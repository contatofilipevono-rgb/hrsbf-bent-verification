import H12CloudChart0Data238

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound60652 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38047,46496,33887,1025,32768,41184,46480,33000,8494,8328,38312,131,1344,46576,48277,12721,4328,256,37356,46497,513]

theorem envBound60653 : H12AffineFastState.Bounded env60653 := by
  intro p hp
  have h : env60653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60652_60653 : H12AffineEnvironment.transform 15 38047 env60652 = env60653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env60652 == env60653) = true)

theorem identity60653 : scanCanonicalize (H12AffineFastState.compose env60653 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 5560) := by decide +kernel

theorem selectedBound60653 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,5560,295,8216,4583,1025,5560,13656,8232,5456,8494,8328,16,131,1344,8264,10541,12721,4328,256,1108,8217,513]

theorem envBound60654 : H12AffineFastState.Bounded env60654 := by
  intro p hp
  have h : env60654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60653_60654 : H12AffineEnvironment.transform 14 5560 env60653 = env60654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5560 env60653 == env60654) = true)

theorem identity60654 : scanCanonicalize (H12AffineFastState.compose env60654 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound60654 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1345,1108,295,8216,11,1025,1108,9396,8232,1212,8494,8328,16,131,1344,8264,10541,8285,260,256,1108,8217,513]

theorem envBound60655 : H12AffineFastState.Bounded env60655 := by
  intro p hp
  have h : env60655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60654_60655 : H12AffineEnvironment.transform 11 492 env60654 = env60655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env60654 == env60655) = true)

theorem identity60655 : scanCanonicalize (H12AffineFastState.compose env60655 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2991) := by decide +kernel

theorem selectedBound60655 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,2991,1345,1108,295,2999,11,1025,1108,3867,2951,1212,2689,2855,16,131,1344,3047,642,3058,260,256,1108,2998,513]

theorem envBound60656 : H12AffineFastState.Bounded env60656 := by
  intro p hp
  have h : env60656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60655_60656 : H12AffineEnvironment.transform 12 2991 env60655 = env60656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2991 env60655 == env60656) = true)

theorem identity60656 : scanCanonicalize (H12AffineFastState.compose env60656 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound60656 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env60657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,522,492,421,1345,1108,295,445,11,1025,1108,1297,397,1212,139,301,16,131,1344,493,642,504,260,256,1108,444,513]

theorem envBound60657 : H12AffineFastState.Bounded env60657 := by
  intro p hp
  have h : env60657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60656_60657 : H12AffineEnvironment.transform 10 522 env60656 = env60657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env60656 == env60657) = true)

theorem identity60657 : scanCanonicalize (H12AffineFastState.compose env60657 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound60657 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60658 : List Nat := [2,4,8,16,32,64,128,256,216,1024,210,492,421,1345,1108,295,445,11,1025,1108,1297,397,1212,139,301,16,131,1344,493,90,504,260,256,1108,444,217]

theorem envBound60658 : H12AffineFastState.Bounded env60658 := by
  intro p hp
  have h : env60658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60657_60658 : H12AffineEnvironment.transform 8 216 env60657 = env60658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env60657 == env60658) = true)

theorem identity60658 : scanCanonicalize (H12AffineFastState.compose env60658 (packedSelected [1,3,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60658 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env60659 : List Nat := [2,4,8,16,32,17,128,256,137,1024,131,445,421,1296,1029,295,445,11,1025,1029,1297,397,1212,139,301,16,131,1297,444,11,425,260,256,1029,444,136]

theorem envBound60659 : H12AffineFastState.Bounded env60659 := by
  intro p hp
  have h : env60659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60658_60659 : H12AffineEnvironment.transform 5 17 env60658 = env60659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60658 == env60659) = true)

def env60660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136513,46481,144712,169102,26056,157001,311708,16385,131152,93514,200846,209367,256,81971,131073,18241]

theorem envBound60660 : H12AffineFastState.Bounded env60660 := by
  intro p hp
  have h : env60660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60627_60660 : H12AffineEnvironment.transform 20 136513 env60627 = env60660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env60627 == env60660) = true)

def env60661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1025,32768,136513,46481,144712,169102,26056,157001,103452,16385,131152,93514,200846,209367,256,81971,131073,18241]

theorem envBound60661 : H12AffineFastState.Bounded env60661 := by
  intro p hp
  have h : env60661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60660_60661 : H12AffineEnvironment.transform 17 87424 env60660 = env60661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env60660 == env60661) = true)

theorem identity60661 : scanCanonicalize (H12AffineFastState.compose env60661 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 94575) := by decide +kernel

theorem selectedBound60661 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,94575,87424,1025,32768,91182,46481,82983,124385,26056,70694,103452,16385,94527,93514,25057,16568,256,81971,94574,18241]

theorem envBound60662 : H12AffineFastState.Bounded env60662 := by
  intro p hp
  have h : env60662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60661_60662 : H12AffineEnvironment.transform 16 94575 env60661 = env60662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 94575 env60661 == env60662) = true)

def env60663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,78895,69824,1025,32768,74094,46481,65895,106657,8328,70694,103452,1345,78975,75786,9377,1528,256,66931,78894,513]

theorem envBound60663 : H12AffineFastState.Bounded env60663 := by
  intro p hp
  have h : env60663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60662_60663 : H12AffineEnvironment.transform 13 1344 env60662 = env60663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60662 == env60663) = true)

theorem identity60663 : scanCanonicalize (H12AffineFastState.compose env60663 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound60663 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38046,41137,33886,1025,32768,46576,46481,38393,13375,8328,32952,130,1345,41185,48276,9377,1528,256,37357,41136,513]

theorem envBound60664 : H12AffineFastState.Bounded env60664 := by
  intro p hp
  have h : env60664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60663_60664 : H12AffineEnvironment.transform 15 38046 env60663 = env60664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env60663 == env60664) = true)

theorem identity60664 : scanCanonicalize (H12AffineFastState.compose env60664 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 168) := by decide +kernel

theorem selectedBound60664 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,168,5174,8217,1270,1025,168,13656,13625,5457,13375,8328,16,130,1345,8265,15420,9377,1528,256,4421,8216,513]

theorem envBound60665 : H12AffineFastState.Bounded env60665 := by
  intro p hp
  have h : env60665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60664_60665 : H12AffineEnvironment.transform 14 168 env60664 = env60665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 168 env60664 == env60665) = true)

theorem identity60665 : scanCanonicalize (H12AffineFastState.compose env60665 (packedSelected [25] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound60665 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60666 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,444,168,4298,8217,10,253,168,12708,12741,4525,12483,8328,16,130,445,8265,14528,8285,260,256,4421,8216,513]

theorem envBound60666 : H12AffineFastState.Bounded env60666 := by
  intro p hp
  have h : env60666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60665_60666 : H12AffineEnvironment.transform 9 252 env60665 = env60666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env60665 == env60666) = true)

theorem identity60666 : scanCanonicalize (H12AffineFastState.compose env60666 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2991) := by decide +kernel

theorem selectedBound60666 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60667 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,2991,444,168,4298,2998,10,253,168,6667,6762,4525,7020,2855,16,130,445,3046,4975,3058,260,256,4421,2999,513]

theorem envBound60667 : H12AffineFastState.Bounded env60667 := by
  intro p hp
  have h : env60667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60666_60667 : H12AffineEnvironment.transform 12 2991 env60666 = env60667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2991 env60666 == env60667) = true)

theorem identity60667 : scanCanonicalize (H12AffineFastState.compose env60667 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 3047) := by decide +kernel

theorem selectedBound60667 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env60668 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,3047,2991,444,168,2861,2998,10,253,168,492,397,2634,139,2855,16,130,445,3046,2184,3058,260,256,2722,2999,513]

theorem envBound60668 : H12AffineFastState.Bounded env60668 := by
  intro p hp
  have h : env60668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60667_60668 : H12AffineEnvironment.transform 11 3047 env60667 = env60668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3047 env60667 == env60668) = true)

theorem identity60668 : scanCanonicalize (H12AffineFastState.compose env60668 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound60668 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60669 : List Nat := [2,4,8,16,32,64,128,256,217,252,2048,2366,2422,444,168,2548,2415,10,253,168,492,397,2195,139,2558,16,130,445,2367,2184,2347,260,256,2171,2414,216]

theorem envBound60669 : H12AffineFastState.Bounded env60669 := by
  intro p hp
  have h : env60669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60668_60669 : H12AffineEnvironment.transform 8 217 env60668 = env60669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env60668 == env60669) = true)

theorem identity60669 : scanCanonicalize (H12AffineFastState.compose env60669 (packedSelected [1,3,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60669 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env60670 : List Nat := [2,4,8,16,32,17,128,256,136,173,2048,2366,2343,444,168,2469,2366,10,172,168,445,397,2195,139,2479,16,130,445,2367,2184,2347,260,256,2090,2367,137]

theorem envBound60670 : H12AffineFastState.Bounded env60670 := by
  intro p hp
  have h : env60670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60669_60670 : H12AffineEnvironment.transform 5 17 env60669 = env60670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60669 == env60670) = true)

theorem identity60670 : scanCanonicalize (H12AffineFastState.compose env60670 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound60670 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60671 : List Nat := [2,4,8,16,32,17,128,256,136,173,131,445,420,444,168,294,445,10,172,168,445,397,16,139,300,16,130,445,444,11,424,260,256,169,444,137]

theorem envBound60671 : H12AffineFastState.Bounded env60671 := by
  intro p hp
  have h : env60671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60670_60671 : H12AffineEnvironment.transform 10 131 env60670 = env60671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env60670 == env60671) = true)

theorem identity60671 : scanCanonicalize (H12AffineFastState.compose env60671 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound60671 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60672 : List Nat := [2,4,8,16,32,17,34,256,42,15,33,287,262,286,10,294,287,10,14,10,287,303,16,41,300,16,32,287,286,11,266,260,256,11,286,43]

theorem envBound60672 : H12AffineFastState.Bounded env60672 := by
  intro p hp
  have h : env60672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60671_60672 : H12AffineEnvironment.transform 6 34 env60671 = env60672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env60671 == env60672) = true)

theorem identity60672 : scanCanonicalize (H12AffineFastState.compose env60672 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 54) := by decide +kernel

theorem selectedBound60672 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60673 : List Nat := [2,4,8,16,32,17,34,54,42,15,33,41,48,40,10,16,41,10,14,10,41,25,16,41,26,16,32,41,40,11,60,50,54,11,40,43]

theorem envBound60673 : H12AffineFastState.Bounded env60673 := by
  intro p hp
  have h : env60673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60672_60673 : H12AffineEnvironment.transform 7 54 env60672 = env60673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 54 env60672 == env60673) = true)

theorem identity60673 : scanCanonicalize (H12AffineFastState.compose env60673 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound60673 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env60674 : List Nat := [2,4,8,16,9,17,11,31,3,15,8,0,25,1,10,16,0,10,14,10,0,25,16,0,26,16,9,0,1,11,21,27,31,11,1,2]

theorem envBound60674 : H12AffineFastState.Bounded env60674 := by
  intro p hp
  have h : env60674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60673_60674 : H12AffineEnvironment.transform 4 9 env60673 = env60674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env60673 == env60674) = true)

theorem identity60674 : scanCanonicalize (H12AffineFastState.compose env60674 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60674 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60675 : List Nat := [1,4,8,16,9,17,8,28,0,12,8,0,25,1,9,16,0,9,13,9,0,25,16,0,25,16,9,0,1,8,21,24,28,8,1,1]

theorem envBound60675 : H12AffineFastState.Bounded env60675 := by
  intro p hp
  have h : env60675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60674_60675 : H12AffineEnvironment.transform 0 1 env60674 = env60675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60674 == env60675) = true)

theorem identity60675 : scanCanonicalize (H12AffineFastState.compose env60675 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound60675 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60676 : List Nat := [1,4,8,8,9,9,8,4,0,12,8,0,1,1,9,8,0,9,13,9,0,1,8,0,1,8,9,0,1,8,13,0,4,8,1,1]

theorem envBound60676 : H12AffineFastState.Bounded env60676 := by
  intro p hp
  have h : env60676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60675_60676 : H12AffineEnvironment.transform 3 8 env60675 = env60676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env60675 == env60676) = true)

theorem identity60676 : scanCanonicalize (H12AffineFastState.compose env60676 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60676 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env60677 : List Nat := [1,4,0,0,1,1,0,4,0,4,0,0,1,1,1,0,0,1,5,1,0,1,0,0,1,0,1,0,1,0,5,0,4,0,1,1]

theorem envBound60677 : H12AffineFastState.Bounded env60677 := by
  intro p hp
  have h : env60677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60676_60677 : H12AffineEnvironment.transform 2 0 env60676 = env60677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60676 == env60677) = true)

def env60678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,78894,69825,1025,32768,74095,46481,65894,106656,8329,70694,103452,1344,78974,75787,9376,1529,256,66930,78895,512]

theorem envBound60678 : H12AffineFastState.Bounded env60678 := by
  intro p hp
  have h : env60678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60662_60678 : H12AffineEnvironment.transform 13 1345 env60662 = env60678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60662 == env60678) = true)

theorem identity60678 : scanCanonicalize (H12AffineFastState.compose env60678 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound60678 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,74047,67024,1025,32768,74095,41088,65894,106656,8329,65847,98573,1344,74095,75787,9376,1529,256,66930,74046,512]

theorem envBound60679 : H12AffineFastState.Bounded env60679 := by
  intro p hp
  have h : env60679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60678_60679 : H12AffineEnvironment.transform 11 1297 env60678 = env60679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env60678 == env60679) = true)

def env60680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1025,32768,136513,46481,144712,169102,26056,157001,103453,16385,131152,93514,200846,209367,256,81971,131073,18241]

theorem envBound60680 : H12AffineFastState.Bounded env60680 := by
  intro p hp
  have h : env60680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60660_60680 : H12AffineEnvironment.transform 17 87425 env60660 = env60680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env60660 == env60680) = true)

theorem identity60680 : scanCanonicalize (H12AffineFastState.compose env60680 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 78895) := by decide +kernel

theorem selectedBound60680 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78895,87425,1025,32768,74094,46481,65895,106657,26056,86374,103453,16385,78975,93514,9377,1528,256,81971,78894,18241]

theorem envBound60681 : H12AffineFastState.Bounded env60681 := by
  intro p hp
  have h : env60681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60680_60681 : H12AffineEnvironment.transform 16 78895 env60680 = env60681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78895 env60680 == env60681) = true)

def env60682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,78895,69825,1025,32768,74094,46481,65895,106657,8328,70694,103453,1345,78975,75786,9377,1528,256,66931,78894,513]

theorem envBound60682 : H12AffineFastState.Bounded env60682 := by
  intro p hp
  have h : env60682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60681_60682 : H12AffineEnvironment.transform 13 1344 env60681 = env60682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60681 == env60682) = true)

theorem identity60682 : scanCanonicalize (H12AffineFastState.compose env60682 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound60682 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38046,41137,33887,1025,32768,46576,46481,38393,13375,8328,32952,131,1345,41185,48276,9377,1528,256,37357,41136,513]

theorem envBound60683 : H12AffineFastState.Bounded env60683 := by
  intro p hp
  have h : env60683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60682_60683 : H12AffineEnvironment.transform 15 38046 env60682 = env60683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env60682 == env60683) = true)

theorem identity60683 : scanCanonicalize (H12AffineFastState.compose env60683 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 168) := by decide +kernel

theorem selectedBound60683 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,168,5174,8217,1271,1025,168,13656,13625,5457,13375,8328,16,131,1345,8265,15420,9377,1528,256,4421,8216,513]

theorem envBound60684 : H12AffineFastState.Bounded env60684 := by
  intro p hp
  have h : env60684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60683_60684 : H12AffineEnvironment.transform 14 168 env60683 = env60684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 168 env60683 == env60684) = true)

theorem identity60684 : scanCanonicalize (H12AffineFastState.compose env60684 (packedSelected [25] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound60684 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60685 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,444,168,4298,8217,11,253,168,12708,12741,4525,12483,8328,16,131,445,8265,14528,8285,260,256,4421,8216,513]

theorem envBound60685 : H12AffineFastState.Bounded env60685 := by
  intro p hp
  have h : env60685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60684_60685 : H12AffineEnvironment.transform 9 252 env60684 = env60685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env60684 == env60685) = true)

theorem identity60685 : scanCanonicalize (H12AffineFastState.compose env60685 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2991) := by decide +kernel

theorem selectedBound60685 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60686 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,2991,444,168,4298,2998,11,253,168,6667,6762,4525,7020,2855,16,131,445,3046,4975,3058,260,256,4421,2999,513]

theorem envBound60686 : H12AffineFastState.Bounded env60686 := by
  intro p hp
  have h : env60686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60685_60686 : H12AffineEnvironment.transform 12 2991 env60685 = env60686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2991 env60685 == env60686) = true)

theorem identity60686 : scanCanonicalize (H12AffineFastState.compose env60686 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 3047) := by decide +kernel

theorem selectedBound60686 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env60687 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,3047,2991,444,168,2861,2998,11,253,168,492,397,2634,139,2855,16,131,445,3046,2184,3058,260,256,2722,2999,513]

theorem envBound60687 : H12AffineFastState.Bounded env60687 := by
  intro p hp
  have h : env60687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60686_60687 : H12AffineEnvironment.transform 11 3047 env60686 = env60687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3047 env60686 == env60687) = true)

theorem identity60687 : scanCanonicalize (H12AffineFastState.compose env60687 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound60687 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60688 : List Nat := [2,4,8,16,32,64,128,256,217,252,2048,2366,2422,444,168,2548,2415,11,253,168,492,397,2195,139,2558,16,131,445,2367,2184,2347,260,256,2171,2414,216]

theorem envBound60688 : H12AffineFastState.Bounded env60688 := by
  intro p hp
  have h : env60688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60687_60688 : H12AffineEnvironment.transform 8 217 env60687 = env60688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env60687 == env60688) = true)

theorem identity60688 : scanCanonicalize (H12AffineFastState.compose env60688 (packedSelected [1,3,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60688 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env60689 : List Nat := [2,4,8,16,32,16,128,256,137,172,2048,2366,2342,444,168,2468,2367,11,173,168,444,397,2195,139,2478,16,131,445,2367,2184,2347,260,256,2091,2366,136]

theorem envBound60689 : H12AffineFastState.Bounded env60689 := by
  intro p hp
  have h : env60689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60688_60689 : H12AffineEnvironment.transform 5 16 env60688 = env60689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60688 == env60689) = true)

theorem identity60689 : scanCanonicalize (H12AffineFastState.compose env60689 (packedSelected [3,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound60689 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env60690 : List Nat := [2,4,8,16,32,16,128,14,137,172,2048,2096,2088,178,168,2218,2097,11,173,168,178,131,2195,139,2208,16,131,179,2097,2184,2085,10,14,2091,2096,136]

theorem envBound60690 : H12AffineFastState.Bounded env60690 := by
  intro p hp
  have h : env60690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60689_60690 : H12AffineEnvironment.transform 7 14 env60689 = env60690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env60689 == env60690) = true)

theorem identity60690 : scanCanonicalize (H12AffineFastState.compose env60690 (packedSelected [0,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound60690 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env60691 : List Nat := [2,4,8,9,32,9,128,14,137,172,2048,2089,2088,171,168,2218,2088,11,173,168,171,131,2186,139,2208,9,131,170,2088,2184,2085,10,14,2091,2089,136]

theorem envBound60691 : H12AffineFastState.Bounded env60691 := by
  intro p hp
  have h : env60691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60690_60691 : H12AffineEnvironment.transform 3 9 env60690 = env60691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env60690 == env60691) = true)

theorem identity60691 : scanCanonicalize (H12AffineFastState.compose env60691 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound60691 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env60692 : List Nat := [2,4,8,9,32,9,8,14,1,36,2048,2089,2088,35,32,2082,2088,11,37,32,35,11,2050,3,2088,9,11,34,2088,2048,2085,10,14,2091,2089,0]

theorem envBound60692 : H12AffineFastState.Bounded env60692 := by
  intro p hp
  have h : env60692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60691_60692 : H12AffineEnvironment.transform 6 8 env60691 = env60692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env60691 == env60692) = true)

theorem identity60692 : scanCanonicalize (H12AffineFastState.compose env60692 (packedSelected [4,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound60692 : packedSelected [4,8,11] rootPS < 2^1333 := by decide +kernel

def env60693 : List Nat := [2,4,8,9,11,9,8,14,1,15,2048,2050,2051,8,11,2057,2051,11,14,11,8,11,2050,3,2051,9,11,9,2051,2048,2062,10,14,2048,2050,0]

theorem envBound60693 : H12AffineFastState.Bounded env60693 := by
  intro p hp
  have h : env60693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60692_60693 : H12AffineEnvironment.transform 4 11 env60692 = env60693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env60692 == env60693) = true)

theorem identity60693 : scanCanonicalize (H12AffineFastState.compose env60693 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 8) := by decide +kernel

theorem selectedBound60693 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60694 : List Nat := [2,4,8,9,11,9,8,14,1,15,8,10,11,8,11,1,11,11,14,11,8,11,10,3,11,9,11,9,11,8,6,10,14,8,10,0]

theorem envBound60694 : H12AffineFastState.Bounded env60694 := by
  intro p hp
  have h : env60694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60693_60694 : H12AffineEnvironment.transform 10 8 env60693 = env60694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 8 env60693 == env60694) = true)

def env60695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,78895,69824,1025,32768,74094,46481,65895,106657,8329,70695,103453,1344,78975,75787,9377,1528,256,66930,78894,512]

theorem envBound60695 : H12AffineFastState.Bounded env60695 := by
  intro p hp
  have h : env60695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60681_60695 : H12AffineEnvironment.transform 13 1345 env60681 = env60695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60681 == env60695) = true)

theorem identity60695 : scanCanonicalize (H12AffineFastState.compose env60695 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound60695 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,74046,67025,1025,32768,74094,41088,65895,106657,8329,65846,98572,1344,74094,75787,9377,1528,256,66930,74047,512]

theorem envBound60696 : H12AffineFastState.Bounded env60696 := by
  intro p hp
  have h : env60696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60695_60696 : H12AffineEnvironment.transform 11 1297 env60695 = env60696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env60695 == env60696) = true)

def env60697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,2269393,144713,169103,2257032,157000,2544861,16385,131152,2324490,200847,209367,256,2315634,131073,2249217]

theorem envBound60697 : H12AffineFastState.Bounded env60697 := by
  intro p hp
  have h : env60697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60626_60697 : H12AffineEnvironment.transform 21 2269393 env60626 = env60697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269393 env60626 == env60697) = true)

def env60698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136512,46481,144713,169103,26056,157000,311709,16385,131152,93514,200847,209367,256,81970,131073,18241]

theorem envBound60698 : H12AffineFastState.Bounded env60698 := by
  intro p hp
  have h : env60698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60697_60698 : H12AffineEnvironment.transform 20 136512 env60697 = env60698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env60697 == env60698) = true)

def env60699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1025,32768,136512,46481,144713,169103,26056,157000,103453,16385,131152,93514,200847,209367,256,81970,131073,18241]

theorem envBound60699 : H12AffineFastState.Bounded env60699 := by
  intro p hp
  have h : env60699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60698_60699 : H12AffineEnvironment.transform 17 87424 env60698 = env60699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env60698 == env60699) = true)

theorem identity60699 : scanCanonicalize (H12AffineFastState.compose env60699 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 70006) := by decide +kernel

theorem selectedBound60699 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70006,87424,1025,32768,66614,46481,74815,99833,26056,95294,103453,16385,69926,93514,505,8353,256,81970,70007,18241]

theorem envBound60700 : H12AffineFastState.Bounded env60700 := by
  intro p hp
  have h : env60700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60699_60700 : H12AffineEnvironment.transform 16 70006 env60699 = env60700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70006 env60699 == env60700) = true)

def env60701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,70006,69824,1025,32768,66614,46481,74815,99833,8328,78206,103453,1345,69926,75786,505,8353,256,66930,70007,513]

theorem envBound60701 : H12AffineFastState.Bounded env60701 := by
  intro p hp
  have h : env60701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60700_60701 : H12AffineEnvironment.transform 13 1344 env60700 = env60701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60700 == env60701) = true)

theorem identity60701 : scanCanonicalize (H12AffineFastState.compose env60701 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound60701 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38047,34281,33887,1025,32768,37033,46481,45216,4454,8328,42465,130,1345,34233,48277,505,8353,256,37357,34280,513]

theorem envBound60702 : H12AffineFastState.Bounded env60702 := by
  intro p hp
  have h : env60702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60701_60702 : H12AffineEnvironment.transform 15 38047 env60701 = env60702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env60701 == env60702) = true)

theorem identity60702 : scanCanonicalize (H12AffineFastState.compose env60702 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 9712) := by decide +kernel

theorem selectedBound60702 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,9712,12655,8217,8623,1025,9712,13657,4193,5456,4454,8328,17,130,1345,8265,6501,505,8353,256,13341,8216,513]

theorem envBound60703 : H12AffineFastState.Bounded env60703 := by
  intro p hp
  have h : env60703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60702_60703 : H12AffineEnvironment.transform 14 9712 env60702 = env60703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9712 env60702 == env60703) = true)

theorem identity60703 : scanCanonicalize (H12AffineFastState.compose env60703 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound60703 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1344,1109,4298,444,10,1025,1109,5372,4193,5456,4454,301,17,130,1345,492,6501,505,260,256,5560,445,513]

theorem envBound60704 : H12AffineFastState.Bounded env60704 := by
  intro p hp
  have h : env60704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60703_60704 : H12AffineEnvironment.transform 12 421 env60703 = env60704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env60703 == env60704) = true)

theorem identity60704 : scanCanonicalize (H12AffineFastState.compose env60704 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 934) := by decide +kernel

theorem selectedBound60704 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,934,4096,421,1344,1109,4298,444,10,1025,1109,5372,4193,5456,4454,301,17,130,1345,492,4803,505,260,256,5560,445,513]

theorem envBound60705 : H12AffineFastState.Bounded env60705 := by
  intro p hp
  have h : env60705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60704_60705 : H12AffineEnvironment.transform 10 934 env60704 = env60705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 934 env60704 == env60705) = true)

theorem identity60705 : scanCanonicalize (H12AffineFastState.compose env60705 (packedSelected [0,1,5,7,10,13,16] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound60705 : packedSelected [0,1,5,7,10,13,16] rootPS < 2^1333 := by decide +kernel

def env60706 : List Nat := [2,4,8,16,32,64,128,256,512,172,934,4096,421,492,249,4298,444,10,173,249,4176,4193,4604,4454,301,17,130,493,492,4803,505,260,256,4372,445,513]

theorem envBound60706 : H12AffineFastState.Bounded env60706 := by
  intro p hp
  have h : env60706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60705_60706 : H12AffineEnvironment.transform 9 172 env60705 = env60706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env60705 == env60706) = true)

theorem identity60706 : scanCanonicalize (H12AffineFastState.compose env60706 (packedSelected [1,4,5,9,10,13,20] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound60706 : packedSelected [1,4,5,9,10,13,20] rootPS < 2^1333 := by decide +kernel

def env60707 : List Nat := [2,4,8,16,32,64,128,256,512,172,934,64,421,492,249,138,444,10,173,249,16,33,444,294,301,17,130,493,492,643,505,260,256,340,445,513]

theorem envBound60707 : H12AffineFastState.Bounded env60707 := by
  intro p hp
  have h : env60707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60706_60707 : H12AffineEnvironment.transform 11 64 env60706 = env60707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env60706 == env60707) = true)

theorem identity60707 : scanCanonicalize (H12AffineFastState.compose env60707 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound60707 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60708 : List Nat := [2,4,8,16,32,64,128,256,216,172,382,64,421,492,249,138,444,10,173,249,16,33,444,294,301,17,130,493,492,91,505,260,256,340,445,217]

theorem envBound60708 : H12AffineFastState.Bounded env60708 := by
  intro p hp
  have h : env60708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60707_60708 : H12AffineEnvironment.transform 8 216 env60707 = env60708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env60707 == env60708) = true)

theorem identity60708 : scanCanonicalize (H12AffineFastState.compose env60708 (packedSelected [0,1,2,3,5,7,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound60708 : packedSelected [0,1,2,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env60709 : List Nat := [2,4,8,16,32,64,66,256,26,110,382,64,359,302,59,72,382,10,111,59,16,33,382,294,301,17,64,303,302,91,315,260,256,340,383,27]

theorem envBound60709 : H12AffineFastState.Bounded env60709 := by
  intro p hp
  have h : env60709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60708_60709 : H12AffineEnvironment.transform 6 66 env60708 = env60709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env60708 == env60709) = true)

theorem identity60709 : scanCanonicalize (H12AffineFastState.compose env60709 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound60709 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env60710 : List Nat := [2,4,8,16,32,64,66,36,26,110,90,64,67,10,59,72,90,10,111,59,16,33,90,2,9,17,64,11,10,91,31,32,36,112,91,27]

theorem envBound60710 : H12AffineFastState.Bounded env60710 := by
  intro p hp
  have h : env60710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60709_60710 : H12AffineEnvironment.transform 7 36 env60709 = env60710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env60709 == env60710) = true)

theorem identity60710 : scanCanonicalize (H12AffineFastState.compose env60710 (packedSelected [1,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound60710 : packedSelected [1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env60711 : List Nat := [2,4,8,16,19,64,66,23,26,93,90,64,67,10,8,72,90,10,92,8,16,18,90,2,9,17,64,11,10,91,31,19,23,67,91,27]

theorem envBound60711 : H12AffineFastState.Bounded env60711 := by
  intro p hp
  have h : env60711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60710_60711 : H12AffineEnvironment.transform 4 19 env60710 = env60711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env60710 == env60711) = true)

theorem identity60711 : scanCanonicalize (H12AffineFastState.compose env60711 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound60711 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60712 : List Nat := [2,4,8,16,19,11,9,23,26,22,17,11,8,10,8,3,17,10,23,8,16,18,17,2,9,17,11,11,10,16,31,19,23,8,16,27]

theorem envBound60712 : H12AffineFastState.Bounded env60712 := by
  intro p hp
  have h : env60712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60711_60712 : H12AffineEnvironment.transform 5 11 env60711 = env60712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env60711 == env60712) = true)

theorem identity60712 : scanCanonicalize (H12AffineFastState.compose env60712 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound60712 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60713 : List Nat := [2,4,8,9,10,11,9,14,3,15,8,11,8,10,8,3,8,10,14,8,9,11,8,2,9,8,11,11,10,9,6,10,14,8,9,2]

theorem envBound60713 : H12AffineFastState.Bounded env60713 := by
  intro p hp
  have h : env60713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60712_60713 : H12AffineEnvironment.transform 3 9 env60712 = env60713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env60712 == env60713) = true)

def env60714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,70006,69825,1025,32768,66614,46481,74815,99833,8329,78207,103453,1344,69926,75787,505,8353,256,66931,70007,512]

theorem envBound60714 : H12AffineFastState.Bounded env60714 := by
  intro p hp
  have h : env60714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60700_60714 : H12AffineEnvironment.transform 13 1345 env60700 = env60714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60700 == env60714) = true)

theorem identity60714 : scanCanonicalize (H12AffineFastState.compose env60714 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound60714 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,66663,67024,1025,32768,66614,41088,74815,99833,8329,74862,98572,1344,66615,75787,505,8353,256,66931,66662,512]

theorem envBound60715 : H12AffineFastState.Bounded env60715 := by
  intro p hp
  have h : env60715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60714_60715 : H12AffineEnvironment.transform 11 1297 env60714 = env60715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env60714 == env60715) = true)

def env60716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1025,32768,136512,46481,144713,169103,26056,157000,103452,16385,131152,93514,200847,209367,256,81970,131073,18241]

theorem envBound60716 : H12AffineFastState.Bounded env60716 := by
  intro p hp
  have h : env60716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60698_60716 : H12AffineEnvironment.transform 17 87425 env60698 = env60716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env60698 == env60716) = true)

theorem identity60716 : scanCanonicalize (H12AffineFastState.compose env60716 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 87094) := by decide +kernel

theorem selectedBound60716 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,87094,87425,1025,32768,82294,46481,90495,114873,26056,78206,103452,16385,87142,93514,17593,26081,256,81970,87095,18241]

theorem envBound60717 : H12AffineFastState.Bounded env60717 := by
  intro p hp
  have h : env60717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60716_60717 : H12AffineEnvironment.transform 16 87094 env60716 = env60717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 87094 env60716 == env60717) = true)

def env60718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,70006,69825,1025,32768,66614,46481,74815,99833,8328,78206,103452,1345,69926,75786,505,8353,256,66930,70007,513]

theorem envBound60718 : H12AffineFastState.Bounded env60718 := by
  intro p hp
  have h : env60718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60717_60718 : H12AffineEnvironment.transform 13 1344 env60717 = env60718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60717 == env60718) = true)

theorem identity60718 : scanCanonicalize (H12AffineFastState.compose env60718 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound60718 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38047,34281,33886,1025,32768,37033,46481,45216,4454,8328,42465,131,1345,34233,48277,505,8353,256,37357,34280,513]

theorem envBound60719 : H12AffineFastState.Bounded env60719 := by
  intro p hp
  have h : env60719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60718_60719 : H12AffineEnvironment.transform 15 38047 env60718 = env60719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env60718 == env60719) = true)

theorem identity60719 : scanCanonicalize (H12AffineFastState.compose env60719 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 9712) := by decide +kernel

theorem selectedBound60719 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,9712,12655,8217,8622,1025,9712,13657,4193,5456,4454,8328,17,131,1345,8265,6501,505,8353,256,13341,8216,513]

theorem envBound60720 : H12AffineFastState.Bounded env60720 := by
  intro p hp
  have h : env60720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60719_60720 : H12AffineEnvironment.transform 14 9712 env60719 = env60720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9712 env60719 == env60720) = true)

theorem identity60720 : scanCanonicalize (H12AffineFastState.compose env60720 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound60720 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1344,1109,4298,444,11,1025,1109,5372,4193,5456,4454,301,17,131,1345,492,6501,505,260,256,5560,445,513]

theorem envBound60721 : H12AffineFastState.Bounded env60721 := by
  intro p hp
  have h : env60721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60720_60721 : H12AffineEnvironment.transform 12 421 env60720 = env60721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env60720 == env60721) = true)

theorem identity60721 : scanCanonicalize (H12AffineFastState.compose env60721 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 934) := by decide +kernel

theorem selectedBound60721 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,934,4096,421,1344,1109,4298,444,11,1025,1109,5372,4193,5456,4454,301,17,131,1345,492,4803,505,260,256,5560,445,513]

theorem envBound60722 : H12AffineFastState.Bounded env60722 := by
  intro p hp
  have h : env60722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60721_60722 : H12AffineEnvironment.transform 10 934 env60721 = env60722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 934 env60721 == env60722) = true)

theorem identity60722 : scanCanonicalize (H12AffineFastState.compose env60722 (packedSelected [0,1,5,7,10,13,16] rootPS)) = affineNative (2^(11+1) ^^^ 445) := by decide +kernel

theorem selectedBound60722 : packedSelected [0,1,5,7,10,13,16] rootPS < 2^1333 := by decide +kernel

def env60723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,934,445,421,1344,1109,375,444,11,1025,1109,1345,476,1261,219,301,17,131,1345,492,894,505,260,256,1029,445,513]

theorem envBound60723 : H12AffineFastState.Bounded env60723 := by
  intro p hp
  have h : env60723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60722_60723 : H12AffineEnvironment.transform 11 445 env60722 = env60723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 445 env60722 == env60723) = true)

theorem identity60723 : scanCanonicalize (H12AffineFastState.compose env60723 (packedSelected [1,4,5,9,10,13,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound60723 : packedSelected [1,4,5,9,10,13,20] rootPS < 2^1333 := by decide +kernel

def env60724 : List Nat := [2,4,8,16,32,64,128,253,512,1024,603,64,88,1213,1109,138,65,11,1025,1109,1212,33,1261,219,208,17,131,1212,17,643,4,249,253,1029,64,513]

theorem envBound60724 : H12AffineFastState.Bounded env60724 := by
  intro p hp
  have h : env60724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60723_60724 : H12AffineEnvironment.transform 7 253 env60723 = env60724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env60723 == env60724) = true)

theorem identity60724 : scanCanonicalize (H12AffineFastState.compose env60724 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound60724 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60725 : List Nat := [2,4,8,16,32,64,128,253,216,1024,131,64,88,1213,1109,138,65,11,1025,1109,1212,33,1261,219,208,17,131,1212,17,91,4,249,253,1029,64,217]

theorem envBound60725 : H12AffineFastState.Bounded env60725 := by
  intro p hp
  have h : env60725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60724_60725 : H12AffineEnvironment.transform 8 216 env60724 = env60725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env60724 == env60725) = true)

theorem identity60725 : scanCanonicalize (H12AffineFastState.compose env60725 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound60725 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60726 : List Nat := [2,4,8,16,32,64,128,253,216,173,131,64,88,16,248,138,65,11,172,248,17,33,64,219,208,17,131,17,17,91,4,249,253,168,64,217]

theorem envBound60726 : H12AffineFastState.Bounded env60726 := by
  intro p hp
  have h : env60726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60725_60726 : H12AffineEnvironment.transform 9 173 env60725 = env60726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env60725 == env60726) = true)

theorem identity60726 : scanCanonicalize (H12AffineFastState.compose env60726 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound60726 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env60727 : List Nat := [2,4,8,16,26,64,128,199,216,151,131,64,88,16,194,138,65,11,150,194,17,27,64,219,208,17,131,17,17,91,4,195,199,146,64,217]

theorem envBound60727 : H12AffineFastState.Bounded env60727 := by
  intro p hp
  have h : env60727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60726_60727 : H12AffineEnvironment.transform 4 26 env60726 = env60727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env60726 == env60727) = true)

theorem identity60727 : scanCanonicalize (H12AffineFastState.compose env60727 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound60727 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env60728 : List Nat := [2,4,8,16,26,64,9,78,81,30,10,64,88,16,75,3,65,11,31,75,17,27,64,82,89,17,10,17,17,91,4,74,78,27,64,80]

theorem envBound60728 : H12AffineFastState.Bounded env60728 := by
  intro p hp
  have h : env60728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60727_60728 : H12AffineEnvironment.transform 6 9 env60727 = env60728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env60727 == env60728) = true)

theorem identity60728 : scanCanonicalize (H12AffineFastState.compose env60728 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound60728 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60729 : List Nat := [2,4,8,9,3,64,9,78,72,7,10,64,65,9,75,3,65,11,6,75,8,2,64,75,64,8,10,8,8,66,4,74,78,2,64,73]

theorem envBound60729 : H12AffineFastState.Bounded env60729 := by
  intro p hp
  have h : env60729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60728_60729 : H12AffineEnvironment.transform 3 9 env60728 = env60729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env60728 == env60729) = true)

theorem identity60729 : scanCanonicalize (H12AffineFastState.compose env60729 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound60729 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60730 : List Nat := [2,4,8,9,3,0,9,14,8,7,10,0,1,9,11,3,1,11,6,11,8,2,0,11,0,8,10,8,8,2,4,10,14,2,0,9]

theorem envBound60730 : H12AffineFastState.Bounded env60730 := by
  intro p hp
  have h : env60730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60729_60730 : H12AffineEnvironment.transform 5 0 env60729 = env60730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env60729 == env60730) = true)

theorem identity60730 : scanCanonicalize (H12AffineFastState.compose env60730 (packedSelected [2,7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60730 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env60731 : List Nat := [1,4,8,9,0,0,9,13,8,4,9,0,1,9,8,0,1,8,5,8,8,1,0,8,0,8,9,8,8,1,4,9,13,1,0,9]

theorem envBound60731 : H12AffineFastState.Bounded env60731 := by
  intro p hp
  have h : env60731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60730_60731 : H12AffineEnvironment.transform 0 1 env60730 = env60731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60730 == env60731) = true)

theorem identity60731 : scanCanonicalize (H12AffineFastState.compose env60731 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60731 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60732 : List Nat := [1,4,1,0,0,0,0,4,1,4,0,0,1,0,1,0,1,1,5,1,1,1,0,1,0,1,0,1,1,1,4,0,4,1,0,0]

theorem envBound60732 : H12AffineFastState.Bounded env60732 := by
  intro p hp
  have h : env60732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60731_60732 : H12AffineEnvironment.transform 2 1 env60731 = env60732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60731 == env60732) = true)

def env60733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,70007,69824,1025,32768,66615,46481,74814,99832,8329,78206,103452,1344,69927,75787,504,8352,256,66931,70006,512]

theorem envBound60733 : H12AffineFastState.Bounded env60733 := by
  intro p hp
  have h : env60733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60717_60733 : H12AffineEnvironment.transform 13 1345 env60717 = env60733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60717 == env60733) = true)

theorem identity60733 : scanCanonicalize (H12AffineFastState.compose env60733 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound60733 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,66662,67025,1025,32768,66615,41088,74814,99832,8329,74863,98573,1344,66614,75787,504,8352,256,66931,66663,512]

theorem envBound60734 : H12AffineFastState.Bounded env60734 := by
  intro p hp
  have h : env60734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60733_60734 : H12AffineEnvironment.transform 11 1297 env60733 = env60734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env60733 == env60734) = true)

def env60735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136513,46480,144713,169103,26057,157000,311708,16385,131152,93515,200847,209367,256,81971,131073,18240]

theorem envBound60735 : H12AffineFastState.Bounded env60735 := by
  intro p hp
  have h : env60735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60697_60735 : H12AffineEnvironment.transform 20 136513 env60697 = env60735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env60697 == env60735) = true)

def env60736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1025,32768,136513,46480,144713,169103,26057,157000,103452,16385,131152,93515,200847,209367,256,81971,131073,18240]

theorem envBound60736 : H12AffineFastState.Bounded env60736 := by
  intro p hp
  have h : env60736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60735_60736 : H12AffineEnvironment.transform 17 87424 env60735 = env60736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env60735 == env60736) = true)

theorem identity60736 : scanCanonicalize (H12AffineFastState.compose env60736 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 82215) := by decide +kernel

theorem selectedBound60736 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82215,87424,1025,32768,87142,46480,95342,120232,26057,74863,103452,16385,82295,93515,20904,28912,256,81971,82214,18240]

theorem envBound60737 : H12AffineFastState.Bounded env60737 := by
  intro p hp
  have h : env60737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60736_60737 : H12AffineEnvironment.transform 16 82215 env60736 = env60737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82215 env60736 == env60737) = true)

def env60738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,66663,69824,1025,32768,69926,46480,78126,102632,8329,74863,103452,1345,66615,75787,5352,13744,256,66931,66662,512]

theorem envBound60738 : H12AffineFastState.Bounded env60738 := by
  intro p hp
  have h : env60738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60737_60738 : H12AffineEnvironment.transform 13 1344 env60737 = env60738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60737 == env60738) = true)

theorem identity60738 : scanCanonicalize (H12AffineFastState.compose env60738 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound60738 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,66663,67024,1025,32768,66614,41088,74814,99832,8329,74863,98572,1345,66615,75787,504,8352,256,66931,66662,512]

theorem envBound60739 : H12AffineFastState.Bounded env60739 := by
  intro p hp
  have h : env60739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60738_60739 : H12AffineEnvironment.transform 11 1296 env60738 = env60739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env60738 == env60739) = true)

def env60740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,66662,69825,1025,32768,69927,46480,78127,102633,8328,74863,103452,1344,66614,75786,5353,13745,256,66930,66663,513]

theorem envBound60740 : H12AffineFastState.Bounded env60740 := by
  intro p hp
  have h : env60740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60737_60740 : H12AffineEnvironment.transform 13 1345 env60737 = env60740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60737 == env60740) = true)

theorem identity60740 : scanCanonicalize (H12AffineFastState.compose env60740 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound60740 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38046,37112,33887,1025,32768,34233,46480,42417,1143,8328,45297,130,1344,37032,48276,5353,13745,256,37356,37113,513]

theorem envBound60741 : H12AffineFastState.Bounded env60741 := by
  intro p hp
  have h : env60741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60740_60741 : H12AffineEnvironment.transform 15 38046 env60740 = env60741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env60740 == env60741) = true)

theorem identity60741 : scanCanonicalize (H12AffineFastState.compose env60741 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 12512) := by decide +kernel

theorem selectedBound60741 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,12512,9342,8216,13503,1025,12512,13657,1392,5457,1143,8328,17,130,1344,8264,3188,5353,13745,256,8460,8217,513]

theorem envBound60742 : H12AffineFastState.Bounded env60742 := by
  intro p hp
  have h : env60742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60741_60742 : H12AffineEnvironment.transform 14 12512 env60741 = env60742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12512 env60741 == env60742) = true)

theorem identity60742 : scanCanonicalize (H12AffineFastState.compose env60742 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 5301) := by decide +kernel

theorem selectedBound60742 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1345,1109,4299,5293,10,1025,1109,492,1392,5457,1143,5181,17,130,1344,5373,3188,5353,260,256,5561,5292,513]

theorem envBound60743 : H12AffineFastState.Bounded env60743 := by
  intro p hp
  have h : env60743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60742_60743 : H12AffineEnvironment.transform 12 5301 env60742 = env60743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5301 env60742 == env60743) = true)

theorem identity60743 : scanCanonicalize (H12AffineFastState.compose env60743 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 3766) := by decide +kernel

theorem selectedBound60743 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3766,2563,1345,1109,3709,2587,10,1025,1109,492,1392,3047,1143,2699,17,130,1344,2635,3188,2655,260,256,2831,2586,513]

theorem envBound60744 : H12AffineFastState.Bounded env60744 := by
  intro p hp
  have h : env60744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60743_60744 : H12AffineEnvironment.transform 11 3766 env60743 = env60744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3766 env60743 == env60744) = true)

theorem identity60744 : scanCanonicalize (H12AffineFastState.compose env60744 (packedSelected [0,1,5,7,10,13,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60744 : packedSelected [0,1,5,7,10,13,16] rootPS < 2^1333 := by decide +kernel

def env60745 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3766,2563,1297,1029,3629,2587,10,1025,1029,444,1312,2999,1063,2699,17,130,1296,2587,3108,2575,260,256,2831,2586,513]

theorem envBound60745 : H12AffineFastState.Bounded env60745 := by
  intro p hp
  have h : env60745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60744_60745 : H12AffineEnvironment.transform 5 16 env60744 = env60745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60744 == env60745) = true)

theorem identity60745 : scanCanonicalize (H12AffineFastState.compose env60745 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound60745 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60746 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1702,16,1189,1297,1029,139,1213,10,1025,1029,444,1312,1297,1063,1069,17,130,1296,1213,642,1193,260,256,1449,1212,513]

theorem envBound60746 : H12AffineFastState.Bounded env60746 := by
  intro p hp
  have h : env60746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60745_60746 : H12AffineEnvironment.transform 10 1702 env60745 = env60746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env60745 == env60746) = true)

theorem identity60746 : scanCanonicalize (H12AffineFastState.compose env60746 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound60746 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env60747 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1071,16,1189,1297,1029,139,1213,10,1025,1029,444,1312,1297,1063,1069,17,130,1296,1213,11,1193,260,256,1449,1212,136]

theorem envBound60747 : H12AffineFastState.Bounded env60747 := by
  intro p hp
  have h : env60747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60746_60747 : H12AffineEnvironment.transform 8 137 env60746 = env60747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env60746 == env60747) = true)

theorem identity60747 : scanCanonicalize (H12AffineFastState.compose env60747 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound60747 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env60748 : List Nat := [2,4,8,16,32,16,128,5,137,1024,1071,16,1189,1044,1029,139,1213,10,1025,1029,185,1061,1044,1063,1069,17,130,1045,1213,11,1193,1,5,1196,1212,136]

theorem envBound60748 : H12AffineFastState.Bounded env60748 := by
  intro p hp
  have h : env60748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60747_60748 : H12AffineEnvironment.transform 7 5 env60747 = env60748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env60747 == env60748) = true)

theorem identity60748 : scanCanonicalize (H12AffineFastState.compose env60748 (packedSelected [1,2,3,4,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound60748 : packedSelected [1,2,3,4,9,10] rootPS < 2^1333 := by decide +kernel

def env60749 : List Nat := [2,4,8,16,32,16,128,5,137,173,130,16,8,185,168,139,16,10,172,168,185,136,185,138,128,17,130,184,16,11,4,1,5,1,17,136]

theorem envBound60749 : H12AffineFastState.Bounded env60749 := by
  intro p hp
  have h : env60749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60748_60749 : H12AffineEnvironment.transform 9 173 env60748 = env60749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env60748 == env60749) = true)

theorem identity60749 : scanCanonicalize (H12AffineFastState.compose env60749 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound60749 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env60750 : List Nat := [2,4,8,16,32,16,40,5,33,5,42,16,8,17,0,35,16,10,4,0,17,32,17,34,40,17,42,16,16,11,4,1,5,1,17,32]

theorem envBound60750 : H12AffineFastState.Bounded env60750 := by
  intro p hp
  have h : env60750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60749_60750 : H12AffineEnvironment.transform 6 40 env60749 = env60750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env60749 == env60750) = true)

theorem identity60750 : scanCanonicalize (H12AffineFastState.compose env60750 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60750 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60751 : List Nat := [2,4,8,1,32,1,40,5,33,5,42,1,8,0,0,35,1,10,4,0,0,32,0,34,40,0,42,1,1,11,4,1,5,1,0,32]

theorem envBound60751 : H12AffineFastState.Bounded env60751 := by
  intro p hp
  have h : env60751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60750_60751 : H12AffineEnvironment.transform 3 1 env60750 = env60751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60750 == env60751) = true)

theorem identity60751 : scanCanonicalize (H12AffineFastState.compose env60751 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60751 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60752 : List Nat := [2,4,2,1,32,1,34,5,33,5,32,1,2,0,0,35,1,0,4,0,0,32,0,34,34,0,32,1,1,1,4,1,5,1,0,32]

theorem envBound60752 : H12AffineFastState.Bounded env60752 := by
  intro p hp
  have h : env60752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60751_60752 : H12AffineEnvironment.transform 2 2 env60751 = env60752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60751 == env60752) = true)

theorem identity60752 : scanCanonicalize (H12AffineFastState.compose env60752 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60752 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60753 : List Nat := [0,4,0,1,32,1,32,5,33,5,32,1,0,0,0,33,1,0,4,0,0,32,0,32,32,0,32,1,1,1,4,1,5,1,0,32]

theorem envBound60753 : H12AffineFastState.Bounded env60753 := by
  intro p hp
  have h : env60753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60752_60753 : H12AffineEnvironment.transform 0 0 env60752 = env60753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60752 == env60753) = true)

theorem identity60753 : scanCanonicalize (H12AffineFastState.compose env60753 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound60753 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env60754 : List Nat := [0,4,0,1,1,1,1,5,0,5,1,1,0,0,0,0,1,0,4,0,0,1,0,1,1,0,1,1,1,1,4,1,5,1,0,1]

theorem envBound60754 : H12AffineFastState.Bounded env60754 := by
  intro p hp
  have h : env60754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60753_60754 : H12AffineEnvironment.transform 4 1 env60753 = env60754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env60753 == env60754) = true)

def env60755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1025,32768,136513,46480,144713,169103,26057,157000,103453,16385,131152,93515,200847,209367,256,81971,131073,18240]

theorem envBound60755 : H12AffineFastState.Bounded env60755 := by
  intro p hp
  have h : env60755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60735_60755 : H12AffineEnvironment.transform 17 87425 env60735 = env60755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env60735 == env60755) = true)

theorem identity60755 : scanCanonicalize (H12AffineFastState.compose env60755 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 66662) := by decide +kernel

theorem selectedBound60755 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,66662,87425,1025,32768,69927,46480,78127,102633,26057,90414,103453,16385,66614,93515,5353,13745,256,81971,66663,18240]

theorem envBound60756 : H12AffineFastState.Bounded env60756 := by
  intro p hp
  have h : env60756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60755_60756 : H12AffineEnvironment.transform 16 66662 env60755 = env60756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 66662 env60755 == env60756) = true)

def env60757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,66662,69825,1025,32768,69927,46480,78127,102633,8329,74862,103453,1345,66614,75787,5353,13745,256,66931,66663,512]

theorem envBound60757 : H12AffineFastState.Bounded env60757 := by
  intro p hp
  have h : env60757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60756_60757 : H12AffineEnvironment.transform 13 1344 env60756 = env60757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60756 == env60757) = true)

theorem identity60757 : scanCanonicalize (H12AffineFastState.compose env60757 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound60757 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,66662,67025,1025,32768,66615,41088,74815,99833,8329,74862,98573,1345,66614,75787,505,8353,256,66931,66663,512]

theorem envBound60758 : H12AffineFastState.Bounded env60758 := by
  intro p hp
  have h : env60758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60757_60758 : H12AffineEnvironment.transform 11 1296 env60757 = env60758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env60757 == env60758) = true)

def env60759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,66662,69824,1025,32768,69927,46480,78127,102633,8328,74863,103453,1344,66614,75786,5353,13745,256,66930,66663,513]

theorem envBound60759 : H12AffineFastState.Bounded env60759 := by
  intro p hp
  have h : env60759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60756_60759 : H12AffineEnvironment.transform 13 1345 env60756 = env60759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60756 == env60759) = true)

theorem identity60759 : scanCanonicalize (H12AffineFastState.compose env60759 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound60759 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38046,37112,33886,1025,32768,34233,46480,42417,1143,8328,45297,131,1344,37032,48276,5353,13745,256,37356,37113,513]

theorem envBound60760 : H12AffineFastState.Bounded env60760 := by
  intro p hp
  have h : env60760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60759_60760 : H12AffineEnvironment.transform 15 38046 env60759 = env60760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env60759 == env60760) = true)

theorem identity60760 : scanCanonicalize (H12AffineFastState.compose env60760 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 12512) := by decide +kernel

theorem selectedBound60760 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,12512,9342,8216,13502,1025,12512,13657,1392,5457,1143,8328,17,131,1344,8264,3188,5353,13745,256,8460,8217,513]

theorem envBound60761 : H12AffineFastState.Bounded env60761 := by
  intro p hp
  have h : env60761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60760_60761 : H12AffineEnvironment.transform 14 12512 env60760 = env60761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12512 env60760 == env60761) = true)

theorem identity60761 : scanCanonicalize (H12AffineFastState.compose env60761 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 5301) := by decide +kernel

theorem selectedBound60761 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1345,1109,4299,5293,11,1025,1109,492,1392,5457,1143,5181,17,131,1344,5373,3188,5353,260,256,5561,5292,513]

theorem envBound60762 : H12AffineFastState.Bounded env60762 := by
  intro p hp
  have h : env60762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60761_60762 : H12AffineEnvironment.transform 12 5301 env60761 = env60762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5301 env60761 == env60762) = true)

theorem identity60762 : scanCanonicalize (H12AffineFastState.compose env60762 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 3766) := by decide +kernel

theorem selectedBound60762 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3766,2563,1345,1109,3709,2587,11,1025,1109,492,1392,3047,1143,2699,17,131,1344,2635,3188,2655,260,256,2831,2586,513]

theorem envBound60763 : H12AffineFastState.Bounded env60763 := by
  intro p hp
  have h : env60763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60762_60763 : H12AffineEnvironment.transform 11 3766 env60762 = env60763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3766 env60762 == env60763) = true)

theorem identity60763 : scanCanonicalize (H12AffineFastState.compose env60763 (packedSelected [0,1,5,7,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 1014) := by decide +kernel

theorem selectedBound60763 : packedSelected [0,1,5,7,10,13,16] rootPS < 2^1333 := by decide +kernel

def env60764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1014,1344,501,1345,1109,1419,493,11,1025,1109,492,1392,17,1143,381,17,131,1344,445,1922,425,260,256,249,492,513]

theorem envBound60764 : H12AffineFastState.Bounded env60764 := by
  intro p hp
  have h : env60764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60763_60764 : H12AffineEnvironment.transform 10 1014 env60763 = env60764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1014 env60763 == env60764) = true)

theorem identity60764 : scanCanonicalize (H12AffineFastState.compose env60764 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound60764 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60765 : List Nat := [2,4,8,16,32,64,128,256,512,256,1014,64,501,65,341,139,493,11,257,341,492,112,17,375,381,17,131,64,445,642,425,260,256,249,492,513]

theorem envBound60765 : H12AffineFastState.Bounded env60765 := by
  intro p hp
  have h : env60765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60764_60765 : H12AffineEnvironment.transform 9 256 env60764 = env60765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env60764 == env60765) = true)

theorem identity60765 : scanCanonicalize (H12AffineFastState.compose env60765 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound60765 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env60766 : List Nat := [2,4,8,16,32,64,128,256,217,256,303,64,501,65,341,139,493,11,257,341,492,112,17,375,381,17,131,64,445,91,425,260,256,249,492,216]

theorem envBound60766 : H12AffineFastState.Bounded env60766 := by
  intro p hp
  have h : env60766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60765_60766 : H12AffineEnvironment.transform 8 217 env60765 = env60766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env60765 == env60766) = true)

theorem identity60766 : scanCanonicalize (H12AffineFastState.compose env60766 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60766 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env60767 : List Nat := [2,4,8,16,32,64,128,94,217,94,113,64,171,65,11,139,179,11,95,11,178,112,17,41,35,17,131,64,227,91,247,90,94,249,178,216]

theorem envBound60767 : H12AffineFastState.Bounded env60767 := by
  intro p hp
  have h : env60767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60766_60767 : H12AffineEnvironment.transform 7 94 env60766 = env60767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60766 == env60767) = true)

theorem identity60767 : scanCanonicalize (H12AffineFastState.compose env60767 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound60767 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60768 : List Nat := [2,4,8,16,32,64,115,94,42,94,113,64,88,65,11,120,64,11,95,11,65,112,17,41,35,17,112,64,16,91,4,90,94,10,65,43]

theorem envBound60768 : H12AffineFastState.Bounded env60768 := by
  intro p hp
  have h : env60768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60767_60768 : H12AffineEnvironment.transform 6 115 env60767 = env60768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env60767 == env60768) = true)

theorem identity60768 : scanCanonicalize (H12AffineFastState.compose env60768 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 50) := by decide +kernel

theorem selectedBound60768 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60769 : List Nat := [2,4,8,16,32,50,1,44,42,44,3,50,42,51,11,10,50,11,45,11,51,2,17,41,35,17,2,50,16,41,4,40,44,10,51,43]

theorem envBound60769 : H12AffineFastState.Bounded env60769 := by
  intro p hp
  have h : env60769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60768_60769 : H12AffineEnvironment.transform 5 50 env60768 = env60769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 50 env60768 == env60769) = true)

theorem identity60769 : scanCanonicalize (H12AffineFastState.compose env60769 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound60769 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env60770 : List Nat := [2,4,8,16,24,10,1,20,18,20,3,10,18,11,11,10,10,11,21,11,11,2,17,17,27,17,2,10,16,17,4,16,20,10,11,19]

theorem envBound60770 : H12AffineFastState.Bounded env60770 := by
  intro p hp
  have h : env60770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60769_60770 : H12AffineEnvironment.transform 4 24 env60769 = env60770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env60769 == env60770) = true)

theorem identity60770 : scanCanonicalize (H12AffineFastState.compose env60770 (packedSelected [1,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60770 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60771 : List Nat := [0,4,8,16,24,8,1,20,16,20,1,8,16,9,9,8,8,9,21,9,9,0,17,17,25,17,0,8,16,17,4,16,20,8,9,17]

theorem envBound60771 : H12AffineFastState.Bounded env60771 := by
  intro p hp
  have h : env60771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60770_60771 : H12AffineEnvironment.transform 0 0 env60770 = env60771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60770 == env60771) = true)

theorem identity60771 : scanCanonicalize (H12AffineFastState.compose env60771 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60771 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env60772 : List Nat := [0,4,8,0,8,8,1,4,0,4,1,8,0,9,9,8,8,9,5,9,9,0,1,1,9,1,0,8,0,1,4,0,4,8,9,1]

theorem envBound60772 : H12AffineFastState.Bounded env60772 := by
  intro p hp
  have h : env60772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60771_60772 : H12AffineEnvironment.transform 3 0 env60771 = env60772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60771 == env60772) = true)

theorem identity60772 : scanCanonicalize (H12AffineFastState.compose env60772 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60772 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60773 : List Nat := [0,4,1,0,1,1,1,4,0,4,1,1,0,0,0,1,1,0,5,0,0,0,1,1,0,1,0,1,0,1,4,0,4,1,0,1]

theorem envBound60773 : H12AffineFastState.Bounded env60773 := by
  intro p hp
  have h : env60773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60772_60773 : H12AffineEnvironment.transform 2 1 env60772 = env60773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60772 == env60773) = true)

def env60774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,6329753,6304863,33554432,6342040,2544860,16385,131152,4315355,6402143,209367,256,2315635,131073,33563273]

theorem envBound60774 : H12AffineFastState.Bounded env60774 := by
  intro p hp
  have h : env60774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60485_60774 : H12AffineEnvironment.transform 22 6329753 env60485 = env60774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329753 env60485 == env60774) = true)

def env60775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,6329753,6304863,4247640,6342040,2544860,16385,131152,4315355,6402143,209367,256,2315635,131073,4256465]

theorem envBound60775 : H12AffineFastState.Bounded env60775 := by
  intro p hp
  have h : env60775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60774_60775 : H12AffineEnvironment.transform 24 4247640 env60774 = env60775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247640 env60774 == env60775) = true)

def env60776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,2269392,144713,169103,2257032,157000,2544860,16385,131152,2324491,200847,209367,256,2315635,131073,2249217]

theorem envBound60776 : H12AffineFastState.Bounded env60776 := by
  intro p hp
  have h : env60776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60775_60776 : H12AffineEnvironment.transform 21 2269392 env60775 = env60776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269392 env60775 == env60776) = true)

def env60777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136512,46480,144713,169103,26056,157000,311708,16385,131152,93515,200847,209367,256,81971,131073,18241]

theorem envBound60777 : H12AffineFastState.Bounded env60777 := by
  intro p hp
  have h : env60777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60776_60777 : H12AffineEnvironment.transform 20 136512 env60776 = env60777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env60776 == env60777) = true)

def env60778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1025,32768,136512,46480,144713,169103,26056,157000,103452,16385,131152,93515,200847,209367,256,81971,131073,18241]

theorem envBound60778 : H12AffineFastState.Bounded env60778 := by
  intro p hp
  have h : env60778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60777_60778 : H12AffineEnvironment.transform 17 87424 env60777 = env60778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env60777 == env60778) = true)

theorem identity60778 : scanCanonicalize (H12AffineFastState.compose env60778 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9713) := by decide +kernel

theorem selectedBound60778 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9713,65536,131072,87424,1025,9713,136512,4193,144713,143742,26056,157000,78317,16385,131152,93515,200847,209367,256,81971,131073,18241]

theorem envBound60779 : H12AffineFastState.Bounded env60779 := by
  intro p hp
  have h : env60779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60778_60779 : H12AffineEnvironment.transform 14 9713 env60778 = env60779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9713 env60778 == env60779) = true)

def env60780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,9713,65536,131072,69824,1025,9713,136512,4193,144713,143742,8328,139272,78317,1345,131152,75787,200847,209367,256,66931,131073,513]

theorem envBound60780 : H12AffineFastState.Bounded env60780 := by
  intro p hp
  have h : env60780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60779_60780 : H12AffineEnvironment.transform 13 1344 env60779 = env60780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60779 == env60780) = true)

theorem identity60780 : scanCanonicalize (H12AffineFastState.compose env60780 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 12655) := by decide +kernel

theorem selectedBound60780 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,9713,12655,131072,8623,1025,9713,136512,4193,144713,143742,8328,139272,130,1345,131152,6500,139744,131256,256,13340,131073,513]

theorem envBound60781 : H12AffineFastState.Bounded env60781 := by
  intro p hp
  have h : env60781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60780_60781 : H12AffineEnvironment.transform 15 12655 env60780 = env60781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12655 env60780 == env60781) = true)

theorem identity60781 : scanCanonicalize (H12AffineFastState.compose env60781 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound60781 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,9713,12655,8216,8623,1025,9713,13656,4193,5457,4454,8328,16,130,1345,8264,6500,504,8352,256,13340,8217,513]

theorem envBound60782 : H12AffineFastState.Bounded env60782 := by
  intro p hp
  have h : env60782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60781_60782 : H12AffineEnvironment.transform 16 8216 env60781 = env60782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env60781 == env60782) = true)

theorem identity60782 : scanCanonicalize (H12AffineFastState.compose env60782 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound60782 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1344,1109,4299,444,11,1025,1109,5372,4193,5457,4454,300,16,130,1345,492,6500,504,260,256,5560,445,513]

theorem envBound60783 : H12AffineFastState.Bounded env60783 := by
  intro p hp
  have h : env60783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60782_60783 : H12AffineEnvironment.transform 12 420 env60782 = env60783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env60782 == env60783) = true)

theorem identity60783 : scanCanonicalize (H12AffineFastState.compose env60783 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound60783 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,4096,420,1344,1109,4299,444,11,1025,1109,5372,4193,5457,4454,300,16,130,1345,492,5695,504,260,256,5560,445,513]

theorem envBound60784 : H12AffineFastState.Bounded env60784 := by
  intro p hp
  have h : env60784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60783_60784 : H12AffineEnvironment.transform 10 1883 env60783 = env60784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env60783 == env60784) = true)

theorem identity60784 : scanCanonicalize (H12AffineFastState.compose env60784 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound60784 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env60785 : List Nat := [2,4,8,16,32,64,128,256,216,1024,1411,4096,420,1344,1109,4299,444,11,1025,1109,5372,4193,5457,4454,300,16,130,1345,492,5351,504,260,256,5560,445,217]

theorem envBound60785 : H12AffineFastState.Bounded env60785 := by
  intro p hp
  have h : env60785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60784_60785 : H12AffineEnvironment.transform 8 216 env60784 = env60785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env60784 == env60785) = true)

theorem identity60785 : scanCanonicalize (H12AffineFastState.compose env60785 (packedSelected [1,4,5,9,10,17,20] rootPS)) = affineNative (2^(11+1) ^^^ 1260) := by decide +kernel

theorem selectedBound60785 : packedSelected [1,4,5,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env60786 : List Nat := [2,4,8,16,32,64,128,256,216,1024,1411,1260,420,1344,1109,1063,444,11,1025,1109,16,1165,445,1418,300,16,130,1345,492,11,504,260,256,340,445,217]

theorem envBound60786 : H12AffineFastState.Bounded env60786 := by
  intro p hp
  have h : env60786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60785_60786 : H12AffineEnvironment.transform 11 1260 env60785 = env60786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env60785 == env60786) = true)

theorem identity60786 : scanCanonicalize (H12AffineFastState.compose env60786 (packedSelected [1,4,5,9,10,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 336) := by decide +kernel

theorem selectedBound60786 : packedSelected [1,4,5,9,10,16,17] rootPS < 2^1333 := by decide +kernel

def env60787 : List Nat := [2,4,8,16,32,64,128,256,216,336,211,444,420,16,261,375,444,11,337,261,16,477,445,218,300,16,130,17,492,11,504,260,256,340,445,217]

theorem envBound60787 : H12AffineFastState.Bounded env60787 := by
  intro p hp
  have h : env60787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60786_60787 : H12AffineEnvironment.transform 9 336 env60786 = env60787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env60786 == env60787) = true)

theorem identity60787 : scanCanonicalize (H12AffineFastState.compose env60787 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 204) := by decide +kernel

theorem selectedBound60787 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env60788 : List Nat := [2,4,8,16,32,64,128,204,216,156,211,112,104,16,201,187,112,11,157,201,16,17,113,218,224,16,130,17,32,11,52,200,204,152,113,217]

theorem envBound60788 : H12AffineFastState.Bounded env60788 := by
  intro p hp
  have h : env60788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60787_60788 : H12AffineEnvironment.transform 7 204 env60787 = env60788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 204 env60787 == env60788) = true)

theorem identity60788 : scanCanonicalize (H12AffineFastState.compose env60788 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60788 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env60789 : List Nat := [2,4,8,16,32,17,128,157,137,156,130,33,57,16,152,187,33,11,157,152,16,17,32,139,177,16,130,17,32,11,52,153,157,152,32,136]

theorem envBound60789 : H12AffineFastState.Bounded env60789 := by
  intro p hp
  have h : env60789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60788_60789 : H12AffineEnvironment.transform 5 17 env60788 = env60789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60788 == env60789) = true)

theorem identity60789 : scanCanonicalize (H12AffineFastState.compose env60789 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound60789 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60790 : List Nat := [2,4,8,16,32,17,8,21,1,20,10,33,57,16,16,51,33,11,21,16,16,17,32,3,57,16,10,17,32,11,52,17,21,16,32,0]

theorem envBound60790 : H12AffineFastState.Bounded env60790 := by
  intro p hp
  have h : env60790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60789_60790 : H12AffineEnvironment.transform 6 8 env60789 = env60790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env60789 == env60790) = true)

theorem identity60790 : scanCanonicalize (H12AffineFastState.compose env60790 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound60790 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60791 : List Nat := [2,4,8,16,18,17,8,21,1,20,10,19,11,16,16,1,19,11,21,16,16,17,18,3,11,16,10,17,18,11,6,17,21,16,18,0]

theorem envBound60791 : H12AffineFastState.Bounded env60791 := by
  intro p hp
  have h : env60791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60790_60791 : H12AffineEnvironment.transform 4 18 env60790 = env60791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env60790 == env60791) = true)

theorem identity60791 : scanCanonicalize (H12AffineFastState.compose env60791 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60791 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60792 : List Nat := [1,4,8,16,17,17,8,21,1,20,9,16,8,16,16,1,16,8,21,16,16,17,17,0,8,16,9,17,17,8,5,17,21,16,17,0]

theorem envBound60792 : H12AffineFastState.Bounded env60792 := by
  intro p hp
  have h : env60792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60791_60792 : H12AffineEnvironment.transform 0 1 env60791 = env60792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60791 == env60792) = true)

def env60793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9713,65536,131072,69825,1025,9713,136512,4193,144713,143742,8329,139273,78317,1344,131152,75786,200847,209367,256,66930,131073,512]

theorem envBound60793 : H12AffineFastState.Bounded env60793 := by
  intro p hp
  have h : env60793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60779_60793 : H12AffineEnvironment.transform 13 1345 env60779 = env60793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60779 == env60793) = true)

theorem identity60793 : scanCanonicalize (H12AffineFastState.compose env60793 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound60793 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,9713,65536,131072,67024,1025,9713,131153,1392,139352,140399,8329,139273,75004,1344,131152,75786,198046,206022,256,66930,131073,512]

theorem envBound60794 : H12AffineFastState.Bounded env60794 := by
  intro p hp
  have h : env60794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60793_60794 : H12AffineEnvironment.transform 11 1297 env60793 = env60794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env60793 == env60794) = true)

def env60795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1025,32768,136512,46480,144713,169103,26056,157000,103453,16385,131152,93515,200847,209367,256,81971,131073,18241]

theorem envBound60795 : H12AffineFastState.Bounded env60795 := by
  intro p hp
  have h : env60795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60777_60795 : H12AffineEnvironment.transform 17 87425 env60777 = env60795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env60777 == env60795) = true)

theorem identity60795 : scanCanonicalize (H12AffineFastState.compose env60795 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 24753) := by decide +kernel

theorem selectedBound60795 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,24753,65536,131072,87425,1025,24753,136512,21793,144713,160830,26056,157000,95404,16385,131152,93515,200847,209367,256,81971,131073,18241]

theorem envBound60796 : H12AffineFastState.Bounded env60796 := by
  intro p hp
  have h : env60796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60795_60796 : H12AffineEnvironment.transform 14 24753 env60795 = env60796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24753 env60795 == env60796) = true)

def env60797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,9713,65536,131072,69825,1025,9713,136512,4193,144713,143742,8328,139272,78316,1345,131152,75787,200847,209367,256,66931,131073,513]

theorem envBound60797 : H12AffineFastState.Bounded env60797 := by
  intro p hp
  have h : env60797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60796_60797 : H12AffineEnvironment.transform 13 1344 env60796 = env60797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60796 == env60797) = true)

theorem identity60797 : scanCanonicalize (H12AffineFastState.compose env60797 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 12655) := by decide +kernel

theorem selectedBound60797 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,9713,12655,131072,8622,1025,9713,136512,4193,144713,143742,8328,139272,131,1345,131152,6500,139744,131256,256,13340,131073,513]

theorem envBound60798 : H12AffineFastState.Bounded env60798 := by
  intro p hp
  have h : env60798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60797_60798 : H12AffineEnvironment.transform 15 12655 env60797 = env60798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12655 env60797 == env60798) = true)

theorem identity60798 : scanCanonicalize (H12AffineFastState.compose env60798 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound60798 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,9713,12655,8216,8622,1025,9713,13656,4193,5457,4454,8328,16,131,1345,8264,6500,504,8352,256,13340,8217,513]

theorem envBound60799 : H12AffineFastState.Bounded env60799 := by
  intro p hp
  have h : env60799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60798_60799 : H12AffineEnvironment.transform 16 8216 env60798 = env60799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env60798 == env60799) = true)

theorem identity60799 : scanCanonicalize (H12AffineFastState.compose env60799 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound60799 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1344,1109,4299,444,10,1025,1109,5372,4193,5457,4454,300,16,131,1345,492,6500,504,260,256,5560,445,513]

theorem envBound60800 : H12AffineFastState.Bounded env60800 := by
  intro p hp
  have h : env60800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60799_60800 : H12AffineEnvironment.transform 12 420 env60799 = env60800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env60799 == env60800) = true)

theorem identity60800 : scanCanonicalize (H12AffineFastState.compose env60800 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound60800 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,4096,420,1344,1109,4299,444,10,1025,1109,5372,4193,5457,4454,300,16,131,1345,492,5695,504,260,256,5560,445,513]

theorem envBound60801 : H12AffineFastState.Bounded env60801 := by
  intro p hp
  have h : env60801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60800_60801 : H12AffineEnvironment.transform 10 1883 env60800 = env60801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env60800 == env60801) = true)

theorem identity60801 : scanCanonicalize (H12AffineFastState.compose env60801 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 1992) := by decide +kernel

theorem selectedBound60801 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env60802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,1992,420,1344,1109,1795,444,10,1025,1109,820,1961,665,1710,300,16,131,1345,492,503,504,260,256,624,445,513]

theorem envBound60802 : H12AffineFastState.Bounded env60802 := by
  intro p hp
  have h : env60802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60801_60802 : H12AffineEnvironment.transform 11 1992 env60801 = env60802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1992 env60801 == env60802) = true)

theorem identity60802 : scanCanonicalize (H12AffineFastState.compose env60802 (packedSelected [1,4,5,9,10,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound60802 : packedSelected [1,4,5,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env60803 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1702,1589,89,1213,1109,1790,65,10,1025,1109,713,1620,665,1710,209,16,131,1212,17,10,5,249,253,624,64,513]

theorem envBound60803 : H12AffineFastState.Bounded env60803 := by
  intro p hp
  have h : env60803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60802_60803 : H12AffineEnvironment.transform 7 253 env60802 = env60803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env60802 == env60803) = true)

theorem identity60803 : scanCanonicalize (H12AffineFastState.compose env60803 (packedSelected [1,4,5,9,10,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound60803 : packedSelected [1,4,5,9,10,16,17] rootPS < 2^1333 := by decide +kernel

def env60804 : List Nat := [2,4,8,16,32,64,128,253,512,173,523,664,89,16,248,595,65,10,172,248,713,761,665,515,209,16,131,17,17,10,5,249,253,624,64,513]

theorem envBound60804 : H12AffineFastState.Bounded env60804 := by
  intro p hp
  have h : env60804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60803_60804 : H12AffineEnvironment.transform 9 173 env60803 = env60804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env60803 == env60804) = true)

theorem identity60804 : scanCanonicalize (H12AffineFastState.compose env60804 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound60804 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60805 : List Nat := [2,4,8,16,32,64,128,253,136,173,131,16,89,16,248,219,65,10,172,248,65,113,17,139,209,16,131,17,17,10,5,249,253,248,64,137]

theorem envBound60805 : H12AffineFastState.Bounded env60805 := by
  intro p hp
  have h : env60805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60804_60805 : H12AffineEnvironment.transform 8 136 env60804 = env60805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env60804 == env60805) = true)

theorem identity60805 : scanCanonicalize (H12AffineFastState.compose env60805 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound60805 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60806 : List Nat := [2,4,8,16,32,64,57,68,49,20,58,16,89,16,65,98,65,10,21,65,65,113,17,50,104,16,58,17,17,10,5,64,68,65,64,48]

theorem envBound60806 : H12AffineFastState.Bounded env60806 := by
  intro p hp
  have h : env60806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60805_60806 : H12AffineEnvironment.transform 6 57 env60805 = env60806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env60805 == env60806) = true)

theorem identity60806 : scanCanonicalize (H12AffineFastState.compose env60806 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60806 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env60807 : List Nat := [2,4,8,16,16,64,9,68,1,20,10,16,89,16,65,82,65,10,21,65,65,65,17,2,88,16,10,17,17,10,5,64,68,65,64,0]

theorem envBound60807 : H12AffineFastState.Bounded env60807 := by
  intro p hp
  have h : env60807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60806_60807 : H12AffineEnvironment.transform 4 16 env60806 = env60807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60806 == env60807) = true)

theorem identity60807 : scanCanonicalize (H12AffineFastState.compose env60807 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound60807 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60808 : List Nat := [2,4,8,9,9,64,9,68,1,13,10,9,64,9,65,75,65,10,12,65,65,65,8,2,65,9,10,8,8,10,5,64,68,65,64,0]

theorem envBound60808 : H12AffineFastState.Bounded env60808 := by
  intro p hp
  have h : env60808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60807_60808 : H12AffineEnvironment.transform 3 9 env60807 = env60808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env60807 == env60808) = true)

def env60809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9712,65536,131072,69824,1025,9712,136512,4192,144713,143743,8329,139273,78317,1344,131152,75786,200847,209367,256,66930,131073,512]

theorem envBound60809 : H12AffineFastState.Bounded env60809 := by
  intro p hp
  have h : env60809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60796_60809 : H12AffineEnvironment.transform 13 1345 env60796 = env60809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60796 == env60809) = true)

theorem identity60809 : scanCanonicalize (H12AffineFastState.compose env60809 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound60809 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,9712,65536,131072,67025,1025,9712,131153,1393,139352,140398,8329,139273,75004,1344,131152,75786,198046,206022,256,66930,131073,512]

theorem envBound60810 : H12AffineFastState.Bounded env60810 := by
  intro p hp
  have h : env60810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60809_60810 : H12AffineEnvironment.transform 11 1297 env60809 = env60810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env60809 == env60810) = true)

def env60811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136513,46481,144713,169103,26057,157000,311709,16385,131152,93514,200847,209367,256,81970,131073,18240]

theorem envBound60811 : H12AffineFastState.Bounded env60811 := by
  intro p hp
  have h : env60811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60776_60811 : H12AffineEnvironment.transform 20 136513 env60776 = env60811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env60776 == env60811) = true)

def env60812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1025,32768,136513,46481,144713,169103,26057,157000,103453,16385,131152,93514,200847,209367,256,81970,131073,18240]

theorem envBound60812 : H12AffineFastState.Bounded env60812 := by
  intro p hp
  have h : env60812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60811_60812 : H12AffineEnvironment.transform 17 87424 env60811 = env60812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env60811 == env60812) = true)

theorem identity60812 : scanCanonicalize (H12AffineFastState.compose env60812 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 30112) := by decide +kernel

theorem selectedBound60812 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30112,65536,131072,87424,1025,30112,136513,16433,144713,155951,26057,157000,90557,16385,131152,93514,200847,209367,256,81970,131073,18240]

theorem envBound60813 : H12AffineFastState.Bounded env60813 := by
  intro p hp
  have h : env60813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60812_60813 : H12AffineEnvironment.transform 14 30112 env60812 = env60813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30112 env60812 == env60813) = true)

def env60814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12512,65536,131072,69824,1025,12512,136513,1393,144713,140399,8329,139272,75005,1345,131152,75786,200847,209367,256,66930,131073,512]

theorem envBound60814 : H12AffineFastState.Bounded env60814 := by
  intro p hp
  have h : env60814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60813_60814 : H12AffineEnvironment.transform 13 1344 env60813 = env60814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60813 == env60814) = true)

theorem identity60814 : scanCanonicalize (H12AffineFastState.compose env60814 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound60814 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,9712,65536,131072,67024,1025,9712,131153,1393,139353,140399,8329,139272,75005,1345,131152,75786,198047,206023,256,66930,131073,512]

theorem envBound60815 : H12AffineFastState.Bounded env60815 := by
  intro p hp
  have h : env60815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60814_60815 : H12AffineEnvironment.transform 11 1296 env60814 = env60815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env60814 == env60815) = true)

def env60816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,12513,65536,131072,69825,1025,12513,136513,1392,144713,140398,8328,139273,75004,1344,131152,75787,200847,209367,256,66931,131073,513]

theorem envBound60816 : H12AffineFastState.Bounded env60816 := by
  intro p hp
  have h : env60816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60813_60816 : H12AffineEnvironment.transform 13 1345 env60813 = env60816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60813 == env60816) = true)

theorem identity60816 : scanCanonicalize (H12AffineFastState.compose env60816 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 9342) := by decide +kernel

theorem selectedBound60816 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,12513,9342,131072,13503,1025,12513,136513,1392,144713,140398,8328,139273,130,1344,131152,3189,144625,136617,256,8461,131073,513]

theorem envBound60817 : H12AffineFastState.Bounded env60817 := by
  intro p hp
  have h : env60817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60816_60817 : H12AffineEnvironment.transform 15 9342 env60816 = env60817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9342 env60816 == env60817) = true)

theorem identity60817 : scanCanonicalize (H12AffineFastState.compose env60817 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8217) := by decide +kernel

theorem selectedBound60817 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,12513,9342,8217,13503,1025,12513,13656,1392,5456,1143,8328,16,130,1344,8265,3189,5352,13744,256,8461,8216,513]

theorem envBound60818 : H12AffineFastState.Bounded env60818 := by
  intro p hp
  have h : env60818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60817_60818 : H12AffineEnvironment.transform 16 8217 env60817 = env60818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8217 env60817 == env60818) = true)

theorem identity60818 : scanCanonicalize (H12AffineFastState.compose env60818 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 5300) := by decide +kernel

theorem selectedBound60818 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1345,1109,4298,5293,11,1025,1109,492,1392,5456,1143,5180,16,130,1344,5373,3189,5352,260,256,5561,5292,513]

theorem envBound60819 : H12AffineFastState.Bounded env60819 := by
  intro p hp
  have h : env60819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60818_60819 : H12AffineEnvironment.transform 12 5300 env60818 = env60819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env60818 == env60819) = true)

theorem identity60819 : scanCanonicalize (H12AffineFastState.compose env60819 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound60819 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,4096,5300,1345,1109,4298,5293,11,1025,1109,492,1392,5456,1143,5180,16,130,1344,5373,814,5352,260,256,5561,5292,513]

theorem envBound60820 : H12AffineFastState.Bounded env60820 := by
  intro p hp
  have h : env60820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60819_60820 : H12AffineEnvironment.transform 10 1883 env60819 = env60820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env60819 == env60820) = true)

theorem identity60820 : scanCanonicalize (H12AffineFastState.compose env60820 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound60820 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env60821 : List Nat := [2,4,8,16,32,64,128,256,512,548,383,4096,4752,869,625,4298,4745,11,549,625,492,852,4980,595,4632,16,130,868,4825,814,4812,260,256,5021,4744,513]

theorem envBound60821 : H12AffineFastState.Bounded env60821 := by
  intro p hp
  have h : env60821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60820_60821 : H12AffineEnvironment.transform 9 548 env60820 = env60821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env60820 == env60821) = true)

theorem identity60821 : scanCanonicalize (H12AffineFastState.compose env60821 (packedSelected [1,5,10,16,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound60821 : packedSelected [1,5,10,16,17,20] rootPS < 2^1333 := by decide +kernel

def env60822 : List Nat := [2,4,8,16,32,64,128,256,292,256,383,4096,4532,65,341,4298,4525,11,257,341,492,112,4176,375,4412,16,130,64,4605,10,4584,260,256,4281,4524,293]

theorem envBound60822 : H12AffineFastState.Bounded env60822 := by
  intro p hp
  have h : env60822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60821_60822 : H12AffineEnvironment.transform 8 292 env60821 = env60822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env60821 == env60822) = true)

theorem identity60822 : scanCanonicalize (H12AffineFastState.compose env60822 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(11+1) ^^^ 445) := by decide +kernel

theorem selectedBound60822 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env60823 : List Nat := [2,4,8,16,32,64,128,256,292,256,383,445,9,65,341,375,16,11,257,341,492,112,493,375,129,16,130,64,64,10,85,260,256,260,17,293]

theorem envBound60823 : H12AffineFastState.Bounded env60823 := by
  intro p hp
  have h : env60823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60822_60823 : H12AffineEnvironment.transform 11 445 env60822 = env60823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 445 env60822 == env60823) = true)

def env60824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1025,32768,136513,46481,144713,169103,26057,157000,103452,16385,131152,93514,200847,209367,256,81970,131073,18240]

theorem envBound60824 : H12AffineFastState.Bounded env60824 := by
  intro p hp
  have h : env60824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60811_60824 : H12AffineEnvironment.transform 17 87425 env60811 = env60824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env60811 == env60824) = true)

theorem identity60824 : scanCanonicalize (H12AffineFastState.compose env60824 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 12513) := by decide +kernel

theorem selectedBound60824 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,12513,65536,131072,87425,1025,12513,136513,1392,144713,140398,26057,157000,75005,16385,131152,93514,200847,209367,256,81970,131073,18240]

theorem envBound60825 : H12AffineFastState.Bounded env60825 := by
  intro p hp
  have h : env60825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60824_60825 : H12AffineEnvironment.transform 14 12513 env60824 = env60825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12513 env60824 == env60825) = true)

def env60826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12513,65536,131072,69825,1025,12513,136513,1392,144713,140398,8329,139272,75005,1345,131152,75786,200847,209367,256,66930,131073,512]

theorem envBound60826 : H12AffineFastState.Bounded env60826 := by
  intro p hp
  have h : env60826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60825_60826 : H12AffineEnvironment.transform 13 1344 env60825 = env60826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60825 == env60826) = true)

theorem identity60826 : scanCanonicalize (H12AffineFastState.compose env60826 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound60826 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,9713,65536,131072,67025,1025,9713,131153,1392,139353,140398,8329,139272,75005,1345,131152,75786,198047,206023,256,66930,131073,512]

theorem envBound60827 : H12AffineFastState.Bounded env60827 := by
  intro p hp
  have h : env60827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60826_60827 : H12AffineEnvironment.transform 11 1296 env60826 = env60827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env60826 == env60827) = true)

def env60828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,12513,65536,131072,69824,1025,12513,136513,1392,144713,140398,8328,139273,75005,1344,131152,75787,200847,209367,256,66931,131073,513]

theorem envBound60828 : H12AffineFastState.Bounded env60828 := by
  intro p hp
  have h : env60828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60825_60828 : H12AffineEnvironment.transform 13 1345 env60825 = env60828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60825 == env60828) = true)

theorem identity60828 : scanCanonicalize (H12AffineFastState.compose env60828 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 9342) := by decide +kernel

theorem selectedBound60828 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,12513,9342,131072,13502,1025,12513,136513,1392,144713,140398,8328,139273,131,1344,131152,3189,144625,136617,256,8461,131073,513]

theorem envBound60829 : H12AffineFastState.Bounded env60829 := by
  intro p hp
  have h : env60829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60828_60829 : H12AffineEnvironment.transform 15 9342 env60828 = env60829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9342 env60828 == env60829) = true)

theorem identity60829 : scanCanonicalize (H12AffineFastState.compose env60829 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8217) := by decide +kernel

theorem selectedBound60829 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,12513,9342,8217,13502,1025,12513,13656,1392,5456,1143,8328,16,131,1344,8265,3189,5352,13744,256,8461,8216,513]

theorem envBound60830 : H12AffineFastState.Bounded env60830 := by
  intro p hp
  have h : env60830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60829_60830 : H12AffineEnvironment.transform 16 8217 env60829 = env60830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8217 env60829 == env60830) = true)

theorem identity60830 : scanCanonicalize (H12AffineFastState.compose env60830 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 5300) := by decide +kernel

theorem selectedBound60830 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1345,1109,4298,5293,10,1025,1109,492,1392,5456,1143,5180,16,131,1344,5373,3189,5352,260,256,5561,5292,513]

theorem envBound60831 : H12AffineFastState.Bounded env60831 := by
  intro p hp
  have h : env60831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60830_60831 : H12AffineEnvironment.transform 12 5300 env60830 = env60831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env60830 == env60831) = true)

theorem identity60831 : scanCanonicalize (H12AffineFastState.compose env60831 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound60831 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,4096,5300,1345,1109,4298,5293,10,1025,1109,492,1392,5456,1143,5180,16,131,1344,5373,814,5352,260,256,5561,5292,513]

theorem envBound60832 : H12AffineFastState.Bounded env60832 := by
  intro p hp
  have h : env60832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60831_60832 : H12AffineEnvironment.transform 10 1883 env60831 = env60832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env60831 == env60832) = true)

theorem identity60832 : scanCanonicalize (H12AffineFastState.compose env60832 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound60832 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env60833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,821,1921,1345,1109,1023,1944,10,1025,1109,492,1392,1637,1143,1801,16,131,1344,1992,814,2013,260,256,1676,1945,513]

theorem envBound60833 : H12AffineFastState.Bounded env60833 := by
  intro p hp
  have h : env60833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60832_60833 : H12AffineEnvironment.transform 11 821 env60832 = env60833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env60832 == env60833) = true)

theorem identity60833 : scanCanonicalize (H12AffineFastState.compose env60833 (packedSelected [1,5,10,16,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound60833 : packedSelected [1,5,10,16,17,20] rootPS < 2^1333 := by decide +kernel

def env60834 : List Nat := [2,4,8,16,32,64,128,256,293,1024,1150,16,1188,1345,1109,218,1213,10,1025,1109,492,1392,1344,1143,1068,16,131,1344,1261,11,1272,260,256,1449,1212,292]

theorem envBound60834 : H12AffineFastState.Bounded env60834 := by
  intro p hp
  have h : env60834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60833_60834 : H12AffineEnvironment.transform 8 293 env60833 = env60834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env60833 == env60834) = true)

theorem identity60834 : scanCanonicalize (H12AffineFastState.compose env60834 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound60834 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env60835 : List Nat := [2,4,8,16,32,64,128,256,293,173,211,16,9,492,248,218,16,10,172,248,492,477,493,218,129,16,131,493,64,11,85,260,256,260,17,292]

theorem envBound60835 : H12AffineFastState.Bounded env60835 := by
  intro p hp
  have h : env60835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60834_60835 : H12AffineEnvironment.transform 9 173 env60834 = env60835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env60834 == env60835) = true)

def env60836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,2269393,144712,169102,2257033,157001,2544860,16385,131152,2324490,200846,209367,256,2315635,131073,2249216]

theorem envBound60836 : H12AffineFastState.Bounded env60836 := by
  intro p hp
  have h : env60836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60775_60836 : H12AffineEnvironment.transform 21 2269393 env60775 = env60836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269393 env60775 == env60836) = true)

def env60837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136512,46481,144712,169102,26057,157001,311708,16385,131152,93514,200846,209367,256,81971,131073,18240]

theorem envBound60837 : H12AffineFastState.Bounded env60837 := by
  intro p hp
  have h : env60837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60836_60837 : H12AffineEnvironment.transform 20 136512 env60836 = env60837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env60836 == env60837) = true)

def env60838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1025,32768,136512,46481,144712,169102,26057,157001,103452,16385,131152,93514,200846,209367,256,81971,131073,18240]

theorem envBound60838 : H12AffineFastState.Bounded env60838 := by
  intro p hp
  have h : env60838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60837_60838 : H12AffineEnvironment.transform 17 87424 env60837 = env60838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env60837 == env60838) = true)

theorem identity60838 : scanCanonicalize (H12AffineFastState.compose env60838 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 5561) := by decide +kernel

theorem selectedBound60838 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,5561,65536,131072,87424,1025,5561,136512,8232,144712,131383,26057,157001,65957,16385,131152,93514,200846,209367,256,81971,131073,18240]

theorem envBound60839 : H12AffineFastState.Bounded env60839 := by
  intro p hp
  have h : env60839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60838_60839 : H12AffineEnvironment.transform 14 5561 env60838 = env60839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5561 env60838 == env60839) = true)

def env60840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5561,65536,131072,69824,1025,5561,136512,8232,144712,131383,8329,139273,65957,1345,131152,75786,200846,209367,256,66931,131073,512]

theorem envBound60840 : H12AffineFastState.Bounded env60840 := by
  intro p hp
  have h : env60840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60839_60840 : H12AffineEnvironment.transform 13 1344 env60839 = env60840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60839 == env60840) = true)

theorem identity60840 : scanCanonicalize (H12AffineFastState.compose env60840 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound60840 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,169,65536,131072,67024,1025,169,131152,8232,139352,131383,8329,139273,65957,1345,131152,75786,198046,206023,256,66931,131073,512]

theorem envBound60841 : H12AffineFastState.Bounded env60841 := by
  intro p hp
  have h : env60841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60840_60841 : H12AffineEnvironment.transform 11 1296 env60840 = env60841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env60840 == env60841) = true)

def env60842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,5561,65536,131072,69825,1025,5561,136512,8232,144712,131383,8328,139272,65957,1344,131152,75787,200846,209367,256,66930,131073,513]

theorem envBound60842 : H12AffineFastState.Bounded env60842 := by
  intro p hp
  have h : env60842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60839_60842 : H12AffineEnvironment.transform 13 1345 env60839 = env60842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60839 == env60842) = true)

theorem identity60842 : scanCanonicalize (H12AffineFastState.compose env60842 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 295) := by decide +kernel

theorem selectedBound60842 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,5561,295,131072,4582,1025,5561,136512,8232,144712,131383,8328,139272,130,1344,131152,10540,135593,143600,256,1109,131073,513]

theorem envBound60843 : H12AffineFastState.Bounded env60843 := by
  intro p hp
  have h : env60843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60842_60843 : H12AffineEnvironment.transform 15 295 env60842 = env60843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 295 env60842 == env60843) = true)

theorem identity60843 : scanCanonicalize (H12AffineFastState.compose env60843 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8217) := by decide +kernel

theorem selectedBound60843 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,5561,295,8217,4582,1025,5561,13657,8232,5457,8494,8328,17,130,1344,8265,10540,12720,4329,256,1109,8216,513]

theorem envBound60844 : H12AffineFastState.Bounded env60844 := by
  intro p hp
  have h : env60844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60843_60844 : H12AffineEnvironment.transform 16 8217 env60843 = env60844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8217 env60843 == env60844) = true)

theorem identity60844 : scanCanonicalize (H12AffineFastState.compose env60844 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound60844 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1345,1108,295,8217,11,1025,1108,9396,8232,1212,8494,8328,17,130,1344,8265,10540,8285,260,256,1109,8216,513]

theorem envBound60845 : H12AffineFastState.Bounded env60845 := by
  intro p hp
  have h : env60845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60844_60845 : H12AffineEnvironment.transform 11 493 env60844 = env60845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env60844 == env60845) = true)

theorem identity60845 : scanCanonicalize (H12AffineFastState.compose env60845 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1783) := by decide +kernel

theorem selectedBound60845 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1783,493,8192,1345,1108,295,8217,11,1025,1108,9396,8232,1212,8494,8328,17,130,1344,8265,10203,8285,260,256,1109,8216,513]

theorem envBound60846 : H12AffineFastState.Bounded env60846 := by
  intro p hp
  have h : env60846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60845_60846 : H12AffineEnvironment.transform 10 1783 env60845 = env60846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1783 env60845 == env60846) = true)

theorem identity60846 : scanCanonicalize (H12AffineFastState.compose env60846 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound60846 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env60847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1783,493,421,1345,1108,295,444,11,1025,1108,1297,397,1212,139,301,17,130,1344,492,1662,504,260,256,1109,445,513]

theorem envBound60847 : H12AffineFastState.Bounded env60847 := by
  intro p hp
  have h : env60847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60846_60847 : H12AffineEnvironment.transform 12 421 env60846 = env60847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env60846 == env60847) = true)

theorem identity60847 : scanCanonicalize (H12AffineFastState.compose env60847 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound60847 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60848 : List Nat := [2,4,8,16,32,64,128,256,512,904,383,493,421,713,988,295,444,11,905,988,665,397,820,139,301,17,130,712,492,502,504,260,256,989,445,513]

theorem envBound60848 : H12AffineFastState.Bounded env60848 := by
  intro p hp
  have h : env60848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60847_60848 : H12AffineEnvironment.transform 9 904 env60847 = env60848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env60847 == env60848) = true)

theorem identity60848 : scanCanonicalize (H12AffineFastState.compose env60848 (packedSelected [0,3,4,7,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60848 : packedSelected [0,3,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env60849 : List Nat := [2,4,8,16,32,64,128,94,512,726,33,179,251,713,642,121,226,11,727,642,665,211,618,139,115,17,130,712,178,168,166,90,94,643,227,513]

theorem envBound60849 : H12AffineFastState.Bounded env60849 := by
  intro p hp
  have h : env60849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60848_60849 : H12AffineEnvironment.transform 7 94 env60848 = env60849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60848 == env60849) = true)

theorem identity60849 : scanCanonicalize (H12AffineFastState.compose env60849 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound60849 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env60850 : List Nat := [2,4,8,16,32,64,128,94,42,252,33,179,251,227,168,121,226,11,253,168,179,211,64,139,115,17,130,226,178,168,166,90,94,169,227,43]

theorem envBound60850 : H12AffineFastState.Bounded env60850 := by
  intro p hp
  have h : env60850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60849_60850 : H12AffineEnvironment.transform 8 42 env60849 = env60850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env60849 == env60850) = true)

theorem identity60850 : scanCanonicalize (H12AffineFastState.compose env60850 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 24) := by decide +kernel

theorem selectedBound60850 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60851 : List Nat := [2,4,8,16,32,24,128,6,42,164,33,179,163,187,168,33,186,11,165,168,179,139,24,139,43,17,130,186,178,168,166,2,6,169,187,43]

theorem envBound60851 : H12AffineFastState.Bounded env60851 := by
  intro p hp
  have h : env60851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60850_60851 : H12AffineEnvironment.transform 5 24 env60850 = env60851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 24 env60850 == env60851) = true)

theorem identity60851 : scanCanonicalize (H12AffineFastState.compose env60851 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 42) := by decide +kernel

theorem selectedBound60851 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60852 : List Nat := [2,4,8,16,32,24,42,6,42,14,33,25,9,17,2,33,16,11,15,2,25,33,24,33,43,17,40,16,24,2,12,2,6,3,17,43]

theorem envBound60852 : H12AffineFastState.Bounded env60852 := by
  intro p hp
  have h : env60852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60851_60852 : H12AffineEnvironment.transform 6 42 env60851 = env60852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 42 env60851 == env60852) = true)

theorem identity60852 : scanCanonicalize (H12AffineFastState.compose env60852 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60852 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60853 : List Nat := [2,4,8,10,32,2,42,6,42,14,33,3,9,11,2,33,10,11,15,2,3,33,2,33,43,11,40,10,2,2,12,2,6,3,11,43]

theorem envBound60853 : H12AffineFastState.Bounded env60853 := by
  intro p hp
  have h : env60853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60852_60853 : H12AffineEnvironment.transform 3 10 env60852 = env60853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60852 == env60853) = true)

theorem identity60853 : scanCanonicalize (H12AffineFastState.compose env60853 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60853 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env60854 : List Nat := [2,4,8,10,0,2,10,6,10,14,1,3,9,11,2,1,10,11,15,2,3,1,2,1,11,11,8,10,2,2,12,2,6,3,11,11]

theorem envBound60854 : H12AffineFastState.Bounded env60854 := by
  intro p hp
  have h : env60854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60853_60854 : H12AffineEnvironment.transform 4 0 env60853 = env60854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60853 == env60854) = true)

theorem identity60854 : scanCanonicalize (H12AffineFastState.compose env60854 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60854 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60855 : List Nat := [2,4,1,3,0,2,3,6,3,7,1,3,0,2,2,1,3,2,6,2,3,1,2,1,2,2,1,3,2,2,5,2,6,3,2,2]

theorem envBound60855 : H12AffineFastState.Bounded env60855 := by
  intro p hp
  have h : env60855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60854_60855 : H12AffineEnvironment.transform 2 1 env60854 = env60855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60854 == env60855) = true)

theorem identity60855 : scanCanonicalize (H12AffineFastState.compose env60855 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60855 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60856 : List Nat := [0,4,1,1,0,0,1,4,1,5,1,1,0,0,0,1,1,0,4,0,1,1,0,1,0,0,1,1,0,0,5,0,4,1,0,0]

theorem envBound60856 : H12AffineFastState.Bounded env60856 := by
  intro p hp
  have h : env60856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60855_60856 : H12AffineEnvironment.transform 0 0 env60855 = env60856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60855 == env60856) = true)

def env60857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1025,32768,136512,46481,144712,169102,26057,157001,103453,16385,131152,93514,200846,209367,256,81971,131073,18240]

theorem envBound60857 : H12AffineFastState.Bounded env60857 := by
  intro p hp
  have h : env60857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60837_60857 : H12AffineEnvironment.transform 17 87425 env60837 = env60857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env60837 == env60857) = true)

theorem identity60857 : scanCanonicalize (H12AffineFastState.compose env60857 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 20728) := by decide +kernel

theorem selectedBound60857 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20728,65536,131072,87425,1025,20728,136512,25961,144712,148598,26057,157001,83173,16385,131152,93514,200846,209367,256,81971,131073,18240]

theorem envBound60858 : H12AffineFastState.Bounded env60858 := by
  intro p hp
  have h : env60858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60857_60858 : H12AffineEnvironment.transform 14 20728 env60857 = env60858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20728 env60857 == env60858) = true)

def env60859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5560,65536,131072,69825,1025,5560,136512,8233,144712,131382,8329,139273,65957,1345,131152,75786,200846,209367,256,66931,131073,512]

theorem envBound60859 : H12AffineFastState.Bounded env60859 := by
  intro p hp
  have h : env60859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60858_60859 : H12AffineEnvironment.transform 13 1344 env60858 = env60859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60858 == env60859) = true)

theorem identity60859 : scanCanonicalize (H12AffineFastState.compose env60859 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound60859 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,168,65536,131072,67025,1025,168,131152,8233,139352,131382,8329,139273,65957,1345,131152,75786,198046,206023,256,66931,131073,512]

theorem envBound60860 : H12AffineFastState.Bounded env60860 := by
  intro p hp
  have h : env60860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60859_60860 : H12AffineEnvironment.transform 11 1296 env60859 = env60860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env60859 == env60860) = true)

def env60861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,5561,65536,131072,69824,1025,5561,136512,8232,144712,131383,8328,139272,65956,1344,131152,75787,200846,209367,256,66930,131073,513]

theorem envBound60861 : H12AffineFastState.Bounded env60861 := by
  intro p hp
  have h : env60861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60858_60861 : H12AffineEnvironment.transform 13 1345 env60858 = env60861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60858 == env60861) = true)

theorem identity60861 : scanCanonicalize (H12AffineFastState.compose env60861 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 295) := by decide +kernel

theorem selectedBound60861 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,5561,295,131072,4583,1025,5561,136512,8232,144712,131383,8328,139272,131,1344,131152,10540,135593,143600,256,1109,131073,513]

theorem envBound60862 : H12AffineFastState.Bounded env60862 := by
  intro p hp
  have h : env60862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60861_60862 : H12AffineEnvironment.transform 15 295 env60861 = env60862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 295 env60861 == env60862) = true)

theorem identity60862 : scanCanonicalize (H12AffineFastState.compose env60862 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8217) := by decide +kernel

theorem selectedBound60862 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,5561,295,8217,4583,1025,5561,13657,8232,5457,8494,8328,17,131,1344,8265,10540,12720,4329,256,1109,8216,513]

theorem envBound60863 : H12AffineFastState.Bounded env60863 := by
  intro p hp
  have h : env60863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60862_60863 : H12AffineEnvironment.transform 16 8217 env60862 = env60863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8217 env60862 == env60863) = true)

theorem identity60863 : scanCanonicalize (H12AffineFastState.compose env60863 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound60863 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1345,1108,295,8217,10,1025,1108,9396,8232,1212,8494,8328,17,131,1344,8265,10540,8285,260,256,1109,8216,513]

theorem envBound60864 : H12AffineFastState.Bounded env60864 := by
  intro p hp
  have h : env60864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60863_60864 : H12AffineEnvironment.transform 11 493 env60863 = env60864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env60863 == env60864) = true)

theorem identity60864 : scanCanonicalize (H12AffineFastState.compose env60864 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1783) := by decide +kernel

theorem selectedBound60864 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1783,493,8192,1345,1108,295,8217,10,1025,1108,9396,8232,1212,8494,8328,17,131,1344,8265,10203,8285,260,256,1109,8216,513]

theorem envBound60865 : H12AffineFastState.Bounded env60865 := by
  intro p hp
  have h : env60865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60864_60865 : H12AffineEnvironment.transform 10 1783 env60864 = env60865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1783 env60864 == env60865) = true)

theorem identity60865 : scanCanonicalize (H12AffineFastState.compose env60865 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound60865 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env60866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1783,493,421,1345,1108,295,444,10,1025,1108,1297,397,1212,139,301,17,131,1344,492,1662,504,260,256,1109,445,513]

theorem envBound60866 : H12AffineFastState.Bounded env60866 := by
  intro p hp
  have h : env60866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60865_60866 : H12AffineEnvironment.transform 12 421 env60865 = env60866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env60865 == env60866) = true)

theorem identity60866 : scanCanonicalize (H12AffineFastState.compose env60866 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound60866 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60867 : List Nat := [2,4,8,16,32,64,128,256,512,904,383,493,421,713,988,295,444,10,905,988,665,397,820,139,301,17,131,712,492,502,504,260,256,989,445,513]

theorem envBound60867 : H12AffineFastState.Bounded env60867 := by
  intro p hp
  have h : env60867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60866_60867 : H12AffineEnvironment.transform 9 904 env60866 = env60867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env60866 == env60867) = true)

theorem identity60867 : scanCanonicalize (H12AffineFastState.compose env60867 (packedSelected [0,3,4,7,8,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound60867 : packedSelected [0,3,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env60868 : List Nat := [2,4,8,16,32,64,128,256,123,499,383,493,421,178,423,295,444,10,498,423,226,397,335,139,301,17,131,179,492,502,504,260,256,422,445,122]

theorem envBound60868 : H12AffineFastState.Bounded env60868 := by
  intro p hp
  have h : env60868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60867_60868 : H12AffineEnvironment.transform 8 123 env60867 = env60868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env60867 == env60868) = true)

theorem identity60868 : scanCanonicalize (H12AffineFastState.compose env60868 (packedSelected [2,7,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound60868 : packedSelected [2,7,9,11] rootPS < 2^1333 := by decide +kernel

def env60869 : List Nat := [2,4,8,16,32,64,128,252,123,15,131,17,89,178,91,219,64,10,14,91,226,113,179,139,209,17,131,179,16,10,4,248,252,90,65,122]

theorem envBound60869 : H12AffineFastState.Bounded env60869 := by
  intro p hp
  have h : env60869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60868_60869 : H12AffineEnvironment.transform 7 252 env60868 = env60869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env60868 == env60869) = true)

theorem identity60869 : scanCanonicalize (H12AffineFastState.compose env60869 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 33) := by decide +kernel

theorem selectedBound60869 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env60870 : List Nat := [2,4,8,16,32,64,33,93,123,15,34,17,89,19,91,122,64,10,14,91,67,113,18,42,112,17,34,18,16,10,4,89,93,90,65,122]

theorem envBound60870 : H12AffineFastState.Bounded env60870 := by
  intro p hp
  have h : env60870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60869_60870 : H12AffineEnvironment.transform 6 33 env60869 = env60870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 33 env60869 == env60870) = true)

theorem identity60870 : scanCanonicalize (H12AffineFastState.compose env60870 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound60870 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env60871 : List Nat := [2,4,8,16,32,18,33,15,41,15,34,17,11,19,9,40,18,10,14,9,17,35,18,42,34,17,34,18,16,10,4,11,15,8,19,40]

theorem envBound60871 : H12AffineFastState.Bounded env60871 := by
  intro p hp
  have h : env60871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60870_60871 : H12AffineEnvironment.transform 5 18 env60870 = env60871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env60870 == env60871) = true)

theorem identity60871 : scanCanonicalize (H12AffineFastState.compose env60871 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound60871 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env60872 : List Nat := [2,4,8,16,27,18,26,15,18,15,25,17,11,19,9,19,18,10,14,9,17,24,18,17,25,17,25,18,16,10,4,11,15,8,19,19]

theorem envBound60872 : H12AffineFastState.Bounded env60872 := by
  intro p hp
  have h : env60872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60871_60872 : H12AffineEnvironment.transform 4 27 env60871 = env60872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env60871 == env60872) = true)

theorem identity60872 : scanCanonicalize (H12AffineFastState.compose env60872 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60872 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60873 : List Nat := [2,4,1,16,18,18,19,6,18,6,16,17,2,19,0,19,18,3,7,0,17,17,18,17,16,17,16,18,16,3,4,2,6,1,19,19]

theorem envBound60873 : H12AffineFastState.Bounded env60873 := by
  intro p hp
  have h : env60873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60872_60873 : H12AffineEnvironment.transform 2 1 env60872 = env60873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60872 == env60873) = true)

theorem identity60873 : scanCanonicalize (H12AffineFastState.compose env60873 (packedSelected [0,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60873 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env60874 : List Nat := [1,4,1,16,17,17,16,5,17,5,16,17,1,16,0,16,17,0,4,0,17,17,17,17,16,17,16,17,16,0,4,1,5,1,16,16]

theorem envBound60874 : H12AffineFastState.Bounded env60874 := by
  intro p hp
  have h : env60874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60873_60874 : H12AffineEnvironment.transform 0 1 env60873 = env60874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60873 == env60874) = true)

theorem identity60874 : scanCanonicalize (H12AffineFastState.compose env60874 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60874 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60875 : List Nat := [1,4,1,0,1,1,0,5,1,5,0,1,1,0,0,0,1,0,4,0,1,1,1,1,0,1,0,1,0,0,4,1,5,1,0,0]

theorem envBound60875 : H12AffineFastState.Bounded env60875 := by
  intro p hp
  have h : env60875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60874_60875 : H12AffineEnvironment.transform 3 0 env60874 = env60875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60874 == env60875) = true)

def env60876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136513,46480,144712,169102,26056,157001,311709,16385,131152,93515,200846,209367,256,81970,131073,18241]

theorem envBound60876 : H12AffineFastState.Bounded env60876 := by
  intro p hp
  have h : env60876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60836_60876 : H12AffineEnvironment.transform 20 136513 env60836 = env60876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env60836 == env60876) = true)

def env60877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1025,32768,136513,46480,144712,169102,26056,157001,103453,16385,131152,93515,200846,209367,256,81970,131073,18241]

theorem envBound60877 : H12AffineFastState.Bounded env60877 := by
  intro p hp
  have h : env60877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60876_60877 : H12AffineEnvironment.transform 17 87424 env60876 = env60877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env60876 == env60877) = true)

theorem identity60877 : scanCanonicalize (H12AffineFastState.compose env60877 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 17897) := by decide +kernel

theorem selectedBound60877 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,17897,65536,131072,87424,1025,17897,136513,28793,144712,151911,26056,157001,86516,16385,131152,93515,200846,209367,256,81970,131073,18241]

theorem envBound60878 : H12AffineFastState.Bounded env60878 := by
  intro p hp
  have h : env60878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60877_60878 : H12AffineEnvironment.transform 14 17897 env60877 = env60878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17897 env60877 == env60878) = true)

def env60879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,169,65536,131072,69824,1025,169,136513,13625,144712,136231,8328,139273,70836,1345,131152,75787,200846,209367,256,66930,131073,513]

theorem envBound60879 : H12AffineFastState.Bounded env60879 := by
  intro p hp
  have h : env60879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60878_60879 : H12AffineEnvironment.transform 13 1344 env60878 = env60879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60878 == env60879) = true)

theorem identity60879 : scanCanonicalize (H12AffineFastState.compose env60879 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 5174) := by decide +kernel

theorem selectedBound60879 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,169,5174,131072,1270,1025,169,136513,13625,144712,136231,8328,139273,130,1345,131152,15421,132280,140769,256,4420,131073,513]

theorem envBound60880 : H12AffineFastState.Bounded env60880 := by
  intro p hp
  have h : env60880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60879_60880 : H12AffineEnvironment.transform 15 5174 env60879 = env60880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5174 env60879 == env60880) = true)

theorem identity60880 : scanCanonicalize (H12AffineFastState.compose env60880 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound60880 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,169,5174,8216,1270,1025,169,13657,13625,5456,13375,8328,17,130,1345,8264,15421,9376,1529,256,4420,8217,513]

theorem envBound60881 : H12AffineFastState.Bounded env60881 := by
  intro p hp
  have h : env60881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60880_60881 : H12AffineEnvironment.transform 16 8216 env60880 = env60881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env60880 == env60881) = true)

theorem identity60881 : scanCanonicalize (H12AffineFastState.compose env60881 (packedSelected [25] rootPS)) = affineNative (2^(9+1) ^^^ 253) := by decide +kernel

theorem selectedBound60881 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60882 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,445,169,4299,8216,11,252,169,12708,12740,4525,12482,8328,17,130,444,8264,14528,8285,260,256,4420,8217,513]

theorem envBound60882 : H12AffineFastState.Bounded env60882 := by
  intro p hp
  have h : env60882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60881_60882 : H12AffineEnvironment.transform 9 253 env60881 = env60882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 253 env60881 == env60882) = true)

theorem identity60882 : scanCanonicalize (H12AffineFastState.compose env60882 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound60882 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60883 : List Nat := [2,4,8,16,32,64,128,256,512,253,522,4096,8192,445,169,4299,8216,11,252,169,12708,12740,4525,12482,8328,17,130,444,8264,13002,8285,260,256,4420,8217,513]

theorem envBound60883 : H12AffineFastState.Bounded env60883 := by
  intro p hp
  have h : env60883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60882_60883 : H12AffineEnvironment.transform 10 522 env60882 = env60883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env60882 == env60883) = true)

theorem identity60883 : scanCanonicalize (H12AffineFastState.compose env60883 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4169) := by decide +kernel

theorem selectedBound60883 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env60884 : List Nat := [2,4,8,16,32,64,128,256,512,253,522,4096,4169,445,169,4299,4177,11,252,169,493,397,4525,139,4289,17,130,444,4097,643,4116,260,256,4420,4176,513]

theorem envBound60884 : H12AffineFastState.Bounded env60884 := by
  intro p hp
  have h : env60884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60883_60884 : H12AffineEnvironment.transform 12 4169 env60883 = env60884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4169 env60883 == env60884) = true)

theorem identity60884 : scanCanonicalize (H12AffineFastState.compose env60884 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 664) := by decide +kernel

theorem selectedBound60884 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60885 : List Nat := [2,4,8,16,32,64,128,256,512,253,522,664,721,445,169,595,713,11,252,169,493,397,821,139,601,17,130,444,665,643,652,260,256,988,712,513]

theorem envBound60885 : H12AffineFastState.Bounded env60885 := by
  intro p hp
  have h : env60885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60884_60885 : H12AffineEnvironment.transform 11 664 env60884 = env60885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 664 env60884 == env60885) = true)

theorem identity60885 : scanCanonicalize (H12AffineFastState.compose env60885 (packedSelected [3,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound60885 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env60886 : List Nat := [2,4,8,16,32,64,115,256,512,14,522,619,546,334,90,595,570,11,15,90,286,382,821,120,601,17,113,335,618,624,639,260,256,815,571,513]

theorem envBound60886 : H12AffineFastState.Bounded env60886 := by
  intro p hp
  have h : env60886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60885_60886 : H12AffineEnvironment.transform 6 115 env60885 = env60886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env60885 == env60886) = true)

theorem identity60886 : scanCanonicalize (H12AffineFastState.compose env60886 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound60886 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env60887 : List Nat := [2,4,8,16,32,64,115,256,122,14,112,17,88,334,90,41,64,11,15,90,286,382,335,120,35,17,113,335,16,10,5,260,256,341,65,123]

theorem envBound60887 : H12AffineFastState.Bounded env60887 := by
  intro p hp
  have h : env60887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60886_60887 : H12AffineEnvironment.transform 8 122 env60886 = env60887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env60886 == env60887) = true)

theorem identity60887 : scanCanonicalize (H12AffineFastState.compose env60887 (packedSelected [0,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 93) := by decide +kernel

theorem selectedBound60887 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env60888 : List Nat := [2,4,8,16,32,64,115,93,122,14,112,17,88,19,90,41,64,11,15,90,67,35,18,120,35,17,113,18,16,10,5,89,93,8,65,123]

theorem envBound60888 : H12AffineFastState.Bounded env60888 := by
  intro p hp
  have h : env60888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60887_60888 : H12AffineEnvironment.transform 7 93 env60887 = env60888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 93 env60887 == env60888) = true)

theorem identity60888 : scanCanonicalize (H12AffineFastState.compose env60888 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound60888 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env60889 : List Nat := [2,4,8,16,32,58,9,39,0,14,10,17,34,19,32,41,58,11,15,32,57,35,18,2,35,17,11,18,16,10,5,35,39,8,59,1]

theorem envBound60889 : H12AffineFastState.Bounded env60889 := by
  intro p hp
  have h : env60889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60888_60889 : H12AffineEnvironment.transform 5 58 env60888 = env60889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env60888 == env60889) = true)

theorem identity60889 : scanCanonicalize (H12AffineFastState.compose env60889 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound60889 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env60890 : List Nat := [2,4,8,16,8,18,9,15,0,14,10,17,10,19,8,1,18,11,15,8,17,11,18,2,11,17,11,18,16,10,5,11,15,8,19,1]

theorem envBound60890 : H12AffineFastState.Bounded env60890 := by
  intro p hp
  have h : env60890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60889_60890 : H12AffineEnvironment.transform 4 8 env60889 = env60890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env60889 == env60890) = true)

theorem identity60890 : scanCanonicalize (H12AffineFastState.compose env60890 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60890 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60891 : List Nat := [2,4,0,16,0,18,1,7,0,6,2,17,2,19,0,1,18,3,7,0,17,3,18,2,3,17,3,18,16,2,5,3,7,0,19,1]

theorem envBound60891 : H12AffineFastState.Bounded env60891 := by
  intro p hp
  have h : env60891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60890_60891 : H12AffineEnvironment.transform 2 0 env60890 = env60891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60890 == env60891) = true)

theorem identity60891 : scanCanonicalize (H12AffineFastState.compose env60891 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60891 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60892 : List Nat := [2,4,0,0,0,2,1,7,0,6,2,1,2,3,0,1,2,3,7,0,1,3,2,2,3,1,3,2,0,2,5,3,7,0,3,1]

theorem envBound60892 : H12AffineFastState.Bounded env60892 := by
  intro p hp
  have h : env60892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60891_60892 : H12AffineEnvironment.transform 3 0 env60891 = env60892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60891 == env60892) = true)

theorem identity60892 : scanCanonicalize (H12AffineFastState.compose env60892 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60892 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60893 : List Nat := [0,4,0,0,0,0,1,5,0,4,0,1,0,1,0,1,0,1,5,0,1,1,0,0,1,1,1,0,0,0,5,1,5,0,1,1]

theorem envBound60893 : H12AffineFastState.Bounded env60893 := by
  intro p hp
  have h : env60893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60892_60893 : H12AffineEnvironment.transform 0 0 env60892 = env60893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60892 == env60893) = true)

def env60894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,168,65536,131072,69825,1025,168,136513,13624,144712,136230,8329,139272,70837,1344,131152,75786,200846,209367,256,66931,131073,512]

theorem envBound60894 : H12AffineFastState.Bounded env60894 := by
  intro p hp
  have h : env60894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60878_60894 : H12AffineEnvironment.transform 13 1345 env60878 = env60894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60878 == env60894) = true)

theorem identity60894 : scanCanonicalize (H12AffineFastState.compose env60894 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound60894 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,168,65536,131072,67024,1025,168,131152,8233,139353,131383,8329,139272,65956,1344,131152,75786,198047,206022,256,66931,131073,512]

theorem envBound60895 : H12AffineFastState.Bounded env60895 := by
  intro p hp
  have h : env60895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60894_60895 : H12AffineEnvironment.transform 11 1297 env60894 = env60895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env60894 == env60895) = true)

def env60896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1025,32768,136513,46480,144712,169102,26056,157001,103452,16385,131152,93515,200846,209367,256,81970,131073,18241]

theorem envBound60896 : H12AffineFastState.Bounded env60896 := by
  intro p hp
  have h : env60896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60876_60896 : H12AffineEnvironment.transform 17 87425 env60876 = env60896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env60876 == env60896) = true)

theorem identity60896 : scanCanonicalize (H12AffineFastState.compose env60896 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 169) := by decide +kernel

theorem selectedBound60896 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,169,65536,131072,87425,1025,169,136513,13625,144712,136231,26056,157001,70837,16385,131152,93515,200846,209367,256,81970,131073,18241]

theorem envBound60897 : H12AffineFastState.Bounded env60897 := by
  intro p hp
  have h : env60897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60896_60897 : H12AffineEnvironment.transform 14 169 env60896 = env60897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 169 env60896 == env60897) = true)

def env60898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,169,65536,131072,69825,1025,169,136513,13625,144712,136231,8328,139273,70837,1345,131152,75787,200846,209367,256,66930,131073,513]

theorem envBound60898 : H12AffineFastState.Bounded env60898 := by
  intro p hp
  have h : env60898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60897_60898 : H12AffineEnvironment.transform 13 1344 env60897 = env60898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env60897 == env60898) = true)

theorem identity60898 : scanCanonicalize (H12AffineFastState.compose env60898 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 5174) := by decide +kernel

theorem selectedBound60898 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,169,5174,131072,1271,1025,169,136513,13625,144712,136231,8328,139273,131,1345,131152,15421,132280,140769,256,4420,131073,513]

theorem envBound60899 : H12AffineFastState.Bounded env60899 := by
  intro p hp
  have h : env60899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60898_60899 : H12AffineEnvironment.transform 15 5174 env60898 = env60899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5174 env60898 == env60899) = true)

theorem identity60899 : scanCanonicalize (H12AffineFastState.compose env60899 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound60899 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,169,5174,8216,1271,1025,169,13657,13625,5456,13375,8328,17,131,1345,8264,15421,9376,1529,256,4420,8217,513]

theorem envBound60900 : H12AffineFastState.Bounded env60900 := by
  intro p hp
  have h : env60900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60899_60900 : H12AffineEnvironment.transform 16 8216 env60899 = env60900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env60899 == env60900) = true)

theorem identity60900 : scanCanonicalize (H12AffineFastState.compose env60900 (packedSelected [25] rootPS)) = affineNative (2^(9+1) ^^^ 253) := by decide +kernel

theorem selectedBound60900 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60901 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,445,169,4299,8216,10,252,169,12708,12740,4525,12482,8328,17,131,444,8264,14528,8285,260,256,4420,8217,513]

theorem envBound60901 : H12AffineFastState.Bounded env60901 := by
  intro p hp
  have h : env60901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60900_60901 : H12AffineEnvironment.transform 9 253 env60900 = env60901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 253 env60900 == env60901) = true)

theorem identity60901 : scanCanonicalize (H12AffineFastState.compose env60901 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound60901 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60902 : List Nat := [2,4,8,16,32,64,128,256,512,253,522,4096,8192,445,169,4299,8216,10,252,169,12708,12740,4525,12482,8328,17,131,444,8264,13002,8285,260,256,4420,8217,513]

theorem envBound60902 : H12AffineFastState.Bounded env60902 := by
  intro p hp
  have h : env60902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60901_60902 : H12AffineEnvironment.transform 10 522 env60901 = env60902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env60901 == env60902) = true)

theorem identity60902 : scanCanonicalize (H12AffineFastState.compose env60902 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4169) := by decide +kernel

theorem selectedBound60902 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env60903 : List Nat := [2,4,8,16,32,64,128,256,512,253,522,4096,4169,445,169,4299,4177,10,252,169,493,397,4525,139,4289,17,131,444,4097,643,4116,260,256,4420,4176,513]

theorem envBound60903 : H12AffineFastState.Bounded env60903 := by
  intro p hp
  have h : env60903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60902_60903 : H12AffineEnvironment.transform 12 4169 env60902 = env60903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4169 env60902 == env60903) = true)

theorem identity60903 : scanCanonicalize (H12AffineFastState.compose env60903 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 664) := by decide +kernel

theorem selectedBound60903 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60904 : List Nat := [2,4,8,16,32,64,128,256,512,253,522,664,721,445,169,595,713,10,252,169,493,397,821,139,601,17,131,444,665,643,652,260,256,988,712,513]

theorem envBound60904 : H12AffineFastState.Bounded env60904 := by
  intro p hp
  have h : env60904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60903_60904 : H12AffineEnvironment.transform 11 664 env60903 = env60904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 664 env60903 == env60904) = true)

theorem identity60904 : scanCanonicalize (H12AffineFastState.compose env60904 (packedSelected [3,8,12] rootPS)) = affineNative (2^(8+1) ^^^ 471) := by decide +kernel

theorem selectedBound60904 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env60905 : List Nat := [2,4,8,16,32,64,128,256,471,253,477,335,262,445,169,388,286,10,252,169,493,397,226,139,398,17,131,444,334,340,347,260,256,11,287,470]

theorem envBound60905 : H12AffineFastState.Bounded env60905 := by
  intro p hp
  have h : env60905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60904_60905 : H12AffineEnvironment.transform 8 471 env60904 = env60905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 471 env60904 == env60905) = true)

theorem identity60905 : scanCanonicalize (H12AffineFastState.compose env60905 (packedSelected [0,1,3,4,5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound60905 : packedSelected [0,1,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env60906 : List Nat := [2,4,8,16,32,64,34,256,373,95,383,335,262,287,11,294,286,10,94,11,335,303,64,41,300,17,33,286,334,340,347,260,256,11,287,372]

theorem envBound60906 : H12AffineFastState.Bounded env60906 := by
  intro p hp
  have h : env60906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60905_60906 : H12AffineEnvironment.transform 6 34 env60905 = env60906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env60905 == env60906) = true)

theorem identity60906 : scanCanonicalize (H12AffineFastState.compose env60906 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 124) := by decide +kernel

theorem selectedBound60906 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env60907 : List Nat := [2,4,8,16,32,64,34,124,9,95,3,51,122,99,11,90,98,10,94,11,51,83,64,41,80,17,33,98,50,40,39,120,124,11,99,8]

theorem envBound60907 : H12AffineFastState.Bounded env60907 := by
  intro p hp
  have h : env60907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60906_60907 : H12AffineEnvironment.transform 7 124 env60906 = env60907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 124 env60906 == env60907) = true)

theorem identity60907 : scanCanonicalize (H12AffineFastState.compose env60907 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound60907 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60908 : List Nat := [2,4,8,16,2,64,0,94,9,95,3,17,88,65,11,90,64,10,94,11,17,83,64,11,80,17,3,64,16,10,5,90,94,11,65,8]

theorem envBound60908 : H12AffineFastState.Bounded env60908 := by
  intro p hp
  have h : env60908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60907_60908 : H12AffineEnvironment.transform 4 2 env60907 = env60908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env60907 == env60908) = true)

def env60909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,169,65536,131072,69824,1025,169,136513,13625,144712,136231,8329,139272,70837,1344,131152,75786,200846,209367,256,66931,131073,512]

theorem envBound60909 : H12AffineFastState.Bounded env60909 := by
  intro p hp
  have h : env60909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60897_60909 : H12AffineEnvironment.transform 13 1345 env60897 = env60909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env60897 == env60909) = true)

theorem identity60909 : scanCanonicalize (H12AffineFastState.compose env60909 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound60909 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,169,65536,131072,67025,1025,169,131152,8232,139353,131382,8329,139272,65956,1344,131152,75786,198047,206022,256,66931,131073,512]

theorem envBound60910 : H12AffineFastState.Bounded env60910 := by
  intro p hp
  have h : env60910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60909_60910 : H12AffineEnvironment.transform 11 1297 env60909 = env60910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env60909 == env60910) = true)

def env60911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,6329753,6304863,4247641,6342040,2544860,16385,131152,4315355,6402143,209367,256,2315635,131073,4256464]

theorem envBound60911 : H12AffineFastState.Bounded env60911 := by
  intro p hp
  have h : env60911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60774_60911 : H12AffineEnvironment.transform 24 4247641 env60774 = env60911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247641 env60774 == env60911) = true)

def env60912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,2269392,144713,169103,2257033,157000,2544860,16385,131152,2324491,200847,209367,256,2315635,131073,2249216]

theorem envBound60912 : H12AffineFastState.Bounded env60912 := by
  intro p hp
  have h : env60912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60911_60912 : H12AffineEnvironment.transform 21 2269392 env60911 = env60912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269392 env60911 == env60912) = true)

def env60913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136512,46480,144713,169103,26057,157000,311708,16385,131152,93515,200847,209367,256,81971,131073,18240]

theorem envBound60913 : H12AffineFastState.Bounded env60913 := by
  intro p hp
  have h : env60913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60912_60913 : H12AffineEnvironment.transform 20 136512 env60912 = env60913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env60912 == env60913) = true)

def env60914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1025,32768,136512,46480,144713,169103,26057,157000,103452,16385,131152,93515,200847,209367,256,81971,131073,18240]

theorem envBound60914 : H12AffineFastState.Bounded env60914 := by
  intro p hp
  have h : env60914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60913_60914 : H12AffineEnvironment.transform 17 87424 env60913 = env60914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env60913 == env60914) = true)

theorem identity60914 : scanCanonicalize (H12AffineFastState.compose env60914 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound60914 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5292,32768,65536,131072,65836,1025,32768,136512,46480,144713,169103,12645,143844,103452,5293,131152,80359,200847,209367,256,70815,131073,5100]

theorem envBound60915 : H12AffineFastState.Bounded env60915 := by
  intro p hp
  have h : env60915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60914_60915 : H12AffineEnvironment.transform 13 5292 env60914 = env60915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env60914 == env60915) = true)

def env60916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,32768,65536,131072,65836,1025,32768,132268,42108,140453,165219,8329,139272,99824,1345,131152,75787,196963,204859,256,66931,131073,512]

theorem envBound60916 : H12AffineFastState.Bounded env60916 := by
  intro p hp
  have h : env60916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0