import H12CloudChart1Data217

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity55201 : scanCanonicalize (H12AffineFastState.compose env55201 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound55201 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55202 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,17,2057,81,2389,2050,64,33,320,2388,81,33,17,3,2056,65,340,65,17,2420,21,33,257,33,1,512]

theorem envBound55202 : H12AffineFastState.Bounded env55202 := by
  intro p hp
  have h : env55202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55201_55202 : H12AffineEnvironment.transform 12 2057 env55201 = env55202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env55201 == env55202) = true)

theorem identity55202 : scanCanonicalize (H12AffineFastState.compose env55202 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound55202 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55203 : List Nat := [2,4,8,16,32,64,9,256,512,321,32,17,41,81,373,34,64,33,320,372,81,33,17,3,40,65,340,65,17,340,21,33,257,33,1,512]

theorem envBound55203 : H12AffineFastState.Bounded env55203 := by
  intro p hp
  have h : env55203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55202_55203 : H12AffineEnvironment.transform 10 32 env55202 = env55203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env55202 == env55203) = true)

theorem identity55203 : scanCanonicalize (H12AffineFastState.compose env55203 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound55203 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55204 : List Nat := [2,4,8,16,32,64,9,256,91,321,32,17,41,81,373,34,64,33,320,372,81,33,17,3,40,65,340,65,17,340,21,33,257,33,1,91]

theorem envBound55204 : H12AffineFastState.Bounded env55204 := by
  intro p hp
  have h : env55204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55203_55204 : H12AffineEnvironment.transform 8 91 env55203 = env55204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env55203 == env55204) = true)

theorem identity55204 : scanCanonicalize (H12AffineFastState.compose env55204 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55204 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55205 : List Nat := [2,4,8,16,1,64,9,256,91,321,1,17,8,81,340,3,64,0,320,341,81,0,17,3,9,65,340,65,17,340,21,0,257,0,1,91]

theorem envBound55205 : H12AffineFastState.Bounded env55205 := by
  intro p hp
  have h : env55205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55204_55205 : H12AffineEnvironment.transform 4 1 env55204 = env55205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55204 == env55205) = true)

theorem identity55205 : scanCanonicalize (H12AffineFastState.compose env55205 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound55205 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55206 : List Nat := [2,4,8,16,1,64,9,15,91,78,1,17,8,81,91,3,64,0,79,90,81,0,17,3,9,65,91,65,17,91,21,0,14,0,1,91]

theorem envBound55206 : H12AffineFastState.Bounded env55206 := by
  intro p hp
  have h : env55206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55205_55206 : H12AffineEnvironment.transform 7 15 env55205 = env55206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env55205 == env55206) = true)

theorem identity55206 : scanCanonicalize (H12AffineFastState.compose env55206 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound55206 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55207 : List Nat := [2,4,8,16,1,0,9,15,27,14,1,17,8,17,27,3,0,0,15,26,17,0,17,3,9,1,27,1,17,27,21,0,14,0,1,27]

theorem envBound55207 : H12AffineFastState.Bounded env55207 := by
  intro p hp
  have h : env55207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55206_55207 : H12AffineEnvironment.transform 5 0 env55206 = env55207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55206 == env55207) = true)

theorem identity55207 : scanCanonicalize (H12AffineFastState.compose env55207 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound55207 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55208 : List Nat := [2,4,8,12,1,0,9,15,7,14,1,13,8,13,7,3,0,0,15,6,13,0,13,3,9,1,7,1,13,7,9,0,14,0,1,7]

theorem envBound55208 : H12AffineFastState.Bounded env55208 := by
  intro p hp
  have h : env55208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55207_55208 : H12AffineEnvironment.transform 3 12 env55207 = env55208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env55207 == env55208) = true)

theorem identity55208 : scanCanonicalize (H12AffineFastState.compose env55208 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound55208 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55209 : List Nat := [2,4,4,0,1,0,5,3,7,2,1,1,4,1,7,3,0,0,3,6,1,0,1,3,5,1,7,1,1,7,5,0,2,0,1,7]

theorem envBound55209 : H12AffineFastState.Bounded env55209 := by
  intro p hp
  have h : env55209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55208_55209 : H12AffineEnvironment.transform 2 4 env55208 = env55209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env55208 == env55209) = true)

theorem identity55209 : scanCanonicalize (H12AffineFastState.compose env55209 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55209 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55210 : List Nat := [0,4,4,0,1,0,5,1,5,0,1,1,4,1,5,1,0,0,1,4,1,0,1,1,5,1,5,1,1,5,5,0,0,0,1,5]

theorem envBound55210 : H12AffineFastState.Bounded env55210 := by
  intro p hp
  have h : env55210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55209_55210 : H12AffineEnvironment.transform 0 0 env55209 = env55210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55209 == env55210) = true)

theorem identity55210 : scanCanonicalize (H12AffineFastState.compose env55210 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound55210 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env55211 : List Nat := [0,1,1,0,1,0,0,1,0,0,1,1,1,1,0,1,0,0,1,1,1,0,1,1,0,1,0,1,1,0,0,0,0,0,1,0]

theorem envBound55211 : H12AffineFastState.Bounded env55211 := by
  intro p hp
  have h : env55211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55210_55211 : H12AffineEnvironment.transform 1 1 env55210 = env55211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env55210 == env55211) = true)

def env55212 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,62589,119878,16777216,8193,65,16959507,16880708,102743,212078,16797783,16875893,257,16777250,16834831,16873224]

theorem envBound55212 : H12AffineFastState.Bounded env55212 := by
  intro p hp
  have h : env55212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55187_55212 : H12AffineEnvironment.transform 20 4161 env55187 = env55212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env55187 == env55212) = true)

theorem identity55212 : scanCanonicalize (H12AffineFastState.compose env55212 (packedSelected [17] rootPS)) = affineNative (2^(23+1) ^^^ 95497) := by decide +kernel

theorem selectedBound55212 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55213 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,62589,119878,95497,8193,65,245018,57677,102743,212078,75102,62588,257,95531,103430,513]

theorem envBound55213 : H12AffineFastState.Bounded env55213 := by
  intro p hp
  have h : env55213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55212_55213 : H12AffineEnvironment.transform 23 95497 env55212 = env55213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env55212 == env55213) = true)

theorem identity55213 : scanCanonicalize (H12AffineFastState.compose env55213 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55213 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env55214 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10280,1025,8541,4161,21793,95514,95497,8193,65,203846,16401,77835,212078,75102,21792,257,95531,79194,513]

theorem envBound55214 : H12AffineFastState.Bounded env55214 := by
  intro p hp
  have h : env55214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55213_55214 : H12AffineEnvironment.transform 14 8540 env55213 = env55214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env55213 == env55214) = true)

theorem identity55214 : scanCanonicalize (H12AffineFastState.compose env55214 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound55214 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env55215 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8540,65536,131072,10280,1025,8541,4161,112,73803,73816,8193,65,203846,5440,77835,212078,75102,113,257,73850,79194,513]

theorem envBound55215 : H12AffineFastState.Bounded env55215 := by
  intro p hp
  have h : env55215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55214_55215 : H12AffineEnvironment.transform 13 5457 env55214 = env55215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env55214 == env55215) = true)

theorem identity55215 : scanCanonicalize (H12AffineFastState.compose env55215 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55215 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env55216 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,65536,131072,10280,1025,8460,4112,33,73754,73737,8193,16,203799,5393,77835,212031,75023,32,257,73771,79115,513]

theorem envBound55216 : H12AffineFastState.Bounded env55216 := by
  intro p hp
  have h : env55216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55215_55216 : H12AffineEnvironment.transform 5 17 env55215 = env55216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55215 == env55216) = true)

theorem identity55216 : scanCanonicalize (H12AffineFastState.compose env55216 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound55216 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env55217 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,65536,70678,10280,1025,8460,4112,33,73754,73737,8193,16,2049,5393,77835,10281,75023,32,257,73771,79115,513]

theorem envBound55217 : H12AffineFastState.Bounded env55217 := by
  intro p hp
  have h : env55217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55216_55217 : H12AffineEnvironment.transform 16 70678 env55216 = env55217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env55216 == env55217) = true)

theorem identity55217 : scanCanonicalize (H12AffineFastState.compose env55217 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound55217 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55218 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8203,13341,10280,1025,8460,4112,33,17,2,8193,16,2049,5393,4096,10281,1284,32,257,32,5376,513]

theorem envBound55218 : H12AffineFastState.Bounded env55218 := by
  intro p hp
  have h : env55218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55217_55218 : H12AffineEnvironment.transform 15 8203 env55217 = env55218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env55217 == env55218) = true)

def env55219 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,2155580,2212870,16777216,8193,65,16959507,18973701,102742,2305071,18890775,16875893,257,16777251,16834830,18966344]

theorem envBound55219 : H12AffineFastState.Bounded env55219 := by
  intro p hp
  have h : env55219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55186_55219 : H12AffineEnvironment.transform 17 10281 env55186 = env55219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55186 == env55219) = true)

theorem identity55219 : scanCanonicalize (H12AffineFastState.compose env55219 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound55219 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env55220 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115735,73771,17,16777216,8193,65,16959507,16793618,102742,190520,16876544,16875893,257,16777251,16834830,16819039]

theorem envBound55220 : H12AffineFastState.Bounded env55220 := by
  intro p hp
  have h : env55220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55219_55220 : H12AffineEnvironment.transform 20 115735 env55219 = env55220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env55219 == env55220) = true)

theorem identity55220 : scanCanonicalize (H12AffineFastState.compose env55220 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound55220 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1025,32769,115735,73771,17,16777216,8193,65,16885769,16793618,102742,100386,16876544,16875893,257,16777251,16834830,16819039]

theorem envBound55221 : H12AffineFastState.Bounded env55221 := by
  intro p hp
  have h : env55221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55220_55221 : H12AffineEnvironment.transform 16 90138 env55220 = env55221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env55220 == env55221) = true)

theorem identity55221 : scanCanonicalize (H12AffineFastState.compose env55221 (packedSelected [1,2,3,5,6,7,8,9,10,11,18,19,20,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 41342) := by decide +kernel

theorem selectedBound55221 : packedSelected [1,2,3,5,6,7,8,9,10,11,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env55222 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,41342,49508,10281,1025,32769,25961,33109,17,16777216,8193,65,16779639,16793618,12328,10588,16786814,16785419,257,16777251,16834830,16819039]

theorem envBound55222 : H12AffineFastState.Bounded env55222 := by
  intro p hp
  have h : env55222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55221_55222 : H12AffineEnvironment.transform 15 41342 env55221 = env55222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41342 env55221 == env55222) = true)

theorem identity55222 : scanCanonicalize (H12AffineFastState.compose env55222 (packedSelected [1,4,8,9,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 12344) := by decide +kernel

theorem selectedBound55222 : packedSelected [1,4,8,9,14,16,19] rootPS < 2^1333 := by decide +kernel

def env55223 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12344,32768,41342,45404,10281,1025,32769,5457,33109,17,16777216,8193,65,16779639,16789546,12328,10588,16786814,16785419,257,16777251,16814390,16819039]

theorem envBound55223 : H12AffineFastState.Bounded env55223 := by
  intro p hp
  have h : env55223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55222_55223 : H12AffineEnvironment.transform 13 12344 env55222 = env55223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12344 env55222 == env55223) = true)

theorem identity55223 : scanCanonicalize (H12AffineFastState.compose env55223 (packedSelected [4,8,9,14,16,17,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 8234) := by decide +kernel

theorem selectedBound55223 : packedSelected [4,8,9,14,16,17,28,31] rootPS < 2^1333 := by decide +kernel

def env55224 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12344,32768,41342,45404,10281,1025,32769,5457,33109,17,8234,8193,65,10589,4096,12328,10588,1364,33,257,8201,45340,33653]

theorem envBound55224 : H12AffineFastState.Bounded env55224 := by
  intro p hp
  have h : env55224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55223_55224 : H12AffineEnvironment.transform 23 8234 env55223 = env55224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8234 env55223 == env55224) = true)

theorem identity55224 : scanCanonicalize (H12AffineFastState.compose env55224 (packedSelected [11,16,17,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound55224 : packedSelected [11,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env55225 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,4113,32768,33111,37237,2048,1025,32769,5457,33109,17,3,40,65,2420,4096,4097,2421,1364,33,257,32,37173,33653]

theorem envBound55225 : H12AffineFastState.Bounded env55225 := by
  intro p hp
  have h : env55225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55224_55225 : H12AffineEnvironment.transform 12 41 env55224 = env55225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env55224 == env55225) = true)

theorem identity55225 : scanCanonicalize (H12AffineFastState.compose env55225 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55225 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env55226 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,9,4113,32768,33111,37205,2048,1025,32769,5457,33109,17,3,8,65,2388,4096,4097,2389,1364,1,257,0,37141,33621]

theorem envBound55226 : H12AffineFastState.Bounded env55226 := by
  intro p hp
  have h : env55226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55225_55226 : H12AffineEnvironment.transform 4 0 env55225 = env55226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55225 == env55226) = true)

theorem identity55226 : scanCanonicalize (H12AffineFastState.compose env55226 (packedSelected [2,4,9] rootPS)) = affineNative (2^(14+1) ^^^ 3344) := by decide +kernel

theorem selectedBound55226 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env55227 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,9,4113,3344,3143,7237,2048,1025,3345,5457,3141,17,3,8,65,2388,4096,4097,2389,1364,1,257,0,7173,3653]

theorem envBound55227 : H12AffineFastState.Bounded env55227 := by
  intro p hp
  have h : env55227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55226_55227 : H12AffineEnvironment.transform 14 3344 env55226 = env55227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3344 env55226 == env55227) = true)

theorem identity55227 : scanCanonicalize (H12AffineFastState.compose env55227 (packedSelected [0,1,7,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound55227 : packedSelected [0,1,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env55228 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,1108,9,1093,3344,3143,2065,2048,1025,3345,261,3141,17,3,8,65,2388,1108,1109,2389,1364,1,257,0,2129,3653]

theorem envBound55228 : H12AffineFastState.Bounded env55228 := by
  intro p hp
  have h : env55228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55227_55228 : H12AffineEnvironment.transform 11 1108 env55227 = env55228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env55227 == env55228) = true)

theorem identity55228 : scanCanonicalize (H12AffineFastState.compose env55228 (packedSelected [6,10] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound55228 : packedSelected [6,10] rootPS < 2^1333 := by decide +kernel

def env55229 : List Nat := [2,4,8,16,0,64,9,256,512,257,2048,341,9,324,2065,2374,2065,2048,256,2064,261,2372,17,3,8,65,2388,341,340,2389,85,1,257,0,2129,2884]

theorem envBound55229 : H12AffineFastState.Bounded env55229 := by
  intro p hp
  have h : env55229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55228_55229 : H12AffineEnvironment.transform 9 257 env55228 = env55229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env55228 == env55229) = true)

theorem identity55229 : scanCanonicalize (H12AffineFastState.compose env55229 (packedSelected [3,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound55229 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env55230 : List Nat := [2,4,8,16,0,64,9,256,512,257,260,341,9,324,277,66,277,260,256,276,261,64,17,3,8,65,80,341,340,81,85,1,257,0,341,576]

theorem envBound55230 : H12AffineFastState.Bounded env55230 := by
  intro p hp
  have h : env55230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55229_55230 : H12AffineEnvironment.transform 10 260 env55229 = env55230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env55229 == env55230) = true)

theorem identity55230 : scanCanonicalize (H12AffineFastState.compose env55230 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound55230 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55231 : List Nat := [2,4,8,16,0,64,9,68,512,69,64,17,9,0,81,66,81,64,68,80,65,64,17,3,8,65,80,17,16,81,85,1,69,0,17,576]

theorem envBound55231 : H12AffineFastState.Bounded env55231 := by
  intro p hp
  have h : env55231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55230_55231 : H12AffineEnvironment.transform 7 68 env55230 = env55231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env55230 == env55231) = true)

theorem identity55231 : scanCanonicalize (H12AffineFastState.compose env55231 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound55231 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env55232 : List Nat := [2,4,8,16,0,64,9,68,0,69,64,17,9,0,81,66,81,64,68,80,65,64,17,3,8,65,80,17,16,81,85,1,69,0,17,64]

theorem envBound55232 : H12AffineFastState.Bounded env55232 := by
  intro p hp
  have h : env55232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55231_55232 : H12AffineEnvironment.transform 8 0 env55231 = env55232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env55231 == env55232) = true)

theorem identity55232 : scanCanonicalize (H12AffineFastState.compose env55232 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55232 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env55233 : List Nat := [2,4,8,16,0,17,9,21,0,20,17,17,9,0,0,19,0,17,21,1,16,17,17,3,8,16,1,17,16,0,4,1,20,0,17,17]

theorem envBound55233 : H12AffineFastState.Bounded env55233 := by
  intro p hp
  have h : env55233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55232_55233 : H12AffineEnvironment.transform 5 17 env55232 = env55233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55232 == env55233) = true)

theorem identity55233 : scanCanonicalize (H12AffineFastState.compose env55233 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55233 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env55234 : List Nat := [2,4,8,0,0,1,9,5,0,4,1,1,9,0,0,3,0,1,5,1,0,1,1,3,8,0,1,1,0,0,4,1,4,0,1,1]

theorem envBound55234 : H12AffineFastState.Bounded env55234 := by
  intro p hp
  have h : env55234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55233_55234 : H12AffineEnvironment.transform 3 0 env55233 = env55234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55233 == env55234) = true)

theorem identity55234 : scanCanonicalize (H12AffineFastState.compose env55234 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55234 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55235 : List Nat := [2,4,2,0,0,1,3,5,0,4,1,1,3,0,0,3,0,1,5,1,0,1,1,3,2,0,1,1,0,0,4,1,4,0,1,1]

theorem envBound55235 : H12AffineFastState.Bounded env55235 := by
  intro p hp
  have h : env55235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55234_55235 : H12AffineEnvironment.transform 2 2 env55234 = env55235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55234 == env55235) = true)

def env55236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485414,16777216,8328,65,16959643,18973836,375286,2305190,19163319,16876029,257,17049610,17090990,19222369]

theorem envBound55236 : H12AffineFastState.Bounded env55236 := by
  intro p hp
  have h : env55236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55171_55236 : H12AffineEnvironment.transform 21 2155581 env55171 = env55236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155581 env55171 == env55236) = true)

def env55237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485294,16777216,8192,65,16959507,18973700,375166,2305070,19163199,16875893,257,17049610,17090854,19222369]

theorem envBound55237 : H12AffineFastState.Bounded env55237 := by
  intro p hp
  have h : env55237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55236_55237 : H12AffineEnvironment.transform 6 8 env55236 = env55237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55236 == env55237) = true)

def env55238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2155581,2212870,16777216,8192,65,16959507,18973700,102742,2305070,18890775,16875893,257,16777250,16834830,18966345]

theorem envBound55238 : H12AffineFastState.Bounded env55238 := by
  intro p hp
  have h : env55238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55237_55238 : H12AffineEnvironment.transform 17 10280 env55237 = env55238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env55237 == env55238) = true)

theorem identity55238 : scanCanonicalize (H12AffineFastState.compose env55238 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound55238 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env55239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,91466,98679,41292,16777216,8192,65,16959507,16834894,102742,149860,16852317,16875893,257,16777250,16834830,16777731]

theorem envBound55239 : H12AffineFastState.Bounded env55239 := by
  intro p hp
  have h : env55239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55238_55239 : H12AffineEnvironment.transform 20 91466 env55238 = env55239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env55238 == env55239) = true)

theorem identity55239 : scanCanonicalize (H12AffineFastState.compose env55239 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound55239 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env55240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10280,1025,8540,91466,73770,17,16777216,8192,65,16935246,16793619,77835,149860,16852317,16850984,257,16777250,16793683,16777731]

theorem envBound55240 : H12AffineFastState.Bounded env55240 := by
  intro p hp
  have h : env55240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55239_55240 : H12AffineEnvironment.transform 14 8541 env55239 = env55240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env55239 == env55240) = true)

theorem identity55240 : scanCanonicalize (H12AffineFastState.compose env55240 (packedSelected [0,3,4,7,10,16,17,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound55240 : packedSelected [0,3,4,7,10,16,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10280,1025,8540,91466,73770,17,16777216,8192,65,16845140,16793619,77835,76158,16852317,16850984,257,16777250,16793683,16777731]

theorem envBound55241 : H12AffineFastState.Bounded env55241 := by
  intro p hp
  have h : env55241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55240_55241 : H12AffineEnvironment.transform 16 90138 env55240 = env55241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env55240 == env55241) = true)

theorem identity55241 : scanCanonicalize (H12AffineFastState.compose env55241 (packedSelected [0,3,4,5,7,10,17,22] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound55241 : packedSelected [0,3,4,5,7,10,17,22] rootPS < 2^1333 := by decide +kernel

def env55242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,342,24908,10280,1025,8540,25628,8572,17,16777216,8192,65,16779266,16793619,12637,10280,16786443,16785790,257,16777250,16793683,16777731]

theorem envBound55242 : H12AffineFastState.Bounded env55242 := by
  intro p hp
  have h : env55242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55241_55242 : H12AffineEnvironment.transform 15 342 env55241 = env55242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env55241 == env55242) = true)

theorem identity55242 : scanCanonicalize (H12AffineFastState.compose env55242 (packedSelected [16,20] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound55242 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,342,24908,10280,1025,8540,25628,8572,17,2,8192,65,2048,16401,12637,10280,9225,8572,257,32,16465,513]

theorem envBound55243 : H12AffineFastState.Bounded env55243 := by
  intro p hp
  have h : env55243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55242_55243 : H12AffineEnvironment.transform 23 2 env55242 = env55243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env55242 == env55243) = true)

theorem identity55243 : scanCanonicalize (H12AffineFastState.compose env55243 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55243 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env55244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,8540,8541,342,16,10280,1025,8540,1344,8572,17,2,8192,65,2048,8525,12637,10280,9225,8572,257,32,8461,513]

theorem envBound55244 : H12AffineFastState.Bounded env55244 := by
  intro p hp
  have h : env55244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55243_55244 : H12AffineEnvironment.transform 13 8540 env55243 = env55244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8540 env55243 == env55244) = true)

theorem identity55244 : scanCanonicalize (H12AffineFastState.compose env55244 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 2169) := by decide +kernel

theorem selectedBound55244 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env55245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2169,2341,2340,342,16,81,1025,2341,1344,2309,17,2,2169,65,2048,2356,6436,81,3184,2309,257,32,2420,513]

theorem envBound55245 : H12AffineFastState.Bounded env55245 := by
  intro p hp
  have h : env55245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55244_55245 : H12AffineEnvironment.transform 12 2169 env55244 = env55245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2169 env55244 == env55245) = true)

theorem identity55245 : scanCanonicalize (H12AffineFastState.compose env55245 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound55245 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55246 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,16,2169,2341,2340,342,16,81,1025,2341,1344,2309,17,2,2169,65,2048,2356,2356,81,3184,2309,257,32,2420,513]

theorem envBound55246 : H12AffineFastState.Bounded env55246 := by
  intro p hp
  have h : env55246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55245_55246 : H12AffineEnvironment.transform 11 16 env55245 = env55246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env55245 == env55246) = true)

theorem identity55246 : scanCanonicalize (H12AffineFastState.compose env55246 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound55246 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env55247 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1077,16,1100,1296,1297,342,16,81,1025,1296,1344,1328,17,2,1100,65,1077,1281,1281,81,69,1328,257,32,1345,513]

theorem envBound55247 : H12AffineFastState.Bounded env55247 := by
  intro p hp
  have h : env55247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55246_55247 : H12AffineEnvironment.transform 10 1077 env55246 = env55247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env55246 == env55247) = true)

theorem identity55247 : scanCanonicalize (H12AffineFastState.compose env55247 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound55247 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55248 : List Nat := [2,4,8,16,32,64,8,256,512,100,81,16,40,372,373,342,16,81,101,372,292,340,17,2,40,65,81,357,357,81,69,340,257,32,293,513]

theorem envBound55248 : H12AffineFastState.Bounded env55248 := by
  intro p hp
  have h : env55248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55247_55248 : H12AffineEnvironment.transform 9 100 env55247 = env55248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env55247 == env55248) = true)

theorem identity55248 : scanCanonicalize (H12AffineFastState.compose env55248 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound55248 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env55249 : List Nat := [2,4,8,16,32,64,8,68,512,100,81,16,40,48,49,18,16,81,101,48,96,16,17,2,40,65,81,33,33,81,69,16,69,32,97,513]

theorem envBound55249 : H12AffineFastState.Bounded env55249 := by
  intro p hp
  have h : env55249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55248_55249 : H12AffineEnvironment.transform 7 68 env55248 = env55249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env55248 == env55249) = true)

theorem identity55249 : scanCanonicalize (H12AffineFastState.compose env55249 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound55249 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env55250 : List Nat := [2,4,8,16,32,0,8,4,512,36,17,16,40,48,49,18,16,17,37,48,32,16,17,2,40,1,17,33,33,17,5,16,5,32,33,513]

theorem envBound55250 : H12AffineFastState.Bounded env55250 := by
  intro p hp
  have h : env55250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55249_55250 : H12AffineEnvironment.transform 5 0 env55249 = env55250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55249 == env55250) = true)

theorem identity55250 : scanCanonicalize (H12AffineFastState.compose env55250 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound55250 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55251 : List Nat := [2,4,8,16,17,0,8,4,512,21,17,16,25,1,0,18,16,17,20,1,17,16,17,2,25,1,17,16,16,17,5,16,5,17,16,513]

theorem envBound55251 : H12AffineFastState.Bounded env55251 := by
  intro p hp
  have h : env55251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55250_55251 : H12AffineEnvironment.transform 4 17 env55250 = env55251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env55250 == env55251) = true)

theorem identity55251 : scanCanonicalize (H12AffineFastState.compose env55251 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55251 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55252 : List Nat := [2,4,8,1,0,0,8,4,512,4,0,1,8,1,0,3,1,0,5,1,0,1,0,2,8,1,0,1,1,0,5,1,5,0,1,513]

theorem envBound55252 : H12AffineFastState.Bounded env55252 := by
  intro p hp
  have h : env55252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55251_55252 : H12AffineEnvironment.transform 3 1 env55251 = env55252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55251 == env55252) = true)

theorem identity55252 : scanCanonicalize (H12AffineFastState.compose env55252 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound55252 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55253 : List Nat := [2,4,8,1,0,0,8,4,0,4,0,1,8,1,0,3,1,0,5,1,0,1,0,2,8,1,0,1,1,0,5,1,5,0,1,1]

theorem envBound55253 : H12AffineFastState.Bounded env55253 := by
  intro p hp
  have h : env55253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55252_55253 : H12AffineEnvironment.transform 8 0 env55252 = env55253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env55252 == env55253) = true)

def env55254 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,2155581,2212871,16777216,8192,65,16959507,18973700,102743,2305070,18890774,16875893,257,16777251,16834831,18966344]

theorem envBound55254 : H12AffineFastState.Bounded env55254 := by
  intro p hp
  have h : env55254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55237_55254 : H12AffineEnvironment.transform 17 10281 env55237 = env55254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55237 == env55254) = true)

theorem identity55254 : scanCanonicalize (H12AffineFastState.compose env55254 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound55254 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env55255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1025,8540,2097152,2114912,2188634,16777216,8192,65,16935246,18949465,77834,2305070,18890774,16850984,257,16777251,16793682,18966344]

theorem envBound55255 : H12AffineFastState.Bounded env55255 := by
  intro p hp
  have h : env55255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55254_55255 : H12AffineEnvironment.transform 14 8541 env55254 = env55255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env55254 == env55255) = true)

theorem identity55255 : scanCanonicalize (H12AffineFastState.compose env55255 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 2303321) := by decide +kernel

theorem selectedBound55255 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env55256 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1025,8540,2097152,2114912,2188634,2303321,8192,65,2182167,131072,77834,2305070,222543,2229617,257,2303354,2319627,147985]

theorem envBound55256 : H12AffineFastState.Bounded env55256 := by
  intro p hp
  have h : env55256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55255_55256 : H12AffineEnvironment.transform 23 2303321 env55255 = env55256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2303321 env55255 == env55256) = true)

theorem identity55256 : scanCanonicalize (H12AffineFastState.compose env55256 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound55256 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env55257 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,10281,1025,8540,2097152,2114912,2114896,2229587,8192,65,2124829,131072,4096,2231332,148805,2229617,257,2229616,2245889,147985]

theorem envBound55257 : H12AffineFastState.Bounded env55257 := by
  intro p hp
  have h : env55257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55256_55257 : H12AffineEnvironment.transform 15 8202 env55256 = env55257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env55256 == env55257) = true)

theorem identity55257 : scanCanonicalize (H12AffineFastState.compose env55257 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound55257 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env55258 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,10281,1025,8540,5456,20528,20480,135171,8192,65,31053,131072,4096,137588,148805,135201,257,135200,151633,147985]

theorem envBound55258 : H12AffineFastState.Bounded env55258 := by
  intro p hp
  have h : env55258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55257_55258 : H12AffineEnvironment.transform 20 5456 env55257 = env55258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env55257 == env55258) = true)

theorem identity55258 : scanCanonicalize (H12AffineFastState.compose env55258 (packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound55258 : packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env55259 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,8541,8202,131072,10281,1025,8540,5456,8572,8524,135171,8192,65,2049,131072,4096,137588,144393,135201,257,135200,139549,144221]

theorem envBound55259 : H12AffineFastState.Bounded env55259 := by
  intro p hp
  have h : env55259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55258_55259 : H12AffineEnvironment.transform 13 12620 env55258 = env55259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env55258 == env55259) = true)

theorem identity55259 : scanCanonicalize (H12AffineFastState.compose env55259 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound55259 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env55260 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,8541,8202,13673,10281,1025,8540,5456,8572,8524,9578,8192,65,2049,13673,4096,11293,352,9544,257,9545,5236,1588]

theorem envBound55260 : H12AffineFastState.Bounded env55260 := by
  intro p hp
  have h : env55260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55259_55260 : H12AffineEnvironment.transform 16 13673 env55259 = env55260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env55259 == env55260) = true)

theorem identity55260 : scanCanonicalize (H12AffineFastState.compose env55260 (packedSelected [2,3,4,5,6,9,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55260 : packedSelected [2,3,4,5,6,9,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env55261 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4113,0,343,5172,2420,1025,1,5456,33,17,1079,349,65,2049,5172,4096,3392,352,1045,257,1044,5236,1588]

theorem envBound55261 : H12AffineFastState.Bounded env55261 := by
  intro p hp
  have h : env55261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55260_55261 : H12AffineEnvironment.transform 12 349 env55260 = env55261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55260 == env55261) = true)

theorem identity55261 : scanCanonicalize (H12AffineFastState.compose env55261 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound55261 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env55262 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,120,4113,0,114,5172,2129,1025,1,5237,33,17,1079,120,65,2049,5172,4096,3173,69,1045,36,1044,5236,1588]

theorem envBound55262 : H12AffineFastState.Bounded env55262 := by
  intro p hp
  have h : env55262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55261_55262 : H12AffineEnvironment.transform 7 37 env55261 = env55262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55261 == env55262) = true)

theorem identity55262 : scanCanonicalize (H12AffineFastState.compose env55262 (packedSelected [2,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound55262 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env55263 : List Nat := [2,4,8,16,32,64,8,37,512,100,2048,4096,120,4113,0,114,4176,2129,101,1,4113,33,17,83,120,65,2049,4176,4096,2049,69,113,36,112,4112,592]

theorem envBound55263 : H12AffineFastState.Bounded env55263 := by
  intro p hp
  have h : env55263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55262_55263 : H12AffineEnvironment.transform 9 100 env55262 = env55263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env55262 == env55263) = true)

theorem identity55263 : scanCanonicalize (H12AffineFastState.compose env55263 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound55263 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env55264 : List Nat := [2,4,8,16,32,64,8,37,512,100,2048,2112,120,2129,0,114,2064,2129,101,1,2129,33,17,83,120,65,2049,2064,2112,2049,69,113,36,112,2128,592]

theorem envBound55264 : H12AffineFastState.Bounded env55264 := by
  intro p hp
  have h : env55264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55263_55264 : H12AffineEnvironment.transform 11 2112 env55263 = env55264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env55263 == env55264) = true)

def env55265 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485295,16777216,8193,65,16959506,18973701,375167,2305071,19163198,16875892,257,17049610,17090855,19222369]

theorem envBound55265 : H12AffineFastState.Bounded env55265 := by
  intro p hp
  have h : env55265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55236_55265 : H12AffineEnvironment.transform 6 9 env55236 = env55265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55236 == env55265) = true)

theorem identity55265 : scanCanonicalize (H12AffineFastState.compose env55265 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388158) := by decide +kernel

theorem selectedBound55265 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env55266 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,329731,17,16777216,8193,65,16959506,17066043,375167,442385,16876544,16875892,257,17049610,17090855,16819039]

theorem envBound55266 : H12AffineFastState.Bounded env55266 := by
  intro p hp
  have h : env55266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55265_55266 : H12AffineEnvironment.transform 20 388158 env55265 = env55266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388158 env55265 == env55266) = true)

def env55267 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,388158,329731,17,16777216,8193,65,16812034,17066043,375167,294913,16876544,16875892,257,17049610,17090855,16819039]

theorem envBound55267 : H12AffineFastState.Bounded env55267 := by
  intro p hp
  have h : env55267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55266_55267 : H12AffineEnvironment.transform 16 16400 env55266 = env55267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env55266 == env55267) = true)

theorem identity55267 : scanCanonicalize (H12AffineFastState.compose env55267 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound55267 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env55268 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,388158,329731,17,41310,8193,65,10588,313701,375167,294913,75102,73770,257,297300,288889,513]

theorem envBound55268 : H12AffineFastState.Bounded env55268 := by
  intro p hp
  have h : env55268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55267_55268 : H12AffineEnvironment.transform 23 41310 env55267 = env55268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env55267 == env55268) = true)

theorem identity55268 : scanCanonicalize (H12AffineFastState.compose env55268 (packedSelected [2,4,6,7,9,11,17,18,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 76158) := by decide +kernel

theorem selectedBound55268 : packedSelected [2,4,6,7,9,11,17,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env55269 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,76158,1025,32769,50496,8573,17,41310,8193,65,10588,122907,36865,108927,75102,73770,257,106538,82183,513]

theorem envBound55269 : H12AffineFastState.Bounded env55269 := by
  intro p hp
  have h : env55269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55268_55269 : H12AffineEnvironment.transform 17 76158 env55268 = env55269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76158 env55268 == env55269) = true)

theorem identity55269 : scanCanonicalize (H12AffineFastState.compose env55269 (packedSelected [2,6,7,14,17,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound55269 : packedSelected [2,6,7,14,17,20,27] rootPS < 2^1333 := by decide +kernel

def env55270 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16400,43049,1025,32769,50496,8573,17,41310,8193,65,10588,24908,36865,10280,41993,41341,257,8573,49232,513]

theorem envBound55270 : H12AffineFastState.Bounded env55270 := by
  intro p hp
  have h : env55270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55269_55270 : H12AffineEnvironment.transform 15 33111 env55269 = env55270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env55269 == env55270) = true)

theorem identity55270 : scanCanonicalize (H12AffineFastState.compose env55270 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound55270 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env55271 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,342,16400,10280,1025,0,17729,8573,17,8543,8193,65,10588,24908,4096,10280,9224,8572,257,8573,16465,513]

theorem envBound55271 : H12AffineFastState.Bounded env55271 := by
  intro p hp
  have h : env55271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55270_55271 : H12AffineEnvironment.transform 14 1 env55270 = env55271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env55270 == env55271) = true)

theorem identity55271 : scanCanonicalize (H12AffineFastState.compose env55271 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55271 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55272 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,342,16400,2420,1025,0,17729,33,17,3,349,65,2048,16400,4096,2420,1364,32,257,33,16465,513]

theorem envBound55272 : H12AffineFastState.Bounded env55272 := by
  intro p hp
  have h : env55272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55271_55272 : H12AffineEnvironment.transform 12 348 env55271 = env55272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55271 == env55272) = true)

theorem identity55272 : scanCanonicalize (H12AffineFastState.compose env55272 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound55272 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55273 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,342,5393,2420,1025,0,4160,33,17,3,349,65,2048,5393,4096,2420,1364,32,257,33,5456,513]

theorem envBound55273 : H12AffineFastState.Bounded env55273 := by
  intro p hp
  have h : env55273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55272_55273 : H12AffineEnvironment.transform 13 5377 env55272 = env55273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55272 == env55273) = true)

theorem identity55273 : scanCanonicalize (H12AffineFastState.compose env55273 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55273 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55274 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,263,5393,2341,1025,0,4113,33,17,3,268,16,2048,5393,4096,2341,1285,32,257,33,5377,513]

theorem envBound55274 : H12AffineFastState.Bounded env55274 := by
  intro p hp
  have h : env55274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55273_55274 : H12AffineEnvironment.transform 5 17 env55273 = env55274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55273 == env55274) = true)

theorem identity55274 : scanCanonicalize (H12AffineFastState.compose env55274 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55274 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55275 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,1,35,5173,2049,1025,0,4113,33,17,3,40,16,2048,5173,4096,2049,1057,32,37,33,5157,513]

theorem envBound55275 : H12AffineFastState.Bounded env55275 := by
  intro p hp
  have h : env55275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55274_55275 : H12AffineEnvironment.transform 7 36 env55274 = env55275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55274 == env55275) = true)

def env55276 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1045,1,35,1029,2049,1025,0,33,33,17,3,40,16,2048,1029,48,2049,1057,32,37,33,1045,513]

theorem envBound55276 : H12AffineFastState.Bounded env55276 := by
  intro p hp
  have h : env55276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55275_55276 : H12AffineEnvironment.transform 11 48 env55275 = env55276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env55275 == env55276) = true)

theorem identity55276 : scanCanonicalize (H12AffineFastState.compose env55276 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55276 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55277 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,16,9,1045,1,3,1029,2049,1025,0,1,1,17,3,8,16,2048,1029,16,2049,1025,0,5,1,1045,513]

theorem envBound55277 : H12AffineFastState.Bounded env55277 := by
  intro p hp
  have h : env55277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55276_55277 : H12AffineEnvironment.transform 4 0 env55276 = env55277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55276 == env55277) = true)

def env55278 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,16,9,1,1,3,17,2049,21,0,1,1,17,3,8,16,2048,17,16,2049,21,0,5,1,1,513]

theorem envBound55278 : H12AffineFastState.Bounded env55278 := by
  intro p hp
  have h : env55278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55277_55278 : H12AffineEnvironment.transform 9 20 env55277 = env55278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env55277 == env55278) = true)

theorem identity55278 : scanCanonicalize (H12AffineFastState.compose env55278 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound55278 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55279 : List Nat := [2,4,8,16,0,17,9,4,512,20,523,16,9,1,1,3,17,522,21,0,1,1,17,3,8,16,523,17,16,522,21,0,5,1,1,513]

theorem envBound55279 : H12AffineFastState.Bounded env55279 := by
  intro p hp
  have h : env55279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55278_55279 : H12AffineEnvironment.transform 10 523 env55278 = env55279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env55278 == env55279) = true)

def leafEnv55279 : List Nat := [2,4,8,16,0,17,9,4,512,20,523,16,9,1,1,3,17,522,21,0,1,1,17,3,20,8,1,16,523,17,16,522,21,0,5,1,5,2,1,513,1,1,0]

def active55279 : List Nat := [0,1,2,3,8]

def tree55279 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55279 : H12WitnessSearch.Good tree55279 := H12GlobalWitnessIndex.good

theorem leafIdentity55279 : H12AffineFastState.composeSystem env55279 rootObs = leafEnv55279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55279 rootObs == leafEnv55279) = true)

theorem terminalChecked55279 : H12PackedTerminal.terminalCheckFast leafEnv55279 active55279 tree55279 = true := by decide +kernel

def env55280 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,16,9,0,1,3,16,2049,20,0,1,1,17,3,8,16,2048,16,16,2049,20,0,5,1,0,513]

theorem envBound55280 : H12AffineFastState.Bounded env55280 := by
  intro p hp
  have h : env55280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55277_55280 : H12AffineEnvironment.transform 9 21 env55277 = env55280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env55277 == env55280) = true)

theorem identity55280 : scanCanonicalize (H12AffineFastState.compose env55280 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound55280 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55281 : List Nat := [2,4,8,16,0,17,9,4,512,21,0,16,9,0,1,3,16,1,20,0,1,1,17,3,8,16,0,16,16,1,20,0,5,1,0,513]

theorem envBound55281 : H12AffineFastState.Bounded env55281 := by
  intro p hp
  have h : env55281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55280_55281 : H12AffineEnvironment.transform 10 0 env55280 = env55281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env55280 == env55281) = true)

def leafEnv55281 : List Nat := [2,4,8,16,0,17,9,4,512,21,0,16,9,0,1,3,16,1,20,0,1,1,17,3,21,8,1,16,0,16,16,1,20,0,5,1,5,2,0,513,1,1,0]

def active55281 : List Nat := [0,1,2,3,8]

def tree55281 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55281 : H12WitnessSearch.Good tree55281 := H12GlobalWitnessIndex.good

theorem leafIdentity55281 : H12AffineFastState.composeSystem env55281 rootObs = leafEnv55281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55281 rootObs == leafEnv55281) = true)

theorem terminalChecked55281 : H12PackedTerminal.terminalCheckFast leafEnv55281 active55281 tree55281 = true := by decide +kernel

def env55282 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1044,1,35,1028,2049,1025,0,32,33,17,3,40,16,2048,1028,49,2049,1057,32,37,33,1044,513]

theorem envBound55282 : H12AffineFastState.Bounded env55282 := by
  intro p hp
  have h : env55282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55275_55282 : H12AffineEnvironment.transform 11 49 env55275 = env55282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env55275 == env55282) = true)

theorem identity55282 : scanCanonicalize (H12AffineFastState.compose env55282 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound55282 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55283 : List Nat := [2,4,8,16,32,17,9,36,512,21,2048,49,41,1,1,35,17,2049,20,0,32,33,17,3,40,16,2048,17,49,2049,52,32,37,33,1,513]

theorem envBound55283 : H12AffineFastState.Bounded env55283 := by
  intro p hp
  have h : env55283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55282_55283 : H12AffineEnvironment.transform 9 21 env55282 = env55283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env55282 == env55283) = true)

def env55284 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,17,9,1,1,3,17,2049,20,0,0,1,17,3,8,16,2048,17,17,2049,20,0,5,1,1,513]

theorem envBound55284 : H12AffineFastState.Bounded env55284 := by
  intro p hp
  have h : env55284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55283_55284 : H12AffineEnvironment.transform 4 0 env55283 = env55284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55283 == env55284) = true)

theorem identity55284 : scanCanonicalize (H12AffineFastState.compose env55284 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound55284 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55285 : List Nat := [2,4,8,16,0,17,9,4,512,21,1,17,9,1,1,3,17,0,20,0,0,1,17,3,8,16,1,17,17,0,20,0,5,1,1,513]

theorem envBound55285 : H12AffineFastState.Bounded env55285 := by
  intro p hp
  have h : env55285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55284_55285 : H12AffineEnvironment.transform 10 1 env55284 = env55285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env55284 == env55285) = true)

def leafEnv55285 : List Nat := [2,4,8,16,0,17,9,4,512,21,1,17,9,1,1,3,17,0,20,0,0,1,17,3,21,8,1,16,1,17,17,0,20,0,5,1,5,2,1,513,1,0,0]

def active55285 : List Nat := [0,1,2,3,8]

def tree55285 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55285 : H12WitnessSearch.Good tree55285 := H12GlobalWitnessIndex.good

theorem leafIdentity55285 : H12AffineFastState.composeSystem env55285 rootObs = leafEnv55285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55285 rootObs == leafEnv55285) = true)

theorem terminalChecked55285 : H12PackedTerminal.terminalCheckFast leafEnv55285 active55285 tree55285 = true := by decide +kernel

def env55286 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,8,1,1,2,17,2049,20,0,1,0,17,3,9,16,2048,17,16,2049,21,1,4,0,1,513]

theorem envBound55286 : H12AffineFastState.Bounded env55286 := by
  intro p hp
  have h : env55286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55283_55286 : H12AffineEnvironment.transform 4 1 env55283 = env55286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55283 == env55286) = true)

theorem identity55286 : scanCanonicalize (H12AffineFastState.compose env55286 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound55286 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55287 : List Nat := [2,4,8,16,1,17,9,5,512,21,522,16,8,1,1,2,17,523,20,0,1,0,17,3,9,16,522,17,16,523,21,1,4,0,1,513]

theorem envBound55287 : H12AffineFastState.Bounded env55287 := by
  intro p hp
  have h : env55287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55286_55287 : H12AffineEnvironment.transform 10 522 env55286 = env55287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env55286 == env55287) = true)

def leafEnv55287 : List Nat := [2,4,8,16,1,17,9,5,512,21,522,16,8,1,1,2,17,523,20,0,1,0,17,3,20,9,1,16,522,17,16,523,21,1,4,0,5,3,1,513,1,1,0]

def active55287 : List Nat := [0,1,2,3,8]

def tree55287 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55287 : H12WitnessSearch.Good tree55287 := H12GlobalWitnessIndex.good

theorem leafIdentity55287 : H12AffineFastState.composeSystem env55287 rootObs = leafEnv55287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55287 rootObs == leafEnv55287) = true)

theorem terminalChecked55287 : H12PackedTerminal.terminalCheckFast leafEnv55287 active55287 tree55287 = true := by decide +kernel

def env55288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388158,329731,17,16777216,8193,65,16812035,17066043,375167,294912,16876544,16875892,257,17049610,17090855,16819039]

theorem envBound55288 : H12AffineFastState.Bounded env55288 := by
  intro p hp
  have h : env55288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55266_55288 : H12AffineEnvironment.transform 16 16401 env55266 = env55288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env55266 == env55288) = true)

def env55289 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388158,329731,17,16777216,8193,65,16812035,17066043,374795,294912,16876544,16875520,117,17049610,17090643,16818731]

theorem envBound55289 : H12AffineFastState.Bounded env55289 := by
  intro p hp
  have h : env55289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55288_55289 : H12AffineEnvironment.transform 7 116 env55288 = env55289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env55288 == env55289) = true)

theorem identity55289 : scanCanonicalize (H12AffineFastState.compose env55289 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound55289 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55290 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388158,329731,17,41002,8193,65,10281,313361,374795,294912,74794,73770,117,296992,288889,513]

theorem envBound55290 : H12AffineFastState.Bounded env55290 := by
  intro p hp
  have h : env55290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55289_55290 : H12AffineEnvironment.transform 23 41002 env55289 = env55290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env55289 == env55290) = true)

theorem identity55290 : scanCanonicalize (H12AffineFastState.compose env55290 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound55290 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env55291 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,115734,73771,17,41002,8193,65,10281,57401,102435,43048,74794,73770,117,40968,16465,513]

theorem envBound55291 : H12AffineFastState.Bounded env55291 := by
  intro p hp
  have h : env55291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55290_55291 : H12AffineEnvironment.transform 17 10280 env55290 = env55291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env55290 == env55291) = true)

theorem identity55291 : scanCanonicalize (H12AffineFastState.compose env55291 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound55291 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env55292 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,0,65536,16401,10280,1025,1,82966,73771,17,8234,8193,65,10281,24633,69667,10280,74794,73770,117,8200,16465,513]

theorem envBound55292 : H12AffineFastState.Bounded env55292 := by
  intro p hp
  have h : env55292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55291_55292 : H12AffineEnvironment.transform 14 0 env55291 = env55292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env55291 == env55292) = true)

def env55293 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388158,329731,17,16777216,8193,65,16812035,17066043,374794,294912,16876544,16875521,116,17049610,17090642,16818730]

theorem envBound55293 : H12AffineFastState.Bounded env55293 := by
  intro p hp
  have h : env55293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55288_55293 : H12AffineEnvironment.transform 7 117 env55288 = env55293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env55288 == env55293) = true)

def env55294 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388126,329731,17,16777216,8193,65,16812035,17066011,374794,294912,16876544,16875521,84,17049610,17090642,16818698]

theorem envBound55294 : H12AffineFastState.Bounded env55294 := by
  intro p hp
  have h : env55294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55293_55294 : H12AffineEnvironment.transform 4 0 env55293 = env55294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55293 == env55294) = true)

theorem identity55294 : scanCanonicalize (H12AffineFastState.compose env55294 (packedSelected [0,1,3,4,5,7,8,9,10,14,19,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound55294 : packedSelected [0,1,3,4,5,7,8,9,10,14,19,23,32] rootPS < 2^1333 := by decide +kernel

def env55295 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8192,16384,32768,40971,16401,262144,1025,32769,281621,305160,17,16777216,8193,65,16812035,17066011,268289,294912,16786443,16785418,84,17049610,17090642,16818698]

theorem envBound55295 : H12AffineFastState.Bounded env55295 := by
  intro p hp
  have h : env55295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55294_55295 : H12AffineEnvironment.transform 15 40971 env55294 = env55295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env55294 == env55295) = true)

def env55296 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388127,329731,17,16777216,8193,65,16812035,17066010,374794,294912,16876544,16875521,85,17049610,17090642,16818699]

theorem envBound55296 : H12AffineFastState.Bounded env55296 := by
  intro p hp
  have h : env55296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55293_55296 : H12AffineEnvironment.transform 4 1 env55293 = env55296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55293 == env55296) = true)

theorem identity55296 : scanCanonicalize (H12AffineFastState.compose env55296 (packedSelected [0,1,3,4,5,7,8,9,10,14,19,23,32] rootPS)) = affineNative (2^(23+1) ^^^ 65537) := by decide +kernel

theorem selectedBound55296 : packedSelected [0,1,3,4,5,7,8,9,10,14,19,23,32] rootPS < 2^1333 := by decide +kernel

def env55297 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388127,329731,17,65537,8193,65,100354,354331,374794,294912,33793,32768,85,337931,378963,107018]

theorem envBound55297 : H12AffineFastState.Bounded env55297 := by
  intro p hp
  have h : env55297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55296_55297 : H12AffineEnvironment.transform 23 65537 env55296 = env55297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65537 env55296 == env55297) = true)

theorem identity55297 : scanCanonicalize (H12AffineFastState.compose env55297 (packedSelected [0,3,4,7,10,17,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10248) := by decide +kernel

theorem selectedBound55297 : packedSelected [0,3,4,7,10,17,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55298 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,8192,16384,32768,65536,16401,10248,1025,32769,115735,73739,17,65537,8193,65,100354,81939,102402,43016,33793,32768,85,65539,122971,107018]

theorem envBound55298 : H12AffineFastState.Bounded env55298 := by
  intro p hp
  have h : env55298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55297_55298 : H12AffineEnvironment.transform 17 10248 env55297 = env55298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10248 env55297 == env55298) = true)

theorem identity55298 : scanCanonicalize (H12AffineFastState.compose env55298 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound55298 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env55299 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,8192,16384,0,65536,16401,10248,1025,1,82967,73739,17,65537,8193,65,67586,81939,69634,10248,1025,0,85,65539,90203,74250]

theorem envBound55299 : H12AffineFastState.Bounded env55299 := by
  intro p hp
  have h : env55299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55298_55299 : H12AffineEnvironment.transform 14 0 env55298 = env55299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env55298 == env55299) = true)

theorem identity55299 : scanCanonicalize (H12AffineFastState.compose env55299 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 12312) := by decide +kernel

theorem selectedBound55299 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env55300 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,8192,12312,0,65536,12297,10248,1025,1,78863,73739,17,65537,8193,65,67586,77835,69634,10248,1025,0,85,65539,69699,74250]

theorem envBound55300 : H12AffineFastState.Bounded env55300 := by
  intro p hp
  have h : env55300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55299_55300 : H12AffineEnvironment.transform 13 12312 env55299 = env55300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12312 env55299 == env55300) = true)

theorem identity55300 : scanCanonicalize (H12AffineFastState.compose env55300 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound55300 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env55301 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,8192,12312,0,2,12297,10248,1025,1,13325,8201,17,3,8193,65,2048,12297,4096,10248,1025,0,85,1,4161,8712]

theorem envBound55301 : H12AffineFastState.Bounded env55301 := by
  intro p hp
  have h : env55301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55300_55301 : H12AffineEnvironment.transform 15 2 env55300 = env55301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env55300 == env55301) = true)

theorem identity55301 : scanCanonicalize (H12AffineFastState.compose env55301 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound55301 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55302 : List Nat := [2,4,8,16,1,64,9,84,512,68,2048,4096,8192,12312,0,2,12297,10248,69,1,12361,8201,17,3,8193,65,2048,12297,4096,10248,69,0,85,1,4161,8712]

theorem envBound55302 : H12AffineFastState.Bounded env55302 := by
  intro p hp
  have h : env55302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55301_55302 : H12AffineEnvironment.transform 9 68 env55301 = env55302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env55301 == env55302) = true)

theorem identity55302 : scanCanonicalize (H12AffineFastState.compose env55302 (packedSelected [1,3,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound55302 : packedSelected [1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env55303 : List Nat := [2,4,8,16,1,64,9,84,80,68,2048,4096,8192,12312,0,2,12297,10248,69,1,12361,8201,17,3,8193,65,2048,12297,4096,10248,69,0,85,1,4161,8280]

theorem envBound55303 : H12AffineFastState.Bounded env55303 := by
  intro p hp
  have h : env55303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55302_55303 : H12AffineEnvironment.transform 8 80 env55302 = env55303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env55302 == env55303) = true)

theorem identity55303 : scanCanonicalize (H12AffineFastState.compose env55303 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55303 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55304 : List Nat := [2,4,8,16,1,16,9,4,0,20,2048,4096,8192,12312,0,2,12297,10248,21,1,12313,8201,17,3,8193,17,2048,12297,4096,10248,21,0,5,1,4113,8200]

theorem envBound55304 : H12AffineFastState.Bounded env55304 := by
  intro p hp
  have h : env55304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55303_55304 : H12AffineEnvironment.transform 5 16 env55303 = env55304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55303 == env55304) = true)

theorem identity55304 : scanCanonicalize (H12AffineFastState.compose env55304 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound55304 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env55305 : List Nat := [2,4,8,16,1,16,9,4,0,20,2048,4096,8,4112,0,2,4097,2048,21,1,4113,1,17,3,9,17,2048,4097,4096,2048,21,0,5,1,4113,0]

theorem envBound55305 : H12AffineFastState.Bounded env55305 := by
  intro p hp
  have h : env55305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55304_55305 : H12AffineEnvironment.transform 12 8 env55304 = env55305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env55304 == env55305) = true)

theorem identity55305 : scanCanonicalize (H12AffineFastState.compose env55305 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound55305 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55306 : List Nat := [2,4,8,16,1,16,9,4,0,20,2048,2065,8,2049,0,2,2064,2048,21,1,2048,1,17,3,9,17,2048,2064,2065,2048,21,0,5,1,2048,0]

theorem envBound55306 : H12AffineFastState.Bounded env55306 := by
  intro p hp
  have h : env55306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55305_55306 : H12AffineEnvironment.transform 11 2065 env55305 = env55306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env55305 == env55306) = true)

theorem identity55306 : scanCanonicalize (H12AffineFastState.compose env55306 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound55306 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55307 : List Nat := [2,4,8,16,1,16,9,4,0,20,30,15,8,31,0,2,14,30,21,1,30,1,17,3,9,17,30,14,15,30,21,0,5,1,30,0]

theorem envBound55307 : H12AffineFastState.Bounded env55307 := by
  intro p hp
  have h : env55307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55306_55307 : H12AffineEnvironment.transform 10 30 env55306 = env55307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env55306 == env55307) = true)

def leafEnv55307 : List Nat := [2,4,8,16,1,16,9,4,0,20,30,15,8,31,0,2,14,30,21,1,30,1,17,3,20,9,1,17,30,14,15,30,21,0,5,1,5,3,30,0,1,31,0]

def active55307 : List Nat := [0,1,2,3]

def tree55307 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55307 : H12WitnessSearch.Good tree55307 := H12GlobalWitnessIndex.good

theorem leafIdentity55307 : H12AffineFastState.composeSystem env55307 rootObs = leafEnv55307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55307 rootObs == leafEnv55307) = true)

theorem terminalChecked55307 : H12PackedTerminal.terminalCheckFast leafEnv55307 active55307 tree55307 = true := by decide +kernel

def env55308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254785,92374096,145662401,525568,140903596,27337992,25733062]

theorem envBound55308 : H12AffineFastState.Bounded env55308 := by
  intro p hp
  have h : env55308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53840_55308 : H12AffineEnvironment.transform 29 155254785 env53840 = env55308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env53840 == env55308) = true)

def env55309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254785,25265168,145662401,525568,140903596,27337992,25733062]

theorem envBound55309 : H12AffineFastState.Bounded env55309 := by
  intro p hp
  have h : env55309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55308_55309 : H12AffineEnvironment.transform 25 64 env55308 = env55309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env55308 == env55309) = true)

def env55310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356289,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound55310 : H12AffineFastState.Bounded env55310 := by
  intro p hp
  have h : env55310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55309_55310 : H12AffineEnvironment.transform 26 30393344 env55309 = env55310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env55309 == env55310) = true)

def env55311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound55311 : H12AffineFastState.Bounded env55311 := by
  intro p hp
  have h : env55311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55310_55311 : H12AffineEnvironment.transform 18 1024 env55310 = env55311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env55310 == env55311) = true)

theorem identity55311 : scanCanonicalize (H12AffineFastState.compose env55311 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 41431) := by decide +kernel

theorem selectedBound55311 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env55312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41431,8328,64,13066711,2172250,10507601,8830977,8463815,6407190,256,10577275,10585311,8389137]

theorem envBound55312 : H12AffineFastState.Bounded env55312 := by
  intro p hp
  have h : env55312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55311_55312 : H12AffineEnvironment.transform 23 41431 env55311 = env55312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41431 env55311 == env55312) = true)

def env55313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58516,4194304,8388608,41431,8328,64,13066711,115150,8434117,8830977,8463815,4268162,256,8487407,8478795,8389137]

theorem envBound55313 : H12AffineFastState.Bounded env55313 := by
  intro p hp
  have h : env55313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55312_55313 : H12AffineEnvironment.transform 20 58516 env55312 = env55313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env55312 == env55313) = true)

def env55314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58516,4194304,16,41431,8328,64,4678087,115150,45525,442385,75223,4268162,256,98815,90203,513]

theorem envBound55314 : H12AffineFastState.Bounded env55314 := by
  intro p hp
  have h : env55314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55313_55314 : H12AffineEnvironment.transform 22 16 env55313 = env55314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env55313 == env55314) = true)

theorem identity55314 : scanCanonicalize (H12AffineFastState.compose env55314 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound55314 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58516,4194304,16,41431,8328,64,4604365,57796,45525,442385,1501,4194440,256,41461,16465,513]

theorem envBound55315 : H12AffineFastState.Bounded env55315 := by
  intro p hp
  have h : env55315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55314_55315 : H12AffineEnvironment.transform 15 8202 env55314 = env55315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env55314 == env55315) = true)

theorem identity55315 : scanCanonicalize (H12AffineFastState.compose env55315 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419912) := by decide +kernel

theorem selectedBound55315 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env55316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58516,419912,16,41431,8328,64,10629,57796,45525,442385,1501,420032,256,41461,16465,513]

theorem envBound55316 : H12AffineFastState.Bounded env55316 := by
  intro p hp
  have h : env55316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55315_55316 : H12AffineEnvironment.transform 21 419912 env55315 = env55316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419912 env55315 == env55316) = true)

def env55317 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58396,419912,16,41311,8192,64,10509,57676,45405,442385,1365,419912,256,41341,16465,513]

theorem envBound55317 : H12AffineFastState.Bounded env55317 := by
  intro p hp
  have h : env55317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55316_55317 : H12AffineEnvironment.transform 6 8 env55316 = env55317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55316 == env55317) = true)

theorem identity55317 : scanCanonicalize (H12AffineFastState.compose env55317 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound55317 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55318 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,262144,1024,8540,17729,419912,16,2,8192,64,10509,16401,4096,418124,1365,419912,256,32,16465,513]

theorem envBound55318 : H12AffineFastState.Bounded env55318 := by
  intro p hp
  have h : env55318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55317_55318 : H12AffineEnvironment.transform 14 8541 env55317 = env55318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env55317 == env55318) = true)

theorem identity55318 : scanCanonicalize (H12AffineFastState.compose env55318 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound55318 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55319 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,157753,1024,8540,17729,113,16,2,8192,64,10509,16401,4096,2421,1365,113,256,32,16465,513]

theorem envBound55319 : H12AffineFastState.Bounded env55319 := by
  intro p hp
  have h : env55319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55318_55319 : H12AffineEnvironment.transform 17 157753 env55318 = env55319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env55318 == env55319) = true)

theorem identity55319 : scanCanonicalize (H12AffineFastState.compose env55319 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound55319 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env55320 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,8202,131072,145448,1024,8540,5456,113,16,2,8192,64,10509,4096,4096,2421,1365,113,256,32,4160,513]

theorem envBound55320 : H12AffineFastState.Bounded env55320 := by
  intro p hp
  have h : env55320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55319_55320 : H12AffineEnvironment.transform 13 4113 env55319 = env55320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env55319 == env55320) = true)

theorem identity55320 : scanCanonicalize (H12AffineFastState.compose env55320 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound55320 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env55321 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8541,8202,4096,10280,1024,8540,5456,113,16,2,8192,64,10509,4096,4096,2421,1365,113,256,32,4160,513]

theorem envBound55321 : H12AffineFastState.Bounded env55321 := by
  intro p hp
  have h : env55321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55320_55321 : H12AffineEnvironment.transform 16 4096 env55320 = env55321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env55320 == env55321) = true)

theorem identity55321 : scanCanonicalize (H12AffineFastState.compose env55321 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound55321 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env55322 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6429,4113,6208,6423,4096,4405,1024,6209,5456,113,16,2,6429,64,4112,4096,4096,2421,1365,113,256,32,4160,513]

theorem envBound55322 : H12AffineFastState.Bounded env55322 := by
  intro p hp
  have h : env55322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55321_55322 : H12AffineEnvironment.transform 12 6429 env55321 = env55322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env55321 == env55322) = true)

theorem identity55322 : scanCanonicalize (H12AffineFastState.compose env55322 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound55322 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env55323 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,1337,3125,1124,1331,3108,3345,1024,1125,2420,113,16,2,1337,64,3124,3108,3108,2421,1365,113,256,32,3172,513]

theorem envBound55323 : H12AffineFastState.Bounded env55323 := by
  intro p hp
  have h : env55323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55322_55323 : H12AffineEnvironment.transform 11 3108 env55322 = env55323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env55322 == env55323) = true)

theorem identity55323 : scanCanonicalize (H12AffineFastState.compose env55323 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound55323 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env55324 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2065,268,2048,81,262,2065,2340,53,80,2420,113,16,2,268,64,2049,2065,2065,2421,352,113,256,32,2129,513]

theorem envBound55324 : H12AffineFastState.Bounded env55324 := by
  intro p hp
  have h : env55324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55323_55324 : H12AffineEnvironment.transform 9 53 env55323 = env55324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55323 == env55324) = true)

theorem identity55324 : scanCanonicalize (H12AffineFastState.compose env55324 (packedSelected [0,1,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound55324 : packedSelected [0,1,3,8] rootPS < 2^1333 := by decide +kernel

def env55325 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,2065,121,2048,81,115,2065,2129,53,80,2049,113,16,2,121,64,2049,2065,2065,2048,21,113,117,32,2129,513]

theorem envBound55325 : H12AffineFastState.Bounded env55325 := by
  intro p hp
  have h : env55325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55324_55325 : H12AffineEnvironment.transform 7 117 env55324 = env55325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env55324 == env55325) = true)

theorem identity55325 : scanCanonicalize (H12AffineFastState.compose env55325 (packedSelected [0,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound55325 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env55326 : List Nat := [2,4,8,16,32,64,8,117,512,53,49,32,121,49,81,115,32,96,53,80,48,113,16,2,121,64,48,32,32,49,21,113,117,32,96,513]

theorem envBound55326 : H12AffineFastState.Bounded env55326 := by
  intro p hp
  have h : env55326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55325_55326 : H12AffineEnvironment.transform 10 49 env55325 = env55326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env55325 == env55326) = true)

theorem identity55326 : scanCanonicalize (H12AffineFastState.compose env55326 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55326 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env55327 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,32,41,49,1,35,32,48,53,0,48,33,16,2,41,16,48,32,32,49,21,33,37,32,48,513]

theorem envBound55327 : H12AffineFastState.Bounded env55327 := by
  intro p hp
  have h : env55327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55326_55327 : H12AffineEnvironment.transform 5 16 env55326 = env55327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55326 == env55327) = true)

def leafEnv55327 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,32,41,49,1,35,32,48,53,0,48,33,16,2,21,41,1,16,48,32,32,49,21,33,37,32,4,35,48,513,1,49,0]

def active55327 : List Nat := [0,1,2,3,4,8]

def tree55327 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55327 : H12WitnessSearch.Good tree55327 := H12GlobalWitnessIndex.good

theorem leafIdentity55327 : H12AffineFastState.composeSystem env55327 rootObs = leafEnv55327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55327 rootObs == leafEnv55327) = true)

theorem terminalChecked55327 : H12PackedTerminal.terminalCheckFast leafEnv55327 active55327 tree55327 = true := by decide +kernel

def env55328 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58397,419912,16,41310,8193,64,10508,57677,45404,442385,1364,419913,256,41340,16465,513]

theorem envBound55328 : H12AffineFastState.Bounded env55328 := by
  intro p hp
  have h : env55328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55316_55328 : H12AffineEnvironment.transform 6 9 env55316 = env55328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55316 == env55328) = true)

def env55329 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,262144,1024,32769,58397,272392,16,41310,8193,64,10508,57677,45404,294993,1364,272393,256,41340,16465,513]

theorem envBound55329 : H12AffineFastState.Bounded env55329 := by
  intro p hp
  have h : env55329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55328_55329 : H12AffineEnvironment.transform 16 16448 env55328 = env55329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env55328 == env55329) = true)

theorem identity55329 : scanCanonicalize (H12AffineFastState.compose env55329 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 43128) := by decide +kernel

theorem selectedBound55329 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55330 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,43128,1024,32769,58397,32880,16,41310,8193,64,10508,57677,45404,10281,1364,32881,256,41340,16465,513]

theorem envBound55330 : H12AffineFastState.Bounded env55330 := by
  intro p hp
  have h : env55330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55329_55330 : H12AffineEnvironment.transform 17 43128 env55329 = env55330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43128 env55329 == env55330) = true)

theorem identity55330 : scanCanonicalize (H12AffineFastState.compose env55330 (packedSelected [11,32] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound55330 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env55331 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,8202,16448,2420,1024,8461,17681,8572,16,82,8193,64,10508,16449,4176,10281,1364,8573,256,112,16465,513]

theorem envBound55331 : H12AffineFastState.Bounded env55331 := by
  intro p hp
  have h : env55331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55330_55331 : H12AffineEnvironment.transform 14 8460 env55330 = env55331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env55330 == env55331) = true)

def env55332 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,8202,16400,2340,1024,8461,17681,8492,16,2,8193,16,10508,16401,4096,10281,1284,8493,256,32,16385,513]

theorem envBound55332 : H12AffineFastState.Bounded env55332 := by
  intro p hp
  have h : env55332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55331_55332 : H12AffineEnvironment.transform 5 16 env55331 = env55332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55331 == env55332) = true)

theorem identity55332 : scanCanonicalize (H12AffineFastState.compose env55332 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound55332 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55333 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1,8192,16384,8460,8202,16400,2340,1024,8461,17681,8492,16,2,8193,16,10508,16401,1,10281,1284,8493,256,32,16385,513]

theorem envBound55333 : H12AffineFastState.Bounded env55333 := by
  intro p hp
  have h : env55333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55332_55333 : H12AffineEnvironment.transform 11 1 env55332 = env55333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env55332 == env55333) = true)

theorem identity55333 : scanCanonicalize (H12AffineFastState.compose env55333 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55333 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55334 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1,269,16384,1,263,16400,2340,1024,0,17681,33,16,2,268,16,2049,16401,1,2340,1284,32,256,32,16385,513]

theorem envBound55334 : H12AffineFastState.Bounded env55334 := by
  intro p hp
  have h : env55334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55333_55334 : H12AffineEnvironment.transform 12 269 env55333 = env55334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55333 == env55334) = true)

theorem identity55334 : scanCanonicalize (H12AffineFastState.compose env55334 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound55334 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55335 : List Nat := [2,4,8,16,32,16,9,256,512,1024,26,1,269,16384,1,263,16400,318,1024,0,17681,33,16,2,268,16,27,16401,1,318,1284,32,256,32,16385,513]

theorem envBound55335 : H12AffineFastState.Bounded env55335 := by
  intro p hp
  have h : env55335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55334_55335 : H12AffineEnvironment.transform 10 26 env55334 = env55335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env55334 == env55335) = true)

theorem identity55335 : scanCanonicalize (H12AffineFastState.compose env55335 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound55335 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55336 : List Nat := [2,4,8,16,32,16,9,256,512,20,26,1,269,16384,1,263,16400,318,20,0,16645,33,16,2,268,16,27,16401,1,318,272,32,256,32,16385,513]

theorem envBound55336 : H12AffineFastState.Bounded env55336 := by
  intro p hp
  have h : env55336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55335_55336 : H12AffineEnvironment.transform 9 20 env55335 = env55336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env55335 == env55336) = true)

theorem identity55336 : scanCanonicalize (H12AffineFastState.compose env55336 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55336 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55337 : List Nat := [2,4,8,0,32,0,9,256,512,4,10,1,269,16384,1,263,16384,302,4,0,16645,33,0,2,268,0,11,16385,1,302,256,32,256,32,16385,513]

theorem envBound55337 : H12AffineFastState.Bounded env55337 := by
  intro p hp
  have h : env55337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55336_55337 : H12AffineEnvironment.transform 3 0 env55336 = env55337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55336 == env55337) = true)

theorem identity55337 : scanCanonicalize (H12AffineFastState.compose env55337 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound55337 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55338 : List Nat := [2,4,8,0,32,0,9,14,512,4,10,1,3,16384,1,9,16384,32,4,0,16395,33,0,2,2,0,11,16385,1,32,14,32,14,32,16385,513]

theorem envBound55338 : H12AffineFastState.Bounded env55338 := by
  intro p hp
  have h : env55338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55337_55338 : H12AffineEnvironment.transform 7 14 env55337 = env55338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env55337 == env55338) = true)

theorem identity55338 : scanCanonicalize (H12AffineFastState.compose env55338 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55338 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env55339 : List Nat := [2,4,8,0,0,0,9,14,512,4,10,1,3,16384,1,9,16384,0,4,0,16395,1,0,2,2,0,11,16385,1,0,14,0,14,0,16385,513]

theorem envBound55339 : H12AffineFastState.Bounded env55339 := by
  intro p hp
  have h : env55339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55338_55339 : H12AffineEnvironment.transform 4 0 env55338 = env55339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55338 == env55339) = true)

theorem identity55339 : scanCanonicalize (H12AffineFastState.compose env55339 (packedSelected [0,9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55339 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env55340 : List Nat := [2,4,2,0,0,0,3,4,512,4,0,1,3,16384,1,3,16384,0,4,0,16385,1,0,2,2,0,1,16385,1,0,4,0,4,0,16385,513]

theorem envBound55340 : H12AffineFastState.Bounded env55340 := by
  intro p hp
  have h : env55340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55339_55340 : H12AffineEnvironment.transform 2 2 env55339 = env55340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55339 == env55340) = true)

theorem identity55340 : scanCanonicalize (H12AffineFastState.compose env55340 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound55340 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55341 : List Nat := [2,0,2,0,0,0,3,0,512,0,0,1,3,16384,1,3,16384,0,0,0,16385,1,0,2,2,0,1,16385,1,0,0,0,0,0,16385,513]

theorem envBound55341 : H12AffineFastState.Bounded env55341 := by
  intro p hp
  have h : env55341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55340_55341 : H12AffineEnvironment.transform 1 0 env55340 = env55341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env55340 == env55341) = true)

theorem identity55341 : scanCanonicalize (H12AffineFastState.compose env55341 (packedSelected [1] rootPS)) = affineNative (2^(13+1) ^^^ 2) := by decide +kernel

theorem selectedBound55341 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55342 : List Nat := [2,0,2,0,0,0,3,0,512,0,0,1,3,2,1,3,2,0,0,0,3,1,0,2,2,0,1,3,1,0,0,0,0,0,3,513]

theorem envBound55342 : H12AffineFastState.Bounded env55342 := by
  intro p hp
  have h : env55342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55341_55342 : H12AffineEnvironment.transform 13 2 env55341 = env55342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2 env55341 == env55342) = true)

def env55343 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,8202,16401,2341,1024,8461,17681,8493,16,3,8193,17,10508,16400,4097,10281,1285,8492,256,33,16384,513]

theorem envBound55343 : H12AffineFastState.Bounded env55343 := by
  intro p hp
  have h : env55343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55331_55343 : H12AffineEnvironment.transform 5 17 env55331 = env55343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55331 == env55343) = true)

theorem identity55343 : scanCanonicalize (H12AffineFastState.compose env55343 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound55343 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55344 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5156,8460,8202,5173,2341,1024,8461,4405,8493,16,3,8193,17,10508,5172,4097,10281,1285,8492,256,33,5156,513]

theorem envBound55344 : H12AffineFastState.Bounded env55344 := by
  intro p hp
  have h : env55344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55343_55344 : H12AffineEnvironment.transform 13 5156 env55343 = env55344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env55343 == env55344) = true)

theorem identity55344 : scanCanonicalize (H12AffineFastState.compose env55344 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55344 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env55345 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5156,0,262,5173,2341,1024,1,4405,33,16,3,269,17,2048,5172,4097,2341,1285,32,256,33,5156,513]

theorem envBound55345 : H12AffineFastState.Bounded env55345 := by
  intro p hp
  have h : env55345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55344_55345 : H12AffineEnvironment.transform 12 268 env55344 = env55345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55344 == env55345) = true)

def env55346 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3888,268,2836,0,262,2821,2341,1024,1,3589,33,16,3,269,17,2048,2820,3889,2341,1285,32,256,33,2836,513]

theorem envBound55346 : H12AffineFastState.Bounded env55346 := by
  intro p hp
  have h : env55346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55345_55346 : H12AffineEnvironment.transform 11 3888 env55345 = env55346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env55345 == env55346) = true)

def env55347 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,48,268,1044,0,262,1029,1573,1024,1,261,33,16,3,269,17,1792,1028,49,1573,1285,32,256,33,1044,513]

theorem envBound55347 : H12AffineFastState.Bounded env55347 := by
  intro p hp
  have h : env55347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55346_55347 : H12AffineEnvironment.transform 10 1792 env55346 = env55347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env55346 == env55347) = true)

def env55348 : List Nat := [2,4,8,16,32,17,9,256,512,52,820,48,268,32,0,262,49,529,52,1,261,33,16,3,269,17,820,48,49,529,305,32,256,33,32,513]

theorem envBound55348 : H12AffineFastState.Bounded env55348 := by
  intro p hp
  have h : env55348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55347_55348 : H12AffineEnvironment.transform 9 52 env55347 = env55348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55347 == env55348) = true)

theorem identity55348 : scanCanonicalize (H12AffineFastState.compose env55348 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound55348 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55349 : List Nat := [2,4,8,16,32,17,9,256,270,52,58,48,268,32,0,262,49,287,52,1,261,33,16,3,269,17,58,48,49,287,305,32,256,33,32,271]

theorem envBound55349 : H12AffineFastState.Bounded env55349 := by
  intro p hp
  have h : env55349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55348_55349 : H12AffineEnvironment.transform 8 270 env55348 = env55349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env55348 == env55349) = true)

def leafEnv55349 : List Nat := [2,4,8,16,32,17,9,256,270,52,58,48,268,32,0,262,49,287,52,1,261,33,16,3,305,269,1,17,58,48,49,287,305,32,256,33,4,263,32,271,1,261,0]

def active55349 : List Nat := [0,1,2,3,4,7]

def tree55349 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55349 : H12WitnessSearch.Good tree55349 := H12GlobalWitnessIndex.good

theorem leafIdentity55349 : H12AffineFastState.composeSystem env55349 rootObs = leafEnv55349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55349 rootObs == leafEnv55349) = true)

theorem terminalChecked55349 : H12PackedTerminal.terminalCheckFast leafEnv55349 active55349 tree55349 = true := by decide +kernel

def env55350 : List Nat := [2,4,8,16,32,17,9,256,512,53,821,48,268,33,0,262,48,528,53,1,261,33,16,3,269,17,821,49,49,528,304,32,256,33,33,513]

theorem envBound55350 : H12AffineFastState.Bounded env55350 := by
  intro p hp
  have h : env55350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55347_55350 : H12AffineEnvironment.transform 9 53 env55347 = env55350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55347 == env55350) = true)

def env55351 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,49,268,1045,0,262,1028,1572,1024,1,260,33,16,3,269,17,1793,1029,48,1572,1285,32,256,33,1045,513]

theorem envBound55351 : H12AffineFastState.Bounded env55351 := by
  intro p hp
  have h : env55351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55346_55351 : H12AffineEnvironment.transform 10 1793 env55346 = env55351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env55346 == env55351) = true)

theorem identity55351 : scanCanonicalize (H12AffineFastState.compose env55351 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound55351 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55352 : List Nat := [2,4,8,16,32,17,9,256,512,272,529,49,268,261,0,262,276,820,272,1,260,33,16,3,269,17,529,277,48,820,21,32,256,33,261,513]

theorem envBound55352 : H12AffineFastState.Bounded env55352 := by
  intro p hp
  have h : env55352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55351_55352 : H12AffineEnvironment.transform 9 272 env55351 = env55352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55351 == env55352) = true)

def env55353 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,49,40,33,0,34,48,528,52,1,32,33,16,3,41,17,529,49,48,528,21,32,36,33,33,513]

theorem envBound55353 : H12AffineFastState.Bounded env55353 := by
  intro p hp
  have h : env55353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55352_55353 : H12AffineEnvironment.transform 7 36 env55352 = env55353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55352 == env55353) = true)

theorem identity55353 : scanCanonicalize (H12AffineFastState.compose env55353 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound55353 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55354 : List Nat := [2,4,8,16,32,17,9,36,43,52,58,49,40,33,0,34,48,59,52,1,32,33,16,3,41,17,58,49,48,59,21,32,36,33,33,42]

theorem envBound55354 : H12AffineFastState.Bounded env55354 := by
  intro p hp
  have h : env55354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55353_55354 : H12AffineEnvironment.transform 8 43 env55353 = env55354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env55353 == env55354) = true)

def leafEnv55354 : List Nat := [2,4,8,16,32,17,9,36,43,52,58,49,40,33,0,34,48,59,52,1,32,33,16,3,21,41,1,17,58,49,48,59,21,32,36,33,4,35,33,42,1,32,0]

def active55354 : List Nat := [0,1,2,3,4]

def tree55354 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55354 : H12WitnessSearch.Good tree55354 := H12GlobalWitnessIndex.good

theorem leafIdentity55354 : H12AffineFastState.composeSystem env55354 rootObs = leafEnv55354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55354 rootObs == leafEnv55354) = true)

theorem terminalChecked55354 : H12PackedTerminal.terminalCheckFast leafEnv55354 active55354 tree55354 = true := by decide +kernel

def env55355 : List Nat := [2,4,8,16,32,17,9,37,512,53,529,49,41,32,0,35,49,529,53,1,33,33,16,3,40,17,529,48,48,529,21,32,37,33,32,513]

theorem envBound55355 : H12AffineFastState.Bounded env55355 := by
  intro p hp
  have h : env55355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55352_55355 : H12AffineEnvironment.transform 7 37 env55352 = env55355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55352 == env55355) = true)

def env55356 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3889,268,2837,0,262,2820,2341,1024,1,3588,33,16,3,269,17,2048,2821,3888,2341,1285,32,256,33,2837,513]

theorem envBound55356 : H12AffineFastState.Bounded env55356 := by
  intro p hp
  have h : env55356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55345_55356 : H12AffineEnvironment.transform 11 3889 env55345 = env55356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env55345 == env55356) = true)

def env55357 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,49,268,1045,0,262,1028,1573,1024,1,260,33,16,3,269,17,1792,1029,48,1573,1285,32,256,33,1045,513]

theorem envBound55357 : H12AffineFastState.Bounded env55357 := by
  intro p hp
  have h : env55357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55356_55357 : H12AffineEnvironment.transform 10 1792 env55356 = env55357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env55356 == env55357) = true)

theorem identity55357 : scanCanonicalize (H12AffineFastState.compose env55357 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55358 : List Nat := [2,4,8,16,32,17,9,256,512,52,820,49,268,33,0,262,48,529,52,1,260,33,16,3,269,17,820,49,48,529,305,32,256,33,33,513]

theorem envBound55358 : H12AffineFastState.Bounded env55358 := by
  intro p hp
  have h : env55358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55357_55358 : H12AffineEnvironment.transform 9 52 env55357 = env55358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55357 == env55358) = true)

theorem identity55358 : scanCanonicalize (H12AffineFastState.compose env55358 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound55358 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55359 : List Nat := [2,4,8,16,32,17,9,256,271,52,59,49,268,33,0,262,48,286,52,1,260,33,16,3,269,17,59,49,48,286,305,32,256,33,33,270]

theorem envBound55359 : H12AffineFastState.Bounded env55359 := by
  intro p hp
  have h : env55359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55358_55359 : H12AffineEnvironment.transform 8 271 env55358 = env55359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env55358 == env55359) = true)

def leafEnv55359 : List Nat := [2,4,8,16,32,17,9,256,271,52,59,49,268,33,0,262,48,286,52,1,260,33,16,3,305,269,1,17,59,49,48,286,305,32,256,33,4,263,33,270,1,260,0]

def active55359 : List Nat := [0,1,2,3,4,7]

def tree55359 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55359 : H12WitnessSearch.Good tree55359 := H12GlobalWitnessIndex.good

theorem leafIdentity55359 : H12AffineFastState.composeSystem env55359 rootObs = leafEnv55359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55359 rootObs == leafEnv55359) = true)

theorem terminalChecked55359 : H12PackedTerminal.terminalCheckFast leafEnv55359 active55359 tree55359 = true := by decide +kernel

def env55360 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,48,268,1044,0,262,1029,1572,1024,1,261,33,16,3,269,17,1793,1028,49,1572,1285,32,256,33,1044,513]

theorem envBound55360 : H12AffineFastState.Bounded env55360 := by
  intro p hp
  have h : env55360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55356_55360 : H12AffineEnvironment.transform 10 1793 env55356 = env55360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env55356 == env55360) = true)

theorem identity55360 : scanCanonicalize (H12AffineFastState.compose env55360 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55360 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55361 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1573,48,40,1044,0,34,1029,1572,1024,1,33,33,16,3,41,17,1573,1028,49,1572,1057,32,36,33,1044,513]

theorem envBound55361 : H12AffineFastState.Bounded env55361 := by
  intro p hp
  have h : env55361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55360_55361 : H12AffineEnvironment.transform 7 36 env55360 = env55361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55360 == env55361) = true)

def env55362 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,48,40,32,0,34,49,528,52,1,33,33,16,3,41,17,529,48,49,528,21,32,36,33,32,513]

theorem envBound55362 : H12AffineFastState.Bounded env55362 := by
  intro p hp
  have h : env55362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55361_55362 : H12AffineEnvironment.transform 9 52 env55361 = env55362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55361 == env55362) = true)

theorem identity55362 : scanCanonicalize (H12AffineFastState.compose env55362 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound55362 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55363 : List Nat := [2,4,8,16,32,17,9,36,42,52,59,48,40,32,0,34,49,58,52,1,33,33,16,3,41,17,59,48,49,58,21,32,36,33,32,43]

theorem envBound55363 : H12AffineFastState.Bounded env55363 := by
  intro p hp
  have h : env55363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55362_55363 : H12AffineEnvironment.transform 8 42 env55362 = env55363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env55362 == env55363) = true)

def leafEnv55363 : List Nat := [2,4,8,16,32,17,9,36,42,52,59,48,40,32,0,34,49,58,52,1,33,33,16,3,21,41,1,17,59,48,49,58,21,32,36,33,4,35,32,43,1,33,0]

def active55363 : List Nat := [0,1,2,3,4]

def tree55363 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55363 : H12WitnessSearch.Good tree55363 := H12GlobalWitnessIndex.good

theorem leafIdentity55363 : H12AffineFastState.composeSystem env55363 rootObs = leafEnv55363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55363 rootObs == leafEnv55363) = true)

theorem terminalChecked55363 : H12PackedTerminal.terminalCheckFast leafEnv55363 active55363 tree55363 = true := by decide +kernel

def env55364 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,48,40,33,0,34,48,529,53,1,33,33,16,3,41,17,528,49,49,529,20,32,36,33,33,513]

theorem envBound55364 : H12AffineFastState.Bounded env55364 := by
  intro p hp
  have h : env55364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55361_55364 : H12AffineEnvironment.transform 9 53 env55361 = env55364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55361 == env55364) = true)

def env55365 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,262144,1024,32769,58397,272393,16,41310,8193,64,10508,57677,45404,294992,1364,272392,256,41340,16465,513]

theorem envBound55365 : H12AffineFastState.Bounded env55365 := by
  intro p hp
  have h : env55365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55328_55365 : H12AffineEnvironment.transform 16 16449 env55328 = env55365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env55328 == env55365) = true)

theorem identity55365 : scanCanonicalize (H12AffineFastState.compose env55365 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound55365 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55366 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,35189,1024,32769,58397,41340,16,41310,8193,64,10508,57677,45404,2341,1364,41341,256,41340,16465,513]

theorem envBound55366 : H12AffineFastState.Bounded env55366 := by
  intro p hp
  have h : env55366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55365_55366 : H12AffineEnvironment.transform 17 35189 env55365 = env55366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env55365 == env55366) = true)

theorem identity55366 : scanCanonicalize (H12AffineFastState.compose env55366 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55366 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env55367 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,343,16449,35189,1024,32769,50496,32801,16,32771,348,64,2129,49168,36865,2341,1364,32800,256,32801,16465,513]

theorem envBound55367 : H12AffineFastState.Bounded env55367 := by
  intro p hp
  have h : env55367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55366_55367 : H12AffineEnvironment.transform 12 349 env55366 = env55367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55366 == env55367) = true)

theorem identity55367 : scanCanonicalize (H12AffineFastState.compose env55367 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound55367 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,343,16449,2420,1024,0,17729,32,16,2,348,64,2129,16401,4096,2341,1364,33,256,32,16465,513]

theorem envBound55368 : H12AffineFastState.Bounded env55368 := by
  intro p hp
  have h : env55368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55367_55368 : H12AffineEnvironment.transform 14 1 env55367 = env55368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env55367 == env55368) = true)

theorem identity55368 : scanCanonicalize (H12AffineFastState.compose env55368 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound55368 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env55369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4113,1,343,4176,2420,1024,0,5456,32,16,2,348,64,2129,4096,4096,2341,1364,33,256,32,4160,513]

theorem envBound55369 : H12AffineFastState.Bounded env55369 := by
  intro p hp
  have h : env55369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55368_55369 : H12AffineEnvironment.transform 13 4113 env55368 = env55369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env55368 == env55369) = true)

theorem identity55369 : scanCanonicalize (H12AffineFastState.compose env55369 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55369 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55370 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,4113,1,263,4096,2340,1024,0,5376,32,16,2,268,16,2049,4096,4096,2341,1284,33,256,32,4112,513]

theorem envBound55370 : H12AffineFastState.Bounded env55370 := by
  intro p hp
  have h : env55370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55369_55370 : H12AffineEnvironment.transform 5 16 env55369 = env55370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55369 == env55370) = true)

theorem identity55370 : scanCanonicalize (H12AffineFastState.compose env55370 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound55370 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55371 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8,4113,1,2,4096,2081,1024,0,5125,32,16,2,9,16,2049,4096,4096,2080,1025,33,5,32,4112,513]

theorem envBound55371 : H12AffineFastState.Bounded env55371 := by
  intro p hp
  have h : env55371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55370_55371 : H12AffineEnvironment.transform 7 5 env55370 = env55371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env55370 == env55371) = true)

theorem identity55371 : scanCanonicalize (H12AffineFastState.compose env55371 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3621) := by decide +kernel

theorem selectedBound55371 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55372 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,3621,8,3636,1,2,3621,2081,1024,0,2592,32,16,2,9,16,2049,3621,3621,2080,1025,33,5,32,3637,513]

theorem envBound55372 : H12AffineFastState.Bounded env55372 := by
  intro p hp
  have h : env55372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55371_55372 : H12AffineEnvironment.transform 11 3621 env55371 = env55372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3621 env55371 == env55372) = true)

theorem identity55372 : scanCanonicalize (H12AffineFastState.compose env55372 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound55372 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55373 : List Nat := [2,4,8,16,32,16,9,5,512,1024,17,1588,8,1573,1,2,1588,48,1024,0,561,32,16,2,9,16,16,1588,1588,49,1025,33,5,32,1572,513]

theorem envBound55373 : H12AffineFastState.Bounded env55373 := by
  intro p hp
  have h : env55373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55372_55373 : H12AffineEnvironment.transform 10 17 env55372 = env55373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env55372 == env55373) = true)

theorem identity55373 : scanCanonicalize (H12AffineFastState.compose env55373 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55373 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env55374 : List Nat := [2,4,8,16,32,16,9,5,512,52,17,512,8,529,1,2,512,48,52,0,561,32,16,2,9,16,16,512,512,49,53,33,5,32,528,513]

theorem envBound55374 : H12AffineFastState.Bounded env55374 := by
  intro p hp
  have h : env55374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55373_55374 : H12AffineEnvironment.transform 9 52 env55373 = env55374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55373 == env55374) = true)

theorem identity55374 : scanCanonicalize (H12AffineFastState.compose env55374 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound55374 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env55375 : List Nat := [2,4,8,16,32,16,9,5,16,52,17,16,8,1,1,2,16,48,52,0,33,32,16,2,9,16,16,16,16,49,53,33,5,32,0,17]

theorem envBound55375 : H12AffineFastState.Bounded env55375 := by
  intro p hp
  have h : env55375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55374_55375 : H12AffineEnvironment.transform 8 16 env55374 = env55375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env55374 == env55375) = true)

def env55376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58516,4194304,17,41431,8328,64,4678086,115150,45524,442384,75222,4268162,256,98814,90202,512]

theorem envBound55376 : H12AffineFastState.Bounded env55376 := by
  intro p hp
  have h : env55376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55313_55376 : H12AffineEnvironment.transform 22 17 env55313 = env55376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env55313 == env55376) = true)

theorem identity55376 : scanCanonicalize (H12AffineFastState.compose env55376 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10708) := by decide +kernel

theorem selectedBound55376 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10708,1024,32769,58516,4194304,17,41431,8328,64,4409362,115150,45524,190916,75222,4268162,256,98814,90202,512]

theorem envBound55377 : H12AffineFastState.Bounded env55377 := by
  intro p hp
  have h : env55377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55376_55377 : H12AffineEnvironment.transform 17 10708 env55376 = env55377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10708 env55376 == env55377) = true)

theorem identity55377 : scanCanonicalize (H12AffineFastState.compose env55377 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 120203) := by decide +kernel

theorem selectedBound55377 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10708,1024,32769,58516,120203,17,41431,8328,64,171417,115150,45524,190916,75222,62729,256,98814,90202,512]

theorem envBound55378 : H12AffineFastState.Bounded env55378 := by
  intro p hp
  have h : env55378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55377_55378 : H12AffineEnvironment.transform 21 120203 env55377 = env55378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 120203 env55377 == env55378) = true)

theorem identity55378 : scanCanonicalize (H12AffineFastState.compose env55378 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound55378 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env55379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10708,1024,32769,58516,120203,17,41431,8328,64,56712,115150,45524,43477,75222,62729,256,98814,90202,512]

theorem envBound55379 : H12AffineFastState.Bounded env55379 := by
  intro p hp
  have h : env55379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55378_55379 : H12AffineEnvironment.transform 16 16401 env55378 = env55379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env55378 == env55379) = true)

theorem identity55379 : scanCanonicalize (H12AffineFastState.compose env55379 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound55379 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env55380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,16401,10708,1024,29909,4160,74079,17,21763,8328,64,10588,79130,17664,23809,75222,477,256,95530,90202,512]

theorem envBound55380 : H12AffineFastState.Bounded env55380 := by
  intro p hp
  have h : env55380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55379_55380 : H12AffineEnvironment.transform 14 29908 env55379 = env55380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env55379 == env55380) = true)

theorem identity55380 : scanCanonicalize (H12AffineFastState.compose env55380 (packedSelected [1,2,3,5,8,10,14,19,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55380 : packedSelected [1,2,3,5,8,10,14,19,23,32] rootPS < 2^1333 := by decide +kernel

def env55381 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,16401,10589,1024,29788,4160,74079,17,21763,8193,64,10588,79130,17664,23809,75103,340,256,95530,90202,512]

theorem envBound55381 : H12AffineFastState.Bounded env55381 := by
  intro p hp
  have h : env55381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55380_55381 : H12AffineEnvironment.transform 6 9 env55380 = env55381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55380 == env55381) = true)

theorem identity55381 : scanCanonicalize (H12AffineFastState.compose env55381 (packedSelected [17] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound55381 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55382 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,29789,65536,16401,10281,1024,29788,4160,73771,17,21623,8193,64,10280,78958,17524,23669,74795,32,116,95326,90202,512]

theorem envBound55382 : H12AffineFastState.Bounded env55382 := by
  intro p hp
  have h : env55382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55381_55382 : H12AffineEnvironment.transform 7 116 env55381 = env55382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env55381 == env55382) = true)

theorem identity55382 : scanCanonicalize (H12AffineFastState.compose env55382 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 21543) := by decide +kernel

theorem selectedBound55382 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55383 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,29789,21543,16401,10281,1024,29788,4160,29708,17,21623,8193,64,10280,24649,17524,23669,28684,32,116,8313,13437,512]

theorem envBound55383 : H12AffineFastState.Bounded env55383 := by
  intro p hp
  have h : env55383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55382_55383 : H12AffineEnvironment.transform 15 21543 env55382 = env55383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21543 env55382 == env55383) = true)

theorem identity55383 : scanCanonicalize (H12AffineFastState.compose env55383 (packedSelected [1,2,8,10,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 6209) := by decide +kernel

theorem selectedBound55383 : packedSelected [1,2,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env55384 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,6209,11292,3174,6224,10281,1024,11293,4160,11341,17,3126,8193,64,10280,14344,7221,1076,10317,32,116,8313,13437,512]

theorem envBound55384 : H12AffineFastState.Bounded env55384 := by
  intro p hp
  have h : env55384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55383_55384 : H12AffineEnvironment.transform 13 6209 env55383 = env55384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6209 env55383 == env55384) = true)

theorem identity55384 : scanCanonicalize (H12AffineFastState.compose env55384 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1133) := by decide +kernel

theorem selectedBound55384 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env55385 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,1133,6209,2161,3174,6224,3140,1024,2160,4160,2080,17,3126,1132,64,3141,7269,7221,1076,3104,32,116,1044,4112,512]

theorem envBound55385 : H12AffineFastState.Bounded env55385 := by
  intro p hp
  have h : env55385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55384_55385 : H12AffineEnvironment.transform 12 1133 env55384 = env55385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1133 env55384 == env55385) = true)

theorem identity55385 : scanCanonicalize (H12AffineFastState.compose env55385 (packedSelected [1,8,10,11,12,18] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55385 : packedSelected [1,8,10,11,12,18] rootPS < 2^1333 := by decide +kernel

def env55386 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,4096,89,6209,2161,2130,6224,2160,52,2160,4160,2080,17,2050,88,64,2161,6225,6145,0,2068,32,116,32,4112,512]

theorem envBound55386 : H12AffineFastState.Bounded env55386 := by
  intro p hp
  have h : env55386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55385_55386 : H12AffineEnvironment.transform 9 52 env55385 = env55386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55385 == env55386) = true)

theorem identity55386 : scanCanonicalize (H12AffineFastState.compose env55386 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55386 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env55387 : List Nat := [2,4,8,16,0,64,9,84,512,20,2048,4096,89,6209,2129,2130,6224,2128,20,2128,4160,2048,17,2050,88,64,2129,6225,6145,0,2068,0,84,0,4112,512]

theorem envBound55387 : H12AffineFastState.Bounded env55387 := by
  intro p hp
  have h : env55387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55386_55387 : H12AffineEnvironment.transform 4 0 env55386 = env55387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55386 == env55387) = true)

theorem identity55387 : scanCanonicalize (H12AffineFastState.compose env55387 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound55387 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env55388 : List Nat := [2,4,8,16,0,64,9,84,512,20,2048,2113,89,0,2129,2130,17,2128,20,2128,2049,2048,17,2050,88,64,2129,16,64,0,2068,0,84,0,2129,512]

theorem envBound55388 : H12AffineFastState.Bounded env55388 := by
  intro p hp
  have h : env55388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55387_55388 : H12AffineEnvironment.transform 11 2113 env55387 = env55388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env55387 == env55388) = true)

theorem identity55388 : scanCanonicalize (H12AffineFastState.compose env55388 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound55388 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env55389 : List Nat := [2,4,8,16,0,64,9,84,512,20,81,16,89,0,0,3,17,1,20,1,80,81,17,83,88,64,0,16,64,0,69,0,84,0,0,512]

theorem envBound55389 : H12AffineFastState.Bounded env55389 := by
  intro p hp
  have h : env55389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55388_55389 : H12AffineEnvironment.transform 10 81 env55388 = env55389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env55388 == env55389) = true)

def env55390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58517,4194304,8388608,41431,8328,64,13066711,115151,8434116,8830977,8463815,4268163,256,8487406,8478794,8389137]

theorem envBound55390 : H12AffineFastState.Bounded env55390 := by
  intro p hp
  have h : env55390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55312_55390 : H12AffineEnvironment.transform 20 58517 env55312 = env55390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env55312 == env55390) = true)

def env55391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58517,4194304,16,41431,8328,64,4678087,115151,45524,442385,75223,4268163,256,98814,90202,513]

theorem envBound55391 : H12AffineFastState.Bounded env55391 := by
  intro p hp
  have h : env55391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55390_55391 : H12AffineEnvironment.transform 22 16 env55390 = env55391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env55390 == env55391) = true)

def env55392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41311,8192,64,4677967,115015,45404,442385,75103,4268043,256,98678,90202,513]

theorem envBound55392 : H12AffineFastState.Bounded env55392 := by
  intro p hp
  have h : env55392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55391_55392 : H12AffineEnvironment.transform 6 8 env55391 = env55392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55391 == env55392) = true)

theorem identity55392 : scanCanonicalize (H12AffineFastState.compose env55392 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound55392 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,17728,4194304,16,2,8192,64,4677967,90138,4097,418124,75103,4268043,256,73771,90202,513]

theorem envBound55393 : H12AffineFastState.Bounded env55393 := by
  intro p hp
  have h : env55393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55392_55393 : H12AffineEnvironment.transform 14 8541 env55392 = env55393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env55392 == env55393) = true)

theorem identity55393 : scanCanonicalize (H12AffineFastState.compose env55393 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound55393 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env55394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,65536,131072,262144,1024,8540,5456,4194304,16,2,8192,64,4665695,77834,4097,405852,75103,4268043,256,73771,77898,513]

theorem envBound55394 : H12AffineFastState.Bounded env55394 := by
  intro p hp
  have h : env55394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55393_55394 : H12AffineEnvironment.transform 13 4112 env55393 = env55394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env55393 == env55394) = true)

theorem identity55394 : scanCanonicalize (H12AffineFastState.compose env55394 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 77835) := by decide +kernel

theorem selectedBound55394 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env55395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,65536,77835,262144,1024,8540,5456,4194304,16,2,8192,64,4456788,77834,4097,328023,75103,4268043,256,73771,77898,513]

theorem envBound55395 : H12AffineFastState.Bounded env55395 := by
  intro p hp
  have h : env55395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55394_55395 : H12AffineEnvironment.transform 16 77835 env55394 = env55395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 77835 env55394 == env55395) = true)

theorem identity55395 : scanCanonicalize (H12AffineFastState.compose env55395 (packedSelected [0,2,3,5,6,10,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound55395 : packedSelected [0,2,3,5,6,10,14,27] rootPS < 2^1333 := by decide +kernel

def env55396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,65536,77835,262144,1024,8540,5456,33,16,2,8192,64,262517,77834,4097,328023,75103,73770,256,73771,77898,513]

theorem envBound55396 : H12AffineFastState.Bounded env55396 := by
  intro p hp
  have h : env55396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55395_55396 : H12AffineEnvironment.transform 21 33 env55395 = env55396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env55395 == env55396) = true)

theorem identity55396 : scanCanonicalize (H12AffineFastState.compose env55396 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound55396 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env55397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,65536,77835,67619,1024,8540,5456,33,16,2,8192,64,67926,77834,4097,2420,75103,73770,256,73771,77898,513]

theorem envBound55397 : H12AffineFastState.Bounded env55397 := by
  intro p hp
  have h : env55397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55396_55397 : H12AffineEnvironment.transform 17 67619 env55396 = env55397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env55396 == env55397) = true)

theorem identity55397 : scanCanonicalize (H12AffineFastState.compose env55397 (packedSelected [0,4,6,7,9,11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 1298) := by decide +kernel

theorem selectedBound55397 : packedSelected [0,4,6,7,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env55398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,1298,13593,3377,1024,8540,5456,33,16,2,8192,64,3140,13592,4097,2420,8269,9528,256,9529,13656,513]

theorem envBound55398 : H12AffineFastState.Bounded env55398 := by
  intro p hp
  have h : env55398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55397_55398 : H12AffineEnvironment.transform 15 1298 env55397 = env55398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1298 env55397 == env55398) = true)

theorem identity55398 : scanCanonicalize (H12AffineFastState.compose env55398 (packedSelected [0,1,2,3,4,7,9,11,12,15,23,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound55398 : packedSelected [0,1,2,3,4,7,9,11,12,15,23,24,28] rootPS < 2^1333 := by decide +kernel

def env55399 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1305,4112,1092,1298,4096,3377,1024,1093,5456,33,16,2,1305,64,3140,4097,4097,2420,1364,33,256,32,4161,513]

theorem envBound55399 : H12AffineFastState.Bounded env55399 := by
  intro p hp
  have h : env55399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55398_55399 : H12AffineEnvironment.transform 12 1305 env55398 = env55399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env55398 == env55399) = true)

def env55400 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41310,8193,64,4677966,115014,45405,442385,75102,4268042,256,98679,90202,513]

theorem envBound55400 : H12AffineFastState.Bounded env55400 := by
  intro p hp
  have h : env55400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55391_55400 : H12AffineEnvironment.transform 6 9 env55391 = env55400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55391 == env55400) = true)

def env55401 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41230,8193,16,4677918,114966,45325,442385,75022,4268042,256,98599,90122,513]

theorem envBound55401 : H12AffineFastState.Bounded env55401 := by
  intro p hp
  have h : env55401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55400_55401 : H12AffineEnvironment.transform 5 16 env55400 = env55401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55400 == env55401) = true)

def env55402 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,4194304,16,41230,8193,16,4409654,114966,45325,190521,75022,4268042,256,98599,90122,513]

theorem envBound55402 : H12AffineFastState.Bounded env55402 := by
  intro p hp
  have h : env55402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55401_55402 : H12AffineEnvironment.transform 17 10280 env55401 = env55402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env55401 == env55402) = true)

theorem identity55402 : scanCanonicalize (H12AffineFastState.compose env55402 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 118035) := by decide +kernel

theorem selectedBound55402 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env55403 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,118035,16,41230,8193,16,164901,114966,45325,190521,75022,60697,256,98599,90122,513]

theorem envBound55403 : H12AffineFastState.Bounded env55403 := by
  intro p hp
  have h : env55403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55402_55403 : H12AffineEnvironment.transform 21 118035 env55402 = env55403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 118035 env55402 == env55403) = true)

theorem identity55403 : scanCanonicalize (H12AffineFastState.compose env55403 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound55403 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env55404 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58396,118035,16,41230,8193,16,123966,114966,45325,100386,75022,60697,256,98599,90122,513]

theorem envBound55404 : H12AffineFastState.Bounded env55404 := by
  intro p hp
  have h : env55404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55403_55404 : H12AffineEnvironment.transform 16 90139 env55403 = env55404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env55403 == env55404) = true)

theorem identity55404 : scanCanonicalize (H12AffineFastState.compose env55404 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound55404 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env55405 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,293,32768,65536,74046,10280,1024,32769,42297,101430,16,41230,8193,16,107803,98355,45325,100386,75022,44092,256,98599,74031,513]

theorem envBound55405 : H12AffineFastState.Bounded env55405 := by
  intro p hp
  have h : env55405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55404_55405 : H12AffineEnvironment.transform 13 293 env55404 = env55405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env55404 == env55405) = true)

theorem identity55405 : scanCanonicalize (H12AffineFastState.compose env55405 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound55405 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env55406 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,293,32768,8203,309,10280,1024,32769,42297,44093,16,41230,8193,16,34064,41016,45325,43049,1285,44092,256,41260,292,513]

theorem envBound55406 : H12AffineFastState.Bounded env55406 := by
  intro p hp
  have h : env55406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55405_55406 : H12AffineEnvironment.transform 15 8203 env55405 = env55406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env55405 == env55406) = true)

theorem identity55406 : scanCanonicalize (H12AffineFastState.compose env55406 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound55406 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55407 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,309,8192,293,32768,8203,309,10280,1024,32769,42297,44093,16,41230,8193,16,34064,41016,41016,43049,1285,44092,256,41260,292,513]

theorem envBound55407 : H12AffineFastState.Bounded env55407 := by
  intro p hp
  have h : env55407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55406_55407 : H12AffineEnvironment.transform 11 309 env55406 = env55407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env55406 == env55407) = true)

theorem identity55407 : scanCanonicalize (H12AffineFastState.compose env55407 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound55407 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env55408 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,309,1052,293,32768,1047,309,3124,1024,32769,33061,34849,16,34066,1053,16,34064,33828,33828,35893,1285,34848,256,34096,292,513]

theorem envBound55408 : H12AffineFastState.Bounded env55408 := by
  intro p hp
  have h : env55408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55407_55408 : H12AffineEnvironment.transform 12 1052 env55407 = env55408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env55407 == env55408) = true)

theorem identity55408 : scanCanonicalize (H12AffineFastState.compose env55408 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1077) := by decide +kernel

theorem selectedBound55408 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env55409 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,309,1052,293,1077,1047,309,3124,1024,1076,1296,3092,16,295,1053,16,293,17,17,2048,1285,3093,256,261,292,513]

theorem envBound55409 : H12AffineFastState.Bounded env55409 := by
  intro p hp
  have h : env55409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55408_55409 : H12AffineEnvironment.transform 14 1077 env55408 = env55409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1077 env55408 == env55409) = true)

theorem identity55409 : scanCanonicalize (H12AffineFastState.compose env55409 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound55409 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env55410 : List Nat := [2,4,8,16,32,16,9,256,512,257,2048,309,285,293,308,278,309,2357,257,309,17,2325,16,295,284,16,293,17,17,2048,4,2324,256,261,292,513]

theorem envBound55410 : H12AffineFastState.Bounded env55410 := by
  intro p hp
  have h : env55410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55409_55410 : H12AffineEnvironment.transform 9 257 env55409 = env55410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env55409 == env55410) = true)

theorem identity55410 : scanCanonicalize (H12AffineFastState.compose env55410 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound55410 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env55411 : List Nat := [2,4,8,16,32,16,9,256,512,257,293,309,285,293,308,278,309,16,257,309,17,48,16,295,284,16,293,17,17,293,4,49,256,261,292,513]

theorem envBound55411 : H12AffineFastState.Bounded env55411 := by
  intro p hp
  have h : env55411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55410_55411 : H12AffineEnvironment.transform 10 293 env55410 = env55411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env55410 == env55411) = true)

theorem identity55411 : scanCanonicalize (H12AffineFastState.compose env55411 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound55411 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55412 : List Nat := [2,4,8,16,32,16,9,53,512,52,16,0,40,16,1,35,0,16,52,0,17,48,16,18,41,16,16,17,17,16,4,49,53,48,17,513]

theorem envBound55412 : H12AffineFastState.Bounded env55412 := by
  intro p hp
  have h : env55412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55411_55412 : H12AffineEnvironment.transform 7 53 env55411 = env55412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env55411 == env55412) = true)

theorem identity55412 : scanCanonicalize (H12AffineFastState.compose env55412 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound55412 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55413 : List Nat := [2,4,8,16,32,16,9,53,33,52,16,0,40,16,1,35,0,16,52,0,17,48,16,18,41,16,16,17,17,16,4,49,53,48,17,32]

theorem envBound55413 : H12AffineFastState.Bounded env55413 := by
  intro p hp
  have h : env55413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55412_55413 : H12AffineEnvironment.transform 8 33 env55412 = env55413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env55412 == env55413) = true)

theorem identity55413 : scanCanonicalize (H12AffineFastState.compose env55413 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55413 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env55414 : List Nat := [2,4,8,0,32,0,9,37,33,36,0,0,40,0,1,35,0,0,36,0,1,32,0,2,41,0,0,1,1,0,4,33,37,32,1,32]

theorem envBound55414 : H12AffineFastState.Bounded env55414 := by
  intro p hp
  have h : env55414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55413_55414 : H12AffineEnvironment.transform 3 0 env55413 = env55414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55413 == env55414) = true)

theorem identity55414 : scanCanonicalize (H12AffineFastState.compose env55414 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55414 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55415 : List Nat := [2,4,8,0,0,0,9,5,1,4,0,0,8,0,1,3,0,0,4,0,1,0,0,2,9,0,0,1,1,0,4,1,5,0,1,0]

theorem envBound55415 : H12AffineFastState.Bounded env55415 := by
  intro p hp
  have h : env55415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55414_55415 : H12AffineEnvironment.transform 4 0 env55414 = env55415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55414 == env55415) = true)

def env55416 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41230,8193,16,4409655,114966,45325,190520,75022,4268042,256,98599,90122,513]

theorem envBound55416 : H12AffineFastState.Bounded env55416 := by
  intro p hp
  have h : env55416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55401_55416 : H12AffineEnvironment.transform 17 10281 env55401 = env55416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55401 == env55416) = true)

theorem identity55416 : scanCanonicalize (H12AffineFastState.compose env55416 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246071) := by decide +kernel

theorem selectedBound55416 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env55417 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,246071,16,41230,8193,16,34816,114966,45325,190520,75022,188733,256,98599,90122,513]

theorem envBound55417 : H12AffineFastState.Bounded env55417 := by
  intro p hp
  have h : env55417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55416_55417 : H12AffineEnvironment.transform 21 246071 env55416 = env55417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246071 env55416 == env55417) = true)

theorem identity55417 : scanCanonicalize (H12AffineFastState.compose env55417 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound55417 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env55418 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,65536,131072,10281,1024,0,25629,213302,16,8463,8193,16,2049,82199,12556,157753,75022,155964,256,65830,90122,513]

theorem envBound55418 : H12AffineFastState.Bounded env55418 := by
  intro p hp
  have h : env55418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55417_55418 : H12AffineEnvironment.transform 14 1 env55417 = env55418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env55417 == env55418) = true)

theorem identity55418 : scanCanonicalize (H12AffineFastState.compose env55418 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound55418 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env55419 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,262,131072,10281,1024,0,25629,147504,16,8463,8193,16,2049,16401,12556,157753,9224,155964,256,32,24844,513]

theorem envBound55419 : H12AffineFastState.Bounded env55419 := by
  intro p hp
  have h : env55419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55418_55419 : H12AffineEnvironment.transform 15 262 env55418 = env55419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env55418 == env55419) = true)

theorem identity55419 : scanCanonicalize (H12AffineFastState.compose env55419 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound55419 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env55420 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,262,16400,10281,1024,0,25629,32,16,8463,8193,16,2049,16401,12556,10281,9224,8492,256,32,24844,513]

theorem envBound55420 : H12AffineFastState.Bounded env55420 := by
  intro p hp
  have h : env55420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55419_55420 : H12AffineEnvironment.transform 16 16400 env55419 = env55420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env55419 == env55420) = true)

theorem identity55420 : scanCanonicalize (H12AffineFastState.compose env55420 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55420 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env55421 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,262,16400,2340,1024,0,17680,32,16,2,268,16,2049,16401,4097,2340,1285,33,256,32,16385,513]

theorem envBound55421 : H12AffineFastState.Bounded env55421 := by
  intro p hp
  have h : env55421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55420_55421 : H12AffineEnvironment.transform 12 269 env55420 = env55421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55420 == env55421) = true)

theorem identity55421 : scanCanonicalize (H12AffineFastState.compose env55421 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4388) := by decide +kernel

theorem selectedBound55421 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55422 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,4388,1,262,4404,2340,1024,0,5172,32,16,2,268,16,2049,4405,4097,2340,1285,33,256,32,4389,513]

theorem envBound55422 : H12AffineFastState.Bounded env55422 := by
  intro p hp
  have h : env55422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55421_55422 : H12AffineEnvironment.transform 13 4388 env55421 = env55422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4388 env55421 == env55422) = true)

theorem identity55422 : scanCanonicalize (H12AffineFastState.compose env55422 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound55422 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55423 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,512,269,804,1,262,820,2340,1024,0,1588,32,16,2,268,16,2049,821,513,2340,1285,33,256,32,805,513]

theorem envBound55423 : H12AffineFastState.Bounded env55423 := by
  intro p hp
  have h : env55423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55422_55423 : H12AffineEnvironment.transform 11 512 env55422 = env55423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env55422 == env55423) = true)

theorem identity55423 : scanCanonicalize (H12AffineFastState.compose env55423 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound55423 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55424 : List Nat := [2,4,8,16,32,16,9,256,512,769,2048,512,269,804,1,262,820,2340,769,0,309,32,16,2,268,16,2049,821,513,2340,516,33,256,32,805,513]

theorem envBound55424 : H12AffineFastState.Bounded env55424 := by
  intro p hp
  have h : env55424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55423_55424 : H12AffineEnvironment.transform 9 769 env55423 = env55424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env55423 == env55424) = true)

theorem identity55424 : scanCanonicalize (H12AffineFastState.compose env55424 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound55424 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55425 : List Nat := [2,4,8,16,32,16,9,52,512,565,2048,512,57,528,1,50,512,2064,565,0,1,32,16,2,56,16,2049,513,513,2064,516,33,52,32,529,513]

theorem envBound55425 : H12AffineFastState.Bounded env55425 := by
  intro p hp
  have h : env55425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55424_55425 : H12AffineEnvironment.transform 7 52 env55424 = env55425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env55424 == env55425) = true)

theorem identity55425 : scanCanonicalize (H12AffineFastState.compose env55425 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound55425 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55426 : List Nat := [2,4,8,16,32,16,9,52,512,565,16,512,57,528,1,50,512,0,565,0,1,32,16,2,56,16,17,513,513,0,516,33,52,32,529,513]

theorem envBound55426 : H12AffineFastState.Bounded env55426 := by
  intro p hp
  have h : env55426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55425_55426 : H12AffineEnvironment.transform 10 16 env55425 = env55426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env55425 == env55426) = true)

theorem identity55426 : scanCanonicalize (H12AffineFastState.compose env55426 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound55426 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55427 : List Nat := [2,4,8,16,32,16,9,52,32,21,16,32,57,48,1,50,32,0,21,0,1,32,16,2,56,16,17,33,33,0,36,33,52,32,49,33]

theorem envBound55427 : H12AffineFastState.Bounded env55427 := by
  intro p hp
  have h : env55427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55426_55427 : H12AffineEnvironment.transform 8 32 env55426 = env55427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env55426 == env55427) = true)

def env55428 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41231,8193,17,4677919,114967,45324,442385,75023,4268042,256,98598,90123,513]

theorem envBound55428 : H12AffineFastState.Bounded env55428 := by
  intro p hp
  have h : env55428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55400_55428 : H12AffineEnvironment.transform 5 17 env55400 = env55428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55400 == env55428) = true)

theorem identity55428 : scanCanonicalize (H12AffineFastState.compose env55428 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound55428 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env55429 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41231,8193,17,4409654,114967,45324,190520,75023,4268042,256,98598,90123,513]

theorem envBound55429 : H12AffineFastState.Bounded env55429 := by
  intro p hp
  have h : env55429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55428_55429 : H12AffineEnvironment.transform 17 10281 env55428 = env55429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55428 == env55429) = true)

theorem identity55429 : scanCanonicalize (H12AffineFastState.compose env55429 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound55429 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env55430 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1024,32769,58396,4194304,16,41231,8193,17,4385085,24860,45324,190520,34052,4227073,256,8493,49152,513]

theorem envBound55430 : H12AffineFastState.Bounded env55430 := by
  intro p hp
  have h : env55430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55429_55430 : H12AffineEnvironment.transform 15 40971 env55429 = env55430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env55429 == env55430) = true)

theorem identity55430 : scanCanonicalize (H12AffineFastState.compose env55430 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 155965) := by decide +kernel

theorem selectedBound55430 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55431 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1024,32769,58396,155965,16,41231,8193,17,34816,24860,45324,190520,34052,188732,256,8493,49152,513]

theorem envBound55431 : H12AffineFastState.Bounded env55431 := by
  intro p hp
  have h : env55431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55430_55431 : H12AffineEnvironment.transform 21 155965 env55430 = env55431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 155965 env55430 == env55431) = true)

theorem identity55431 : scanCanonicalize (H12AffineFastState.compose env55431 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound55431 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env55432 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40971,16400,10281,1024,32769,58396,8493,16,41231,8193,17,34816,24860,45324,43048,34052,41260,256,8493,49152,513]

theorem envBound55432 : H12AffineFastState.Bounded env55432 := by
  intro p hp
  have h : env55432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55431_55432 : H12AffineEnvironment.transform 16 16400 env55431 = env55432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env55431 == env55432) = true)

def env55433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58517,4194304,17,41431,8328,64,4678086,115151,45525,442384,75222,4268163,256,98815,90203,512]

theorem envBound55433 : H12AffineFastState.Bounded env55433 := by
  intro p hp
  have h : env55433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55390_55433 : H12AffineEnvironment.transform 22 17 env55390 = env55433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env55390 == env55433) = true)

theorem identity55433 : scanCanonicalize (H12AffineFastState.compose env55433 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10709) := by decide +kernel

theorem selectedBound55433 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10709,1024,32769,58517,4194304,17,41431,8328,64,4409363,115151,45525,190917,75222,4268163,256,98815,90203,512]

theorem envBound55434 : H12AffineFastState.Bounded env55434 := by
  intro p hp
  have h : env55434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55433_55434 : H12AffineEnvironment.transform 17 10709 env55433 = env55434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10709 env55433 == env55434) = true)

theorem identity55434 : scanCanonicalize (H12AffineFastState.compose env55434 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 62849) := by decide +kernel

theorem selectedBound55434 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10709,1024,32769,58517,62849,17,41431,8328,64,245138,115151,45525,190917,75222,120066,256,98815,90203,512]

theorem envBound55435 : H12AffineFastState.Bounded env55435 := by
  intro p hp
  have h : env55435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55434_55435 : H12AffineEnvironment.transform 21 62849 env55434 = env55435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62849 env55434 == env55435) = true)

theorem identity55435 : scanCanonicalize (H12AffineFastState.compose env55435 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound55435 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env55436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10709,1024,32769,58517,62849,17,41431,8328,64,130435,115151,45525,43476,75222,120066,256,98815,90203,512]

theorem envBound55436 : H12AffineFastState.Bounded env55436 := by
  intro p hp
  have h : env55436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55435_55436 : H12AffineEnvironment.transform 16 16401 env55435 = env55436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env55435 == env55436) = true)

theorem identity55436 : scanCanonicalize (H12AffineFastState.compose env55436 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound55436 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env55437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16401,10709,1024,32769,58517,62849,17,41431,8328,64,10588,5392,45525,43476,61705,477,256,21792,46212,512]

theorem envBound55437 : H12AffineFastState.Bounded env55437 := by
  intro p hp
  have h : env55437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55436_55437 : H12AffineEnvironment.transform 15 54495 env55436 = env55437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env55436 == env55437) = true)

theorem identity55437 : scanCanonicalize (H12AffineFastState.compose env55437 (packedSelected [0,6,27] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound55437 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env55438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,32768,32939,5221,10709,1024,32769,45281,41461,17,41431,8328,64,10588,5392,45525,43476,42365,477,256,340,46212,512]

theorem envBound55438 : H12AffineFastState.Bounded env55438 := by
  intro p hp
  have h : env55438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55437_55438 : H12AffineEnvironment.transform 13 5236 env55437 = env55438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env55437 == env55438) = true)

theorem identity55438 : scanCanonicalize (H12AffineFastState.compose env55438 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound55438 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,260,431,5221,10709,1024,261,12773,8433,17,8403,8328,64,10588,5392,12497,10448,9337,477,256,340,13696,512]

theorem envBound55439 : H12AffineFastState.Bounded env55439 := by
  intro p hp
  have h : env55439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55438_55439 : H12AffineEnvironment.transform 14 260 env55438 = env55439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env55438 == env55439) = true)

theorem identity55439 : scanCanonicalize (H12AffineFastState.compose env55439 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound55439 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env55440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,5236,260,431,5221,2161,1024,261,4161,341,17,375,300,64,2296,5392,4469,2420,1501,477,256,340,5156,512]

theorem envBound55440 : H12AffineFastState.Bounded env55440 := by
  intro p hp
  have h : env55440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55439_55440 : H12AffineEnvironment.transform 12 420 env55439 = env55440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env55439 == env55440) = true)

theorem identity55440 : scanCanonicalize (H12AffineFastState.compose env55440 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound55440 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env55441 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,208,5236,112,219,5221,2161,1024,113,4161,33,17,3,88,64,2296,5220,4097,2048,1193,169,116,32,5156,512]

theorem envBound55441 : H12AffineFastState.Bounded env55441 := by
  intro p hp
  have h : env55441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55440_55441 : H12AffineEnvironment.transform 7 116 env55440 = env55441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env55440 == env55441) = true)

theorem identity55441 : scanCanonicalize (H12AffineFastState.compose env55441 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound55441 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env55442 : List Nat := [2,4,8,16,32,64,128,116,512,1024,81,4096,208,5236,112,219,5221,32,1024,113,4161,33,17,3,88,64,169,5220,4097,81,1193,169,116,32,5156,512]

theorem envBound55442 : H12AffineFastState.Bounded env55442 := by
  intro p hp
  have h : env55442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55441_55442 : H12AffineEnvironment.transform 10 81 env55441 = env55442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env55441 == env55442) = true)

theorem identity55442 : scanCanonicalize (H12AffineFastState.compose env55442 (packedSelected [0,1,2,5,7,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound55442 : packedSelected [0,1,2,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env55443 : List Nat := [2,4,8,16,32,64,41,116,512,1024,81,4096,121,5236,112,114,5221,32,1024,113,4161,33,17,3,88,64,0,5220,4097,81,1024,0,116,32,5156,512]

theorem envBound55443 : H12AffineFastState.Bounded env55443 := by
  intro p hp
  have h : env55443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55442_55443 : H12AffineEnvironment.transform 6 41 env55442 = env55443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env55442 == env55443) = true)

theorem identity55443 : scanCanonicalize (H12AffineFastState.compose env55443 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55443 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env55444 : List Nat := [2,4,8,16,1,64,8,85,512,1024,81,4096,88,5205,81,83,5188,1,1024,80,4161,0,17,3,88,64,0,5189,4097,81,1024,0,85,1,5125,512]

theorem envBound55444 : H12AffineFastState.Bounded env55444 := by
  intro p hp
  have h : env55444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55443_55444 : H12AffineEnvironment.transform 4 1 env55443 = env55444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55443 == env55444) = true)

def env55445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound55445 : H12AffineFastState.Bounded env55445 := by
  intro p hp
  have h : env55445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55310_55445 : H12AffineEnvironment.transform 18 1025 env55310 = env55445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env55310 == env55445) = true)

theorem identity55445 : scanCanonicalize (H12AffineFastState.compose env55445 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 213334) := by decide +kernel

theorem selectedBound55445 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env55446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,213334,16777216,8328,64,21266775,18973836,2298887,360790,16958790,23160257,257,19039739,19031134,17031825]

theorem envBound55446 : H12AffineFastState.Bounded env55446 := by
  intro p hp
  have h : env55446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55445_55446 : H12AffineEnvironment.transform 22 213334 env55445 = env55446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 213334 env55445 == env55446) = true)

def env55447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,412108,213334,16777216,8328,64,16959643,18973836,2298887,360790,16958790,19344397,257,19039739,19031134,17031825]

theorem envBound55447 : H12AffineFastState.Bounded env55447 := by
  intro p hp
  have h : env55447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55446_55447 : H12AffineEnvironment.transform 21 412108 env55446 = env55447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 412108 env55446 == env55447) = true)

def env55448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412108,213334,16777216,8328,64,16959643,16974164,102879,360790,16958790,17148373,257,16777251,16834950,17031825]

theorem envBound55448 : H12AffineFastState.Bounded env55448 := by
  intro p hp
  have h : env55448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55447_55448 : H12AffineEnvironment.transform 20 165336 env55447 = env55448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165336 env55447 == env55448) = true)

theorem identity55448 : scanCanonicalize (H12AffineFastState.compose env55448 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 106625) := by decide +kernel

theorem selectedBound55448 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env55449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412108,213334,106625,8328,64,223258,172501,102879,360790,222663,264532,257,106658,82183,147984]

theorem envBound55449 : H12AffineFastState.Bounded env55449 := by
  intro p hp
  have h : env55449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55448_55449 : H12AffineEnvironment.transform 23 106625 env55448 = env55449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 106625 env55448 == env55449) = true)

def env55450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,50632,264668,65862,106625,8328,64,75786,57797,102879,360790,75223,264532,257,106658,82183,512]

theorem envBound55450 : H12AffineFastState.Bounded env55450 := by
  intro p hp
  have h : env55450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55449_55450 : H12AffineEnvironment.transform 16 16400 env55449 = env55450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env55449 == env55450) = true)

theorem identity55450 : scanCanonicalize (H12AffineFastState.compose env55450 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 62850) := by decide +kernel

theorem selectedBound55450 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62850,16400,262144,1025,32769,50632,264668,62660,21763,8328,64,56712,57797,25693,292052,53333,264532,257,21792,46213,512]

theorem envBound55451 : H12AffineFastState.Bounded env55451 := by
  intro p hp
  have h : env55451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55450_55451 : H12AffineEnvironment.transform 15 62850 env55450 = env55451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62850 env55450 == env55451) = true)

theorem identity55451 : scanCanonicalize (H12AffineFastState.compose env55451 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound55451 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env55452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,343,16400,262144,1025,29908,12573,264668,17,21763,8328,64,10589,5392,25693,292052,9344,264532,257,21792,16464,512]

theorem envBound55452 : H12AffineFastState.Bounded env55452 := by
  intro p hp
  have h : env55452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1