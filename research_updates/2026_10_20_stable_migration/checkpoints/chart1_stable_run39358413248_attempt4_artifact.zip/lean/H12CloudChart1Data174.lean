import H12CloudChart1Data173

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound44113 : H12AffineFastState.Bounded env44113 := by
  intro p hp
  have h : env44113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44112_44113 : H12AffineEnvironment.transform 13 5157 env44112 = env44113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env44112 == env44113) = true)

theorem identity44113 : scanCanonicalize (H12AffineFastState.compose env44113 (packedSelected [3,5] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44113 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env44114 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5157,0,263,5172,2340,1025,1,4405,33,17,3,268,17,2048,5173,4097,2340,1284,32,257,33,5157,513]

theorem envBound44114 : H12AffineFastState.Bounded env44114 := by
  intro p hp
  have h : env44114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44113_44114 : H12AffineEnvironment.transform 14 0 env44113 = env44114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44113 == env44114) = true)

def env44115 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3888,269,2837,0,263,2820,2340,1025,1,3589,33,17,3,268,17,2048,2821,3889,2340,1284,32,257,33,2837,513]

theorem envBound44115 : H12AffineFastState.Bounded env44115 := by
  intro p hp
  have h : env44115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44114_44115 : H12AffineEnvironment.transform 11 3888 env44114 = env44115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env44114 == env44115) = true)

def env44116 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,48,269,1045,0,263,1028,1572,1025,1,261,33,17,3,268,17,1792,1029,49,1572,1284,32,257,33,1045,513]

theorem envBound44116 : H12AffineFastState.Bounded env44116 := by
  intro p hp
  have h : env44116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44115_44116 : H12AffineEnvironment.transform 10 1792 env44115 = env44116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env44115 == env44116) = true)

theorem identity44116 : scanCanonicalize (H12AffineFastState.compose env44116 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound44116 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44117 : List Nat := [2,4,8,16,32,16,9,256,512,305,561,48,269,292,0,263,309,789,304,1,261,33,17,3,268,17,561,308,49,789,53,32,257,33,292,513]

theorem envBound44117 : H12AffineFastState.Bounded env44117 := by
  intro p hp
  have h : env44117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44116_44117 : H12AffineEnvironment.transform 9 305 env44116 = env44117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env44116 == env44117) = true)

def env44118 : List Nat := [2,4,8,16,32,16,9,4,512,53,561,48,9,32,0,3,49,529,52,1,1,33,17,3,8,17,561,48,49,529,53,32,5,33,32,513]

theorem envBound44118 : H12AffineFastState.Bounded env44118 := by
  intro p hp
  have h : env44118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44117_44118 : H12AffineEnvironment.transform 7 4 env44117 = env44118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44117 == env44118) = true)

theorem identity44118 : scanCanonicalize (H12AffineFastState.compose env44118 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44118 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44119 : List Nat := [2,4,8,11,32,11,9,4,512,46,554,43,9,32,0,3,42,522,47,1,1,33,10,3,8,10,554,43,42,522,46,32,5,33,32,513]

theorem envBound44119 : H12AffineFastState.Bounded env44119 := by
  intro p hp
  have h : env44119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44118_44119 : H12AffineEnvironment.transform 3 11 env44118 = env44119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44118 == env44119) = true)

def leafEnv44119 : List Nat := [2,4,8,11,32,11,9,4,512,46,554,43,9,32,0,3,42,522,47,1,1,33,10,3,47,8,1,10,554,43,42,522,46,32,5,33,5,2,32,513,1,1,0]

def active44119 : List Nat := [0,1,2,4,8]

def tree44119 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44119 : H12WitnessSearch.Good tree44119 := H12GlobalWitnessIndex.good

theorem leafIdentity44119 : H12AffineFastState.composeSystem env44119 rootObs = leafEnv44119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44119 rootObs == leafEnv44119) = true)

theorem terminalChecked44119 : H12PackedTerminal.terminalCheckFast leafEnv44119 active44119 tree44119 = true := by decide +kernel

def env44120 : List Nat := [2,4,8,16,32,16,9,5,512,52,561,48,8,33,0,2,48,528,53,1,0,33,17,3,9,17,561,49,49,528,53,32,4,33,33,513]

theorem envBound44120 : H12AffineFastState.Bounded env44120 := by
  intro p hp
  have h : env44120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44117_44120 : H12AffineEnvironment.transform 7 5 env44117 = env44120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env44117 == env44120) = true)

theorem identity44120 : scanCanonicalize (H12AffineFastState.compose env44120 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound44120 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44121 : List Nat := [2,4,8,16,32,16,9,5,16,52,33,48,8,33,0,2,48,0,53,1,0,33,17,3,9,17,33,49,49,0,53,32,4,33,33,17]

theorem envBound44121 : H12AffineFastState.Bounded env44121 := by
  intro p hp
  have h : env44121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44120_44121 : H12AffineEnvironment.transform 8 16 env44120 = env44121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env44120 == env44121) = true)

def leafEnv44121 : List Nat := [2,4,8,16,32,16,9,5,16,52,33,48,8,33,0,2,48,0,53,1,0,33,17,3,52,9,1,17,33,49,49,0,53,32,4,33,5,3,33,17,1,0,0]

def active44121 : List Nat := [0,1,2,3,4]

def tree44121 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44121 : H12WitnessSearch.Good tree44121 := H12GlobalWitnessIndex.good

theorem leafIdentity44121 : H12AffineFastState.composeSystem env44121 rootObs = leafEnv44121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44121 rootObs == leafEnv44121) = true)

theorem terminalChecked44121 : H12PackedTerminal.terminalCheckFast leafEnv44121 active44121 tree44121 = true := by decide +kernel

def env44122 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,49,269,1044,0,263,1029,1573,1025,1,260,33,17,3,268,17,1793,1028,48,1573,1284,32,257,33,1044,513]

theorem envBound44122 : H12AffineFastState.Bounded env44122 := by
  intro p hp
  have h : env44122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44115_44122 : H12AffineEnvironment.transform 10 1793 env44115 = env44122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env44115 == env44122) = true)

theorem identity44122 : scanCanonicalize (H12AffineFastState.compose env44122 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44122 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44123 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1793,17,269,1044,0,263,1029,1541,1025,1,260,1,17,3,268,17,1793,1028,16,1541,1284,0,257,1,1044,513]

theorem envBound44123 : H12AffineFastState.Bounded env44123 := by
  intro p hp
  have h : env44123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44122_44123 : H12AffineEnvironment.transform 4 0 env44122 = env44123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44122 == env44123) = true)

def env44124 : List Nat := [2,4,8,16,0,16,9,256,512,20,789,17,269,0,0,263,17,529,21,1,260,1,17,3,268,17,789,16,16,529,272,0,257,1,0,513]

theorem envBound44124 : H12AffineFastState.Bounded env44124 := by
  intro p hp
  have h : env44124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44123_44124 : H12AffineEnvironment.transform 9 20 env44123 = env44124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env44123 == env44124) = true)

theorem identity44124 : scanCanonicalize (H12AffineFastState.compose env44124 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound44124 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44125 : List Nat := [2,4,8,16,0,16,9,256,277,20,0,17,269,0,0,263,17,260,21,1,260,1,17,3,268,17,0,16,16,260,272,0,257,1,0,276]

theorem envBound44125 : H12AffineFastState.Bounded env44125 := by
  intro p hp
  have h : env44125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44124_44125 : H12AffineEnvironment.transform 8 277 env44124 = env44125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env44124 == env44125) = true)

def leafEnv44125 : List Nat := [2,4,8,16,0,16,9,256,277,20,0,17,269,0,0,263,17,260,21,1,260,1,17,3,273,268,1,17,0,16,16,260,272,0,257,1,5,262,0,276,1,260,0]

def active44125 : List Nat := [0,1,2,3,7]

def tree44125 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44125 : H12WitnessSearch.Good tree44125 := H12GlobalWitnessIndex.good

theorem leafIdentity44125 : H12AffineFastState.composeSystem env44125 rootObs = leafEnv44125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44125 rootObs == leafEnv44125) = true)

theorem terminalChecked44125 : H12PackedTerminal.terminalCheckFast leafEnv44125 active44125 tree44125 = true := by decide +kernel

def env44126 : List Nat := [2,4,8,16,0,16,9,256,512,21,788,17,269,1,0,263,16,528,20,1,260,1,17,3,268,17,788,17,16,528,273,0,257,1,1,513]

theorem envBound44126 : H12AffineFastState.Bounded env44126 := by
  intro p hp
  have h : env44126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44123_44126 : H12AffineEnvironment.transform 9 21 env44123 = env44126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env44123 == env44126) = true)

theorem identity44126 : scanCanonicalize (H12AffineFastState.compose env44126 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44126 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44127 : List Nat := [2,4,8,10,0,10,9,256,512,15,782,11,269,1,0,263,10,522,14,1,260,1,11,3,268,11,782,11,10,522,267,0,257,1,1,513]

theorem envBound44127 : H12AffineFastState.Bounded env44127 := by
  intro p hp
  have h : env44127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44126_44127 : H12AffineEnvironment.transform 3 10 env44126 = env44127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44126 == env44127) = true)

def leafEnv44127 : List Nat := [2,4,8,10,0,10,9,256,512,15,782,11,269,1,0,263,10,522,14,1,260,1,11,3,266,268,1,11,782,11,10,522,267,0,257,1,5,262,1,513,1,260,0]

def active44127 : List Nat := [0,1,2,7,8]

def tree44127 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44127 : H12WitnessSearch.Good tree44127 := H12GlobalWitnessIndex.good

theorem leafIdentity44127 : H12AffineFastState.composeSystem env44127 rootObs = leafEnv44127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44127 rootObs == leafEnv44127) = true)

theorem terminalChecked44127 : H12PackedTerminal.terminalCheckFast leafEnv44127 active44127 tree44127 = true := by decide +kernel

def env44128 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3889,269,2836,0,263,2821,2340,1025,1,3588,33,17,3,268,17,2048,2820,3888,2340,1284,32,257,33,2836,513]

theorem envBound44128 : H12AffineFastState.Bounded env44128 := by
  intro p hp
  have h : env44128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44114_44128 : H12AffineEnvironment.transform 11 3889 env44114 = env44128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env44114 == env44128) = true)

def env44129 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,49,269,1044,0,263,1029,1572,1025,1,260,33,17,3,268,17,1792,1028,48,1572,1284,32,257,33,1044,513]

theorem envBound44129 : H12AffineFastState.Bounded env44129 := by
  intro p hp
  have h : env44129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44128_44129 : H12AffineEnvironment.transform 10 1792 env44128 = env44129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env44128 == env44129) = true)

theorem identity44129 : scanCanonicalize (H12AffineFastState.compose env44129 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound44129 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44130 : List Nat := [2,4,8,16,32,16,9,5,512,1024,1541,49,8,1044,0,2,1029,1572,1025,1,1,33,17,3,9,17,1541,1028,48,1572,1025,32,4,33,1044,513]

theorem envBound44130 : H12AffineFastState.Bounded env44130 := by
  intro p hp
  have h : env44130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44129_44130 : H12AffineEnvironment.transform 7 5 env44129 = env44130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env44129 == env44130) = true)

def env44131 : List Nat := [2,4,8,16,32,16,9,5,512,52,561,49,8,32,0,2,49,528,53,1,1,33,17,3,9,17,561,48,48,528,53,32,4,33,32,513]

theorem envBound44131 : H12AffineFastState.Bounded env44131 := by
  intro p hp
  have h : env44131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44130_44131 : H12AffineEnvironment.transform 9 52 env44130 = env44131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44130 == env44131) = true)

theorem identity44131 : scanCanonicalize (H12AffineFastState.compose env44131 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound44131 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44132 : List Nat := [2,4,8,16,32,16,9,5,17,52,32,49,8,32,0,2,49,1,53,1,1,33,17,3,9,17,32,48,48,1,53,32,4,33,32,16]

theorem envBound44132 : H12AffineFastState.Bounded env44132 := by
  intro p hp
  have h : env44132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44131_44132 : H12AffineEnvironment.transform 8 17 env44131 = env44132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env44131 == env44132) = true)

def leafEnv44132 : List Nat := [2,4,8,16,32,16,9,5,17,52,32,49,8,32,0,2,49,1,53,1,1,33,17,3,52,9,1,17,32,48,48,1,53,32,4,33,5,3,32,16,1,1,0]

def active44132 : List Nat := [0,1,2,3,4]

def tree44132 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44132 : H12WitnessSearch.Good tree44132 := H12GlobalWitnessIndex.good

theorem leafIdentity44132 : H12AffineFastState.composeSystem env44132 rootObs = leafEnv44132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44132 rootObs == leafEnv44132) = true)

theorem terminalChecked44132 : H12PackedTerminal.terminalCheckFast leafEnv44132 active44132 tree44132 = true := by decide +kernel

def env44133 : List Nat := [2,4,8,16,32,16,9,5,512,53,560,49,8,33,0,2,48,529,52,1,1,33,17,3,9,17,560,49,48,529,52,32,4,33,33,513]

theorem envBound44133 : H12AffineFastState.Bounded env44133 := by
  intro p hp
  have h : env44133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44130_44133 : H12AffineEnvironment.transform 9 53 env44130 = env44133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44130 == env44133) = true)

theorem identity44133 : scanCanonicalize (H12AffineFastState.compose env44133 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44133 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44134 : List Nat := [2,4,8,11,32,11,9,5,512,46,555,42,8,33,0,2,43,522,47,1,1,33,10,3,9,10,555,42,43,522,47,32,4,33,33,513]

theorem envBound44134 : H12AffineFastState.Bounded env44134 := by
  intro p hp
  have h : env44134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44133_44134 : H12AffineEnvironment.transform 3 11 env44133 = env44134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44133 == env44134) = true)

def leafEnv44134 : List Nat := [2,4,8,11,32,11,9,5,512,46,555,42,8,33,0,2,43,522,47,1,1,33,10,3,46,9,1,10,555,42,43,522,47,32,4,33,5,3,33,513,1,1,0]

def active44134 : List Nat := [0,1,2,4,8]

def tree44134 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44134 : H12WitnessSearch.Good tree44134 := H12GlobalWitnessIndex.good

theorem leafIdentity44134 : H12AffineFastState.composeSystem env44134 rootObs = leafEnv44134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44134 rootObs == leafEnv44134) = true)

theorem terminalChecked44134 : H12PackedTerminal.terminalCheckFast leafEnv44134 active44134 tree44134 = true := by decide +kernel

def env44135 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,48,269,1045,0,263,1028,1573,1025,1,261,33,17,3,268,17,1793,1029,49,1573,1284,32,257,33,1045,513]

theorem envBound44135 : H12AffineFastState.Bounded env44135 := by
  intro p hp
  have h : env44135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44128_44135 : H12AffineEnvironment.transform 10 1793 env44128 = env44135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env44128 == env44135) = true)

theorem identity44135 : scanCanonicalize (H12AffineFastState.compose env44135 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound44135 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44136 : List Nat := [2,4,8,16,32,16,9,256,512,20,789,48,269,1,0,263,16,561,21,1,261,33,17,3,268,17,789,17,49,561,272,32,257,33,1,513]

theorem envBound44136 : H12AffineFastState.Bounded env44136 := by
  intro p hp
  have h : env44136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44135_44136 : H12AffineEnvironment.transform 9 20 env44135 = env44136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env44135 == env44136) = true)

def env44137 : List Nat := [2,4,8,16,0,16,9,256,512,20,789,16,269,1,0,263,16,529,21,1,261,1,17,3,268,17,789,17,17,529,272,0,257,1,1,513]

theorem envBound44137 : H12AffineFastState.Bounded env44137 := by
  intro p hp
  have h : env44137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44136_44137 : H12AffineEnvironment.transform 4 0 env44136 = env44137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44136 == env44137) = true)

theorem identity44137 : scanCanonicalize (H12AffineFastState.compose env44137 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound44137 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44138 : List Nat := [2,4,8,16,0,16,9,256,276,20,1,16,269,1,0,263,16,261,21,1,261,1,17,3,268,17,1,17,17,261,272,0,257,1,1,277]

theorem envBound44138 : H12AffineFastState.Bounded env44138 := by
  intro p hp
  have h : env44138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44137_44138 : H12AffineEnvironment.transform 8 276 env44137 = env44138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env44137 == env44138) = true)

def leafEnv44138 : List Nat := [2,4,8,16,0,16,9,256,276,20,1,16,269,1,0,263,16,261,21,1,261,1,17,3,273,268,1,17,1,17,17,261,272,0,257,1,5,262,1,277,1,261,0]

def active44138 : List Nat := [0,1,2,3,7]

def tree44138 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44138 : H12WitnessSearch.Good tree44138 := H12GlobalWitnessIndex.good

theorem leafIdentity44138 : H12AffineFastState.composeSystem env44138 rootObs = leafEnv44138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44138 rootObs == leafEnv44138) = true)

theorem terminalChecked44138 : H12PackedTerminal.terminalCheckFast leafEnv44138 active44138 tree44138 = true := by decide +kernel

def env44139 : List Nat := [2,4,8,16,1,16,9,256,512,20,789,17,269,1,0,263,16,528,21,1,261,0,17,3,268,17,789,17,16,528,272,1,257,0,1,513]

theorem envBound44139 : H12AffineFastState.Bounded env44139 := by
  intro p hp
  have h : env44139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44136_44139 : H12AffineEnvironment.transform 4 1 env44136 = env44139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44136 == env44139) = true)

theorem identity44139 : scanCanonicalize (H12AffineFastState.compose env44139 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44139 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44140 : List Nat := [2,4,8,10,1,10,9,256,512,14,783,11,269,1,0,263,10,522,15,1,261,0,11,3,268,11,783,11,10,522,266,1,257,0,1,513]

theorem envBound44140 : H12AffineFastState.Bounded env44140 := by
  intro p hp
  have h : env44140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44139_44140 : H12AffineEnvironment.transform 3 10 env44139 = env44140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44139 == env44140) = true)

def leafEnv44140 : List Nat := [2,4,8,10,1,10,9,256,512,14,783,11,269,1,0,263,10,522,15,1,261,0,11,3,267,268,1,11,783,11,10,522,266,1,257,0,5,262,1,513,1,261,0]

def active44140 : List Nat := [0,1,2,7,8]

def tree44140 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44140 : H12WitnessSearch.Good tree44140 := H12GlobalWitnessIndex.good

theorem leafIdentity44140 : H12AffineFastState.composeSystem env44140 rootObs = leafEnv44140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44140 rootObs == leafEnv44140) = true)

theorem terminalChecked44140 : H12PackedTerminal.terminalCheckFast leafEnv44140 active44140 tree44140 = true := by decide +kernel

def env44141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356288,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound44141 : H12AffineFastState.Bounded env44141 := by
  intro p hp
  have h : env44141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43824_44141 : H12AffineEnvironment.transform 26 30393345 env43824 = env44141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env43824 == env44141) = true)

def env44142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound44142 : H12AffineFastState.Bounded env44142 := by
  intro p hp
  have h : env44142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44141_44142 : H12AffineEnvironment.transform 18 1024 env44141 = env44142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env44141 == env44142) = true)

theorem identity44142 : scanCanonicalize (H12AffineFastState.compose env44142 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 437624) := by decide +kernel

theorem selectedBound44142 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env44143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,4194304,8388608,16777216,8328,65,29868033,17246708,8845352,8830976,25265169,21481656,256,25651669,25659504,25207750]

theorem envBound44143 : H12AffineFastState.Bounded env44143 := by
  intro p hp
  have h : env44143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44142_44143 : H12AffineEnvironment.transform 20 437624 env44142 = env44143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437624 env44142 == env44143) = true)

def env44144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,4194304,8388608,8862964,8328,65,4259061,8393984,8845352,8830976,440549,12645452,256,21793,46212,499506]

theorem envBound44144 : H12AffineFastState.Bounded env44144 := by
  intro p hp
  have h : env44144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44143_44144 : H12AffineEnvironment.transform 23 8862964 env44143 = env44144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862964 env44143 == env44144) = true)

def env44145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,4194304,441640,98780,8328,65,4259061,436264,17664,32040,440549,4606308,256,21793,46212,499506]

theorem envBound44145 : H12AffineFastState.Bounded env44145 := by
  intro p hp
  have h : env44145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44144_44145 : H12AffineEnvironment.transform 22 441640 env44144 = env44145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env44144 == env44145) = true)

def env44146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272512,441640,98780,8328,65,316533,436264,17664,32040,440549,156132,256,21793,46212,499506]

theorem envBound44146 : H12AffineFastState.Bounded env44146 := by
  intro p hp
  have h : env44146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44145_44146 : H12AffineEnvironment.transform 21 272512 env44145 = env44146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env44145 == env44146) = true)

theorem identity44146 : scanCanonicalize (H12AffineFastState.compose env44146 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44146 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,437624,272512,441640,41431,8328,65,316533,436264,17664,32040,440549,156132,256,21793,46212,442169]

theorem envBound44147 : H12AffineFastState.Bounded env44147 := by
  intro p hp
  have h : env44147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44146_44147 : H12AffineEnvironment.transform 15 8203 env44146 = env44147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44146 == env44147) = true)

def env44148 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,437624,272392,441640,41311,8192,65,316533,436264,17664,32040,440429,156012,256,21793,46092,442169]

theorem envBound44148 : H12AffineFastState.Bounded env44148 := by
  intro p hp
  have h : env44148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44147_44148 : H12AffineEnvironment.transform 6 8 env44147 = env44148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44147 == env44148) = true)

theorem identity44148 : scanCanonicalize (H12AffineFastState.compose env44148 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound44148 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env44149 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,13389,262144,1024,32769,301365,272392,297317,41311,8192,65,316533,302181,17664,32040,298016,21793,256,21793,46092,297844]

theorem envBound44149 : H12AffineFastState.Bounded env44149 := by
  intro p hp
  have h : env44149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44148_44149 : H12AffineEnvironment.transform 16 13389 env44148 = env44149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env44148 == env44149) = true)

theorem identity44149 : scanCanonicalize (H12AffineFastState.compose env44149 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 34816) := by decide +kernel

theorem selectedBound44149 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44150 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,13389,34816,1024,32769,4405,40968,357,41311,8192,65,23669,5221,17664,32040,1056,21793,256,21793,46092,884]

theorem envBound44150 : H12AffineFastState.Bounded env44150 := by
  intro p hp
  have h : env44150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44149_44150 : H12AffineEnvironment.transform 17 34816 env44149 = env44150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34816 env44149 == env44150) = true)

theorem identity44150 : scanCanonicalize (H12AffineFastState.compose env44150 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44150 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env44151 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,13389,10589,1024,8540,4405,341,357,2,8192,65,23669,5221,17664,32040,1056,21793,256,21793,5457,884]

theorem envBound44151 : H12AffineFastState.Bounded env44151 := by
  intro p hp
  have h : env44151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44150_44151 : H12AffineEnvironment.transform 14 8541 env44150 = env44151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44150 == env44151) = true)

theorem identity44151 : scanCanonicalize (H12AffineFastState.compose env44151 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound44151 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env44152 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,8541,8203,13389,10589,1024,8540,4405,341,357,2,8192,65,10588,5221,12329,2049,1056,8200,256,8200,5457,884]

theorem envBound44152 : H12AffineFastState.Bounded env44152 := by
  intro p hp
  have h : env44152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44151_44152 : H12AffineEnvironment.transform 13 13609 env44151 = env44152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env44151 == env44152) = true)

theorem identity44152 : scanCanonicalize (H12AffineFastState.compose env44152 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound44152 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env44153 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5156,80,262,5440,2128,1024,81,4405,341,357,2,269,65,2129,5221,4388,2049,1056,261,256,261,5457,884]

theorem envBound44153 : H12AffineFastState.Bounded env44153 := by
  intro p hp
  have h : env44153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44152_44153 : H12AffineEnvironment.transform 12 269 env44152 = env44153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env44152 == env44153) = true)

theorem identity44153 : scanCanonicalize (H12AffineFastState.compose env44153 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound44153 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env44154 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,64,269,1124,80,262,1280,2128,1024,81,373,341,357,2,269,65,2129,1061,356,2049,1056,261,256,261,1297,884]

theorem envBound44154 : H12AffineFastState.Bounded env44154 := by
  intro p hp
  have h : env44154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44153_44154 : H12AffineEnvironment.transform 11 64 env44153 = env44154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env44153 == env44154) = true)

theorem identity44154 : scanCanonicalize (H12AffineFastState.compose env44154 (packedSelected [1,2,3,4,5,6,8,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound44154 : packedSelected [1,2,3,4,5,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env44155 : List Nat := [2,4,8,16,32,64,8,256,512,20,2048,64,269,112,80,262,276,2128,20,81,373,341,357,2,269,65,2129,49,356,2049,52,261,256,261,261,884]

theorem envBound44155 : H12AffineFastState.Bounded env44155 := by
  intro p hp
  have h : env44155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44154_44155 : H12AffineEnvironment.transform 9 20 env44154 = env44155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env44154 == env44155) = true)

theorem identity44155 : scanCanonicalize (H12AffineFastState.compose env44155 (packedSelected [2,3,4,5,6,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44155 : packedSelected [2,3,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env44156 : List Nat := [2,4,8,16,1,64,8,256,512,20,2048,64,269,81,80,262,276,2128,20,81,340,341,324,2,269,65,2129,16,325,2049,21,261,256,261,261,853]

theorem envBound44156 : H12AffineFastState.Bounded env44156 := by
  intro p hp
  have h : env44156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44155_44156 : H12AffineEnvironment.transform 4 1 env44155 = env44156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44155 == env44156) = true)

theorem identity44156 : scanCanonicalize (H12AffineFastState.compose env44156 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44156 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44157 : List Nat := [2,4,8,16,1,16,8,256,512,20,2048,16,269,1,0,262,276,2048,20,1,260,261,276,2,269,17,2049,16,277,2049,21,261,256,261,261,773]

theorem envBound44157 : H12AffineFastState.Bounded env44157 := by
  intro p hp
  have h : env44157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44156_44157 : H12AffineEnvironment.transform 5 16 env44156 = env44157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44156 == env44157) = true)

theorem identity44157 : scanCanonicalize (H12AffineFastState.compose env44157 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound44157 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44158 : List Nat := [2,4,8,16,1,16,8,256,20,20,2048,16,269,1,0,262,276,2048,20,1,260,261,276,2,269,17,2049,16,277,2049,21,261,256,261,261,273]

theorem envBound44158 : H12AffineFastState.Bounded env44158 := by
  intro p hp
  have h : env44158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44157_44158 : H12AffineEnvironment.transform 8 20 env44157 = env44158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env44157 == env44158) = true)

theorem identity44158 : scanCanonicalize (H12AffineFastState.compose env44158 (packedSelected [2,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44158 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env44159 : List Nat := [1,4,8,16,1,16,8,256,20,20,2048,16,269,1,0,261,276,2048,20,1,260,261,276,1,269,17,2049,16,277,2049,21,261,256,261,261,273]

theorem envBound44159 : H12AffineFastState.Bounded env44159 := by
  intro p hp
  have h : env44159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44158_44159 : H12AffineEnvironment.transform 0 1 env44158 = env44159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44158 == env44159) = true)

theorem identity44159 : scanCanonicalize (H12AffineFastState.compose env44159 (packedSelected [2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound44159 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env44160 : List Nat := [1,4,8,16,1,16,8,256,20,20,260,16,269,1,0,261,276,260,20,1,260,261,276,1,269,17,261,16,277,261,21,261,256,261,261,273]

theorem envBound44160 : H12AffineFastState.Bounded env44160 := by
  intro p hp
  have h : env44160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44159_44160 : H12AffineEnvironment.transform 10 260 env44159 = env44160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env44159 == env44160) = true)

theorem identity44160 : scanCanonicalize (H12AffineFastState.compose env44160 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound44160 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env44161 : List Nat := [1,4,8,16,1,16,8,5,20,20,1,16,8,1,0,0,17,1,20,1,1,0,17,1,8,17,0,16,16,0,21,0,5,0,0,20]

theorem envBound44161 : H12AffineFastState.Bounded env44161 := by
  intro p hp
  have h : env44161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44160_44161 : H12AffineEnvironment.transform 7 5 env44160 = env44161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env44160 == env44161) = true)

theorem identity44161 : scanCanonicalize (H12AffineFastState.compose env44161 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound44161 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44162 : List Nat := [1,4,8,12,1,12,8,5,8,8,1,12,8,1,0,0,13,1,8,1,1,0,13,1,8,13,0,12,12,0,9,0,5,0,0,8]

theorem envBound44162 : H12AffineFastState.Bounded env44162 := by
  intro p hp
  have h : env44162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44161_44162 : H12AffineEnvironment.transform 3 12 env44161 = env44162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env44161 == env44162) = true)

def env44163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,437624,272393,441640,41310,8193,65,316533,436264,17664,32040,440428,156013,256,21793,46093,442169]

theorem envBound44163 : H12AffineFastState.Bounded env44163 := by
  intro p hp
  have h : env44163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44147_44163 : H12AffineEnvironment.transform 6 9 env44147 = env44163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44147 == env44163) = true)

theorem identity44163 : scanCanonicalize (H12AffineFastState.compose env44163 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound44163 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env44164 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1024,32769,276584,272393,272440,41310,8193,65,316533,277816,17664,32040,273788,62589,256,21793,46093,272937]

theorem envBound44164 : H12AffineFastState.Bounded env44164 := by
  intro p hp
  have h : env44164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44163_44164 : H12AffineEnvironment.transform 16 38160 env44163 = env44164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env44163 == env44164) = true)

theorem identity44164 : scanCanonicalize (H12AffineFastState.compose env44164 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound44164 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44165 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10281,1024,32769,4161,32,17,41310,8193,65,64604,5393,17664,32040,1365,62589,256,21793,46093,512]

theorem envBound44165 : H12AffineFastState.Bounded env44165 := by
  intro p hp
  have h : env44165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44164_44165 : H12AffineEnvironment.transform 17 10281 env44164 = env44165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env44164 == env44165) = true)

theorem identity44165 : scanCanonicalize (H12AffineFastState.compose env44165 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound44165 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env44166 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,1297,32768,8203,38160,10281,1024,32769,4161,32,17,41310,8193,65,47437,5393,17,14393,1365,45420,256,4144,46093,512]

theorem envBound44166 : H12AffineFastState.Bounded env44166 := by
  intro p hp
  have h : env44166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44165_44166 : H12AffineEnvironment.transform 13 1297 env44165 = env44166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env44165 == env44166) = true)

theorem identity44166 : scanCanonicalize (H12AffineFastState.compose env44166 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 12345) := by decide +kernel

theorem selectedBound44166 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env44167 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,1297,12345,8203,9513,10281,1024,12344,4161,32,17,4455,8193,65,2420,5393,17,14393,1365,341,256,4144,1076,512]

theorem envBound44167 : H12AffineFastState.Bounded env44167 := by
  intro p hp
  have h : env44167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44166_44167 : H12AffineEnvironment.transform 14 12345 env44166 = env44167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12345 env44166 == env44167) = true)

theorem identity44167 : scanCanonicalize (H12AffineFastState.compose env44167 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound44167 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env44168 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,8192,1297,12345,8203,9513,10281,1024,12344,4144,32,17,4374,8193,48,2309,5393,17,14393,1316,292,256,4144,1076,512]

theorem envBound44168 : H12AffineFastState.Bounded env44168 := by
  intro p hp
  have h : env44168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44167_44168 : H12AffineEnvironment.transform 5 49 env44167 = env44168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env44167 == env44168) = true)

def env44169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272513,441640,98780,8328,65,316532,436264,17664,32040,440549,156133,256,21793,46212,499506]

theorem envBound44169 : H12AffineFastState.Bounded env44169 := by
  intro p hp
  have h : env44169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44145_44169 : H12AffineEnvironment.transform 21 272513 env44145 = env44169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env44145 == env44169) = true)

theorem identity44169 : scanCanonicalize (H12AffineFastState.compose env44169 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236851) := by decide +kernel

theorem selectedBound44169 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,77899,243122,73755,98780,8328,65,215367,79131,17664,32040,75222,156133,256,21793,46212,513]

theorem envBound44170 : H12AffineFastState.Bounded env44170 := by
  intro p hp
  have h : env44170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44169_44170 : H12AffineEnvironment.transform 17 236851 env44169 = env44170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236851 env44169 == env44170) = true)

def env44171 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,77899,243002,73755,98644,8192,65,215367,79131,17664,32040,75102,156013,256,21793,46092,513]

theorem envBound44171 : H12AffineFastState.Bounded env44171 := by
  intro p hp
  have h : env44171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44170_44171 : H12AffineEnvironment.transform 6 8 env44170 = env44171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44170 == env44171) = true)

theorem identity44171 : scanCanonicalize (H12AffineFastState.compose env44171 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound44171 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env44172 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,64808,1024,32769,77899,54561,73755,98644,8192,65,10588,79131,17664,32040,75102,65910,256,21793,46092,513]

theorem envBound44172 : H12AffineFastState.Bounded env44172 := by
  intro p hp
  have h : env44172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44171_44172 : H12AffineEnvironment.transform 16 90139 env44171 = env44172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env44171 == env44172) = true)

theorem identity44172 : scanCanonicalize (H12AffineFastState.compose env44172 (packedSelected [0,2,4,6,9,18,20,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound44172 : packedSelected [0,2,4,6,9,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env44173 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1345,65536,90139,30825,1024,1344,77899,20576,73755,66581,8192,65,10588,79131,17664,32040,75102,65910,256,21793,12621,513]

theorem envBound44173 : H12AffineFastState.Bounded env44173 := by
  intro p hp
  have h : env44173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44172_44173 : H12AffineEnvironment.transform 14 1345 env44172 = env44173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env44172 == env44173) = true)

theorem identity44173 : scanCanonicalize (H12AffineFastState.compose env44173 (packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS)) = affineNative (2^(15+1) ^^^ 28990) := by decide +kernel

theorem selectedBound44173 : packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS < 2^1333 := by decide +kernel

def env44174 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1345,28990,4389,30825,1024,1344,16757,20576,20773,29995,8192,65,10588,17445,17664,32040,21600,28744,256,21793,12621,513]

theorem envBound44174 : H12AffineFastState.Bounded env44174 := by
  intro p hp
  have h : env44174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44173_44174 : H12AffineEnvironment.transform 15 28990 env44173 = env44174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28990 env44173 == env44174) = true)

theorem identity44174 : scanCanonicalize (H12AffineFastState.compose env44174 (packedSelected [1,2,3,6,12,15,18,24,28,32] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound44174 : packedSelected [1,2,3,6,12,15,18,24,28,32] rootPS < 2^1333 := by decide +kernel

def env44175 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,1077,28746,4177,30825,1024,1076,16385,20576,20561,29791,8192,65,10280,17445,17524,31836,21600,28744,116,21589,12345,513]

theorem envBound44175 : H12AffineFastState.Bounded env44175 := by
  intro p hp
  have h : env44175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44174_44175 : H12AffineEnvironment.transform 7 116 env44174 = env44175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44174 == env44175) = true)

theorem identity44175 : scanCanonicalize (H12AffineFastState.compose env44175 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound44175 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44176 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,4096,8192,16384,0,28746,4177,30825,53,1,16385,20576,20561,28778,8192,65,10280,16400,16449,30825,20565,28744,116,20576,12345,513]

theorem envBound44176 : H12AffineFastState.Bounded env44176 := by
  intro p hp
  have h : env44176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44175_44176 : H12AffineEnvironment.transform 9 53 env44175 = env44176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44175 == env44176) = true)

theorem identity44176 : scanCanonicalize (H12AffineFastState.compose env44176 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44176 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44177 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,8192,16384,0,28698,4097,30777,53,1,16385,20528,20481,28730,8192,17,10280,16400,16401,30777,20485,28696,36,20528,12345,513]

theorem envBound44177 : H12AffineFastState.Bounded env44177 := by
  intro p hp
  have h : env44177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44176_44177 : H12AffineEnvironment.transform 5 16 env44176 = env44177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44176 == env44177) = true)

def env44178 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,77899,243003,73755,98645,8193,65,215367,79131,17664,32040,75103,156012,256,21793,46093,513]

theorem envBound44178 : H12AffineFastState.Bounded env44178 := by
  intro p hp
  have h : env44178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44170_44178 : H12AffineEnvironment.transform 6 9 env44170 = env44178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44170 == env44178) = true)

theorem identity44178 : scanCanonicalize (H12AffineFastState.compose env44178 (packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound44178 : packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44179 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,131072,215090,1024,21760,77899,221242,73755,87124,8193,65,215367,79131,17664,32040,75103,156012,256,21793,24844,513]

theorem envBound44179 : H12AffineFastState.Bounded env44179 := by
  intro p hp
  have h : env44179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44178_44179 : H12AffineEnvironment.transform 14 21761 env44178 = env44179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env44178 == env44179) = true)

theorem identity44179 : scanCanonicalize (H12AffineFastState.compose env44179 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound44179 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env44180 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,90139,10281,1024,21760,77899,33,73755,87124,8193,65,10588,79131,17664,32040,75103,65911,256,21793,24844,513]

theorem envBound44180 : H12AffineFastState.Bounded env44180 := by
  intro p hp
  have h : env44180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44179_44180 : H12AffineEnvironment.transform 16 90139 env44179 = env44180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env44179 == env44180) = true)

theorem identity44180 : scanCanonicalize (H12AffineFastState.compose env44180 (packedSelected [0,3,5,7,10,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound44180 : packedSelected [0,3,5,7,10,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env44181 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,65536,82247,2421,1024,21760,69911,33,65863,87124,349,65,2048,70727,17664,23668,66563,65911,256,21793,16464,513]

theorem envBound44181 : H12AffineFastState.Bounded env44181 := by
  intro p hp
  have h : env44181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44180_44181 : H12AffineEnvironment.transform 12 348 env44180 = env44181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env44180 == env44181) = true)

theorem identity44181 : scanCanonicalize (H12AffineFastState.compose env44181 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound44181 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44182 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,21591,5392,2421,1024,21760,17728,33,21776,3,349,65,2048,16400,17664,23668,20564,21792,256,21793,16464,513]

theorem envBound44182 : H12AffineFastState.Bounded env44182 := by
  intro p hp
  have h : env44182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44181_44182 : H12AffineEnvironment.transform 15 21591 env44181 = env44182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env44181 == env44182) = true)

theorem identity44182 : scanCanonicalize (H12AffineFastState.compose env44182 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44182 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env44183 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21761,21511,5392,2341,1024,21760,17680,33,21776,3,269,17,2048,16400,17664,23588,20484,21792,256,21793,16384,513]

theorem envBound44183 : H12AffineFastState.Bounded env44183 := by
  intro p hp
  have h : env44183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44182_44183 : H12AffineEnvironment.transform 5 16 env44182 = env44183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44182 == env44183) = true)

theorem identity44183 : scanCanonicalize (H12AffineFastState.compose env44183 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound44183 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env44184 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5392,2341,1024,1,4113,33,17,3,269,17,2048,5393,4097,2341,1285,33,256,32,5377,513]

theorem envBound44184 : H12AffineFastState.Bounded env44184 := by
  intro p hp
  have h : env44184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44183_44184 : H12AffineEnvironment.transform 13 5377 env44183 = env44184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44183 == env44184) = true)

theorem identity44184 : scanCanonicalize (H12AffineFastState.compose env44184 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44184 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44185 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,0,35,5173,2048,1024,1,4113,33,17,3,40,17,2048,5172,4097,2048,1056,33,37,32,5156,513]

theorem envBound44185 : H12AffineFastState.Bounded env44185 := by
  intro p hp
  have h : env44185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44184_44185 : H12AffineEnvironment.transform 7 37 env44184 = env44185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44184 == env44185) = true)

def env44186 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1044,0,35,1029,2048,1024,1,33,33,17,3,40,17,2048,1028,49,2048,1056,33,37,32,1044,513]

theorem envBound44186 : H12AffineFastState.Bounded env44186 := by
  intro p hp
  have h : env44186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44185_44186 : H12AffineEnvironment.transform 11 48 env44185 = env44186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env44185 == env44186) = true)

theorem identity44186 : scanCanonicalize (H12AffineFastState.compose env44186 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound44186 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44187 : List Nat := [2,4,8,16,32,16,9,37,512,1024,560,48,41,1044,0,35,1029,560,1024,1,33,33,17,3,40,17,560,1028,49,560,1056,33,37,32,1044,513]

theorem envBound44187 : H12AffineFastState.Bounded env44187 := by
  intro p hp
  have h : env44187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44186_44187 : H12AffineEnvironment.transform 10 560 env44186 = env44187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env44186 == env44187) = true)

def env44188 : List Nat := [2,4,8,16,32,16,9,37,512,52,560,48,41,32,0,35,49,560,52,1,33,33,17,3,40,17,560,48,49,560,20,33,37,32,32,513]

theorem envBound44188 : H12AffineFastState.Bounded env44188 := by
  intro p hp
  have h : env44188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44187_44188 : H12AffineEnvironment.transform 9 52 env44187 = env44188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44187 == env44188) = true)

theorem identity44188 : scanCanonicalize (H12AffineFastState.compose env44188 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound44188 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44189 : List Nat := [2,4,8,16,32,16,9,37,17,52,33,48,41,32,0,35,49,33,52,1,33,33,17,3,40,17,33,48,49,33,20,33,37,32,32,16]

theorem envBound44189 : H12AffineFastState.Bounded env44189 := by
  intro p hp
  have h : env44189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44188_44189 : H12AffineEnvironment.transform 8 17 env44188 = env44189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env44188 == env44189) = true)

def leafEnv44189 : List Nat := [2,4,8,16,32,16,9,37,17,52,33,48,41,32,0,35,49,33,52,1,33,33,17,3,20,40,1,17,33,48,49,33,20,33,37,32,4,34,32,16,1,33,0]

def active44189 : List Nat := [0,1,2,3,4]

def tree44189 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44189 : H12WitnessSearch.Good tree44189 := H12GlobalWitnessIndex.good

theorem leafIdentity44189 : H12AffineFastState.composeSystem env44189 rootObs = leafEnv44189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44189 rootObs == leafEnv44189) = true)

theorem terminalChecked44189 : H12PackedTerminal.terminalCheckFast leafEnv44189 active44189 tree44189 = true := by decide +kernel

def env44190 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,48,41,33,0,35,48,560,53,1,33,33,17,3,40,17,560,49,49,560,21,33,37,32,33,513]

theorem envBound44190 : H12AffineFastState.Bounded env44190 := by
  intro p hp
  have h : env44190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44187_44190 : H12AffineEnvironment.transform 9 53 env44187 = env44190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44187 == env44190) = true)

theorem identity44190 : scanCanonicalize (H12AffineFastState.compose env44190 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound44190 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44191 : List Nat := [2,4,8,16,26,16,9,31,512,15,522,10,19,27,0,25,10,522,15,1,27,27,17,3,18,17,522,11,11,522,21,27,31,26,27,513]

theorem envBound44191 : H12AffineFastState.Bounded env44191 := by
  intro p hp
  have h : env44191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44190_44191 : H12AffineEnvironment.transform 4 26 env44190 = env44191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env44190 == env44191) = true)

def leafEnv44191 : List Nat := [2,4,8,16,26,16,9,31,512,15,522,10,19,27,0,25,10,522,15,1,27,27,17,3,21,18,1,17,522,11,11,522,21,27,31,26,4,24,27,513,1,27,0]

def active44191 : List Nat := [0,1,2,3,8]

def tree44191 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44191 : H12WitnessSearch.Good tree44191 := H12GlobalWitnessIndex.good

theorem leafIdentity44191 : H12AffineFastState.composeSystem env44191 rootObs = leafEnv44191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44191 rootObs == leafEnv44191) = true)

theorem terminalChecked44191 : H12PackedTerminal.terminalCheckFast leafEnv44191 active44191 tree44191 = true := by decide +kernel

def env44192 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1045,0,35,1028,2048,1024,1,32,33,17,3,40,17,2048,1029,48,2048,1056,33,37,32,1045,513]

theorem envBound44192 : H12AffineFastState.Bounded env44192 := by
  intro p hp
  have h : env44192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44185_44192 : H12AffineEnvironment.transform 11 49 env44185 = env44192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env44185 == env44192) = true)

theorem identity44192 : scanCanonicalize (H12AffineFastState.compose env44192 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound44192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44193 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1540,49,41,1045,0,35,1028,1540,1024,1,32,33,17,3,40,17,1540,1029,48,1540,1056,33,37,32,1045,513]

theorem envBound44193 : H12AffineFastState.Bounded env44193 := by
  intro p hp
  have h : env44193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44192_44193 : H12AffineEnvironment.transform 10 1540 env44192 = env44193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env44192 == env44193) = true)

def env44194 : List Nat := [2,4,8,16,32,16,9,37,512,52,560,49,41,33,0,35,48,560,52,1,32,33,17,3,40,17,560,49,48,560,20,33,37,32,33,513]

theorem envBound44194 : H12AffineFastState.Bounded env44194 := by
  intro p hp
  have h : env44194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44193_44194 : H12AffineEnvironment.transform 9 52 env44193 = env44194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44193 == env44194) = true)

theorem identity44194 : scanCanonicalize (H12AffineFastState.compose env44194 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound44194 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44195 : List Nat := [2,4,8,16,32,16,9,37,16,52,32,49,41,33,0,35,48,32,52,1,32,33,17,3,40,17,32,49,48,32,20,33,37,32,33,17]

theorem envBound44195 : H12AffineFastState.Bounded env44195 := by
  intro p hp
  have h : env44195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44194_44195 : H12AffineEnvironment.transform 8 16 env44194 = env44195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env44194 == env44195) = true)

def leafEnv44195 : List Nat := [2,4,8,16,32,16,9,37,16,52,32,49,41,33,0,35,48,32,52,1,32,33,17,3,20,40,1,17,32,49,48,32,20,33,37,32,4,34,33,17,1,32,0]

def active44195 : List Nat := [0,1,2,3,4]

def tree44195 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44195 : H12WitnessSearch.Good tree44195 := H12GlobalWitnessIndex.good

theorem leafIdentity44195 : H12AffineFastState.composeSystem env44195 rootObs = leafEnv44195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44195 rootObs == leafEnv44195) = true)

theorem terminalChecked44195 : H12PackedTerminal.terminalCheckFast leafEnv44195 active44195 tree44195 = true := by decide +kernel

def env44196 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,49,41,32,0,35,49,561,53,1,32,33,17,3,40,17,561,48,48,561,21,33,37,32,32,513]

theorem envBound44196 : H12AffineFastState.Bounded env44196 := by
  intro p hp
  have h : env44196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44193_44196 : H12AffineEnvironment.transform 9 53 env44193 = env44196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44193 == env44196) = true)

theorem identity44196 : scanCanonicalize (H12AffineFastState.compose env44196 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound44196 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44197 : List Nat := [2,4,8,16,27,16,9,30,512,14,522,10,18,27,0,24,10,522,14,1,27,26,17,3,19,17,522,11,11,522,21,26,30,27,27,513]

theorem envBound44197 : H12AffineFastState.Bounded env44197 := by
  intro p hp
  have h : env44197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44196_44197 : H12AffineEnvironment.transform 4 27 env44196 = env44197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env44196 == env44197) = true)

def leafEnv44197 : List Nat := [2,4,8,16,27,16,9,30,512,14,522,10,18,27,0,24,10,522,14,1,27,26,17,3,21,19,1,17,522,11,11,522,21,26,30,27,4,25,27,513,1,27,0]

def active44197 : List Nat := [0,1,2,3,8]

def tree44197 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44197 : H12WitnessSearch.Good tree44197 := H12GlobalWitnessIndex.good

theorem leafIdentity44197 : H12AffineFastState.composeSystem env44197 rootObs = leafEnv44197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44197 rootObs == leafEnv44197) = true)

theorem terminalChecked44197 : H12PackedTerminal.terminalCheckFast leafEnv44197 active44197 tree44197 = true := by decide +kernel

def env44198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,4194304,441641,98781,8328,65,4259061,436265,17665,32041,440549,4606309,256,21793,46212,499506]

theorem envBound44198 : H12AffineFastState.Bounded env44198 := by
  intro p hp
  have h : env44198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44144_44198 : H12AffineEnvironment.transform 22 441641 env44144 = env44198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441641 env44144 == env44198) = true)

def env44199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272512,441641,98781,8328,65,316533,436265,17665,32041,440549,156133,256,21793,46212,499506]

theorem envBound44199 : H12AffineFastState.Bounded env44199 := by
  intro p hp
  have h : env44199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44198_44199 : H12AffineEnvironment.transform 21 272512 env44198 = env44199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env44198 == env44199) = true)

theorem identity44199 : scanCanonicalize (H12AffineFastState.compose env44199 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound44199 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,437624,272512,441641,21763,8328,65,316533,436265,17665,32041,440549,156133,256,21793,46212,412652]

theorem envBound44200 : H12AffineFastState.Bounded env44200 := by
  intro p hp
  have h : env44200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44199_44200 : H12AffineEnvironment.transform 15 54494 env44199 = env44200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env44199 == env44200) = true)

def env44201 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,437624,272392,441641,21763,8192,65,316533,436265,17665,32041,440429,156013,256,21793,46092,412516]

theorem envBound44201 : H12AffineFastState.Bounded env44201 := by
  intro p hp
  have h : env44201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44200_44201 : H12AffineEnvironment.transform 6 8 env44200 = env44201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44200 == env44201) = true)

theorem identity44201 : scanCanonicalize (H12AffineFastState.compose env44201 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound44201 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env44202 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54358,131072,262144,1024,32769,429092,264532,433269,21763,348,65,316533,428405,17665,23669,432433,147505,256,21793,38224,412516]

theorem envBound44202 : H12AffineFastState.Bounded env44202 := by
  intro p hp
  have h : env44202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44201_44202 : H12AffineEnvironment.transform 12 348 env44201 = env44202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env44201 == env44202) = true)

theorem identity44202 : scanCanonicalize (H12AffineFastState.compose env44202 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 182629) := by decide +kernel

theorem selectedBound44202 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44203 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54358,131072,182629,1024,32769,17729,180273,21776,21763,348,65,138512,16400,17665,23669,20564,147505,256,21793,38224,33281]

theorem envBound44203 : H12AffineFastState.Bounded env44203 := by
  intro p hp
  have h : env44203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44202_44203 : H12AffineEnvironment.transform 17 182629 env44202 = env44203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182629 env44202 == env44203) = true)

theorem identity44203 : scanCanonicalize (H12AffineFastState.compose env44203 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound44203 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env44204 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54358,5393,56436,1024,32769,17729,54560,21776,21763,348,65,2049,16400,17665,23669,20564,21792,256,21793,38224,33281]

theorem envBound44204 : H12AffineFastState.Bounded env44204 := by
  intro p hp
  have h : env44204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44203_44204 : H12AffineEnvironment.transform 16 5393 env44203 = env44204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env44203 == env44204) = true)

theorem identity44204 : scanCanonicalize (H12AffineFastState.compose env44204 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound44204 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env44205 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,342,5393,2420,1024,21761,17729,32,21776,21763,348,65,2049,16400,17665,23669,20564,21792,256,21793,16464,22273]

theorem envBound44205 : H12AffineFastState.Bounded env44205 := by
  intro p hp
  have h : env44205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44204_44205 : H12AffineEnvironment.transform 14 21760 env44204 = env44205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env44204 == env44205) = true)

theorem identity44205 : scanCanonicalize (H12AffineFastState.compose env44205 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound44205 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env44206 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,89,16384,21509,83,5140,2161,1024,21508,17476,32,21525,21510,89,65,2049,16400,17412,23669,20564,21541,5,21540,16464,22020]

theorem envBound44206 : H12AffineFastState.Bounded env44206 := by
  intro p hp
  have h : env44206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44205_44206 : H12AffineEnvironment.transform 7 5 env44205 = env44206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env44205 == env44206) = true)

theorem identity44206 : scanCanonicalize (H12AffineFastState.compose env44206 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound44206 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44207 : List Nat := [2,4,8,16,32,64,8,5,512,20,2048,4096,89,16384,20497,83,4096,2161,20,20496,16464,32,20481,20498,89,65,2049,16400,16400,22625,20564,20529,5,20528,16464,21008]

theorem envBound44207 : H12AffineFastState.Bounded env44207 := by
  intro p hp
  have h : env44207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44206_44207 : H12AffineEnvironment.transform 9 20 env44206 = env44207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env44206 == env44207) = true)

theorem identity44207 : scanCanonicalize (H12AffineFastState.compose env44207 (packedSelected [0,1,3,5,7,8,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound44207 : packedSelected [0,1,3,5,7,8,12,14] rootPS < 2^1333 := by decide +kernel

def env44208 : List Nat := [2,4,8,16,32,64,8,5,512,20,2048,4096,89,2048,6161,83,4096,2161,20,6160,2128,32,6145,6162,89,65,2049,2064,2064,4193,6228,6193,5,6192,2128,6672]

theorem envBound44208 : H12AffineFastState.Bounded env44208 := by
  intro p hp
  have h : env44208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44207_44208 : H12AffineEnvironment.transform 13 2048 env44207 = env44208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env44207 == env44208) = true)

theorem identity44208 : scanCanonicalize (H12AffineFastState.compose env44208 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound44208 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env44209 : List Nat := [2,4,8,16,32,64,8,5,512,20,2048,544,89,2048,2609,83,544,2161,20,2608,2128,32,2593,2610,89,65,2049,2064,2064,577,2676,2577,5,2576,2128,2096]

theorem envBound44209 : H12AffineFastState.Bounded env44209 := by
  intro p hp
  have h : env44209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44208_44209 : H12AffineEnvironment.transform 11 544 env44208 = env44209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env44208 == env44209) = true)

theorem identity44209 : scanCanonicalize (H12AffineFastState.compose env44209 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound44209 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env44210 : List Nat := [2,4,8,16,32,64,8,5,512,20,528,544,89,528,33,83,544,609,20,32,576,32,49,34,89,65,529,512,512,577,100,1,5,0,576,544]

theorem envBound44210 : H12AffineFastState.Bounded env44210 := by
  intro p hp
  have h : env44210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44209_44210 : H12AffineEnvironment.transform 10 528 env44209 = env44210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env44209 == env44210) = true)

theorem identity44210 : scanCanonicalize (H12AffineFastState.compose env44210 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound44210 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env44211 : List Nat := [2,4,8,16,32,49,8,5,512,20,528,544,40,528,33,34,544,528,20,32,561,32,49,34,40,48,529,512,512,560,21,1,5,0,561,544]

theorem envBound44211 : H12AffineFastState.Bounded env44211 := by
  intro p hp
  have h : env44211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44210_44211 : H12AffineEnvironment.transform 5 49 env44210 = env44211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env44210 == env44211) = true)

theorem identity44211 : scanCanonicalize (H12AffineFastState.compose env44211 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound44211 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44212 : List Nat := [2,4,8,16,32,49,8,5,33,20,49,1,40,49,33,34,1,49,20,32,16,32,49,34,40,48,48,33,33,17,21,1,5,0,16,1]

theorem envBound44212 : H12AffineFastState.Bounded env44212 := by
  intro p hp
  have h : env44212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44211_44212 : H12AffineEnvironment.transform 8 33 env44211 = env44212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env44211 == env44212) = true)

def env44213 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,437624,272393,441641,21763,8193,65,316533,436265,17665,32041,440428,156012,256,21793,46093,412517]

theorem envBound44213 : H12AffineFastState.Bounded env44213 := by
  intro p hp
  have h : env44213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44200_44213 : H12AffineEnvironment.transform 6 9 env44200 = env44213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44200 == env44213) = true)

theorem identity44213 : scanCanonicalize (H12AffineFastState.compose env44213 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound44213 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env44214 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1024,32769,165201,32,169216,21763,8193,65,64604,163840,17665,32041,168005,156012,256,21793,46093,156492]

theorem envBound44214 : H12AffineFastState.Bounded env44214 := by
  intro p hp
  have h : env44214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44213_44214 : H12AffineEnvironment.transform 17 10281 env44213 = env44214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env44213 == env44214) = true)

theorem identity44214 : scanCanonicalize (H12AffineFastState.compose env44214 (packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound44214 : packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS < 2^1333 := by decide +kernel

def env44215 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,10281,1024,32769,17728,32,21777,21763,8193,65,64604,16401,17665,32041,20564,41341,256,21793,46093,41821]

theorem envBound44215 : H12AffineFastState.Bounded env44215 := by
  intro p hp
  have h : env44215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44214_44215 : H12AffineEnvironment.transform 16 49169 env44214 = env44215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env44214 == env44215) = true)

theorem identity44215 : scanCanonicalize (H12AffineFastState.compose env44215 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44215 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44216 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29963,24909,10281,1024,8541,17728,32,21777,21763,8193,65,23808,16401,17665,32041,20564,33,256,21793,5457,513]

theorem envBound44216 : H12AffineFastState.Bounded env44216 := by
  intro p hp
  have h : env44216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44215_44216 : H12AffineEnvironment.transform 14 8540 env44215 = env44216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44215 == env44216) = true)

theorem identity44216 : scanCanonicalize (H12AffineFastState.compose env44216 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44216 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env44217 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,29963,24860,10281,1024,8460,17681,32,21777,21763,8193,16,23808,16401,17665,32041,20485,33,256,21793,5376,513]

theorem envBound44217 : H12AffineFastState.Bounded env44217 := by
  intro p hp
  have h : env44217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44216_44217 : H12AffineEnvironment.transform 5 17 env44216 = env44217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44216 == env44217) = true)

theorem identity44217 : scanCanonicalize (H12AffineFastState.compose env44217 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound44217 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env44218 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,21510,16401,2340,1024,1,17681,32,21777,21763,268,16,23808,16401,17665,23588,20485,33,256,21793,5376,513]

theorem envBound44218 : H12AffineFastState.Bounded env44218 := by
  intro p hp
  have h : env44218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44217_44218 : H12AffineEnvironment.transform 12 269 env44217 = env44218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env44217 == env44218) = true)

def env44219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272513,441641,98781,8328,65,316532,436265,17665,32041,440549,156132,256,21793,46212,499506]

theorem envBound44219 : H12AffineFastState.Bounded env44219 := by
  intro p hp
  have h : env44219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44198_44219 : H12AffineEnvironment.transform 21 272513 env44198 = env44219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env44198 == env44219) = true)

theorem identity44219 : scanCanonicalize (H12AffineFastState.compose env44219 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223719) := by decide +kernel

theorem selectedBound44219 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,115871,213350,120014,98781,8328,65,245139,115150,17665,32041,119042,156132,256,21793,46212,63189]

theorem envBound44220 : H12AffineFastState.Bounded env44220 := by
  intro p hp
  have h : env44220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44219_44220 : H12AffineEnvironment.transform 17 223719 env44219 = env44220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223719 env44219 == env44220) = true)

def env44221 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223671,1024,32769,115871,213302,119966,98701,8328,17,245139,115102,17665,32041,119042,156084,256,21793,46212,63109]

theorem envBound44221 : H12AffineFastState.Bounded env44221 := by
  intro p hp
  have h : env44221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44220_44221 : H12AffineEnvironment.transform 5 16 env44220 = env44221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44220 == env44221) = true)

theorem identity44221 : scanCanonicalize (H12AffineFastState.compose env44221 (packedSelected [1,3,10,18,23,24,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound44221 : packedSelected [1,3,10,18,23,24,28,31] rootPS < 2^1333 := by decide +kernel

def env44222 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,35244,1024,32769,115871,41261,119966,98701,8328,17,23944,115102,17665,32041,119042,98735,256,21793,46212,63109]

theorem envBound44222 : H12AffineFastState.Bounded env44222 := by
  intro p hp
  have h : env44222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44221_44222 : H12AffineEnvironment.transform 16 122907 env44221 = env44222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env44221 == env44222) = true)

theorem identity44222 : scanCanonicalize (H12AffineFastState.compose env44222 (packedSelected [3,10,14,16,18,19,20,23,24,35] rootPS)) = affineNative (2^(15+1) ^^^ 62851) := by decide +kernel

theorem selectedBound44222 : packedSelected [3,10,14,16,18,19,20,23,24,35] rootPS < 2^1333 := by decide +kernel

def env44223 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,62851,5528,35244,1024,32769,12572,41261,8477,29710,8328,17,23944,13341,17665,32041,9345,29740,256,21793,46212,63109]

theorem envBound44223 : H12AffineFastState.Bounded env44223 := by
  intro p hp
  have h : env44223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44222_44223 : H12AffineEnvironment.transform 15 62851 env44222 = env44223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62851 env44222 == env44223) = true)

theorem identity44223 : scanCanonicalize (H12AffineFastState.compose env44223 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound44223 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env44224 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,32768,40971,5528,35244,1024,32769,12572,41261,8477,8582,8328,17,2048,13341,4233,10401,9345,8612,256,169,46212,41741]

theorem envBound44224 : H12AffineFastState.Bounded env44224 := by
  intro p hp
  have h : env44224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44223_44224 : H12AffineEnvironment.transform 13 5512 env44223 = env44224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env44223 == env44224) = true)

theorem identity44224 : scanCanonicalize (H12AffineFastState.compose env44224 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound44224 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env44225 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5512,32768,33030,5528,35244,1024,32769,4113,32800,16,139,389,17,2048,5392,4233,2476,1420,169,256,169,38281,33280]

theorem envBound44225 : H12AffineFastState.Bounded env44225 := by
  intro p hp
  have h : env44225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44224_44225 : H12AffineEnvironment.transform 12 269 env44224 = env44225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env44224 == env44225) = true)

theorem identity44225 : scanCanonicalize (H12AffineFastState.compose env44225 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1719) := by decide +kernel

theorem selectedBound44225 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env44226 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1719,4096,269,5512,32768,33030,5528,34587,1024,32769,4113,32800,16,139,389,17,1719,5392,4233,1819,1420,169,256,169,38281,33280]

theorem envBound44226 : H12AffineFastState.Bounded env44226 := by
  intro p hp
  have h : env44226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44225_44226 : H12AffineEnvironment.transform 10 1719 env44225 = env44226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1719 env44225 == env44226) = true)

theorem identity44226 : scanCanonicalize (H12AffineFastState.compose env44226 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44226 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44227 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1719,4096,40,5293,32768,32803,5309,34366,1024,32769,4113,32800,16,139,160,17,1719,5173,4233,1598,1193,169,37,169,38060,33280]

theorem envBound44227 : H12AffineFastState.Bounded env44227 := by
  intro p hp
  have h : env44227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44226_44227 : H12AffineEnvironment.transform 7 37 env44226 = env44227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44226 == env44227) = true)

theorem identity44227 : scanCanonicalize (H12AffineFastState.compose env44227 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound44227 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env44228 : List Nat := [2,4,8,16,32,16,128,37,512,543,168,4096,40,4786,32768,32803,4770,32801,543,32769,4113,32800,16,139,160,17,168,4650,4233,33,694,169,37,169,37555,33280]

theorem envBound44228 : H12AffineFastState.Bounded env44228 := by
  intro p hp
  have h : env44228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44227_44228 : H12AffineEnvironment.transform 9 543 env44227 = env44228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env44227 == env44228) = true)

theorem identity44228 : scanCanonicalize (H12AffineFastState.compose env44228 (packedSelected [2,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound44228 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env44229 : List Nat := [2,4,8,16,32,16,128,37,512,543,168,4096,40,4786,137,170,4770,168,543,136,4113,169,16,139,160,17,168,4650,4233,33,694,169,37,169,4666,649]

theorem envBound44229 : H12AffineFastState.Bounded env44229 := by
  intro p hp
  have h : env44229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44228_44229 : H12AffineEnvironment.transform 14 137 env44228 = env44229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env44228 == env44229) = true)

theorem identity44229 : scanCanonicalize (H12AffineFastState.compose env44229 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound44229 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env44230 : List Nat := [2,4,8,16,32,16,128,37,512,543,168,539,40,169,137,170,185,168,543,136,522,169,16,139,160,17,168,49,658,33,694,169,37,169,33,649]

theorem envBound44230 : H12AffineFastState.Bounded env44230 := by
  intro p hp
  have h : env44230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44229_44230 : H12AffineEnvironment.transform 11 539 env44229 = env44230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env44229 == env44230) = true)

theorem identity44230 : scanCanonicalize (H12AffineFastState.compose env44230 (packedSelected [1,2,3,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound44230 : packedSelected [1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env44231 : List Nat := [2,4,8,16,20,16,128,17,512,543,156,539,28,157,137,158,141,156,543,136,522,157,16,139,148,17,156,5,658,21,642,157,17,157,21,649]

theorem envBound44231 : H12AffineFastState.Bounded env44231 := by
  intro p hp
  have h : env44231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44230_44231 : H12AffineEnvironment.transform 4 20 env44230 = env44231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env44230 == env44231) = true)

theorem identity44231 : scanCanonicalize (H12AffineFastState.compose env44231 (packedSelected [0,2,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound44231 : packedSelected [0,2,3,6] rootPS < 2^1333 := by decide +kernel

def env44232 : List Nat := [2,4,8,7,3,7,128,6,512,520,139,524,11,138,137,137,141,139,520,136,522,138,7,139,131,6,139,5,645,2,642,138,6,138,2,649]

theorem envBound44232 : H12AffineFastState.Bounded env44232 := by
  intro p hp
  have h : env44232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44231_44232 : H12AffineEnvironment.transform 3 7 env44231 = env44232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env44231 == env44232) = true)

theorem identity44232 : scanCanonicalize (H12AffineFastState.compose env44232 (packedSelected [2,10] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound44232 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env44233 : List Nat := [2,4,8,7,3,7,128,6,9,1,139,5,11,138,137,137,141,139,1,136,3,138,7,139,131,6,139,5,140,2,139,138,6,138,2,128]

theorem envBound44233 : H12AffineFastState.Bounded env44233 := by
  intro p hp
  have h : env44233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44232_44233 : H12AffineEnvironment.transform 8 9 env44232 = env44233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env44232 == env44233) = true)

theorem identity44233 : scanCanonicalize (H12AffineFastState.compose env44233 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound44233 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env44234 : List Nat := [2,4,8,7,3,7,11,6,9,1,0,5,11,1,2,2,6,0,1,3,3,1,7,0,8,6,0,5,7,2,0,1,6,1,2,11]

theorem envBound44234 : H12AffineFastState.Bounded env44234 := by
  intro p hp
  have h : env44234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44233_44234 : H12AffineEnvironment.transform 6 11 env44233 = env44234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env44233 == env44234) = true)

theorem identity44234 : scanCanonicalize (H12AffineFastState.compose env44234 (packedSelected [0,3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound44234 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env44235 : List Nat := [0,4,8,5,1,5,9,4,9,1,0,5,9,1,0,0,4,0,1,1,1,1,5,0,8,4,0,5,5,0,0,1,4,1,0,9]

theorem envBound44235 : H12AffineFastState.Bounded env44235 := by
  intro p hp
  have h : env44235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44234_44235 : H12AffineEnvironment.transform 0 0 env44234 = env44235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env44234 == env44235) = true)

theorem identity44235 : scanCanonicalize (H12AffineFastState.compose env44235 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44235 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44236 : List Nat := [0,4,5,5,1,5,4,4,4,1,0,5,4,1,0,0,4,0,1,1,1,1,5,0,5,4,0,5,5,0,0,1,4,1,0,4]

theorem envBound44236 : H12AffineFastState.Bounded env44236 := by
  intro p hp
  have h : env44236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44235_44236 : H12AffineEnvironment.transform 2 5 env44235 = env44236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44235 == env44236) = true)

theorem identity44236 : scanCanonicalize (H12AffineFastState.compose env44236 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound44236 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44237 : List Nat := [0,0,1,1,1,1,0,0,0,1,0,1,0,1,0,0,0,0,1,1,1,1,1,0,1,0,0,1,1,0,0,1,0,1,0,0]

theorem envBound44237 : H12AffineFastState.Bounded env44237 := by
  intro p hp
  have h : env44237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44236_44237 : H12AffineEnvironment.transform 1 0 env44236 = env44237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env44236 == env44237) = true)

def env44238 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223670,1024,32769,115871,213303,119967,98700,8328,16,245139,115103,17665,32041,119042,156085,256,21793,46212,63108]

theorem envBound44238 : H12AffineFastState.Bounded env44238 := by
  intro p hp
  have h : env44238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44220_44238 : H12AffineEnvironment.transform 5 17 env44220 = env44238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44220 == env44238) = true)

theorem identity44238 : scanCanonicalize (H12AffineFastState.compose env44238 (packedSelected [1,3,10,18,23,24,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound44238 : packedSelected [1,3,10,18,23,24,28,31] rootPS < 2^1333 := by decide +kernel

def env44239 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54278,131072,179632,1024,32769,4249,169265,153,21898,8328,16,158101,5529,17665,32041,1284,156085,256,21793,46212,63108]

theorem envBound44239 : H12AffineFastState.Bounded env44239 := by
  intro p hp
  have h : env44239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44238_44239 : H12AffineEnvironment.transform 15 54278 env44238 = env44239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env44238 == env44239) = true)

theorem identity44239 : scanCanonicalize (H12AffineFastState.compose env44239 (packedSelected [0,4,7,16,17,19,20,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound44239 : packedSelected [0,4,7,16,17,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env44240 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,137,21647,131072,146745,1024,136,4249,136632,153,21898,8328,16,158101,5529,17665,32041,1284,156085,256,21793,13325,30221]

theorem envBound44240 : H12AffineFastState.Bounded env44240 := by
  intro p hp
  have h : env44240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44239_44240 : H12AffineEnvironment.transform 14 137 env44239 = env44240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env44239 == env44240) = true)

theorem identity44240 : scanCanonicalize (H12AffineFastState.compose env44240 (packedSelected [1,10,16,17,19,20,28] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound44240 : packedSelected [1,10,16,17,19,20,28] rootPS < 2^1333 := by decide +kernel

def env44241 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,137,262,131072,146745,1024,136,4249,136632,153,3,8328,16,146460,5529,4232,10400,1284,144444,256,168,13325,9092]

theorem envBound44241 : H12AffineFastState.Bounded env44241 := by
  intro p hp
  have h : env44241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44240_44241 : H12AffineEnvironment.transform 13 5513 env44240 = env44241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env44240 == env44241) = true)

theorem identity44241 : scanCanonicalize (H12AffineFastState.compose env44241 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound44241 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env44242 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,137,262,13461,2476,1024,136,4249,8493,153,3,8328,16,2185,5529,4232,10400,1284,169,256,168,13325,9092]

theorem envBound44242 : H12AffineFastState.Bounded env44242 := by
  intro p hp
  have h : env44242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44241_44242 : H12AffineEnvironment.transform 16 13461 env44241 = env44242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env44241 == env44242) = true)

theorem identity44242 : scanCanonicalize (H12AffineFastState.compose env44242 (packedSelected [3,4,5,9,10,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound44242 : packedSelected [3,4,5,9,10,14,15,16] rootPS < 2^1333 := by decide +kernel

def env44243 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5156,137,171,13461,2049,1024,136,4249,8320,153,3,8328,16,2185,5172,4232,10400,1193,169,173,168,13325,8745]

theorem envBound44243 : H12AffineFastState.Bounded env44243 := by
  intro p hp
  have h : env44243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44242_44243 : H12AffineEnvironment.transform 7 173 env44242 = env44243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env44242 == env44243) = true)

theorem identity44243 : scanCanonicalize (H12AffineFastState.compose env44243 (packedSelected [0,4,7,9,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound44243 : packedSelected [0,4,7,9,11,14] rootPS < 2^1333 := by decide +kernel

def env44244 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,161,5156,137,171,5172,2049,1024,136,4249,33,153,3,41,16,2185,5172,4232,2049,1193,169,173,168,5292,648]

theorem envBound44244 : H12AffineFastState.Bounded env44244 := by
  intro p hp
  have h : env44244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44243_44244 : H12AffineEnvironment.transform 12 161 env44243 = env44244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env44243 == env44244) = true)

theorem identity44244 : scanCanonicalize (H12AffineFastState.compose env44244 (packedSelected [4,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound44244 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env44245 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8,5156,32,2,5172,2049,1024,33,4144,33,48,3,41,16,2080,5172,4129,2049,1024,0,4,1,5125,545]

theorem envBound44245 : H12AffineFastState.Bounded env44245 := by
  intro p hp
  have h : env44245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44244_44245 : H12AffineEnvironment.transform 6 41 env44244 = env44245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env44244 == env44245) = true)

def env44246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,4194304,8388608,8862965,8328,65,4259060,8393985,8845352,8830976,440548,12645453,256,21792,46213,499507]

theorem envBound44246 : H12AffineFastState.Bounded env44246 := by
  intro p hp
  have h : env44246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44143_44246 : H12AffineEnvironment.transform 23 8862965 env44143 = env44246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862965 env44143 == env44246) = true)

def env44247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,4194304,441640,98781,8328,65,4259060,436265,17664,32040,440548,4606309,256,21792,46213,499507]

theorem envBound44247 : H12AffineFastState.Bounded env44247 := by
  intro p hp
  have h : env44247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44246_44247 : H12AffineEnvironment.transform 22 441640 env44246 = env44247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441640 env44246 == env44247) = true)

def env44248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272512,441640,98781,8328,65,316532,436265,17664,32040,440548,156133,256,21792,46213,499507]

theorem envBound44248 : H12AffineFastState.Bounded env44248 := by
  intro p hp
  have h : env44248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44247_44248 : H12AffineEnvironment.transform 21 272512 env44247 = env44248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env44247 == env44248) = true)

theorem identity44248 : scanCanonicalize (H12AffineFastState.compose env44248 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149997) := by decide +kernel

theorem selectedBound44248 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,58517,156013,62661,98781,8328,65,171417,57796,17664,32040,61705,156133,256,21792,46213,120542]

theorem envBound44249 : H12AffineFastState.Bounded env44249 := by
  intro p hp
  have h : env44249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44248_44249 : H12AffineEnvironment.transform 17 149997 env44248 = env44249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149997 env44248 == env44249) = true)

def env44250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,56573,1024,32769,58517,62589,62661,98781,8328,65,2185,57796,17664,32040,61705,62709,256,21792,46213,120542]

theorem envBound44250 : H12AffineFastState.Bounded env44250 := by
  intro p hp
  have h : env44250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44249_44250 : H12AffineEnvironment.transform 16 38160 env44249 = env44250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env44249 == env44250) = true)

def env44251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38160,35325,1024,32769,45461,41341,41413,98781,8328,65,2185,46276,4096,10280,41993,41461,256,32,46213,99294]

theorem envBound44251 : H12AffineFastState.Bounded env44251 := by
  intro p hp
  have h : env44251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44250_44251 : H12AffineEnvironment.transform 13 5376 env44250 = env44251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44250 == env44251) = true)

theorem identity44251 : scanCanonicalize (H12AffineFastState.compose env44251 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound44251 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13508,10281,1024,8661,4161,169,17,73737,8328,65,2185,5392,4096,10280,1501,33,256,32,5457,74250]

theorem envBound44252 : H12AffineFastState.Bounded env44252 := by
  intro p hp
  have h : env44252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44251_44252 : H12AffineEnvironment.transform 14 8660 env44251 = env44252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env44251 == env44252) = true)

theorem identity44252 : scanCanonicalize (H12AffineFastState.compose env44252 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound44252 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env44253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,80,65536,5440,2477,1024,81,4161,169,17,65933,268,65,2185,5392,4096,2476,1501,33,256,32,5457,66446]

theorem envBound44253 : H12AffineFastState.Bounded env44253 := by
  intro p hp
  have h : env44253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44252_44253 : H12AffineEnvironment.transform 12 388 env44252 = env44253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env44252 == env44253) = true)

theorem identity44253 : scanCanonicalize (H12AffineFastState.compose env44253 (packedSelected [0,1,2,6,7,8,11,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound44253 : packedSelected [0,1,2,6,7,8,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env44254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,80,478,5440,2477,1024,81,4161,169,17,83,268,65,2185,5392,4096,2476,1501,33,256,32,5457,592]

theorem envBound44254 : H12AffineFastState.Bounded env44254 := by
  intro p hp
  have h : env44254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44253_44254 : H12AffineEnvironment.transform 15 478 env44253 = env44254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env44253 == env44254) = true)

theorem identity44254 : scanCanonicalize (H12AffineFastState.compose env44254 (packedSelected [4,6,9,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44254 : packedSelected [4,6,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env44255 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,1,399,5393,2477,1024,0,4112,169,17,2,268,16,2185,5392,4096,2476,1420,33,256,32,5376,513]

theorem envBound44255 : H12AffineFastState.Bounded env44255 := by
  intro p hp
  have h : env44255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44254_44255 : H12AffineEnvironment.transform 5 17 env44254 = env44255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44254 == env44255) = true)

theorem identity44255 : scanCanonicalize (H12AffineFastState.compose env44255 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound44255 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env44256 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,538,388,1818,1,399,1803,2477,1024,0,522,169,17,2,268,16,2185,1802,538,2476,1420,33,256,32,1818,513]

theorem envBound44256 : H12AffineFastState.Bounded env44256 := by
  intro p hp
  have h : env44256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44255_44256 : H12AffineEnvironment.transform 11 538 env44255 = env44256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env44255 == env44256) = true)

theorem identity44256 : scanCanonicalize (H12AffineFastState.compose env44256 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound44256 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env44257 : List Nat := [2,4,8,16,32,17,128,256,11,1024,2048,17,388,1297,1,399,1280,2477,1024,0,1,169,17,2,268,16,2185,1281,17,2476,1420,33,256,32,1297,10]

theorem envBound44257 : H12AffineFastState.Bounded env44257 := by
  intro p hp
  have h : env44257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44256_44257 : H12AffineEnvironment.transform 8 11 env44256 = env44257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env44256 == env44257) = true)

theorem identity44257 : scanCanonicalize (H12AffineFastState.compose env44257 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound44257 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44258 : List Nat := [2,4,8,16,32,17,128,256,11,1024,292,17,388,1297,1,399,1280,137,1024,0,1,169,17,2,268,16,429,1281,17,136,1420,33,256,32,1297,10]

theorem envBound44258 : H12AffineFastState.Bounded env44258 := by
  intro p hp
  have h : env44258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44257_44258 : H12AffineEnvironment.transform 10 292 env44257 = env44258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env44257 == env44258) = true)

theorem identity44258 : scanCanonicalize (H12AffineFastState.compose env44258 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound44258 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env44259 : List Nat := [2,4,8,16,32,17,128,256,11,189,292,17,388,428,1,399,445,137,189,0,1,169,17,2,268,16,429,444,17,136,305,33,256,32,428,10]

theorem envBound44259 : H12AffineFastState.Bounded env44259 := by
  intro p hp
  have h : env44259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44258_44259 : H12AffineEnvironment.transform 9 189 env44258 = env44259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env44258 == env44259) = true)

theorem identity44259 : scanCanonicalize (H12AffineFastState.compose env44259 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44259 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env44260 : List Nat := [2,4,8,16,0,17,128,256,11,157,260,17,388,396,1,399,413,137,157,0,1,137,17,2,268,16,397,412,17,136,273,1,256,0,396,10]

theorem envBound44260 : H12AffineFastState.Bounded env44260 := by
  intro p hp
  have h : env44260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44259_44260 : H12AffineEnvironment.transform 4 0 env44259 = env44260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44259 == env44260) = true)

theorem identity44260 : scanCanonicalize (H12AffineFastState.compose env44260 (packedSelected [2,11] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44260 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env44261 : List Nat := [2,4,8,16,0,17,128,4,11,157,0,17,128,136,1,139,153,137,157,0,1,137,17,2,8,16,137,152,17,136,21,1,4,0,136,10]

theorem envBound44261 : H12AffineFastState.Bounded env44261 := by
  intro p hp
  have h : env44261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44260_44261 : H12AffineEnvironment.transform 7 4 env44260 = env44261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44260 == env44261) = true)

theorem identity44261 : scanCanonicalize (H12AffineFastState.compose env44261 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44261 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44262 : List Nat := [2,4,8,16,0,17,9,4,11,20,0,17,9,1,1,2,16,0,20,0,1,0,17,2,8,16,0,17,17,1,21,1,4,0,1,10]

theorem envBound44262 : H12AffineFastState.Bounded env44262 := by
  intro p hp
  have h : env44262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44261_44262 : H12AffineEnvironment.transform 6 9 env44261 = env44262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44261 == env44262) = true)

theorem identity44262 : scanCanonicalize (H12AffineFastState.compose env44262 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound44262 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44263 : List Nat := [2,4,6,16,0,17,7,4,5,20,0,17,7,1,1,2,16,0,20,0,1,0,17,2,6,16,0,17,17,1,21,1,4,0,1,4]

theorem envBound44263 : H12AffineFastState.Bounded env44263 := by
  intro p hp
  have h : env44263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44262_44263 : H12AffineEnvironment.transform 2 6 env44262 = env44263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env44262 == env44263) = true)

theorem identity44263 : scanCanonicalize (H12AffineFastState.compose env44263 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound44263 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44264 : List Nat := [2,4,6,3,0,2,7,4,5,7,0,2,7,1,1,2,3,0,7,0,1,0,2,2,6,3,0,2,2,1,6,1,4,0,1,4]

theorem envBound44264 : H12AffineFastState.Bounded env44264 := by
  intro p hp
  have h : env44264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44263_44264 : H12AffineEnvironment.transform 3 3 env44263 = env44264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env44263 == env44264) = true)

def env44265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38160,35324,1024,32769,45460,41340,41412,98781,8328,65,2185,46277,4097,10281,41992,41460,256,33,46213,99295]

theorem envBound44265 : H12AffineFastState.Bounded env44265 := by
  intro p hp
  have h : env44265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44250_44265 : H12AffineEnvironment.transform 13 5377 env44250 = env44265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44250 == env44265) = true)

theorem identity44265 : scanCanonicalize (H12AffineFastState.compose env44265 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44265 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,13388,10400,1024,8541,4296,32,152,73857,8328,65,2185,5529,4097,10281,1364,168,256,33,5593,74371]

theorem envBound44266 : H12AffineFastState.Bounded env44266 := by
  intro p hp
  have h : env44266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44265_44266 : H12AffineEnvironment.transform 14 8540 env44265 = env44266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44265 == env44266) = true)

theorem identity44266 : scanCanonicalize (H12AffineFastState.compose env44266 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound44266 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env44267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8322,13388,10400,1024,8541,4296,32,152,3,8328,65,2185,5529,4097,10281,1364,168,256,33,5593,513]

theorem envBound44267 : H12AffineFastState.Bounded env44267 := by
  intro p hp
  have h : env44267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44266_44267 : H12AffineEnvironment.transform 15 8322 env44266 = env44267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env44266 == env44267) = true)

theorem identity44267 : scanCanonicalize (H12AffineFastState.compose env44267 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound44267 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5377,216,262,5576,2340,1024,217,4296,32,152,3,268,65,2185,5529,4097,2477,1364,168,256,33,5593,513]

theorem envBound44268 : H12AffineFastState.Bounded env44268 := by
  intro p hp
  have h : env44268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44267_44268 : H12AffineEnvironment.transform 12 388 env44267 = env44268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env44267 == env44268) = true)

theorem identity44268 : scanCanonicalize (H12AffineFastState.compose env44268 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44268 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env44269 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,80,262,5440,2340,1024,81,4160,32,16,3,268,65,2049,5393,4097,2341,1364,32,256,33,5457,513]

theorem envBound44269 : H12AffineFastState.Bounded env44269 := by
  intro p hp
  have h : env44269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44268_44269 : H12AffineEnvironment.transform 6 8 env44268 = env44269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44268 == env44269) = true)

theorem identity44269 : scanCanonicalize (H12AffineFastState.compose env44269 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound44269 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env44270 : List Nat := [2,4,8,16,32,64,8,256,512,1024,820,4096,268,5377,80,262,5440,528,1024,81,4160,32,16,3,268,65,821,5393,4097,529,1364,32,256,33,5457,513]

theorem envBound44270 : H12AffineFastState.Bounded env44270 := by
  intro p hp
  have h : env44270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44269_44270 : H12AffineEnvironment.transform 10 820 env44269 = env44270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env44269 == env44270) = true)

theorem identity44270 : scanCanonicalize (H12AffineFastState.compose env44270 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound44270 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44271 : List Nat := [2,4,8,16,32,64,8,5,512,1024,561,4096,9,5124,80,3,5189,528,1024,81,4160,32,16,3,9,65,560,5140,4097,529,1105,32,5,33,5204,513]

theorem envBound44271 : H12AffineFastState.Bounded env44271 := by
  intro p hp
  have h : env44271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44270_44271 : H12AffineEnvironment.transform 7 5 env44270 = env44271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env44270 == env44271) = true)

theorem identity44271 : scanCanonicalize (H12AffineFastState.compose env44271 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound44271 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44272 : List Nat := [2,4,8,16,16,64,8,5,512,1024,513,4096,9,5124,80,3,5189,528,1024,81,4160,16,16,3,9,65,512,5140,4097,529,1105,16,5,17,5204,513]

theorem envBound44272 : H12AffineFastState.Bounded env44272 := by
  intro p hp
  have h : env44272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44271_44272 : H12AffineEnvironment.transform 4 16 env44271 = env44272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env44271 == env44272) = true)

theorem identity44272 : scanCanonicalize (H12AffineFastState.compose env44272 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound44272 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env44273 : List Nat := [2,4,8,16,16,64,8,5,512,69,513,4096,9,4161,80,3,4096,528,69,81,4160,16,16,3,9,65,512,4177,4097,529,20,16,5,17,4113,513]

theorem envBound44273 : H12AffineFastState.Bounded env44273 := by
  intro p hp
  have h : env44273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44272_44273 : H12AffineEnvironment.transform 9 69 env44272 = env44273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env44272 == env44273) = true)

theorem identity44273 : scanCanonicalize (H12AffineFastState.compose env44273 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound44273 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env44274 : List Nat := [2,4,8,16,16,1,8,5,512,4,513,4096,9,4096,17,3,4096,528,4,16,4097,16,16,3,9,0,512,4112,4097,529,20,16,5,17,4113,513]

theorem envBound44274 : H12AffineFastState.Bounded env44274 := by
  intro p hp
  have h : env44274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44273_44274 : H12AffineEnvironment.transform 5 1 env44273 = env44274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env44273 == env44274) = true)

theorem identity44274 : scanCanonicalize (H12AffineFastState.compose env44274 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound44274 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env44275 : List Nat := [2,4,8,16,16,1,8,5,512,4,513,528,9,528,17,3,528,528,4,16,529,16,16,3,9,0,512,512,529,529,20,16,5,17,513,513]

theorem envBound44275 : H12AffineFastState.Bounded env44275 := by
  intro p hp
  have h : env44275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44274_44275 : H12AffineEnvironment.transform 11 528 env44274 = env44275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env44274 == env44275) = true)

def env44276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,56572,1024,32769,58517,62588,62661,98781,8328,65,2184,57796,17664,32040,61705,62708,256,21792,46213,120542]

theorem envBound44276 : H12AffineFastState.Bounded env44276 := by
  intro p hp
  have h : env44276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44249_44276 : H12AffineEnvironment.transform 16 38161 env44249 = env44276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env44249 == env44276) = true)

def env44277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38161,35324,1024,32769,45461,41340,41413,98781,8328,65,2184,46276,4096,10280,41993,41460,256,32,46213,99294]

theorem envBound44277 : H12AffineFastState.Bounded env44277 := by
  intro p hp
  have h : env44277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44276_44277 : H12AffineEnvironment.transform 13 5376 env44276 = env44277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44276 == env44277) = true)

theorem identity44277 : scanCanonicalize (H12AffineFastState.compose env44277 (packedSelected [1,4,7,9,16,20,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 41091) := by decide +kernel

theorem selectedBound44277 : packedSelected [1,4,7,9,16,20,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env44278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,41091,38161,35324,1024,32769,45461,41340,41413,8542,8328,65,2184,46276,4096,10280,41993,41460,256,32,46213,9053]

theorem envBound44278 : H12AffineFastState.Bounded env44278 := by
  intro p hp
  have h : env44278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44277_44278 : H12AffineEnvironment.transform 15 41091 env44277 = env44278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41091 env44277 == env44278) = true)

theorem identity44278 : scanCanonicalize (H12AffineFastState.compose env44278 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound44278 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,32768,33110,38161,35324,1024,32769,36928,32937,32784,139,349,65,2184,38161,4096,2557,34268,32801,256,32,38224,648]

theorem envBound44279 : H12AffineFastState.Bounded env44279 := by
  intro p hp
  have h : env44279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44278_44279 : H12AffineEnvironment.transform 12 469 env44278 = env44279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env44278 == env44279) = true)

theorem identity44279 : scanCanonicalize (H12AffineFastState.compose env44279 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound44279 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env44280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,80,262,5441,2476,1024,81,4112,249,64,139,349,65,2184,5441,4096,2557,1420,113,256,32,5376,648]

theorem envBound44280 : H12AffineFastState.Bounded env44280 := by
  intro p hp
  have h : env44280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44279_44280 : H12AffineEnvironment.transform 14 80 env44279 = env44280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env44279 == env44280) = true)

theorem identity44280 : scanCanonicalize (H12AffineFastState.compose env44280 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound44280 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env44281 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,4096,469,4404,80,262,4469,2476,52,81,4112,249,64,139,349,65,2184,4469,4096,2557,440,113,256,32,4404,648]

theorem envBound44281 : H12AffineFastState.Bounded env44281 := by
  intro p hp
  have h : env44281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44280_44281 : H12AffineEnvironment.transform 9 52 env44280 = env44281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44280 == env44281) = true)

theorem identity44281 : scanCanonicalize (H12AffineFastState.compose env44281 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound44281 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env44282 : List Nat := [2,4,8,16,32,64,89,256,512,52,2048,4096,268,4404,80,262,4469,2421,52,81,4112,32,64,82,349,65,2129,4469,4096,2340,353,113,256,32,4404,593]

theorem envBound44282 : H12AffineFastState.Bounded env44282 := by
  intro p hp
  have h : env44282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44281_44282 : H12AffineEnvironment.transform 6 89 env44281 = env44282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env44281 == env44282) = true)

theorem identity44282 : scanCanonicalize (H12AffineFastState.compose env44282 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound44282 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env44283 : List Nat := [2,4,8,16,32,64,89,52,512,52,2048,4096,56,4096,80,50,4161,2113,52,81,4112,32,64,82,105,65,2129,4161,4096,2064,85,113,52,32,4096,593]

theorem envBound44283 : H12AffineFastState.Bounded env44283 := by
  intro p hp
  have h : env44283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44282_44283 : H12AffineEnvironment.transform 7 52 env44282 = env44283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env44282 == env44283) = true)

theorem identity44283 : scanCanonicalize (H12AffineFastState.compose env44283 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 593) := by decide +kernel

theorem selectedBound44283 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env44284 : List Nat := [2,4,8,16,32,64,89,52,512,52,593,4096,56,4096,80,50,4161,528,52,81,4112,32,64,82,105,65,512,4161,4096,577,85,113,52,32,4096,593]

theorem envBound44284 : H12AffineFastState.Bounded env44284 := by
  intro p hp
  have h : env44284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44283_44284 : H12AffineEnvironment.transform 10 593 env44283 = env44284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 593 env44283 == env44284) = true)

def env44285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38161,35325,1024,32769,45460,41341,41412,98781,8328,65,2184,46277,4097,10281,41992,41461,256,33,46213,99295]

theorem envBound44285 : H12AffineFastState.Bounded env44285 := by
  intro p hp
  have h : env44285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44276_44285 : H12AffineEnvironment.transform 13 5377 env44276 = env44285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44276 == env44285) = true)

theorem identity44285 : scanCanonicalize (H12AffineFastState.compose env44285 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44285 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44286 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,38161,35188,1024,32769,45341,41341,41293,98644,8193,65,2049,46156,4097,10281,41992,41340,256,33,46092,99158]

theorem envBound44286 : H12AffineFastState.Bounded env44286 := by
  intro p hp
  have h : env44286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44285_44286 : H12AffineEnvironment.transform 6 9 env44285 = env44286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44285 == env44286) = true)

theorem identity44286 : scanCanonicalize (H12AffineFastState.compose env44286 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44286 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env44287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,13388,10281,1024,8540,4160,32,16,73737,8193,65,2049,5393,4097,10281,1365,33,256,33,5457,74251]

theorem envBound44287 : H12AffineFastState.Bounded env44287 := by
  intro p hp
  have h : env44287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44286_44287 : H12AffineEnvironment.transform 14 8541 env44286 = env44287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44286 == env44287) = true)

theorem identity44287 : scanCanonicalize (H12AffineFastState.compose env44287 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound44287 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,2,13388,10281,1024,8540,4160,32,16,8203,8193,65,2049,5393,4097,10281,1365,33,256,33,5457,8713]

theorem envBound44288 : H12AffineFastState.Bounded env44288 := by
  intro p hp
  have h : env44288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44287_44288 : H12AffineEnvironment.transform 15 2 env44287 = env44288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env44287 == env44288) = true)

theorem identity44288 : scanCanonicalize (H12AffineFastState.compose env44288 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound44288 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env44289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,2,5392,2421,1024,0,4160,32,16,343,349,65,2049,5393,4097,2421,1365,33,256,33,5457,853]

theorem envBound44289 : H12AffineFastState.Bounded env44289 := by
  intro p hp
  have h : env44289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44288_44289 : H12AffineEnvironment.transform 12 348 env44288 = env44289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env44288 == env44289) = true)

theorem identity44289 : scanCanonicalize (H12AffineFastState.compose env44289 (packedSelected [0,2,7,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44289 : packedSelected [0,2,7,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env44290 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,2,5392,2340,1024,0,4113,32,16,262,268,16,2049,5393,4097,2340,1284,33,256,33,5376,772]

theorem envBound44290 : H12AffineFastState.Bounded env44290 := by
  intro p hp
  have h : env44290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44289_44290 : H12AffineEnvironment.transform 5 17 env44289 = env44290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44289 == env44290) = true)

theorem identity44290 : scanCanonicalize (H12AffineFastState.compose env44290 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3361) := by decide +kernel

theorem selectedBound44290 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env44291 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3361,269,2080,1,2,2097,2340,1024,0,3376,32,16,262,268,16,2049,2096,3360,2340,1284,33,256,33,2081,772]

theorem envBound44291 : H12AffineFastState.Bounded env44291 := by
  intro p hp
  have h : env44291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44290_44291 : H12AffineEnvironment.transform 11 3361 env44290 = env44291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3361 env44290 == env44291) = true)

theorem identity44291 : scanCanonicalize (H12AffineFastState.compose env44291 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound44291 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env44292 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2324,269,2080,1,2,2097,2340,53,0,2309,32,16,262,268,16,2049,2096,2325,2340,305,33,256,33,2081,772]

theorem envBound44292 : H12AffineFastState.Bounded env44292 := by
  intro p hp
  have h : env44292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44291_44292 : H12AffineEnvironment.transform 9 53 env44291 = env44292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44291 == env44292) = true)

theorem identity44292 : scanCanonicalize (H12AffineFastState.compose env44292 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound44292 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env44293 : List Nat := [2,4,8,16,32,17,9,256,512,53,260,16,269,292,1,2,309,32,53,0,1,32,16,262,268,16,261,308,17,32,305,33,256,33,293,772]

theorem envBound44293 : H12AffineFastState.Bounded env44293 := by
  intro p hp
  have h : env44293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44292_44293 : H12AffineEnvironment.transform 10 260 env44292 = env44293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env44292 == env44293) = true)

theorem identity44293 : scanCanonicalize (H12AffineFastState.compose env44293 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44293 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env44294 : List Nat := [2,4,8,16,1,17,9,256,512,20,260,16,269,261,1,2,276,1,20,0,1,1,16,262,268,16,261,277,17,1,272,0,256,0,260,772]

theorem envBound44294 : H12AffineFastState.Bounded env44294 := by
  intro p hp
  have h : env44294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44293_44294 : H12AffineEnvironment.transform 4 1 env44293 = env44294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44293 == env44294) = true)

theorem identity44294 : scanCanonicalize (H12AffineFastState.compose env44294 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound44294 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env44295 : List Nat := [2,4,8,16,1,17,9,256,277,20,260,16,269,261,1,2,276,1,20,0,1,1,16,262,268,16,261,277,17,1,272,0,256,0,260,17]

theorem envBound44295 : H12AffineFastState.Bounded env44295 := by
  intro p hp
  have h : env44295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44294_44295 : H12AffineEnvironment.transform 8 277 env44294 = env44295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env44294 == env44295) = true)

def env44296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272513,441640,98781,8328,65,316533,436265,17664,32040,440548,156132,256,21792,46213,499507]

theorem envBound44296 : H12AffineFastState.Bounded env44296 := by
  intro p hp
  have h : env44296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44247_44296 : H12AffineEnvironment.transform 21 272513 env44247 = env44296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env44247 == env44296) = true)

theorem identity44296 : scanCanonicalize (H12AffineFastState.compose env44296 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound44296 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,416173,272513,412157,95496,8328,65,270496,417020,17664,32040,412721,156132,256,21792,16464,486374]

theorem envBound44297 : H12AffineFastState.Bounded env44297 := by
  intro p hp
  have h : env44297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44296_44297 : H12AffineEnvironment.transform 14 29909 env44296 = env44297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env44296 == env44297) = true)

def env44298 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,416173,272513,412077,95496,8328,17,270496,416940,17664,32040,412721,156084,256,21792,16384,486326]

theorem envBound44298 : H12AffineFastState.Bounded env44298 := by
  intro p hp
  have h : env44298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44297_44298 : H12AffineEnvironment.transform 5 16 env44297 = env44298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44297 == env44298) = true)

theorem identity44298 : scanCanonicalize (H12AffineFastState.compose env44298 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 70814) := by decide +kernel

theorem selectedBound44298 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env44299 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,70814,262144,1024,29828,347443,272513,351539,95496,8328,17,270496,346162,17664,32040,350383,95530,256,21792,16384,294696]

theorem envBound44299 : H12AffineFastState.Bounded env44299 := by
  intro p hp
  have h : env44299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44298_44299 : H12AffineEnvironment.transform 16 70814 env44298 = env44299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70814 env44298 == env44299) = true)

theorem identity44299 : scanCanonicalize (H12AffineFastState.compose env44299 (packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound44299 : packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env44300 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,70814,97326,1024,29828,12573,87215,8477,95496,8328,17,89230,13340,17664,32040,9345,95530,256,21792,16384,66310]

theorem envBound44300 : H12AffineFastState.Bounded env44300 := by
  intro p hp
  have h : env44300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44299_44300 : H12AffineEnvironment.transform 17 97326 env44299 = env44300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env44299 == env44300) = true)

theorem identity44300 : scanCanonicalize (H12AffineFastState.compose env44300 (packedSelected [0,1,3,4,7,17,22,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44300 : packedSelected [0,1,3,4,7,17,22,24,28] rootPS < 2^1333 := by decide +kernel

def env44301 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8203,13461,23589,1024,29828,12573,29860,8477,21763,8328,17,31877,13340,17664,32040,9345,21793,256,21792,16384,8973]

theorem envBound44301 : H12AffineFastState.Bounded env44301 := by
  intro p hp
  have h : env44301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44300_44301 : H12AffineEnvironment.transform 15 8203 env44300 = env44301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44300 == env44301) = true)

theorem identity44301 : scanCanonicalize (H12AffineFastState.compose env44301 (packedSelected [1,2,3,4,5,7,8,11,12,15,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 7701) := by decide +kernel

theorem selectedBound44301 : packedSelected [1,2,3,4,5,7,8,11,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env44302 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,7701,10896,8203,13461,560,1024,10897,12573,10929,8477,2838,8328,17,8848,13340,6933,9021,9345,2868,256,2869,7701,8973]

theorem envBound44302 : H12AffineFastState.Bounded env44302 := by
  intro p hp
  have h : env44302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44301_44302 : H12AffineEnvironment.transform 13 7701 env44301 = env44302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7701 env44301 == env44302) = true)

theorem identity44302 : scanCanonicalize (H12AffineFastState.compose env44302 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44302 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env44303 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,7701,2972,263,5529,560,1024,2973,4113,3005,17,2838,388,17,924,5392,6933,561,1421,2868,256,2869,7701,513]

theorem envBound44303 : H12AffineFastState.Bounded env44303 := by
  intro p hp
  have h : env44303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44302_44303 : H12AffineEnvironment.transform 12 268 env44302 = env44303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44302 == env44303) = true)

theorem identity44303 : scanCanonicalize (H12AffineFastState.compose env44303 (packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound44303 : packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44304 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,268,7701,2869,263,5424,560,1024,2868,4113,2836,17,2838,301,17,821,5392,6933,561,1316,2868,256,2869,7701,513]

theorem envBound44304 : H12AffineFastState.Bounded env44304 := by
  intro p hp
  have h : env44304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44303_44304 : H12AffineEnvironment.transform 6 41 env44303 = env44304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env44303 == env44304) = true)

theorem identity44304 : scanCanonicalize (H12AffineFastState.compose env44304 (packedSelected [1,2,7,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound44304 : packedSelected [1,2,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env44305 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,529,268,3076,2869,263,1825,560,1024,2868,512,2836,17,2838,301,17,821,1793,2308,561,1316,2868,256,2869,3076,513]

theorem envBound44305 : H12AffineFastState.Bounded env44305 := by
  intro p hp
  have h : env44305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44304_44305 : H12AffineEnvironment.transform 11 529 env44304 = env44305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env44304 == env44305) = true)

theorem identity44305 : scanCanonicalize (H12AffineFastState.compose env44305 (packedSelected [1,2,3,4,5,7,8,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44305 : packedSelected [1,2,3,4,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env44306 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,529,268,3076,2837,263,1793,528,1024,2836,512,2836,17,2838,269,17,789,1793,2308,529,1284,2836,256,2837,3076,513]

theorem envBound44306 : H12AffineFastState.Bounded env44306 := by
  intro p hp
  have h : env44306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44305_44306 : H12AffineEnvironment.transform 4 0 env44305 = env44306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44305 == env44306) = true)

theorem identity44306 : scanCanonicalize (H12AffineFastState.compose env44306 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound44306 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44307 : List Nat := [2,4,8,16,0,16,9,256,512,1024,788,529,268,1808,1,263,1793,528,1024,0,512,0,17,2,269,17,789,1793,528,529,1284,0,256,1,1808,513]

theorem envBound44307 : H12AffineFastState.Bounded env44307 := by
  intro p hp
  have h : env44307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44306_44307 : H12AffineEnvironment.transform 10 788 env44306 = env44307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env44306 == env44307) = true)

theorem identity44307 : scanCanonicalize (H12AffineFastState.compose env44307 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound44307 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44308 : List Nat := [2,4,8,16,0,16,9,256,1,1024,277,16,268,1297,1,263,1280,17,1024,0,1,0,17,2,269,17,276,1280,17,16,1284,0,256,1,1297,0]

theorem envBound44308 : H12AffineFastState.Bounded env44308 := by
  intro p hp
  have h : env44308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44307_44308 : H12AffineEnvironment.transform 8 1 env44307 = env44308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env44307 == env44308) = true)

theorem identity44308 : scanCanonicalize (H12AffineFastState.compose env44308 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44308 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44309 : List Nat := [2,4,8,11,0,11,9,256,1,1024,270,11,268,1290,1,263,1280,10,1024,0,1,0,10,2,269,10,271,1280,10,11,1284,0,256,1,1290,0]

theorem envBound44309 : H12AffineFastState.Bounded env44309 := by
  intro p hp
  have h : env44309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44308_44309 : H12AffineEnvironment.transform 3 11 env44308 = env44309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44308 == env44309) = true)

theorem identity44309 : scanCanonicalize (H12AffineFastState.compose env44309 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound44309 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44310 : List Nat := [2,4,8,11,0,11,9,256,1,256,270,11,268,10,1,263,0,10,256,0,1,0,10,2,269,10,271,0,10,11,4,0,256,1,10,0]

theorem envBound44310 : H12AffineFastState.Bounded env44310 := by
  intro p hp
  have h : env44310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44309_44310 : H12AffineEnvironment.transform 9 256 env44309 = env44310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env44309 == env44310) = true)

theorem identity44310 : scanCanonicalize (H12AffineFastState.compose env44310 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound44310 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44311 : List Nat := [2,4,7,4,0,4,6,256,1,256,257,4,259,5,1,263,0,5,256,0,1,0,5,2,258,5,256,0,5,4,4,0,256,1,5,0]

theorem envBound44311 : H12AffineFastState.Bounded env44311 := by
  intro p hp
  have h : env44311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44310_44311 : H12AffineEnvironment.transform 2 7 env44310 = env44311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env44310 == env44311) = true)

theorem identity44311 : scanCanonicalize (H12AffineFastState.compose env44311 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 1) := by decide +kernel

theorem selectedBound44311 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44312 : List Nat := [2,4,7,4,0,4,6,1,1,1,0,4,2,5,1,6,0,5,1,0,1,0,5,2,3,5,1,0,5,4,4,0,1,1,5,0]

theorem envBound44312 : H12AffineFastState.Bounded env44312 := by
  intro p hp
  have h : env44312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44311_44312 : H12AffineEnvironment.transform 7 1 env44311 = env44312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 1 env44311 == env44312) = true)

theorem identity44312 : scanCanonicalize (H12AffineFastState.compose env44312 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44312 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44313 : List Nat := [2,2,1,2,0,2,0,1,1,1,0,2,2,3,1,0,0,3,1,0,1,0,3,2,3,3,1,0,3,2,2,0,1,1,3,0]

theorem envBound44313 : H12AffineFastState.Bounded env44313 := by
  intro p hp
  have h : env44313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44312_44313 : H12AffineEnvironment.transform 1 2 env44312 = env44313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44312 == env44313) = true)

theorem identity44313 : scanCanonicalize (H12AffineFastState.compose env44313 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound44313 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env44314 : List Nat := [0,0,1,0,0,0,0,1,1,1,0,0,0,1,1,0,0,1,1,0,1,0,1,0,1,1,1,0,1,0,0,0,1,1,1,0]

theorem envBound44314 : H12AffineFastState.Bounded env44314 := by
  intro p hp
  have h : env44314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44313_44314 : H12AffineEnvironment.transform 0 0 env44313 = env44314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env44313 == env44314) = true)

def env44315 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,416173,272513,412076,95496,8328,16,270496,416941,17664,32040,412721,156085,256,21792,16385,486327]

theorem envBound44315 : H12AffineFastState.Bounded env44315 := by
  intro p hp
  have h : env44315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44297_44315 : H12AffineEnvironment.transform 5 17 env44297 = env44315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44297 == env44315) = true)

theorem identity44315 : scanCanonicalize (H12AffineFastState.compose env44315 (packedSelected [18,19,23,26] rootPS)) = affineNative (2^(17+1) ^^^ 149813) := by decide +kernel

theorem selectedBound44315 : packedSelected [18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env44316 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,149813,1024,29829,4248,156084,153,95496,8328,16,158101,5528,17664,32040,1284,156085,256,21792,16385,74370]

theorem envBound44316 : H12AffineFastState.Bounded env44316 := by
  intro p hp
  have h : env44316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44315_44316 : H12AffineEnvironment.transform 17 149813 env44315 = env44316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149813 env44315 == env44316) = true)

theorem identity44316 : scanCanonicalize (H12AffineFastState.compose env44316 (packedSelected [3,10,17,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound44316 : packedSelected [3,10,17,19,24] rootPS < 2^1333 := by decide +kernel

def env44317 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,21646,131072,149813,1024,29829,4248,156084,153,8582,8328,16,158101,5528,17664,32040,1284,156085,256,21792,16385,30220]

theorem envBound44317 : H12AffineFastState.Bounded env44317 := by
  intro p hp
  have h : env44317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44316_44317 : H12AffineEnvironment.transform 15 21646 env44316 = env44317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env44316 == env44317) = true)

theorem identity44317 : scanCanonicalize (H12AffineFastState.compose env44317 (packedSelected [0,1,4,7,10,19,22,28] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound44317 : packedSelected [0,1,4,7,10,19,22,28] rootPS < 2^1333 := by decide +kernel

def env44318 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,21646,16537,2476,1024,29829,4248,8493,153,8582,8328,16,10508,5528,17664,32040,1284,8492,256,21792,16385,30220]

theorem envBound44318 : H12AffineFastState.Bounded env44318 := by
  intro p hp
  have h : env44318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44317_44318 : H12AffineEnvironment.transform 16 16537 env44317 = env44318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env44317 == env44318) = true)

theorem identity44318 : scanCanonicalize (H12AffineFastState.compose env44318 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44318 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env44319 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,21511,16400,2341,1024,29708,4113,8493,16,8463,8193,16,10508,5393,17664,32040,1284,8492,256,21792,16385,30220]

theorem envBound44319 : H12AffineFastState.Bounded env44319 := by
  intro p hp
  have h : env44319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44318_44319 : H12AffineEnvironment.transform 6 9 env44318 = env44319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44318 == env44319) = true)

theorem identity44319 : scanCanonicalize (H12AffineFastState.compose env44319 (packedSelected [3,7,8,9,10,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound44319 : packedSelected [3,7,8,9,10,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env44320 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,2562,16384,24079,21511,16400,2341,1024,24078,4113,2863,16,2829,2563,16,782,5393,17664,22314,1284,2862,256,21792,16385,23566]

theorem envBound44320 : H12AffineFastState.Bounded env44320 := by
  intro p hp
  have h : env44320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44319_44320 : H12AffineEnvironment.transform 12 2562 env44319 = env44320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env44319 == env44320) = true)

theorem identity44320 : scanCanonicalize (H12AffineFastState.compose env44320 (packedSelected [1,2,3,4,7,10,11,12,16] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound44320 : packedSelected [1,2,3,4,7,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env44321 : List Nat := [2,4,8,16,32,17,9,256,512,1024,815,4096,301,16384,21792,21511,16400,522,1024,21793,4113,0,16,34,300,16,782,5393,17664,22314,1284,1,256,21792,16385,22305]

theorem envBound44321 : H12AffineFastState.Bounded env44321 := by
  intro p hp
  have h : env44321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44320_44321 : H12AffineEnvironment.transform 10 815 env44320 = env44321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env44320 == env44321) = true)

def env44322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,4194304,441641,98780,8328,65,4259060,436264,17665,32041,440548,4606308,256,21792,46213,499507]

theorem envBound44322 : H12AffineFastState.Bounded env44322 := by
  intro p hp
  have h : env44322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44246_44322 : H12AffineEnvironment.transform 22 441641 env44246 = env44322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441641 env44246 == env44322) = true)

def env44323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272512,441641,98780,8328,65,316532,436264,17665,32041,440548,156132,256,21792,46213,499507]

theorem envBound44323 : H12AffineFastState.Bounded env44323 := by
  intro p hp
  have h : env44323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44322_44323 : H12AffineEnvironment.transform 21 272512 env44322 = env44323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env44322 == env44323) = true)

theorem identity44323 : scanCanonicalize (H12AffineFastState.compose env44323 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound44323 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,169401,16,98780,8328,65,158029,5393,17665,32041,1501,156132,256,21792,46213,74250]

theorem envBound44324 : H12AffineFastState.Bounded env44324 := by
  intro p hp
  have h : env44324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44323_44324 : H12AffineEnvironment.transform 17 179513 env44323 = env44324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env44323 == env44324) = true)

theorem identity44324 : scanCanonicalize (H12AffineFastState.compose env44324 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44324 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env44325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1024,32769,4161,169401,16,41431,8328,65,158029,5393,17665,32041,1501,156132,256,21792,46213,513]

theorem envBound44325 : H12AffineFastState.Bounded env44325 := by
  intro p hp
  have h : env44325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44324_44325 : H12AffineEnvironment.transform 15 8203 env44324 = env44325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44324 == env44325) = true)

def env44326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272513,441641,98780,8328,65,316533,436264,17665,32041,440548,156133,256,21792,46213,499507]

theorem envBound44326 : H12AffineFastState.Bounded env44326 := by
  intro p hp
  have h : env44326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44322_44326 : H12AffineEnvironment.transform 21 272513 env44322 = env44326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env44322 == env44326) = true)

def env44327 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272393,441641,98644,8192,65,316533,436264,17665,32041,440428,156013,256,21792,46093,499507]

theorem envBound44327 : H12AffineFastState.Bounded env44327 := by
  intro p hp
  have h : env44327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44326_44327 : H12AffineEnvironment.transform 6 8 env44326 = env44327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44326 == env44327) = true)

theorem identity44327 : scanCanonicalize (H12AffineFastState.compose env44327 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 122147) := by decide +kernel

theorem selectedBound44327 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env44328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,122147,1024,32769,225371,128298,221194,98644,8192,65,67926,226571,17665,32041,222543,156013,256,21792,46093,147984]

theorem envBound44328 : H12AffineFastState.Bounded env44328 := by
  intro p hp
  have h : env44328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44327_44328 : H12AffineEnvironment.transform 17 122147 env44327 = env44328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122147 env44327 == env44328) = true)

theorem identity44328 : scanCanonicalize (H12AffineFastState.compose env44328 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound44328 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44329 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,122147,1024,32769,102678,128298,98631,98644,8192,65,67926,103494,17665,32041,99330,32800,256,21792,46093,41821]

theorem envBound44329 : H12AffineFastState.Bounded env44329 := by
  intro p hp
  have h : env44329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44328_44329 : H12AffineEnvironment.transform 16 57677 env44328 = env44329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env44328 == env44329) = true)

theorem identity44329 : scanCanonicalize (H12AffineFastState.compose env44329 (packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44329 : packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env44330 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,97407,1024,8541,77898,87158,73755,73736,8192,65,67926,79130,17665,32041,75102,8572,256,21792,5457,513]

theorem envBound44330 : H12AffineFastState.Bounded env44330 := by
  intro p hp
  have h : env44330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44329_44330 : H12AffineEnvironment.transform 14 8540 env44329 = env44330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44329 == env44330) = true)

theorem identity44330 : scanCanonicalize (H12AffineFastState.compose env44330 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound44330 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44331 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,65536,16401,96623,272,8541,77898,86374,73755,73736,8192,65,67926,77834,16401,30777,73806,8572,256,20528,4161,513]

theorem envBound44331 : H12AffineFastState.Bounded env44331 := by
  intro p hp
  have h : env44331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44330_44331 : H12AffineEnvironment.transform 9 272 env44330 = env44331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env44330 == env44331) = true)

theorem identity44331 : scanCanonicalize (H12AffineFastState.compose env44331 (packedSelected [1,2,6,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound44331 : packedSelected [1,2,6,8,19] rootPS < 2^1333 := by decide +kernel

def env44332 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12621,8540,65536,12636,67618,272,8541,77898,73771,73755,73736,8192,65,67926,77834,12636,2420,73806,8572,256,8573,4161,513]

theorem envBound44332 : H12AffineFastState.Bounded env44332 := by
  intro p hp
  have h : env44332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44331_44332 : H12AffineEnvironment.transform 13 12621 env44331 = env44332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env44331 == env44332) = true)

theorem identity44332 : scanCanonicalize (H12AffineFastState.compose env44332 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44332 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44333 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12621,8540,8203,12636,10281,272,8541,4161,32,16,3,8192,65,10589,4097,12636,2420,69,8572,256,8573,4161,513]

theorem envBound44333 : H12AffineFastState.Bounded env44333 := by
  intro p hp
  have h : env44333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44332_44333 : H12AffineEnvironment.transform 15 8203 env44332 = env44333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44332 == env44333) = true)

theorem identity44333 : scanCanonicalize (H12AffineFastState.compose env44333 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound44333 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44334 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,72,4357,276,67,4372,2145,272,277,4161,32,16,3,72,65,2325,4097,4372,2420,69,308,256,309,4161,513]

theorem envBound44334 : H12AffineFastState.Bounded env44334 := by
  intro p hp
  have h : env44334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44333_44334 : H12AffineEnvironment.transform 12 72 env44333 = env44334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env44333 == env44334) = true)

theorem identity44334 : scanCanonicalize (H12AffineFastState.compose env44334 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound44334 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44335 : List Nat := [2,4,8,16,32,64,8,20,512,4,2048,4096,72,4113,0,67,4096,2145,4,1,4161,32,16,3,72,65,2049,4097,4096,2144,69,32,20,33,4161,513]

theorem envBound44335 : H12AffineFastState.Bounded env44335 := by
  intro p hp
  have h : env44335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44334_44335 : H12AffineEnvironment.transform 7 20 env44334 = env44335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env44334 == env44335) = true)

theorem identity44335 : scanCanonicalize (H12AffineFastState.compose env44335 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound44335 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44336 : List Nat := [2,4,8,16,32,64,8,20,512,4,58,4096,72,4113,0,67,4096,91,4,1,4161,32,16,3,72,65,59,4097,4096,90,69,32,20,33,4161,513]

theorem envBound44336 : H12AffineFastState.Bounded env44336 := by
  intro p hp
  have h : env44336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44335_44336 : H12AffineEnvironment.transform 10 58 env44335 = env44336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env44335 == env44336) = true)

theorem identity44336 : scanCanonicalize (H12AffineFastState.compose env44336 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound44336 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44337 : List Nat := [2,4,8,16,32,64,8,20,512,4,58,0,72,17,0,67,0,91,4,1,65,32,16,3,72,65,59,1,0,90,69,32,20,33,65,513]

theorem envBound44337 : H12AffineFastState.Bounded env44337 := by
  intro p hp
  have h : env44337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44336_44337 : H12AffineEnvironment.transform 11 0 env44336 = env44337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env44336 == env44337) = true)

theorem identity44337 : scanCanonicalize (H12AffineFastState.compose env44337 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44337 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env44338 : List Nat := [2,4,8,16,1,64,8,20,512,4,27,0,72,17,0,67,0,91,4,1,65,1,16,3,72,65,26,1,0,90,69,1,20,0,65,513]

theorem envBound44338 : H12AffineFastState.Bounded env44338 := by
  intro p hp
  have h : env44338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44337_44338 : H12AffineEnvironment.transform 4 1 env44337 = env44338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44337 == env44338) = true)

theorem identity44338 : scanCanonicalize (H12AffineFastState.compose env44338 (packedSelected [0,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound44338 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env44339 : List Nat := [2,4,8,16,1,18,8,20,512,4,27,0,26,17,0,17,0,9,4,1,19,1,16,3,26,19,26,1,0,8,23,1,20,0,19,513]

theorem envBound44339 : H12AffineFastState.Bounded env44339 := by
  intro p hp
  have h : env44339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44338_44339 : H12AffineEnvironment.transform 5 18 env44338 = env44339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env44338 == env44339) = true)

theorem identity44339 : scanCanonicalize (H12AffineFastState.compose env44339 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 19) := by decide +kernel

theorem selectedBound44339 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env44340 : List Nat := [2,4,8,16,1,18,8,20,19,4,27,0,26,17,0,17,0,9,4,1,19,1,16,3,26,19,26,1,0,8,23,1,20,0,19,18]

theorem envBound44340 : H12AffineFastState.Bounded env44340 := by
  intro p hp
  have h : env44340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44339_44340 : H12AffineEnvironment.transform 8 19 env44339 = env44340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 19 env44339 == env44340) = true)

theorem identity44340 : scanCanonicalize (H12AffineFastState.compose env44340 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound44340 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env44341 : List Nat := [2,4,8,3,1,1,8,7,0,4,8,0,9,2,0,2,0,9,4,1,0,1,3,3,9,0,9,1,0,8,4,1,7,0,0,1]

theorem envBound44341 : H12AffineFastState.Bounded env44341 := by
  intro p hp
  have h : env44341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44340_44341 : H12AffineEnvironment.transform 3 3 env44340 = env44341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env44340 == env44341) = true)

theorem identity44341 : scanCanonicalize (H12AffineFastState.compose env44341 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44341 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44342 : List Nat := [2,4,5,3,1,1,5,7,0,4,5,0,4,2,0,2,0,4,4,1,0,1,3,3,4,0,4,1,0,5,4,1,7,0,0,1]

theorem envBound44342 : H12AffineFastState.Bounded env44342 := by
  intro p hp
  have h : env44342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44341_44342 : H12AffineEnvironment.transform 2 5 env44341 = env44342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44341 == env44342) = true)

theorem identity44342 : scanCanonicalize (H12AffineFastState.compose env44342 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44342 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44343 : List Nat := [2,2,3,3,1,1,3,1,0,2,3,0,2,2,0,2,0,2,2,1,0,1,3,3,2,0,2,1,0,3,2,1,1,0,0,1]

theorem envBound44343 : H12AffineFastState.Bounded env44343 := by
  intro p hp
  have h : env44343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44342_44343 : H12AffineEnvironment.transform 1 2 env44342 = env44343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44342 == env44343) = true)

theorem identity44343 : scanCanonicalize (H12AffineFastState.compose env44343 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44343 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44344 : List Nat := [1,1,0,0,1,1,0,1,0,1,0,0,1,1,0,1,0,1,1,1,0,1,0,0,1,0,1,1,0,0,1,1,1,0,0,1]

theorem envBound44344 : H12AffineFastState.Bounded env44344 := by
  intro p hp
  have h : env44344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44343_44344 : H12AffineEnvironment.transform 0 1 env44343 = env44344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44343 == env44344) = true)

def env44345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272392,441641,98645,8193,65,316533,436264,17665,32041,440429,156012,256,21792,46092,499507]

theorem envBound44345 : H12AffineFastState.Bounded env44345 := by
  intro p hp
  have h : env44345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44326_44345 : H12AffineEnvironment.transform 6 9 env44326 = env44345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44326 == env44345) = true)

def env44346 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,276584,272392,272441,98645,8193,65,316533,277816,17665,32041,273789,62588,256,21792,46092,330275]

theorem envBound44346 : H12AffineFastState.Bounded env44346 := by
  intro p hp
  have h : env44346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44345_44346 : H12AffineEnvironment.transform 16 38160 env44345 = env44346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env44345 == env44346) = true)

def env44347 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,64808,1024,32769,50496,54560,54545,98645,8193,65,10589,49168,17665,32041,53333,62588,256,21792,46092,128779]

theorem envBound44347 : H12AffineFastState.Bounded env44347 := by
  intro p hp
  have h : env44347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44346_44347 : H12AffineEnvironment.transform 17 64808 env44346 = env44347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env44346 == env44347) = true)

theorem identity44347 : scanCanonicalize (H12AffineFastState.compose env44347 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound44347 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env44348 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16401,10281,1024,21760,4161,33,16,87124,8193,65,10589,5393,17665,32041,1364,8573,256,21792,24845,74250]

theorem envBound44348 : H12AffineFastState.Bounded env44348 := by
  intro p hp
  have h : env44348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44347_44348 : H12AffineEnvironment.transform 14 21761 env44347 = env44348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env44347 == env44348) = true)

theorem identity44348 : scanCanonicalize (H12AffineFastState.compose env44348 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound44348 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env44349 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,21590,16401,10281,1024,21760,4161,33,16,2,8193,65,10589,5393,17665,32041,1364,8573,256,21792,24845,30300]

theorem envBound44349 : H12AffineFastState.Bounded env44349 := by
  intro p hp
  have h : env44349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44348_44349 : H12AffineEnvironment.transform 15 21590 env44348 = env44349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env44348 == env44349) = true)

theorem identity44349 : scanCanonicalize (H12AffineFastState.compose env44349 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound44349 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44350 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8540,8203,13388,10281,1024,8541,4161,33,16,2,8193,65,10589,5393,12636,2420,1364,8573,256,8573,5456,513]

theorem envBound44350 : H12AffineFastState.Bounded env44350 := by
  intro p hp
  have h : env44350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44349_44350 : H12AffineEnvironment.transform 13 13405 env44349 = env44350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env44349 == env44350) = true)

def env44351 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,64809,1024,32769,50497,54561,54544,98645,8193,65,10588,49169,17665,32041,53332,62588,256,21792,46092,128778]

theorem envBound44351 : H12AffineFastState.Bounded env44351 := by
  intro p hp
  have h : env44351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44346_44351 : H12AffineEnvironment.transform 17 64809 env44346 = env44351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env44346 == env44351) = true)

theorem identity44351 : scanCanonicalize (H12AffineFastState.compose env44351 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound44351 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env44352 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38160,64809,1024,32769,50497,54561,54544,29790,8193,65,10588,49169,17665,32041,53332,62588,256,21792,46092,513]

theorem envBound44352 : H12AffineFastState.Bounded env44352 := by
  intro p hp
  have h : env44352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44351_44352 : H12AffineEnvironment.transform 15 62731 env44351 = env44352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env44351 == env44352) = true)

theorem identity44352 : scanCanonicalize (H12AffineFastState.compose env44352 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound44352 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54359,38160,56437,1024,32769,50497,54561,54544,21762,349,65,2048,49169,17665,23669,53332,54560,256,21792,38224,513]

theorem envBound44353 : H12AffineFastState.Bounded env44353 := by
  intro p hp
  have h : env44353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44352_44353 : H12AffineEnvironment.transform 12 348 env44352 = env44353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env44352 == env44353) = true)

theorem identity44353 : scanCanonicalize (H12AffineFastState.compose env44353 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound44353 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env44354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,21590,5393,23668,1024,0,17728,21792,21777,21762,349,65,2048,16400,17665,23669,20565,21793,256,21792,5457,513]

theorem envBound44354 : H12AffineFastState.Bounded env44354 := by
  intro p hp
  have h : env44354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44353_44354 : H12AffineEnvironment.transform 14 1 env44353 = env44354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env44353 == env44354) = true)

theorem identity44354 : scanCanonicalize (H12AffineFastState.compose env44354 (packedSelected [1,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 1124) := by decide +kernel

theorem selectedBound44354 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env44355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,1124,1,4146,5393,6160,1024,0,292,4420,4469,4454,349,65,2048,1140,357,6161,5169,4421,256,4420,5457,513]

theorem envBound44355 : H12AffineFastState.Bounded env44355 := by
  intro p hp
  have h : env44355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44354_44355 : H12AffineEnvironment.transform 13 1124 env44354 = env44355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1124 env44354 == env44355) = true)

theorem identity44355 : scanCanonicalize (H12AffineFastState.compose env44355 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound44355 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,357,348,1124,1,343,1140,2421,1024,0,292,33,16,3,349,65,2048,1140,357,2420,1364,32,256,33,1076,513]

theorem envBound44356 : H12AffineFastState.Bounded env44356 := by
  intro p hp
  have h : env44356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44355_44356 : H12AffineEnvironment.transform 11 357 env44355 = env44356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env44355 == env44356) = true)

theorem identity44356 : scanCanonicalize (H12AffineFastState.compose env44356 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound44356 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,373,357,348,1124,1,343,1140,0,1024,0,292,33,16,3,349,65,373,1140,357,1,1364,32,256,33,1076,513]

theorem envBound44357 : H12AffineFastState.Bounded env44357 := by
  intro p hp
  have h : env44357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44356_44357 : H12AffineEnvironment.transform 10 373 env44356 = env44357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env44356 == env44357) = true)

theorem identity44357 : scanCanonicalize (H12AffineFastState.compose env44357 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound44357 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env44358 : List Nat := [2,4,8,16,32,64,9,256,512,516,373,357,348,608,1,343,624,0,516,0,292,33,16,3,349,65,373,624,357,1,848,32,256,33,560,513]

theorem envBound44358 : H12AffineFastState.Bounded env44358 := by
  intro p hp
  have h : env44358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44357_44358 : H12AffineEnvironment.transform 9 516 env44357 = env44358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env44357 == env44358) = true)

theorem identity44358 : scanCanonicalize (H12AffineFastState.compose env44358 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound44358 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env44359 : List Nat := [2,4,8,16,32,64,9,256,261,257,373,357,348,357,1,343,373,0,257,0,292,33,16,3,349,65,373,373,357,1,85,32,256,33,309,260]

theorem envBound44359 : H12AffineFastState.Bounded env44359 := by
  intro p hp
  have h : env44359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44358_44359 : H12AffineEnvironment.transform 8 261 env44358 = env44359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env44358 == env44359) = true)

theorem identity44359 : scanCanonicalize (H12AffineFastState.compose env44359 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44359 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env44360 : List Nat := [2,4,8,16,0,64,9,256,261,257,341,325,348,325,1,343,341,0,257,0,260,1,16,3,349,65,341,341,325,1,85,0,256,1,277,260]

theorem envBound44360 : H12AffineFastState.Bounded env44360 := by
  intro p hp
  have h : env44360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44359_44360 : H12AffineEnvironment.transform 4 0 env44359 = env44360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44359 == env44360) = true)

theorem identity44360 : scanCanonicalize (H12AffineFastState.compose env44360 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44360 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env44361 : List Nat := [2,4,8,1,0,64,9,256,261,257,324,325,333,325,1,326,324,0,257,0,260,1,1,3,332,65,324,324,325,1,68,0,256,1,260,260]

theorem envBound44361 : H12AffineFastState.Bounded env44361 := by
  intro p hp
  have h : env44361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44360_44361 : H12AffineEnvironment.transform 3 1 env44360 = env44361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44360 == env44361) = true)

end H12CloudChart1