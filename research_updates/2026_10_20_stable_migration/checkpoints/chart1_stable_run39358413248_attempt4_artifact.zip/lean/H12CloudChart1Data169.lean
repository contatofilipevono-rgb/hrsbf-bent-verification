import H12CloudChart1Data168

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound42850 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env42851 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77898,4194304,318564,294187,8193,65,4677967,313701,375166,138340,75102,4466728,257,21792,46093,513]

theorem envBound42851 : H12AffineFastState.Bounded env42851 := by
  intro p hp
  have h : env42851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42850_42851 : H12AffineEnvironment.transform 20 77898 env42850 = env42851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env42850 == env42851) = true)

theorem identity42851 : scanCanonicalize (H12AffineFastState.compose env42851 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound42851 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42852 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,77898,4194304,318564,294187,8193,65,4456788,313701,375166,97407,75102,4466728,257,21792,46093,513]

theorem envBound42852 : H12AffineFastState.Bounded env42852 := by
  intro p hp
  have h : env42852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42851_42852 : H12AffineEnvironment.transform 16 90139 env42851 = env42852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env42851 == env42852) = true)

def env42853 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1025,32769,77898,4194304,62540,21763,8193,65,4204924,57677,102742,97407,75102,4194304,257,21792,46093,513]

theorem envBound42853 : H12AffineFastState.Bounded env42853 := by
  intro p hp
  have h : env42853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42852_42853 : H12AffineEnvironment.transform 17 10280 env42852 = env42853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42852 == env42853) = true)

theorem identity42853 : scanCanonicalize (H12AffineFastState.compose env42853 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound42853 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env42854 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,46156,10280,1025,32769,58397,4194304,62540,21763,8193,65,4204924,57677,17665,43048,61705,4194304,257,21792,46093,513]

theorem envBound42854 : H12AffineFastState.Bounded env42854 := by
  intro p hp
  have h : env42854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42853_42854 : H12AffineEnvironment.transform 15 54359 env42853 = env42854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env42853 == env42854) = true)

theorem identity42854 : scanCanonicalize (H12AffineFastState.compose env42854 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42854 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env42855 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,46156,10280,1025,32769,45341,4194304,41292,3,8193,65,4204924,46157,4097,43048,41993,4194304,257,32,46093,513]

theorem envBound42855 : H12AffineFastState.Bounded env42855 := by
  intro p hp
  have h : env42855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42854_42855 : H12AffineEnvironment.transform 13 5376 env42854 = env42855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42854 == env42855) = true)

theorem identity42855 : scanCanonicalize (H12AffineFastState.compose env42855 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound42855 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env42856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,46156,10280,1025,32769,45341,41340,41292,3,8193,65,34816,46157,4097,43048,41993,41340,257,32,46093,513]

theorem envBound42856 : H12AffineFastState.Bounded env42856 := by
  intro p hp
  have h : env42856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42855_42856 : H12AffineEnvironment.transform 21 41340 env42855 = env42856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env42855 == env42856) = true)

def env42857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1025,32769,77898,4194304,62541,21762,8193,65,4204925,57676,102743,97407,75102,4194305,257,21792,46093,513]

theorem envBound42857 : H12AffineFastState.Bounded env42857 := by
  intro p hp
  have h : env42857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42852_42857 : H12AffineEnvironment.transform 17 10281 env42852 = env42857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42852 == env42857) = true)

theorem identity42857 : scanCanonicalize (H12AffineFastState.compose env42857 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 53574) := by decide +kernel

theorem selectedBound42857 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env42858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,53574,45405,10281,1025,32769,57612,4194304,62541,21762,8193,65,4204925,57676,16401,44345,62488,4194305,257,21792,46093,513]

theorem envBound42858 : H12AffineFastState.Bounded env42858 := by
  intro p hp
  have h : env42858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42857_42858 : H12AffineEnvironment.transform 15 53574 env42857 = env42858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53574 env42857 == env42858) = true)

theorem identity42858 : scanCanonicalize (H12AffineFastState.compose env42858 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound42858 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env42859 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,28699,4096,10281,1025,8540,16465,4194304,21776,21762,8193,65,4204925,16401,16401,3172,21829,4194305,257,21792,5456,513]

theorem envBound42859 : H12AffineFastState.Bounded env42859 := by
  intro p hp
  have h : env42859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42858_42859 : H12AffineEnvironment.transform 14 8541 env42858 = env42859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env42858 == env42859) = true)

theorem identity42859 : scanCanonicalize (H12AffineFastState.compose env42859 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42859 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env42860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,80,20758,4096,2340,1025,81,16465,4194304,21776,21762,268,65,4196464,16401,16401,3172,21829,4194305,257,21792,5456,513]

theorem envBound42860 : H12AffineFastState.Bounded env42860 := by
  intro p hp
  have h : env42860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42859_42860 : H12AffineEnvironment.transform 12 269 env42859 = env42860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42859 == env42860) = true)

theorem identity42860 : scanCanonicalize (H12AffineFastState.compose env42860 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound42860 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env42861 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,269,16384,80,20758,4096,2340,101,81,16465,4194304,20852,20838,268,65,4196464,16401,16401,2048,20769,4194305,257,20804,4404,513]

theorem envBound42861 : H12AffineFastState.Bounded env42861 := by
  intro p hp
  have h : env42861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42860_42861 : H12AffineEnvironment.transform 9 100 env42860 = env42861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env42860 == env42861) = true)

theorem identity42861 : scanCanonicalize (H12AffineFastState.compose env42861 (packedSelected [0,1,2,3,5,6,7,8,11,12,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 18773) := by decide +kernel

theorem selectedBound42861 : packedSelected [0,1,2,3,5,6,7,8,11,12,18,20] rootPS < 2^1333 := by decide +kernel

def env42862 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,269,16384,80,20758,4096,2340,101,81,16465,18773,20852,20838,268,65,16677,16401,16401,2048,20769,18772,257,20804,4404,513]

theorem envBound42862 : H12AffineFastState.Bounded env42862 := by
  intro p hp
  have h : env42862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42861_42862 : H12AffineEnvironment.transform 21 18773 env42861 = env42862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 18773 env42861 == env42862) = true)

theorem identity42862 : scanCanonicalize (H12AffineFastState.compose env42862 (packedSelected [1,2,3,5,6,8,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 2420) := by decide +kernel

theorem selectedBound42862 : packedSelected [1,2,3,5,6,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env42863 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,269,2420,80,6242,4096,2340,101,81,2341,33,6144,6162,268,65,2129,2405,2405,2048,6229,32,257,6192,4404,513]

theorem envBound42863 : H12AffineFastState.Bounded env42863 := by
  intro p hp
  have h : env42863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42862_42863 : H12AffineEnvironment.transform 13 2420 env42862 = env42863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2420 env42862 == env42863) = true)

theorem identity42863 : scanCanonicalize (H12AffineFastState.compose env42863 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42863 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env42864 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,4096,269,2340,0,6194,4096,2340,53,1,2341,33,6144,6162,268,17,2049,2357,2357,2048,6149,32,257,6192,4404,513]

theorem envBound42864 : H12AffineFastState.Bounded env42864 := by
  intro p hp
  have h : env42864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42863_42864 : H12AffineEnvironment.transform 5 16 env42863 = env42864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42863 == env42864) = true)

theorem identity42864 : scanCanonicalize (H12AffineFastState.compose env42864 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42864 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env42865 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,4096,40,2049,0,6194,4096,2049,53,1,2048,33,6144,6162,41,17,2049,2064,2064,2048,6149,32,36,6192,4113,513]

theorem envBound42865 : H12AffineFastState.Bounded env42865 := by
  intro p hp
  have h : env42865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42864_42865 : H12AffineEnvironment.transform 7 37 env42864 = env42865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42864 == env42865) = true)

theorem identity42865 : scanCanonicalize (H12AffineFastState.compose env42865 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound42865 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42866 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2065,40,2049,0,35,2065,2049,53,1,2048,33,17,3,41,17,2049,2064,2064,2048,20,32,36,33,2048,513]

theorem envBound42866 : H12AffineFastState.Bounded env42866 := by
  intro p hp
  have h : env42866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42865_42866 : H12AffineEnvironment.transform 11 2065 env42865 = env42866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env42865 == env42866) = true)

theorem identity42866 : scanCanonicalize (H12AffineFastState.compose env42866 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound42866 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42867 : List Nat := [2,4,8,16,32,16,9,37,33,52,2048,2065,40,2049,0,35,2065,2049,53,1,2048,33,17,3,41,17,2049,2064,2064,2048,20,32,36,33,2048,32]

theorem envBound42867 : H12AffineFastState.Bounded env42867 := by
  intro p hp
  have h : env42867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42866_42867 : H12AffineEnvironment.transform 8 33 env42866 = env42867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env42866 == env42867) = true)

theorem identity42867 : scanCanonicalize (H12AffineFastState.compose env42867 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42867 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42868 : List Nat := [2,4,8,16,0,16,9,5,1,20,2048,2065,8,2049,0,3,2065,2049,21,1,2048,1,17,3,9,17,2049,2064,2064,2048,20,0,4,1,2048,0]

theorem envBound42868 : H12AffineFastState.Bounded env42868 := by
  intro p hp
  have h : env42868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42867_42868 : H12AffineEnvironment.transform 4 0 env42867 = env42868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42867 == env42868) = true)

def env42869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318565,2444776,8328,65,6705549,313701,2394421,138341,2102684,4466728,257,21793,46213,2175562]

theorem envBound42869 : H12AffineFastState.Bounded env42869 := by
  intro p hp
  have h : env42869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42769_42869 : H12AffineEnvironment.transform 22 318565 env42769 = env42869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318565 env42769 == env42869) = true)

def env42870 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318565,2444640,8192,65,6705413,313701,2394421,138341,2102548,4466728,257,21793,46093,2175562]

theorem envBound42870 : H12AffineFastState.Bounded env42870 := by
  intro p hp
  have h : env42870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42869_42870 : H12AffineEnvironment.transform 6 8 env42869 = env42870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42869 == env42870) = true)

theorem identity42870 : scanCanonicalize (H12AffineFastState.compose env42870 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound42870 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env42871 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77899,4194304,318565,294187,8192,65,4677966,313701,375166,138341,75103,4466728,257,21793,46093,513]

theorem envBound42871 : H12AffineFastState.Bounded env42871 := by
  intro p hp
  have h : env42871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42870_42871 : H12AffineEnvironment.transform 20 77899 env42870 = env42871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env42870 == env42871) = true)

def env42872 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,77899,4194304,62541,21763,8192,65,4409702,57677,102742,138341,75103,4194304,257,21793,46093,513]

theorem envBound42872 : H12AffineFastState.Bounded env42872 := by
  intro p hp
  have h : env42872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42871_42872 : H12AffineEnvironment.transform 17 10280 env42871 = env42872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42871 == env42872) = true)

def env42873 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,77899,4194304,17,21763,8192,65,4409702,5393,91402,138341,75103,4194304,257,21793,16465,513]

theorem envBound42873 : H12AffineFastState.Bounded env42873 := by
  intro p hp
  have h : env42873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42872_42873 : H12AffineEnvironment.transform 14 29788 env42872 = env42873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env42872 == env42873) = true)

def env42874 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,77899,21792,17,21763,8192,65,203846,5393,91402,138341,75103,21792,257,21793,16465,513]

theorem envBound42874 : H12AffineFastState.Bounded env42874 := by
  intro p hp
  have h : env42874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42873_42874 : H12AffineEnvironment.transform 21 21792 env42873 = env42874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env42873 == env42874) = true)

theorem identity42874 : scanCanonicalize (H12AffineFastState.compose env42874 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound42874 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env42875 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,80,65536,131072,10280,1025,81,77899,8492,17,8463,8192,65,203846,5393,69894,138341,75103,8492,257,8493,13405,513]

theorem envBound42875 : H12AffineFastState.Bounded env42875 := by
  intro p hp
  have h : env42875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42874_42875 : H12AffineEnvironment.transform 13 13324 env42874 = env42875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env42874 == env42875) = true)

theorem identity42875 : scanCanonicalize (H12AffineFastState.compose env42875 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound42875 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,80,343,131072,10280,1025,81,12572,8492,17,8463,8192,65,138513,5393,4177,138341,9224,8492,257,8493,13405,513]

theorem envBound42876 : H12AffineFastState.Bounded env42876 := by
  intro p hp
  have h : env42876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42875_42876 : H12AffineEnvironment.transform 15 343 env42875 = env42876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env42875 == env42876) = true)

theorem identity42876 : scanCanonicalize (H12AffineFastState.compose env42876 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42876 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env42877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,80,343,131072,2341,1025,81,4113,33,17,2,269,65,138513,5393,4177,138341,1285,33,257,32,5456,513]

theorem envBound42877 : H12AffineFastState.Bounded env42877 := by
  intro p hp
  have h : env42877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42876_42877 : H12AffineEnvironment.transform 12 269 env42876 = env42877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42876 == env42877) = true)

theorem identity42877 : scanCanonicalize (H12AffineFastState.compose env42877 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound42877 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env42878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,80,343,5393,2341,1025,81,4113,33,17,2,269,65,2048,5393,4177,2420,1285,33,257,32,5456,513]

theorem envBound42878 : H12AffineFastState.Bounded env42878 := by
  intro p hp
  have h : env42878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42877_42878 : H12AffineEnvironment.transform 16 5393 env42877 = env42878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env42877 == env42878) = true)

theorem identity42878 : scanCanonicalize (H12AffineFastState.compose env42878 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42878 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42879 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,262,5393,2341,1025,0,4113,33,17,2,269,16,2048,5393,4096,2341,1285,33,257,32,5377,513]

theorem envBound42879 : H12AffineFastState.Bounded env42879 := by
  intro p hp
  have h : env42879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42878_42879 : H12AffineEnvironment.transform 5 17 env42878 = env42879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42878 == env42879) = true)

theorem identity42879 : scanCanonicalize (H12AffineFastState.compose env42879 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42879 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42880 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,1,35,5172,2048,1025,0,4113,33,17,2,40,16,2048,5172,4096,2048,1056,33,36,32,5156,513]

theorem envBound42880 : H12AffineFastState.Bounded env42880 := by
  intro p hp
  have h : env42880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42879_42880 : H12AffineEnvironment.transform 7 37 env42879 = env42880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42879 == env42880) = true)

def env42881 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1044,1,35,1028,2048,1025,0,33,33,17,2,40,16,2048,1028,48,2048,1056,33,36,32,1044,513]

theorem envBound42881 : H12AffineFastState.Bounded env42881 := by
  intro p hp
  have h : env42881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42880_42881 : H12AffineEnvironment.transform 11 48 env42880 = env42881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env42880 == env42881) = true)

theorem identity42881 : scanCanonicalize (H12AffineFastState.compose env42881 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound42881 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42882 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1044,48,40,1044,1,35,1028,1044,1025,0,33,33,17,2,40,16,1044,1028,48,1044,1056,33,36,32,1044,513]

theorem envBound42882 : H12AffineFastState.Bounded env42882 := by
  intro p hp
  have h : env42882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42881_42882 : H12AffineEnvironment.transform 10 1044 env42881 = env42882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env42881 == env42882) = true)

def env42883 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,40,32,1,35,48,32,53,0,33,33,17,2,40,16,32,48,48,32,20,33,36,32,32,513]

theorem envBound42883 : H12AffineFastState.Bounded env42883 := by
  intro p hp
  have h : env42883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42882_42883 : H12AffineEnvironment.transform 9 52 env42882 = env42883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42882 == env42883) = true)

theorem identity42883 : scanCanonicalize (H12AffineFastState.compose env42883 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42883 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42884 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,17,9,1,1,2,17,1,20,0,0,0,17,2,9,16,1,17,17,1,20,0,5,1,1,513]

theorem envBound42884 : H12AffineFastState.Bounded env42884 := by
  intro p hp
  have h : env42884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42883_42884 : H12AffineEnvironment.transform 4 1 env42883 = env42884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42883 == env42884) = true)

def leafEnv42884 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,17,9,1,1,2,17,1,20,0,0,0,17,2,21,9,1,16,1,17,17,1,20,0,5,1,5,2,1,513,1,0,0]

def active42884 : List Nat := [0,1,2,3,8]

def tree42884 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42884 : H12WitnessSearch.Good tree42884 := H12GlobalWitnessIndex.good

theorem leafIdentity42884 : H12AffineFastState.composeSystem env42884 rootObs = leafEnv42884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42884 rootObs == leafEnv42884) = true)

theorem terminalChecked42884 : H12PackedTerminal.terminalCheckFast leafEnv42884 active42884 tree42884 = true := by decide +kernel

def env42885 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,48,40,33,1,35,49,33,52,0,33,33,17,2,40,16,33,49,48,33,21,33,36,32,33,513]

theorem envBound42885 : H12AffineFastState.Bounded env42885 := by
  intro p hp
  have h : env42885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42882_42885 : H12AffineEnvironment.transform 9 53 env42882 = env42885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42882 == env42885) = true)

theorem identity42885 : scanCanonicalize (H12AffineFastState.compose env42885 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound42885 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42886 : List Nat := [2,4,8,16,32,17,8,37,10,53,33,48,40,33,1,35,49,33,52,0,33,33,17,2,40,16,33,49,48,33,21,33,36,32,33,11]

theorem envBound42886 : H12AffineFastState.Bounded env42886 := by
  intro p hp
  have h : env42886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42885_42886 : H12AffineEnvironment.transform 8 10 env42885 = env42886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env42885 == env42886) = true)

def leafEnv42886 : List Nat := [2,4,8,16,32,17,8,37,10,53,33,48,40,33,1,35,49,33,52,0,33,33,17,2,20,40,1,16,33,49,48,33,21,33,36,32,5,35,33,11,1,33,0]

def active42886 : List Nat := [0,1,2,3,4]

def tree42886 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42886 : H12WitnessSearch.Good tree42886 := H12GlobalWitnessIndex.good

theorem leafIdentity42886 : H12AffineFastState.composeSystem env42886 rootObs = leafEnv42886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42886 rootObs == leafEnv42886) = true)

theorem terminalChecked42886 : H12PackedTerminal.terminalCheckFast leafEnv42886 active42886 tree42886 = true := by decide +kernel

def env42887 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1045,1,35,1029,2048,1025,0,32,33,17,2,40,16,2048,1029,49,2048,1056,33,36,32,1045,513]

theorem envBound42887 : H12AffineFastState.Bounded env42887 := by
  intro p hp
  have h : env42887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42880_42887 : H12AffineEnvironment.transform 11 49 env42880 = env42887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env42880 == env42887) = true)

theorem identity42887 : scanCanonicalize (H12AffineFastState.compose env42887 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound42887 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42888 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,49,40,1045,1,35,1029,32,1025,0,32,33,17,2,40,16,32,1029,49,32,1056,33,36,32,1045,513]

theorem envBound42888 : H12AffineFastState.Bounded env42888 := by
  intro p hp
  have h : env42888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42887_42888 : H12AffineEnvironment.transform 10 32 env42887 = env42888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env42887 == env42888) = true)

def env42889 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,49,40,33,1,35,49,32,53,0,32,33,17,2,40,16,32,49,49,32,20,33,36,32,33,513]

theorem envBound42889 : H12AffineFastState.Bounded env42889 := by
  intro p hp
  have h : env42889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42888_42889 : H12AffineEnvironment.transform 9 52 env42888 = env42889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42888 == env42889) = true)

theorem identity42889 : scanCanonicalize (H12AffineFastState.compose env42889 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42889 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42890 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,16,9,0,1,2,16,1,20,0,1,0,17,2,9,16,1,16,16,1,20,0,5,1,0,513]

theorem envBound42890 : H12AffineFastState.Bounded env42890 := by
  intro p hp
  have h : env42890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42889_42890 : H12AffineEnvironment.transform 4 1 env42889 = env42890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42889 == env42890) = true)

def leafEnv42890 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,16,9,0,1,2,16,1,20,0,1,0,17,2,21,9,1,16,1,16,16,1,20,0,5,1,5,2,0,513,1,1,0]

def active42890 : List Nat := [0,1,2,3,8]

def tree42890 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42890 : H12WitnessSearch.Good tree42890 := H12GlobalWitnessIndex.good

theorem leafIdentity42890 : H12AffineFastState.composeSystem env42890 rootObs = leafEnv42890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42890 rootObs == leafEnv42890) = true)

theorem terminalChecked42890 : H12PackedTerminal.terminalCheckFast leafEnv42890 active42890 tree42890 = true := by decide +kernel

def env42891 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,40,32,1,35,48,32,52,0,32,33,17,2,40,16,32,48,49,32,21,33,36,32,32,513]

theorem envBound42891 : H12AffineFastState.Bounded env42891 := by
  intro p hp
  have h : env42891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42888_42891 : H12AffineEnvironment.transform 9 53 env42888 = env42891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42888 == env42891) = true)

theorem identity42891 : scanCanonicalize (H12AffineFastState.compose env42891 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound42891 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42892 : List Nat := [2,4,8,16,32,17,8,37,11,53,32,49,40,32,1,35,48,32,52,0,32,33,17,2,40,16,32,48,49,32,21,33,36,32,32,10]

theorem envBound42892 : H12AffineFastState.Bounded env42892 := by
  intro p hp
  have h : env42892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42891_42892 : H12AffineEnvironment.transform 8 11 env42891 = env42892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env42891 == env42892) = true)

def leafEnv42892 : List Nat := [2,4,8,16,32,17,8,37,11,53,32,49,40,32,1,35,48,32,52,0,32,33,17,2,20,40,1,16,32,48,49,32,21,33,36,32,5,35,32,10,1,32,0]

def active42892 : List Nat := [0,1,2,3,4]

def tree42892 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42892 : H12WitnessSearch.Good tree42892 := H12GlobalWitnessIndex.good

theorem leafIdentity42892 : H12AffineFastState.composeSystem env42892 rootObs = leafEnv42892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42892 rootObs == leafEnv42892) = true)

theorem terminalChecked42892 : H12PackedTerminal.terminalCheckFast leafEnv42892 active42892 tree42892 = true := by decide +kernel

def env42893 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,77899,21793,17,21763,8192,65,203847,5393,91402,138341,75103,21793,257,21793,16465,513]

theorem envBound42893 : H12AffineFastState.Bounded env42893 := by
  intro p hp
  have h : env42893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42873_42893 : H12AffineEnvironment.transform 21 21793 env42873 = env42893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env42873 == env42893) = true)

theorem identity42893 : scanCanonicalize (H12AffineFastState.compose env42893 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound42893 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env42894 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,65536,131072,10280,1025,1,77899,8573,17,8543,8192,65,203847,5393,69974,138341,75103,8573,257,8573,13325,513]

theorem envBound42894 : H12AffineFastState.Bounded env42894 := by
  intro p hp
  have h : env42894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42893_42894 : H12AffineEnvironment.transform 13 13404 env42893 = env42894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env42893 == env42894) = true)

theorem identity42894 : scanCanonicalize (H12AffineFastState.compose env42894 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound42894 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env42895 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,8283,131072,10280,1025,1,4112,8573,17,8543,8192,65,146460,5393,12557,138341,1284,8573,257,8573,13325,513]

theorem envBound42895 : H12AffineFastState.Bounded env42895 := by
  intro p hp
  have h : env42895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42894_42895 : H12AffineEnvironment.transform 15 8283 env42894 = env42895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env42894 == env42895) = true)

theorem identity42895 : scanCanonicalize (H12AffineFastState.compose env42895 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound42895 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42896 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,8283,5441,10280,1025,1,4112,8573,17,8543,8192,65,10589,5393,12557,2340,1284,8573,257,8573,13325,513]

theorem envBound42896 : H12AffineFastState.Bounded env42896 := by
  intro p hp
  have h : env42896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42895_42896 : H12AffineEnvironment.transform 16 5441 env42895 = env42896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env42895 == env42896) = true)

theorem identity42896 : scanCanonicalize (H12AffineFastState.compose env42896 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound42896 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env42897 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,263,5441,2420,1025,1,4112,33,17,3,348,65,2049,5393,4177,2340,1284,33,257,33,5457,513]

theorem envBound42897 : H12AffineFastState.Bounded env42897 := by
  intro p hp
  have h : env42897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42896_42897 : H12AffineEnvironment.transform 12 348 env42896 = env42897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env42896 == env42897) = true)

theorem identity42897 : scanCanonicalize (H12AffineFastState.compose env42897 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42897 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42898 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,263,5393,2340,1025,1,4112,33,17,3,268,17,2049,5393,4097,2340,1284,33,257,33,5377,513]

theorem envBound42898 : H12AffineFastState.Bounded env42898 := by
  intro p hp
  have h : env42898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42897_42898 : H12AffineEnvironment.transform 5 16 env42897 = env42898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42897 == env42898) = true)

theorem identity42898 : scanCanonicalize (H12AffineFastState.compose env42898 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound42898 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42899 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1,268,1281,0,263,1296,2340,1025,1,17,33,17,3,268,17,2049,1296,0,2340,1284,33,257,33,1280,513]

theorem envBound42899 : H12AffineFastState.Bounded env42899 := by
  intro p hp
  have h : env42899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42898_42899 : H12AffineEnvironment.transform 11 1 env42898 = env42899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env42898 == env42899) = true)

theorem identity42899 : scanCanonicalize (H12AffineFastState.compose env42899 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound42899 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42900 : List Nat := [2,4,8,16,32,16,8,256,512,1024,319,1,268,1281,0,263,1296,27,1025,1,17,33,17,3,268,17,318,1296,0,27,1284,33,257,33,1280,513]

theorem envBound42900 : H12AffineFastState.Bounded env42900 := by
  intro p hp
  have h : env42900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42899_42900 : H12AffineEnvironment.transform 10 319 env42899 = env42900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env42899 == env42900) = true)

theorem identity42900 : scanCanonicalize (H12AffineFastState.compose env42900 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound42900 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42901 : List Nat := [2,4,8,16,32,16,8,256,512,21,319,1,268,276,0,263,261,27,20,1,17,33,17,3,268,17,318,261,0,27,273,33,257,33,277,513]

theorem envBound42901 : H12AffineFastState.Bounded env42901 := by
  intro p hp
  have h : env42901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42900_42901 : H12AffineEnvironment.transform 9 21 env42900 = env42901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env42900 == env42901) = true)

theorem identity42901 : scanCanonicalize (H12AffineFastState.compose env42901 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound42901 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42902 : List Nat := [2,4,8,16,32,16,8,52,512,21,11,1,56,32,0,51,49,27,20,1,17,33,17,3,56,17,10,49,0,27,37,33,53,33,33,513]

theorem envBound42902 : H12AffineFastState.Bounded env42902 := by
  intro p hp
  have h : env42902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42901_42902 : H12AffineEnvironment.transform 7 52 env42901 = env42902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env42901 == env42902) = true)

theorem identity42902 : scanCanonicalize (H12AffineFastState.compose env42902 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound42902 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42903 : List Nat := [2,4,8,16,26,16,8,14,512,21,11,1,2,26,0,9,11,27,20,1,17,27,17,3,2,17,10,11,0,27,31,27,15,27,27,513]

theorem envBound42903 : H12AffineFastState.Bounded env42903 := by
  intro p hp
  have h : env42903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42902_42903 : H12AffineEnvironment.transform 4 26 env42902 = env42903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env42902 == env42903) = true)

theorem identity42903 : scanCanonicalize (H12AffineFastState.compose env42903 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42903 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env42904 : List Nat := [2,4,2,16,16,16,2,4,512,21,1,1,2,16,0,3,1,17,20,1,17,17,17,3,2,17,0,1,0,17,21,17,5,17,17,513]

theorem envBound42904 : H12AffineFastState.Bounded env42904 := by
  intro p hp
  have h : env42904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42903_42904 : H12AffineEnvironment.transform 2 2 env42903 = env42904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42903 == env42904) = true)

theorem identity42904 : scanCanonicalize (H12AffineFastState.compose env42904 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 19) := by decide +kernel

theorem selectedBound42904 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42905 : List Nat := [2,4,2,16,16,16,2,4,19,21,1,1,2,16,0,3,1,17,20,1,17,17,17,3,2,17,0,1,0,17,21,17,5,17,17,18]

theorem envBound42905 : H12AffineFastState.Bounded env42905 := by
  intro p hp
  have h : env42905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42904_42905 : H12AffineEnvironment.transform 8 19 env42904 = env42905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 19 env42904 == env42905) = true)

theorem identity42905 : scanCanonicalize (H12AffineFastState.compose env42905 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42905 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env42906 : List Nat := [2,4,2,0,0,0,2,4,3,5,1,1,2,0,0,3,1,1,4,1,1,1,1,3,2,1,0,1,0,1,5,1,5,1,1,2]

theorem envBound42906 : H12AffineFastState.Bounded env42906 := by
  intro p hp
  have h : env42906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42905_42906 : H12AffineEnvironment.transform 3 0 env42905 = env42906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42905 == env42906) = true)

theorem identity42906 : scanCanonicalize (H12AffineFastState.compose env42906 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42906 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42907 : List Nat := [2,3,2,0,0,0,2,3,3,2,1,1,2,0,0,3,1,1,3,1,1,1,1,3,2,1,0,1,0,1,2,1,2,1,1,2]

theorem envBound42907 : H12AffineFastState.Bounded env42907 := by
  intro p hp
  have h : env42907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42906_42907 : H12AffineEnvironment.transform 1 3 env42906 = env42907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42906 == env42907) = true)

def env42908 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,77899,4194304,16,21763,8192,65,4409702,5392,91403,138341,75103,4194304,257,21793,16464,513]

theorem envBound42908 : H12AffineFastState.Bounded env42908 := by
  intro p hp
  have h : env42908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42872_42908 : H12AffineEnvironment.transform 14 29789 env42872 = env42908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env42872 == env42908) = true)

theorem identity42908 : scanCanonicalize (H12AffineFastState.compose env42908 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound42908 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,77899,4194304,16,21763,8192,65,4204925,5392,91403,97406,75103,4194304,257,21793,16464,513]

theorem envBound42909 : H12AffineFastState.Bounded env42909 := by
  intro p hp
  have h : env42909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42908_42909 : H12AffineEnvironment.transform 16 90139 env42908 = env42909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env42908 == env42909) = true)

theorem identity42909 : scanCanonicalize (H12AffineFastState.compose env42909 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound42909 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,77899,73771,16,21763,8192,65,67926,5392,91403,97406,75103,73771,257,21793,16464,513]

theorem envBound42910 : H12AffineFastState.Bounded env42910 := by
  intro p hp
  have h : env42910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42909_42910 : H12AffineEnvironment.transform 21 73771 env42909 = env42910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env42909 == env42910) = true)

theorem identity42910 : scanCanonicalize (H12AffineFastState.compose env42910 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42910 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env42911 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,16401,10280,1025,29788,4161,33,16,21763,8192,65,10588,5392,17665,23668,1365,33,257,21793,16464,513]

theorem envBound42911 : H12AffineFastState.Bounded env42911 := by
  intro p hp
  have h : env42911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42910_42911 : H12AffineEnvironment.transform 15 8202 env42910 = env42911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42910 == env42911) = true)

theorem identity42911 : scanCanonicalize (H12AffineFastState.compose env42911 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound42911 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42912 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8460,8202,5440,10280,1025,8461,4161,33,16,82,8192,65,10588,5392,4176,2341,1365,33,257,112,5377,513]

theorem envBound42912 : H12AffineFastState.Bounded env42912 := by
  intro p hp
  have h : env42912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42911_42912 : H12AffineEnvironment.transform 13 5457 env42911 = env42912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env42911 == env42912) = true)

theorem identity42912 : scanCanonicalize (H12AffineFastState.compose env42912 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound42912 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42913 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,356,8192,1077,8460,8202,1060,10280,1025,8461,293,33,16,82,8192,65,10588,1140,308,2341,1365,33,257,112,1125,513]

theorem envBound42913 : H12AffineFastState.Bounded env42913 := by
  intro p hp
  have h : env42913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42912_42913 : H12AffineEnvironment.transform 11 356 env42912 = env42913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env42912 == env42913) = true)

theorem identity42913 : scanCanonicalize (H12AffineFastState.compose env42913 (packedSelected [0,1,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound42913 : packedSelected [0,1,5,6,7] rootPS < 2^1333 := by decide +kernel

def env42914 : List Nat := [2,4,8,16,32,32,8,256,512,1024,2048,260,8192,1077,8460,8202,1060,10280,1025,8461,293,33,16,50,8192,33,10556,1044,308,2341,1333,33,257,16,1029,513]

theorem envBound42914 : H12AffineFastState.Bounded env42914 := by
  intro p hp
  have h : env42914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42913_42914 : H12AffineEnvironment.transform 5 32 env42913 = env42914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env42913 == env42914) = true)

theorem identity42914 : scanCanonicalize (H12AffineFastState.compose env42914 (packedSelected [1,5,6,11] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound42914 : packedSelected [1,5,6,11] rootPS < 2^1333 := by decide +kernel

def env42915 : List Nat := [2,4,8,16,17,17,8,256,512,1024,2048,260,8192,1028,8460,8202,1045,10265,1025,8461,276,16,16,3,8192,16,10509,1044,261,2324,1284,16,257,16,1029,513]

theorem envBound42915 : H12AffineFastState.Bounded env42915 := by
  intro p hp
  have h : env42915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42914_42915 : H12AffineEnvironment.transform 4 17 env42914 = env42915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env42914 == env42915) = true)

theorem identity42915 : scanCanonicalize (H12AffineFastState.compose env42915 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42915 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42916 : List Nat := [2,4,8,16,17,17,8,5,512,1024,2048,1,8192,1028,8201,8202,1045,10265,1025,8200,17,16,16,3,8192,16,10248,1044,0,2065,1025,16,4,16,1029,513]

theorem envBound42916 : H12AffineFastState.Bounded env42916 := by
  intro p hp
  have h : env42916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42915_42916 : H12AffineEnvironment.transform 7 5 env42915 = env42916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42915 == env42916) = true)

theorem identity42916 : scanCanonicalize (H12AffineFastState.compose env42916 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound42916 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42917 : List Nat := [2,4,8,16,17,17,8,5,512,1024,2048,1,9,1028,0,3,1045,2064,1025,1,17,16,16,3,9,16,2049,1044,0,2065,1025,16,4,16,1029,513]

theorem envBound42917 : H12AffineFastState.Bounded env42917 := by
  intro p hp
  have h : env42917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42916_42917 : H12AffineEnvironment.transform 12 9 env42916 = env42917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env42916 == env42917) = true)

def env42918 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,77899,4194304,62540,21762,8192,65,4409703,57676,102743,138341,75103,4194305,257,21793,46093,513]

theorem envBound42918 : H12AffineFastState.Bounded env42918 := by
  intro p hp
  have h : env42918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42871_42918 : H12AffineEnvironment.transform 17 10281 env42871 = env42918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42871 == env42918) = true)

theorem identity42918 : scanCanonicalize (H12AffineFastState.compose env42918 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound42918 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env42919 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1025,29788,77899,4194304,17,21762,8192,65,4409703,5393,91402,138341,75103,4194305,257,21793,16464,513]

theorem envBound42919 : H12AffineFastState.Bounded env42919 := by
  intro p hp
  have h : env42919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42918_42919 : H12AffineEnvironment.transform 14 29789 env42918 = env42919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env42918 == env42919) = true)

theorem identity42919 : scanCanonicalize (H12AffineFastState.compose env42919 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42919 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42920 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,10281,1025,29788,4160,4194304,17,21762,8192,65,4352364,5393,17665,138341,1364,4194305,257,21793,16464,513]

theorem envBound42920 : H12AffineFastState.Bounded env42920 := by
  intro p hp
  have h : env42920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42919_42920 : H12AffineEnvironment.transform 15 8203 env42919 = env42920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42919 == env42920) = true)

theorem identity42920 : scanCanonicalize (H12AffineFastState.compose env42920 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 29741) := by decide +kernel

theorem selectedBound42920 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env42921 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,10281,1025,29788,4160,29741,17,21762,8192,65,138561,5393,17665,138341,1364,29740,257,21793,16464,513]

theorem envBound42921 : H12AffineFastState.Bounded env42921 := by
  intro p hp
  have h : env42921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42920_42921 : H12AffineEnvironment.transform 21 29741 env42920 = env42921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29741 env42920 == env42921) = true)

theorem identity42921 : scanCanonicalize (H12AffineFastState.compose env42921 (packedSelected [1,4,8,9,10,12,18] rootPS)) = affineNative (2^(16+1) ^^^ 23605) := by decide +kernel

theorem selectedBound42921 : packedSelected [1,4,8,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env42922 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,23605,10281,1025,29788,4160,29741,17,21762,8192,65,16756,5393,17665,16464,1364,29740,257,21793,16464,513]

theorem envBound42922 : H12AffineFastState.Bounded env42922 := by
  intro p hp
  have h : env42922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42921_42922 : H12AffineEnvironment.transform 16 23605 env42921 = env42922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 23605 env42921 == env42922) = true)

theorem identity42922 : scanCanonicalize (H12AffineFastState.compose env42922 (packedSelected [0,4,7,9,11,20] rootPS)) = affineNative (2^(13+1) ^^^ 15453) := by decide +kernel

theorem selectedBound42922 : packedSelected [0,4,7,9,11,20] rootPS < 2^1333 := by decide +kernel

def env42923 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,15453,2048,8203,8296,10281,1025,2049,4160,2160,17,10591,8192,65,15657,5393,14684,15373,1364,2161,257,10620,15373,513]

theorem envBound42923 : H12AffineFastState.Bounded env42923 := by
  intro p hp
  have h : env42923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42922_42923 : H12AffineEnvironment.transform 13 15453 env42922 = env42923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15453 env42922 == env42923) = true)

theorem identity42923 : scanCanonicalize (H12AffineFastState.compose env42923 (packedSelected [1,2,5,6,8,12,15,24] rootPS)) = affineNative (2^(12+1) ^^^ 6201) := by decide +kernel

theorem selectedBound42923 : packedSelected [1,2,5,6,8,12,15,24] rootPS < 2^1333 := by decide +kernel

def env42924 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6201,1124,2048,6194,6225,4112,1025,2049,4160,2160,17,4454,6201,65,1296,5393,357,1076,1364,2161,257,4421,1076,513]

theorem envBound42924 : H12AffineFastState.Bounded env42924 := by
  intro p hp
  have h : env42924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42923_42924 : H12AffineEnvironment.transform 12 6201 env42923 = env42924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6201 env42923 == env42924) = true)

theorem identity42924 : scanCanonicalize (H12AffineFastState.compose env42924 (packedSelected [1,2,3,5,6,8,10,12,15,26] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound42924 : packedSelected [1,2,3,5,6,8,10,12,15,26] rootPS < 2^1333 := by decide +kernel

def env42925 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3109,1052,1124,2048,1047,1140,3125,1025,2049,3173,2160,17,3395,1052,65,1296,2356,357,1076,1364,2161,257,3424,1076,513]

theorem envBound42925 : H12AffineFastState.Bounded env42925 := by
  intro p hp
  have h : env42925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42924_42925 : H12AffineEnvironment.transform 11 3109 env42924 = env42925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env42924 == env42925) = true)

theorem identity42925 : scanCanonicalize (H12AffineFastState.compose env42925 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42925 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42926 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3109,1052,1124,2048,1047,1140,3125,1025,2049,3173,2160,17,3126,1052,65,1125,2113,16,1076,1057,2161,116,3093,1076,513]

theorem envBound42926 : H12AffineFastState.Bounded env42926 := by
  intro p hp
  have h : env42926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42925_42926 : H12AffineEnvironment.transform 7 117 env42925 = env42926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42925 == env42926) = true)

theorem identity42926 : scanCanonicalize (H12AffineFastState.compose env42926 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42926 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env42927 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,3109,1052,1076,2048,1047,1060,3125,1025,2049,3125,2080,17,3126,1052,17,1077,2065,16,1076,1057,2081,36,3093,1076,513]

theorem envBound42927 : H12AffineFastState.Bounded env42927 := by
  intro p hp
  have h : env42927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42926_42927 : H12AffineEnvironment.transform 5 16 env42926 = env42927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42926 == env42927) = true)

theorem identity42927 : scanCanonicalize (H12AffineFastState.compose env42927 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound42927 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42928 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1,1060,1052,1076,1,1047,1060,1076,1025,0,1076,33,17,1079,1052,17,1077,16,16,1076,1057,32,36,1044,1076,513]

theorem envBound42928 : H12AffineFastState.Bounded env42928 := by
  intro p hp
  have h : env42928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42927_42928 : H12AffineEnvironment.transform 10 1 env42927 = env42928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env42927 == env42928) = true)

theorem identity42928 : scanCanonicalize (H12AffineFastState.compose env42928 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42928 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42929 : List Nat := [2,4,8,16,1,16,8,4,512,1024,1,1029,1052,1045,1,1047,1029,1045,1025,0,1045,0,17,1046,1052,17,1044,16,16,1045,1024,1,5,1044,1045,513]

theorem envBound42929 : H12AffineFastState.Bounded env42929 := by
  intro p hp
  have h : env42929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42928_42929 : H12AffineEnvironment.transform 4 1 env42928 = env42929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42928 == env42929) = true)

theorem identity42929 : scanCanonicalize (H12AffineFastState.compose env42929 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound42929 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42930 : List Nat := [2,4,8,16,1,16,8,4,512,5,1,0,25,16,1,18,0,16,4,0,16,0,17,19,25,17,17,16,16,16,5,1,5,17,16,513]

theorem envBound42930 : H12AffineFastState.Bounded env42930 := by
  intro p hp
  have h : env42930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42929_42930 : H12AffineEnvironment.transform 9 5 env42929 = env42930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env42929 == env42930) = true)

theorem identity42930 : scanCanonicalize (H12AffineFastState.compose env42930 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound42930 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42931 : List Nat := [2,4,8,16,1,16,8,4,16,5,1,0,25,16,1,18,0,16,4,0,16,0,17,19,25,17,17,16,16,16,5,1,5,17,16,17]

theorem envBound42931 : H12AffineFastState.Bounded env42931 := by
  intro p hp
  have h : env42931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42930_42931 : H12AffineEnvironment.transform 8 16 env42930 = env42931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env42930 == env42931) = true)

theorem identity42931 : scanCanonicalize (H12AffineFastState.compose env42931 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42931 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env42932 : List Nat := [2,4,8,0,1,0,8,4,0,5,1,0,9,0,1,2,0,0,4,0,0,0,1,3,9,1,1,0,0,0,5,1,5,1,0,1]

theorem envBound42932 : H12AffineFastState.Bounded env42932 := by
  intro p hp
  have h : env42932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42931_42932 : H12AffineEnvironment.transform 3 0 env42931 = env42932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42931 == env42932) = true)

def env42933 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318565,2444641,8193,65,6705412,313701,2394421,138341,2102549,4466728,257,21793,46092,2175562]

theorem envBound42933 : H12AffineFastState.Bounded env42933 := by
  intro p hp
  have h : env42933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42869_42933 : H12AffineEnvironment.transform 6 9 env42869 = env42933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42869 == env42933) = true)

def env42934 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373704,318565,2444641,8193,65,158028,313701,2394421,138341,2102549,2101344,257,21793,46092,2175562]

theorem envBound42934 : H12AffineFastState.Bounded env42934 := by
  intro p hp
  have h : env42934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42933_42934 : H12AffineEnvironment.transform 21 2373704 env42933 = env42934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373704 env42933 == env42934) = true)

theorem identity42934 : scanCanonicalize (H12AffineFastState.compose env42934 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound42934 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env42935 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,77899,329731,318565,294186,8193,65,158028,313701,375166,138341,75102,73771,257,21793,46092,513]

theorem envBound42935 : H12AffineFastState.Bounded env42935 := by
  intro p hp
  have h : env42935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42934_42935 : H12AffineEnvironment.transform 20 77899 env42934 = env42935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env42934 == env42935) = true)

theorem identity42935 : scanCanonicalize (H12AffineFastState.compose env42935 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound42935 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42936 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,77899,329731,318565,294186,8193,65,67927,313701,375166,97406,75102,73771,257,21793,46092,513]

theorem envBound42936 : H12AffineFastState.Bounded env42936 := by
  intro p hp
  have h : env42936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42935_42936 : H12AffineEnvironment.transform 16 90139 env42935 = env42936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env42935 == env42936) = true)

theorem identity42936 : scanCanonicalize (H12AffineFastState.compose env42936 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound42936 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env42937 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,130175,1025,32769,77899,62588,73754,98645,8193,65,67927,79130,17665,97406,75102,73771,257,21793,46092,513]

theorem envBound42937 : H12AffineFastState.Bounded env42937 := by
  intro p hp
  have h : env42937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42936_42937 : H12AffineEnvironment.transform 17 130175 env42936 = env42937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env42936 == env42937) = true)

theorem identity42937 : scanCanonicalize (H12AffineFastState.compose env42937 (packedSelected [2,4,6,9,11,14,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound42937 : packedSelected [2,4,6,9,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env42938 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,262,24861,64889,1025,32769,12621,62588,8476,32851,8193,65,2129,13340,17665,32120,9304,8493,257,21793,46092,513]

theorem envBound42938 : H12AffineFastState.Bounded env42938 := by
  intro p hp
  have h : env42938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42937_42938 : H12AffineEnvironment.transform 15 262 env42937 = env42938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env42937 == env42938) = true)

theorem identity42938 : scanCanonicalize (H12AffineFastState.compose env42938 (packedSelected [2,3,4,5,6,9,10,12,14,15,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound42938 : packedSelected [2,3,4,5,6,9,10,12,14,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env42939 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,262,13673,43277,1025,32769,12621,40968,8476,32851,8193,65,2129,13340,4469,10508,9304,8493,257,341,46092,513]

theorem envBound42939 : H12AffineFastState.Bounded env42939 := by
  intro p hp
  have h : env42939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42938_42939 : H12AffineEnvironment.transform 13 5236 env42938 = env42939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env42938 == env42939) = true)

theorem identity42939 : scanCanonicalize (H12AffineFastState.compose env42939 (packedSelected [0,2,7,11,14,17,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound42939 : packedSelected [0,2,7,11,14,17,18,20] rootPS < 2^1333 := by decide +kernel

def env42940 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,4112,32768,262,12557,43277,101,32769,12621,40968,8476,32851,8193,65,2129,12408,4469,10508,8252,8493,257,341,45160,513]

theorem envBound42940 : H12AffineFastState.Bounded env42940 := by
  intro p hp
  have h : env42940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42939_42940 : H12AffineEnvironment.transform 9 100 env42939 = env42940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env42939 == env42940) = true)

theorem identity42940 : scanCanonicalize (H12AffineFastState.compose env42940 (packedSelected [1,2,6,7,8,9,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound42940 : packedSelected [1,2,6,7,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env42941 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,4112,8460,262,12557,2049,101,8461,12621,260,8476,8543,8193,65,2129,12408,4469,10508,8252,8493,257,341,4452,513]

theorem envBound42941 : H12AffineFastState.Bounded env42941 := by
  intro p hp
  have h : env42941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42940_42941 : H12AffineEnvironment.transform 14 8460 env42940 = env42941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env42940 == env42941) = true)

theorem identity42941 : scanCanonicalize (H12AffineFastState.compose env42941 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound42941 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env42942 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,121,4112,373,262,4468,2049,101,372,4404,260,357,294,120,65,2129,4097,4469,2421,69,340,257,341,4452,513]

theorem envBound42942 : H12AffineFastState.Bounded env42942 := by
  intro p hp
  have h : env42942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42941_42942 : H12AffineEnvironment.transform 12 121 env42941 = env42942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env42941 == env42942) = true)

theorem identity42942 : scanCanonicalize (H12AffineFastState.compose env42942 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound42942 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env42943 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,4096,121,4112,1,114,4096,2049,101,0,4160,112,17,82,120,65,2129,4097,4097,2049,69,32,117,33,4112,513]

theorem envBound42943 : H12AffineFastState.Bounded env42943 := by
  intro p hp
  have h : env42943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42942_42943 : H12AffineEnvironment.transform 7 116 env42942 = env42943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env42942 == env42943) = true)

def env42944 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2373705,318565,2444641,8193,65,158029,313701,2394421,138341,2102549,2101345,257,21793,46092,2175562]

theorem envBound42944 : H12AffineFastState.Bounded env42944 := by
  intro p hp
  have h : env42944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42933_42944 : H12AffineEnvironment.transform 21 2373705 env42933 = env42944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373705 env42933 == env42944) = true)

def env42945 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,272393,318565,351521,8193,65,158029,313701,301429,138341,1365,33,257,21793,46092,74250]

theorem envBound42945 : H12AffineFastState.Bounded env42945 := by
  intro p hp
  have h : env42945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42944_42945 : H12AffineEnvironment.transform 20 4160 env42944 = env42945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env42944 == env42945) = true)

theorem identity42945 : scanCanonicalize (H12AffineFastState.compose env42945 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound42945 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42946 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,21792,41292,73736,8193,65,158029,46156,58460,138341,1365,33,257,21793,46092,74250]

theorem envBound42946 : H12AffineFastState.Bounded env42946 := by
  intro p hp
  have h : env42946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42945_42946 : H12AffineEnvironment.transform 17 32041 env42945 = env42946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env42945 == env42946) = true)

theorem identity42946 : scanCanonicalize (H12AffineFastState.compose env42946 (packedSelected [1,5,8,16,19,20,21,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound42946 : packedSelected [1,5,8,16,19,20,21,24,26] rootPS < 2^1333 := by decide +kernel

def env42947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,46156,32041,1025,32769,4160,21792,41292,73736,8193,65,56577,46156,58460,43049,1365,33,257,21793,46092,74250]

theorem envBound42947 : H12AffineFastState.Bounded env42947 := by
  intro p hp
  have h : env42947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42946_42947 : H12AffineEnvironment.transform 16 46156 env42946 = env42947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env42946 == env42947) = true)

theorem identity42947 : scanCanonicalize (H12AffineFastState.compose env42947 (packedSelected [3,5,8,10,21,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound42947 : packedSelected [3,5,8,10,21,28,31] rootPS < 2^1333 := by decide +kernel

def env42948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,46156,10280,1025,32769,4160,33,41292,73736,8193,65,34816,46156,45405,43049,1365,33,257,32,46092,74250]

theorem envBound42948 : H12AffineFastState.Bounded env42948 := by
  intro p hp
  have h : env42948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42947_42948 : H12AffineEnvironment.transform 13 5377 env42947 = env42948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42947 == env42948) = true)

theorem identity42948 : scanCanonicalize (H12AffineFastState.compose env42948 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42948 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env42949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,46156,10280,1025,32769,4160,33,41292,3,8193,65,34816,46156,45405,43049,1365,33,257,32,46092,513]

theorem envBound42949 : H12AffineFastState.Bounded env42949 := by
  intro p hp
  have h : env42949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42948_42949 : H12AffineEnvironment.transform 15 8203 env42948 = env42949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42948 == env42949) = true)

theorem identity42949 : scanCanonicalize (H12AffineFastState.compose env42949 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound42949 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42950 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,5377,32768,294,38241,2309,1025,32769,4160,33,32865,3,300,65,34816,38241,36976,35076,1365,33,257,32,38177,513]

theorem envBound42950 : H12AffineFastState.Bounded env42950 := by
  intro p hp
  have h : env42950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42949_42950 : H12AffineEnvironment.transform 12 301 env42949 = env42950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env42949 == env42950) = true)

theorem identity42950 : scanCanonicalize (H12AffineFastState.compose env42950 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound42950 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env42951 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1281,301,0,32768,294,32864,2309,1025,32769,1345,33,32865,3,300,65,34816,32864,34161,35076,1365,33,257,32,32800,513]

theorem envBound42951 : H12AffineFastState.Bounded env42951 := by
  intro p hp
  have h : env42951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42950_42951 : H12AffineEnvironment.transform 11 1281 env42950 = env42951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env42950 == env42951) = true)

theorem identity42951 : scanCanonicalize (H12AffineFastState.compose env42951 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 2308) := by decide +kernel

theorem selectedBound42951 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env42952 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1281,301,0,2308,294,2404,2309,1025,2309,1345,33,2405,3,300,65,260,2404,3189,0,1365,33,257,32,2340,513]

theorem envBound42952 : H12AffineFastState.Bounded env42952 := by
  intro p hp
  have h : env42952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42951_42952 : H12AffineEnvironment.transform 14 2308 env42951 = env42952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2308 env42951 == env42952) = true)

theorem identity42952 : scanCanonicalize (H12AffineFastState.compose env42952 (packedSelected [6,14] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound42952 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env42953 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,1281,301,0,1376,294,1280,1377,1025,1377,1345,33,1281,3,300,65,260,1280,17,0,1365,33,257,32,1344,513]

theorem envBound42953 : H12AffineFastState.Bounded env42953 := by
  intro p hp
  have h : env42953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42952_42953 : H12AffineEnvironment.transform 10 1124 env42952 = env42953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env42952 == env42953) = true)

theorem identity42953 : scanCanonicalize (H12AffineFastState.compose env42953 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42953 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42954 : List Nat := [2,4,8,16,32,64,9,36,512,1024,1124,1061,9,0,1092,2,1060,1093,1025,1093,1125,33,1061,3,8,65,32,1060,17,0,1137,33,37,32,1124,513]

theorem envBound42954 : H12AffineFastState.Bounded env42954 := by
  intro p hp
  have h : env42954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42953_42954 : H12AffineEnvironment.transform 7 36 env42953 = env42954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42953 == env42954) = true)

theorem identity42954 : scanCanonicalize (H12AffineFastState.compose env42954 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound42954 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env42955 : List Nat := [2,4,8,16,32,64,9,36,16,1024,1124,1061,9,0,1092,2,1060,1093,1025,1093,1125,33,1061,3,8,65,32,1060,17,0,1137,33,37,32,1124,17]

theorem envBound42955 : H12AffineFastState.Bounded env42955 := by
  intro p hp
  have h : env42955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42954_42955 : H12AffineEnvironment.transform 8 16 env42954 = env42955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env42954 == env42955) = true)

theorem identity42955 : scanCanonicalize (H12AffineFastState.compose env42955 (packedSelected [1,6,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42955 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env42956 : List Nat := [2,4,8,1,32,64,9,36,1,1024,1124,1061,9,0,1092,2,1060,1093,1025,1093,1125,33,1061,3,8,65,32,1060,0,0,1120,33,37,32,1124,0]

theorem envBound42956 : H12AffineFastState.Bounded env42956 := by
  intro p hp
  have h : env42956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42955_42956 : H12AffineEnvironment.transform 3 1 env42955 = env42956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42955 == env42956) = true)

theorem identity42956 : scanCanonicalize (H12AffineFastState.compose env42956 (packedSelected [0,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound42956 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env42957 : List Nat := [2,4,8,1,32,64,9,36,1,68,32,97,9,0,0,2,96,1,69,1,33,33,97,3,8,65,32,96,0,0,36,33,37,32,32,0]

theorem envBound42957 : H12AffineFastState.Bounded env42957 := by
  intro p hp
  have h : env42957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42956_42957 : H12AffineEnvironment.transform 9 68 env42956 = env42957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env42956 == env42957) = true)

theorem identity42957 : scanCanonicalize (H12AffineFastState.compose env42957 (packedSelected [0,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42957 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env42958 : List Nat := [2,4,8,1,1,64,9,5,1,68,1,64,9,0,0,2,65,1,69,1,0,0,64,3,8,65,1,65,0,0,5,0,4,1,1,0]

theorem envBound42958 : H12AffineFastState.Bounded env42958 := by
  intro p hp
  have h : env42958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42957_42958 : H12AffineEnvironment.transform 4 1 env42957 = env42958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42957 == env42958) = true)

def env42959 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,272392,318565,351520,8193,65,158029,313701,301428,138341,1364,32,257,21793,46092,74251]

theorem envBound42959 : H12AffineFastState.Bounded env42959 := by
  intro p hp
  have h : env42959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42944_42959 : H12AffineEnvironment.transform 20 4161 env42944 = env42959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env42944 == env42959) = true)

theorem identity42959 : scanCanonicalize (H12AffineFastState.compose env42959 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42959 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42960 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1025,32769,4161,272392,297317,329760,8193,65,146509,302181,301428,138341,1364,32,257,33,46092,74251]

theorem envBound42960 : H12AffineFastState.Bounded env42960 := by
  intro p hp
  have h : env42960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42959_42960 : H12AffineEnvironment.transform 13 5376 env42959 = env42960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42959 == env42960) = true)

theorem identity42960 : scanCanonicalize (H12AffineFastState.compose env42960 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound42960 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env42961 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67619,1025,32769,4161,73771,98630,3,8193,65,146509,103494,102743,138341,1364,32,257,33,46092,74251]

theorem envBound42961 : H12AffineFastState.Bounded env42961 := by
  intro p hp
  have h : env42961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42960_42961 : H12AffineEnvironment.transform 17 67619 env42960 = env42961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env42960 == env42961) = true)

theorem identity42961 : scanCanonicalize (H12AffineFastState.compose env42961 (packedSelected [0,1,6,7,8,10,15,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 70759) := by decide +kernel

theorem selectedBound42961 : packedSelected [0,1,6,7,8,10,15,21,23] rootPS < 2^1333 := by decide +kernel

def env42962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,70759,67619,1025,32769,4161,73771,98630,3,8193,65,75818,103494,102743,67586,1364,32,257,33,46092,74251]

theorem envBound42962 : H12AffineFastState.Bounded env42962 := by
  intro p hp
  have h : env42962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42961_42962 : H12AffineEnvironment.transform 16 70759 env42961 = env42962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70759 env42961 == env42962) = true)

theorem identity42962 : scanCanonicalize (H12AffineFastState.compose env42962 (packedSelected [2,4,9,11,18,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound42962 : packedSelected [2,4,9,11,18,20,21] rootPS < 2^1333 := by decide +kernel

def env42963 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,65536,70759,67619,1025,1,4161,73771,65862,3,8193,65,75818,70726,69975,67586,1364,32,257,33,13324,74251]

theorem envBound42963 : H12AffineFastState.Bounded env42963 := by
  intro p hp
  have h : env42963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42962_42963 : H12AffineEnvironment.transform 14 0 env42962 = env42963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env42962 == env42963) = true)

theorem identity42963 : scanCanonicalize (H12AffineFastState.compose env42963 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound42963 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env42964 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,114,5141,2129,1025,1,4161,8281,308,3,8193,65,10328,5172,4389,2160,1364,32,257,33,13324,8825]

theorem envBound42964 : H12AffineFastState.Bounded env42964 := by
  intro p hp
  have h : env42964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42963_42964 : H12AffineEnvironment.transform 15 114 env42963 = env42964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env42963 == env42964) = true)

theorem identity42964 : scanCanonicalize (H12AffineFastState.compose env42964 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42964 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env42965 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,8192,5125,0,114,5141,2129,1025,1,4161,8281,49,3,8193,65,10328,5172,4128,2160,1105,32,4,33,13324,8825]

theorem envBound42965 : H12AffineFastState.Bounded env42965 := by
  intro p hp
  have h : env42965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42964_42965 : H12AffineEnvironment.transform 7 5 env42964 = env42965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42964 == env42965) = true)

theorem identity42965 : scanCanonicalize (H12AffineFastState.compose env42965 (packedSelected [3,4,5,6,9,10,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42965 : packedSelected [3,4,5,6,9,10,16] rootPS < 2^1333 := by decide +kernel

def env42966 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,8192,5125,0,35,5141,2048,1025,1,4112,8200,49,3,8193,16,10249,5172,4128,2081,1024,32,4,33,13324,8744]

theorem envBound42966 : H12AffineFastState.Bounded env42966 := by
  intro p hp
  have h : env42966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42965_42966 : H12AffineEnvironment.transform 5 17 env42965 = env42966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42965 == env42966) = true)

theorem identity42966 : scanCanonicalize (H12AffineFastState.compose env42966 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound42966 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42967 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,40,5125,0,35,5141,2048,1025,1,4112,32,49,3,41,16,2081,5172,4128,2081,1024,32,4,33,5156,512]

theorem envBound42967 : H12AffineFastState.Bounded env42967 := by
  intro p hp
  have h : env42967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42966_42967 : H12AffineEnvironment.transform 12 40 env42966 = env42967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env42966 == env42967) = true)

theorem identity42967 : scanCanonicalize (H12AffineFastState.compose env42967 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound42967 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env42968 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,4096,40,4145,0,35,4129,2048,53,1,4112,32,49,3,41,16,2081,4096,4128,2081,52,32,4,33,4112,512]

theorem envBound42968 : H12AffineFastState.Bounded env42968 := by
  intro p hp
  have h : env42968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42967_42968 : H12AffineEnvironment.transform 9 52 env42967 = env42968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42967 == env42968) = true)

theorem identity42968 : scanCanonicalize (H12AffineFastState.compose env42968 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound42968 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env42969 : List Nat := [2,4,8,16,32,17,9,5,38,52,2048,4096,40,4145,0,35,4129,2048,53,1,4112,32,49,3,41,16,2081,4096,4128,2081,52,32,4,33,4112,38]

theorem envBound42969 : H12AffineFastState.Bounded env42969 := by
  intro p hp
  have h : env42969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42968_42969 : H12AffineEnvironment.transform 8 38 env42968 = env42969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env42968 == env42969) = true)

def env42970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254785,92374096,145662401,525568,140903596,27337992,25733062]

theorem envBound42970 : H12AffineFastState.Bounded env42970 := by
  intro p hp
  have h : env42970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41283_42970 : H12AffineEnvironment.transform 29 155254785 env41283 = env42970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env41283 == env42970) = true)

def env42971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254785,25265168,145662401,525568,140903596,27337992,25733062]

theorem envBound42971 : H12AffineFastState.Bounded env42971 := by
  intro p hp
  have h : env42971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42970_42971 : H12AffineEnvironment.transform 25 64 env42970 = env42971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env42970 == env42971) = true)

def env42972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356289,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound42972 : H12AffineFastState.Bounded env42972 := by
  intro p hp
  have h : env42972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42971_42972 : H12AffineEnvironment.transform 26 30393344 env42971 = env42972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env42971 == env42972) = true)

def env42973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound42973 : H12AffineFastState.Bounded env42973 := by
  intro p hp
  have h : env42973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42972_42973 : H12AffineEnvironment.transform 18 1024 env42972 = env42973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env42972 == env42973) = true)

theorem identity42973 : scanCanonicalize (H12AffineFastState.compose env42973 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 152) := by decide +kernel

theorem selectedBound42973 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env42974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,152,16777216,8328,64,21479576,18973836,2119113,442521,16876680,23160257,256,18990132,18949520,16819038]

theorem envBound42974 : H12AffineFastState.Bounded env42974 := by
  intro p hp
  have h : env42974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42973_42974 : H12AffineEnvironment.transform 22 152 env42973 = env42974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env42973 == env42974) = true)

def env42975 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21479440,18973700,2118977,442385,16876544,23160137,256,18990132,18949400,16819038]

theorem envBound42975 : H12AffineFastState.Bounded env42975 := by
  intro p hp
  have h : env42975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42974_42975 : H12AffineEnvironment.transform 6 8 env42974 = env42975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42974 == env42975) = true)

def env42976 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331968,18973700,2118977,294913,16876544,23160137,256,18990132,18949400,16819038]

theorem envBound42976 : H12AffineFastState.Bounded env42976 := by
  intro p hp
  have h : env42976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42975_42976 : H12AffineEnvironment.transform 16 16400 env42975 = env42976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env42975 == env42976) = true)

def env42977 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331968,18973700,2118709,294913,16876544,23159869,116,18990132,18949228,16818730]

theorem envBound42977 : H12AffineFastState.Bounded env42977 := by
  intro p hp
  have h : env42977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42976_42977 : H12AffineEnvironment.transform 7 116 env42976 = env42977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env42976 == env42977) = true)

theorem identity42977 : scanCanonicalize (H12AffineFastState.compose env42977 (packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388159) := by decide +kernel

theorem selectedBound42977 : packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env42978 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,388159,4194304,16,16777216,8192,64,21331968,17066043,374794,294913,16876544,21268482,116,17049611,17090643,16818730]

theorem envBound42978 : H12AffineFastState.Bounded env42978 := by
  intro p hp
  have h : env42978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42977_42978 : H12AffineEnvironment.transform 20 388159 env42977 = env42978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388159 env42977 == env42978) = true)

def env42979 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,388159,4194304,16,351316,8192,64,4250708,78959,374794,294913,317524,4314198,116,95327,103431,392830]

theorem envBound42979 : H12AffineFastState.Bounded env42979 := by
  intro p hp
  have h : env42979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42978_42979 : H12AffineEnvironment.transform 23 351316 env42978 = env42979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351316 env42978 == env42979) = true)

def env42980 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1024,32769,115735,4194304,16,95356,8192,64,4250708,78959,102434,43049,61564,4314198,116,95327,103431,120406]

theorem envBound42980 : H12AffineFastState.Bounded env42980 := by
  intro p hp
  have h : env42980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42979_42980 : H12AffineEnvironment.transform 17 10280 env42979 = env42980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42979 == env42980) = true)

theorem identity42980 : scanCanonicalize (H12AffineFastState.compose env42980 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42980 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42981 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,8203,16400,10280,1024,32769,58396,4194304,16,21623,8192,64,4250708,5220,45097,43049,61564,4256861,116,21588,46092,63069]

theorem envBound42981 : H12AffineFastState.Bounded env42981 := by
  intro p hp
  have h : env42981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42980_42981 : H12AffineEnvironment.transform 15 8203 env42980 = env42981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42980 == env42981) = true)

theorem identity42981 : scanCanonicalize (H12AffineFastState.compose env42981 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound42981 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env42982 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29789,8203,16400,10280,1024,29788,4161,4194304,16,21623,8192,64,4204553,5220,17524,23668,1057,4194304,116,21588,16465,512]

theorem envBound42982 : H12AffineFastState.Bounded env42982 := by
  intro p hp
  have h : env42982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42981_42982 : H12AffineEnvironment.transform 14 29789 env42981 = env42982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env42981 == env42982) = true)

theorem identity42982 : scanCanonicalize (H12AffineFastState.compose env42982 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound42982 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42983 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,8192,16384,28729,8203,16400,10280,100,28728,4161,4194304,16,20499,8192,64,4204553,4096,16400,22544,69,4194304,116,20528,16465,512]

theorem envBound42983 : H12AffineFastState.Bounded env42983 := by
  intro p hp
  have h : env42983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42982_42983 : H12AffineEnvironment.transform 9 100 env42982 = env42983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env42982 == env42983) = true)

theorem identity42983 : scanCanonicalize (H12AffineFastState.compose env42983 (packedSelected [2,4,6,9,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 6216) := by decide +kernel

theorem selectedBound42983 : packedSelected [2,4,6,9,11,14] rootPS < 2^1333 := by decide +kernel

def env42984 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,6216,16384,18545,6211,16400,4192,100,18544,4161,4194304,16,20499,6216,64,4198465,4096,16400,22544,69,4194304,116,20528,16465,512]

theorem envBound42984 : H12AffineFastState.Bounded env42984 := by
  intro p hp
  have h : env42984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42983_42984 : H12AffineEnvironment.transform 12 6216 env42983 = env42984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6216 env42983 == env42984) = true)

theorem identity42984 : scanCanonicalize (H12AffineFastState.compose env42984 (packedSelected [1,2,3,6,15] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound42984 : packedSelected [1,2,3,6,15] rootPS < 2^1333 := by decide +kernel

def env42985 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,2065,89,16384,18545,82,16400,2161,100,18544,2128,4194304,16,18434,89,64,4196432,2065,16400,16385,69,4194304,116,18465,16465,512]

theorem envBound42985 : H12AffineFastState.Bounded env42985 := by
  intro p hp
  have h : env42985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42984_42985 : H12AffineEnvironment.transform 11 2065 env42984 = env42985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env42984 == env42985) = true)

theorem identity42985 : scanCanonicalize (H12AffineFastState.compose env42985 (packedSelected [1,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2080) := by decide +kernel

theorem selectedBound42985 : packedSelected [1,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env42986 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,2065,89,2080,81,82,2096,2161,100,80,2128,4194304,16,34,89,64,4196432,2065,2096,2081,69,4194304,116,1,2161,512]

theorem envBound42986 : H12AffineFastState.Bounded env42986 := by
  intro p hp
  have h : env42986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42985_42986 : H12AffineEnvironment.transform 13 2080 env42985 = env42986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2080 env42985 == env42986) = true)

theorem identity42986 : scanCanonicalize (H12AffineFastState.compose env42986 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42986 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env42987 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2065,9,2080,1,2,2096,2081,52,0,2048,4194304,16,34,9,16,4196352,2065,2096,2081,21,4194304,36,1,2081,512]

theorem envBound42987 : H12AffineFastState.Bounded env42987 := by
  intro p hp
  have h : env42987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42986_42987 : H12AffineEnvironment.transform 5 16 env42986 = env42987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42986 == env42987) = true)

theorem identity42987 : scanCanonicalize (H12AffineFastState.compose env42987 (packedSelected [1,3,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42987 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env42988 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,2065,9,2048,1,2,2064,2049,20,0,2048,4194304,16,2,9,16,4196352,2065,2064,2049,21,4194304,4,1,2049,512]

theorem envBound42988 : H12AffineFastState.Bounded env42988 := by
  intro p hp
  have h : env42988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42987_42988 : H12AffineEnvironment.transform 4 0 env42987 = env42988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42987 == env42988) = true)

theorem identity42988 : scanCanonicalize (H12AffineFastState.compose env42988 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 543) := by decide +kernel

theorem selectedBound42988 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42989 : List Nat := [2,4,8,16,0,16,8,4,512,20,543,526,9,543,1,2,527,542,20,0,543,4194304,16,2,9,16,4194847,526,527,542,21,4194304,4,1,542,512]

theorem envBound42989 : H12AffineFastState.Bounded env42989 := by
  intro p hp
  have h : env42989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42988_42989 : H12AffineEnvironment.transform 10 543 env42988 = env42989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 543 env42988 == env42989) = true)

theorem identity42989 : scanCanonicalize (H12AffineFastState.compose env42989 (packedSelected [2] rootPS)) = affineNative (2^(21+1) ^^^ 0) := by decide +kernel

theorem selectedBound42989 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42990 : List Nat := [2,4,8,16,0,16,8,4,512,20,543,526,9,543,1,2,527,542,20,0,543,0,16,2,9,16,543,526,527,542,21,0,4,1,542,512]

theorem envBound42990 : H12AffineFastState.Bounded env42990 := by
  intro p hp
  have h : env42990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42989_42990 : H12AffineEnvironment.transform 21 0 env42989 = env42990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 0 env42989 == env42990) = true)

theorem identity42990 : scanCanonicalize (H12AffineFastState.compose env42990 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound42990 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42991 : List Nat := [2,4,8,16,0,16,8,4,1,20,30,15,9,30,1,2,14,31,20,0,30,0,16,2,9,16,30,15,14,31,21,0,4,1,31,1]

theorem envBound42991 : H12AffineFastState.Bounded env42991 := by
  intro p hp
  have h : env42991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42990_42991 : H12AffineEnvironment.transform 8 1 env42990 = env42991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env42990 == env42991) = true)

def leafEnv42991 : List Nat := [2,4,8,16,0,16,8,4,1,20,30,15,9,30,1,2,14,31,20,0,30,0,16,2,21,9,1,16,30,15,14,31,21,0,4,1,4,2,31,1,1,31,0]

def active42991 : List Nat := [0,1,2,3]

def tree42991 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42991 : H12WitnessSearch.Good tree42991 := H12GlobalWitnessIndex.good

theorem leafIdentity42991 : H12AffineFastState.composeSystem env42991 rootObs = leafEnv42991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42991 rootObs == leafEnv42991) = true)

theorem terminalChecked42991 : H12PackedTerminal.terminalCheckFast leafEnv42991 active42991 tree42991 = true := by decide +kernel

def env42992 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1024,32769,115734,4194304,16,95357,8192,64,4250708,78959,102435,43048,61565,4314198,116,95327,103431,120407]

theorem envBound42992 : H12AffineFastState.Bounded env42992 := by
  intro p hp
  have h : env42992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42979_42992 : H12AffineEnvironment.transform 17 10281 env42979 = env42992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42979 == env42992) = true)

theorem identity42992 : scanCanonicalize (H12AffineFastState.compose env42992 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound42992 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42993 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54358,16400,10281,1024,32769,4160,4194304,16,41003,8192,64,4250708,57401,17525,43048,61565,4194304,116,40969,16465,513]

theorem envBound42993 : H12AffineFastState.Bounded env42993 := by
  intro p hp
  have h : env42993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42992_42993 : H12AffineEnvironment.transform 15 54358 env42992 = env42993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env42992 == env42993) = true)

theorem identity42993 : scanCanonicalize (H12AffineFastState.compose env42993 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound42993 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env42994 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54358,16400,10281,1024,32769,4160,8201,16,41003,8192,64,64605,57401,17525,43048,61565,8201,116,40969,16465,513]

theorem envBound42994 : H12AffineFastState.Bounded env42994 := by
  intro p hp
  have h : env42994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42993_42994 : H12AffineEnvironment.transform 21 8201 env42993 = env42994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env42993 == env42994) = true)

theorem identity42994 : scanCanonicalize (H12AffineFastState.compose env42994 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound42994 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env42995 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13405,32768,40971,13389,10281,1024,32769,4160,8201,16,41003,8192,64,34816,37988,12328,43048,33824,8201,116,40969,13324,513]

theorem envBound42995 : H12AffineFastState.Bounded env42995 := by
  intro p hp
  have h : env42995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42994_42995 : H12AffineEnvironment.transform 13 13405 env42994 = env42995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env42994 == env42995) = true)

theorem identity42995 : scanCanonicalize (H12AffineFastState.compose env42995 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42995 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42996 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,13325,32768,40971,13341,10281,1024,32769,4112,8201,16,41003,8192,16,34816,37940,12328,43048,33824,8201,36,40969,13324,513]

theorem envBound42996 : H12AffineFastState.Bounded env42996 := by
  intro p hp
  have h : env42996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42995_42996 : H12AffineEnvironment.transform 5 16 env42995 = env42996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42995 == env42996) = true)

theorem identity42996 : scanCanonicalize (H12AffineFastState.compose env42996 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound42996 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42997 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,32768,32802,5172,2048,1024,32769,4112,32,16,32770,41,16,34816,37940,4097,34817,33824,32,36,32800,5157,513]

theorem envBound42997 : H12AffineFastState.Bounded env42997 := by
  intro p hp
  have h : env42997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42996_42997 : H12AffineEnvironment.transform 12 41 env42996 = env42997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env42996 == env42997) = true)

theorem identity42997 : scanCanonicalize (H12AffineFastState.compose env42997 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound42997 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42998 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,1,35,5172,2048,1024,0,4112,32,16,3,41,16,2049,5173,4097,2048,1057,32,36,33,5157,513]

theorem envBound42998 : H12AffineFastState.Bounded env42998 := by
  intro p hp
  have h : env42998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42997_42998 : H12AffineEnvironment.transform 14 1 env42997 = env42998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env42997 == env42998) = true)

theorem identity42998 : scanCanonicalize (H12AffineFastState.compose env42998 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound42998 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42999 : List Nat := [2,4,8,16,32,16,8,36,512,37,2048,4096,41,4097,1,35,4113,2048,37,0,4112,32,16,3,41,16,2049,4112,4097,2048,4,32,36,33,4096,513]

theorem envBound42999 : H12AffineFastState.Bounded env42999 := by
  intro p hp
  have h : env42999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42998_42999 : H12AffineEnvironment.transform 9 37 env42998 = env42999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env42998 == env42999) = true)

theorem identity42999 : scanCanonicalize (H12AffineFastState.compose env42999 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound42999 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43000 : List Nat := [2,4,8,16,32,16,8,36,512,37,2048,513,41,512,1,35,528,2048,37,0,529,32,16,3,41,16,2049,529,512,2048,4,32,36,33,513,513]

theorem envBound43000 : H12AffineFastState.Bounded env43000 := by
  intro p hp
  have h : env43000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42999_43000 : H12AffineEnvironment.transform 11 513 env42999 = env43000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env42999 == env43000) = true)

theorem identity43000 : scanCanonicalize (H12AffineFastState.compose env43000 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound43000 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43001 : List Nat := [2,4,8,16,32,16,8,36,0,37,2048,1,41,0,1,35,16,2048,37,0,17,32,16,3,41,16,2049,17,0,2048,4,32,36,33,1,1]

theorem envBound43001 : H12AffineFastState.Bounded env43001 := by
  intro p hp
  have h : env43001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43000_43001 : H12AffineEnvironment.transform 8 0 env43000 = env43001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env43000 == env43001) = true)

theorem identity43001 : scanCanonicalize (H12AffineFastState.compose env43001 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43001 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43002 : List Nat := [2,4,8,1,32,1,8,36,0,37,2048,1,41,0,1,35,1,2048,37,0,0,32,1,3,41,1,2049,0,0,2048,4,32,36,33,1,1]

theorem envBound43002 : H12AffineFastState.Bounded env43002 := by
  intro p hp
  have h : env43002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43001_43002 : H12AffineEnvironment.transform 3 1 env43001 = env43002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43001 == env43002) = true)

theorem identity43002 : scanCanonicalize (H12AffineFastState.compose env43002 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound43002 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43003 : List Nat := [2,4,8,1,32,1,8,36,0,37,33,1,41,0,1,35,1,33,37,0,0,32,1,3,41,1,32,0,0,33,4,32,36,33,1,1]

theorem envBound43003 : H12AffineFastState.Bounded env43003 := by
  intro p hp
  have h : env43003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43002_43003 : H12AffineEnvironment.transform 10 33 env43002 = env43003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env43002 == env43003) = true)

def env43004 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,388159,4194304,16,351317,8192,64,4250709,78958,374794,294913,317525,4314199,116,95326,103430,392831]

theorem envBound43004 : H12AffineFastState.Bounded env43004 := by
  intro p hp
  have h : env43004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42978_43004 : H12AffineEnvironment.transform 23 351317 env42978 = env43004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351317 env42978 == env43004) = true)

theorem identity43004 : scanCanonicalize (H12AffineFastState.compose env43004 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound43004 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env43005 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,130174,1024,32769,4161,4194304,16,41003,8192,64,4250709,78958,17524,97407,74795,4314199,116,95326,103430,513]

theorem envBound43005 : H12AffineFastState.Bounded env43005 := by
  intro p hp
  have h : env43005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43004_43005 : H12AffineEnvironment.transform 17 130174 env43004 = env43005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env43004 == env43005) = true)

theorem identity43005 : scanCanonicalize (H12AffineFastState.compose env43005 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound43005 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env43006 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54359,16400,10281,1024,32769,4161,4194304,16,41003,8192,64,4250709,57401,17524,43048,61564,4194304,116,40969,16465,513]

theorem envBound43006 : H12AffineFastState.Bounded env43006 := by
  intro p hp
  have h : env43006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43005_43006 : H12AffineEnvironment.transform 15 54359 env43005 = env43006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env43005 == env43006) = true)

theorem identity43006 : scanCanonicalize (H12AffineFastState.compose env43006 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound43006 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env43007 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54359,16400,10281,1024,32769,4161,8201,16,41003,8192,64,64604,57401,17524,43048,61564,8201,116,40969,16465,513]

theorem envBound43007 : H12AffineFastState.Bounded env43007 := by
  intro p hp
  have h : env43007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43006_43007 : H12AffineEnvironment.transform 21 8201 env43006 = env43007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env43006 == env43007) = true)

theorem identity43007 : scanCanonicalize (H12AffineFastState.compose env43007 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound43007 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env43008 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13404,32768,40971,13388,10281,1024,32769,4161,8201,16,41003,8192,64,34816,37989,12328,43048,33824,8201,116,40969,13325,513]

theorem envBound43008 : H12AffineFastState.Bounded env43008 := by
  intro p hp
  have h : env43008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43007_43008 : H12AffineEnvironment.transform 13 13404 env43007 = env43008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env43007 == env43008) = true)

theorem identity43008 : scanCanonicalize (H12AffineFastState.compose env43008 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43008 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env43009 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,13324,32768,40971,13340,10281,1024,32769,4113,8201,16,41003,8192,16,34816,37941,12328,43048,33824,8201,36,40969,13325,513]

theorem envBound43009 : H12AffineFastState.Bounded env43009 := by
  intro p hp
  have h : env43009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43008_43009 : H12AffineEnvironment.transform 5 16 env43008 = env43009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43008 == env43009) = true)

theorem identity43009 : scanCanonicalize (H12AffineFastState.compose env43009 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound43009 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43010 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,32768,32802,5173,2048,1024,32769,4113,32,16,32770,41,16,34816,37941,4097,34817,33824,32,36,32800,5156,513]

theorem envBound43010 : H12AffineFastState.Bounded env43010 := by
  intro p hp
  have h : env43010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43009_43010 : H12AffineEnvironment.transform 12 41 env43009 = env43010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env43009 == env43010) = true)

theorem identity43010 : scanCanonicalize (H12AffineFastState.compose env43010 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound43010 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43011 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,1,35,5173,2048,1024,0,4113,32,16,3,41,16,2049,5172,4097,2048,1057,32,36,33,5156,513]

theorem envBound43011 : H12AffineFastState.Bounded env43011 := by
  intro p hp
  have h : env43011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43010_43011 : H12AffineEnvironment.transform 14 1 env43010 = env43011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env43010 == env43011) = true)

theorem identity43011 : scanCanonicalize (H12AffineFastState.compose env43011 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound43011 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43012 : List Nat := [2,4,8,16,32,16,8,36,512,36,2048,4096,41,4097,1,35,4113,2048,36,0,4113,32,16,3,41,16,2049,4112,4097,2048,5,32,36,33,4096,513]

theorem envBound43012 : H12AffineFastState.Bounded env43012 := by
  intro p hp
  have h : env43012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43011_43012 : H12AffineEnvironment.transform 9 36 env43011 = env43012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env43011 == env43012) = true)

theorem identity43012 : scanCanonicalize (H12AffineFastState.compose env43012 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound43012 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43013 : List Nat := [2,4,8,16,32,16,8,36,512,36,2048,513,41,512,1,35,528,2048,36,0,528,32,16,3,41,16,2049,529,512,2048,5,32,36,33,513,513]

theorem envBound43013 : H12AffineFastState.Bounded env43013 := by
  intro p hp
  have h : env43013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43012_43013 : H12AffineEnvironment.transform 11 513 env43012 = env43013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env43012 == env43013) = true)

theorem identity43013 : scanCanonicalize (H12AffineFastState.compose env43013 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound43013 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43014 : List Nat := [2,4,8,16,32,16,8,36,1,36,2048,0,41,1,1,35,17,2048,36,0,17,32,16,3,41,16,2049,16,1,2048,5,32,36,33,0,0]

theorem envBound43014 : H12AffineFastState.Bounded env43014 := by
  intro p hp
  have h : env43014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43013_43014 : H12AffineEnvironment.transform 8 1 env43013 = env43014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env43013 == env43014) = true)

theorem identity43014 : scanCanonicalize (H12AffineFastState.compose env43014 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43014 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43015 : List Nat := [2,4,8,1,32,1,8,36,1,36,2048,0,41,1,1,35,0,2048,36,0,0,32,1,3,41,1,2049,1,1,2048,5,32,36,33,0,0]

theorem envBound43015 : H12AffineFastState.Bounded env43015 := by
  intro p hp
  have h : env43015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43014_43015 : H12AffineEnvironment.transform 3 1 env43014 = env43015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43014 == env43015) = true)

theorem identity43015 : scanCanonicalize (H12AffineFastState.compose env43015 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound43015 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43016 : List Nat := [2,4,8,1,32,1,8,36,1,36,32,0,41,1,1,35,0,32,36,0,0,32,1,3,41,1,33,1,1,32,5,32,36,33,0,0]

theorem envBound43016 : H12AffineFastState.Bounded env43016 := by
  intro p hp
  have h : env43016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43015_43016 : H12AffineEnvironment.transform 10 32 env43015 = env43016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env43015 == env43016) = true)

theorem identity43016 : scanCanonicalize (H12AffineFastState.compose env43016 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43016 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43017 : List Nat := [2,4,8,1,0,1,8,4,1,4,0,0,9,1,1,3,0,0,4,0,0,0,1,3,9,1,1,1,1,0,5,0,4,1,0,0]

theorem envBound43017 : H12AffineFastState.Bounded env43017 := by
  intro p hp
  have h : env43017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43016_43017 : H12AffineEnvironment.transform 4 0 env43016 = env43017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43016 == env43017) = true)

def env43018 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331968,18973700,2118708,294913,16876544,23159868,117,18990132,18949229,16818731]

theorem envBound43018 : H12AffineFastState.Bounded env43018 := by
  intro p hp
  have h : env43018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42976_43018 : H12AffineEnvironment.transform 7 117 env42976 = env43018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42976 == env43018) = true)

theorem identity43018 : scanCanonicalize (H12AffineFastState.compose env43018 (packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(23+1) ^^^ 2444309) := by decide +kernel

theorem selectedBound43018 : packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env43019 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,2444309,8192,64,6343701,313361,2118708,294913,2410517,4466729,117,296993,288888,2485822]

theorem envBound43019 : H12AffineFastState.Bounded env43019 := by
  intro p hp
  have h : env43019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43018_43019 : H12AffineEnvironment.transform 23 2444309 env43018 = env43019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2444309 env43018 == env43019) = true)

def env43020 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56436,1024,32769,2097152,4194304,16,2199649,8192,64,6343701,5221,2118708,23669,2102369,4256861,117,21589,46092,2175562]

theorem envBound43020 : H12AffineFastState.Bounded env43020 := by
  intro p hp
  have h : env43020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43019_43020 : H12AffineEnvironment.transform 17 56436 env43019 = env43020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env43019 == env43020) = true)

theorem identity43020 : scanCanonicalize (H12AffineFastState.compose env43020 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound43020 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env43021 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56436,1024,32769,77899,4194304,16,41002,8192,64,4324446,5221,91263,23669,74794,4256861,117,21589,46092,513]

theorem envBound43021 : H12AffineFastState.Bounded env43021 := by
  intro p hp
  have h : env43021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43020_43021 : H12AffineEnvironment.transform 20 77899 env43020 = env43021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env43020 == env43021) = true)

theorem identity43021 : scanCanonicalize (H12AffineFastState.compose env43021 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound43021 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env43022 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29789,65536,16400,10281,1024,29788,77899,4194304,16,21623,8192,64,4261891,5221,91263,23669,74794,4194304,117,21589,16465,513]

theorem envBound43022 : H12AffineFastState.Bounded env43022 := by
  intro p hp
  have h : env43022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43021_43022 : H12AffineEnvironment.transform 14 29789 env43021 = env43022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env43021 == env43022) = true)

theorem identity43022 : scanCanonicalize (H12AffineFastState.compose env43022 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound43022 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env43023 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29789,65536,16400,10281,1024,29788,77899,8200,16,21623,8192,64,75787,5221,91263,23669,74794,8200,117,21589,16465,513]

theorem envBound43023 : H12AffineFastState.Bounded env43023 := by
  intro p hp
  have h : env43023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43022_43023 : H12AffineEnvironment.transform 21 8200 env43022 = env43023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env43022 == env43023) = true)

theorem identity43023 : scanCanonicalize (H12AffineFastState.compose env43023 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound43023 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env43024 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29789,21590,16400,10281,1024,29788,25629,8200,16,21623,8192,64,31837,5221,12329,23669,28796,8200,117,21589,16465,513]

theorem envBound43024 : H12AffineFastState.Bounded env43024 := by
  intro p hp
  have h : env43024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43023_43024 : H12AffineEnvironment.transform 15 21590 env43023 = env43024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env43023 == env43024) = true)

theorem identity43024 : scanCanonicalize (H12AffineFastState.compose env43024 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43024 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env43025 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,29709,21510,16400,10281,1024,29708,25629,8200,16,21543,8192,16,31757,5173,12329,23589,28716,8200,37,21509,16385,513]

theorem envBound43025 : H12AffineFastState.Bounded env43025 := by
  intro p hp
  have h : env43025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43024_43025 : H12AffineEnvironment.transform 5 16 env43024 = env43025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43024 == env43025) = true)

theorem identity43025 : scanCanonicalize (H12AffineFastState.compose env43025 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound43025 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43026 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,16384,21541,21510,16400,2049,1024,21540,17461,32,16,21543,40,16,23589,5173,4097,23589,20484,32,37,21509,16385,513]

theorem envBound43026 : H12AffineFastState.Bounded env43026 := by
  intro p hp
  have h : env43026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43025_43026 : H12AffineEnvironment.transform 12 40 env43025 = env43026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env43025 == env43026) = true)

theorem identity43026 : scanCanonicalize (H12AffineFastState.compose env43026 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound43026 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43027 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,1,34,5172,2049,1024,0,4113,32,16,3,40,16,2049,5173,4097,2049,1056,32,37,33,5157,513]

theorem envBound43027 : H12AffineFastState.Bounded env43027 := by
  intro p hp
  have h : env43027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43026_43027 : H12AffineEnvironment.transform 13 5156 env43026 = env43027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env43026 == env43027) = true)

theorem identity43027 : scanCanonicalize (H12AffineFastState.compose env43027 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound43027 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43028 : List Nat := [2,4,8,16,32,16,8,37,512,36,2048,4096,40,4096,1,34,4112,2049,36,0,4113,32,16,3,40,16,2049,4113,4097,2049,4,32,37,33,4097,513]

theorem envBound43028 : H12AffineFastState.Bounded env43028 := by
  intro p hp
  have h : env43028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43027_43028 : H12AffineEnvironment.transform 9 36 env43027 = env43028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env43027 == env43028) = true)

theorem identity43028 : scanCanonicalize (H12AffineFastState.compose env43028 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound43028 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43029 : List Nat := [2,4,8,16,32,16,8,37,512,36,2048,513,40,513,1,34,529,2049,36,0,528,32,16,3,40,16,2049,528,512,2049,4,32,37,33,512,513]

theorem envBound43029 : H12AffineFastState.Bounded env43029 := by
  intro p hp
  have h : env43029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43028_43029 : H12AffineEnvironment.transform 11 513 env43028 = env43029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env43028 == env43029) = true)

theorem identity43029 : scanCanonicalize (H12AffineFastState.compose env43029 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound43029 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43030 : List Nat := [2,4,8,16,32,16,8,37,0,36,2048,1,40,1,1,34,17,2049,36,0,16,32,16,3,40,16,2049,16,0,2049,4,32,37,33,0,1]

theorem envBound43030 : H12AffineFastState.Bounded env43030 := by
  intro p hp
  have h : env43030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43029_43030 : H12AffineEnvironment.transform 8 0 env43029 = env43030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env43029 == env43030) = true)

theorem identity43030 : scanCanonicalize (H12AffineFastState.compose env43030 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43030 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43031 : List Nat := [2,4,8,0,32,0,8,37,0,36,2048,1,40,1,1,34,1,2049,36,0,0,32,0,3,40,0,2049,0,0,2049,4,32,37,33,0,1]

theorem envBound43031 : H12AffineFastState.Bounded env43031 := by
  intro p hp
  have h : env43031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43030_43031 : H12AffineEnvironment.transform 3 0 env43030 = env43031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43030 == env43031) = true)

theorem identity43031 : scanCanonicalize (H12AffineFastState.compose env43031 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43031 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43032 : List Nat := [2,4,8,0,0,0,8,5,0,4,2048,1,8,1,1,2,1,2049,4,0,0,0,0,3,8,0,2049,0,0,2049,4,0,5,1,0,1]

theorem envBound43032 : H12AffineFastState.Bounded env43032 := by
  intro p hp
  have h : env43032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43031_43032 : H12AffineEnvironment.transform 4 0 env43031 = env43032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43031 == env43032) = true)

theorem identity43032 : scanCanonicalize (H12AffineFastState.compose env43032 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound43032 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43033 : List Nat := [2,4,8,0,0,0,8,5,0,4,1,1,8,1,1,2,1,0,4,0,0,0,0,3,8,0,0,0,0,0,4,0,5,1,0,1]

theorem envBound43033 : H12AffineFastState.Bounded env43033 := by
  intro p hp
  have h : env43033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43032_43033 : H12AffineEnvironment.transform 10 1 env43032 = env43033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env43032 == env43033) = true)

def env43034 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56437,1024,32769,2097152,4194304,16,2199648,8192,64,6343701,5220,2118708,23668,2102368,4256860,117,21588,46093,2175563]

theorem envBound43034 : H12AffineFastState.Bounded env43034 := by
  intro p hp
  have h : env43034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43019_43034 : H12AffineEnvironment.transform 17 56437 env43019 = env43034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env43019 == env43034) = true)

def env43035 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56437,1024,32769,4160,4194304,16,98336,8192,64,4250709,5220,17524,23668,1056,4256860,117,21588,46093,74251]

theorem envBound43035 : H12AffineFastState.Bounded env43035 := by
  intro p hp
  have h : env43035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43034_43035 : H12AffineEnvironment.transform 20 4160 env43034 = env43035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43034 == env43035) = true)

theorem identity43035 : scanCanonicalize (H12AffineFastState.compose env43035 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound43035 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43036 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54358,16400,56437,1024,32769,4160,4194304,16,21622,8192,64,4250709,5220,17524,23668,1056,4256860,117,21588,46093,63069]

theorem envBound43036 : H12AffineFastState.Bounded env43036 := by
  intro p hp
  have h : env43036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43035_43036 : H12AffineEnvironment.transform 15 54358 env43035 = env43036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env43035 == env43036) = true)

theorem identity43036 : scanCanonicalize (H12AffineFastState.compose env43036 (packedSelected [0,1,3,4,5,8,9,14,15,23,27] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound43036 : packedSelected [0,1,3,4,5,8,9,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env43037 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54358,16400,56437,1024,32769,4160,8200,16,21622,8192,64,64605,5220,17524,23668,1056,54356,117,21588,46093,63069]

theorem envBound43037 : H12AffineFastState.Bounded env43037 := by
  intro p hp
  have h : env43037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43036_43037 : H12AffineEnvironment.transform 21 8200 env43036 = env43037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env43036 == env43037) = true)

theorem identity43037 : scanCanonicalize (H12AffineFastState.compose env43037 (packedSelected [2,3,4,5,6,9,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound43037 : packedSelected [2,3,4,5,6,9,15,18,19] rootPS < 2^1333 := by decide +kernel

def env43038 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,32768,32803,5221,34816,1024,32769,4160,8200,16,3,8192,64,43048,5220,4097,2049,1056,32801,117,33,46093,41512]

theorem envBound43038 : H12AffineFastState.Bounded env43038 := by
  intro p hp
  have h : env43038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43037_43038 : H12AffineEnvironment.transform 13 5237 env43037 = env43038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env43037 == env43038) = true)

theorem identity43038 : scanCanonicalize (H12AffineFastState.compose env43038 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound43038 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env43039 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8233,8202,5221,10281,1024,8232,4160,8200,16,3,8192,64,2049,5220,4097,2049,1056,8200,117,33,5156,513]

theorem envBound43039 : H12AffineFastState.Bounded env43039 := by
  intro p hp
  have h : env43039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43038_43039 : H12AffineEnvironment.transform 14 8233 env43038 = env43039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env43038 == env43039) = true)

theorem identity43039 : scanCanonicalize (H12AffineFastState.compose env43039 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound43039 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43040 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,1,34,5221,2049,1024,0,4160,32,16,3,40,64,2049,5220,4097,2049,1056,32,117,33,5156,513]

theorem envBound43040 : H12AffineFastState.Bounded env43040 := by
  intro p hp
  have h : env43040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43039_43040 : H12AffineEnvironment.transform 12 40 env43039 = env43040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env43039 == env43040) = true)

theorem identity43040 : scanCanonicalize (H12AffineFastState.compose env43040 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound43040 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43041 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1572,40,593,1,34,577,2049,1024,0,1636,32,16,3,40,64,2049,576,1573,2049,1056,32,117,33,512,513]

theorem envBound43041 : H12AffineFastState.Bounded env43041 := by
  intro p hp
  have h : env43041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43040_43041 : H12AffineEnvironment.transform 11 1572 env43040 = env43041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env43040 == env43041) = true)

theorem identity43041 : scanCanonicalize (H12AffineFastState.compose env43041 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 577) := by decide +kernel

theorem selectedBound43041 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43042 : List Nat := [2,4,8,16,32,64,8,117,512,1024,577,1572,40,593,1,34,577,576,1024,0,1636,32,16,3,40,64,576,576,1573,576,1056,32,117,33,512,513]

theorem envBound43042 : H12AffineFastState.Bounded env43042 := by
  intro p hp
  have h : env43042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43041_43042 : H12AffineEnvironment.transform 10 577 env43041 = env43042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env43041 == env43042) = true)

theorem identity43042 : scanCanonicalize (H12AffineFastState.compose env43042 (packedSelected [5,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43042 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env43043 : List Nat := [2,4,8,0,32,64,8,101,512,1024,577,1572,40,577,1,34,577,576,1024,0,1636,32,0,3,40,64,576,576,1573,576,1056,32,101,33,512,513]

theorem envBound43043 : H12AffineFastState.Bounded env43043 := by
  intro p hp
  have h : env43043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43042_43043 : H12AffineEnvironment.transform 3 0 env43042 = env43043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43042 == env43043) = true)

theorem identity43043 : scanCanonicalize (H12AffineFastState.compose env43043 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound43043 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env43044 : List Nat := [2,4,8,0,32,64,8,101,512,101,577,577,40,577,1,34,577,576,101,0,513,32,0,3,40,64,576,576,576,576,69,32,101,33,512,513]

theorem envBound43044 : H12AffineFastState.Bounded env43044 := by
  intro p hp
  have h : env43044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43043_43044 : H12AffineEnvironment.transform 9 101 env43043 = env43044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env43043 == env43044) = true)

theorem identity43044 : scanCanonicalize (H12AffineFastState.compose env43044 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound43044 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43045 : List Nat := [2,4,8,0,32,32,8,5,512,5,545,545,40,545,1,34,545,544,5,0,513,32,0,3,40,32,544,544,544,544,37,32,5,33,512,513]

theorem envBound43045 : H12AffineFastState.Bounded env43045 := by
  intro p hp
  have h : env43045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43044_43045 : H12AffineEnvironment.transform 5 32 env43044 = env43045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env43044 == env43045) = true)

theorem identity43045 : scanCanonicalize (H12AffineFastState.compose env43045 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43045 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43046 : List Nat := [2,4,8,0,1,1,8,5,512,5,512,512,9,512,1,3,512,513,5,0,513,1,0,3,9,1,513,513,513,513,4,1,5,0,512,513]

theorem envBound43046 : H12AffineFastState.Bounded env43046 := by
  intro p hp
  have h : env43046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43045_43046 : H12AffineEnvironment.transform 4 1 env43045 = env43046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43045 == env43046) = true)

def env43047 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56437,1024,32769,4161,4194304,16,98337,8192,64,4250708,5220,17525,23668,1057,4256860,117,21588,46093,74250]

theorem envBound43047 : H12AffineFastState.Bounded env43047 := by
  intro p hp
  have h : env43047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43034_43047 : H12AffineEnvironment.transform 20 4161 env43034 = env43047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43034 == env43047) = true)

theorem identity43047 : scanCanonicalize (H12AffineFastState.compose env43047 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound43047 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43048 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,16400,56437,1024,32769,4161,4194304,16,41002,8192,64,4250708,5220,17525,23668,1057,4256860,117,21588,46093,513]

theorem envBound43048 : H12AffineFastState.Bounded env43048 := by
  intro p hp
  have h : env43048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43047_43048 : H12AffineEnvironment.transform 15 8203 env43047 = env43048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env43047 == env43048) = true)

theorem identity43048 : scanCanonicalize (H12AffineFastState.compose env43048 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound43048 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env43049 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,32768,8203,5221,34816,1024,32769,4161,4194304,16,41002,8192,64,4229153,5220,4096,2049,1057,4235305,117,33,46093,513]

theorem envBound43049 : H12AffineFastState.Bounded env43049 := by
  intro p hp
  have h : env43049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43048_43049 : H12AffineEnvironment.transform 13 5237 env43048 = env43049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env43048 == env43049) = true)

theorem identity43049 : scanCanonicalize (H12AffineFastState.compose env43049 (packedSelected [3,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 3102) := by decide +kernel

theorem selectedBound43049 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env43050 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,32768,8203,5221,34816,1024,32769,4161,3102,16,41002,8192,64,33855,5220,4096,2049,1057,44087,117,33,46093,513]

theorem envBound43050 : H12AffineFastState.Bounded env43050 := by
  intro p hp
  have h : env43050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43049_43050 : H12AffineEnvironment.transform 21 3102 env43049 = env43050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 3102 env43049 == env43050) = true)

theorem identity43050 : scanCanonicalize (H12AffineFastState.compose env43050 (packedSelected [0,2,4,6,7,9,14,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound43050 : packedSelected [0,2,4,6,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env43051 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,1,8203,5221,2049,1024,0,4161,3102,16,8235,8192,64,1086,5220,4096,2049,1057,11318,117,33,13324,513]

theorem envBound43051 : H12AffineFastState.Bounded env43051 := by
  intro p hp
  have h : env43051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43050_43051 : H12AffineEnvironment.transform 14 1 env43050 = env43051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env43050 == env43051) = true)

theorem identity43051 : scanCanonicalize (H12AffineFastState.compose env43051 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1135) := by decide +kernel

theorem selectedBound43051 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43052 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1135,4096,8192,5237,1,8203,5221,1134,1024,0,4161,113,16,8235,8192,64,1086,5220,4096,1134,1057,8281,117,33,13324,513]

theorem envBound43052 : H12AffineFastState.Bounded env43052 := by
  intro p hp
  have h : env43052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43051_43052 : H12AffineEnvironment.transform 10 1135 env43051 = env43052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1135 env43051 == env43052) = true)

theorem identity43052 : scanCanonicalize (H12AffineFastState.compose env43052 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound43052 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43053 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1135,4096,40,5237,1,35,5221,1134,1024,0,4161,113,16,3,40,64,1086,5220,4096,1134,1057,113,117,33,5156,513]

theorem envBound43053 : H12AffineFastState.Bounded env43053 := by
  intro p hp
  have h : env43053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43052_43053 : H12AffineEnvironment.transform 12 40 env43052 = env43053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env43052 == env43053) = true)

def env43054 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331969,18973700,2118977,294912,16876544,23160137,256,18990132,18949400,16819038]

theorem envBound43054 : H12AffineFastState.Bounded env43054 := by
  intro p hp
  have h : env43054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42975_43054 : H12AffineEnvironment.transform 16 16401 env42975 = env43054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env42975 == env43054) = true)

theorem identity43054 : scanCanonicalize (H12AffineFastState.compose env43054 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound43054 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env43055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,41311,8192,64,4530526,2172251,2118977,294912,75103,6407190,256,2188651,2196551,513]

theorem envBound43055 : H12AffineFastState.Bounded env43055 := by
  intro p hp
  have h : env43055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43054_43055 : H12AffineEnvironment.transform 23 41311 env43054 = env43055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env43054 == env43055) = true)

def env43056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58396,4194304,16,41311,8192,64,4530526,115015,45405,294912,75103,4268042,256,98679,90203,513]

theorem envBound43056 : H12AffineFastState.Bounded env43056 := by
  intro p hp
  have h : env43056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43055_43056 : H12AffineEnvironment.transform 20 58396 env43055 = env43056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env43055 == env43056) = true)

def env43057 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58396,4194304,16,41231,8192,16,4530446,114967,45325,294912,75023,4268042,256,98599,90123,513]

theorem envBound43057 : H12AffineFastState.Bounded env43057 := by
  intro p hp
  have h : env43057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43056_43057 : H12AffineEnvironment.transform 5 16 env43056 = env43057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43056 == env43057) = true)

theorem identity43057 : scanCanonicalize (H12AffineFastState.compose env43057 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272393) := by decide +kernel

theorem selectedBound43057 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env43058 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58396,272393,16,41231,8192,16,67847,114967,45325,294912,75023,329731,256,98599,90123,513]

theorem envBound43058 : H12AffineFastState.Bounded env43058 := by
  intro p hp
  have h : env43058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43057_43058 : H12AffineEnvironment.transform 21 272393 env43057 = env43058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272393 env43057 == env43058) = true)

theorem identity43058 : scanCanonicalize (H12AffineFastState.compose env43058 (packedSelected [0,3,7,10,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound43058 : packedSelected [0,3,7,10,19,20,24] rootPS < 2^1333 := by decide +kernel

def env43059 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33031,16401,262144,1024,32769,58396,272393,16,41231,8192,16,34816,16400,45325,294912,41992,297220,256,32,57612,513]

theorem envBound43059 : H12AffineFastState.Bounded env43059 := by
  intro p hp
  have h : env43059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43058_43059 : H12AffineEnvironment.transform 15 33031 env43058 = env43059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env43058 == env43059) = true)

theorem identity43059 : scanCanonicalize (H12AffineFastState.compose env43059 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound43059 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43060 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33031,16401,2341,1024,32769,58396,8492,16,41231,8192,16,34816,16400,45325,35109,41992,32801,256,32,57612,513]

theorem envBound43060 : H12AffineFastState.Bounded env43060 := by
  intro p hp
  have h : env43060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43059_43060 : H12AffineEnvironment.transform 17 2341 env43059 = env43060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env43059 == env43060) = true)

theorem identity43060 : scanCanonicalize (H12AffineFastState.compose env43060 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound43060 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43061 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,1,262,16401,2341,1024,0,25629,8492,16,8462,8192,16,2049,16400,12556,2340,9225,32,256,32,24845,513]

theorem envBound43061 : H12AffineFastState.Bounded env43061 := by
  intro p hp
  have h : env43061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43060_43061 : H12AffineEnvironment.transform 14 1 env43060 = env43061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env43060 == env43061) = true)

theorem identity43061 : scanCanonicalize (H12AffineFastState.compose env43061 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound43061 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env43062 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1,262,13340,2341,1024,0,4112,8492,16,8462,8192,16,2049,13341,12556,2340,9225,32,256,32,5376,513]

theorem envBound43062 : H12AffineFastState.Bounded env43062 := by
  intro p hp
  have h : env43062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43061_43062 : H12AffineEnvironment.transform 13 13325 env43061 = env43062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env43061 == env43062) = true)

theorem identity43062 : scanCanonicalize (H12AffineFastState.compose env43062 (packedSelected [1,3,4,5,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound43062 : packedSelected [1,3,4,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env43063 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,308,8192,9529,1,262,9512,2341,1024,0,292,8492,16,8462,8192,16,2049,9513,8248,2340,9225,32,256,32,1076,513]

theorem envBound43063 : H12AffineFastState.Bounded env43063 := by
  intro p hp
  have h : env43063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43062_43063 : H12AffineEnvironment.transform 11 308 env43062 = env43063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env43062 == env43063) = true)

theorem identity43063 : scanCanonicalize (H12AffineFastState.compose env43063 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 3384) := by decide +kernel

theorem selectedBound43063 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env43064 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,308,3384,2049,1,262,2064,2341,1024,0,292,3092,16,3126,3384,16,2049,2065,3328,2340,2353,32,256,32,1076,513]

theorem envBound43064 : H12AffineFastState.Bounded env43064 := by
  intro p hp
  have h : env43064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43063_43064 : H12AffineEnvironment.transform 12 3384 env43063 = env43064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3384 env43063 == env43064) = true)

theorem identity43064 : scanCanonicalize (H12AffineFastState.compose env43064 (packedSelected [0,4,7,9,15] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound43064 : packedSelected [0,4,7,9,15] rootPS < 2^1333 := by decide +kernel

def env43065 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,308,269,1076,1,262,1061,1296,1024,0,292,33,16,3,269,16,1076,1060,309,1297,1284,32,256,32,1076,513]

theorem envBound43065 : H12AffineFastState.Bounded env43065 := by
  intro p hp
  have h : env43065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43064_43065 : H12AffineEnvironment.transform 10 1077 env43064 = env43065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env43064 == env43065) = true)

theorem identity43065 : scanCanonicalize (H12AffineFastState.compose env43065 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound43065 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43066 : List Nat := [2,4,8,16,32,16,8,256,512,20,33,308,269,32,1,262,49,260,20,0,292,33,16,3,269,16,32,48,309,261,272,32,256,32,32,513]

theorem envBound43066 : H12AffineFastState.Bounded env43066 := by
  intro p hp
  have h : env43066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43065_43066 : H12AffineEnvironment.transform 9 20 env43065 = env43066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env43065 == env43066) = true)

theorem identity43066 : scanCanonicalize (H12AffineFastState.compose env43066 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43066 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43067 : List Nat := [2,4,8,16,0,16,8,256,512,20,1,276,269,0,1,262,17,260,20,0,260,1,16,3,269,16,0,16,277,261,272,0,256,0,0,513]

theorem envBound43067 : H12AffineFastState.Bounded env43067 := by
  intro p hp
  have h : env43067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43066_43067 : H12AffineEnvironment.transform 4 0 env43066 = env43067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43066 == env43067) = true)

theorem identity43067 : scanCanonicalize (H12AffineFastState.compose env43067 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound43067 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43068 : List Nat := [2,4,8,16,0,16,8,256,261,20,1,276,269,0,1,262,17,260,20,0,260,1,16,3,269,16,0,16,277,261,272,0,256,0,0,260]

theorem envBound43068 : H12AffineFastState.Bounded env43068 := by
  intro p hp
  have h : env43068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43067_43068 : H12AffineEnvironment.transform 8 261 env43067 = env43068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env43067 == env43068) = true)

theorem identity43068 : scanCanonicalize (H12AffineFastState.compose env43068 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43068 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43069 : List Nat := [2,4,8,0,0,0,8,256,261,4,1,260,269,0,1,262,1,260,4,0,260,1,0,3,269,0,0,0,261,261,256,0,256,0,0,260]

theorem envBound43069 : H12AffineFastState.Bounded env43069 := by
  intro p hp
  have h : env43069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43068_43069 : H12AffineEnvironment.transform 3 0 env43068 = env43069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43068 == env43069) = true)

theorem identity43069 : scanCanonicalize (H12AffineFastState.compose env43069 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43069 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env43070 : List Nat := [2,4,8,0,0,0,8,4,1,4,1,0,9,0,1,2,1,0,4,0,0,1,0,3,9,0,0,0,1,1,4,0,4,0,0,0]

theorem envBound43070 : H12AffineFastState.Bounded env43070 := by
  intro p hp
  have h : env43070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43069_43070 : H12AffineEnvironment.transform 7 4 env43069 = env43070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43069 == env43070) = true)

theorem identity43070 : scanCanonicalize (H12AffineFastState.compose env43070 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound43070 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43071 : List Nat := [2,4,2,0,0,0,2,4,1,4,1,0,3,0,1,2,1,0,4,0,0,1,0,3,3,0,0,0,1,1,4,0,4,0,0,0]

theorem envBound43071 : H12AffineFastState.Bounded env43071 := by
  intro p hp
  have h : env43071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43070_43071 : H12AffineEnvironment.transform 2 2 env43070 = env43071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env43070 == env43071) = true)

def env43072 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58396,4194304,16,41230,8192,17,4530447,114966,45324,294912,75022,4268042,256,98598,90122,513]

theorem envBound43072 : H12AffineFastState.Bounded env43072 := by
  intro p hp
  have h : env43072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43056_43072 : H12AffineEnvironment.transform 5 17 env43056 = env43072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43056 == env43072) = true)

theorem identity43072 : scanCanonicalize (H12AffineFastState.compose env43072 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 329731) := by decide +kernel

theorem selectedBound43072 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env43073 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58396,329731,16,41230,8192,17,10508,114966,45324,294912,75022,272393,256,98598,90122,513]

theorem envBound43073 : H12AffineFastState.Bounded env43073 := by
  intro p hp
  have h : env43073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43072_43073 : H12AffineEnvironment.transform 21 329731 env43072 = env43073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 329731 env43072 == env43073) = true)

theorem identity43073 : scanCanonicalize (H12AffineFastState.compose env43073 (packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound43073 : packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env43074 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,2341,1024,32769,58396,65830,16,41230,8192,17,10508,114966,45324,35109,75022,8492,256,98598,90122,513]

theorem envBound43074 : H12AffineFastState.Bounded env43074 := by
  intro p hp
  have h : env43074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43073_43074 : H12AffineEnvironment.transform 17 2341 env43073 = env43074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env43073 == env43074) = true)

theorem identity43074 : scanCanonicalize (H12AffineFastState.compose env43074 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound43074 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env43075 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,16401,2341,1024,8460,17681,65830,16,3,8192,17,10508,90139,4097,10280,75022,8492,256,73771,90122,513]

theorem envBound43075 : H12AffineFastState.Bounded env43075 := by
  intro p hp
  have h : env43075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43074_43075 : H12AffineEnvironment.transform 14 8461 env43074 = env43075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env43074 == env43075) = true)

theorem identity43075 : scanCanonicalize (H12AffineFastState.compose env43075 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43075 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43076 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,65536,16401,2341,1024,0,17681,65830,16,3,268,17,2048,82199,4097,2340,66562,32,256,65831,82182,513]

theorem envBound43076 : H12AffineFastState.Bounded env43076 := by
  intro p hp
  have h : env43076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43075_43076 : H12AffineEnvironment.transform 12 268 env43075 = env43076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43075 == env43076) = true)

theorem identity43076 : scanCanonicalize (H12AffineFastState.compose env43076 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound43076 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43077 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,262,16401,2341,1024,0,17681,32,16,3,268,17,2048,16401,4097,2340,1284,32,256,33,16384,513]

theorem envBound43077 : H12AffineFastState.Bounded env43077 := by
  intro p hp
  have h : env43077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43076_43077 : H12AffineEnvironment.transform 15 262 env43076 = env43077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env43076 == env43077) = true)

theorem identity43077 : scanCanonicalize (H12AffineFastState.compose env43077 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound43077 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43078 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,1076,1,262,1061,2341,1024,0,293,32,16,3,268,17,2048,1061,4097,2340,1284,32,256,33,1076,513]

theorem envBound43078 : H12AffineFastState.Bounded env43078 := by
  intro p hp
  have h : env43078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43077_43078 : H12AffineEnvironment.transform 13 1076 env43077 = env43078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env43077 == env43078) = true)

theorem identity43078 : scanCanonicalize (H12AffineFastState.compose env43078 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound43078 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43079 : List Nat := [2,4,8,16,32,17,8,256,512,1024,522,4096,268,1076,1,262,1061,815,1024,0,293,32,16,3,268,17,522,1061,4097,814,1284,32,256,33,1076,513]

theorem envBound43079 : H12AffineFastState.Bounded env43079 := by
  intro p hp
  have h : env43079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43078_43079 : H12AffineEnvironment.transform 10 522 env43078 = env43079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env43078 == env43079) = true)

theorem identity43079 : scanCanonicalize (H12AffineFastState.compose env43079 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 826) := by decide +kernel

theorem selectedBound43079 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43080 : List Nat := [2,4,8,16,32,17,8,256,512,826,522,4096,268,782,1,262,799,815,826,0,293,32,16,3,268,17,522,799,4097,814,574,32,256,33,782,513]

theorem envBound43080 : H12AffineFastState.Bounded env43080 := by
  intro p hp
  have h : env43080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43079_43080 : H12AffineEnvironment.transform 9 826 env43079 = env43080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 826 env43079 == env43080) = true)

theorem identity43080 : scanCanonicalize (H12AffineFastState.compose env43080 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound43080 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43081 : List Nat := [2,4,8,16,32,17,8,256,512,826,522,538,268,782,1,262,799,815,826,0,293,32,16,3,268,17,522,799,539,814,574,32,256,33,782,513]

theorem envBound43081 : H12AffineFastState.Bounded env43081 := by
  intro p hp
  have h : env43081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43080_43081 : H12AffineEnvironment.transform 11 538 env43080 = env43081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env43080 == env43081) = true)

theorem identity43081 : scanCanonicalize (H12AffineFastState.compose env43081 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound43081 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43082 : List Nat := [2,4,8,16,32,17,8,256,42,272,32,48,268,292,1,262,309,261,272,0,293,32,16,3,268,17,32,309,49,260,20,32,256,33,292,43]

theorem envBound43082 : H12AffineFastState.Bounded env43082 := by
  intro p hp
  have h : env43082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43081_43082 : H12AffineEnvironment.transform 8 42 env43081 = env43082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env43081 == env43082) = true)

def env43083 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58397,4194304,16,41311,8192,64,4530526,115014,45404,294912,75103,4268043,256,98678,90202,513]

theorem envBound43083 : H12AffineFastState.Bounded env43083 := by
  intro p hp
  have h : env43083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43055_43083 : H12AffineEnvironment.transform 20 58397 env43055 = env43083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env43055 == env43083) = true)

theorem identity43083 : scanCanonicalize (H12AffineFastState.compose env43083 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound43083 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43084 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,58397,4194304,16,41311,8192,64,4456789,57677,45404,294912,1364,4194304,256,41341,16465,513]

theorem envBound43084 : H12AffineFastState.Bounded env43084 := by
  intro p hp
  have h : env43084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43083_43084 : H12AffineEnvironment.transform 15 8203 env43083 = env43084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env43083 == env43084) = true)

theorem identity43084 : scanCanonicalize (H12AffineFastState.compose env43084 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272473) := by decide +kernel

theorem selectedBound43084 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env43085 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,58397,272473,16,41311,8192,64,10508,57677,45404,294912,1364,272473,256,41341,16465,513]

theorem envBound43085 : H12AffineFastState.Bounded env43085 := by
  intro p hp
  have h : env43085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43084_43085 : H12AffineEnvironment.transform 21 272473 env43084 = env43085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272473 env43084 == env43085) = true)

theorem identity43085 : scanCanonicalize (H12AffineFastState.compose env43085 (packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound43085 : packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS < 2^1333 := by decide +kernel

def env43086 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,16401,262144,1024,1,25629,272473,16,8543,8192,64,10508,24909,12636,262144,1364,272473,256,8573,16465,513]

theorem envBound43086 : H12AffineFastState.Bounded env43086 := by
  intro p hp
  have h : env43086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43085_43086 : H12AffineEnvironment.transform 14 0 env43085 = env43086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env43085 == env43086) = true)

theorem identity43086 : scanCanonicalize (H12AffineFastState.compose env43086 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound43086 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43087 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,16401,2420,1024,1,25629,8493,16,8543,8192,64,10508,24909,12636,2420,1364,8493,256,8573,16465,513]

theorem envBound43087 : H12AffineFastState.Bounded env43087 := by
  intro p hp
  have h : env43087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43086_43087 : H12AffineEnvironment.transform 17 2420 env43086 = env43087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env43086 == env43087) = true)

theorem identity43087 : scanCanonicalize (H12AffineFastState.compose env43087 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound43087 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env43088 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,342,16401,2420,1024,1,17728,112,16,2,349,64,2129,16400,4097,2420,1364,112,256,32,16465,513]

theorem envBound43088 : H12AffineFastState.Bounded env43088 := by
  intro p hp
  have h : env43088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43087_43088 : H12AffineEnvironment.transform 12 349 env43087 = env43088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env43087 == env43088) = true)

theorem identity43088 : scanCanonicalize (H12AffineFastState.compose env43088 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43088 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43089 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,263,16401,2341,1024,1,17681,33,16,2,268,17,2048,16400,4097,2341,1285,33,256,32,16384,513]

theorem envBound43089 : H12AffineFastState.Bounded env43089 := by
  intro p hp
  have h : env43089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43088_43089 : H12AffineEnvironment.transform 5 17 env43088 = env43089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43088 == env43089) = true)

theorem identity43089 : scanCanonicalize (H12AffineFastState.compose env43089 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound43089 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43090 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5157,0,263,5172,2341,1024,1,4404,33,16,2,268,17,2048,5173,4097,2341,1285,33,256,32,5157,513]

theorem envBound43090 : H12AffineFastState.Bounded env43090 := by
  intro p hp
  have h : env43090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43089_43090 : H12AffineEnvironment.transform 13 5157 env43089 = env43090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env43089 == env43090) = true)

def env43091 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,268,2837,0,263,2820,2341,1024,1,3588,33,16,2,268,17,2048,2821,3889,2341,1285,33,256,32,2837,513]

theorem envBound43091 : H12AffineFastState.Bounded env43091 := by
  intro p hp
  have h : env43091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43090_43091 : H12AffineEnvironment.transform 11 3888 env43090 = env43091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env43090 == env43091) = true)

def env43092 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,268,1045,0,263,1028,1573,1024,1,260,33,16,2,268,17,1792,1029,49,1573,1285,33,256,32,1045,513]

theorem envBound43092 : H12AffineFastState.Bounded env43092 := by
  intro p hp
  have h : env43092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43091_43092 : H12AffineEnvironment.transform 10 1792 env43091 = env43092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env43091 == env43092) = true)

theorem identity43092 : scanCanonicalize (H12AffineFastState.compose env43092 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound43092 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43093 : List Nat := [2,4,8,16,32,17,8,256,16,1024,1296,48,268,1045,0,263,1028,1077,1024,1,260,33,16,2,268,17,1296,1029,49,1077,1285,33,256,32,1045,17]

theorem envBound43093 : H12AffineFastState.Bounded env43093 := by
  intro p hp
  have h : env43093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43092_43093 : H12AffineEnvironment.transform 8 16 env43092 = env43093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env43092 == env43093) = true)

def env43094 : List Nat := [2,4,8,16,32,17,8,256,16,52,292,48,268,33,0,263,48,1,52,1,260,33,16,2,268,17,292,49,49,1,305,33,256,32,33,17]

theorem envBound43094 : H12AffineFastState.Bounded env43094 := by
  intro p hp
  have h : env43094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43093_43094 : H12AffineEnvironment.transform 9 52 env43093 = env43094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43093 == env43094) = true)

theorem identity43094 : scanCanonicalize (H12AffineFastState.compose env43094 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43094 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43095 : List Nat := [2,4,8,16,32,17,8,5,16,52,33,48,9,33,0,2,48,1,52,1,1,33,16,2,9,17,33,49,49,1,52,33,5,32,33,17]

theorem envBound43095 : H12AffineFastState.Bounded env43095 := by
  intro p hp
  have h : env43095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43094_43095 : H12AffineEnvironment.transform 7 5 env43094 = env43095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43094 == env43095) = true)

def leafEnv43095 : List Nat := [2,4,8,16,32,17,8,5,16,52,33,48,9,33,0,2,48,1,52,1,1,33,16,2,52,9,1,17,33,49,49,1,52,33,5,32,4,2,33,17,1,1,0]

def active43095 : List Nat := [0,1,2,3,4]

def tree43095 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43095 : H12WitnessSearch.Good tree43095 := H12GlobalWitnessIndex.good

theorem leafIdentity43095 : H12AffineFastState.composeSystem env43095 rootObs = leafEnv43095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43095 rootObs == leafEnv43095) = true)

theorem terminalChecked43095 : H12PackedTerminal.terminalCheckFast leafEnv43095 active43095 tree43095 = true := by decide +kernel

def env43096 : List Nat := [2,4,8,16,32,17,8,256,16,53,293,48,268,32,0,263,49,0,53,1,260,33,16,2,268,17,293,48,49,0,304,33,256,32,32,17]

theorem envBound43096 : H12AffineFastState.Bounded env43096 := by
  intro p hp
  have h : env43096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43093_43096 : H12AffineEnvironment.transform 9 53 env43093 = env43096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43093 == env43096) = true)

theorem identity43096 : scanCanonicalize (H12AffineFastState.compose env43096 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43096 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43097 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,42,268,32,0,263,43,0,47,1,260,33,10,2,268,11,293,42,43,0,298,33,256,32,32,11]

theorem envBound43097 : H12AffineFastState.Bounded env43097 := by
  intro p hp
  have h : env43097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43096_43097 : H12AffineEnvironment.transform 3 10 env43096 = env43097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43096 == env43097) = true)

def leafEnv43097 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,42,268,32,0,263,43,0,47,1,260,33,10,2,298,268,1,11,293,42,43,0,298,33,256,32,4,263,32,11,1,260,0]

def active43097 : List Nat := [0,1,2,4,7]

def tree43097 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43097 : H12WitnessSearch.Good tree43097 := H12GlobalWitnessIndex.good

theorem leafIdentity43097 : H12AffineFastState.composeSystem env43097 rootObs = leafEnv43097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43097 rootObs == leafEnv43097) = true)

theorem terminalChecked43097 : H12PackedTerminal.terminalCheckFast leafEnv43097 active43097 tree43097 = true := by decide +kernel

def env43098 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,268,1044,0,263,1029,1572,1024,1,261,33,16,2,268,17,1793,1028,48,1572,1285,33,256,32,1044,513]

theorem envBound43098 : H12AffineFastState.Bounded env43098 := by
  intro p hp
  have h : env43098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43091_43098 : H12AffineEnvironment.transform 10 1793 env43091 = env43098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env43091 == env43098) = true)

theorem identity43098 : scanCanonicalize (H12AffineFastState.compose env43098 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound43098 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43099 : List Nat := [2,4,8,16,32,17,8,256,512,769,0,49,268,789,0,263,772,293,769,1,261,33,16,2,268,17,0,773,48,293,516,33,256,32,789,513]

theorem envBound43099 : H12AffineFastState.Bounded env43099 := by
  intro p hp
  have h : env43099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43098_43099 : H12AffineEnvironment.transform 9 769 env43098 = env43099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env43098 == env43099) = true)

def env43100 : List Nat := [2,4,8,16,32,17,8,256,308,53,0,49,268,33,0,263,48,293,53,1,261,33,16,2,268,17,0,49,48,293,304,33,256,32,33,309]

theorem envBound43100 : H12AffineFastState.Bounded env43100 := by
  intro p hp
  have h : env43100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43099_43100 : H12AffineEnvironment.transform 8 308 env43099 = env43100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env43099 == env43100) = true)

theorem identity43100 : scanCanonicalize (H12AffineFastState.compose env43100 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43100 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43101 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,42,268,33,0,263,43,293,46,1,261,33,11,2,268,10,0,42,43,293,299,33,256,32,33,302]

theorem envBound43101 : H12AffineFastState.Bounded env43101 := by
  intro p hp
  have h : env43101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43100_43101 : H12AffineEnvironment.transform 3 11 env43100 = env43101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43100 == env43101) = true)

end H12CloudChart1