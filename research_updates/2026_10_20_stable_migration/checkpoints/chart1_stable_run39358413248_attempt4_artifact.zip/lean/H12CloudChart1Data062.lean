import H12CloudChart1Data061

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans15599_15600 : H12AffineEnvironment.transform 10 0 env15599 = env15600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env15599 == env15600) = true)

def env15601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,2097152,4194304,8388608,10588557,8328,65,6458736,8393984,10507601,8527100,2102684,12645453,257,21793,46213,2175562]

theorem envBound15601 : H12AffineFastState.Bounded env15601 := by
  intro p hp
  have h : env15601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15517_15601 : H12AffineEnvironment.transform 17 56573 env15517 = env15601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56573 env15517 == env15601) = true)

def env15602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,4194304,8388608,8487373,8328,65,4365616,8393984,8406289,8527100,1500,12645453,257,21793,46213,74250]

theorem envBound15602 : H12AffineFastState.Bounded env15602 := by
  intro p hp
  have h : env15602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15601_15602 : H12AffineEnvironment.transform 20 4160 env15601 = env15602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15601 == env15602) = true)

def env15603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,4194304,16,98781,8328,65,4365616,5392,17665,138476,1500,4256861,257,21793,46213,74250]

theorem envBound15603 : H12AffineFastState.Bounded env15603 := by
  intro p hp
  have h : env15603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15602_15603 : H12AffineEnvironment.transform 22 16 env15602 = env15603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env15602 == env15603) = true)

theorem identity15603 : scanCanonicalize (H12AffineFastState.compose env15603 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 119926) := by decide +kernel

theorem selectedBound15603 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,119926,16,98781,8328,65,215366,5392,17665,138476,1500,73771,257,21793,46213,74250]

theorem envBound15604 : H12AffineFastState.Bounded env15604 := by
  intro p hp
  have h : env15604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15603_15604 : H12AffineEnvironment.transform 21 119926 env15603 = env15604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119926 env15603 == env15604) = true)

theorem identity15604 : scanCanonicalize (H12AffineFastState.compose env15604 (packedSelected [1,3,5,8,10,12,15,17,19,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound15604 : packedSelected [1,3,5,8,10,12,15,17,19,38,41] rootPS < 2^1333 := by decide +kernel

def env15605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,56573,1025,32769,4160,119926,16,98781,8328,65,10588,5392,17665,97526,1500,73771,257,21793,46213,74250]

theorem envBound15605 : H12AffineFastState.Bounded env15605 := by
  intro p hp
  have h : env15605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15604_15605 : H12AffineEnvironment.transform 16 90138 env15604 = env15605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env15604 == env15605) = true)

def env15606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,56437,1025,32769,4160,119926,16,98645,8192,65,10588,5392,17665,97406,1364,73771,257,21793,46093,74250]

theorem envBound15606 : H12AffineFastState.Bounded env15606 := by
  intro p hp
  have h : env15606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15605_15606 : H12AffineEnvironment.transform 6 8 env15605 = env15606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15605 == env15606) = true)

theorem identity15606 : scanCanonicalize (H12AffineFastState.compose env15606 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound15606 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15607 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,5393,56437,1025,32769,4160,41341,16,62558,8192,65,10588,5392,17665,2421,1364,21792,257,21793,46093,22273]

theorem envBound15607 : H12AffineFastState.Bounded env15607 := by
  intro p hp
  have h : env15607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15606_15607 : H12AffineEnvironment.transform 15 29963 env15606 = env15607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env15606 == env15607) = true)

theorem identity15607 : scanCanonicalize (H12AffineFastState.compose env15607 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound15607 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env15608 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,29823,5221,56437,1025,32769,4160,40969,16,62558,8192,65,10280,5220,17525,2049,1056,21588,117,21589,46093,22133]

theorem envBound15608 : H12AffineFastState.Bounded env15608 := by
  intro p hp
  have h : env15608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15607_15608 : H12AffineEnvironment.transform 7 116 env15607 = env15608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env15607 == env15608) = true)

theorem identity15608 : scanCanonicalize (H12AffineFastState.compose env15608 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound15608 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env15609 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,21541,29823,5221,2128,1025,21540,4160,29740,16,8315,8192,65,10280,5220,17525,2049,1056,21588,117,21589,24616,22133]

theorem envBound15609 : H12AffineFastState.Bounded env15609 := by
  intro p hp
  have h : env15609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15608_15609 : H12AffineEnvironment.transform 14 21541 env15608 = env15609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env15608 == env15609) = true)

def env15610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,56436,1025,32769,4160,119926,16,98644,8193,65,10588,5392,17665,97407,1365,73771,257,21793,46092,74250]

theorem envBound15610 : H12AffineFastState.Bounded env15610 := by
  intro p hp
  have h : env15610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15605_15610 : H12AffineEnvironment.transform 6 9 env15605 = env15610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15605 == env15610) = true)

theorem identity15610 : scanCanonicalize (H12AffineFastState.compose env15610 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound15610 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15611 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,46156,56436,1025,32769,4160,32,16,21762,8193,65,10588,5392,17665,43049,1365,62589,257,21793,46092,63068]

theorem envBound15611 : H12AffineFastState.Bounded env15611 := by
  intro p hp
  have h : env15611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15610_15611 : H12AffineEnvironment.transform 15 54358 env15610 = env15611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env15610 == env15611) = true)

theorem identity15611 : scanCanonicalize (H12AffineFastState.compose env15611 (packedSelected [1,2,3,4,5,6,8,9,11,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound15611 : packedSelected [1,2,3,4,5,6,8,9,11,15,16,20] rootPS < 2^1333 := by decide +kernel

def env15612 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,21511,13341,23589,1025,80,4160,32,16,21762,8193,65,10588,5392,17665,10360,1365,29740,257,21793,13405,30221]

theorem envBound15612 : H12AffineFastState.Bounded env15612 := by
  intro p hp
  have h : env15612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15611_15612 : H12AffineEnvironment.transform 14 81 env15611 = env15612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env15611 == env15612) = true)

theorem identity15612 : scanCanonicalize (H12AffineFastState.compose env15612 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound15612 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env15613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,81,262,13341,2340,1025,80,4160,32,16,3,8193,65,10588,5392,4096,10360,1365,8493,257,32,13405,8972]

theorem envBound15613 : H12AffineFastState.Bounded env15613 := by
  intro p hp
  have h : env15613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15612_15613 : H12AffineEnvironment.transform 13 5377 env15612 = env15613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15612 == env15613) = true)

theorem identity15613 : scanCanonicalize (H12AffineFastState.compose env15613 (packedSelected [4,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound15613 : packedSelected [4,9,12] rootPS < 2^1333 := by decide +kernel

def env15614 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6429,5377,81,262,3328,2340,1025,80,4160,32,16,3,6428,65,4161,5392,4096,4453,1365,6192,257,32,3392,6673]

theorem envBound15614 : H12AffineFastState.Bounded env15614 := by
  intro p hp
  have h : env15614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15613_15614 : H12AffineEnvironment.transform 12 6429 env15613 = env15614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env15613 == env15614) = true)

theorem identity15614 : scanCanonicalize (H12AffineFastState.compose env15614 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound15614 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env15615 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,348,3392,81,262,3328,2340,1025,80,2049,32,16,3,349,65,2048,3409,2113,2340,1365,113,257,32,3392,592]

theorem envBound15615 : H12AffineFastState.Bounded env15615 := by
  intro p hp
  have h : env15615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15614_15615 : H12AffineEnvironment.transform 11 2113 env15614 = env15615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env15614 == env15615) = true)

theorem identity15615 : scanCanonicalize (H12AffineFastState.compose env15615 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15615 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15616 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2113,41,3125,81,115,3189,2129,1025,80,2049,32,16,3,40,65,2048,3108,2113,2129,1056,113,116,32,3125,592]

theorem envBound15616 : H12AffineFastState.Bounded env15616 := by
  intro p hp
  have h : env15616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15615_15616 : H12AffineEnvironment.transform 7 117 env15615 = env15616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15615 == env15616) = true)

theorem identity15616 : scanCanonicalize (H12AffineFastState.compose env15616 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15616 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env15617 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,2065,41,3125,1,35,3109,2049,1025,0,2049,32,16,3,40,17,2048,3108,2065,2049,1056,33,36,32,3125,512]

theorem envBound15617 : H12AffineFastState.Bounded env15617 := by
  intro p hp
  have h : env15617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15616_15617 : H12AffineEnvironment.transform 5 16 env15616 = env15617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15616 == env15617) = true)

theorem identity15617 : scanCanonicalize (H12AffineFastState.compose env15617 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound15617 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15618 : List Nat := [2,4,8,16,32,16,9,37,512,21,2048,2065,41,2080,1,35,2096,2049,20,0,2049,32,16,3,40,17,2048,2097,2065,2049,53,33,36,32,2080,512]

theorem envBound15618 : H12AffineFastState.Bounded env15618 := by
  intro p hp
  have h : env15618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15617_15618 : H12AffineEnvironment.transform 9 21 env15617 = env15618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env15617 == env15618) = true)

theorem identity15618 : scanCanonicalize (H12AffineFastState.compose env15618 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound15618 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15619 : List Nat := [2,4,8,16,32,16,9,37,512,21,555,570,41,523,1,35,539,554,20,0,554,32,16,3,40,17,555,538,570,554,53,33,36,32,523,512]

theorem envBound15619 : H12AffineFastState.Bounded env15619 := by
  intro p hp
  have h : env15619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15618_15619 : H12AffineEnvironment.transform 10 555 env15618 = env15619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env15618 == env15619) = true)

theorem identity15619 : scanCanonicalize (H12AffineFastState.compose env15619 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 25) := by decide +kernel

theorem selectedBound15619 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env15620 : List Nat := [2,4,8,16,25,16,9,28,512,21,530,515,16,523,1,26,539,531,20,0,531,25,16,3,17,17,530,538,515,531,12,24,29,25,523,512]

theorem envBound15620 : H12AffineFastState.Bounded env15620 := by
  intro p hp
  have h : env15620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15619_15620 : H12AffineEnvironment.transform 4 25 env15619 = env15620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 25 env15619 == env15620) = true)

theorem identity15620 : scanCanonicalize (H12AffineFastState.compose env15620 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound15620 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15621 : List Nat := [2,4,8,9,0,9,9,5,512,12,523,515,9,523,1,3,514,522,13,0,522,0,9,3,8,8,523,515,515,522,12,1,4,0,523,512]

theorem envBound15621 : H12AffineFastState.Bounded env15621 := by
  intro p hp
  have h : env15621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15620_15621 : H12AffineEnvironment.transform 3 9 env15620 = env15621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env15620 == env15621) = true)

theorem identity15621 : scanCanonicalize (H12AffineFastState.compose env15621 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound15621 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15622 : List Nat := [2,4,8,9,0,9,9,5,6,12,13,5,9,13,1,3,4,12,13,0,12,0,9,3,8,8,13,5,5,12,12,1,4,0,13,6]

theorem envBound15622 : H12AffineFastState.Bounded env15622 := by
  intro p hp
  have h : env15622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15621_15622 : H12AffineEnvironment.transform 8 6 env15621 = env15622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env15621 == env15622) = true)

def env15623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4160,4194304,17,98780,8328,65,4365616,5393,17664,138477,1500,4256860,257,21793,46213,74250]

theorem envBound15623 : H12AffineFastState.Bounded env15623 := by
  intro p hp
  have h : env15623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15602_15623 : H12AffineEnvironment.transform 22 17 env15602 = env15623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env15602 == env15623) = true)

theorem identity15623 : scanCanonicalize (H12AffineFastState.compose env15623 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound15623 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,56573,1025,32769,4160,4194304,17,21763,8328,65,4365616,5393,17664,138477,1500,4256860,257,21793,46213,63189]

theorem envBound15624 : H12AffineFastState.Bounded env15624 := by
  intro p hp
  have h : env15624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15623_15624 : H12AffineEnvironment.transform 15 54495 env15623 = env15624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env15623 == env15624) = true)

theorem identity15624 : scanCanonicalize (H12AffineFastState.compose env15624 (packedSelected [1,4,5,7,8,9,11,14,16,18,19,20,23,24,26,27,32,35] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound15624 : packedSelected [1,4,5,7,8,9,11,14,16,18,19,20,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env15625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,8322,131072,10400,1025,29788,4160,4194304,17,21763,8328,65,4352365,5393,17664,138477,1500,4194305,257,21793,16600,648]

theorem envBound15625 : H12AffineFastState.Bounded env15625 := by
  intro p hp
  have h : env15625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15624_15625 : H12AffineEnvironment.transform 14 29789 env15624 = env15625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env15624 == env15625) = true)

theorem identity15625 : scanCanonicalize (H12AffineFastState.compose env15625 (packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15625 : packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env15626 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,10281,1025,29788,4160,4194304,17,21763,8193,65,4352365,5393,17664,138340,1365,4194305,257,21793,16465,513]

theorem envBound15626 : H12AffineFastState.Bounded env15626 := by
  intro p hp
  have h : env15626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15625_15626 : H12AffineEnvironment.transform 6 9 env15625 = env15626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15625 == env15626) = true)

theorem identity15626 : scanCanonicalize (H12AffineFastState.compose env15626 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 136496) := by decide +kernel

theorem selectedBound15626 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env15627 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,10281,1025,29788,4160,136496,17,21763,8193,65,31837,5393,17664,138340,1365,136497,257,21793,16465,513]

theorem envBound15627 : H12AffineFastState.Bounded env15627 := by
  intro p hp
  have h : env15627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15626_15627 : H12AffineEnvironment.transform 21 136496 env15626 = env15627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136496 env15626 == env15627) = true)

theorem identity15627 : scanCanonicalize (H12AffineFastState.compose env15627 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound15627 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env15628 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,16401,10281,1025,29788,4160,21793,17,21763,8193,65,31837,5393,17664,23669,1365,21792,257,21793,16465,513]

theorem envBound15628 : H12AffineFastState.Bounded env15628 := by
  intro p hp
  have h : env15628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15627_15628 : H12AffineEnvironment.transform 16 16401 env15627 = env15628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env15627 == env15628) = true)

theorem identity15628 : scanCanonicalize (H12AffineFastState.compose env15628 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15628 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env15629 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8203,16401,10281,1025,29708,4112,21793,17,21763,8193,17,31757,5393,17664,23589,1285,21792,257,21793,16385,513]

theorem envBound15629 : H12AffineFastState.Bounded env15629 := by
  intro p hp
  have h : env15629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15628_15629 : H12AffineEnvironment.transform 5 16 env15628 = env15629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15628 == env15629) = true)

theorem identity15629 : scanCanonicalize (H12AffineFastState.compose env15629 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15629 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env15630 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21760,262,16401,2340,1025,21761,4112,21793,17,21763,268,17,23808,5393,17664,23589,1285,21792,257,21793,16385,513]

theorem envBound15630 : H12AffineFastState.Bounded env15630 := by
  intro p hp
  have h : env15630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15629_15630 : H12AffineEnvironment.transform 12 269 env15629 = env15630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15629 == env15630) = true)

theorem identity15630 : scanCanonicalize (H12AffineFastState.compose env15630 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound15630 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15631 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,262,5392,2340,1025,0,4112,32,17,2,268,17,2049,5393,4097,2340,1285,33,257,32,5376,513]

theorem envBound15631 : H12AffineFastState.Bounded env15631 := by
  intro p hp
  have h : env15631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15630_15631 : H12AffineEnvironment.transform 13 5377 env15630 = env15631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15630 == env15631) = true)

theorem identity15631 : scanCanonicalize (H12AffineFastState.compose env15631 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound15631 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15632 : List Nat := [2,4,8,16,32,16,9,53,512,1024,2048,4096,56,5172,1,51,5157,2065,1025,0,4112,32,17,2,57,17,2049,5156,4097,2065,1072,33,52,32,5173,513]

theorem envBound15632 : H12AffineFastState.Bounded env15632 := by
  intro p hp
  have h : env15632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15631_15632 : H12AffineEnvironment.transform 7 53 env15631 = env15632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env15631 == env15632) = true)

theorem identity15632 : scanCanonicalize (H12AffineFastState.compose env15632 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound15632 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15633 : List Nat := [2,4,8,16,32,16,9,53,512,1024,2048,1573,56,529,1,51,512,2065,1025,0,1589,32,17,2,57,17,2049,513,1572,2065,1072,33,52,32,528,513]

theorem envBound15633 : H12AffineFastState.Bounded env15633 := by
  intro p hp
  have h : env15633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15632_15633 : H12AffineEnvironment.transform 11 1573 env15632 = env15633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env15632 == env15633) = true)

theorem identity15633 : scanCanonicalize (H12AffineFastState.compose env15633 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound15633 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15634 : List Nat := [2,4,8,16,32,16,9,53,512,564,2048,17,56,529,1,51,512,2065,565,0,1,32,17,2,57,17,2049,513,16,2065,516,33,52,32,528,513]

theorem envBound15634 : H12AffineFastState.Bounded env15634 := by
  intro p hp
  have h : env15634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15633_15634 : H12AffineEnvironment.transform 9 564 env15633 = env15634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env15633 == env15634) = true)

def env15635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,4194304,8388608,8487372,8328,65,4365617,8393984,8406288,8527100,1501,12645453,257,21793,46213,74251]

theorem envBound15635 : H12AffineFastState.Bounded env15635 := by
  intro p hp
  have h : env15635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15601_15635 : H12AffineEnvironment.transform 20 4161 env15601 = env15635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15601 == env15635) = true)

def env15636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,4194304,16,98780,8328,65,4365617,5392,17664,138476,1501,4256861,257,21793,46213,74251]

theorem envBound15636 : H12AffineFastState.Bounded env15636 := by
  intro p hp
  have h : env15636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15635_15636 : H12AffineEnvironment.transform 22 16 env15635 = env15636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env15635 == env15636) = true)

theorem identity15636 : scanCanonicalize (H12AffineFastState.compose env15636 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound15636 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,73891,16,98780,8328,65,245138,5392,17664,138476,1501,120062,257,21793,46213,74251]

theorem envBound15637 : H12AffineFastState.Bounded env15637 := by
  intro p hp
  have h : env15637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15636_15637 : H12AffineEnvironment.transform 21 73891 env15636 = env15637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env15636 == env15637) = true)

def env15638 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,73771,16,98644,8192,65,245018,5392,17664,138340,1365,119926,257,21793,46093,74251]

theorem envBound15638 : H12AffineFastState.Bounded env15638 := by
  intro p hp
  have h : env15638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15637_15638 : H12AffineEnvironment.transform 6 8 env15637 = env15638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15637 == env15638) = true)

theorem identity15638 : scanCanonicalize (H12AffineFastState.compose env15638 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound15638 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15639 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,56437,1025,32769,4161,21793,16,62558,8192,65,182288,5392,17664,138340,1365,41340,257,21793,46093,22273]

theorem envBound15639 : H12AffineFastState.Bounded env15639 := by
  intro p hp
  have h : env15639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15638_15639 : H12AffineEnvironment.transform 15 29962 env15638 = env15639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env15638 == env15639) = true)

theorem identity15639 : scanCanonicalize (H12AffineFastState.compose env15639 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound15639 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env15640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,16400,56437,1025,32769,4161,21793,16,62558,8192,65,34816,5392,17664,23668,1365,41340,257,21793,46093,22273]

theorem envBound15640 : H12AffineFastState.Bounded env15640 := by
  intro p hp
  have h : env15640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15639_15640 : H12AffineEnvironment.transform 16 16400 env15639 = env15640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env15639 == env15640) = true)

theorem identity15640 : scanCanonicalize (H12AffineFastState.compose env15640 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15640 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env15641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8202,5392,35189,1025,32769,4161,33,16,41310,8192,65,34816,5392,4096,2420,1365,41340,257,33,46093,513]

theorem envBound15641 : H12AffineFastState.Bounded env15641 := by
  intro p hp
  have h : env15641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15640_15641 : H12AffineEnvironment.transform 13 5376 env15640 = env15641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15640 == env15641) = true)

theorem identity15641 : scanCanonicalize (H12AffineFastState.compose env15641 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound15641 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15642 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,9292,8202,5392,11577,1025,9293,4161,33,16,1298,8192,65,11340,5392,4096,2420,1365,1328,257,33,4161,513]

theorem envBound15642 : H12AffineFastState.Bounded env15642 := by
  intro p hp
  have h : env15642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15641_15642 : H12AffineEnvironment.transform 14 9292 env15641 = env15642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env15641 == env15642) = true)

theorem identity15642 : scanCanonicalize (H12AffineFastState.compose env15642 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1124) := by decide +kernel

theorem selectedBound15642 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15643 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1124,8192,356,9292,8202,372,11577,1025,9293,1061,33,16,1298,8192,65,11340,372,1124,2420,1365,1328,257,33,1061,513]

theorem envBound15643 : H12AffineFastState.Bounded env15643 := by
  intro p hp
  have h : env15643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15642_15643 : H12AffineEnvironment.transform 11 1124 env15642 = env15643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1124 env15642 == env15643) = true)

def env15644 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,73770,16,98645,8193,65,245019,5392,17664,138341,1364,119927,257,21793,46092,74251]

theorem envBound15644 : H12AffineFastState.Bounded env15644 := by
  intro p hp
  have h : env15644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15637_15644 : H12AffineEnvironment.transform 6 9 env15637 = env15644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15637 == env15644) = true)

theorem identity15644 : scanCanonicalize (H12AffineFastState.compose env15644 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound15644 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15645 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,56436,1025,32769,4161,62589,16,21762,8193,65,158028,5392,17664,138341,1364,32,257,21793,46092,63068]

theorem envBound15645 : H12AffineFastState.Bounded env15645 := by
  intro p hp
  have h : env15645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15644_15645 : H12AffineEnvironment.transform 15 54359 env15644 = env15645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env15644 == env15645) = true)

theorem identity15645 : scanCanonicalize (H12AffineFastState.compose env15645 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound15645 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env15646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16400,56436,1025,32769,4161,62589,16,21762,8193,65,10588,5392,17664,23669,1364,32,257,21793,46092,63068]

theorem envBound15646 : H12AffineFastState.Bounded env15646 := by
  intro p hp
  have h : env15646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15645_15646 : H12AffineEnvironment.transform 16 16400 env15645 = env15646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env15645 == env15646) = true)

theorem identity15646 : scanCanonicalize (H12AffineFastState.compose env15646 (packedSelected [2,3,5,6,14,15,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound15646 : packedSelected [2,3,5,6,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env15647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,33031,5440,35108,1025,32769,4161,41261,16,82,8193,65,10588,5392,4176,2341,1364,32,257,113,46092,41740]

theorem envBound15647 : H12AffineFastState.Bounded env15647 := by
  intro p hp
  have h : env15647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15646_15647 : H12AffineEnvironment.transform 13 5456 env15646 = env15647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env15646 == env15647) = true)

theorem identity15647 : scanCanonicalize (H12AffineFastState.compose env15647 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15647 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env15648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,32768,33031,5440,35108,1025,32769,4161,32800,16,82,268,65,2129,5392,4176,2341,1364,32,257,113,38145,33281]

theorem envBound15648 : H12AffineFastState.Bounded env15648 := by
  intro p hp
  have h : env15648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15647_15648 : H12AffineEnvironment.transform 12 269 env15647 = env15648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15647 == env15648) = true)

theorem identity15648 : scanCanonicalize (H12AffineFastState.compose env15648 (packedSelected [0,2,3,6,8,9,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 6208) := by decide +kernel

theorem selectedBound15648 : packedSelected [0,2,3,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env15649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,6208,6471,5440,4452,1025,6209,4161,6240,16,82,268,65,2129,5392,4176,2341,1364,32,257,113,3393,6721]

theorem envBound15649 : H12AffineFastState.Bounded env15649 := by
  intro p hp
  have h : env15649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15648_15649 : H12AffineEnvironment.transform 14 6208 env15648 = env15649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6208 env15648 == env15649) = true)

theorem identity15649 : scanCanonicalize (H12AffineFastState.compose env15649 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound15649 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env15650 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,269,3344,0,263,3328,2340,1025,1,2049,32,16,82,268,65,2129,3408,2064,2341,1364,32,257,113,3393,513]

theorem envBound15650 : H12AffineFastState.Bounded env15650 := by
  intro p hp
  have h : env15650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15649_15650 : H12AffineEnvironment.transform 11 2112 env15649 = env15650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env15649 == env15650) = true)

theorem identity15650 : scanCanonicalize (H12AffineFastState.compose env15650 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15650 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env15651 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2064,269,3344,0,263,3328,2340,1025,1,2049,32,16,2,268,17,2049,3328,2064,2341,1284,32,257,33,3345,513]

theorem envBound15651 : H12AffineFastState.Bounded env15651 := by
  intro p hp
  have h : env15651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15650_15651 : H12AffineEnvironment.transform 5 16 env15650 = env15651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15650 == env15651) = true)

theorem identity15651 : scanCanonicalize (H12AffineFastState.compose env15651 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound15651 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15652 : List Nat := [2,4,8,16,32,16,9,256,512,1024,277,261,269,1029,0,263,1045,49,1025,1,276,32,16,2,268,17,276,1045,261,48,1284,32,257,33,1028,513]

theorem envBound15652 : H12AffineFastState.Bounded env15652 := by
  intro p hp
  have h : env15652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15651_15652 : H12AffineEnvironment.transform 10 277 env15651 = env15652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env15651 == env15652) = true)

theorem identity15652 : scanCanonicalize (H12AffineFastState.compose env15652 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound15652 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15653 : List Nat := [2,4,8,16,32,16,9,256,512,565,277,261,269,560,0,263,544,49,564,1,276,32,16,2,268,17,276,544,261,48,817,32,257,33,561,513]

theorem envBound15653 : H12AffineFastState.Bounded env15653 := by
  intro p hp
  have h : env15653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15652_15653 : H12AffineEnvironment.transform 9 565 env15652 = env15653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env15652 == env15653) = true)

theorem identity15653 : scanCanonicalize (H12AffineFastState.compose env15653 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15653 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15654 : List Nat := [2,4,8,16,1,16,9,256,512,532,277,261,269,529,0,263,513,16,533,1,276,1,16,2,268,17,276,513,261,17,784,1,257,0,528,513]

theorem envBound15654 : H12AffineFastState.Bounded env15654 := by
  intro p hp
  have h : env15654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15653_15654 : H12AffineEnvironment.transform 4 1 env15653 = env15654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15653 == env15654) = true)

theorem identity15654 : scanCanonicalize (H12AffineFastState.compose env15654 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15654 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15655 : List Nat := [2,4,8,16,1,16,9,5,512,532,16,0,8,529,0,2,513,16,533,1,17,1,16,2,9,17,17,513,0,17,533,1,4,0,528,513]

theorem envBound15655 : H12AffineFastState.Bounded env15655 := by
  intro p hp
  have h : env15655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15654_15655 : H12AffineEnvironment.transform 7 5 env15654 = env15655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15654 == env15655) = true)

def env15656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56573,1025,32769,4161,4194304,17,98781,8328,65,4365617,5393,17665,138477,1501,4256860,257,21793,46213,74251]

theorem envBound15656 : H12AffineFastState.Bounded env15656 := by
  intro p hp
  have h : env15656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15635_15656 : H12AffineEnvironment.transform 22 17 env15635 = env15656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env15635 == env15656) = true)

theorem identity15656 : scanCanonicalize (H12AffineFastState.compose env15656 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15656 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56573,1025,32769,4161,4194304,17,41431,8328,65,4365617,5393,17665,138477,1501,4256860,257,21793,46213,513]

theorem envBound15657 : H12AffineFastState.Bounded env15657 := by
  intro p hp
  have h : env15657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15656_15657 : H12AffineEnvironment.transform 15 8202 env15656 = env15657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15656 == env15657) = true)

theorem identity15657 : scanCanonicalize (H12AffineFastState.compose env15657 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound15657 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env15658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56573,1025,32769,4161,112,17,41431,8328,65,171329,5393,17665,138477,1501,62508,257,21793,46213,513]

theorem envBound15658 : H12AffineFastState.Bounded env15658 := by
  intro p hp
  have h : env15658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15657_15658 : H12AffineEnvironment.transform 21 112 env15657 = env15658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env15657 == env15658) = true)

def env15659 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56437,1025,32769,4161,112,17,41311,8192,65,171329,5393,17665,138341,1365,62508,257,21793,46093,513]

theorem envBound15659 : H12AffineFastState.Bounded env15659 := by
  intro p hp
  have h : env15659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15658_15659 : H12AffineEnvironment.transform 6 8 env15658 = env15659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15658 == env15659) = true)

theorem identity15659 : scanCanonicalize (H12AffineFastState.compose env15659 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15659 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15660 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,32040,1025,8540,4161,112,17,2,8192,65,146460,5393,17665,138341,1365,21873,257,21793,5456,513]

theorem envBound15660 : H12AffineFastState.Bounded env15660 := by
  intro p hp
  have h : env15660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15659_15660 : H12AffineEnvironment.transform 14 8541 env15659 = env15660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15659 == env15660) = true)

theorem identity15660 : scanCanonicalize (H12AffineFastState.compose env15660 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound15660 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15661 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,8541,8202,131072,30777,272,8540,4161,112,17,2,8192,65,145677,4096,16400,137588,68,20576,257,20528,4161,513]

theorem envBound15661 : H12AffineFastState.Bounded env15661 := by
  intro p hp
  have h : env15661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15660_15661 : H12AffineEnvironment.transform 9 273 env15660 = env15661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15660 == env15661) = true)

theorem identity15661 : scanCanonicalize (H12AffineFastState.compose env15661 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound15661 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env15662 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,12392,8541,8202,131072,2129,272,8540,4161,112,17,2,8192,65,145677,4096,12408,137588,68,8200,257,8280,4161,513]

theorem envBound15662 : H12AffineFastState.Bounded env15662 := by
  intro p hp
  have h : env15662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15661_15662 : H12AffineEnvironment.transform 13 12392 env15661 = env15662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env15661 == env15662) = true)

theorem identity15662 : scanCanonicalize (H12AffineFastState.compose env15662 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 12408) := by decide +kernel

theorem selectedBound15662 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env15663 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,12392,8541,8202,12408,2129,272,8540,4161,112,17,2,8192,65,2421,4096,12408,10508,68,8200,257,8280,4161,513]

theorem envBound15663 : H12AffineFastState.Bounded env15663 := by
  intro p hp
  have h : env15663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15662_15663 : H12AffineEnvironment.transform 16 12408 env15662 = env15663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12408 env15662 == env15663) = true)

theorem identity15663 : scanCanonicalize (H12AffineFastState.compose env15663 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound15663 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15664 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,120,4112,293,114,4096,2129,272,292,4161,112,17,2,120,65,2421,4096,4096,2420,68,112,257,32,4161,513]

theorem envBound15664 : H12AffineFastState.Bounded env15664 := by
  intro p hp
  have h : env15664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15663_15664 : H12AffineEnvironment.transform 12 120 env15663 = env15664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env15663 == env15664) = true)

def env15665 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56436,1025,32769,4161,112,17,41310,8193,65,171329,5393,17665,138340,1364,62508,257,21793,46092,513]

theorem envBound15665 : H12AffineFastState.Bounded env15665 := by
  intro p hp
  have h : env15665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15658_15665 : H12AffineEnvironment.transform 6 9 env15658 = env15665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15658 == env15665) = true)

def env15666 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56356,1025,32769,4113,32,17,41230,8193,17,171281,5393,17665,138292,1284,62508,257,21793,46092,513]

theorem envBound15666 : H12AffineFastState.Bounded env15666 := by
  intro p hp
  have h : env15666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15665_15666 : H12AffineEnvironment.transform 5 16 env15665 = env15666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15665 == env15666) = true)

theorem identity15666 : scanCanonicalize (H12AffineFastState.compose env15666 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15666 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env15667 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,8202,131072,23589,1025,0,4113,32,17,8463,8193,17,138512,5393,17665,138292,1284,29741,257,21793,13325,513]

theorem envBound15667 : H12AffineFastState.Bounded env15667 := by
  intro p hp
  have h : env15667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15666_15667 : H12AffineEnvironment.transform 14 1 env15666 = env15667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15666 == env15667) = true)

theorem identity15667 : scanCanonicalize (H12AffineFastState.compose env15667 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound15667 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15668 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,8202,13340,23589,1025,0,4113,32,17,8463,8193,17,10508,5393,17665,10280,1284,29741,257,21793,13325,513]

theorem envBound15668 : H12AffineFastState.Bounded env15668 := by
  intro p hp
  have h : env15668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15667_15668 : H12AffineEnvironment.transform 16 13340 env15667 = env15668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env15667 == env15668) = true)

theorem identity15668 : scanCanonicalize (H12AffineFastState.compose env15668 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15668 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15669 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,1,8202,13340,2341,1025,0,4113,32,17,8463,8193,17,10508,5393,4097,10280,1284,8493,257,33,13325,513]

theorem envBound15669 : H12AffineFastState.Bounded env15669 := by
  intro p hp
  have h : env15669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15668_15669 : H12AffineEnvironment.transform 13 5376 env15668 = env15669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15668 == env15669) = true)

theorem identity15669 : scanCanonicalize (H12AffineFastState.compose env15669 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound15669 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env15670 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2357,8192,3125,1,8202,11561,2341,1025,0,2340,32,17,8463,8193,17,10508,3108,2356,10280,1284,8493,257,33,11576,513]

theorem envBound15670 : H12AffineFastState.Bounded env15670 := by
  intro p hp
  have h : env15670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15669_15670 : H12AffineEnvironment.transform 11 2357 env15669 = env15670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env15669 == env15670) = true)

theorem identity15670 : scanCanonicalize (H12AffineFastState.compose env15670 (packedSelected [1,2,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 1069) := by decide +kernel

theorem selectedBound15670 : packedSelected [1,2,8,11] rootPS < 2^1333 := by decide +kernel

def env15671 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2357,1069,3125,1,1063,2308,2341,1025,0,2340,32,17,1314,1068,17,3361,3108,2356,3077,1284,1280,257,33,2325,513]

theorem envBound15671 : H12AffineFastState.Bounded env15671 := by
  intro p hp
  have h : env15671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15670_15671 : H12AffineEnvironment.transform 12 1069 env15670 = env15671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1069 env15670 == env15671) = true)

theorem identity15671 : scanCanonicalize (H12AffineFastState.compose env15671 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound15671 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env15672 : List Nat := [2,4,8,16,32,16,9,256,512,1024,16,293,1069,1061,1,1063,276,309,1025,0,308,32,17,1314,1068,17,1329,1076,292,1045,1284,1280,257,33,261,513]

theorem envBound15672 : H12AffineFastState.Bounded env15672 := by
  intro p hp
  have h : env15672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15671_15672 : H12AffineEnvironment.transform 10 16 env15671 = env15672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env15671 == env15672) = true)

theorem identity15672 : scanCanonicalize (H12AffineFastState.compose env15672 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15672 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env15673 : List Nat := [2,4,8,16,32,16,9,4,512,1024,16,33,1069,1061,1,1063,16,49,1025,0,48,32,17,1062,1068,17,1077,1076,32,1045,1024,1028,5,33,1,513]

theorem envBound15673 : H12AffineFastState.Bounded env15673 := by
  intro p hp
  have h : env15673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15672_15673 : H12AffineEnvironment.transform 7 4 env15672 = env15673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15672 == env15673) = true)

theorem identity15673 : scanCanonicalize (H12AffineFastState.compose env15673 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound15673 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15674 : List Nat := [2,4,8,16,32,16,9,4,512,5,16,33,40,32,1,34,16,49,4,0,48,32,17,35,41,17,48,49,32,16,5,1,5,33,1,513]

theorem envBound15674 : H12AffineFastState.Bounded env15674 := by
  intro p hp
  have h : env15674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15673_15674 : H12AffineEnvironment.transform 9 5 env15673 = env15674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env15673 == env15674) = true)

def env15675 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56357,1025,32769,4112,33,17,41231,8193,16,171280,5393,17665,138293,1285,62508,257,21793,46092,513]

theorem envBound15675 : H12AffineFastState.Bounded env15675 := by
  intro p hp
  have h : env15675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15665_15675 : H12AffineEnvironment.transform 5 17 env15665 = env15675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15665 == env15675) = true)

theorem identity15675 : scanCanonicalize (H12AffineFastState.compose env15675 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound15675 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env15676 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8202,13341,56357,1025,32769,4112,33,17,41231,8193,16,43277,5393,17665,10280,1285,62508,257,21793,46092,513]

theorem envBound15676 : H12AffineFastState.Bounded env15676 := by
  intro p hp
  have h : env15676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15675_15676 : H12AffineEnvironment.transform 16 13341 env15675 = env15676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env15675 == env15676) = true)

theorem identity15676 : scanCanonicalize (H12AffineFastState.compose env15676 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound15676 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15677 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,8202,13341,10281,1025,29709,4112,33,17,21763,8193,16,23809,5393,17665,10280,1285,32,257,21793,16384,513]

theorem envBound15677 : H12AffineFastState.Bounded env15677 := by
  intro p hp
  have h : env15677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15676_15677 : H12AffineEnvironment.transform 14 29708 env15676 = env15677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env15676 == env15677) = true)

def env15678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,1073741824,92374096,4294967296,525568,4308116845,27337993,25733062]

theorem envBound15678 : H12AffineFastState.Bounded env15678 := by
  intro p hp
  have h : env15678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9916_15678 : H12AffineEnvironment.transform 28 77616401 env9916 = env15678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616401 env9916 == env15678) = true)

def env15679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,1073741824,92374096,145662400,525568,140903597,27337993,25733062]

theorem envBound15679 : H12AffineFastState.Bounded env15679 := by
  intro p hp
  have h : env15679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15678_15679 : H12AffineEnvironment.transform 31 145662400 env15678 = env15679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env15678 == env15679) = true)

def env15680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254784,92374096,145662400,525568,140903597,27337993,25733062]

theorem envBound15680 : H12AffineFastState.Bounded env15680 := by
  intro p hp
  have h : env15680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15679_15680 : H12AffineEnvironment.transform 29 155254784 env15679 = env15680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env15679 == env15680) = true)

def env15681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254784,25265168,145662400,525568,140903597,27337993,25733062]

theorem envBound15681 : H12AffineFastState.Bounded env15681 := by
  intro p hp
  have h : env15681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15680_15681 : H12AffineEnvironment.transform 25 64 env15680 = env15681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env15680 == env15681) = true)

def env15682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356288,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound15682 : H12AffineFastState.Bounded env15682 := by
  intro p hp
  have h : env15682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15681_15682 : H12AffineEnvironment.transform 26 30393344 env15681 = env15682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env15681 == env15682) = true)

def env15683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound15683 : H12AffineFastState.Bounded env15683 := by
  intro p hp
  have h : env15683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15682_15683 : H12AffineEnvironment.transform 18 1024 env15682 = env15683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env15682 == env15683) = true)

theorem identity15683 : scanCanonicalize (H12AffineFastState.compose env15683 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 41413) := by decide +kernel

theorem selectedBound15683 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env15684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,41413,16777216,8328,64,21455301,18973836,2159764,418245,16852437,23160256,256,18965864,18973900,16777731]

theorem envBound15684 : H12AffineFastState.Bounded env15684 := by
  intro p hp
  have h : env15684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15683_15684 : H12AffineEnvironment.transform 22 41413 env15683 = env15684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41413 env15683 == env15684) = true)

def env15685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,262144,1024,32769,2097152,4194304,41413,16777216,8328,64,21331969,18973836,2159764,294913,16852437,23160256,256,18965864,18973900,16777731]

theorem envBound15685 : H12AffineFastState.Bounded env15685 := by
  intro p hp
  have h : env15685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15684_15685 : H12AffineEnvironment.transform 16 57796 env15684 = env15685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57796 env15684 == env15685) = true)

theorem identity15685 : scanCanonicalize (H12AffineFastState.compose env15685 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound15685 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env15686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,262144,1024,32769,2097152,4194304,41413,2,8328,64,4554755,2196622,2159764,294913,75223,6383042,256,2188650,2196686,513]

theorem envBound15686 : H12AffineFastState.Bounded env15686 := by
  intro p hp
  have h : env15686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15685_15686 : H12AffineEnvironment.transform 23 2 env15685 = env15686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env15685 == env15686) = true)

def env15687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,10280,1024,32769,2097152,4194304,41413,2,8328,64,4302891,2196622,2159764,43049,75223,6383042,256,2188650,2196686,513]

theorem envBound15687 : H12AffineFastState.Bounded env15687 := by
  intro p hp
  have h : env15687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15686_15687 : H12AffineEnvironment.transform 17 10280 env15686 = env15687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env15686 == env15687) = true)

theorem identity15687 : scanCanonicalize (H12AffineFastState.compose env15687 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15687 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env15688 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41293,2,8192,64,4302891,2196486,2159644,43049,75103,6382922,256,2188650,2196550,513]

theorem envBound15688 : H12AffineFastState.Bounded env15688 := by
  intro p hp
  have h : env15688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15687_15688 : H12AffineEnvironment.transform 6 8 env15687 = env15688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15687 == env15688) = true)

theorem identity15688 : scanCanonicalize (H12AffineFastState.compose env15688 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound15688 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env15689 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,115735,4194304,41293,2,8192,64,4302891,16401,77835,43049,75103,4235613,256,41341,16465,513]

theorem envBound15689 : H12AffineFastState.Bounded env15689 := by
  intro p hp
  have h : env15689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15688_15689 : H12AffineEnvironment.transform 20 115735 env15688 = env15689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env15688 == env15689) = true)

theorem identity15689 : scanCanonicalize (H12AffineFastState.compose env15689 (packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound15689 : packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env15690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,91467,4194304,17,2,8192,64,4262263,16401,77835,2421,75103,4194305,256,33,16465,513]

theorem envBound15690 : H12AffineFastState.Bounded env15690 := by
  intro p hp
  have h : env15690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15689_15690 : H12AffineEnvironment.transform 14 8540 env15689 = env15690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env15689 == env15690) = true)

theorem identity15690 : scanCanonicalize (H12AffineFastState.compose env15690 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15690 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env15691 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1024,8541,17729,4194304,17,2,8192,64,4204925,16401,4097,2421,1365,4194305,256,33,16465,513]

theorem envBound15691 : H12AffineFastState.Bounded env15691 := by
  intro p hp
  have h : env15691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15690_15691 : H12AffineEnvironment.transform 15 8202 env15690 = env15691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15690 == env15691) = true)

theorem identity15691 : scanCanonicalize (H12AffineFastState.compose env15691 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15691 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15692 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,8202,16400,10280,1024,8460,17680,4194304,17,2,8192,17,4204844,16401,4097,2340,1284,4194305,256,33,16384,513]

theorem envBound15692 : H12AffineFastState.Bounded env15692 := by
  intro p hp
  have h : env15692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15691_15692 : H12AffineEnvironment.transform 5 17 env15691 = env15692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15691 == env15692) = true)

theorem identity15692 : scanCanonicalize (H12AffineFastState.compose env15692 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3101) := by decide +kernel

theorem selectedBound15692 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env15693 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,3101,16384,3344,3095,16400,1077,1024,3345,17680,4194304,17,2,3101,17,4195633,16401,4097,2340,1284,4194305,256,33,16384,513]

theorem envBound15693 : H12AffineFastState.Bounded env15693 := by
  intro p hp
  have h : env15693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15692_15693 : H12AffineEnvironment.transform 12 3101 env15692 = env15693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3101 env15692 == env15693) = true)

theorem identity15693 : scanCanonicalize (H12AffineFastState.compose env15693 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound15693 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15694 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,3101,16384,3344,3095,16400,1077,1024,3345,17680,33,17,2,3101,17,1296,16401,4097,2340,1284,32,256,33,16384,513]

theorem envBound15694 : H12AffineFastState.Bounded env15694 := by
  intro p hp
  have h : env15694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15693_15694 : H12AffineEnvironment.transform 21 33 env15693 = env15694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env15693 == env15694) = true)

theorem identity15694 : scanCanonicalize (H12AffineFastState.compose env15694 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound15694 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15695 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2325,3101,16384,3344,3095,16400,1077,1024,3345,17680,33,17,2,3101,17,1296,16401,2324,2340,1284,32,256,33,16384,513]

theorem envBound15695 : H12AffineFastState.Bounded env15695 := by
  intro p hp
  have h : env15695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15694_15695 : H12AffineEnvironment.transform 11 2325 env15694 = env15695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env15694 == env15695) = true)

theorem identity15695 : scanCanonicalize (H12AffineFastState.compose env15695 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound15695 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env15696 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1557,1792,520,16384,773,514,16400,1077,1024,772,17680,33,17,2,520,17,1296,16401,1793,1841,1284,32,256,33,16384,513]

theorem envBound15696 : H12AffineFastState.Bounded env15696 := by
  intro p hp
  have h : env15696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15695_15696 : H12AffineEnvironment.transform 10 1557 env15695 = env15696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env15695 == env15696) = true)

theorem identity15696 : scanCanonicalize (H12AffineFastState.compose env15696 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 292) := by decide +kernel

theorem selectedBound15696 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env15697 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1557,1792,520,292,773,514,308,1077,1024,772,1076,33,17,2,520,17,1296,309,1793,1841,1284,32,256,33,292,513]

theorem envBound15697 : H12AffineFastState.Bounded env15697 := by
  intro p hp
  have h : env15697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15696_15697 : H12AffineEnvironment.transform 13 292 env15696 = env15697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 292 env15696 == env15697) = true)

theorem identity15697 : scanCanonicalize (H12AffineFastState.compose env15697 (packedSelected [1,3,12] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound15697 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env15698 : List Nat := [2,4,8,16,32,17,8,256,261,1024,1296,1029,269,292,0,263,308,1077,1024,1,1076,33,17,2,269,17,1296,309,1028,1076,1284,32,256,33,292,260]

theorem envBound15698 : H12AffineFastState.Bounded env15698 := by
  intro p hp
  have h : env15698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15697_15698 : H12AffineEnvironment.transform 8 261 env15697 = env15698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env15697 == env15698) = true)

theorem identity15698 : scanCanonicalize (H12AffineFastState.compose env15698 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound15698 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15699 : List Nat := [2,4,8,16,32,17,8,256,261,52,292,49,269,292,0,263,308,1,52,1,0,33,17,2,269,17,292,309,48,0,304,32,256,33,292,260]

theorem envBound15699 : H12AffineFastState.Bounded env15699 := by
  intro p hp
  have h : env15699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15698_15699 : H12AffineEnvironment.transform 9 52 env15698 = env15699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15698 == env15699) = true)

theorem identity15699 : scanCanonicalize (H12AffineFastState.compose env15699 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound15699 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15700 : List Nat := [2,4,8,16,16,17,8,256,261,4,276,1,269,276,0,263,260,1,4,1,0,17,17,2,269,17,276,261,0,0,256,16,256,17,276,260]

theorem envBound15700 : H12AffineFastState.Bounded env15700 := by
  intro p hp
  have h : env15700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15699_15700 : H12AffineEnvironment.transform 4 16 env15699 = env15700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env15699 == env15700) = true)

def env15701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,10281,1024,32769,2097152,4194304,41413,2,8328,64,4302890,2196622,2159764,43048,75223,6383042,256,2188650,2196686,513]

theorem envBound15701 : H12AffineFastState.Bounded env15701 := by
  intro p hp
  have h : env15701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15686_15701 : H12AffineEnvironment.transform 17 10281 env15686 = env15701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env15686 == env15701) = true)

theorem identity15701 : scanCanonicalize (H12AffineFastState.compose env15701 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15701 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env15702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16537,10281,1024,8540,2097152,4194304,152,2,8328,64,4262263,2172371,2119113,2421,75223,6383042,256,2188650,2172307,513]

theorem envBound15702 : H12AffineFastState.Bounded env15702 := by
  intro p hp
  have h : env15702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15701_15702 : H12AffineEnvironment.transform 14 8541 env15701 = env15702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15701 == env15702) = true)

theorem identity15702 : scanCanonicalize (H12AffineFastState.compose env15702 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound15702 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env15703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8323,16537,10281,1024,8540,2097152,4194304,152,2,8328,64,4205044,2098512,2119113,2421,1364,6309185,256,2115049,2098448,513]

theorem envBound15703 : H12AffineFastState.Bounded env15703 := by
  intro p hp
  have h : env15703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15702_15703 : H12AffineEnvironment.transform 15 8323 env15702 = env15703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env15702 == env15703) = true)

theorem identity15703 : scanCanonicalize (H12AffineFastState.compose env15703 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound15703 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env15704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8323,16537,10281,1024,8540,5456,4194304,152,2,8328,64,4205044,4096,16537,2421,1364,4214801,256,20665,4160,513]

theorem envBound15704 : H12AffineFastState.Bounded env15704 := by
  intro p hp
  have h : env15704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15703_15704 : H12AffineEnvironment.transform 20 5456 env15703 = env15704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env15703 == env15704) = true)

theorem identity15704 : scanCanonicalize (H12AffineFastState.compose env15704 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound15704 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8541,8323,4232,10281,1024,8540,5456,4194304,152,2,8328,64,4205044,4096,4232,2421,1364,4194304,256,168,4160,513]

theorem envBound15705 : H12AffineFastState.Bounded env15705 := by
  intro p hp
  have h : env15705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15704_15705 : H12AffineEnvironment.transform 13 4113 env15704 = env15705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env15704 == env15705) = true)

theorem identity15705 : scanCanonicalize (H12AffineFastState.compose env15705 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(21+1) ^^^ 8612) := by decide +kernel

theorem selectedBound15705 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env15706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8541,8323,4232,10281,1024,8540,5456,8612,152,2,8328,64,2128,4096,4232,2421,1364,8612,256,168,4160,513]

theorem envBound15706 : H12AffineFastState.Bounded env15706 := by
  intro p hp
  have h : env15706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15705_15706 : H12AffineEnvironment.transform 21 8612 env15705 = env15706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8612 env15705 == env15706) = true)

theorem identity15706 : scanCanonicalize (H12AffineFastState.compose env15706 (packedSelected [0,1,4,5,7,8,9,14,24] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound15706 : packedSelected [0,1,4,5,7,8,9,14,24] rootPS < 2^1333 := by decide +kernel

def env15707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,4113,136,342,4232,2556,1024,137,5456,113,152,2,349,64,2128,4096,4232,2421,1364,113,256,168,4160,513]

theorem envBound15707 : H12AffineFastState.Bounded env15707 := by
  intro p hp
  have h : env15707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15706_15707 : H12AffineEnvironment.transform 12 469 env15706 = env15707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env15706 == env15707) = true)

theorem identity15707 : scanCanonicalize (H12AffineFastState.compose env15707 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound15707 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15708 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,4113,81,342,4177,2341,1024,80,5456,113,65,2,349,64,2128,4096,4177,2421,1364,113,256,113,4160,513]

theorem envBound15708 : H12AffineFastState.Bounded env15708 := by
  intro p hp
  have h : env15708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15707_15708 : H12AffineEnvironment.transform 6 89 env15707 = env15708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env15707 == env15708) = true)

theorem identity15708 : scanCanonicalize (H12AffineFastState.compose env15708 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15708 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15709 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,4113,0,263,4096,2341,1024,1,5377,32,16,2,268,17,2049,4096,4096,2340,1285,32,256,32,4113,513]

theorem envBound15709 : H12AffineFastState.Bounded env15709 := by
  intro p hp
  have h : env15709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15708_15709 : H12AffineEnvironment.transform 5 17 env15708 = env15709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15708 == env15709) = true)

theorem identity15709 : scanCanonicalize (H12AffineFastState.compose env15709 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound15709 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15710 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,268,4113,0,263,4096,2341,53,1,4404,32,16,2,268,17,2049,4096,4096,2340,304,32,256,32,4113,513]

theorem envBound15710 : H12AffineFastState.Bounded env15710 := by
  intro p hp
  have h : env15710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15709_15710 : H12AffineEnvironment.transform 9 53 env15709 = env15710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15709 == env15710) = true)

theorem identity15710 : scanCanonicalize (H12AffineFastState.compose env15710 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound15710 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env15711 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,560,268,545,0,263,560,2341,53,1,772,32,16,2,268,17,2049,560,560,2340,304,32,256,32,545,513]

theorem envBound15711 : H12AffineFastState.Bounded env15711 := by
  intro p hp
  have h : env15711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15710_15711 : H12AffineEnvironment.transform 11 560 env15710 = env15711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env15710 == env15711) = true)

def env15712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,262144,1024,32769,2097152,4194304,41413,16777216,8328,64,21331968,18973836,2159764,294912,16852437,23160256,256,18965864,18973900,16777731]

theorem envBound15712 : H12AffineFastState.Bounded env15712 := by
  intro p hp
  have h : env15712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15684_15712 : H12AffineEnvironment.transform 16 57797 env15684 = env15712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57797 env15684 == env15712) = true)

def env15713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,10280,1024,32769,2097152,4194304,41413,16777216,8328,64,21080104,18973836,2159764,43048,16852437,23160256,256,18965864,18973900,16777731]

theorem envBound15713 : H12AffineFastState.Bounded env15713 := by
  intro p hp
  have h : env15713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15712_15713 : H12AffineEnvironment.transform 17 10280 env15712 = env15713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env15712 == env15713) = true)

theorem identity15713 : scanCanonicalize (H12AffineFastState.compose env15713 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound15713 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env15714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,10280,1024,32769,2097152,4194304,41413,138,8328,64,4303010,2196486,2159764,43048,75103,6382922,256,2188770,2196550,649]

theorem envBound15714 : H12AffineFastState.Bounded env15714 := by
  intro p hp
  have h : env15714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15713_15714 : H12AffineEnvironment.transform 23 138 env15713 = env15714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env15713 == env15714) = true)

def env15715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41293,2,8192,64,4302890,2196486,2159644,43048,75103,6382922,256,2188650,2196550,513]

theorem envBound15715 : H12AffineFastState.Bounded env15715 := by
  intro p hp
  have h : env15715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15714_15715 : H12AffineEnvironment.transform 6 8 env15714 = env15715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15714 == env15715) = true)

theorem identity15715 : scanCanonicalize (H12AffineFastState.compose env15715 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 50496) := by decide +kernel

theorem selectedBound15715 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env15716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,50496,4194304,41293,2,8192,64,4302890,82246,12636,43048,75103,4300810,256,106538,82182,513]

theorem envBound15716 : H12AffineFastState.Bounded env15716 := by
  intro p hp
  have h : env15716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15715_15716 : H12AffineEnvironment.transform 20 50496 env15715 = env15716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50496 env15715 == env15716) = true)

theorem identity15716 : scanCanonicalize (H12AffineFastState.compose env15716 (packedSelected [0,3,4,5,7,9,10,14,16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound15716 : packedSelected [0,3,4,5,7,9,10,14,16,17,20] rootPS < 2^1333 := by decide +kernel

def env15717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,57677,10280,1024,32769,50496,4194304,41293,2,8192,64,4237693,16401,12636,43048,9224,4235613,256,41341,16465,513]

theorem envBound15717 : H12AffineFastState.Bounded env15717 := by
  intro p hp
  have h : env15717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15716_15717 : H12AffineEnvironment.transform 15 343 env15716 = env15717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env15716 == env15717) = true)

theorem identity15717 : scanCanonicalize (H12AffineFastState.compose env15717 (packedSelected [1,2,3,4,5,6,8,9,14,15,16] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound15717 : packedSelected [1,2,3,4,5,6,8,9,14,15,16] rootPS < 2^1333 := by decide +kernel

def env15718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,57677,10280,1024,32769,50496,41341,41293,2,8192,64,2048,16401,12636,43048,9224,32,256,41341,16465,513]

theorem envBound15718 : H12AffineFastState.Bounded env15718 := by
  intro p hp
  have h : env15718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15717_15718 : H12AffineEnvironment.transform 21 41341 env15717 = env15718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env15717 == env15718) = true)

theorem identity15718 : scanCanonicalize (H12AffineFastState.compose env15718 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15718 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,16400,10280,1024,8540,25629,32,16,2,8192,64,2048,16401,12636,2421,9224,32,256,32,16465,513]

theorem envBound15719 : H12AffineFastState.Bounded env15719 := by
  intro p hp
  have h : env15719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15718_15719 : H12AffineEnvironment.transform 14 8541 env15718 = env15719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15718 == env15719) = true)

def env15720 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41292,3,8193,64,4302891,2196486,2159645,43048,75103,6382922,256,2188651,2196550,512]

theorem envBound15720 : H12AffineFastState.Bounded env15720 := by
  intro p hp
  have h : env15720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15714_15720 : H12AffineEnvironment.transform 6 9 env15714 = env15720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15714 == env15720) = true)

theorem identity15720 : scanCanonicalize (H12AffineFastState.compose env15720 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound15720 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,32,41292,3,8193,64,108555,2196486,2159645,43048,75103,2188650,256,2188651,2196550,512]

theorem envBound15721 : H12AffineFastState.Bounded env15721 := by
  intro p hp
  have h : env15721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15720_15721 : H12AffineEnvironment.transform 21 32 env15720 = env15721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env15720 == env15721) = true)

theorem identity15721 : scanCanonicalize (H12AffineFastState.compose env15721 (packedSelected [0,3,4,5,7,9,10,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15721 : packedSelected [0,3,4,5,7,9,10,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env15722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,57676,10280,1024,32769,2097152,32,41292,3,8193,64,34816,2139149,2159645,43048,1364,2114913,256,2114912,2139213,512]

theorem envBound15722 : H12AffineFastState.Bounded env15722 := by
  intro p hp
  have h : env15722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15721_15722 : H12AffineEnvironment.transform 15 8203 env15721 = env15722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15721 == env15722) = true)

theorem identity15722 : scanCanonicalize (H12AffineFastState.compose env15722 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15722 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,262,49217,2341,1024,32769,2097152,32,32833,3,268,64,34816,2131200,2151696,35109,1364,2114913,256,2114912,2131264,512]

theorem envBound15723 : H12AffineFastState.Bounded env15723 := by
  intro p hp
  have h : env15723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15722_15723 : H12AffineEnvironment.transform 12 269 env15722 = env15723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15722 == env15723) = true)

theorem identity15723 : scanCanonicalize (H12AffineFastState.compose env15723 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(20+1) ^^^ 50448) := by decide +kernel

theorem selectedBound15723 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env15724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,262,49217,2341,1024,32769,50448,32,32833,3,268,64,34816,16400,4096,35109,1364,32881,256,32880,16464,512]

theorem envBound15724 : H12AffineFastState.Bounded env15724 := by
  intro p hp
  have h : env15724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15723_15724 : H12AffineEnvironment.transform 20 50448 env15723 = env15724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env15723 == env15724) = true)

theorem identity15724 : scanCanonicalize (H12AffineFastState.compose env15724 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 21793) := by decide +kernel

theorem selectedBound15724 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env15725 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21793,262,5472,2341,1024,21792,4145,32,21856,3,268,64,23841,16400,4096,23556,1364,21840,256,21841,16464,512]

theorem envBound15725 : H12AffineFastState.Bounded env15725 := by
  intro p hp
  have h : env15725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15724_15725 : H12AffineEnvironment.transform 14 21793 env15724 = env15725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21793 env15724 == env15725) = true)

theorem identity15725 : scanCanonicalize (H12AffineFastState.compose env15725 (packedSelected [6,14] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound15725 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env15726 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5236,341,262,5472,2341,1024,340,4145,32,276,3,268,64,2389,5220,4096,2160,1364,292,256,293,5156,512]

theorem envBound15726 : H12AffineFastState.Bounded env15726 := by
  intro p hp
  have h : env15726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15725_15726 : H12AffineEnvironment.transform 13 5236 env15725 = env15726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env15725 == env15726) = true)

theorem identity15726 : scanCanonicalize (H12AffineFastState.compose env15726 (packedSelected [0,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound15726 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env15727 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,269,5125,292,262,5393,2341,1024,293,4145,32,276,3,268,49,2340,5141,4096,2049,1317,292,256,293,5156,512]

theorem envBound15727 : H12AffineFastState.Bounded env15727 := by
  intro p hp
  have h : env15727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15726_15727 : H12AffineEnvironment.transform 5 49 env15726 = env15727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env15726 == env15727) = true)

theorem identity15727 : scanCanonicalize (H12AffineFastState.compose env15727 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15727 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env15728 : List Nat := [2,4,8,16,32,49,9,4,512,1024,2048,4096,9,5125,32,2,5141,2081,1024,33,4145,32,16,3,8,49,2080,5141,4096,2049,1057,32,4,33,5156,512]

theorem envBound15728 : H12AffineFastState.Bounded env15728 := by
  intro p hp
  have h : env15728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15727_15728 : H12AffineEnvironment.transform 7 4 env15727 = env15728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15727 == env15728) = true)

theorem identity15728 : scanCanonicalize (H12AffineFastState.compose env15728 (packedSelected [20] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15728 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env15729 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5125,1,2,5141,2048,1024,0,4112,1,16,3,8,16,2049,5141,4096,2049,1024,1,4,0,5125,512]

theorem envBound15729 : H12AffineFastState.Bounded env15729 := by
  intro p hp
  have h : env15729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15728_15729 : H12AffineEnvironment.transform 4 1 env15728 = env15729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15728 == env15729) = true)

def env15730 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,9,1045,1,2,1029,2048,1024,0,0,1,16,3,8,16,2049,1029,16,2049,1024,1,4,0,1045,512]

theorem envBound15730 : H12AffineFastState.Bounded env15730 := by
  intro p hp
  have h : env15730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15729_15730 : H12AffineEnvironment.transform 11 16 env15729 = env15730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env15729 == env15730) = true)

def env15731 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,9,1044,1,2,1028,2048,1024,0,1,1,16,3,8,16,2049,1028,17,2049,1024,1,4,0,1044,512]

theorem envBound15731 : H12AffineFastState.Bounded env15731 := by
  intro p hp
  have h : env15731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15729_15731 : H12AffineEnvironment.transform 11 17 env15729 = env15731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env15729 == env15731) = true)

theorem identity15731 : scanCanonicalize (H12AffineFastState.compose env15731 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound15731 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15732 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,9,1,1,2,17,2048,21,0,1,1,16,3,8,16,2049,17,17,2049,21,1,4,0,1,512]

theorem envBound15732 : H12AffineFastState.Bounded env15732 := by
  intro p hp
  have h : env15732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15731_15732 : H12AffineEnvironment.transform 9 21 env15731 = env15732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env15731 == env15732) = true)

theorem identity15732 : scanCanonicalize (H12AffineFastState.compose env15732 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound15732 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15733 : List Nat := [2,4,8,5,1,5,9,4,512,0,2048,4,9,1,1,2,4,2048,0,0,1,1,5,3,8,5,2049,4,4,2049,0,1,4,0,1,512]

theorem envBound15733 : H12AffineFastState.Bounded env15733 := by
  intro p hp
  have h : env15733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15732_15733 : H12AffineEnvironment.transform 3 5 env15732 = env15733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env15732 == env15733) = true)

def leafEnv15733 : List Nat := [2,4,8,5,1,5,9,4,512,0,2048,4,9,1,1,2,4,2048,0,0,1,1,5,3,0,8,1,5,2049,4,4,2049,0,1,4,0,4,3,1,512,1,1,0]

def active15733 : List Nat := [0,1,2,8,10]

def tree15733 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15733 : H12WitnessSearch.Good tree15733 := H12GlobalWitnessIndex.good

theorem leafIdentity15733 : H12AffineFastState.composeSystem env15733 rootObs = leafEnv15733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15733 rootObs == leafEnv15733) = true)

theorem terminalChecked15733 : H12PackedTerminal.terminalCheckFast leafEnv15733 active15733 tree15733 = true := by decide +kernel

def env15734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,10281,1024,32769,2097152,4194304,41413,16777216,8328,64,21080105,18973836,2159764,43049,16852437,23160256,256,18965864,18973900,16777731]

theorem envBound15734 : H12AffineFastState.Bounded env15734 := by
  intro p hp
  have h : env15734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15712_15734 : H12AffineEnvironment.transform 17 10281 env15712 = env15734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env15712 == env15734) = true)

theorem identity15734 : scanCanonicalize (H12AffineFastState.compose env15734 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound15734 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env15735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,10281,1024,32769,2097152,4194304,41413,41311,8328,64,4262262,2172371,2159764,43049,99466,6407327,256,2212919,2172307,41820]

theorem envBound15735 : H12AffineFastState.Bounded env15735 := by
  intro p hp
  have h : env15735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15734_15735 : H12AffineEnvironment.transform 23 41311 env15734 = env15735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env15734 == env15735) = true)

theorem identity15735 : scanCanonicalize (H12AffineFastState.compose env15735 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound15735 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env15736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,57797,10281,1024,32769,2097152,4194304,41413,41311,8328,64,4205044,2098513,2159764,43049,41992,6349853,256,2155701,2098449,41820]

theorem envBound15736 : H12AffineFastState.Bounded env15736 := by
  intro p hp
  have h : env15736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15735_15736 : H12AffineEnvironment.transform 15 8322 env15735 = env15736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env15735 == env15736) = true)

theorem identity15736 : scanCanonicalize (H12AffineFastState.compose env15736 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 29125) := by decide +kernel

theorem selectedBound15736 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env15737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29125,8322,4096,10281,1024,29124,2097152,4194304,20480,20634,8328,64,4205044,2098513,2098513,23020,21965,6297048,256,2102640,2098449,21145]

theorem envBound15737 : H12AffineFastState.Bounded env15737 := by
  intro p hp
  have h : env15737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15736_15737 : H12AffineEnvironment.transform 14 29125 env15736 = env15737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29125 env15736 == env15737) = true)

theorem identity15737 : scanCanonicalize (H12AffineFastState.compose env15737 (packedSelected [0,9,11,14,18,22,23,27,32,35] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound15737 : packedSelected [0,9,11,14,18,22,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env15738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29125,8322,4096,10281,1024,29124,2097152,169,20480,20634,8328,64,10589,2098513,2098513,23020,21965,2102641,256,2102640,2098449,21145]

theorem envBound15738 : H12AffineFastState.Bounded env15738 := by
  intro p hp
  have h : env15738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15737_15738 : H12AffineEnvironment.transform 21 169 env15737 = env15738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env15737 == env15738) = true)

theorem identity15738 : scanCanonicalize (H12AffineFastState.compose env15738 (packedSelected [0,1,2,3,6,7,16,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15738 : packedSelected [0,1,2,3,6,7,16,24,28] rootPS < 2^1333 := by decide +kernel

def env15739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8202,4096,10281,1024,29004,2097152,33,20480,20498,8192,64,10589,2098513,2098513,22884,21829,2102641,256,2102640,2098449,21009]

theorem envBound15739 : H12AffineFastState.Bounded env15739 := by
  intro p hp
  have h : env15739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15738_15739 : H12AffineEnvironment.transform 6 8 env15738 = env15739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15738 == env15739) = true)

theorem identity15739 : scanCanonicalize (H12AffineFastState.compose env15739 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(20+1) ^^^ 12621) := by decide +kernel

theorem selectedBound15739 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env15740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8202,4096,10281,1024,29004,12621,33,20480,20498,8192,64,10589,13340,13340,22884,21829,9276,256,9277,13404,21009]

theorem envBound15740 : H12AffineFastState.Bounded env15740 := by
  intro p hp
  have h : env15740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15739_15740 : H12AffineEnvironment.transform 20 12621 env15739 = env15740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12621 env15739 == env15740) = true)

theorem identity15740 : scanCanonicalize (H12AffineFastState.compose env15740 (packedSelected [11,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound15740 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env15741 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,28729,8202,4096,10281,1024,28728,12345,33,20480,20498,8192,64,10281,13340,13340,22544,21553,9276,116,9277,13404,21009]

theorem envBound15741 : H12AffineFastState.Bounded env15741 := by
  intro p hp
  have h : env15741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15740_15741 : H12AffineEnvironment.transform 7 116 env15740 = env15741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env15740 == env15741) = true)

theorem identity15741 : scanCanonicalize (H12AffineFastState.compose env15741 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound15741 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env15742 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,4112,8233,8202,4096,10281,1024,8232,12345,33,16,2,8192,64,10281,13340,13340,2048,1057,9276,116,9277,13404,513]

theorem envBound15742 : H12AffineFastState.Bounded env15742 := by
  intro p hp
  have h : env15742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15741_15742 : H12AffineEnvironment.transform 13 4112 env15741 = env15742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env15741 == env15742) = true)

theorem identity15742 : scanCanonicalize (H12AffineFastState.compose env15742 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 633) := by decide +kernel

theorem selectedBound15742 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15743 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,633,4112,592,627,4096,2640,1024,593,4672,33,16,2,633,64,2640,5733,5733,2048,1057,1605,116,1604,5669,513]

theorem envBound15743 : H12AffineFastState.Bounded env15743 := by
  intro p hp
  have h : env15743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15742_15743 : H12AffineEnvironment.transform 12 633 env15742 = env15743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 633 env15742 == env15743) = true)

theorem identity15743 : scanCanonicalize (H12AffineFastState.compose env15743 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 593) := by decide +kernel

theorem selectedBound15743 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env15744 : List Nat := [2,4,8,16,32,64,8,116,512,1024,593,4096,633,4112,592,627,4096,1,1024,593,4672,33,16,2,633,64,1,5733,5733,593,1057,1605,116,1604,5669,513]

theorem envBound15744 : H12AffineFastState.Bounded env15744 := by
  intro p hp
  have h : env15744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15743_15744 : H12AffineEnvironment.transform 10 593 env15743 = env15744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 593 env15743 == env15744) = true)

theorem identity15744 : scanCanonicalize (H12AffineFastState.compose env15744 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound15744 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15745 : List Nat := [2,4,8,16,32,64,8,116,81,1024,0,4096,40,4112,1,34,4096,1,1024,0,4113,33,16,2,40,64,1,5172,5172,0,1057,1044,116,1045,5236,80]

theorem envBound15745 : H12AffineFastState.Bounded env15745 := by
  intro p hp
  have h : env15745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15744_15745 : H12AffineEnvironment.transform 8 81 env15744 = env15745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env15744 == env15745) = true)

theorem identity15745 : scanCanonicalize (H12AffineFastState.compose env15745 (packedSelected [1,2,5] rootPS)) = affineNative (2^(11+1) ^^^ 1125) := by decide +kernel

theorem selectedBound15745 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env15746 : List Nat := [2,4,8,16,32,64,8,116,81,1024,0,1125,40,1141,1,34,1125,1,1024,0,1140,33,16,2,40,64,1,81,81,0,1057,1044,116,1045,17,80]

theorem envBound15746 : H12AffineFastState.Bounded env15746 := by
  intro p hp
  have h : env15746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15745_15746 : H12AffineEnvironment.transform 11 1125 env15745 = env15746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1125 env15745 == env15746) = true)

theorem identity15746 : scanCanonicalize (H12AffineFastState.compose env15746 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound15746 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env15747 : List Nat := [2,4,8,16,32,64,8,116,81,21,0,112,40,96,1,34,112,1,21,0,97,33,16,2,40,64,1,81,81,0,52,1,116,0,17,80]

theorem envBound15747 : H12AffineFastState.Bounded env15747 := by
  intro p hp
  have h : env15747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15746_15747 : H12AffineEnvironment.transform 9 21 env15746 = env15747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env15746 == env15747) = true)

theorem identity15747 : scanCanonicalize (H12AffineFastState.compose env15747 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15747 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15748 : List Nat := [2,4,8,0,32,64,8,100,65,5,0,96,40,96,1,34,96,1,5,0,97,33,0,2,40,64,1,65,65,0,36,1,100,0,1,64]

theorem envBound15748 : H12AffineFastState.Bounded env15748 := by
  intro p hp
  have h : env15748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15747_15748 : H12AffineEnvironment.transform 3 0 env15747 = env15748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15747 == env15748) = true)

theorem identity15748 : scanCanonicalize (H12AffineFastState.compose env15748 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound15748 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15749 : List Nat := [2,4,8,0,32,0,8,36,1,5,0,32,40,32,1,34,32,1,5,0,33,33,0,2,40,0,1,1,1,0,36,1,36,0,1,0]

theorem envBound15749 : H12AffineFastState.Bounded env15749 := by
  intro p hp
  have h : env15749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15748_15749 : H12AffineEnvironment.transform 5 0 env15748 = env15749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env15748 == env15749) = true)

theorem identity15749 : scanCanonicalize (H12AffineFastState.compose env15749 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15749 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15750 : List Nat := [2,4,8,0,0,0,8,4,1,5,0,0,8,0,1,2,0,1,5,0,1,1,0,2,8,0,1,1,1,0,4,1,4,0,1,0]

theorem envBound15750 : H12AffineFastState.Bounded env15750 := by
  intro p hp
  have h : env15750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15749_15750 : H12AffineEnvironment.transform 4 0 env15749 = env15750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15749 == env15750) = true)

def env15751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound15751 : H12AffineFastState.Bounded env15751 := by
  intro p hp
  have h : env15751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15682_15751 : H12AffineEnvironment.transform 18 1025 env15682 = env15751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env15682 == env15751) = true)

theorem identity15751 : scanCanonicalize (H12AffineFastState.compose env15751 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 213317) := by decide +kernel

theorem selectedBound15751 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env15752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,213317,8328,64,12878148,2278856,10507601,8830977,8570197,6431877,257,10651113,10642508,8643202]

theorem envBound15752 : H12AffineFastState.Bounded env15752 := by
  intro p hp
  have h : env15752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15751_15752 : H12AffineEnvironment.transform 23 213317 env15751 = env15752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 213317 env15751 == env15752) = true)

def env15753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281672,213317,8328,64,6705548,2278856,165273,2363593,2102685,6431877,257,21793,46212,2175562]

theorem envBound15753 : H12AffineFastState.Bounded env15753 := by
  intro p hp
  have h : env15753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15752_15753 : H12AffineEnvironment.transform 22 2281672 env15752 = env15753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281672 env15752 == env15753) = true)

def env15754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6590740,2098512,17665,2363593,2102685,6349853,257,21793,46212,2175562]

theorem envBound15754 : H12AffineFastState.Bounded env15754 := by
  intro p hp
  have h : env15754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15753_15754 : H12AffineEnvironment.transform 16 49304 env15753 = env15754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env15753 == env15754) = true)

def env15755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2144660,2098512,17665,2363593,2102685,2411677,257,21793,46212,2175562]

theorem envBound15755 : H12AffineFastState.Bounded env15755 := by
  intro p hp
  have h : env15755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15754_15755 : H12AffineEnvironment.transform 21 272512 env15754 = env15755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env15754 == env15755) = true)

theorem identity15755 : scanCanonicalize (H12AffineFastState.compose env15755 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound15755 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,115871,272512,120015,98781,8328,64,97547,115151,17665,382038,119042,329730,257,21793,46212,63189]

theorem envBound15756 : H12AffineFastState.Bounded env15756 := by
  intro p hp
  have h : env15756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15755_15756 : H12AffineEnvironment.transform 20 115871 env15755 = env15756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env15755 == env15756) = true)

def env15757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10400,1025,32769,115871,32,120015,98781,8328,64,97547,115151,17665,130294,119042,73890,257,21793,46212,63189]

theorem envBound15757 : H12AffineFastState.Bounded env15757 := by
  intro p hp
  have h : env15757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15756_15757 : H12AffineEnvironment.transform 17 10400 env15756 = env15757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env15756 == env15757) = true)

theorem identity15757 : scanCanonicalize (H12AffineFastState.compose env15757 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound15757 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env15758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,16384,32768,65536,49304,2265,1025,32769,115871,32,120015,98781,241,64,89458,115151,17665,121999,119042,65755,257,21793,38141,54956]

theorem envBound15758 : H12AffineFastState.Bounded env15758 := by
  intro p hp
  have h : env15758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15757_15758 : H12AffineEnvironment.transform 12 121 env15757 = env15758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env15757 == env15758) = true)

theorem identity15758 : scanCanonicalize (H12AffineFastState.compose env15758 (packedSelected [1,2,5,6,8,9,14,16,17,18,19,20,22,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 21930) := by decide +kernel

theorem selectedBound15758 : packedSelected [1,2,5,6,8,9,14,16,17,18,19,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env15759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,16384,32768,21930,49304,2265,1025,32769,37173,32,33125,54391,241,64,2264,37989,17665,35109,33960,21873,257,21793,38141,54956]

theorem envBound15759 : H12AffineFastState.Bounded env15759 := by
  intro p hp
  have h : env15759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15758_15759 : H12AffineEnvironment.transform 15 21930 env15758 = env15759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21930 env15758 == env15759) = true)

theorem identity15759 : scanCanonicalize (H12AffineFastState.compose env15759 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15759 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env15760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,32768,21794,49168,2129,1025,32769,37173,32,33125,54391,121,64,2128,37989,17665,35109,33824,21873,257,21793,38005,54820]

theorem envBound15760 : H12AffineFastState.Bounded env15760 := by
  intro p hp
  have h : env15760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15759_15760 : H12AffineEnvironment.transform 6 8 env15759 = env15760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15759 == env15760) = true)

theorem identity15760 : scanCanonicalize (H12AffineFastState.compose env15760 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound15760 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15761 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,21621,21794,5221,2129,1025,21620,17728,32,21776,2,121,64,2128,16400,17665,23888,20565,21873,257,21793,16384,593]

theorem envBound15761 : H12AffineFastState.Bounded env15761 := by
  intro p hp
  have h : env15761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15760_15761 : H12AffineEnvironment.transform 14 21621 env15760 = env15761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env15760 == env15761) = true)

theorem identity15761 : scanCanonicalize (H12AffineFastState.compose env15761 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15761 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env15762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5376,373,34,5221,2129,1025,372,4160,32,16,2,121,64,2128,5392,4097,2128,1365,113,257,33,5376,593]

theorem envBound15762 : H12AffineFastState.Bounded env15762 := by
  intro p hp
  have h : env15762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15761_15762 : H12AffineEnvironment.transform 13 5376 env15761 = env15762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15761 == env15762) = true)

theorem identity15762 : scanCanonicalize (H12AffineFastState.compose env15762 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound15762 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env15763 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,121,5204,33,34,5221,2129,1025,32,4160,32,16,2,121,64,2128,5188,4097,2128,1025,113,85,33,5204,593]

theorem envBound15763 : H12AffineFastState.Bounded env15763 := by
  intro p hp
  have h : env15763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15762_15763 : H12AffineEnvironment.transform 7 84 env15762 = env15763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env15762 == env15763) = true)

theorem identity15763 : scanCanonicalize (H12AffineFastState.compose env15763 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15763 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15764 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,4096,40,5125,33,34,5172,2048,1025,32,4113,32,16,2,40,17,2049,5141,4097,2049,1025,32,4,33,5125,512]

theorem envBound15764 : H12AffineFastState.Bounded env15764 := by
  intro p hp
  have h : env15764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15763_15764 : H12AffineEnvironment.transform 5 17 env15763 = env15764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15763 == env15764) = true)

theorem identity15764 : scanCanonicalize (H12AffineFastState.compose env15764 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15764 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env15765 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8,5125,1,2,5140,2048,1025,0,4113,0,16,2,8,17,2049,5141,4097,2049,1025,0,4,1,5125,512]

theorem envBound15765 : H12AffineFastState.Bounded env15765 := by
  intro p hp
  have h : env15765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15764_15765 : H12AffineEnvironment.transform 4 0 env15764 = env15765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15764 == env15765) = true)

def env15766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10401,1025,32769,115871,33,120015,98781,8328,64,97547,115151,17665,130295,119042,73891,257,21793,46212,63189]

theorem envBound15766 : H12AffineFastState.Bounded env15766 := by
  intro p hp
  have h : env15766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15756_15766 : H12AffineEnvironment.transform 17 10401 env15756 = env15766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env15756 == env15766) = true)

theorem identity15766 : scanCanonicalize (H12AffineFastState.compose env15766 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound15766 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env15767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,38161,10401,1025,32769,102678,33,98630,98781,8328,64,75906,103494,4232,108926,99467,73891,257,168,46212,41820]

theorem envBound15767 : H12AffineFastState.Bounded env15767 := by
  intro p hp
  have h : env15767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15766_15767 : H12AffineEnvironment.transform 13 5513 env15766 = env15767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env15766 == env15767) = true)

theorem identity15767 : scanCanonicalize (H12AffineFastState.compose env15767 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound15767 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env15768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8660,65536,13509,10401,1025,8661,78018,33,73874,73737,8328,64,75906,79250,4232,67754,75103,73891,257,168,5456,648]

theorem envBound15768 : H12AffineFastState.Bounded env15768 := by
  intro p hp
  have h : env15768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15767_15768 : H12AffineEnvironment.transform 14 8660 env15767 = env15768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env15767 == env15768) = true)

theorem identity15768 : scanCanonicalize (H12AffineFastState.compose env15768 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15768 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15769 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,13388,10280,1025,8540,77899,33,73755,73737,8193,64,75787,79131,4097,67619,75103,73770,257,33,5456,513]

theorem envBound15769 : H12AffineFastState.Bounded env15769 := by
  intro p hp
  have h : env15769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15768_15769 : H12AffineEnvironment.transform 6 9 env15768 = env15769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15768 == env15769) = true)

theorem identity15769 : scanCanonicalize (H12AffineFastState.compose env15769 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound15769 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15770 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,81,65536,5440,2340,1025,80,69959,33,65815,65797,269,64,67847,70679,4097,67619,66643,65830,257,33,5456,513]

theorem envBound15770 : H12AffineFastState.Bounded env15770 := by
  intro p hp
  have h : env15770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15769_15770 : H12AffineEnvironment.transform 12 268 env15769 = env15770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env15769 == env15770) = true)

theorem identity15770 : scanCanonicalize (H12AffineFastState.compose env15770 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound15770 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env15771 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,81,263,5440,2340,1025,80,4160,33,16,2,269,64,2048,5392,4097,2340,1364,33,257,33,5456,513]

theorem envBound15771 : H12AffineFastState.Bounded env15771 := by
  intro p hp
  have h : env15771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15770_15771 : H12AffineEnvironment.transform 15 263 env15770 = env15771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env15770 == env15771) = true)

theorem identity15771 : scanCanonicalize (H12AffineFastState.compose env15771 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound15771 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env15772 : List Nat := [2,4,8,16,32,64,9,256,308,1024,2048,4096,268,5376,81,263,5440,2340,1025,80,4160,33,16,2,269,64,2048,5392,4097,2340,1364,33,257,33,5456,309]

theorem envBound15772 : H12AffineFastState.Bounded env15772 := by
  intro p hp
  have h : env15772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15771_15772 : H12AffineEnvironment.transform 8 308 env15771 = env15772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env15771 == env15772) = true)

theorem identity15772 : scanCanonicalize (H12AffineFastState.compose env15772 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15772 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15773 : List Nat := [2,4,8,16,32,64,9,5,49,1024,2048,4096,9,5125,81,2,5189,2081,1025,80,4160,33,16,2,8,64,2048,5141,4097,2081,1105,33,4,33,5205,48]

theorem envBound15773 : H12AffineFastState.Bounded env15773 := by
  intro p hp
  have h : env15773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15772_15773 : H12AffineEnvironment.transform 7 5 env15772 = env15773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15772 == env15773) = true)

theorem identity15773 : scanCanonicalize (H12AffineFastState.compose env15773 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound15773 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15774 : List Nat := [2,4,8,16,32,64,9,5,49,1024,2048,81,9,1108,81,2,1044,2081,1025,80,17,33,16,2,8,64,2048,1092,80,2081,1105,33,4,33,1028,48]

theorem envBound15774 : H12AffineFastState.Bounded env15774 := by
  intro p hp
  have h : env15774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15773_15774 : H12AffineEnvironment.transform 11 81 env15773 = env15774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env15773 == env15774) = true)

theorem identity15774 : scanCanonicalize (H12AffineFastState.compose env15774 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound15774 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15775 : List Nat := [2,4,8,16,32,48,9,5,49,1024,2048,33,9,1060,33,2,1044,2081,1025,32,17,33,16,2,8,48,2048,1076,32,2081,1057,33,4,33,1028,48]

theorem envBound15775 : H12AffineFastState.Bounded env15775 := by
  intro p hp
  have h : env15775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15774_15775 : H12AffineEnvironment.transform 5 48 env15774 = env15775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env15774 == env15775) = true)

theorem identity15775 : scanCanonicalize (H12AffineFastState.compose env15775 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound15775 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env15776 : List Nat := [2,4,8,16,32,48,9,5,49,1024,1076,33,9,1060,33,2,1044,1045,1025,32,17,33,16,2,8,48,1076,1076,32,1045,1057,33,4,33,1028,48]

theorem envBound15776 : H12AffineFastState.Bounded env15776 := by
  intro p hp
  have h : env15776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15775_15776 : H12AffineEnvironment.transform 10 1076 env15775 = env15776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env15775 == env15776) = true)

theorem identity15776 : scanCanonicalize (H12AffineFastState.compose env15776 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15776 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env15777 : List Nat := [2,4,8,16,1,17,9,5,16,1024,1045,0,9,1029,0,2,1044,1045,1025,1,17,0,16,2,8,17,1045,1045,1,1045,1024,0,4,0,1028,17]

theorem envBound15777 : H12AffineFastState.Bounded env15777 := by
  intro p hp
  have h : env15777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15776_15777 : H12AffineEnvironment.transform 4 1 env15776 = env15777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15776 == env15777) = true)

theorem identity15777 : scanCanonicalize (H12AffineFastState.compose env15777 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15777 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15778 : List Nat := [2,4,8,1,1,0,9,5,1,1024,1028,0,9,1029,0,2,1029,1028,1025,1,0,0,1,2,8,0,1028,1028,1,1028,1024,0,4,0,1028,0]

theorem envBound15778 : H12AffineFastState.Bounded env15778 := by
  intro p hp
  have h : env15778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15777_15778 : H12AffineEnvironment.transform 3 1 env15777 = env15778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15777 == env15778) = true)

theorem identity15778 : scanCanonicalize (H12AffineFastState.compose env15778 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound15778 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15779 : List Nat := [2,4,8,1,1,0,9,5,1,4,0,0,9,1,0,2,1,0,5,1,0,0,1,2,8,0,0,0,1,0,4,0,4,0,0,0]

theorem envBound15779 : H12AffineFastState.Bounded env15779 := by
  intro p hp
  have h : env15779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15778_15779 : H12AffineEnvironment.transform 9 4 env15778 = env15779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env15778 == env15779) = true)

def env15780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2144661,2098512,17665,2363593,2102685,2411676,257,21793,46212,2175562]

theorem envBound15780 : H12AffineFastState.Bounded env15780 := by
  intro p hp
  have h : env15780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15754_15780 : H12AffineEnvironment.transform 21 272513 env15754 = env15780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env15754 == env15780) = true)

theorem identity15780 : scanCanonicalize (H12AffineFastState.compose env15780 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound15780 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,49304,262144,1025,32769,2097152,272513,2101328,21763,8328,64,2144661,2098512,17665,2363593,2102685,2411676,257,21793,46212,2156180]

theorem envBound15781 : H12AffineFastState.Bounded env15781 := by
  intro p hp
  have h : env15781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15780_15781 : H12AffineEnvironment.transform 15 54494 env15780 = env15781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env15780 == env15781) = true)

def env15782 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49168,262144,1025,32769,2097152,272393,2101328,21763,8192,64,2144541,2098512,17665,2363457,2102549,2411540,257,21793,46092,2156060]

theorem envBound15782 : H12AffineFastState.Bounded env15782 := by
  intro p hp
  have h : env15782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15781_15782 : H12AffineEnvironment.transform 6 8 env15781 = env15782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15781 == env15782) = true)

theorem identity15782 : scanCanonicalize (H12AffineFastState.compose env15782 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 17509) := by decide +kernel

theorem selectedBound15782 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env15783 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49168,262144,1025,32769,17509,272393,21557,21763,8192,64,64888,16693,17665,283684,20848,297073,257,21793,46092,41593]

theorem envBound15783 : H12AffineFastState.Bounded env15783 := by
  intro p hp
  have h : env15783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15782_15783 : H12AffineEnvironment.transform 20 17509 env15782 = env15783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17509 env15782 == env15783) = true)

theorem identity15783 : scanCanonicalize (H12AffineFastState.compose env15783 (packedSelected [0,1,4,8,14,15,16,17,22,26,27,41] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound15783 : packedSelected [0,1,4,8,14,15,16,17,22,26,27,41] rootPS < 2^1333 := by decide +kernel

def env15784 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49168,43049,1025,32769,17509,32800,21557,21763,8192,64,64888,16693,17665,64525,20848,8280,257,21793,46092,41593]

theorem envBound15784 : H12AffineFastState.Bounded env15784 := by
  intro p hp
  have h : env15784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15783_15784 : H12AffineEnvironment.transform 17 43049 env15783 = env15784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env15783 == env15784) = true)

theorem identity15784 : scanCanonicalize (H12AffineFastState.compose env15784 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15784 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env15785 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,32768,54358,49168,43049,1025,32769,17509,32800,21557,21543,8192,64,64604,16401,17445,64525,20564,8280,37,21509,46092,41593]

theorem envBound15785 : H12AffineFastState.Bounded env15785 := by
  intro p hp
  have h : env15785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15784_15785 : H12AffineEnvironment.transform 7 36 env15784 = env15785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15784 == env15785) = true)

theorem identity15785 : scanCanonicalize (H12AffineFastState.compose env15785 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound15785 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env15786 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13404,32768,40970,46156,43049,1025,32769,12345,32800,8297,8315,8192,64,34816,13389,12409,34897,9224,8280,37,8281,46092,41593]

theorem envBound15786 : H12AffineFastState.Bounded env15786 := by
  intro p hp
  have h : env15786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15785_15786 : H12AffineEnvironment.transform 13 13404 env15785 = env15786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env15785 == env15786) = true)

theorem identity15786 : scanCanonicalize (H12AffineFastState.compose env15786 (packedSelected [1,2,3,4,5,6,8,9,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 6249) := by decide +kernel

theorem selectedBound15786 : packedSelected [1,2,3,4,5,6,8,9,11,17] rootPS < 2^1333 := by decide +kernel

def env15787 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,6249,3125,32768,39011,35877,36928,1025,32769,2128,32800,6144,6162,6249,64,34816,3108,2064,34897,7265,6193,37,6192,35941,39440]

theorem envBound15787 : H12AffineFastState.Bounded env15787 := by
  intro p hp
  have h : env15787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15786_15787 : H12AffineEnvironment.transform 12 6249 env15786 = env15787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6249 env15786 == env15787) = true)

theorem identity15787 : scanCanonicalize (H12AffineFastState.compose env15787 (packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound15787 : packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env15788 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,2064,121,3125,32768,32883,35877,34896,1025,32769,2128,32800,16,2,121,64,34816,3108,2064,34897,1137,33,37,32,35941,33280]

theorem envBound15788 : H12AffineFastState.Bounded env15788 := by
  intro p hp
  have h : env15788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15787_15788 : H12AffineEnvironment.transform 11 2064 env15787 = env15788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env15787 == env15788) = true)

theorem identity15788 : scanCanonicalize (H12AffineFastState.compose env15788 (packedSelected [1,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound15788 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env15789 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1124,1140,121,81,32768,32883,32833,33844,1025,32769,1076,32800,16,2,121,64,33892,64,1140,33845,1137,33,37,32,32769,33280]

theorem envBound15789 : H12AffineFastState.Bounded env15789 := by
  intro p hp
  have h : env15789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15788_15789 : H12AffineEnvironment.transform 10 1124 env15788 = env15789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env15788 == env15789) = true)

theorem identity15789 : scanCanonicalize (H12AffineFastState.compose env15789 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15789 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15790 : List Nat := [2,4,8,1,32,64,8,36,512,1024,1124,1125,104,64,32768,32866,32833,33829,1025,32769,1061,32800,1,2,104,64,33892,64,1125,33828,1120,33,37,32,32769,33280]

theorem envBound15790 : H12AffineFastState.Bounded env15790 := by
  intro p hp
  have h : env15790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15789_15790 : H12AffineEnvironment.transform 3 1 env15789 = env15790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15789 == env15790) = true)

theorem identity15790 : scanCanonicalize (H12AffineFastState.compose env15790 (packedSelected [3,5,6] rootPS)) = affineNative (2^(14+1) ^^^ 1125) := by decide +kernel

theorem selectedBound15790 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env15791 : List Nat := [2,4,8,1,32,64,8,36,512,1024,1124,1125,104,64,1125,1031,1060,64,1025,1124,1061,1093,1,2,104,64,1,64,1125,65,1120,33,37,32,1124,1637]

theorem envBound15791 : H12AffineFastState.Bounded env15791 := by
  intro p hp
  have h : env15791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15790_15791 : H12AffineEnvironment.transform 14 1125 env15790 = env15791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1125 env15790 == env15791) = true)

theorem identity15791 : scanCanonicalize (H12AffineFastState.compose env15791 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound15791 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env15792 : List Nat := [2,4,8,1,32,64,8,36,512,100,0,1,104,64,1,99,64,64,101,0,65,33,1,2,104,64,1,64,1,65,4,33,37,32,0,513]

theorem envBound15792 : H12AffineFastState.Bounded env15792 := by
  intro p hp
  have h : env15792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15791_15792 : H12AffineEnvironment.transform 9 100 env15791 = env15792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env15791 == env15792) = true)

def env15793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,262144,1025,32769,2097152,272392,2101328,21763,8193,64,2144540,2098512,17665,2363456,2102548,2411541,257,21793,46093,2156061]

theorem envBound15793 : H12AffineFastState.Bounded env15793 := by
  intro p hp
  have h : env15793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15781_15793 : H12AffineEnvironment.transform 6 9 env15781 = env15793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15781 == env15793) = true)

theorem identity15793 : scanCanonicalize (H12AffineFastState.compose env15793 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 36928) := by decide +kernel

theorem selectedBound15793 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env15794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,262144,1025,32769,36928,272392,32784,21763,8193,64,10588,38160,17665,294912,34132,285781,257,21793,46093,30301]

theorem envBound15794 : H12AffineFastState.Bounded env15794 := by
  intro p hp
  have h : env15794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15793_15794 : H12AffineEnvironment.transform 20 36928 env15793 = env15794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 36928 env15793 == env15794) = true)

theorem identity15794 : scanCanonicalize (H12AffineFastState.compose env15794 (packedSelected [0,1,3,5,8,9,10,22,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound15794 : packedSelected [0,1,3,5,8,9,10,22,26,27] rootPS < 2^1333 := by decide +kernel

def env15795 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,56437,1025,32769,36928,62589,32784,21763,8193,64,10588,38160,17665,23669,34132,32800,257,21793,46093,30301]

theorem envBound15795 : H12AffineFastState.Bounded env15795 := by
  intro p hp
  have h : env15795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15794_15795 : H12AffineEnvironment.transform 17 56437 env15794 = env15795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env15794 == env15795) = true)

theorem identity15795 : scanCanonicalize (H12AffineFastState.compose env15795 (packedSelected [4,8,9,10,12,14,15,16,28] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15795 : packedSelected [4,8,9,10,12,14,15,16,28] rootPS < 2^1333 := by decide +kernel

def env15796 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,54359,49169,56437,1025,32769,36928,54640,32784,21763,268,64,2129,38160,17665,23669,34132,32800,257,21793,38144,22352]

theorem envBound15796 : H12AffineFastState.Bounded env15796 := by
  intro p hp
  have h : env15796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15795_15796 : H12AffineEnvironment.transform 12 269 env15795 = env15796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15795 == env15796) = true)

theorem identity15796 : scanCanonicalize (H12AffineFastState.compose env15796 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound15796 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env15797 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21760,343,5393,2421,1025,21761,17728,112,21776,21763,268,64,2129,16400,17665,23669,20564,21792,257,21793,16384,22352]

theorem envBound15797 : H12AffineFastState.Bounded env15797 := by
  intro p hp
  have h : env15797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15796_15797 : H12AffineEnvironment.transform 14 21760 env15796 = env15797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env15796 == env15797) = true)

theorem identity15797 : scanCanonicalize (H12AffineFastState.compose env15797 (packedSelected [2,6,12,18] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound15797 : packedSelected [2,6,12,18] rootPS < 2^1333 := by decide +kernel

def env15798 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,269,16384,20836,343,4469,2421,101,20837,16676,112,20852,20839,268,64,2129,16400,16741,22545,20564,20804,257,20805,16384,21300]

theorem envBound15798 : H12AffineFastState.Bounded env15798 := by
  intro p hp
  have h : env15798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15797_15798 : H12AffineEnvironment.transform 9 100 env15797 = env15798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env15797 == env15798) = true)

theorem identity15798 : scanCanonicalize (H12AffineFastState.compose env15798 (packedSelected [1,3,4,5,8,9,15] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound15798 : packedSelected [1,3,4,5,8,9,15] rootPS < 2^1333 := by decide +kernel

def env15799 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,269,4405,81,343,4469,2421,101,80,4113,112,65,82,268,64,2129,4389,4176,2340,353,113,257,112,4405,513]

theorem envBound15799 : H12AffineFastState.Bounded env15799 := by
  intro p hp
  have h : env15799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15798_15799 : H12AffineEnvironment.transform 13 4405 env15798 = env15799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env15798 == env15799) = true)

theorem identity15799 : scanCanonicalize (H12AffineFastState.compose env15799 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15799 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15800 : List Nat := [2,4,8,16,32,64,9,256,1,100,2048,4096,269,4405,81,343,4469,2421,101,80,4113,112,65,82,268,64,2129,4389,4176,2340,353,113,257,112,4405,0]

theorem envBound15800 : H12AffineFastState.Bounded env15800 := by
  intro p hp
  have h : env15800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15799_15800 : H12AffineEnvironment.transform 8 1 env15799 = env15800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15799 == env15800) = true)

theorem identity15800 : scanCanonicalize (H12AffineFastState.compose env15800 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15800 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15801 : List Nat := [2,4,8,16,32,17,9,256,1,53,2048,4096,269,4405,0,262,4388,2340,52,1,4113,33,16,3,268,17,2048,4389,4097,2340,304,32,257,33,4405,0]

theorem envBound15801 : H12AffineFastState.Bounded env15801 := by
  intro p hp
  have h : env15801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15800_15801 : H12AffineEnvironment.transform 5 17 env15800 = env15801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15800 == env15801) = true)

theorem identity15801 : scanCanonicalize (H12AffineFastState.compose env15801 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15801 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15802 : List Nat := [2,4,8,1,32,0,9,256,1,36,2048,4096,269,4388,0,262,4388,2340,37,1,4096,33,1,3,268,0,2048,4389,4097,2340,289,32,257,33,4388,0]

theorem envBound15802 : H12AffineFastState.Bounded env15802 := by
  intro p hp
  have h : env15802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15801_15802 : H12AffineEnvironment.transform 3 1 env15801 = env15802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15801 == env15802) = true)

def env15803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6590741,2098513,17664,2363593,2102685,6349852,257,21793,46212,2175562]

theorem envBound15803 : H12AffineFastState.Bounded env15803 := by
  intro p hp
  have h : env15803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15753_15803 : H12AffineEnvironment.transform 16 49305 env15753 = env15803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env15753 == env15803) = true)

def env15804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2144661,2098513,17664,2363593,2102685,2411676,257,21793,46212,2175562]

theorem envBound15804 : H12AffineFastState.Bounded env15804 := by
  intro p hp
  have h : env15804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15803_15804 : H12AffineEnvironment.transform 21 272512 env15803 = env15804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env15803 == env15804) = true)

theorem identity15804 : scanCanonicalize (H12AffineFastState.compose env15804 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound15804 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,77899,272512,73754,98780,8328,64,100830,79130,17664,336002,75222,392407,257,21793,46212,513]

theorem envBound15805 : H12AffineFastState.Bounded env15805 := by
  intro p hp
  have h : env15805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15804_15805 : H12AffineEnvironment.transform 20 77899 env15804 = env15805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env15804 == env15805) = true)

def env15806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,77899,272392,73754,98644,8192,64,100694,79130,17664,335882,75102,392287,257,21793,46092,513]

theorem envBound15806 : H12AffineFastState.Bounded env15806 := by
  intro p hp
  have h : env15806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15805_15806 : H12AffineEnvironment.transform 6 8 env15805 = env15806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15805 == env15806) = true)

theorem identity15806 : scanCanonicalize (H12AffineFastState.compose env15806 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound15806 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15807 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,49169,262144,1025,32769,36928,272392,32785,8543,8192,64,10589,38161,17664,294913,34133,285780,257,21793,46092,513]

theorem envBound15807 : H12AffineFastState.Bounded env15807 := by
  intro p hp
  have h : env15807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15806_15807 : H12AffineEnvironment.transform 15 40971 env15806 = env15807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env15806 == env15807) = true)

theorem identity15807 : scanCanonicalize (H12AffineFastState.compose env15807 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 63544) := by decide +kernel

theorem selectedBound15807 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env15808 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,49169,63544,1025,32769,36928,53296,32785,8543,8192,64,10589,38161,17664,30777,34133,42092,257,21793,46092,513]

theorem envBound15808 : H12AffineFastState.Bounded env15808 := by
  intro p hp
  have h : env15808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15807_15808 : H12AffineEnvironment.transform 17 63544 env15807 = env15808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63544 env15807 == env15808) = true)

theorem identity15808 : scanCanonicalize (H12AffineFastState.compose env15808 (packedSelected [4,7,9,17,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound15808 : packedSelected [4,7,9,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env15809 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1345,9546,17744,32121,1025,1344,5377,21873,1360,8543,8192,64,10589,4176,17664,30777,20,8493,257,21793,12621,513]

theorem envBound15809 : H12AffineFastState.Bounded env15809 := by
  intro p hp
  have h : env15809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15808_15809 : H12AffineEnvironment.transform 14 1345 env15808 = env15809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env15808 == env15809) = true)

theorem identity15809 : scanCanonicalize (H12AffineFastState.compose env15809 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15809 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env15810 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,1076,9279,17445,31756,1025,1077,5236,21508,1061,8234,8192,64,10280,4176,17525,30777,20,8280,116,21588,12344,513]

theorem envBound15810 : H12AffineFastState.Bounded env15810 := by
  intro p hp
  have h : env15810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15809_15810 : H12AffineEnvironment.transform 7 117 env15809 = env15810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15809 == env15810) = true)

theorem identity15810 : scanCanonicalize (H12AffineFastState.compose env15810 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound15810 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env15811 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1053,16384,1076,34,17445,22545,1025,1077,5236,21508,1061,1079,1053,64,3125,4176,17525,23588,20,1093,116,21588,5157,513]

theorem envBound15811 : H12AffineFastState.Bounded env15811 := by
  intro p hp
  have h : env15811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15810_15811 : H12AffineEnvironment.transform 12 1053 env15810 = env15811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env15810 == env15811) = true)

theorem identity15811 : scanCanonicalize (H12AffineFastState.compose env15811 (packedSelected [0,1,2,3,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound15811 : packedSelected [0,1,2,3,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15812 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,121,16384,80,34,16449,22545,101,81,4112,20576,65,83,121,64,2129,4176,16401,22592,20,33,116,20528,4161,513]

theorem envBound15812 : H12AffineFastState.Bounded env15812 := by
  intro p hp
  have h : env15812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15811_15812 : H12AffineEnvironment.transform 9 100 env15811 = env15812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env15811 == env15812) = true)

theorem identity15812 : scanCanonicalize (H12AffineFastState.compose env15812 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15812 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15813 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,40,16384,1,34,16400,22545,52,0,4112,20529,16,2,40,17,2048,4097,16401,22545,20,33,37,20528,4112,513]

theorem envBound15813 : H12AffineFastState.Bounded env15813 := by
  intro p hp
  have h : env15813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15812_15813 : H12AffineEnvironment.transform 5 17 env15812 = env15813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15812 == env15813) = true)

theorem identity15813 : scanCanonicalize (H12AffineFastState.compose env15813 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound15813 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15814 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,40,4113,1,34,4097,2048,52,0,4112,32,16,2,40,17,2048,4097,4096,2048,20,33,37,33,4112,513]

theorem envBound15814 : H12AffineFastState.Bounded env15814 := by
  intro p hp
  have h : env15814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15813_15814 : H12AffineEnvironment.transform 13 4113 env15813 = env15814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env15813 == env15814) = true)

theorem identity15814 : scanCanonicalize (H12AffineFastState.compose env15814 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2080) := by decide +kernel

theorem selectedBound15814 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15815 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,2080,40,2097,1,34,2081,2048,52,0,2096,32,16,2,40,17,2048,2081,2080,2048,20,33,37,33,2096,513]

theorem envBound15815 : H12AffineFastState.Bounded env15815 := by
  intro p hp
  have h : env15815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15814_15815 : H12AffineEnvironment.transform 11 2080 env15814 = env15815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2080 env15814 == env15815) = true)

theorem identity15815 : scanCanonicalize (H12AffineFastState.compose env15815 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound15815 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15816 : List Nat := [2,4,8,16,32,17,8,36,512,53,512,544,40,561,1,34,545,512,52,0,560,32,16,2,40,17,512,545,544,512,20,33,37,33,560,513]

theorem envBound15816 : H12AffineFastState.Bounded env15816 := by
  intro p hp
  have h : env15816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15815_15816 : H12AffineEnvironment.transform 10 512 env15815 = env15816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env15815 == env15816) = true)

theorem identity15816 : scanCanonicalize (H12AffineFastState.compose env15816 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound15816 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15817 : List Nat := [2,4,8,16,32,17,8,36,48,53,48,16,40,1,1,34,17,48,52,0,0,32,16,2,40,17,48,17,16,48,20,33,37,33,0,49]

theorem envBound15817 : H12AffineFastState.Bounded env15817 := by
  intro p hp
  have h : env15817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15816_15817 : H12AffineEnvironment.transform 8 48 env15816 = env15817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env15816 == env15817) = true)

theorem identity15817 : scanCanonicalize (H12AffineFastState.compose env15817 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound15817 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15818 : List Nat := [2,4,8,16,16,17,8,20,0,5,0,16,24,1,1,18,17,0,4,0,0,16,16,2,24,17,0,17,16,0,20,17,21,17,0,1]

theorem envBound15818 : H12AffineFastState.Bounded env15818 := by
  intro p hp
  have h : env15818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15817_15818 : H12AffineEnvironment.transform 4 16 env15817 = env15818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env15817 == env15818) = true)

def env15819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,77899,272393,73754,98645,8193,64,100695,79130,17664,335883,75103,392286,257,21793,46093,513]

theorem envBound15819 : H12AffineFastState.Bounded env15819 := by
  intro p hp
  have h : env15819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15805_15819 : H12AffineEnvironment.transform 6 9 env15805 = env15819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15805 == env15819) = true)

theorem identity15819 : scanCanonicalize (H12AffineFastState.compose env15819 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound15819 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env15820 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1025,32769,77899,41340,73754,98645,8193,64,100695,79130,17664,108926,75103,95531,257,21793,46093,513]

theorem envBound15820 : H12AffineFastState.Bounded env15820 := by
  intro p hp
  have h : env15820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15819_15820 : H12AffineEnvironment.transform 17 35189 env15819 = env15820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env15819 == env15820) = true)

theorem identity15820 : scanCanonicalize (H12AffineFastState.compose env15820 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15820 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env15821 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38160,35189,1025,32769,77899,41340,73754,98645,8193,64,100695,79130,4096,108926,75103,73771,257,33,46093,513]

theorem envBound15821 : H12AffineFastState.Bounded env15821 := by
  intro p hp
  have h : env15821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15820_15821 : H12AffineEnvironment.transform 13 5376 env15820 = env15821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15820 == env15821) = true)

theorem identity15821 : scanCanonicalize (H12AffineFastState.compose env15821 (packedSelected [0,3,5,7,10,12,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound15821 : packedSelected [0,3,5,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env15822 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8282,38160,35189,1025,32769,4113,41340,64,41231,8193,64,43277,5440,4096,35108,1285,113,257,33,46093,513]

theorem envBound15822 : H12AffineFastState.Bounded env15822 := by
  intro p hp
  have h : env15822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15821_15822 : H12AffineEnvironment.transform 15 8282 env15821 = env15822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env15821 == env15822) = true)

theorem identity15822 : scanCanonicalize (H12AffineFastState.compose env15822 (packedSelected [0,7,16,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15822 : packedSelected [0,7,16,18,23] rootPS < 2^1333 := by decide +kernel

def env15823 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,8282,5393,2420,1025,0,4113,8573,64,8462,8193,64,10508,5440,4096,2341,1285,113,257,33,13324,513]

theorem envBound15823 : H12AffineFastState.Bounded env15823 := by
  intro p hp
  have h : env15823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15822_15823 : H12AffineEnvironment.transform 14 1 env15822 = env15823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15822 == env15823) = true)

theorem identity15823 : scanCanonicalize (H12AffineFastState.compose env15823 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15823 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15824 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,1,8203,5393,2341,1025,0,4113,8492,17,8462,8193,17,10508,5393,4096,2341,1285,32,257,33,13324,513]

theorem envBound15824 : H12AffineFastState.Bounded env15824 := by
  intro p hp
  have h : env15824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15823_15824 : H12AffineEnvironment.transform 5 17 env15823 = env15824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15823 == env15824) = true)

theorem identity15824 : scanCanonicalize (H12AffineFastState.compose env15824 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound15824 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env15825 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,552,5376,1,547,5393,2341,1025,0,4113,772,17,806,553,17,2852,5393,4096,2341,1285,32,257,33,5668,513]

theorem envBound15825 : H12AffineFastState.Bounded env15825 := by
  intro p hp
  have h : env15825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15824_15825 : H12AffineEnvironment.transform 12 552 env15824 = env15825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env15824 == env15825) = true)

theorem identity15825 : scanCanonicalize (H12AffineFastState.compose env15825 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound15825 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env15826 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,513,552,1793,1,547,1808,2341,1025,0,528,772,17,806,553,17,2852,1808,513,2341,1285,32,257,33,1061,513]

theorem envBound15826 : H12AffineFastState.Bounded env15826 := by
  intro p hp
  have h : env15826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15825_15826 : H12AffineEnvironment.transform 11 513 env15825 = env15826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env15825 == env15826) = true)

theorem identity15826 : scanCanonicalize (H12AffineFastState.compose env15826 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15826 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env15827 : List Nat := [2,4,8,1,32,0,9,256,512,1024,2048,513,552,1793,1,547,1793,2341,1025,0,513,772,0,806,553,0,2852,1793,513,2341,1285,32,257,33,1061,513]

theorem envBound15827 : H12AffineFastState.Bounded env15827 := by
  intro p hp
  have h : env15827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15826_15827 : H12AffineEnvironment.transform 3 1 env15826 = env15827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15826 == env15827) = true)

theorem identity15827 : scanCanonicalize (H12AffineFastState.compose env15827 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound15827 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env15828 : List Nat := [2,4,8,1,32,0,9,256,512,289,2048,513,552,544,1,547,544,2341,288,0,513,772,0,806,553,0,2852,544,513,2341,36,32,257,33,260,513]

theorem envBound15828 : H12AffineFastState.Bounded env15828 := by
  intro p hp
  have h : env15828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15827_15828 : H12AffineEnvironment.transform 9 289 env15827 = env15828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env15827 == env15828) = true)

theorem identity15828 : scanCanonicalize (H12AffineFastState.compose env15828 (packedSelected [0,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound15828 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env15829 : List Nat := [2,4,8,1,32,0,9,256,512,289,0,513,552,544,1,547,544,293,288,0,513,772,0,806,553,0,804,544,513,293,36,32,257,33,260,513]

theorem envBound15829 : H12AffineFastState.Bounded env15829 := by
  intro p hp
  have h : env15829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15828_15829 : H12AffineEnvironment.transform 10 0 env15828 = env15829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env15828 == env15829) = true)

theorem identity15829 : scanCanonicalize (H12AffineFastState.compose env15829 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound15829 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15830 : List Nat := [2,4,8,1,32,0,9,256,292,289,0,293,268,260,1,263,260,293,288,0,293,32,0,2,269,0,0,260,293,293,36,32,257,33,260,293]

theorem envBound15830 : H12AffineFastState.Bounded env15830 := by
  intro p hp
  have h : env15830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15829_15830 : H12AffineEnvironment.transform 8 292 env15829 = env15830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env15829 == env15830) = true)

theorem identity15830 : scanCanonicalize (H12AffineFastState.compose env15830 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15830 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15831 : List Nat := [2,4,8,1,32,0,9,5,33,36,0,32,9,1,1,2,1,32,37,0,32,32,0,2,8,0,0,1,32,32,36,32,4,33,1,32]

theorem envBound15831 : H12AffineFastState.Bounded env15831 := by
  intro p hp
  have h : env15831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15830_15831 : H12AffineEnvironment.transform 7 5 env15830 = env15831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15830 == env15831) = true)

def env15832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2144660,2098513,17664,2363593,2102685,2411677,257,21793,46212,2175562]

theorem envBound15832 : H12AffineFastState.Bounded env15832 := by
  intro p hp
  have h : env15832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15803_15832 : H12AffineEnvironment.transform 21 272513 env15803 = env15832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env15803 == env15832) = true)

theorem identity15832 : scanCanonicalize (H12AffineFastState.compose env15832 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15832 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49305,262144,1025,32769,2097152,272513,2101329,41431,8328,64,2144660,2098513,17664,2363593,2102685,2411677,257,21793,46212,2101825]

theorem envBound15833 : H12AffineFastState.Bounded env15833 := by
  intro p hp
  have h : env15833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15832_15833 : H12AffineEnvironment.transform 15 8203 env15832 = env15833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15832 == env15833) = true)

theorem identity15833 : scanCanonicalize (H12AffineFastState.compose env15833 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15833 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env15834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,25028,262144,1025,8540,2097152,272513,2101329,138,8328,64,2103497,2098513,17664,2363593,2102685,2387392,257,21793,5593,2101825]

theorem envBound15834 : H12AffineFastState.Bounded env15834 := by
  intro p hp
  have h : env15834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15833_15834 : H12AffineEnvironment.transform 14 8541 env15833 = env15834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15833 == env15834) = true)

theorem identity15834 : scanCanonicalize (H12AffineFastState.compose env15834 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15834 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env15835 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,24909,262144,1025,8540,2097152,272392,2101329,3,8193,64,2103360,2098513,17664,2363456,2102548,2387273,257,21793,5456,2101825]

theorem envBound15835 : H12AffineFastState.Bounded env15835 := by
  intro p hp
  have h : env15835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15834_15835 : H12AffineEnvironment.transform 6 9 env15834 = env15835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15834 == env15835) = true)

theorem identity15835 : scanCanonicalize (H12AffineFastState.compose env15835 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound15835 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env15836 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,24909,2048,1025,8540,2097152,8200,2101329,3,8193,64,2103360,2098513,17664,2103360,2102548,2123081,257,21793,5456,2101825]

theorem envBound15836 : H12AffineFastState.Bounded env15836 := by
  intro p hp
  have h : env15836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15835_15836 : H12AffineEnvironment.transform 17 2048 env15835 = env15836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env15835 == env15836) = true)

theorem identity15836 : scanCanonicalize (H12AffineFastState.compose env15836 (packedSelected [0,1,3,5,7,8,9,14,17,18,20,22,23] rootPS)) = affineNative (2^(20+1) ^^^ 28008) := by decide +kernel

theorem selectedBound15836 : packedSelected [0,1,3,5,7,8,9,14,17,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env15837 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,24909,2048,1025,8540,28008,8200,32057,3,8193,64,29992,26681,17664,29992,30844,2081,257,21793,5456,32553]

theorem envBound15837 : H12AffineFastState.Bounded env15837 := by
  intro p hp
  have h : env15837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15836_15837 : H12AffineEnvironment.transform 20 28008 env15836 = env15837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 28008 env15836 == env15837) = true)

theorem identity15837 : scanCanonicalize (H12AffineFastState.compose env15837 (packedSelected [1,4,5,6,8,14,17,20,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound15837 : packedSelected [1,4,5,6,8,14,17,20,22,24] rootPS < 2^1333 := by decide +kernel

def env15838 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,373,35,16741,2048,1025,372,19776,32,23825,3,41,64,21760,18449,17664,21760,22612,2081,257,21793,5456,24321]

theorem envBound15838 : H12AffineFastState.Bounded env15838 := by
  intro p hp
  have h : env15838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15837_15838 : H12AffineEnvironment.transform 12 40 env15837 = env15838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env15837 == env15838) = true)

theorem identity15838 : scanCanonicalize (H12AffineFastState.compose env15838 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 7424) := by decide +kernel

theorem selectedBound15838 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15839 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,7424,373,35,7269,2048,1025,372,4160,32,17,3,41,64,2048,5393,6144,2048,1364,2081,257,2081,5456,513]

theorem envBound15839 : H12AffineFastState.Bounded env15839 := by
  intro p hp
  have h : env15839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15838_15839 : H12AffineEnvironment.transform 13 7424 env15838 = env15839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7424 env15838 == env15839) = true)

theorem identity15839 : scanCanonicalize (H12AffineFastState.compose env15839 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15839 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env15840 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,7285,0,35,7269,2048,1025,1,4160,32,17,3,41,64,2048,5220,6144,2048,1057,2081,116,2081,5157,513]

theorem envBound15840 : H12AffineFastState.Bounded env15840 := by
  intro p hp
  have h : env15840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15839_15840 : H12AffineEnvironment.transform 7 117 env15839 = env15840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15839 == env15840) = true)

theorem identity15840 : scanCanonicalize (H12AffineFastState.compose env15840 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 111) := by decide +kernel

theorem selectedBound15840 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15841 : List Nat := [2,4,8,16,32,64,9,117,512,111,2048,4096,40,6170,0,35,6154,2048,110,1,4160,32,17,3,41,64,2048,4107,6144,2048,78,2081,116,2081,4170,513]

theorem envBound15841 : H12AffineFastState.Bounded env15841 := by
  intro p hp
  have h : env15841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15840_15841 : H12AffineEnvironment.transform 9 111 env15840 = env15841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 111 env15840 == env15841) = true)

theorem identity15841 : scanCanonicalize (H12AffineFastState.compose env15841 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound15841 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15842 : List Nat := [2,4,8,16,32,58,9,15,512,21,2048,4096,40,6170,0,35,6154,2048,20,1,4154,32,17,3,41,58,2048,4107,6144,2048,52,2081,14,2081,4144,513]

theorem envBound15842 : H12AffineFastState.Bounded env15842 := by
  intro p hp
  have h : env15842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15841_15842 : H12AffineEnvironment.transform 5 58 env15841 = env15842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env15841 == env15842) = true)

theorem identity15842 : scanCanonicalize (H12AffineFastState.compose env15842 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound15842 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15843 : List Nat := [2,4,8,16,32,58,9,15,512,21,1,4096,40,4123,0,35,4107,1,20,1,4154,32,17,3,41,58,1,4107,4097,1,52,32,14,32,4144,513]

theorem envBound15843 : H12AffineFastState.Bounded env15843 := by
  intro p hp
  have h : env15843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15842_15843 : H12AffineEnvironment.transform 10 1 env15842 = env15843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env15842 == env15843) = true)

theorem identity15843 : scanCanonicalize (H12AffineFastState.compose env15843 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 10) := by decide +kernel

theorem selectedBound15843 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15844 : List Nat := [2,4,8,16,32,58,9,15,512,21,1,10,40,17,0,35,1,1,20,1,48,32,17,3,41,58,1,1,11,1,52,32,14,32,58,513]

theorem envBound15844 : H12AffineFastState.Bounded env15844 := by
  intro p hp
  have h : env15844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15843_15844 : H12AffineEnvironment.transform 11 10 env15843 = env15844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 10 env15843 == env15844) = true)

def env15845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281673,213317,8328,64,6705549,2278856,165272,2363592,2102684,6431877,257,21792,46213,2175563]

theorem envBound15845 : H12AffineFastState.Bounded env15845 := by
  intro p hp
  have h : env15845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15752_15845 : H12AffineEnvironment.transform 22 2281673 env15752 = env15845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281673 env15752 == env15845) = true)

def env15846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6590741,2098512,17664,2363592,2102684,6349853,257,21792,46213,2175563]

theorem envBound15846 : H12AffineFastState.Bounded env15846 := by
  intro p hp
  have h : env15846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15845_15846 : H12AffineEnvironment.transform 16 49304 env15845 = env15846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env15845 == env15846) = true)

def env15847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2144661,2098512,17664,2363592,2102684,2411677,257,21792,46213,2175563]

theorem envBound15847 : H12AffineFastState.Bounded env15847 := by
  intro p hp
  have h : env15847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15846_15847 : H12AffineEnvironment.transform 21 272512 env15846 = env15847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env15846 == env15847) = true)

theorem identity15847 : scanCanonicalize (H12AffineFastState.compose env15847 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound15847 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13389,262144,1025,29908,2097152,272512,2101329,95496,8328,64,2116928,2098512,17664,2363592,2102684,2373704,257,21792,16464,2175563]

theorem envBound15848 : H12AffineFastState.Bounded env15848 := by
  intro p hp
  have h : env15848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15847_15848 : H12AffineEnvironment.transform 14 29909 env15847 = env15848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env15847 == env15848) = true)

def env15849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21541,65536,5309,262144,1025,21540,2097152,264304,2101329,87544,120,64,2116928,2098512,17664,2363592,2102684,2365624,257,21792,16464,2167483]

theorem envBound15849 : H12AffineFastState.Bounded env15849 := by
  intro p hp
  have h : env15849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15848_15849 : H12AffineEnvironment.transform 12 240 env15848 = env15849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env15848 == env15849) = true)

theorem identity15849 : scanCanonicalize (H12AffineFastState.compose env15849 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound15849 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env15850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21541,65536,5309,2557,1025,21540,2097152,397,2101329,87544,120,64,2116928,2098512,17664,2103605,2102684,2101573,257,21792,16464,2167483]

theorem envBound15850 : H12AffineFastState.Bounded env15850 := by
  intro p hp
  have h : env15850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15849_15850 : H12AffineEnvironment.transform 17 2557 env15849 = env15850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env15849 == env15850) = true)

theorem identity15850 : scanCanonicalize (H12AffineFastState.compose env15850 (packedSelected [3,4,7,9,10,14,17,24,26,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 4589) := by decide +kernel

theorem selectedBound15850 : packedSelected [3,4,7,9,10,14,17,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env15851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21541,65536,5309,2557,1025,21540,4589,397,444,87544,120,64,23725,5309,17664,2264,1137,168,257,21792,16464,66390]

theorem envBound15851 : H12AffineFastState.Bounded env15851 := by
  intro p hp
  have h : env15851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15850_15851 : H12AffineEnvironment.transform 20 4589 env15850 = env15851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4589 env15850 == env15851) = true)

theorem identity15851 : scanCanonicalize (H12AffineFastState.compose env15851 (packedSelected [1,5,8,16,19,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21874) := by decide +kernel

theorem selectedBound15851 : packedSelected [1,5,8,16,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env15852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21541,21874,5309,2557,1025,21540,4589,397,444,138,120,64,23725,5309,17664,2264,1137,168,257,21792,16464,22052]

theorem envBound15852 : H12AffineFastState.Bounded env15852 := by
  intro p hp
  have h : env15852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15851_15852 : H12AffineEnvironment.transform 15 21874 env15851 = env15852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21874 env15851 == env15852) = true)

theorem identity15852 : scanCanonicalize (H12AffineFastState.compose env15852 (packedSelected [1,8,12,15,16,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound15852 : packedSelected [1,8,12,15,16,19,20] rootPS < 2^1333 := by decide +kernel

def env15853 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,240,16384,21541,21647,5309,2048,1025,21540,4112,112,65,138,120,64,23725,5309,17661,2264,1137,168,252,21725,16464,22052]

theorem envBound15853 : H12AffineFastState.Bounded env15853 := by
  intro p hp
  have h : env15853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15852_15853 : H12AffineEnvironment.transform 7 253 env15852 = env15853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env15852 == env15853) = true)

theorem identity15853 : scanCanonicalize (H12AffineFastState.compose env15853 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound15853 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env15854 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,240,5157,0,170,5309,2048,1025,1,4112,112,65,138,120,64,2184,5309,4312,2264,1137,168,252,248,5237,513]

theorem envBound15854 : H12AffineFastState.Bounded env15854 := by
  intro p hp
  have h : env15854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15853_15854 : H12AffineEnvironment.transform 13 5157 env15853 = env15854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env15853 == env15854) = true)

theorem identity15854 : scanCanonicalize (H12AffineFastState.compose env15854 (packedSelected [1,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound15854 : packedSelected [1,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env15855 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,2112,240,3173,0,170,3325,2048,1025,1,2128,112,65,138,120,64,2184,3325,2200,2264,1137,168,252,248,3125,513]

theorem envBound15855 : H12AffineFastState.Bounded env15855 := by
  intro p hp
  have h : env15855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15854_15855 : H12AffineEnvironment.transform 11 2112 env15854 = env15855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env15854 == env15855) = true)

theorem identity15855 : scanCanonicalize (H12AffineFastState.compose env15855 (packedSelected [1,2,6,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15855 : packedSelected [1,2,6,8,10] rootPS < 2^1333 := by decide +kernel

def env15856 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2064,160,3125,0,170,3245,2048,1025,1,2048,32,17,138,40,16,2184,3245,2200,2184,1057,168,172,168,3125,513]

theorem envBound15856 : H12AffineFastState.Bounded env15856 := by
  intro p hp
  have h : env15856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15855_15856 : H12AffineEnvironment.transform 5 16 env15855 = env15856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15855 == env15856) = true)

def env15857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21540,65536,5308,262144,1025,21541,2097152,264305,2101329,87545,121,64,2116928,2098512,17664,2363592,2102684,2365625,257,21792,16464,2167482]

theorem envBound15857 : H12AffineFastState.Bounded env15857 := by
  intro p hp
  have h : env15857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15848_15857 : H12AffineEnvironment.transform 12 241 env15848 = env15857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env15848 == env15857) = true)

theorem identity15857 : scanCanonicalize (H12AffineFastState.compose env15857 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound15857 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env15858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21540,65536,5308,2420,1025,21541,2097152,261,2101329,87545,121,64,2116928,2098512,17664,2103740,2102684,2101709,257,21792,16464,2167482]

theorem envBound15858 : H12AffineFastState.Bounded env15858 := by
  intro p hp
  have h : env15858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15857_15858 : H12AffineEnvironment.transform 17 2420 env15857 = env15858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env15857 == env15858) = true)

theorem identity15858 : scanCanonicalize (H12AffineFastState.compose env15858 (packedSelected [0,1,2,6,7,8,10,11,12,15,16,17,23,26,31] rootPS)) = affineNative (2^(20+1) ^^^ 82967) := by decide +kernel

theorem selectedBound15858 : packedSelected [0,1,2,6,7,8,10,11,12,15,16,17,23,26,31] rootPS < 2^1333 := by decide +kernel

def env15859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21540,65536,5308,2420,1025,21541,82967,261,87110,87545,121,64,67927,82247,17664,89515,86411,87514,257,21792,16464,22189]

end H12CloudChart1