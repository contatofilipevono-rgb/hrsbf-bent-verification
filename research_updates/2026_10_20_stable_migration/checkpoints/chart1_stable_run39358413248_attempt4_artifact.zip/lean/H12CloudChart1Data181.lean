import H12CloudChart1Data180

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem leafIdentity45873 : H12AffineFastState.composeSystem env45873 rootObs = leafEnv45873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45873 rootObs == leafEnv45873) = true)

theorem terminalChecked45873 : H12PackedTerminal.terminalCheckFast leafEnv45873 active45873 tree45873 = true := by decide +kernel

def env45874 : List Nat := [2,4,8,16,0,16,9,5,512,21,528,16,8,0,1,2,17,528,21,0,1,1,17,3,9,17,528,16,17,528,21,1,5,0,0,513]

theorem envBound45874 : H12AffineFastState.Bounded env45874 := by
  intro p hp
  have h : env45874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45871_45874 : H12AffineEnvironment.transform 9 21 env45871 = env45874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env45871 == env45874) = true)

theorem identity45874 : scanCanonicalize (H12AffineFastState.compose env45874 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound45874 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45875 : List Nat := [2,4,8,16,0,16,9,5,17,21,1,16,8,0,1,2,17,1,21,0,1,1,17,3,9,17,1,16,17,1,21,1,5,0,0,16]

theorem envBound45875 : H12AffineFastState.Bounded env45875 := by
  intro p hp
  have h : env45875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45874_45875 : H12AffineEnvironment.transform 8 17 env45874 = env45875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env45874 == env45875) = true)

def leafEnv45875 : List Nat := [2,4,8,16,0,16,9,5,17,21,1,16,8,0,1,2,17,1,21,0,1,1,17,3,21,9,1,17,1,16,17,1,21,1,5,0,4,3,0,16,1,1,0]

def active45875 : List Nat := [0,1,2,3]

def tree45875 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45875 : H12WitnessSearch.Good tree45875 := H12GlobalWitnessIndex.good

theorem leafIdentity45875 : H12AffineFastState.composeSystem env45875 rootObs = leafEnv45875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45875 rootObs == leafEnv45875) = true)

theorem terminalChecked45875 : H12PackedTerminal.terminalCheckFast leafEnv45875 active45875 tree45875 = true := by decide +kernel

def env45876 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,17,8,1044,1,2,1029,2048,1024,0,0,1,17,3,9,17,2048,1028,16,2048,1024,1,5,0,1044,513]

theorem envBound45876 : H12AffineFastState.Bounded env45876 := by
  intro p hp
  have h : env45876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45869_45876 : H12AffineEnvironment.transform 11 17 env45869 = env45876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env45869 == env45876) = true)

theorem identity45876 : scanCanonicalize (H12AffineFastState.compose env45876 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound45876 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45877 : List Nat := [2,4,8,16,0,16,9,5,512,1024,528,17,8,1044,1,2,1029,528,1024,0,0,1,17,3,9,17,528,1028,16,528,1024,1,5,0,1044,513]

theorem envBound45877 : H12AffineFastState.Bounded env45877 := by
  intro p hp
  have h : env45877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45876_45877 : H12AffineEnvironment.transform 10 528 env45876 = env45877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env45876 == env45877) = true)

def env45878 : List Nat := [2,4,8,16,0,16,9,5,512,20,528,17,8,0,1,2,17,528,20,0,0,1,17,3,9,17,528,16,16,528,20,1,5,0,0,513]

theorem envBound45878 : H12AffineFastState.Bounded env45878 := by
  intro p hp
  have h : env45878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45877_45878 : H12AffineEnvironment.transform 9 20 env45877 = env45878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45877 == env45878) = true)

theorem identity45878 : scanCanonicalize (H12AffineFastState.compose env45878 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45878 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45879 : List Nat := [2,4,8,11,0,11,9,5,512,15,523,10,8,0,1,2,10,523,15,0,0,1,10,3,9,10,523,11,11,523,15,1,5,0,0,513]

theorem envBound45879 : H12AffineFastState.Bounded env45879 := by
  intro p hp
  have h : env45879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45878_45879 : H12AffineEnvironment.transform 3 11 env45878 = env45879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45878 == env45879) = true)

def leafEnv45879 : List Nat := [2,4,8,11,0,11,9,5,512,15,523,10,8,0,1,2,10,523,15,0,0,1,10,3,15,9,1,10,523,11,11,523,15,1,5,0,4,3,0,513,1,0,0]

def active45879 : List Nat := [0,1,2,8]

def tree45879 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45879 : H12WitnessSearch.Good tree45879 := H12GlobalWitnessIndex.good

theorem leafIdentity45879 : H12AffineFastState.composeSystem env45879 rootObs = leafEnv45879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45879 rootObs == leafEnv45879) = true)

theorem terminalChecked45879 : H12PackedTerminal.terminalCheckFast leafEnv45879 active45879 tree45879 = true := by decide +kernel

def env45880 : List Nat := [2,4,8,16,0,16,9,5,512,21,528,17,8,1,1,2,16,528,21,0,0,1,17,3,9,17,528,17,16,528,21,1,5,0,1,513]

theorem envBound45880 : H12AffineFastState.Bounded env45880 := by
  intro p hp
  have h : env45880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45877_45880 : H12AffineEnvironment.transform 9 21 env45877 = env45880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env45877 == env45880) = true)

theorem identity45880 : scanCanonicalize (H12AffineFastState.compose env45880 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound45880 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45881 : List Nat := [2,4,8,16,0,16,9,5,16,21,0,17,8,1,1,2,16,0,21,0,0,1,17,3,9,17,0,17,16,0,21,1,5,0,1,17]

theorem envBound45881 : H12AffineFastState.Bounded env45881 := by
  intro p hp
  have h : env45881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45880_45881 : H12AffineEnvironment.transform 8 16 env45880 = env45881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env45880 == env45881) = true)

def leafEnv45881 : List Nat := [2,4,8,16,0,16,9,5,16,21,0,17,8,1,1,2,16,0,21,0,0,1,17,3,21,9,1,17,0,17,16,0,21,1,5,0,4,3,1,17,1,0,0]

def active45881 : List Nat := [0,1,2,3]

def tree45881 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45881 : H12WitnessSearch.Good tree45881 := H12GlobalWitnessIndex.good

theorem leafIdentity45881 : H12AffineFastState.composeSystem env45881 rootObs = leafEnv45881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45881 rootObs == leafEnv45881) = true)

theorem terminalChecked45881 : H12PackedTerminal.terminalCheckFast leafEnv45881 active45881 tree45881 = true := by decide +kernel

def env45882 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247962,1024,32769,77899,253978,73755,95497,8328,65,245139,115151,17665,10368,119043,180377,256,41428,16464,63188]

theorem envBound45882 : H12AffineFastState.Bounded env45882 := by
  intro p hp
  have h : env45882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45860_45882 : H12AffineEnvironment.transform 4 1 env45860 = env45882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45860 == env45882) = true)

theorem identity45882 : scanCanonicalize (H12AffineFastState.compose env45882 (packedSelected [0,2,3,4,6,7,11,14,15,22,24,26,31,32,35,38] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45882 : packedSelected [0,2,3,4,6,7,11,14,15,22,24,26,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env45883 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,349,16384,32768,65536,131072,247962,1024,32769,69910,246087,65862,87124,469,65,236750,115151,17665,2525,119043,180377,256,32905,16464,55177]

theorem envBound45883 : H12AffineFastState.Bounded env45883 := by
  intro p hp
  have h : env45883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45882_45883 : H12AffineEnvironment.transform 12 349 env45882 = env45883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45882 == env45883) = true)

theorem identity45883 : scanCanonicalize (H12AffineFastState.compose env45883 (packedSelected [0,3,9,11,12,16,17,20,22,24,26,27,31,32,41] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound45883 : packedSelected [0,3,9,11,12,16,17,20,22,24,26,27,31,32,41] rootPS < 2^1333 := by decide +kernel

def env45884 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,349,5376,32768,65536,131072,236954,1024,32769,69910,234567,65862,65876,469,65,236750,103631,4097,2525,99331,169369,256,32905,5456,33417]

theorem envBound45884 : H12AffineFastState.Bounded env45884 := by
  intro p hp
  have h : env45884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45883_45884 : H12AffineEnvironment.transform 13 5376 env45883 = env45884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45883 == env45884) = true)

theorem identity45884 : scanCanonicalize (H12AffineFastState.compose env45884 (packedSelected [0,1,4,7,17,19,22,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound45884 : packedSelected [0,1,4,7,17,19,22,28,31] rootPS < 2^1333 := by decide +kernel

def env45885 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,349,5376,32768,33247,131072,138309,1024,32769,37065,136600,32921,32907,469,65,138513,5392,4097,2525,1500,169369,256,32905,5456,33417]

theorem envBound45885 : H12AffineFastState.Bounded env45885 := by
  intro p hp
  have h : env45885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45884_45885 : H12AffineEnvironment.transform 15 33247 env45884 = env45885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env45884 == env45885) = true)

theorem identity45885 : scanCanonicalize (H12AffineFastState.compose env45885 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound45885 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45886 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,349,5376,136,343,131072,138309,1024,137,4161,136600,17,3,469,65,138513,5392,4097,2525,1500,136465,256,1,5456,513]

theorem envBound45886 : H12AffineFastState.Bounded env45886 := by
  intro p hp
  have h : env45886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45885_45886 : H12AffineEnvironment.transform 14 136 env45885 = env45886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env45885 == env45886) = true)

theorem identity45886 : scanCanonicalize (H12AffineFastState.compose env45886 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound45886 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env45887 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,349,5376,136,343,5393,2388,1024,137,4161,137,17,3,469,65,2048,5392,4097,2525,1500,0,256,1,5456,513]

theorem envBound45887 : H12AffineFastState.Bounded env45887 := by
  intro p hp
  have h : env45887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45886_45887 : H12AffineEnvironment.transform 16 5393 env45886 = env45887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env45886 == env45887) = true)

theorem identity45887 : scanCanonicalize (H12AffineFastState.compose env45887 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45887 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45888 : List Nat := [2,4,8,16,1,16,128,256,512,1024,2048,4096,269,5376,136,263,5393,2308,1024,137,4113,137,17,3,389,17,2048,5392,4097,2445,1420,0,256,1,5376,513]

theorem envBound45888 : H12AffineFastState.Bounded env45888 := by
  intro p hp
  have h : env45888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45887_45888 : H12AffineEnvironment.transform 5 16 env45887 = env45888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45887 == env45888) = true)

theorem identity45888 : scanCanonicalize (H12AffineFastState.compose env45888 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound45888 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env45889 : List Nat := [2,4,8,16,1,16,128,141,512,1024,2048,4096,128,5261,136,138,5276,2185,1024,137,4113,137,17,3,8,17,2048,5277,4097,2048,1025,0,141,1,5261,513]

theorem envBound45889 : H12AffineFastState.Bounded env45889 := by
  intro p hp
  have h : env45889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45888_45889 : H12AffineEnvironment.transform 7 141 env45888 = env45889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env45888 == env45889) = true)

theorem identity45889 : scanCanonicalize (H12AffineFastState.compose env45889 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45889 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env45890 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5124,1,3,5141,2048,1024,0,4113,0,17,3,8,17,2048,5140,4097,2048,1025,0,4,1,5124,513]

theorem envBound45890 : H12AffineFastState.Bounded env45890 := by
  intro p hp
  have h : env45890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45889_45890 : H12AffineEnvironment.transform 6 9 env45889 = env45890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45889 == env45890) = true)

def env45891 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,9,1044,1,3,1029,2048,1024,0,1,0,17,3,8,17,2048,1028,17,2048,1025,0,4,1,1044,513]

theorem envBound45891 : H12AffineFastState.Bounded env45891 := by
  intro p hp
  have h : env45891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45890_45891 : H12AffineEnvironment.transform 11 16 env45890 = env45891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env45890 == env45891) = true)

theorem identity45891 : scanCanonicalize (H12AffineFastState.compose env45891 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound45891 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45892 : List Nat := [2,4,8,16,1,16,9,4,512,1024,529,16,9,1044,1,3,1029,529,1024,0,1,0,17,3,8,17,529,1028,17,529,1025,0,4,1,1044,513]

theorem envBound45892 : H12AffineFastState.Bounded env45892 := by
  intro p hp
  have h : env45892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45891_45892 : H12AffineEnvironment.transform 10 529 env45891 = env45892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env45891 == env45892) = true)

def env45893 : List Nat := [2,4,8,16,1,16,9,4,512,20,529,16,9,0,1,3,17,529,20,0,1,0,17,3,8,17,529,16,17,529,21,0,4,1,0,513]

theorem envBound45893 : H12AffineFastState.Bounded env45893 := by
  intro p hp
  have h : env45893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45892_45893 : H12AffineEnvironment.transform 9 20 env45892 = env45893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45892 == env45893) = true)

theorem identity45893 : scanCanonicalize (H12AffineFastState.compose env45893 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound45893 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45894 : List Nat := [2,4,8,16,1,16,9,4,16,20,1,16,9,0,1,3,17,1,20,0,1,0,17,3,8,17,1,16,17,1,21,0,4,1,0,17]

theorem envBound45894 : H12AffineFastState.Bounded env45894 := by
  intro p hp
  have h : env45894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45893_45894 : H12AffineEnvironment.transform 8 16 env45893 = env45894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env45893 == env45894) = true)

def leafEnv45894 : List Nat := [2,4,8,16,1,16,9,4,16,20,1,16,9,0,1,3,17,1,20,0,1,0,17,3,21,8,1,17,1,16,17,1,21,0,4,1,4,2,0,17,1,1,0]

def active45894 : List Nat := [0,1,2,3]

def tree45894 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45894 : H12WitnessSearch.Good tree45894 := H12GlobalWitnessIndex.good

theorem leafIdentity45894 : H12AffineFastState.composeSystem env45894 rootObs = leafEnv45894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45894 rootObs == leafEnv45894) = true)

theorem terminalChecked45894 : H12PackedTerminal.terminalCheckFast leafEnv45894 active45894 tree45894 = true := by decide +kernel

def env45895 : List Nat := [2,4,8,16,1,16,9,4,512,21,529,16,9,1,1,3,16,529,21,0,1,0,17,3,8,17,529,17,17,529,20,0,4,1,1,513]

theorem envBound45895 : H12AffineFastState.Bounded env45895 := by
  intro p hp
  have h : env45895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45892_45895 : H12AffineEnvironment.transform 9 21 env45892 = env45895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env45892 == env45895) = true)

theorem identity45895 : scanCanonicalize (H12AffineFastState.compose env45895 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound45895 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45896 : List Nat := [2,4,8,10,1,10,9,4,512,15,523,10,9,1,1,3,10,523,15,0,1,0,11,3,8,11,523,11,11,523,14,0,4,1,1,513]

theorem envBound45896 : H12AffineFastState.Bounded env45896 := by
  intro p hp
  have h : env45896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45895_45896 : H12AffineEnvironment.transform 3 10 env45895 = env45896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env45895 == env45896) = true)

def leafEnv45896 : List Nat := [2,4,8,10,1,10,9,4,512,15,523,10,9,1,1,3,10,523,15,0,1,0,11,3,14,8,1,11,523,11,11,523,14,0,4,1,4,2,1,513,1,1,0]

def active45896 : List Nat := [0,1,2,8]

def tree45896 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45896 : H12WitnessSearch.Good tree45896 := H12GlobalWitnessIndex.good

theorem leafIdentity45896 : H12AffineFastState.composeSystem env45896 rootObs = leafEnv45896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45896 rootObs == leafEnv45896) = true)

theorem terminalChecked45896 : H12PackedTerminal.terminalCheckFast leafEnv45896 active45896 tree45896 = true := by decide +kernel

def env45897 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,9,1045,1,3,1028,2048,1024,0,0,0,17,3,8,17,2048,1029,16,2048,1025,0,4,1,1045,513]

theorem envBound45897 : H12AffineFastState.Bounded env45897 := by
  intro p hp
  have h : env45897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45890_45897 : H12AffineEnvironment.transform 11 17 env45890 = env45897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env45890 == env45897) = true)

theorem identity45897 : scanCanonicalize (H12AffineFastState.compose env45897 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound45897 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45898 : List Nat := [2,4,8,16,1,16,9,4,512,1024,1541,17,9,1045,1,3,1028,1541,1024,0,0,0,17,3,8,17,1541,1029,16,1541,1025,0,4,1,1045,513]

theorem envBound45898 : H12AffineFastState.Bounded env45898 := by
  intro p hp
  have h : env45898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45897_45898 : H12AffineEnvironment.transform 10 1541 env45897 = env45898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env45897 == env45898) = true)

def env45899 : List Nat := [2,4,8,16,1,16,9,4,512,20,529,17,9,1,1,3,16,529,20,0,0,0,17,3,8,17,529,17,16,529,21,0,4,1,1,513]

theorem envBound45899 : H12AffineFastState.Bounded env45899 := by
  intro p hp
  have h : env45899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45898_45899 : H12AffineEnvironment.transform 9 20 env45898 = env45899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45898 == env45899) = true)

theorem identity45899 : scanCanonicalize (H12AffineFastState.compose env45899 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound45899 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45900 : List Nat := [2,4,8,16,1,16,9,4,17,20,0,17,9,1,1,3,16,0,20,0,0,0,17,3,8,17,0,17,16,0,21,0,4,1,1,16]

theorem envBound45900 : H12AffineFastState.Bounded env45900 := by
  intro p hp
  have h : env45900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45899_45900 : H12AffineEnvironment.transform 8 17 env45899 = env45900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env45899 == env45900) = true)

def leafEnv45900 : List Nat := [2,4,8,16,1,16,9,4,17,20,0,17,9,1,1,3,16,0,20,0,0,0,17,3,21,8,1,17,0,17,16,0,21,0,4,1,4,2,1,16,1,0,0]

def active45900 : List Nat := [0,1,2,3]

def tree45900 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45900 : H12WitnessSearch.Good tree45900 := H12GlobalWitnessIndex.good

theorem leafIdentity45900 : H12AffineFastState.composeSystem env45900 rootObs = leafEnv45900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45900 rootObs == leafEnv45900) = true)

theorem terminalChecked45900 : H12PackedTerminal.terminalCheckFast leafEnv45900 active45900 tree45900 = true := by decide +kernel

def env45901 : List Nat := [2,4,8,16,1,16,9,4,512,21,528,17,9,0,1,3,17,528,21,0,0,0,17,3,8,17,528,16,16,528,20,0,4,1,0,513]

theorem envBound45901 : H12AffineFastState.Bounded env45901 := by
  intro p hp
  have h : env45901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45898_45901 : H12AffineEnvironment.transform 9 21 env45898 = env45901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env45898 == env45901) = true)

theorem identity45901 : scanCanonicalize (H12AffineFastState.compose env45901 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45901 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45902 : List Nat := [2,4,8,11,1,11,9,4,512,14,523,10,9,0,1,3,10,523,14,0,0,0,10,3,8,10,523,11,11,523,15,0,4,1,0,513]

theorem envBound45902 : H12AffineFastState.Bounded env45902 := by
  intro p hp
  have h : env45902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45901_45902 : H12AffineEnvironment.transform 3 11 env45901 = env45902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45901 == env45902) = true)

def leafEnv45902 : List Nat := [2,4,8,11,1,11,9,4,512,14,523,10,9,0,1,3,10,523,14,0,0,0,10,3,15,8,1,10,523,11,11,523,15,0,4,1,4,2,0,513,1,0,0]

def active45902 : List Nat := [0,1,2,8]

def tree45902 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45902 : H12WitnessSearch.Good tree45902 := H12GlobalWitnessIndex.good

theorem leafIdentity45902 : H12AffineFastState.composeSystem env45902 rootObs = leafEnv45902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45902 rootObs == leafEnv45902) = true)

theorem terminalChecked45902 : H12PackedTerminal.terminalCheckFast leafEnv45902 active45902 tree45902 = true := by decide +kernel

def env45903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272513,452768,441778,8328,65,245138,115151,17665,10401,119043,329730,256,485710,493803,63188]

theorem envBound45903 : H12AffineFastState.Bounded env45903 := by
  intro p hp
  have h : env45903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45858_45903 : H12AffineEnvironment.transform 21 272513 env45858 = env45903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45858 == env45903) = true)

theorem identity45903 : scanCanonicalize (H12AffineFastState.compose env45903 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound45903 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,456944,272513,452768,441778,8328,65,171417,57796,17665,10401,61704,272393,256,411973,436448,63188]

theorem envBound45904 : H12AffineFastState.Bounded env45904 := by
  intro p hp
  have h : env45904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45903_45904 : H12AffineEnvironment.transform 15 8203 env45903 = env45904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env45903 == env45904) = true)

def env45905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,456824,272393,452648,441658,8192,65,171281,57676,17665,10281,61704,272393,256,411973,436328,63068]

theorem envBound45905 : H12AffineFastState.Bounded env45905 := by
  intro p hp
  have h : env45905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45904_45905 : H12AffineEnvironment.transform 6 8 env45904 = env45905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45904 == env45905) = true)

theorem identity45905 : scanCanonicalize (H12AffineFastState.compose env45905 (packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 43357) := by decide +kernel

theorem selectedBound45905 : packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env45906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,43357,1024,32769,151845,33108,147829,136295,8192,65,171281,57676,17665,10281,61704,33108,256,188440,131381,63068]

theorem envBound45906 : H12AffineFastState.Bounded env45906 := by
  intro p hp
  have h : env45906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45905_45906 : H12AffineEnvironment.transform 17 43357 env45905 = env45906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43357 env45905 == env45906) = true)

theorem identity45906 : scanCanonicalize (H12AffineFastState.compose env45906 (packedSelected [0,6,16,20,27] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound45906 : packedSelected [0,6,16,20,27] rootPS < 2^1333 := by decide +kernel

def env45907 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,32768,35,131072,35189,1024,32769,151845,33108,147829,136295,40,65,171281,49508,17665,2049,53536,33108,256,180272,131381,54900]

theorem envBound45907 : H12AffineFastState.Bounded env45907 := by
  intro p hp
  have h : env45907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45906_45907 : H12AffineEnvironment.transform 12 40 env45906 = env45907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env45906 == env45907) = true)

theorem identity45907 : scanCanonicalize (H12AffineFastState.compose env45907 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 49509) := by decide +kernel

theorem selectedBound45907 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env45908 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,32768,35,49509,35189,1024,32769,36928,33108,32784,54530,40,65,23668,49508,17665,2049,53536,33108,256,341,49232,54900]

theorem envBound45908 : H12AffineFastState.Bounded env45908 := by
  intro p hp
  have h : env45908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45907_45908 : H12AffineEnvironment.transform 16 49509 env45907 = env45908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49509 env45907 == env45908) = true)

def env45909 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,456825,272392,452649,441659,8193,65,171280,57677,17665,10280,61704,272393,256,411973,436329,63069]

theorem envBound45909 : H12AffineFastState.Bounded env45909 := by
  intro p hp
  have h : env45909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45904_45909 : H12AffineEnvironment.transform 6 9 env45904 = env45909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45904 == env45909) = true)

theorem identity45909 : scanCanonicalize (H12AffineFastState.compose env45909 (packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound45909 : packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env45910 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,46157,262144,1024,32769,281652,272392,285796,264566,8193,65,10589,57677,17665,10280,61704,272393,256,326920,269348,63069]

theorem envBound45910 : H12AffineFastState.Bounded env45910 := by
  intro p hp
  have h : env45910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45909_45910 : H12AffineEnvironment.transform 16 46157 env45909 = env45910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env45909 == env45910) = true)

theorem identity45910 : scanCanonicalize (H12AffineFastState.compose env45910 (packedSelected [0,1,3,4,5,12,14,15,17,18,19,20,22,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound45910 : packedSelected [0,1,3,4,5,12,14,15,17,18,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env45911 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,46157,35189,1024,32769,50497,41341,54545,32771,8193,65,10589,57677,17665,10280,61704,41340,256,29821,38225,63069]

theorem envBound45911 : H12AffineFastState.Bounded env45911 := by
  intro p hp
  have h : env45911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45910_45911 : H12AffineEnvironment.transform 17 35189 env45910 = env45911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env45910 == env45911) = true)

theorem identity45911 : scanCanonicalize (H12AffineFastState.compose env45911 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45911 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env45912 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,343,38161,35189,1024,32769,50497,32801,54545,32771,349,65,2049,49169,17665,2420,53332,32800,256,21793,38225,55041]

theorem envBound45912 : H12AffineFastState.Bounded env45912 := by
  intro p hp
  have h : env45912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45911_45912 : H12AffineEnvironment.transform 12 348 env45911 = env45912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45911 == env45912) = true)

theorem identity45912 : scanCanonicalize (H12AffineFastState.compose env45912 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound45912 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env45913 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21840,343,16449,23589,1024,21841,4113,21873,65,21843,349,65,2049,5441,17665,2420,1284,21872,256,21793,16385,593]

theorem envBound45913 : H12AffineFastState.Bounded env45913 := by
  intro p hp
  have h : env45913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45912_45913 : H12AffineEnvironment.transform 14 21840 env45912 = env45913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env45912 == env45913) = true)

theorem identity45913 : scanCanonicalize (H12AffineFastState.compose env45913 (packedSelected [4,6,7,10,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound45913 : packedSelected [4,6,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env45914 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4112,1344,343,4177,3125,1024,1345,4113,1377,65,1347,349,65,2049,5441,5393,2420,1284,1376,256,1329,4113,593]

theorem envBound45914 : H12AffineFastState.Bounded env45914 := by
  intro p hp
  have h : env45914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45913_45914 : H12AffineEnvironment.transform 13 4112 env45913 = env45914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env45913 == env45914) = true)

theorem identity45914 : scanCanonicalize (H12AffineFastState.compose env45914 (packedSelected [0,2,6,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound45914 : packedSelected [0,2,6,9,12] rootPS < 2^1333 := by decide +kernel

def env45915 : List Nat := [2,4,8,16,32,64,9,256,512,68,2048,4096,348,4112,260,343,4177,2161,68,261,4113,293,65,263,349,65,2049,4357,4437,2420,320,292,256,373,4113,593]

theorem envBound45915 : H12AffineFastState.Bounded env45915 := by
  intro p hp
  have h : env45915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45914_45915 : H12AffineEnvironment.transform 9 68 env45914 = env45915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env45914 == env45915) = true)

theorem identity45915 : scanCanonicalize (H12AffineFastState.compose env45915 (packedSelected [0,3,4,5,6,7,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45915 : packedSelected [0,3,4,5,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env45916 : List Nat := [2,4,8,16,32,16,9,256,512,20,2048,4096,268,4112,260,263,4097,2081,20,261,4113,293,17,263,269,17,2049,4357,4357,2340,272,292,256,293,4113,513]

theorem envBound45916 : H12AffineFastState.Bounded env45916 := by
  intro p hp
  have h : env45916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45915_45916 : H12AffineEnvironment.transform 5 16 env45915 = env45916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45915 == env45916) = true)

theorem identity45916 : scanCanonicalize (H12AffineFastState.compose env45916 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound45916 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env45917 : List Nat := [2,4,8,16,32,16,9,256,512,20,260,4096,268,4112,260,263,4097,293,20,261,4113,293,17,263,269,17,261,4357,4357,32,272,292,256,293,4113,513]

theorem envBound45917 : H12AffineFastState.Bounded env45917 := by
  intro p hp
  have h : env45917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45916_45917 : H12AffineEnvironment.transform 10 260 env45916 = env45917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env45916 == env45917) = true)

def env45918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,452768,441779,8328,65,4691218,115151,17664,10401,119042,4268163,256,485710,493803,63189]

theorem envBound45918 : H12AffineFastState.Bounded env45918 := by
  intro p hp
  have h : env45918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45857_45918 : H12AffineEnvironment.transform 20 456945 env45857 = env45918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456945 env45857 == env45918) = true)

def env45919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272512,452768,441779,8328,65,245138,115151,17664,10401,119042,329731,256,485710,493803,63189]

theorem envBound45919 : H12AffineFastState.Bounded env45919 := by
  intro p hp
  have h : env45919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45918_45919 : H12AffineEnvironment.transform 21 272512 env45918 = env45919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45918 == env45919) = true)

theorem identity45919 : scanCanonicalize (H12AffineFastState.compose env45919 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound45919 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,115870,201967,120015,98780,8328,65,245138,115151,17664,10401,119042,144492,256,21793,46212,63189]

theorem envBound45920 : H12AffineFastState.Bounded env45920 := by
  intro p hp
  have h : env45920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45919_45920 : H12AffineEnvironment.transform 17 212079 env45919 = env45920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env45919 == env45920) = true)

def env45921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130175,1024,32769,115870,120063,120015,98780,8328,65,97666,115151,17664,10401,119042,62588,256,21793,46212,63189]

theorem envBound45921 : H12AffineFastState.Bounded env45921 := by
  intro p hp
  have h : env45921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45920_45921 : H12AffineEnvironment.transform 16 49168 env45920 = env45921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env45920 == env45921) = true)

theorem identity45921 : scanCanonicalize (H12AffineFastState.compose env45921 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound45921 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env45922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33030,49168,32121,1024,32769,17816,22009,21961,218,8328,65,64644,16585,17664,10401,20484,62588,256,21793,46212,63189]

theorem envBound45922 : H12AffineFastState.Bounded env45922 := by
  intro p hp
  have h : env45922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45921_45922 : H12AffineEnvironment.transform 15 33030 env45921 = env45922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env45921 == env45922) = true)

theorem identity45922 : scanCanonicalize (H12AffineFastState.compose env45922 (packedSelected [0,1,4,5,7,8,10,11,16,17,19,20,22,24,26,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound45922 : packedSelected [0,1,4,5,7,8,10,11,16,17,19,20,22,24,26,31,32] rootPS < 2^1333 := by decide +kernel

def env45923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,216,478,16584,32121,1024,217,17816,22009,21961,218,8328,65,31836,16585,17664,10401,20484,29860,256,21793,13404,30221]

theorem envBound45923 : H12AffineFastState.Bounded env45923 := by
  intro p hp
  have h : env45923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45922_45923 : H12AffineEnvironment.transform 14 216 env45922 = env45923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env45922 == env45923) = true)

theorem identity45923 : scanCanonicalize (H12AffineFastState.compose env45923 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45923 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env45924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,216,478,16584,23588,1024,217,17816,22009,21961,218,469,65,23809,16585,17664,2556,20484,22009,256,21793,5377,22352]

theorem envBound45924 : H12AffineFastState.Bounded env45924 := by
  intro p hp
  have h : env45924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45923_45924 : H12AffineEnvironment.transform 12 349 env45923 = env45924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45923 == env45924) = true)

theorem identity45924 : scanCanonicalize (H12AffineFastState.compose env45924 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound45924 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env45925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5457,216,478,5529,2421,1024,217,4297,168,152,218,469,65,2128,5528,4177,2556,1365,168,256,112,5377,513]

theorem envBound45925 : H12AffineFastState.Bounded env45925 := by
  intro p hp
  have h : env45925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45924_45925 : H12AffineEnvironment.transform 13 5457 env45924 = env45925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env45924 == env45925) = true)

theorem identity45925 : scanCanonicalize (H12AffineFastState.compose env45925 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound45925 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45926 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5457,1,263,5440,2421,1024,0,4112,113,65,3,268,65,2128,5441,4177,2341,1365,113,256,112,5377,513]

theorem envBound45926 : H12AffineFastState.Bounded env45926 := by
  intro p hp
  have h : env45926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45925_45926 : H12AffineEnvironment.transform 6 89 env45925 = env45926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env45925 == env45926) = true)

theorem identity45926 : scanCanonicalize (H12AffineFastState.compose env45926 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45926 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45927 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,263,5392,2341,1024,0,4112,33,17,3,268,17,2048,5393,4097,2341,1285,33,256,32,5377,513]

theorem envBound45927 : H12AffineFastState.Bounded env45927 := by
  intro p hp
  have h : env45927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45926_45927 : H12AffineEnvironment.transform 5 16 env45926 = env45927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45926 == env45927) = true)

theorem identity45927 : scanCanonicalize (H12AffineFastState.compose env45927 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45927 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45928 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,1,35,5172,2049,1024,0,4112,33,17,3,40,17,2048,5173,4097,2049,1057,33,36,32,5157,513]

theorem envBound45928 : H12AffineFastState.Bounded env45928 := by
  intro p hp
  have h : env45928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45927_45928 : H12AffineEnvironment.transform 7 36 env45927 = env45928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45927 == env45928) = true)

def env45929 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,41,1045,1,35,1028,2049,1024,0,32,33,17,3,40,17,2048,1029,49,2049,1057,33,36,32,1045,513]

theorem envBound45929 : H12AffineFastState.Bounded env45929 := by
  intro p hp
  have h : env45929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45928_45929 : H12AffineEnvironment.transform 11 48 env45928 = env45929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env45928 == env45929) = true)

theorem identity45929 : scanCanonicalize (H12AffineFastState.compose env45929 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45929 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45930 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,17,8,1045,1,2,1028,2049,1024,0,1,0,17,3,9,17,2048,1029,16,2049,1024,0,5,1,1045,513]

theorem envBound45930 : H12AffineFastState.Bounded env45930 := by
  intro p hp
  have h : env45930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45929_45930 : H12AffineEnvironment.transform 4 1 env45929 = env45930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45929 == env45930) = true)

def env45931 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,17,8,1,1,2,16,2049,20,0,1,0,17,3,9,17,2048,17,16,2049,20,0,5,1,1,513]

theorem envBound45931 : H12AffineFastState.Bounded env45931 := by
  intro p hp
  have h : env45931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45930_45931 : H12AffineEnvironment.transform 9 20 env45930 = env45931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45930 == env45931) = true)

theorem identity45931 : scanCanonicalize (H12AffineFastState.compose env45931 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45931 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45932 : List Nat := [2,4,8,16,1,16,9,5,512,20,0,17,8,1,1,2,16,1,20,0,1,0,17,3,9,17,0,17,16,1,20,0,5,1,1,513]

theorem envBound45932 : H12AffineFastState.Bounded env45932 := by
  intro p hp
  have h : env45932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45931_45932 : H12AffineEnvironment.transform 10 0 env45931 = env45932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45931 == env45932) = true)

def leafEnv45932 : List Nat := [2,4,8,16,1,16,9,5,512,20,0,17,8,1,1,2,16,1,20,0,1,0,17,3,20,9,1,17,0,17,16,1,20,0,5,1,4,3,1,513,1,1,0]

def active45932 : List Nat := [0,1,2,3,8]

def tree45932 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45932 : H12WitnessSearch.Good tree45932 := H12GlobalWitnessIndex.good

theorem leafIdentity45932 : H12AffineFastState.composeSystem env45932 rootObs = leafEnv45932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45932 rootObs == leafEnv45932) = true)

theorem terminalChecked45932 : H12PackedTerminal.terminalCheckFast leafEnv45932 active45932 tree45932 = true := by decide +kernel

def env45933 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,17,8,0,1,2,17,2049,21,0,1,0,17,3,9,17,2048,16,16,2049,21,0,5,1,0,513]

theorem envBound45933 : H12AffineFastState.Bounded env45933 := by
  intro p hp
  have h : env45933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45930_45933 : H12AffineEnvironment.transform 9 21 env45930 = env45933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env45930 == env45933) = true)

theorem identity45933 : scanCanonicalize (H12AffineFastState.compose env45933 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound45933 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45934 : List Nat := [2,4,8,16,1,16,9,5,512,21,522,17,8,0,1,2,17,523,21,0,1,0,17,3,9,17,522,16,16,523,21,0,5,1,0,513]

theorem envBound45934 : H12AffineFastState.Bounded env45934 := by
  intro p hp
  have h : env45934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45933_45934 : H12AffineEnvironment.transform 10 522 env45933 = env45934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env45933 == env45934) = true)

def leafEnv45934 : List Nat := [2,4,8,16,1,16,9,5,512,21,522,17,8,0,1,2,17,523,21,0,1,0,17,3,21,9,1,17,522,16,16,523,21,0,5,1,4,3,0,513,1,1,0]

def active45934 : List Nat := [0,1,2,3,8]

def tree45934 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45934 : H12WitnessSearch.Good tree45934 := H12GlobalWitnessIndex.good

theorem leafIdentity45934 : H12AffineFastState.composeSystem env45934 rootObs = leafEnv45934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45934 rootObs == leafEnv45934) = true)

theorem terminalChecked45934 : H12PackedTerminal.terminalCheckFast leafEnv45934 active45934 tree45934 = true := by decide +kernel

def env45935 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,41,1044,1,35,1029,2049,1024,0,33,33,17,3,40,17,2048,1028,48,2049,1057,33,36,32,1044,513]

theorem envBound45935 : H12AffineFastState.Bounded env45935 := by
  intro p hp
  have h : env45935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45928_45935 : H12AffineEnvironment.transform 11 49 env45928 = env45935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env45928 == env45935) = true)

theorem identity45935 : scanCanonicalize (H12AffineFastState.compose env45935 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound45935 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45936 : List Nat := [2,4,8,16,32,16,9,36,512,20,2048,49,41,0,1,35,17,2049,20,0,33,33,17,3,40,17,2048,16,48,2049,53,33,36,32,0,513]

theorem envBound45936 : H12AffineFastState.Bounded env45936 := by
  intro p hp
  have h : env45936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45935_45936 : H12AffineEnvironment.transform 9 20 env45935 = env45936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45935 == env45936) = true)

def env45937 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,17,9,0,1,3,17,2049,20,0,1,1,17,3,8,17,2048,16,16,2049,21,1,4,0,0,513]

theorem envBound45937 : H12AffineFastState.Bounded env45937 := by
  intro p hp
  have h : env45937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45936_45937 : H12AffineEnvironment.transform 4 0 env45936 = env45937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45936 == env45937) = true)

theorem identity45937 : scanCanonicalize (H12AffineFastState.compose env45937 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound45937 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45938 : List Nat := [2,4,8,16,0,16,9,4,512,20,522,17,9,0,1,3,17,523,20,0,1,1,17,3,8,17,522,16,16,523,21,1,4,0,0,513]

theorem envBound45938 : H12AffineFastState.Bounded env45938 := by
  intro p hp
  have h : env45938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45937_45938 : H12AffineEnvironment.transform 10 522 env45937 = env45938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env45937 == env45938) = true)

def leafEnv45938 : List Nat := [2,4,8,16,0,16,9,4,512,20,522,17,9,0,1,3,17,523,20,0,1,1,17,3,21,8,1,17,522,16,16,523,21,1,4,0,4,2,0,513,1,1,0]

def active45938 : List Nat := [0,1,2,3,8]

def tree45938 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45938 : H12WitnessSearch.Good tree45938 := H12GlobalWitnessIndex.good

theorem leafIdentity45938 : H12AffineFastState.composeSystem env45938 rootObs = leafEnv45938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45938 rootObs == leafEnv45938) = true)

theorem terminalChecked45938 : H12PackedTerminal.terminalCheckFast leafEnv45938 active45938 tree45938 = true := by decide +kernel

def env45939 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,16,8,0,1,2,17,2049,20,0,0,0,17,3,9,17,2048,16,17,2049,20,0,5,1,0,513]

theorem envBound45939 : H12AffineFastState.Bounded env45939 := by
  intro p hp
  have h : env45939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45936_45939 : H12AffineEnvironment.transform 4 1 env45936 = env45939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45936 == env45939) = true)

theorem identity45939 : scanCanonicalize (H12AffineFastState.compose env45939 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound45939 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45940 : List Nat := [2,4,8,16,1,16,9,5,512,20,1,16,8,0,1,2,17,0,20,0,0,0,17,3,9,17,1,16,17,0,20,0,5,1,0,513]

theorem envBound45940 : H12AffineFastState.Bounded env45940 := by
  intro p hp
  have h : env45940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45939_45940 : H12AffineEnvironment.transform 10 1 env45939 = env45940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env45939 == env45940) = true)

def leafEnv45940 : List Nat := [2,4,8,16,1,16,9,5,512,20,1,16,8,0,1,2,17,0,20,0,0,0,17,3,20,9,1,17,1,16,17,0,20,0,5,1,4,3,0,513,1,0,0]

def active45940 : List Nat := [0,1,2,3,8]

def tree45940 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45940 : H12WitnessSearch.Good tree45940 := H12GlobalWitnessIndex.good

theorem leafIdentity45940 : H12AffineFastState.composeSystem env45940 rootObs = leafEnv45940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45940 rootObs == leafEnv45940) = true)

theorem terminalChecked45940 : H12PackedTerminal.terminalCheckFast leafEnv45940 active45940 tree45940 = true := by decide +kernel

def env45941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130174,1024,32769,115870,120062,120015,98780,8328,65,97667,115151,17664,10401,119042,62589,256,21793,46212,63189]

theorem envBound45941 : H12AffineFastState.Bounded env45941 := by
  intro p hp
  have h : env45941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45920_45941 : H12AffineEnvironment.transform 16 49169 env45920 = env45941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env45920 == env45941) = true)

theorem identity45941 : scanCanonicalize (H12AffineFastState.compose env45941 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45941 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env45942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,65536,49169,122146,1024,32769,115870,120062,120015,98780,468,65,89311,115151,17664,2557,119042,54561,256,21793,38360,55177]

theorem envBound45942 : H12AffineFastState.Bounded env45942 := by
  intro p hp
  have h : env45942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45941_45942 : H12AffineEnvironment.transform 12 348 env45941 = env45942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45941 == env45942) = true)

theorem identity45942 : scanCanonicalize (H12AffineFastState.compose env45942 (packedSelected [1,4,5,7,8,9,16,20,24,27] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45942 : packedSelected [1,4,5,7,8,9,16,20,24,27] rootPS < 2^1333 := by decide +kernel

def env45943 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,49169,122146,1024,32769,115735,119927,119878,98645,349,65,89174,115014,17664,2420,119042,54561,256,21793,38225,55040]

theorem envBound45943 : H12AffineFastState.Bounded env45943 := by
  intro p hp
  have h : env45943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45942_45943 : H12AffineEnvironment.transform 6 9 env45942 = env45943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45942 == env45943) = true)

theorem identity45943 : scanCanonicalize (H12AffineFastState.compose env45943 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound45943 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env45944 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,65536,5392,67619,1024,21760,69910,65910,65863,87124,349,65,89174,70727,17664,2420,66563,32,256,21793,16464,513]

theorem envBound45944 : H12AffineFastState.Bounded env45944 := by
  intro p hp
  have h : env45944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45943_45944 : H12AffineEnvironment.transform 14 21761 env45943 = env45944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env45943 == env45944) = true)

def env45945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272513,452768,441779,8328,65,245139,115151,17664,10401,119042,329730,256,485710,493803,63189]

theorem envBound45945 : H12AffineFastState.Bounded env45945 := by
  intro p hp
  have h : env45945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45918_45945 : H12AffineEnvironment.transform 21 272513 env45918 = env45945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45918 == env45945) = true)

theorem identity45945 : scanCanonicalize (H12AffineFastState.compose env45945 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound45945 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,456945,272513,452768,441779,8328,65,158028,5392,17664,10401,1501,318685,256,441745,416820,63189]

theorem envBound45946 : H12AffineFastState.Bounded env45946 := by
  intro p hp
  have h : env45946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45945_45946 : H12AffineEnvironment.transform 15 54495 env45945 = env45946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env45945 == env45946) = true)

theorem identity45946 : scanCanonicalize (H12AffineFastState.compose env45946 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound45946 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env45947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,131072,262144,1024,29909,396325,272513,400500,412007,8328,65,158028,5392,17664,10401,1501,272393,256,411973,416820,513]

theorem envBound45947 : H12AffineFastState.Bounded env45947 := by
  intro p hp
  have h : env45947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45946_45947 : H12AffineEnvironment.transform 14 29908 env45946 = env45947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env45946 == env45947) = true)

theorem identity45947 : scanCanonicalize (H12AffineFastState.compose env45947 (packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45947 : packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env45948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21897,342,131072,262144,1024,21896,396325,264668,400500,412007,469,65,149521,5392,17664,2556,1501,264532,256,411973,416820,513]

theorem envBound45948 : H12AffineFastState.Bounded env45948 := by
  intro p hp
  have h : env45948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45947_45948 : H12AffineEnvironment.transform 12 349 env45947 = env45948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45947 == env45948) = true)

theorem identity45948 : scanCanonicalize (H12AffineFastState.compose env45948 (packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS)) = affineNative (2^(17+1) ^^^ 2556) := by decide +kernel

theorem selectedBound45948 : packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env45949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21897,342,131072,2556,1024,21896,132569,32,136584,147611,469,65,149521,5392,17664,2556,1501,168,256,147641,153032,513]

theorem envBound45949 : H12AffineFastState.Bounded env45949 := by
  intro p hp
  have h : env45949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45948_45949 : H12AffineEnvironment.transform 17 2556 env45948 = env45949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2556 env45948 == env45949) = true)

theorem identity45949 : scanCanonicalize (H12AffineFastState.compose env45949 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound45949 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env45950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21897,342,5529,2556,1024,21896,4160,32,17,21762,469,65,23944,5392,17664,2556,1501,168,256,21792,16465,513]

theorem envBound45950 : H12AffineFastState.Bounded env45950 := by
  intro p hp
  have h : env45950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45949_45950 : H12AffineEnvironment.transform 16 5529 env45949 = env45950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env45949 == env45950) = true)

theorem identity45950 : scanCanonicalize (H12AffineFastState.compose env45950 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound45950 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45951 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,16384,21841,342,5441,2340,1024,21840,4160,32,17,21762,269,65,23888,5392,17664,2340,1285,112,256,21792,16465,513]

theorem envBound45951 : H12AffineFastState.Bounded env45951 := by
  intro p hp
  have h : env45951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45950_45951 : H12AffineEnvironment.transform 6 88 env45950 = env45951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env45950 == env45951) = true)

theorem identity45951 : scanCanonicalize (H12AffineFastState.compose env45951 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound45951 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env45952 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,5457,0,342,5441,2340,1024,1,4160,32,17,83,269,65,2049,5392,4177,2340,1285,112,256,113,5376,513]

theorem envBound45952 : H12AffineFastState.Bounded env45952 := by
  intro p hp
  have h : env45952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45951_45952 : H12AffineEnvironment.transform 13 5457 env45951 = env45952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env45951 == env45952) = true)

theorem identity45952 : scanCanonicalize (H12AffineFastState.compose env45952 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1636) := by decide +kernel

theorem selectedBound45952 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env45953 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1636,349,821,0,342,805,2340,1024,1,1572,32,17,83,269,65,2049,884,1589,2340,1285,112,256,113,868,513]

theorem envBound45953 : H12AffineFastState.Bounded env45953 := by
  intro p hp
  have h : env45953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45952_45953 : H12AffineEnvironment.transform 11 1636 env45952 = env45953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1636 env45952 == env45953) = true)

theorem identity45953 : scanCanonicalize (H12AffineFastState.compose env45953 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 885) := by decide +kernel

theorem selectedBound45953 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45954 : List Nat := [2,4,8,16,32,64,88,256,512,1024,885,1636,349,821,0,342,805,593,1024,1,1572,32,17,83,269,65,884,884,1589,593,1285,112,256,113,868,513]

theorem envBound45954 : H12AffineFastState.Bounded env45954 := by
  intro p hp
  have h : env45954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45953_45954 : H12AffineEnvironment.transform 10 885 env45953 = env45954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 885 env45953 == env45954) = true)

theorem identity45954 : scanCanonicalize (H12AffineFastState.compose env45954 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound45954 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env45955 : List Nat := [2,4,8,16,32,0,24,256,512,1024,821,1572,285,821,0,278,805,529,1024,1,1572,32,17,19,269,1,820,820,1589,529,1285,48,256,49,804,513]

theorem envBound45955 : H12AffineFastState.Bounded env45955 := by
  intro p hp
  have h : env45955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45954_45955 : H12AffineEnvironment.transform 5 0 env45954 = env45955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env45954 == env45955) = true)

theorem identity45955 : scanCanonicalize (H12AffineFastState.compose env45955 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound45955 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env45956 : List Nat := [2,4,8,16,32,0,24,256,512,256,821,804,285,821,0,278,805,529,256,1,804,32,17,19,269,1,820,820,821,529,5,48,256,49,804,513]

theorem envBound45956 : H12AffineFastState.Bounded env45956 := by
  intro p hp
  have h : env45956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45955_45956 : H12AffineEnvironment.transform 9 256 env45955 = env45956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env45955 == env45956) = true)

theorem identity45956 : scanCanonicalize (H12AffineFastState.compose env45956 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound45956 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env45957 : List Nat := [2,4,8,16,32,0,24,21,512,21,544,561,8,544,0,3,560,529,21,1,561,32,17,19,24,1,545,545,544,529,5,48,21,49,561,513]

theorem envBound45957 : H12AffineFastState.Bounded env45957 := by
  intro p hp
  have h : env45957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45956_45957 : H12AffineEnvironment.transform 7 21 env45956 = env45957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env45956 == env45957) = true)

theorem identity45957 : scanCanonicalize (H12AffineFastState.compose env45957 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45957 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env45958 : List Nat := [2,4,8,0,32,0,8,5,512,5,544,545,8,544,0,3,544,513,5,1,545,32,1,3,8,1,545,545,544,513,5,32,5,33,545,513]

theorem envBound45958 : H12AffineFastState.Bounded env45958 := by
  intro p hp
  have h : env45958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45957_45958 : H12AffineEnvironment.transform 3 0 env45957 = env45958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45957 == env45958) = true)

theorem identity45958 : scanCanonicalize (H12AffineFastState.compose env45958 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound45958 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45959 : List Nat := [2,4,8,0,32,0,8,5,0,5,32,33,8,32,0,3,32,1,5,1,33,32,1,3,8,1,33,33,32,1,5,32,5,33,33,1]

theorem envBound45959 : H12AffineFastState.Bounded env45959 := by
  intro p hp
  have h : env45959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45958_45959 : H12AffineEnvironment.transform 8 0 env45958 = env45959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env45958 == env45959) = true)

theorem identity45959 : scanCanonicalize (H12AffineFastState.compose env45959 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45959 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env45960 : List Nat := [2,4,8,0,1,0,8,5,0,5,1,0,8,1,0,3,1,1,5,1,0,1,1,3,8,1,0,0,1,1,5,1,5,0,0,1]

theorem envBound45960 : H12AffineFastState.Bounded env45960 := by
  intro p hp
  have h : env45960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45959_45960 : H12AffineEnvironment.transform 4 1 env45959 = env45960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45959 == env45960) = true)

def env45961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452769,2114883,8328,65,6385123,115150,2538992,10400,2566643,4268162,256,485710,493803,2493988]

theorem envBound45961 : H12AffineFastState.Bounded env45961 := by
  intro p hp
  have h : env45961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45856_45961 : H12AffineEnvironment.transform 22 452769 env45856 = env45961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env45856 == env45961) = true)

def env45962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452769,441779,8328,65,4691219,115150,17664,10400,119043,4268162,256,485710,493803,63188]

theorem envBound45962 : H12AffineFastState.Bounded env45962 := by
  intro p hp
  have h : env45962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45961_45962 : H12AffineEnvironment.transform 20 456944 env45961 = env45962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456944 env45961 == env45962) = true)

def env45963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452769,441779,8328,65,245139,115150,17664,10400,119043,329730,256,485710,493803,63188]

theorem envBound45963 : H12AffineFastState.Bounded env45963 := by
  intro p hp
  have h : env45963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45962_45963 : H12AffineEnvironment.transform 21 272512 env45962 = env45963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45962 == env45963) = true)

def env45964 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272392,452649,441659,8192,65,245019,115014,17664,10280,119043,329730,256,485710,493667,63068]

theorem envBound45964 : H12AffineFastState.Bounded env45964 := by
  intro p hp
  have h : env45964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45963_45964 : H12AffineEnvironment.transform 6 8 env45963 = env45964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45963 == env45964) = true)

def env45965 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276584,272392,272441,294187,8192,65,97547,115014,17664,10280,119043,329730,256,371038,346227,63068]

theorem envBound45965 : H12AffineFastState.Bounded env45965 := by
  intro p hp
  have h : env45965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45964_45965 : H12AffineEnvironment.transform 16 49168 env45964 = env45965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env45964 == env45965) = true)

theorem identity45965 : scanCanonicalize (H12AffineFastState.compose env45965 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45965 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45966 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24908,262144,1024,8541,276584,272392,272441,294187,8192,65,97547,90138,17664,10280,94303,329730,256,329730,346227,22272]

theorem envBound45966 : H12AffineFastState.Bounded env45966 := by
  intro p hp
  have h : env45966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45965_45966 : H12AffineEnvironment.transform 14 8540 env45965 = env45966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45965 == env45966) = true)

theorem identity45966 : scanCanonicalize (H12AffineFastState.compose env45966 (packedSelected [3,4,5,7,8,9,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound45966 : packedSelected [3,4,5,7,8,9,27,28] rootPS < 2^1333 := by decide +kernel

def env45967 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24908,10360,1024,8541,4112,112,65,21843,8192,65,97547,90138,17664,10280,94303,73850,256,73850,90123,22272]

theorem envBound45967 : H12AffineFastState.Bounded env45967 := by
  intro p hp
  have h : env45967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45966_45967 : H12AffineEnvironment.transform 17 10360 env45966 = env45967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env45966 == env45967) = true)

theorem identity45967 : scanCanonicalize (H12AffineFastState.compose env45967 (packedSelected [0,1,3,5,7,8,10,11,15,16,18,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 18466) := by decide +kernel

theorem selectedBound45967 : packedSelected [0,1,3,5,7,8,10,11,15,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env45968 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,18466,24908,10360,1024,8541,4112,112,65,21843,8192,65,13609,10296,17664,10280,14461,26712,256,26712,10281,22272]

theorem envBound45968 : H12AffineFastState.Bounded env45968 := by
  intro p hp
  have h : env45968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45967_45968 : H12AffineEnvironment.transform 15 18466 env45967 = env45968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18466 env45967 == env45968) = true)

theorem identity45968 : scanCanonicalize (H12AffineFastState.compose env45968 (packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound45968 : packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS < 2^1333 := by decide +kernel

def env45969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,8192,16384,8540,18466,24908,10360,1024,8541,3124,112,65,18807,8192,65,10509,10296,17664,10280,9305,26712,256,26712,10281,19236]

theorem envBound45969 : H12AffineFastState.Bounded env45969 := by
  intro p hp
  have h : env45969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45968_45969 : H12AffineEnvironment.transform 11 3108 env45968 = env45969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env45968 == env45969) = true)

theorem identity45969 : scanCanonicalize (H12AffineFastState.compose env45969 (packedSelected [0,7,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45969 : packedSelected [0,7,11,15,16] rootPS < 2^1333 := by decide +kernel

def env45970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,269,16384,81,18466,16449,2421,1024,80,3124,112,65,18807,269,65,2048,2357,17664,2341,1364,18773,256,18773,2340,19236]

theorem envBound45970 : H12AffineFastState.Bounded env45970 := by
  intro p hp
  have h : env45970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45969_45970 : H12AffineEnvironment.transform 12 269 env45969 = env45970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45969 == env45970) = true)

theorem identity45970 : scanCanonicalize (H12AffineFastState.compose env45970 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound45970 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env45971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,1140,269,16384,81,16498,16449,293,1024,80,1124,112,65,16679,269,65,80,357,17664,373,1364,16645,256,16645,372,17268]

theorem envBound45971 : H12AffineFastState.Bounded env45971 := by
  intro p hp
  have h : env45971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45970_45971 : H12AffineEnvironment.transform 10 80 env45970 = env45971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env45970 == env45971) = true)

theorem identity45971 : scanCanonicalize (H12AffineFastState.compose env45971 (packedSelected [1,3,4,5,6,8,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound45971 : packedSelected [1,3,4,5,6,8,9,14] rootPS < 2^1333 := by decide +kernel

def env45972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,1140,269,293,81,343,356,293,1024,80,1124,112,65,2,269,65,80,357,1061,373,1364,32,256,32,372,593]

theorem envBound45972 : H12AffineFastState.Bounded env45972 := by
  intro p hp
  have h : env45972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45971_45972 : H12AffineEnvironment.transform 13 293 env45971 = env45972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env45971 == env45972) = true)

theorem identity45972 : scanCanonicalize (H12AffineFastState.compose env45972 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound45972 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env45973 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,357,269,293,81,343,356,293,273,80,373,112,65,2,269,65,80,357,308,373,69,32,256,32,372,593]

theorem envBound45973 : H12AffineFastState.Bounded env45973 := by
  intro p hp
  have h : env45973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45972_45973 : H12AffineEnvironment.transform 9 273 env45972 = env45973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env45972 == env45973) = true)

theorem identity45973 : scanCanonicalize (H12AffineFastState.compose env45973 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45973 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env45974 : List Nat := [2,4,8,16,32,64,8,37,512,52,80,64,40,0,81,114,65,0,52,80,80,112,65,2,40,65,80,64,17,80,69,32,37,32,81,593]

theorem envBound45974 : H12AffineFastState.Bounded env45974 := by
  intro p hp
  have h : env45974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45973_45974 : H12AffineEnvironment.transform 7 37 env45973 = env45974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45973 == env45974) = true)

theorem identity45974 : scanCanonicalize (H12AffineFastState.compose env45974 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45974 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45975 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,17,40,0,0,35,16,0,52,1,1,33,16,2,40,16,1,17,17,1,20,32,37,32,0,512]

theorem envBound45975 : H12AffineFastState.Bounded env45975 := by
  intro p hp
  have h : env45975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45974_45975 : H12AffineEnvironment.transform 5 17 env45974 = env45975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45974 == env45975) = true)

theorem identity45975 : scanCanonicalize (H12AffineFastState.compose env45975 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound45975 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45976 : List Nat := [2,4,8,16,32,17,8,37,4,52,1,17,40,0,0,35,16,0,52,1,1,33,16,2,40,16,1,17,17,1,20,32,37,32,0,4]

theorem envBound45976 : H12AffineFastState.Bounded env45976 := by
  intro p hp
  have h : env45976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45975_45976 : H12AffineEnvironment.transform 8 4 env45975 = env45976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env45975 == env45976) = true)

theorem identity45976 : scanCanonicalize (H12AffineFastState.compose env45976 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound45976 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45977 : List Nat := [2,4,8,16,7,17,8,2,4,19,1,17,15,0,0,4,16,0,19,1,1,6,16,2,15,16,1,17,17,1,20,7,2,7,0,4]

theorem envBound45977 : H12AffineFastState.Bounded env45977 := by
  intro p hp
  have h : env45977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45976_45977 : H12AffineEnvironment.transform 4 7 env45976 = env45977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env45976 == env45977) = true)

theorem identity45977 : scanCanonicalize (H12AffineFastState.compose env45977 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45977 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45978 : List Nat := [2,4,8,0,7,1,8,2,4,3,1,1,15,0,0,4,0,0,3,1,1,6,0,2,15,0,1,1,1,1,4,7,2,7,0,4]

theorem envBound45978 : H12AffineFastState.Bounded env45978 := by
  intro p hp
  have h : env45978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45977_45978 : H12AffineEnvironment.transform 3 0 env45977 = env45978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45977 == env45978) = true)

theorem identity45978 : scanCanonicalize (H12AffineFastState.compose env45978 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45978 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45979 : List Nat := [2,4,5,0,7,1,5,2,4,3,1,1,2,0,0,4,0,0,3,1,1,6,0,2,2,0,1,1,1,1,4,7,2,7,0,4]

theorem envBound45979 : H12AffineFastState.Bounded env45979 := by
  intro p hp
  have h : env45979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45978_45979 : H12AffineEnvironment.transform 2 5 env45978 = env45979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45978 == env45979) = true)

theorem identity45979 : scanCanonicalize (H12AffineFastState.compose env45979 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound45979 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env45980 : List Nat := [2,1,0,0,2,1,0,2,1,3,1,1,2,0,0,1,0,0,3,1,1,3,0,2,2,0,1,1,1,1,1,2,2,2,0,1]

theorem envBound45980 : H12AffineFastState.Bounded env45980 := by
  intro p hp
  have h : env45980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45979_45980 : H12AffineEnvironment.transform 1 1 env45979 = env45980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env45979 == env45980) = true)

theorem identity45980 : scanCanonicalize (H12AffineFastState.compose env45980 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45980 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env45981 : List Nat := [1,1,0,0,1,1,0,1,1,0,1,1,1,0,0,1,0,0,0,1,1,0,0,1,1,0,1,1,1,1,1,1,1,1,0,1]

theorem envBound45981 : H12AffineFastState.Bounded env45981 := by
  intro p hp
  have h : env45981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45980_45981 : H12AffineEnvironment.transform 0 1 env45980 = env45981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45980 == env45981) = true)

def env45982 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276585,272392,272440,294186,8192,65,97546,115014,17664,10280,119043,329730,256,371039,346226,63068]

theorem envBound45982 : H12AffineFastState.Bounded env45982 := by
  intro p hp
  have h : env45982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45964_45982 : H12AffineEnvironment.transform 16 49169 env45964 = env45982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env45964 == env45982) = true)

theorem identity45982 : scanCanonicalize (H12AffineFastState.compose env45982 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound45982 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45983 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1024,32769,45340,41341,41293,62559,8192,65,97546,115014,17664,10280,119043,98679,256,73770,114951,63068]

theorem envBound45983 : H12AffineFastState.Bounded env45983 := by
  intro p hp
  have h : env45983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45982_45983 : H12AffineEnvironment.transform 17 35189 env45982 = env45983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env45982 == env45983) = true)

theorem identity45983 : scanCanonicalize (H12AffineFastState.compose env45983 (packedSelected [0,1,3,4,8,10,12,14,15,20,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound45983 : packedSelected [0,1,3,4,8,10,12,14,15,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env45984 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,293,65536,16692,2128,1024,292,12345,8280,8296,30074,8192,65,97546,82019,17664,10280,86054,65618,256,73770,81954,30585]

theorem envBound45984 : H12AffineFastState.Bounded env45984 := by
  intro p hp
  have h : env45984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45983_45984 : H12AffineEnvironment.transform 14 293 env45983 = env45984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env45983 == env45984) = true)

theorem identity45984 : scanCanonicalize (H12AffineFastState.compose env45984 (packedSelected [1,2,4,5,6,8,11,16,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound45984 : packedSelected [1,2,4,5,6,8,11,16,22,23,24] rootPS < 2^1333 := by decide +kernel

def env45985 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,293,65536,5440,2128,1024,292,12345,8280,8296,8462,8192,65,76158,70679,4468,10280,66642,65618,256,73770,70742,8973]

theorem envBound45985 : H12AffineFastState.Bounded env45985 := by
  intro p hp
  have h : env45985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45984_45985 : H12AffineEnvironment.transform 13 5236 env45984 = env45985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env45984 == env45985) = true)

theorem identity45985 : scanCanonicalize (H12AffineFastState.compose env45985 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound45985 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env45986 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5236,293,65536,5440,2128,1024,292,4112,113,65,295,41,65,67927,70679,4468,2049,66642,65618,256,65539,70742,804]

theorem envBound45986 : H12AffineFastState.Bounded env45986 := by
  intro p hp
  have h : env45986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45985_45986 : H12AffineEnvironment.transform 12 41 env45985 = env45986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env45985 == env45986) = true)

theorem identity45986 : scanCanonicalize (H12AffineFastState.compose env45986 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound45986 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env45987 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5236,293,35,5440,2128,1024,292,4112,113,65,295,41,65,2420,5172,4468,2049,1137,113,256,32,5237,804]

theorem envBound45987 : H12AffineFastState.Bounded env45987 := by
  intro p hp
  have h : env45987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45986_45987 : H12AffineEnvironment.transform 15 35 env45986 = env45987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env45986 == env45987) = true)

theorem identity45987 : scanCanonicalize (H12AffineFastState.compose env45987 (packedSelected [1,3,5,6,7,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound45987 : packedSelected [1,3,5,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env45988 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,41,4112,293,35,4388,2128,100,292,4112,113,65,295,41,65,2420,4176,4468,2049,21,113,256,32,4113,804]

theorem envBound45988 : H12AffineFastState.Bounded env45988 := by
  intro p hp
  have h : env45988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45987_45988 : H12AffineEnvironment.transform 9 100 env45987 = env45988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env45987 == env45988) = true)

theorem identity45988 : scanCanonicalize (H12AffineFastState.compose env45988 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound45988 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env45989 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,41,4112,81,35,4176,2128,100,80,4112,113,65,83,41,65,2048,4176,4096,2049,21,113,116,32,4113,592]

theorem envBound45989 : H12AffineFastState.Bounded env45989 := by
  intro p hp
  have h : env45989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45988_45989 : H12AffineEnvironment.transform 7 116 env45988 = env45989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env45988 == env45989) = true)

theorem identity45989 : scanCanonicalize (H12AffineFastState.compose env45989 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound45989 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env45990 : List Nat := [2,4,8,16,32,64,8,116,512,100,81,4096,41,4112,81,35,4176,1,100,80,4112,113,65,83,41,65,81,4176,4096,80,21,113,116,32,4113,592]

theorem envBound45990 : H12AffineFastState.Bounded env45990 := by
  intro p hp
  have h : env45990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45989_45990 : H12AffineEnvironment.transform 10 81 env45989 = env45990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env45989 == env45990) = true)

theorem identity45990 : scanCanonicalize (H12AffineFastState.compose env45990 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound45990 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env45991 : List Nat := [2,4,8,16,32,64,8,116,512,100,81,16,41,0,81,35,64,1,100,80,0,113,65,83,41,65,81,64,16,80,21,113,116,32,1,592]

theorem envBound45991 : H12AffineFastState.Bounded env45991 := by
  intro p hp
  have h : env45991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45990_45991 : H12AffineEnvironment.transform 11 16 env45990 = env45991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env45990 == env45991) = true)

theorem identity45991 : scanCanonicalize (H12AffineFastState.compose env45991 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45991 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env45992 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,16,41,0,0,35,17,1,53,1,0,32,16,2,41,16,0,17,16,1,21,32,37,32,1,513]

theorem envBound45992 : H12AffineFastState.Bounded env45992 := by
  intro p hp
  have h : env45992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45991_45992 : H12AffineEnvironment.transform 5 17 env45991 = env45992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45991 == env45992) = true)

theorem identity45992 : scanCanonicalize (H12AffineFastState.compose env45992 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound45992 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45993 : List Nat := [2,4,8,16,32,17,8,37,17,53,0,16,41,0,0,35,17,1,53,1,0,32,16,2,41,16,0,17,16,1,21,32,37,32,1,16]

theorem envBound45993 : H12AffineFastState.Bounded env45993 := by
  intro p hp
  have h : env45993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45992_45993 : H12AffineEnvironment.transform 8 17 env45992 = env45993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env45992 == env45993) = true)

theorem identity45993 : scanCanonicalize (H12AffineFastState.compose env45993 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45993 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45994 : List Nat := [2,4,8,11,32,10,8,37,10,46,0,11,41,0,0,35,10,1,46,1,0,32,11,2,41,11,0,10,11,1,14,32,37,32,1,11]

theorem envBound45994 : H12AffineFastState.Bounded env45994 := by
  intro p hp
  have h : env45994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45993_45994 : H12AffineEnvironment.transform 3 11 env45993 = env45994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45993 == env45994) = true)

theorem identity45994 : scanCanonicalize (H12AffineFastState.compose env45994 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45994 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45995 : List Nat := [2,4,2,1,32,0,2,37,0,36,0,1,35,0,0,35,0,1,36,1,0,32,1,2,35,1,0,0,1,1,4,32,37,32,1,1]

theorem envBound45995 : H12AffineFastState.Bounded env45995 := by
  intro p hp
  have h : env45995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45994_45995 : H12AffineEnvironment.transform 2 2 env45994 = env45995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45994 == env45995) = true)

def env45996 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272393,452648,441658,8193,65,245018,115015,17664,10281,119043,329730,256,485710,493666,63069]

theorem envBound45996 : H12AffineFastState.Bounded env45996 := by
  intro p hp
  have h : env45996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45963_45996 : H12AffineEnvironment.transform 6 9 env45963 = env45996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45963 == env45996) = true)

def env45997 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276585,272393,272440,294186,8193,65,97546,115015,17664,10281,119043,329730,256,371038,346226,63069]

theorem envBound45997 : H12AffineFastState.Bounded env45997 := by
  intro p hp
  have h : env45997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45996_45997 : H12AffineEnvironment.transform 16 49168 env45996 = env45997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env45996 == env45997) = true)

theorem identity45997 : scanCanonicalize (H12AffineFastState.compose env45997 (packedSelected [1,5,7,10,14,18,19,20,23,24,26,27,28,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound45997 : packedSelected [1,5,7,10,14,18,19,20,23,24,26,27,28,38,41] rootPS < 2^1333 := by decide +kernel

def env45998 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,56356,1024,32769,58445,62509,62492,41230,8193,65,97546,115015,17664,10281,119043,119846,256,95610,103510,63069]

theorem envBound45998 : H12AffineFastState.Bounded env45998 := by
  intro p hp
  have h : env45998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45997_45998 : H12AffineEnvironment.transform 17 56356 env45997 = env45998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env45997 == env45998) = true)

theorem identity45998 : scanCanonicalize (H12AffineFastState.compose env45998 (packedSelected [0,1,5,7,9,12,14,15,16,19,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound45998 : packedSelected [0,1,5,7,9,12,14,15,16,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env45999 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13389,10361,1024,29788,4112,112,65,21843,8193,65,97546,79130,17664,10281,75102,73851,256,95610,90123,512]

theorem envBound45999 : H12AffineFastState.Bounded env45999 := by
  intro p hp
  have h : env45999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45998_45999 : H12AffineEnvironment.transform 14 29789 env45998 = env45999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env45998 == env45999) = true)

theorem identity45999 : scanCanonicalize (H12AffineFastState.compose env45999 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound45999 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env46000 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,30042,13389,10361,1024,29788,4112,112,65,21843,8193,65,2128,16448,17664,10281,20484,21793,256,32,5457,512]

theorem envBound46000 : H12AffineFastState.Bounded env46000 := by
  intro p hp
  have h : env46000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45999_46000 : H12AffineEnvironment.transform 15 30042 env45999 = env46000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env45999 == env46000) = true)

theorem identity46000 : scanCanonicalize (H12AffineFastState.compose env46000 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound46000 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env46001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4405,9576,9327,13389,10361,1024,9577,4112,112,65,1126,8193,65,2128,4469,5173,10281,305,1044,256,32,5457,512]

theorem envBound46001 : H12AffineFastState.Bounded env46001 := by
  intro p hp
  have h : env46001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46000_46001 : H12AffineEnvironment.transform 13 4405 env46000 = env46001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env46000 == env46001) = true)

theorem identity46001 : scanCanonicalize (H12AffineFastState.compose env46001 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound46001 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env46002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4405,0,263,4389,3345,1024,1,4112,112,65,1126,1385,65,2128,4469,5173,3393,305,1044,256,32,5457,512]

theorem envBound46002 : H12AffineFastState.Bounded env46002 := by
  intro p hp
  have h : env46002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46001_46002 : H12AffineEnvironment.transform 12 1384 env46001 = env46002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env46001 == env46002) = true)

theorem identity46002 : scanCanonicalize (H12AffineFastState.compose env46002 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound46002 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46003 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,1305,4405,0,263,4389,3345,1024,1,4112,1,48,1047,1304,48,2081,4356,5173,3376,305,1044,256,32,5408,512]

theorem envBound46003 : H12AffineFastState.Bounded env46003 := by
  intro p hp
  have h : env46003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46002_46003 : H12AffineEnvironment.transform 5 49 env46002 = env46003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env46002 == env46003) = true)

theorem identity46003 : scanCanonicalize (H12AffineFastState.compose env46003 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46003 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46004 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,4096,1085,4113,0,35,4097,3125,1024,1,4112,1,48,1047,1084,48,2081,4128,5173,3092,21,1044,36,32,5124,512]

theorem envBound46004 : H12AffineFastState.Bounded env46004 := by
  intro p hp
  have h : env46004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46003_46004 : H12AffineEnvironment.transform 7 36 env46003 = env46004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46003 == env46004) = true)

theorem identity46004 : scanCanonicalize (H12AffineFastState.compose env46004 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46004 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46005 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,1053,4113,0,3,4097,3093,1024,1,4112,1,16,1047,1052,16,2049,4096,5141,3092,21,1044,4,0,5124,512]

theorem envBound46005 : H12AffineFastState.Bounded env46005 := by
  intro p hp
  have h : env46005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46004_46005 : H12AffineEnvironment.transform 4 0 env46004 = env46005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46004 == env46005) = true)

theorem identity46005 : scanCanonicalize (H12AffineFastState.compose env46005 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound46005 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46006 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,1044,1053,1029,0,3,1045,3093,1024,1,1028,1,16,1047,1052,16,2049,1044,1,3092,21,1044,4,0,16,512]

theorem envBound46006 : H12AffineFastState.Bounded env46006 := by
  intro p hp
  have h : env46006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46005_46006 : H12AffineEnvironment.transform 11 1044 env46005 = env46006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env46005 == env46006) = true)

theorem identity46006 : scanCanonicalize (H12AffineFastState.compose env46006 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound46006 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env46007 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1044,1044,1053,1029,0,3,1045,1,1024,1,1028,1,16,1047,1052,16,1045,1044,1,0,21,1044,4,0,16,512]

theorem envBound46007 : H12AffineFastState.Bounded env46007 := by
  intro p hp
  have h : env46007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46006_46007 : H12AffineEnvironment.transform 10 1044 env46006 = env46007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env46006 == env46007) = true)

theorem identity46007 : scanCanonicalize (H12AffineFastState.compose env46007 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound46007 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env46008 : List Nat := [2,4,8,16,0,17,9,4,512,20,0,0,9,17,0,3,1,1,20,1,16,1,16,3,8,16,1,0,1,0,21,0,4,0,16,512]

theorem envBound46008 : H12AffineFastState.Bounded env46008 := by
  intro p hp
  have h : env46008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46007_46008 : H12AffineEnvironment.transform 9 20 env46007 = env46008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env46007 == env46008) = true)

theorem identity46008 : scanCanonicalize (H12AffineFastState.compose env46008 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound46008 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46009 : List Nat := [2,4,8,16,0,17,9,4,17,20,0,0,9,17,0,3,1,1,20,1,16,1,16,3,8,16,1,0,1,0,21,0,4,0,16,17]

theorem envBound46009 : H12AffineFastState.Bounded env46009 := by
  intro p hp
  have h : env46009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46008_46009 : H12AffineEnvironment.transform 8 17 env46008 = env46009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env46008 == env46009) = true)

theorem identity46009 : scanCanonicalize (H12AffineFastState.compose env46009 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound46009 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46010 : List Nat := [2,4,8,14,0,15,9,4,15,10,0,0,9,15,0,3,1,1,10,1,14,1,14,3,8,14,1,0,1,0,11,0,4,0,14,15]

theorem envBound46010 : H12AffineFastState.Bounded env46010 := by
  intro p hp
  have h : env46010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46009_46010 : H12AffineEnvironment.transform 3 14 env46009 = env46010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env46009 == env46010) = true)

def env46011 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276584,272393,272441,294187,8193,65,97547,115015,17664,10281,119043,329730,256,371039,346227,63069]

theorem envBound46011 : H12AffineFastState.Bounded env46011 := by
  intro p hp
  have h : env46011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45996_46011 : H12AffineEnvironment.transform 16 49169 env45996 = env46011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env45996 == env46011) = true)

theorem identity46011 : scanCanonicalize (H12AffineFastState.compose env46011 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound46011 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46012 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4160,33,17,21763,8193,65,97547,115015,17664,10281,119043,73770,256,98679,90203,63069]

theorem envBound46012 : H12AffineFastState.Bounded env46012 := by
  intro p hp
  have h : env46012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46011_46012 : H12AffineEnvironment.transform 17 10280 env46011 = env46012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env46011 == env46012) = true)

theorem identity46012 : scanCanonicalize (H12AffineFastState.compose env46012 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound46012 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env46013 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,262,49169,10280,1024,32769,4160,33,17,21763,8193,65,31757,49217,17664,10281,53253,8492,256,32881,24925,63069]

theorem envBound46013 : H12AffineFastState.Bounded env46013 := by
  intro p hp
  have h : env46013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46012_46013 : H12AffineEnvironment.transform 15 262 env46012 = env46013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env46012 == env46013) = true)

theorem identity46013 : scanCanonicalize (H12AffineFastState.compose env46013 (packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound46013 : packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env46014 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,262,5441,10280,1024,21841,4160,33,17,21763,8193,65,31757,5393,17664,10281,1365,8492,256,21793,24925,8973]

theorem envBound46014 : H12AffineFastState.Bounded env46014 := by
  intro p hp
  have h : env46014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46013_46014 : H12AffineEnvironment.transform 14 21840 env46013 = env46014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env46013 == env46014) = true)

theorem identity46014 : scanCanonicalize (H12AffineFastState.compose env46014 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46014 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env46015 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21840,262,5441,2421,1024,21841,4160,33,17,21763,348,65,23888,5393,17664,2420,1365,113,256,21793,16384,592]

theorem envBound46015 : H12AffineFastState.Bounded env46015 := by
  intro p hp
  have h : env46015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46014_46015 : H12AffineEnvironment.transform 12 349 env46014 = env46015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46014 == env46015) = true)

def env46016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272513,452769,441779,8328,65,245138,115150,17664,10400,119043,329731,256,485710,493803,63188]

theorem envBound46016 : H12AffineFastState.Bounded env46016 := by
  intro p hp
  have h : env46016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45962_46016 : H12AffineEnvironment.transform 21 272513 env45962 = env46016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45962 == env46016) = true)

theorem identity46016 : scanCanonicalize (H12AffineFastState.compose env46016 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190641) := by decide +kernel

theorem selectedBound46016 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,180272,16,21762,8328,65,245138,115150,17664,10400,119043,254130,256,98815,90202,63188]

theorem envBound46017 : H12AffineFastState.Bounded env46017 := by
  intro p hp
  have h : env46017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46016_46017 : H12AffineEnvironment.transform 17 190641 env46016 = env46017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env46016 == env46017) = true)

def env46018 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,180272,16,21762,8192,65,245018,115014,17664,10280,119043,254010,256,98679,90202,63068]

theorem envBound46018 : H12AffineFastState.Bounded env46018 := by
  intro p hp
  have h : env46018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46017_46018 : H12AffineEnvironment.transform 6 8 env46017 = env46018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46017 == env46018) = true)

theorem identity46018 : scanCanonicalize (H12AffineFastState.compose env46018 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound46018 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46019 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35189,1024,32769,4161,41340,16,21762,8192,65,121942,115014,17664,10280,119043,98678,256,98679,90202,63068]

theorem envBound46019 : H12AffineFastState.Bounded env46019 := by
  intro p hp
  have h : env46019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46018_46019 : H12AffineEnvironment.transform 16 24908 env46018 = env46019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env46018 == env46019) = true)

theorem identity46019 : scanCanonicalize (H12AffineFastState.compose env46019 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound46019 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env46020 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,24908,23669,1024,21761,4161,29820,16,21762,8192,65,67926,70726,17664,10280,66563,87158,256,87159,90202,9052]

theorem envBound46020 : H12AffineFastState.Bounded env46020 := by
  intro p hp
  have h : env46020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46019_46020 : H12AffineEnvironment.transform 14 21760 env46019 = env46020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env46019 == env46020) = true)

theorem identity46020 : scanCanonicalize (H12AffineFastState.compose env46020 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46020 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env46021 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,65536,16401,23669,1024,21761,4161,21793,16,21762,349,65,67926,70726,17664,2421,66563,87158,256,87159,82183,513]

theorem envBound46021 : H12AffineFastState.Bounded env46021 := by
  intro p hp
  have h : env46021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46020_46021 : H12AffineEnvironment.transform 12 349 env46020 = env46021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46020 == env46021) = true)

theorem identity46021 : scanCanonicalize (H12AffineFastState.compose env46021 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound46021 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,35,16401,23669,1024,21761,4161,21793,16,21762,349,65,2421,5221,17664,2421,1056,21589,256,21588,16676,513]

theorem envBound46022 : H12AffineFastState.Bounded env46022 := by
  intro p hp
  have h : env46022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46021_46022 : H12AffineEnvironment.transform 15 35 env46021 = env46022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env46021 == env46022) = true)

theorem identity46022 : scanCanonicalize (H12AffineFastState.compose env46022 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound46022 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env46023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5236,372,35,5221,2049,1024,373,4161,341,16,374,349,65,2421,5221,4468,2421,1056,33,256,32,5456,513]

theorem envBound46023 : H12AffineFastState.Bounded env46023 := by
  intro p hp
  have h : env46023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46022_46023 : H12AffineEnvironment.transform 13 5236 env46022 = env46023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env46022 == env46023) = true)

theorem identity46023 : scanCanonicalize (H12AffineFastState.compose env46023 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 2420) := by decide +kernel

theorem selectedBound46023 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env46024 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2420,349,3328,372,35,3345,2049,1024,373,2357,341,16,374,349,65,2421,3345,2048,2421,1056,33,256,32,3108,513]

theorem envBound46024 : H12AffineFastState.Bounded env46024 := by
  intro p hp
  have h : env46024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46023_46024 : H12AffineEnvironment.transform 11 2420 env46023 = env46024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2420 env46023 == env46024) = true)

theorem identity46024 : scanCanonicalize (H12AffineFastState.compose env46024 (packedSelected [1,3,4,5,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound46024 : packedSelected [1,3,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env46025 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,2420,349,2404,372,35,2421,2049,100,373,2357,341,16,374,349,65,2421,2421,2048,2421,68,33,256,32,2112,513]

theorem envBound46025 : H12AffineFastState.Bounded env46025 := by
  intro p hp
  have h : env46025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46024_46025 : H12AffineEnvironment.transform 9 100 env46024 = env46025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env46024 == env46025) = true)

theorem identity46025 : scanCanonicalize (H12AffineFastState.compose env46025 (packedSelected [4,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound46025 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env46026 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,2049,40,2065,1,35,2048,2049,100,0,2112,32,16,3,40,65,2048,2048,2048,2048,68,33,117,32,2112,513]

theorem envBound46026 : H12AffineFastState.Bounded env46026 := by
  intro p hp
  have h : env46026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46025_46026 : H12AffineEnvironment.transform 7 117 env46025 = env46026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env46025 == env46026) = true)

theorem identity46026 : scanCanonicalize (H12AffineFastState.compose env46026 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound46026 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46027 : List Nat := [2,4,8,16,32,0,8,53,512,36,2048,2049,40,2065,1,35,2048,2049,36,0,2048,32,16,3,40,1,2048,2048,2048,2048,4,33,53,32,2048,513]

theorem envBound46027 : H12AffineFastState.Bounded env46027 := by
  intro p hp
  have h : env46027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46026_46027 : H12AffineEnvironment.transform 5 0 env46026 = env46027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env46026 == env46027) = true)

theorem identity46027 : scanCanonicalize (H12AffineFastState.compose env46027 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound46027 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46028 : List Nat := [2,4,8,7,32,0,8,34,512,36,2048,2049,40,2054,1,35,2048,2049,36,0,2048,32,7,3,40,1,2048,2048,2048,2048,4,33,34,32,2048,513]

theorem envBound46028 : H12AffineFastState.Bounded env46028 := by
  intro p hp
  have h : env46028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46027_46028 : H12AffineEnvironment.transform 3 7 env46027 = env46028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env46027 == env46028) = true)

theorem identity46028 : scanCanonicalize (H12AffineFastState.compose env46028 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound46028 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env46029 : List Nat := [2,4,4,7,32,0,4,34,512,36,2048,2049,36,2054,1,35,2048,2049,36,0,2048,32,7,3,36,1,2048,2048,2048,2048,4,33,34,32,2048,513]

theorem envBound46029 : H12AffineFastState.Bounded env46029 := by
  intro p hp
  have h : env46029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46028_46029 : H12AffineEnvironment.transform 2 4 env46028 = env46029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env46028 == env46029) = true)

theorem identity46029 : scanCanonicalize (H12AffineFastState.compose env46029 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 36) := by decide +kernel

theorem selectedBound46029 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46030 : List Nat := [2,4,4,7,32,0,4,34,36,36,2048,2049,36,2054,1,35,2048,2049,36,0,2048,32,7,3,36,1,2048,2048,2048,2048,4,33,34,32,2048,37]

theorem envBound46030 : H12AffineFastState.Bounded env46030 := by
  intro p hp
  have h : env46030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46029_46030 : H12AffineEnvironment.transform 8 36 env46029 = env46030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 36 env46029 == env46030) = true)

def env46031 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,180272,16,21762,8193,65,245019,115015,17664,10281,119043,254011,256,98678,90202,63069]

theorem envBound46031 : H12AffineFastState.Bounded env46031 := by
  intro p hp
  have h : env46031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46017_46031 : H12AffineEnvironment.transform 6 9 env46017 = env46031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46017 == env46031) = true)

theorem identity46031 : scanCanonicalize (H12AffineFastState.compose env46031 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound46031 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46032 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4161,32,16,21762,8193,65,97547,115015,17664,10281,119043,73771,256,98678,90202,63069]

theorem envBound46032 : H12AffineFastState.Bounded env46032 := by
  intro p hp
  have h : env46032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46031_46032 : H12AffineEnvironment.transform 16 49168 env46031 = env46032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env46031 == env46032) = true)

theorem identity46032 : scanCanonicalize (H12AffineFastState.compose env46032 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound46032 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env46033 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,32768,65536,49168,2340,1024,32769,4161,32,16,21762,269,65,89095,115015,17664,2341,119043,65831,256,98678,82262,55121]

theorem envBound46033 : H12AffineFastState.Bounded env46033 := by
  intro p hp
  have h : env46033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46032_46033 : H12AffineEnvironment.transform 12 268 env46032 = env46033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env46032 == env46033) = true)

theorem identity46033 : scanCanonicalize (H12AffineFastState.compose env46033 (packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound46033 : packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env46034 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,32768,65536,38161,2340,1024,32769,4161,32,16,3,269,65,67846,103494,4097,2341,99330,65831,256,98678,70743,33360]

theorem envBound46034 : H12AffineFastState.Bounded env46034 := by
  intro p hp
  have h : env46034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46033_46034 : H12AffineEnvironment.transform 13 5377 env46033 = env46034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46033 == env46034) = true)

theorem identity46034 : scanCanonicalize (H12AffineFastState.compose env46034 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound46034 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env46035 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,1,65536,5392,2340,1024,0,4161,32,16,3,269,65,67846,70727,4097,2341,66563,65831,256,65911,70743,593]

theorem envBound46035 : H12AffineFastState.Bounded env46035 := by
  intro p hp
  have h : env46035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46034_46035 : H12AffineEnvironment.transform 14 1 env46034 = env46035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env46034 == env46035) = true)

theorem identity46035 : scanCanonicalize (H12AffineFastState.compose env46035 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound46035 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env46036 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,268,3392,1,65536,3409,2340,1024,0,2048,32,16,3,269,65,67846,68614,2112,2341,66563,65831,256,65911,68630,593]

theorem envBound46036 : H12AffineFastState.Bounded env46036 := by
  intro p hp
  have h : env46036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46035_46036 : H12AffineEnvironment.transform 11 2113 env46035 = env46036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env46035 == env46036) = true)

theorem identity46036 : scanCanonicalize (H12AffineFastState.compose env46036 (packedSelected [0,4,7,9,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound46036 : packedSelected [0,4,7,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env46037 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,268,3392,1,262,3409,2340,1024,0,2048,32,16,3,269,65,2048,3328,2112,2341,1285,33,256,113,3344,593]

theorem envBound46037 : H12AffineFastState.Bounded env46037 := by
  intro p hp
  have h : env46037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46036_46037 : H12AffineEnvironment.transform 15 262 env46036 = env46037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env46036 == env46037) = true)

theorem identity46037 : scanCanonicalize (H12AffineFastState.compose env46037 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 596) := by decide +kernel

theorem selectedBound46037 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env46038 : List Nat := [2,4,8,16,32,64,9,256,512,596,2048,2113,268,2836,1,262,2821,2340,596,0,2048,32,16,3,269,65,2048,2900,2112,2341,849,33,256,113,2884,593]

theorem envBound46038 : H12AffineFastState.Bounded env46038 := by
  intro p hp
  have h : env46038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46037_46038 : H12AffineEnvironment.transform 9 596 env46037 = env46038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 596 env46037 == env46038) = true)

theorem identity46038 : scanCanonicalize (H12AffineFastState.compose env46038 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound46038 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env46039 : List Nat := [2,4,8,16,32,64,9,21,512,596,2048,2113,25,2561,1,19,2576,2097,596,0,2048,32,16,3,24,65,2048,2625,2112,2096,580,33,21,113,2641,593]

theorem envBound46039 : H12AffineFastState.Bounded env46039 := by
  intro p hp
  have h : env46039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46038_46039 : H12AffineEnvironment.transform 7 21 env46038 = env46039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env46038 == env46039) = true)

theorem identity46039 : scanCanonicalize (H12AffineFastState.compose env46039 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound46039 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env46040 : List Nat := [2,4,8,16,32,33,9,21,512,565,2048,2080,25,2561,1,19,2576,2097,565,0,2048,32,16,3,24,32,2048,2592,2081,2096,549,33,21,16,2608,560]

theorem envBound46040 : H12AffineFastState.Bounded env46040 := by
  intro p hp
  have h : env46040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46039_46040 : H12AffineEnvironment.transform 5 33 env46039 = env46040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env46039 == env46040) = true)

theorem identity46040 : scanCanonicalize (H12AffineFastState.compose env46040 (packedSelected [3,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46040 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env46041 : List Nat := [2,4,8,0,32,33,9,5,512,549,2048,2080,9,2561,1,3,2560,2081,549,0,2048,32,0,3,8,32,2048,2592,2081,2080,549,33,5,0,2592,544]

theorem envBound46041 : H12AffineFastState.Bounded env46041 := by
  intro p hp
  have h : env46041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46040_46041 : H12AffineEnvironment.transform 3 0 env46040 = env46041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46040 == env46041) = true)

theorem identity46041 : scanCanonicalize (H12AffineFastState.compose env46041 (packedSelected [0,7,12] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound46041 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env46042 : List Nat := [2,4,8,0,32,33,9,5,512,549,512,544,9,1,1,3,0,545,549,0,512,32,0,3,8,32,512,32,545,544,549,33,5,0,32,544]

theorem envBound46042 : H12AffineFastState.Bounded env46042 := by
  intro p hp
  have h : env46042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46041_46042 : H12AffineEnvironment.transform 10 512 env46041 = env46042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env46041 == env46042) = true)

def env46043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,452769,441778,8328,65,4691218,115150,17665,10400,119042,4268162,256,485710,493803,63189]

theorem envBound46043 : H12AffineFastState.Bounded env46043 := by
  intro p hp
  have h : env46043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45961_46043 : H12AffineEnvironment.transform 20 456945 env45961 = env46043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456945 env45961 == env46043) = true)

def env46044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272512,452769,441778,8328,65,245138,115150,17665,10400,119042,329730,256,485710,493803,63189]

theorem envBound46044 : H12AffineFastState.Bounded env46044 := by
  intro p hp
  have h : env46044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46043_46044 : H12AffineEnvironment.transform 21 272512 env46043 = env46044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46043 == env46044) = true)

theorem identity46044 : scanCanonicalize (H12AffineFastState.compose env46044 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound46044 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,396325,272512,400501,412006,8328,65,215366,79130,17665,10400,75222,329730,256,485710,490559,513]

theorem envBound46045 : H12AffineFastState.Bounded env46045 := by
  intro p hp
  have h : env46045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46044_46045 : H12AffineEnvironment.transform 14 29908 env46044 = env46045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env46044 == env46045) = true)

def env46046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,396325,272392,400501,412006,8192,65,215366,79130,17665,10280,75102,329730,256,485710,490559,513]

theorem envBound46046 : H12AffineFastState.Bounded env46046 := by
  intro p hp
  have h : env46046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46045_46046 : H12AffineEnvironment.transform 6 8 env46045 = env46046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46045 == env46046) = true)

theorem identity46046 : scanCanonicalize (H12AffineFastState.compose env46046 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound46046 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env46047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1024,29789,355390,272392,359534,338301,8192,65,10589,79130,17665,10280,75102,329730,256,264533,269348,513]

theorem envBound46047 : H12AffineFastState.Bounded env46047 := by
  intro p hp
  have h : env46047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46046_46047 : H12AffineEnvironment.transform 16 90139 env46046 = env46047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env46046 == env46047) = true)

theorem identity46047 : scanCanonicalize (H12AffineFastState.compose env46047 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound46047 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env46048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,97327,1024,29789,4113,87079,65,21842,8192,65,10589,79130,17665,10280,75102,29741,256,95610,90123,513]

theorem envBound46048 : H12AffineFastState.Bounded env46048 := by
  intro p hp
  have h : env46048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46047_46048 : H12AffineEnvironment.transform 17 97327 env46047 = env46048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env46047 == env46048) = true)

theorem identity46048 : scanCanonicalize (H12AffineFastState.compose env46048 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound46048 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env46049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,65536,70726,67698,1024,0,4113,73850,65,8463,8192,65,10589,79130,12636,10280,75102,112,256,65831,70742,513]

theorem envBound46049 : H12AffineFastState.Bounded env46049 := by
  intro p hp
  have h : env46049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46048_46049 : H12AffineEnvironment.transform 13 13405 env46048 = env46049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env46048 == env46049) = true)

theorem identity46049 : scanCanonicalize (H12AffineFastState.compose env46049 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46049 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env46050 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1,65536,70678,67618,1024,0,4113,73770,17,8463,8192,17,10509,79130,12556,10280,75022,32,256,65831,70662,513]

theorem envBound46050 : H12AffineFastState.Bounded env46050 := by
  intro p hp
  have h : env46050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46049_46050 : H12AffineEnvironment.transform 5 16 env46049 = env46050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46049 == env46050) = true)

theorem identity46050 : scanCanonicalize (H12AffineFastState.compose env46050 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46050 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46051 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,1,65536,70678,67618,1024,0,4113,65831,17,2,269,17,2048,70679,4097,2341,66563,32,256,65831,70662,513]

theorem envBound46051 : H12AffineFastState.Bounded env46051 := by
  intro p hp
  have h : env46051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46050_46051 : H12AffineEnvironment.transform 12 269 env46050 = env46051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46050 == env46051) = true)

theorem identity46051 : scanCanonicalize (H12AffineFastState.compose env46051 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(15+1) ^^^ 7175) := by decide +kernel

theorem selectedBound46051 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env46052 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,1,7175,2065,5157,1024,0,4113,7456,17,2,269,17,2048,2064,4097,2341,6148,32,256,7456,2049,513]

theorem envBound46052 : H12AffineFastState.Bounded env46052 := by
  intro p hp
  have h : env46052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46051_46052 : H12AffineEnvironment.transform 15 7175 env46051 = env46052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7175 env46051 == env46052) = true)

theorem identity46052 : scanCanonicalize (H12AffineFastState.compose env46052 (packedSelected [4,5,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound46052 : packedSelected [4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env46053 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,4112,1,6423,2065,4405,272,0,4113,6192,17,2,269,17,2048,2064,4097,2341,6148,32,256,6192,2049,513]

theorem envBound46053 : H12AffineFastState.Bounded env46053 := by
  intro p hp
  have h : env46053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46052_46053 : H12AffineEnvironment.transform 9 272 env46052 = env46053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env46052 == env46053) = true)

theorem identity46053 : scanCanonicalize (H12AffineFastState.compose env46053 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound46053 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env46054 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2065,269,2049,1,262,2065,2340,272,0,2048,33,17,2,269,17,2048,2064,2064,2341,21,32,256,33,2049,513]

theorem envBound46054 : H12AffineFastState.Bounded env46054 := by
  intro p hp
  have h : env46054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46053_46054 : H12AffineEnvironment.transform 11 2065 env46053 = env46054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env46053 == env46054) = true)

theorem identity46054 : scanCanonicalize (H12AffineFastState.compose env46054 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound46054 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46055 : List Nat := [2,4,8,16,17,16,8,256,512,272,2048,2065,269,2049,1,262,2065,2325,272,0,2048,16,17,2,269,17,2048,2064,2064,2324,21,17,256,16,2049,513]

theorem envBound46055 : H12AffineFastState.Bounded env46055 := by
  intro p hp
  have h : env46055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46054_46055 : H12AffineEnvironment.transform 4 17 env46054 = env46055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env46054 == env46055) = true)

theorem identity46055 : scanCanonicalize (H12AffineFastState.compose env46055 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound46055 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46056 : List Nat := [2,4,8,16,17,16,8,256,512,272,788,773,269,789,1,262,773,513,272,0,788,16,17,2,269,17,788,772,772,512,21,17,256,16,789,513]

theorem envBound46056 : H12AffineFastState.Bounded env46056 := by
  intro p hp
  have h : env46056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46055_46056 : H12AffineEnvironment.transform 10 788 env46055 = env46056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env46055 == env46056) = true)

theorem identity46056 : scanCanonicalize (H12AffineFastState.compose env46056 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound46056 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46057 : List Nat := [2,4,8,16,17,16,8,256,276,272,0,17,269,1,1,262,17,277,272,0,0,16,17,2,269,17,0,16,16,276,21,17,256,16,1,277]

theorem envBound46057 : H12AffineFastState.Bounded env46057 := by
  intro p hp
  have h : env46057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46056_46057 : H12AffineEnvironment.transform 8 276 env46056 = env46057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env46056 == env46057) = true)

theorem identity46057 : scanCanonicalize (H12AffineFastState.compose env46057 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound46057 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46058 : List Nat := [2,4,8,16,17,16,8,5,17,21,0,17,8,1,1,3,17,16,21,0,0,16,17,2,8,17,0,16,16,17,21,17,5,16,1,16]

theorem envBound46058 : H12AffineFastState.Bounded env46058 := by
  intro p hp
  have h : env46058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46057_46058 : H12AffineEnvironment.transform 7 5 env46057 = env46058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env46057 == env46058) = true)

theorem identity46058 : scanCanonicalize (H12AffineFastState.compose env46058 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46058 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46059 : List Nat := [2,4,8,11,10,11,8,5,10,14,0,10,8,1,1,3,10,11,14,0,0,11,10,2,8,10,0,11,11,10,14,10,5,11,1,11]

theorem envBound46059 : H12AffineFastState.Bounded env46059 := by
  intro p hp
  have h : env46059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46058_46059 : H12AffineEnvironment.transform 3 11 env46058 = env46059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46058 == env46059) = true)

def env46060 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,396325,272393,400501,412006,8193,65,215366,79130,17665,10281,75103,329730,256,485710,490559,513]

theorem envBound46060 : H12AffineFastState.Bounded env46060 := by
  intro p hp
  have h : env46060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46045_46060 : H12AffineEnvironment.transform 6 9 env46045 = env46060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46045 == env46060) = true)

theorem identity46060 : scanCanonicalize (H12AffineFastState.compose env46060 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound46060 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env46061 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1024,29788,140301,33,144477,155982,8193,65,215366,79130,17665,10281,75103,73770,256,213350,218135,513]

theorem envBound46061 : H12AffineFastState.Bounded env46061 := by
  intro p hp
  have h : env46061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46060_46061 : H12AffineEnvironment.transform 17 10280 env46060 = env46061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env46060 == env46061) = true)

theorem identity46061 : scanCanonicalize (H12AffineFastState.compose env46061 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound46061 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env46062 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,5393,10280,1024,29788,12572,33,8524,29791,8193,65,89175,79130,17665,10281,75103,73770,256,87159,82182,513]

theorem envBound46062 : H12AffineFastState.Bounded env46062 := by
  intro p hp
  have h : env46062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46061_46062 : H12AffineEnvironment.transform 16 5393 env46061 = env46062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env46061 == env46062) = true)

theorem identity46062 : scanCanonicalize (H12AffineFastState.compose env46062 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46062 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env46063 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,65536,5393,2341,1024,21841,4113,33,65,21842,268,65,89175,70679,17665,2340,66642,65831,256,87159,82182,513]

theorem envBound46063 : H12AffineFastState.Bounded env46063 := by
  intro p hp
  have h : env46063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46062_46063 : H12AffineEnvironment.transform 12 269 env46062 = env46063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46062 == env46063) = true)

theorem identity46063 : scanCanonicalize (H12AffineFastState.compose env46063 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound46063 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env46064 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,21591,5393,2341,1024,21841,4113,33,65,21842,268,65,2048,16448,17665,2340,20485,21872,256,32,5457,513]

theorem envBound46064 : H12AffineFastState.Bounded env46064 := by
  intro p hp
  have h : env46064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46063_46064 : H12AffineEnvironment.transform 15 21591 env46063 = env46064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env46063 == env46064) = true)

def env46065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272513,452769,441778,8328,65,245139,115150,17665,10400,119042,329731,256,485710,493803,63189]

theorem envBound46065 : H12AffineFastState.Bounded env46065 := by
  intro p hp
  have h : env46065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46043_46065 : H12AffineEnvironment.transform 21 272513 env46043 = env46065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46043 == env46065) = true)

theorem identity46065 : scanCanonicalize (H12AffineFastState.compose env46065 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound46065 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,58516,144612,62660,41431,8328,65,245139,115150,17665,10400,119042,201830,256,95531,103566,63189]

theorem envBound46066 : H12AffineFastState.Bounded env46066 := by
  intro p hp
  have h : env46066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46065_46066 : H12AffineEnvironment.transform 17 138341 env46065 = env46066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env46065 == env46066) = true)

def env46067 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,58396,144492,62540,41311,8192,65,245019,115014,17665,10280,119042,201830,256,95531,103430,63069]

theorem envBound46067 : H12AffineFastState.Bounded env46067 := by
  intro p hp
  have h : env46067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46066_46067 : H12AffineEnvironment.transform 6 8 env46066 = env46067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46066 == env46067) = true)

theorem identity46067 : scanCanonicalize (H12AffineFastState.compose env46067 (packedSelected [0,4,8,10,11,12,14,15,16,22,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound46067 : packedSelected [0,4,8,10,11,12,14,15,16,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env46068 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,114,131072,138341,1024,32769,58396,144492,62540,41311,8192,65,179561,49460,17665,10280,53616,136212,256,30041,38004,63069]

theorem envBound46068 : H12AffineFastState.Bounded env46068 := by
  intro p hp
  have h : env46068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46067_46068 : H12AffineEnvironment.transform 15 114 env46067 = env46068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env46067 == env46068) = true)

theorem identity46068 : scanCanonicalize (H12AffineFastState.compose env46068 (packedSelected [1,3,4,9,10,18,19,20,23,24,26,28,31,35] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46068 : packedSelected [1,3,4,9,10,18,19,20,23,24,26,28,31,35] rootPS < 2^1333 := by decide +kernel

def env46069 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,35,131072,138292,1024,32769,58396,144445,62493,41230,8192,16,179512,49460,17665,10280,53537,136212,256,29960,37925,62988]

theorem envBound46069 : H12AffineFastState.Bounded env46069 := by
  intro p hp
  have h : env46069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46068_46069 : H12AffineEnvironment.transform 5 17 env46068 = env46069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46068 == env46069) = true)

theorem identity46069 : scanCanonicalize (H12AffineFastState.compose env46069 (packedSelected [0,7,9,14,17,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46069 : packedSelected [0,7,9,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env46070 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,35,131072,138292,1024,32769,58396,144445,62493,41003,8192,16,179229,49169,17444,10280,53252,136212,37,29741,37925,62988]

theorem envBound46070 : H12AffineFastState.Bounded env46070 := by
  intro p hp
  have h : env46070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46069_46070 : H12AffineEnvironment.transform 7 37 env46069 = env46070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46069 == env46070) = true)

theorem identity46070 : scanCanonicalize (H12AffineFastState.compose env46070 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 24632) := by decide +kernel

theorem selectedBound46070 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env46071 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,35,24632,31756,1024,32769,58396,21509,62493,41003,8192,16,56357,49169,17444,10280,53252,29740,37,29741,37925,62988]

theorem envBound46071 : H12AffineFastState.Bounded env46071 := by
  intro p hp
  have h : env46071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46070_46071 : H12AffineEnvironment.transform 16 24632 env46070 = env46071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24632 env46070 == env46071) = true)

theorem identity46071 : scanCanonicalize (H12AffineFastState.compose env46071 (packedSelected [0,4,7,9,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound46071 : packedSelected [0,4,7,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env46072 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,8232,35,24632,31756,1024,8233,17460,21509,21557,3,8192,16,31757,24633,17444,10280,28716,29740,37,29741,13325,22052]

theorem envBound46072 : H12AffineFastState.Bounded env46072 := by
  intro p hp
  have h : env46072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46071_46072 : H12AffineEnvironment.transform 14 8232 env46071 = env46072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env46071 == env46072) = true)

theorem identity46072 : scanCanonicalize (H12AffineFastState.compose env46072 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound46072 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46073 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,13325,8232,35,5173,2049,1024,8233,12345,8200,8248,3,8192,16,2048,5172,12329,10280,1057,33,37,32,13325,8745]

theorem envBound46073 : H12AffineFastState.Bounded env46073 := by
  intro p hp
  have h : env46073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46072_46073 : H12AffineEnvironment.transform 13 13325 env46072 = env46073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env46072 == env46073) = true)

theorem identity46073 : scanCanonicalize (H12AffineFastState.compose env46073 (packedSelected [3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound46073 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env46074 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,2065,8192,11292,8232,35,3108,2049,1024,8233,10280,8200,8248,3,8192,16,2048,3109,10296,10280,1057,33,37,32,11292,8745]

theorem envBound46074 : H12AffineFastState.Bounded env46074 := by
  intro p hp
  have h : env46074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46073_46074 : H12AffineEnvironment.transform 11 2065 env46073 = env46074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env46073 == env46074) = true)

theorem identity46074 : scanCanonicalize (H12AffineFastState.compose env46074 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound46074 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46075 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,2065,41,3125,1,35,3108,2049,1024,0,2049,33,17,3,41,16,2048,3109,2065,2049,1057,33,37,32,3125,512]

theorem envBound46075 : H12AffineFastState.Bounded env46075 := by
  intro p hp
  have h : env46075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46074_46075 : H12AffineEnvironment.transform 12 41 env46074 = env46075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env46074 == env46075) = true)

theorem identity46075 : scanCanonicalize (H12AffineFastState.compose env46075 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound46075 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46076 : List Nat := [2,4,8,16,32,17,8,37,512,1024,16,1,41,1061,1,35,1076,17,1024,0,17,33,17,3,41,16,16,1077,1,17,1057,33,37,32,1061,512]

theorem envBound46076 : H12AffineFastState.Bounded env46076 := by
  intro p hp
  have h : env46076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46075_46076 : H12AffineEnvironment.transform 10 16 env46075 = env46076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env46075 == env46076) = true)

theorem identity46076 : scanCanonicalize (H12AffineFastState.compose env46076 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound46076 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46077 : List Nat := [2,4,8,16,32,17,8,37,512,14,16,1,41,43,1,35,58,17,14,0,17,33,17,3,41,16,16,59,1,17,47,33,37,32,43,512]

theorem envBound46077 : H12AffineFastState.Bounded env46077 := by
  intro p hp
  have h : env46077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46076_46077 : H12AffineEnvironment.transform 9 14 env46076 = env46077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env46076 == env46077) = true)

theorem identity46077 : scanCanonicalize (H12AffineFastState.compose env46077 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound46077 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46078 : List Nat := [2,4,8,16,32,17,8,37,59,14,16,1,41,43,1,35,58,17,14,0,17,33,17,3,41,16,16,59,1,17,47,33,37,32,43,59]

theorem envBound46078 : H12AffineFastState.Bounded env46078 := by
  intro p hp
  have h : env46078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46077_46078 : H12AffineEnvironment.transform 8 59 env46077 = env46078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env46077 == env46078) = true)

theorem identity46078 : scanCanonicalize (H12AffineFastState.compose env46078 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46078 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46079 : List Nat := [2,4,8,16,0,17,8,5,27,14,16,1,9,11,1,3,26,17,14,0,17,1,17,3,9,16,16,27,1,17,15,1,5,0,11,27]

theorem envBound46079 : H12AffineFastState.Bounded env46079 := by
  intro p hp
  have h : env46079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46078_46079 : H12AffineEnvironment.transform 4 0 env46078 = env46079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46078 == env46079) = true)

theorem identity46079 : scanCanonicalize (H12AffineFastState.compose env46079 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound46079 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46080 : List Nat := [2,4,8,3,0,2,8,5,8,14,3,1,9,11,1,3,9,2,14,0,2,1,2,3,9,3,3,8,1,2,15,1,5,0,11,8]

theorem envBound46080 : H12AffineFastState.Bounded env46080 := by
  intro p hp
  have h : env46080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46079_46080 : H12AffineEnvironment.transform 3 3 env46079 = env46080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env46079 == env46080) = true)

def env46081 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,58397,144493,62541,41310,8193,65,245018,115015,17665,10281,119042,201830,256,95531,103431,63068]

theorem envBound46081 : H12AffineFastState.Bounded env46081 := by
  intro p hp
  have h : env46081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46066_46081 : H12AffineEnvironment.transform 6 9 env46066 = env46081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46066 == env46081) = true)

theorem identity46081 : scanCanonicalize (H12AffineFastState.compose env46081 (packedSelected [0,4,8,10,11,12,14,15,16,22,27,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound46081 : packedSelected [0,4,8,10,11,12,14,15,16,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env46082 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,65536,131072,138341,1024,81,25677,144493,29725,8462,8193,65,212298,82199,17665,10281,86354,201830,256,95531,70743,30220]

theorem envBound46082 : H12AffineFastState.Bounded env46082 := by
  intro p hp
  have h : env46082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46081_46082 : H12AffineEnvironment.transform 14 80 env46081 = env46082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env46081 == env46082) = true)

theorem identity46082 : scanCanonicalize (H12AffineFastState.compose env46082 (packedSelected [0,1,3,4,8,10,12,14,15,20,22,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound46082 : packedSelected [0,1,3,4,8,10,12,14,15,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env46083 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,65536,16400,23669,1024,81,25677,29821,29725,8462,8193,65,97626,82199,17665,10281,86354,87158,256,95531,70743,30220]

theorem envBound46083 : H12AffineFastState.Bounded env46083 := by
  intro p hp
  have h : env46083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46082_46083 : H12AffineEnvironment.transform 16 16400 env46082 = env46083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env46082 == env46083) = true)

theorem identity46083 : scanCanonicalize (H12AffineFastState.compose env46083 (packedSelected [0,3,5,7,9,10,12,14,15,16,17,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46083 : packedSelected [0,3,5,7,9,10,12,14,15,16,17,22] rootPS < 2^1333 := by decide +kernel

def env46084 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,80,65536,16400,23669,1024,81,17728,21872,21776,3,268,65,89175,82199,17665,2340,86354,87158,256,87078,70743,22273]

theorem envBound46084 : H12AffineFastState.Bounded env46084 := by
  intro p hp
  have h : env46084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46083_46084 : H12AffineEnvironment.transform 12 269 env46083 = env46084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46083 == env46084) = true)

theorem identity46084 : scanCanonicalize (H12AffineFastState.compose env46084 (packedSelected [1,3,5,8,14,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 6471) := by decide +kernel

theorem selectedBound46084 : packedSelected [1,3,5,8,14,16,17] rootPS < 2^1333 := by decide +kernel

def env46085 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,80,6471,16400,23669,1024,81,17728,21872,21776,3,268,65,17680,22608,17665,2340,18453,19761,256,19809,3344,22273]

theorem envBound46085 : H12AffineFastState.Bounded env46085 := by
  intro p hp
  have h : env46085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46084_46085 : H12AffineEnvironment.transform 15 6471 env46084 = env46085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6471 env46084 == env46085) = true)

theorem identity46085 : scanCanonicalize (H12AffineFastState.compose env46085 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 3344) := by decide +kernel

theorem selectedBound46085 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env46086 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,3344,80,6471,3328,4453,1024,81,2128,6240,6144,3,268,65,2048,5440,2065,2340,1285,33,256,113,3344,6673]

theorem envBound46086 : H12AffineFastState.Bounded env46086 := by
  intro p hp
  have h : env46086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46085_46086 : H12AffineEnvironment.transform 13 3344 env46085 = env46086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3344 env46085 == env46086) = true)

theorem identity46086 : scanCanonicalize (H12AffineFastState.compose env46086 (packedSelected [1,2,6,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound46086 : packedSelected [1,2,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46087 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1360,269,3344,80,3095,3328,1077,1024,81,2128,3376,3408,3,268,65,2048,16,2065,2340,1285,33,256,113,3344,3905]

theorem envBound46087 : H12AffineFastState.Bounded env46087 := by
  intro p hp
  have h : env46087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46086_46087 : H12AffineEnvironment.transform 11 1360 env46086 = env46087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env46086 == env46087) = true)

def env46088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound46088 : H12AffineFastState.Bounded env46088 := by
  intro p hp
  have h : env46088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45854_46088 : H12AffineEnvironment.transform 18 1025 env45854 = env46088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env45854 == env46088) = true)

theorem identity46088 : scanCanonicalize (H12AffineFastState.compose env46088 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 347491) := by decide +kernel

theorem selectedBound46088 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347491,4194304,8388608,16777216,8328,65,29868032,17091055,8722482,8830976,25265169,21244066,257,25463246,25454698,25207751]

theorem envBound46089 : H12AffineFastState.Bounded env46089 := by
  intro p hp
  have h : env46089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46088_46089 : H12AffineEnvironment.transform 20 347491 env46088 = env46089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 347491 env46088 == env46089) = true)

def env46090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347491,4194304,8388608,392436,8328,65,12729588,79131,8722482,8830976,8681701,4314198,257,8484154,8492190,8740659]

theorem envBound46090 : H12AffineFastState.Bounded env46090 := by
  intro p hp
  have h : env46090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46089_46090 : H12AffineEnvironment.transform 23 392436 env46089 = env46090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392436 env46089 == env46090) = true)

def env46091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,8388608,98780,8328,65,12729588,79131,8480026,8568104,8390093,4314198,257,8484154,8492190,8462875]

theorem envBound46091 : H12AffineFastState.Bounded env46091 := by
  intro p hp
  have h : env46091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46090_46091 : H12AffineEnvironment.transform 17 32040 env46090 = env46091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env46090 == env46091) = true)

def env46092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,16,98780,8328,65,4340964,79131,91402,179512,1501,4314198,257,95530,103566,74251]

theorem envBound46092 : H12AffineFastState.Bounded env46092 := by
  intro p hp
  have h : env46092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46091_46092 : H12AffineEnvironment.transform 22 16 env46091 = env46092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env46091 == env46092) = true)

theorem identity46092 : scanCanonicalize (H12AffineFastState.compose env46092 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 95650) := by decide +kernel

theorem selectedBound46092 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,95650,16,98780,8328,65,215366,79131,91402,179512,1501,41460,257,95530,103566,74251]

theorem envBound46093 : H12AffineFastState.Bounded env46093 := by
  intro p hp
  have h : env46093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46092_46093 : H12AffineEnvironment.transform 21 95650 env46092 = env46093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95650 env46092 == env46093) = true)

def env46094 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,95530,16,98644,8192,65,215366,79131,91402,179512,1365,41340,257,95530,103430,74251]

theorem envBound46094 : H12AffineFastState.Bounded env46094 := by
  intro p hp
  have h : env46094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46093_46094 : H12AffineEnvironment.transform 6 8 env46093 = env46094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46093 == env46094) = true)

theorem identity46094 : scanCanonicalize (H12AffineFastState.compose env46094 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound46094 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46095 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1025,32769,77899,73770,16,98644,8192,65,203846,79131,77834,179512,1365,41340,257,73770,103430,74251]

theorem envBound46095 : H12AffineFastState.Bounded env46095 := by
  intro p hp
  have h : env46095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46094_46095 : H12AffineEnvironment.transform 13 5376 env46094 = env46095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46094 == env46095) = true)

theorem identity46095 : scanCanonicalize (H12AffineFastState.compose env46095 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46095 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env46096 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,10280,1025,32769,4160,33,16,41311,8192,65,146509,5392,4097,179512,1365,41340,257,33,46093,512]

theorem envBound46096 : H12AffineFastState.Bounded env46096 := by
  intro p hp
  have h : env46096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46095_46096 : H12AffineEnvironment.transform 15 8203 env46095 = env46096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46095 == env46096) = true)

theorem identity46096 : scanCanonicalize (H12AffineFastState.compose env46096 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound46096 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,5376,32768,1330,131072,3345,1025,32769,4160,33,16,33894,1337,65,137588,5392,4097,169985,1365,33861,257,33,37172,512]

theorem envBound46097 : H12AffineFastState.Bounded env46097 := by
  intro p hp
  have h : env46097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46096_46097 : H12AffineEnvironment.transform 12 1337 env46096 = env46097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env46096 == env46097) = true)

theorem identity46097 : scanCanonicalize (H12AffineFastState.compose env46097 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 4112) := by decide +kernel

theorem selectedBound46097 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env46098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,5376,4112,1330,131072,3345,1025,4113,4160,33,16,5238,1337,65,137588,5392,4097,133137,1365,5205,257,33,292,512]

theorem envBound46098 : H12AffineFastState.Bounded env46098 := by
  intro p hp
  have h : env46098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46097_46098 : H12AffineEnvironment.transform 14 4112 env46097 = env46098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4112 env46097 == env46098) = true)

theorem identity46098 : scanCanonicalize (H12AffineFastState.compose env46098 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound46098 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env46099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1281,1337,1,1297,1330,131072,3345,1025,1296,1345,33,16,375,1337,65,134261,17,1280,133137,1365,340,257,33,292,512]

theorem envBound46099 : H12AffineFastState.Bounded env46099 := by
  intro p hp
  have h : env46099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46098_46099 : H12AffineEnvironment.transform 11 1281 env46098 = env46099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env46098 == env46099) = true)

theorem identity46099 : scanCanonicalize (H12AffineFastState.compose env46099 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound46099 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,372,1281,1337,1,1297,1330,131072,1125,1025,1296,1345,33,16,375,1337,65,132353,17,1280,131429,1365,340,257,33,292,512]

theorem envBound46100 : H12AffineFastState.Bounded env46100 := by
  intro p hp
  have h : env46100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46099_46100 : H12AffineEnvironment.transform 10 372 env46099 = env46100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env46099 == env46100) = true)

theorem identity46100 : scanCanonicalize (H12AffineFastState.compose env46100 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound46100 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env46101 : List Nat := [2,4,8,16,32,64,8,256,512,273,372,16,40,1,0,35,131072,372,272,1,80,33,16,375,40,65,131088,17,17,131429,68,340,257,33,292,512]

theorem envBound46101 : H12AffineFastState.Bounded env46101 := by
  intro p hp
  have h : env46101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46100_46101 : H12AffineEnvironment.transform 9 273 env46100 = env46101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46100 == env46101) = true)

theorem identity46101 : scanCanonicalize (H12AffineFastState.compose env46101 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound46101 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46102 : List Nat := [2,4,8,16,32,64,8,85,512,68,33,16,40,1,0,35,131072,33,69,1,80,33,16,34,40,65,131088,17,17,131120,68,1,84,33,113,512]

theorem envBound46102 : H12AffineFastState.Bounded env46102 := by
  intro p hp
  have h : env46102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46101_46102 : H12AffineEnvironment.transform 7 85 env46101 = env46102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env46101 == env46102) = true)

theorem identity46102 : scanCanonicalize (H12AffineFastState.compose env46102 (packedSelected [4,6,7] rootPS)) = affineNative (2^(16+1) ^^^ 48) := by decide +kernel

theorem selectedBound46102 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env46103 : List Nat := [2,4,8,16,32,64,8,85,512,68,33,16,40,1,0,35,48,33,69,1,80,33,16,34,40,65,32,17,17,0,68,1,84,33,113,512]

theorem envBound46103 : H12AffineFastState.Bounded env46103 := by
  intro p hp
  have h : env46103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46102_46103 : H12AffineEnvironment.transform 16 48 env46102 = env46103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 48 env46102 == env46103) = true)

theorem identity46103 : scanCanonicalize (H12AffineFastState.compose env46103 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46103 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env46104 : List Nat := [2,4,8,16,32,17,8,4,512,21,33,16,40,1,0,35,48,33,20,1,1,33,16,34,40,16,32,17,17,0,21,1,5,33,32,512]

theorem envBound46104 : H12AffineFastState.Bounded env46104 := by
  intro p hp
  have h : env46104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46103_46104 : H12AffineEnvironment.transform 5 17 env46103 = env46104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46103 == env46104) = true)

theorem identity46104 : scanCanonicalize (H12AffineFastState.compose env46104 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46104 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46105 : List Nat := [2,4,8,16,1,17,8,4,512,21,0,16,9,1,0,2,17,0,20,1,1,0,16,3,9,16,1,17,17,0,21,1,5,0,1,512]

theorem envBound46105 : H12AffineFastState.Bounded env46105 := by
  intro p hp
  have h : env46105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46104_46105 : H12AffineEnvironment.transform 4 1 env46104 = env46105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46104 == env46105) = true)

theorem identity46105 : scanCanonicalize (H12AffineFastState.compose env46105 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound46105 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46106 : List Nat := [2,4,8,16,1,17,8,4,4,21,0,16,9,1,0,2,17,0,20,1,1,0,16,3,9,16,1,17,17,0,21,1,5,0,1,4]

theorem envBound46106 : H12AffineFastState.Bounded env46106 := by
  intro p hp
  have h : env46106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46105_46106 : H12AffineEnvironment.transform 8 4 env46105 = env46106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env46105 == env46106) = true)

theorem identity46106 : scanCanonicalize (H12AffineFastState.compose env46106 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound46106 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46107 : List Nat := [2,4,0,16,1,17,0,4,4,21,0,16,1,1,0,2,17,0,20,1,1,0,16,3,1,16,1,17,17,0,21,1,5,0,1,4]

theorem envBound46107 : H12AffineFastState.Bounded env46107 := by
  intro p hp
  have h : env46107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46106_46107 : H12AffineEnvironment.transform 2 0 env46106 = env46107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env46106 == env46107) = true)

theorem identity46107 : scanCanonicalize (H12AffineFastState.compose env46107 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound46107 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46108 : List Nat := [2,3,0,16,1,17,0,3,3,18,0,16,1,1,0,2,17,0,19,1,1,0,16,3,1,16,1,17,17,0,18,1,2,0,1,3]

theorem envBound46108 : H12AffineFastState.Bounded env46108 := by
  intro p hp
  have h : env46108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46107_46108 : H12AffineEnvironment.transform 1 3 env46107 = env46108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env46107 == env46108) = true)

def env46109 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,95531,16,98645,8193,65,215366,79131,91402,179512,1364,41341,257,95530,103431,74251]

theorem envBound46109 : H12AffineFastState.Bounded env46109 := by
  intro p hp
  have h : env46109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46093_46109 : H12AffineEnvironment.transform 6 9 env46093 = env46109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46093 == env46109) = true)

theorem identity46109 : scanCanonicalize (H12AffineFastState.compose env46109 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound46109 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46110 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32040,1025,29789,77899,95531,16,95497,8193,65,215366,79131,91402,149860,1364,21793,257,95530,90203,74251]

theorem envBound46110 : H12AffineFastState.Bounded env46110 := by
  intro p hp
  have h : env46110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46109_46110 : H12AffineEnvironment.transform 14 29788 env46109 = env46110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env46109 == env46110) = true)

theorem identity46110 : scanCanonicalize (H12AffineFastState.compose env46110 (packedSelected [0,2,4,7,11,14,16,18,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46110 : packedSelected [0,2,4,7,11,14,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env46111 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32040,1025,29789,4160,21792,16,21762,8193,65,158029,5392,17665,149860,1364,21793,257,21793,16464,512]

theorem envBound46111 : H12AffineFastState.Bounded env46111 := by
  intro p hp
  have h : env46111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46110_46111 : H12AffineEnvironment.transform 15 8203 env46110 = env46111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46110 == env46111) = true)

theorem identity46111 : scanCanonicalize (H12AffineFastState.compose env46111 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound46111 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46112 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,372,8203,131072,2048,1025,373,4160,8200,16,8234,8193,65,138341,5392,12329,146508,1364,8201,257,8201,13688,512]

theorem envBound46112 : H12AffineFastState.Bounded env46112 := by
  intro p hp
  have h : env46112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46111_46112 : H12AffineEnvironment.transform 13 13608 env46111 = env46112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env46111 == env46112) = true)

theorem identity46112 : scanCanonicalize (H12AffineFastState.compose env46112 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46112 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46113 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5157,372,262,131072,2048,1025,373,4160,261,16,295,268,65,138341,5392,4388,138561,1364,260,257,260,5237,512]

theorem envBound46113 : H12AffineFastState.Bounded env46113 := by
  intro p hp
  have h : env46113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46112_46113 : H12AffineEnvironment.transform 12 269 env46112 = env46113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46112 == env46113) = true)

theorem identity46113 : scanCanonicalize (H12AffineFastState.compose env46113 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46113 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env46114 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5157,293,262,131072,2048,1025,292,4113,261,16,295,268,16,138292,5392,4388,138512,1285,260,257,260,5156,512]

theorem envBound46114 : H12AffineFastState.Bounded env46114 := by
  intro p hp
  have h : env46114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46113_46114 : H12AffineEnvironment.transform 5 17 env46113 = env46114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46113 == env46114) = true)

theorem identity46114 : scanCanonicalize (H12AffineFastState.compose env46114 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46114 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46115 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,269,5125,261,262,131072,2048,1025,260,4113,261,16,263,268,16,138260,5392,4356,138512,1285,260,257,260,5124,512]

theorem envBound46115 : H12AffineFastState.Bounded env46115 := by
  intro p hp
  have h : env46115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46114_46115 : H12AffineEnvironment.transform 4 0 env46114 = env46115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46114 == env46115) = true)

theorem identity46115 : scanCanonicalize (H12AffineFastState.compose env46115 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(16+1) ^^^ 5140) := by decide +kernel

theorem selectedBound46115 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env46116 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,269,5125,261,262,5140,2048,1025,260,4113,261,16,263,268,16,2048,5392,4356,2308,1285,260,257,260,5124,512]

theorem envBound46116 : H12AffineFastState.Bounded env46116 := by
  intro p hp
  have h : env46116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46115_46116 : H12AffineEnvironment.transform 16 5140 env46115 = env46116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5140 env46115 == env46116) = true)

theorem identity46116 : scanCanonicalize (H12AffineFastState.compose env46116 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1280) := by decide +kernel

theorem selectedBound46116 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env46117 : List Nat := [2,4,8,16,0,17,9,256,512,1024,1280,4096,269,5125,261,262,5140,1280,1025,260,4113,261,16,263,268,16,1280,5392,4356,1028,1285,260,257,260,5124,512]

theorem envBound46117 : H12AffineFastState.Bounded env46117 := by
  intro p hp
  have h : env46117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46116_46117 : H12AffineEnvironment.transform 10 1280 env46116 = env46117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1280 env46116 == env46117) = true)

theorem identity46117 : scanCanonicalize (H12AffineFastState.compose env46117 (packedSelected [3,8] rootPS)) = affineNative (2^(11+1) ^^^ 1808) := by decide +kernel

theorem selectedBound46117 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env46118 : List Nat := [2,4,8,16,0,17,9,256,512,1024,1280,1808,269,789,261,262,772,1280,1025,260,1793,261,16,263,268,16,1280,512,1556,1028,1285,260,257,260,788,512]

theorem envBound46118 : H12AffineFastState.Bounded env46118 := by
  intro p hp
  have h : env46118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46117_46118 : H12AffineEnvironment.transform 11 1808 env46117 = env46118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1808 env46117 == env46118) = true)

theorem identity46118 : scanCanonicalize (H12AffineFastState.compose env46118 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound46118 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env46119 : List Nat := [2,4,8,16,0,17,9,256,512,533,789,261,269,789,261,262,772,789,532,260,276,261,16,263,268,16,789,512,1,529,784,260,257,260,788,512]

theorem envBound46119 : H12AffineFastState.Bounded env46119 := by
  intro p hp
  have h : env46119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46118_46119 : H12AffineEnvironment.transform 9 533 env46118 = env46119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env46118 == env46119) = true)

theorem identity46119 : scanCanonicalize (H12AffineFastState.compose env46119 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound46119 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1