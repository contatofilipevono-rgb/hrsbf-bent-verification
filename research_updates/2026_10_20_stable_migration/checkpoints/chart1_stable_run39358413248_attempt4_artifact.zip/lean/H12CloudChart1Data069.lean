import H12CloudChart1Data068

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound17388 : packedSelected [0,4,7,9,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env17389 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,5376,1,342,5440,2421,1024,0,4161,32,64,2,348,64,2049,5440,4176,2420,1285,32,256,32,5456,593]

theorem envBound17389 : H12AffineFastState.Bounded env17389 := by
  intro p hp
  have h : env17389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17388_17389 : H12AffineEnvironment.transform 12 268 env17388 = env17389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17388 == env17389) = true)

theorem identity17389 : scanCanonicalize (H12AffineFastState.compose env17389 (packedSelected [0,1,2,3,4,5,6,7,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound17389 : packedSelected [0,1,2,3,4,5,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env17390 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,16,268,1296,1,342,1360,2421,1024,0,81,32,64,2,348,64,2049,1360,64,2420,1285,32,256,32,1344,593]

theorem envBound17390 : H12AffineFastState.Bounded env17390 := by
  intro p hp
  have h : env17390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17389_17390 : H12AffineEnvironment.transform 11 16 env17389 = env17390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env17389 == env17390) = true)

theorem identity17390 : scanCanonicalize (H12AffineFastState.compose env17390 (packedSelected [1,4,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17390 : packedSelected [1,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env17391 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,16,268,1296,1,262,1280,2341,1024,0,1,32,16,2,268,16,2049,1280,16,2340,1285,32,256,32,1296,513]

theorem envBound17391 : H12AffineFastState.Bounded env17391 := by
  intro p hp
  have h : env17391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17390_17391 : H12AffineEnvironment.transform 5 16 env17390 = env17391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17390 == env17391) = true)

theorem identity17391 : scanCanonicalize (H12AffineFastState.compose env17391 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound17391 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17392 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,16,268,1,1,262,17,2341,273,0,1,32,16,2,268,16,2049,17,16,2340,20,32,256,32,1,513]

theorem envBound17392 : H12AffineFastState.Bounded env17392 := by
  intro p hp
  have h : env17392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17391_17392 : H12AffineEnvironment.transform 9 273 env17391 = env17392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17391 == env17392) = true)

def env17393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,21912,98645,8328,64,410093,16536,17800,431512,20701,62708,256,21792,46213,96011]

theorem envBound17393 : H12AffineFastState.Bounded env17393 := by
  intro p hp
  have h : env17393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17367_17393 : H12AffineEnvironment.transform 21 21793 env17367 = env17393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env17367 == env17393) = true)

theorem identity17393 : scanCanonicalize (H12AffineFastState.compose env17393 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound17393 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,17729,21793,21912,73736,8328,64,410093,16536,17800,406725,20701,21929,256,21792,5592,96011]

theorem envBound17394 : H12AffineFastState.Bounded env17394 := by
  intro p hp
  have h : env17394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17393_17394 : H12AffineEnvironment.transform 14 8541 env17393 = env17394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env17393 == env17394) = true)

def env17395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10400,1024,8540,17729,21793,21912,73736,8328,64,158029,16536,17800,138341,20701,21929,256,21792,5592,96011]

theorem envBound17395 : H12AffineFastState.Bounded env17395 := by
  intro p hp
  have h : env17395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17394_17395 : H12AffineEnvironment.transform 17 10400 env17394 = env17395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env17394 == env17395) = true)

theorem identity17395 : scanCanonicalize (H12AffineFastState.compose env17395 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound17395 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,29962,131072,10400,1024,8540,17729,21793,21912,21762,8328,64,158029,16536,17800,138341,20701,21929,256,21792,5592,513]

theorem envBound17396 : H12AffineFastState.Bounded env17396 := by
  intro p hp
  have h : env17396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17395_17396 : H12AffineEnvironment.transform 15 29962 env17395 = env17396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env17395 == env17396) = true)

theorem identity17396 : scanCanonicalize (H12AffineFastState.compose env17396 (packedSelected [2,3,5,11,15,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 24680) := by decide +kernel

theorem selectedBound17396 : packedSelected [2,3,5,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env17397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,29962,24680,10400,1024,8540,17729,21793,21912,21762,8328,64,2341,16536,17800,31757,20701,21929,256,21792,5592,513]

theorem envBound17397 : H12AffineFastState.Bounded env17397 := by
  intro p hp
  have h : env17397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17396_17397 : H12AffineEnvironment.transform 16 24680 env17396 = env17397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24680 env17396 == env17397) = true)

theorem identity17397 : scanCanonicalize (H12AffineFastState.compose env17397 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound17397 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env17398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,217,21646,16876,2340,1024,216,17729,21793,21912,21762,268,64,2341,16536,17800,23945,20701,21929,256,21792,5592,513]

theorem envBound17398 : H12AffineFastState.Bounded env17398 := by
  intro p hp
  have h : env17398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17397_17398 : H12AffineEnvironment.transform 12 388 env17397 = env17398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env17397 == env17398) = true)

def env17399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10401,1024,8540,17729,21793,21912,73736,8328,64,158028,16536,17800,138340,20701,21929,256,21792,5592,96011]

theorem envBound17399 : H12AffineFastState.Bounded env17399 := by
  intro p hp
  have h : env17399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17394_17399 : H12AffineEnvironment.transform 17 10401 env17394 = env17399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env17394 == env17399) = true)

theorem identity17399 : scanCanonicalize (H12AffineFastState.compose env17399 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound17399 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8322,131072,10401,1024,8540,17729,21793,21912,138,8328,64,158028,16536,17800,138340,20701,21929,256,21792,5592,22409]

theorem envBound17400 : H12AffineFastState.Bounded env17400 := by
  intro p hp
  have h : env17400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17399_17400 : H12AffineEnvironment.transform 15 8322 env17399 = env17400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env17399 == env17400) = true)

theorem identity17400 : scanCanonicalize (H12AffineFastState.compose env17400 (packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 5577) := by decide +kernel

theorem selectedBound17400 : packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env17401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8322,5577,10401,1024,8540,17729,21793,21912,138,8328,64,31877,16536,17800,2477,20701,21929,256,21792,5592,22409]

theorem envBound17401 : H12AffineFastState.Bounded env17401 := by
  intro p hp
  have h : env17401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17400_17401 : H12AffineEnvironment.transform 16 5577 env17400 = env17401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5577 env17400 == env17401) = true)

theorem identity17401 : scanCanonicalize (H12AffineFastState.compose env17401 (packedSelected [2,9,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13556) := by decide +kernel

theorem selectedBound17401 : packedSelected [2,9,16,20,22] rootPS < 2^1333 := by decide +kernel

def env17402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13556,8541,8322,5577,10401,1024,8540,12725,8661,8556,138,8328,64,2161,13420,12668,2477,9257,8541,256,8660,5592,9085]

theorem envBound17402 : H12AffineFastState.Bounded env17402 := by
  intro p hp
  have h : env17402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17401_17402 : H12AffineEnvironment.transform 13 13556 env17401 = env17402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13556 env17401 == env17402) = true)

theorem identity17402 : scanCanonicalize (H12AffineFastState.compose env17402 (packedSelected [0,2,3,4,7,9,10,18,19,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound17402 : packedSelected [0,2,3,4,7,9,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env17403 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,8192,13324,8541,8314,5425,10329,1024,8540,12621,8493,8556,114,8304,64,2161,13420,12668,2389,9257,8541,256,8492,5408,9085]

theorem envBound17403 : H12AffineFastState.Bounded env17403 := by
  intro p hp
  have h : env17403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17402_17403 : H12AffineEnvironment.transform 6 120 env17402 = env17403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env17402 == env17403) = true)

theorem identity17403 : scanCanonicalize (H12AffineFastState.compose env17403 (packedSelected [3,5,6,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound17403 : packedSelected [3,5,6,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env17404 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,120,5236,293,2,5425,2081,1024,292,4405,341,276,114,8,64,2161,5140,4356,2389,1105,293,256,340,5408,773]

theorem envBound17404 : H12AffineFastState.Bounded env17404 := by
  intro p hp
  have h : env17404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17403_17404 : H12AffineEnvironment.transform 12 120 env17403 = env17404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env17403 == env17404) = true)

theorem identity17404 : scanCanonicalize (H12AffineFastState.compose env17404 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17404 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env17405 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,4096,120,5236,32,2,5172,2081,1024,33,4144,80,17,114,8,64,2161,5140,4097,2128,1105,32,5,81,5157,512]

theorem envBound17405 : H12AffineFastState.Bounded env17405 := by
  intro p hp
  have h : env17405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17404_17405 : H12AffineEnvironment.transform 7 5 env17404 = env17405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17404 == env17405) = true)

theorem identity17405 : scanCanonicalize (H12AffineFastState.compose env17405 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound17405 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env17406 : List Nat := [2,4,8,16,32,48,8,5,512,1024,2048,4096,8,5124,32,2,5172,2081,1024,33,4144,32,17,2,8,48,2049,5140,4097,2080,1057,32,5,33,5157,512]

theorem envBound17406 : H12AffineFastState.Bounded env17406 := by
  intro p hp
  have h : env17406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17405_17406 : H12AffineEnvironment.transform 5 48 env17405 = env17406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env17405 == env17406) = true)

def env17407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21913,2212884,8328,64,6705548,16536,2097352,431513,2102685,4235733,256,21793,46212,2175563]

theorem envBound17407 : H12AffineFastState.Bounded env17407 := by
  intro p hp
  have h : env17407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17276_17407 : H12AffineEnvironment.transform 22 21913 env17276 = env17407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21913 env17276 == env17407) = true)

def env17408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,4194304,21913,98644,8328,64,4592844,16536,17800,431513,20701,4235733,256,21793,46212,96011]

theorem envBound17408 : H12AffineFastState.Bounded env17408 := by
  intro p hp
  have h : env17408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17407_17408 : H12AffineEnvironment.transform 20 17728 env17407 = env17408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env17407 == env17408) = true)

def env17409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21913,98644,8328,64,410092,16536,17800,431513,20701,62709,256,21793,46212,96011]

theorem envBound17409 : H12AffineFastState.Bounded env17409 := by
  intro p hp
  have h : env17409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17408_17409 : H12AffineEnvironment.transform 21 21792 env17408 = env17409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env17408 == env17409) = true)

theorem identity17409 : scanCanonicalize (H12AffineFastState.compose env17409 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound17409 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,131072,262144,1024,32769,17728,21792,21913,41431,8328,64,410092,16536,17800,431513,20701,62709,256,21793,46212,22408]

theorem envBound17410 : H12AffineFastState.Bounded env17410 := by
  intro p hp
  have h : env17410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17409_17410 : H12AffineEnvironment.transform 15 8323 env17409 = env17410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env17409 == env17410) = true)

def env17411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5440,262144,1024,32769,17728,21792,21913,41431,8328,64,283820,16536,17800,295129,20701,62709,256,21793,46212,22408]

theorem envBound17411 : H12AffineFastState.Bounded env17411 := by
  intro p hp
  have h : env17411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17410_17411 : H12AffineEnvironment.transform 16 5440 env17410 = env17411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env17410 == env17411) = true)

theorem identity17411 : scanCanonicalize (H12AffineFastState.compose env17411 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 56492) := by decide +kernel

theorem selectedBound17411 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env17412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5440,56492,1024,32769,17728,21792,21913,41431,8328,64,34816,16536,17800,23669,20701,62709,256,21793,46212,22408]

theorem envBound17412 : H12AffineFastState.Bounded env17412 := by
  intro p hp
  have h : env17412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17411_17412 : H12AffineEnvironment.transform 17 56492 env17411 = env17412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56492 env17411 == env17412) = true)

theorem identity17412 : scanCanonicalize (H12AffineFastState.compose env17412 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound17412 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8323,5440,35109,1024,32769,4297,169,16,41431,8328,64,34816,5393,4097,2556,1364,41340,256,168,46212,513]

theorem envBound17413 : H12AffineFastState.Bounded env17413 := by
  intro p hp
  have h : env17413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17412_17413 : H12AffineEnvironment.transform 13 5513 env17412 = env17413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env17412 == env17413) = true)

theorem identity17413 : scanCanonicalize (H12AffineFastState.compose env17413 (packedSelected [0,1,2,3,5,6,7,8,9,10,14,20,21,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound17413 : packedSelected [0,1,2,3,5,6,7,8,9,10,14,20,21,22,26] rootPS < 2^1333 := by decide +kernel

def env17414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8581,8323,5440,10400,1024,8580,4297,169,16,82,8328,64,10629,5393,4097,2556,1364,249,256,168,5377,513]

theorem envBound17414 : H12AffineFastState.Bounded env17414 := by
  intro p hp
  have h : env17414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17413_17414 : H12AffineEnvironment.transform 14 8581 env17413 = env17414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env17413 == env17414) = true)

theorem identity17414 : scanCanonicalize (H12AffineFastState.compose env17414 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17414 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env17415 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,8581,8323,5393,10400,1024,8580,4248,169,16,3,8328,17,10629,5393,4097,2477,1285,168,256,168,5377,513]

theorem envBound17415 : H12AffineFastState.Bounded env17415 := by
  intro p hp
  have h : env17415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17414_17415 : H12AffineEnvironment.transform 5 17 env17414 = env17415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17414 == env17415) = true)

theorem identity17415 : scanCanonicalize (H12AffineFastState.compose env17415 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound17415 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env17416 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,128,5513,261,3,5393,2080,1024,260,4248,169,16,3,8,17,2309,5393,4097,2477,1285,168,256,168,5377,513]

theorem envBound17416 : H12AffineFastState.Bounded env17416 := by
  intro p hp
  have h : env17416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17415_17416 : H12AffineEnvironment.transform 12 128 env17415 = env17416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env17415 == env17416) = true)

theorem identity17416 : scanCanonicalize (H12AffineFastState.compose env17416 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17416 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env17417 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,128,5260,0,3,5140,2080,1024,1,4248,169,16,3,8,17,2048,5140,4097,2216,1024,168,5,168,5124,513]

theorem envBound17417 : H12AffineFastState.Bounded env17417 := by
  intro p hp
  have h : env17417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17416_17417 : H12AffineEnvironment.transform 7 5 env17416 = env17417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17416 == env17417) = true)

theorem identity17417 : scanCanonicalize (H12AffineFastState.compose env17417 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17417 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17418 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,4096,8,5124,0,3,5140,2080,1024,1,4112,33,16,3,8,17,2048,5140,4097,2080,1024,32,5,32,5124,513]

theorem envBound17418 : H12AffineFastState.Bounded env17418 := by
  intro p hp
  have h : env17418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17417_17418 : H12AffineEnvironment.transform 6 8 env17417 = env17418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17417 == env17418) = true)

theorem identity17418 : scanCanonicalize (H12AffineFastState.compose env17418 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound17418 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17419 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,1028,8,0,0,3,16,2080,1024,1,1044,33,16,3,8,17,2048,16,1029,2080,1024,32,5,32,0,513]

theorem envBound17419 : H12AffineFastState.Bounded env17419 := by
  intro p hp
  have h : env17419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17418_17419 : H12AffineEnvironment.transform 11 1028 env17418 = env17419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env17418 == env17419) = true)

theorem identity17419 : scanCanonicalize (H12AffineFastState.compose env17419 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound17419 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17420 : List Nat := [2,4,8,16,32,17,8,5,512,1024,554,1028,8,0,0,3,16,522,1024,1,1044,33,16,3,8,17,554,16,1029,522,1024,32,5,32,0,513]

theorem envBound17420 : H12AffineFastState.Bounded env17420 := by
  intro p hp
  have h : env17420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17419_17420 : H12AffineEnvironment.transform 10 554 env17419 = env17420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env17419 == env17420) = true)

theorem identity17420 : scanCanonicalize (H12AffineFastState.compose env17420 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17420 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17421 : List Nat := [2,4,8,16,32,17,8,5,0,1024,42,1028,8,0,0,3,16,10,1024,1,1044,33,16,3,8,17,42,16,1029,10,1024,32,5,32,0,1]

theorem envBound17421 : H12AffineFastState.Bounded env17421 := by
  intro p hp
  have h : env17421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17420_17421 : H12AffineEnvironment.transform 8 0 env17420 = env17421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17420 == env17421) = true)

theorem identity17421 : scanCanonicalize (H12AffineFastState.compose env17421 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound17421 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17422 : List Nat := [2,4,8,16,32,17,8,5,0,37,42,33,8,0,0,3,16,10,37,1,49,33,16,3,8,17,42,16,32,10,37,32,5,32,0,1]

theorem envBound17422 : H12AffineFastState.Bounded env17422 := by
  intro p hp
  have h : env17422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17421_17422 : H12AffineEnvironment.transform 9 37 env17421 = env17422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env17421 == env17422) = true)

theorem identity17422 : scanCanonicalize (H12AffineFastState.compose env17422 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17422 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17423 : List Nat := [2,4,8,16,1,17,8,5,0,4,11,0,8,0,0,3,16,10,4,1,16,0,16,3,8,17,11,16,1,10,4,1,5,1,0,1]

theorem envBound17423 : H12AffineFastState.Bounded env17423 := by
  intro p hp
  have h : env17423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17422_17423 : H12AffineEnvironment.transform 4 1 env17422 = env17423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17422 == env17423) = true)

theorem identity17423 : scanCanonicalize (H12AffineFastState.compose env17423 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound17423 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17424 : List Nat := [2,4,8,5,1,4,8,5,0,4,11,0,8,0,0,3,5,10,4,1,5,0,5,3,8,4,11,5,1,10,4,1,5,1,0,1]

theorem envBound17424 : H12AffineFastState.Bounded env17424 := by
  intro p hp
  have h : env17424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17423_17424 : H12AffineEnvironment.transform 3 5 env17423 = env17424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env17423 == env17424) = true)

theorem identity17424 : scanCanonicalize (H12AffineFastState.compose env17424 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound17424 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env17425 : List Nat := [2,4,7,5,1,4,7,5,0,4,4,0,7,0,0,3,5,5,4,1,5,0,5,3,7,4,4,5,1,5,4,1,5,1,0,1]

theorem envBound17425 : H12AffineFastState.Bounded env17425 := by
  intro p hp
  have h : env17425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17424_17425 : H12AffineEnvironment.transform 2 7 env17424 = env17425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env17424 == env17425) = true)

theorem identity17425 : scanCanonicalize (H12AffineFastState.compose env17425 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound17425 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17426 : List Nat := [2,2,1,3,1,2,1,3,0,2,2,0,1,0,0,3,3,3,2,1,3,0,3,3,1,2,2,3,1,3,2,1,3,1,0,1]

theorem envBound17426 : H12AffineFastState.Bounded env17426 := by
  intro p hp
  have h : env17426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17425_17426 : H12AffineEnvironment.transform 1 2 env17425 = env17426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env17425 == env17426) = true)

theorem identity17426 : scanCanonicalize (H12AffineFastState.compose env17426 (packedSelected [10] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound17426 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env17427 : List Nat := [0,0,1,1,1,0,1,1,0,0,0,0,1,0,0,1,1,1,0,1,1,0,1,1,1,0,0,1,1,1,0,1,1,1,0,1]

theorem envBound17427 : H12AffineFastState.Bounded env17427 := by
  intro p hp
  have h : env17427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17426_17427 : H12AffineEnvironment.transform 0 0 env17426 = env17427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env17426 == env17427) = true)

def env17428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5441,262144,1024,32769,17728,21792,21913,41431,8328,64,283821,16536,17800,295128,20701,62709,256,21793,46212,22408]

theorem envBound17428 : H12AffineFastState.Bounded env17428 := by
  intro p hp
  have h : env17428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17410_17428 : H12AffineEnvironment.transform 16 5441 env17410 = env17428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env17410 == env17428) = true)

theorem identity17428 : scanCanonicalize (H12AffineFastState.compose env17428 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound17428 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env17429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5441,56357,1024,32769,17728,21792,21913,41431,8328,64,34952,16536,17800,23805,20701,62709,256,21793,46212,22408]

theorem envBound17429 : H12AffineFastState.Bounded env17429 := by
  intro p hp
  have h : env17429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17428_17429 : H12AffineEnvironment.transform 17 56357 env17428 = env17429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env17428 == env17429) = true)

theorem identity17429 : scanCanonicalize (H12AffineFastState.compose env17429 (packedSelected [0,3,4,7,10,11,16,18,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound17429 : packedSelected [0,3,4,7,10,11,16,18,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env17430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8323,5441,10481,1024,29909,17728,21792,21913,21763,8328,64,31836,16536,17800,23805,20701,33,256,21793,16464,22408]

theorem envBound17430 : H12AffineFastState.Bounded env17430 := by
  intro p hp
  have h : env17430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17429_17430 : H12AffineEnvironment.transform 14 29908 env17429 = env17430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env17429 == env17430) = true)

theorem identity17430 : scanCanonicalize (H12AffineFastState.compose env17430 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,21,22] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17430 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,21,22] rootPS < 2^1333 := by decide +kernel

def env17431 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8323,5392,10400,1024,29828,17681,21792,21913,21763,8328,17,31757,16536,17800,23724,20620,33,256,21793,16385,22408]

theorem envBound17431 : H12AffineFastState.Bounded env17431 := by
  intro p hp
  have h : env17431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17430_17431 : H12AffineEnvironment.transform 5 17 env17430 = env17431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17430 == env17431) = true)

theorem identity17431 : scanCanonicalize (H12AffineFastState.compose env17431 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound17431 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17432 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,8460,8323,5392,10400,1024,8461,4248,169,16,138,8328,17,10628,5393,4097,2341,1285,33,256,168,5512,513]

theorem envBound17432 : H12AffineFastState.Bounded env17432 := by
  intro p hp
  have h : env17432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17431_17432 : H12AffineEnvironment.transform 13 5513 env17431 = env17432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env17431 == env17432) = true)

theorem identity17432 : scanCanonicalize (H12AffineFastState.compose env17432 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound17432 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17433 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8,5513,260,139,5392,2216,1024,261,4248,169,16,138,128,17,2444,5393,4097,2341,1285,33,256,168,5512,513]

theorem envBound17433 : H12AffineFastState.Bounded env17433 := by
  intro p hp
  have h : env17433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17432_17433 : H12AffineEnvironment.transform 12 8 env17432 = env17433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env17432 == env17433) = true)

theorem identity17433 : scanCanonicalize (H12AffineFastState.compose env17433 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17433 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env17434 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8,5377,260,3,5392,2080,1024,261,4112,33,16,2,8,17,2308,5393,4097,2341,1285,33,256,32,5376,513]

theorem envBound17434 : H12AffineFastState.Bounded env17434 := by
  intro p hp
  have h : env17434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17433_17434 : H12AffineEnvironment.transform 6 8 env17433 = env17434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17433 == env17434) = true)

theorem identity17434 : scanCanonicalize (H12AffineFastState.compose env17434 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound17434 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17435 : List Nat := [2,4,8,16,32,17,8,256,512,36,2048,4096,8,4389,260,3,4404,2080,36,261,4112,33,16,2,8,17,2308,4405,4097,2341,289,33,256,32,4388,513]

theorem envBound17435 : H12AffineFastState.Bounded env17435 := by
  intro p hp
  have h : env17435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17434_17435 : H12AffineEnvironment.transform 9 36 env17434 = env17435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env17434 == env17435) = true)

theorem identity17435 : scanCanonicalize (H12AffineFastState.compose env17435 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 772) := by decide +kernel

theorem selectedBound17435 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17436 : List Nat := [2,4,8,16,32,17,8,256,512,36,772,4096,8,4389,260,3,4404,804,36,261,4112,33,16,2,8,17,512,4405,4097,545,289,33,256,32,4388,513]

theorem envBound17436 : H12AffineFastState.Bounded env17436 := by
  intro p hp
  have h : env17436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17435_17436 : H12AffineEnvironment.transform 10 772 env17435 = env17436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 772 env17435 == env17436) = true)

theorem identity17436 : scanCanonicalize (H12AffineFastState.compose env17436 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound17436 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17437 : List Nat := [2,4,8,16,32,17,8,52,512,36,560,4096,8,4113,48,3,4096,528,36,49,4112,33,16,2,8,17,512,4097,4097,545,21,33,52,32,4112,513]

theorem envBound17437 : H12AffineFastState.Bounded env17437 := by
  intro p hp
  have h : env17437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17436_17437 : H12AffineEnvironment.transform 7 52 env17436 = env17437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env17436 == env17437) = true)

theorem identity17437 : scanCanonicalize (H12AffineFastState.compose env17437 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound17437 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17438 : List Nat := [2,4,8,16,32,17,8,52,512,36,560,16,8,1,48,3,16,528,36,49,0,33,16,2,8,17,512,17,17,545,21,33,52,32,0,513]

theorem envBound17438 : H12AffineFastState.Bounded env17438 := by
  intro p hp
  have h : env17438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17437_17438 : H12AffineEnvironment.transform 11 16 env17437 = env17438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env17437 == env17438) = true)

theorem identity17438 : scanCanonicalize (H12AffineFastState.compose env17438 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17438 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17439 : List Nat := [2,4,8,0,32,1,8,36,512,36,544,0,8,1,32,3,0,512,36,33,0,33,0,2,8,1,512,1,1,545,5,33,36,32,0,513]

theorem envBound17439 : H12AffineFastState.Bounded env17439 := by
  intro p hp
  have h : env17439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17438_17439 : H12AffineEnvironment.transform 3 0 env17438 = env17439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17438 == env17439) = true)

theorem identity17439 : scanCanonicalize (H12AffineFastState.compose env17439 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17439 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17440 : List Nat := [2,4,8,0,32,1,8,36,1,36,33,0,8,1,32,3,0,1,36,33,0,33,0,2,8,1,1,1,1,32,5,33,36,32,0,0]

theorem envBound17440 : H12AffineFastState.Bounded env17440 := by
  intro p hp
  have h : env17440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17439_17440 : H12AffineEnvironment.transform 8 1 env17439 = env17440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17439 == env17440) = true)

theorem identity17440 : scanCanonicalize (H12AffineFastState.compose env17440 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17440 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17441 : List Nat := [2,4,8,0,1,1,8,5,1,5,0,0,8,1,1,3,0,1,5,0,0,0,0,2,8,1,1,1,1,1,5,0,5,1,0,0]

theorem envBound17441 : H12AffineFastState.Bounded env17441 := by
  intro p hp
  have h : env17441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17440_17441 : H12AffineEnvironment.transform 4 1 env17440 = env17441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17440 == env17441) = true)

def env17442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,21913,98644,8328,64,410093,16536,17800,431513,20701,62708,256,21793,46212,96011]

theorem envBound17442 : H12AffineFastState.Bounded env17442 := by
  intro p hp
  have h : env17442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17408_17442 : H12AffineEnvironment.transform 21 21793 env17408 = env17442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env17408 == env17442) = true)

theorem identity17442 : scanCanonicalize (H12AffineFastState.compose env17442 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound17442 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,17728,21793,21913,62558,8328,64,410093,16536,17800,431513,20701,62708,256,21793,46212,513]

theorem envBound17443 : H12AffineFastState.Bounded env17443 := by
  intro p hp
  have h : env17443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17442_17443 : H12AffineEnvironment.transform 15 29962 env17442 = env17443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env17442 == env17443) = true)

theorem identity17443 : scanCanonicalize (H12AffineFastState.compose env17443 (packedSelected [12,15,21,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17443 : packedSelected [12,15,21,38,41] rootPS < 2^1333 := by decide +kernel

def env17444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,17728,21793,21776,62558,8193,64,409956,16401,17665,431376,20564,62589,256,21793,46093,513]

theorem envBound17444 : H12AffineFastState.Bounded env17444 := by
  intro p hp
  have h : env17444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17443_17444 : H12AffineEnvironment.transform 6 9 env17443 = env17444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17443 == env17444) = true)

theorem identity17444 : scanCanonicalize (H12AffineFastState.compose env17444 (packedSelected [0,3,4,7,9,10,14,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound17444 : packedSelected [0,3,4,7,9,10,14,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env17445 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,131072,262144,1024,29788,17728,21793,21776,3,8193,64,409956,16401,17665,418125,20564,32,256,21793,16464,513]

theorem envBound17445 : H12AffineFastState.Bounded env17445 := by
  intro p hp
  have h : env17445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17444_17445 : H12AffineEnvironment.transform 14 29789 env17444 = env17445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env17444 == env17445) = true)

theorem identity17445 : scanCanonicalize (H12AffineFastState.compose env17445 (packedSelected [2,4,6,9,14,16,21] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound17445 : packedSelected [2,4,6,9,14,16,21] rootPS < 2^1333 := by decide +kernel

def env17446 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,5441,262144,1024,29788,17728,21793,21776,3,8193,64,283685,16401,17665,291852,20564,32,256,21793,16464,513]

theorem envBound17446 : H12AffineFastState.Bounded env17446 := by
  intro p hp
  have h : env17446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17445_17446 : H12AffineEnvironment.transform 16 5441 env17445 = env17446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env17445 == env17446) = true)

theorem identity17446 : scanCanonicalize (H12AffineFastState.compose env17446 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound17446 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17447 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,5441,23669,1024,29788,17728,21793,21776,3,8193,64,2128,16401,17665,10361,20564,32,256,21793,16464,513]

theorem envBound17447 : H12AffineFastState.Bounded env17447 := by
  intro p hp
  have h : env17447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17446_17447 : H12AffineEnvironment.transform 17 23669 env17446 = env17447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env17446 == env17447) = true)

theorem identity17447 : scanCanonicalize (H12AffineFastState.compose env17447 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound17447 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env17448 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8461,8282,5441,2341,1024,8460,4112,113,64,3,8193,64,2128,5441,4177,10361,1284,32,256,113,5376,513]

theorem envBound17448 : H12AffineFastState.Bounded env17448 := by
  intro p hp
  have h : env17448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17447_17448 : H12AffineEnvironment.transform 13 5456 env17447 = env17448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env17447 == env17448) = true)

theorem identity17448 : scanCanonicalize (H12AffineFastState.compose env17448 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound17448 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,81,262,5441,2341,1024,80,4112,113,64,3,349,64,2128,5441,4177,2341,1284,32,256,113,5376,513]

theorem envBound17449 : H12AffineFastState.Bounded env17449 := by
  intro p hp
  have h : env17449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17448_17449 : H12AffineEnvironment.transform 12 348 env17448 = env17449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env17448 == env17449) = true)

theorem identity17449 : scanCanonicalize (H12AffineFastState.compose env17449 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17449 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17450 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,262,5393,2341,1024,0,4112,33,16,3,269,16,2048,5393,4097,2341,1284,32,256,33,5376,513]

theorem envBound17450 : H12AffineFastState.Bounded env17450 := by
  intro p hp
  have h : env17450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17449_17450 : H12AffineEnvironment.transform 5 16 env17449 = env17450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17449 == env17450) = true)

theorem identity17450 : scanCanonicalize (H12AffineFastState.compose env17450 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound17450 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17451 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1077,268,309,1,262,292,2341,1024,0,1061,33,16,3,269,16,2048,292,1076,2341,1284,32,256,33,309,513]

theorem envBound17451 : H12AffineFastState.Bounded env17451 := by
  intro p hp
  have h : env17451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17450_17451 : H12AffineEnvironment.transform 11 1077 env17450 = env17451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env17450 == env17451) = true)

theorem identity17451 : scanCanonicalize (H12AffineFastState.compose env17451 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound17451 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17452 : List Nat := [2,4,8,16,32,16,9,256,512,1024,303,1077,268,309,1,262,292,10,1024,0,1061,33,16,3,269,16,303,292,1076,10,1284,32,256,33,309,513]

theorem envBound17452 : H12AffineFastState.Bounded env17452 := by
  intro p hp
  have h : env17452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17451_17452 : H12AffineEnvironment.transform 10 303 env17451 = env17452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env17451 == env17452) = true)

theorem identity17452 : scanCanonicalize (H12AffineFastState.compose env17452 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound17452 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17453 : List Nat := [2,4,8,16,32,16,9,256,512,5,303,48,268,309,1,262,292,10,5,0,32,33,16,3,269,16,303,292,49,10,257,32,256,33,309,513]

theorem envBound17453 : H12AffineFastState.Bounded env17453 := by
  intro p hp
  have h : env17453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17452_17453 : H12AffineEnvironment.transform 9 5 env17452 = env17453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env17452 == env17453) = true)

theorem identity17453 : scanCanonicalize (H12AffineFastState.compose env17453 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound17453 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17454 : List Nat := [2,4,8,16,32,16,9,15,512,5,32,48,3,58,1,9,43,10,5,0,32,33,16,3,2,16,32,43,49,10,14,32,15,33,58,513]

theorem envBound17454 : H12AffineFastState.Bounded env17454 := by
  intro p hp
  have h : env17454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17453_17454 : H12AffineEnvironment.transform 7 15 env17453 = env17454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env17453 == env17454) = true)

def env17455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,4194304,21913,98645,8328,64,4592845,16536,17801,431513,20700,4235733,256,21793,46212,96010]

theorem envBound17455 : H12AffineFastState.Bounded env17455 := by
  intro p hp
  have h : env17455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17407_17455 : H12AffineEnvironment.transform 20 17729 env17407 = env17455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env17407 == env17455) = true)

def env17456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,21913,98645,8328,64,410093,16536,17801,431513,20700,62709,256,21793,46212,96010]

theorem envBound17456 : H12AffineFastState.Bounded env17456 := by
  intro p hp
  have h : env17456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17455_17456 : H12AffineEnvironment.transform 21 21792 env17455 = env17456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env17455 == env17456) = true)

theorem identity17456 : scanCanonicalize (H12AffineFastState.compose env17456 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound17456 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,17729,21792,21913,21763,8328,64,410093,16536,17801,431513,20700,62709,256,21793,46212,41820]

theorem envBound17457 : H12AffineFastState.Bounded env17457 := by
  intro p hp
  have h : env17457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17456_17457 : H12AffineEnvironment.transform 15 54358 env17456 = env17457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env17456 == env17457) = true)

theorem identity17457 : scanCanonicalize (H12AffineFastState.compose env17457 (packedSelected [3,10,12,15,21,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound17457 : packedSelected [3,10,12,15,21,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env17458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,131072,35325,1024,32769,17729,21792,21913,21763,8328,64,182288,16536,17801,138340,20700,62709,256,21793,46212,41820]

theorem envBound17458 : H12AffineFastState.Bounded env17458 := by
  intro p hp
  have h : env17458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17457_17458 : H12AffineEnvironment.transform 17 35325 env17457 = env17458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env17457 == env17458) = true)

theorem identity17458 : scanCanonicalize (H12AffineFastState.compose env17458 (packedSelected [0,1,3,4,5,6,7,8,9,10,11,12,15,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound17458 : packedSelected [0,1,3,4,5,6,7,8,9,10,11,12,15,19,21,23] rootPS < 2^1333 := by decide +kernel

def env17459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,5220,35325,1024,32769,17729,21792,21913,21763,8328,64,56436,16536,17801,2048,20700,62709,256,21793,46212,41820]

theorem envBound17459 : H12AffineFastState.Bounded env17459 := by
  intro p hp
  have h : env17459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17458_17459 : H12AffineEnvironment.transform 16 5220 env17458 = env17459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env17458 == env17459) = true)

theorem identity17459 : scanCanonicalize (H12AffineFastState.compose env17459 (packedSelected [0,2,3,4,7,10,11,14,16,18,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound17459 : packedSelected [0,2,3,4,7,10,11,14,16,18,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env17460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29992,8574,5220,31957,1024,29993,17729,21792,21913,21763,8328,64,10588,16536,17801,2048,20700,477,256,21793,16812,22132]

theorem envBound17460 : H12AffineFastState.Bounded env17460 := by
  intro p hp
  have h : env17460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17459_17460 : H12AffineEnvironment.transform 14 29992 env17459 = env17460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env17459 == env17460) = true)

theorem identity17460 : scanCanonicalize (H12AffineFastState.compose env17460 (packedSelected [2,4,9,11,16,18,21] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound17460 : packedSelected [2,4,9,11,16,18,21] rootPS < 2^1333 := by decide +kernel

def env17461 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,29789,8203,5220,31957,1024,29788,17460,21589,21740,21622,8328,64,10281,16536,17660,2048,20700,168,117,21588,16601,22132]

theorem envBound17461 : H12AffineFastState.Bounded env17461 := by
  intro p hp
  have h : env17461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17460_17461 : H12AffineEnvironment.transform 7 117 env17460 = env17461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env17460 == env17461) = true)

theorem identity17461 : scanCanonicalize (H12AffineFastState.compose env17461 (packedSelected [0,6,7,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound17461 : packedSelected [0,6,7,14,20] rootPS < 2^1333 := by decide +kernel

def env17462 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5372,8353,8203,5220,10281,1024,8352,4296,169,16,138,8328,64,10281,5220,4096,2048,1056,168,117,168,5157,648]

theorem envBound17462 : H12AffineFastState.Bounded env17462 := by
  intro p hp
  have h : env17462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17461_17462 : H12AffineEnvironment.transform 13 5372 env17461 = env17462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env17461 == env17462) = true)

theorem identity17462 : scanCanonicalize (H12AffineFastState.compose env17462 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 3660) := by decide +kernel

theorem selectedBound17462 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env17463 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,3660,5372,3821,3655,5220,1637,1024,3820,4296,169,16,138,3780,64,1637,5220,4096,2048,1056,168,117,168,5157,648]

theorem envBound17463 : H12AffineFastState.Bounded env17463 := by
  intro p hp
  have h : env17463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17462_17463 : H12AffineEnvironment.transform 12 3660 env17462 = env17463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3660 env17462 == env17463) = true)

theorem identity17463 : scanCanonicalize (H12AffineFastState.compose env17463 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1637) := by decide +kernel

theorem selectedBound17463 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env17464 : List Nat := [2,4,8,16,32,64,128,117,512,1024,1637,4096,41,5372,136,34,5220,1637,1024,137,4296,169,16,138,161,64,1637,5220,4096,1637,1056,168,117,168,5157,648]

theorem envBound17464 : H12AffineFastState.Bounded env17464 := by
  intro p hp
  have h : env17464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17463_17464 : H12AffineEnvironment.transform 10 1637 env17463 = env17464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1637 env17463 == env17464) = true)

theorem identity17464 : scanCanonicalize (H12AffineFastState.compose env17464 (packedSelected [1,3,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound17464 : packedSelected [1,3,6,11] rootPS < 2^1333 := by decide +kernel

def env17465 : List Nat := [2,4,8,16,32,64,128,117,512,1024,1637,648,41,1652,136,34,1772,1637,1024,137,576,169,16,138,161,64,1637,1772,648,1637,1056,168,117,168,1709,648]

theorem envBound17465 : H12AffineFastState.Bounded env17465 := by
  intro p hp
  have h : env17465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17464_17465 : H12AffineEnvironment.transform 11 648 env17464 = env17465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env17464 == env17465) = true)

theorem identity17465 : scanCanonicalize (H12AffineFastState.compose env17465 (packedSelected [1,2,3,6,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17465 : packedSelected [1,2,3,6,12] rootPS < 2^1333 := by decide +kernel

def env17466 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1589,648,41,1572,136,34,1724,1589,1024,137,528,169,16,138,161,16,1589,1724,648,1589,1056,168,37,168,1709,648]

theorem envBound17466 : H12AffineFastState.Bounded env17466 := by
  intro p hp
  have h : env17466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17465_17466 : H12AffineEnvironment.transform 5 16 env17465 = env17466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17465 == env17466) = true)

theorem identity17466 : scanCanonicalize (H12AffineFastState.compose env17466 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound17466 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env17467 : List Nat := [2,4,8,16,32,16,128,37,512,188,649,648,41,664,136,34,512,649,188,137,528,169,16,138,161,16,649,512,648,649,156,168,37,168,529,648]

theorem envBound17467 : H12AffineFastState.Bounded env17467 := by
  intro p hp
  have h : env17467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17466_17467 : H12AffineEnvironment.transform 9 188 env17466 = env17467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env17466 == env17467) = true)

theorem identity17467 : scanCanonicalize (H12AffineFastState.compose env17467 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound17467 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env17468 : List Nat := [2,4,8,16,32,16,128,37,17,188,152,153,41,137,136,34,17,152,188,137,1,169,16,138,161,16,152,17,153,152,156,168,37,168,0,153]

theorem envBound17468 : H12AffineFastState.Bounded env17468 := by
  intro p hp
  have h : env17468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17467_17468 : H12AffineEnvironment.transform 8 17 env17467 = env17468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env17467 == env17468) = true)

def env17469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,21913,98645,8328,64,410092,16536,17801,431513,20700,62708,256,21793,46212,96010]

theorem envBound17469 : H12AffineFastState.Bounded env17469 := by
  intro p hp
  have h : env17469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17455_17469 : H12AffineEnvironment.transform 21 21793 env17455 = env17469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env17455 == env17469) = true)

theorem identity17469 : scanCanonicalize (H12AffineFastState.compose env17469 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound17469 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,262144,1024,32769,17729,21793,21913,138,8328,64,410092,16536,17801,431513,20700,62708,256,21793,46212,63189]

theorem envBound17470 : H12AffineFastState.Bounded env17470 := by
  intro p hp
  have h : env17470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17469_17470 : H12AffineEnvironment.transform 15 33247 env17469 = env17470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env17469 == env17470) = true)

def env17471 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,33031,131072,262144,1024,32769,17729,21793,21825,82,8272,64,409908,16448,17745,431425,20484,62508,256,21793,46172,62989]

theorem envBound17471 : H12AffineFastState.Bounded env17471 := by
  intro p hp
  have h : env17471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17470_17471 : H12AffineEnvironment.transform 6 88 env17470 = env17471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env17470 == env17471) = true)

theorem identity17471 : scanCanonicalize (H12AffineFastState.compose env17471 (packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS)) = affineNative (2^(17+1) ^^^ 146793) := by decide +kernel

theorem selectedBound17471 : packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env17472 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,33031,131072,146793,1024,32769,17729,21793,21825,82,8272,64,31837,16448,17745,43048,20484,62508,256,21793,46172,62989]

theorem envBound17472 : H12AffineFastState.Bounded env17472 := by
  intro p hp
  have h : env17472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17471_17472 : H12AffineEnvironment.transform 17 146793 env17471 = env17472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146793 env17471 == env17472) = true)

theorem identity17472 : scanCanonicalize (H12AffineFastState.compose env17472 (packedSelected [0,1,4,7,11,16,18,19,20,21,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound17472 : packedSelected [0,1,4,7,11,16,18,19,20,21,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env17473 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,29789,30042,131072,146793,1024,29788,17729,21793,21825,82,8272,64,31837,16448,17745,23669,20484,113,256,21793,16385,592]

theorem envBound17473 : H12AffineFastState.Bounded env17473 := by
  intro p hp
  have h : env17473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17472_17473 : H12AffineEnvironment.transform 14 29789 env17472 = env17473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env17472 == env17473) = true)

def env17474 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,33030,131072,262144,1024,32769,17729,21793,21824,83,8273,64,409909,16449,17744,431424,20485,62509,256,21793,46173,62988]

theorem envBound17474 : H12AffineFastState.Bounded env17474 := by
  intro p hp
  have h : env17474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17470_17474 : H12AffineEnvironment.transform 6 89 env17470 = env17474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env17470 == env17474) = true)

theorem identity17474 : scanCanonicalize (H12AffineFastState.compose env17474 (packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS)) = affineNative (2^(17+1) ^^^ 171109) := by decide +kernel

theorem selectedBound17474 : packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env17475 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,33030,131072,171109,1024,32769,17729,21793,21824,83,8273,64,56656,16449,17744,2341,20485,62509,256,21793,46173,62988]

theorem envBound17475 : H12AffineFastState.Bounded env17475 := by
  intro p hp
  have h : env17475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17474_17475 : H12AffineEnvironment.transform 17 171109 env17474 = env17475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171109 env17474 == env17475) = true)

theorem identity17475 : scanCanonicalize (H12AffineFastState.compose env17475 (packedSelected [0,9,21,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound17475 : packedSelected [0,9,21,22,27] rootPS < 2^1333 := by decide +kernel

def env17476 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,8541,8283,131072,146744,1024,8540,17729,21793,21824,83,8273,64,31757,16449,17744,2341,20485,21872,256,21793,5376,22353]

theorem envBound17476 : H12AffineFastState.Bounded env17476 := by
  intro p hp
  have h : env17476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17475_17476 : H12AffineEnvironment.transform 14 8541 env17475 = env17476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env17475 == env17476) = true)

theorem identity17476 : scanCanonicalize (H12AffineFastState.compose env17476 (packedSelected [1,5,8,16,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound17476 : packedSelected [1,5,8,16,20,24] rootPS < 2^1333 := by decide +kernel

def env17477 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8541,8283,131072,146744,1024,8540,4113,113,16,83,8273,64,10589,5393,4096,2341,1365,32,256,113,5376,513]

theorem envBound17477 : H12AffineFastState.Bounded env17477 := by
  intro p hp
  have h : env17477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17476_17477 : H12AffineEnvironment.transform 13 5456 env17476 = env17477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env17476 == env17477) = true)

theorem identity17477 : scanCanonicalize (H12AffineFastState.compose env17477 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound17477 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17478 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8541,8283,5393,10281,1024,8540,4113,113,16,83,8273,64,10589,5393,4096,2341,1365,32,256,113,5376,513]

theorem envBound17478 : H12AffineFastState.Bounded env17478 := by
  intro p hp
  have h : env17478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17477_17478 : H12AffineEnvironment.transform 16 5393 env17477 = env17478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env17477 == env17478) = true)

theorem identity17478 : scanCanonicalize (H12AffineFastState.compose env17478 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17478 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17479 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8202,5393,10281,1024,8461,4113,32,16,2,8192,17,10508,5393,4096,2341,1284,32,256,32,5376,513]

theorem envBound17479 : H12AffineFastState.Bounded env17479 := by
  intro p hp
  have h : env17479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17478_17479 : H12AffineEnvironment.transform 5 17 env17478 = env17479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17478 == env17479) = true)

def env17480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound17480 : H12AffineFastState.Bounded env17480 := by
  intro p hp
  have h : env17480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17274_17480 : H12AffineEnvironment.transform 18 1025 env17274 = env17480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env17274 == env17480) = true)

theorem identity17480 : scanCanonicalize (H12AffineFastState.compose env17480 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2237588) := by decide +kernel

theorem selectedBound17480 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237588,16777216,8328,64,23454868,18973837,160197,2417813,19112068,23160257,257,17031225,16974237,19040083]

theorem envBound17481 : H12AffineFastState.Bounded env17481 := by
  intro p hp
  have h : env17481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17480_17481 : H12AffineEnvironment.transform 22 2237588 env17480 = env17481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2237588 env17480 == env17481) = true)

def env17482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237588,242968,8328,64,6705548,2240917,160197,2417813,2102684,6475993,257,21793,46213,2175563]

theorem envBound17482 : H12AffineFastState.Bounded env17482 := by
  intro p hp
  have h : env17482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17481_17482 : H12AffineEnvironment.transform 23 242968 env17481 = env17482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242968 env17481 == env17482) = true)

def env17483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,2237588,242968,8328,64,2144540,2240917,160197,2417813,2102684,2373705,257,21793,46213,2175563]

theorem envBound17483 : H12AffineFastState.Bounded env17483 := by
  intro p hp
  have h : env17483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17482_17483 : H12AffineEnvironment.transform 21 452752 env17482 = env17483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452752 env17482 == env17483) = true)

def env17484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,144596,242968,8328,64,43356,139733,160197,324821,1500,272393,257,21793,46213,74251]

theorem envBound17484 : H12AffineFastState.Bounded env17484 := by
  intro p hp
  have h : env17484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17483_17484 : H12AffineEnvironment.transform 20 4160 env17483 = env17484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17483 == env17484) = true)

theorem identity17484 : scanCanonicalize (H12AffineFastState.compose env17484 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17484 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4160,452752,144596,169234,8328,64,43356,139733,160197,324821,1500,272393,257,21793,46213,513]

theorem envBound17485 : H12AffineFastState.Bounded env17485 := by
  intro p hp
  have h : env17485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17484_17485 : H12AffineEnvironment.transform 15 8202 env17484 = env17485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17484 == env17485) = true)

def env17486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4160,305280,29892,54530,8328,64,43356,25029,12757,324821,1500,272393,257,21793,46213,513]

theorem envBound17486 : H12AffineFastState.Bounded env17486 := by
  intro p hp
  have h : env17486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17485_17486 : H12AffineEnvironment.transform 16 16400 env17485 = env17486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env17485 == env17486) = true)

def env17487 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4160,305160,29772,54530,8192,64,43356,24909,12637,324701,1364,272393,257,21793,46093,513]

theorem envBound17487 : H12AffineFastState.Bounded env17487 := by
  intro p hp
  have h : env17487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17486_17487 : H12AffineEnvironment.transform 6 8 env17486 = env17487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17486 == env17487) = true)

def env17488 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4160,305161,29773,54530,8193,64,43356,24908,12636,324700,1365,272393,257,21793,46092,513]

theorem envBound17488 : H12AffineFastState.Bounded env17488 := by
  intro p hp
  have h : env17488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17486_17488 : H12AffineEnvironment.transform 6 9 env17486 = env17488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17486 == env17488) = true)

theorem identity17488 : scanCanonicalize (H12AffineFastState.compose env17488 (packedSelected [0,14,27] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound17488 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env17489 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,16384,32768,1095,16400,262144,1025,32769,4160,298052,20480,54530,1100,64,36113,17665,5393,315409,1365,265284,257,21793,36929,513]

theorem envBound17489 : H12AffineFastState.Bounded env17489 := by
  intro p hp
  have h : env17489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17488_17489 : H12AffineEnvironment.transform 12 1101 env17488 = env17489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env17488 == env17489) = true)

theorem identity17489 : scanCanonicalize (H12AffineFastState.compose env17489 (packedSelected [12,15,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 22884) := by decide +kernel

theorem selectedBound17489 : packedSelected [12,15,38,41] rootPS < 2^1333 := by decide +kernel

def env17490 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,16384,32768,1095,16400,22884,1025,32769,4160,54560,20480,54530,1100,64,36113,17665,5393,35189,1365,21792,257,21793,36929,513]

theorem envBound17490 : H12AffineFastState.Bounded env17490 := by
  intro p hp
  have h : env17490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17489_17490 : H12AffineEnvironment.transform 17 22884 env17489 = env17490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22884 env17489 == env17490) = true)

def env17491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4160,305281,29893,54531,8328,64,43356,25028,12756,324821,1500,272393,257,21793,46213,513]

theorem envBound17491 : H12AffineFastState.Bounded env17491 := by
  intro p hp
  have h : env17491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17485_17491 : H12AffineEnvironment.transform 16 16401 env17485 = env17491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env17485 == env17491) = true)

theorem identity17491 : scanCanonicalize (H12AffineFastState.compose env17491 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound17491 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8202,13509,262144,1025,32769,4160,305281,17,41431,8328,64,43356,5392,12756,294913,1500,272393,257,8693,46213,513]

theorem envBound17492 : H12AffineFastState.Bounded env17492 := by
  intro p hp
  have h : env17492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17491_17492 : H12AffineEnvironment.transform 13 13524 env17491 = env17492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env17491 == env17492) = true)

theorem identity17492 : scanCanonicalize (H12AffineFastState.compose env17492 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound17492 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8202,13509,43049,1025,32769,4160,168,17,41431,8328,64,43356,5392,12756,10280,1500,32800,257,8693,46213,513]

theorem envBound17493 : H12AffineFastState.Bounded env17493 := by
  intro p hp
  have h : env17493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17492_17493 : H12AffineEnvironment.transform 17 43049 env17492 = env17493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env17492 == env17493) = true)

theorem identity17493 : scanCanonicalize (H12AffineFastState.compose env17493 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17493 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env17494 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8202,13389,43049,1025,32769,4160,32,17,41311,8192,64,43356,5392,12636,10280,1364,32800,257,8573,46093,513]

theorem envBound17494 : H12AffineFastState.Bounded env17494 := by
  intro p hp
  have h : env17494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17493_17494 : H12AffineEnvironment.transform 6 8 env17493 = env17494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17493 == env17494) = true)

theorem identity17494 : scanCanonicalize (H12AffineFastState.compose env17494 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound17494 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17495 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,8202,13389,10281,1025,1,4160,32,17,8543,8192,64,10588,5392,12636,10280,1364,32,257,8573,13325,513]

theorem envBound17495 : H12AffineFastState.Bounded env17495 := by
  intro p hp
  have h : env17495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17494_17495 : H12AffineEnvironment.transform 14 0 env17494 = env17495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17494 == env17495) = true)

theorem identity17495 : scanCanonicalize (H12AffineFastState.compose env17495 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound17495 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17496 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,343,5392,2420,1025,1,4160,32,17,2,349,64,2049,5392,4097,2421,1364,32,257,32,5456,513]

theorem envBound17496 : H12AffineFastState.Bounded env17496 := by
  intro p hp
  have h : env17496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17495_17496 : H12AffineEnvironment.transform 12 349 env17495 = env17496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env17495 == env17496) = true)

theorem identity17496 : scanCanonicalize (H12AffineFastState.compose env17496 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound17496 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17497 : List Nat := [2,4,8,16,32,64,8,256,512,1024,90,4096,349,5377,0,343,5392,302,1025,1,4160,32,17,2,349,64,91,5392,4097,303,1364,32,257,32,5456,513]

theorem envBound17497 : H12AffineFastState.Bounded env17497 := by
  intro p hp
  have h : env17497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17496_17497 : H12AffineEnvironment.transform 10 90 env17496 = env17497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env17496 == env17497) = true)

theorem identity17497 : scanCanonicalize (H12AffineFastState.compose env17497 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound17497 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,90,1297,349,16,0,343,1,302,1025,1,1361,32,17,2,349,64,91,1,1296,303,1364,32,257,32,65,513]

theorem envBound17498 : H12AffineFastState.Bounded env17498 := by
  intro p hp
  have h : env17498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17497_17498 : H12AffineEnvironment.transform 11 1297 env17497 = env17498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17497 == env17498) = true)

theorem identity17498 : scanCanonicalize (H12AffineFastState.compose env17498 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound17498 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env17499 : List Nat := [2,4,8,16,32,64,8,117,512,1024,90,1124,40,16,0,34,1,91,1025,1,1060,32,17,2,40,64,91,1,1125,90,1057,32,116,32,65,513]

theorem envBound17499 : H12AffineFastState.Bounded env17499 := by
  intro p hp
  have h : env17499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17498_17499 : H12AffineEnvironment.transform 7 117 env17498 = env17499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env17498 == env17499) = true)

theorem identity17499 : scanCanonicalize (H12AffineFastState.compose env17499 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 110) := by decide +kernel

theorem selectedBound17499 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17500 : List Nat := [2,4,8,16,32,64,8,117,512,110,90,10,40,16,0,34,1,91,111,1,74,32,17,2,40,64,91,1,11,90,79,32,116,32,65,513]

theorem envBound17500 : H12AffineFastState.Bounded env17500 := by
  intro p hp
  have h : env17500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17499_17500 : H12AffineEnvironment.transform 9 110 env17499 = env17500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 110 env17499 == env17500) = true)

theorem identity17500 : scanCanonicalize (H12AffineFastState.compose env17500 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17500 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env17501 : List Nat := [2,4,8,16,1,64,8,84,512,79,90,10,9,16,0,3,1,91,78,1,74,1,17,2,9,64,91,1,11,90,79,1,85,1,65,513]

theorem envBound17501 : H12AffineFastState.Bounded env17501 := by
  intro p hp
  have h : env17501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17500_17501 : H12AffineEnvironment.transform 4 1 env17500 = env17501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17500 == env17501) = true)

def env17502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,144597,242968,8328,64,43357,139732,160197,324820,1501,272392,257,21793,46213,74250]

theorem envBound17502 : H12AffineFastState.Bounded env17502 := by
  intro p hp
  have h : env17502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17483_17502 : H12AffineEnvironment.transform 20 4161 env17483 = env17502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17483 == env17502) = true)

theorem identity17502 : scanCanonicalize (H12AffineFastState.compose env17502 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound17502 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4161,329867,120014,21763,8328,64,43357,115151,102878,324820,1501,272392,257,21793,46213,74250]

theorem envBound17503 : H12AffineFastState.Bounded env17503 := by
  intro p hp
  have h : env17503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17502_17503 : H12AffineEnvironment.transform 16 122907 env17502 = env17503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env17502 == env17503) = true)

def env17504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10400,1025,32769,4161,73771,120014,21763,8328,64,43357,115151,102878,56436,1501,168,257,21793,46213,74250]

theorem envBound17504 : H12AffineFastState.Bounded env17504 := by
  intro p hp
  have h : env17504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17503_17504 : H12AffineEnvironment.transform 17 10400 env17503 = env17504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env17503 == env17504) = true)

theorem identity17504 : scanCanonicalize (H12AffineFastState.compose env17504 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound17504 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env17505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,65536,90258,10400,1025,136,4161,73771,87111,21763,8328,64,10708,82246,69975,23805,1501,168,257,21793,13324,74250]

theorem envBound17505 : H12AffineFastState.Bounded env17505 := by
  intro p hp
  have h : env17505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17504_17505 : H12AffineEnvironment.transform 14 137 env17504 = env17505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env17504 == env17505) = true)

theorem identity17505 : scanCanonicalize (H12AffineFastState.compose env17505 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17505 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env17506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,90138,10280,1025,0,4161,73771,87111,21763,8192,64,10588,82246,69975,23669,1365,32,257,21793,13324,74250]

theorem envBound17506 : H12AffineFastState.Bounded env17506 := by
  intro p hp
  have h : env17506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17505_17506 : H12AffineEnvironment.transform 6 8 env17505 = env17506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17505 == env17506) = true)

theorem identity17506 : scanCanonicalize (H12AffineFastState.compose env17506 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound17506 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,65536,70726,10280,1025,0,4161,73771,73755,8543,8192,64,10588,79130,69975,10281,1365,32,257,8573,13324,74250]

theorem envBound17507 : H12AffineFastState.Bounded env17507 := by
  intro p hp
  have h : env17507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17506_17507 : H12AffineEnvironment.transform 13 13404 env17506 = env17507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env17506 == env17507) = true)

theorem identity17507 : scanCanonicalize (H12AffineFastState.compose env17507 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound17507 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env17508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,1094,4096,10280,1025,0,4161,9325,9309,8543,8192,64,10588,12636,5393,10281,1365,32,257,8573,13324,9804]

theorem envBound17508 : H12AffineFastState.Bounded env17508 := by
  intro p hp
  have h : env17508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17507_17508 : H12AffineEnvironment.transform 15 1094 env17507 = env17508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env17507 == env17508) = true)

theorem identity17508 : scanCanonicalize (H12AffineFastState.compose env17508 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound17508 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env17509 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,1094,4096,2420,1025,0,4161,1329,1281,3,348,64,2048,4096,5393,2421,1365,32,257,33,5456,1808]

theorem envBound17509 : H12AffineFastState.Bounded env17509 := by
  intro p hp
  have h : env17509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17508_17509 : H12AffineEnvironment.transform 12 348 env17508 = env17509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env17508 == env17509) = true)

theorem identity17509 : scanCanonicalize (H12AffineFastState.compose env17509 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound17509 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17510 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4113,1,343,4096,2420,272,0,4161,32,16,3,348,64,2048,4096,4096,2421,68,32,257,33,4161,513]

theorem envBound17510 : H12AffineFastState.Bounded env17510 := by
  intro p hp
  have h : env17510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17509_17510 : H12AffineEnvironment.transform 9 273 env17509 = env17510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17509 == env17510) = true)

theorem identity17510 : scanCanonicalize (H12AffineFastState.compose env17510 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17510 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17511 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,269,4113,1,262,4096,2341,272,0,4112,32,16,3,269,17,2048,4096,4096,2340,21,32,257,33,4112,513]

theorem envBound17511 : H12AffineFastState.Bounded env17511 := by
  intro p hp
  have h : env17511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17510_17511 : H12AffineEnvironment.transform 5 17 env17510 = env17511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17510 == env17511) = true)

theorem identity17511 : scanCanonicalize (H12AffineFastState.compose env17511 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound17511 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17512 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,16,269,1,1,262,16,2341,272,0,0,32,16,3,269,17,2048,16,16,2340,21,32,257,33,0,513]

theorem envBound17512 : H12AffineFastState.Bounded env17512 := by
  intro p hp
  have h : env17512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17511_17512 : H12AffineEnvironment.transform 11 16 env17511 = env17512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env17511 == env17512) = true)

theorem identity17512 : scanCanonicalize (H12AffineFastState.compose env17512 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound17512 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17513 : List Nat := [2,4,8,16,32,17,8,256,512,273,292,16,269,1,1,262,16,1,272,0,0,32,16,3,269,17,292,16,16,0,21,32,257,33,0,513]

theorem envBound17513 : H12AffineFastState.Bounded env17513 := by
  intro p hp
  have h : env17513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17512_17513 : H12AffineEnvironment.transform 10 292 env17512 = env17513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env17512 == env17513) = true)

theorem identity17513 : scanCanonicalize (H12AffineFastState.compose env17513 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17513 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17514 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,16,41,1,1,34,16,1,52,0,0,32,16,3,41,17,0,16,16,0,21,32,37,33,0,513]

theorem envBound17514 : H12AffineFastState.Bounded env17514 := by
  intro p hp
  have h : env17514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17513_17514 : H12AffineEnvironment.transform 7 36 env17513 = env17514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17513 == env17514) = true)

theorem identity17514 : scanCanonicalize (H12AffineFastState.compose env17514 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17514 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17515 : List Nat := [2,4,8,16,32,17,8,36,0,53,0,16,41,1,1,34,16,1,52,0,0,32,16,3,41,17,0,16,16,0,21,32,37,33,0,1]

theorem envBound17515 : H12AffineFastState.Bounded env17515 := by
  intro p hp
  have h : env17515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17514_17515 : H12AffineEnvironment.transform 8 0 env17514 = env17515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17514 == env17515) = true)

theorem identity17515 : scanCanonicalize (H12AffineFastState.compose env17515 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound17515 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17516 : List Nat := [2,4,8,16,11,17,8,15,0,30,0,16,2,1,1,9,16,1,31,0,0,11,16,3,2,17,0,16,16,0,21,11,14,10,0,1]

theorem envBound17516 : H12AffineFastState.Bounded env17516 := by
  intro p hp
  have h : env17516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17515_17516 : H12AffineEnvironment.transform 4 11 env17515 = env17516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env17515 == env17516) = true)

def env17517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10401,1025,32769,4161,73770,120014,21763,8328,64,43357,115151,102878,56437,1501,169,257,21793,46213,74250]

theorem envBound17517 : H12AffineFastState.Bounded env17517 := by
  intro p hp
  have h : env17517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17503_17517 : H12AffineEnvironment.transform 17 10401 env17503 = env17517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env17503 == env17517) = true)

theorem identity17517 : scanCanonicalize (H12AffineFastState.compose env17517 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound17517 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env17518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49305,10401,1025,32769,4161,168,62540,21763,8328,64,43357,57677,45404,56437,1501,169,257,21793,46213,648]

theorem envBound17518 : H12AffineFastState.Bounded env17518 := by
  intro p hp
  have h : env17518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17517_17518 : H12AffineEnvironment.transform 15 8322 env17517 = env17518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env17517 == env17518) = true)

theorem identity17518 : scanCanonicalize (H12AffineFastState.compose env17518 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound17518 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env17519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,342,49305,2421,1025,32769,4161,168,54680,21763,348,64,34953,49305,37000,56437,1501,169,257,21793,38225,648]

theorem envBound17519 : H12AffineFastState.Bounded env17519 := by
  intro p hp
  have h : env17519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17518_17519 : H12AffineEnvironment.transform 12 468 env17518 = env17519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env17518 == env17519) = true)

theorem identity17519 : scanCanonicalize (H12AffineFastState.compose env17519 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound17519 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env17520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,136,342,16401,2421,1025,137,4161,168,21776,21763,348,64,2049,16401,4096,23805,1501,169,257,21793,5593,648]

theorem envBound17520 : H12AffineFastState.Bounded env17520 := by
  intro p hp
  have h : env17520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17519_17520 : H12AffineEnvironment.transform 14 136 env17519 = env17520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env17519 == env17520) = true)

theorem identity17520 : scanCanonicalize (H12AffineFastState.compose env17520 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17520 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,342,16401,2421,1025,0,4161,33,21776,21763,348,64,2049,16401,4096,23668,1364,32,257,21793,5456,513]

theorem envBound17521 : H12AffineFastState.Bounded env17521 := by
  intro p hp
  have h : env17521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17520_17521 : H12AffineEnvironment.transform 6 9 env17520 = env17521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17520 == env17521) = true)

theorem identity17521 : scanCanonicalize (H12AffineFastState.compose env17521 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound17521 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4113,1,342,4096,2421,1025,0,4161,33,1281,1298,348,64,2049,4096,4096,3173,1364,32,257,1328,5456,513]

theorem envBound17522 : H12AffineFastState.Bounded env17522 := by
  intro p hp
  have h : env17522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17521_17522 : H12AffineEnvironment.transform 13 4113 env17521 = env17522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env17521 == env17522) = true)

theorem identity17522 : scanCanonicalize (H12AffineFastState.compose env17522 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound17522 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env17523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,349,2128,1,342,2113,2421,1025,0,2048,33,1281,1298,348,64,2049,2113,2113,3173,1364,32,257,1328,3345,513]

theorem envBound17523 : H12AffineFastState.Bounded env17523 := by
  intro p hp
  have h : env17523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17522_17523 : H12AffineEnvironment.transform 11 2113 env17522 = env17523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env17522 == env17523) = true)

theorem identity17523 : scanCanonicalize (H12AffineFastState.compose env17523 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17523 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env17524 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2113,349,2128,1,342,2113,2421,52,0,2048,33,308,295,348,64,2049,2113,2113,2128,353,32,257,261,2340,513]

theorem envBound17524 : H12AffineFastState.Bounded env17524 := by
  intro p hp
  have h : env17524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17523_17524 : H12AffineEnvironment.transform 9 53 env17523 = env17524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17523 == env17524) = true)

theorem identity17524 : scanCanonicalize (H12AffineFastState.compose env17524 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17524 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env17525 : List Nat := [2,4,8,16,32,64,9,36,512,53,2048,2113,121,2128,1,114,2113,2129,52,0,2048,33,16,3,120,64,2049,2113,2113,2128,69,32,37,33,2048,513]

theorem envBound17525 : H12AffineFastState.Bounded env17525 := by
  intro p hp
  have h : env17525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17524_17525 : H12AffineEnvironment.transform 7 36 env17524 = env17525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17524 == env17525) = true)

theorem identity17525 : scanCanonicalize (H12AffineFastState.compose env17525 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17525 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17526 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2064,40,2049,1,35,2064,2048,52,0,2048,33,16,3,41,17,2049,2064,2064,2049,20,32,37,33,2048,513]

theorem envBound17526 : H12AffineFastState.Bounded env17526 := by
  intro p hp
  have h : env17526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17525_17526 : H12AffineEnvironment.transform 5 17 env17525 = env17526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17525 == env17526) = true)

def env17527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,2237588,242968,8328,64,2144541,2240917,160197,2417813,2102684,2373704,257,21793,46213,2175563]

theorem envBound17527 : H12AffineFastState.Bounded env17527 := by
  intro p hp
  have h : env17527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17482_17527 : H12AffineEnvironment.transform 21 452753 env17482 = env17527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452753 env17482 == env17527) = true)

def env17528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,144596,242968,8328,64,43357,139733,160197,324821,1500,272392,257,21793,46213,74251]

theorem envBound17528 : H12AffineFastState.Bounded env17528 := by
  intro p hp
  have h : env17528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17527_17528 : H12AffineEnvironment.transform 20 4160 env17527 = env17528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17527 == env17528) = true)

theorem identity17528 : scanCanonicalize (H12AffineFastState.compose env17528 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound17528 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70863,262144,1025,32769,4160,392286,73755,41431,8328,64,43357,79130,91402,324821,1500,272392,257,21793,46213,74251]

theorem envBound17529 : H12AffineFastState.Bounded env17529 := by
  intro p hp
  have h : env17529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17528_17529 : H12AffineEnvironment.transform 16 70863 env17528 = env17529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env17528 == env17529) = true)

def env17530 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,4160,392286,73755,41311,8192,64,43357,79130,91402,324701,1364,272392,257,21793,46093,74251]

theorem envBound17530 : H12AffineFastState.Bounded env17530 := by
  intro p hp
  have h : env17530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17529_17530 : H12AffineEnvironment.transform 6 8 env17529 = env17530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17529 == env17530) = true)

theorem identity17530 : scanCanonicalize (H12AffineFastState.compose env17530 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound17530 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env17531 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,67619,1025,32769,4160,62589,73755,41311,8192,64,43357,79130,91402,130174,1364,73771,257,21793,46093,74251]

theorem envBound17531 : H12AffineFastState.Bounded env17531 := by
  intro p hp
  have h : env17531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17530_17531 : H12AffineEnvironment.transform 17 67619 env17530 = env17531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env17530 == env17531) = true)

theorem identity17531 : scanCanonicalize (H12AffineFastState.compose env17531 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17531 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17532 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,13389,10281,1025,32769,4160,62589,17,41311,8192,64,43357,5392,17664,56436,1364,33,257,21793,46093,513]

theorem envBound17532 : H12AffineFastState.Bounded env17532 := by
  intro p hp
  have h : env17532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17531_17532 : H12AffineEnvironment.transform 15 8202 env17531 = env17532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17531 == env17532) = true)

theorem identity17532 : scanCanonicalize (H12AffineFastState.compose env17532 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound17532 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env17533 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8202,13389,10281,1025,21761,4160,8573,17,29791,8192,64,31837,5392,17664,2420,1364,33,257,21793,24845,513]

theorem envBound17533 : H12AffineFastState.Bounded env17533 := by
  intro p hp
  have h : env17533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17532_17533 : H12AffineEnvironment.transform 14 21760 env17532 = env17533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env17532 == env17533) = true)

theorem identity17533 : scanCanonicalize (H12AffineFastState.compose env17533 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound17533 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17534 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,8202,13389,10281,1025,0,4160,8573,17,8542,8192,64,10588,5392,4097,2420,1364,33,257,32,13324,513]

theorem envBound17534 : H12AffineFastState.Bounded env17534 := by
  intro p hp
  have h : env17534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17533_17534 : H12AffineEnvironment.transform 13 5377 env17533 = env17534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env17533 == env17534) = true)

def env17535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,4160,392286,73755,41310,8193,64,43357,79130,91402,324700,1365,272392,257,21793,46092,74251]

theorem envBound17535 : H12AffineFastState.Bounded env17535 := by
  intro p hp
  have h : env17535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17529_17535 : H12AffineEnvironment.transform 6 9 env17529 = env17535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17529 == env17535) = true)

theorem identity17535 : scanCanonicalize (H12AffineFastState.compose env17535 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 76158) := by decide +kernel

theorem selectedBound17535 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env17536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,76158,1025,32769,4160,54560,73755,41310,8193,64,43357,79130,91402,122146,1365,65910,257,21793,46092,74251]

theorem envBound17536 : H12AffineFastState.Bounded env17536 := by
  intro p hp
  have h : env17536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17535_17536 : H12AffineEnvironment.transform 17 76158 env17535 = env17536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76158 env17535 == env17536) = true)

theorem identity17536 : scanCanonicalize (H12AffineFastState.compose env17536 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound17536 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env17537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,16400,32040,1025,32769,4160,54560,29773,41310,8193,64,43357,24908,12636,35188,1365,21792,257,21793,46092,30301]

theorem envBound17537 : H12AffineFastState.Bounded env17537 := by
  intro p hp
  have h : env17537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17536_17537 : H12AffineEnvironment.transform 15 21590 env17536 = env17537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env17536 == env17537) = true)

theorem identity17537 : scanCanonicalize (H12AffineFastState.compose env17537 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound17537 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env17538 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21590,16400,32040,1025,29789,4160,8572,29773,21762,8193,64,23809,24908,12636,32040,1365,21792,257,21793,16464,30301]

theorem envBound17538 : H12AffineFastState.Bounded env17538 := by
  intro p hp
  have h : env17538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17537_17538 : H12AffineEnvironment.transform 14 29788 env17537 = env17538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env17537 == env17538) = true)

theorem identity17538 : scanCanonicalize (H12AffineFastState.compose env17538 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound17538 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env17539 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,372,8574,13624,2048,1025,373,4160,8572,357,8234,8193,64,10281,5220,12636,2048,1365,8200,257,8201,13688,885]

theorem envBound17539 : H12AffineFastState.Bounded env17539 := by
  intro p hp
  have h : env17539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17538_17539 : H12AffineEnvironment.transform 13 13608 env17538 = env17539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env17538 == env17539) = true)

theorem identity17539 : scanCanonicalize (H12AffineFastState.compose env17539 (packedSelected [2,3,5,10,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound17539 : packedSelected [2,3,5,10,12,14] rootPS < 2^1333 := by decide +kernel

def env17540 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4160,372,1046,4176,2048,1025,373,4160,1044,357,1346,1385,64,3393,5220,5172,2048,1365,1376,257,1377,4112,885]

theorem envBound17540 : H12AffineFastState.Bounded env17540 := by
  intro p hp
  have h : env17540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17539_17540 : H12AffineEnvironment.transform 12 1384 env17539 = env17540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env17539 == env17540) = true)

theorem identity17540 : scanCanonicalize (H12AffineFastState.compose env17540 (packedSelected [0,2,4,7,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound17540 : packedSelected [0,2,4,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env17541 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,121,4160,372,263,4176,2048,272,373,4160,261,357,83,120,64,2128,4469,4389,2048,68,113,257,112,4112,885]

theorem envBound17541 : H12AffineFastState.Bounded env17541 := by
  intro p hp
  have h : env17541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17540_17541 : H12AffineEnvironment.transform 9 273 env17540 = env17541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17540 == env17541) = true)

theorem identity17541 : scanCanonicalize (H12AffineFastState.compose env17541 (packedSelected [0,1,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound17541 : packedSelected [0,1,6,7,8] rootPS < 2^1333 := by decide +kernel

def env17542 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,64,121,0,372,263,16,2048,272,373,0,261,357,83,120,64,2128,309,357,2048,68,113,257,112,80,885]

theorem envBound17542 : H12AffineFastState.Bounded env17542 := by
  intro p hp
  have h : env17542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17541_17542 : H12AffineEnvironment.transform 11 64 env17541 = env17542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env17541 == env17542) = true)

theorem identity17542 : scanCanonicalize (H12AffineFastState.compose env17542 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17542 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17543 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,16,41,0,292,263,16,2048,272,293,0,261,309,3,40,16,2048,309,309,2048,20,33,257,32,0,805]

theorem envBound17543 : H12AffineFastState.Bounded env17543 := by
  intro p hp
  have h : env17543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17542_17543 : H12AffineEnvironment.transform 5 16 env17542 = env17543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17542 == env17543) = true)

theorem identity17543 : scanCanonicalize (H12AffineFastState.compose env17543 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound17543 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env17544 : List Nat := [2,4,8,16,32,16,9,256,512,273,544,16,41,0,292,263,16,544,272,293,0,261,309,3,40,16,544,309,309,544,20,33,257,32,0,805]

theorem envBound17544 : H12AffineFastState.Bounded env17544 := by
  intro p hp
  have h : env17544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17543_17544 : H12AffineEnvironment.transform 10 544 env17543 = env17544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env17543 == env17544) = true)

theorem identity17544 : scanCanonicalize (H12AffineFastState.compose env17544 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound17544 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env17545 : List Nat := [2,4,8,16,32,16,9,256,33,273,1,16,41,0,292,263,16,1,272,293,0,261,309,3,40,16,1,309,309,1,20,33,257,32,0,260]

theorem envBound17545 : H12AffineFastState.Bounded env17545 := by
  intro p hp
  have h : env17545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17544_17545 : H12AffineEnvironment.transform 8 33 env17544 = env17545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env17544 == env17545) = true)

theorem identity17545 : scanCanonicalize (H12AffineFastState.compose env17545 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17545 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17546 : List Nat := [2,4,8,16,32,16,9,36,33,53,1,16,41,0,0,35,16,1,52,1,0,33,17,3,40,16,1,17,17,1,20,33,37,32,0,32]

theorem envBound17546 : H12AffineFastState.Bounded env17546 := by
  intro p hp
  have h : env17546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17545_17546 : H12AffineEnvironment.transform 7 36 env17545 = env17546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17545 == env17546) = true)

theorem identity17546 : scanCanonicalize (H12AffineFastState.compose env17546 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound17546 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17547 : List Nat := [2,4,8,16,17,16,9,21,16,4,1,16,24,0,0,18,16,1,5,1,0,16,17,3,25,16,1,17,17,1,20,16,20,17,0,17]

theorem envBound17547 : H12AffineFastState.Bounded env17547 := by
  intro p hp
  have h : env17547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17546_17547 : H12AffineEnvironment.transform 4 17 env17546 = env17547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env17546 == env17547) = true)

def env17548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,144597,242968,8328,64,43356,139732,160197,324820,1501,272393,257,21793,46213,74250]

theorem envBound17548 : H12AffineFastState.Bounded env17548 := by
  intro p hp
  have h : env17548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17527_17548 : H12AffineEnvironment.transform 20 4161 env17527 = env17548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17527 == env17548) = true)

theorem identity17548 : scanCanonicalize (H12AffineFastState.compose env17548 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound17548 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4161,452753,144597,156103,8328,64,43356,139732,160197,324820,1501,272393,257,21793,46213,63189]

theorem envBound17549 : H12AffineFastState.Bounded env17549 := by
  intro p hp
  have h : env17549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17548_17549 : H12AffineEnvironment.transform 15 54495 env17548 = env17549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env17548 == env17549) = true)

def env17550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16448,262144,1025,32769,4161,305361,29845,8583,8328,64,43356,24980,12677,324820,1501,272393,257,21793,46213,63189]

theorem envBound17550 : H12AffineFastState.Bounded env17550 := by
  intro p hp
  have h : env17550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17549_17550 : H12AffineEnvironment.transform 16 16448 env17549 = env17550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env17549 == env17550) = true)

theorem identity17550 : scanCanonicalize (H12AffineFastState.compose env17550 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound17550 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env17551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,30083,16448,262144,1025,8541,4161,264589,29845,8583,8328,64,2048,24980,12677,284040,1501,272393,257,21793,5593,22409]

theorem envBound17551 : H12AffineFastState.Bounded env17551 := by
  intro p hp
  have h : env17551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17550_17551 : H12AffineEnvironment.transform 14 8540 env17550 = env17551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env17550 == env17551) = true)

theorem identity17551 : scanCanonicalize (H12AffineFastState.compose env17551 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound17551 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env17552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,30083,16448,32041,1025,8541,4161,29860,29845,8583,8328,64,2048,24980,12677,10401,1501,21792,257,21793,5593,22409]

theorem envBound17552 : H12AffineFastState.Bounded env17552 := by
  intro p hp
  have h : env17552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17551_17552 : H12AffineEnvironment.transform 17 32041 env17551 = env17552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env17551 == env17552) = true)

theorem identity17552 : scanCanonicalize (H12AffineFastState.compose env17552 (packedSelected [0,3,4,5,7,9,11,15,17,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound17552 : packedSelected [0,3,4,5,7,9,11,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env17553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,8540,343,13460,2557,1025,8541,4161,112,65,8583,8328,64,2048,5440,12677,10401,1501,8692,257,8693,5593,9053]

theorem envBound17553 : H12AffineFastState.Bounded env17553 := by
  intro p hp
  have h : env17553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17552_17553 : H12AffineEnvironment.transform 13 13524 env17552 = env17553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env17552 == env17553) = true)

theorem identity17553 : scanCanonicalize (H12AffineFastState.compose env17553 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound17553 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env17554 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,13324,8540,343,13388,2341,1025,8541,4161,112,65,8543,8272,64,2048,5440,12637,10361,1285,8492,257,8493,5377,9053]

theorem envBound17554 : H12AffineFastState.Bounded env17554 := by
  intro p hp
  have h : env17554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17553_17554 : H12AffineEnvironment.transform 6 88 env17553 = env17554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env17553 == env17554) = true)

theorem identity17554 : scanCanonicalize (H12AffineFastState.compose env17554 (packedSelected [2,4,6,9,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound17554 : packedSelected [2,4,6,9,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env17555 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,1337,4405,1125,343,4469,2341,1025,1124,4161,112,65,1126,1385,64,2048,5440,5220,3392,1285,1045,257,1044,5377,1636]

theorem envBound17555 : H12AffineFastState.Bounded env17555 := by
  intro p hp
  have h : env17555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17554_17555 : H12AffineEnvironment.transform 12 1337 env17554 = env17555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env17554 == env17555) = true)

theorem identity17555 : scanCanonicalize (H12AffineFastState.compose env17555 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17555 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env17556 : List Nat := [2,4,8,16,32,64,88,256,512,53,2048,4096,268,4405,80,343,4469,2341,52,81,4161,112,65,83,348,64,2048,4469,4177,2421,304,32,257,33,4404,593]

theorem envBound17556 : H12AffineFastState.Bounded env17556 := by
  intro p hp
  have h : env17556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17555_17556 : H12AffineEnvironment.transform 9 53 env17555 = env17556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17555 == env17556) = true)

theorem identity17556 : scanCanonicalize (H12AffineFastState.compose env17556 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound17556 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env17557 : List Nat := [2,4,8,16,32,64,88,256,512,53,2048,261,268,48,80,343,112,2341,52,81,324,112,65,83,348,64,2048,112,340,2421,304,32,257,33,49,593]

theorem envBound17557 : H12AffineFastState.Bounded env17557 := by
  intro p hp
  have h : env17557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17556_17557 : H12AffineEnvironment.transform 11 261 env17556 = env17557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env17556 == env17557) = true)

theorem identity17557 : scanCanonicalize (H12AffineFastState.compose env17557 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound17557 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17558 : List Nat := [2,4,8,16,32,49,41,256,512,53,2048,261,268,48,33,294,1,2341,52,32,309,1,48,34,301,49,2048,1,293,2308,304,32,257,33,49,544]

theorem envBound17558 : H12AffineFastState.Bounded env17558 := by
  intro p hp
  have h : env17558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17557_17558 : H12AffineEnvironment.transform 5 49 env17557 = env17558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env17557 == env17558) = true)

theorem identity17558 : scanCanonicalize (H12AffineFastState.compose env17558 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17558 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17559 : List Nat := [2,4,8,16,1,16,8,256,512,20,2048,261,268,17,0,263,1,2308,21,1,276,1,17,3,268,16,2048,1,260,2308,273,1,257,0,16,513]

theorem envBound17559 : H12AffineFastState.Bounded env17559 := by
  intro p hp
  have h : env17559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17558_17559 : H12AffineEnvironment.transform 4 1 env17558 = env17559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17558 == env17559) = true)

theorem identity17559 : scanCanonicalize (H12AffineFastState.compose env17559 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17559 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17560 : List Nat := [2,4,8,16,1,16,8,5,512,20,2048,0,9,17,0,2,1,2049,21,1,17,1,17,3,9,16,2048,1,1,2049,20,1,4,0,16,513]

theorem envBound17560 : H12AffineFastState.Bounded env17560 := by
  intro p hp
  have h : env17560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17559_17560 : H12AffineEnvironment.transform 7 5 env17559 = env17560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17559 == env17560) = true)

theorem identity17560 : scanCanonicalize (H12AffineFastState.compose env17560 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound17560 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17561 : List Nat := [2,4,8,16,1,16,8,5,20,20,2048,0,9,17,0,2,1,2049,21,1,17,1,17,3,9,16,2048,1,1,2049,20,1,4,0,16,21]

theorem envBound17561 : H12AffineFastState.Bounded env17561 := by
  intro p hp
  have h : env17561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17560_17561 : H12AffineEnvironment.transform 8 20 env17560 = env17561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env17560 == env17561) = true)

theorem identity17561 : scanCanonicalize (H12AffineFastState.compose env17561 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 18) := by decide +kernel

theorem selectedBound17561 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17562 : List Nat := [2,4,8,16,1,16,8,5,20,20,18,0,9,17,0,2,1,19,21,1,17,1,17,3,9,16,18,1,1,19,20,1,4,0,16,21]

theorem envBound17562 : H12AffineFastState.Bounded env17562 := by
  intro p hp
  have h : env17562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17561_17562 : H12AffineEnvironment.transform 10 18 env17561 = env17562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 18 env17561 == env17562) = true)

theorem identity17562 : scanCanonicalize (H12AffineFastState.compose env17562 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound17562 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17563 : List Nat := [2,4,5,16,1,16,5,5,20,20,18,0,4,17,0,2,1,19,21,1,17,1,17,3,4,16,18,1,1,19,20,1,4,0,16,21]

theorem envBound17563 : H12AffineFastState.Bounded env17563 := by
  intro p hp
  have h : env17563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17562_17563 : H12AffineEnvironment.transform 2 5 env17562 = env17563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env17562 == env17563) = true)

theorem identity17563 : scanCanonicalize (H12AffineFastState.compose env17563 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound17563 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17564 : List Nat := [2,4,5,5,1,5,5,5,1,1,7,0,4,4,0,2,1,6,0,1,4,1,4,3,4,5,7,1,1,6,1,1,4,0,5,0]

theorem envBound17564 : H12AffineFastState.Bounded env17564 := by
  intro p hp
  have h : env17564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17563_17564 : H12AffineEnvironment.transform 3 5 env17563 = env17564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env17563 == env17564) = true)

def env17565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16449,262144,1025,32769,4161,305360,29844,8582,8328,64,43356,24981,12676,324820,1501,272393,257,21793,46213,63189]

theorem envBound17565 : H12AffineFastState.Bounded env17565 := by
  intro p hp
  have h : env17565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17549_17565 : H12AffineEnvironment.transform 16 16449 env17549 = env17565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env17549 == env17565) = true)

theorem identity17565 : scanCanonicalize (H12AffineFastState.compose env17565 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound17565 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env17566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29962,16449,262144,1025,8660,4161,264453,29844,8582,8328,64,2185,24981,12676,283905,1501,272393,257,21793,5456,22272]

theorem envBound17566 : H12AffineFastState.Bounded env17566 := by
  intro p hp
  have h : env17566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17565_17566 : H12AffineEnvironment.transform 14 8661 env17565 = env17566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env17565 == env17566) = true)

theorem identity17566 : scanCanonicalize (H12AffineFastState.compose env17566 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound17566 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env17567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29962,16449,10281,1025,8660,4161,8492,29844,8582,8328,64,2185,24981,12676,32040,1501,32,257,21793,5456,22272]

theorem envBound17567 : H12AffineFastState.Bounded env17567 := by
  intro p hp
  have h : env17567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17566_17567 : H12AffineEnvironment.transform 17 10281 env17566 = env17567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env17566 == env17567) = true)

theorem identity17567 : scanCanonicalize (H12AffineFastState.compose env17567 (packedSelected [0,1,4,7,8,18,19,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound17567 : packedSelected [0,1,4,7,8,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env17568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8202,5441,10281,1025,8660,4161,8492,8596,8582,8328,64,2185,13461,12676,10280,1501,32,257,33,5456,512]

theorem envBound17568 : H12AffineFastState.Bounded env17568 := by
  intro p hp
  have h : env17568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17567_17568 : H12AffineEnvironment.transform 13 5376 env17567 = env17568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17567 == env17568) = true)

theorem identity17568 : scanCanonicalize (H12AffineFastState.compose env17568 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound17568 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17569 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,4096,8192,5376,8613,8202,5425,10281,1025,8612,4145,8492,8596,8582,8328,48,2185,13461,12676,10280,1453,32,257,33,5408,512]

theorem envBound17569 : H12AffineFastState.Bounded env17569 := by
  intro p hp
  have h : env17569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17568_17569 : H12AffineEnvironment.transform 5 48 env17568 = env17569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env17568 == env17569) = true)

theorem identity17569 : scanCanonicalize (H12AffineFastState.compose env17569 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound17569 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env17570 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,4096,40,5376,397,34,5425,2049,1025,396,4145,260,444,430,160,48,2185,5309,4524,2048,1453,32,257,33,5408,512]

theorem envBound17570 : H12AffineFastState.Bounded env17570 := by
  intro p hp
  have h : env17570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17569_17570 : H12AffineEnvironment.transform 12 40 env17569 = env17570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env17569 == env17570) = true)

theorem identity17570 : scanCanonicalize (H12AffineFastState.compose env17570 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17570 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env17571 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,9,5376,397,3,5392,2049,1025,396,4112,260,413,399,129,17,2185,5276,4493,2048,1420,1,257,0,5377,512]

theorem envBound17571 : H12AffineFastState.Bounded env17571 := by
  intro p hp
  have h : env17571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17570_17571 : H12AffineEnvironment.transform 4 1 env17570 = env17571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17570 == env17571) = true)

theorem identity17571 : scanCanonicalize (H12AffineFastState.compose env17571 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound17571 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env17572 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,538,9,1818,397,3,1802,2049,1025,396,522,260,413,399,129,17,2185,1670,919,2048,1420,1,257,0,1819,512]

theorem envBound17572 : H12AffineFastState.Bounded env17572 := by
  intro p hp
  have h : env17572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17571_17572 : H12AffineEnvironment.transform 11 538 env17571 = env17572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env17571 == env17572) = true)

theorem identity17572 : scanCanonicalize (H12AffineFastState.compose env17572 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound17572 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17573 : List Nat := [2,4,8,16,1,17,128,141,512,1024,2048,538,9,1687,0,3,1671,2049,1025,1,522,137,16,2,129,17,2185,1670,538,2048,1025,1,140,0,1686,512]

theorem envBound17573 : H12AffineFastState.Bounded env17573 := by
  intro p hp
  have h : env17573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17572_17573 : H12AffineEnvironment.transform 7 141 env17572 = env17573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env17572 == env17573) = true)

theorem identity17573 : scanCanonicalize (H12AffineFastState.compose env17573 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 670) := by decide +kernel

theorem selectedBound17573 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env17574 : List Nat := [2,4,8,16,1,17,128,141,512,670,2048,538,9,9,0,3,25,2049,671,1,522,137,16,2,129,17,2185,24,538,2048,671,1,140,0,8,512]

theorem envBound17574 : H12AffineFastState.Bounded env17574 := by
  intro p hp
  have h : env17574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17573_17574 : H12AffineEnvironment.transform 9 670 env17573 = env17574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 670 env17573 == env17574) = true)

theorem identity17574 : scanCanonicalize (H12AffineFastState.compose env17574 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17574 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17575 : List Nat := [2,4,8,16,1,17,8,5,512,534,2048,538,9,9,0,3,25,2049,535,1,522,1,16,2,9,17,2049,24,538,2048,535,1,4,0,8,512]

theorem envBound17575 : H12AffineFastState.Bounded env17575 := by
  intro p hp
  have h : env17575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17574_17575 : H12AffineEnvironment.transform 6 8 env17574 = env17575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17574 == env17575) = true)

theorem identity17575 : scanCanonicalize (H12AffineFastState.compose env17575 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound17575 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env17576 : List Nat := [2,4,8,16,1,17,8,5,512,534,523,538,9,9,0,3,25,522,535,1,522,1,16,2,9,17,522,24,538,523,535,1,4,0,8,512]

theorem envBound17576 : H12AffineFastState.Bounded env17576 := by
  intro p hp
  have h : env17576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17575_17576 : H12AffineEnvironment.transform 10 523 env17575 = env17576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env17575 == env17576) = true)

theorem identity17576 : scanCanonicalize (H12AffineFastState.compose env17576 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound17576 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17577 : List Nat := [2,4,8,16,1,17,8,5,10,28,1,16,9,9,0,3,25,0,29,1,0,1,16,2,9,17,0,24,16,1,29,1,4,0,8,10]

theorem envBound17577 : H12AffineFastState.Bounded env17577 := by
  intro p hp
  have h : env17577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17576_17577 : H12AffineEnvironment.transform 8 10 env17576 = env17577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env17576 == env17577) = true)

theorem identity17577 : scanCanonicalize (H12AffineFastState.compose env17577 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound17577 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17578 : List Nat := [2,4,8,5,1,4,8,5,10,9,1,5,9,9,0,3,12,0,8,1,0,1,5,2,9,4,0,13,5,1,8,1,4,0,8,10]

theorem envBound17578 : H12AffineFastState.Bounded env17578 := by
  intro p hp
  have h : env17578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17577_17578 : H12AffineEnvironment.transform 3 5 env17577 = env17578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env17577 == env17578) = true)

def env17579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237588,242969,8328,64,6705549,2240916,160197,2417813,2102685,6475992,257,21792,46212,2175562]

theorem envBound17579 : H12AffineFastState.Bounded env17579 := by
  intro p hp
  have h : env17579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17481_17579 : H12AffineEnvironment.transform 23 242969 env17481 = env17579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242969 env17481 == env17579) = true)

def env17580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,2237588,242969,8328,64,2144541,2240916,160197,2417813,2102685,2373704,257,21792,46212,2175562]

theorem envBound17580 : H12AffineFastState.Bounded env17580 := by
  intro p hp
  have h : env17580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17579_17580 : H12AffineEnvironment.transform 21 452752 env17579 = env17580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452752 env17579 == env17580) = true)

def env17581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,144596,242969,8328,64,43357,139732,160197,324821,1501,272392,257,21792,46212,74250]

theorem envBound17581 : H12AffineFastState.Bounded env17581 := by
  intro p hp
  have h : env17581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17580_17581 : H12AffineEnvironment.transform 20 4160 env17580 = env17581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17580 == env17581) = true)

theorem identity17581 : scanCanonicalize (H12AffineFastState.compose env17581 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound17581 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272512,62660,95497,8328,64,43357,57796,45525,324821,1501,272392,257,21792,46212,74250]

theorem envBound17582 : H12AffineFastState.Bounded env17582 := by
  intro p hp
  have h : env17582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17581_17582 : H12AffineEnvironment.transform 16 49168 env17581 = env17582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env17581 == env17582) = true)

theorem identity17582 : scanCanonicalize (H12AffineFastState.compose env17582 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17582 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env17583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,4160,272512,62660,21762,8328,64,43357,57796,45525,324821,1501,272392,257,21792,46212,513]

theorem envBound17583 : H12AffineFastState.Bounded env17583 := by
  intro p hp
  have h : env17583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17582_17583 : H12AffineEnvironment.transform 15 8203 env17582 = env17583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17582 == env17583) = true)

theorem identity17583 : scanCanonicalize (H12AffineFastState.compose env17583 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound17583 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env17584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49168,10280,1025,32769,4160,168,62660,21762,8328,64,43357,57796,45525,56573,1501,32,257,21792,46212,513]

theorem envBound17584 : H12AffineFastState.Bounded env17584 := by
  intro p hp
  have h : env17584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17583_17584 : H12AffineEnvironment.transform 17 10280 env17583 = env17584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env17583 == env17584) = true)

theorem identity17584 : scanCanonicalize (H12AffineFastState.compose env17584 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound17584 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env17585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,292,8203,16692,10280,1025,293,4160,168,30176,21762,8328,64,10361,24800,12529,24025,1501,32,257,21792,13728,513]

theorem envBound17585 : H12AffineFastState.Bounded env17585 := by
  intro p hp
  have h : env17585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17584_17585 : H12AffineEnvironment.transform 14 292 env17584 = env17585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env17584 == env17585) = true)

theorem identity17585 : scanCanonicalize (H12AffineFastState.compose env17585 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17585 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17586 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,16384,1,8203,16401,10280,1025,0,4160,168,29893,21543,8328,64,10361,24800,12529,23804,1272,32,36,21509,13445,513]

theorem envBound17586 : H12AffineFastState.Bounded env17586 := by
  intro p hp
  have h : env17586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17585_17586 : H12AffineEnvironment.transform 7 37 env17585 = env17586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17585 == env17586) = true)

theorem identity17586 : scanCanonicalize (H12AffineFastState.compose env17586 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound17586 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17587 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,4113,1,8203,4096,10280,1025,0,4160,168,9428,1078,8328,64,10361,12529,12529,3309,1272,32,36,1044,13445,513]

theorem envBound17587 : H12AffineFastState.Bounded env17587 := by
  intro p hp
  have h : env17587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17586_17587 : H12AffineEnvironment.transform 13 4113 env17586 = env17587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env17586 == env17587) = true)

theorem identity17587 : scanCanonicalize (H12AffineFastState.compose env17587 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound17587 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env17588 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,1101,4113,1,1094,4096,3173,1025,0,4160,168,153,1078,1221,64,3124,5308,5308,3309,1272,32,36,1044,4296,513]

theorem envBound17588 : H12AffineFastState.Bounded env17588 := by
  intro p hp
  have h : env17588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17587_17588 : H12AffineEnvironment.transform 12 1101 env17587 = env17588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env17587 == env17588) = true)

theorem identity17588 : scanCanonicalize (H12AffineFastState.compose env17588 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17588 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env17589 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,1101,4113,1,1094,4096,3173,1025,0,4160,33,16,1078,1100,64,3124,5173,5173,3172,1137,32,36,1044,4161,513]

theorem envBound17589 : H12AffineFastState.Bounded env17589 := by
  intro p hp
  have h : env17589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17588_17589 : H12AffineEnvironment.transform 6 9 env17588 = env17589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17588 == env17589) = true)

theorem identity17589 : scanCanonicalize (H12AffineFastState.compose env17589 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17589 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17590 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,120,4113,1,115,4096,2128,52,0,4160,33,16,3,121,64,2049,4096,4096,2129,68,32,36,33,4161,513]

theorem envBound17590 : H12AffineFastState.Bounded env17590 := by
  intro p hp
  have h : env17590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17589_17590 : H12AffineEnvironment.transform 9 53 env17589 = env17590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17589 == env17590) = true)

theorem identity17590 : scanCanonicalize (H12AffineFastState.compose env17590 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17590 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17591 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,41,4113,1,34,4096,2049,52,0,4113,33,16,3,40,17,2049,4096,4096,2048,21,32,36,33,4112,513]

theorem envBound17591 : H12AffineFastState.Bounded env17591 := by
  intro p hp
  have h : env17591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17590_17591 : H12AffineEnvironment.transform 5 17 env17590 = env17591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17590 == env17591) = true)

theorem identity17591 : scanCanonicalize (H12AffineFastState.compose env17591 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound17591 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17592 : List Nat := [2,4,8,16,32,17,9,37,512,53,529,4096,41,4113,1,34,4096,528,52,0,4113,33,16,3,40,17,528,4096,4096,529,21,32,36,33,4112,513]

theorem envBound17592 : H12AffineFastState.Bounded env17592 := by
  intro p hp
  have h : env17592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17591_17592 : H12AffineEnvironment.transform 10 529 env17591 = env17592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env17591 == env17592) = true)

theorem identity17592 : scanCanonicalize (H12AffineFastState.compose env17592 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound17592 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17593 : List Nat := [2,4,8,16,32,17,9,37,512,53,529,26,41,11,1,34,26,528,52,0,11,33,16,3,40,17,528,26,26,529,21,32,36,33,10,513]

theorem envBound17593 : H12AffineFastState.Bounded env17593 := by
  intro p hp
  have h : env17593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17592_17593 : H12AffineEnvironment.transform 11 26 env17592 = env17593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env17592 == env17593) = true)

theorem identity17593 : scanCanonicalize (H12AffineFastState.compose env17593 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound17593 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17594 : List Nat := [2,4,8,16,32,17,9,37,26,53,11,26,41,11,1,34,26,10,52,0,11,33,16,3,40,17,10,26,26,11,21,32,36,33,10,27]

theorem envBound17594 : H12AffineFastState.Bounded env17594 := by
  intro p hp
  have h : env17594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17593_17594 : H12AffineEnvironment.transform 8 26 env17593 = env17594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env17593 == env17594) = true)

def env17595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,144597,242969,8328,64,43356,139733,160197,324820,1500,272393,257,21792,46212,74251]

theorem envBound17595 : H12AffineFastState.Bounded env17595 := by
  intro p hp
  have h : env17595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17580_17595 : H12AffineEnvironment.transform 20 4161 env17580 = env17595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17580 == env17595) = true)

def env17596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,180408,144597,242969,8328,64,43356,139733,160197,56572,1500,33,257,21792,46212,74251]

theorem envBound17596 : H12AffineFastState.Bounded env17596 := by
  intro p hp
  have h : env17596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17595_17596 : H12AffineEnvironment.transform 17 10280 env17595 = env17596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env17595 == env17596) = true)

def env17597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,4161,21928,41413,73737,8328,64,43356,46277,58581,56572,1500,33,257,21792,46212,74251]

theorem envBound17597 : H12AffineFastState.Bounded env17597 := by
  intro p hp
  have h : env17597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17596_17597 : H12AffineEnvironment.transform 16 38160 env17596 = env17597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env17596 == env17597) = true)

theorem identity17597 : scanCanonicalize (H12AffineFastState.compose env17597 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound17597 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,38160,10280,1025,32769,4161,21928,41413,41430,8328,64,43356,46277,58581,56572,1500,33,257,21792,46212,41940]

theorem envBound17598 : H12AffineFastState.Bounded env17598 := by
  intro p hp
  have h : env17598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17597_17598 : H12AffineEnvironment.transform 15 33247 env17597 = env17598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env17597 == env17598) = true)

theorem identity17598 : scanCanonicalize (H12AffineFastState.compose env17598 (packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound17598 : packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env17599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,8574,13745,10280,1025,8352,4161,21928,356,375,8328,64,2557,5220,17524,31837,1500,33,257,21792,5157,885]

theorem envBound17599 : H12AffineFastState.Bounded env17599 := by
  intro p hp
  have h : env17599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17598_17599 : H12AffineEnvironment.transform 14 8353 env17598 = env17599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env17598 == env17599) = true)

theorem identity17599 : scanCanonicalize (H12AffineFastState.compose env17599 (packedSelected [3,10,12,15,18,19,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 12344) := by decide +kernel

theorem selectedBound17599 : packedSelected [3,10,12,15,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env17600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12344,8353,8574,13745,10280,1025,8352,4161,9616,356,375,8328,64,2557,5220,13388,3173,1500,33,257,9496,5157,885]

theorem envBound17600 : H12AffineFastState.Bounded env17600 := by
  intro p hp
  have h : env17600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17599_17600 : H12AffineEnvironment.transform 13 12344 env17599 = env17600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12344 env17599 == env17600) = true)

theorem identity17600 : scanCanonicalize (H12AffineFastState.compose env17600 (packedSelected [2,4,6,12,15,16,18,19,22,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound17600 : packedSelected [2,4,6,12,15,16,18,19,22,23,26] rootPS < 2^1333 := by decide +kernel

def env17601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1053,5157,1212,1379,4524,3125,1025,1213,4161,397,356,375,1173,64,2557,5220,4177,3173,1500,33,257,261,5157,885]

theorem envBound17601 : H12AffineFastState.Bounded env17601 := by
  intro p hp
  have h : env17601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17600_17601 : H12AffineEnvironment.transform 12 1053 env17600 = env17601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env17600 == env17601) = true)

theorem identity17601 : scanCanonicalize (H12AffineFastState.compose env17601 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17601 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env17602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,5157,1076,1379,4388,3125,1025,1077,4161,261,356,375,1053,64,2421,5220,4177,3173,1364,33,257,261,5157,885]

theorem envBound17602 : H12AffineFastState.Bounded env17602 := by
  intro p hp
  have h : env17602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17601_17602 : H12AffineEnvironment.transform 6 8 env17601 = env17602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17601 == env17602) = true)

theorem identity17602 : scanCanonicalize (H12AffineFastState.compose env17602 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound17602 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env17603 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,121,4161,80,263,4388,2129,101,81,4161,261,356,375,121,64,2421,4096,4177,2049,304,33,257,261,4161,885]

theorem envBound17603 : H12AffineFastState.Bounded env17603 := by
  intro p hp
  have h : env17603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17602_17603 : H12AffineEnvironment.transform 9 100 env17602 = env17603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env17602 == env17603) = true)

theorem identity17603 : scanCanonicalize (H12AffineFastState.compose env17603 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound17603 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17604 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,121,4161,80,114,4177,2129,101,81,4161,112,17,2,121,64,2048,4096,4177,2049,69,33,116,112,4161,512]

theorem envBound17604 : H12AffineFastState.Bounded env17604 := by
  intro p hp
  have h : env17604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17603_17604 : H12AffineEnvironment.transform 7 117 env17603 = env17604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env17603 == env17604) = true)

theorem identity17604 : scanCanonicalize (H12AffineFastState.compose env17604 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound17604 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17605 : List Nat := [2,4,8,16,32,48,8,5,512,20,2048,4096,9,4145,32,2,4129,2081,21,33,4145,0,17,2,9,48,2048,4096,4129,2049,53,33,4,0,4145,512]

theorem envBound17605 : H12AffineFastState.Bounded env17605 := by
  intro p hp
  have h : env17605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17604_17605 : H12AffineEnvironment.transform 5 48 env17604 = env17605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env17604 == env17605) = true)

theorem identity17605 : scanCanonicalize (H12AffineFastState.compose env17605 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound17605 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17606 : List Nat := [2,4,8,16,32,48,8,5,512,20,2048,1,9,48,32,2,32,2081,21,33,48,0,17,2,9,48,2048,1,32,2049,53,33,4,0,48,512]

theorem envBound17606 : H12AffineFastState.Bounded env17606 := by
  intro p hp
  have h : env17606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17605_17606 : H12AffineEnvironment.transform 11 1 env17605 = env17606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env17605 == env17606) = true)

theorem identity17606 : scanCanonicalize (H12AffineFastState.compose env17606 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17606 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env17607 : List Nat := [2,4,8,16,16,0,8,5,512,20,2048,1,9,0,16,2,16,2065,21,17,0,0,17,2,9,0,2048,1,16,2049,5,17,4,0,0,512]

theorem envBound17607 : H12AffineFastState.Bounded env17607 := by
  intro p hp
  have h : env17607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17606_17607 : H12AffineEnvironment.transform 4 16 env17606 = env17607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17606 == env17607) = true)

theorem identity17607 : scanCanonicalize (H12AffineFastState.compose env17607 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17607 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17608 : List Nat := [2,4,8,16,16,0,8,5,1,20,2048,1,9,0,16,2,16,2065,21,17,0,0,17,2,9,0,2048,1,16,2049,5,17,4,0,0,1]

theorem envBound17608 : H12AffineFastState.Bounded env17608 := by
  intro p hp
  have h : env17608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17607_17608 : H12AffineEnvironment.transform 8 1 env17607 = env17608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17607 == env17608) = true)

def env17609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,4161,21929,41412,73736,8328,64,43356,46276,58580,56572,1500,33,257,21792,46212,74251]

theorem envBound17609 : H12AffineFastState.Bounded env17609 := by
  intro p hp
  have h : env17609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17596_17609 : H12AffineEnvironment.transform 16 38161 env17596 = env17609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env17596 == env17609) = true)

theorem identity17609 : scanCanonicalize (H12AffineFastState.compose env17609 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound17609 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,38161,10280,1025,32769,4161,21929,41412,41310,8328,64,43356,46276,58580,56572,1500,33,257,21792,46212,41821]

theorem envBound17610 : H12AffineFastState.Bounded env17610 := by
  intro p hp
  have h : env17610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17609_17610 : H12AffineEnvironment.transform 15 33110 env17609 = env17610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env17609 == env17610) = true)

theorem identity17610 : scanCanonicalize (H12AffineFastState.compose env17610 (packedSelected [0,1,3,4,7,8,10,19,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound17610 : packedSelected [0,1,3,4,7,8,10,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env17611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1100,16384,32768,33110,38161,3172,1025,32769,4161,21929,34184,34066,1220,64,36112,37000,49304,56572,1500,33,257,21792,37064,34577]

theorem envBound17611 : H12AffineFastState.Bounded env17611 := by
  intro p hp
  have h : env17611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17610_17611 : H12AffineEnvironment.transform 12 1100 env17610 = env17611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env17610 == env17611) = true)

theorem identity17611 : scanCanonicalize (H12AffineFastState.compose env17611 (packedSelected [1,3,4,5,7,8,9,10,11,16,19,20,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5293) := by decide +kernel

theorem selectedBound17611 : packedSelected [1,3,4,5,7,8,9,10,11,16,19,20,23,27] rootPS < 2^1333 := by decide +kernel

def env17612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1100,5293,32768,33110,38161,3172,1025,32769,4161,260,34184,34066,1220,64,36112,37000,37941,34897,1500,33,257,397,37064,34577]

theorem envBound17612 : H12AffineFastState.Bounded env17612 := by
  intro p hp
  have h : env17612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17611_17612 : H12AffineEnvironment.transform 13 5293 env17611 = env17612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5293 env17611 == env17612) = true)

theorem identity17612 : scanCanonicalize (H12AffineFastState.compose env17612 (packedSelected [1,2,3,6,8,9,10,12,14,15,16,20,22,24] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound17612 : packedSelected [1,2,3,6,8,9,10,12,14,15,16,20,22,24] rootPS < 2^1333 := by decide +kernel

def env17613 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,349,4540,32768,33110,36864,2421,272,32769,4161,260,32921,32771,469,64,34817,37000,37156,34897,205,33,257,397,37064,33280]

theorem envBound17613 : H12AffineFastState.Bounded env17613 := by
  intro p hp
  have h : env17613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17612_17613 : H12AffineEnvironment.transform 9 273 env17612 = env17613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17612 == env17613) = true)

def env17614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,180409,144597,242969,8328,64,43356,139733,160197,56573,1500,32,257,21792,46212,74251]

theorem envBound17614 : H12AffineFastState.Bounded env17614 := by
  intro p hp
  have h : env17614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17595_17614 : H12AffineEnvironment.transform 17 10281 env17595 = env17614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env17595 == env17614) = true)

def env17615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4161,21929,41413,73737,8328,64,43356,46277,58581,56573,1500,32,257,21792,46212,74251]

theorem envBound17615 : H12AffineFastState.Bounded env17615 := by
  intro p hp
  have h : env17615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17614_17615 : H12AffineEnvironment.transform 16 38160 env17614 = env17615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env17614 == env17615) = true)

theorem identity17615 : scanCanonicalize (H12AffineFastState.compose env17615 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17615 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38160,10281,1025,32769,4161,21929,41413,3,8328,64,43356,46277,58581,56573,1500,32,257,21792,46212,513]

theorem envBound17616 : H12AffineFastState.Bounded env17616 := by
  intro p hp
  have h : env17616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17615_17616 : H12AffineEnvironment.transform 15 8202 env17615 = env17616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17615 == env17616) = true)

theorem identity17616 : scanCanonicalize (H12AffineFastState.compose env17616 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound17616 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env17617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8202,38160,10281,1025,32769,4161,32,41413,3,8328,64,43356,46277,45404,35188,1500,32,257,169,46212,513]

theorem envBound17617 : H12AffineFastState.Bounded env17617 := by
  intro p hp
  have h : env17617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17616_17617 : H12AffineEnvironment.transform 13 5513 env17616 = env17617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env17616 == env17617) = true)

theorem identity17617 : scanCanonicalize (H12AffineFastState.compose env17617 (packedSelected [1,4,8,9,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound17617 : packedSelected [1,4,8,9,14,16,19] rootPS < 2^1333 := by decide +kernel

def env17618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,32768,479,38160,2556,1025,32769,4161,32,32784,3,349,64,34953,38160,37001,35188,1500,32,257,169,38225,513]

theorem envBound17618 : H12AffineFastState.Bounded env17618 := by
  intro p hp
  have h : env17618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17617_17618 : H12AffineEnvironment.transform 12 469 env17617 = env17618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env17617 == env17618) = true)

theorem identity17618 : scanCanonicalize (H12AffineFastState.compose env17618 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound17618 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,137,479,5529,2556,1025,136,4161,32,153,3,349,64,2048,5529,4096,2557,1500,32,257,169,5592,513]

theorem envBound17619 : H12AffineFastState.Bounded env17619 := by
  intro p hp
  have h : env17619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17618_17619 : H12AffineEnvironment.transform 14 137 env17618 = env17619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env17618 == env17619) = true)

theorem identity17619 : scanCanonicalize (H12AffineFastState.compose env17619 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17619 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env17620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,342,5392,2421,1025,1,4161,32,16,3,349,64,2048,5392,4096,2420,1365,32,257,32,5457,513]

theorem envBound17620 : H12AffineFastState.Bounded env17620 := by
  intro p hp
  have h : env17620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17619_17620 : H12AffineEnvironment.transform 6 9 env17619 = env17620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17619 == env17620) = true)

theorem identity17620 : scanCanonicalize (H12AffineFastState.compose env17620 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1792) := by decide +kernel

theorem selectedBound17620 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1792,348,512,0,342,528,2421,1025,1,1857,32,16,3,349,64,2048,528,1792,2420,1365,32,257,32,593,513]

theorem envBound17621 : H12AffineFastState.Bounded env17621 := by
  intro p hp
  have h : env17621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17620_17621 : H12AffineEnvironment.transform 11 1792 env17620 = env17621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1792 env17620 == env17621) = true)

theorem identity17621 : scanCanonicalize (H12AffineFastState.compose env17621 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17621 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17622 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1792,269,512,0,263,528,2340,1025,1,1808,32,16,3,268,17,2048,528,1792,2341,1284,32,257,32,512,513]

theorem envBound17622 : H12AffineFastState.Bounded env17622 := by
  intro p hp
  have h : env17622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17621_17622 : H12AffineEnvironment.transform 5 17 env17621 = env17622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17621 == env17622) = true)

theorem identity17622 : scanCanonicalize (H12AffineFastState.compose env17622 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17622 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17623 : List Nat := [2,4,8,16,16,17,9,256,512,1024,2048,1792,269,512,0,263,528,2324,1025,1,1808,16,16,3,268,17,2048,528,1792,2325,1284,16,257,16,512,513]

theorem envBound17623 : H12AffineFastState.Bounded env17623 := by
  intro p hp
  have h : env17623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17622_17623 : H12AffineEnvironment.transform 4 16 env17622 = env17623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17622 == env17623) = true)

theorem identity17623 : scanCanonicalize (H12AffineFastState.compose env17623 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1808) := by decide +kernel

theorem selectedBound17623 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17624 : List Nat := [2,4,8,16,16,17,9,256,512,1024,1808,1792,269,512,0,263,528,1540,1025,1,1808,16,16,3,268,17,1808,528,1792,1541,1284,16,257,16,512,513]

theorem envBound17624 : H12AffineFastState.Bounded env17624 := by
  intro p hp
  have h : env17624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17623_17624 : H12AffineEnvironment.transform 10 1808 env17623 = env17624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1808 env17623 == env17624) = true)

theorem identity17624 : scanCanonicalize (H12AffineFastState.compose env17624 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound17624 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17625 : List Nat := [2,4,8,16,16,17,9,256,512,257,529,513,269,512,0,263,528,773,256,1,529,16,16,3,268,17,529,528,513,772,5,16,257,16,512,513]

theorem envBound17625 : H12AffineFastState.Bounded env17625 := by
  intro p hp
  have h : env17625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17624_17625 : H12AffineEnvironment.transform 9 257 env17624 = env17625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env17624 == env17625) = true)

theorem identity17625 : scanCanonicalize (H12AffineFastState.compose env17625 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound17625 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17626 : List Nat := [2,4,8,16,16,17,9,21,512,20,529,513,24,512,0,18,528,528,21,1,529,16,16,3,25,17,529,528,513,529,5,16,20,16,512,513]

theorem envBound17626 : H12AffineFastState.Bounded env17626 := by
  intro p hp
  have h : env17626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17625_17626 : H12AffineEnvironment.transform 7 21 env17625 = env17626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env17625 == env17626) = true)

theorem identity17626 : scanCanonicalize (H12AffineFastState.compose env17626 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17626 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env17627 : List Nat := [2,4,8,0,0,1,9,5,512,4,513,513,8,512,0,2,512,512,5,1,513,0,0,3,9,1,513,512,513,513,5,0,4,0,512,513]

theorem envBound17627 : H12AffineFastState.Bounded env17627 := by
  intro p hp
  have h : env17627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17626_17627 : H12AffineEnvironment.transform 3 0 env17626 = env17627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17626 == env17627) = true)

theorem identity17627 : scanCanonicalize (H12AffineFastState.compose env17627 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17627 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17628 : List Nat := [2,4,8,0,0,1,9,5,1,4,0,0,8,1,0,2,1,1,5,1,0,0,0,3,9,1,0,1,0,0,5,0,4,0,1,0]

theorem envBound17628 : H12AffineFastState.Bounded env17628 := by
  intro p hp
  have h : env17628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17627_17628 : H12AffineEnvironment.transform 8 1 env17627 = env17628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17627 == env17628) = true)

def env17629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4161,21928,41412,73736,8328,64,43356,46276,58580,56573,1500,32,257,21792,46212,74251]

theorem envBound17629 : H12AffineFastState.Bounded env17629 := by
  intro p hp
  have h : env17629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17614_17629 : H12AffineEnvironment.transform 16 38161 env17614 = env17629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env17614 == env17629) = true)

theorem identity17629 : scanCanonicalize (H12AffineFastState.compose env17629 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound17629 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,38161,10281,1025,32769,4161,21928,41412,138,8328,64,43356,46276,58580,56573,1500,32,257,21792,46212,649]

theorem envBound17630 : H12AffineFastState.Bounded env17630 := by
  intro p hp
  have h : env17630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17629_17630 : H12AffineEnvironment.transform 15 8322 env17629 = env17630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env17629 == env17630) = true)

theorem identity17630 : scanCanonicalize (H12AffineFastState.compose env17630 (packedSelected [0,1,2,6,7,8,10,11,12,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound17630 : packedSelected [0,1,2,6,7,8,10,11,12,18,20] rootPS < 2^1333 := by decide +kernel

def env17631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29828,8322,24981,10281,1025,29829,4161,21928,21824,138,8328,64,24024,16448,4176,10361,1500,32,257,21792,16384,649]

theorem envBound17631 : H12AffineFastState.Bounded env17631 := by
  intro p hp
  have h : env17631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17630_17631 : H12AffineEnvironment.transform 14 29828 env17630 = env17631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env17630 == env17631) = true)

theorem identity17631 : scanCanonicalize (H12AffineFastState.compose env17631 (packedSelected [10,11,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound17631 : packedSelected [10,11,15,18,19] rootPS < 2^1333 := by decide +kernel

def env17632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,21761,263,16400,2476,1025,21760,4161,21928,21824,138,269,64,24024,16448,4176,2556,1500,32,257,21792,16384,649]

theorem envBound17632 : H12AffineFastState.Bounded env17632 := by
  intro p hp
  have h : env17632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17631_17632 : H12AffineEnvironment.transform 12 389 env17631 = env17632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env17631 == env17632) = true)

theorem identity17632 : scanCanonicalize (H12AffineFastState.compose env17632 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17632 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17633 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21761,263,16400,2476,1025,21760,4112,21928,21777,138,269,17,23945,16401,4097,2477,1421,32,257,21792,16384,649]

theorem envBound17633 : H12AffineFastState.Bounded env17633 := by
  intro p hp
  have h : env17633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17632_17633 : H12AffineEnvironment.transform 5 17 env17632 = env17633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17632 == env17633) = true)

theorem identity17633 : scanCanonicalize (H12AffineFastState.compose env17633 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound17633 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env17634 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5512,137,263,5528,2476,1025,136,4112,32,153,138,269,17,2049,5529,4097,2477,1421,32,257,168,5512,649]

theorem envBound17634 : H12AffineFastState.Bounded env17634 := by
  intro p hp
  have h : env17634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17633_17634 : H12AffineEnvironment.transform 13 5512 env17633 = env17634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env17633 == env17634) = true)

theorem identity17634 : scanCanonicalize (H12AffineFastState.compose env17634 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17634 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env17635 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,1,263,5392,2340,1025,0,4112,32,17,2,269,17,2049,5393,4097,2341,1285,32,257,32,5376,513]

theorem envBound17635 : H12AffineFastState.Bounded env17635 := by
  intro p hp
  have h : env17635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17634_17635 : H12AffineEnvironment.transform 6 8 env17634 = env17635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17634 == env17635) = true)

theorem identity17635 : scanCanonicalize (H12AffineFastState.compose env17635 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound17635 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17636 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1280,269,0,1,263,16,2340,1025,0,1296,32,17,2,269,17,2049,17,1281,2341,1285,32,257,32,0,513]

theorem envBound17636 : H12AffineFastState.Bounded env17636 := by
  intro p hp
  have h : env17636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17635_17636 : H12AffineEnvironment.transform 11 1280 env17635 = env17636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env17635 == env17636) = true)

def env17637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,2237588,242969,8328,64,2144540,2240916,160197,2417813,2102685,2373705,257,21792,46212,2175562]

theorem envBound17637 : H12AffineFastState.Bounded env17637 := by
  intro p hp
  have h : env17637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17579_17637 : H12AffineEnvironment.transform 21 452753 env17579 = env17637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452753 env17579 == env17637) = true)

def env17638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,144596,242969,8328,64,43356,139732,160197,324821,1501,272393,257,21792,46212,74250]

theorem envBound17638 : H12AffineFastState.Bounded env17638 := by
  intro p hp
  have h : env17638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17637_17638 : H12AffineEnvironment.transform 20 4160 env17637 = env17638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17637 == env17638) = true)

theorem identity17638 : scanCanonicalize (H12AffineFastState.compose env17638 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound17638 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4160,400452,144596,213452,8328,64,23945,139732,160197,262144,1501,272393,257,21792,16465,74250]

theorem envBound17639 : H12AffineFastState.Bounded env17639 := by
  intro p hp
  have h : env17639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17638_17639 : H12AffineEnvironment.transform 14 29909 env17638 = env17639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env17638 == env17639) = true)

def env17640 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1025,29828,4112,400404,144516,213404,8328,16,23945,139652,160149,262144,1421,272393,257,21792,16385,74250]

theorem envBound17640 : H12AffineFastState.Bounded env17640 := by
  intro p hp
  have h : env17640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17639_17640 : H12AffineEnvironment.transform 5 16 env17639 = env17640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17639 == env17640) = true)

theorem identity17640 : scanCanonicalize (H12AffineFastState.compose env17640 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound17640 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env17641 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,79130,262144,1025,29828,4112,338190,65950,29830,8328,16,23945,70814,83087,262144,1421,272393,257,21792,16385,74250]

theorem envBound17641 : H12AffineFastState.Bounded env17641 := by
  intro p hp
  have h : env17641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17640_17641 : H12AffineEnvironment.transform 16 79130 env17640 = env17641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env17640 == env17641) = true)

theorem identity17641 : scanCanonicalize (H12AffineFastState.compose env17641 (packedSelected [1,3,4,7,9,10,11,14,17,24,27,28,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound17641 : packedSelected [1,3,4,7,9,10,11,14,17,24,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env17642 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8322,5528,262144,1025,29828,4112,264588,8476,29830,8328,16,23945,13340,25613,262144,1421,272393,257,21792,16385,648]

theorem envBound17642 : H12AffineFastState.Bounded env17642 := by
  intro p hp
  have h : env17642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17641_17642 : H12AffineEnvironment.transform 15 8322 env17641 = env17642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env17641 == env17642) = true)

theorem identity17642 : scanCanonicalize (H12AffineFastState.compose env17642 (packedSelected [0,2,3,5,6,7,10,12,15,16,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 31005) := by decide +kernel

theorem selectedBound17642 : packedSelected [0,2,3,5,6,7,10,12,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env17643 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8322,5528,31005,1025,29828,4112,28817,8476,29830,8328,16,23945,13340,25613,31005,1421,20756,257,21792,16385,648]

theorem envBound17643 : H12AffineFastState.Bounded env17643 := by
  intro p hp
  have h : env17643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17642_17643 : H12AffineEnvironment.transform 17 31005 env17642 = env17643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 31005 env17642 == env17643) = true)

theorem identity17643 : scanCanonicalize (H12AffineFastState.compose env17643 (packedSelected [2,3,4,5,6,10,11,16,17,18,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17643 : packedSelected [2,3,4,5,6,10,11,16,17,18,22] rootPS < 2^1333 := by decide +kernel

def env17644 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,8202,5392,31005,1025,29708,4112,28697,8476,29710,8192,16,23809,13340,25613,31005,1285,20756,257,21792,16385,512]

theorem envBound17644 : H12AffineFastState.Bounded env17644 := by
  intro p hp
  have h : env17644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17643_17644 : H12AffineEnvironment.transform 6 8 env17643 = env17644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17643 == env17644) = true)

theorem identity17644 : scanCanonicalize (H12AffineFastState.compose env17644 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound17644 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env17645 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1053,16384,20496,1047,5392,23808,1025,20497,4112,21508,1281,20499,1053,16,23809,4097,16400,23808,1285,20756,257,21792,16385,512]

theorem envBound17645 : H12AffineFastState.Bounded env17645 := by
  intro p hp
  have h : env17645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17644_17645 : H12AffineEnvironment.transform 12 1053 env17644 = env17645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env17644 == env17645) = true)

theorem identity17645 : scanCanonicalize (H12AffineFastState.compose env17645 (packedSelected [0,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound17645 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env17646 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1053,4373,261,1047,5392,3093,1025,260,4112,1297,1281,262,1053,16,3092,4097,4357,3093,1285,1,257,1077,4372,512]

theorem envBound17646 : H12AffineFastState.Bounded env17646 := by
  intro p hp
  have h : env17646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17645_17646 : H12AffineEnvironment.transform 13 4373 env17645 = env17646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env17645 == env17646) = true)

theorem identity17646 : scanCanonicalize (H12AffineFastState.compose env17646 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

end H12CloudChart1