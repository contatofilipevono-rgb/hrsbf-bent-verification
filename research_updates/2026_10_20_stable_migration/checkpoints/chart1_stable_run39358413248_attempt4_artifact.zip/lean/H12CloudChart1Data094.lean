import H12CloudChart1Data093

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound23797 : H12AffineFastState.Bounded env23797 := by
  intro p hp
  have h : env23797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23796_23797 : H12AffineEnvironment.transform 15 8203 env23796 = env23797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23796 == env23797) = true)

theorem identity23797 : scanCanonicalize (H12AffineFastState.compose env23797 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound23797 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env23798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,25028,262144,1025,8540,2097152,272513,2101329,138,8328,64,2103497,2098512,17665,2363593,2102685,2387393,257,21792,5592,2101825]

theorem envBound23798 : H12AffineFastState.Bounded env23798 := by
  intro p hp
  have h : env23798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23797_23798 : H12AffineEnvironment.transform 14 8541 env23797 = env23798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env23797 == env23798) = true)

theorem identity23798 : scanCanonicalize (H12AffineFastState.compose env23798 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23798 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env23799 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,24909,262144,1025,8540,2097152,272392,2101329,3,8193,64,2103360,2098512,17665,2363456,2102548,2387272,257,21792,5457,2101825]

theorem envBound23799 : H12AffineFastState.Bounded env23799 := by
  intro p hp
  have h : env23799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23798_23799 : H12AffineEnvironment.transform 6 9 env23798 = env23799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23798 == env23799) = true)

theorem identity23799 : scanCanonicalize (H12AffineFastState.compose env23799 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10588) := by decide +kernel

theorem selectedBound23799 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env23800 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,24909,10588,1025,8540,2097152,340,2101329,3,8193,64,2103360,2098512,17665,2111772,2102548,2114580,257,21792,5457,2101825]

theorem envBound23800 : H12AffineFastState.Bounded env23800 := by
  intro p hp
  have h : env23800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23799_23800 : H12AffineEnvironment.transform 17 10588 env23799 = env23800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10588 env23799 == env23800) = true)

theorem identity23800 : scanCanonicalize (H12AffineFastState.compose env23800 (packedSelected [1,4,5,6,8,14,17,20,22,24] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23800 : packedSelected [1,4,5,6,8,14,17,20,22,24] rootPS < 2^1333 := by decide +kernel

def env23801 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8233,8203,24633,10280,1025,8232,2097152,32,2101329,3,8193,64,2103360,2098212,17525,2111592,2102368,2114580,117,21588,5157,2101825]

theorem envBound23801 : H12AffineFastState.Bounded env23801 := by
  intro p hp
  have h : env23801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23800_23801 : H12AffineEnvironment.transform 7 116 env23800 = env23801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23800 == env23801) = true)

theorem identity23801 : scanCanonicalize (H12AffineFastState.compose env23801 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound23801 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23802 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8233,8203,24633,10280,1025,8232,4160,32,17,3,8193,64,2048,5220,17525,10280,1056,21588,117,21588,5157,513]

theorem envBound23802 : H12AffineFastState.Bounded env23802 := by
  intro p hp
  have h : env23802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23801_23802 : H12AffineEnvironment.transform 20 4160 env23801 = env23802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env23801 == env23802) = true)

theorem identity23802 : scanCanonicalize (H12AffineFastState.compose env23802 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound23802 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env23803 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,16384,80,114,16448,2129,1025,81,4160,32,17,3,120,64,2048,5220,17525,2129,1056,21588,117,21588,5157,513]

theorem envBound23803 : H12AffineFastState.Bounded env23803 := by
  intro p hp
  have h : env23803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23802_23803 : H12AffineEnvironment.transform 12 121 env23802 = env23803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env23802 == env23803) = true)

theorem identity23803 : scanCanonicalize (H12AffineFastState.compose env23803 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 7205) := by decide +kernel

theorem selectedBound23803 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env23804 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,7205,80,114,7269,2129,1025,81,4160,32,17,3,120,64,2048,5220,6224,2129,1056,2161,117,2161,5157,513]

theorem envBound23804 : H12AffineFastState.Bounded env23804 := by
  intro p hp
  have h : env23804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23803_23804 : H12AffineEnvironment.transform 13 7205 env23803 = env23804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7205 env23803 == env23804) = true)

theorem identity23804 : scanCanonicalize (H12AffineFastState.compose env23804 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound23804 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env23805 : List Nat := [2,4,8,16,32,64,9,116,512,1024,80,4096,121,5237,80,114,5173,1,1025,81,4160,32,17,3,120,64,80,5220,4096,1,1056,33,117,33,5157,513]

theorem envBound23805 : H12AffineFastState.Bounded env23805 := by
  intro p hp
  have h : env23805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23804_23805 : H12AffineEnvironment.transform 10 80 env23804 = env23805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env23804 == env23805) = true)

theorem identity23805 : scanCanonicalize (H12AffineFastState.compose env23805 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound23805 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env23806 : List Nat := [2,4,8,16,32,64,9,116,512,1024,80,64,121,1077,80,114,1141,1,1025,81,0,32,17,3,120,64,80,1060,64,1,1056,33,117,33,1125,513]

theorem envBound23806 : H12AffineFastState.Bounded env23806 := by
  intro p hp
  have h : env23806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23805_23806 : H12AffineEnvironment.transform 11 64 env23805 = env23806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env23805 == env23806) = true)

theorem identity23806 : scanCanonicalize (H12AffineFastState.compose env23806 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23806 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env23807 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1,17,40,1077,1,35,1060,1,1025,0,0,32,17,3,41,17,1,1060,17,1,1056,33,36,33,1076,513]

theorem envBound23807 : H12AffineFastState.Bounded env23807 := by
  intro p hp
  have h : env23807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23806_23807 : H12AffineEnvironment.transform 5 17 env23806 = env23807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23806 == env23807) = true)

theorem identity23807 : scanCanonicalize (H12AffineFastState.compose env23807 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound23807 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23808 : List Nat := [2,4,8,16,32,17,9,37,512,53,1,17,40,0,1,35,17,1,52,0,0,32,17,3,41,17,1,17,17,1,21,33,36,33,1,513]

theorem envBound23808 : H12AffineFastState.Bounded env23808 := by
  intro p hp
  have h : env23808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23807_23808 : H12AffineEnvironment.transform 9 53 env23807 = env23808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env23807 == env23808) = true)

theorem identity23808 : scanCanonicalize (H12AffineFastState.compose env23808 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound23808 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23809 : List Nat := [2,4,8,16,32,17,9,37,32,53,1,17,40,0,1,35,17,1,52,0,0,32,17,3,41,17,1,17,17,1,21,33,36,33,1,33]

theorem envBound23809 : H12AffineFastState.Bounded env23809 := by
  intro p hp
  have h : env23809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23808_23809 : H12AffineEnvironment.transform 8 32 env23808 = env23809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env23808 == env23809) = true)

def env23810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356289,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound23810 : H12AffineFastState.Bounded env23810 := by
  intro p hp
  have h : env23810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23537_23810 : H12AffineEnvironment.transform 26 30393345 env23537 = env23810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env23537 == env23810) = true)

def env23811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound23811 : H12AffineFastState.Bounded env23811 := by
  intro p hp
  have h : env23811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23810_23811 : H12AffineEnvironment.transform 18 1024 env23810 = env23811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env23810 == env23811) = true)

theorem identity23811 : scanCanonicalize (H12AffineFastState.compose env23811 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2213007) := by decide +kernel

theorem selectedBound23811 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2213007,16777216,8328,64,23463054,18973837,102879,2557070,18890911,23160256,256,16777250,16834951,18966345]

theorem envBound23812 : H12AffineFastState.Bounded env23812 := by
  intro p hp
  have h : env23812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23811_23812 : H12AffineEnvironment.transform 22 2213007 env23811 = env23812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2213007 env23811 == env23812) = true)

def env23813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2411540,2213007,16777216,8328,64,16959642,18973837,102879,2557070,18890911,17148372,256,16777250,16834951,18966345]

theorem envBound23813 : H12AffineFastState.Bounded env23813 := by
  intro p hp
  have h : env23813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23812_23813 : H12AffineEnvironment.transform 21 2411540 env23812 = env23813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2411540 env23812 == env23813) = true)

def env23814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,318548,120015,16777216,8328,64,16959642,16880845,102879,464078,16797919,17148372,256,16777250,16834951,16873225]

theorem envBound23814 : H12AffineFastState.Bounded env23814 := by
  intro p hp
  have h : env23814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23813_23814 : H12AffineEnvironment.transform 20 4160 env23813 = env23814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env23813 == env23814) = true)

def env23815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,4160,62708,120015,16777216,8328,64,16959642,16880845,102879,212078,16797919,16875892,256,16777250,16834951,16873225]

theorem envBound23815 : H12AffineFastState.Bounded env23815 := by
  intro p hp
  have h : env23815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23814_23815 : H12AffineEnvironment.transform 17 10400 env23814 = env23815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env23814 == env23815) = true)

def env23816 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62588,119879,16777216,8192,64,16959506,16880709,102743,212078,16797783,16875892,256,16777250,16834831,16873225]

theorem envBound23816 : H12AffineFastState.Bounded env23816 := by
  intro p hp
  have h : env23816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23815_23816 : H12AffineEnvironment.transform 6 8 env23815 = env23816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23815 == env23816) = true)

theorem identity23816 : scanCanonicalize (H12AffineFastState.compose env23816 (packedSelected [17] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound23816 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23817 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62588,119879,2,8192,64,182288,103495,102743,212078,20565,98678,256,32,57613,96011]

theorem envBound23817 : H12AffineFastState.Bounded env23817 := by
  intro p hp
  have h : env23817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23816_23817 : H12AffineEnvironment.transform 23 2 env23816 = env23817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env23816 == env23817) = true)

theorem identity23817 : scanCanonicalize (H12AffineFastState.compose env23817 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound23817 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env23818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1024,32769,4160,62588,119879,2,8192,64,108554,103495,102743,23668,20565,98678,256,32,57613,96011]

theorem envBound23818 : H12AffineFastState.Bounded env23818 := by
  intro p hp
  have h : env23818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23817_23818 : H12AffineEnvironment.transform 16 90138 env23817 = env23818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env23817 == env23818) = true)

theorem identity23818 : scanCanonicalize (H12AffineFastState.compose env23818 (packedSelected [0,2,4,6,9,11,18,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23818 : packedSelected [0,2,4,6,9,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env23819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,90138,10280,1024,0,4160,29821,87110,2,8192,64,75787,70726,69974,23668,20565,65911,256,32,24844,96011]

theorem envBound23819 : H12AffineFastState.Bounded env23819 := by
  intro p hp
  have h : env23819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23818_23819 : H12AffineEnvironment.transform 14 1 env23818 = env23819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23818 == env23819) = true)

theorem identity23819 : scanCanonicalize (H12AffineFastState.compose env23819 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound23819 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env23820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8202,16400,10280,1024,0,4160,29821,29772,2,8192,64,2049,13388,12636,23668,20565,8573,256,32,24844,22273]

theorem envBound23820 : H12AffineFastState.Bounded env23820 := by
  intro p hp
  have h : env23820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23819_23820 : H12AffineEnvironment.transform 15 8202 env23819 = env23820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env23819 == env23820) = true)

theorem identity23820 : scanCanonicalize (H12AffineFastState.compose env23820 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound23820 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env23821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,1,8202,5440,10280,1024,0,4160,8493,8476,2,8192,64,2049,13388,12636,2340,1285,8573,256,32,13404,593]

theorem envBound23821 : H12AffineFastState.Bounded env23821 := by
  intro p hp
  have h : env23821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23820_23821 : H12AffineEnvironment.transform 13 5456 env23820 = env23821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env23820 == env23821) = true)

theorem identity23821 : scanCanonicalize (H12AffineFastState.compose env23821 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23821 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env23822 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5237,1,8202,5221,10280,1024,0,4160,8200,8249,2,8192,64,2049,13388,12409,2049,1056,8280,37,32,13404,593]

theorem envBound23822 : H12AffineFastState.Bounded env23822 := by
  intro p hp
  have h : env23822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23821_23822 : H12AffineEnvironment.transform 7 37 env23821 = env23822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23821 == env23822) = true)

theorem identity23822 : scanCanonicalize (H12AffineFastState.compose env23822 (packedSelected [12,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound23822 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env23823 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,5237,1,115,5221,2129,1024,0,4160,113,64,2,121,64,2049,5173,4096,2049,1056,33,37,32,5157,593]

theorem envBound23823 : H12AffineFastState.Bounded env23823 := by
  intro p hp
  have h : env23823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23822_23823 : H12AffineEnvironment.transform 12 121 env23822 = env23823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env23822 == env23823) = true)

theorem identity23823 : scanCanonicalize (H12AffineFastState.compose env23823 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound23823 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23824 : List Nat := [2,4,8,16,32,49,8,37,512,1024,2048,4096,8,5124,1,2,5140,2080,1024,0,4145,0,49,2,8,49,2049,5173,4096,2049,1056,33,37,32,5157,544]

theorem envBound23824 : H12AffineFastState.Bounded env23824 := by
  intro p hp
  have h : env23824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23823_23824 : H12AffineEnvironment.transform 5 49 env23823 = env23824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env23823 == env23824) = true)

theorem identity23824 : scanCanonicalize (H12AffineFastState.compose env23824 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23824 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23825 : List Nat := [2,4,8,16,1,16,8,4,512,1024,2048,4096,8,5124,1,2,5140,2049,1024,0,4112,0,16,2,8,16,2049,5140,4096,2049,1025,0,4,1,5124,513]

theorem envBound23825 : H12AffineFastState.Bounded env23825 := by
  intro p hp
  have h : env23825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23824_23825 : H12AffineEnvironment.transform 4 1 env23824 = env23825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23824 == env23825) = true)

theorem identity23825 : scanCanonicalize (H12AffineFastState.compose env23825 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound23825 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23826 : List Nat := [2,4,8,16,1,16,8,4,512,20,2048,4096,8,4112,1,2,4096,2049,20,0,4112,0,16,2,8,16,2049,4096,4096,2049,21,0,4,1,4112,513]

theorem envBound23826 : H12AffineFastState.Bounded env23826 := by
  intro p hp
  have h : env23826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23825_23826 : H12AffineEnvironment.transform 9 20 env23825 = env23826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env23825 == env23826) = true)

def env23827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,62589,119878,16777216,8193,64,16959507,16880708,102742,212078,16797782,16875892,256,16777250,16834830,16873225]

theorem envBound23827 : H12AffineFastState.Bounded env23827 := by
  intro p hp
  have h : env23827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23815_23827 : H12AffineEnvironment.transform 6 9 env23815 = env23827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23815 == env23827) = true)

theorem identity23827 : scanCanonicalize (H12AffineFastState.compose env23827 (packedSelected [17] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound23827 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,62589,119878,41310,8193,64,158029,79130,102742,212078,61704,73770,256,41340,16464,120407]

theorem envBound23828 : H12AffineFastState.Bounded env23828 := by
  intro p hp
  have h : env23828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23827_23828 : H12AffineEnvironment.transform 23 41310 env23827 = env23828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env23827 == env23828) = true)

theorem identity23828 : scanCanonicalize (H12AffineFastState.compose env23828 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound23828 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env23829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,46156,10281,1024,32769,4160,62589,119878,41310,8193,64,56577,79130,102742,100386,61704,73770,256,41340,16464,120407]

theorem envBound23829 : H12AffineFastState.Bounded env23829 := by
  intro p hp
  have h : env23829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23828_23829 : H12AffineEnvironment.transform 16 46156 env23828 = env23829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env23828 == env23829) = true)

theorem identity23829 : scanCanonicalize (H12AffineFastState.compose env23829 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound23829 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9292,65536,4096,10281,1024,9293,4160,20529,94218,1298,8193,64,31053,79130,79130,76910,21828,73770,256,1328,16464,94747]

theorem envBound23830 : H12AffineFastState.Bounded env23830 := by
  intro p hp
  have h : env23830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23829_23830 : H12AffineEnvironment.transform 14 9292 env23829 = env23830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env23829 == env23830) = true)

theorem identity23830 : scanCanonicalize (H12AffineFastState.compose env23830 (packedSelected [0,1,4,7,8,11,16,18,19,20,22,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound23830 : packedSelected [0,1,4,7,8,11,16,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env23831 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,8540,65536,4096,10281,272,8541,4160,20529,94218,2,8193,64,31053,77834,77834,76158,20564,73770,256,32,16464,94747]

theorem envBound23831 : H12AffineFastState.Bounded env23831 := by
  intro p hp
  have h : env23831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23830_23831 : H12AffineEnvironment.transform 9 272 env23830 = env23831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env23830 == env23831) = true)

theorem identity23831 : scanCanonicalize (H12AffineFastState.compose env23831 (packedSelected [0,7,9,11,12,14,15,16,18,22] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound23831 : packedSelected [0,7,9,11,12,14,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env23832 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,8540,115,4096,10281,272,8541,4160,20529,28793,2,8193,64,31053,12409,12409,10509,20564,8281,256,32,16464,29288]

theorem envBound23832 : H12AffineFastState.Bounded env23832 := by
  intro p hp
  have h : env23832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23831_23832 : H12AffineEnvironment.transform 15 115 env23831 = env23832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env23831 == env23832) = true)

theorem identity23832 : scanCanonicalize (H12AffineFastState.compose env23832 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound23832 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env23833 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4452,8540,115,4096,10281,272,8541,4160,341,8477,2,8193,64,10281,12409,12409,10509,304,8281,256,32,4404,8972]

theorem envBound23833 : H12AffineFastState.Bounded env23833 := by
  intro p hp
  have h : env23833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23832_23833 : H12AffineEnvironment.transform 13 4452 env23832 = env23833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env23832 == env23833) = true)

theorem identity23833 : scanCanonicalize (H12AffineFastState.compose env23833 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23833 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23834 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,269,4452,81,115,4096,2340,272,80,4160,341,16,2,268,64,2340,4468,4468,2048,304,340,256,32,4404,513]

theorem envBound23834 : H12AffineFastState.Bounded env23834 := by
  intro p hp
  have h : env23834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23833_23834 : H12AffineEnvironment.transform 12 269 env23833 = env23834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23833 == env23834) = true)

theorem identity23834 : scanCanonicalize (H12AffineFastState.compose env23834 (packedSelected [0,1,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 772) := by decide +kernel

theorem selectedBound23834 : packedSelected [0,1,4,6] rootPS < 2^1333 := by decide +kernel

def env23835 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,772,269,608,81,115,772,2340,272,80,836,341,16,2,268,64,2340,624,624,2048,304,340,256,32,560,513]

theorem envBound23835 : H12AffineFastState.Bounded env23835 := by
  intro p hp
  have h : env23835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23834_23835 : H12AffineEnvironment.transform 11 772 env23834 = env23835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env23834 == env23835) = true)

theorem identity23835 : scanCanonicalize (H12AffineFastState.compose env23835 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23835 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env23836 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,624,121,608,81,115,624,2128,100,80,560,33,16,2,120,64,2128,624,624,2048,68,32,116,32,560,513]

theorem envBound23836 : H12AffineFastState.Bounded env23836 := by
  intro p hp
  have h : env23836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23835_23836 : H12AffineEnvironment.transform 7 116 env23835 = env23836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23835 == env23836) = true)

theorem identity23836 : scanCanonicalize (H12AffineFastState.compose env23836 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound23836 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23837 : List Nat := [2,4,8,16,32,48,9,4,512,20,2048,512,9,528,33,3,512,2080,20,32,560,33,16,2,8,48,2080,512,512,2048,52,32,4,32,560,513]

theorem envBound23837 : H12AffineFastState.Bounded env23837 := by
  intro p hp
  have h : env23837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23836_23837 : H12AffineEnvironment.transform 5 48 env23836 = env23837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env23836 == env23837) = true)

theorem identity23837 : scanCanonicalize (H12AffineFastState.compose env23837 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23837 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23838 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,512,9,528,1,3,512,2048,20,0,528,1,16,2,8,16,2048,512,512,2048,20,0,4,0,528,513]

theorem envBound23838 : H12AffineFastState.Bounded env23838 := by
  intro p hp
  have h : env23838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23837_23838 : H12AffineEnvironment.transform 4 0 env23837 = env23838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23837 == env23838) = true)

theorem identity23838 : scanCanonicalize (H12AffineFastState.compose env23838 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound23838 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23839 : List Nat := [2,4,8,16,0,16,9,4,512,20,17,512,9,528,1,3,512,17,20,0,528,1,16,2,8,16,17,512,512,17,20,0,4,0,528,513]

theorem envBound23839 : H12AffineFastState.Bounded env23839 := by
  intro p hp
  have h : env23839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23838_23839 : H12AffineEnvironment.transform 10 17 env23838 = env23839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env23838 == env23839) = true)

theorem identity23839 : scanCanonicalize (H12AffineFastState.compose env23839 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound23839 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23840 : List Nat := [2,4,8,16,0,16,9,4,0,20,17,0,9,16,1,3,0,17,20,0,16,1,16,2,8,16,17,0,0,17,20,0,4,0,16,1]

theorem envBound23840 : H12AffineFastState.Bounded env23840 := by
  intro p hp
  have h : env23840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23839_23840 : H12AffineEnvironment.transform 8 0 env23839 = env23840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23839 == env23840) = true)

theorem identity23840 : scanCanonicalize (H12AffineFastState.compose env23840 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23840 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env23841 : List Nat := [2,4,8,0,0,0,9,4,0,4,1,0,9,0,1,3,0,1,4,0,0,1,0,2,8,0,1,0,0,1,4,0,4,0,0,1]

theorem envBound23841 : H12AffineFastState.Bounded env23841 := by
  intro p hp
  have h : env23841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23840_23841 : H12AffineEnvironment.transform 3 0 env23840 = env23841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23840 == env23841) = true)

def env23842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,4160,62709,120015,16777216,8328,64,16959642,16880845,102879,212079,16797919,16875893,256,16777250,16834951,16873225]

theorem envBound23842 : H12AffineFastState.Bounded env23842 := by
  intro p hp
  have h : env23842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23814_23842 : H12AffineEnvironment.transform 17 10401 env23814 = env23842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env23814 == env23842) = true)

def env23843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,62589,119879,16777216,8192,64,16959506,16880709,102743,212079,16797783,16875893,256,16777250,16834831,16873225]

theorem envBound23843 : H12AffineFastState.Bounded env23843 := by
  intro p hp
  have h : env23843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23842_23843 : H12AffineEnvironment.transform 6 8 env23842 = env23843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23842 == env23843) = true)

theorem identity23843 : scanCanonicalize (H12AffineFastState.compose env23843 (packedSelected [17] rootPS)) = affineNative (2^(23+1) ^^^ 119893) := by decide +kernel

theorem selectedBound23843 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23844 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,62589,119879,119893,8192,64,203847,16400,102743,212079,99330,21792,256,119927,79194,41820]

theorem envBound23844 : H12AffineFastState.Bounded env23844 := by
  intro p hp
  have h : env23844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23843_23844 : H12AffineEnvironment.transform 23 119893 env23843 = env23844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119893 env23843 == env23844) = true)

theorem identity23844 : scanCanonicalize (H12AffineFastState.compose env23844 (packedSelected [1,3,4,5,7,8,9,10,14,16,19,20,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound23844 : packedSelected [1,3,4,5,7,8,9,10,14,16,19,20,27,35] rootPS < 2^1333 := by decide +kernel

def env23845 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,4160,62589,119879,119893,8192,64,31837,16400,102743,23669,99330,21792,256,119927,79194,41820]

theorem envBound23845 : H12AffineFastState.Bounded env23845 := by
  intro p hp
  have h : env23845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23844_23845 : H12AffineEnvironment.transform 16 90138 env23844 = env23845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env23844 == env23845) = true)

theorem identity23845 : scanCanonicalize (H12AffineFastState.compose env23845 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23845 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env23846 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79131,10281,1024,32769,4160,41340,98630,98644,8192,64,10588,5393,102743,2420,99330,33,256,98678,79194,41820]

theorem envBound23846 : H12AffineFastState.Bounded env23846 := by
  intro p hp
  have h : env23846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23845_23846 : H12AffineEnvironment.transform 13 5377 env23845 = env23846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23845 == env23846) = true)

theorem identity23846 : scanCanonicalize (H12AffineFastState.compose env23846 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound23846 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env23847 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,79131,10281,1024,8540,4160,33,73755,73737,8192,64,10588,5393,77834,2420,75103,33,256,73771,79194,513]

theorem envBound23847 : H12AffineFastState.Bounded env23847 := by
  intro p hp
  have h : env23847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23846_23847 : H12AffineEnvironment.transform 14 8541 env23846 = env23847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env23846 == env23847) = true)

theorem identity23847 : scanCanonicalize (H12AffineFastState.compose env23847 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound23847 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23848 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,9499,4096,10281,1024,8540,4160,33,1280,1298,8192,64,10588,5393,5393,2420,68,33,256,1328,4161,513]

theorem envBound23848 : H12AffineFastState.Bounded env23848 := by
  intro p hp
  have h : env23848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23847_23848 : H12AffineEnvironment.transform 15 9499 env23847 = env23848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env23847 == env23848) = true)

theorem identity23848 : scanCanonicalize (H12AffineFastState.compose env23848 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound23848 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env23849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3109,8192,2340,8541,9499,3109,10281,1024,8540,3173,33,1280,1298,8192,64,10588,2356,2356,2420,68,33,256,1328,3172,513]

theorem envBound23849 : H12AffineFastState.Bounded env23849 := by
  intro p hp
  have h : env23849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23848_23849 : H12AffineEnvironment.transform 11 3109 env23848 = env23849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env23848 == env23849) = true)

theorem identity23849 : scanCanonicalize (H12AffineFastState.compose env23849 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound23849 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23850 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2357,8192,2340,8541,8203,2357,10281,272,8540,2421,33,16,2,8192,64,10588,2356,2356,2420,68,33,256,32,2420,513]

theorem envBound23850 : H12AffineFastState.Bounded env23850 := by
  intro p hp
  have h : env23850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23849_23850 : H12AffineEnvironment.transform 9 272 env23849 = env23850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env23849 == env23850) = true)

theorem identity23850 : scanCanonicalize (H12AffineFastState.compose env23850 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 364) := by decide +kernel

theorem selectedBound23850 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23851 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2357,364,2340,49,359,2357,2373,272,48,2421,33,16,2,364,64,2096,2356,2356,2420,68,33,256,32,2420,513]

theorem envBound23851 : H12AffineFastState.Bounded env23851 := by
  intro p hp
  have h : env23851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23850_23851 : H12AffineEnvironment.transform 12 364 env23850 = env23851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 364 env23850 == env23851) = true)

theorem identity23851 : scanCanonicalize (H12AffineFastState.compose env23851 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23851 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env23852 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,2357,317,2340,49,310,2357,2324,272,48,2340,33,16,2,317,17,2096,2356,2356,2341,21,33,256,32,2341,513]

theorem envBound23852 : H12AffineFastState.Bounded env23852 := by
  intro p hp
  have h : env23852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23851_23852 : H12AffineEnvironment.transform 5 17 env23851 = env23852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23851 == env23852) = true)

theorem identity23852 : scanCanonicalize (H12AffineFastState.compose env23852 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound23852 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23853 : List Nat := [2,4,8,16,32,17,8,256,512,272,560,773,317,788,49,310,773,804,272,48,788,33,16,2,317,17,512,772,772,789,21,33,256,32,789,513]

theorem envBound23853 : H12AffineFastState.Bounded env23853 := by
  intro p hp
  have h : env23853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23852_23853 : H12AffineEnvironment.transform 10 560 env23852 = env23853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env23852 == env23853) = true)

theorem identity23853 : scanCanonicalize (H12AffineFastState.compose env23853 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound23853 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23854 : List Nat := [2,4,8,16,32,17,8,256,32,272,16,293,317,308,49,310,293,260,272,48,308,33,16,2,317,17,32,292,292,309,21,33,256,32,309,33]

theorem envBound23854 : H12AffineFastState.Bounded env23854 := by
  intro p hp
  have h : env23854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23853_23854 : H12AffineEnvironment.transform 8 32 env23853 = env23854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env23853 == env23854) = true)

theorem identity23854 : scanCanonicalize (H12AffineFastState.compose env23854 (packedSelected [1,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound23854 : packedSelected [1,5,9] rootPS < 2^1333 := by decide +kernel

def env23855 : List Nat := [2,4,8,16,32,17,8,52,32,36,16,17,9,0,49,2,17,48,36,48,0,33,16,2,9,17,32,16,16,1,21,33,52,32,1,33]

theorem envBound23855 : H12AffineFastState.Bounded env23855 := by
  intro p hp
  have h : env23855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23854_23855 : H12AffineEnvironment.transform 7 52 env23854 = env23855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env23854 == env23855) = true)

theorem identity23855 : scanCanonicalize (H12AffineFastState.compose env23855 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23855 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23856 : List Nat := [2,4,8,16,0,17,8,20,0,4,16,17,9,0,17,2,17,16,4,16,0,1,16,2,9,17,0,16,16,1,21,1,20,0,1,1]

theorem envBound23856 : H12AffineFastState.Bounded env23856 := by
  intro p hp
  have h : env23856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23855_23856 : H12AffineEnvironment.transform 4 0 env23855 = env23856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23855 == env23856) = true)

theorem identity23856 : scanCanonicalize (H12AffineFastState.compose env23856 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23856 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23857 : List Nat := [2,4,8,1,0,0,8,5,0,4,1,0,9,0,0,2,0,1,4,1,0,1,1,2,9,0,0,1,1,1,4,1,5,0,1,1]

theorem envBound23857 : H12AffineFastState.Bounded env23857 := by
  intro p hp
  have h : env23857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23856_23857 : H12AffineEnvironment.transform 3 1 env23856 = env23857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23856 == env23857) = true)

def env23858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62588,119878,16777216,8193,64,16959507,16880708,102742,212079,16797782,16875893,256,16777250,16834830,16873225]

theorem envBound23858 : H12AffineFastState.Bounded env23858 := by
  intro p hp
  have h : env23858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23842_23858 : H12AffineEnvironment.transform 6 9 env23842 = env23858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23842 == env23858) = true)

theorem identity23858 : scanCanonicalize (H12AffineFastState.compose env23858 (packedSelected [17] rootPS)) = affineNative (2^(23+1) ^^^ 95496) := by decide +kernel

theorem selectedBound23858 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23859 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62588,119878,95496,8193,64,245019,57676,102742,212079,75102,62589,256,95530,103430,513]

theorem envBound23859 : H12AffineFastState.Bounded env23859 := by
  intro p hp
  have h : env23859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23858_23859 : H12AffineEnvironment.transform 23 95496 env23858 = env23859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env23858 == env23859) = true)

theorem identity23859 : scanCanonicalize (H12AffineFastState.compose env23859 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound23859 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env23860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,4160,62588,119878,95496,8193,64,89174,57676,102742,122146,75102,62589,256,95530,103430,513]

theorem envBound23860 : H12AffineFastState.Bounded env23860 := by
  intro p hp
  have h : env23860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23859_23860 : H12AffineEnvironment.transform 16 57677 env23859 = env23860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env23859 == env23860) = true)

theorem identity23860 : scanCanonicalize (H12AffineFastState.compose env23860 (packedSelected [1,3,5,8,14,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 62811) := by decide +kernel

theorem selectedBound23860 : packedSelected [1,3,5,8,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env23861 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62811,57677,10280,1024,32769,4160,62588,8477,32851,8193,64,43277,57676,25613,10361,53253,62589,256,32881,24925,513]

theorem envBound23861 : H12AffineFastState.Bounded env23861 := by
  intro p hp
  have h : env23861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23860_23861 : H12AffineEnvironment.transform 15 62811 env23860 = env23861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62811 env23860 == env23861) = true)

theorem identity23861 : scanCanonicalize (H12AffineFastState.compose env23861 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound23861 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env23862 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,342,5440,10280,1024,29708,4160,113,8477,29790,8193,64,23808,5441,25613,10361,9224,112,256,29820,24925,513]

theorem envBound23862 : H12AffineFastState.Bounded env23862 := by
  intro p hp
  have h : env23862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23861_23862 : H12AffineEnvironment.transform 14 29709 env23861 = env23862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env23861 == env23862) = true)

theorem identity23862 : scanCanonicalize (H12AffineFastState.compose env23862 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23862 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23863 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21761,342,5440,2340,1024,21760,4160,113,17,21842,269,64,23808,5441,17665,2421,1284,112,256,21872,16465,513]

theorem envBound23863 : H12AffineFastState.Bounded env23863 := by
  intro p hp
  have h : env23863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23862_23863 : H12AffineEnvironment.transform 12 268 env23862 = env23863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23862 == env23863) = true)

def env23864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,318549,120014,16777216,8328,64,16959642,16880844,102879,464079,16797918,17148372,256,16777250,16834951,16873224]

theorem envBound23864 : H12AffineFastState.Bounded env23864 := by
  intro p hp
  have h : env23864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23813_23864 : H12AffineEnvironment.transform 20 4161 env23813 = env23864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env23813 == env23864) = true)

theorem identity23864 : scanCanonicalize (H12AffineFastState.compose env23864 (packedSelected [21] rootPS)) = affineNative (2^(23+1) ^^^ 95497) := by decide +kernel

theorem selectedBound23864 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,318549,120014,95497,8328,64,245139,57797,102879,464079,75223,318685,256,95531,103566,513]

theorem envBound23865 : H12AffineFastState.Bounded env23865 := by
  intro p hp
  have h : env23865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23864_23865 : H12AffineEnvironment.transform 23 95497 env23864 = env23865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env23864 == env23865) = true)

def env23866 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,318549,119878,95497,8192,64,245019,57677,102743,463943,75103,318549,256,95531,103430,513]

theorem envBound23866 : H12AffineFastState.Bounded env23866 := by
  intro p hp
  have h : env23866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23865_23866 : H12AffineEnvironment.transform 6 8 env23865 = env23866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23865 == env23866) = true)

theorem identity23866 : scanCanonicalize (H12AffineFastState.compose env23866 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound23866 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env23867 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,4161,318549,119878,95497,8192,64,56577,57677,102743,291933,75103,318549,256,95531,103430,513]

theorem envBound23867 : H12AffineFastState.Bounded env23867 := by
  intro p hp
  have h : env23867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23866_23867 : H12AffineEnvironment.transform 16 90138 env23866 = env23867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env23866 == env23867) = true)

def env23868 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1024,32769,4161,62589,119878,95497,8192,64,56577,57677,102743,23669,75103,62589,256,95531,103430,513]

theorem envBound23868 : H12AffineFastState.Bounded env23868 := by
  intro p hp
  have h : env23868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23867_23868 : H12AffineEnvironment.transform 17 10280 env23867 = env23868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23867 == env23868) = true)

theorem identity23868 : scanCanonicalize (H12AffineFastState.compose env23868 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound23868 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23869 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,46156,10280,1024,32769,4161,62589,16,41311,8192,64,56577,57677,17665,23669,61705,62589,256,41341,16464,513]

theorem envBound23869 : H12AffineFastState.Bounded env23869 := by
  intro p hp
  have h : env23869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23868_23869 : H12AffineEnvironment.transform 15 54358 env23868 = env23869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env23868 == env23869) = true)

theorem identity23869 : scanCanonicalize (H12AffineFastState.compose env23869 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 7285) := by decide +kernel

theorem selectedBound23869 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23870 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,7285,32768,34851,46156,10280,1024,32769,4161,43016,16,41311,8192,64,33140,48440,6516,0,44412,43016,256,41341,7205,513]

theorem envBound23870 : H12AffineFastState.Bounded env23870 := by
  intro p hp
  have h : env23870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23869_23870 : H12AffineEnvironment.transform 13 7285 env23869 = env23870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7285 env23869 == env23870) = true)

theorem identity23870 : scanCanonicalize (H12AffineFastState.compose env23870 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound23870 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23871 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,7285,8541,10622,5393,10280,1024,8540,4161,2389,16,2,8192,64,8233,7269,6516,0,3105,2389,256,32,7205,513]

theorem envBound23871 : H12AffineFastState.Bounded env23871 := by
  intro p hp
  have h : env23871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23870_23871 : H12AffineEnvironment.transform 14 8541 env23870 = env23871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env23870 == env23871) = true)

theorem identity23871 : scanCanonicalize (H12AffineFastState.compose env23871 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound23871 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23872 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,4096,8192,4112,8541,9499,5393,9293,1024,8540,4161,1328,16,2,8192,64,8233,4096,5393,0,68,1328,256,32,4160,513]

theorem envBound23872 : H12AffineFastState.Bounded env23872 := by
  intro p hp
  have h : env23872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23871_23872 : H12AffineEnvironment.transform 10 1125 env23871 = env23872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env23871 == env23872) = true)

theorem identity23872 : scanCanonicalize (H12AffineFastState.compose env23872 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound23872 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env23873 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,4096,121,4112,292,1378,5393,1076,1024,293,4161,1328,16,2,121,64,80,4096,5393,0,68,1328,256,32,4160,513]

theorem envBound23873 : H12AffineFastState.Bounded env23873 := by
  intro p hp
  have h : env23873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23872_23873 : H12AffineEnvironment.transform 12 121 env23872 = env23873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env23872 == env23873) = true)

theorem identity23873 : scanCanonicalize (H12AffineFastState.compose env23873 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound23873 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env23874 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,96,121,112,292,1378,1393,1076,1024,293,33,1328,16,2,121,64,80,96,1393,0,68,1328,256,32,32,513]

theorem envBound23874 : H12AffineFastState.Bounded env23874 := by
  intro p hp
  have h : env23874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23873_23874 : H12AffineEnvironment.transform 11 96 env23873 = env23874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env23873 == env23874) = true)

theorem identity23874 : scanCanonicalize (H12AffineFastState.compose env23874 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23874 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env23875 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1125,96,121,112,1,1095,1108,1076,1024,0,33,1045,16,2,121,64,80,96,1108,0,68,1045,37,32,32,513]

theorem envBound23875 : H12AffineFastState.Bounded env23875 := by
  intro p hp
  have h : env23875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23874_23875 : H12AffineEnvironment.transform 7 37 env23874 = env23875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23874 == env23875) = true)

theorem identity23875 : scanCanonicalize (H12AffineFastState.compose env23875 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound23875 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env23876 : List Nat := [2,4,8,16,17,64,8,20,512,1024,1108,81,72,65,1,1095,1108,1029,1024,0,16,1045,16,2,72,64,80,81,1108,0,68,1045,20,17,17,513]

theorem envBound23876 : H12AffineFastState.Bounded env23876 := by
  intro p hp
  have h : env23876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23875_23876 : H12AffineEnvironment.transform 4 17 env23875 = env23876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env23875 == env23876) = true)

theorem identity23876 : scanCanonicalize (H12AffineFastState.compose env23876 (packedSelected [3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound23876 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env23877 : List Nat := [2,4,8,16,17,64,8,20,512,85,1,81,72,65,1,18,1,80,85,0,16,64,16,2,72,64,80,81,1,0,68,64,20,17,17,513]

theorem envBound23877 : H12AffineFastState.Bounded env23877 := by
  intro p hp
  have h : env23877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23876_23877 : H12AffineEnvironment.transform 9 85 env23876 = env23877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env23876 == env23877) = true)

theorem identity23877 : scanCanonicalize (H12AffineFastState.compose env23877 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23877 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env23878 : List Nat := [2,4,8,0,1,64,8,4,512,69,1,65,72,65,1,2,1,64,69,0,0,64,0,2,72,64,64,65,1,0,68,64,4,1,1,513]

theorem envBound23878 : H12AffineFastState.Bounded env23878 := by
  intro p hp
  have h : env23878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23877_23878 : H12AffineEnvironment.transform 3 0 env23877 = env23878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23877 == env23878) = true)

def env23879 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,4161,62588,119878,95497,8192,64,56577,57677,102743,23668,75103,62588,256,95531,103430,513]

theorem envBound23879 : H12AffineFastState.Bounded env23879 := by
  intro p hp
  have h : env23879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23867_23879 : H12AffineEnvironment.transform 17 10281 env23867 = env23879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23867 == env23879) = true)

theorem identity23879 : scanCanonicalize (H12AffineFastState.compose env23879 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound23879 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,28698,4096,10281,1024,32769,4161,62588,42076,1299,8192,64,56577,57677,57677,23668,21829,62588,256,1329,58396,513]

theorem envBound23880 : H12AffineFastState.Bounded env23880 := by
  intro p hp
  have h : env23880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23879_23880 : H12AffineEnvironment.transform 15 28698 env23879 = env23880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env23879 == env23880) = true)

theorem identity23880 : scanCanonicalize (H12AffineFastState.compose env23880 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound23880 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,28698,4096,10281,1024,8540,4161,21793,1281,1299,8192,64,31836,16400,16400,23668,21829,21793,256,1329,17729,513]

theorem envBound23881 : H12AffineFastState.Bounded env23881 := by
  intro p hp
  have h : env23881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23880_23881 : H12AffineEnvironment.transform 14 8541 env23880 = env23881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env23880 == env23881) = true)

theorem identity23881 : scanCanonicalize (H12AffineFastState.compose env23881 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 11292) := by decide +kernel

theorem selectedBound23881 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env23882 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,11292,8541,7174,4096,10281,1024,8540,4161,14653,1281,1299,8192,64,4160,11276,11276,12392,14681,14653,256,1329,10589,513]

theorem envBound23882 : H12AffineFastState.Bounded env23882 := by
  intro p hp
  have h : env23882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23881_23882 : H12AffineEnvironment.transform 13 11292 env23881 = env23882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11292 env23881 == env23882) = true)

theorem identity23882 : scanCanonicalize (H12AffineFastState.compose env23882 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 6428) := by decide +kernel

theorem selectedBound23882 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env23883 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6428,5376,6209,7174,4096,4405,1024,6208,4161,33,1281,1299,6428,64,4160,5392,5392,2420,69,33,256,1329,4161,513]

theorem envBound23883 : H12AffineFastState.Bounded env23883 := by
  intro p hp
  have h : env23883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23882_23883 : H12AffineEnvironment.transform 12 6428 env23882 = env23883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6428 env23882 == env23883) = true)

theorem identity23883 : scanCanonicalize (H12AffineFastState.compose env23883 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound23883 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env23884 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3109,1337,2341,1124,35,3109,3344,1024,1125,3172,33,1281,1299,1337,64,3173,2357,2357,2420,69,33,256,1329,3172,513]

theorem envBound23884 : H12AffineFastState.Bounded env23884 := by
  intro p hp
  have h : env23884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23883_23884 : H12AffineEnvironment.transform 11 3109 env23883 = env23884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env23883 == env23884) = true)

theorem identity23884 : scanCanonicalize (H12AffineFastState.compose env23884 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound23884 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env23885 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2064,268,2341,81,35,2064,2341,53,80,2129,33,308,294,268,64,2128,2357,2357,2420,69,33,256,260,2129,513]

theorem envBound23885 : H12AffineFastState.Bounded env23885 := by
  intro p hp
  have h : env23885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23884_23885 : H12AffineEnvironment.transform 9 53 env23884 = env23885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env23884 == env23885) = true)

theorem identity23885 : scanCanonicalize (H12AffineFastState.compose env23885 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 885) := by decide +kernel

theorem selectedBound23885 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23886 : List Nat := [2,4,8,16,32,64,8,256,512,53,885,869,268,592,81,35,869,592,53,80,804,33,308,294,268,64,805,576,576,513,69,33,256,260,804,513]

theorem envBound23886 : H12AffineFastState.Bounded env23886 := by
  intro p hp
  have h : env23886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23885_23886 : H12AffineEnvironment.transform 10 885 env23885 = env23886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 885 env23885 == env23886) = true)

theorem identity23886 : scanCanonicalize (H12AffineFastState.compose env23886 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23886 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23887 : List Nat := [2,4,8,16,32,17,8,256,512,53,804,820,268,513,0,35,820,513,53,1,804,33,308,294,268,17,805,529,529,513,20,33,256,260,804,513]

theorem envBound23887 : H12AffineFastState.Bounded env23887 := by
  intro p hp
  have h : env23887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23886_23887 : H12AffineEnvironment.transform 5 17 env23886 = env23887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23886 == env23887) = true)

theorem identity23887 : scanCanonicalize (H12AffineFastState.compose env23887 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound23887 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env23888 : List Nat := [2,4,8,16,32,17,8,256,16,53,308,292,268,17,0,35,292,17,53,1,308,33,308,294,268,17,309,1,1,17,20,33,256,260,308,17]

theorem envBound23888 : H12AffineFastState.Bounded env23888 := by
  intro p hp
  have h : env23888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23887_23888 : H12AffineEnvironment.transform 8 16 env23887 = env23888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env23887 == env23888) = true)

theorem identity23888 : scanCanonicalize (H12AffineFastState.compose env23888 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23888 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env23889 : List Nat := [2,4,8,0,32,1,8,256,0,37,292,292,268,1,0,35,292,1,37,1,292,33,292,294,268,1,293,1,1,1,4,33,256,260,292,1]

theorem envBound23889 : H12AffineFastState.Bounded env23889 := by
  intro p hp
  have h : env23889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23888_23889 : H12AffineEnvironment.transform 3 0 env23888 = env23889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23888 == env23889) = true)

theorem identity23889 : scanCanonicalize (H12AffineFastState.compose env23889 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound23889 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env23890 : List Nat := [2,4,8,0,32,1,8,36,0,37,0,0,40,1,0,35,0,1,37,1,0,33,0,2,40,1,1,1,1,1,4,33,36,32,0,1]

theorem envBound23890 : H12AffineFastState.Bounded env23890 := by
  intro p hp
  have h : env23890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23889_23890 : H12AffineEnvironment.transform 7 36 env23889 = env23890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env23889 == env23890) = true)

theorem identity23890 : scanCanonicalize (H12AffineFastState.compose env23890 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23890 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23891 : List Nat := [2,4,8,0,1,1,8,5,0,4,0,0,9,1,0,2,0,1,4,1,0,0,0,2,9,1,1,1,1,1,4,0,5,1,0,1]

theorem envBound23891 : H12AffineFastState.Bounded env23891 := by
  intro p hp
  have h : env23891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23890_23891 : H12AffineEnvironment.transform 4 1 env23890 = env23891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23890 == env23891) = true)

def env23892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,318549,119879,95497,8193,64,245018,57676,102742,463942,75102,318548,256,95531,103431,513]

theorem envBound23892 : H12AffineFastState.Bounded env23892 := by
  intro p hp
  have h : env23892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23865_23892 : H12AffineEnvironment.transform 6 9 env23865 = env23892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23865 == env23892) = true)

def env23893 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,62589,119879,95497,8193,64,245018,57676,102742,212078,75102,62588,256,95531,103431,513]

theorem envBound23893 : H12AffineFastState.Bounded env23893 := by
  intro p hp
  have h : env23893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23892_23893 : H12AffineEnvironment.transform 17 10280 env23892 = env23893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23892 == env23893) = true)

theorem identity23893 : scanCanonicalize (H12AffineFastState.compose env23893 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound23893 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env23894 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,4161,62589,119879,95497,8193,64,89175,57676,102742,122147,75102,62588,256,95531,103431,513]

theorem envBound23894 : H12AffineFastState.Bounded env23894 := by
  intro p hp
  have h : env23894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23893_23894 : H12AffineEnvironment.transform 16 57677 env23893 = env23894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env23893 == env23894) = true)

theorem identity23894 : scanCanonicalize (H12AffineFastState.compose env23894 (packedSelected [1,3,5,8,14,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 62810) := by decide +kernel

theorem selectedBound23894 : packedSelected [1,3,5,8,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env23895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62810,57677,10280,1024,32769,4161,62589,8477,32851,8193,64,43277,57676,25612,10361,53252,62588,256,32881,24925,513]

theorem envBound23895 : H12AffineFastState.Bounded env23895 := by
  intro p hp
  have h : env23895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23894_23895 : H12AffineEnvironment.transform 15 62810 env23894 = env23895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62810 env23894 == env23895) = true)

theorem identity23895 : scanCanonicalize (H12AffineFastState.compose env23895 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound23895 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env23896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,342,5441,10280,1024,29709,4161,113,8477,29791,8193,64,23809,5440,25612,10361,9224,112,256,29821,24925,513]

theorem envBound23896 : H12AffineFastState.Bounded env23896 := by
  intro p hp
  have h : env23896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23895_23896 : H12AffineEnvironment.transform 14 29708 env23895 = env23896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env23895 == env23896) = true)

theorem identity23896 : scanCanonicalize (H12AffineFastState.compose env23896 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23896 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21760,342,5441,2340,1024,21761,4161,113,17,21843,269,64,23809,5440,17664,2421,1284,112,256,21873,16465,513]

theorem envBound23897 : H12AffineFastState.Bounded env23897 := by
  intro p hp
  have h : env23897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23896_23897 : H12AffineEnvironment.transform 12 268 env23896 = env23897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23896 == env23897) = true)

def env23898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,62588,119879,95497,8193,64,245018,57676,102742,212079,75102,62589,256,95531,103431,513]

theorem envBound23898 : H12AffineFastState.Bounded env23898 := by
  intro p hp
  have h : env23898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23892_23898 : H12AffineEnvironment.transform 17 10281 env23892 = env23898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23892 == env23898) = true)

theorem identity23898 : scanCanonicalize (H12AffineFastState.compose env23898 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound23898 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23899 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1024,32769,4161,62588,16,41310,8193,64,158029,57676,17665,190520,61705,62589,256,41340,16464,513]

theorem envBound23899 : H12AffineFastState.Bounded env23899 := by
  intro p hp
  have h : env23899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23898_23899 : H12AffineEnvironment.transform 15 54359 env23898 = env23899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env23898 == env23899) = true)

theorem identity23899 : scanCanonicalize (H12AffineFastState.compose env23899 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound23899 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env23900 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,46157,10281,1024,32769,4161,62588,16,41310,8193,64,56576,57676,17665,23669,61705,62589,256,41340,16464,513]

theorem envBound23900 : H12AffineFastState.Bounded env23900 := by
  intro p hp
  have h : env23900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23899_23900 : H12AffineEnvironment.transform 16 46157 env23899 = env23900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env23899 == env23900) = true)

theorem identity23900 : scanCanonicalize (H12AffineFastState.compose env23900 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound23900 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23901 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9293,28698,4096,10281,1024,9292,4161,20529,16,1299,8193,64,31053,17665,17665,23669,21828,20528,256,1329,16464,513]

theorem envBound23901 : H12AffineFastState.Bounded env23901 := by
  intro p hp
  have h : env23901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23900_23901 : H12AffineEnvironment.transform 14 9293 env23900 = env23901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env23900 == env23901) = true)

theorem identity23901 : scanCanonicalize (H12AffineFastState.compose env23901 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 5213) := by decide +kernel

theorem selectedBound23901 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5213,16384,4112,17479,4096,7284,1024,4113,4161,20529,16,1299,5212,64,19728,17665,17665,23669,21828,20528,256,1329,16464,513]

theorem envBound23902 : H12AffineFastState.Bounded env23902 := by
  intro p hp
  have h : env23902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23901_23902 : H12AffineEnvironment.transform 12 5213 env23901 = env23902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5213 env23901 == env23902) = true)

theorem identity23902 : scanCanonicalize (H12AffineFastState.compose env23902 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound23902 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env23903 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,4152,16384,4112,16418,4096,6161,101,4113,4161,20529,16,374,4153,64,18805,16740,16740,22544,20769,20528,256,340,16464,513]

theorem envBound23903 : H12AffineFastState.Bounded env23903 := by
  intro p hp
  have h : env23903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23902_23903 : H12AffineEnvironment.transform 9 101 env23902 = env23903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env23902 == env23903) = true)

theorem identity23903 : scanCanonicalize (H12AffineFastState.compose env23903 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 4144) := by decide +kernel

theorem selectedBound23903 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env23904 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,4152,4144,4112,4114,4096,6161,101,4113,4161,1,16,374,4153,64,6469,4436,4436,2080,273,0,256,340,4192,513]

theorem envBound23904 : H12AffineFastState.Bounded env23904 := by
  intro p hp
  have h : env23904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23903_23904 : H12AffineEnvironment.transform 13 4144 env23903 = env23904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4144 env23903 == env23904) = true)

theorem identity23904 : scanCanonicalize (H12AffineFastState.compose env23904 (packedSelected [0,3,6,7,8,11,24] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound23904 : packedSelected [0,3,6,7,8,11,24] rootPS < 2^1333 := by decide +kernel

def env23905 : List Nat := [2,4,8,16,32,64,9,256,0,101,2048,4096,4152,4144,4112,4114,4096,6161,101,4113,4161,1,16,374,4153,64,6469,4436,4436,2080,273,0,256,340,4192,1]

theorem envBound23905 : H12AffineFastState.Bounded env23905 := by
  intro p hp
  have h : env23905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23904_23905 : H12AffineEnvironment.transform 8 0 env23904 = env23905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23904 == env23905) = true)

theorem identity23905 : scanCanonicalize (H12AffineFastState.compose env23905 (packedSelected [0,1,3,7,8,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound23905 : packedSelected [0,1,3,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env23906 : List Nat := [2,4,8,16,32,64,9,256,0,101,2048,309,269,261,293,295,309,2340,101,292,372,1,16,374,268,64,2160,97,97,2080,273,0,256,340,341,1]

theorem envBound23906 : H12AffineFastState.Bounded env23906 := by
  intro p hp
  have h : env23906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23905_23906 : H12AffineEnvironment.transform 11 309 env23905 = env23906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env23905 == env23906) = true)

theorem identity23906 : scanCanonicalize (H12AffineFastState.compose env23906 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23906 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env23907 : List Nat := [2,4,8,16,32,64,9,117,0,101,2048,64,120,112,80,82,64,2129,101,81,1,1,16,3,121,64,2160,97,97,2080,100,0,117,33,32,1]

theorem envBound23907 : H12AffineFastState.Bounded env23907 := by
  intro p hp
  have h : env23907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23906_23907 : H12AffineEnvironment.transform 7 117 env23906 = env23907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23906 == env23907) = true)

theorem identity23907 : scanCanonicalize (H12AffineFastState.compose env23907 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound23907 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env23908 : List Nat := [2,4,8,16,16,64,9,69,0,85,2048,64,72,64,80,82,64,2129,85,81,1,1,16,3,73,64,2112,81,81,2064,84,0,69,17,16,1]

theorem envBound23908 : H12AffineFastState.Bounded env23908 := by
  intro p hp
  have h : env23908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23907_23908 : H12AffineEnvironment.transform 4 16 env23907 = env23908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env23907 == env23908) = true)

theorem identity23908 : scanCanonicalize (H12AffineFastState.compose env23908 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23908 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env23909 : List Nat := [2,4,8,1,1,64,9,69,0,68,2048,64,72,64,65,67,64,2112,68,64,1,1,1,3,73,64,2112,64,64,2049,69,0,69,0,1,1]

theorem envBound23909 : H12AffineFastState.Bounded env23909 := by
  intro p hp
  have h : env23909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23908_23909 : H12AffineEnvironment.transform 3 1 env23908 = env23909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23908 == env23909) = true)

theorem identity23909 : scanCanonicalize (H12AffineFastState.compose env23909 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound23909 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23910 : List Nat := [2,4,8,1,1,1,9,4,0,5,2048,1,9,1,0,2,1,2049,5,1,1,1,1,3,8,1,2049,1,1,2049,4,0,4,0,1,1]

theorem envBound23910 : H12AffineFastState.Bounded env23910 := by
  intro p hp
  have h : env23910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23909_23910 : H12AffineEnvironment.transform 5 1 env23909 = env23910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env23909 == env23910) = true)

def env23911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2411541,2213007,16777216,8328,64,16959643,18973837,102879,2557070,18890911,17148373,256,16777250,16834951,18966345]

theorem envBound23911 : H12AffineFastState.Bounded env23911 := by
  intro p hp
  have h : env23911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23812_23911 : H12AffineEnvironment.transform 21 2411541 env23812 = env23911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2411541 env23812 == env23911) = true)

theorem identity23911 : scanCanonicalize (H12AffineFastState.compose env23911 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound23911 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env23912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,329866,16,16777216,8328,64,16959643,16793618,102879,442385,16876544,17148373,256,16777250,16834951,16819158]

theorem envBound23912 : H12AffineFastState.Bounded env23912 := by
  intro p hp
  have h : env23912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23911_23912 : H12AffineEnvironment.transform 20 115871 env23911 = env23912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env23911 == env23912) = true)

def env23913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,329866,16,95496,8328,64,245139,79130,102879,442385,61704,318685,256,95530,103567,120542]

theorem envBound23913 : H12AffineFastState.Bounded env23913 := by
  intro p hp
  have h : env23913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23912_23913 : H12AffineEnvironment.transform 23 95496 env23912 = env23913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env23912 == env23913) = true)

theorem identity23913 : scanCanonicalize (H12AffineFastState.compose env23913 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound23913 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4160,318549,16,41431,8328,64,158028,57797,17664,442385,61704,318685,256,41461,16464,513]

theorem envBound23914 : H12AffineFastState.Bounded env23914 := by
  intro p hp
  have h : env23914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23913_23914 : H12AffineEnvironment.transform 15 54495 env23913 = env23914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env23913 == env23914) = true)

def env23915 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,318549,16,41311,8192,64,158028,57677,17664,442385,61704,318549,256,41341,16464,513]

theorem envBound23915 : H12AffineFastState.Bounded env23915 := by
  intro p hp
  have h : env23915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23914_23915 : H12AffineEnvironment.transform 6 8 env23914 = env23915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23914 == env23915) = true)

theorem identity23915 : scanCanonicalize (H12AffineFastState.compose env23915 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound23915 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23916 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29962,131072,262144,1024,8540,4160,294152,16,2,8192,64,158028,16400,17664,418124,20565,294152,256,32,16464,513]

theorem envBound23916 : H12AffineFastState.Bounded env23916 := by
  intro p hp
  have h : env23916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23915_23916 : H12AffineEnvironment.transform 14 8541 env23915 = env23916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env23915 == env23916) = true)

theorem identity23916 : scanCanonicalize (H12AffineFastState.compose env23916 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound23916 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23917 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28698,131072,262144,272,8540,4160,292888,16,2,8192,64,158028,16400,16400,418124,20565,292888,256,32,16464,513]

theorem envBound23917 : H12AffineFastState.Bounded env23917 := by
  intro p hp
  have h : env23917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23916_23917 : H12AffineEnvironment.transform 9 272 env23916 = env23917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env23916 == env23917) = true)

theorem identity23917 : scanCanonicalize (H12AffineFastState.compose env23917 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound23917 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env23918 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28698,4096,262144,272,8540,4160,292888,16,2,8192,64,31052,16400,16400,291148,20565,292888,256,32,16464,513]

theorem envBound23918 : H12AffineFastState.Bounded env23918 := by
  intro p hp
  have h : env23918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23917_23918 : H12AffineEnvironment.transform 16 4096 env23917 = env23918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env23917 == env23918) = true)

theorem identity23918 : scanCanonicalize (H12AffineFastState.compose env23918 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound23918 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23919 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28698,4096,2420,272,8540,4160,29036,16,2,8192,64,31052,16400,16400,30776,20565,29036,256,32,16464,513]

theorem envBound23919 : H12AffineFastState.Bounded env23919 := by
  intro p hp
  have h : env23919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23918_23919 : H12AffineEnvironment.transform 17 2420 env23918 = env23919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env23918 == env23919) = true)

theorem identity23919 : scanCanonicalize (H12AffineFastState.compose env23919 (packedSelected [1,2,5,6,8,12,15,24] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23919 : packedSelected [1,2,5,6,8,12,15,24] rootPS < 2^1333 := by decide +kernel

def env23920 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,4096,8192,16384,8312,28698,4096,2129,53,8313,4160,28745,16,2,8192,64,30825,16400,16400,30776,20565,28745,37,32,16464,513]

theorem envBound23920 : H12AffineFastState.Bounded env23920 := by
  intro p hp
  have h : env23920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23919_23920 : H12AffineEnvironment.transform 7 37 env23919 = env23920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23919 == env23920) = true)

theorem identity23920 : scanCanonicalize (H12AffineFastState.compose env23920 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound23920 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env23921 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,4096,8192,4161,8312,8283,4096,2129,53,8313,4160,8200,16,2,8192,64,10280,4177,4177,10361,20,8200,37,32,4113,513]

theorem envBound23921 : H12AffineFastState.Bounded env23921 := by
  intro p hp
  have h : env23921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23920_23921 : H12AffineEnvironment.transform 13 4161 env23920 = env23921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env23920 == env23921) = true)

theorem identity23921 : scanCanonicalize (H12AffineFastState.compose env23921 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound23921 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23922 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,4096,40,4161,80,115,4096,2129,53,81,4160,32,16,2,40,64,2048,4177,4177,2129,20,32,37,32,4113,513]

theorem envBound23922 : H12AffineFastState.Bounded env23922 := by
  intro p hp
  have h : env23922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23921_23922 : H12AffineEnvironment.transform 12 40 env23921 = env23922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env23921 == env23922) = true)

theorem identity23922 : scanCanonicalize (H12AffineFastState.compose env23922 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound23922 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env23923 : List Nat := [2,4,8,16,32,64,8,37,512,53,97,4096,40,4161,80,115,4096,48,53,81,4160,32,16,2,40,64,97,4177,4177,48,20,32,37,32,4113,513]

theorem envBound23923 : H12AffineFastState.Bounded env23923 := by
  intro p hp
  have h : env23923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23922_23923 : H12AffineEnvironment.transform 10 97 env23922 = env23923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env23922 == env23923) = true)

theorem identity23923 : scanCanonicalize (H12AffineFastState.compose env23923 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound23923 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env23924 : List Nat := [2,4,8,16,17,64,8,20,512,4,80,4096,25,4161,80,66,4096,1,4,81,4160,17,16,2,25,64,80,4177,4177,1,20,17,20,17,4113,513]

theorem envBound23924 : H12AffineFastState.Bounded env23924 := by
  intro p hp
  have h : env23924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23923_23924 : H12AffineEnvironment.transform 4 17 env23923 = env23924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env23923 == env23924) = true)

theorem identity23924 : scanCanonicalize (H12AffineFastState.compose env23924 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23924 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env23925 : List Nat := [2,4,8,0,1,64,8,4,512,4,64,4096,9,4161,64,66,4096,1,4,65,4160,1,0,2,9,64,64,4161,4161,1,4,1,4,1,4097,513]

theorem envBound23925 : H12AffineFastState.Bounded env23925 := by
  intro p hp
  have h : env23925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23924_23925 : H12AffineEnvironment.transform 3 0 env23924 = env23925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23924 == env23925) = true)

theorem identity23925 : scanCanonicalize (H12AffineFastState.compose env23925 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound23925 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23926 : List Nat := [2,4,8,0,1,0,8,4,512,4,0,4096,9,4097,0,2,4096,1,4,1,4096,1,0,2,9,0,0,4097,4097,1,4,1,4,1,4097,513]

theorem envBound23926 : H12AffineFastState.Bounded env23926 := by
  intro p hp
  have h : env23926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23925_23926 : H12AffineEnvironment.transform 5 0 env23925 = env23926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env23925 == env23926) = true)

theorem identity23926 : scanCanonicalize (H12AffineFastState.compose env23926 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23926 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23927 : List Nat := [2,4,8,0,1,0,8,4,1,4,0,4096,9,4097,0,2,4096,1,4,1,4096,1,0,2,9,0,0,4097,4097,1,4,1,4,1,4097,0]

theorem envBound23927 : H12AffineFastState.Bounded env23927 := by
  intro p hp
  have h : env23927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23926_23927 : H12AffineEnvironment.transform 8 1 env23926 = env23927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23926 == env23927) = true)

theorem identity23927 : scanCanonicalize (H12AffineFastState.compose env23927 (packedSelected [7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound23927 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23928 : List Nat := [2,4,8,0,1,0,8,4,1,4,0,1,9,0,0,2,1,1,4,1,1,1,0,2,9,0,0,0,0,1,4,1,4,1,0,0]

theorem envBound23928 : H12AffineFastState.Bounded env23928 := by
  intro p hp
  have h : env23928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23927_23928 : H12AffineEnvironment.transform 11 1 env23927 = env23928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env23927 == env23928) = true)

def env23929 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,318549,16,41310,8193,64,158028,57676,17664,442385,61704,318548,256,41340,16464,513]

theorem envBound23929 : H12AffineFastState.Bounded env23929 := by
  intro p hp
  have h : env23929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23914_23929 : H12AffineEnvironment.transform 6 9 env23914 = env23929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23914 == env23929) = true)

def env23930 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4112,318469,16,41230,8193,16,157980,57628,17664,442385,61704,318468,256,41260,16384,513]

theorem envBound23930 : H12AffineFastState.Bounded env23930 := by
  intro p hp
  have h : env23930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23929_23930 : H12AffineEnvironment.transform 5 16 env23929 = env23930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23929 == env23930) = true)

theorem identity23930 : scanCanonicalize (H12AffineFastState.compose env23930 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound23930 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23931 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,179513,1024,32769,4112,155964,16,41230,8193,16,157980,57628,17664,32040,61704,155965,256,41260,16384,513]

theorem envBound23931 : H12AffineFastState.Bounded env23931 := by
  intro p hp
  have h : env23931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23930_23931 : H12AffineEnvironment.transform 17 179513 env23930 = env23931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env23930 == env23931) = true)

theorem identity23931 : scanCanonicalize (H12AffineFastState.compose env23931 (packedSelected [3,10,18,19,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound23931 : packedSelected [3,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env23932 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,24860,56357,1024,32769,4112,32,16,41230,8193,16,2048,57628,17664,32040,61704,33,256,41260,16384,513]

theorem envBound23932 : H12AffineFastState.Bounded env23932 := by
  intro p hp
  have h : env23932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23931_23932 : H12AffineEnvironment.transform 16 24860 env23931 = env23932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env23931 == env23932) = true)

theorem identity23932 : scanCanonicalize (H12AffineFastState.compose env23932 (packedSelected [0,1,7,8,12,15,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound23932 : packedSelected [0,1,7,8,12,15,19,20] rootPS < 2^1333 := by decide +kernel

def env23933 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21760,262,24860,2341,1024,21761,4112,32,16,29710,8193,16,2048,13340,17664,32040,9224,33,256,29740,16384,513]

theorem envBound23933 : H12AffineFastState.Bounded env23933 := by
  intro p hp
  have h : env23933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23932_23933 : H12AffineEnvironment.transform 14 21760 env23932 = env23933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env23932 == env23933) = true)

theorem identity23933 : scanCanonicalize (H12AffineFastState.compose env23933 (packedSelected [0,3,5,6,7,18] rootPS)) = affineNative (2^(13+1) ^^^ 6161) := by decide +kernel

theorem selectedBound23933 : packedSelected [0,3,5,6,7,18] rootPS < 2^1333 := by decide +kernel

def env23934 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,6161,3345,262,14605,2341,1024,3344,4112,32,16,11295,8193,16,2048,13340,7441,9529,9224,33,256,11325,6161,513]

theorem envBound23934 : H12AffineFastState.Bounded env23934 := by
  intro p hp
  have h : env23934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23933_23934 : H12AffineEnvironment.transform 13 6161 env23933 = env23934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6161 env23933 == env23934) = true)

theorem identity23934 : scanCanonicalize (H12AffineFastState.compose env23934 (packedSelected [2,3,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23934 : packedSelected [2,3,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env23935 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,6161,3345,262,6145,2341,1024,3344,4112,32,16,3347,269,16,2048,5392,7441,1077,1284,33,256,3377,6161,513]

theorem envBound23935 : H12AffineFastState.Bounded env23935 := by
  intro p hp
  have h : env23935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23934_23935 : H12AffineEnvironment.transform 12 268 env23934 = env23935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23934 == env23935) = true)

theorem identity23935 : scanCanonicalize (H12AffineFastState.compose env23935 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound23935 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env23936 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,6161,3125,34,6145,2049,1024,3124,4112,32,16,3127,41,16,2048,5172,7221,1077,1056,33,36,3093,6161,513]

theorem envBound23936 : H12AffineFastState.Bounded env23936 := by
  intro p hp
  have h : env23936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23935_23936 : H12AffineEnvironment.transform 7 36 env23935 = env23936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env23935 == env23936) = true)

theorem identity23936 : scanCanonicalize (H12AffineFastState.compose env23936 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound23936 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23937 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,4096,40,6161,2049,34,6145,2049,52,2048,4112,32,16,2051,41,16,2048,4096,6145,1,20,33,36,2081,6161,513]

theorem envBound23937 : H12AffineFastState.Bounded env23937 := by
  intro p hp
  have h : env23937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23936_23937 : H12AffineEnvironment.transform 9 52 env23936 = env23937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env23936 == env23937) = true)

theorem identity23937 : scanCanonicalize (H12AffineFastState.compose env23937 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23937 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23938 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,4096,40,4112,0,34,4096,0,52,1,4112,32,16,2,41,16,1,4096,4096,1,20,33,36,32,4112,513]

theorem envBound23938 : H12AffineFastState.Bounded env23938 := by
  intro p hp
  have h : env23938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23937_23938 : H12AffineEnvironment.transform 10 1 env23937 = env23938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23937 == env23938) = true)

theorem identity23938 : scanCanonicalize (H12AffineFastState.compose env23938 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound23938 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23939 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,49,40,33,0,34,49,0,52,1,33,32,16,2,41,16,1,49,49,1,20,33,36,32,33,513]

theorem envBound23939 : H12AffineFastState.Bounded env23939 := by
  intro p hp
  have h : env23939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23938_23939 : H12AffineEnvironment.transform 11 49 env23938 = env23939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env23938 == env23939) = true)

theorem identity23939 : scanCanonicalize (H12AffineFastState.compose env23939 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23939 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23940 : List Nat := [2,4,8,0,32,0,9,36,512,36,1,33,40,33,0,34,33,0,36,1,33,32,0,2,41,0,1,33,33,1,4,33,36,32,33,513]

theorem envBound23940 : H12AffineFastState.Bounded env23940 := by
  intro p hp
  have h : env23940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23939_23940 : H12AffineEnvironment.transform 3 0 env23939 = env23940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23939 == env23940) = true)

theorem identity23940 : scanCanonicalize (H12AffineFastState.compose env23940 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23940 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23941 : List Nat := [2,4,8,0,1,0,9,5,512,5,1,0,9,0,0,3,0,0,5,1,0,1,0,2,8,0,1,0,0,1,4,0,5,1,0,513]

theorem envBound23941 : H12AffineFastState.Bounded env23941 := by
  intro p hp
  have h : env23941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23940_23941 : H12AffineEnvironment.transform 4 1 env23940 = env23941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23940 == env23941) = true)

def env23942 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4113,318468,16,41231,8193,17,157981,57629,17664,442385,61704,318469,256,41261,16385,513]

theorem envBound23942 : H12AffineFastState.Bounded env23942 := by
  intro p hp
  have h : env23942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23929_23942 : H12AffineEnvironment.transform 5 17 env23929 = env23942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23929 == env23942) = true)

theorem identity23942 : scanCanonicalize (H12AffineFastState.compose env23942 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 149813) := by decide +kernel

theorem selectedBound23942 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23943 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,149813,1024,32769,4113,169265,16,41231,8193,17,157981,57629,17664,35108,61704,169264,256,41261,16385,513]

theorem envBound23943 : H12AffineFastState.Bounded env23943 := by
  intro p hp
  have h : env23943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23942_23943 : H12AffineEnvironment.transform 17 149813 env23942 = env23943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149813 env23942 == env23943) = true)

theorem identity23943 : scanCanonicalize (H12AffineFastState.compose env23943 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound23943 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env23944 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,29962,131072,149813,1024,8460,4113,144444,16,2,8193,17,157981,16400,17664,10281,20485,144445,256,32,16385,513]

theorem envBound23944 : H12AffineFastState.Bounded env23944 := by
  intro p hp
  have h : env23944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23943_23944 : H12AffineEnvironment.transform 14 8461 env23943 = env23944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env23943 == env23944) = true)

theorem identity23944 : scanCanonicalize (H12AffineFastState.compose env23944 (packedSelected [1,3,8,10,12,15,24] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound23944 : packedSelected [1,3,8,10,12,15,24] rootPS < 2^1333 := by decide +kernel

def env23945 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,29962,5392,23589,1024,8460,4113,8492,16,2,8193,17,31757,16400,17664,10281,20485,8493,256,32,16385,513]

theorem envBound23945 : H12AffineFastState.Bounded env23945 := by
  intro p hp
  have h : env23945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23944_23945 : H12AffineEnvironment.transform 16 5392 env23944 = env23945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env23944 == env23945) = true)

theorem identity23945 : scanCanonicalize (H12AffineFastState.compose env23945 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23945 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23946 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,21510,5392,23589,1024,0,4113,32,16,2,269,17,23809,16400,17664,2341,20485,33,256,32,16385,513]

theorem envBound23946 : H12AffineFastState.Bounded env23946 := by
  intro p hp
  have h : env23946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23945_23946 : H12AffineEnvironment.transform 12 268 env23945 = env23946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23945 == env23946) = true)

theorem identity23946 : scanCanonicalize (H12AffineFastState.compose env23946 (packedSelected [1,2,3,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23946 : packedSelected [1,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env23947 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,16384,1,21510,5173,23589,1024,0,4113,32,16,2,40,17,23588,16400,17445,2048,20485,33,37,32,16385,513]

theorem envBound23947 : H12AffineFastState.Bounded env23947 := by
  intro p hp
  have h : env23947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23946_23947 : H12AffineEnvironment.transform 7 37 env23946 = env23947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23946 == env23947) = true)

theorem identity23947 : scanCanonicalize (H12AffineFastState.compose env23947 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound23947 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env23948 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5156,1,34,5173,2049,1024,0,4113,32,16,2,40,17,2048,5172,4097,2048,1057,33,37,32,5157,513]

theorem envBound23948 : H12AffineFastState.Bounded env23948 := by
  intro p hp
  have h : env23948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23947_23948 : H12AffineEnvironment.transform 13 5156 env23947 = env23948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env23947 == env23948) = true)

theorem identity23948 : scanCanonicalize (H12AffineFastState.compose env23948 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23948 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23949 : List Nat := [2,4,8,0,32,1,9,37,512,1024,2048,4096,41,5156,1,34,5157,2049,1024,0,4097,32,0,2,40,1,2048,5156,4097,2048,1057,33,37,32,5157,513]

theorem envBound23949 : H12AffineFastState.Bounded env23949 := by
  intro p hp
  have h : env23949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23948_23949 : H12AffineEnvironment.transform 3 0 env23948 = env23949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23948 == env23949) = true)

theorem identity23949 : scanCanonicalize (H12AffineFastState.compose env23949 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound23949 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23950 : List Nat := [2,4,8,0,32,1,9,37,512,1024,2048,512,41,1572,1,34,1573,2049,1024,0,513,32,0,2,40,1,2048,1572,513,2048,1057,33,37,32,1573,513]

theorem envBound23950 : H12AffineFastState.Bounded env23950 := by
  intro p hp
  have h : env23950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23949_23950 : H12AffineEnvironment.transform 11 512 env23949 = env23950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env23949 == env23950) = true)

theorem identity23950 : scanCanonicalize (H12AffineFastState.compose env23950 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound23950 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23951 : List Nat := [2,4,8,0,32,1,9,37,512,1024,512,512,41,1572,1,34,1573,513,1024,0,513,32,0,2,40,1,512,1572,513,512,1057,33,37,32,1573,513]

theorem envBound23951 : H12AffineFastState.Bounded env23951 := by
  intro p hp
  have h : env23951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23950_23951 : H12AffineEnvironment.transform 10 512 env23950 = env23951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env23950 == env23951) = true)

theorem identity23951 : scanCanonicalize (H12AffineFastState.compose env23951 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound23951 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23952 : List Nat := [2,4,8,0,32,1,9,37,512,36,512,512,41,512,1,34,513,513,36,0,513,32,0,2,40,1,512,512,513,512,5,33,37,32,513,513]

theorem envBound23952 : H12AffineFastState.Bounded env23952 := by
  intro p hp
  have h : env23952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23951_23952 : H12AffineEnvironment.transform 9 36 env23951 = env23952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env23951 == env23952) = true)

theorem identity23952 : scanCanonicalize (H12AffineFastState.compose env23952 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound23952 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23953 : List Nat := [2,4,8,0,11,1,9,14,512,15,512,512,2,512,1,9,513,513,15,0,513,11,0,2,3,1,512,512,513,512,5,10,14,11,513,513]

theorem envBound23953 : H12AffineFastState.Bounded env23953 := by
  intro p hp
  have h : env23953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23952_23953 : H12AffineEnvironment.transform 4 11 env23952 = env23953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env23952 == env23953) = true)

def env23954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,329866,16,95497,8328,64,245138,79131,102879,442385,61705,318684,256,95531,103566,120543]

theorem envBound23954 : H12AffineFastState.Bounded env23954 := by
  intro p hp
  have h : env23954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23912_23954 : H12AffineEnvironment.transform 23 95497 env23912 = env23954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env23912 == env23954) = true)

def env23955 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,329730,16,95497,8192,64,245018,79131,102743,442385,61705,318548,256,95531,103430,120407]

theorem envBound23955 : H12AffineFastState.Bounded env23955 := by
  intro p hp
  have h : env23955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23954_23955 : H12AffineEnvironment.transform 6 8 env23954 = env23955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23954 == env23955) = true)

theorem identity23955 : scanCanonicalize (H12AffineFastState.compose env23955 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound23955 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23956 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,262144,1024,32769,45340,294153,16,2,8192,64,182289,16400,58460,442385,61705,318548,256,32,57613,41820]

theorem envBound23956 : H12AffineFastState.Bounded env23956 := by
  intro p hp
  have h : env23956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23955_23956 : H12AffineEnvironment.transform 15 29963 env23955 = env23956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env23955 == env23956) = true)

def env23957 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,16400,262144,1024,32769,45340,294153,16,2,8192,64,34817,16400,58460,294913,61705,318548,256,32,57613,41820]

theorem envBound23957 : H12AffineFastState.Bounded env23957 := by
  intro p hp
  have h : env23957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23956_23957 : H12AffineEnvironment.transform 16 16400 env23956 = env23957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env23956 == env23957) = true)

theorem identity23957 : scanCanonicalize (H12AffineFastState.compose env23957 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound23957 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env23958 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,16400,64808,1024,32769,45340,32801,16,2,8192,64,34817,16400,58460,32041,61705,8572,256,32,57613,41820]

theorem envBound23958 : H12AffineFastState.Bounded env23958 := by
  intro p hp
  have h : env23958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23957_23958 : H12AffineEnvironment.transform 17 64808 env23957 = env23958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env23957 == env23958) = true)

theorem identity23958 : scanCanonicalize (H12AffineFastState.compose env23958 (packedSelected [4,5,9,12,14,15,16,18,19,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound23958 : packedSelected [4,5,9,12,14,15,16,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env23959 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,29963,16400,23809,1024,8232,4405,8200,16,2,8192,64,10280,16400,17525,32041,20768,8572,256,32,16676,885]

theorem envBound23959 : H12AffineFastState.Bounded env23959 := by
  intro p hp
  have h : env23959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23958_23959 : H12AffineEnvironment.transform 14 8233 env23958 = env23959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env23958 == env23959) = true)

theorem identity23959 : scanCanonicalize (H12AffineFastState.compose env23959 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23959 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env23960 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8233,8202,5393,2048,1024,8232,4405,8200,16,2,8192,64,10280,5393,4468,10280,1057,8572,256,32,5157,885]

theorem envBound23960 : H12AffineFastState.Bounded env23960 := by
  intro p hp
  have h : env23960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23959_23960 : H12AffineEnvironment.transform 13 5377 env23959 = env23960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23959 == env23960) = true)

theorem identity23960 : scanCanonicalize (H12AffineFastState.compose env23960 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23960 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env23961 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5156,8233,8202,5172,2048,1024,8232,4112,8200,16,2,8192,64,10280,5172,4177,10280,1057,8281,37,32,5157,592]

theorem envBound23961 : H12AffineFastState.Bounded env23961 := by
  intro p hp
  have h : env23961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23960_23961 : H12AffineEnvironment.transform 7 37 env23960 = env23961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23960 == env23961) = true)

theorem identity23961 : scanCanonicalize (H12AffineFastState.compose env23961 (packedSelected [0,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound23961 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env23962 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,1100,5156,1125,1094,5172,2048,1024,1124,4112,1092,16,2,1100,64,3172,5172,4177,3172,1057,1045,37,32,5157,592]

theorem envBound23962 : H12AffineFastState.Bounded env23962 := by
  intro p hp
  have h : env23962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23961_23962 : H12AffineEnvironment.transform 12 1100 env23961 = env23962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env23961 == env23962) = true)

theorem identity23962 : scanCanonicalize (H12AffineFastState.compose env23962 (packedSelected [2,4,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23962 : packedSelected [2,4,9,14] rootPS < 2^1333 := by decide +kernel

def env23963 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,1052,5156,1077,1046,5172,2048,1024,1076,4112,1044,16,2,1052,16,3124,5172,4097,3124,1057,1045,37,32,5157,512]

theorem envBound23963 : H12AffineFastState.Bounded env23963 := by
  intro p hp
  have h : env23963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23962_23963 : H12AffineEnvironment.transform 5 16 env23962 = env23963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23962 == env23963) = true)

theorem identity23963 : scanCanonicalize (H12AffineFastState.compose env23963 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound23963 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23964 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,1044,1052,48,1077,1046,32,2048,1024,1076,1028,1044,16,2,1052,16,3124,32,1045,3124,1057,1045,37,32,49,512]

theorem envBound23964 : H12AffineFastState.Bounded env23964 := by
  intro p hp
  have h : env23964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23963_23964 : H12AffineEnvironment.transform 11 1044 env23963 = env23964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env23963 == env23964) = true)

theorem identity23964 : scanCanonicalize (H12AffineFastState.compose env23964 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1055) := by decide +kernel

theorem selectedBound23964 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23965 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1055,1044,1052,48,1077,1046,32,1055,1024,1076,1028,1044,16,2,1052,16,43,32,1045,43,1057,1045,37,32,49,512]

theorem envBound23965 : H12AffineFastState.Bounded env23965 := by
  intro p hp
  have h : env23965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23964_23965 : H12AffineEnvironment.transform 10 1055 env23964 = env23965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1055 env23964 == env23965) = true)

theorem identity23965 : scanCanonicalize (H12AffineFastState.compose env23965 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 535) := by decide +kernel

theorem selectedBound23965 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env23966 : List Nat := [2,4,8,16,32,16,8,37,512,535,520,515,523,48,546,513,32,520,535,547,531,515,16,2,523,16,43,32,514,43,566,514,37,32,49,512]

theorem envBound23966 : H12AffineFastState.Bounded env23966 := by
  intro p hp
  have h : env23966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23965_23966 : H12AffineEnvironment.transform 9 535 env23965 = env23966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 535 env23965 == env23966) = true)

theorem identity23966 : scanCanonicalize (H12AffineFastState.compose env23966 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound23966 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23967 : List Nat := [2,4,8,16,32,16,8,37,3,20,11,0,8,48,33,2,32,11,20,32,16,0,16,2,8,16,43,32,1,43,53,1,37,32,49,3]

theorem envBound23967 : H12AffineFastState.Bounded env23967 := by
  intro p hp
  have h : env23967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23966_23967 : H12AffineEnvironment.transform 8 3 env23966 = env23967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env23966 == env23967) = true)

theorem identity23967 : scanCanonicalize (H12AffineFastState.compose env23967 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23967 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env23968 : List Nat := [2,4,8,16,0,16,8,5,3,20,11,0,8,16,1,2,0,11,20,0,16,0,16,2,8,16,11,0,1,11,21,1,5,0,17,3]

theorem envBound23968 : H12AffineFastState.Bounded env23968 := by
  intro p hp
  have h : env23968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23967_23968 : H12AffineEnvironment.transform 4 0 env23967 = env23968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23967 == env23968) = true)

theorem identity23968 : scanCanonicalize (H12AffineFastState.compose env23968 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound23968 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23969 : List Nat := [2,4,8,14,0,14,8,5,3,10,11,0,8,14,1,2,0,11,10,0,14,0,14,2,8,14,11,0,1,11,11,1,5,0,15,3]

theorem envBound23969 : H12AffineFastState.Bounded env23969 := by
  intro p hp
  have h : env23969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23968_23969 : H12AffineEnvironment.transform 3 14 env23968 = env23969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env23968 == env23969) = true)

theorem identity23969 : scanCanonicalize (H12AffineFastState.compose env23969 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound23969 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23970 : List Nat := [2,4,6,0,0,0,6,5,3,4,5,0,6,0,1,2,0,5,4,0,0,0,0,2,6,0,5,0,1,5,5,1,5,0,1,3]

theorem envBound23970 : H12AffineFastState.Bounded env23970 := by
  intro p hp
  have h : env23970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23969_23970 : H12AffineEnvironment.transform 2 6 env23969 = env23970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env23969 == env23970) = true)

theorem identity23970 : scanCanonicalize (H12AffineFastState.compose env23970 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound23970 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23971 : List Nat := [2,1,3,0,0,0,3,0,3,1,0,0,3,0,1,2,0,0,1,0,0,0,0,2,3,0,0,0,1,0,0,1,0,0,1,3]

theorem envBound23971 : H12AffineFastState.Bounded env23971 := by
  intro p hp
  have h : env23971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23970_23971 : H12AffineEnvironment.transform 1 1 env23970 = env23971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env23970 == env23971) = true)

def env23972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,16401,262144,1024,32769,45340,294153,16,2,8192,64,34816,16400,58460,294912,61705,318548,256,32,57613,41820]

theorem envBound23972 : H12AffineFastState.Bounded env23972 := by
  intro p hp
  have h : env23972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23956_23972 : H12AffineEnvironment.transform 16 16401 env23956 = env23972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23956 == env23972) = true)

theorem identity23972 : scanCanonicalize (H12AffineFastState.compose env23972 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound23972 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env23973 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,16401,43049,1024,32769,45340,54560,16,2,8192,64,34816,16400,58460,10281,61705,29821,256,32,57613,41820]

theorem envBound23973 : H12AffineFastState.Bounded env23973 := by
  intro p hp
  have h : env23973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23972_23973 : H12AffineEnvironment.transform 17 43049 env23972 = env23973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env23972 == env23973) = true)

theorem identity23973 : scanCanonicalize (H12AffineFastState.compose env23973 (packedSelected [1,3,5,7,12,14,15,16,18,19,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound23973 : packedSelected [1,3,5,7,12,14,15,16,18,19,23,27,28] rootPS < 2^1333 := by decide +kernel

def env23974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,29963,16401,2049,1024,8233,4404,29960,16,2,8192,64,10280,16400,17524,10281,20769,29821,256,32,16677,884]

theorem envBound23974 : H12AffineFastState.Bounded env23974 := by
  intro p hp
  have h : env23974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23973_23974 : H12AffineEnvironment.transform 14 8232 env23973 = env23974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env23973 == env23974) = true)

theorem identity23974 : scanCanonicalize (H12AffineFastState.compose env23974 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound23974 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env23975 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8232,8574,5220,2049,1024,8233,4404,8573,16,2,8192,64,10280,5221,4097,10281,1364,8200,256,32,5456,884]

theorem envBound23975 : H12AffineFastState.Bounded env23975 := by
  intro p hp
  have h : env23975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23974_23975 : H12AffineEnvironment.transform 13 5237 env23974 = env23975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env23974 == env23975) = true)

theorem identity23975 : scanCanonicalize (H12AffineFastState.compose env23975 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound23975 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env23976 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5237,373,35,5220,2049,1024,372,4404,32,16,2,349,64,2421,5221,4097,2420,1364,341,256,32,5456,884]

theorem envBound23976 : H12AffineFastState.Bounded env23976 := by
  intro p hp
  have h : env23976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23975_23976 : H12AffineEnvironment.transform 12 349 env23975 = env23976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env23975 == env23976) = true)

theorem identity23976 : scanCanonicalize (H12AffineFastState.compose env23976 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23976 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env23977 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,1,35,5220,2049,1024,0,4160,32,16,2,41,64,2049,5221,4097,2048,1056,33,116,32,5156,512]

theorem envBound23977 : H12AffineFastState.Bounded env23977 := by
  intro p hp
  have h : env23977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23976_23977 : H12AffineEnvironment.transform 7 116 env23976 = env23977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23976 == env23977) = true)

theorem identity23977 : scanCanonicalize (H12AffineFastState.compose env23977 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23977 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23978 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,4096,9,5205,1,3,5188,2049,1024,0,4160,0,16,2,9,64,2049,5189,4097,2048,1024,1,84,0,5124,512]

theorem envBound23978 : H12AffineFastState.Bounded env23978 := by
  intro p hp
  have h : env23978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23977_23978 : H12AffineEnvironment.transform 4 0 env23977 = env23978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23977 == env23978) = true)

theorem identity23978 : scanCanonicalize (H12AffineFastState.compose env23978 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23978 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23979 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,9,5124,1,3,5141,2049,1024,0,4113,0,16,2,9,17,2049,5140,4097,2048,1024,1,5,0,5124,512]

theorem envBound23979 : H12AffineFastState.Bounded env23979 := by
  intro p hp
  have h : env23979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23978_23979 : H12AffineEnvironment.transform 5 17 env23978 = env23979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23978 == env23979) = true)

def env23980 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,9,1044,1,3,1029,2049,1024,0,1,0,16,2,9,17,2049,1028,17,2048,1024,1,5,0,1044,512]

theorem envBound23980 : H12AffineFastState.Bounded env23980 := by
  intro p hp
  have h : env23980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23979_23980 : H12AffineEnvironment.transform 11 16 env23979 = env23980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env23979 == env23980) = true)

theorem identity23980 : scanCanonicalize (H12AffineFastState.compose env23980 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound23980 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23981 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,16,9,1044,1,3,1029,1,1024,0,1,0,16,2,9,17,1,1028,17,0,1024,1,5,0,1044,512]

theorem envBound23981 : H12AffineFastState.Bounded env23981 := by
  intro p hp
  have h : env23981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23980_23981 : H12AffineEnvironment.transform 10 0 env23980 = env23981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env23980 == env23981) = true)

def env23982 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,9,0,1,3,17,1,20,0,1,0,16,2,9,17,1,16,17,0,20,1,5,0,0,512]

theorem envBound23982 : H12AffineFastState.Bounded env23982 := by
  intro p hp
  have h : env23982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23981_23982 : H12AffineEnvironment.transform 9 20 env23981 = env23982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env23981 == env23982) = true)

theorem identity23982 : scanCanonicalize (H12AffineFastState.compose env23982 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound23982 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23983 : List Nat := [2,4,8,16,0,17,8,5,30,20,0,16,9,0,1,3,17,1,20,0,1,0,16,2,9,17,1,16,17,0,20,1,5,0,0,30]

theorem envBound23983 : H12AffineFastState.Bounded env23983 := by
  intro p hp
  have h : env23983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23982_23983 : H12AffineEnvironment.transform 8 30 env23982 = env23983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env23982 == env23983) = true)

def leafEnv23983 : List Nat := [2,4,8,16,0,17,8,5,30,20,0,16,9,0,1,3,17,1,20,0,1,0,16,2,20,9,1,17,1,16,17,0,20,1,5,0,4,3,0,30,1,1,0]

def active23983 : List Nat := [0,1,2,3]

def tree23983 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23983 : H12WitnessSearch.Good tree23983 := H12GlobalWitnessIndex.good

theorem leafIdentity23983 : H12AffineFastState.composeSystem env23983 rootObs = leafEnv23983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23983 rootObs == leafEnv23983) = true)

theorem terminalChecked23983 : H12PackedTerminal.terminalCheckFast leafEnv23983 active23983 tree23983 = true := by decide +kernel

def env23984 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,9,1,1,3,16,1,21,0,1,0,16,2,9,17,1,17,17,0,21,1,5,0,1,512]

theorem envBound23984 : H12AffineFastState.Bounded env23984 := by
  intro p hp
  have h : env23984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23981_23984 : H12AffineEnvironment.transform 9 21 env23981 = env23984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env23981 == env23984) = true)

theorem identity23984 : scanCanonicalize (H12AffineFastState.compose env23984 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound23984 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23985 : List Nat := [2,4,8,4,0,5,8,5,512,1,0,4,9,1,1,3,4,1,1,0,1,0,4,2,9,5,1,5,5,0,1,1,5,0,1,512]

theorem envBound23985 : H12AffineFastState.Bounded env23985 := by
  intro p hp
  have h : env23985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23984_23985 : H12AffineEnvironment.transform 3 4 env23984 = env23985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env23984 == env23985) = true)

def leafEnv23985 : List Nat := [2,4,8,4,0,5,8,5,512,1,0,4,9,1,1,3,4,1,1,0,1,0,4,2,1,9,1,5,1,5,5,0,1,1,5,0,4,3,1,512,1,1,0]

def active23985 : List Nat := [0,1,2,8]

def tree23985 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23985 : H12WitnessSearch.Good tree23985 := H12GlobalWitnessIndex.good

theorem leafIdentity23985 : H12AffineFastState.composeSystem env23985 rootObs = leafEnv23985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23985 rootObs == leafEnv23985) = true)

theorem terminalChecked23985 : H12PackedTerminal.terminalCheckFast leafEnv23985 active23985 tree23985 = true := by decide +kernel

def env23986 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,9,1045,1,3,1028,2049,1024,0,0,0,16,2,9,17,2049,1029,16,2048,1024,1,5,0,1045,512]

theorem envBound23986 : H12AffineFastState.Bounded env23986 := by
  intro p hp
  have h : env23986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23979_23986 : H12AffineEnvironment.transform 11 17 env23979 = env23986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env23979 == env23986) = true)

theorem identity23986 : scanCanonicalize (H12AffineFastState.compose env23986 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound23986 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23987 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1044,17,9,1045,1,3,1028,1045,1024,0,0,0,16,2,9,17,1045,1029,16,1044,1024,1,5,0,1045,512]

theorem envBound23987 : H12AffineFastState.Bounded env23987 := by
  intro p hp
  have h : env23987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23986_23987 : H12AffineEnvironment.transform 10 1044 env23986 = env23987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env23986 == env23987) = true)

def env23988 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,9,1,1,3,16,1,20,0,0,0,16,2,9,17,1,17,16,0,20,1,5,0,1,512]

theorem envBound23988 : H12AffineFastState.Bounded env23988 := by
  intro p hp
  have h : env23988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23987_23988 : H12AffineEnvironment.transform 9 20 env23987 = env23988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env23987 == env23988) = true)

theorem identity23988 : scanCanonicalize (H12AffineFastState.compose env23988 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound23988 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23989 : List Nat := [2,4,8,16,0,17,8,5,30,20,0,17,9,1,1,3,16,1,20,0,0,0,16,2,9,17,1,17,16,0,20,1,5,0,1,30]

theorem envBound23989 : H12AffineFastState.Bounded env23989 := by
  intro p hp
  have h : env23989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23988_23989 : H12AffineEnvironment.transform 8 30 env23988 = env23989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env23988 == env23989) = true)

def leafEnv23989 : List Nat := [2,4,8,16,0,17,8,5,30,20,0,17,9,1,1,3,16,1,20,0,0,0,16,2,20,9,1,17,1,17,16,0,20,1,5,0,4,3,1,30,1,0,0]

def active23989 : List Nat := [0,1,2,3]

def tree23989 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23989 : H12WitnessSearch.Good tree23989 := H12GlobalWitnessIndex.good

theorem leafIdentity23989 : H12AffineFastState.composeSystem env23989 rootObs = leafEnv23989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23989 rootObs == leafEnv23989) = true)

theorem terminalChecked23989 : H12PackedTerminal.terminalCheckFast leafEnv23989 active23989 tree23989 = true := by decide +kernel

def env23990 : List Nat := [2,4,8,16,0,17,8,5,512,21,1,17,9,0,1,3,17,0,21,0,0,0,16,2,9,17,0,16,16,1,21,1,5,0,0,512]

theorem envBound23990 : H12AffineFastState.Bounded env23990 := by
  intro p hp
  have h : env23990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23987_23990 : H12AffineEnvironment.transform 9 21 env23987 = env23990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env23987 == env23990) = true)

theorem identity23990 : scanCanonicalize (H12AffineFastState.compose env23990 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound23990 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23991 : List Nat := [2,4,8,4,0,5,8,5,512,1,1,5,9,0,1,3,5,0,1,0,0,0,4,2,9,5,0,4,4,1,1,1,5,0,0,512]

theorem envBound23991 : H12AffineFastState.Bounded env23991 := by
  intro p hp
  have h : env23991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23990_23991 : H12AffineEnvironment.transform 3 4 env23990 = env23991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env23990 == env23991) = true)

def leafEnv23991 : List Nat := [2,4,8,4,0,5,8,5,512,1,1,5,9,0,1,3,5,0,1,0,0,0,4,2,1,9,1,5,0,4,4,1,1,1,5,0,4,3,0,512,1,0,0]

def active23991 : List Nat := [0,1,2,8]

def tree23991 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23991 : H12WitnessSearch.Good tree23991 := H12GlobalWitnessIndex.good

theorem leafIdentity23991 : H12AffineFastState.composeSystem env23991 rootObs = leafEnv23991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23991 rootObs == leafEnv23991) = true)

theorem terminalChecked23991 : H12PackedTerminal.terminalCheckFast leafEnv23991 active23991 tree23991 = true := by decide +kernel

def env23992 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,329731,16,95497,8193,64,245019,79131,102742,442385,61705,318549,256,95531,103431,120406]

theorem envBound23992 : H12AffineFastState.Bounded env23992 := by
  intro p hp
  have h : env23992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23954_23992 : H12AffineEnvironment.transform 6 9 env23954 = env23992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23954 == env23992) = true)

theorem identity23992 : scanCanonicalize (H12AffineFastState.compose env23992 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound23992 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23993 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,318548,16,41310,8193,64,158028,57676,17665,442385,61705,318549,256,41340,16464,513]

theorem envBound23993 : H12AffineFastState.Bounded env23993 := by
  intro p hp
  have h : env23993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23992_23993 : H12AffineEnvironment.transform 15 54359 env23992 = env23993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env23992 == env23993) = true)

def env23994 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4113,318468,16,41230,8193,16,157980,57628,17665,442385,61705,318469,256,41260,16384,513]

theorem envBound23994 : H12AffineFastState.Bounded env23994 := by
  intro p hp
  have h : env23994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23993_23994 : H12AffineEnvironment.transform 5 16 env23993 = env23994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23993 == env23994) = true)

theorem identity23994 : scanCanonicalize (H12AffineFastState.compose env23994 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound23994 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23995 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,179512,1024,32769,4113,155964,16,41230,8193,16,157980,57628,17665,32041,61705,155965,256,41260,16384,513]

theorem envBound23995 : H12AffineFastState.Bounded env23995 := by
  intro p hp
  have h : env23995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23994_23995 : H12AffineEnvironment.transform 17 179512 env23994 = env23995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env23994 == env23995) = true)

theorem identity23995 : scanCanonicalize (H12AffineFastState.compose env23995 (packedSelected [3,10,18,19,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound23995 : packedSelected [3,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env23996 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,24860,56356,1024,32769,4113,32,16,41230,8193,16,2048,57628,17665,32041,61705,33,256,41260,16384,513]

theorem envBound23996 : H12AffineFastState.Bounded env23996 := by
  intro p hp
  have h : env23996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23995_23996 : H12AffineEnvironment.transform 16 24860 env23995 = env23996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env23995 == env23996) = true)

theorem identity23996 : scanCanonicalize (H12AffineFastState.compose env23996 (packedSelected [0,1,7,8,12,15,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23996 : packedSelected [0,1,7,8,12,15,19,20] rootPS < 2^1333 := by decide +kernel

def env23997 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,32768,54279,16401,56356,1024,32769,4113,32,16,32771,268,16,2048,49169,17665,23588,53252,33,256,32801,16384,513]

theorem envBound23997 : H12AffineFastState.Bounded env23997 := by
  intro p hp
  have h : env23997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23996_23997 : H12AffineEnvironment.transform 12 269 env23996 = env23997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23996 == env23997) = true)

theorem identity23997 : scanCanonicalize (H12AffineFastState.compose env23997 (packedSelected [1,4,7,8,11,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 19492) := by decide +kernel

theorem selectedBound23997 : packedSelected [1,4,7,8,11,12,18] rootPS < 2^1333 := by decide +kernel

def env23998 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,19492,6179,16401,4096,1024,19493,4113,32,16,19495,268,16,2048,3125,17665,23588,7200,33,256,19461,16384,513]

theorem envBound23998 : H12AffineFastState.Bounded env23998 := by
  intro p hp
  have h : env23998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23997_23998 : H12AffineEnvironment.transform 14 19492 env23997 = env23998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 19492 env23997 == env23998) = true)

theorem identity23998 : scanCanonicalize (H12AffineFastState.compose env23998 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 2341) := by decide +kernel

theorem selectedBound23998 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env23999 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2341,269,16384,19492,262,16401,2341,1024,19493,2356,32,16,19495,268,16,2048,3125,17665,17665,1285,33,256,19461,16384,513]

theorem envBound23999 : H12AffineFastState.Bounded env23999 := by
  intro p hp
  have h : env23999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23998_23999 : H12AffineEnvironment.transform 11 2341 env23998 = env23999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2341 env23998 == env23999) = true)

theorem identity23999 : scanCanonicalize (H12AffineFastState.compose env23999 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1792) := by decide +kernel

theorem selectedBound23999 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env24000 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,1573,269,16384,17188,262,16401,1573,1024,17189,1588,32,16,17191,268,16,1792,821,17665,17665,1285,33,256,17157,16384,513]

theorem envBound24000 : H12AffineFastState.Bounded env24000 := by
  intro p hp
  have h : env24000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23999_24000 : H12AffineEnvironment.transform 10 1792 env23999 = env24000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env23999 == env24000) = true)

theorem identity24000 : scanCanonicalize (H12AffineFastState.compose env24000 (packedSelected [0,2,9] rootPS)) = affineNative (2^(13+1) ^^^ 309) := by decide +kernel

theorem selectedBound24000 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env24001 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,1573,269,309,529,262,292,1573,1024,528,1588,32,16,530,268,16,1792,821,1076,1076,1285,33,256,560,309,513]

theorem envBound24001 : H12AffineFastState.Bounded env24001 := by
  intro p hp
  have h : env24001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24000_24001 : H12AffineEnvironment.transform 13 309 env24000 = env24001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 309 env24000 == env24001) = true)

theorem identity24001 : scanCanonicalize (H12AffineFastState.compose env24001 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound24001 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env24002 : List Nat := [2,4,8,16,32,16,9,256,17,1024,1297,1076,269,309,0,262,292,1076,1024,1,1061,32,16,3,268,16,1297,292,1076,1076,1285,33,256,33,309,16]

theorem envBound24002 : H12AffineFastState.Bounded env24002 := by
  intro p hp
  have h : env24002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24001_24002 : H12AffineEnvironment.transform 8 17 env24001 = env24002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env24001 == env24002) = true)

theorem identity24002 : scanCanonicalize (H12AffineFastState.compose env24002 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24002 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24003 : List Nat := [2,4,8,0,32,0,9,256,1,1024,1281,1060,269,293,0,262,292,1060,1024,1,1061,32,0,3,268,0,1281,292,1060,1060,1285,33,256,33,293,0]

theorem envBound24003 : H12AffineFastState.Bounded env24003 := by
  intro p hp
  have h : env24003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24002_24003 : H12AffineEnvironment.transform 3 0 env24002 = env24003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24002 == env24003) = true)

theorem identity24003 : scanCanonicalize (H12AffineFastState.compose env24003 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound24003 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24004 : List Nat := [2,4,8,0,32,0,9,256,1,257,0,293,269,293,0,262,292,293,257,1,292,32,0,3,268,0,0,292,293,293,4,33,256,33,293,0]

theorem envBound24004 : H12AffineFastState.Bounded env24004 := by
  intro p hp
  have h : env24004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24003_24004 : H12AffineEnvironment.transform 9 257 env24003 = env24004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env24003 == env24004) = true)

def env24005 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4112,318469,16,41231,8193,17,157981,57629,17665,442385,61705,318468,256,41261,16385,513]

theorem envBound24005 : H12AffineFastState.Bounded env24005 := by
  intro p hp
  have h : env24005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23993_24005 : H12AffineEnvironment.transform 5 17 env23993 = env24005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23993 == env24005) = true)

theorem identity24005 : scanCanonicalize (H12AffineFastState.compose env24005 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 149813) := by decide +kernel

theorem selectedBound24005 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24006 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,149813,1024,32769,4112,169264,16,41231,8193,17,157981,57629,17665,35108,61705,169265,256,41261,16385,513]

theorem envBound24006 : H12AffineFastState.Bounded env24006 := by
  intro p hp
  have h : env24006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24005_24006 : H12AffineEnvironment.transform 17 149813 env24005 = env24006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149813 env24005 == env24006) = true)

theorem identity24006 : scanCanonicalize (H12AffineFastState.compose env24006 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound24006 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env24007 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,29963,131072,149813,1024,8460,4112,144445,16,2,8193,17,157981,16400,17665,10281,20484,144444,256,32,16385,513]

theorem envBound24007 : H12AffineFastState.Bounded env24007 := by
  intro p hp
  have h : env24007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24006_24007 : H12AffineEnvironment.transform 14 8461 env24006 = env24007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env24006 == env24007) = true)

theorem identity24007 : scanCanonicalize (H12AffineFastState.compose env24007 (packedSelected [1,3,8,10,12,15,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound24007 : packedSelected [1,3,8,10,12,15,24] rootPS < 2^1333 := by decide +kernel

def env24008 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,8461,263,131072,146745,1024,8460,4112,144445,16,2,8193,17,138513,13340,12557,10281,9224,144444,256,32,13325,513]

theorem envBound24008 : H12AffineFastState.Bounded env24008 := by
  intro p hp
  have h : env24008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24007_24008 : H12AffineEnvironment.transform 13 13324 env24007 = env24008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env24007 == env24008) = true)

theorem identity24008 : scanCanonicalize (H12AffineFastState.compose env24008 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound24008 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24009 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,8461,263,5392,10281,1024,8460,4112,8493,16,2,8193,17,2049,13340,12557,10281,9224,8492,256,32,13325,513]

theorem envBound24009 : H12AffineFastState.Bounded env24009 := by
  intro p hp
  have h : env24009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24008_24009 : H12AffineEnvironment.transform 16 5392 env24008 = env24009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env24008 == env24009) = true)

theorem identity24009 : scanCanonicalize (H12AffineFastState.compose env24009 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound24009 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env24010 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,8192,12572,8461,263,4096,10281,272,8460,4112,8493,16,2,8193,17,2049,12556,12557,10281,8472,8492,256,32,12573,513]

theorem envBound24010 : H12AffineFastState.Bounded env24010 := by
  intro p hp
  have h : env24010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24009_24010 : H12AffineEnvironment.transform 9 272 env24009 = env24010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env24009 == env24010) = true)

theorem identity24010 : scanCanonicalize (H12AffineFastState.compose env24010 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound24010 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24011 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,301,4145,32,263,4096,2308,272,33,4112,0,16,2,300,17,2049,4129,4128,2308,53,1,256,32,4144,513]

theorem envBound24011 : H12AffineFastState.Bounded env24011 := by
  intro p hp
  have h : env24011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24010_24011 : H12AffineEnvironment.transform 12 301 env24010 = env24011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env24010 == env24011) = true)

theorem identity24011 : scanCanonicalize (H12AffineFastState.compose env24011 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24011 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24012 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,4096,268,4112,1,263,4096,2308,272,0,4112,0,16,2,269,17,2049,4096,4097,2308,20,1,256,1,4113,513]

theorem envBound24012 : H12AffineFastState.Bounded env24012 := by
  intro p hp
  have h : env24012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24011_24012 : H12AffineEnvironment.transform 4 1 env24011 = env24012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24011 == env24012) = true)

theorem identity24012 : scanCanonicalize (H12AffineFastState.compose env24012 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound24012 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24013 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,277,268,261,1,263,277,2308,272,0,261,0,16,2,269,17,2049,277,276,2308,20,1,256,1,260,513]

theorem envBound24013 : H12AffineFastState.Bounded env24013 := by
  intro p hp
  have h : env24013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24012_24013 : H12AffineEnvironment.transform 11 277 env24012 = env24013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env24012 == env24013) = true)

theorem identity24013 : scanCanonicalize (H12AffineFastState.compose env24013 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound24013 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24014 : List Nat := [2,4,8,16,1,17,9,256,512,272,522,277,268,261,1,263,277,782,272,0,261,0,16,2,269,17,523,277,276,782,20,1,256,1,260,513]

theorem envBound24014 : H12AffineFastState.Bounded env24014 := by
  intro p hp
  have h : env24014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24013_24014 : H12AffineEnvironment.transform 10 522 env24013 = env24014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env24013 == env24014) = true)

theorem identity24014 : scanCanonicalize (H12AffineFastState.compose env24014 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound24014 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24015 : List Nat := [2,4,8,16,1,17,9,256,10,272,0,277,268,261,1,263,277,260,272,0,261,0,16,2,269,17,1,277,276,260,20,1,256,1,260,11]

theorem envBound24015 : H12AffineFastState.Bounded env24015 := by
  intro p hp
  have h : env24015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24014_24015 : H12AffineEnvironment.transform 8 10 env24014 = env24015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env24014 == env24015) = true)

def env24016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound24016 : H12AffineFastState.Bounded env24016 := by
  intro p hp
  have h : env24016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23810_24016 : H12AffineEnvironment.transform 18 1025 env23810 = env24016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env23810 == env24016) = true)

theorem identity24016 : scanCanonicalize (H12AffineFastState.compose env24016 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2237454) := by decide +kernel

theorem selectedBound24016 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env24017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2237454,8328,64,15066126,237698,10507600,8830976,10723358,4407758,257,8642722,8585478,10651593]

theorem envBound24017 : H12AffineFastState.Bounded env24017 := by
  intro p hp
  have h : env24017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24016_24017 : H12AffineEnvironment.transform 23 2237454 env24016 = env24017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2237454 env24016 == env24017) = true)

def env24018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15066126,115150,10507600,8692044,10600786,4268162,257,8487406,8478794,10544773]

theorem envBound24018 : H12AffineFastState.Bounded env24018 := by
  intro p hp
  have h : env24018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24017_24018 : H12AffineEnvironment.transform 16 24908 env24017 = env24018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env24017 == env24018) = true)

def env24019 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,8388608,2114834,8328,16,15066126,115102,10507520,8691996,10600706,4268162,257,8487358,8478746,10544773]

theorem envBound24019 : H12AffineFastState.Bounded env24019 := by
  intro p hp
  have h : env24019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24018_24019 : H12AffineEnvironment.transform 5 16 env24018 = env24019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24018 == env24019) = true)

theorem identity24019 : scanCanonicalize (H12AffineFastState.compose env24019 (packedSelected [1,3,12,17,21,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound24019 : packedSelected [1,3,12,17,21,24,28,41] rootPS < 2^1333 := by decide +kernel

def env24020 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,2097152,4194304,8388608,2114834,8328,16,14797862,115102,10507520,8423732,10600706,4268162,257,8487358,8478746,10544773]

theorem envBound24020 : H12AffineFastState.Bounded env24020 := by
  intro p hp
  have h : env24020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24019_24020 : H12AffineEnvironment.transform 17 10280 env24019 = env24020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24019 == env24020) = true)

def env24021 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,2097152,4194304,8388608,2114834,8192,16,14797862,114966,10507520,8423732,10600706,4268042,257,8487222,8478746,10544653]

theorem envBound24021 : H12AffineFastState.Bounded env24021 := by
  intro p hp
  have h : env24021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24020_24021 : H12AffineEnvironment.transform 6 8 env24020 = env24021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24020 == env24021) = true)

theorem identity24021 : scanCanonicalize (H12AffineFastState.compose env24021 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 2155532) := by decide +kernel

theorem selectedBound24021 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env24022 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,2097152,4194304,2155532,2114834,8192,16,4270122,114966,45324,2125112,75022,4268042,257,2188602,2196502,513]

theorem envBound24022 : H12AffineFastState.Bounded env24022 := by
  intro p hp
  have h : env24022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24021_24022 : H12AffineEnvironment.transform 22 2155532 env24021 = env24022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2155532 env24021 == env24022) = true)

theorem identity24022 : scanCanonicalize (H12AffineFastState.compose env24022 (packedSelected [2,3,4,5,6,9,10,12,15,16,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 2221370) := by decide +kernel

theorem selectedBound24022 : packedSelected [2,3,4,5,6,9,10,12,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env24023 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,2097152,2221370,2155532,2114834,8192,16,2149648,114966,45324,2125112,75022,2147632,257,2188602,2196502,513]

theorem envBound24023 : H12AffineFastState.Bounded env24023 := by
  intro p hp
  have h : env24023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24022_24023 : H12AffineEnvironment.transform 21 2221370 env24022 = env24023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2221370 env24022 == env24023) = true)

theorem identity24023 : scanCanonicalize (H12AffineFastState.compose env24023 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(20+1) ^^^ 124187) := by decide +kernel

theorem selectedBound24023 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env24024 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,124187,33,65815,106505,8192,16,75787,114966,45324,100387,75022,73771,257,32801,24845,513]

theorem envBound24024 : H12AffineFastState.Bounded env24024 := by
  intro p hp
  have h : env24024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24023_24024 : H12AffineEnvironment.transform 20 124187 env24023 = env24024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124187 env24023 == env24024) = true)

def env24025 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,2097152,4194304,8388608,2114834,8193,16,14797862,114967,10507520,8423732,10600706,4268043,257,8487223,8478746,10544652]

theorem envBound24025 : H12AffineFastState.Bounded env24025 := by
  intro p hp
  have h : env24025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24020_24025 : H12AffineEnvironment.transform 6 9 env24020 = env24025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24020 == env24025) = true)

theorem identity24025 : scanCanonicalize (H12AffineFastState.compose env24025 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound24025 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env24026 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,17681,4194304,8388608,3,8193,16,12683575,114967,8392721,8423732,8487955,4268043,257,8487223,8478746,8430365]

theorem envBound24026 : H12AffineFastState.Bounded env24026 := by
  intro p hp
  have h : env24026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24025_24026 : H12AffineEnvironment.transform 20 17681 env24025 = env24026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env24025 == env24026) = true)

theorem identity24026 : scanCanonicalize (H12AffineFastState.compose env24026 (packedSelected [0,3,4,5,10,12,14,15,20,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound24026 : packedSelected [0,3,4,5,10,12,14,15,20,22,27] rootPS < 2^1333 := by decide +kernel

def env24027 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8232,65536,24860,10280,1025,8233,17681,4194304,8388608,3,8193,16,12658975,90431,8392721,8399132,8463419,4268043,257,8462623,8478746,8389429]

theorem envBound24027 : H12AffineFastState.Bounded env24027 := by
  intro p hp
  have h : env24027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24026_24027 : H12AffineEnvironment.transform 14 8232 env24026 = env24027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env24026 == env24027) = true)

theorem identity24027 : scanCanonicalize (H12AffineFastState.compose env24027 (packedSelected [0,3,7,8,9,14,16,18,19,22,23,24,28] rootPS)) = affineNative (2^(22+1) ^^^ 4194581) := by decide +kernel

theorem selectedBound24027 : packedSelected [0,3,7,8,9,14,16,18,19,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env24028 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8232,65536,24860,10280,1025,8233,17681,4194304,4194581,3,8193,16,75786,90431,4198660,4204553,4269358,4268043,257,4268042,4284687,4194848]

theorem envBound24028 : H12AffineFastState.Bounded env24028 := by
  intro p hp
  have h : env24028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24027_24028 : H12AffineEnvironment.transform 22 4194581 env24027 = env24028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194581 env24027 == env24028) = true)

theorem identity24028 : scanCanonicalize (H12AffineFastState.compose env24028 (packedSelected [0,1,2,6,7,8,11,17,18,19,20] rootPS)) = affineNative (2^(21+1) ^^^ 87299) := by decide +kernel

theorem selectedBound24028 : packedSelected [0,1,2,6,7,8,11,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env24029 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8232,65536,24860,10280,1025,8233,17681,87299,87062,3,8193,16,75786,90431,82951,97546,28717,29960,257,29961,13324,87843]

theorem envBound24029 : H12AffineFastState.Bounded env24029 := by
  intro p hp
  have h : env24029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24028_24029 : H12AffineEnvironment.transform 21 87299 env24028 = env24029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 87299 env24028 == env24029) = true)

theorem identity24029 : scanCanonicalize (H12AffineFastState.compose env24029 (packedSelected [0,4,7,9,11,12,14,17] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound24029 : packedSelected [0,4,7,9,11,12,14,17] rootPS < 2^1333 := by decide +kernel

def env24030 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8232,28699,24860,10280,1025,8233,17681,9496,9229,3,8193,16,22545,4388,13340,3345,28717,29960,257,29961,13324,10040]

theorem envBound24030 : H12AffineFastState.Bounded env24030 := by
  intro p hp
  have h : env24030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24029_24030 : H12AffineEnvironment.transform 15 28699 env24029 = env24030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env24029 == env24030) = true)

theorem identity24030 : scanCanonicalize (H12AffineFastState.compose env24030 (packedSelected [1,3,4,5,8,9,10,11,12,14,15,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound24030 : packedSelected [1,3,4,5,8,9,10,11,12,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env24031 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1053,16384,1077,21510,17665,3125,1025,1076,17681,261,16,3,1052,16,22545,4388,4097,3345,21552,20757,257,20756,4113,805]

theorem envBound24031 : H12AffineFastState.Bounded env24031 := by
  intro p hp
  have h : env24031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24030_24031 : H12AffineEnvironment.transform 12 1053 env24030 = env24031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env24030 == env24031) = true)

theorem identity24031 : scanCanonicalize (H12AffineFastState.compose env24031 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound24031 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24032 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1053,4405,1077,1331,5172,3125,1025,1076,5156,261,16,3,1052,16,2340,4388,4097,3345,1285,32,257,33,4113,805]

theorem envBound24032 : H12AffineFastState.Bounded env24032 := by
  intro p hp
  have h : env24032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24031_24032 : H12AffineEnvironment.transform 13 4405 env24031 = env24032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env24031 == env24032) = true)

def env24033 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,8388608,2114835,8328,17,15066126,115103,10507521,8691997,10600707,4268162,257,8487359,8478747,10544773]

theorem envBound24033 : H12AffineFastState.Bounded env24033 := by
  intro p hp
  have h : env24033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24018_24033 : H12AffineEnvironment.transform 5 17 env24018 = env24033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24018 == env24033) = true)

def env24034 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,2101248,2114835,8328,17,4584462,115103,17665,2404637,119043,4268162,257,2199999,2191387,63109]

theorem envBound24034 : H12AffineFastState.Bounded env24034 := by
  intro p hp
  have h : env24034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24033_24034 : H12AffineEnvironment.transform 22 2101248 env24033 = env24034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101248 env24033 == env24034) = true)

def env24035 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,272512,2101248,2114835,8328,17,121998,115103,17665,2404637,119043,329730,257,2199999,2191387,63109]

theorem envBound24035 : H12AffineFastState.Bounded env24035 := by
  intro p hp
  have h : env24035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24034_24035 : H12AffineEnvironment.transform 21 272512 env24034 = env24035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env24034 == env24035) = true)

theorem identity24035 : scanCanonicalize (H12AffineFastState.compose env24035 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24035 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24036 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,24861,262144,1025,32769,2097152,272512,2101248,2114835,8328,17,64644,57749,17665,2404637,61705,272392,257,2142645,2117649,63109]

theorem envBound24036 : H12AffineFastState.Bounded env24036 := by
  intro p hp
  have h : env24036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24035_24036 : H12AffineEnvironment.transform 15 8202 env24035 = env24036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24035 == env24036) = true)

def env24037 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,32768,170,16829,262144,1025,32769,2097152,264224,2101248,2114835,40,17,56356,49461,17665,2396605,53673,264360,257,2134293,2117649,54821]

theorem envBound24037 : H12AffineFastState.Bounded env24037 := by
  intro p hp
  have h : env24037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24036_24037 : H12AffineEnvironment.transform 12 160 env24036 = env24037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env24036 == env24037) = true)

theorem identity24037 : scanCanonicalize (H12AffineFastState.compose env24037 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound24037 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env24038 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,32768,170,16829,2476,1025,32769,2097152,396,2101248,2114835,40,17,56356,49461,17665,2136081,53673,260,257,2134293,2117649,54821]

theorem envBound24038 : H12AffineFastState.Bounded env24038 := by
  intro p hp
  have h : env24038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24037_24038 : H12AffineEnvironment.transform 17 2476 env24037 = env24038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env24037 == env24038) = true)

theorem identity24038 : scanCanonicalize (H12AffineFastState.compose env24038 (packedSelected [2,5,6,9,11,12,14,15,16,18,19,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24038 : packedSelected [2,5,6,9,11,12,14,15,16,18,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env24039 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,0,170,16829,2476,1025,1,2097152,396,2101248,2114835,40,17,23588,16693,17665,2103313,20905,260,257,2101525,2117649,22053]

theorem envBound24039 : H12AffineFastState.Bounded env24039 := by
  intro p hp
  have h : env24039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24038_24039 : H12AffineEnvironment.transform 14 0 env24038 = env24039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24038 == env24039) = true)

theorem identity24039 : scanCanonicalize (H12AffineFastState.compose env24039 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 17816) := by decide +kernel

theorem selectedBound24039 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env24040 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,0,170,16829,2476,1025,1,17816,396,21912,139,40,17,23588,16693,17665,23945,20905,260,257,21645,5513,22053]

theorem envBound24040 : H12AffineFastState.Bounded env24040 := by
  intro p hp
  have h : env24040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24039_24040 : H12AffineEnvironment.transform 20 17816 env24039 = env24040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17816 env24039 == env24040) = true)

theorem identity24040 : scanCanonicalize (H12AffineFastState.compose env24040 (packedSelected [0,1,2,3,5,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound24040 : packedSelected [0,1,2,3,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env24041 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,1212,0,170,1281,2476,1025,1,292,396,4388,139,40,17,6296,1417,445,6453,5397,260,257,4145,5513,4761]

theorem envBound24041 : H12AffineFastState.Bounded env24041 := by
  intro p hp
  have h : env24041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24040_24041 : H12AffineEnvironment.transform 13 1212 env24040 = env24041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env24040 == env24041) = true)

theorem identity24041 : scanCanonicalize (H12AffineFastState.compose env24041 (packedSelected [0,2,3,4,5,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24041 : packedSelected [0,2,3,4,5,12,15] rootPS < 2^1333 := by decide +kernel

def env24042 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,41,1077,0,35,1281,2341,1025,1,292,261,4388,2,40,17,6161,1280,308,6453,5397,260,257,4145,5376,4624]

theorem envBound24042 : H12AffineFastState.Bounded env24042 := by
  intro p hp
  have h : env24042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24041_24042 : H12AffineEnvironment.transform 6 9 env24041 = env24042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24041 == env24042) = true)

theorem identity24042 : scanCanonicalize (H12AffineFastState.compose env24042 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound24042 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env24043 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,309,41,1077,0,35,1281,2341,1025,1,292,261,17,2,40,17,2340,1280,308,2048,1056,260,257,260,1077,805]

theorem envBound24043 : H12AffineFastState.Bounded env24043 := by
  intro p hp
  have h : env24043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24042_24043 : H12AffineEnvironment.transform 11 309 env24042 = env24043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env24042 == env24043) = true)

theorem identity24043 : scanCanonicalize (H12AffineFastState.compose env24043 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound24043 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env24044 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,309,41,293,0,35,17,2341,273,1,292,261,17,2,40,17,2340,16,308,2048,304,260,257,260,293,805]

theorem envBound24044 : H12AffineFastState.Bounded env24044 := by
  intro p hp
  have h : env24044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24043_24044 : H12AffineEnvironment.transform 9 272 env24043 = env24044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env24043 == env24044) = true)

theorem identity24044 : scanCanonicalize (H12AffineFastState.compose env24044 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound24044 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24045 : List Nat := [2,4,8,16,32,17,9,256,512,272,292,309,41,293,0,35,17,1,273,1,292,261,17,2,40,17,0,16,308,292,304,260,257,260,293,805]

theorem envBound24045 : H12AffineFastState.Bounded env24045 := by
  intro p hp
  have h : env24045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24044_24045 : H12AffineEnvironment.transform 10 292 env24044 = env24045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env24044 == env24045) = true)

theorem identity24045 : scanCanonicalize (H12AffineFastState.compose env24045 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound24045 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24046 : List Nat := [2,4,8,16,32,17,9,36,512,52,0,17,41,1,0,35,17,1,53,1,0,33,17,2,40,17,0,16,16,0,20,32,37,32,1,513]

theorem envBound24046 : H12AffineFastState.Bounded env24046 := by
  intro p hp
  have h : env24046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24045_24046 : H12AffineEnvironment.transform 7 36 env24045 = env24046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env24045 == env24046) = true)

theorem identity24046 : scanCanonicalize (H12AffineFastState.compose env24046 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24046 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24047 : List Nat := [2,4,8,16,0,17,9,4,512,20,0,17,9,1,0,3,17,1,21,1,0,1,17,2,8,17,0,16,16,0,20,0,5,0,1,513]

theorem envBound24047 : H12AffineFastState.Bounded env24047 := by
  intro p hp
  have h : env24047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24046_24047 : H12AffineEnvironment.transform 4 0 env24046 = env24047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24046 == env24047) = true)

theorem identity24047 : scanCanonicalize (H12AffineFastState.compose env24047 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound24047 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24048 : List Nat := [2,4,8,16,0,17,9,4,17,20,0,17,9,1,0,3,17,1,21,1,0,1,17,2,8,17,0,16,16,0,20,0,5,0,1,16]

theorem envBound24048 : H12AffineFastState.Bounded env24048 := by
  intro p hp
  have h : env24048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24047_24048 : H12AffineEnvironment.transform 8 17 env24047 = env24048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env24047 == env24048) = true)

def env24049 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,16384,32768,171,16828,262144,1025,32769,2097152,264225,2101248,2114835,41,17,56357,49460,17665,2396604,53672,264361,257,2134292,2117649,54820]

theorem envBound24049 : H12AffineFastState.Bounded env24049 := by
  intro p hp
  have h : env24049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24036_24049 : H12AffineEnvironment.transform 12 161 env24036 = env24049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env24036 == env24049) = true)

theorem identity24049 : scanCanonicalize (H12AffineFastState.compose env24049 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound24049 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env24050 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,16384,32768,171,16828,2340,1025,32769,2097152,261,2101248,2114835,41,17,56357,49460,17665,2136216,53672,397,257,2134292,2117649,54820]

theorem envBound24050 : H12AffineFastState.Bounded env24050 := by
  intro p hp
  have h : env24050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24049_24050 : H12AffineEnvironment.transform 17 2340 env24049 = env24050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env24049 == env24050) = true)

theorem identity24050 : scanCanonicalize (H12AffineFastState.compose env24050 (packedSelected [0,2,3,4,6,7,9,10,11,14,17,19,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

end H12CloudChart1