import H12CloudChart1Data179

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans45623_45624 : H12AffineEnvironment.transform 3 0 env45623 = env45624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45623 == env45624) = true)

theorem identity45624 : scanCanonicalize (H12AffineFastState.compose env45624 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 46) := by decide +kernel

theorem selectedBound45624 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45625 : List Nat := [2,4,8,0,32,0,8,36,46,37,0,1,40,0,0,35,1,1,37,1,1,32,1,3,40,1,1,1,1,1,5,32,36,32,0,46]

theorem envBound45625 : H12AffineFastState.Bounded env45625 := by
  intro p hp
  have h : env45625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45624_45625 : H12AffineEnvironment.transform 8 46 env45624 = env45625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 46 env45624 == env45625) = true)

theorem identity45625 : scanCanonicalize (H12AffineFastState.compose env45625 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45625 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45626 : List Nat := [2,4,8,0,0,0,8,4,14,5,0,1,8,0,0,3,1,1,5,1,1,0,1,3,8,1,1,1,1,1,5,0,4,0,0,14]

theorem envBound45626 : H12AffineFastState.Bounded env45626 := by
  intro p hp
  have h : env45626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45625_45626 : H12AffineEnvironment.transform 4 0 env45625 = env45626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45625 == env45626) = true)

def env45627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,509986,498992,8328,65,349611,395772,494898,67618,119043,272392,256,98814,90202,63188]

theorem envBound45627 : H12AffineFastState.Bounded env45627 := by
  intro p hp
  have h : env45627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45596_45627 : H12AffineEnvironment.transform 20 4161 env45596 = env45627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env45596 == env45627) = true)

def env45628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,4161,180409,254082,243088,8328,65,97547,139612,238994,67618,119043,168,256,98814,90202,63188]

theorem envBound45628 : H12AffineFastState.Bounded env45628 := by
  intro p hp
  have h : env45628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45627_45628 : H12AffineEnvironment.transform 17 10400 env45627 = env45628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env45627 == env45628) = true)

def env45629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,180273,253962,242968,8192,65,97547,139612,238874,67618,119043,32,256,98678,90202,63068]

theorem envBound45629 : H12AffineFastState.Bounded env45629 := by
  intro p hp
  have h : env45629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45628_45629 : H12AffineEnvironment.transform 6 8 env45628 = env45629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45628 == env45629) = true)

theorem identity45629 : scanCanonicalize (H12AffineFastState.compose env45629 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound45629 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env45630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1024,29788,4161,144492,201815,213317,8192,65,97547,139612,217415,67618,75102,32,256,95531,90202,513]

theorem envBound45630 : H12AffineFastState.Bounded env45630 := by
  intro p hp
  have h : env45630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45629_45630 : H12AffineEnvironment.transform 14 29789 env45629 = env45630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env45629 == env45630) = true)

theorem identity45630 : scanCanonicalize (H12AffineFastState.compose env45630 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound45630 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env45631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,82246,10280,1024,29788,4161,95530,21777,3,8192,65,97547,90138,4097,67618,75102,32,256,95531,90202,513]

theorem envBound45631 : H12AffineFastState.Bounded env45631 := by
  intro p hp
  have h : env45631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45630_45631 : H12AffineEnvironment.transform 16 82246 env45630 = env45631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env45630 == env45631) = true)

theorem identity45631 : scanCanonicalize (H12AffineFastState.compose env45631 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound45631 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45632 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,263,16449,10280,1024,29788,4161,29741,21777,3,8192,65,31756,24861,4097,2341,9305,32,256,29740,24925,513]

theorem envBound45632 : H12AffineFastState.Bounded env45632 := by
  intro p hp
  have h : env45632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45631_45632 : H12AffineEnvironment.transform 15 263 env45631 = env45632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env45631 == env45632) = true)

theorem identity45632 : scanCanonicalize (H12AffineFastState.compose env45632 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound45632 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45633 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,263,5440,10280,1024,8541,4161,8492,16,3,8192,65,10509,13340,4097,2341,9305,32,256,8493,13404,513]

theorem envBound45633 : H12AffineFastState.Bounded env45633 := by
  intro p hp
  have h : env45633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45632_45633 : H12AffineEnvironment.transform 13 5377 env45632 = env45633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45632 == env45633) = true)

theorem identity45633 : scanCanonicalize (H12AffineFastState.compose env45633 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45633 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45634 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,263,5440,2421,1024,0,4161,113,16,3,349,65,2128,5441,4097,2341,1284,32,256,112,5377,513]

theorem envBound45634 : H12AffineFastState.Bounded env45634 := by
  intro p hp
  have h : env45634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45633_45634 : H12AffineEnvironment.transform 12 349 env45633 = env45634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45633 == env45634) = true)

theorem identity45634 : scanCanonicalize (H12AffineFastState.compose env45634 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound45634 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env45635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1588,4096,349,5377,1,263,5440,1857,1024,0,4161,113,16,3,349,65,1636,5441,4097,1809,1284,32,256,112,5377,513]

theorem envBound45635 : H12AffineFastState.Bounded env45635 := by
  intro p hp
  have h : env45635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45634_45635 : H12AffineEnvironment.transform 10 1588 env45634 = env45635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env45634 == env45635) = true)

theorem identity45635 : scanCanonicalize (H12AffineFastState.compose env45635 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 324) := by decide +kernel

theorem selectedBound45635 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env45636 : List Nat := [2,4,8,16,32,64,8,256,324,1024,1392,4096,349,5377,1,263,5440,1029,1024,0,4161,113,16,3,349,65,1312,5441,4097,1109,1284,32,256,112,5377,325]

theorem envBound45636 : H12AffineFastState.Bounded env45636 := by
  intro p hp
  have h : env45636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45635_45636 : H12AffineEnvironment.transform 8 324 env45635 = env45636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env45635 == env45636) = true)

theorem identity45636 : scanCanonicalize (H12AffineFastState.compose env45636 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound45636 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env45637 : List Nat := [2,4,8,16,32,64,8,256,324,116,260,4096,349,4469,1,263,4404,113,116,0,4161,113,16,3,349,65,340,4405,4097,33,368,32,256,112,4469,325]

theorem envBound45637 : H12AffineFastState.Bounded env45637 := by
  intro p hp
  have h : env45637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45636_45637 : H12AffineEnvironment.transform 9 116 env45636 = env45637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env45636 == env45637) = true)

theorem identity45637 : scanCanonicalize (H12AffineFastState.compose env45637 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound45637 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45638 : List Nat := [2,4,8,16,32,64,8,256,324,116,260,260,349,113,1,263,48,113,116,0,325,113,16,3,349,65,340,49,261,33,368,32,256,112,113,325]

theorem envBound45638 : H12AffineFastState.Bounded env45638 := by
  intro p hp
  have h : env45638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45637_45638 : H12AffineEnvironment.transform 11 260 env45637 = env45638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env45637 == env45638) = true)

theorem identity45638 : scanCanonicalize (H12AffineFastState.compose env45638 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound45638 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45639 : List Nat := [2,4,8,16,32,64,8,52,112,116,48,48,105,113,1,51,48,113,116,0,113,113,16,3,105,65,96,49,49,33,68,32,52,112,113,113]

theorem envBound45639 : H12AffineFastState.Bounded env45639 := by
  intro p hp
  have h : env45639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45638_45639 : H12AffineEnvironment.transform 7 52 env45638 = env45639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env45638 == env45639) = true)

def env45640 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,180272,253963,242969,8193,65,97547,139612,238875,67618,119043,33,256,98679,90202,63069]

theorem envBound45640 : H12AffineFastState.Bounded env45640 := by
  intro p hp
  have h : env45640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45628_45640 : H12AffineEnvironment.transform 6 9 env45628 = env45640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45628 == env45640) = true)

theorem identity45640 : scanCanonicalize (H12AffineFastState.compose env45640 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45640 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45641 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,4161,156012,213335,201797,8193,65,97547,139612,197703,67618,94303,33,256,73771,90202,22273]

theorem envBound45641 : H12AffineFastState.Bounded env45641 := by
  intro p hp
  have h : env45641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45640_45641 : H12AffineEnvironment.transform 14 8540 env45640 = env45641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45640 == env45641) = true)

theorem identity45641 : scanCanonicalize (H12AffineFastState.compose env45641 (packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound45641 : packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env45642 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,13389,10281,1024,8541,4161,21793,95514,73736,8193,65,97547,5393,77834,67618,94303,33,256,73771,90202,22273]

theorem envBound45642 : H12AffineFastState.Bounded env45642 := by
  intro p hp
  have h : env45642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45641_45642 : H12AffineEnvironment.transform 16 13389 env45641 = env45642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env45641 == env45642) = true)

theorem identity45642 : scanCanonicalize (H12AffineFastState.compose env45642 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound45642 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env45643 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,1095,13389,10281,1024,8541,4161,21793,29021,9295,8193,65,31052,5393,13389,3173,29720,33,256,9324,25629,22273]

theorem envBound45643 : H12AffineFastState.Bounded env45643 := by
  intro p hp
  have h : env45643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45642_45643 : H12AffineEnvironment.transform 15 1095 env45642 = env45643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env45642 == env45643) = true)

theorem identity45643 : scanCanonicalize (H12AffineFastState.compose env45643 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound45643 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env45644 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12392,8540,1095,13389,10281,1024,8541,4161,9545,309,9295,8193,65,2340,5393,13389,3173,1136,33,256,9324,5237,10089]

theorem envBound45644 : H12AffineFastState.Bounded env45644 := by
  intro p hp
  have h : env45644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45643_45644 : H12AffineEnvironment.transform 13 12392 env45643 = env45644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env45643 == env45644) = true)

theorem identity45644 : scanCanonicalize (H12AffineFastState.compose env45644 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound45644 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env45645 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,5377,1077,1095,4388,3392,1024,1076,4161,32,309,294,1384,65,2340,5393,4388,3173,1136,33,256,261,5237,512]

theorem envBound45645 : H12AffineFastState.Bounded env45645 := by
  intro p hp
  have h : env45645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45644_45645 : H12AffineEnvironment.transform 12 1385 env45644 = env45645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env45644 == env45645) = true)

theorem identity45645 : scanCanonicalize (H12AffineFastState.compose env45645 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound45645 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env45646 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,1085,5205,1077,1095,4208,3092,1024,1076,4161,32,97,114,1084,65,2160,5189,4208,3173,1136,33,84,81,5237,512]

theorem envBound45646 : H12AffineFastState.Bounded env45646 := by
  intro p hp
  have h : env45646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45645_45646 : H12AffineEnvironment.transform 7 84 env45645 = env45646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env45645 == env45646) = true)

theorem identity45646 : scanCanonicalize (H12AffineFastState.compose env45646 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound45646 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env45647 : List Nat := [2,4,8,16,32,64,9,84,512,1024,1,4096,1085,5205,1077,1095,4208,1045,1024,1076,4161,32,97,114,1084,65,113,5189,4208,1124,1136,33,84,81,5237,512]

theorem envBound45647 : H12AffineFastState.Bounded env45647 := by
  intro p hp
  have h : env45647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45646_45647 : H12AffineEnvironment.transform 10 1 env45646 = env45647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env45646 == env45647) = true)

theorem identity45647 : scanCanonicalize (H12AffineFastState.compose env45647 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound45647 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env45648 : List Nat := [2,4,8,16,32,64,9,84,512,1024,1,97,1085,1076,1077,1095,17,1045,1024,1076,32,32,97,114,1084,65,113,1060,17,1124,1136,33,84,81,1044,512]

theorem envBound45648 : H12AffineFastState.Bounded env45648 := by
  intro p hp
  have h : env45648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45647_45648 : H12AffineEnvironment.transform 11 97 env45647 = env45648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env45647 == env45648) = true)

theorem identity45648 : scanCanonicalize (H12AffineFastState.compose env45648 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45648 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45649 : List Nat := [2,4,8,16,32,16,9,4,512,1024,1,49,1085,1076,1077,1047,17,1045,1024,1076,32,32,49,34,1084,17,33,1060,17,1076,1056,33,4,1,1044,512]

theorem envBound45649 : H12AffineFastState.Bounded env45649 := by
  intro p hp
  have h : env45649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45648_45649 : H12AffineEnvironment.transform 5 16 env45648 = env45649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45648 == env45649) = true)

theorem identity45649 : scanCanonicalize (H12AffineFastState.compose env45649 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound45649 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env45650 : List Nat := [2,4,8,16,32,16,9,4,512,21,1,49,40,33,32,2,17,0,21,33,32,32,49,34,41,17,33,49,17,33,53,33,4,1,1,512]

theorem envBound45650 : H12AffineFastState.Bounded env45650 := by
  intro p hp
  have h : env45650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45649_45650 : H12AffineEnvironment.transform 9 21 env45649 = env45650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env45649 == env45650) = true)

theorem identity45650 : scanCanonicalize (H12AffineFastState.compose env45650 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 31) := by decide +kernel

theorem selectedBound45650 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45651 : List Nat := [2,4,8,16,31,16,9,4,512,21,1,14,23,30,31,2,17,0,21,30,31,31,14,29,22,17,30,14,17,30,10,30,4,1,1,512]

theorem envBound45651 : H12AffineFastState.Bounded env45651 := by
  intro p hp
  have h : env45651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45650_45651 : H12AffineEnvironment.transform 4 31 env45650 = env45651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 31 env45650 == env45651) = true)

theorem identity45651 : scanCanonicalize (H12AffineFastState.compose env45651 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound45651 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45652 : List Nat := [2,4,7,16,16,16,6,4,512,21,1,1,23,17,16,2,17,0,21,17,16,16,1,18,22,17,17,1,17,17,5,17,4,1,1,512]

theorem envBound45652 : H12AffineFastState.Bounded env45652 := by
  intro p hp
  have h : env45652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45651_45652 : H12AffineEnvironment.transform 2 7 env45651 = env45652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env45651 == env45652) = true)

theorem identity45652 : scanCanonicalize (H12AffineFastState.compose env45652 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound45652 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45653 : List Nat := [2,4,7,16,16,16,6,4,17,21,1,1,23,17,16,2,17,0,21,17,16,16,1,18,22,17,17,1,17,17,5,17,4,1,1,17]

theorem envBound45653 : H12AffineFastState.Bounded env45653 := by
  intro p hp
  have h : env45653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45652_45653 : H12AffineEnvironment.transform 8 17 env45652 = env45653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env45652 == env45653) = true)

theorem identity45653 : scanCanonicalize (H12AffineFastState.compose env45653 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45653 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45654 : List Nat := [2,4,7,1,1,1,6,4,0,4,1,1,6,0,1,2,0,0,4,0,1,1,1,3,7,0,0,1,0,0,5,0,4,1,1,0]

theorem envBound45654 : H12AffineFastState.Bounded env45654 := by
  intro p hp
  have h : env45654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45653_45654 : H12AffineEnvironment.transform 3 1 env45653 = env45654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45653 == env45654) = true)

def env45655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,4161,180409,254083,243089,8328,65,97546,139613,238995,67618,119043,169,256,98814,90202,63188]

theorem envBound45655 : H12AffineFastState.Bounded env45655 := by
  intro p hp
  have h : env45655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45627_45655 : H12AffineEnvironment.transform 17 10401 env45627 = env45655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env45627 == env45655) = true)

def env45656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,180273,253963,242969,8192,65,97546,139613,238875,67618,119043,33,256,98678,90202,63068]

theorem envBound45656 : H12AffineFastState.Bounded env45656 := by
  intro p hp
  have h : env45656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45655_45656 : H12AffineEnvironment.transform 6 8 env45655 = env45656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45655 == env45656) = true)

theorem identity45656 : scanCanonicalize (H12AffineFastState.compose env45656 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound45656 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45657 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1024,32769,4161,73771,17,21763,8192,65,97546,115015,17665,67618,119043,33,256,98678,90202,63068]

theorem envBound45657 : H12AffineFastState.Bounded env45657 := by
  intro p hp
  have h : env45657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45656_45657 : H12AffineEnvironment.transform 16 122906 env45656 = env45657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env45656 == env45657) = true)

theorem identity45657 : scanCanonicalize (H12AffineFastState.compose env45657 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound45657 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env45658 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,103494,10281,1024,32769,4161,73771,17,8543,8192,65,67926,111899,12637,67618,107871,33,256,98678,70662,33280]

theorem envBound45658 : H12AffineFastState.Bounded env45658 := by
  intro p hp
  have h : env45658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45657_45658 : H12AffineEnvironment.transform 13 13404 env45657 = env45658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env45657 == env45658) = true)

theorem identity45658 : scanCanonicalize (H12AffineFastState.compose env45658 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound45658 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env45659 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8283,46109,10281,1024,32769,4161,112,17,8543,8192,65,10509,38208,12637,10361,34052,33,256,41261,13405,33280]

theorem envBound45659 : H12AffineFastState.Bounded env45659 := by
  intro p hp
  have h : env45659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45658_45659 : H12AffineEnvironment.transform 15 8283 env45658 = env45659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env45658 == env45659) = true)

theorem identity45659 : scanCanonicalize (H12AffineFastState.compose env45659 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45659 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env45660 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13404,32768,8283,46109,10281,1024,32769,4161,112,17,8315,8192,65,10281,37988,12409,10361,33824,33,36,40969,13405,33280]

theorem envBound45660 : H12AffineFastState.Bounded env45660 := by
  intro p hp
  have h : env45660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45659_45660 : H12AffineEnvironment.transform 7 36 env45659 = env45660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45659 == env45660) = true)

theorem identity45660 : scanCanonicalize (H12AffineFastState.compose env45660 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound45660 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env45661 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13404,0,8283,13341,10281,1024,1,4161,112,17,8315,8192,65,10281,5220,12409,10361,1056,33,36,8201,13405,512]

theorem envBound45661 : H12AffineFastState.Bounded env45661 := by
  intro p hp
  have h : env45661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45660_45661 : H12AffineEnvironment.transform 14 0 env45660 = env45661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env45660 == env45661) = true)

theorem identity45661 : scanCanonicalize (H12AffineFastState.compose env45661 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45661 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env45662 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,13324,0,8203,13341,10281,1024,1,4113,32,17,8235,8192,17,10281,5172,12329,10281,1056,33,36,8201,13325,512]

theorem envBound45662 : H12AffineFastState.Bounded env45662 := by
  intro p hp
  have h : env45662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45661_45662 : H12AffineEnvironment.transform 5 16 env45661 = env45662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45661 == env45662) = true)

theorem identity45662 : scanCanonicalize (H12AffineFastState.compose env45662 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound45662 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env45663 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,7180,2048,0,7175,2065,5157,1024,1,4113,32,17,7207,7180,17,5157,5172,3109,5157,1056,33,36,7173,2049,512]

theorem envBound45663 : H12AffineFastState.Bounded env45663 := by
  intro p hp
  have h : env45663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45662_45663 : H12AffineEnvironment.transform 12 7180 env45662 = env45663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env45662 == env45663) = true)

theorem identity45663 : scanCanonicalize (H12AffineFastState.compose env45663 (packedSelected [1,2,5] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound45663 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env45664 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3109,41,2048,0,34,2065,2048,1024,1,3124,32,17,2,41,17,2048,2065,3109,2048,1056,33,36,32,2049,512]

theorem envBound45664 : H12AffineFastState.Bounded env45664 := by
  intro p hp
  have h : env45664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45663_45664 : H12AffineEnvironment.transform 11 3109 env45663 = env45664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env45663 == env45664) = true)

theorem identity45664 : scanCanonicalize (H12AffineFastState.compose env45664 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45664 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45665 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,3077,9,2048,0,2,2065,2048,1024,1,3092,0,17,2,9,17,2048,2065,3077,2048,1024,1,4,0,2049,512]

theorem envBound45665 : H12AffineFastState.Bounded env45665 := by
  intro p hp
  have h : env45665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45664_45665 : H12AffineEnvironment.transform 4 0 env45664 = env45665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45664 == env45665) = true)

theorem identity45665 : scanCanonicalize (H12AffineFastState.compose env45665 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound45665 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45666 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,2065,9,2048,0,2,2065,2048,20,1,2048,0,17,2,9,17,2048,2065,2065,2048,20,1,4,0,2049,512]

theorem envBound45666 : H12AffineFastState.Bounded env45666 := by
  intro p hp
  have h : env45666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45665_45666 : H12AffineEnvironment.transform 9 20 env45665 = env45666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45665 == env45666) = true)

def env45667 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,180272,253962,242968,8193,65,97546,139613,238874,67618,119043,32,256,98679,90202,63069]

theorem envBound45667 : H12AffineFastState.Bounded env45667 := by
  intro p hp
  have h : env45667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45655_45667 : H12AffineEnvironment.transform 6 9 env45655 = env45667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45655 == env45667) = true)

theorem identity45667 : scanCanonicalize (H12AffineFastState.compose env45667 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound45667 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45668 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1024,32769,4161,98679,41293,62559,8193,65,97546,90138,58461,67618,119043,32,256,98679,90202,63069]

theorem envBound45668 : H12AffineFastState.Bounded env45668 := by
  intro p hp
  have h : env45668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45667_45668 : H12AffineEnvironment.transform 16 82247 env45667 = env45668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env45667 == env45668) = true)

theorem identity45668 : scanCanonicalize (H12AffineFastState.compose env45668 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45668 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env45669 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82247,2420,1024,32769,4161,98679,32785,54531,349,65,89174,82246,50433,67618,119043,32,256,98679,82182,55041]

theorem envBound45669 : H12AffineFastState.Bounded env45669 := by
  intro p hp
  have h : env45669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45668_45669 : H12AffineEnvironment.transform 12 348 env45668 = env45669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45668 == env45669) = true)

theorem identity45669 : scanCanonicalize (H12AffineFastState.compose env45669 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound45669 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env45670 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54279,38208,2420,1024,32769,4161,21872,32785,54531,349,65,34897,38209,50433,56357,1284,32,256,21872,38145,55041]

theorem envBound45670 : H12AffineFastState.Bounded env45670 := by
  intro p hp
  have h : env45670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45669_45670 : H12AffineEnvironment.transform 15 54279 env45669 = env45670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env45669 == env45670) = true)

theorem identity45670 : scanCanonicalize (H12AffineFastState.compose env45670 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound45670 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env45671 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,262,16449,2420,1024,21760,4161,21872,21776,2,349,65,23888,16448,4096,2340,1284,32,256,21872,16384,512]

theorem envBound45671 : H12AffineFastState.Bounded env45671 := by
  intro p hp
  have h : env45671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45670_45671 : H12AffineEnvironment.transform 14 21761 env45670 = env45671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env45670 == env45671) = true)

theorem identity45671 : scanCanonicalize (H12AffineFastState.compose env45671 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5488) := by decide +kernel

theorem selectedBound45671 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env45672 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5488,113,262,5425,2420,1024,112,4161,0,96,2,349,65,2080,5424,4096,2340,1284,32,256,0,5488,512]

theorem envBound45672 : H12AffineFastState.Bounded env45672 := by
  intro p hp
  have h : env45672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45671_45672 : H12AffineEnvironment.transform 13 5488 env45671 = env45672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5488 env45671 == env45672) = true)

theorem identity45672 : scanCanonicalize (H12AffineFastState.compose env45672 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45672 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env45673 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5408,33,262,5425,2340,1024,32,4113,0,48,2,269,17,2080,5424,4096,2340,1284,32,256,0,5408,512]

theorem envBound45673 : H12AffineFastState.Bounded env45673 := by
  intro p hp
  have h : env45673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45672_45673 : H12AffineEnvironment.transform 5 16 env45672 = env45673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45672 == env45673) = true)

theorem identity45673 : scanCanonicalize (H12AffineFastState.compose env45673 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound45673 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env45674 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2586,268,3898,33,262,3883,2340,1024,32,2571,0,48,2,269,17,2080,3882,2586,2340,1284,32,256,0,3898,512]

theorem envBound45674 : H12AffineFastState.Bounded env45674 := by
  intro p hp
  have h : env45674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45673_45674 : H12AffineEnvironment.transform 11 2586 env45673 = env45674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env45673 == env45674) = true)

theorem identity45674 : scanCanonicalize (H12AffineFastState.compose env45674 (packedSelected [0,1,3,4,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45674 : packedSelected [0,1,3,4,12] rootPS < 2^1333 := by decide +kernel

def env45675 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,2586,268,3866,1,262,3851,2308,1024,0,2571,0,16,2,269,17,2048,3850,2586,2308,1284,0,256,0,3866,512]

theorem envBound45675 : H12AffineFastState.Bounded env45675 := by
  intro p hp
  have h : env45675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45674_45675 : H12AffineEnvironment.transform 4 0 env45674 = env45675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45674 == env45675) = true)

theorem identity45675 : scanCanonicalize (H12AffineFastState.compose env45675 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound45675 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45676 : List Nat := [2,4,8,16,0,16,9,21,512,1024,2048,2586,25,3599,1,19,3614,2065,1024,0,2571,0,16,2,24,17,2048,3615,2586,2065,1041,0,21,0,3599,512]

theorem envBound45676 : H12AffineFastState.Bounded env45676 := by
  intro p hp
  have h : env45676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45675_45676 : H12AffineEnvironment.transform 7 21 env45675 = env45676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env45675 == env45676) = true)

theorem identity45676 : scanCanonicalize (H12AffineFastState.compose env45676 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound45676 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45677 : List Nat := [2,4,8,16,0,16,9,21,512,1024,10,528,25,1541,1,19,1556,27,1024,0,513,0,16,2,24,17,10,1557,528,27,1041,0,21,0,1541,512]

theorem envBound45677 : H12AffineFastState.Bounded env45677 := by
  intro p hp
  have h : env45677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45676_45677 : H12AffineEnvironment.transform 10 10 env45676 = env45677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env45676 == env45677) = true)

theorem identity45677 : scanCanonicalize (H12AffineFastState.compose env45677 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45677 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45678 : List Nat := [2,4,3,16,0,16,2,21,512,1024,1,528,18,1541,1,19,1556,16,1024,0,513,0,16,2,19,17,1,1557,528,16,1041,0,21,0,1541,512]

theorem envBound45678 : H12AffineFastState.Bounded env45678 := by
  intro p hp
  have h : env45678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45677_45678 : H12AffineEnvironment.transform 2 3 env45677 = env45678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45677 == env45678) = true)

theorem identity45678 : scanCanonicalize (H12AffineFastState.compose env45678 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound45678 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45679 : List Nat := [2,4,3,16,0,16,2,21,512,5,1,528,18,512,1,19,529,16,5,0,513,0,16,2,19,17,1,528,528,16,20,0,21,0,512,512]

theorem envBound45679 : H12AffineFastState.Bounded env45679 := by
  intro p hp
  have h : env45679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45678_45679 : H12AffineEnvironment.transform 9 5 env45678 = env45679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env45678 == env45679) = true)

theorem identity45679 : scanCanonicalize (H12AffineFastState.compose env45679 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound45679 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45680 : List Nat := [2,4,3,16,0,16,2,21,6,5,1,22,18,6,1,19,23,16,5,0,7,0,16,2,19,17,1,22,22,16,20,0,21,0,6,6]

theorem envBound45680 : H12AffineFastState.Bounded env45680 := by
  intro p hp
  have h : env45680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45679_45680 : H12AffineEnvironment.transform 8 6 env45679 = env45680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env45679 == env45680) = true)

theorem identity45680 : scanCanonicalize (H12AffineFastState.compose env45680 (packedSelected [0,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45680 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45681 : List Nat := [2,2,3,16,0,16,2,19,0,3,1,16,18,0,1,19,17,16,3,0,1,0,16,2,19,17,1,16,16,16,18,0,19,0,0,0]

theorem envBound45681 : H12AffineFastState.Bounded env45681 := by
  intro p hp
  have h : env45681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45680_45681 : H12AffineEnvironment.transform 1 2 env45680 = env45681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45680 == env45681) = true)

theorem identity45681 : scanCanonicalize (H12AffineFastState.compose env45681 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound45681 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45682 : List Nat := [2,2,3,2,0,2,2,1,0,3,1,2,0,0,1,1,3,2,3,0,1,0,2,2,1,3,1,2,2,2,0,0,1,0,0,0]

theorem envBound45682 : H12AffineFastState.Bounded env45682 := by
  intro p hp
  have h : env45682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45681_45682 : H12AffineEnvironment.transform 3 2 env45681 = env45682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env45681 == env45682) = true)

theorem identity45682 : scanCanonicalize (H12AffineFastState.compose env45682 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45682 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env45683 : List Nat := [1,1,0,1,0,1,1,1,0,0,1,1,0,0,1,1,0,1,0,0,1,0,1,1,1,0,1,1,1,1,0,0,1,0,0,0]

theorem envBound45683 : H12AffineFastState.Bounded env45683 := by
  intro p hp
  have h : env45683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45682_45683 : H12AffineEnvironment.transform 0 1 env45682 = env45683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45682 == env45683) = true)

def env45684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,509986,498993,8328,65,349610,2496956,2596211,67618,119042,2373704,256,2199998,2191386,63189]

theorem envBound45684 : H12AffineFastState.Bounded env45684 := by
  intro p hp
  have h : env45684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45595_45684 : H12AffineEnvironment.transform 23 498993 env45595 = env45684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498993 env45595 == env45684) = true)

def env45685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,509986,498993,8328,65,349610,395772,494899,67618,119042,272392,256,98814,90202,63189]

theorem envBound45685 : H12AffineFastState.Bounded env45685 := by
  intro p hp
  have h : env45685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45684_45685 : H12AffineEnvironment.transform 20 4160 env45684 = env45685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env45684 == env45685) = true)

theorem identity45685 : scanCanonicalize (H12AffineFastState.compose env45685 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound45685 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4160,144493,474358,485861,8328,65,349610,395772,489959,67618,75222,272392,256,95530,90202,513]

theorem envBound45686 : H12AffineFastState.Bounded env45686 := by
  intro p hp
  have h : env45686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45685_45686 : H12AffineEnvironment.transform 14 29908 env45685 = env45686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env45685 == env45686) = true)

def env45687 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4160,144493,474238,485741,8192,65,349474,395636,489839,67618,75102,272392,256,95530,90202,513]

theorem envBound45687 : H12AffineFastState.Bounded env45687 := by
  intro p hp
  have h : env45687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45686_45687 : H12AffineEnvironment.transform 6 8 env45686 = env45687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45686 == env45687) = true)

theorem identity45687 : scanCanonicalize (H12AffineFastState.compose env45687 (packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound45687 : packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS < 2^1333 := by decide +kernel

def env45688 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32040,1024,29789,4160,144493,213334,201797,8192,65,75786,160860,197703,67618,75102,21792,256,95530,90202,513]

theorem envBound45688 : H12AffineFastState.Bounded env45688 := by
  intro p hp
  have h : env45688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45687_45688 : H12AffineEnvironment.transform 17 32040 env45687 = env45688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env45687 == env45688) = true)

theorem identity45688 : scanCanonicalize (H12AffineFastState.compose env45688 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound45688 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env45689 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21590,131072,32040,1024,29789,4160,144493,136448,147475,8192,65,31836,160860,151569,23668,28936,21792,256,8572,13324,513]

theorem envBound45689 : H12AffineFastState.Bounded env45689 := by
  intro p hp
  have h : env45689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45688_45689 : H12AffineEnvironment.transform 15 21590 env45688 = env45689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env45688 == env45689) = true)

theorem identity45689 : scanCanonicalize (H12AffineFastState.compose env45689 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45689 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env45690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,21590,131072,23669,1024,21760,4160,136496,136448,147475,349,65,23809,152833,151569,23668,20565,21792,256,33,5457,513]

theorem envBound45690 : H12AffineFastState.Bounded env45690 := by
  intro p hp
  have h : env45690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45689_45690 : H12AffineEnvironment.transform 12 349 env45689 = env45690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45689 == env45690) = true)

theorem identity45690 : scanCanonicalize (H12AffineFastState.compose env45690 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound45690 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env45691 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,21590,5392,23669,1024,21760,4160,32,16,21763,349,65,23809,16401,17665,23668,20565,21792,256,33,5457,513]

theorem envBound45691 : H12AffineFastState.Bounded env45691 := by
  intro p hp
  have h : env45691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45690_45691 : H12AffineEnvironment.transform 16 5392 env45690 = env45691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env45690 == env45691) = true)

theorem identity45691 : scanCanonicalize (H12AffineFastState.compose env45691 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45691 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45692 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,349,16384,21761,21590,5392,23637,1024,21760,4160,0,16,21763,349,65,23809,16401,17665,23636,20565,21760,256,1,5457,513]

theorem envBound45692 : H12AffineFastState.Bounded env45692 := by
  intro p hp
  have h : env45692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45691_45692 : H12AffineEnvironment.transform 4 0 env45691 = env45692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45691 == env45692) = true)

theorem identity45692 : scanCanonicalize (H12AffineFastState.compose env45692 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound45692 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45693 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,349,5376,1,342,5392,2389,1024,0,4160,0,16,3,349,65,2049,5393,4097,2388,1365,0,256,1,5457,513]

theorem envBound45693 : H12AffineFastState.Bounded env45693 := by
  intro p hp
  have h : env45693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45692_45693 : H12AffineEnvironment.transform 13 5376 env45692 = env45693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45692 == env45693) = true)

theorem identity45693 : scanCanonicalize (H12AffineFastState.compose env45693 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 833) := by decide +kernel

theorem selectedBound45693 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45694 : List Nat := [2,4,8,16,0,64,8,256,512,833,2048,4096,349,4673,1,342,4689,2389,833,0,4160,0,16,3,349,65,2049,4688,4097,2388,532,0,256,1,4624,513]

theorem envBound45694 : H12AffineFastState.Bounded env45694 := by
  intro p hp
  have h : env45694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45693_45694 : H12AffineEnvironment.transform 9 833 env45693 = env45694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 833 env45693 == env45694) = true)

theorem identity45694 : scanCanonicalize (H12AffineFastState.compose env45694 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45694 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45695 : List Nat := [2,4,8,16,0,17,8,256,512,784,2048,4096,268,4624,1,263,4608,2308,784,0,4113,0,16,3,268,16,2049,4609,4097,2309,532,0,256,1,4624,513]

theorem envBound45695 : H12AffineFastState.Bounded env45695 := by
  intro p hp
  have h : env45695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45694_45695 : H12AffineEnvironment.transform 5 17 env45694 = env45695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45694 == env45695) = true)

theorem identity45695 : scanCanonicalize (H12AffineFastState.compose env45695 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound45695 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45696 : List Nat := [2,4,8,16,0,17,8,256,512,784,2048,260,268,788,1,263,772,2308,784,0,277,0,16,3,268,16,2049,773,261,2309,532,0,256,1,788,513]

theorem envBound45696 : H12AffineFastState.Bounded env45696 := by
  intro p hp
  have h : env45696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45695_45696 : H12AffineEnvironment.transform 11 260 env45695 = env45696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env45695 == env45696) = true)

theorem identity45696 : scanCanonicalize (H12AffineFastState.compose env45696 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound45696 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45697 : List Nat := [2,4,8,16,0,17,8,256,512,784,260,260,268,788,1,263,772,0,784,0,277,0,16,3,268,16,261,773,261,1,532,0,256,1,788,513]

theorem envBound45697 : H12AffineFastState.Bounded env45697 := by
  intro p hp
  have h : env45697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45696_45697 : H12AffineEnvironment.transform 10 260 env45696 = env45697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env45696 == env45697) = true)

theorem identity45697 : scanCanonicalize (H12AffineFastState.compose env45697 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45697 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45698 : List Nat := [2,4,8,0,0,1,8,256,512,768,260,260,268,772,1,263,772,0,768,0,261,0,0,3,268,0,261,773,261,1,516,0,256,1,772,513]

theorem envBound45698 : H12AffineFastState.Bounded env45698 := by
  intro p hp
  have h : env45698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45697_45698 : H12AffineEnvironment.transform 3 0 env45697 = env45698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45697 == env45698) = true)

theorem identity45698 : scanCanonicalize (H12AffineFastState.compose env45698 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound45698 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45699 : List Nat := [2,4,8,0,0,1,8,256,261,5,260,260,268,1,1,263,1,0,5,0,261,0,0,3,268,0,261,0,261,1,257,0,256,1,1,260]

theorem envBound45699 : H12AffineFastState.Bounded env45699 := by
  intro p hp
  have h : env45699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45698_45699 : H12AffineEnvironment.transform 8 261 env45698 = env45699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env45698 == env45699) = true)

theorem identity45699 : scanCanonicalize (H12AffineFastState.compose env45699 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound45699 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45700 : List Nat := [2,4,8,0,0,1,8,4,1,5,0,0,8,1,1,3,1,0,5,0,1,0,0,3,8,0,1,0,1,1,5,0,4,1,1,0]

theorem envBound45700 : H12AffineFastState.Bounded env45700 := by
  intro p hp
  have h : env45700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45699_45700 : H12AffineEnvironment.transform 7 4 env45699 = env45700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env45699 == env45700) = true)

theorem identity45700 : scanCanonicalize (H12AffineFastState.compose env45700 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45700 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45701 : List Nat := [2,4,3,0,0,1,3,4,1,5,0,0,3,1,1,3,1,0,5,0,1,0,0,3,3,0,1,0,1,1,5,0,4,1,1,0]

theorem envBound45701 : H12AffineFastState.Bounded env45701 := by
  intro p hp
  have h : env45701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45700_45701 : H12AffineEnvironment.transform 2 3 env45700 = env45701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45700 == env45701) = true)

def env45702 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4160,144493,474239,485740,8193,65,349475,395637,489838,67618,75103,272392,256,95530,90202,513]

theorem envBound45702 : H12AffineFastState.Bounded env45702 := by
  intro p hp
  have h : env45702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45686_45702 : H12AffineEnvironment.transform 6 9 env45686 = env45702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45686 == env45702) = true)

theorem identity45702 : scanCanonicalize (H12AffineFastState.compose env45702 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound45702 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env45703 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1024,29788,4160,87158,285796,264567,8193,65,349475,354670,268661,67618,75103,272392,256,95530,90202,513]

theorem envBound45703 : H12AffineFastState.Bounded env45703 := by
  intro p hp
  have h : env45703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45702_45703 : H12AffineEnvironment.transform 16 90139 env45702 = env45703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env45702 == env45703) = true)

theorem identity45703 : scanCanonicalize (H12AffineFastState.compose env45703 (packedSelected [0,4,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 96622) := by decide +kernel

theorem selectedBound45703 : packedSelected [0,4,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env45704 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,96622,1024,29788,4160,87158,75018,94233,8193,65,11341,4096,90139,67618,75103,86374,256,95530,90202,513]

theorem envBound45704 : H12AffineFastState.Bounded env45704 := by
  intro p hp
  have h : env45704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45703_45704 : H12AffineEnvironment.transform 17 96622 env45703 = env45704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96622 env45703 == env45704) = true)

theorem identity45704 : scanCanonicalize (H12AffineFastState.compose env45704 (packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound45704 : packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS < 2^1333 := by decide +kernel

def env45705 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,1047,25612,32121,1024,29788,4160,20577,8477,29710,8193,65,11341,4096,25612,3125,8520,21873,256,28989,25677,513]

theorem envBound45705 : H12AffineFastState.Bounded env45705 := by
  intro p hp
  have h : env45705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45704_45705 : H12AffineEnvironment.transform 15 1047 env45704 = env45705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env45704 == env45705) = true)

theorem identity45705 : scanCanonicalize (H12AffineFastState.compose env45705 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound45705 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env45706 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8461,1047,12636,10281,1024,8460,4160,1329,8477,8542,8193,65,11341,4096,12636,3125,8520,33,256,9325,12573,513]

theorem envBound45706 : H12AffineFastState.Bounded env45706 := by
  intro p hp
  have h : env45706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45705_45706 : H12AffineEnvironment.transform 13 5456 env45705 = env45706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env45705 == env45706) = true)

theorem identity45706 : scanCanonicalize (H12AffineFastState.compose env45706 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound45706 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env45707 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7180,5456,7425,1047,3408,5157,1024,7424,4160,1329,7441,7506,7181,65,4161,4096,3408,3125,7492,33,256,6241,3345,513]

theorem envBound45707 : H12AffineFastState.Bounded env45707 := by
  intro p hp
  have h : env45707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45706_45707 : H12AffineEnvironment.transform 12 7180 env45706 = env45707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env45706 == env45707) = true)

theorem identity45707 : scanCanonicalize (H12AffineFastState.compose env45707 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound45707 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env45708 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,348,2048,81,1047,3408,2421,1024,80,3344,1329,65,2,349,65,3345,3408,3408,3125,20,33,256,1329,3345,513]

theorem envBound45708 : H12AffineFastState.Bounded env45708 := by
  intro p hp
  have h : env45708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45707_45708 : H12AffineEnvironment.transform 11 3408 env45707 = env45708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env45707 == env45708) = true)

theorem identity45708 : scanCanonicalize (H12AffineFastState.compose env45708 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound45708 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env45709 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2112,348,2048,81,263,2112,2421,272,80,2048,33,65,2,349,65,2049,2112,2112,2341,20,33,256,33,2049,513]

theorem envBound45709 : H12AffineFastState.Bounded env45709 := by
  intro p hp
  have h : env45709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45708_45709 : H12AffineEnvironment.transform 9 272 env45708 = env45709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env45708 == env45709) = true)

theorem identity45709 : scanCanonicalize (H12AffineFastState.compose env45709 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45709 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45710 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,2065,269,2048,0,263,2065,2340,272,1,2048,33,16,2,268,16,2049,2065,2065,2341,20,33,256,33,2049,513]

theorem envBound45710 : H12AffineFastState.Bounded env45710 := by
  intro p hp
  have h : env45710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45709_45710 : H12AffineEnvironment.transform 5 17 env45709 = env45710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45709 == env45710) = true)

theorem identity45710 : scanCanonicalize (H12AffineFastState.compose env45710 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound45710 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45711 : List Nat := [2,4,8,16,32,17,9,256,512,272,261,276,269,261,0,263,276,33,272,1,261,33,16,2,268,16,260,276,276,32,20,33,256,33,260,513]

theorem envBound45711 : H12AffineFastState.Bounded env45711 := by
  intro p hp
  have h : env45711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45710_45711 : H12AffineEnvironment.transform 10 261 env45710 = env45711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env45710 == env45711) = true)

theorem identity45711 : scanCanonicalize (H12AffineFastState.compose env45711 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45711 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45712 : List Nat := [2,4,8,16,32,17,9,37,512,53,32,49,40,32,0,34,49,33,53,1,32,33,16,2,41,16,33,49,49,32,20,33,37,33,33,513]

theorem envBound45712 : H12AffineFastState.Bounded env45712 := by
  intro p hp
  have h : env45712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45711_45712 : H12AffineEnvironment.transform 7 37 env45711 = env45712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45711 == env45712) = true)

theorem identity45712 : scanCanonicalize (H12AffineFastState.compose env45712 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound45712 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45713 : List Nat := [2,4,8,16,32,17,9,37,33,53,32,49,40,32,0,34,49,33,53,1,32,33,16,2,41,16,33,49,49,32,20,33,37,33,33,32]

theorem envBound45713 : H12AffineFastState.Bounded env45713 := by
  intro p hp
  have h : env45713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45712_45713 : H12AffineEnvironment.transform 8 33 env45712 = env45713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env45712 == env45713) = true)

theorem identity45713 : scanCanonicalize (H12AffineFastState.compose env45713 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45713 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45714 : List Nat := [2,4,8,0,32,1,9,37,33,37,32,33,40,32,0,34,33,33,37,1,32,33,0,2,41,0,33,33,33,32,4,33,37,33,33,32]

theorem envBound45714 : H12AffineFastState.Bounded env45714 := by
  intro p hp
  have h : env45714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45713_45714 : H12AffineEnvironment.transform 3 0 env45713 = env45714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45713 == env45714) = true)

theorem identity45714 : scanCanonicalize (H12AffineFastState.compose env45714 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45714 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env45715 : List Nat := [2,4,8,0,0,1,9,5,1,5,0,1,8,0,0,2,1,1,5,1,0,1,0,2,9,0,1,1,1,0,4,1,5,1,1,0]

theorem envBound45715 : H12AffineFastState.Bounded env45715 := by
  intro p hp
  have h : env45715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45714_45715 : H12AffineEnvironment.transform 4 0 env45714 = env45715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45714 == env45715) = true)

def env45716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,509986,498993,8328,65,349610,395773,494898,67618,119042,272393,256,98815,90203,63189]

theorem envBound45716 : H12AffineFastState.Bounded env45716 := by
  intro p hp
  have h : env45716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45684_45716 : H12AffineEnvironment.transform 20 4161 env45684 = env45716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env45684 == env45716) = true)

theorem identity45716 : scanCanonicalize (H12AffineFastState.compose env45716 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138476) := by decide +kernel

theorem selectedBound45716 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138476,1024,32769,4161,180409,120014,98781,8328,65,215366,5393,102878,67618,119042,144613,256,98815,90203,63189]

theorem envBound45717 : H12AffineFastState.Bounded env45717 := by
  intro p hp
  have h : env45717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45716_45717 : H12AffineEnvironment.transform 17 138476 env45716 = env45717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138476 env45716 == env45717) = true)

def env45718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10400,1024,32769,4161,62709,120014,98781,8328,65,97546,5393,102878,67618,119042,169,256,98815,90203,63189]

theorem envBound45718 : H12AffineFastState.Bounded env45718 := by
  intro p hp
  have h : env45718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45717_45718 : H12AffineEnvironment.transform 16 13388 env45717 = env45718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env45717 == env45718) = true)

theorem identity45718 : scanCanonicalize (H12AffineFastState.compose env45718 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound45718 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env45719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,13388,10400,1024,32769,4161,62709,16,21763,8328,65,43476,5393,17664,56572,1500,169,256,21793,46213,63189]

theorem envBound45719 : H12AffineFastState.Bounded env45719 := by
  intro p hp
  have h : env45719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45718_45719 : H12AffineEnvironment.transform 15 54494 env45718 = env45719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env45718 == env45719) = true)

theorem identity45719 : scanCanonicalize (H12AffineFastState.compose env45719 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound45719 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env45720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,13388,10400,1024,32769,4161,41460,16,2,8328,65,43476,5393,4097,35325,1500,169,256,32,46213,41940]

theorem envBound45720 : H12AffineFastState.Bounded env45720 := by
  intro p hp
  have h : env45720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45719_45720 : H12AffineEnvironment.transform 13 5377 env45719 = env45720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45719 == env45720) = true)

theorem identity45720 : scanCanonicalize (H12AffineFastState.compose env45720 (packedSelected [0,1,2,4,7,8,11,12,14,15,17,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8493) := by decide +kernel

theorem selectedBound45720 : packedSelected [0,1,2,4,7,8,11,12,14,15,17,18,19,22] rootPS < 2^1333 := by decide +kernel

def env45721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8493,8434,13388,10400,1024,8492,4161,217,16,2,8328,65,2297,5393,4097,10448,1500,169,256,32,5544,761]

theorem envBound45721 : H12AffineFastState.Bounded env45721 := by
  intro p hp
  have h : env45721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45720_45721 : H12AffineEnvironment.transform 14 8493 env45720 = env45721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8493 env45720 == env45721) = true)

theorem identity45721 : scanCanonicalize (H12AffineFastState.compose env45721 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound45721 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,248,295,5529,2421,1024,249,4161,217,16,2,349,65,2297,5393,4097,2309,1500,169,256,32,5544,761]

theorem envBound45722 : H12AffineFastState.Bounded env45722 := by
  intro p hp
  have h : env45722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45721_45722 : H12AffineEnvironment.transform 12 469 env45721 = env45722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env45721 == env45722) = true)

theorem identity45722 : scanCanonicalize (H12AffineFastState.compose env45722 (packedSelected [2,3,5,10,11,12,14,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound45722 : packedSelected [2,3,5,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env45723 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,301,5377,0,295,5473,2421,1024,1,4161,33,16,2,349,65,2049,5393,4097,2309,1316,81,256,32,5456,513]

theorem envBound45723 : H12AffineFastState.Bounded env45723 := by
  intro p hp
  have h : env45723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45722_45723 : H12AffineEnvironment.transform 6 120 env45722 = env45723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env45722 == env45723) = true)

theorem identity45723 : scanCanonicalize (H12AffineFastState.compose env45723 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45723 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45724 : List Nat := [2,4,8,16,0,64,88,256,512,1024,2048,4096,269,5377,0,263,5441,2389,1024,1,4161,1,16,2,349,65,2049,5393,4097,2309,1284,81,256,0,5456,513]

theorem envBound45724 : H12AffineFastState.Bounded env45724 := by
  intro p hp
  have h : env45724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45723_45724 : H12AffineEnvironment.transform 4 0 env45723 = env45724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45723 == env45724) = true)

theorem identity45724 : scanCanonicalize (H12AffineFastState.compose env45724 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1360) := by decide +kernel

theorem selectedBound45724 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env45725 : List Nat := [2,4,8,16,0,64,88,256,512,1024,1360,4096,269,5377,0,263,5441,1029,1024,1,4161,1,16,2,349,65,1361,5393,4097,1109,1284,81,256,0,5456,513]

theorem envBound45725 : H12AffineFastState.Bounded env45725 := by
  intro p hp
  have h : env45725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45724_45725 : H12AffineEnvironment.transform 10 1360 env45724 = env45725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1360 env45724 == env45725) = true)

theorem identity45725 : scanCanonicalize (H12AffineFastState.compose env45725 (packedSelected [0,1,2,4,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1540) := by decide +kernel

theorem selectedBound45725 : packedSelected [0,1,2,4,8,10] rootPS < 2^1333 := by decide +kernel

def env45726 : List Nat := [2,4,8,16,0,64,88,256,512,1024,1360,1540,269,773,0,263,837,1029,1024,1,1605,1,16,2,349,65,1361,789,1541,1109,1284,81,256,0,852,513]

theorem envBound45726 : H12AffineFastState.Bounded env45726 := by
  intro p hp
  have h : env45726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45725_45726 : H12AffineEnvironment.transform 11 1540 env45725 = env45726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1540 env45725 == env45726) = true)

theorem identity45726 : scanCanonicalize (H12AffineFastState.compose env45726 (packedSelected [0,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound45726 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env45727 : List Nat := [2,4,8,16,0,64,88,256,512,4,340,512,269,773,0,263,837,1,4,1,577,1,16,2,349,65,341,789,513,81,256,81,256,0,852,513]

theorem envBound45727 : H12AffineFastState.Bounded env45727 := by
  intro p hp
  have h : env45727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45726_45727 : H12AffineEnvironment.transform 9 4 env45726 = env45727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env45726 == env45727) = true)

theorem identity45727 : scanCanonicalize (H12AffineFastState.compose env45727 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound45727 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45728 : List Nat := [2,4,8,16,0,64,88,256,64,4,340,64,269,325,0,263,261,1,4,1,1,1,16,2,349,65,341,341,65,81,256,81,256,0,276,65]

theorem envBound45728 : H12AffineFastState.Bounded env45728 := by
  intro p hp
  have h : env45728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45727_45728 : H12AffineEnvironment.transform 8 64 env45727 = env45728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env45727 == env45728) = true)

theorem identity45728 : scanCanonicalize (H12AffineFastState.compose env45728 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound45728 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45729 : List Nat := [2,4,8,16,0,64,88,68,64,4,16,64,73,1,0,67,65,1,4,1,1,1,16,2,25,65,17,17,65,81,68,81,68,0,80,65]

theorem envBound45729 : H12AffineFastState.Bounded env45729 := by
  intro p hp
  have h : env45729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45728_45729 : H12AffineEnvironment.transform 7 68 env45728 = env45729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env45728 == env45729) = true)

theorem identity45729 : scanCanonicalize (H12AffineFastState.compose env45729 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45729 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env45730 : List Nat := [2,4,8,16,0,16,8,20,16,4,16,16,25,1,0,19,17,1,4,1,1,1,16,2,25,17,17,17,17,1,20,1,20,0,0,17]

theorem envBound45730 : H12AffineFastState.Bounded env45730 := by
  intro p hp
  have h : env45730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45729_45730 : H12AffineEnvironment.transform 5 16 env45729 = env45730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45729 == env45730) = true)

theorem identity45730 : scanCanonicalize (H12AffineFastState.compose env45730 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound45730 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45731 : List Nat := [2,0,8,16,0,16,8,16,16,0,16,16,25,1,0,19,17,1,0,1,1,1,16,2,25,17,17,17,17,1,16,1,16,0,0,17]

theorem envBound45731 : H12AffineFastState.Bounded env45731 := by
  intro p hp
  have h : env45731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45730_45731 : H12AffineEnvironment.transform 1 0 env45730 = env45731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env45730 == env45731) = true)

theorem identity45731 : scanCanonicalize (H12AffineFastState.compose env45731 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45731 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45732 : List Nat := [1,0,8,16,0,16,8,16,16,0,16,16,25,1,0,16,17,1,0,1,1,1,16,1,25,17,17,17,17,1,16,1,16,0,0,17]

theorem envBound45732 : H12AffineFastState.Bounded env45732 := by
  intro p hp
  have h : env45732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45731_45732 : H12AffineEnvironment.transform 0 1 env45731 = env45732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45731 == env45732) = true)

def env45733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10401,1024,32769,4161,62708,120014,98781,8328,65,97547,5393,102878,67618,119042,168,256,98815,90203,63189]

theorem envBound45733 : H12AffineFastState.Bounded env45733 := by
  intro p hp
  have h : env45733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45717_45733 : H12AffineEnvironment.transform 16 13389 env45717 = env45733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env45717 == env45733) = true)

theorem identity45733 : scanCanonicalize (H12AffineFastState.compose env45733 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(14+1) ^^^ 30072) := by decide +kernel

theorem selectedBound45733 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env45734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30072,65536,13389,10401,1024,30073,4161,396,74166,95397,8328,65,97547,5393,91302,67618,74874,168,256,95367,90203,941]

theorem envBound45734 : H12AffineFastState.Bounded env45734 := by
  intro p hp
  have h : env45734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45733_45734 : H12AffineEnvironment.transform 14 30072 env45733 = env45734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30072 env45733 == env45734) = true)

theorem identity45734 : scanCanonicalize (H12AffineFastState.compose env45734 (packedSelected [1,4,5,9,10,12,14,15,18,19,20,23,24,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 250) := by decide +kernel

theorem selectedBound45734 : packedSelected [1,4,5,9,10,12,14,15,18,19,20,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env45735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30072,250,13389,10401,1024,30073,4161,396,8524,29791,8328,65,32241,5393,25692,2264,9344,168,256,29821,24737,941]

theorem envBound45735 : H12AffineFastState.Bounded env45735 := by
  intro p hp
  have h : env45735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45734_45735 : H12AffineEnvironment.transform 15 250 env45734 = env45735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 250 env45734 == env45735) = true)

theorem identity45735 : scanCanonicalize (H12AffineFastState.compose env45735 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound45735 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env45736 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,29909,250,13389,10401,1024,29908,4161,33,8417,29791,8328,65,31836,5308,25692,2264,9344,168,173,29821,24737,512]

theorem envBound45736 : H12AffineFastState.Bounded env45736 := by
  intro p hp
  have h : env45736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45735_45736 : H12AffineEnvironment.transform 7 173 env45735 = env45736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env45735 == env45736) = true)

theorem identity45736 : scanCanonicalize (H12AffineFastState.compose env45736 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound45736 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env45737 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,5124,8401,250,13389,10401,1024,8400,4161,33,8417,8283,8328,65,10328,5308,12376,2264,9344,168,173,8313,13477,512]

theorem envBound45737 : H12AffineFastState.Bounded env45737 := by
  intro p hp
  have h : env45737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45736_45737 : H12AffineEnvironment.transform 13 5124 env45736 = env45737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env45736 == env45737) = true)

def env45738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound45738 : H12AffineFastState.Bounded env45738 := by
  intro p hp
  have h : env45738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45497_45738 : H12AffineEnvironment.transform 18 1025 env45497 = env45738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env45497 == env45738) = true)

theorem identity45738 : scanCanonicalize (H12AffineFastState.compose env45738 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 272546) := by decide +kernel

theorem selectedBound45738 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env45739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,272546,8328,65,12839075,2468910,10507601,8830977,8760499,6638946,257,10873870,10816939,8686437]

theorem envBound45739 : H12AffineFastState.Bounded env45739 := by
  intro p hp
  have h : env45739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45738_45739 : H12AffineEnvironment.transform 23 272546 env45738 = env45739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272546 env45738 == env45739) = true)

def env45740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147592,272546,8328,65,4302891,2468910,2233817,295049,519227,6638946,257,2600070,2575651,445421]

theorem envBound45740 : H12AffineFastState.Bounded env45740 := by
  intro p hp
  have h : env45740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45739_45740 : H12AffineEnvironment.transform 22 147592 env45739 = env45740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env45739 == env45740) = true)

def env45741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,152,272546,8328,65,4302891,2468910,2119113,295049,371755,6638946,257,2485398,2428211,297981]

theorem envBound45741 : H12AffineFastState.Bounded env45741 := by
  intro p hp
  have h : env45741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45740_45741 : H12AffineEnvironment.transform 16 16400 env45740 = env45741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env45740 == env45741) = true)

def env45742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,16,272426,8192,65,4302891,2468910,2118977,294913,371755,6638946,257,2485278,2428211,297845]

theorem envBound45742 : H12AffineFastState.Bounded env45742 := by
  intro p hp
  have h : env45742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45741_45742 : H12AffineEnvironment.transform 6 8 env45741 = env45742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45741 == env45742) = true)

theorem identity45742 : scanCanonicalize (H12AffineFastState.compose env45742 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound45742 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env45743 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,16,41310,8192,65,4302891,2172250,2118977,2421,75103,6407190,257,2188650,2196551,513]

theorem envBound45743 : H12AffineFastState.Bounded env45743 := by
  intro p hp
  have h : env45743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45742_45743 : H12AffineEnvironment.transform 17 35188 env45742 = env45743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env45742 == env45743) = true)

theorem identity45743 : scanCanonicalize (H12AffineFastState.compose env45743 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound45743 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env45744 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35188,1025,32769,2097152,4194304,16,41310,8192,65,4229152,2098513,2118977,2421,1364,6349853,257,2114913,2139212,513]

theorem envBound45744 : H12AffineFastState.Bounded env45744 := by
  intro p hp
  have h : env45744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45743_45744 : H12AffineEnvironment.transform 15 8203 env45743 = env45744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env45743 == env45744) = true)

theorem identity45744 : scanCanonicalize (H12AffineFastState.compose env45744 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound45744 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45745 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35188,1025,32769,2097152,41341,16,41310,8192,65,10589,2098513,2118977,2421,1364,2114912,257,2114913,2139212,513]

theorem envBound45745 : H12AffineFastState.Bounded env45745 := by
  intro p hp
  have h : env45745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45744_45745 : H12AffineEnvironment.transform 21 41341 env45744 = env45745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env45744 == env45745) = true)

theorem identity45745 : scanCanonicalize (H12AffineFastState.compose env45745 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 38145) := by decide +kernel

theorem selectedBound45745 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35188,1025,32769,38145,41341,16,41310,8192,65,10589,36944,49216,2421,1364,53345,257,53344,12621,513]

theorem envBound45746 : H12AffineFastState.Bounded env45746 := by
  intro p hp
  have h : env45746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45745_45746 : H12AffineEnvironment.transform 20 38145 env45745 = env45746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 38145 env45745 == env45746) = true)

theorem identity45746 : scanCanonicalize (H12AffineFastState.compose env45746 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound45746 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env45747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8203,16400,30777,1025,29004,25676,20528,16,20499,8192,65,10589,24861,12557,2421,1364,8492,257,8493,12621,513]

theorem envBound45747 : H12AffineFastState.Bounded env45747 := by
  intro p hp
  have h : env45747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45746_45747 : H12AffineEnvironment.transform 14 29005 env45746 = env45747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env45746 == env45747) = true)

theorem identity45747 : scanCanonicalize (H12AffineFastState.compose env45747 (packedSelected [0,1,2,3,4,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound45747 : packedSelected [0,1,2,3,4,10,11,15] rootPS < 2^1333 := by decide +kernel

def env45748 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,16384,29005,8203,16400,30777,101,29004,24616,20528,16,20499,8192,65,10589,24861,12557,2421,304,8492,257,8493,12621,513]

theorem envBound45748 : H12AffineFastState.Bounded env45748 := by
  intro p hp
  have h : env45748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45747_45748 : H12AffineEnvironment.transform 9 100 env45747 = env45748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env45747 == env45748) = true)

theorem identity45748 : scanCanonicalize (H12AffineFastState.compose env45748 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 10589) := by decide +kernel

theorem selectedBound45748 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env45749 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,10589,6160,8203,10573,4452,101,6161,2421,14701,16,14670,8192,65,10589,2112,12557,2421,304,8492,257,8493,12621,513]

theorem envBound45749 : H12AffineFastState.Bounded env45749 := by
  intro p hp
  have h : env45749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45748_45749 : H12AffineEnvironment.transform 13 10589 env45748 = env45749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10589 env45748 == env45749) = true)

def env45750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,17,272427,8193,65,4302891,2468910,2118976,294912,371755,6638946,257,2485279,2428211,297844]

theorem envBound45750 : H12AffineFastState.Bounded env45750 := by
  intro p hp
  have h : env45750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45741_45750 : H12AffineEnvironment.transform 6 9 env45741 = env45750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45741 == env45750) = true)

theorem identity45750 : scanCanonicalize (H12AffineFastState.compose env45750 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound45750 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env45751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,17,41310,8193,65,4302891,2172251,2118976,2421,75102,6407191,257,2188650,2196550,513]

theorem envBound45751 : H12AffineFastState.Bounded env45751 := by
  intro p hp
  have h : env45751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45750_45751 : H12AffineEnvironment.transform 17 35189 env45750 = env45751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env45750 == env45751) = true)

theorem identity45751 : scanCanonicalize (H12AffineFastState.compose env45751 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound45751 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env45752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,115734,4194304,17,41310,8193,65,4302891,57677,102742,2421,75102,4194305,257,41340,16464,513]

theorem envBound45752 : H12AffineFastState.Bounded env45752 := by
  intro p hp
  have h : env45752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45751_45752 : H12AffineEnvironment.transform 20 115734 env45751 = env45752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env45751 == env45752) = true)

theorem identity45752 : scanCanonicalize (H12AffineFastState.compose env45752 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound45752 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env45753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1025,8540,91467,4194304,17,3,8193,65,4262262,16400,77835,2421,75102,4194305,257,33,16464,513]

theorem envBound45753 : H12AffineFastState.Bounded env45753 := by
  intro p hp
  have h : env45753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45752_45753 : H12AffineEnvironment.transform 14 8541 env45752 = env45753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env45752 == env45753) = true)

theorem identity45753 : scanCanonicalize (H12AffineFastState.compose env45753 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45753 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1025,8540,17729,4194304,17,3,8193,65,4204924,16400,4097,2421,1364,4194305,257,33,16464,513]

theorem envBound45754 : H12AffineFastState.Bounded env45754 := by
  intro p hp
  have h : env45754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45753_45754 : H12AffineEnvironment.transform 15 8202 env45753 = env45754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45753 == env45754) = true)

theorem identity45754 : scanCanonicalize (H12AffineFastState.compose env45754 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45754 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45755 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,8202,16400,10280,1025,8461,17680,4194304,17,3,8193,16,4204845,16400,4097,2340,1285,4194305,257,33,16385,513]

theorem envBound45755 : H12AffineFastState.Bounded env45755 := by
  intro p hp
  have h : env45755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45754_45755 : H12AffineEnvironment.transform 5 17 env45754 = env45755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45754 == env45755) = true)

theorem identity45755 : scanCanonicalize (H12AffineFastState.compose env45755 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 15366) := by decide +kernel

theorem selectedBound45755 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env45756 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,15366,8460,8202,15382,10280,1025,8461,14614,4194304,17,3,8193,16,4204845,15382,4097,2340,1285,4194305,257,33,15367,513]

theorem envBound45756 : H12AffineFastState.Bounded env45756 := by
  intro p hp
  have h : env45756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45755_45756 : H12AffineEnvironment.transform 13 15366 env45755 = env45756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15366 env45755 == env45756) = true)

theorem identity45756 : scanCanonicalize (H12AffineFastState.compose env45756 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45756 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45757 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,7435,1,263,7451,2341,1025,0,6171,4194304,17,3,268,16,4196384,7451,4097,2340,1285,4194305,257,33,7434,513]

theorem envBound45757 : H12AffineFastState.Bounded env45757 := by
  intro p hp
  have h : env45757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45756_45757 : H12AffineEnvironment.transform 12 269 env45756 = env45757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45756 == env45757) = true)

theorem identity45757 : scanCanonicalize (H12AffineFastState.compose env45757 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 5141) := by decide +kernel

theorem selectedBound45757 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45758 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,7435,1,263,7451,2341,1025,0,6171,5141,17,3,268,16,7221,7451,4097,2340,1285,5140,257,33,7434,513]

theorem envBound45758 : H12AffineFastState.Bounded env45758 := by
  intro p hp
  have h : env45758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45757_45758 : H12AffineEnvironment.transform 21 5141 env45757 = env45758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5141 env45757 == env45758) = true)

theorem identity45758 : scanCanonicalize (H12AffineFastState.compose env45758 (packedSelected [1,3,12] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound45758 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env45759 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1077,269,2366,1,263,2350,2341,1025,0,3118,32,17,3,268,16,2048,2350,1076,2340,1285,33,257,33,2367,513]

theorem envBound45759 : H12AffineFastState.Bounded env45759 := by
  intro p hp
  have h : env45759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45758_45759 : H12AffineEnvironment.transform 11 1077 env45758 = env45759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env45758 == env45759) = true)

theorem identity45759 : scanCanonicalize (H12AffineFastState.compose env45759 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound45759 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45760 : List Nat := [2,4,8,16,32,17,9,256,512,1024,270,1077,269,48,1,263,32,43,1025,0,1312,32,17,3,268,16,270,32,1076,42,1285,33,257,33,49,513]

theorem envBound45760 : H12AffineFastState.Bounded env45760 := by
  intro p hp
  have h : env45760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45759_45760 : H12AffineEnvironment.transform 10 270 env45759 = env45760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env45759 == env45760) = true)

theorem identity45760 : scanCanonicalize (H12AffineFastState.compose env45760 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound45760 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45761 : List Nat := [2,4,8,16,32,17,9,21,512,1024,27,1077,24,48,1,18,32,43,1025,0,1077,32,17,3,25,16,27,32,1076,42,1040,33,20,33,49,513]

theorem envBound45761 : H12AffineFastState.Bounded env45761 := by
  intro p hp
  have h : env45761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45760_45761 : H12AffineEnvironment.transform 7 21 env45760 = env45761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env45760 == env45761) = true)

theorem identity45761 : scanCanonicalize (H12AffineFastState.compose env45761 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound45761 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45762 : List Nat := [2,4,8,16,32,17,9,21,10,1024,27,1077,24,48,1,18,32,43,1025,0,1077,32,17,3,25,16,27,32,1076,42,1040,33,20,33,49,11]

theorem envBound45762 : H12AffineFastState.Bounded env45762 := by
  intro p hp
  have h : env45762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45761_45762 : H12AffineEnvironment.transform 8 10 env45761 = env45762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env45761 == env45762) = true)

theorem identity45762 : scanCanonicalize (H12AffineFastState.compose env45762 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound45762 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env45763 : List Nat := [2,4,8,7,32,6,9,2,10,1024,12,1058,15,39,1,5,32,43,1025,0,1058,32,6,3,14,7,12,32,1059,42,1031,33,3,33,38,11]

theorem envBound45763 : H12AffineFastState.Bounded env45763 := by
  intro p hp
  have h : env45763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45762_45763 : H12AffineEnvironment.transform 3 7 env45762 = env45763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env45762 == env45763) = true)

theorem identity45763 : scanCanonicalize (H12AffineFastState.compose env45763 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound45763 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45764 : List Nat := [2,4,8,7,32,6,9,2,10,9,12,43,15,39,1,5,32,43,8,0,43,32,6,3,14,7,12,32,42,42,14,33,3,33,38,11]

theorem envBound45764 : H12AffineFastState.Bounded env45764 := by
  intro p hp
  have h : env45764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45763_45764 : H12AffineEnvironment.transform 9 9 env45763 = env45764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env45763 == env45764) = true)

def env45765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,153,272546,8328,65,4302891,2468910,2119112,295049,371754,6638946,257,2485399,2428210,297980]

theorem envBound45765 : H12AffineFastState.Bounded env45765 := by
  intro p hp
  have h : env45765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45740_45765 : H12AffineEnvironment.transform 16 16401 env45740 = env45765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env45740 == env45765) = true)

theorem identity45765 : scanCanonicalize (H12AffineFastState.compose env45765 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound45765 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env45766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,153,138,8328,65,4302891,2196486,2119112,43169,99330,6382922,257,2213055,2172186,41940]

theorem envBound45766 : H12AffineFastState.Bounded env45766 := by
  intro p hp
  have h : env45766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45765_45766 : H12AffineEnvironment.transform 17 10280 env45765 = env45766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env45765 == env45766) = true)

def env45767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,17,2,8192,65,4302891,2196486,2118976,43049,99330,6382922,257,2212919,2172186,41820]

theorem envBound45767 : H12AffineFastState.Bounded env45767 := by
  intro p hp
  have h : env45767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45766_45767 : H12AffineEnvironment.transform 6 8 env45766 = env45767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45766 == env45767) = true)

theorem identity45767 : scanCanonicalize (H12AffineFastState.compose env45767 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound45767 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env45768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,2097152,4194304,17,2,8192,65,4262262,2172251,2118976,2420,75103,6382922,257,2188650,2172186,513]

theorem envBound45768 : H12AffineFastState.Bounded env45768 := by
  intro p hp
  have h : env45768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45767_45768 : H12AffineEnvironment.transform 14 8541 env45767 = env45768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env45767 == env45768) = true)

theorem identity45768 : scanCanonicalize (H12AffineFastState.compose env45768 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 79195) := by decide +kernel

theorem selectedBound45768 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env45769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,79195,4194304,17,2,8192,65,4262262,4096,90139,2420,75103,4214801,257,20529,4161,513]

theorem envBound45769 : H12AffineFastState.Bounded env45769 := by
  intro p hp
  have h : env45769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45768_45769 : H12AffineEnvironment.transform 20 79195 env45768 = env45769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 79195 env45768 == env45769) = true)

theorem identity45769 : scanCanonicalize (H12AffineFastState.compose env45769 (packedSelected [9,14,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45769 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env45770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10280,1025,8540,5457,4194304,17,2,8192,65,4204924,4096,16401,2420,1365,4214801,257,20529,4161,513]

theorem envBound45770 : H12AffineFastState.Bounded env45770 := by
  intro p hp
  have h : env45770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45769_45770 : H12AffineEnvironment.transform 15 8202 env45769 = env45770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45769 == env45770) = true)

theorem identity45770 : scanCanonicalize (H12AffineFastState.compose env45770 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 4144) := by decide +kernel

theorem selectedBound45770 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env45771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10280,1025,8540,5457,4144,17,2,8192,65,14668,4096,16401,2420,1365,16417,257,20529,4161,513]

theorem envBound45771 : H12AffineFastState.Bounded env45771 := by
  intro p hp
  have h : env45771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45770_45771 : H12AffineEnvironment.transform 21 4144 env45770 = env45771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4144 env45770 == env45771) = true)

theorem identity45771 : scanCanonicalize (H12AffineFastState.compose env45771 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound45771 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env45772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,1297,1094,16401,3172,1025,1296,5457,4144,17,2,1100,65,7424,4096,16401,2420,1365,16417,257,20529,4161,513]

theorem envBound45772 : H12AffineFastState.Bounded env45772 := by
  intro p hp
  have h : env45772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45771_45772 : H12AffineEnvironment.transform 12 1100 env45771 = env45772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env45771 == env45772) = true)

theorem identity45772 : scanCanonicalize (H12AffineFastState.compose env45772 (packedSelected [4,9,23] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound45772 : packedSelected [4,9,23] rootPS < 2^1333 := by decide +kernel

def env45773 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,16,1100,16384,1297,1094,16401,3172,1025,1296,1345,32,17,2,1100,65,3344,16,16401,2420,1365,16417,257,16417,81,513]

theorem envBound45773 : H12AffineFastState.Bounded env45773 := by
  intro p hp
  have h : env45773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45772_45773 : H12AffineEnvironment.transform 11 16 env45772 = env45773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env45772 == env45773) = true)

theorem identity45773 : scanCanonicalize (H12AffineFastState.compose env45773 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 80) := by decide +kernel

theorem selectedBound45773 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45774 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,16,1100,80,1297,1094,65,3172,1025,1296,1345,32,17,2,1100,65,3344,16,65,2420,1365,113,257,113,81,513]

theorem envBound45774 : H12AffineFastState.Bounded env45774 := by
  intro p hp
  have h : env45774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45773_45774 : H12AffineEnvironment.transform 13 80 env45773 = env45774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 80 env45773 == env45774) = true)

theorem identity45774 : scanCanonicalize (H12AffineFastState.compose env45774 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound45774 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45775 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,16,1100,80,1297,1094,65,1344,1025,1296,1345,32,17,2,1100,65,1076,16,65,80,1365,113,257,113,81,513]

theorem envBound45775 : H12AffineFastState.Bounded env45775 := by
  intro p hp
  have h : env45775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45774_45775 : H12AffineEnvironment.transform 10 292 env45774 = env45775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env45774 == env45775) = true)

theorem identity45775 : scanCanonicalize (H12AffineFastState.compose env45775 (packedSelected [3,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound45775 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env45776 : List Nat := [2,4,8,16,32,64,8,116,512,1024,80,16,1100,80,1125,1094,65,1076,1025,1124,1077,32,17,2,1100,65,1076,16,65,80,1057,113,117,113,81,513]

theorem envBound45776 : H12AffineFastState.Bounded env45776 := by
  intro p hp
  have h : env45776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45775_45776 : H12AffineEnvironment.transform 7 116 env45775 = env45776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env45775 == env45776) = true)

theorem identity45776 : scanCanonicalize (H12AffineFastState.compose env45776 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound45776 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45777 : List Nat := [2,4,8,16,32,64,8,116,512,52,80,16,120,80,81,114,65,0,53,80,1,32,17,2,120,65,0,16,65,80,21,113,117,113,81,513]

theorem envBound45777 : H12AffineFastState.Bounded env45777 := by
  intro p hp
  have h : env45777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45776_45777 : H12AffineEnvironment.transform 9 52 env45776 = env45777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45776 == env45777) = true)

def env45778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,16,3,8193,65,4302891,2196486,2118977,43048,99330,6382922,257,2212918,2172186,41821]

theorem envBound45778 : H12AffineFastState.Bounded env45778 := by
  intro p hp
  have h : env45778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45766_45778 : H12AffineEnvironment.transform 6 9 env45766 = env45778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45766 == env45778) = true)

theorem identity45778 : scanCanonicalize (H12AffineFastState.compose env45778 (packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound45778 : packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env45779 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10280,1025,32769,2097152,4194304,16,3,8193,65,4196384,2106381,2118977,43048,9225,6341953,257,2122813,2131217,41821]

theorem envBound45779 : H12AffineFastState.Bounded env45779 := by
  intro p hp
  have h : env45779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45778_45779 : H12AffineEnvironment.transform 15 40971 env45778 = env45779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env45778 == env45779) = true)

theorem identity45779 : scanCanonicalize (H12AffineFastState.compose env45779 (packedSelected [0,1,2,3,5,6,11,12,14,15,16,19,20,23,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45779 : packedSelected [0,1,2,3,5,6,11,12,14,15,16,19,20,23,27,28] rootPS < 2^1333 := by decide +kernel

def env45780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,33111,16401,2420,1025,32769,2097152,4194304,16,3,349,65,4196384,2098513,2118977,35188,1365,6341953,257,2114913,2131217,33281]

theorem envBound45780 : H12AffineFastState.Bounded env45780 := by
  intro p hp
  have h : env45780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45779_45780 : H12AffineEnvironment.transform 12 348 env45779 = env45780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45779 == env45780) = true)

theorem identity45780 : scanCanonicalize (H12AffineFastState.compose env45780 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 50497) := by decide +kernel

theorem selectedBound45780 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env45781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,33111,16401,2420,1025,32769,50497,4194304,16,3,349,65,4196384,49168,36864,35188,1365,4194304,257,32800,16464,33281]

theorem envBound45781 : H12AffineFastState.Bounded env45781 := by
  intro p hp
  have h : env45781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45780_45781 : H12AffineEnvironment.transform 20 50497 env45780 = env45781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50497 env45780 == env45781) = true)

theorem identity45781 : scanCanonicalize (H12AffineFastState.compose env45781 (packedSelected [1,8,19] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound45781 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env45782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,33111,16401,2420,1025,32769,50497,33,16,3,349,65,2049,49168,36864,35188,1365,33,257,32800,16464,33281]

theorem envBound45782 : H12AffineFastState.Bounded env45782 := by
  intro p hp
  have h : env45782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45781_45782 : H12AffineEnvironment.transform 21 33 env45781 = env45782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env45781 == env45782) = true)

theorem identity45782 : scanCanonicalize (H12AffineFastState.compose env45782 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5488) := by decide +kernel

theorem selectedBound45782 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env45783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5488,32768,33111,5473,2420,1025,32769,36913,33,16,3,349,65,2049,38240,36864,35188,1365,33,257,32800,5408,33281]

theorem envBound45783 : H12AffineFastState.Bounded env45783 := by
  intro p hp
  have h : env45783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45782_45783 : H12AffineEnvironment.transform 13 5488 env45782 = env45783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5488 env45782 == env45783) = true)

theorem identity45783 : scanCanonicalize (H12AffineFastState.compose env45783 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45783 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env45784 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5408,32768,33031,5425,2340,1025,32769,36913,33,16,3,269,17,2049,38192,36864,35108,1285,33,257,32800,5408,33281]

theorem envBound45784 : H12AffineFastState.Bounded env45784 := by
  intro p hp
  have h : env45784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45783_45784 : H12AffineEnvironment.transform 5 16 env45783 = env45784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45783 == env45784) = true)

theorem identity45784 : scanCanonicalize (H12AffineFastState.compose env45784 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(14+1) ^^^ 4894) := by decide +kernel

theorem selectedBound45784 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env45785 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5408,4894,4633,5425,2340,1025,4895,815,33,16,3,269,17,2049,1582,798,6714,1285,33,257,4926,5408,4383]

theorem envBound45785 : H12AffineFastState.Bounded env45785 := by
  intro p hp
  have h : env45785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45784_45785 : H12AffineEnvironment.transform 14 4894 env45784 = env45785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4894 env45784 == env45785) = true)

theorem identity45785 : scanCanonicalize (H12AffineFastState.compose env45785 (packedSelected [2,3,5,11] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound45785 : packedSelected [2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env45786 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3076,268,2340,3866,3613,2357,2340,1025,3867,815,33,16,3,269,17,2049,1582,798,1598,1285,33,257,3898,2340,3355]

theorem envBound45786 : H12AffineFastState.Bounded env45786 := by
  intro p hp
  have h : env45786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45785_45786 : H12AffineEnvironment.transform 11 3076 env45785 = env45786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env45785 == env45786) = true)

theorem identity45786 : scanCanonicalize (H12AffineFastState.compose env45786 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound45786 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env45787 : List Nat := [2,4,8,16,32,16,9,256,512,1024,554,1582,268,782,1328,1079,799,782,1025,1329,815,33,16,3,269,17,555,1582,798,1598,1285,33,257,1296,782,1841]

theorem envBound45787 : H12AffineFastState.Bounded env45787 := by
  intro p hp
  have h : env45787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45786_45787 : H12AffineEnvironment.transform 10 554 env45786 = env45787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env45786 == env45787) = true)

theorem identity45787 : scanCanonicalize (H12AffineFastState.compose env45787 (packedSelected [0,3,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound45787 : packedSelected [0,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env45788 : List Nat := [2,4,8,16,32,16,9,256,512,52,554,538,268,782,260,3,799,782,53,261,815,33,16,3,269,17,555,538,798,522,305,33,257,292,782,773]

theorem envBound45788 : H12AffineFastState.Bounded env45788 := by
  intro p hp
  have h : env45788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45787_45788 : H12AffineEnvironment.transform 9 52 env45787 = env45788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45787 == env45788) = true)

def env45789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147593,272546,8328,65,4302890,2468910,2233816,295048,519226,6638946,257,2600071,2575650,445420]

theorem envBound45789 : H12AffineFastState.Bounded env45789 := by
  intro p hp
  have h : env45789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45739_45789 : H12AffineEnvironment.transform 22 147593 env45739 = env45789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env45739 == env45789) = true)

def env45790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,153,272546,8328,65,4302890,2468910,2119112,295048,371754,6638946,257,2485399,2428210,297980]

theorem envBound45790 : H12AffineFastState.Bounded env45790 := by
  intro p hp
  have h : env45790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45789_45790 : H12AffineEnvironment.transform 16 16400 env45789 = env45790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env45789 == env45790) = true)

theorem identity45790 : scanCanonicalize (H12AffineFastState.compose env45790 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound45790 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env45791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16400,262144,1025,8660,2097152,4194304,153,272546,8328,65,4262399,2428411,2119112,270685,331263,6638946,257,2444610,2428210,272937]

theorem envBound45791 : H12AffineFastState.Bounded env45791 := by
  intro p hp
  have h : env45791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45790_45791 : H12AffineEnvironment.transform 14 8661 env45790 = env45791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env45790 == env45791) = true)

theorem identity45791 : scanCanonicalize (H12AffineFastState.compose env45791 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45791 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env45792 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,262144,1025,8541,2097152,4194304,16,272427,8193,65,4262262,2428274,2118977,270685,331126,6638946,257,2444610,2428210,272937]

theorem envBound45792 : H12AffineFastState.Bounded env45792 := by
  intro p hp
  have h : env45792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45791_45792 : H12AffineEnvironment.transform 6 9 env45791 = env45792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45791 == env45792) = true)

theorem identity45792 : scanCanonicalize (H12AffineFastState.compose env45792 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound45792 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env45793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1025,8541,2097152,4194304,16,3,8193,65,4262262,2172250,2118977,2421,75102,6382922,257,2188650,2172186,513]

theorem envBound45793 : H12AffineFastState.Bounded env45793 := by
  intro p hp
  have h : env45793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45792_45793 : H12AffineEnvironment.transform 17 10280 env45792 = env45793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env45792 == env45793) = true)

theorem identity45793 : scanCanonicalize (H12AffineFastState.compose env45793 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound45793 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env45794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10280,1025,8541,2097152,4194304,16,3,8193,65,4204925,2098513,2118977,2421,1365,6309185,257,2114913,2098449,513]

theorem envBound45794 : H12AffineFastState.Bounded env45794 := by
  intro p hp
  have h : env45794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45793_45794 : H12AffineEnvironment.transform 15 8203 env45793 = env45794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env45793 == env45794) = true)

theorem identity45794 : scanCanonicalize (H12AffineFastState.compose env45794 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2114913) := by decide +kernel

theorem selectedBound45794 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45795 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10280,1025,8541,2097152,2114913,16,3,8193,65,2124828,2098513,2118977,2421,1365,32,257,2114913,2098449,513]

theorem envBound45795 : H12AffineFastState.Bounded env45795 := by
  intro p hp
  have h : env45795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45794_45795 : H12AffineEnvironment.transform 21 2114913 env45794 = env45795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env45794 == env45795) = true)

theorem identity45795 : scanCanonicalize (H12AffineFastState.compose env45795 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound45795 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45796 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10280,1025,8541,17680,113,16,3,8193,65,10508,16449,4177,2421,1365,32,257,113,16385,513]

theorem envBound45796 : H12AffineFastState.Bounded env45796 := by
  intro p hp
  have h : env45796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45795_45796 : H12AffineEnvironment.transform 20 17680 env45795 = env45796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env45795 == env45796) = true)

theorem identity45796 : scanCanonicalize (H12AffineFastState.compose env45796 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45796 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env45797 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,8203,16400,10280,1025,8461,17680,33,16,3,8193,17,10508,16401,4097,2341,1285,32,257,33,16385,513]

theorem envBound45797 : H12AffineFastState.Bounded env45797 := by
  intro p hp
  have h : env45797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45796_45797 : H12AffineEnvironment.transform 5 16 env45796 = env45797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45796 == env45797) = true)

theorem identity45797 : scanCanonicalize (H12AffineFastState.compose env45797 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound45797 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45798 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,5384,16384,5124,5379,16400,7456,1025,5125,17680,33,16,3,5385,17,7172,16401,4097,2341,1285,32,257,33,16385,513]

theorem envBound45798 : H12AffineFastState.Bounded env45798 := by
  intro p hp
  have h : env45798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45797_45798 : H12AffineEnvironment.transform 12 5384 env45797 = env45798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env45797 == env45798) = true)

theorem identity45798 : scanCanonicalize (H12AffineFastState.compose env45798 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound45798 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env45799 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2096,3384,16384,3124,3379,16400,1296,1025,3125,17680,33,16,3,3385,17,1076,16401,2097,2341,1285,32,257,33,16385,513]

theorem envBound45799 : H12AffineFastState.Bounded env45799 := by
  intro p hp
  have h : env45799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45798_45799 : H12AffineEnvironment.transform 11 2096 env45798 = env45799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env45798 == env45799) = true)

theorem identity45799 : scanCanonicalize (H12AffineFastState.compose env45799 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(13+1) ^^^ 3605) := by decide +kernel

theorem selectedBound45799 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env45800 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2096,3384,3605,3124,3379,3589,1296,1025,3125,2821,33,16,3,3385,17,1076,3588,2097,2341,1285,32,257,33,3604,513]

theorem envBound45800 : H12AffineFastState.Bounded env45800 := by
  intro p hp
  have h : env45800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45799_45800 : H12AffineEnvironment.transform 13 3605 env45799 = env45800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3605 env45799 == env45800) = true)

theorem identity45800 : scanCanonicalize (H12AffineFastState.compose env45800 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound45800 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env45801 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1044,1060,300,513,32,295,529,1296,1025,33,1809,33,16,3,301,17,1076,528,1061,1329,1285,32,257,33,512,513]

theorem envBound45801 : H12AffineFastState.Bounded env45801 := by
  intro p hp
  have h : env45801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45800_45801 : H12AffineEnvironment.transform 10 1044 env45800 = env45801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env45800 == env45801) = true)

theorem identity45801 : scanCanonicalize (H12AffineFastState.compose env45801 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45801 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env45802 : List Nat := [2,4,8,1,32,1,9,256,512,1024,1029,1060,300,513,32,295,512,1281,1025,33,1792,33,1,3,301,0,1061,513,1061,1312,1285,32,257,33,512,513]

theorem envBound45802 : H12AffineFastState.Bounded env45802 := by
  intro p hp
  have h : env45802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45801_45802 : H12AffineEnvironment.transform 3 1 env45801 = env45802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45801 == env45802) = true)

theorem identity45802 : scanCanonicalize (H12AffineFastState.compose env45802 (packedSelected [1,3,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45802 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env45803 : List Nat := [2,4,8,1,0,1,9,256,512,1024,1029,1028,268,513,0,263,512,1281,1025,1,1792,1,1,3,269,0,1029,513,1029,1280,1285,0,257,1,512,513]

theorem envBound45803 : H12AffineFastState.Bounded env45803 := by
  intro p hp
  have h : env45803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45802_45803 : H12AffineEnvironment.transform 4 0 env45802 = env45803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45802 == env45803) = true)

theorem identity45803 : scanCanonicalize (H12AffineFastState.compose env45803 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound45803 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45804 : List Nat := [2,4,8,1,0,1,9,256,512,768,773,772,268,513,0,263,512,513,769,1,0,1,1,3,269,0,773,513,773,512,517,0,257,1,512,513]

theorem envBound45804 : H12AffineFastState.Bounded env45804 := by
  intro p hp
  have h : env45804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45803_45804 : H12AffineEnvironment.transform 9 768 env45803 = env45804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env45803 == env45804) = true)

theorem identity45804 : scanCanonicalize (H12AffineFastState.compose env45804 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound45804 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45805 : List Nat := [2,4,8,1,0,1,9,256,1,257,260,261,268,0,0,263,1,0,256,1,0,1,1,3,269,0,260,0,260,1,4,0,257,1,1,0]

theorem envBound45805 : H12AffineFastState.Bounded env45805 := by
  intro p hp
  have h : env45805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45804_45805 : H12AffineEnvironment.transform 8 1 env45804 = env45805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env45804 == env45805) = true)

theorem identity45805 : scanCanonicalize (H12AffineFastState.compose env45805 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound45805 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45806 : List Nat := [2,4,8,1,0,1,9,5,1,4,1,0,9,0,0,2,1,0,5,1,0,1,1,3,8,0,1,0,1,1,4,0,4,1,1,0]

theorem envBound45806 : H12AffineFastState.Bounded env45806 := by
  intro p hp
  have h : env45806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45805_45806 : H12AffineEnvironment.transform 7 5 env45805 = env45806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env45805 == env45806) = true)

def env45807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,152,272546,8328,65,4302890,2468910,2119113,295048,371755,6638946,257,2485398,2428211,297981]

theorem envBound45807 : H12AffineFastState.Bounded env45807 := by
  intro p hp
  have h : env45807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45789_45807 : H12AffineEnvironment.transform 16 16401 env45789 = env45807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env45789 == env45807) = true)

theorem identity45807 : scanCanonicalize (H12AffineFastState.compose env45807 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound45807 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env45808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35324,1025,32769,2097152,4194304,152,41310,8328,65,4302890,2172370,2119113,2420,75223,6407326,257,2188650,2196687,513]

theorem envBound45808 : H12AffineFastState.Bounded env45808 := by
  intro p hp
  have h : env45808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45807_45808 : H12AffineEnvironment.transform 17 35324 env45807 = env45808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env45807 == env45808) = true)

def env45809 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,16,41310,8192,65,4302890,2172250,2118977,2420,75103,6407190,257,2188650,2196551,513]

theorem envBound45809 : H12AffineFastState.Bounded env45809 := by
  intro p hp
  have h : env45809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45808_45809 : H12AffineEnvironment.transform 6 8 env45808 = env45809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45808 == env45809) = true)

theorem identity45809 : scanCanonicalize (H12AffineFastState.compose env45809 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45809 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env45810 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35188,1025,32769,2097152,4194304,16,41310,8192,65,4229152,2098512,2118977,2420,1365,6349852,257,2114912,2139213,513]

theorem envBound45810 : H12AffineFastState.Bounded env45810 := by
  intro p hp
  have h : env45810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45809_45810 : H12AffineEnvironment.transform 15 8202 env45809 = env45810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45809 == env45810) = true)

theorem identity45810 : scanCanonicalize (H12AffineFastState.compose env45810 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 2114912) := by decide +kernel

theorem selectedBound45810 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45811 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35188,1025,32769,2097152,2114912,16,41310,8192,65,2149696,2098512,2118977,2420,1365,41340,257,2114912,2139213,513]

theorem envBound45811 : H12AffineFastState.Bounded env45811 := by
  intro p hp
  have h : env45811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45810_45811 : H12AffineEnvironment.transform 21 2114912 env45810 = env45811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env45810 == env45811) = true)

theorem identity45811 : scanCanonicalize (H12AffineFastState.compose env45811 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound45811 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env45812 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8202,16401,30777,1025,29004,2097152,2114912,16,20499,8192,65,2112525,2098512,2118977,2420,1365,20529,257,2114912,2118912,513]

theorem envBound45812 : H12AffineFastState.Bounded env45812 := by
  intro p hp
  have h : env45812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45811_45812 : H12AffineEnvironment.transform 14 29005 env45811 = env45812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env45811 == env45812) = true)

theorem identity45812 : scanCanonicalize (H12AffineFastState.compose env45812 (packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound45812 : packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS < 2^1333 := by decide +kernel

def env45813 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,8202,4096,10280,1025,8541,2097152,2102641,16,2,8192,65,2112525,2098512,2098512,2420,1365,32,257,2102641,2098449,513]

theorem envBound45813 : H12AffineFastState.Bounded env45813 := by
  intro p hp
  have h : env45813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45812_45813 : H12AffineEnvironment.transform 13 4113 env45812 = env45813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env45812 == env45813) = true)

def env45814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,17,41310,8193,65,4302890,2172251,2118976,2420,75102,6407191,257,2188650,2196550,513]

theorem envBound45814 : H12AffineFastState.Bounded env45814 := by
  intro p hp
  have h : env45814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45808_45814 : H12AffineEnvironment.transform 6 9 env45808 = env45814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45808 == env45814) = true)

theorem identity45814 : scanCanonicalize (H12AffineFastState.compose env45814 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound45814 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env45815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,115734,4194304,17,41310,8193,65,4302890,57677,102742,2420,75102,4194305,257,41340,16464,513]

theorem envBound45815 : H12AffineFastState.Bounded env45815 := by
  intro p hp
  have h : env45815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45814_45815 : H12AffineEnvironment.transform 20 115734 env45814 = env45815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env45814 == env45815) = true)

def env45816 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10589,1025,8233,91198,4194304,17,374,8193,65,4261890,16741,78206,2420,75102,4194305,257,340,16464,513]

theorem envBound45816 : H12AffineFastState.Bounded env45816 := by
  intro p hp
  have h : env45816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45815_45816 : H12AffineEnvironment.transform 14 8232 env45815 = env45816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env45815 == env45816) = true)

theorem identity45816 : scanCanonicalize (H12AffineFastState.compose env45816 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound45816 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env45817 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,342,16401,10589,1025,8233,25960,4194304,17,374,8193,65,4196692,16741,12328,2420,9224,4194305,257,340,16464,513]

theorem envBound45817 : H12AffineFastState.Bounded env45817 := by
  intro p hp
  have h : env45817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45816_45817 : H12AffineEnvironment.transform 15 342 env45816 = env45817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env45816 == env45817) = true)

theorem identity45817 : scanCanonicalize (H12AffineFastState.compose env45817 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound45817 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env45818 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,342,16401,10589,1025,8233,25960,8573,17,374,8193,65,10281,16741,12328,2420,9224,8572,257,340,16464,513]

theorem envBound45818 : H12AffineFastState.Bounded env45818 := by
  intro p hp
  have h : env45818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45817_45818 : H12AffineEnvironment.transform 21 8573 env45817 = env45818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env45817 == env45818) = true)

theorem identity45818 : scanCanonicalize (H12AffineFastState.compose env45818 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound45818 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,1,342,16401,2420,1025,0,17729,340,17,374,40,65,2048,16741,4097,2420,1057,341,257,340,16464,513]

theorem envBound45819 : H12AffineFastState.Bounded env45819 := by
  intro p hp
  have h : env45819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45818_45819 : H12AffineEnvironment.transform 12 41 env45818 = env45819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env45818 == env45819) = true)

theorem identity45819 : scanCanonicalize (H12AffineFastState.compose env45819 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45819 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45820 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,16384,1,262,16401,2340,1025,0,17681,260,17,294,40,17,2048,16693,4097,2340,1057,261,257,260,16384,513]

theorem envBound45820 : H12AffineFastState.Bounded env45820 := by
  intro p hp
  have h : env45820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45819_45820 : H12AffineEnvironment.transform 5 16 env45819 = env45820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45819 == env45820) = true)

theorem identity45820 : scanCanonicalize (H12AffineFastState.compose env45820 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound45820 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env45821 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,5377,1,262,5392,2340,1025,0,4112,260,17,294,40,17,2048,5172,4097,2340,1057,261,257,260,5377,513]

theorem envBound45821 : H12AffineFastState.Bounded env45821 := by
  intro p hp
  have h : env45821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45820_45821 : H12AffineEnvironment.transform 13 5377 env45820 = env45821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45820 == env45821) = true)

theorem identity45821 : scanCanonicalize (H12AffineFastState.compose env45821 (packedSelected [1,3,4,5,8,9,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45821 : packedSelected [1,3,4,5,8,9,15] rootPS < 2^1333 := by decide +kernel

def env45822 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,1,35,5173,2049,1025,0,4112,33,17,3,40,17,2048,5172,4097,2049,1057,32,36,33,5156,513]

theorem envBound45822 : H12AffineFastState.Bounded env45822 := by
  intro p hp
  have h : env45822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45821_45822 : H12AffineEnvironment.transform 7 37 env45821 = env45822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45821 == env45822) = true)

def env45823 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1044,1,35,1029,2049,1025,0,32,33,17,3,40,17,2048,1028,49,2049,1057,32,36,33,1044,513]

theorem envBound45823 : H12AffineFastState.Bounded env45823 := by
  intro p hp
  have h : env45823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45822_45823 : H12AffineEnvironment.transform 11 48 env45822 = env45823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env45822 == env45823) = true)

theorem identity45823 : scanCanonicalize (H12AffineFastState.compose env45823 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45823 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45824 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,8,1044,1,2,1029,2049,1025,0,1,0,17,3,9,17,2048,1028,16,2049,1024,1,5,0,1044,513]

theorem envBound45824 : H12AffineFastState.Bounded env45824 := by
  intro p hp
  have h : env45824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45823_45824 : H12AffineEnvironment.transform 4 1 env45823 = env45824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45823 == env45824) = true)

def env45825 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,17,8,0,1,2,17,2049,21,0,1,0,17,3,9,17,2048,16,16,2049,20,1,5,0,0,513]

theorem envBound45825 : H12AffineFastState.Bounded env45825 := by
  intro p hp
  have h : env45825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45824_45825 : H12AffineEnvironment.transform 9 20 env45824 = env45825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45824 == env45825) = true)

theorem identity45825 : scanCanonicalize (H12AffineFastState.compose env45825 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45825 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45826 : List Nat := [2,4,8,16,1,16,9,4,512,20,0,17,8,0,1,2,17,1,21,0,1,0,17,3,9,17,0,16,16,1,20,1,5,0,0,513]

theorem envBound45826 : H12AffineFastState.Bounded env45826 := by
  intro p hp
  have h : env45826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45825_45826 : H12AffineEnvironment.transform 10 0 env45825 = env45826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45825 == env45826) = true)

def leafEnv45826 : List Nat := [2,4,8,16,1,16,9,4,512,20,0,17,8,0,1,2,17,1,21,0,1,0,17,3,21,9,1,17,0,16,16,1,20,1,5,0,5,3,0,513,1,1,0]

def active45826 : List Nat := [0,1,2,3,8]

def tree45826 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45826 : H12WitnessSearch.Good tree45826 := H12GlobalWitnessIndex.good

theorem leafIdentity45826 : H12AffineFastState.composeSystem env45826 rootObs = leafEnv45826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45826 rootObs == leafEnv45826) = true)

theorem terminalChecked45826 : H12PackedTerminal.terminalCheckFast leafEnv45826 active45826 tree45826 = true := by decide +kernel

def env45827 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,8,1,1,2,16,2049,20,0,1,0,17,3,9,17,2048,17,16,2049,21,1,5,0,1,513]

theorem envBound45827 : H12AffineFastState.Bounded env45827 := by
  intro p hp
  have h : env45827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45824_45827 : H12AffineEnvironment.transform 9 21 env45824 = env45827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env45824 == env45827) = true)

theorem identity45827 : scanCanonicalize (H12AffineFastState.compose env45827 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound45827 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45828 : List Nat := [2,4,8,16,1,16,9,4,512,21,522,17,8,1,1,2,16,523,20,0,1,0,17,3,9,17,522,17,16,523,21,1,5,0,1,513]

theorem envBound45828 : H12AffineFastState.Bounded env45828 := by
  intro p hp
  have h : env45828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45827_45828 : H12AffineEnvironment.transform 10 522 env45827 = env45828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env45827 == env45828) = true)

def leafEnv45828 : List Nat := [2,4,8,16,1,16,9,4,512,21,522,17,8,1,1,2,16,523,20,0,1,0,17,3,20,9,1,17,522,17,16,523,21,1,5,0,5,3,1,513,1,1,0]

def active45828 : List Nat := [0,1,2,3,8]

def tree45828 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45828 : H12WitnessSearch.Good tree45828 := H12GlobalWitnessIndex.good

theorem leafIdentity45828 : H12AffineFastState.composeSystem env45828 rootObs = leafEnv45828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45828 rootObs == leafEnv45828) = true)

theorem terminalChecked45828 : H12PackedTerminal.terminalCheckFast leafEnv45828 active45828 tree45828 = true := by decide +kernel

def env45829 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1045,1,35,1028,2049,1025,0,33,33,17,3,40,17,2048,1029,48,2049,1057,32,36,33,1045,513]

theorem envBound45829 : H12AffineFastState.Bounded env45829 := by
  intro p hp
  have h : env45829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45822_45829 : H12AffineEnvironment.transform 11 49 env45822 = env45829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env45822 == env45829) = true)

theorem identity45829 : scanCanonicalize (H12AffineFastState.compose env45829 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound45829 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45830 : List Nat := [2,4,8,16,32,16,9,37,512,20,2048,49,41,1,1,35,16,2049,21,0,33,33,17,3,40,17,2048,17,48,2049,53,32,36,33,1,513]

theorem envBound45830 : H12AffineFastState.Bounded env45830 := by
  intro p hp
  have h : env45830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45829_45830 : H12AffineEnvironment.transform 9 20 env45829 = env45830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45829 == env45830) = true)

def env45831 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,17,9,1,1,3,16,2049,21,0,1,1,17,3,8,17,2048,17,16,2049,21,0,4,1,1,513]

theorem envBound45831 : H12AffineFastState.Bounded env45831 := by
  intro p hp
  have h : env45831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45830_45831 : H12AffineEnvironment.transform 4 0 env45830 = env45831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45830 == env45831) = true)

theorem identity45831 : scanCanonicalize (H12AffineFastState.compose env45831 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound45831 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45832 : List Nat := [2,4,8,16,0,16,9,5,512,20,522,17,9,1,1,3,16,523,21,0,1,1,17,3,8,17,522,17,16,523,21,0,4,1,1,513]

theorem envBound45832 : H12AffineFastState.Bounded env45832 := by
  intro p hp
  have h : env45832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45831_45832 : H12AffineEnvironment.transform 10 522 env45831 = env45832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env45831 == env45832) = true)

def leafEnv45832 : List Nat := [2,4,8,16,0,16,9,5,512,20,522,17,9,1,1,3,16,523,21,0,1,1,17,3,20,8,1,17,522,17,16,523,21,0,4,1,5,2,1,513,1,1,0]

def active45832 : List Nat := [0,1,2,3,8]

def tree45832 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45832 : H12WitnessSearch.Good tree45832 := H12GlobalWitnessIndex.good

theorem leafIdentity45832 : H12AffineFastState.composeSystem env45832 rootObs = leafEnv45832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45832 rootObs == leafEnv45832) = true)

theorem terminalChecked45832 : H12PackedTerminal.terminalCheckFast leafEnv45832 active45832 tree45832 = true := by decide +kernel

def env45833 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,8,1,1,2,16,2049,21,0,0,0,17,3,9,17,2048,17,17,2049,20,1,5,0,1,513]

theorem envBound45833 : H12AffineFastState.Bounded env45833 := by
  intro p hp
  have h : env45833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45830_45833 : H12AffineEnvironment.transform 4 1 env45830 = env45833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45830 == env45833) = true)

theorem identity45833 : scanCanonicalize (H12AffineFastState.compose env45833 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound45833 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45834 : List Nat := [2,4,8,16,1,16,9,4,512,20,1,16,8,1,1,2,16,0,21,0,0,0,17,3,9,17,1,17,17,0,20,1,5,0,1,513]

theorem envBound45834 : H12AffineFastState.Bounded env45834 := by
  intro p hp
  have h : env45834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45833_45834 : H12AffineEnvironment.transform 10 1 env45833 = env45834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env45833 == env45834) = true)

def leafEnv45834 : List Nat := [2,4,8,16,1,16,9,4,512,20,1,16,8,1,1,2,16,0,21,0,0,0,17,3,21,9,1,17,1,17,17,0,20,1,5,0,5,3,1,513,1,0,0]

def active45834 : List Nat := [0,1,2,3,8]

def tree45834 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45834 : H12WitnessSearch.Good tree45834 := H12GlobalWitnessIndex.good

theorem leafIdentity45834 : H12AffineFastState.composeSystem env45834 rootObs = leafEnv45834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45834 rootObs == leafEnv45834) = true)

theorem terminalChecked45834 : H12PackedTerminal.terminalCheckFast leafEnv45834 active45834 tree45834 = true := by decide +kernel

def env45835 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10588,1025,8232,91199,4194304,17,375,8193,65,4261891,16740,78207,2420,75102,4194305,257,341,16464,513]

theorem envBound45835 : H12AffineFastState.Bounded env45835 := by
  intro p hp
  have h : env45835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45815_45835 : H12AffineEnvironment.transform 14 8233 env45815 = env45835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env45815 == env45835) = true)

theorem identity45835 : scanCanonicalize (H12AffineFastState.compose env45835 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound45835 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env45836 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,34,16401,10588,1025,8232,25629,4194304,17,375,8193,65,4196385,16740,12637,2420,9596,4194305,257,341,16464,513]

theorem envBound45836 : H12AffineFastState.Bounded env45836 := by
  intro p hp
  have h : env45836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45835_45836 : H12AffineEnvironment.transform 15 34 env45835 = env45836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env45835 == env45836) = true)

theorem identity45836 : scanCanonicalize (H12AffineFastState.compose env45836 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound45836 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env45837 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,34,16401,10588,1025,8232,25629,8493,17,375,8193,65,10508,16740,12637,2420,9596,8492,257,341,16464,513]

theorem envBound45837 : H12AffineFastState.Bounded env45837 := by
  intro p hp
  have h : env45837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45836_45837 : H12AffineEnvironment.transform 21 8493 env45836 = env45837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env45836 == env45837) = true)

theorem identity45837 : scanCanonicalize (H12AffineFastState.compose env45837 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound45837 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env45838 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8233,34,16401,10280,1025,8232,25629,8281,17,3,8193,65,10360,16400,12329,2048,9224,8280,117,33,16464,513]

theorem envBound45838 : H12AffineFastState.Bounded env45838 := by
  intro p hp
  have h : env45838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45837_45838 : H12AffineEnvironment.transform 7 116 env45837 = env45838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env45837 == env45838) = true)

theorem identity45838 : scanCanonicalize (H12AffineFastState.compose env45838 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45838 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45839 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8233,34,16401,10280,1025,8232,25629,8201,17,3,8193,17,10280,16400,12329,2048,9224,8200,37,33,16384,513]

theorem envBound45839 : H12AffineFastState.Bounded env45839 := by
  intro p hp
  have h : env45839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45838_45839 : H12AffineEnvironment.transform 5 16 env45838 = env45839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45838 == env45839) = true)

theorem identity45839 : scanCanonicalize (H12AffineFastState.compose env45839 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound45839 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45840 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,13324,8233,34,13341,10280,1025,8232,4113,8201,17,3,8193,17,10280,13340,12329,2048,9224,8200,37,33,13324,513]

theorem envBound45840 : H12AffineFastState.Bounded env45840 := by
  intro p hp
  have h : env45840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45839_45840 : H12AffineEnvironment.transform 13 13324 env45839 = env45840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env45839 == env45840) = true)

theorem identity45840 : scanCanonicalize (H12AffineFastState.compose env45840 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound45840 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45841 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5156,1,34,5173,2048,1025,0,4113,33,17,3,41,17,2048,5172,4097,2048,1056,32,37,33,5156,513]

theorem envBound45841 : H12AffineFastState.Bounded env45841 := by
  intro p hp
  have h : env45841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45840_45841 : H12AffineEnvironment.transform 12 40 env45840 = env45841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env45840 == env45841) = true)

def env45842 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,40,1044,1,34,1029,2048,1025,0,33,33,17,3,41,17,2048,1028,49,2048,1056,32,37,33,1044,513]

theorem envBound45842 : H12AffineFastState.Bounded env45842 := by
  intro p hp
  have h : env45842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45841_45842 : H12AffineEnvironment.transform 11 48 env45841 = env45842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env45841 == env45842) = true)

theorem identity45842 : scanCanonicalize (H12AffineFastState.compose env45842 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound45842 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45843 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1540,48,40,1044,1,34,1029,1540,1025,0,33,33,17,3,41,17,1540,1028,49,1540,1056,32,37,33,1044,513]

theorem envBound45843 : H12AffineFastState.Bounded env45843 := by
  intro p hp
  have h : env45843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45842_45843 : H12AffineEnvironment.transform 10 1540 env45842 = env45843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env45842 == env45843) = true)

def env45844 : List Nat := [2,4,8,16,32,16,9,36,512,52,560,48,40,32,1,34,49,560,53,0,33,33,17,3,41,17,560,48,49,560,20,32,37,33,32,513]

theorem envBound45844 : H12AffineFastState.Bounded env45844 := by
  intro p hp
  have h : env45844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45843_45844 : H12AffineEnvironment.transform 9 52 env45843 = env45844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45843 == env45844) = true)

theorem identity45844 : scanCanonicalize (H12AffineFastState.compose env45844 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound45844 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45845 : List Nat := [2,4,8,16,27,16,9,31,512,15,523,11,19,27,1,25,10,523,14,0,26,26,17,3,18,17,523,11,10,523,20,27,30,26,27,513]

theorem envBound45845 : H12AffineFastState.Bounded env45845 := by
  intro p hp
  have h : env45845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45844_45845 : H12AffineEnvironment.transform 4 27 env45844 = env45845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env45844 == env45845) = true)

def leafEnv45845 : List Nat := [2,4,8,16,27,16,9,31,512,15,523,11,19,27,1,25,10,523,14,0,26,26,17,3,21,18,1,17,523,11,10,523,20,27,30,26,5,24,27,513,1,26,0]

def active45845 : List Nat := [0,1,2,3,8]

def tree45845 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45845 : H12WitnessSearch.Good tree45845 := H12GlobalWitnessIndex.good

theorem leafIdentity45845 : H12AffineFastState.composeSystem env45845 rootObs = leafEnv45845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45845 rootObs == leafEnv45845) = true)

theorem terminalChecked45845 : H12PackedTerminal.terminalCheckFast leafEnv45845 active45845 tree45845 = true := by decide +kernel

def env45846 : List Nat := [2,4,8,16,32,16,9,36,512,53,561,48,40,33,1,34,48,561,52,0,33,33,17,3,41,17,561,49,49,561,21,32,37,33,33,513]

theorem envBound45846 : H12AffineFastState.Bounded env45846 := by
  intro p hp
  have h : env45846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45843_45846 : H12AffineEnvironment.transform 9 53 env45843 = env45846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45843 == env45846) = true)

theorem identity45846 : scanCanonicalize (H12AffineFastState.compose env45846 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound45846 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45847 : List Nat := [2,4,8,16,32,16,9,36,16,53,33,48,40,33,1,34,48,33,52,0,33,33,17,3,41,17,33,49,49,33,21,32,37,33,33,17]

theorem envBound45847 : H12AffineFastState.Bounded env45847 := by
  intro p hp
  have h : env45847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45846_45847 : H12AffineEnvironment.transform 8 16 env45846 = env45847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env45846 == env45847) = true)

def leafEnv45847 : List Nat := [2,4,8,16,32,16,9,36,16,53,33,48,40,33,1,34,48,33,52,0,33,33,17,3,20,41,1,17,33,49,49,33,21,32,37,33,5,35,33,17,1,33,0]

def active45847 : List Nat := [0,1,2,3,4]

def tree45847 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45847 : H12WitnessSearch.Good tree45847 := H12GlobalWitnessIndex.good

theorem leafIdentity45847 : H12AffineFastState.composeSystem env45847 rootObs = leafEnv45847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45847 rootObs == leafEnv45847) = true)

theorem terminalChecked45847 : H12PackedTerminal.terminalCheckFast leafEnv45847 active45847 tree45847 = true := by decide +kernel

def env45848 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,40,1045,1,34,1028,2048,1025,0,32,33,17,3,41,17,2048,1029,48,2048,1056,32,37,33,1045,513]

theorem envBound45848 : H12AffineFastState.Bounded env45848 := by
  intro p hp
  have h : env45848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45841_45848 : H12AffineEnvironment.transform 11 49 env45841 = env45848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env45841 == env45848) = true)

theorem identity45848 : scanCanonicalize (H12AffineFastState.compose env45848 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound45848 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45849 : List Nat := [2,4,8,16,32,16,9,36,512,1024,561,49,40,1045,1,34,1028,561,1025,0,32,33,17,3,41,17,561,1029,48,561,1056,32,37,33,1045,513]

theorem envBound45849 : H12AffineFastState.Bounded env45849 := by
  intro p hp
  have h : env45849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45848_45849 : H12AffineEnvironment.transform 10 561 env45848 = env45849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env45848 == env45849) = true)

def env45850 : List Nat := [2,4,8,16,32,16,9,36,512,52,561,49,40,33,1,34,48,561,53,0,32,33,17,3,41,17,561,49,48,561,20,32,37,33,33,513]

theorem envBound45850 : H12AffineFastState.Bounded env45850 := by
  intro p hp
  have h : env45850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45849_45850 : H12AffineEnvironment.transform 9 52 env45849 = env45850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45849 == env45850) = true)

theorem identity45850 : scanCanonicalize (H12AffineFastState.compose env45850 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound45850 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45851 : List Nat := [2,4,8,16,26,16,9,30,512,14,523,11,18,27,1,24,10,523,15,0,26,27,17,3,19,17,523,11,10,523,20,26,31,27,27,513]

theorem envBound45851 : H12AffineFastState.Bounded env45851 := by
  intro p hp
  have h : env45851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45850_45851 : H12AffineEnvironment.transform 4 26 env45850 = env45851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env45850 == env45851) = true)

def leafEnv45851 : List Nat := [2,4,8,16,26,16,9,30,512,14,523,11,18,27,1,24,10,523,15,0,26,27,17,3,21,19,1,17,523,11,10,523,20,26,31,27,5,25,27,513,1,26,0]

def active45851 : List Nat := [0,1,2,3,8]

def tree45851 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45851 : H12WitnessSearch.Good tree45851 := H12GlobalWitnessIndex.good

theorem leafIdentity45851 : H12AffineFastState.composeSystem env45851 rootObs = leafEnv45851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45851 rootObs == leafEnv45851) = true)

theorem terminalChecked45851 : H12PackedTerminal.terminalCheckFast leafEnv45851 active45851 tree45851 = true := by decide +kernel

def env45852 : List Nat := [2,4,8,16,32,16,9,36,512,53,561,49,40,32,1,34,49,561,52,0,32,33,17,3,41,17,561,48,48,561,21,32,37,33,32,513]

theorem envBound45852 : H12AffineFastState.Bounded env45852 := by
  intro p hp
  have h : env45852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45849_45852 : H12AffineEnvironment.transform 9 53 env45849 = env45852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45849 == env45852) = true)

theorem identity45852 : scanCanonicalize (H12AffineFastState.compose env45852 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound45852 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45853 : List Nat := [2,4,8,16,32,16,9,36,17,53,32,49,40,32,1,34,49,32,52,0,32,33,17,3,41,17,32,48,48,32,21,32,37,33,32,16]

theorem envBound45853 : H12AffineFastState.Bounded env45853 := by
  intro p hp
  have h : env45853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45852_45853 : H12AffineEnvironment.transform 8 17 env45852 = env45853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env45852 == env45853) = true)

def leafEnv45853 : List Nat := [2,4,8,16,32,16,9,36,17,53,32,49,40,32,1,34,49,32,52,0,32,33,17,3,20,41,1,17,32,48,48,32,21,32,37,33,5,35,32,16,1,32,0]

def active45853 : List Nat := [0,1,2,3,4]

def tree45853 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45853 : H12WitnessSearch.Good tree45853 := H12GlobalWitnessIndex.good

theorem leafIdentity45853 : H12AffineFastState.composeSystem env45853 rootObs = leafEnv45853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45853 rootObs == leafEnv45853) = true)

theorem terminalChecked45853 : H12PackedTerminal.terminalCheckFast leafEnv45853 active45853 tree45853 = true := by decide +kernel

def env45854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356289,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound45854 : H12AffineFastState.Bounded env45854 := by
  intro p hp
  have h : env45854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45496_45854 : H12AffineEnvironment.transform 26 30393345 env45496 = env45854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env45496 == env45854) = true)

def env45855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound45855 : H12AffineFastState.Bounded env45855 := by
  intro p hp
  have h : env45855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45854_45855 : H12AffineEnvironment.transform 18 1024 env45854 = env45855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env45854 == env45855) = true)

theorem identity45855 : scanCanonicalize (H12AffineFastState.compose env45855 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10923490) := by decide +kernel

theorem selectedBound45855 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env45856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10923490,8328,65,6385123,8857967,10507601,8830977,2566643,13092899,256,485710,493803,2493988]

theorem envBound45856 : H12AffineFastState.Bounded env45856 := by
  intro p hp
  have h : env45856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45855_45856 : H12AffineEnvironment.transform 23 10923490 env45855 = env45856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10923490 env45855 == env45856) = true)

def env45857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452768,2114882,8328,65,6385123,115151,2538993,10401,2566643,4268163,256,485710,493803,2493988]

theorem envBound45857 : H12AffineFastState.Bounded env45857 := by
  intro p hp
  have h : env45857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45856_45857 : H12AffineEnvironment.transform 22 452768 env45856 = env45857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env45856 == env45857) = true)

def env45858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452768,441778,8328,65,4691219,115151,17665,10401,119043,4268163,256,485710,493803,63188]

theorem envBound45858 : H12AffineFastState.Bounded env45858 := by
  intro p hp
  have h : env45858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45857_45858 : H12AffineEnvironment.transform 20 456944 env45857 = env45858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456944 env45857 == env45858) = true)

def env45859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452768,441778,8328,65,245139,115151,17665,10401,119043,329731,256,485710,493803,63188]

theorem envBound45859 : H12AffineFastState.Bounded env45859 := by
  intro p hp
  have h : env45859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45858_45859 : H12AffineEnvironment.transform 21 272512 env45858 = env45859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45858 == env45859) = true)

theorem identity45859 : scanCanonicalize (H12AffineFastState.compose env45859 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247995) := by decide +kernel

theorem selectedBound45859 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,77899,254011,73755,95497,8328,65,245139,115151,17665,10401,119043,180408,256,41461,16464,63188]

theorem envBound45860 : H12AffineFastState.Bounded env45860 := by
  intro p hp
  have h : env45860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45859_45860 : H12AffineEnvironment.transform 17 247995 env45859 = env45860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247995 env45859 == env45860) = true)

def env45861 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247963,1024,32769,77899,253979,73755,95497,8328,65,245139,115151,17665,10369,119043,180376,256,41429,16464,63188]

theorem envBound45861 : H12AffineFastState.Bounded env45861 := by
  intro p hp
  have h : env45861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45860_45861 : H12AffineEnvironment.transform 4 0 env45860 = env45861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45860 == env45861) = true)

theorem identity45861 : scanCanonicalize (H12AffineFastState.compose env45861 (packedSelected [0,2,3,4,6,7,11,14,15,22,24,26,31,32,35,38] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound45861 : packedSelected [0,2,3,4,6,7,11,14,15,22,24,26,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env45862 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,21896,65536,131072,204051,1024,21897,77899,210323,73755,95497,8328,65,223259,70727,17665,10369,66699,136464,256,29789,16464,9052]

theorem envBound45862 : H12AffineFastState.Bounded env45862 := by
  intro p hp
  have h : env45862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45861_45862 : H12AffineEnvironment.transform 14 21896 env45861 = env45862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env45861 == env45862) = true)

theorem identity45862 : scanCanonicalize (H12AffineFastState.compose env45862 (packedSelected [1,2,3,4,5,6,7,8,9,11,12,16,17,19,20,27,31,32,41] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound45862 : packedSelected [1,2,3,4,5,6,7,8,9,11,12,16,17,19,20,27,31,32,41] rootPS < 2^1333 := by decide +kernel

def env45863 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,21896,478,131072,138445,1024,21897,12693,144461,8645,29911,8328,65,158149,5529,17665,10369,1365,136464,256,29789,16464,9052]

theorem envBound45863 : H12AffineFastState.Bounded env45863 := by
  intro p hp
  have h : env45863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45862_45863 : H12AffineEnvironment.transform 15 478 env45862 = env45863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env45862 == env45863) = true)

theorem identity45863 : scanCanonicalize (H12AffineFastState.compose env45863 (packedSelected [1,5,8,16,17,19,20,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound45863 : packedSelected [1,5,8,16,17,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env45864 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,468,16384,21896,478,131072,138445,1024,21897,4161,136601,17,21763,348,65,149521,5529,17665,2389,1365,136464,256,21897,16464,648]

theorem envBound45864 : H12AffineFastState.Bounded env45864 := by
  intro p hp
  have h : env45864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45863_45864 : H12AffineEnvironment.transform 12 468 env45863 = env45864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env45863 == env45864) = true)

theorem identity45864 : scanCanonicalize (H12AffineFastState.compose env45864 (packedSelected [0,2,6,7,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound45864 : packedSelected [0,2,6,7,16,17] rootPS < 2^1333 := by decide +kernel

def env45865 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,468,16384,21896,478,16401,23772,1024,21897,4161,21896,17,21763,348,65,2048,5529,17665,2389,1365,21761,256,21897,16464,648]

theorem envBound45865 : H12AffineFastState.Bounded env45865 := by
  intro p hp
  have h : env45865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45864_45865 : H12AffineEnvironment.transform 16 16401 env45864 = env45865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env45864 == env45865) = true)

theorem identity45865 : scanCanonicalize (H12AffineFastState.compose env45865 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound45865 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45866 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,468,5376,136,478,5393,2524,1024,137,4161,136,17,3,348,65,2048,5529,4097,2389,1365,1,256,137,5456,648]

theorem envBound45866 : H12AffineFastState.Bounded env45866 := by
  intro p hp
  have h : env45866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45865_45866 : H12AffineEnvironment.transform 13 5376 env45865 = env45866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45865 == env45866) = true)

theorem identity45866 : scanCanonicalize (H12AffineFastState.compose env45866 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45866 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45867 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,349,5376,1,343,5393,2389,1024,0,4161,1,17,3,348,65,2048,5392,4097,2389,1365,1,256,0,5456,513]

theorem envBound45867 : H12AffineFastState.Bounded env45867 := by
  intro p hp
  have h : env45867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45866_45867 : H12AffineEnvironment.transform 6 9 env45866 = env45867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45866 == env45867) = true)

theorem identity45867 : scanCanonicalize (H12AffineFastState.compose env45867 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound45867 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45868 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8,5205,1,2,5188,2048,1024,0,4161,1,17,3,9,65,2048,5189,4097,2048,1024,1,85,0,5125,513]

theorem envBound45868 : H12AffineFastState.Bounded env45868 := by
  intro p hp
  have h : env45868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45867_45868 : H12AffineEnvironment.transform 7 85 env45867 = env45868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env45867 == env45868) = true)

theorem identity45868 : scanCanonicalize (H12AffineFastState.compose env45868 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45868 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45869 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,8,5125,1,2,5140,2048,1024,0,4113,1,17,3,9,17,2048,5141,4097,2048,1024,1,5,0,5125,513]

theorem envBound45869 : H12AffineFastState.Bounded env45869 := by
  intro p hp
  have h : env45869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45868_45869 : H12AffineEnvironment.transform 5 16 env45868 = env45869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45868 == env45869) = true)

def env45870 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,16,8,1045,1,2,1028,2048,1024,0,1,1,17,3,9,17,2048,1029,17,2048,1024,1,5,0,1045,513]

theorem envBound45870 : H12AffineFastState.Bounded env45870 := by
  intro p hp
  have h : env45870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45869_45870 : H12AffineEnvironment.transform 11 16 env45869 = env45870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env45869 == env45870) = true)

theorem identity45870 : scanCanonicalize (H12AffineFastState.compose env45870 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound45870 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45871 : List Nat := [2,4,8,16,0,16,9,5,512,1024,1541,16,8,1045,1,2,1028,1541,1024,0,1,1,17,3,9,17,1541,1029,17,1541,1024,1,5,0,1045,513]

theorem envBound45871 : H12AffineFastState.Bounded env45871 := by
  intro p hp
  have h : env45871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45870_45871 : H12AffineEnvironment.transform 10 1541 env45870 = env45871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env45870 == env45871) = true)

def env45872 : List Nat := [2,4,8,16,0,16,9,5,512,20,529,16,8,1,1,2,16,529,20,0,1,1,17,3,9,17,529,17,17,529,20,1,5,0,1,513]

theorem envBound45872 : H12AffineFastState.Bounded env45872 := by
  intro p hp
  have h : env45872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45871_45872 : H12AffineEnvironment.transform 9 20 env45871 = env45872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env45871 == env45872) = true)

theorem identity45872 : scanCanonicalize (H12AffineFastState.compose env45872 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound45872 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45873 : List Nat := [2,4,8,10,0,10,9,5,512,14,523,10,8,1,1,2,10,523,14,0,1,1,11,3,9,11,523,11,11,523,14,1,5,0,1,513]

theorem envBound45873 : H12AffineFastState.Bounded env45873 := by
  intro p hp
  have h : env45873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45872_45873 : H12AffineEnvironment.transform 3 10 env45872 = env45873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env45872 == env45873) = true)

def leafEnv45873 : List Nat := [2,4,8,10,0,10,9,5,512,14,523,10,8,1,1,2,10,523,14,0,1,1,11,3,14,9,1,11,523,11,11,523,14,1,5,0,4,3,1,513,1,1,0]

def active45873 : List Nat := [0,1,2,8]

def tree45873 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45873 : H12WitnessSearch.Good tree45873 := H12GlobalWitnessIndex.good

end H12CloudChart1