import H12CloudChart1Data127

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env32478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound32478 : H12AffineFastState.Bounded env32478 := by
  intro p hp
  have h : env32478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32299_32478 : H12AffineEnvironment.transform 18 1025 env32299 = env32478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env32299 == env32478) = true)

theorem identity32478 : scanCanonicalize (H12AffineFastState.compose env32478 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 140301) := by decide +kernel

theorem selectedBound32478 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env32479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,4194304,8388608,16777216,8328,64,29868032,17014912,8548701,8830976,25265168,21184972,257,25419936,25362692,25207751]

theorem envBound32479 : H12AffineFastState.Bounded env32479 := by
  intro p hp
  have h : env32479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32478_32479 : H12AffineEnvironment.transform 20 140301 env32478 = env32479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 140301 env32478 == env32479) = true)

def env32480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,4194304,8388608,8631680,8328,64,4486528,8393984,8548701,8830976,143760,12645452,257,21792,46212,202311]

theorem envBound32480 : H12AffineFastState.Bounded env32480 := by
  intro p hp
  have h : env32480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32479_32480 : H12AffineEnvironment.transform 23 8631680 env32479 = env32480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8631680 env32479 == env32480) = true)

def env32481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,4194304,180360,95496,8328,64,4486528,185736,45525,262280,143760,4338884,257,21792,46212,202311]

theorem envBound32481 : H12AffineFastState.Bounded env32481 := by
  intro p hp
  have h : env32481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32480_32481 : H12AffineEnvironment.transform 22 180360 env32480 = env32481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env32480 == env32481) = true)

def env32482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272512,180360,95496,8328,64,23808,185736,45525,262280,143760,400452,257,21792,46212,202311]

theorem envBound32482 : H12AffineFastState.Bounded env32482 := by
  intro p hp
  have h : env32482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32481_32482 : H12AffineEnvironment.transform 21 272512 env32481 = env32482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env32481 == env32482) = true)

theorem identity32482 : scanCanonicalize (H12AffineFastState.compose env32482 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound32482 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77899,272512,120014,95496,8328,64,23808,115150,45525,262280,75222,329730,257,21792,46212,513]

theorem envBound32483 : H12AffineFastState.Bounded env32483 := by
  intro p hp
  have h : env32483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32482_32483 : H12AffineEnvironment.transform 16 70726 env32482 = env32483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env32482 == env32483) = true)

def env32484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77899,272392,119878,95496,8192,64,23808,115014,45405,262144,75102,329730,257,21792,46092,513]

theorem envBound32484 : H12AffineFastState.Bounded env32484 := by
  intro p hp
  have h : env32484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32483_32484 : H12AffineEnvironment.transform 6 8 env32483 = env32484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32483 == env32484) = true)

theorem identity32484 : scanCanonicalize (H12AffineFastState.compose env32484 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound32484 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env32485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,65536,70726,262144,1025,32769,77899,272392,106523,65877,8192,64,10589,111899,45405,262144,75102,329730,257,8573,46092,513]

theorem envBound32485 : H12AffineFastState.Bounded env32485 := by
  intro p hp
  have h : env32485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32484_32485 : H12AffineEnvironment.transform 13 13405 env32484 = env32485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env32484 == env32485) = true)

theorem identity32485 : scanCanonicalize (H12AffineFastState.compose env32485 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 100466) := by decide +kernel

theorem selectedBound32485 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env32486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,65536,70726,100466,1025,32769,77899,106618,106523,65877,8192,64,10589,111899,45405,100466,75102,32880,257,8573,46092,513]

theorem envBound32486 : H12AffineFastState.Bounded env32486 := by
  intro p hp
  have h : env32486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32485_32486 : H12AffineEnvironment.transform 17 100466 env32485 = env32486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100466 env32485 == env32486) = true)

theorem identity32486 : scanCanonicalize (H12AffineFastState.compose env32486 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound32486 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env32487 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,33111,38161,2341,1025,32769,45340,8493,8524,32770,8192,64,10589,13388,45405,2341,41993,32880,257,8573,46092,513]

theorem envBound32487 : H12AffineFastState.Bounded env32487 := by
  intro p hp
  have h : env32487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32486_32487 : H12AffineEnvironment.transform 15 33111 env32486 = env32487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env32486 == env32487) = true)

theorem identity32487 : scanCanonicalize (H12AffineFastState.compose env32487 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 1076) := by decide +kernel

theorem selectedBound32487 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env32488 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1076,1379,4389,2341,1025,1077,13608,8493,8524,1078,8192,64,10589,13388,13673,2341,8253,1092,257,8573,12344,513]

theorem envBound32488 : H12AffineFastState.Bounded env32488 := by
  intro p hp
  have h : env32488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32487_32488 : H12AffineEnvironment.transform 14 1076 env32487 = env32488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1076 env32487 == env32488) = true)

theorem identity32488 : scanCanonicalize (H12AffineFastState.compose env32488 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32488 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env32489 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1076,1331,4389,2341,1025,1077,13608,8493,8476,1078,8192,16,10509,13340,13625,2341,8253,1044,257,8493,12344,513]

theorem envBound32489 : H12AffineFastState.Bounded env32489 := by
  intro p hp
  have h : env32489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32488_32489 : H12AffineEnvironment.transform 5 16 env32488 = env32489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32488 == env32489) = true)

theorem identity32489 : scanCanonicalize (H12AffineFastState.compose env32489 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound32489 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32490 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,8192,12345,0,263,4389,2341,53,1,12572,8493,8476,2,8192,16,10509,12328,12557,2341,8253,32,257,8493,12344,513]

theorem envBound32490 : H12AffineFastState.Bounded env32490 := by
  intro p hp
  have h : env32490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32489_32490 : H12AffineEnvironment.transform 9 52 env32489 = env32490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32489 == env32490) = true)

theorem identity32490 : scanCanonicalize (H12AffineFastState.compose env32490 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound32490 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env32491 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,512,8192,8761,0,263,805,2341,53,1,8988,8493,8476,2,8192,16,10509,8744,8973,2341,8253,32,257,8493,8760,513]

theorem envBound32491 : H12AffineFastState.Bounded env32491 := by
  intro p hp
  have h : env32491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32490_32491 : H12AffineEnvironment.transform 11 512 env32490 = env32491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env32490 == env32491) = true)

theorem identity32491 : scanCanonicalize (H12AffineFastState.compose env32491 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound32491 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32492 : List Nat := [2,4,8,16,32,16,8,256,512,52,821,512,8192,8761,0,263,805,528,53,1,8988,8493,8476,2,8192,16,8760,8744,8973,528,8253,32,257,8493,8760,513]

theorem envBound32492 : H12AffineFastState.Bounded env32492 := by
  intro p hp
  have h : env32492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32491_32492 : H12AffineEnvironment.transform 10 821 env32491 = env32492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env32491 == env32492) = true)

def env32493 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77899,272393,119879,95496,8193,64,23808,115015,45404,262145,75103,329730,257,21792,46093,513]

theorem envBound32493 : H12AffineFastState.Bounded env32493 := by
  intro p hp
  have h : env32493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32483_32493 : H12AffineEnvironment.transform 6 9 env32483 = env32493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32483 == env32493) = true)

def env32494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272513,180360,95496,8328,64,23809,185736,45525,262280,143760,400453,257,21792,46212,202311]

theorem envBound32494 : H12AffineFastState.Bounded env32494 := by
  intro p hp
  have h : env32494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32481_32494 : H12AffineEnvironment.transform 21 272513 env32481 = env32494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env32481 == env32494) = true)

theorem identity32494 : scanCanonicalize (H12AffineFastState.compose env32494 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound32494 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,140301,272513,180360,41431,8328,64,23809,185736,45525,262280,143760,400453,257,21792,46212,180888]

theorem envBound32495 : H12AffineFastState.Bounded env32495 := by
  intro p hp
  have h : env32495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32494_32495 : H12AffineEnvironment.transform 15 54495 env32494 = env32495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env32494 == env32495) = true)

def env32496 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,140301,272393,180224,41311,8192,64,23809,185600,45405,262144,143640,400453,257,21792,46092,180752]

theorem envBound32496 : H12AffineFastState.Bounded env32496 := by
  intro p hp
  have h : env32496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32495_32496 : H12AffineEnvironment.transform 6 8 env32495 = env32496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32495 == env32496) = true)

theorem identity32496 : scanCanonicalize (H12AffineFastState.compose env32496 (packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 49460) := by decide +kernel

theorem selectedBound32496 : packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env32497 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49460,262144,1025,32769,58681,272393,308,41311,8192,64,23809,5172,45405,262144,61484,318833,257,21792,46092,804]

theorem envBound32497 : H12AffineFastState.Bounded env32497 := by
  intro p hp
  have h : env32497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32496_32497 : H12AffineEnvironment.transform 16 49460 env32496 = env32497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49460 env32496 == env32497) = true)

theorem identity32497 : scanCanonicalize (H12AffineFastState.compose env32497 (packedSelected [2,3,5,6,9,12,14,15,16,17,18,20,22,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound32497 : packedSelected [2,3,5,6,9,12,14,15,16,17,18,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env32498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,293,21874,16401,262144,1025,292,25628,272393,308,8314,8192,64,23809,5172,12408,262144,28937,285780,257,21792,13609,804]

theorem envBound32498 : H12AffineFastState.Bounded env32498 := by
  intro p hp
  have h : env32498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32497_32498 : H12AffineEnvironment.transform 14 293 env32497 = env32498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env32497 == env32498) = true)

theorem identity32498 : scanCanonicalize (H12AffineFastState.compose env32498 (packedSelected [3,4,9,10,14,17,19,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound32498 : packedSelected [3,4,9,10,14,17,19,20,24] rootPS < 2^1333 := by decide +kernel

def env32499 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,293,21874,16401,262144,1025,292,17509,264304,308,3,121,64,23809,5172,4097,262144,20848,285780,257,21792,5456,804]

theorem envBound32499 : H12AffineFastState.Bounded env32499 := by
  intro p hp
  have h : env32499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32498_32499 : H12AffineEnvironment.transform 12 121 env32498 = env32499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env32498 == env32499) = true)

theorem identity32499 : scanCanonicalize (H12AffineFastState.compose env32499 (packedSelected [16,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32499 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env32500 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,1,21590,16401,262144,1025,0,17509,264304,16,3,121,64,23589,5172,4097,262144,20564,285780,37,21508,5236,512]

theorem envBound32500 : H12AffineFastState.Bounded env32500 := by
  intro p hp
  have h : env32500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32499_32500 : H12AffineEnvironment.transform 7 36 env32499 = env32500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32499 == env32500) = true)

theorem identity32500 : scanCanonicalize (H12AffineFastState.compose env32500 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5204) := by decide +kernel

theorem selectedBound32500 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32501 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,5204,1,2,5189,262144,1025,0,4145,264304,16,3,121,64,2161,5172,4097,262144,1024,264192,37,80,5236,512]

theorem envBound32501 : H12AffineFastState.Bounded env32501 := by
  intro p hp
  have h : env32501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32500_32501 : H12AffineEnvironment.transform 13 5204 env32500 = env32501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5204 env32500 == env32501) = true)

theorem identity32501 : scanCanonicalize (H12AffineFastState.compose env32501 (packedSelected [0,7,16] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound32501 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env32502 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,5204,1,2,5189,2048,1025,0,4145,112,16,3,121,64,2161,5172,4097,2048,1024,0,37,80,5236,512]

theorem envBound32502 : H12AffineFastState.Bounded env32502 := by
  intro p hp
  have h : env32502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32501_32502 : H12AffineEnvironment.transform 17 2048 env32501 = env32502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env32501 == env32502) = true)

theorem identity32502 : scanCanonicalize (H12AffineFastState.compose env32502 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound32502 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32503 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,9,5156,1,2,5173,2048,1025,0,4145,0,16,3,9,48,2049,5172,4097,2048,1024,0,37,32,5124,512]

theorem envBound32503 : H12AffineFastState.Bounded env32503 := by
  intro p hp
  have h : env32503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32502_32503 : H12AffineEnvironment.transform 5 48 env32502 = env32503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env32502 == env32503) = true)

theorem identity32503 : scanCanonicalize (H12AffineFastState.compose env32503 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound32503 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32504 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,529,9,1589,1,2,1572,2048,1025,0,544,0,16,3,9,48,2049,1573,528,2048,1024,0,37,32,1557,512]

theorem envBound32504 : H12AffineFastState.Bounded env32504 := by
  intro p hp
  have h : env32504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32503_32504 : H12AffineEnvironment.transform 11 529 env32503 = env32504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env32503 == env32504) = true)

theorem identity32504 : scanCanonicalize (H12AffineFastState.compose env32504 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound32504 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32505 : List Nat := [2,4,8,16,32,48,8,36,512,1024,529,529,9,1589,1,2,1572,529,1025,0,544,0,16,3,9,48,528,1573,528,529,1024,0,37,32,1557,512]

theorem envBound32505 : H12AffineFastState.Bounded env32505 := by
  intro p hp
  have h : env32505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32504_32505 : H12AffineEnvironment.transform 10 529 env32504 = env32505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env32504 == env32505) = true)

theorem identity32505 : scanCanonicalize (H12AffineFastState.compose env32505 (packedSelected [5,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32505 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32506 : List Nat := [2,4,8,1,32,33,8,36,512,1024,512,512,9,1572,1,2,1572,512,1025,0,544,0,1,3,9,33,513,1573,513,512,1024,0,37,32,1540,512]

theorem envBound32506 : H12AffineFastState.Bounded env32506 := by
  intro p hp
  have h : env32506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32505_32506 : H12AffineEnvironment.transform 3 1 env32505 = env32506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32505 == env32506) = true)

theorem identity32506 : scanCanonicalize (H12AffineFastState.compose env32506 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound32506 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env32507 : List Nat := [2,4,8,1,32,33,8,36,512,36,512,512,9,512,1,2,512,512,37,0,544,0,1,3,9,33,513,513,513,512,36,0,37,32,544,512]

theorem envBound32507 : H12AffineFastState.Bounded env32507 := by
  intro p hp
  have h : env32507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32506_32507 : H12AffineEnvironment.transform 9 36 env32506 = env32507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env32506 == env32507) = true)

theorem identity32507 : scanCanonicalize (H12AffineFastState.compose env32507 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound32507 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32508 : List Nat := [2,4,8,1,14,15,8,10,512,10,512,512,9,512,1,2,512,512,11,0,526,0,1,3,9,15,513,513,513,512,10,0,11,14,526,512]

theorem envBound32508 : H12AffineFastState.Bounded env32508 := by
  intro p hp
  have h : env32508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32507_32508 : H12AffineEnvironment.transform 4 14 env32507 = env32508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env32507 == env32508) = true)

theorem identity32508 : scanCanonicalize (H12AffineFastState.compose env32508 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound32508 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32509 : List Nat := [2,4,7,1,1,0,7,5,512,5,512,512,6,512,1,2,512,512,4,0,513,0,1,3,6,0,513,513,513,512,5,0,4,1,513,512]

theorem envBound32509 : H12AffineFastState.Bounded env32509 := by
  intro p hp
  have h : env32509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32508_32509 : H12AffineEnvironment.transform 2 7 env32508 = env32509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env32508 == env32509) = true)

theorem identity32509 : scanCanonicalize (H12AffineFastState.compose env32509 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32509 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32510 : List Nat := [2,4,7,1,1,0,7,5,1,5,1,1,6,1,1,2,1,1,4,0,0,0,1,3,6,0,0,0,0,1,5,0,4,1,0,1]

theorem envBound32510 : H12AffineFastState.Bounded env32510 := by
  intro p hp
  have h : env32510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32509_32510 : H12AffineEnvironment.transform 8 1 env32509 = env32510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32509 == env32510) = true)

def env32511 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,140301,272392,180225,41310,8193,64,23809,185601,45404,262145,143641,400453,257,21792,46093,180753]

theorem envBound32511 : H12AffineFastState.Bounded env32511 := by
  intro p hp
  have h : env32511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32495_32511 : H12AffineEnvironment.transform 6 9 env32495 = env32511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32495 == env32511) = true)

theorem identity32511 : scanCanonicalize (H12AffineFastState.compose env32511 (packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 157801) := by decide +kernel

theorem selectedBound32511 : packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env32512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,157801,1025,32769,140301,147553,180225,41310,8193,64,23809,185601,45404,157800,143641,29740,257,21792,46093,180753]

theorem envBound32512 : H12AffineFastState.Bounded env32512 := by
  intro p hp
  have h : env32512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32511_32512 : H12AffineEnvironment.transform 17 157801 env32511 = env32512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157801 env32511 == env32512) = true)

theorem identity32512 : scanCanonicalize (H12AffineFastState.compose env32512 (packedSelected [0,3,4,5,12,14,15,16,18,22,23,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound32512 : packedSelected [0,3,4,5,12,14,15,16,18,22,23,27,31] rootPS < 2^1333 := by decide +kernel

def env32513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,43129,1025,32769,58397,32881,17,41310,8193,64,23809,5393,45404,43128,61705,29740,257,21792,46093,513]

theorem envBound32513 : H12AffineFastState.Bounded env32513 := by
  intro p hp
  have h : env32513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32512_32513 : H12AffineEnvironment.transform 16 49168 env32512 = env32513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env32512 == env32513) = true)

theorem identity32513 : scanCanonicalize (H12AffineFastState.compose env32513 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound32513 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,21511,16449,10280,1025,80,25676,32,17,8463,8193,64,23809,5393,12557,10281,29016,29740,257,21792,13404,513]

theorem envBound32514 : H12AffineFastState.Bounded env32514 := by
  intro p hp
  have h : env32514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32513_32514 : H12AffineEnvironment.transform 14 81 env32513 = env32514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env32513 == env32514) = true)

theorem identity32514 : scanCanonicalize (H12AffineFastState.compose env32514 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound32514 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env32515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,81,263,5441,10280,1025,80,12620,32,17,8463,8193,64,2049,5393,12557,10281,9304,8492,257,32,13404,513]

theorem envBound32515 : H12AffineFastState.Bounded env32515 := by
  intro p hp
  have h : env32515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32514_32515 : H12AffineEnvironment.transform 13 5376 env32514 = env32515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env32514 == env32515) = true)

theorem identity32515 : scanCanonicalize (H12AffineFastState.compose env32515 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32515 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,81,263,5441,2421,1025,80,4113,32,17,82,348,64,2049,5393,4176,2420,1285,113,257,32,5377,513]

theorem envBound32516 : H12AffineFastState.Bounded env32516 := by
  intro p hp
  have h : env32516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32515_32516 : H12AffineEnvironment.transform 12 349 env32515 = env32516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32515 == env32516) = true)

theorem identity32516 : scanCanonicalize (H12AffineFastState.compose env32516 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound32516 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env32517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,349,2048,81,263,2113,2421,1025,80,3345,32,17,82,348,64,2049,2065,3408,2420,1285,113,257,32,2049,513]

theorem envBound32517 : H12AffineFastState.Bounded env32517 := by
  intro p hp
  have h : env32517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32516_32517 : H12AffineEnvironment.transform 11 3328 env32516 = env32517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env32516 == env32517) = true)

theorem identity32517 : scanCanonicalize (H12AffineFastState.compose env32517 (packedSelected [0,3,5,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32517 : packedSelected [0,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env32518 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3328,268,2048,0,263,2064,2340,1025,1,3345,32,17,3,269,17,2049,2065,3329,2341,1285,32,257,32,2049,513]

theorem envBound32518 : H12AffineFastState.Bounded env32518 := by
  intro p hp
  have h : env32518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32517_32518 : H12AffineEnvironment.transform 5 17 env32517 = env32518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32517 == env32518) = true)

theorem identity32518 : scanCanonicalize (H12AffineFastState.compose env32518 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound32518 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32519 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1,1281,268,1,0,263,17,293,1025,1,1296,32,17,3,269,17,0,16,1280,292,1285,32,257,32,0,513]

theorem envBound32519 : H12AffineFastState.Bounded env32519 := by
  intro p hp
  have h : env32519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32518_32519 : H12AffineEnvironment.transform 10 1 env32518 = env32519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env32518 == env32519) = true)

def env32520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,4194304,180361,95497,8328,64,4486528,185737,45524,262281,143760,4338885,257,21792,46212,202311]

theorem envBound32520 : H12AffineFastState.Bounded env32520 := by
  intro p hp
  have h : env32520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32480_32520 : H12AffineEnvironment.transform 22 180361 env32480 = env32520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env32480 == env32520) = true)

def env32521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272512,180361,95497,8328,64,23808,185737,45524,262281,143760,400453,257,21792,46212,202311]

theorem envBound32521 : H12AffineFastState.Bounded env32521 := by
  intro p hp
  have h : env32521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32520_32521 : H12AffineEnvironment.transform 21 272512 env32520 = env32521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env32520 == env32521) = true)

theorem identity32521 : scanCanonicalize (H12AffineFastState.compose env32521 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123027) := by decide +kernel

theorem selectedBound32521 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,115870,272512,73754,95497,8328,64,23808,79130,45524,262281,119043,392406,257,21792,46212,63188]

theorem envBound32522 : H12AffineFastState.Bounded env32522 := by
  intro p hp
  have h : env32522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32521_32522 : H12AffineEnvironment.transform 16 123027 env32521 = env32522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123027 env32521 == env32522) = true)

def env32523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10400,1025,32769,115870,32,73754,95497,8328,64,23808,79130,45524,10281,119043,119926,257,21792,46212,63188]

theorem envBound32523 : H12AffineFastState.Bounded env32523 := by
  intro p hp
  have h : env32523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32522_32523 : H12AffineEnvironment.transform 17 10400 env32522 = env32523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env32522 == env32523) = true)

theorem identity32523 : scanCanonicalize (H12AffineFastState.compose env32523 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 41091) := by decide +kernel

theorem selectedBound32523 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env32524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41091,16400,10400,1025,32769,25629,32,32921,54666,8328,64,23808,38297,45524,10281,29056,29941,257,21792,46212,63188]

theorem envBound32524 : H12AffineFastState.Bounded env32524 := by
  intro p hp
  have h : env32524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32523_32524 : H12AffineEnvironment.transform 15 41091 env32523 = env32524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41091 env32523 == env32524) = true)

theorem identity32524 : scanCanonicalize (H12AffineFastState.compose env32524 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound32524 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env32525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,41091,13389,10400,1025,32769,4160,32,32921,41431,8328,64,10589,38297,45524,10281,1501,168,257,8573,46212,33417]

theorem envBound32525 : H12AffineFastState.Bounded env32525 := by
  intro p hp
  have h : env32525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32524_32525 : H12AffineEnvironment.transform 13 13405 env32524 = env32525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env32524 == env32525) = true)

theorem identity32525 : scanCanonicalize (H12AffineFastState.compose env32525 (packedSelected [16,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound32525 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env32526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8660,343,13389,10400,1025,8661,4160,32,8525,3,8328,64,10589,13389,4096,10281,1501,168,257,8573,5456,9053]

theorem envBound32526 : H12AffineFastState.Bounded env32526 := by
  intro p hp
  have h : env32526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32525_32526 : H12AffineEnvironment.transform 14 8660 env32525 = env32526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env32525 == env32526) = true)

theorem identity32526 : scanCanonicalize (H12AffineFastState.compose env32526 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32526 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,343,5392,2557,1025,136,4160,32,16,3,469,64,2048,5392,4096,2420,1501,168,257,32,5456,512]

theorem envBound32527 : H12AffineFastState.Bounded env32527 := by
  intro p hp
  have h : env32527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32526_32527 : H12AffineEnvironment.transform 12 349 env32526 = env32527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32526 == env32527) = true)

theorem identity32527 : scanCanonicalize (H12AffineFastState.compose env32527 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32527 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32528 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,349,5376,137,343,5392,2525,1025,136,4160,0,16,3,469,64,2048,5392,4096,2388,1501,136,257,0,5456,512]

theorem envBound32528 : H12AffineFastState.Bounded env32528 := by
  intro p hp
  have h : env32528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32527_32528 : H12AffineEnvironment.transform 4 0 env32527 = env32528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32527 == env32528) = true)

theorem identity32528 : scanCanonicalize (H12AffineFastState.compose env32528 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound32528 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32529 : List Nat := [2,4,8,16,0,64,128,5,512,1024,2048,4096,88,5125,137,82,5141,2264,1025,136,4160,0,16,3,208,64,2048,5141,4096,2129,1240,136,4,0,5205,512]

theorem envBound32529 : H12AffineFastState.Bounded env32529 := by
  intro p hp
  have h : env32529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32528_32529 : H12AffineEnvironment.transform 7 5 env32528 = env32529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env32528 == env32529) = true)

theorem identity32529 : scanCanonicalize (H12AffineFastState.compose env32529 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 204) := by decide +kernel

theorem selectedBound32529 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32530 : List Nat := [2,4,8,16,0,64,128,5,512,204,2048,4096,88,4297,137,82,4313,2264,205,136,4160,0,16,3,208,64,2048,4313,4096,2129,20,136,4,0,4249,512]

theorem envBound32530 : H12AffineFastState.Bounded env32530 := by
  intro p hp
  have h : env32530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32529_32530 : H12AffineEnvironment.transform 9 204 env32529 = env32530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 204 env32529 == env32530) = true)

theorem identity32530 : scanCanonicalize (H12AffineFastState.compose env32530 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32530 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32531 : List Nat := [2,4,8,16,0,64,9,5,512,69,2048,4096,88,4160,0,82,4176,2129,68,1,4160,0,16,3,89,64,2048,4176,4096,2129,20,1,4,0,4112,512]

theorem envBound32531 : H12AffineFastState.Bounded env32531 := by
  intro p hp
  have h : env32531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32530_32531 : H12AffineEnvironment.transform 6 9 env32530 = env32531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32530 == env32531) = true)

theorem identity32531 : scanCanonicalize (H12AffineFastState.compose env32531 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32531 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32532 : List Nat := [2,4,8,16,0,17,9,5,512,20,2048,4096,9,4113,0,3,4097,2048,21,1,4113,0,16,3,8,17,2048,4097,4096,2048,20,1,4,0,4112,512]

theorem envBound32532 : H12AffineFastState.Bounded env32532 := by
  intro p hp
  have h : env32532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32531_32532 : H12AffineEnvironment.transform 5 17 env32531 = env32532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32531 == env32532) = true)

theorem identity32532 : scanCanonicalize (H12AffineFastState.compose env32532 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2577) := by decide +kernel

theorem selectedBound32532 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32533 : List Nat := [2,4,8,16,0,17,9,5,512,20,2048,2577,9,2560,0,3,2576,2048,21,1,2560,0,16,3,8,17,2048,2576,2577,2048,20,1,4,0,2561,512]

theorem envBound32533 : H12AffineFastState.Bounded env32533 := by
  intro p hp
  have h : env32533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32532_32533 : H12AffineEnvironment.transform 11 2577 env32532 = env32533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2577 env32532 == env32533) = true)

theorem identity32533 : scanCanonicalize (H12AffineFastState.compose env32533 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound32533 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32534 : List Nat := [2,4,8,16,0,17,9,5,20,20,2048,2053,9,2068,0,3,2052,2048,21,1,2068,0,16,3,8,17,2048,2052,2053,2048,20,1,4,0,2069,20]

theorem envBound32534 : H12AffineFastState.Bounded env32534 := by
  intro p hp
  have h : env32534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32533_32534 : H12AffineEnvironment.transform 8 20 env32533 = env32534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env32533 == env32534) = true)

theorem identity32534 : scanCanonicalize (H12AffineFastState.compose env32534 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound32534 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32535 : List Nat := [2,4,8,4,0,5,9,5,0,0,2048,2053,9,2048,0,3,2052,2048,1,1,2048,0,4,3,8,5,2048,2052,2053,2048,0,1,4,0,2049,0]

theorem envBound32535 : H12AffineFastState.Bounded env32535 := by
  intro p hp
  have h : env32535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32534_32535 : H12AffineEnvironment.transform 3 4 env32534 = env32535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env32534 == env32535) = true)

def env32536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10401,1025,32769,115870,33,73754,95497,8328,64,23808,79130,45524,10280,119043,119927,257,21792,46212,63188]

theorem envBound32536 : H12AffineFastState.Bounded env32536 := by
  intro p hp
  have h : env32536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32522_32536 : H12AffineEnvironment.transform 17 10401 env32522 = env32536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env32522 == env32536) = true)

theorem identity32536 : scanCanonicalize (H12AffineFastState.compose env32536 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound32536 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env32537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,478,57677,10401,1025,32769,50496,33,8644,29911,8328,64,23808,13508,45524,10280,53469,54697,257,21792,46212,63188]

theorem envBound32537 : H12AffineFastState.Bounded env32537 := by
  intro p hp
  have h : env32537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32536_32537 : H12AffineEnvironment.transform 15 478 env32536 = env32537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env32536 == env32537) = true)

theorem identity32537 : scanCanonicalize (H12AffineFastState.compose env32537 (packedSelected [0,4,7,14,17,18,19,22,23,26,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound32537 : packedSelected [0,4,7,14,17,18,19,22,23,26,35] rootPS < 2^1333 := by decide +kernel

def env32538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,478,5528,10401,1025,29908,12693,33,8644,29911,8328,64,23808,13508,17665,10280,9224,8572,257,21792,16465,513]

theorem envBound32538 : H12AffineFastState.Bounded env32538 := by
  intro p hp
  have h : env32538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32537_32538 : H12AffineEnvironment.transform 14 29909 env32537 = env32538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env32537 == env32538) = true)

theorem identity32538 : scanCanonicalize (H12AffineFastState.compose env32538 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound32538 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,478,5528,2421,1025,21760,4161,33,16,21763,348,64,23808,5392,17665,2556,1500,168,257,21792,16465,513]

theorem envBound32539 : H12AffineFastState.Bounded env32539 := by
  intro p hp
  have h : env32539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32538_32539 : H12AffineEnvironment.transform 12 468 env32538 = env32539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env32538 == env32539) = true)

theorem identity32539 : scanCanonicalize (H12AffineFastState.compose env32539 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound32539 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env32540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,478,5528,2421,1025,137,4161,33,16,138,348,64,2185,5392,4232,2556,1500,168,257,169,5592,513]

theorem envBound32540 : H12AffineFastState.Bounded env32540 := by
  intro p hp
  have h : env32540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32539_32540 : H12AffineEnvironment.transform 13 5513 env32539 = env32540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env32539 == env32540) = true)

theorem identity32540 : scanCanonicalize (H12AffineFastState.compose env32540 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound32540 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env32541 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,40,5237,136,34,5220,2185,1025,137,4161,33,16,138,160,64,2185,5356,4232,2048,1056,168,253,169,5156,513]

theorem envBound32541 : H12AffineFastState.Bounded env32541 := by
  intro p hp
  have h : env32541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32540_32541 : H12AffineEnvironment.transform 7 252 env32540 = env32541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env32540 == env32541) = true)

theorem identity32541 : scanCanonicalize (H12AffineFastState.compose env32541 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound32541 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32542 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,40,5237,80,34,5220,2129,1025,81,4161,33,16,82,120,64,2129,5172,4176,2048,1056,112,37,113,5156,513]

theorem envBound32542 : H12AffineFastState.Bounded env32542 := by
  intro p hp
  have h : env32542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32541_32542 : H12AffineEnvironment.transform 6 88 env32541 = env32542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env32541 == env32542) = true)

theorem identity32542 : scanCanonicalize (H12AffineFastState.compose env32542 (packedSelected [0,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32542 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env32543 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,1,34,5173,2048,1025,0,4112,33,16,3,41,17,2048,5172,4097,2048,1056,33,37,32,5156,513]

theorem envBound32543 : H12AffineFastState.Bounded env32543 := by
  intro p hp
  have h : env32543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32542_32543 : H12AffineEnvironment.transform 5 17 env32542 = env32543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32542 == env32543) = true)

def env32544 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1044,1,34,1029,2048,1025,0,32,33,16,3,41,17,2048,1028,49,2048,1056,33,37,32,1044,513]

theorem envBound32544 : H12AffineFastState.Bounded env32544 := by
  intro p hp
  have h : env32544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32543_32544 : H12AffineEnvironment.transform 11 48 env32543 = env32544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32543 == env32544) = true)

theorem identity32544 : scanCanonicalize (H12AffineFastState.compose env32544 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound32544 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32545 : List Nat := [2,4,8,16,32,17,9,36,512,1024,528,48,40,1044,1,34,1029,528,1025,0,32,33,16,3,41,17,528,1028,49,528,1056,33,37,32,1044,513]

theorem envBound32545 : H12AffineFastState.Bounded env32545 := by
  intro p hp
  have h : env32545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32544_32545 : H12AffineEnvironment.transform 10 528 env32544 = env32545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env32544 == env32545) = true)

def env32546 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,48,40,32,1,34,49,528,53,0,32,33,16,3,41,17,528,48,49,528,20,33,37,32,32,513]

theorem envBound32546 : H12AffineFastState.Bounded env32546 := by
  intro p hp
  have h : env32546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32545_32546 : H12AffineEnvironment.transform 9 52 env32545 = env32546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32545 == env32546) = true)

def env32547 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,48,40,33,1,34,48,528,52,0,32,33,16,3,41,17,528,49,49,528,21,33,37,32,33,513]

theorem envBound32547 : H12AffineFastState.Bounded env32547 := by
  intro p hp
  have h : env32547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32545_32547 : H12AffineEnvironment.transform 9 53 env32545 = env32547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32545 == env32547) = true)

theorem identity32547 : scanCanonicalize (H12AffineFastState.compose env32547 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound32547 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32548 : List Nat := [2,4,8,16,32,17,9,36,42,53,58,48,40,33,1,34,48,58,52,0,32,33,16,3,41,17,58,49,49,58,21,33,37,32,33,43]

theorem envBound32548 : H12AffineFastState.Bounded env32548 := by
  intro p hp
  have h : env32548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32547_32548 : H12AffineEnvironment.transform 8 42 env32547 = env32548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env32547 == env32548) = true)

def leafEnv32548 : List Nat := [2,4,8,16,32,17,9,36,42,53,58,48,40,33,1,34,48,58,52,0,32,33,16,3,20,41,1,17,58,49,49,58,21,33,37,32,5,35,33,43,1,32,0]

def active32548 : List Nat := [0,1,2,3,4]

def tree32548 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32548 : H12WitnessSearch.Good tree32548 := H12GlobalWitnessIndex.good

theorem leafIdentity32548 : H12AffineFastState.composeSystem env32548 rootObs = leafEnv32548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32548 rootObs == leafEnv32548) = true)

theorem terminalChecked32548 : H12PackedTerminal.terminalCheckFast leafEnv32548 active32548 tree32548 = true := by decide +kernel

def env32549 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1045,1,34,1028,2048,1025,0,33,33,16,3,41,17,2048,1029,48,2048,1056,33,37,32,1045,513]

theorem envBound32549 : H12AffineFastState.Bounded env32549 := by
  intro p hp
  have h : env32549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32543_32549 : H12AffineEnvironment.transform 11 49 env32543 = env32549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env32543 == env32549) = true)

theorem identity32549 : scanCanonicalize (H12AffineFastState.compose env32549 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound32549 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32550 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1573,49,40,1045,1,34,1028,1573,1025,0,33,33,16,3,41,17,1573,1029,48,1573,1056,33,37,32,1045,513]

theorem envBound32550 : H12AffineFastState.Bounded env32550 := by
  intro p hp
  have h : env32550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32549_32550 : H12AffineEnvironment.transform 10 1573 env32549 = env32550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env32549 == env32550) = true)

def env32551 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,49,40,33,1,34,48,529,53,0,33,33,16,3,41,17,529,49,48,529,20,33,37,32,33,513]

theorem envBound32551 : H12AffineFastState.Bounded env32551 := by
  intro p hp
  have h : env32551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32550_32551 : H12AffineEnvironment.transform 9 52 env32550 = env32551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32550 == env32551) = true)

def env32552 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,49,40,32,1,34,49,528,52,0,33,33,16,3,41,17,528,48,48,528,21,33,37,32,32,513]

theorem envBound32552 : H12AffineFastState.Bounded env32552 := by
  intro p hp
  have h : env32552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32550_32552 : H12AffineEnvironment.transform 9 53 env32550 = env32552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32550 == env32552) = true)

theorem identity32552 : scanCanonicalize (H12AffineFastState.compose env32552 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound32552 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32553 : List Nat := [2,4,8,16,32,17,9,36,43,53,59,49,40,32,1,34,49,59,52,0,33,33,16,3,41,17,59,48,48,59,21,33,37,32,32,42]

theorem envBound32553 : H12AffineFastState.Bounded env32553 := by
  intro p hp
  have h : env32553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32552_32553 : H12AffineEnvironment.transform 8 43 env32552 = env32553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env32552 == env32553) = true)

def leafEnv32553 : List Nat := [2,4,8,16,32,17,9,36,43,53,59,49,40,32,1,34,49,59,52,0,33,33,16,3,20,41,1,17,59,48,48,59,21,33,37,32,5,35,32,42,1,33,0]

def active32553 : List Nat := [0,1,2,3,4]

def tree32553 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32553 : H12WitnessSearch.Good tree32553 := H12GlobalWitnessIndex.good

theorem leafIdentity32553 : H12AffineFastState.composeSystem env32553 rootObs = leafEnv32553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32553 rootObs == leafEnv32553) = true)

theorem terminalChecked32553 : H12PackedTerminal.terminalCheckFast leafEnv32553 active32553 tree32553 = true := by decide +kernel

def env32554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272513,180361,95497,8328,64,23809,185737,45524,262281,143760,400452,257,21792,46212,202311]

theorem envBound32554 : H12AffineFastState.Bounded env32554 := by
  intro p hp
  have h : env32554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32520_32554 : H12AffineEnvironment.transform 21 272513 env32520 = env32554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env32520 == env32554) = true)

theorem identity32554 : scanCanonicalize (H12AffineFastState.compose env32554 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32554 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,140301,272513,180361,21762,8328,64,23809,185737,45524,262281,143760,400452,257,21792,46212,144972]

theorem envBound32555 : H12AffineFastState.Bounded env32555 := by
  intro p hp
  have h : env32555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32554_32555 : H12AffineEnvironment.transform 15 8203 env32554 = env32555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32554 == env32555) = true)

def env32556 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,140301,272393,180225,21762,8192,64,23809,185601,45404,262145,143640,400452,257,21792,46092,144972]

theorem envBound32556 : H12AffineFastState.Bounded env32556 := by
  intro p hp
  have h : env32556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32555_32556 : H12AffineEnvironment.transform 6 8 env32555 = env32556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32555 == env32556) = true)

def env32557 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,58397,272393,17,21762,8192,64,23809,5393,45404,262145,61704,318548,257,21792,46092,63068]

theorem envBound32557 : H12AffineFastState.Bounded env32557 := by
  intro p hp
  have h : env32557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32556_32557 : H12AffineEnvironment.transform 16 49168 env32556 = env32557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env32556 == env32557) = true)

theorem identity32557 : scanCanonicalize (H12AffineFastState.compose env32557 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound32557 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32558 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49168,35189,1025,32769,58397,41340,17,21762,8192,64,23809,5393,45404,35188,61704,21793,257,21792,46092,63068]

theorem envBound32558 : H12AffineFastState.Bounded env32558 := by
  intro p hp
  have h : env32558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32557_32558 : H12AffineEnvironment.transform 17 35189 env32557 = env32558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env32557 == env32558) = true)

theorem identity32558 : scanCanonicalize (H12AffineFastState.compose env32558 (packedSelected [0,2,7,9,11,18,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound32558 : packedSelected [0,2,7,9,11,18,20,22] rootPS < 2^1333 := by decide +kernel

def env32559 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8203,5392,23669,1025,21761,12573,29820,17,21762,8192,64,23809,5393,25692,23668,9224,21793,257,21792,24844,9052]

theorem envBound32559 : H12AffineFastState.Bounded env32559 := by
  intro p hp
  have h : env32559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32558_32559 : H12AffineEnvironment.transform 14 21760 env32558 = env32559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env32558 == env32559) = true)

theorem identity32559 : scanCanonicalize (H12AffineFastState.compose env32559 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32559 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env32560 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,342,5392,23669,1025,21761,4160,21793,17,21762,349,64,23809,5393,17665,23668,1365,21793,257,21792,16465,513]

theorem envBound32560 : H12AffineFastState.Bounded env32560 := by
  intro p hp
  have h : env32560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32559_32560 : H12AffineEnvironment.transform 12 349 env32559 = env32560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32559 == env32560) = true)

theorem identity32560 : scanCanonicalize (H12AffineFastState.compose env32560 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound32560 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32561 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,342,5392,2421,1025,1,4160,33,17,2,349,64,2049,5393,4097,2420,1365,33,257,32,5457,513]

theorem envBound32561 : H12AffineFastState.Bounded env32561 := by
  intro p hp
  have h : env32561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32560_32561 : H12AffineEnvironment.transform 13 5376 env32560 = env32561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env32560 == env32561) = true)

theorem identity32561 : scanCanonicalize (H12AffineFastState.compose env32561 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound32561 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32562 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,349,4160,0,342,4176,2421,321,1,4160,33,17,2,349,64,2049,4177,4097,2420,21,33,257,32,4113,513]

theorem envBound32562 : H12AffineFastState.Bounded env32562 := by
  intro p hp
  have h : env32562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32561_32562 : H12AffineEnvironment.transform 9 320 env32561 = env32562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env32561 == env32562) = true)

theorem identity32562 : scanCanonicalize (H12AffineFastState.compose env32562 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound32562 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32563 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,356,349,292,0,342,308,2421,321,1,292,33,17,2,349,64,2049,309,357,2420,21,33,257,32,373,513]

theorem envBound32563 : H12AffineFastState.Bounded env32563 := by
  intro p hp
  have h : env32563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32562_32563 : H12AffineEnvironment.transform 11 356 env32562 = env32563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env32562 == env32563) = true)

def env32564 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,58396,272393,16,21762,8192,64,23809,5392,45404,262145,61705,318549,257,21792,46092,63069]

theorem envBound32564 : H12AffineFastState.Bounded env32564 := by
  intro p hp
  have h : env32564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32556_32564 : H12AffineEnvironment.transform 16 49169 env32556 = env32564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env32556 == env32564) = true)

theorem identity32564 : scanCanonicalize (H12AffineFastState.compose env32564 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32564 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32565 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,24909,262144,1025,8541,17728,272393,16,21762,8192,64,23809,5392,4096,262145,20565,294153,257,21792,5456,22273]

theorem envBound32565 : H12AffineFastState.Bounded env32565 := by
  intro p hp
  have h : env32565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32564_32565 : H12AffineEnvironment.transform 14 8540 env32564 = env32565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32564 == env32565) = true)

theorem identity32565 : scanCanonicalize (H12AffineFastState.compose env32565 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound32565 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env32566 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,24909,10281,1025,8541,17728,32,16,21762,8192,64,23809,5392,4096,10280,20565,21792,257,21792,5456,22273]

theorem envBound32566 : H12AffineFastState.Bounded env32566 := by
  intro p hp
  have h : env32566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32565_32566 : H12AffineEnvironment.transform 17 10281 env32565 = env32566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env32565 == env32566) = true)

theorem identity32566 : scanCanonicalize (H12AffineFastState.compose env32566 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound32566 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env32567 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,1296,1095,17665,3173,1025,1297,17728,32,16,21762,1100,64,23809,5392,4096,3172,20565,21792,257,21792,5456,22273]

theorem envBound32567 : H12AffineFastState.Bounded env32567 := by
  intro p hp
  have h : env32567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32566_32567 : H12AffineEnvironment.transform 12 1100 env32566 = env32567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env32566 == env32567) = true)

theorem identity32567 : scanCanonicalize (H12AffineFastState.compose env32567 (packedSelected [2,4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32567 : packedSelected [2,4,9,16] rootPS < 2^1333 := by decide +kernel

def env32568 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1052,16384,1296,1047,17665,3125,1025,1297,17680,32,16,21762,1052,16,23809,5392,4096,3124,20485,21792,257,21792,5376,22273]

theorem envBound32568 : H12AffineFastState.Bounded env32568 := by
  intro p hp
  have h : env32568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32567_32568 : H12AffineEnvironment.transform 5 16 env32567 = env32568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32567 == env32568) = true)

theorem identity32568 : scanCanonicalize (H12AffineFastState.compose env32568 (packedSelected [0,2,4,7,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound32568 : packedSelected [0,2,4,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env32569 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2064,1052,16384,1296,1047,17665,3125,1025,1297,17680,32,16,19730,1052,16,17681,3328,2064,3124,18453,19760,257,19760,3344,20241]

theorem envBound32569 : H12AffineFastState.Bounded env32569 := by
  intro p hp
  have h : env32569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32568_32569 : H12AffineEnvironment.transform 11 2064 env32568 = env32569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env32568 == env32569) = true)

theorem identity32569 : scanCanonicalize (H12AffineFastState.compose env32569 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 2341) := by decide +kernel

theorem selectedBound32569 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32570 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2064,1052,2341,1296,1047,3108,3125,1025,1297,3125,32,16,1079,1052,16,3124,3328,2064,3124,304,1045,257,1045,3344,1588]

theorem envBound32570 : H12AffineFastState.Bounded env32570 := by
  intro p hp
  have h : env32570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32569_32570 : H12AffineEnvironment.transform 13 2341 env32569 = env32570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2341 env32569 == env32570) = true)

theorem identity32570 : scanCanonicalize (H12AffineFastState.compose env32570 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound32570 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env32571 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2064,269,2341,1,262,2357,2340,272,0,2340,32,16,294,269,16,2341,2065,2064,2341,304,260,257,260,2049,805]

theorem envBound32571 : H12AffineFastState.Bounded env32571 := by
  intro p hp
  have h : env32571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32570_32571 : H12AffineEnvironment.transform 9 273 env32570 = env32571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env32570 == env32571) = true)

theorem identity32571 : scanCanonicalize (H12AffineFastState.compose env32571 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32571 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env32572 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2064,41,2049,1,34,2065,2048,52,0,2048,32,16,2,41,16,2049,2065,2064,2049,20,32,37,32,2049,513]

theorem envBound32572 : H12AffineFastState.Bounded env32572 := by
  intro p hp
  have h : env32572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32571_32572 : H12AffineEnvironment.transform 7 36 env32571 = env32572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32571 == env32572) = true)

theorem identity32572 : scanCanonicalize (H12AffineFastState.compose env32572 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound32572 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32573 : List Nat := [2,4,8,16,32,16,8,36,512,53,544,560,41,545,1,34,561,544,52,0,544,32,16,2,41,16,545,561,560,545,20,32,37,32,545,513]

theorem envBound32573 : H12AffineFastState.Bounded env32573 := by
  intro p hp
  have h : env32573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32572_32573 : H12AffineEnvironment.transform 10 544 env32572 = env32573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env32572 == env32573) = true)

theorem identity32573 : scanCanonicalize (H12AffineFastState.compose env32573 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound32573 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32574 : List Nat := [2,4,8,16,17,16,8,21,512,4,529,513,24,528,1,19,512,529,5,0,529,17,16,2,24,16,528,512,513,528,20,17,20,17,528,513]

theorem envBound32574 : H12AffineFastState.Bounded env32574 := by
  intro p hp
  have h : env32574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32573_32574 : H12AffineEnvironment.transform 4 17 env32573 = env32574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env32573 == env32574) = true)

theorem identity32574 : scanCanonicalize (H12AffineFastState.compose env32574 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32574 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32575 : List Nat := [2,4,8,1,0,1,8,4,512,4,512,513,9,513,1,2,512,512,5,0,512,0,1,2,9,1,513,512,513,513,5,0,5,0,513,513]

theorem envBound32575 : H12AffineFastState.Bounded env32575 := by
  intro p hp
  have h : env32575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32574_32575 : H12AffineEnvironment.transform 3 1 env32574 = env32575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32574 == env32575) = true)

theorem identity32575 : scanCanonicalize (H12AffineFastState.compose env32575 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32575 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32576 : List Nat := [2,4,8,1,0,1,8,4,1,4,1,0,9,0,1,2,1,1,5,0,1,0,1,2,9,1,0,1,0,0,5,0,5,0,0,0]

theorem envBound32576 : H12AffineFastState.Bounded env32576 := by
  intro p hp
  have h : env32576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32575_32576 : H12AffineEnvironment.transform 8 1 env32575 = env32576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32575 == env32576) = true)

def env32577 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,140301,272392,180224,21762,8193,64,23809,185600,45405,262144,143641,400452,257,21792,46093,144972]

theorem envBound32577 : H12AffineFastState.Bounded env32577 := by
  intro p hp
  have h : env32577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32555_32577 : H12AffineEnvironment.transform 6 9 env32555 = env32577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32555 == env32577) = true)

def env32578 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,58397,272392,16,21762,8193,64,23809,5392,45405,262144,61705,318548,257,21792,46093,63068]

theorem envBound32578 : H12AffineFastState.Bounded env32578 := by
  intro p hp
  have h : env32578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32577_32578 : H12AffineEnvironment.transform 16 49168 env32577 = env32578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env32577 == env32578) = true)

theorem identity32578 : scanCanonicalize (H12AffineFastState.compose env32578 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32578 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env32579 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,343,49168,262144,1025,32769,50497,264532,16,21762,349,64,23809,5392,36865,262144,53333,318548,257,21792,38225,55040]

theorem envBound32579 : H12AffineFastState.Bounded env32579 := by
  intro p hp
  have h : env32579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32578_32579 : H12AffineEnvironment.transform 12 348 env32578 = env32579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32578 == env32579) = true)

def env32580 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,58396,272392,17,21762,8193,64,23809,5393,45405,262144,61704,318549,257,21792,46093,63069]

theorem envBound32580 : H12AffineFastState.Bounded env32580 := by
  intro p hp
  have h : env32580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32577_32580 : H12AffineEnvironment.transform 16 49169 env32577 = env32580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env32577 == env32580) = true)

theorem identity32580 : scanCanonicalize (H12AffineFastState.compose env32580 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32580 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32581 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,10280,1025,32769,58396,32,17,21762,8193,64,23809,5393,45405,10280,61704,62589,257,21792,46093,63069]

theorem envBound32581 : H12AffineFastState.Bounded env32581 := by
  intro p hp
  have h : env32581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32580_32581 : H12AffineEnvironment.transform 17 10280 env32580 = env32581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32580 == env32581) = true)

theorem identity32581 : scanCanonicalize (H12AffineFastState.compose env32581 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound32581 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env32582 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8203,5393,10280,1025,21761,12572,32,17,21762,8193,64,23809,5393,25693,10280,9224,8573,257,21792,24845,9053]

theorem envBound32582 : H12AffineFastState.Bounded env32582 := by
  intro p hp
  have h : env32582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32581_32582 : H12AffineEnvironment.transform 14 21760 env32581 = env32582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env32581 == env32582) = true)

theorem identity32582 : scanCanonicalize (H12AffineFastState.compose env32582 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound32582 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env32583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8541,8203,5393,10280,1025,8540,12572,32,17,8543,8193,64,10588,5393,4096,10280,9224,8573,257,8573,5456,9053]

theorem envBound32583 : H12AffineFastState.Bounded env32583 := by
  intro p hp
  have h : env32583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32582_32583 : H12AffineEnvironment.transform 13 13405 env32582 = env32583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env32582 == env32583) = true)

theorem identity32583 : scanCanonicalize (H12AffineFastState.compose env32583 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32583 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env32584 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13405,8232,8203,5220,10280,1025,8233,12393,32,17,8234,8193,64,10281,5220,4096,10280,9224,8200,116,8200,5157,8744]

theorem envBound32584 : H12AffineFastState.Bounded env32584 := by
  intro p hp
  have h : env32584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32583_32584 : H12AffineEnvironment.transform 7 117 env32583 = env32584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32583 == env32584) = true)

theorem identity32584 : scanCanonicalize (H12AffineFastState.compose env32584 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound32584 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32585 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,1,34,5220,2049,1025,0,4160,32,17,3,40,64,2048,5220,4096,2049,1057,33,116,33,5157,513]

theorem envBound32585 : H12AffineFastState.Bounded env32585 := by
  intro p hp
  have h : env32585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32584_32585 : H12AffineEnvironment.transform 12 41 env32584 = env32585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env32584 == env32585) = true)

theorem identity32585 : scanCanonicalize (H12AffineFastState.compose env32585 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound32585 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32586 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,41,4112,1,34,4096,2049,101,0,4160,32,17,3,40,64,2048,4096,4096,2049,69,33,116,33,4161,513]

theorem envBound32586 : H12AffineFastState.Bounded env32586 := by
  intro p hp
  have h : env32586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32585_32586 : H12AffineEnvironment.transform 9 100 env32585 = env32586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env32585 == env32586) = true)

theorem identity32586 : scanCanonicalize (H12AffineFastState.compose env32586 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound32586 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32587 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,16,41,0,1,34,16,2049,101,0,80,32,17,3,40,64,2048,16,16,2049,69,33,116,33,81,513]

theorem envBound32587 : H12AffineFastState.Bounded env32587 := by
  intro p hp
  have h : env32587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32586_32587 : H12AffineEnvironment.transform 11 16 env32586 = env32587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env32586 == env32587) = true)

theorem identity32587 : scanCanonicalize (H12AffineFastState.compose env32587 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound32587 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32588 : List Nat := [2,4,8,16,17,64,9,68,512,85,2048,16,24,0,1,19,16,2049,84,0,80,17,17,3,25,64,2048,16,16,2049,69,16,69,16,81,513]

theorem envBound32588 : H12AffineFastState.Bounded env32588 := by
  intro p hp
  have h : env32588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32587_32588 : H12AffineEnvironment.transform 4 17 env32587 = env32588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env32587 == env32588) = true)

def env32589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,4194304,8388608,8631681,8328,64,4486529,8393985,8548701,8830976,143761,12645453,257,21793,46213,202310]

theorem envBound32589 : H12AffineFastState.Bounded env32589 := by
  intro p hp
  have h : env32589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32479_32589 : H12AffineEnvironment.transform 23 8631681 env32479 = env32589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8631681 env32479 == env32589) = true)

def env32590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,4194304,180360,95497,8328,64,4486529,185737,45525,262280,143761,4338885,257,21793,46213,202310]

theorem envBound32590 : H12AffineFastState.Bounded env32590 := by
  intro p hp
  have h : env32590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32589_32590 : H12AffineEnvironment.transform 22 180360 env32589 = env32590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env32589 == env32590) = true)

def env32591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272512,180360,95497,8328,64,23809,185737,45525,262280,143761,400453,257,21793,46213,202310]

theorem envBound32591 : H12AffineFastState.Bounded env32591 := by
  intro p hp
  have h : env32591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32590_32591 : H12AffineEnvironment.transform 21 272512 env32590 = env32591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env32590 == env32591) = true)

def env32592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272392,180224,95497,8192,64,23809,185601,45405,262144,143641,400453,257,21793,46093,202310]

theorem envBound32592 : H12AffineFastState.Bounded env32592 := by
  intro p hp
  have h : env32592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32591_32592 : H12AffineEnvironment.transform 6 8 env32591 = env32592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32591 == env32592) = true)

def env32593 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58397,272392,16,95497,8192,64,23809,5393,45405,262144,61705,318549,257,21793,46093,120406]

theorem envBound32593 : H12AffineFastState.Bounded env32593 := by
  intro p hp
  have h : env32593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32592_32593 : H12AffineEnvironment.transform 16 49168 env32592 = env32593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env32592 == env32593) = true)

theorem identity32593 : scanCanonicalize (H12AffineFastState.compose env32593 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32593 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32594 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24908,262144,1025,8541,17729,272392,16,95497,8192,64,23809,5393,4097,262144,20565,294153,257,21793,5457,96010]

theorem envBound32594 : H12AffineFastState.Bounded env32594 := by
  intro p hp
  have h : env32594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32593_32594 : H12AffineEnvironment.transform 14 8540 env32593 = env32594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32593 == env32594) = true)

theorem identity32594 : scanCanonicalize (H12AffineFastState.compose env32594 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound32594 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env32595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24908,2421,1025,8541,17729,8573,16,95497,8192,64,23809,5393,4097,2421,20565,29820,257,21793,5457,96010]

theorem envBound32595 : H12AffineFastState.Bounded env32595 := by
  intro p hp
  have h : env32595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32594_32595 : H12AffineEnvironment.transform 17 2421 env32594 = env32595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env32594 == env32595) = true)

theorem identity32595 : scanCanonicalize (H12AffineFastState.compose env32595 (packedSelected [4,7,9,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound32595 : packedSelected [4,7,9,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env32596 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,21511,24908,2421,1025,8541,17729,8573,16,8462,8192,64,23809,5393,4097,2421,20565,29820,257,21793,5457,8973]

theorem envBound32596 : H12AffineFastState.Bounded env32596 := by
  intro p hp
  have h : env32596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32595_32596 : H12AffineEnvironment.transform 15 21511 env32595 = env32596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env32595 == env32596) = true)

theorem identity32596 : scanCanonicalize (H12AffineFastState.compose env32596 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound32596 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env32597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8540,8495,5220,2421,1025,8541,12393,8573,16,8462,8192,64,10281,5393,4097,2421,9597,340,257,8201,5457,8973]

theorem envBound32597 : H12AffineFastState.Bounded env32597 := by
  intro p hp
  have h : env32597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32596_32597 : H12AffineEnvironment.transform 13 13608 env32596 = env32597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env32596 == env32597) = true)

theorem identity32597 : scanCanonicalize (H12AffineFastState.compose env32597 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound32597 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env32598 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,373,262,5220,2421,1025,372,4160,340,16,295,41,64,2048,5393,4097,2421,1364,340,257,32,5457,804]

theorem envBound32598 : H12AffineFastState.Bounded env32598 := by
  intro p hp
  have h : env32598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32597_32598 : H12AffineEnvironment.transform 12 41 env32597 = env32598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env32597 == env32598) = true)

theorem identity32598 : scanCanonicalize (H12AffineFastState.compose env32598 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32598 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32599 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,5377,292,262,5173,2340,1025,293,4113,261,16,295,41,17,2048,5393,4097,2340,1285,261,257,32,5376,804]

theorem envBound32599 : H12AffineFastState.Bounded env32599 := by
  intro p hp
  have h : env32599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32598_32599 : H12AffineEnvironment.transform 5 17 env32598 = env32599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32598 == env32599) = true)

theorem identity32599 : scanCanonicalize (H12AffineFastState.compose env32599 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound32599 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env32600 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,17,41,1296,292,262,1060,2340,1025,293,0,261,16,295,41,17,2048,1280,16,2340,1285,261,257,32,1297,804]

theorem envBound32600 : H12AffineFastState.Bounded env32600 := by
  intro p hp
  have h : env32600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32599_32600 : H12AffineEnvironment.transform 11 17 env32599 = env32600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env32599 == env32600) = true)

theorem identity32600 : scanCanonicalize (H12AffineFastState.compose env32600 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound32600 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env32601 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,17,41,292,292,262,16,2340,53,293,0,261,16,295,41,17,2048,308,16,2340,305,261,257,32,293,804]

theorem envBound32601 : H12AffineFastState.Bounded env32601 := by
  intro p hp
  have h : env32601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32600_32601 : H12AffineEnvironment.transform 9 52 env32600 = env32601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32600 == env32601) = true)

def env32602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58396,272392,17,95497,8192,64,23809,5392,45405,262144,61704,318548,257,21793,46093,120407]

theorem envBound32602 : H12AffineFastState.Bounded env32602 := by
  intro p hp
  have h : env32602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32592_32602 : H12AffineEnvironment.transform 16 49169 env32592 = env32602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env32592 == env32602) = true)

theorem identity32602 : scanCanonicalize (H12AffineFastState.compose env32602 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound32602 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1025,32769,58396,41341,17,95497,8192,64,23809,5392,45405,35189,61704,21793,257,21793,46093,120407]

theorem envBound32603 : H12AffineFastState.Bounded env32603 := by
  intro p hp
  have h : env32603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32602_32603 : H12AffineEnvironment.transform 17 35189 env32602 = env32603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env32602 == env32603) = true)

theorem identity32603 : scanCanonicalize (H12AffineFastState.compose env32603 (packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 30072) := by decide +kernel

theorem selectedBound32603 : packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env32604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30072,65536,13673,31757,1025,30073,4452,21509,17,95497,8192,64,23809,5392,17445,31757,1136,21793,257,21793,16757,74543]

theorem envBound32604 : H12AffineFastState.Bounded env32604 := by
  intro p hp
  have h : env32604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32603_32604 : H12AffineEnvironment.transform 14 30072 env32603 = env32604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30072 env32603 == env32604) = true)

theorem identity32604 : scanCanonicalize (H12AffineFastState.compose env32604 (packedSelected [3,5,10,12,15,18,19,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound32604 : packedSelected [3,5,10,12,15,18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env32605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8461,65536,13673,10360,1025,8460,4452,112,17,74108,8192,64,2420,5392,4176,10360,1136,340,257,340,5376,74543]

theorem envBound32605 : H12AffineFastState.Bounded env32605 := by
  intro p hp
  have h : env32605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32604_32605 : H12AffineEnvironment.transform 13 5237 env32604 = env32605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env32604 == env32605) = true)

theorem identity32605 : scanCanonicalize (H12AffineFastState.compose env32605 (packedSelected [0,2,3,5,6,7,9,10,11,14,15,16,22] rootPS)) = affineNative (2^(12+1) ^^^ 7261) := by decide +kernel

theorem selectedBound32605 : packedSelected [0,2,3,5,6,7,9,10,11,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env32606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7261,5237,7504,65536,2356,5157,1025,7505,4452,112,17,72993,7261,64,2420,5392,4176,5157,1136,340,257,340,5376,73586]

theorem envBound32606 : H12AffineFastState.Bounded env32606 := by
  intro p hp
  have h : env32606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32605_32606 : H12AffineEnvironment.transform 12 7261 env32605 = env32606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7261 env32605 == env32606) = true)

theorem identity32606 : scanCanonicalize (H12AffineFastState.compose env32606 (packedSelected [4,9,10,12,15,19] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32606 : packedSelected [4,9,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env32607 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,7261,5237,7205,65536,2113,5157,1025,7204,4113,112,17,72788,7261,64,2049,5221,4176,5157,1136,33,116,33,5237,73223]

theorem envBound32607 : H12AffineFastState.Bounded env32607 := by
  intro p hp
  have h : env32607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32606_32607 : H12AffineEnvironment.transform 7 117 env32606 = env32607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32606 == env32607) = true)

theorem identity32607 : scanCanonicalize (H12AffineFastState.compose env32607 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 7175) := by decide +kernel

theorem selectedBound32607 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env32608 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,7261,5237,7205,7175,2113,5157,1025,7204,4113,112,17,83,7261,64,2049,5221,4176,5157,1136,33,116,33,5237,512]

theorem envBound32608 : H12AffineFastState.Bounded env32608 := by
  intro p hp
  have h : env32608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32607_32608 : H12AffineEnvironment.transform 15 7175 env32607 = env32608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7175 env32607 == env32608) = true)

theorem identity32608 : scanCanonicalize (H12AffineFastState.compose env32608 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound32608 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env32609 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3108,121,2129,1,35,2113,2049,1025,0,3125,112,17,83,121,64,2049,2113,3188,2049,1136,33,116,33,2129,512]

theorem envBound32609 : H12AffineFastState.Bounded env32609 := by
  intro p hp
  have h : env32609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32608_32609 : H12AffineEnvironment.transform 11 3108 env32608 = env32609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env32608 == env32609) = true)

theorem identity32609 : scanCanonicalize (H12AffineFastState.compose env32609 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32609 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32610 : List Nat := [2,4,8,16,0,64,8,85,512,1024,2048,3076,89,2129,1,3,2113,2049,1025,0,3093,80,17,83,89,64,2049,2113,3156,2049,1104,1,84,1,2129,512]

theorem envBound32610 : H12AffineFastState.Bounded env32610 := by
  intro p hp
  have h : env32610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32609_32610 : H12AffineEnvironment.transform 4 0 env32609 = env32610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32609 == env32610) = true)

theorem identity32610 : scanCanonicalize (H12AffineFastState.compose env32610 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound32610 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32611 : List Nat := [2,4,8,16,0,64,8,85,512,85,2048,2129,89,2129,1,3,2113,2049,84,0,2112,80,17,83,89,64,2049,2113,2049,2049,5,1,84,1,2129,512]

theorem envBound32611 : H12AffineFastState.Bounded env32611 := by
  intro p hp
  have h : env32611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32610_32611 : H12AffineEnvironment.transform 9 85 env32610 = env32611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env32610 == env32611) = true)

theorem identity32611 : scanCanonicalize (H12AffineFastState.compose env32611 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound32611 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env32612 : List Nat := [2,4,8,16,0,64,8,85,512,85,64,17,89,17,1,3,1,65,84,0,0,80,17,83,89,64,65,1,65,65,5,1,84,1,17,512]

theorem envBound32612 : H12AffineFastState.Bounded env32612 := by
  intro p hp
  have h : env32612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32611_32612 : H12AffineEnvironment.transform 10 64 env32611 = env32612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env32611 == env32612) = true)

theorem identity32612 : scanCanonicalize (H12AffineFastState.compose env32612 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32612 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32613 : List Nat := [2,4,8,16,0,16,8,5,512,5,16,17,9,17,1,3,1,17,4,0,0,0,17,3,9,16,17,1,17,17,5,1,4,1,17,512]

theorem envBound32613 : H12AffineFastState.Bounded env32613 := by
  intro p hp
  have h : env32613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32612_32613 : H12AffineEnvironment.transform 5 16 env32612 = env32613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32612 == env32613) = true)

theorem identity32613 : scanCanonicalize (H12AffineFastState.compose env32613 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound32613 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32614 : List Nat := [2,4,8,16,0,16,8,5,16,5,16,17,9,17,1,3,1,17,4,0,0,0,17,3,9,16,17,1,17,17,5,1,4,1,17,16]

theorem envBound32614 : H12AffineFastState.Bounded env32614 := by
  intro p hp
  have h : env32614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32613_32614 : H12AffineEnvironment.transform 8 16 env32613 = env32614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env32613 == env32614) = true)

theorem identity32614 : scanCanonicalize (H12AffineFastState.compose env32614 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound32614 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32615 : List Nat := [2,4,8,0,0,0,8,5,0,5,0,1,9,1,1,3,1,1,4,0,0,0,1,3,9,0,1,1,1,1,5,1,4,1,1,0]

theorem envBound32615 : H12AffineFastState.Bounded env32615 := by
  intro p hp
  have h : env32615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32614_32615 : H12AffineEnvironment.transform 3 0 env32614 = env32615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32614 == env32615) = true)

theorem identity32615 : scanCanonicalize (H12AffineFastState.compose env32615 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound32615 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32616 : List Nat := [2,1,8,0,0,0,8,0,0,0,0,1,9,1,1,3,1,1,1,0,0,0,1,3,9,0,1,1,1,1,0,1,1,1,1,0]

theorem envBound32616 : H12AffineFastState.Bounded env32616 := by
  intro p hp
  have h : env32616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32615_32616 : H12AffineEnvironment.transform 1 1 env32615 = env32616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env32615 == env32616) = true)

def env32617 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272393,180225,95497,8193,64,23809,185600,45404,262145,143640,400453,257,21793,46092,202310]

theorem envBound32617 : H12AffineFastState.Bounded env32617 := by
  intro p hp
  have h : env32617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32591_32617 : H12AffineEnvironment.transform 6 9 env32591 = env32617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32591 == env32617) = true)

def env32618 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58397,272393,17,95497,8193,64,23809,5392,45404,262145,61704,318549,257,21793,46092,120406]

theorem envBound32618 : H12AffineFastState.Bounded env32618 := by
  intro p hp
  have h : env32618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32617_32618 : H12AffineEnvironment.transform 16 49168 env32617 = env32618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env32617 == env32618) = true)

theorem identity32618 : scanCanonicalize (H12AffineFastState.compose env32618 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32618 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32619 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,58397,33,17,95497,8193,64,23809,5392,45404,10281,61704,62589,257,21793,46092,120406]

theorem envBound32619 : H12AffineFastState.Bounded env32619 := by
  intro p hp
  have h : env32619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32618_32619 : H12AffineEnvironment.transform 17 10280 env32618 = env32619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32618 == env32619) = true)

theorem identity32619 : scanCanonicalize (H12AffineFastState.compose env32619 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound32619 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env32620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,65536,24860,10280,1025,8461,17681,33,17,95497,8193,64,23809,5392,4176,10281,20484,21873,257,21793,5376,96090]

theorem envBound32620 : H12AffineFastState.Bounded env32620 := by
  intro p hp
  have h : env32620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32619_32620 : H12AffineEnvironment.transform 14 8460 env32619 = env32620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env32619 == env32620) = true)

theorem identity32620 : scanCanonicalize (H12AffineFastState.compose env32620 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound32620 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env32621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,263,24860,10280,1025,8461,17681,33,17,29710,8193,64,23809,5392,4176,10281,20484,21873,257,21793,5376,30301]

theorem envBound32621 : H12AffineFastState.Bounded env32621 := by
  intro p hp
  have h : env32621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32620_32621 : H12AffineEnvironment.transform 15 263 env32620 = env32621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env32620 == env32621) = true)

theorem identity32621 : scanCanonicalize (H12AffineFastState.compose env32621 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound32621 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env32622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,1,263,16401,2341,1025,0,17681,33,17,21763,268,64,23809,5392,4176,2340,20484,21873,257,21793,5376,22352]

theorem envBound32622 : H12AffineFastState.Bounded env32622 := by
  intro p hp
  have h : env32622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32621_32622 : H12AffineEnvironment.transform 12 269 env32621 = env32622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env32621 == env32622) = true)

theorem identity32622 : scanCanonicalize (H12AffineFastState.compose env32622 (packedSelected [0,3,5,6,9,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound32622 : packedSelected [0,3,5,6,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env32623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,269,16384,1,263,16401,2341,1025,0,17681,33,17,19731,268,64,17681,3328,2112,2340,18452,19809,257,19761,3344,20288]

theorem envBound32623 : H12AffineFastState.Bounded env32623 := by
  intro p hp
  have h : env32623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32622_32623 : H12AffineEnvironment.transform 11 2064 env32622 = env32623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env32622 == env32623) = true)

theorem identity32623 : scanCanonicalize (H12AffineFastState.compose env32623 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32623 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env32624 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,2064,40,16384,1,34,16401,2048,1025,0,17460,33,17,19510,41,64,17460,3109,2112,2049,18452,19524,36,19476,3125,20069]

theorem envBound32624 : H12AffineFastState.Bounded env32624 := by
  intro p hp
  have h : env32624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32623_32624 : H12AffineEnvironment.transform 7 37 env32623 = env32624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32623 == env32624) = true)

theorem identity32624 : scanCanonicalize (H12AffineFastState.compose env32624 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 3125) := by decide +kernel

theorem selectedBound32624 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env32625 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,2064,40,3125,1,34,3108,2048,1025,0,2049,33,17,3,41,64,2049,3109,2112,2049,1057,113,36,33,3125,592]

theorem envBound32625 : H12AffineFastState.Bounded env32625 := by
  intro p hp
  have h : env32625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32624_32625 : H12AffineEnvironment.transform 13 3125 env32624 = env32625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3125 env32624 == env32625) = true)

theorem identity32625 : scanCanonicalize (H12AffineFastState.compose env32625 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound32625 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env32626 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1076,1060,40,1,1,34,16,1076,1025,0,1077,33,17,3,41,64,1077,17,1140,1077,1057,113,36,33,1,592]

theorem envBound32626 : H12AffineFastState.Bounded env32626 := by
  intro p hp
  have h : env32626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32625_32626 : H12AffineEnvironment.transform 10 1076 env32625 = env32626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env32625 == env32626) = true)

theorem identity32626 : scanCanonicalize (H12AffineFastState.compose env32626 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound32626 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env32627 : List Nat := [2,4,8,16,32,64,9,37,512,101,81,65,40,1,1,34,16,81,100,0,80,33,17,3,41,64,80,17,17,80,68,113,36,33,1,592]

theorem envBound32627 : H12AffineFastState.Bounded env32627 := by
  intro p hp
  have h : env32627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32626_32627 : H12AffineEnvironment.transform 9 101 env32626 = env32627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env32626 == env32627) = true)

theorem identity32627 : scanCanonicalize (H12AffineFastState.compose env32627 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32627 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32628 : List Nat := [2,4,8,16,32,16,9,37,512,53,1,17,40,1,1,34,16,1,52,0,0,33,17,3,41,16,0,17,17,0,20,33,36,33,1,512]

theorem envBound32628 : H12AffineFastState.Bounded env32628 := by
  intro p hp
  have h : env32628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32627_32628 : H12AffineEnvironment.transform 5 16 env32627 = env32628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32627 == env32628) = true)

theorem identity32628 : scanCanonicalize (H12AffineFastState.compose env32628 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound32628 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32629 : List Nat := [2,4,8,4,32,4,9,37,512,33,1,5,40,1,1,34,4,1,32,0,0,33,5,3,41,4,0,5,5,0,0,33,36,33,1,512]

theorem envBound32629 : H12AffineFastState.Bounded env32629 := by
  intro p hp
  have h : env32629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32628_32629 : H12AffineEnvironment.transform 3 4 env32628 = env32629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env32628 == env32629) = true)

theorem identity32629 : scanCanonicalize (H12AffineFastState.compose env32629 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound32629 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32630 : List Nat := [2,4,8,4,7,4,9,2,512,6,1,5,15,1,1,5,4,1,7,0,0,6,5,3,14,4,0,5,5,0,0,6,3,6,1,512]

theorem envBound32630 : H12AffineFastState.Bounded env32630 := by
  intro p hp
  have h : env32630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32629_32630 : H12AffineEnvironment.transform 4 7 env32629 = env32630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env32629 == env32630) = true)

theorem identity32630 : scanCanonicalize (H12AffineFastState.compose env32630 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound32630 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32631 : List Nat := [2,2,8,2,1,2,9,2,512,0,1,3,9,1,1,3,2,1,1,0,0,0,3,3,8,2,0,3,3,0,0,0,3,0,1,512]

theorem envBound32631 : H12AffineFastState.Bounded env32631 := by
  intro p hp
  have h : env32631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32630_32631 : H12AffineEnvironment.transform 1 2 env32630 = env32631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env32630 == env32631) = true)

theorem identity32631 : scanCanonicalize (H12AffineFastState.compose env32631 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound32631 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32632 : List Nat := [2,2,8,2,1,2,9,2,10,0,1,3,9,1,1,3,2,1,1,0,0,0,3,3,8,2,0,3,3,0,0,0,3,0,1,10]

theorem envBound32632 : H12AffineFastState.Bounded env32632 := by
  intro p hp
  have h : env32632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32631_32632 : H12AffineEnvironment.transform 8 10 env32631 = env32632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env32631 == env32632) = true)

def env32633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58396,272393,16,95497,8193,64,23809,5393,45404,262145,61705,318548,257,21793,46092,120407]

theorem envBound32633 : H12AffineFastState.Bounded env32633 := by
  intro p hp
  have h : env32633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32617_32633 : H12AffineEnvironment.transform 16 49169 env32617 = env32633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env32617 == env32633) = true)

theorem identity32633 : scanCanonicalize (H12AffineFastState.compose env32633 (packedSelected [0,1,3,4,8,10,12,14,16,18,22,23,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 64889) := by decide +kernel

theorem selectedBound32633 : packedSelected [0,1,3,4,8,10,12,14,16,18,22,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env32634 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,64889,1025,32769,58396,54640,16,95497,8193,64,23809,5393,45404,64888,61705,8493,257,21793,46092,120407]

theorem envBound32634 : H12AffineFastState.Bounded env32634 := by
  intro p hp
  have h : env32634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32633_32634 : H12AffineEnvironment.transform 17 64889 env32633 = env32634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64889 env32633 == env32634) = true)

theorem identity32634 : scanCanonicalize (H12AffineFastState.compose env32634 (packedSelected [1,3,4,5,9,10,12,15,18,20,23,26,28,31,35] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32634 : packedSelected [1,3,4,5,9,10,12,15,18,20,23,26,28,31,35] rootPS < 2^1333 := by decide +kernel

def env32635 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,32768,65536,49169,56437,1025,32769,50448,54640,16,87045,269,64,23809,5393,36944,56436,53253,33,257,21793,38144,120407]

theorem envBound32635 : H12AffineFastState.Bounded env32635 := by
  intro p hp
  have h : env32635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32634_32635 : H12AffineEnvironment.transform 12 268 env32634 = env32635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32634 == env32635) = true)

theorem identity32635 : scanCanonicalize (H12AffineFastState.compose env32635 (packedSelected [0,1,3,7,8,9,10,12,14,15,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound32635 : packedSelected [0,1,3,7,8,9,10,12,14,15,20,22,24] rootPS < 2^1333 := by decide +kernel

def env32636 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,32768,65536,38209,35109,1025,32769,36928,32800,16,65877,269,64,2129,5393,36944,35108,34133,33,257,113,38144,99079]

theorem envBound32636 : H12AffineFastState.Bounded env32636 := by
  intro p hp
  have h : env32636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32635_32636 : H12AffineEnvironment.transform 13 5456 env32635 = env32636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env32635 == env32636) = true)

theorem identity32636 : scanCanonicalize (H12AffineFastState.compose env32636 (packedSelected [2,3,6,7,8,9,10,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 39942) := by decide +kernel

theorem selectedBound32636 : packedSelected [2,3,6,7,8,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env32637 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,32768,39942,38209,35109,1025,32769,36928,32800,16,40275,269,64,2129,5393,36944,35108,34133,33,257,113,38144,7937]

theorem envBound32637 : H12AffineFastState.Bounded env32637 := by
  intro p hp
  have h : env32637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32636_32637 : H12AffineEnvironment.transform 15 39942 env32636 = env32637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 39942 env32636 == env32637) = true)

theorem identity32637 : scanCanonicalize (H12AffineFastState.compose env32637 (packedSelected [3,4,7,8,11,14,19] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound32637 : packedSelected [3,4,7,8,11,14,19] rootPS < 2^1333 := by decide +kernel

def env32638 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,268,2048,32768,33110,34833,35109,1025,32769,36112,32800,16,32771,269,64,2129,2113,36096,35108,34133,33,257,113,34896,593]

theorem envBound32638 : H12AffineFastState.Bounded env32638 := by
  intro p hp
  have h : env32638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32637_32638 : H12AffineEnvironment.transform 11 3408 env32637 = env32638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env32637 == env32638) = true)

theorem identity32638 : scanCanonicalize (H12AffineFastState.compose env32638 (packedSelected [1,2,6,8,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound32638 : packedSelected [1,2,6,8,12,14] rootPS < 2^1333 := by decide +kernel

def env32639 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3108,120,2048,32768,32802,34833,34897,1025,32769,35940,32800,16,32771,121,64,2129,2113,35956,34896,33825,33,117,113,34896,593]

theorem envBound32639 : H12AffineFastState.Bounded env32639 := by
  intro p hp
  have h : env32639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32638_32639 : H12AffineEnvironment.transform 7 116 env32638 = env32639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env32638 == env32639) = true)

theorem identity32639 : scanCanonicalize (H12AffineFastState.compose env32639 (packedSelected [0,2,3,4,6,8,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 1125) := by decide +kernel

theorem selectedBound32639 : packedSelected [0,2,3,4,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env32640 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3108,120,2048,1125,1095,3188,3124,1025,1124,2049,1093,16,1126,121,64,2129,2113,2065,3125,68,33,117,113,3125,593]

theorem envBound32640 : H12AffineFastState.Bounded env32640 := by
  intro p hp
  have h : env32640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32639_32640 : H12AffineEnvironment.transform 14 1125 env32639 = env32640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1125 env32639 == env32640) = true)

theorem identity32640 : scanCanonicalize (H12AffineFastState.compose env32640 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound32640 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env32641 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,2113,120,2048,0,34,2065,2129,100,1,2049,32,16,3,121,64,2129,2113,2065,2128,68,33,117,113,2128,593]

theorem envBound32641 : H12AffineFastState.Bounded env32641 := by
  intro p hp
  have h : env32641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32640_32641 : H12AffineEnvironment.transform 9 101 env32640 = env32641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env32640 == env32641) = true)

theorem identity32641 : scanCanonicalize (H12AffineFastState.compose env32641 (packedSelected [0,6] rootPS)) = affineNative (2^(10+1) ^^^ 576) := by decide +kernel

theorem selectedBound32641 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env32642 : List Nat := [2,4,8,16,32,64,9,116,512,101,576,513,120,576,0,34,593,529,100,1,577,32,16,3,121,64,529,513,593,528,68,33,117,113,528,593]

theorem envBound32642 : H12AffineFastState.Bounded env32642 := by
  intro p hp
  have h : env32642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32641_32642 : H12AffineEnvironment.transform 10 576 env32641 = env32642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env32641 == env32642) = true)

theorem identity32642 : scanCanonicalize (H12AffineFastState.compose env32642 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32642 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env32643 : List Nat := [2,4,8,16,32,16,9,36,512,53,528,513,40,528,0,34,513,529,52,1,529,32,16,3,41,16,529,513,513,528,20,33,37,33,528,513]

theorem envBound32643 : H12AffineFastState.Bounded env32643 := by
  intro p hp
  have h : env32643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32642_32643 : H12AffineEnvironment.transform 5 16 env32642 = env32643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32642 == env32643) = true)

def env32644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272513,180360,95497,8328,64,23808,185737,45525,262280,143761,400452,257,21793,46213,202310]

theorem envBound32644 : H12AffineFastState.Bounded env32644 := by
  intro p hp
  have h : env32644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32590_32644 : H12AffineEnvironment.transform 21 272513 env32590 = env32644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env32590 == env32644) = true)

theorem identity32644 : scanCanonicalize (H12AffineFastState.compose env32644 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound32644 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,58516,272513,17,95497,8328,64,23808,5392,45525,262280,61704,318685,257,21793,46213,120543]

theorem envBound32645 : H12AffineFastState.Bounded env32645 := by
  intro p hp
  have h : env32645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32644_32645 : H12AffineEnvironment.transform 16 49305 env32644 = env32645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env32644 == env32645) = true)

def env32646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58396,272393,17,95497,8192,64,23808,5392,45405,262144,61704,318549,257,21793,46093,120407]

theorem envBound32646 : H12AffineFastState.Bounded env32646 := by
  intro p hp
  have h : env32646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32645_32646 : H12AffineEnvironment.transform 6 8 env32645 = env32646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32645 == env32646) = true)

theorem identity32646 : scanCanonicalize (H12AffineFastState.compose env32646 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound32646 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32647 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1025,32769,58396,41340,17,95497,8192,64,23808,5392,45405,35189,61704,21792,257,21793,46093,120407]

theorem envBound32647 : H12AffineFastState.Bounded env32647 := by
  intro p hp
  have h : env32647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32646_32647 : H12AffineEnvironment.transform 17 35189 env32646 = env32647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env32646 == env32647) = true)

theorem identity32647 : scanCanonicalize (H12AffineFastState.compose env32647 (packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound32647 : packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env32648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,32768,65536,46393,35189,1025,32769,37172,41340,17,65569,8192,64,10280,5392,45405,35189,33824,8200,257,8201,46093,107391]

theorem envBound32648 : H12AffineFastState.Bounded env32648 := by
  intro p hp
  have h : env32648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32647_32648 : H12AffineEnvironment.transform 13 13608 env32647 = env32648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env32647 == env32648) = true)

theorem identity32648 : scanCanonicalize (H12AffineFastState.compose env32648 (packedSelected [0,2,4,6,7,9,11,14,19,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32648 : packedSelected [0,2,4,6,7,9,11,14,19,23,26] rootPS < 2^1333 := by decide +kernel

def env32649 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5156,32768,65536,37941,35189,1025,32769,37172,32880,17,65569,268,64,2340,5392,36945,35189,33824,260,257,261,38145,98931]

theorem envBound32649 : H12AffineFastState.Bounded env32649 := by
  intro p hp
  have h : env32649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32648_32649 : H12AffineEnvironment.transform 12 268 env32648 = env32649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32648 == env32649) = true)

theorem identity32649 : scanCanonicalize (H12AffineFastState.compose env32649 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound32649 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env32650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5156,32768,115,37941,35189,1025,32769,37172,32880,17,82,268,64,2340,5392,36945,35189,33824,260,257,261,38145,33280]

theorem envBound32650 : H12AffineFastState.Bounded env32650 := by
  intro p hp
  have h : env32650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32649_32650 : H12AffineEnvironment.transform 15 115 env32649 = env32650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env32649 == env32650) = true)

theorem identity32650 : scanCanonicalize (H12AffineFastState.compose env32650 (packedSelected [0,1,3,4,5,7,8,9,10,11,12,14,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound32650 : packedSelected [0,1,3,4,5,7,8,9,10,11,12,14,19] rootPS < 2^1333 := by decide +kernel

def env32651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5156,0,115,5173,2421,1025,1,4404,112,17,82,268,64,2340,5392,4177,2421,1056,260,257,261,5377,512]

theorem envBound32651 : H12AffineFastState.Bounded env32651 := by
  intro p hp
  have h : env32651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32650_32651 : H12AffineEnvironment.transform 14 0 env32650 = env32651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env32650 == env32651) = true)

theorem identity32651 : scanCanonicalize (H12AffineFastState.compose env32651 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound32651 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32652 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,268,5156,0,3,5173,2309,1025,1,4404,0,17,34,268,48,2340,5392,4129,2309,1056,260,257,261,5377,512]

theorem envBound32652 : H12AffineFastState.Bounded env32652 := by
  intro p hp
  have h : env32652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32651_32652 : H12AffineEnvironment.transform 5 48 env32651 = env32652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env32651 == env32652) = true)

theorem identity32652 : scanCanonicalize (H12AffineFastState.compose env32652 (packedSelected [0,2,4,7,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32652 : packedSelected [0,2,4,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env32653 : List Nat := [2,4,8,16,32,48,8,37,512,1024,2048,4096,41,5156,0,3,5173,2080,1025,1,4113,0,17,34,41,48,2049,5173,4129,2080,1056,33,36,32,5156,512]

theorem envBound32653 : H12AffineFastState.Bounded env32653 := by
  intro p hp
  have h : env32653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32652_32653 : H12AffineEnvironment.transform 7 37 env32652 = env32653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32652 == env32653) = true)

theorem identity32653 : scanCanonicalize (H12AffineFastState.compose env32653 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32653 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32654 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,4096,9,5124,0,3,5141,2048,1025,1,4113,0,17,2,9,16,2049,5141,4097,2048,1024,1,4,0,5124,512]

theorem envBound32654 : H12AffineFastState.Bounded env32654 := by
  intro p hp
  have h : env32654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32653_32654 : H12AffineEnvironment.transform 4 0 env32653 = env32654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32653 == env32654) = true)

theorem identity32654 : scanCanonicalize (H12AffineFastState.compose env32654 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3598) := by decide +kernel

theorem selectedBound32654 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32655 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,3598,9,2570,0,3,2587,2048,1025,1,3615,0,17,2,9,16,2049,2587,3599,2048,1024,1,4,0,2570,512]

theorem envBound32655 : H12AffineFastState.Bounded env32655 := by
  intro p hp
  have h : env32655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32654_32655 : H12AffineEnvironment.transform 11 3598 env32654 = env32655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3598 env32654 == env32655) = true)

theorem identity32655 : scanCanonicalize (H12AffineFastState.compose env32655 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound32655 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32656 : List Nat := [2,4,8,16,0,16,8,5,512,30,2048,2576,9,2570,0,3,2587,2048,31,1,2561,0,17,2,9,16,2049,2587,2577,2048,30,1,4,0,2570,512]

theorem envBound32656 : H12AffineFastState.Bounded env32656 := by
  intro p hp
  have h : env32656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32655_32656 : H12AffineEnvironment.transform 9 30 env32655 = env32656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env32655 == env32656) = true)

theorem identity32656 : scanCanonicalize (H12AffineFastState.compose env32656 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound32656 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32657 : List Nat := [2,4,8,16,0,16,8,5,17,30,2048,2049,9,2075,0,3,2058,2048,31,1,2064,0,17,2,9,16,2049,2058,2048,2048,30,1,4,0,2075,17]

theorem envBound32657 : H12AffineFastState.Bounded env32657 := by
  intro p hp
  have h : env32657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32656_32657 : H12AffineEnvironment.transform 8 17 env32656 = env32657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env32656 == env32657) = true)

theorem identity32657 : scanCanonicalize (H12AffineFastState.compose env32657 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound32657 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32658 : List Nat := [2,4,8,16,0,16,8,5,17,30,11,10,9,16,0,3,1,11,31,1,27,0,17,2,9,16,10,1,11,11,30,1,4,0,16,17]

theorem envBound32658 : H12AffineFastState.Bounded env32658 := by
  intro p hp
  have h : env32658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32657_32658 : H12AffineEnvironment.transform 10 11 env32657 = env32658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env32657 == env32658) = true)

theorem identity32658 : scanCanonicalize (H12AffineFastState.compose env32658 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound32658 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32659 : List Nat := [2,4,8,2,0,2,8,5,3,12,11,10,9,2,0,3,1,11,13,1,9,0,3,2,9,2,10,1,11,11,12,1,4,0,2,3]

theorem envBound32659 : H12AffineFastState.Bounded env32659 := by
  intro p hp
  have h : env32659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32658_32659 : H12AffineEnvironment.transform 3 2 env32658 = env32659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env32658 == env32659) = true)

theorem identity32659 : scanCanonicalize (H12AffineFastState.compose env32659 (packedSelected [0,8] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound32659 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env32660 : List Nat := [1,4,8,1,0,1,8,5,0,12,8,9,9,1,0,0,1,8,13,1,9,0,0,1,9,1,9,1,8,8,12,1,4,0,1,0]

theorem envBound32660 : H12AffineFastState.Bounded env32660 := by
  intro p hp
  have h : env32660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32659_32660 : H12AffineEnvironment.transform 0 1 env32659 = env32660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env32659 == env32660) = true)

theorem identity32660 : scanCanonicalize (H12AffineFastState.compose env32660 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound32660 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32661 : List Nat := [1,1,8,1,0,1,8,0,0,9,8,9,9,1,0,0,1,8,8,1,9,0,0,1,9,1,9,1,8,8,9,1,1,0,1,0]

theorem envBound32661 : H12AffineFastState.Bounded env32661 := by
  intro p hp
  have h : env32661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32660_32661 : H12AffineEnvironment.transform 1 1 env32660 = env32661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env32660 == env32661) = true)

theorem identity32661 : scanCanonicalize (H12AffineFastState.compose env32661 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound32661 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env32662 : List Nat := [1,1,0,1,0,1,0,0,0,1,0,1,1,1,0,0,1,0,0,1,1,0,0,1,1,1,1,1,0,0,1,1,1,0,1,0]

theorem envBound32662 : H12AffineFastState.Bounded env32662 := by
  intro p hp
  have h : env32662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32661_32662 : H12AffineEnvironment.transform 2 0 env32661 = env32662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env32661 == env32662) = true)

def env32663 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58397,272392,17,95497,8193,64,23808,5392,45404,262145,61704,318548,257,21793,46092,120406]

theorem envBound32663 : H12AffineFastState.Bounded env32663 := by
  intro p hp
  have h : env32663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32645_32663 : H12AffineEnvironment.transform 6 9 env32645 = env32663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32645 == env32663) = true)

theorem identity32663 : scanCanonicalize (H12AffineFastState.compose env32663 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32663 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32664 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,58397,32,17,95497,8193,64,23808,5392,45404,10281,61704,62588,257,21793,46092,120406]

theorem envBound32664 : H12AffineFastState.Bounded env32664 := by
  intro p hp
  have h : env32664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32663_32664 : H12AffineEnvironment.transform 17 10280 env32663 = env32664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env32663 == env32664) = true)

theorem identity32664 : scanCanonicalize (H12AffineFastState.compose env32664 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound32664 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env32665 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,65536,16449,10280,1025,80,25676,32,17,95497,8193,64,23808,5392,12557,10281,29017,29741,257,21793,13405,87559]

theorem envBound32665 : H12AffineFastState.Bounded env32665 := by
  intro p hp
  have h : env32665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32664_32665 : H12AffineEnvironment.transform 14 81 env32664 = env32665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env32664 == env32665) = true)

theorem identity32665 : scanCanonicalize (H12AffineFastState.compose env32665 (packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound32665 : packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env32666 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,30042,16449,10280,1025,80,25676,32,17,83,8193,64,23808,5392,12557,10281,29017,29741,257,21793,13405,9053]

theorem envBound32666 : H12AffineFastState.Bounded env32666 := by
  intro p hp
  have h : env32666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32665_32666 : H12AffineEnvironment.transform 15 30042 env32665 = env32666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env32665 == env32666) = true)

theorem identity32666 : scanCanonicalize (H12AffineFastState.compose env32666 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32666 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env32667 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,29962,16401,10280,1025,0,25628,32,17,3,8193,16,23808,5392,12557,10281,28937,29741,257,21793,13325,8973]

theorem envBound32667 : H12AffineFastState.Bounded env32667 := by
  intro p hp
  have h : env32667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32666_32667 : H12AffineEnvironment.transform 5 16 env32666 = env32667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32666 == env32667) = true)

theorem identity32667 : scanCanonicalize (H12AffineFastState.compose env32667 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound32667 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env32668 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3108,8192,16384,1,26926,16401,10280,1025,0,25628,32,17,3,8193,16,16676,2356,11561,10281,27949,26633,257,18693,10281,8973]

theorem envBound32668 : H12AffineFastState.Bounded env32668 := by
  intro p hp
  have h : env32668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32667_32668 : H12AffineEnvironment.transform 11 3108 env32667 = env32668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env32667 == env32668) = true)

theorem identity32668 : scanCanonicalize (H12AffineFastState.compose env32668 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 10280) := by decide +kernel

theorem selectedBound32668 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32669 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3108,8192,10280,1,262,10297,10280,1025,0,3124,32,17,3,8193,16,10508,2356,11561,10281,1285,33,257,8493,10281,8973]

theorem envBound32669 : H12AffineFastState.Bounded env32669 := by
  intro p hp
  have h : env32669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32668_32669 : H12AffineEnvironment.transform 13 10280 env32668 = env32669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10280 env32668 == env32669) = true)

theorem identity32669 : scanCanonicalize (H12AffineFastState.compose env32669 (packedSelected [2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3133) := by decide +kernel

theorem selectedBound32669 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env32670 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3108,3133,1045,1,262,1028,1045,1025,0,3124,32,17,3,3132,16,1329,2356,276,1044,1285,33,257,3344,1044,3888]

theorem envBound32670 : H12AffineFastState.Bounded env32670 := by
  intro p hp
  have h : env32670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32669_32670 : H12AffineEnvironment.transform 12 3133 env32669 = env32670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3133 env32669 == env32670) = true)

theorem identity32670 : scanCanonicalize (H12AffineFastState.compose env32670 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound32670 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env32671 : List Nat := [2,4,8,16,32,16,9,256,512,1024,261,1313,1336,1045,1,262,1028,1045,1025,0,1329,32,17,3,1337,16,1329,49,276,1044,1285,33,257,1045,1044,1589]

theorem envBound32671 : H12AffineFastState.Bounded env32671 := by
  intro p hp
  have h : env32671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32670_32671 : H12AffineEnvironment.transform 10 261 env32670 = env32671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env32670 == env32671) = true)

theorem identity32671 : scanCanonicalize (H12AffineFastState.compose env32671 (packedSelected [0,1,2,3,4,6,12] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound32671 : packedSelected [0,1,2,3,4,6,12] rootPS < 2^1333 := by decide +kernel

def env32672 : List Nat := [2,4,8,16,32,16,9,256,512,52,261,277,268,33,1,262,48,33,53,0,261,32,17,3,269,16,261,49,276,32,305,33,257,33,32,513]

theorem envBound32672 : H12AffineFastState.Bounded env32672 := by
  intro p hp
  have h : env32672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32671_32672 : H12AffineEnvironment.transform 9 52 env32671 = env32672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32671 == env32672) = true)

theorem identity32672 : scanCanonicalize (H12AffineFastState.compose env32672 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound32672 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32673 : List Nat := [2,4,8,16,32,16,9,53,512,52,48,32,57,33,1,51,48,33,53,0,48,32,17,3,56,16,48,49,33,32,4,33,52,33,32,513]

theorem envBound32673 : H12AffineFastState.Bounded env32673 := by
  intro p hp
  have h : env32673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32672_32673 : H12AffineEnvironment.transform 7 53 env32672 = env32673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env32672 == env32673) = true)

theorem identity32673 : scanCanonicalize (H12AffineFastState.compose env32673 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound32673 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32674 : List Nat := [2,4,8,16,32,16,9,53,32,52,48,32,57,33,1,51,48,33,53,0,48,32,17,3,56,16,48,49,33,32,4,33,52,33,32,33]

theorem envBound32674 : H12AffineFastState.Bounded env32674 := by
  intro p hp
  have h : env32674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32673_32674 : H12AffineEnvironment.transform 8 32 env32673 = env32674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env32673 == env32674) = true)

theorem identity32674 : scanCanonicalize (H12AffineFastState.compose env32674 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound32674 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32675 : List Nat := [2,4,8,16,16,16,9,5,16,4,0,16,9,17,1,3,0,17,5,0,0,16,17,3,8,16,0,1,17,16,4,17,4,17,16,17]

theorem envBound32675 : H12AffineFastState.Bounded env32675 := by
  intro p hp
  have h : env32675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32674_32675 : H12AffineEnvironment.transform 4 16 env32674 = env32675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env32674 == env32675) = true)

def env32676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,4194304,180361,95496,8328,64,4486529,185736,45524,262281,143761,4338884,257,21793,46213,202310]

theorem envBound32676 : H12AffineFastState.Bounded env32676 := by
  intro p hp
  have h : env32676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32589_32676 : H12AffineEnvironment.transform 22 180361 env32589 = env32676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env32589 == env32676) = true)

def env32677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272512,180361,95496,8328,64,23809,185736,45524,262281,143761,400452,257,21793,46213,202310]

theorem envBound32677 : H12AffineFastState.Bounded env32677 := by
  intro p hp
  have h : env32677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32676_32677 : H12AffineEnvironment.transform 21 272512 env32676 = env32677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env32676 == env32677) = true)

theorem identity32677 : scanCanonicalize (H12AffineFastState.compose env32677 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound32677 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,140301,272512,144477,95496,8328,64,23809,139612,17664,262281,143761,400452,257,21793,16465,202310]

theorem envBound32678 : H12AffineFastState.Bounded env32678 := by
  intro p hp
  have h : env32678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32677_32678 : H12AffineEnvironment.transform 14 29908 env32677 = env32678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env32677 == env32678) = true)

def env32679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140301,272392,144477,95496,8192,64,23809,139612,17664,262145,143641,400452,257,21793,16465,202310]

theorem envBound32679 : H12AffineFastState.Bounded env32679 := by
  intro p hp
  have h : env32679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32678_32679 : H12AffineEnvironment.transform 6 8 env32678 = env32679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32678 == env32679) = true)

theorem identity32679 : scanCanonicalize (H12AffineFastState.compose env32679 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound32679 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env32680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1025,29789,140301,33,144477,95496,8192,64,23809,139612,17664,10280,143641,144493,257,21793,16465,202310]

theorem envBound32680 : H12AffineFastState.Bounded env32680 := by
  intro p hp
  have h : env32680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32679_32680 : H12AffineEnvironment.transform 17 10281 env32679 = env32680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env32679 == env32680) = true)

theorem identity32680 : scanCanonicalize (H12AffineFastState.compose env32680 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound32680 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32681 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1025,8541,140301,33,144477,73736,8192,64,2049,139612,4096,10280,143641,144493,257,33,5457,202310]

theorem envBound32681 : H12AffineFastState.Bounded env32681 := by
  intro p hp
  have h : env32681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32680_32681 : H12AffineEnvironment.transform 13 5376 env32680 = env32681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env32680 == env32681) = true)

theorem identity32681 : scanCanonicalize (H12AffineFastState.compose env32681 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 78127) := by decide +kernel

theorem selectedBound32681 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env32682 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,78127,10281,1025,8541,70946,33,66930,73736,8192,64,2049,69747,4096,10280,65590,66882,257,33,5457,10089]

theorem envBound32682 : H12AffineFastState.Bounded env32682 := by
  intro p hp
  have h : env32682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32681_32682 : H12AffineEnvironment.transform 16 78127 env32681 = env32682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78127 env32681 == env32682) = true)

theorem identity32682 : scanCanonicalize (H12AffineFastState.compose env32682 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32682 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32683 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5156,8312,65536,77835,10281,1025,8313,70662,33,66646,73736,8192,64,2049,69747,4096,10280,65590,66662,37,33,5237,9805]

theorem envBound32683 : H12AffineFastState.Bounded env32683 := by
  intro p hp
  have h : env32683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32682_32683 : H12AffineEnvironment.transform 7 36 env32682 = env32683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32682 == env32683) = true)

theorem identity32683 : scanCanonicalize (H12AffineFastState.compose env32683 (packedSelected [11,16,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound32683 : packedSelected [11,16,20,23] rootPS < 2^1333 := by decide +kernel

def env32684 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,1100,5156,1076,65536,70727,3173,1025,1077,70662,33,66646,66628,1100,64,2049,69747,4096,3172,65590,66662,37,33,5237,513]

theorem envBound32684 : H12AffineFastState.Bounded env32684 := by
  intro p hp
  have h : env32684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32683_32684 : H12AffineEnvironment.transform 12 1100 env32683 = env32684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env32683 == env32684) = true)

theorem identity32684 : scanCanonicalize (H12AffineFastState.compose env32684 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound32684 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env32685 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,1100,5156,1076,1094,4097,3173,1025,1077,4160,33,16,2,1100,64,2049,5173,4096,3172,1136,32,37,33,5237,513]

theorem envBound32685 : H12AffineFastState.Bounded env32685 := by
  intro p hp
  have h : env32685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32684_32685 : H12AffineEnvironment.transform 15 1094 env32684 = env32685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env32684 == env32685) = true)

theorem identity32685 : scanCanonicalize (H12AffineFastState.compose env32685 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound32685 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env32686 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,2113,1100,3173,1076,1094,2112,3173,1025,1077,2049,33,16,2,1100,64,2049,3188,2113,3172,1136,32,37,33,3124,513]

theorem envBound32686 : H12AffineFastState.Bounded env32686 := by
  intro p hp
  have h : env32686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32685_32686 : H12AffineEnvironment.transform 11 2113 env32685 = env32686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env32685 == env32686) = true)

theorem identity32686 : scanCanonicalize (H12AffineFastState.compose env32686 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound32686 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env32687 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,2113,40,2049,80,34,2112,2049,101,81,2049,33,16,2,40,64,2049,2064,2113,2048,20,32,37,33,2128,513]

theorem envBound32687 : H12AffineFastState.Bounded env32687 := by
  intro p hp
  have h : env32687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32686_32687 : H12AffineEnvironment.transform 9 100 env32686 = env32687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env32686 == env32687) = true)

theorem identity32687 : scanCanonicalize (H12AffineFastState.compose env32687 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32687 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env32688 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2065,40,2049,0,34,2064,2049,53,1,2049,33,16,2,40,16,2049,2064,2065,2048,20,32,37,33,2048,513]

theorem envBound32688 : H12AffineFastState.Bounded env32688 := by
  intro p hp
  have h : env32688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32687_32688 : H12AffineEnvironment.transform 5 16 env32687 = env32688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32687 == env32688) = true)

theorem identity32688 : scanCanonicalize (H12AffineFastState.compose env32688 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound32688 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32689 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,33,40,49,0,34,32,49,53,1,49,33,16,2,40,16,49,32,33,48,20,32,37,33,48,513]

theorem envBound32689 : H12AffineFastState.Bounded env32689 := by
  intro p hp
  have h : env32689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32688_32689 : H12AffineEnvironment.transform 10 48 env32688 = env32689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env32688 == env32689) = true)

def leafEnv32689 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,33,40,49,0,34,32,49,53,1,49,33,16,2,21,40,1,16,49,32,33,48,20,32,37,33,5,34,48,513,1,48,0]

def active32689 : List Nat := [0,1,2,3,4,8]

def tree32689 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32689 : H12WitnessSearch.Good tree32689 := H12GlobalWitnessIndex.good

theorem leafIdentity32689 : H12AffineFastState.composeSystem env32689 rootObs = leafEnv32689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32689 rootObs == leafEnv32689) = true)

theorem terminalChecked32689 : H12PackedTerminal.terminalCheckFast leafEnv32689 active32689 tree32689 = true := by decide +kernel

def env32690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140301,272393,144477,95496,8193,64,23809,139612,17664,262144,143640,400452,257,21793,16465,202310]

theorem envBound32690 : H12AffineFastState.Bounded env32690 := by
  intro p hp
  have h : env32690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32678_32690 : H12AffineEnvironment.transform 6 9 env32678 = env32690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32678 == env32690) = true)

theorem identity32690 : scanCanonicalize (H12AffineFastState.compose env32690 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 76159) := by decide +kernel

theorem selectedBound32690 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env32691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,76159,1025,29788,140301,65910,144477,95496,8193,64,23809,139612,17664,76159,143640,210235,257,21793,16465,202310]

theorem envBound32691 : H12AffineFastState.Bounded env32691 := by
  intro p hp
  have h : env32691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32690_32691 : H12AffineEnvironment.transform 17 76159 env32690 = env32691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76159 env32690 == env32691) = true)

theorem identity32691 : scanCanonicalize (H12AffineFastState.compose env32691 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound32691 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env32692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,70727,76159,1025,29788,77898,65910,73754,95496,8193,64,23809,79131,17664,76159,75103,8572,257,21793,16465,513]

theorem envBound32692 : H12AffineFastState.Bounded env32692 := by
  intro p hp
  have h : env32692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32691_32692 : H12AffineEnvironment.transform 16 70727 env32691 = env32692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env32691 == env32692) = true)

theorem identity32692 : scanCanonicalize (H12AffineFastState.compose env32692 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound32692 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env32693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,70727,76159,1025,8541,77898,65910,73754,73737,8193,64,2048,79131,4097,76159,75103,8572,257,32,5456,513]

theorem envBound32693 : H12AffineFastState.Bounded env32693 := by
  intro p hp
  have h : env32693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32692_32693 : H12AffineEnvironment.transform 13 5377 env32692 = env32693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env32692 == env32693) = true)

theorem identity32693 : scanCanonicalize (H12AffineFastState.compose env32693 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32693 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32694 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,65536,70727,67618,1025,0,69911,65910,65863,65876,348,64,2048,70726,4097,67618,66562,33,257,32,5456,513]

theorem envBound32694 : H12AffineFastState.Bounded env32694 := by
  intro p hp
  have h : env32694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32693_32694 : H12AffineEnvironment.transform 12 349 env32693 = env32694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32693 == env32694) = true)

theorem identity32694 : scanCanonicalize (H12AffineFastState.compose env32694 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32694 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env32695 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5156,1,65536,70727,67618,1025,0,69682,65619,65634,65649,121,64,2048,70726,4097,67618,66562,33,36,32,5237,513]

theorem envBound32695 : H12AffineFastState.Bounded env32695 := by
  intro p hp
  have h : env32695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32694_32695 : H12AffineEnvironment.transform 7 37 env32694 = env32695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32694 == env32695) = true)

theorem identity32695 : scanCanonicalize (H12AffineFastState.compose env32695 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound32695 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env32696 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5156,1,35,5220,2049,1025,0,4113,112,65,82,121,64,2048,5221,4097,2049,1057,33,36,32,5237,513]

theorem envBound32696 : H12AffineFastState.Bounded env32696 := by
  intro p hp
  have h : env32696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32695_32696 : H12AffineEnvironment.transform 15 35 env32695 = env32696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env32695 == env32696) = true)

theorem identity32696 : scanCanonicalize (H12AffineFastState.compose env32696 (packedSelected [4,5,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32696 : packedSelected [4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env32697 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5156,1,35,5173,2049,1025,0,4113,33,16,3,40,17,2048,5172,4097,2049,1057,33,36,32,5156,513]

theorem envBound32697 : H12AffineFastState.Bounded env32697 := by
  intro p hp
  have h : env32697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32696_32697 : H12AffineEnvironment.transform 5 17 env32696 = env32697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32696 == env32697) = true)

def env32698 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,41,1044,1,35,1029,2049,1025,0,33,33,16,3,40,17,2048,1028,49,2049,1057,33,36,32,1044,513]

theorem envBound32698 : H12AffineFastState.Bounded env32698 := by
  intro p hp
  have h : env32698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32697_32698 : H12AffineEnvironment.transform 11 48 env32697 = env32698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32697 == env32698) = true)

theorem identity32698 : scanCanonicalize (H12AffineFastState.compose env32698 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound32698 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32699 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,48,41,32,1,35,49,2049,53,0,33,33,16,3,40,17,2048,48,49,2049,21,33,36,32,32,513]

theorem envBound32699 : H12AffineFastState.Bounded env32699 := by
  intro p hp
  have h : env32699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32698_32699 : H12AffineEnvironment.transform 9 52 env32698 = env32699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32698 == env32699) = true)

def env32700 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,41,1045,1,35,1028,2049,1025,0,32,33,16,3,40,17,2048,1029,48,2049,1057,33,36,32,1045,513]

theorem envBound32700 : H12AffineFastState.Bounded env32700 := by
  intro p hp
  have h : env32700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32697_32700 : H12AffineEnvironment.transform 11 49 env32697 = env32700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env32697 == env32700) = true)

def env32701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272513,180361,95496,8328,64,23808,185736,45524,262281,143761,400453,257,21793,46213,202310]

theorem envBound32701 : H12AffineFastState.Bounded env32701 := by
  intro p hp
  have h : env32701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32676_32701 : H12AffineEnvironment.transform 21 272513 env32676 = env32701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env32676 == env32701) = true)

theorem identity32701 : scanCanonicalize (H12AffineFastState.compose env32701 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound32701 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4161,272513,62661,95496,8328,64,23808,57796,45524,262281,1501,272393,257,21793,46213,74250]

theorem envBound32702 : H12AffineFastState.Bounded env32702 := by
  intro p hp
  have h : env32702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32701_32702 : H12AffineEnvironment.transform 16 13388 env32701 = env32702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env32701 == env32702) = true)

theorem identity32702 : scanCanonicalize (H12AffineFastState.compose env32702 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32702 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env32703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,13388,262144,1025,32769,4161,272513,62661,21763,8328,64,23808,57796,45524,262281,1501,272393,257,21793,46213,513]

theorem envBound32703 : H12AffineFastState.Bounded env32703 := by
  intro p hp
  have h : env32703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32702_32703 : H12AffineEnvironment.transform 15 8203 env32702 = env32703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32702 == env32703) = true)

theorem identity32703 : scanCanonicalize (H12AffineFastState.compose env32703 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound32703 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env32704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,5528,262144,1025,32769,4161,264533,54545,21763,348,64,23808,49168,36864,262281,1501,264669,257,21793,38225,513]

theorem envBound32704 : H12AffineFastState.Bounded env32704 := by
  intro p hp
  have h : env32704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32703_32704 : H12AffineEnvironment.transform 12 468 env32703 = env32704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env32703 == env32704) = true)

theorem identity32704 : scanCanonicalize (H12AffineFastState.compose env32704 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound32704 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env32705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,5528,2420,1025,32769,4161,33,54545,21763,348,64,23808,49168,36864,2557,1501,169,257,21793,38225,513]

theorem envBound32705 : H12AffineFastState.Bounded env32705 := by
  intro p hp
  have h : env32705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32704_32705 : H12AffineEnvironment.transform 17 2420 env32704 = env32705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env32704 == env32705) = true)

theorem identity32705 : scanCanonicalize (H12AffineFastState.compose env32705 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound32705 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env32706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4112,32768,479,5528,2420,1025,32769,4161,33,34049,1299,348,64,3344,36864,36864,2557,1501,169,257,1329,38225,513]

theorem envBound32706 : H12AffineFastState.Bounded env32706 := by
  intro p hp
  have h : env32706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32705_32706 : H12AffineEnvironment.transform 13 4112 env32705 = env32706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env32705 == env32706) = true)

theorem identity32706 : scanCanonicalize (H12AffineFastState.compose env32706 (packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 6297) := by decide +kernel

theorem selectedBound32706 : packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env32707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4112,6297,479,5528,2420,1025,6296,4161,33,7576,1299,348,64,3344,2201,2201,2557,1501,169,257,1329,3528,513]

theorem envBound32707 : H12AffineFastState.Bounded env32707 := by
  intro p hp
  have h : env32707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32706_32707 : H12AffineEnvironment.transform 14 6297 env32706 = env32707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6297 env32706 == env32707) = true)

theorem identity32707 : scanCanonicalize (H12AffineFastState.compose env32707 (packedSelected [0,4,6,10,11,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound32707 : packedSelected [0,4,6,10,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env32708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,468,508,2421,479,1140,2420,1025,2420,429,33,3188,1299,348,64,3344,2201,2201,2557,1501,169,257,1329,3528,513]

theorem envBound32708 : H12AffineFastState.Bounded env32708 := by
  intro p hp
  have h : env32708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32707_32708 : H12AffineEnvironment.transform 11 492 env32707 = env32708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env32707 == env32708) = true)

theorem identity32708 : scanCanonicalize (H12AffineFastState.compose env32708 (packedSelected [0,1,2,6,7,8,10,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32708 : packedSelected [0,1,2,6,7,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env32709 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,356,348,372,2421,343,1140,2420,1025,2420,293,33,3188,1299,348,64,3344,2065,2065,2421,1365,33,257,1329,3392,513]

theorem envBound32709 : H12AffineFastState.Bounded env32709 := by
  intro p hp
  have h : env32709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32708_32709 : H12AffineEnvironment.transform 6 8 env32708 = env32709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32708 == env32709) = true)

theorem identity32709 : scanCanonicalize (H12AffineFastState.compose env32709 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound32709 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32710 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,356,348,372,80,343,1140,81,1025,81,293,33,1361,1299,348,64,1077,308,308,80,1365,33,257,1329,1125,513]

theorem envBound32710 : H12AffineFastState.Bounded env32710 := by
  intro p hp
  have h : env32710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32709_32710 : H12AffineEnvironment.transform 10 293 env32709 = env32710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env32709 == env32710) = true)

theorem identity32710 : scanCanonicalize (H12AffineFastState.compose env32710 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound32710 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32711 : List Nat := [2,4,8,16,32,64,8,256,512,53,293,356,348,372,80,343,65,81,52,81,293,33,356,294,348,64,0,308,308,80,352,33,257,260,80,513]

theorem envBound32711 : H12AffineFastState.Bounded env32711 := by
  intro p hp
  have h : env32711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32710_32711 : H12AffineEnvironment.transform 9 53 env32710 = env32711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32710 == env32711) = true)

theorem identity32711 : scanCanonicalize (H12AffineFastState.compose env32711 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32711 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env32712 : List Nat := [2,4,8,16,32,64,8,37,512,53,0,65,121,81,80,114,65,81,52,81,0,33,65,3,121,64,0,17,17,80,69,33,36,33,80,513]

theorem envBound32712 : H12AffineFastState.Bounded env32712 := by
  intro p hp
  have h : env32712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32711_32712 : H12AffineEnvironment.transform 7 37 env32711 = env32712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32711 == env32712) = true)

theorem identity32712 : scanCanonicalize (H12AffineFastState.compose env32712 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32712 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32713 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,16,40,0,1,35,16,0,52,0,0,33,16,3,40,17,0,17,17,1,20,33,36,33,1,513]

theorem envBound32713 : H12AffineFastState.Bounded env32713 := by
  intro p hp
  have h : env32713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32712_32713 : H12AffineEnvironment.transform 5 17 env32712 = env32713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32712 == env32713) = true)

theorem identity32713 : scanCanonicalize (H12AffineFastState.compose env32713 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound32713 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32714 : List Nat := [2,4,8,16,32,17,8,37,26,53,0,16,40,0,1,35,16,0,52,0,0,33,16,3,40,17,0,17,17,1,20,33,36,33,1,27]

theorem envBound32714 : H12AffineFastState.Bounded env32714 := by
  intro p hp
  have h : env32714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32713_32714 : H12AffineEnvironment.transform 8 26 env32713 = env32714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env32713 == env32714) = true)

theorem identity32714 : scanCanonicalize (H12AffineFastState.compose env32714 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32714 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32715 : List Nat := [2,4,8,1,32,0,8,37,11,36,0,1,40,0,1,35,1,0,37,0,0,33,1,3,40,0,0,0,0,1,5,33,36,33,1,10]

theorem envBound32715 : H12AffineFastState.Bounded env32715 := by
  intro p hp
  have h : env32715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32714_32715 : H12AffineEnvironment.transform 3 1 env32714 = env32715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32714 == env32715) = true)

theorem identity32715 : scanCanonicalize (H12AffineFastState.compose env32715 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound32715 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32716 : List Nat := [2,4,3,1,32,0,3,37,0,36,0,1,35,0,1,35,1,0,37,0,0,33,1,3,35,0,0,0,0,1,5,33,36,33,1,1]

theorem envBound32716 : H12AffineFastState.Bounded env32716 := by
  intro p hp
  have h : env32716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32715_32716 : H12AffineEnvironment.transform 2 3 env32715 = env32716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env32715 == env32716) = true)

def env32717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254784,25265169,145662400,525568,140903597,27337993,25733062]

theorem envBound32717 : H12AffineFastState.Bounded env32717 := by
  intro p hp
  have h : env32717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31963_32717 : H12AffineEnvironment.transform 25 65 env31963 = env32717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env31963 == env32717) = true)

def env32718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356288,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound32718 : H12AffineFastState.Bounded env32718 := by
  intro p hp
  have h : env32718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32717_32718 : H12AffineEnvironment.transform 26 30393344 env32717 = env32718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env32717 == env32718) = true)

def env32719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound32719 : H12AffineFastState.Bounded env32719 := by
  intro p hp
  have h : env32719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32718_32719 : H12AffineEnvironment.transform 18 1024 env32718 = env32719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env32718 == env32719) = true)

theorem identity32719 : scanCanonicalize (H12AffineFastState.compose env32719 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 485741) := by decide +kernel

theorem selectedBound32719 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env32720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,485741,8328,65,12626285,2551265,10507601,8830976,8842620,6687917,256,10923456,10898532,8899243]

theorem envBound32720 : H12AffineFastState.Bounded env32720 := by
  intro p hp
  have h : env32720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32719_32720 : H12AffineEnvironment.transform 23 485741 env32719 = env32720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 485741 env32719 == env32720) = true)

def env32721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2554080,485741,8328,65,6705549,2551265,437681,2111712,2102684,6687917,256,21792,46212,2175563]

theorem envBound32721 : H12AffineFastState.Bounded env32721 := by
  intro p hp
  have h : env32721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32720_32721 : H12AffineEnvironment.transform 22 2554080 env32720 = env32721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2554080 env32720 == env32721) = true)

def env32722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101328,98781,8328,65,6338877,2098513,17665,2111712,2102684,6349853,256,21792,46212,2175563]

theorem envBound32722 : H12AffineFastState.Bounded env32722 := by
  intro p hp
  have h : env32722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32721_32722 : H12AffineEnvironment.transform 17 190640 env32721 = env32722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env32721 == env32722) = true)

def env32723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,16,98781,8328,65,4237693,5393,17665,10400,1500,4256861,256,21792,46212,74251]

theorem envBound32723 : H12AffineFastState.Bounded env32723 := by
  intro p hp
  have h : env32723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32722_32723 : H12AffineEnvironment.transform 20 4160 env32722 = env32723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32722 == env32723) = true)

theorem identity32723 : scanCanonicalize (H12AffineFastState.compose env32723 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound32723 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,138341,1024,29908,4160,4194304,16,95496,8328,65,4218280,5393,17665,10400,1500,4194440,256,21792,16465,74251]

theorem envBound32724 : H12AffineFastState.Bounded env32724 := by
  intro p hp
  have h : env32724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32723_32724 : H12AffineEnvironment.transform 14 29909 env32723 = env32724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env32723 == env32724) = true)

def env32725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138341,1024,8660,4160,4194304,16,73736,8328,65,4196520,5393,4097,10400,1500,4194440,256,32,5457,74251]

theorem envBound32725 : H12AffineFastState.Bounded env32725 := by
  intro p hp
  have h : env32725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32724_32725 : H12AffineEnvironment.transform 13 5376 env32724 = env32725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env32724 == env32725) = true)

theorem identity32725 : scanCanonicalize (H12AffineFastState.compose env32725 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound32725 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13389,10280,1024,8660,4160,4194304,16,73736,8328,65,4196520,5393,4097,10400,1500,4194440,256,32,5457,74251]

theorem envBound32726 : H12AffineFastState.Bounded env32726 := by
  intro p hp
  have h : env32726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32725_32726 : H12AffineEnvironment.transform 16 13389 env32725 = env32726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env32725 == env32726) = true)

theorem identity32726 : scanCanonicalize (H12AffineFastState.compose env32726 (packedSelected [2,3,5,6,7,9,10,16,22,23,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32726 : packedSelected [2,3,5,6,7,9,10,16,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env32727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,13389,10280,1024,8660,4160,4194304,16,3,8328,65,4196520,5393,4097,10400,1500,4194440,256,32,5457,512]

theorem envBound32727 : H12AffineFastState.Bounded env32727 := by
  intro p hp
  have h : env32727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32726_32727 : H12AffineEnvironment.transform 15 8203 env32726 = env32727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32726 == env32727) = true)

theorem identity32727 : scanCanonicalize (H12AffineFastState.compose env32727 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound32727 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,380,5376,169,375,5425,2388,1024,168,4160,4194304,16,3,500,65,4196520,5393,4097,2524,1500,4194440,256,32,5457,512]

theorem envBound32728 : H12AffineFastState.Bounded env32728 := by
  intro p hp
  have h : env32728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32727_32728 : H12AffineEnvironment.transform 12 380 env32727 = env32728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env32727 == env32728) = true)

theorem identity32728 : scanCanonicalize (H12AffineFastState.compose env32728 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound32728 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env32729 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,160,5340,169,171,5357,2184,1024,168,4160,4194304,16,3,40,65,4196520,5325,4097,2048,1024,4194440,220,32,5261,512]

theorem envBound32729 : H12AffineFastState.Bounded env32729 := by
  intro p hp
  have h : env32729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32728_32729 : H12AffineEnvironment.transform 7 220 env32728 = env32729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env32728 == env32729) = true)

theorem identity32729 : scanCanonicalize (H12AffineFastState.compose env32729 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound32729 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env32730 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,129,5340,136,138,5324,2184,1024,137,4160,4194304,16,3,9,65,4196489,5325,4097,2048,1024,4194440,220,1,5261,512]

theorem envBound32730 : H12AffineFastState.Bounded env32730 := by
  intro p hp
  have h : env32730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32729_32730 : H12AffineEnvironment.transform 4 1 env32729 = env32730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env32729 == env32730) = true)

theorem identity32730 : scanCanonicalize (H12AffineFastState.compose env32730 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound32730 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32731 : List Nat := [2,4,8,16,1,64,128,220,512,1024,0,4096,129,5340,136,138,5324,136,1024,137,4160,4194304,16,3,9,65,4194441,5325,4097,0,1024,4194440,220,1,5261,512]

theorem envBound32731 : H12AffineFastState.Bounded env32731 := by
  intro p hp
  have h : env32731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32730_32731 : H12AffineEnvironment.transform 10 0 env32730 = env32731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env32730 == env32731) = true)

def env32732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,138341,1024,8661,4160,4194304,16,73737,8328,65,4196521,5393,4096,10400,1500,4194440,256,33,5456,74251]

theorem envBound32732 : H12AffineFastState.Bounded env32732 := by
  intro p hp
  have h : env32732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32724_32732 : H12AffineEnvironment.transform 13 5377 env32724 = env32732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env32724 == env32732) = true)

theorem identity32732 : scanCanonicalize (H12AffineFastState.compose env32732 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound32732 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13508,10401,1024,8661,4160,4194304,16,73737,8328,65,4196521,5393,4096,10400,1500,4194440,256,33,5456,74251]

theorem envBound32733 : H12AffineFastState.Bounded env32733 := by
  intro p hp
  have h : env32733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32732_32733 : H12AffineEnvironment.transform 16 13508 env32732 = env32733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env32732 == env32733) = true)

theorem identity32733 : scanCanonicalize (H12AffineFastState.compose env32733 (packedSelected [0,1,2,5,6,10,12,14,15,18,24,27,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 8612) := by decide +kernel

theorem selectedBound32733 : packedSelected [0,1,2,5,6,10,12,14,15,18,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env32734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13508,10401,1024,8661,4160,8612,16,73737,8328,65,10509,5393,4096,10400,1500,8492,256,33,5456,74251]

theorem envBound32734 : H12AffineFastState.Bounded env32734 := by
  intro p hp
  have h : env32734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32733_32734 : H12AffineEnvironment.transform 21 8612 env32733 = env32734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8612 env32733 == env32734) = true)

theorem identity32734 : scanCanonicalize (H12AffineFastState.compose env32734 (packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32734 : packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,22,24] rootPS < 2^1333 := by decide +kernel

def env32735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,216,65536,5576,2477,1024,217,4160,168,16,65797,388,65,2049,5393,4096,2476,1500,32,256,33,5456,66311]

end H12CloudChart1