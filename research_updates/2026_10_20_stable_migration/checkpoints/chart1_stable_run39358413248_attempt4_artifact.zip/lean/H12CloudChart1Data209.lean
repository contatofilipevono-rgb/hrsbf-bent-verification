import H12CloudChart1Data208

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity52923 : scanCanonicalize (H12AffineFastState.compose env52923 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound52923 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env52924 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,40970,38161,35189,1025,32769,4161,32,8525,32770,8193,64,34817,46156,12637,43048,34133,33,257,32800,13324,513]

theorem envBound52924 : H12AffineFastState.Bounded env52924 := by
  intro p hp
  have h : env52924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52923_52924 : H12AffineEnvironment.transform 13 5376 env52923 = env52924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52923 == env52924) = true)

theorem identity52924 : scanCanonicalize (H12AffineFastState.compose env52924 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound52924 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env52925 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,342,13389,10281,1025,8541,4161,32,8525,8542,8193,64,10589,5392,12637,2420,9225,33,257,8572,13324,513]

theorem envBound52925 : H12AffineFastState.Bounded env52925 := by
  intro p hp
  have h : env52925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52924_52925 : H12AffineEnvironment.transform 14 8540 env52924 = env52925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52924 == env52925) = true)

theorem identity52925 : scanCanonicalize (H12AffineFastState.compose env52925 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52925 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52926 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,262,13341,10281,1025,8461,4113,32,8477,8462,8193,16,10509,5392,12557,2340,9225,33,257,8492,13324,513]

theorem envBound52926 : H12AffineFastState.Bounded env52926 := by
  intro p hp
  have h : env52926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52925_52926 : H12AffineEnvironment.transform 5 16 env52925 = env52926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52925 == env52926) = true)

theorem identity52926 : scanCanonicalize (H12AffineFastState.compose env52926 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound52926 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52927 : List Nat := [2,4,8,16,32,16,9,256,512,785,2048,4096,8192,4625,8460,262,13068,10281,784,8461,4113,32,8477,8462,8193,16,10509,4609,12557,2340,8984,33,257,8492,13085,513]

theorem envBound52927 : H12AffineFastState.Bounded env52927 := by
  intro p hp
  have h : env52927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52926_52927 : H12AffineEnvironment.transform 9 785 env52926 = env52927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env52926 == env52927) = true)

theorem identity52927 : scanCanonicalize (H12AffineFastState.compose env52927 (packedSelected [1,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52927 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env52928 : List Nat := [2,4,8,16,32,16,9,256,512,785,2048,4096,268,4625,0,262,4608,2341,784,1,4113,32,17,2,269,16,2049,4609,4097,2340,532,33,257,32,4625,513]

theorem envBound52928 : H12AffineFastState.Bounded env52928 := by
  intro p hp
  have h : env52928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52927_52928 : H12AffineEnvironment.transform 12 268 env52927 = env52928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52927 == env52928) = true)

theorem identity52928 : scanCanonicalize (H12AffineFastState.compose env52928 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound52928 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52929 : List Nat := [2,4,8,16,32,16,9,256,512,785,2048,261,268,788,0,262,773,2341,784,1,276,32,17,2,269,16,2049,772,260,2340,532,33,257,32,788,513]

theorem envBound52929 : H12AffineFastState.Bounded env52929 := by
  intro p hp
  have h : env52929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52928_52929 : H12AffineEnvironment.transform 11 261 env52928 = env52929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env52928 == env52929) = true)

theorem identity52929 : scanCanonicalize (H12AffineFastState.compose env52929 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound52929 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52930 : List Nat := [2,4,8,16,32,16,9,256,512,785,293,261,268,788,0,262,773,0,784,1,276,32,17,2,269,16,292,772,260,1,532,33,257,32,788,513]

theorem envBound52930 : H12AffineFastState.Bounded env52930 := by
  intro p hp
  have h : env52930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52929_52930 : H12AffineEnvironment.transform 10 293 env52929 = env52930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env52929 == env52930) = true)

theorem identity52930 : scanCanonicalize (H12AffineFastState.compose env52930 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52930 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52931 : List Nat := [2,4,8,0,32,0,9,256,512,769,293,261,268,772,0,262,773,0,768,1,260,32,1,2,269,0,292,772,260,1,516,33,257,32,772,513]

theorem envBound52931 : H12AffineFastState.Bounded env52931 := by
  intro p hp
  have h : env52931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52930_52931 : H12AffineEnvironment.transform 3 0 env52930 = env52931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52930 == env52931) = true)

theorem identity52931 : scanCanonicalize (H12AffineFastState.compose env52931 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound52931 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52932 : List Nat := [2,4,8,0,32,0,9,256,261,4,293,261,268,1,0,262,0,0,5,1,260,32,1,2,269,0,292,1,260,1,257,33,257,32,1,260]

theorem envBound52932 : H12AffineFastState.Bounded env52932 := by
  intro p hp
  have h : env52932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52931_52932 : H12AffineEnvironment.transform 8 261 env52931 = env52932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env52931 == env52932) = true)

def env52933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411972,213471,16777216,8328,64,16959643,16974301,102879,360926,16958927,17148372,257,16777251,16834950,17031704]

theorem envBound52933 : H12AffineFastState.Bounded env52933 := by
  intro p hp
  have h : env52933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52855_52933 : H12AffineEnvironment.transform 20 165201 env52855 = env52933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165201 env52855 == env52933) = true)

theorem identity52933 : scanCanonicalize (H12AffineFastState.compose env52933 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188871) := by decide +kernel

theorem selectedBound52933 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env52934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411972,213471,188871,8328,64,10588,122906,102879,360926,9224,477203,257,188900,131137,66527]

theorem envBound52934 : H12AffineFastState.Bounded env52934 := by
  intro p hp
  have h : env52934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52933_52934 : H12AffineEnvironment.transform 23 188871 env52933 = env52934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188871 env52933 == env52934) = true)

def env52935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,318548,120015,29911,8328,64,10588,122906,102879,360926,9224,384259,257,29940,38225,66527]

theorem envBound52935 : H12AffineFastState.Bounded env52935 := by
  intro p hp
  have h : env52935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52934_52935 : H12AffineEnvironment.transform 16 38160 env52934 = env52935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env52934 == env52935) = true)

theorem identity52935 : scanCanonicalize (H12AffineFastState.compose env52935 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound52935 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,25029,262144,1025,29908,4161,272513,73754,29911,8328,64,10588,70863,91402,357643,9224,338390,257,29940,24964,66527]

theorem envBound52936 : H12AffineFastState.Bounded env52936 := by
  intro p hp
  have h : env52936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52935_52936 : H12AffineEnvironment.transform 14 29909 env52935 = env52936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env52935 == env52936) = true)

def env52937 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,24981,262144,1025,29828,4113,272513,73754,29831,8328,16,10508,70815,91402,357643,9224,338310,257,29860,24964,66447]

theorem envBound52937 : H12AffineFastState.Bounded env52937 := by
  intro p hp
  have h : env52937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52936_52937 : H12AffineEnvironment.transform 5 16 env52936 = env52937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52936 == env52937) = true)

theorem identity52937 : scanCanonicalize (H12AffineFastState.compose env52937 (packedSelected [0,1,3,5,8,9,10,12,15,17,19,22,27,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52937 : packedSelected [0,1,3,5,8,9,10,12,15,17,19,22,27,38,41] rootPS < 2^1333 := by decide +kernel

def env52938 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,65536,24860,262144,1025,29709,4113,272392,73754,29710,8193,16,10508,70678,91402,357643,9224,338191,257,29741,24845,66310]

theorem envBound52938 : H12AffineFastState.Bounded env52938 := by
  intro p hp
  have h : env52938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52937_52938 : H12AffineEnvironment.transform 6 9 env52937 = env52938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52937 == env52938) = true)

theorem identity52938 : scanCanonicalize (H12AffineFastState.compose env52938 (packedSelected [3,10,16,19,20,24] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound52938 : packedSelected [3,10,16,19,20,24] rootPS < 2^1333 := by decide +kernel

def env52939 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,65536,24860,10280,1025,29709,4113,32,73754,29710,8193,16,10508,70678,91402,89379,9224,65831,257,29741,24845,66310]

theorem envBound52939 : H12AffineFastState.Bounded env52939 := by
  intro p hp
  have h : env52939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52938_52939 : H12AffineEnvironment.transform 17 10280 env52938 = env52939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52938 == env52939) = true)

theorem identity52939 : scanCanonicalize (H12AffineFastState.compose env52939 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound52939 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52940 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1052,16384,20496,65536,17664,3124,1025,20497,4113,32,66566,20498,1053,16,3344,70678,82198,89379,20,65831,257,20529,17681,66310]

theorem envBound52940 : H12AffineFastState.Bounded env52940 := by
  intro p hp
  have h : env52940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52939_52940 : H12AffineEnvironment.transform 12 1052 env52939 = env52940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env52939 == env52940) = true)

theorem identity52940 : scanCanonicalize (H12AffineFastState.compose env52940 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 1046) := by decide +kernel

theorem selectedBound52940 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52941 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1052,16384,20496,1046,17664,3124,1025,20497,4113,32,16,20498,1053,16,3344,4096,17664,22837,20,1329,257,20529,17681,1808]

theorem envBound52941 : H12AffineFastState.Bounded env52941 := by
  intro p hp
  have h : env52941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52940_52941 : H12AffineEnvironment.transform 15 1046 env52940 = env52941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1046 env52940 == env52941) = true)

theorem identity52941 : scanCanonicalize (H12AffineFastState.compose env52941 (packedSelected [2,5,6,7,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound52941 : packedSelected [2,5,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env52942 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,16384,20496,262,16400,2340,273,20497,4113,32,16,20498,269,16,2048,4096,16400,22837,20,33,257,20529,16385,512]

theorem envBound52942 : H12AffineFastState.Bounded env52942 := by
  intro p hp
  have h : env52942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52941_52942 : H12AffineEnvironment.transform 9 272 env52941 = env52942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env52941 == env52942) = true)

theorem identity52942 : scanCanonicalize (H12AffineFastState.compose env52942 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound52942 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env52943 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,2325,268,16384,18693,262,16400,2340,273,18692,2308,32,16,18695,269,16,2048,2325,16400,16416,20,33,257,18724,16385,512]

theorem envBound52943 : H12AffineFastState.Bounded env52943 := by
  intro p hp
  have h : env52943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52942_52943 : H12AffineEnvironment.transform 11 2325 env52942 = env52943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env52942 == env52943) = true)

theorem identity52943 : scanCanonicalize (H12AffineFastState.compose env52943 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52943 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52944 : List Nat := [2,4,8,16,1,16,9,256,512,272,2048,2325,268,16384,18693,262,16400,2309,273,18692,2308,1,16,18695,269,16,2048,2325,16400,16385,20,0,257,18693,16385,512]

theorem envBound52944 : H12AffineFastState.Bounded env52944 := by
  intro p hp
  have h : env52944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52943_52944 : H12AffineEnvironment.transform 4 1 env52943 = env52944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52943 == env52944) = true)

theorem identity52944 : scanCanonicalize (H12AffineFastState.compose env52944 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(13+1) ^^^ 2308) := by decide +kernel

theorem selectedBound52944 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env52945 : List Nat := [2,4,8,16,1,16,9,256,512,272,2048,2325,268,2308,1,262,2324,2309,273,0,2308,1,16,3,269,16,2048,2325,2324,2309,20,0,257,1,2309,512]

theorem envBound52945 : H12AffineFastState.Bounded env52945 := by
  intro p hp
  have h : env52945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52944_52945 : H12AffineEnvironment.transform 13 2308 env52944 = env52945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2308 env52944 == env52945) = true)

theorem identity52945 : scanCanonicalize (H12AffineFastState.compose env52945 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52945 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52946 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,2064,9,2049,1,3,2065,2048,20,0,2049,1,16,3,8,16,2048,2064,2065,2048,20,0,4,1,2048,512]

theorem envBound52946 : H12AffineFastState.Bounded env52946 := by
  intro p hp
  have h : env52946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52945_52946 : H12AffineEnvironment.transform 7 5 env52945 = env52946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52945 == env52946) = true)

theorem identity52946 : scanCanonicalize (H12AffineFastState.compose env52946 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound52946 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52947 : List Nat := [2,4,8,16,1,16,9,5,1,21,2048,2064,9,2049,1,3,2065,2048,20,0,2049,1,16,3,8,16,2048,2064,2065,2048,20,0,4,1,2048,1]

theorem envBound52947 : H12AffineFastState.Bounded env52947 := by
  intro p hp
  have h : env52947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52946_52947 : H12AffineEnvironment.transform 8 1 env52946 = env52947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env52946 == env52947) = true)

theorem identity52947 : scanCanonicalize (H12AffineFastState.compose env52947 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound52947 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52948 : List Nat := [2,4,8,4,1,4,9,5,1,1,2048,2052,9,2049,1,3,2053,2048,0,0,2049,1,4,3,8,4,2048,2052,2053,2048,0,0,4,1,2048,1]

theorem envBound52948 : H12AffineFastState.Bounded env52948 := by
  intro p hp
  have h : env52948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52947_52948 : H12AffineEnvironment.transform 3 4 env52947 = env52948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env52947 == env52948) = true)

def env52949 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,24980,262144,1025,29829,4112,272513,73754,29830,8328,17,10509,70814,91402,357643,9224,338311,257,29861,24964,66446]

theorem envBound52949 : H12AffineFastState.Bounded env52949 := by
  intro p hp
  have h : env52949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52936_52949 : H12AffineEnvironment.transform 5 17 env52936 = env52949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52936 == env52949) = true)

theorem identity52949 : scanCanonicalize (H12AffineFastState.compose env52949 (packedSelected [0,3,5,8,9,11,14,16,17,20,22,27,28,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound52949 : packedSelected [0,3,5,8,9,11,14,16,17,20,22,27,28,32,35] rootPS < 2^1333 := by decide +kernel

def env52950 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,399,24980,262144,1025,29829,4112,272513,8597,29830,8328,17,10509,5393,25733,291972,9224,272392,257,29861,24964,513]

theorem envBound52950 : H12AffineFastState.Bounded env52950 := by
  intro p hp
  have h : env52950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52949_52950 : H12AffineEnvironment.transform 15 399 env52949 = env52950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env52949 == env52950) = true)

def env52951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,318549,120014,29910,8328,64,10588,122906,102879,360926,9224,384258,257,29941,38224,66527]

theorem envBound52951 : H12AffineFastState.Bounded env52951 := by
  intro p hp
  have h : env52951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52934_52951 : H12AffineEnvironment.transform 16 38161 env52934 = env52951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env52934 == env52951) = true)

theorem identity52951 : scanCanonicalize (H12AffineFastState.compose env52951 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound52951 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62730,38161,262144,1025,32769,4160,318549,8644,29910,8328,64,10588,5392,25813,292052,9224,272392,257,29941,38224,63189]

theorem envBound52952 : H12AffineFastState.Bounded env52952 := by
  intro p hp
  have h : env52952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52951_52952 : H12AffineEnvironment.transform 15 62730 env52951 = env52952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env52951 == env52952) = true)

def env52953 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,38161,262144,1025,32769,4160,318549,8524,29790,8192,64,10588,5392,25693,291932,9224,272392,257,29821,38224,63069]

theorem envBound52953 : H12AffineFastState.Bounded env52953 := by
  intro p hp
  have h : env52953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52952_52953 : H12AffineEnvironment.transform 6 8 env52952 = env52953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52952 == env52953) = true)

theorem identity52953 : scanCanonicalize (H12AffineFastState.compose env52953 (packedSelected [1,10,14,19,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound52953 : packedSelected [1,10,14,19,28,35] rootPS < 2^1333 := by decide +kernel

def env52954 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,38161,35108,1025,32769,4160,21873,8524,29790,8192,64,10588,5392,25693,64888,9224,41260,257,29821,38224,63069]

theorem envBound52954 : H12AffineFastState.Bounded env52954 := by
  intro p hp
  have h : env52954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52953_52954 : H12AffineEnvironment.transform 17 35108 env52953 = env52954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env52953 == env52954) = true)

theorem identity52954 : scanCanonicalize (H12AffineFastState.compose env52954 (packedSelected [4,5,9,12,14,15,17,18,19,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound52954 : packedSelected [4,5,9,12,14,15,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env52955 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,32768,41263,38161,35108,1025,32769,4160,340,8524,8315,8192,64,10588,5392,12408,43357,9224,41260,257,8280,38224,41592]

theorem envBound52955 : H12AffineFastState.Bounded env52955 := by
  intro p hp
  have h : env52955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52954_52955 : H12AffineEnvironment.transform 13 5157 env52954 = env52955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env52954 == env52955) = true)

theorem identity52955 : scanCanonicalize (H12AffineFastState.compose env52955 (packedSelected [0,2,4,6,7,9,11,14,17,23] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound52955 : packedSelected [0,2,4,6,7,9,11,14,17,23] rootPS < 2^1333 := by decide +kernel

def env52956 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5157,32768,41050,37988,34897,1025,32769,4160,33,8249,8315,8192,64,10281,5221,12408,43048,9224,41049,116,8280,37925,41592]

theorem envBound52956 : H12AffineFastState.Bounded env52956 := by
  intro p hp
  have h : env52956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52955_52956 : H12AffineEnvironment.transform 7 117 env52955 = env52956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env52955 == env52956) = true)

theorem identity52956 : scanCanonicalize (H12AffineFastState.compose env52956 (packedSelected [0,1,3,5,7,8,11,12,14,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52956 : packedSelected [0,1,3,5,7,8,11,12,14,17] rootPS < 2^1333 := by decide +kernel

def env52957 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,5157,32768,40971,37941,34816,1025,32769,4113,33,8249,8234,8192,17,10281,5172,12329,43048,9224,40968,37,8201,37925,41513]

theorem envBound52957 : H12AffineFastState.Bounded env52957 := by
  intro p hp
  have h : env52957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52956_52957 : H12AffineEnvironment.transform 5 17 env52956 = env52957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52956 == env52957) = true)

theorem identity52957 : scanCanonicalize (H12AffineFastState.compose env52957 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound52957 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env52958 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,5157,8233,34,13340,10281,1025,8232,4113,33,8249,8234,8192,17,10281,5172,12329,2049,9224,33,37,8201,13324,512]

theorem envBound52958 : H12AffineFastState.Bounded env52958 := by
  intro p hp
  have h : env52958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52957_52958 : H12AffineEnvironment.transform 14 8233 env52957 = env52958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env52957 == env52958) = true)

theorem identity52958 : scanCanonicalize (H12AffineFastState.compose env52958 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3599) := by decide +kernel

theorem selectedBound52958 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52959 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,3599,8192,2602,8233,34,10771,10281,1025,8232,3614,33,8249,8234,8192,17,10281,2619,11814,2049,9224,33,37,8201,10755,512]

theorem envBound52959 : H12AffineFastState.Bounded env52959 := by
  intro p hp
  have h : env52959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52958_52959 : H12AffineEnvironment.transform 11 3599 env52958 = env52959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3599 env52958 == env52959) = true)

theorem identity52959 : scanCanonicalize (H12AffineFastState.compose env52959 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound52959 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52960 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,3599,9,2602,32,34,2586,2080,1025,33,3614,33,48,35,9,17,2080,2619,3631,2049,1025,33,37,0,2570,512]

theorem envBound52960 : H12AffineFastState.Bounded env52960 := by
  intro p hp
  have h : env52960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52959_52960 : H12AffineEnvironment.transform 12 9 env52959 = env52960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env52959 == env52960) = true)

theorem identity52960 : scanCanonicalize (H12AffineFastState.compose env52960 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52960 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52961 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,3599,9,2570,0,2,2586,2048,1025,1,3614,1,16,3,9,17,2048,2587,3599,2049,1025,1,5,0,2570,512]

theorem envBound52961 : H12AffineFastState.Bounded env52961 := by
  intro p hp
  have h : env52961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52960_52961 : H12AffineEnvironment.transform 4 0 env52960 = env52961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52960 == env52961) = true)

theorem identity52961 : scanCanonicalize (H12AffineFastState.compose env52961 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound52961 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52962 : List Nat := [2,4,8,16,0,17,8,4,512,1024,522,1029,9,0,0,2,16,522,1025,1,1044,1,16,3,9,17,522,17,1029,523,1025,1,5,0,0,512]

theorem envBound52962 : H12AffineFastState.Bounded env52962 := by
  intro p hp
  have h : env52962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52961_52962 : H12AffineEnvironment.transform 10 522 env52961 = env52962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env52961 == env52962) = true)

theorem identity52962 : scanCanonicalize (H12AffineFastState.compose env52962 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 17) := by decide +kernel

theorem selectedBound52962 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52963 : List Nat := [2,4,8,16,0,17,8,4,512,17,522,20,9,0,0,2,16,522,16,1,5,1,16,3,9,17,522,17,20,523,16,1,5,0,0,512]

theorem envBound52963 : H12AffineFastState.Bounded env52963 := by
  intro p hp
  have h : env52963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52962_52963 : H12AffineEnvironment.transform 9 17 env52962 = env52963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 17 env52962 == env52963) = true)

theorem identity52963 : scanCanonicalize (H12AffineFastState.compose env52963 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound52963 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52964 : List Nat := [2,1,8,16,0,17,8,1,512,17,522,17,9,0,0,2,16,522,16,1,0,1,16,3,9,17,522,17,17,523,16,1,0,0,0,512]

theorem envBound52964 : H12AffineFastState.Bounded env52964 := by
  intro p hp
  have h : env52964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52963_52964 : H12AffineEnvironment.transform 1 1 env52963 = env52964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env52963 == env52964) = true)

theorem identity52964 : scanCanonicalize (H12AffineFastState.compose env52964 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 19) := by decide +kernel

theorem selectedBound52964 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52965 : List Nat := [2,1,8,16,0,17,8,1,19,17,25,17,9,0,0,2,16,25,16,1,0,1,16,3,9,17,25,17,17,24,16,1,0,0,0,19]

theorem envBound52965 : H12AffineFastState.Bounded env52965 := by
  intro p hp
  have h : env52965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52964_52965 : H12AffineEnvironment.transform 8 19 env52964 = env52965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 19 env52964 == env52965) = true)

def env52966 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38161,262144,1025,32769,4160,318549,8525,29791,8193,64,10588,5392,25692,291933,9224,272392,257,29820,38224,63068]

theorem envBound52966 : H12AffineFastState.Bounded env52966 := by
  intro p hp
  have h : env52966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52952_52966 : H12AffineEnvironment.transform 6 9 env52952 = env52966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52952 == env52966) = true)

theorem identity52966 : scanCanonicalize (H12AffineFastState.compose env52966 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound52966 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env52967 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,343,24908,262144,1025,29788,4160,272392,8525,29791,8193,64,10588,5392,25692,291933,9224,272392,257,29820,24845,513]

theorem envBound52967 : H12AffineFastState.Bounded env52967 := by
  intro p hp
  have h : env52967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52966_52967 : H12AffineEnvironment.transform 14 29789 env52966 = env52967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env52966 == env52967) = true)

theorem identity52967 : scanCanonicalize (H12AffineFastState.compose env52967 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound52967 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52968 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,343,24908,32040,1025,29788,4160,21792,8525,29791,8193,64,10588,5392,25692,2421,9224,21792,257,29820,24845,513]

theorem envBound52968 : H12AffineFastState.Bounded env52968 := by
  intro p hp
  have h : env52968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52967_52968 : H12AffineEnvironment.transform 17 32040 env52967 = env52968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env52967 == env52968) = true)

theorem identity52968 : scanCanonicalize (H12AffineFastState.compose env52968 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound52968 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env52969 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,343,13388,10280,1025,8540,4160,32,8525,8543,8193,64,10588,5392,12636,2421,9224,32,257,8572,13325,513]

theorem envBound52969 : H12AffineFastState.Bounded env52969 := by
  intro p hp
  have h : env52969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52968_52969 : H12AffineEnvironment.transform 13 5376 env52968 = env52969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52968 == env52969) = true)

theorem identity52969 : scanCanonicalize (H12AffineFastState.compose env52969 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound52969 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52970 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,5376,1296,343,4097,3173,1025,1297,4160,32,1280,1298,1100,64,3345,5392,5393,2421,69,32,257,1329,4160,513]

theorem envBound52970 : H12AffineFastState.Bounded env52970 := by
  intro p hp
  have h : env52970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52969_52970 : H12AffineEnvironment.transform 12 1101 env52969 = env52970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env52969 == env52970) = true)

theorem identity52970 : scanCanonicalize (H12AffineFastState.compose env52970 (packedSelected [1,3,4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound52970 : packedSelected [1,3,4,9,11] rootPS < 2^1333 := by decide +kernel

def env52971 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3108,1101,2340,1296,343,3109,3173,1025,1297,3172,32,1280,1298,1100,64,3345,2356,2357,2421,69,32,257,1329,3172,513]

theorem envBound52971 : H12AffineFastState.Bounded env52971 := by
  intro p hp
  have h : env52971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52970_52971 : H12AffineEnvironment.transform 11 3108 env52970 = env52971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env52970 == env52971) = true)

theorem identity52971 : scanCanonicalize (H12AffineFastState.compose env52971 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound52971 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52972 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1076,16,1101,1296,1296,343,17,81,1025,1297,80,32,1280,1298,1100,64,293,1280,1281,1345,69,32,257,1329,80,513]

theorem envBound52972 : H12AffineFastState.Bounded env52972 := by
  intro p hp
  have h : env52972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52971_52972 : H12AffineEnvironment.transform 10 1076 env52971 = env52972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env52971 == env52972) = true)

theorem identity52972 : scanCanonicalize (H12AffineFastState.compose env52972 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52972 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52973 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,16,1052,1296,1296,262,17,0,1025,1297,1,32,1280,1298,1053,17,293,1280,1281,1296,20,32,257,1329,1,513]

theorem envBound52973 : H12AffineFastState.Bounded env52973 := by
  intro p hp
  have h : env52973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52972_52973 : H12AffineEnvironment.transform 5 17 env52972 = env52973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52972 == env52973) = true)

theorem identity52973 : scanCanonicalize (H12AffineFastState.compose env52973 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52973 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52974 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1076,16,1052,1077,1077,35,17,0,1025,1076,1,32,1061,1079,1053,17,0,1061,1060,1077,20,32,36,1044,1,513]

theorem envBound52974 : H12AffineFastState.Bounded env52974 := by
  intro p hp
  have h : env52974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52973_52974 : H12AffineEnvironment.transform 7 37 env52973 = env52974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52973 == env52974) = true)

theorem identity52974 : scanCanonicalize (H12AffineFastState.compose env52974 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound52974 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env52975 : List Nat := [2,4,8,16,32,17,9,37,512,533,545,16,521,544,544,35,17,0,532,545,1,32,560,546,520,17,0,560,561,544,20,32,36,513,1,513]

theorem envBound52975 : H12AffineFastState.Bounded env52975 := by
  intro p hp
  have h : env52975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52974_52975 : H12AffineEnvironment.transform 9 533 env52974 = env52975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env52974 == env52975) = true)

theorem identity52975 : scanCanonicalize (H12AffineFastState.compose env52975 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound52975 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env52976 : List Nat := [2,4,8,16,32,17,9,37,32,53,1,16,41,0,0,35,17,0,52,1,1,32,16,2,40,17,0,16,17,0,20,32,36,33,1,33]

theorem envBound52976 : H12AffineFastState.Bounded env52976 := by
  intro p hp
  have h : env52976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52975_52976 : H12AffineEnvironment.transform 8 32 env52975 = env52976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env52975 == env52976) = true)

def env52977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,411973,213471,16777216,8328,64,16959642,18973836,2299022,360926,16958927,19344516,257,19039602,19031255,17031704]

theorem envBound52977 : H12AffineFastState.Bounded env52977 := by
  intro p hp
  have h : env52977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52854_52977 : H12AffineEnvironment.transform 21 411973 env52854 = env52977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 411973 env52854 == env52977) = true)

def env52978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411973,213471,16777216,8328,64,16959642,16974300,102878,360926,16958927,17148372,257,16777250,16834951,17031704]

theorem envBound52978 : H12AffineFastState.Bounded env52978 := by
  intro p hp
  have h : env52978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52977_52978 : H12AffineEnvironment.transform 20 165200 env52977 = env52978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165200 env52977 == env52978) = true)

theorem identity52978 : scanCanonicalize (H12AffineFastState.compose env52978 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 82382) := by decide +kernel

theorem selectedBound52978 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env52979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,115870,329867,17,16777216,8328,64,16877908,16793618,102878,360926,16876545,17148372,257,16777250,16834951,16819158]

theorem envBound52979 : H12AffineFastState.Bounded env52979 := by
  intro p hp
  have h : env52979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52978_52979 : H12AffineEnvironment.transform 16 82382 env52978 = env52979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82382 env52978 == env52979) = true)

def env52980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,115870,329867,17,95496,8328,64,64604,79130,102878,360926,61705,318684,257,95530,103567,120542]

theorem envBound52980 : H12AffineFastState.Bounded env52980 := by
  intro p hp
  have h : env52980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52979_52980 : H12AffineEnvironment.transform 23 95496 env52979 = env52980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env52979 == env52980) = true)

def env52981 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115734,329731,17,95496,8192,64,64604,79130,102742,360790,61705,318548,257,95530,103431,120406]

theorem envBound52981 : H12AffineFastState.Bounded env52981 := by
  intro p hp
  have h : env52981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52980_52981 : H12AffineEnvironment.transform 6 8 env52980 = env52981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52980 == env52981) = true)

theorem identity52981 : scanCanonicalize (H12AffineFastState.compose env52981 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound52981 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52982 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,35188,1025,32769,115734,98679,17,95496,8192,64,64604,79130,102742,67618,61705,21792,257,95530,103431,120406]

theorem envBound52982 : H12AffineFastState.Bounded env52982 := by
  intro p hp
  have h : env52982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52981_52982 : H12AffineEnvironment.transform 17 35188 env52981 = env52982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env52981 == env52982) = true)

theorem identity52982 : scanCanonicalize (H12AffineFastState.compose env52982 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound52982 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52983 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,46156,35188,1025,32769,12572,29821,17,32770,8192,64,64604,49168,25692,64808,61705,21792,257,32800,24845,9052]

theorem envBound52983 : H12AffineFastState.Bounded env52983 := by
  intro p hp
  have h : env52983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52982_52983 : H12AffineEnvironment.transform 15 62730 env52982 = env52983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env52982 == env52983) = true)

theorem identity52983 : scanCanonicalize (H12AffineFastState.compose env52983 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound52983 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env52984 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8202,24908,23668,1025,21761,12572,29821,17,21762,8192,64,10588,5392,25692,10280,9225,21792,257,21792,24845,9052]

theorem envBound52984 : H12AffineFastState.Bounded env52984 := by
  intro p hp
  have h : env52984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52983_52984 : H12AffineEnvironment.transform 14 21760 env52983 = env52984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env52983 == env52984) = true)

theorem identity52984 : scanCanonicalize (H12AffineFastState.compose env52984 (packedSelected [0,2,4,5,7,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 2844) := by decide +kernel

theorem selectedBound52984 : packedSelected [0,2,4,5,7,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env52985 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2844,16384,21760,2838,19024,23668,1025,21761,6656,24417,17,21762,2844,64,576,5392,20288,820,3861,21792,257,21792,18961,2112]

theorem envBound52985 : H12AffineFastState.Bounded env52985 := by
  intro p hp
  have h : env52985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52984_52985 : H12AffineEnvironment.transform 12 2844 env52984 = env52985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2844 env52984 == env52985) = true)

theorem identity52985 : scanCanonicalize (H12AffineFastState.compose env52985 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound52985 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env52986 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,2665,16384,21621,2659,19024,23668,1025,21620,6656,24084,17,21623,2665,64,576,5221,20021,577,3680,21589,116,21589,18961,2112]

theorem envBound52986 : H12AffineFastState.Bounded env52986 := by
  intro p hp
  have h : env52986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52985_52986 : H12AffineEnvironment.transform 7 117 env52985 = env52986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env52985 == env52986) = true)

theorem identity52986 : scanCanonicalize (H12AffineFastState.compose env52986 (packedSelected [2,5,6,8,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4672) := by decide +kernel

theorem selectedBound52986 : packedSelected [2,5,6,8,12,15] rootPS < 2^1333 := by decide +kernel

def env52987 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,2665,4672,1589,2659,6160,3636,1025,1588,6656,3156,17,1591,2665,64,576,5221,7285,577,3680,1557,116,1557,6225,2112]

theorem envBound52987 : H12AffineFastState.Bounded env52987 := by
  intro p hp
  have h : env52987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52986_52987 : H12AffineEnvironment.transform 13 4672 env52986 = env52987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4672 env52986 == env52987) = true)

theorem identity52987 : scanCanonicalize (H12AffineFastState.compose env52987 (packedSelected [2,4,5,6,8,9,11,12,16] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound52987 : packedSelected [2,4,5,6,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env52988 : List Nat := [2,4,8,16,32,64,8,117,512,1024,528,4096,121,4672,1589,115,4608,1060,1025,1588,4112,1604,17,1591,121,64,576,5221,5733,577,1136,1557,116,1557,4673,592]

theorem envBound52988 : H12AffineFastState.Bounded env52988 := by
  intro p hp
  have h : env52988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52987_52988 : H12AffineEnvironment.transform 10 528 env52987 = env52988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env52987 == env52988) = true)

theorem identity52988 : scanCanonicalize (H12AffineFastState.compose env52988 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1637) := by decide +kernel

theorem selectedBound52988 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env52989 : List Nat := [2,4,8,16,32,64,8,117,512,1024,528,1637,121,1061,1589,115,1125,1060,1025,1588,1653,1604,17,1591,121,64,576,512,0,577,1136,1557,116,1557,1060,592]

theorem envBound52989 : H12AffineFastState.Bounded env52989 := by
  intro p hp
  have h : env52989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52988_52989 : H12AffineEnvironment.transform 11 1637 env52988 = env52989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1637 env52988 == env52989) = true)

theorem identity52989 : scanCanonicalize (H12AffineFastState.compose env52989 (packedSelected [0,1,2,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52989 : packedSelected [0,1,2,5,6,7] rootPS < 2^1333 := by decide +kernel

def env52990 : List Nat := [2,4,8,16,32,16,8,37,512,1024,528,1589,41,1061,1589,35,1077,1060,1025,1588,1573,1556,17,1591,41,16,528,512,0,529,1056,1557,36,1557,1060,512]

theorem envBound52990 : H12AffineFastState.Bounded env52990 := by
  intro p hp
  have h : env52990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52989_52990 : H12AffineEnvironment.transform 5 16 env52989 = env52990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52989 == env52990) = true)

theorem identity52990 : scanCanonicalize (H12AffineFastState.compose env52990 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52990 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env52991 : List Nat := [2,4,8,16,1,16,8,4,512,1024,528,1556,8,1028,1556,2,1044,1029,1025,1557,1540,1556,17,1558,8,16,528,512,0,529,1025,1557,5,1557,1029,512]

theorem envBound52991 : H12AffineFastState.Bounded env52991 := by
  intro p hp
  have h : env52991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52990_52991 : H12AffineEnvironment.transform 4 1 env52990 = env52991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52990 == env52991) = true)

theorem identity52991 : scanCanonicalize (H12AffineFastState.compose env52991 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound52991 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env52992 : List Nat := [2,4,8,16,1,16,8,4,512,533,528,1,8,529,1,2,513,528,532,0,17,1,17,3,8,16,528,512,0,529,532,0,5,0,528,512]

theorem envBound52992 : H12AffineFastState.Bounded env52992 := by
  intro p hp
  have h : env52992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52991_52992 : H12AffineEnvironment.transform 9 533 env52991 = env52992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env52991 == env52992) = true)

def env52993 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115735,329730,17,95496,8193,64,64604,79130,102743,360791,61705,318549,257,95530,103430,120407]

theorem envBound52993 : H12AffineFastState.Bounded env52993 := by
  intro p hp
  have h : env52993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52980_52993 : H12AffineEnvironment.transform 6 9 env52980 = env52993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52980 == env52993) = true)

theorem identity52993 : scanCanonicalize (H12AffineFastState.compose env52993 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound52993 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52994 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10281,1025,32769,115735,73771,17,95496,8193,64,64604,79130,102743,108926,61705,62588,257,95530,103430,120407]

theorem envBound52994 : H12AffineFastState.Bounded env52994 := by
  intro p hp
  have h : env52994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52993_52994 : H12AffineEnvironment.transform 17 10281 env52993 = env52994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52993 == env52994) = true)

theorem identity52994 : scanCanonicalize (H12AffineFastState.compose env52994 (packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound52994 : packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env52995 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,82247,2420,1025,32769,115735,65910,17,87125,348,64,56577,70727,102743,100387,53332,54561,257,87159,103430,120407]

theorem envBound52995 : H12AffineFastState.Bounded env52995 := by
  intro p hp
  have h : env52995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52994_52995 : H12AffineEnvironment.transform 12 349 env52994 = env52995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env52994 == env52995) = true)

theorem identity52995 : scanCanonicalize (H12AffineFastState.compose env52995 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound52995 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env52996 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,65536,82247,2420,1025,21760,69910,65910,17,87125,348,64,2048,70727,83030,89378,1365,32,257,87159,82183,66390]

theorem envBound52996 : H12AffineFastState.Bounded env52996 := by
  intro p hp
  have h : env52996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52995_52996 : H12AffineEnvironment.transform 14 21761 env52995 = env52996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env52995 == env52996) = true)

theorem identity52996 : scanCanonicalize (H12AffineFastState.compose env52996 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound52996 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env52997 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,81,65536,70679,2420,1025,80,69910,65910,17,65797,348,64,2048,70727,69894,67698,1365,32,257,65831,70743,66390]

theorem envBound52997 : H12AffineFastState.Bounded env52997 := by
  intro p hp
  have h : env52997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52996_52997 : H12AffineEnvironment.transform 13 5456 env52996 = env52997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env52996 == env52997) = true)

theorem identity52997 : scanCanonicalize (H12AffineFastState.compose env52997 (packedSelected [4,9,11,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound52997 : packedSelected [4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env52998 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5156,81,65536,70679,2048,1025,80,69730,65538,17,65649,40,64,2048,70727,69746,67698,1057,32,117,65619,70743,66082]

theorem envBound52998 : H12AffineFastState.Bounded env52998 := by
  intro p hp
  have h : env52998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52997_52998 : H12AffineEnvironment.transform 7 116 env52997 = env52998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env52997 == env52998) = true)

theorem identity52998 : scanCanonicalize (H12AffineFastState.compose env52998 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound52998 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env52999 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5156,81,114,5221,2048,1025,80,4112,112,17,3,40,64,2048,5173,4096,2048,1057,32,117,33,5157,592]

theorem envBound52999 : H12AffineFastState.Bounded env52999 := by
  intro p hp
  have h : env52999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52998_52999 : H12AffineEnvironment.transform 15 114 env52998 = env52999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env52998 == env52999) = true)

theorem identity52999 : scanCanonicalize (H12AffineFastState.compose env52999 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound52999 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env53000 : List Nat := [2,4,8,16,32,49,9,5,512,1024,2048,4096,41,5156,32,3,5140,2048,1025,33,4112,1,17,3,40,49,2048,5173,4096,2048,1057,32,4,33,5157,545]

theorem envBound53000 : H12AffineFastState.Bounded env53000 := by
  intro p hp
  have h : env53000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52999_53000 : H12AffineEnvironment.transform 5 49 env52999 = env53000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env52999 == env53000) = true)

def env53001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,115870,329867,17,95497,8328,64,64605,79131,102878,360926,61704,318685,257,95531,103566,120543]

theorem envBound53001 : H12AffineFastState.Bounded env53001 := by
  intro p hp
  have h : env53001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52979_53001 : H12AffineEnvironment.transform 23 95497 env52979 = env53001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env52979 == env53001) = true)

theorem identity53001 : scanCanonicalize (H12AffineFastState.compose env53001 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound53001 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,38160,262144,1025,32769,4160,318549,17,41431,8328,64,64605,57797,17664,283904,61704,318685,257,41461,16464,513]

theorem envBound53002 : H12AffineFastState.Bounded env53002 := by
  intro p hp
  have h : env53002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53001_53002 : H12AffineEnvironment.transform 15 54494 env53001 = env53002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env53001 == env53002) = true)

def env53003 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,262144,1025,32769,4160,318549,17,41311,8192,64,64605,57677,17664,283904,61704,318549,257,41341,16464,513]

theorem envBound53003 : H12AffineFastState.Bounded env53003 := by
  intro p hp
  have h : env53003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53002_53003 : H12AffineEnvironment.transform 6 8 env53002 = env53003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53002 == env53003) = true)

theorem identity53003 : scanCanonicalize (H12AffineFastState.compose env53003 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound53003 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,35188,1025,32769,4160,21793,17,41311,8192,64,64605,57677,17664,56436,61704,21793,257,41341,16464,513]

theorem envBound53004 : H12AffineFastState.Bounded env53004 := by
  intro p hp
  have h : env53004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53003_53004 : H12AffineEnvironment.transform 17 35188 env53003 = env53004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env53003 == env53004) = true)

theorem identity53004 : scanCanonicalize (H12AffineFastState.compose env53004 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound53004 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env53005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,9293,28699,12637,11577,1025,9292,4160,21793,17,1298,8192,64,22544,17664,17664,30777,21829,21793,257,1328,16464,513]

theorem envBound53005 : H12AffineFastState.Bounded env53005 := by
  intro p hp
  have h : env53005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53004_53005 : H12AffineEnvironment.transform 14 9293 env53004 = env53005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env53004 == env53005) = true)

theorem identity53005 : scanCanonicalize (H12AffineFastState.compose env53005 (packedSelected [1,8,9,14,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53005 : packedSelected [1,8,9,14,19,22] rootPS < 2^1333 := by decide +kernel

def env53006 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1296,20806,4096,3172,1025,1297,4160,21793,17,1298,349,64,22544,17664,17664,22884,21829,21793,257,1328,16464,513]

theorem envBound53006 : H12AffineFastState.Bounded env53006 := by
  intro p hp
  have h : env53006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53005_53006 : H12AffineEnvironment.transform 12 349 env53005 = env53006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53005 == env53006) = true)

theorem identity53006 : scanCanonicalize (H12AffineFastState.compose env53006 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound53006 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53007 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4113,1296,343,4096,3172,1025,1297,4160,1328,17,1298,349,64,2049,5393,5393,2421,1364,1328,257,1328,4161,513]

theorem envBound53007 : H12AffineFastState.Bounded env53007 := by
  intro p hp
  have h : env53007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53006_53007 : H12AffineEnvironment.transform 13 4113 env53006 = env53007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env53006 == env53007) = true)

theorem identity53007 : scanCanonicalize (H12AffineFastState.compose env53007 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53007 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53008 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,4113,1296,262,4096,3125,1025,1297,4113,1328,17,1298,268,17,2049,5393,5393,2340,1285,1328,257,1328,4112,513]

theorem envBound53008 : H12AffineFastState.Bounded env53008 := by
  intro p hp
  have h : env53008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53007_53008 : H12AffineEnvironment.transform 5 17 env53007 = env53008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53007 == env53008) = true)

theorem identity53008 : scanCanonicalize (H12AffineFastState.compose env53008 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 308) := by decide +kernel

theorem selectedBound53008 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env53009 : List Nat := [2,4,8,16,32,17,8,256,512,1024,308,4096,268,4113,1296,262,4096,1281,1025,1297,4113,1328,17,1298,268,17,309,5393,5393,16,1285,1328,257,1328,4112,513]

theorem envBound53009 : H12AffineFastState.Bounded env53009 := by
  intro p hp
  have h : env53009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53008_53009 : H12AffineEnvironment.transform 10 308 env53008 = env53009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 308 env53008 == env53009) = true)

theorem identity53009 : scanCanonicalize (H12AffineFastState.compose env53009 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53009 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env53010 : List Nat := [2,4,8,16,32,17,8,256,512,272,308,4096,268,4113,0,262,4096,17,273,1,4113,32,17,2,268,17,309,4097,4097,16,21,32,257,32,4112,513]

theorem envBound53010 : H12AffineFastState.Bounded env53010 := by
  intro p hp
  have h : env53010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53009_53010 : H12AffineEnvironment.transform 9 272 env53009 = env53010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53009 == env53010) = true)

theorem identity53010 : scanCanonicalize (H12AffineFastState.compose env53010 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound53010 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53011 : List Nat := [2,4,8,16,32,17,8,256,512,272,308,0,268,17,0,262,0,17,273,1,17,32,17,2,268,17,309,1,1,16,21,32,257,32,16,513]

theorem envBound53011 : H12AffineFastState.Bounded env53011 := by
  intro p hp
  have h : env53011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53010_53011 : H12AffineEnvironment.transform 11 0 env53010 = env53011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env53010 == env53011) = true)

theorem identity53011 : scanCanonicalize (H12AffineFastState.compose env53011 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53011 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53012 : List Nat := [2,4,8,16,32,17,8,256,1,272,308,0,268,17,0,262,0,17,273,1,17,32,17,2,268,17,309,1,1,16,21,32,257,32,16,0]

theorem envBound53012 : H12AffineFastState.Bounded env53012 := by
  intro p hp
  have h : env53012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53011_53012 : H12AffineEnvironment.transform 8 1 env53011 = env53012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53011 == env53012) = true)

theorem identity53012 : scanCanonicalize (H12AffineFastState.compose env53012 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53012 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env53013 : List Nat := [2,4,8,16,32,17,8,4,1,20,48,0,8,17,0,2,0,17,21,1,17,32,17,2,8,17,49,1,1,16,21,32,5,32,16,0]

theorem envBound53013 : H12AffineFastState.Bounded env53013 := by
  intro p hp
  have h : env53013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53012_53013 : H12AffineEnvironment.transform 7 4 env53012 = env53013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53012 == env53013) = true)

theorem identity53013 : scanCanonicalize (H12AffineFastState.compose env53013 (packedSelected [0,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53013 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env53014 : List Nat := [2,4,8,16,1,17,8,4,1,20,17,0,8,17,0,2,0,17,21,1,17,1,17,2,8,17,16,1,1,16,21,1,5,1,16,0]

theorem envBound53014 : H12AffineFastState.Bounded env53014 := by
  intro p hp
  have h : env53014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53013_53014 : H12AffineEnvironment.transform 4 1 env53013 = env53014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53013 == env53014) = true)

theorem identity53014 : scanCanonicalize (H12AffineFastState.compose env53014 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53014 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env53015 : List Nat := [2,4,8,0,1,1,8,4,1,4,1,0,8,1,0,2,0,1,5,1,1,1,1,2,8,1,0,1,1,0,5,1,5,1,0,0]

theorem envBound53015 : H12AffineFastState.Bounded env53015 := by
  intro p hp
  have h : env53015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53014_53015 : H12AffineEnvironment.transform 3 0 env53014 = env53015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53014 == env53015) = true)

def env53016 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,262144,1025,32769,4160,318549,17,41310,8193,64,64605,57676,17664,283904,61704,318548,257,41340,16464,513]

theorem envBound53016 : H12AffineFastState.Bounded env53016 := by
  intro p hp
  have h : env53016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53002_53016 : H12AffineEnvironment.transform 6 9 env53002 = env53016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53002 == env53016) = true)

theorem identity53016 : scanCanonicalize (H12AffineFastState.compose env53016 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound53016 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53017 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,10281,1025,32769,4160,62588,17,41310,8193,64,64605,57676,17664,32041,61704,62589,257,41340,16464,513]

theorem envBound53017 : H12AffineFastState.Bounded env53017 := by
  intro p hp
  have h : env53017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53016_53017 : H12AffineEnvironment.transform 17 10281 env53016 = env53017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53016 == env53017) = true)

theorem identity53017 : scanCanonicalize (H12AffineFastState.compose env53017 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound53017 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env53018 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,38160,10281,1025,32769,4160,41341,17,41310,8193,64,43356,46157,4097,10280,41993,41340,257,41340,5457,513]

theorem envBound53018 : H12AffineFastState.Bounded env53018 := by
  intro p hp
  have h : env53018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53017_53018 : H12AffineEnvironment.transform 13 5377 env53017 = env53018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env53017 == env53018) = true)

theorem identity53018 : scanCanonicalize (H12AffineFastState.compose env53018 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound53018 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53019 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8232,8574,13624,10281,1025,8233,4160,341,17,374,8193,64,2420,5221,4097,10280,1057,340,257,340,5457,513]

theorem envBound53019 : H12AffineFastState.Bounded env53019 := by
  intro p hp
  have h : env53019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53018_53019 : H12AffineEnvironment.transform 14 8232 env53018 = env53019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env53018 == env53019) = true)

theorem identity53019 : scanCanonicalize (H12AffineFastState.compose env53019 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound53019 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env53020 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5377,81,263,5441,2128,1025,80,4160,341,17,374,120,64,2420,5221,4097,2129,1057,340,257,340,5457,513]

theorem envBound53020 : H12AffineFastState.Bounded env53020 := by
  intro p hp
  have h : env53020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53019_53020 : H12AffineEnvironment.transform 12 121 env53019 = env53020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env53019 == env53020) = true)

theorem identity53020 : scanCanonicalize (H12AffineFastState.compose env53020 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound53020 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env53021 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5236,81,114,5172,2128,1025,80,4160,32,17,3,120,64,2049,5221,4097,2129,1057,33,116,33,5156,513]

theorem envBound53021 : H12AffineFastState.Bounded env53021 := by
  intro p hp
  have h : env53021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53020_53021 : H12AffineEnvironment.transform 7 117 env53020 = env53021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env53020 == env53021) = true)

theorem identity53021 : scanCanonicalize (H12AffineFastState.compose env53021 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound53021 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env53022 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1060,121,80,81,114,16,2128,1025,80,1124,32,17,3,120,64,2049,65,1061,2129,1057,33,116,33,0,513]

theorem envBound53022 : H12AffineFastState.Bounded env53022 := by
  intro p hp
  have h : env53022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53021_53022 : H12AffineEnvironment.transform 11 1060 env53021 = env53022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env53021 == env53022) = true)

theorem identity53022 : scanCanonicalize (H12AffineFastState.compose env53022 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53022 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53023 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,1060,40,1,0,35,16,2049,1025,1,1077,32,17,3,41,17,2049,16,1061,2048,1057,33,37,33,0,513]

theorem envBound53023 : H12AffineFastState.Bounded env53023 := by
  intro p hp
  have h : env53023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53022_53023 : H12AffineEnvironment.transform 5 17 env53022 = env53023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53022 == env53023) = true)

theorem identity53023 : scanCanonicalize (H12AffineFastState.compose env53023 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound53023 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53024 : List Nat := [2,4,8,16,32,17,9,36,512,37,2048,1,40,1,0,35,16,2049,36,1,16,32,17,3,41,17,2049,16,0,2048,4,33,37,33,0,513]

theorem envBound53024 : H12AffineFastState.Bounded env53024 := by
  intro p hp
  have h : env53024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53023_53024 : H12AffineEnvironment.transform 9 37 env53023 = env53024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env53023 == env53024) = true)

theorem identity53024 : scanCanonicalize (H12AffineFastState.compose env53024 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound53024 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53025 : List Nat := [2,4,8,16,32,17,9,36,512,37,10,1,40,1,0,35,16,11,36,1,16,32,17,3,41,17,11,16,0,10,4,33,37,33,0,513]

theorem envBound53025 : H12AffineFastState.Bounded env53025 := by
  intro p hp
  have h : env53025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53024_53025 : H12AffineEnvironment.transform 10 10 env53024 = env53025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env53024 == env53025) = true)

theorem identity53025 : scanCanonicalize (H12AffineFastState.compose env53025 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound53025 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53026 : List Nat := [2,4,8,16,27,17,9,31,512,30,10,1,19,1,0,24,16,11,31,1,16,27,17,3,18,17,11,16,0,10,4,26,30,26,0,513]

theorem envBound53026 : H12AffineFastState.Bounded env53026 := by
  intro p hp
  have h : env53026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53025_53026 : H12AffineEnvironment.transform 4 27 env53025 = env53026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env53025 == env53026) = true)

def env53027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411973,213471,16777216,8328,64,16959642,16974301,102879,360926,16958927,17148373,257,16777251,16834950,17031704]

theorem envBound53027 : H12AffineFastState.Bounded env53027 := by
  intro p hp
  have h : env53027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52977_53027 : H12AffineEnvironment.transform 20 165201 env52977 = env53027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165201 env52977 == env53027) = true)

theorem identity53027 : scanCanonicalize (H12AffineFastState.compose env53027 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 106505) := by decide +kernel

theorem selectedBound53027 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env53028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411973,213471,106505,8328,64,223379,172500,102879,360926,222662,264668,257,106538,82319,147985]

theorem envBound53028 : H12AffineFastState.Bounded env53028 := by
  intro p hp
  have h : env53028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53027_53028 : H12AffineEnvironment.transform 23 106505 env53027 = env53028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 106505 env53027 == env53028) = true)

def env53029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,131072,262144,1025,21761,151633,411973,213471,95497,8328,64,223379,160980,83167,349406,222662,264668,257,95530,82319,147985]

theorem envBound53029 : H12AffineFastState.Bounded env53029 := by
  intro p hp
  have h : env53029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53028_53029 : H12AffineEnvironment.transform 14 21760 env53028 = env53029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env53028 == env53029) = true)

theorem identity53029 : scanCanonicalize (H12AffineFastState.compose env53029 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound53029 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,90139,262144,1025,21761,77898,338270,8644,95497,8328,64,2184,70863,83167,349406,1501,264668,257,95530,82319,74250]

theorem envBound53030 : H12AffineFastState.Bounded env53030 := by
  intro p hp
  have h : env53030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53029_53030 : H12AffineEnvironment.transform 16 90139 env53029 = env53030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env53029 == env53030) = true)

theorem identity53030 : scanCanonicalize (H12AffineFastState.compose env53030 (packedSelected [0,1,9,10,11,12,15,17,19,22,27,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 89595) := by decide +kernel

theorem selectedBound53030 : packedSelected [0,1,9,10,11,12,15,17,19,22,27,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env53031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,90139,89595,1025,21761,77898,29861,8644,95497,8328,64,2184,70863,83167,2341,1501,87079,257,95530,82319,74250]

theorem envBound53031 : H12AffineFastState.Bounded env53031 := by
  intro p hp
  have h : env53031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53030_53031 : H12AffineEnvironment.transform 17 89595 env53030 = env53031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89595 env53030 == env53031) = true)

theorem identity53031 : scanCanonicalize (H12AffineFastState.compose env53031 (packedSelected [1,3,18,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound53031 : packedSelected [1,3,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env53032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,263,24860,23804,1025,21761,12621,29861,8644,29710,8328,64,2184,5576,17880,2341,1501,21792,257,29741,16520,8973]

theorem envBound53032 : H12AffineFastState.Bounded env53032 := by
  intro p hp
  have h : env53032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53031_53032 : H12AffineEnvironment.transform 15 263 env53031 = env53032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env53031 == env53032) = true)

theorem identity53032 : scanCanonicalize (H12AffineFastState.compose env53032 (packedSelected [16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53032 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env53033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,21760,263,16401,23804,1025,21761,4160,21928,201,21763,389,64,2184,5576,17880,2341,1501,21792,257,21792,16520,512]

theorem envBound53033 : H12AffineFastState.Bounded env53033 := by
  intro p hp
  have h : env53033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53032_53033 : H12AffineEnvironment.transform 12 269 env53032 = env53033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53032 == env53033) = true)

theorem identity53033 : scanCanonicalize (H12AffineFastState.compose env53033 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 6682) := by decide +kernel

theorem selectedBound53033 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env53034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,6682,3866,263,6667,1766,1025,3867,4160,4018,201,3865,389,64,2184,5576,8130,2341,1501,3898,257,3898,6802,512]

theorem envBound53034 : H12AffineFastState.Bounded env53034 := by
  intro p hp
  have h : env53034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53033_53034 : H12AffineEnvironment.transform 13 6682 env53033 = env53034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6682 env53033 == env53034) = true)

theorem identity53034 : scanCanonicalize (H12AffineFastState.compose env53034 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(10+1) ^^^ 1767) := by decide +kernel

theorem selectedBound53034 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env53035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1767,4096,269,5373,509,263,5356,1766,1025,508,4160,341,201,510,389,64,1647,5576,4389,1986,1501,477,257,477,5237,512]

theorem envBound53035 : H12AffineFastState.Bounded env53035 := by
  intro p hp
  have h : env53035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53034_53035 : H12AffineEnvironment.transform 10 1767 env53034 = env53035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1767 env53034 == env53035) = true)

theorem identity53035 : scanCanonicalize (H12AffineFastState.compose env53035 (packedSelected [3,5,12,14] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound53035 : packedSelected [3,5,12,14] rootPS < 2^1333 := by decide +kernel

def env53036 : List Nat := [2,4,8,16,32,64,128,256,91,1024,1212,4096,269,5373,509,263,5356,1213,1025,508,4160,341,201,510,389,64,1076,5576,4389,1433,1501,477,257,477,5237,91]

theorem envBound53036 : H12AffineFastState.Bounded env53036 := by
  intro p hp
  have h : env53036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53035_53036 : H12AffineEnvironment.transform 8 91 env53035 = env53036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env53035 == env53036) = true)

theorem identity53036 : scanCanonicalize (H12AffineFastState.compose env53036 (packedSelected [2,6,17] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound53036 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env53037 : List Nat := [2,4,8,16,32,64,128,220,91,1024,1212,4096,209,5373,33,219,5356,1213,1025,32,4160,137,201,34,89,64,1076,5140,4345,1093,1025,1,221,1,5237,91]

theorem envBound53037 : H12AffineFastState.Bounded env53037 := by
  intro p hp
  have h : env53037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53036_53037 : H12AffineEnvironment.transform 7 220 env53036 = env53037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env53036 == env53037) = true)

theorem identity53037 : scanCanonicalize (H12AffineFastState.compose env53037 (packedSelected [3,5,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 1277) := by decide +kernel

theorem selectedBound53037 : packedSelected [3,5,6,11] rootPS < 2^1333 := by decide +kernel

def env53038 : List Nat := [2,4,8,16,32,64,128,220,91,1024,1212,1277,209,0,33,219,17,1213,1025,32,1213,137,201,34,89,64,1076,233,1028,1093,1025,1,221,1,136,91]

theorem envBound53038 : H12AffineFastState.Bounded env53038 := by
  intro p hp
  have h : env53038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53037_53038 : H12AffineEnvironment.transform 11 1277 env53037 = env53038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1277 env53037 == env53038) = true)

theorem identity53038 : scanCanonicalize (H12AffineFastState.compose env53038 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 27) := by decide +kernel

theorem selectedBound53038 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env53039 : List Nat := [2,4,8,16,32,64,27,71,91,1024,1063,1126,74,0,33,64,17,1062,1025,32,1062,18,82,34,89,64,1076,114,1028,1093,1025,1,70,1,19,91]

theorem envBound53039 : H12AffineFastState.Bounded env53039 := by
  intro p hp
  have h : env53039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53038_53039 : H12AffineEnvironment.transform 6 27 env53038 = env53039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 27 env53038 == env53039) = true)

theorem identity53039 : scanCanonicalize (H12AffineFastState.compose env53039 (packedSelected [0,5,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53039 : packedSelected [0,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env53040 : List Nat := [2,4,8,16,32,16,27,23,11,1024,1063,1078,26,0,33,16,17,1062,1025,32,1062,18,2,34,9,16,1076,34,1028,1045,1025,1,22,1,19,11]

theorem envBound53040 : H12AffineFastState.Bounded env53040 := by
  intro p hp
  have h : env53040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53039_53040 : H12AffineEnvironment.transform 5 16 env53039 = env53040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53039 == env53040) = true)

theorem identity53040 : scanCanonicalize (H12AffineFastState.compose env53040 (packedSelected [0,4,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound53040 : packedSelected [0,4,5,7,10] rootPS < 2^1333 := by decide +kernel

def env53041 : List Nat := [2,4,8,16,18,16,27,23,11,1024,1045,1028,26,0,19,16,17,1044,1025,18,1044,18,2,16,9,16,1030,16,1028,1045,1025,1,22,1,19,11]

theorem envBound53041 : H12AffineFastState.Bounded env53041 := by
  intro p hp
  have h : env53041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53040_53041 : H12AffineEnvironment.transform 4 18 env53040 = env53041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env53040 == env53041) = true)

theorem identity53041 : scanCanonicalize (H12AffineFastState.compose env53041 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 27) := by decide +kernel

theorem selectedBound53041 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53042 : List Nat := [2,4,8,16,18,16,27,23,11,27,14,31,26,0,19,16,17,15,26,18,15,18,2,16,9,16,29,16,31,14,26,1,22,1,19,11]

theorem envBound53042 : H12AffineFastState.Bounded env53042 := by
  intro p hp
  have h : env53042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53041_53042 : H12AffineEnvironment.transform 9 27 env53041 = env53042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 27 env53041 == env53042) = true)

def env53043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,131072,262144,1025,21760,151632,411973,213471,95496,8328,64,223379,160981,83166,349407,222662,264668,257,95531,82319,147985]

theorem envBound53043 : H12AffineFastState.Bounded env53043 := by
  intro p hp
  have h : env53043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53028_53043 : H12AffineEnvironment.transform 14 21761 env53028 = env53043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env53028 == env53043) = true)

theorem identity53043 : scanCanonicalize (H12AffineFastState.compose env53043 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound53043 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,131072,262144,1025,21760,151632,411973,156116,21763,8328,64,149656,160981,25813,292052,148941,264668,257,21792,24964,147985]

theorem envBound53044 : H12AffineFastState.Bounded env53044 := by
  intro p hp
  have h : env53044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53043_53044 : H12AffineEnvironment.transform 15 8203 env53043 = env53044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env53043 == env53044) = true)

def env53045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,131072,10280,1025,21760,151632,156013,156116,21763,8328,64,149656,160981,25813,23804,148941,8692,257,21792,24964,147985]

theorem envBound53045 : H12AffineFastState.Bounded env53045 := by
  intro p hp
  have h : env53045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53044_53045 : H12AffineEnvironment.transform 17 10280 env53044 = env53045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53044 == env53045) = true)

theorem identity53045 : scanCanonicalize (H12AffineFastState.compose env53045 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound53045 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53046 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,8192,16384,20633,8203,131072,10280,409,20632,151632,156013,156116,20635,8328,64,149656,160077,24909,22884,147541,8692,257,20664,24964,147985]

theorem envBound53046 : H12AffineFastState.Bounded env53046 := by
  intro p hp
  have h : env53046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53045_53046 : H12AffineEnvironment.transform 9 408 env53045 = env53046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env53045 == env53046) = true)

theorem identity53046 : scanCanonicalize (H12AffineFastState.compose env53046 (packedSelected [1,2,4,6,8,11,17,18,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 24632) := by decide +kernel

theorem selectedBound53046 : packedSelected [1,2,4,6,8,11,17,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env53047 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,8192,16384,20633,8203,24632,10280,409,20632,12392,341,492,20635,8328,64,10400,4469,24909,22884,8301,8692,257,20664,24964,8745]

theorem envBound53047 : H12AffineFastState.Bounded env53047 := by
  intro p hp
  have h : env53047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53046_53047 : H12AffineEnvironment.transform 16 24632 env53046 = env53047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24632 env53046 == env53047) = true)

theorem identity53047 : scanCanonicalize (H12AffineFastState.compose env53047 (packedSelected [4,5,9,14,16,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound53047 : packedSelected [4,5,9,14,16,24,26] rootPS < 2^1333 := by decide +kernel

def env53048 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,40,16384,20633,35,16400,2048,409,20632,4160,341,492,20635,160,64,2184,4469,16741,22884,69,476,257,20664,16812,513]

theorem envBound53048 : H12AffineFastState.Bounded env53048 := by
  intro p hp
  have h : env53048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53047_53048 : H12AffineEnvironment.transform 12 40 env53047 = env53048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env53047 == env53048) = true)

theorem identity53048 : scanCanonicalize (H12AffineFastState.compose env53048 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound53048 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53049 : List Nat := [2,4,8,16,32,64,128,117,512,237,2048,4096,40,16384,20633,35,16400,2048,236,20632,4160,32,153,20635,160,64,2184,4096,16400,22545,69,169,116,20664,16601,513]

theorem envBound53049 : H12AffineFastState.Bounded env53049 := by
  intro p hp
  have h : env53049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53048_53049 : H12AffineEnvironment.transform 7 117 env53048 = env53049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env53048 == env53049) = true)

theorem identity53049 : scanCanonicalize (H12AffineFastState.compose env53049 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound53049 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env53050 : List Nat := [2,4,8,16,32,64,128,117,512,237,2048,4096,40,4113,136,35,4097,2048,236,137,4160,32,153,138,160,64,2184,4096,4097,2048,69,169,116,169,4296,513]

theorem envBound53050 : H12AffineFastState.Bounded env53050 := by
  intro p hp
  have h : env53050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53049_53050 : H12AffineEnvironment.transform 13 4113 env53049 = env53050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env53049 == env53050) = true)

theorem identity53050 : scanCanonicalize (H12AffineFastState.compose env53050 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound53050 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env53051 : List Nat := [2,4,8,16,32,64,128,117,512,237,0,4096,40,4113,136,35,4097,0,236,137,4160,32,153,138,160,64,136,4096,4097,0,69,169,116,169,4296,513]

theorem envBound53051 : H12AffineFastState.Bounded env53051 := by
  intro p hp
  have h : env53051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53050_53051 : H12AffineEnvironment.transform 10 0 env53050 = env53051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env53050 == env53051) = true)

theorem identity53051 : scanCanonicalize (H12AffineFastState.compose env53051 (packedSelected [1,3,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 201) := by decide +kernel

theorem selectedBound53051 : packedSelected [1,3,6,9] rootPS < 2^1333 := by decide +kernel

def env53052 : List Nat := [2,4,8,16,32,64,128,117,512,237,0,201,40,216,136,35,200,0,236,137,137,32,153,138,160,64,136,201,200,0,69,169,116,169,1,513]

theorem envBound53052 : H12AffineFastState.Bounded env53052 := by
  intro p hp
  have h : env53052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53051_53052 : H12AffineEnvironment.transform 11 201 env53051 = env53052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 201 env53051 == env53052) = true)

theorem identity53052 : scanCanonicalize (H12AffineFastState.compose env53052 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53052 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env53053 : List Nat := [2,4,8,16,32,16,128,37,512,189,0,153,40,136,136,35,152,0,188,137,137,32,153,138,160,16,136,153,152,0,21,169,36,169,1,513]

theorem envBound53053 : H12AffineFastState.Bounded env53053 := by
  intro p hp
  have h : env53053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53052_53053 : H12AffineEnvironment.transform 5 16 env53052 = env53053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53052 == env53053) = true)

def env53054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,131072,10281,1025,21760,151632,156012,156116,21763,8328,64,149656,160981,25813,23805,148941,8693,257,21792,24964,147985]

theorem envBound53054 : H12AffineFastState.Bounded env53054 := by
  intro p hp
  have h : env53054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53044_53054 : H12AffineEnvironment.transform 17 10281 env53044 = env53054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53044 == env53054) = true)

theorem identity53054 : scanCanonicalize (H12AffineFastState.compose env53054 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound53054 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8540,8203,131072,10281,1025,8541,140301,136497,136585,8542,8328,64,146629,131208,4232,10400,143760,8693,257,8573,5593,144972]

theorem envBound53055 : H12AffineFastState.Bounded env53055 := by
  intro p hp
  have h : env53055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53054_53055 : H12AffineEnvironment.transform 13 13405 env53054 = env53055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env53054 == env53055) = true)

theorem identity53055 : scanCanonicalize (H12AffineFastState.compose env53055 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound53055 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env53056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8540,8203,13509,10281,1025,8541,4296,8692,8524,8542,8328,64,2048,13389,4232,10400,1365,8693,257,8573,5593,649]

theorem envBound53056 : H12AffineFastState.Bounded env53056 := by
  intro p hp
  have h : env53056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53055_53056 : H12AffineEnvironment.transform 16 13509 env53055 = env53056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env53055 == env53056) = true)

theorem identity53056 : scanCanonicalize (H12AffineFastState.compose env53056 (packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 3552) := by decide +kernel

theorem selectedBound53056 : packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS < 2^1333 := by decide +kernel

def env53057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3552,6589,3260,3563,6437,1481,1025,3261,4296,3092,3244,3262,3432,64,2048,6573,4232,1344,1365,3093,257,3229,5593,649]

theorem envBound53057 : H12AffineFastState.Bounded env53057 := by
  intro p hp
  have h : env53057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53056_53057 : H12AffineEnvironment.transform 12 3552 env53056 = env53057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3552 env53056 == env53057) = true)

theorem identity53057 : scanCanonicalize (H12AffineFastState.compose env53057 (packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound53057 : packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS < 2^1333 := by decide +kernel

def env53058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,65,3552,2556,3260,3563,2404,1481,1025,3261,137,3092,3244,3262,3432,64,2048,2540,201,1344,1365,3093,257,3229,1432,649]

theorem envBound53058 : H12AffineFastState.Bounded env53058 := by
  intro p hp
  have h : env53058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53057_53058 : H12AffineEnvironment.transform 11 65 env53057 = env53058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env53057 == env53058) = true)

theorem identity53058 : scanCanonicalize (H12AffineFastState.compose env53058 (packedSelected [1,3,5,8,11,12,18] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53058 : packedSelected [1,3,5,8,11,12,18] rootPS < 2^1333 := by decide +kernel

def env53059 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,65,3432,2420,3124,3427,2404,1345,1025,3125,1,3092,3108,3126,3432,64,2048,2404,65,1344,1365,3093,257,3093,1296,513]

theorem envBound53059 : H12AffineFastState.Bounded env53059 := by
  intro p hp
  have h : env53059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53058_53059 : H12AffineEnvironment.transform 6 8 env53058 = env53059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53058 == env53059) = true)

theorem identity53059 : scanCanonicalize (H12AffineFastState.compose env53059 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound53059 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env53060 : List Nat := [2,4,8,16,32,64,8,256,512,1024,81,65,1337,293,1125,1330,309,1345,1025,1124,1,1093,1141,1127,1337,64,81,309,65,1344,1365,1092,257,1092,1296,513]

theorem envBound53060 : H12AffineFastState.Bounded env53060 := by
  intro p hp
  have h : env53060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53059_53060 : H12AffineEnvironment.transform 10 81 env53059 = env53060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env53059 == env53060) = true)

theorem identity53060 : scanCanonicalize (H12AffineFastState.compose env53060 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53060 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env53061 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,17,1337,293,1077,1330,309,1297,1025,1076,1,1045,1061,1079,1337,16,1,309,17,1296,1285,1044,257,1044,1296,513]

theorem envBound53061 : H12AffineFastState.Bounded env53061 := by
  intro p hp
  have h : env53061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53060_53061 : H12AffineEnvironment.transform 5 16 env53060 = env53061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53060 == env53061) = true)

theorem identity53061 : scanCanonicalize (H12AffineFastState.compose env53061 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound53061 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53062 : List Nat := [2,4,8,16,32,16,8,256,512,52,1,17,269,293,1,262,309,293,53,0,1,33,17,3,269,16,1,309,17,292,305,32,257,32,292,513]

theorem envBound53062 : H12AffineFastState.Bounded env53062 := by
  intro p hp
  have h : env53062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53061_53062 : H12AffineEnvironment.transform 9 52 env53061 = env53062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53061 == env53062) = true)

def env53063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254785,25265169,145662400,525568,140903597,27337992,25733062]

theorem envBound53063 : H12AffineFastState.Bounded env53063 := by
  intro p hp
  have h : env53063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52228_53063 : H12AffineEnvironment.transform 25 65 env52228 = env53063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env52228 == env53063) = true)

def env53064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356289,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound53064 : H12AffineFastState.Bounded env53064 := by
  intro p hp
  have h : env53064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53063_53064 : H12AffineEnvironment.transform 26 30393344 env53063 = env53064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env53063 == env53064) = true)

def env53065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound53065 : H12AffineFastState.Bounded env53065 := by
  intro p hp
  have h : env53065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53064_53065 : H12AffineEnvironment.transform 18 1024 env53064 = env53065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env53064 == env53065) = true)

theorem identity53065 : scanCanonicalize (H12AffineFastState.compose env53065 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10882238) := by decide +kernel

theorem selectedBound53065 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env53066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10882238,8328,65,6409406,8882227,10507600,8830977,2590895,13068670,256,509971,469430,2535288]

theorem envBound53066 : H12AffineFastState.Bounded env53066 := by
  intro p hp
  have h : env53066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53065_53066 : H12AffineEnvironment.transform 23 10882238 env53065 = env53066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10882238 env53065 == env53066) = true)

def env53067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412156,2114882,8328,65,6409406,115151,2497708,35325,2590895,4268162,256,509971,469430,2535288]

theorem envBound53067 : H12AffineFastState.Bounded env53067 := by
  intro p hp
  have h : env53067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53066_53067 : H12AffineEnvironment.transform 22 412156 env53066 = env53067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412156 env53066 == env53067) = true)

def env53068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262520,412156,2114882,8328,65,215366,115151,2497708,35325,2590895,2336122,256,509971,469430,2535288]

theorem envBound53068 : H12AffineFastState.Bounded env53068 := by
  intro p hp
  have h : env53068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53067_53068 : H12AffineEnvironment.transform 21 2262520 env53067 = env53068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262520 env53067 == env53068) = true)

def env53069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412156,21762,8328,65,215366,115151,396524,35325,497903,243002,256,509971,469430,442168]

theorem envBound53069 : H12AffineFastState.Bounded env53069 := by
  intro p hp
  have h : env53069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53068_53069 : H12AffineEnvironment.transform 20 4160 env53068 = env53069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env53068 == env53069) = true)

def env53070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,169400,156116,21762,8328,65,215366,115151,140484,35325,241863,243002,256,254011,197022,169744]

theorem envBound53070 : H12AffineFastState.Bounded env53070 := by
  intro p hp
  have h : env53070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53069_53070 : H12AffineEnvironment.transform 17 10280 env53069 = env53070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53069 == env53070) = true)

def env53071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4160,21928,41412,21762,8328,65,100694,115151,58580,35325,94423,95530,256,73771,115086,22272]

theorem envBound53071 : H12AffineFastState.Bounded env53071 := by
  intro p hp
  have h : env53071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53070_53071 : H12AffineEnvironment.transform 16 49168 env53070 = env53071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env53070 == env53071) = true)

theorem identity53071 : scanCanonicalize (H12AffineFastState.compose env53071 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound53071 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,24908,10280,1024,8541,4160,21928,152,21762,8328,65,75786,90259,17800,10401,94423,95530,256,73771,90322,22272]

theorem envBound53072 : H12AffineFastState.Bounded env53072 := by
  intro p hp
  have h : env53072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53071_53072 : H12AffineEnvironment.transform 14 8540 env53071 = env53072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env53071 == env53072) = true)

theorem identity53072 : scanCanonicalize (H12AffineFastState.compose env53072 (packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 29823) := by decide +kernel

theorem selectedBound53072 : packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS < 2^1333 := by decide +kernel

def env53073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,29823,24908,10280,1024,8541,4160,21928,152,21762,8328,65,23669,5356,17800,10401,1192,341,256,21588,5293,22272]

theorem envBound53073 : H12AffineFastState.Bounded env53073 := by
  intro p hp
  have h : env53073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53072_53073 : H12AffineEnvironment.transform 15 29823 env53072 = env53073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29823 env53072 == env53073) = true)

theorem identity53073 : scanCanonicalize (H12AffineFastState.compose env53073 (packedSelected [7,14,18,19,20,23,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53073 : packedSelected [7,14,18,19,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env53074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,0,21795,16400,2420,1024,1,4160,21928,152,21762,468,65,23669,5356,17800,2557,1192,341,256,21588,5293,22272]

theorem envBound53074 : H12AffineFastState.Bounded env53074 := by
  intro p hp
  have h : env53074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53073_53074 : H12AffineEnvironment.transform 12 348 env53073 = env53074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53073 == env53074) = true)

theorem identity53074 : scanCanonicalize (H12AffineFastState.compose env53074 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound53074 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env53075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,4112,0,1331,4096,2420,1024,1,4160,1464,152,1298,468,65,3173,5356,5528,2557,1192,341,256,1092,5293,1808]

theorem envBound53075 : H12AffineFastState.Bounded env53075 := by
  intro p hp
  have h : env53075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53074_53075 : H12AffineEnvironment.transform 13 4112 env53074 = env53075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env53074 == env53075) = true)

theorem identity53075 : scanCanonicalize (H12AffineFastState.compose env53075 (packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound53075 : packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env53076 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,348,4112,0,114,4096,2420,321,1,4160,249,152,83,468,65,2340,4525,4313,2557,489,341,256,261,4588,593]

theorem envBound53076 : H12AffineFastState.Bounded env53076 := by
  intro p hp
  have h : env53076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53075_53076 : H12AffineEnvironment.transform 9 321 env53075 = env53076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env53075 == env53076) = true)

theorem identity53076 : scanCanonicalize (H12AffineFastState.compose env53076 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound53076 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53077 : List Nat := [2,4,8,16,32,64,128,116,512,53,2048,4096,40,4112,0,114,4096,2048,53,1,4160,249,152,83,160,65,2128,4313,4313,2185,157,33,116,113,4248,593]

theorem envBound53077 : H12AffineFastState.Bounded env53077 := by
  intro p hp
  have h : env53077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53076_53077 : H12AffineEnvironment.transform 7 116 env53076 = env53077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env53076 == env53077) = true)

theorem identity53077 : scanCanonicalize (H12AffineFastState.compose env53077 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53077 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53078 : List Nat := [2,4,8,16,32,16,128,36,512,53,2048,4096,40,4112,0,34,4096,2048,53,1,4112,169,152,3,160,17,2048,4233,4233,2185,157,33,36,33,4248,513]

theorem envBound53078 : H12AffineFastState.Bounded env53078 := by
  intro p hp
  have h : env53078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53077_53078 : H12AffineEnvironment.transform 5 16 env53077 = env53078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53077 == env53078) = true)

theorem identity53078 : scanCanonicalize (H12AffineFastState.compose env53078 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound53078 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env53079 : List Nat := [2,4,8,16,32,16,128,36,512,53,0,4096,40,4112,0,34,4096,0,53,1,4112,169,152,3,160,17,0,4233,4233,137,157,33,36,33,4248,513]

theorem envBound53079 : H12AffineFastState.Bounded env53079 := by
  intro p hp
  have h : env53079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53078_53079 : H12AffineEnvironment.transform 10 0 env53078 = env53079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env53078 == env53079) = true)

theorem identity53079 : scanCanonicalize (H12AffineFastState.compose env53079 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound53079 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env53080 : List Nat := [2,4,8,16,32,16,128,36,512,53,0,16,40,0,0,34,16,0,53,1,0,169,152,3,160,17,0,153,153,137,157,33,36,33,136,513]

theorem envBound53080 : H12AffineFastState.Bounded env53080 := by
  intro p hp
  have h : env53080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53079_53080 : H12AffineEnvironment.transform 11 16 env53079 = env53080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env53079 == env53080) = true)

theorem identity53080 : scanCanonicalize (H12AffineFastState.compose env53080 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53080 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53081 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,16,40,0,0,34,16,0,53,1,0,33,16,3,40,17,0,17,17,1,21,33,36,33,0,513]

theorem envBound53081 : H12AffineFastState.Bounded env53081 := by
  intro p hp
  have h : env53081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53080_53081 : H12AffineEnvironment.transform 6 8 env53080 = env53081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53080 == env53081) = true)

theorem identity53081 : scanCanonicalize (H12AffineFastState.compose env53081 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53081 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53082 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,16,8,0,0,2,16,0,21,1,0,1,16,3,8,17,0,17,17,1,21,1,4,1,0,513]

theorem envBound53082 : H12AffineFastState.Bounded env53082 := by
  intro p hp
  have h : env53082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53081_53082 : H12AffineEnvironment.transform 4 0 env53081 = env53082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53081 == env53082) = true)

theorem identity53082 : scanCanonicalize (H12AffineFastState.compose env53082 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound53082 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53083 : List Nat := [2,4,8,1,0,1,8,4,512,4,0,1,8,0,0,2,1,0,4,1,0,1,1,3,8,0,0,0,0,1,4,1,4,1,0,513]

theorem envBound53083 : H12AffineFastState.Bounded env53083 := by
  intro p hp
  have h : env53083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53082_53083 : H12AffineEnvironment.transform 3 1 env53082 = env53083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53082 == env53083) = true)

theorem identity53083 : scanCanonicalize (H12AffineFastState.compose env53083 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound53083 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53084 : List Nat := [2,4,8,1,0,1,8,4,0,4,0,1,8,0,0,2,1,0,4,1,0,1,1,3,8,0,0,0,0,1,4,1,4,1,0,1]

theorem envBound53084 : H12AffineFastState.Bounded env53084 := by
  intro p hp
  have h : env53084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53083_53084 : H12AffineEnvironment.transform 8 0 env53083 = env53084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env53083 == env53084) = true)

def env53085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4160,21929,41413,21762,8328,65,100695,115151,58581,35325,94422,95531,256,73770,115087,22273]

theorem envBound53085 : H12AffineFastState.Bounded env53085 := by
  intro p hp
  have h : env53085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53070_53085 : H12AffineEnvironment.transform 16 49169 env53070 = env53085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env53070 == env53085) = true)

theorem identity53085 : scanCanonicalize (H12AffineFastState.compose env53085 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound53085 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,25029,10280,1024,8661,4160,21929,17,21762,8328,65,75907,90139,17665,10281,94422,95531,256,73770,90203,22273]

theorem envBound53086 : H12AffineFastState.Bounded env53086 := by
  intro p hp
  have h : env53086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53085_53086 : H12AffineEnvironment.transform 14 8660 env53085 = env53086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env53085 == env53086) = true)

theorem identity53086 : scanCanonicalize (H12AffineFastState.compose env53086 (packedSelected [2,3,5,6,7,8,9,11,16,22,23,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 21875) := by decide +kernel

theorem selectedBound53086 : packedSelected [2,3,5,6,7,8,9,11,16,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env53087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,21875,25029,10280,1024,8661,4160,21929,17,21762,8328,65,32240,13672,17665,10281,9637,8280,256,30041,13608,22273]

theorem envBound53087 : H12AffineFastState.Bounded env53087 := by
  intro p hp
  have h : env53087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53086_53087 : H12AffineEnvironment.transform 15 21875 env53086 = env53087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21875 env53086 == env53087) = true)

theorem identity53087 : scanCanonicalize (H12AffineFastState.compose env53087 (packedSelected [1,4,5,8,9,14,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound53087 : packedSelected [1,4,5,8,9,14,20,24] rootPS < 2^1333 := by decide +kernel

def env53088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5592,8660,171,13341,10280,1024,8661,4160,113,17,218,8328,65,10280,13672,4313,10281,9637,8280,256,8321,13608,729]

theorem envBound53088 : H12AffineFastState.Bounded env53088 := by
  intro p hp
  have h : env53088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53087_53088 : H12AffineEnvironment.transform 13 5592 env53087 = env53088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env53087 == env53088) = true)

theorem identity53088 : scanCanonicalize (H12AffineFastState.compose env53088 (packedSelected [0,1,2,4,6,7,8,9,11,14,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 1457) := by decide +kernel

theorem selectedBound53088 : packedSelected [0,1,2,4,6,7,8,9,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env53089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1457,5592,1125,171,4524,3481,1024,1124,4160,113,17,218,1337,65,3481,4313,4313,3480,20,1513,256,1328,4249,729]

theorem envBound53089 : H12AffineFastState.Bounded env53089 := by
  intro p hp
  have h : env53089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53088_53089 : H12AffineEnvironment.transform 12 1457 env53088 = env53089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env53088 == env53089) = true)

theorem identity53089 : scanCanonicalize (H12AffineFastState.compose env53089 (packedSelected [4,9,11,14,18,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53089 : packedSelected [4,9,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env53090 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,5456,1125,35,4388,3345,1024,1124,4160,113,17,82,1337,65,3345,4177,4177,3344,20,1377,256,1328,4113,593]

theorem envBound53090 : H12AffineFastState.Bounded env53090 := by
  intro p hp
  have h : env53090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53089_53090 : H12AffineEnvironment.transform 6 8 env53089 = env53090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53089 == env53090) = true)

theorem identity53090 : scanCanonicalize (H12AffineFastState.compose env53090 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound53090 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env53091 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,1101,5156,1125,35,4176,3173,1024,1124,4160,113,17,82,1101,65,3173,4177,4177,3172,20,1045,116,1092,4113,593]

theorem envBound53091 : H12AffineFastState.Bounded env53091 := by
  intro p hp
  have h : env53091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53090_53091 : H12AffineEnvironment.transform 7 116 env53090 = env53091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env53090 == env53091) = true)

theorem identity53091 : scanCanonicalize (H12AffineFastState.compose env53091 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53091 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53092 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,1053,5156,1077,35,4096,3125,1024,1076,4112,33,17,2,1053,17,3125,4097,4097,3124,20,1045,36,1044,4113,513]

theorem envBound53092 : H12AffineFastState.Bounded env53092 := by
  intro p hp
  have h : env53092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53091_53092 : H12AffineEnvironment.transform 5 16 env53091 = env53092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53091 == env53092) = true)

theorem identity53092 : scanCanonicalize (H12AffineFastState.compose env53092 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound53092 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env53093 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3109,1053,2049,1077,35,3109,3125,1024,1076,3125,33,17,2,1053,17,3125,3108,3108,3124,20,1045,36,1044,3124,513]

theorem envBound53093 : H12AffineFastState.Bounded env53093 := by
  intro p hp
  have h : env53093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53092_53093 : H12AffineEnvironment.transform 11 3109 env53092 = env53093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env53092 == env53093) = true)

theorem identity53093 : scanCanonicalize (H12AffineFastState.compose env53093 (packedSelected [0,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound53093 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env53094 : List Nat := [2,4,8,16,32,16,8,36,512,1024,17,1076,1053,16,1077,35,1076,1060,1024,1076,1060,33,17,2,1053,17,1060,1077,1077,1061,20,1045,36,1044,1061,513]

theorem envBound53094 : H12AffineFastState.Bounded env53094 := by
  intro p hp
  have h : env53094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53093_53094 : H12AffineEnvironment.transform 10 17 env53093 = env53094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env53093 == env53094) = true)

theorem identity53094 : scanCanonicalize (H12AffineFastState.compose env53094 (packedSelected [2,3] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound53094 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env53095 : List Nat := [2,4,8,16,32,16,8,36,59,1024,17,1076,1053,16,1077,35,1076,1060,1024,1076,1060,33,17,2,1053,17,1060,1077,1077,1061,20,1045,36,1044,1061,58]

theorem envBound53095 : H12AffineFastState.Bounded env53095 := by
  intro p hp
  have h : env53095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53094_53095 : H12AffineEnvironment.transform 8 59 env53094 = env53095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env53094 == env53095) = true)

theorem identity53095 : scanCanonicalize (H12AffineFastState.compose env53095 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound53095 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53096 : List Nat := [2,4,8,16,32,16,8,36,59,53,17,1,40,16,0,35,1,17,53,1,17,33,17,2,40,17,17,0,0,16,20,32,36,33,16,58]

theorem envBound53096 : H12AffineFastState.Bounded env53096 := by
  intro p hp
  have h : env53096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53095_53096 : H12AffineEnvironment.transform 9 53 env53095 = env53096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53095 == env53096) = true)

theorem identity53096 : scanCanonicalize (H12AffineFastState.compose env53096 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound53096 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53097 : List Nat := [2,4,8,1,32,1,8,36,42,36,0,1,40,1,0,35,1,0,36,1,0,33,0,2,40,0,0,0,0,1,5,32,36,33,1,43]

theorem envBound53097 : H12AffineFastState.Bounded env53097 := by
  intro p hp
  have h : env53097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53096_53097 : H12AffineEnvironment.transform 3 1 env53096 = env53097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53096 == env53097) = true)

theorem identity53097 : scanCanonicalize (H12AffineFastState.compose env53097 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound53097 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53098 : List Nat := [2,4,2,1,32,1,2,36,32,36,0,1,34,1,0,35,1,0,36,1,0,33,0,2,34,0,0,0,0,1,5,32,36,33,1,33]

theorem envBound53098 : H12AffineFastState.Bounded env53098 := by
  intro p hp
  have h : env53098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53097_53098 : H12AffineEnvironment.transform 2 2 env53097 = env53098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env53097 == env53098) = true)

theorem identity53098 : scanCanonicalize (H12AffineFastState.compose env53098 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53098 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53099 : List Nat := [2,4,2,1,0,1,2,4,0,4,0,1,2,1,0,3,1,0,4,1,0,1,0,2,2,0,0,0,0,1,5,0,4,1,1,1]

theorem envBound53099 : H12AffineFastState.Bounded env53099 := by
  intro p hp
  have h : env53099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53098_53099 : H12AffineEnvironment.transform 4 0 env53098 = env53099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53098 == env53099) = true)

def env53100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,169400,156117,21762,8328,65,215366,115151,140485,35325,241862,243002,256,254010,197023,169745]

theorem envBound53100 : H12AffineFastState.Bounded env53100 := by
  intro p hp
  have h : env53100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53069_53100 : H12AffineEnvironment.transform 17 10281 env53069 = env53100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53069 == env53100) = true)

def env53101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4160,21928,41413,21762,8328,65,100694,115151,58581,35325,94422,95530,256,73770,115087,22273]

theorem envBound53101 : H12AffineFastState.Bounded env53101 := by
  intro p hp
  have h : env53101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53100_53101 : H12AffineEnvironment.transform 16 49168 env53100 = env53101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env53100 == env53101) = true)

theorem identity53101 : scanCanonicalize (H12AffineFastState.compose env53101 (packedSelected [0,1,2,3,5,6,7,11,14,15,18,20,26,28,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 21726) := by decide +kernel

theorem selectedBound53101 : packedSelected [0,1,2,3,5,6,7,11,14,15,18,20,26,28,35,38] rootPS < 2^1333 := by decide +kernel

def env53102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21726,49168,10281,1024,32769,4160,21928,41413,21762,8328,65,56712,38161,58581,35325,9224,8692,256,29940,38225,22273]

theorem envBound53102 : H12AffineFastState.Bounded env53102 := by
  intro p hp
  have h : env53102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53101_53102 : H12AffineEnvironment.transform 15 21726 env53101 = env53102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21726 env53101 == env53102) = true)

theorem identity53102 : scanCanonicalize (H12AffineFastState.compose env53102 (packedSelected [2,5,6,7,9,20,22,23,24,26,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53102 : packedSelected [2,5,6,7,9,20,22,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env53103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,478,38160,10281,1024,32769,4160,168,41413,2,8328,65,34952,38161,45525,35325,9224,8692,256,8692,38225,513]

theorem envBound53103 : H12AffineFastState.Bounded env53103 := by
  intro p hp
  have h : env53103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53102_53103 : H12AffineEnvironment.transform 13 5376 env53102 = env53103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53102 == env53103) = true)

theorem identity53103 : scanCanonicalize (H12AffineFastState.compose env53103 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound53103 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env53104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,136,478,5528,10281,1024,137,4160,168,8525,2,8328,65,2048,5529,12637,2421,9224,8692,256,8692,5593,513]

theorem envBound53104 : H12AffineFastState.Bounded env53104 := by
  intro p hp
  have h : env53104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53103_53104 : H12AffineEnvironment.transform 14 136 env53103 = env53104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env53103 == env53104) = true)

theorem identity53104 : scanCanonicalize (H12AffineFastState.compose env53104 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53104 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53105 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,343,5393,10281,1024,0,4160,33,8525,2,8193,65,2048,5392,12637,2421,9224,8573,256,8573,5456,513]

theorem envBound53105 : H12AffineFastState.Bounded env53105 := by
  intro p hp
  have h : env53105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53104_53105 : H12AffineEnvironment.transform 6 9 env53104 = env53105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53104 == env53105) = true)

theorem identity53105 : scanCanonicalize (H12AffineFastState.compose env53105 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53105 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,1,343,5393,2340,1024,0,4160,33,64,2,268,65,2048,5392,4176,2421,1285,112,256,112,5456,513]

theorem envBound53106 : H12AffineFastState.Bounded env53106 := by
  intro p hp
  have h : env53106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53105_53106 : H12AffineEnvironment.transform 12 269 env53105 = env53106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53105 == env53106) = true)

theorem identity53106 : scanCanonicalize (H12AffineFastState.compose env53106 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound53106 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env53107 : List Nat := [2,4,8,16,32,64,9,256,512,305,2048,4096,269,4145,1,343,4128,2340,305,0,4160,33,64,2,268,65,2048,4129,4176,2421,52,112,256,112,4193,513]

theorem envBound53107 : H12AffineFastState.Bounded env53107 := by
  intro p hp
  have h : env53107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53106_53107 : H12AffineEnvironment.transform 9 305 env53106 = env53107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env53106 == env53107) = true)

theorem identity53107 : scanCanonicalize (H12AffineFastState.compose env53107 (packedSelected [2,3,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53107 : packedSelected [2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env53108 : List Nat := [2,4,8,16,32,16,9,256,512,305,2048,4096,269,4145,1,263,4128,2340,305,0,4112,33,16,2,268,17,2048,4129,4096,2341,52,32,256,32,4145,513]

theorem envBound53108 : H12AffineFastState.Bounded env53108 := by
  intro p hp
  have h : env53108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53107_53108 : H12AffineEnvironment.transform 5 16 env53107 = env53108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53107 == env53108) = true)

def env53109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4160,21929,41412,21762,8328,65,100695,115151,58580,35325,94423,95531,256,73771,115086,22272]

theorem envBound53109 : H12AffineFastState.Bounded env53109 := by
  intro p hp
  have h : env53109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53100_53109 : H12AffineEnvironment.transform 16 49169 env53100 = env53109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env53100 == env53109) = true)

theorem identity53109 : scanCanonicalize (H12AffineFastState.compose env53109 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53109 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53110 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4160,21792,41293,21762,8193,65,100695,115014,58461,35188,94302,95531,256,73771,114951,22272]

theorem envBound53110 : H12AffineFastState.Bounded env53110 := by
  intro p hp
  have h : env53110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53109_53110 : H12AffineEnvironment.transform 6 9 env53109 = env53110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53109 == env53110) = true)

theorem identity53110 : scanCanonicalize (H12AffineFastState.compose env53110 (packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound53110 : packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53111 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,65536,5441,10281,1024,21841,4160,21792,29725,21762,8193,65,89095,70678,12557,23588,94302,95531,256,73771,70743,22272]

theorem envBound53111 : H12AffineFastState.Bounded env53111 := by
  intro p hp
  have h : env53111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53110_53111 : H12AffineEnvironment.transform 14 21840 env53110 = env53111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env53110 == env53111) = true)

theorem identity53111 : scanCanonicalize (H12AffineFastState.compose env53111 (packedSelected [0,2,3,6,7,10,11,16,18,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound53111 : packedSelected [0,2,3,6,7,10,11,16,18,19,24] rootPS < 2^1333 := by decide +kernel

def env53112 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,262,5441,10281,1024,21841,4160,21792,29725,21762,8193,65,23809,5392,12557,23588,29016,29741,256,8493,5457,22272]

theorem envBound53112 : H12AffineFastState.Bounded env53112 := by
  intro p hp
  have h : env53112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53111_53112 : H12AffineEnvironment.transform 15 262 env53111 = env53112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env53111 == env53112) = true)

theorem identity53112 : scanCanonicalize (H12AffineFastState.compose env53112 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound53112 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env53113 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8460,262,5441,10281,1024,8461,4160,8572,65,8542,8193,65,10589,5392,12557,10360,1284,113,256,8493,5457,9052]

theorem envBound53113 : H12AffineFastState.Bounded env53113 := by
  intro p hp
  have h : env53113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53112_53113 : H12AffineEnvironment.transform 13 13404 env53112 = env53113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env53112 == env53113) = true)

theorem identity53113 : scanCanonicalize (H12AffineFastState.compose env53113 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53113 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53114 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,0,262,5441,2341,1024,1,4160,112,65,82,269,65,2129,5392,4097,2420,1284,113,256,33,5457,592]

theorem envBound53114 : H12AffineFastState.Bounded env53114 := by
  intro p hp
  have h : env53114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53113_53114 : H12AffineEnvironment.transform 12 268 env53113 = env53114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53113 == env53114) = true)

theorem identity53114 : scanCanonicalize (H12AffineFastState.compose env53114 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53114 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env53115 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,262,5392,2341,1024,1,4113,33,16,3,269,16,2048,5392,4097,2341,1284,32,256,33,5376,513]

theorem envBound53115 : H12AffineFastState.Bounded env53115 := by
  intro p hp
  have h : env53115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53114_53115 : H12AffineEnvironment.transform 5 17 env53114 = env53115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53114 == env53115) = true)

theorem identity53115 : scanCanonicalize (H12AffineFastState.compose env53115 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound53115 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53116 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,0,34,5172,2049,1024,1,4113,33,16,3,41,16,2048,5172,4097,2049,1056,32,36,33,5156,513]

theorem envBound53116 : H12AffineFastState.Bounded env53116 := by
  intro p hp
  have h : env53116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53115_53116 : H12AffineEnvironment.transform 7 36 env53115 = env53116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53115 == env53116) = true)

theorem identity53116 : scanCanonicalize (H12AffineFastState.compose env53116 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound53116 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53117 : List Nat := [2,4,8,16,32,17,9,36,512,1024,523,4096,40,5157,0,34,5172,522,1024,1,4113,33,16,3,41,16,523,5172,4097,522,1056,32,36,33,5156,513]

theorem envBound53117 : H12AffineFastState.Bounded env53117 := by
  intro p hp
  have h : env53117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53116_53117 : H12AffineEnvironment.transform 10 523 env53116 = env53117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env53116 == env53117) = true)

theorem identity53117 : scanCanonicalize (H12AffineFastState.compose env53117 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53117 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53118 : List Nat := [2,4,8,16,0,17,9,4,512,1024,523,4096,8,5125,0,2,5140,522,1024,1,4113,1,16,3,9,16,523,5140,4097,522,1024,0,4,1,5124,513]

theorem envBound53118 : H12AffineFastState.Bounded env53118 := by
  intro p hp
  have h : env53118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53117_53118 : H12AffineEnvironment.transform 4 0 env53117 = env53118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53117 == env53118) = true)

def env53119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412156,21763,8328,65,215366,115151,396525,35325,497902,243003,256,509971,469430,442169]

theorem envBound53119 : H12AffineFastState.Bounded env53119 := by
  intro p hp
  have h : env53119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53068_53119 : H12AffineEnvironment.transform 20 4161 env53068 = env53119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env53068 == env53119) = true)

theorem identity53119 : scanCanonicalize (H12AffineFastState.compose env53119 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound53119 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,169401,62660,21763,8328,65,215366,115151,45525,35325,75222,243003,256,95531,103566,513]

theorem envBound53120 : H12AffineFastState.Bounded env53120 := by
  intro p hp
  have h : env53120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53119_53120 : H12AffineEnvironment.transform 17 179512 env53119 = env53120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env53119 == env53120) = true)

def env53121 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,169265,62540,21763,8192,65,215366,115015,45405,35189,75102,243003,256,95531,103430,513]

theorem envBound53121 : H12AffineFastState.Bounded env53121 := by
  intro p hp
  have h : env53121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53120_53121 : H12AffineEnvironment.transform 6 8 env53120 = env53121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53120 == env53121) = true)

theorem identity53121 : scanCanonicalize (H12AffineFastState.compose env53121 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound53121 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env53122 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,122146,1024,32769,4161,128299,62540,21763,8192,65,10588,115015,45405,35189,75102,54561,256,95531,103430,513]

theorem envBound53122 : H12AffineFastState.Bounded env53122 := by
  intro p hp
  have h : env53122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53121_53122 : H12AffineEnvironment.transform 16 90138 env53121 = env53122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env53121 == env53122) = true)

theorem identity53122 : scanCanonicalize (H12AffineFastState.compose env53122 (packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS)) = affineNative (2^(14+1) ^^^ 20789) := by decide +kernel

theorem selectedBound53122 : packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env53123 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,20789,65536,90138,68631,1024,20788,4161,74782,9593,21763,8192,65,10588,69746,24680,22592,75102,1044,256,95531,83251,513]

theorem envBound53123 : H12AffineFastState.Bounded env53123 := by
  intro p hp
  have h : env53123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53122_53123 : H12AffineEnvironment.transform 14 20789 env53122 = env53123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20789 env53122 == env53123) = true)

theorem identity53123 : scanCanonicalize (H12AffineFastState.compose env53123 (packedSelected [7,8,10,14,17,20,23,27,28,32] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound53123 : packedSelected [7,8,10,14,17,20,23,27,28,32] rootPS < 2^1333 := by decide +kernel

def env53124 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,20789,65536,83031,68631,1024,20788,4161,65619,308,21763,1101,65,3345,69746,17445,22592,65811,1044,256,86374,83251,513]

theorem envBound53124 : H12AffineFastState.Bounded env53124 := by
  intro p hp
  have h : env53124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53123_53124 : H12AffineEnvironment.transform 12 1101 env53123 = env53124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env53123 == env53124) = true)

theorem identity53124 : scanCanonicalize (H12AffineFastState.compose env53124 (packedSelected [0,1,2,4,5,6,9,10,11,12,15,17,18,20,24,27,28] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound53124 : packedSelected [0,1,2,4,5,6,9,10,11,12,15,17,18,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env53125 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,269,16384,20789,65536,82199,67927,320,20788,4161,65619,308,20547,269,65,2129,69746,16741,22592,65811,340,256,86374,82035,513]

theorem envBound53125 : H12AffineFastState.Bounded env53125 := by
  intro p hp
  have h : env53125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53124_53125 : H12AffineEnvironment.transform 9 320 env53124 = env53125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env53124 == env53125) = true)

theorem identity53125 : scanCanonicalize (H12AffineFastState.compose env53125 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 20579) := by decide +kernel

theorem selectedBound53125 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env53126 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,269,16384,20789,20579,4468,22836,320,20788,4161,20528,308,20547,269,65,2129,16401,16741,22592,20848,340,256,261,4112,513]

theorem envBound53126 : H12AffineFastState.Bounded env53126 := by
  intro p hp
  have h : env53126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53125_53126 : H12AffineEnvironment.transform 15 20579 env53125 = env53126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20579 env53125 == env53126) = true)

theorem identity53126 : scanCanonicalize (H12AffineFastState.compose env53126 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound53126 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env53127 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,269,4113,292,114,4468,2341,320,293,4161,33,308,82,269,65,2129,4096,4468,2129,353,340,256,261,4112,513]

theorem envBound53127 : H12AffineFastState.Bounded env53127 := by
  intro p hp
  have h : env53127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53126_53127 : H12AffineEnvironment.transform 13 4113 env53126 = env53127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env53126 == env53127) = true)

theorem identity53127 : scanCanonicalize (H12AffineFastState.compose env53127 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound53127 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53128 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,4096,121,4113,80,114,4096,2129,52,81,4161,33,64,82,121,65,2129,4096,4096,2129,21,32,116,113,4112,513]

theorem envBound53128 : H12AffineFastState.Bounded env53128 := by
  intro p hp
  have h : env53128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53127_53128 : H12AffineEnvironment.transform 7 116 env53127 = env53128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env53127 == env53128) = true)

theorem identity53128 : scanCanonicalize (H12AffineFastState.compose env53128 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound53128 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53129 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,528,121,513,80,114,528,2129,52,81,593,33,64,82,121,65,2129,528,528,2129,21,32,116,113,512,513]

theorem envBound53129 : H12AffineFastState.Bounded env53129 := by
  intro p hp
  have h : env53129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53128_53129 : H12AffineEnvironment.transform 11 528 env53128 = env53129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env53128 == env53129) = true)

theorem identity53129 : scanCanonicalize (H12AffineFastState.compose env53129 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53129 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53130 : List Nat := [2,4,8,16,32,64,8,116,1,52,2048,17,121,0,80,114,17,2129,52,81,80,33,64,82,121,65,2129,17,17,2129,21,32,116,113,1,0]

theorem envBound53130 : H12AffineFastState.Bounded env53130 := by
  intro p hp
  have h : env53130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53129_53130 : H12AffineEnvironment.transform 8 1 env53129 = env53130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53129 == env53130) = true)

theorem identity53130 : scanCanonicalize (H12AffineFastState.compose env53130 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound53130 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53131 : List Nat := [2,4,8,16,32,0,8,52,1,52,2048,17,57,0,16,50,17,2065,52,17,16,33,0,18,57,1,2065,17,17,2065,21,32,52,49,1,0]

theorem envBound53131 : H12AffineFastState.Bounded env53131 := by
  intro p hp
  have h : env53131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53130_53131 : H12AffineEnvironment.transform 5 0 env53130 = env53131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env53130 == env53131) = true)

theorem identity53131 : scanCanonicalize (H12AffineFastState.compose env53131 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53131 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53132 : List Nat := [2,4,8,16,1,0,8,21,1,21,2048,17,24,0,16,19,17,2065,21,17,16,0,0,18,24,1,2065,17,17,2065,21,1,21,16,1,0]

theorem envBound53132 : H12AffineFastState.Bounded env53132 := by
  intro p hp
  have h : env53132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53131_53132 : H12AffineEnvironment.transform 4 1 env53131 = env53132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53131 == env53132) = true)

theorem identity53132 : scanCanonicalize (H12AffineFastState.compose env53132 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound53132 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env53133 : List Nat := [2,4,8,16,1,0,8,21,1,21,16,17,24,0,16,19,17,1,21,17,16,0,0,18,24,1,1,17,17,1,21,1,21,16,1,0]

theorem envBound53133 : H12AffineFastState.Bounded env53133 := by
  intro p hp
  have h : env53133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53132_53133 : H12AffineEnvironment.transform 10 16 env53132 = env53133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env53132 == env53133) = true)

theorem identity53133 : scanCanonicalize (H12AffineFastState.compose env53133 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53133 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53134 : List Nat := [2,4,8,0,1,0,8,5,1,5,0,1,8,0,0,3,1,1,5,1,0,0,0,2,8,1,1,1,1,1,5,1,5,0,1,0]

theorem envBound53134 : H12AffineFastState.Bounded env53134 := by
  intro p hp
  have h : env53134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53133_53134 : H12AffineEnvironment.transform 3 0 env53133 = env53134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53133 == env53134) = true)

def env53135 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,169264,62541,21763,8193,65,215366,115014,45404,35188,75103,243003,256,95531,103431,513]

theorem envBound53135 : H12AffineFastState.Bounded env53135 := by
  intro p hp
  have h : env53135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53120_53135 : H12AffineEnvironment.transform 6 9 env53120 = env53135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53120 == env53135) = true)

theorem identity53135 : scanCanonicalize (H12AffineFastState.compose env53135 (packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound53135 : packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env53136 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4161,33,62541,21763,8193,65,121943,115014,45404,35188,75103,73770,256,95531,103431,513]

theorem envBound53136 : H12AffineFastState.Bounded env53136 := by
  intro p hp
  have h : env53136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53135_53136 : H12AffineEnvironment.transform 16 38161 env53135 = env53136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env53135 == env53136) = true)

theorem identity53136 : scanCanonicalize (H12AffineFastState.compose env53136 (packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound53136 : packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS < 2^1333 := by decide +kernel

def env53137 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,65536,13340,10281,1024,8460,4161,33,21824,21763,8193,65,97626,90187,4177,10361,75103,73770,256,95531,79114,513]

theorem envBound53137 : H12AffineFastState.Bounded env53137 := by
  intro p hp
  have h : env53137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53136_53137 : H12AffineEnvironment.transform 14 8461 env53136 = env53137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env53136 == env53137) = true)

theorem identity53137 : scanCanonicalize (H12AffineFastState.compose env53137 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound53137 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env53138 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,30043,13340,10281,1024,8460,4161,33,21824,21763,8193,65,2049,5392,4177,10361,20484,21873,256,112,16465,513]

theorem envBound53138 : H12AffineFastState.Bounded env53138 := by
  intro p hp
  have h : env53138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53137_53138 : H12AffineEnvironment.transform 15 30043 env53137 = env53138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env53137 == env53138) = true)

theorem identity53138 : scanCanonicalize (H12AffineFastState.compose env53138 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53138 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env53139 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,1,21591,5392,2341,1024,0,4161,33,21824,21763,269,65,2049,5392,4177,2421,20484,21873,256,112,16465,513]

theorem envBound53139 : H12AffineFastState.Bounded env53139 := by
  intro p hp
  have h : env53139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53138_53139 : H12AffineEnvironment.transform 12 268 env53138 = env53139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53138 == env53139) = true)

theorem identity53139 : scanCanonicalize (H12AffineFastState.compose env53139 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound53139 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env53140 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,1,342,5392,2341,1024,0,4161,33,65,2,269,65,2049,5392,4177,2421,1285,112,256,112,5456,513]

theorem envBound53140 : H12AffineFastState.Bounded env53140 := by
  intro p hp
  have h : env53140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53139_53140 : H12AffineEnvironment.transform 13 5377 env53139 = env53140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env53139 == env53140) = true)

theorem identity53140 : scanCanonicalize (H12AffineFastState.compose env53140 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53140 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53141 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5392,2341,1024,0,4113,33,17,2,269,17,2049,5392,4097,2341,1285,32,256,32,5376,513]

theorem envBound53141 : H12AffineFastState.Bounded env53141 := by
  intro p hp
  have h : env53141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53140_53141 : H12AffineEnvironment.transform 5 16 env53140 = env53141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53140 == env53141) = true)

theorem identity53141 : scanCanonicalize (H12AffineFastState.compose env53141 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound53141 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53142 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,0,268,1281,1,262,1296,2341,1024,0,17,33,17,2,269,17,2049,1296,1,2341,1285,32,256,32,1280,513]

theorem envBound53142 : H12AffineFastState.Bounded env53142 := by
  intro p hp
  have h : env53142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53141_53142 : H12AffineEnvironment.transform 11 0 env53141 = env53142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env53141 == env53142) = true)

theorem identity53142 : scanCanonicalize (H12AffineFastState.compose env53142 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound53142 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53143 : List Nat := [2,4,8,16,32,16,9,256,512,1024,319,0,268,1281,1,262,1296,26,1024,0,17,33,17,2,269,17,318,1296,1,26,1285,32,256,32,1280,513]

theorem envBound53143 : H12AffineFastState.Bounded env53143 := by
  intro p hp
  have h : env53143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53142_53143 : H12AffineEnvironment.transform 10 319 env53142 = env53143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env53142 == env53143) = true)

theorem identity53143 : scanCanonicalize (H12AffineFastState.compose env53143 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound53143 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53144 : List Nat := [2,4,8,16,32,16,9,256,512,21,319,0,268,276,1,262,261,26,21,0,17,33,17,2,269,17,318,261,1,26,272,32,256,32,277,513]

theorem envBound53144 : H12AffineFastState.Bounded env53144 := by
  intro p hp
  have h : env53144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53143_53144 : H12AffineEnvironment.transform 9 21 env53143 = env53144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env53143 == env53144) = true)

theorem identity53144 : scanCanonicalize (H12AffineFastState.compose env53144 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound53144 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53145 : List Nat := [2,4,8,16,32,16,9,53,512,21,10,0,57,33,1,51,48,26,21,0,17,33,17,2,56,17,11,48,1,26,37,32,53,32,32,513]

theorem envBound53145 : H12AffineFastState.Bounded env53145 := by
  intro p hp
  have h : env53145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53144_53145 : H12AffineEnvironment.transform 7 53 env53144 = env53145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env53144 == env53145) = true)

theorem identity53145 : scanCanonicalize (H12AffineFastState.compose env53145 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound53145 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53146 : List Nat := [2,4,8,16,27,16,9,14,512,21,10,0,2,26,1,8,11,26,21,0,17,26,17,2,3,17,11,11,1,26,30,27,14,27,27,513]

theorem envBound53146 : H12AffineFastState.Bounded env53146 := by
  intro p hp
  have h : env53146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53145_53146 : H12AffineEnvironment.transform 4 27 env53145 = env53146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env53145 == env53146) = true)

theorem identity53146 : scanCanonicalize (H12AffineFastState.compose env53146 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound53146 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env53147 : List Nat := [2,4,3,16,16,16,2,5,512,21,1,0,2,17,1,3,0,17,21,0,17,17,17,2,3,17,0,0,1,17,21,16,5,16,16,513]

theorem envBound53147 : H12AffineFastState.Bounded env53147 := by
  intro p hp
  have h : env53147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53146_53147 : H12AffineEnvironment.transform 2 3 env53146 = env53147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env53146 == env53147) = true)

theorem identity53147 : scanCanonicalize (H12AffineFastState.compose env53147 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 19) := by decide +kernel

theorem selectedBound53147 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53148 : List Nat := [2,4,3,16,16,16,2,5,19,21,1,0,2,17,1,3,0,17,21,0,17,17,17,2,3,17,0,0,1,17,21,16,5,16,16,18]

theorem envBound53148 : H12AffineFastState.Bounded env53148 := by
  intro p hp
  have h : env53148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53147_53148 : H12AffineEnvironment.transform 8 19 env53147 = env53148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 19 env53147 == env53148) = true)

theorem identity53148 : scanCanonicalize (H12AffineFastState.compose env53148 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53148 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env53149 : List Nat := [2,4,3,0,0,0,2,5,3,5,1,0,2,1,1,3,0,1,5,0,1,1,1,2,3,1,0,0,1,1,5,0,5,0,0,2]

theorem envBound53149 : H12AffineFastState.Bounded env53149 := by
  intro p hp
  have h : env53149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53148_53149 : H12AffineEnvironment.transform 3 0 env53148 = env53149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53148 == env53149) = true)

theorem identity53149 : scanCanonicalize (H12AffineFastState.compose env53149 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound53149 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53150 : List Nat := [2,0,3,0,0,0,2,1,3,1,1,0,2,1,1,3,0,1,1,0,1,1,1,2,3,1,0,0,1,1,1,0,1,0,0,2]

theorem envBound53150 : H12AffineFastState.Bounded env53150 := by
  intro p hp
  have h : env53150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53149_53150 : H12AffineEnvironment.transform 1 0 env53149 = env53150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env53149 == env53150) = true)

def env53151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262521,412156,2114882,8328,65,215367,115151,2497708,35325,2590895,2336123,256,509971,469430,2535288]

theorem envBound53151 : H12AffineFastState.Bounded env53151 := by
  intro p hp
  have h : env53151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53067_53151 : H12AffineEnvironment.transform 21 2262521 env53067 = env53151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262521 env53067 == env53151) = true)

def env53152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412156,21762,8328,65,215367,115151,396524,35325,497903,243003,256,509971,469430,442168]

theorem envBound53152 : H12AffineFastState.Bounded env53152 := by
  intro p hp
  have h : env53152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53151_53152 : H12AffineEnvironment.transform 20 4160 env53151 = env53152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env53151 == env53152) = true)

theorem identity53152 : scanCanonicalize (H12AffineFastState.compose env53152 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149996) := by decide +kernel

theorem selectedBound53152 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4160,169401,16,21762,8328,65,215367,115151,17664,35325,119043,243003,256,98815,90202,63188]

theorem envBound53153 : H12AffineFastState.Bounded env53153 := by
  intro p hp
  have h : env53153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53152_53153 : H12AffineEnvironment.transform 17 149996 env53152 = env53153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149996 env53152 == env53153) = true)

def env53154 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169265,16,21762,8192,65,215367,115015,17664,35189,119043,243003,256,98679,90202,63068]

theorem envBound53154 : H12AffineFastState.Bounded env53154 := by
  intro p hp
  have h : env53154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53153_53154 : H12AffineEnvironment.transform 6 8 env53153 = env53154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53153 == env53154) = true)

theorem identity53154 : scanCanonicalize (H12AffineFastState.compose env53154 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound53154 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53155 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1024,32769,4160,21793,16,21762,8192,65,100695,115015,17664,35189,119043,95531,256,98679,90202,63068]

theorem envBound53155 : H12AffineFastState.Bounded env53155 := by
  intro p hp
  have h : env53155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53154_53155 : H12AffineEnvironment.transform 16 49168 env53154 = env53155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env53154 == env53155) = true)

theorem identity53155 : scanCanonicalize (H12AffineFastState.compose env53155 (packedSelected [3,5,7,10,11,12,14,15,18,20,23,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 54562) := by decide +kernel

theorem selectedBound53155 : packedSelected [3,5,7,10,11,12,14,15,18,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env53156 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54562,49168,35188,1024,32769,4160,21793,16,21762,8192,65,23669,5221,17664,35189,1057,40969,256,21589,46456,63068]

theorem envBound53156 : H12AffineFastState.Bounded env53156 := by
  intro p hp
  have h : env53156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53155_53156 : H12AffineEnvironment.transform 15 54562 env53155 = env53156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54562 env53155 == env53156) = true)

theorem identity53156 : scanCanonicalize (H12AffineFastState.compose env53156 (packedSelected [3,5,10,12,15,16,18,19,20,23,26] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound53156 : packedSelected [3,5,10,12,15,16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env53157 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54359,49168,34817,1024,32769,4160,21588,16,21623,8192,65,23669,5221,17525,34816,1057,40969,117,21589,46093,63068]

theorem envBound53157 : H12AffineFastState.Bounded env53157 := by
  intro p hp
  have h : env53157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53156_53157 : H12AffineEnvironment.transform 7 117 env53156 = env53157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env53156 == env53157) = true)

theorem identity53157 : scanCanonicalize (H12AffineFastState.compose env53157 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound53157 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env53158 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,32768,54359,49168,34817,1024,32769,4160,21588,16,21623,40,65,23669,5221,17525,34816,1057,32801,117,21589,37925,54900]

theorem envBound53158 : H12AffineFastState.Bounded env53158 := by
  intro p hp
  have h : env53158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53157_53158 : H12AffineEnvironment.transform 12 40 env53157 = env53158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env53157 == env53158) = true)

theorem identity53158 : scanCanonicalize (H12AffineFastState.compose env53158 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53158 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53159 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,9,16384,32768,54359,49168,34817,1024,32769,4160,21588,16,21590,9,65,23636,5188,17492,34816,1024,32768,84,21589,37892,54869]

theorem envBound53159 : H12AffineFastState.Bounded env53159 := by
  intro p hp
  have h : env53159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53158_53159 : H12AffineEnvironment.transform 4 1 env53158 = env53159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53158 == env53159) = true)

theorem identity53159 : scanCanonicalize (H12AffineFastState.compose env53159 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21588) := by decide +kernel

theorem selectedBound53159 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env53160 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,9,16384,21588,3,5188,23637,1024,21589,4160,21588,16,21590,9,65,23636,5188,17492,23636,1024,21588,84,21589,16464,513]

theorem envBound53160 : H12AffineFastState.Bounded env53160 := by
  intro p hp
  have h : env53160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53159_53160 : H12AffineEnvironment.transform 14 21588 env53159 = env53160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21588 env53159 == env53160) = true)

theorem identity53160 : scanCanonicalize (H12AffineFastState.compose env53160 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound53160 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53161 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,9,5124,80,3,5188,2129,1024,81,4160,80,16,82,9,65,2128,5188,4176,2128,1024,80,84,81,5204,513]

theorem envBound53161 : H12AffineFastState.Bounded env53161 := by
  intro p hp
  have h : env53161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53160_53161 : H12AffineEnvironment.transform 13 5124 env53160 = env53161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env53160 == env53161) = true)

theorem identity53161 : scanCanonicalize (H12AffineFastState.compose env53161 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 577) := by decide +kernel

theorem selectedBound53161 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env53162 : List Nat := [2,4,8,16,1,64,8,84,512,1024,577,4096,9,5124,80,3,5188,528,1024,81,4160,80,16,82,9,65,529,5188,4176,529,1024,80,84,81,5204,513]

theorem envBound53162 : H12AffineFastState.Bounded env53162 := by
  intro p hp
  have h : env53162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53161_53162 : H12AffineEnvironment.transform 10 577 env53161 = env53162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env53161 == env53162) = true)

theorem identity53162 : scanCanonicalize (H12AffineFastState.compose env53162 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53162 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53163 : List Nat := [2,4,8,16,1,16,8,4,512,1024,529,4096,9,5124,0,3,5140,528,1024,1,4112,0,16,2,9,17,529,5140,4096,529,1024,0,4,1,5124,513]

theorem envBound53163 : H12AffineFastState.Bounded env53163 := by
  intro p hp
  have h : env53163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53162_53163 : H12AffineEnvironment.transform 5 16 env53162 = env53163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53162 == env53163) = true)

theorem identity53163 : scanCanonicalize (H12AffineFastState.compose env53163 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound53163 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53164 : List Nat := [2,4,8,16,1,16,8,4,512,1024,529,1045,9,17,0,3,1,528,1024,1,1029,0,16,2,9,17,529,1,1045,529,1024,0,4,1,17,513]

theorem envBound53164 : H12AffineFastState.Bounded env53164 := by
  intro p hp
  have h : env53164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53163_53164 : H12AffineEnvironment.transform 11 1045 env53163 = env53164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env53163 == env53164) = true)

theorem identity53164 : scanCanonicalize (H12AffineFastState.compose env53164 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound53164 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53165 : List Nat := [2,4,8,16,1,16,8,4,512,516,529,529,9,17,0,3,1,528,516,1,513,0,16,2,9,17,529,1,529,529,516,0,4,1,17,513]

theorem envBound53165 : H12AffineFastState.Bounded env53165 := by
  intro p hp
  have h : env53165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53164_53165 : H12AffineEnvironment.transform 9 516 env53164 = env53165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env53164 == env53165) = true)

theorem identity53165 : scanCanonicalize (H12AffineFastState.compose env53165 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53165 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53166 : List Nat := [2,4,8,16,1,16,8,4,1,5,16,16,9,17,0,3,1,17,5,1,0,0,16,2,9,17,16,1,16,16,5,0,4,1,17,0]

theorem envBound53166 : H12AffineFastState.Bounded env53166 := by
  intro p hp
  have h : env53166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53165_53166 : H12AffineEnvironment.transform 8 1 env53165 = env53166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53165 == env53166) = true)

def env53167 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169264,16,21762,8193,65,215367,115014,17664,35188,119043,243003,256,98678,90202,63069]

theorem envBound53167 : H12AffineFastState.Bounded env53167 := by
  intro p hp
  have h : env53167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53153_53167 : H12AffineEnvironment.transform 6 9 env53153 = env53167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53153 == env53167) = true)

theorem identity53167 : scanCanonicalize (H12AffineFastState.compose env53167 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound53167 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53168 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10281,1024,32769,4160,62588,16,21762,8193,65,75787,115014,17664,35188,119043,119927,256,98678,90202,63069]

theorem envBound53168 : H12AffineFastState.Bounded env53168 := by
  intro p hp
  have h : env53168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53167_53168 : H12AffineEnvironment.transform 16 24908 env53167 = env53168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env53167 == env53168) = true)

theorem identity53168 : scanCanonicalize (H12AffineFastState.compose env53168 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound53168 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env53169 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,13389,10281,1024,32769,4160,41341,16,3,8193,65,75787,103495,4097,35188,99330,98678,256,98678,79195,41820]

theorem envBound53169 : H12AffineFastState.Bounded env53169 := by
  intro p hp
  have h : env53169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53168_53169 : H12AffineEnvironment.transform 13 5377 env53168 = env53169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env53168 == env53169) = true)

theorem identity53169 : scanCanonicalize (H12AffineFastState.compose env53169 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,16,18,19,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53169 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,16,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env53170 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,65536,5393,2421,1024,32769,4160,32801,16,3,349,65,67927,103495,4097,35188,99330,98678,256,98678,70663,33280]

theorem envBound53170 : H12AffineFastState.Bounded env53170 := by
  intro p hp
  have h : env53170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53169_53170 : H12AffineEnvironment.transform 12 348 env53169 = env53170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53169 == env53170) = true)

theorem identity53170 : scanCanonicalize (H12AffineFastState.compose env53170 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound53170 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53171 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,342,5393,2421,1024,32769,4160,32801,16,3,349,65,2049,38161,4097,35188,34132,32800,256,32800,5457,33280]

theorem envBound53171 : H12AffineFastState.Bounded env53171 := by
  intro p hp
  have h : env53171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53170_53171 : H12AffineEnvironment.transform 15 342 env53170 = env53171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env53170 == env53171) = true)

theorem identity53171 : scanCanonicalize (H12AffineFastState.compose env53171 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 341) := by decide +kernel

theorem selectedBound53171 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,341,342,5393,2421,1024,340,4160,372,16,3,349,65,2049,5188,4097,2081,1025,373,256,373,5457,853]

theorem envBound53172 : H12AffineFastState.Bounded env53172 := by
  intro p hp
  have h : env53172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53171_53172 : H12AffineEnvironment.transform 14 341 env53171 = env53172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 341 env53171 == env53172) = true)

theorem identity53172 : scanCanonicalize (H12AffineFastState.compose env53172 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound53172 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env53173 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,89,5124,80,83,5140,2160,1024,81,4160,113,16,3,88,65,2049,5188,4097,2081,1025,112,5,112,5204,592]

theorem envBound53173 : H12AffineFastState.Bounded env53173 := by
  intro p hp
  have h : env53173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53172_53173 : H12AffineEnvironment.transform 7 5 env53172 = env53173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env53172 == env53173) = true)

theorem identity53173 : scanCanonicalize (H12AffineFastState.compose env53173 (packedSelected [0,2,3,5,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound53173 : packedSelected [0,2,3,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env53174 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,2096,89,3124,80,83,3108,2160,1024,81,2160,113,16,3,88,65,2049,3188,2097,2081,1025,112,5,112,3172,592]

theorem envBound53174 : H12AffineFastState.Bounded env53174 := by
  intro p hp
  have h : env53174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53173_53174 : H12AffineEnvironment.transform 11 2096 env53173 = env53174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env53173 == env53174) = true)

theorem identity53174 : scanCanonicalize (H12AffineFastState.compose env53174 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound53174 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env53175 : List Nat := [2,4,8,16,32,64,9,5,512,1024,113,65,89,1093,80,83,1109,1,1024,81,1,113,16,3,88,65,112,1029,64,80,1025,112,5,112,1045,592]

theorem envBound53175 : H12AffineFastState.Bounded env53175 := by
  intro p hp
  have h : env53175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53174_53175 : H12AffineEnvironment.transform 10 113 env53174 = env53175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env53174 == env53175) = true)

theorem identity53175 : scanCanonicalize (H12AffineFastState.compose env53175 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound53175 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env53176 : List Nat := [2,4,8,16,32,48,9,5,512,1024,1,49,41,1077,32,35,1061,1,1024,33,1,1,16,3,40,49,0,1029,48,32,1025,0,5,0,1045,544]

theorem envBound53176 : H12AffineFastState.Bounded env53176 := by
  intro p hp
  have h : env53176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53175_53176 : H12AffineEnvironment.transform 5 48 env53175 = env53176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env53175 == env53176) = true)

theorem identity53176 : scanCanonicalize (H12AffineFastState.compose env53176 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53176 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53177 : List Nat := [2,4,8,16,1,17,9,5,512,1024,1,16,8,1044,1,2,1028,1,1024,0,1,1,16,3,9,16,0,1029,17,1,1025,0,5,0,1045,513]

theorem envBound53177 : H12AffineFastState.Bounded env53177 := by
  intro p hp
  have h : env53177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53176_53177 : H12AffineEnvironment.transform 4 1 env53176 = env53177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53176 == env53177) = true)

theorem identity53177 : scanCanonicalize (H12AffineFastState.compose env53177 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53177 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53178 : List Nat := [2,4,8,0,1,1,9,5,512,1024,1,0,8,1028,1,2,1028,1,1024,0,1,1,0,3,9,0,0,1029,1,1,1025,0,5,0,1029,513]

theorem envBound53178 : H12AffineFastState.Bounded env53178 := by
  intro p hp
  have h : env53178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53177_53178 : H12AffineEnvironment.transform 3 0 env53177 = env53178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53177 == env53178) = true)

theorem identity53178 : scanCanonicalize (H12AffineFastState.compose env53178 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53178 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53179 : List Nat := [2,4,8,0,1,1,9,5,1,1024,1,0,8,1028,1,2,1028,1,1024,0,1,1,0,3,9,0,0,1029,1,1,1025,0,5,0,1029,0]

end H12CloudChart1