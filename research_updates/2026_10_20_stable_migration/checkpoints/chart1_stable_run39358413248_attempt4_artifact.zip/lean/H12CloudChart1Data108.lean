import H12CloudChart1Data107

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity27365 : scanCanonicalize (H12AffineFastState.compose env27365 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound27365 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env27366 : List Nat := [2,4,8,10,32,10,9,36,512,1024,1572,545,41,1540,1541,35,11,1572,1024,1540,555,33,11,3,40,11,1573,10,545,1572,549,33,36,1572,1540,1029]

theorem envBound27366 : H12AffineFastState.Bounded env27366 := by
  intro p hp
  have h : env27366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27365_27366 : H12AffineEnvironment.transform 10 1572 env27365 = env27366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env27365 == env27366) = true)

theorem identity27366 : scanCanonicalize (H12AffineFastState.compose env27366 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27366 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27367 : List Nat := [2,4,2,0,32,0,3,36,512,1024,1572,545,35,1540,1541,35,1,1572,1024,1540,545,33,1,3,34,1,1573,0,545,1572,549,33,36,1572,1540,1029]

theorem envBound27367 : H12AffineFastState.Bounded env27367 := by
  intro p hp
  have h : env27367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27366_27367 : H12AffineEnvironment.transform 2 2 env27366 = env27367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27366 == env27367) = true)

theorem identity27367 : scanCanonicalize (H12AffineFastState.compose env27367 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27367 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env27368 : List Nat := [2,4,2,0,1,0,3,5,512,1024,1541,512,2,1540,1541,2,1,1541,1024,1540,512,0,1,3,3,1,1540,0,512,1541,516,0,5,1541,1540,1029]

theorem envBound27368 : H12AffineFastState.Bounded env27368 := by
  intro p hp
  have h : env27368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27367_27368 : H12AffineEnvironment.transform 4 1 env27367 = env27368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27367 == env27368) = true)

theorem identity27368 : scanCanonicalize (H12AffineFastState.compose env27368 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound27368 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27369 : List Nat := [2,0,2,0,1,0,3,1,512,1024,1537,512,2,1536,1537,2,1,1537,1024,1536,512,0,1,3,3,1,1536,0,512,1537,512,0,1,1537,1536,1025]

theorem envBound27369 : H12AffineFastState.Bounded env27369 := by
  intro p hp
  have h : env27369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27368_27369 : H12AffineEnvironment.transform 1 0 env27368 = env27369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env27368 == env27369) = true)

theorem identity27369 : scanCanonicalize (H12AffineFastState.compose env27369 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 515) := by decide +kernel

theorem selectedBound27369 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27370 : List Nat := [2,0,2,0,1,0,3,1,512,515,2,512,2,3,2,2,1,2,515,3,512,0,1,3,3,1,3,0,512,2,512,0,1,2,3,514]

theorem envBound27370 : H12AffineFastState.Bounded env27370 := by
  intro p hp
  have h : env27370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27369_27370 : H12AffineEnvironment.transform 9 515 env27369 = env27370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 515 env27369 == env27370) = true)

theorem identity27370 : scanCanonicalize (H12AffineFastState.compose env27370 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound27370 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27371 : List Nat := [1,0,1,0,1,0,0,1,512,512,1,512,1,0,1,1,1,1,512,0,512,0,1,0,0,1,0,0,512,1,512,0,1,1,0,513]

theorem envBound27371 : H12AffineFastState.Bounded env27371 := by
  intro p hp
  have h : env27371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27370_27371 : H12AffineEnvironment.transform 0 1 env27370 = env27371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env27370 == env27371) = true)

theorem identity27371 : scanCanonicalize (H12AffineFastState.compose env27371 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27371 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27372 : List Nat := [1,0,1,0,1,0,0,1,0,0,1,0,1,0,1,1,1,1,0,0,0,0,1,0,0,1,0,0,0,1,0,0,1,1,0,1]

theorem envBound27372 : H12AffineFastState.Bounded env27372 := by
  intro p hp
  have h : env27372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27371_27372 : H12AffineEnvironment.transform 8 0 env27371 = env27372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27371 == env27372) = true)

def env27373 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276584,272392,272441,294186,8193,65,97547,115014,17665,10281,119042,329730,256,371038,346226,63068]

theorem envBound27373 : H12AffineFastState.Bounded env27373 := by
  intro p hp
  have h : env27373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27355_27373 : H12AffineEnvironment.transform 16 49169 env27355 = env27373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env27355 == env27373) = true)

theorem identity27373 : scanCanonicalize (H12AffineFastState.compose env27373 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound27373 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27374 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,38160,262144,1024,32769,276584,272392,272441,272427,8193,65,75786,103495,4096,10281,99331,329730,256,371038,335219,41821]

theorem envBound27374 : H12AffineFastState.Bounded env27374 := by
  intro p hp
  have h : env27374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27373_27374 : H12AffineEnvironment.transform 13 5377 env27373 = env27374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env27373 == env27374) = true)

theorem identity27374 : scanCanonicalize (H12AffineFastState.compose env27374 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound27374 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env27375 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,38160,108926,1024,32769,102678,98678,98631,98645,8193,65,75786,103495,4096,10281,99331,41340,256,32,46093,41821]

theorem envBound27375 : H12AffineFastState.Bounded env27375 := by
  intro p hp
  have h : env27375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27374_27375 : H12AffineEnvironment.transform 17 108926 env27374 = env27375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env27374 == env27375) = true)

theorem identity27375 : scanCanonicalize (H12AffineFastState.compose env27375 (packedSelected [4,5,9,12,14,15,16,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 41343) := by decide +kernel

theorem selectedBound27375 : packedSelected [4,5,9,12,14,15,16,19,24] rootPS < 2^1333 := by decide +kernel

def env27376 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,41343,38160,2049,1024,32769,12393,8201,8248,8234,8193,65,35189,13624,4096,10281,9596,41340,256,32,46093,41821]

theorem envBound27376 : H12AffineFastState.Bounded env27376 := by
  intro p hp
  have h : env27376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27375_27376 : H12AffineEnvironment.transform 15 41343 env27375 = env27376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41343 env27375 == env27376) = true)

theorem identity27376 : scanCanonicalize (H12AffineFastState.compose env27376 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27376 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env27377 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,41262,38160,2049,1024,32769,12344,8201,8248,8234,8193,16,35108,13624,4096,10281,9517,41261,256,32,46093,41740]

theorem envBound27377 : H12AffineFastState.Bounded env27377 := by
  intro p hp
  have h : env27377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27376_27377 : H12AffineEnvironment.transform 5 17 env27376 = env27377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27376 == env27377) = true)

theorem identity27377 : scanCanonicalize (H12AffineFastState.compose env27377 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,19,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound27377 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,19,23] rootPS < 2^1333 := by decide +kernel

def env27378 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,41,5377,32768,33031,38160,2049,1024,32769,4113,32,17,3,40,16,35108,5393,4096,2048,1284,33028,256,32,37924,33573]

theorem envBound27378 : H12AffineFastState.Bounded env27378 := by
  intro p hp
  have h : env27378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27377_27378 : H12AffineEnvironment.transform 12 41 env27377 = env27378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env27377 == env27378) = true)

theorem identity27378 : scanCanonicalize (H12AffineFastState.compose env27378 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound27378 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27379 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,41,5377,33,294,5425,2049,1024,32,4113,32,17,3,40,16,2309,5393,4096,2048,1284,293,256,32,5125,772]

theorem envBound27379 : H12AffineFastState.Bounded env27379 := by
  intro p hp
  have h : env27379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27378_27379 : H12AffineEnvironment.transform 14 33 env27378 = env27379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env27378 == env27379) = true)

theorem identity27379 : scanCanonicalize (H12AffineFastState.compose env27379 (packedSelected [0,6,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27379 : packedSelected [0,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env27380 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,41,5125,33,34,5173,2049,1024,32,4113,32,17,3,40,16,2049,5141,4096,2048,1024,33,4,32,5125,512]

theorem envBound27380 : H12AffineFastState.Bounded env27380 := by
  intro p hp
  have h : env27380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27379_27380 : H12AffineEnvironment.transform 7 4 env27379 = env27380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27379 == env27380) = true)

theorem identity27380 : scanCanonicalize (H12AffineFastState.compose env27380 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27380 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27381 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,9,5125,1,2,5141,2049,1024,0,4113,0,17,3,8,16,2049,5141,4096,2048,1024,1,4,0,5125,512]

theorem envBound27381 : H12AffineFastState.Bounded env27381 := by
  intro p hp
  have h : env27381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27380_27381 : H12AffineEnvironment.transform 4 0 env27380 = env27381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27380 == env27381) = true)

def env27382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452649,2114883,8328,65,6385003,115150,2538873,10280,2566523,4268162,256,485830,493667,2494124]

theorem envBound27382 : H12AffineFastState.Bounded env27382 := by
  intro p hp
  have h : env27382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27242_27382 : H12AffineEnvironment.transform 22 452649 env27242 = env27382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env27242 == env27382) = true)

def env27383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452649,441659,8328,65,4691219,115150,17665,10280,119043,4268162,256,485830,493667,63188]

theorem envBound27383 : H12AffineFastState.Bounded env27383 := by
  intro p hp
  have h : env27383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27382_27383 : H12AffineEnvironment.transform 20 456824 env27382 = env27383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456824 env27382 == env27383) = true)

def env27384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452649,441659,8328,65,245139,115150,17665,10280,119043,329730,256,485830,493667,63188]

theorem envBound27384 : H12AffineFastState.Bounded env27384 := by
  intro p hp
  have h : env27384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27383_27384 : H12AffineEnvironment.transform 21 272512 env27383 = env27384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27383 == env27384) = true)

theorem identity27384 : scanCanonicalize (H12AffineFastState.compose env27384 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound27384 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,456824,272512,452649,441659,8328,65,158028,5393,17665,10280,1500,318685,256,441625,416956,63188]

theorem envBound27385 : H12AffineFastState.Bounded env27385 := by
  intro p hp
  have h : env27385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27384_27385 : H12AffineEnvironment.transform 15 54495 env27384 = env27385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env27384 == env27385) = true)

theorem identity27385 : scanCanonicalize (H12AffineFastState.compose env27385 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound27385 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env27386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,131072,262144,1024,29908,396461,272512,400636,412142,8328,65,158028,5393,17665,10280,1500,272392,256,412108,416956,513]

theorem envBound27386 : H12AffineFastState.Bounded env27386 := by
  intro p hp
  have h : env27386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27385_27386 : H12AffineEnvironment.transform 14 29909 env27385 = env27386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env27385 == env27386) = true)

theorem identity27386 : scanCanonicalize (H12AffineFastState.compose env27386 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound27386 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env27387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,131072,2421,1024,29908,132568,8693,136585,147611,8328,65,158028,5393,17665,10280,1500,8573,256,147641,153033,513]

theorem envBound27387 : H12AffineFastState.Bounded env27387 := by
  intro p hp
  have h : env27387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27386_27387 : H12AffineEnvironment.transform 17 2421 env27386 = env27387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env27386 == env27387) = true)

theorem identity27387 : scanCanonicalize (H12AffineFastState.compose env27387 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound27387 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env27388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,13389,2421,1024,29908,12693,8693,8644,29910,8328,65,23809,5393,17665,10280,1500,8573,256,29940,24964,513]

theorem envBound27388 : H12AffineFastState.Bounded env27388 := by
  intro p hp
  have h : env27388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27387_27388 : H12AffineEnvironment.transform 16 13389 env27387 = env27388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env27387 == env27388) = true)

theorem identity27388 : scanCanonicalize (H12AffineFastState.compose env27388 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound27388 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env27389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,136,8202,13389,2421,1024,137,12693,8693,8644,139,8328,65,10588,5393,12636,10280,1500,8573,256,169,5593,513]

theorem envBound27389 : H12AffineFastState.Bounded env27389 := by
  intro p hp
  have h : env27389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27388_27389 : H12AffineEnvironment.transform 13 13405 env27388 = env27389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env27388 == env27389) = true)

theorem identity27389 : scanCanonicalize (H12AffineFastState.compose env27389 (packedSelected [0,2,3,4,5,7,9,10,12,15,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound27389 : packedSelected [0,2,3,4,5,7,9,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env27390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,478,5529,2421,1024,137,4161,33,16,139,348,65,2184,5393,4232,2556,1500,169,256,169,5593,513]

theorem envBound27390 : H12AffineFastState.Bounded env27390 := by
  intro p hp
  have h : env27390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27389_27390 : H12AffineEnvironment.transform 12 468 env27389 = env27390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env27389 == env27390) = true)

def env27391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452649,441659,8328,65,245138,115150,17665,10280,119043,329731,256,485830,493667,63188]

theorem envBound27391 : H12AffineFastState.Bounded env27391 := by
  intro p hp
  have h : env27391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27383_27391 : H12AffineEnvironment.transform 21 272513 env27383 = env27391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27383 == env27391) = true)

theorem identity27391 : scanCanonicalize (H12AffineFastState.compose env27391 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound27391 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,115870,201831,120015,98781,8328,65,245138,115150,17665,10280,119043,144613,256,21792,46213,63188]

theorem envBound27392 : H12AffineFastState.Bounded env27392 := by
  intro p hp
  have h : env27392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27391_27392 : H12AffineEnvironment.transform 17 212198 env27391 = env27392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env27391 == env27392) = true)

def env27393 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212150,1024,32769,115870,201783,119967,98701,8328,17,245138,115102,17665,10280,119043,144565,256,21792,46213,63108]

theorem envBound27393 : H12AffineFastState.Bounded env27393 := by
  intro p hp
  have h : env27393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27392_27393 : H12AffineEnvironment.transform 5 16 env27392 = env27393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27392 == env27393) = true)

theorem identity27393 : scanCanonicalize (H12AffineFastState.compose env27393 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound27393 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env27394 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,5528,76078,1024,32769,115870,65967,119967,98701,8328,17,108554,115102,17665,10280,119043,8493,256,21792,46213,63108]

theorem envBound27394 : H12AffineFastState.Bounded env27394 := by
  intro p hp
  have h : env27394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27393_27394 : H12AffineEnvironment.transform 16 5528 env27393 = env27394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env27393 == env27394) = true)

theorem identity27394 : scanCanonicalize (H12AffineFastState.compose env27394 (packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound27394 : packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS < 2^1333 := by decide +kernel

def env27395 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,5528,2341,1024,32769,58517,8612,62612,41350,8328,17,34817,57749,17665,10280,61704,8493,256,21792,46213,63108]

theorem envBound27395 : H12AffineFastState.Bounded env27395 := by
  intro p hp
  have h : env27395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27394_27395 : H12AffineEnvironment.transform 15 8203 env27394 = env27395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env27394 == env27395) = true)

theorem identity27395 : scanCanonicalize (H12AffineFastState.compose env27395 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound27395 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env27396 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8203,5528,2341,1024,32769,45340,8612,41245,41350,8328,17,34817,46108,4232,10280,42113,8493,256,169,46213,41741]

theorem envBound27396 : H12AffineFastState.Bounded env27396 := by
  intro p hp
  have h : env27396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27395_27396 : H12AffineEnvironment.transform 13 5513 env27395 = env27396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env27395 == env27396) = true)

theorem identity27396 : scanCanonicalize (H12AffineFastState.compose env27396 (packedSelected [0,7,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound27396 : packedSelected [0,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env27397 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1337,5513,32768,1330,5528,2341,1024,32769,37925,1181,33828,33983,1457,17,34817,37157,4232,3345,33208,1044,256,169,37308,34356]

theorem envBound27397 : H12AffineFastState.Bounded env27397 := by
  intro p hp
  have h : env27397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27396_27397 : H12AffineEnvironment.transform 12 1337 env27396 = env27397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env27396 == env27397) = true)

theorem identity27397 : scanCanonicalize (H12AffineFastState.compose env27397 (packedSelected [2,3,5,6,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound27397 : packedSelected [2,3,5,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env27398 : List Nat := [2,4,8,16,32,16,128,256,512,53,2048,4096,268,4540,32768,263,4525,2341,53,32769,36880,168,32785,32906,388,17,34817,37157,4232,2340,33208,33,256,169,37308,33281]

theorem envBound27398 : H12AffineFastState.Bounded env27398 := by
  intro p hp
  have h : env27398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27397_27398 : H12AffineEnvironment.transform 9 53 env27397 = env27398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env27397 == env27398) = true)

theorem identity27398 : scanCanonicalize (H12AffineFastState.compose env27398 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound27398 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env27399 : List Nat := [2,4,8,16,32,16,128,256,512,53,2048,2065,268,2477,32768,263,2492,2341,53,32769,34817,168,32785,32906,388,17,34817,35124,2201,2340,33208,33,256,169,35245,33281]

theorem envBound27399 : H12AffineFastState.Bounded env27399 := by
  intro p hp
  have h : env27399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27398_27399 : H12AffineEnvironment.transform 11 2065 env27398 = env27399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env27398 == env27399) = true)

theorem identity27399 : scanCanonicalize (H12AffineFastState.compose env27399 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound27399 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env27400 : List Nat := [2,4,8,16,32,16,128,256,512,53,136,153,268,293,32768,263,308,429,53,32769,32905,168,32785,32906,388,17,32905,33212,17,428,33208,33,256,169,33061,33281]

theorem envBound27400 : H12AffineFastState.Bounded env27400 := by
  intro p hp
  have h : env27400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27399_27400 : H12AffineEnvironment.transform 10 136 env27399 = env27400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env27399 == env27400) = true)

theorem identity27400 : scanCanonicalize (H12AffineFastState.compose env27400 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27400 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env27401 : List Nat := [2,4,8,16,32,16,128,36,512,53,136,153,40,1,32768,35,16,137,53,32769,32905,168,32785,32906,160,17,32905,32920,17,136,32924,33,36,169,32769,33281]

theorem envBound27401 : H12AffineFastState.Bounded env27401 := by
  intro p hp
  have h : env27401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27400_27401 : H12AffineEnvironment.transform 7 36 env27400 = env27401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27400 == env27401) = true)

def env27402 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212151,1024,32769,115870,201782,119966,98700,8328,16,245138,115103,17665,10280,119043,144564,256,21792,46213,63109]

theorem envBound27402 : H12AffineFastState.Bounded env27402 := by
  intro p hp
  have h : env27402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27392_27402 : H12AffineEnvironment.transform 5 17 env27392 = env27402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27392 == env27402) = true)

theorem identity27402 : scanCanonicalize (H12AffineFastState.compose env27402 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 115102) := by decide +kernel

theorem selectedBound27402 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env27403 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,115102,64809,1024,32769,115870,54696,119966,98700,8328,16,31756,115103,17665,10280,119043,128298,256,21792,46213,63109]

theorem envBound27403 : H12AffineFastState.Bounded env27403 := by
  intro p hp
  have h : env27403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27402_27403 : H12AffineEnvironment.transform 16 115102 env27402 = env27403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115102 env27402 == env27403) = true)

theorem identity27403 : scanCanonicalize (H12AffineFastState.compose env27403 (packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27403 : packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env27404 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,114967,64809,1024,32769,115735,54561,119831,98565,8193,16,31756,114966,17665,10280,119043,128298,256,21792,46092,62988]

theorem envBound27404 : H12AffineFastState.Bounded env27404 := by
  intro p hp
  have h : env27404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27403_27404 : H12AffineEnvironment.transform 6 9 env27403 = env27404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27403 == env27404) = true)

theorem identity27404 : scanCanonicalize (H12AffineFastState.compose env27404 (packedSelected [0,3,4,7,10,16,19,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound27404 : packedSelected [0,3,4,7,10,16,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env27405 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,65536,79130,2340,1024,29708,77850,8492,73754,95496,8193,16,31756,79131,17665,10280,75022,65831,256,21792,16385,513]

theorem envBound27405 : H12AffineFastState.Bounded env27405 := by
  intro p hp
  have h : env27405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27404_27405 : H12AffineEnvironment.transform 14 29709 env27404 = env27405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env27404 == env27405) = true)

theorem identity27405 : scanCanonicalize (H12AffineFastState.compose env27405 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound27405 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27406 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,34,13624,2340,1024,29708,12344,8492,8248,29994,8193,16,31756,13625,17665,10280,9516,261,256,21792,16385,513]

theorem envBound27406 : H12AffineFastState.Bounded env27406 := by
  intro p hp
  have h : env27406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27405_27406 : H12AffineEnvironment.transform 15 34 env27405 = env27406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env27405 == env27406) = true)

theorem identity27406 : scanCanonicalize (H12AffineFastState.compose env27406 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound27406 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env27407 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,16384,28729,34,12556,2340,52,28728,12344,8492,8248,28958,8193,16,30776,12557,16693,10280,8472,261,256,20756,16385,513]

theorem envBound27407 : H12AffineFastState.Bounded env27407 := by
  intro p hp
  have h : env27407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27406_27407 : H12AffineEnvironment.transform 9 52 env27406 = env27407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27406 == env27407) = true)

def env27408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452649,441658,8328,65,4691218,115150,17664,10280,119042,4268162,256,485830,493667,63189]

theorem envBound27408 : H12AffineFastState.Bounded env27408 := by
  intro p hp
  have h : env27408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27382_27408 : H12AffineEnvironment.transform 20 456825 env27382 = env27408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456825 env27382 == env27408) = true)

def env27409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452649,441658,8328,65,245138,115150,17664,10280,119042,329730,256,485830,493667,63189]

theorem envBound27409 : H12AffineFastState.Bounded env27409 := by
  intro p hp
  have h : env27409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27408_27409 : H12AffineEnvironment.transform 21 272512 env27408 = env27409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27408 == env27409) = true)

theorem identity27409 : scanCanonicalize (H12AffineFastState.compose env27409 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27409 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456825,272512,452649,441658,8328,65,171416,57796,17664,10280,61704,272392,256,412108,436329,63189]

theorem envBound27410 : H12AffineFastState.Bounded env27410 := by
  intro p hp
  have h : env27410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27409_27410 : H12AffineEnvironment.transform 15 8202 env27409 = env27410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27409 == env27410) = true)

def env27411 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456825,272392,452649,441658,8192,65,171280,57676,17664,10280,61704,272392,256,411972,436329,63069]

theorem envBound27411 : H12AffineFastState.Bounded env27411 := by
  intro p hp
  have h : env27411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27410_27411 : H12AffineEnvironment.transform 6 8 env27410 = env27411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27410 == env27411) = true)

theorem identity27411 : scanCanonicalize (H12AffineFastState.compose env27411 (packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound27411 : packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env27412 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46157,262144,1024,32769,281652,272392,285796,264567,8192,65,10589,57676,17664,10280,61704,272392,256,326921,269348,63069]

theorem envBound27412 : H12AffineFastState.Bounded env27412 := by
  intro p hp
  have h : env27412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27411_27412 : H12AffineEnvironment.transform 16 46157 env27411 = env27412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env27411 == env27412) = true)

theorem identity27412 : scanCanonicalize (H12AffineFastState.compose env27412 (packedSelected [0,1,3,4,5,12,14,15,17,18,19,20,22,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound27412 : packedSelected [0,1,3,4,5,12,14,15,17,18,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env27413 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46157,32041,1024,32769,12573,21793,8525,29790,8192,65,10589,57676,17664,10280,61704,21793,256,32800,24845,63069]

theorem envBound27413 : H12AffineFastState.Bounded env27413 := by
  intro p hp
  have h : env27413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27412_27413 : H12AffineEnvironment.transform 17 32041 env27412 = env27413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env27412 == env27413) = true)

theorem identity27413 : scanCanonicalize (H12AffineFastState.compose env27413 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound27413 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env27414 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,5393,32041,1024,8541,12573,21793,8525,29790,8192,65,10589,16400,17664,10280,20564,21793,256,8572,24845,22273]

theorem envBound27414 : H12AffineFastState.Bounded env27414 := by
  intro p hp
  have h : env27414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27413_27414 : H12AffineEnvironment.transform 14 8540 env27413 = env27414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env27413 == env27414) = true)

theorem identity27414 : scanCanonicalize (H12AffineFastState.compose env27414 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound27414 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env27415 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,1296,1094,5393,22885,1024,1297,5457,21793,1281,20498,1100,65,3345,16400,17664,3172,20564,21793,256,1328,17729,22273]

theorem envBound27415 : H12AffineFastState.Bounded env27415 := by
  intro p hp
  have h : env27415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27414_27415 : H12AffineEnvironment.transform 12 1100 env27414 = env27415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env27414 == env27415) = true)

theorem identity27415 : scanCanonicalize (H12AffineFastState.compose env27415 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound27415 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27416 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3329,1100,16384,1296,1094,2064,17508,1024,1297,2128,18464,1281,19731,1100,65,3345,16400,17664,3172,19797,18464,256,1328,17729,18944]

theorem envBound27416 : H12AffineFastState.Bounded env27416 := by
  intro p hp
  have h : env27416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27415_27416 : H12AffineEnvironment.transform 11 3329 env27415 = env27416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env27415 == env27416) = true)

theorem identity27416 : scanCanonicalize (H12AffineFastState.compose env27416 (packedSelected [1,6,7,8,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound27416 : packedSelected [1,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env27417 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3108,1100,16384,1077,1094,2064,17508,1024,1076,2128,18464,1060,19510,1100,65,3124,16400,17445,3172,19568,18464,37,1045,17508,18944]

theorem envBound27417 : H12AffineFastState.Bounded env27417 := by
  intro p hp
  have h : env27417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27416_27417 : H12AffineEnvironment.transform 7 37 env27416 = env27417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env27416 == env27417) = true)

theorem identity27417 : scanCanonicalize (H12AffineFastState.compose env27417 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 2128) := by decide +kernel

theorem selectedBound27417 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env27418 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3108,1100,2128,1077,1094,2064,3124,1024,1076,2128,112,1060,1126,1100,65,3124,2112,3189,3172,1056,112,37,1045,3124,592]

theorem envBound27418 : H12AffineFastState.Bounded env27418 := by
  intro p hp
  have h : env27418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27417_27418 : H12AffineEnvironment.transform 13 2128 env27417 = env27418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2128 env27417 == env27418) = true)

theorem identity27418 : scanCanonicalize (H12AffineFastState.compose env27418 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 17) := by decide +kernel

theorem selectedBound27418 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27419 : List Nat := [2,4,8,16,32,64,8,37,512,17,2048,2101,93,2128,36,87,2064,2085,17,37,2128,112,53,119,93,65,2085,2112,2148,2165,49,112,37,4,2085,592]

theorem envBound27419 : H12AffineFastState.Bounded env27419 := by
  intro p hp
  have h : env27419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27418_27419 : H12AffineEnvironment.transform 9 17 env27418 = env27419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 17 env27418 == env27419) = true)

theorem identity27419 : scanCanonicalize (H12AffineFastState.compose env27419 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound27419 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env27420 : List Nat := [2,4,8,16,32,64,8,37,512,17,113,68,93,33,36,87,97,84,17,37,33,112,53,119,93,65,84,49,21,4,49,112,37,4,84,592]

theorem envBound27420 : H12AffineFastState.Bounded env27420 := by
  intro p hp
  have h : env27420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27419_27420 : H12AffineEnvironment.transform 10 113 env27419 = env27420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env27419 == env27420) = true)

theorem identity27420 : scanCanonicalize (H12AffineFastState.compose env27420 (packedSelected [1,2,4,6,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27420 : packedSelected [1,2,4,6,8,10] rootPS < 2^1333 := by decide +kernel

def env27421 : List Nat := [2,4,8,16,32,17,8,37,512,17,32,21,12,33,36,6,48,5,17,37,33,33,53,38,12,16,5,49,21,4,49,33,37,4,5,513]

theorem envBound27421 : H12AffineFastState.Bounded env27421 := by
  intro p hp
  have h : env27421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27420_27421 : H12AffineEnvironment.transform 5 17 env27420 = env27421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27420 == env27421) = true)

theorem identity27421 : scanCanonicalize (H12AffineFastState.compose env27421 (packedSelected [2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound27421 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env27422 : List Nat := [2,4,8,6,32,7,8,37,512,7,32,3,12,33,36,6,38,5,7,37,33,33,35,38,12,6,5,39,3,4,39,33,37,4,5,513]

theorem envBound27422 : H12AffineFastState.Bounded env27422 := by
  intro p hp
  have h : env27422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27421_27422 : H12AffineEnvironment.transform 3 6 env27421 = env27422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env27421 == env27422) = true)

def env27423 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456825,272393,452649,441658,8193,65,171281,57677,17664,10280,61704,272392,256,411973,436329,63068]

theorem envBound27423 : H12AffineFastState.Bounded env27423 := by
  intro p hp
  have h : env27423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27410_27423 : H12AffineEnvironment.transform 6 9 env27410 = env27423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27410 == env27423) = true)

theorem identity27423 : scanCanonicalize (H12AffineFastState.compose env27423 (packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 182337) := by decide +kernel

theorem selectedBound27423 : packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env27424 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,182337,1024,32769,12344,188488,8296,30075,8193,65,171281,57677,17664,10280,61704,188489,256,33028,24616,63068]

theorem envBound27424 : H12AffineFastState.Bounded env27424 := by
  intro p hp
  have h : env27424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27423_27424 : H12AffineEnvironment.transform 17 182337 env27423 = env27424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182337 env27423 == env27424) = true)

theorem identity27424 : scanCanonicalize (H12AffineFastState.compose env27424 (packedSelected [2,7,8,11,12,15,18,20,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound27424 : packedSelected [2,7,8,11,12,15,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env27425 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,8202,131072,171281,1024,32769,12344,177432,8296,8235,8193,65,171281,46109,4176,10280,42072,177433,256,33028,13688,41740]

theorem envBound27425 : H12AffineFastState.Bounded env27425 := by
  intro p hp
  have h : env27425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27424_27425 : H12AffineEnvironment.transform 13 5456 env27424 = env27425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env27424 == env27425) = true)

theorem identity27425 : scanCanonicalize (H12AffineFastState.compose env27425 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound27425 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env27426 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,293,8202,131072,138292,1024,292,12344,144445,8296,8235,8193,65,138292,13624,4176,10280,9597,144444,256,33,13688,8745]

theorem envBound27426 : H12AffineFastState.Bounded env27426 := by
  intro p hp
  have h : env27426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27425_27426 : H12AffineEnvironment.transform 14 293 env27425 = env27426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env27425 == env27426) = true)

theorem identity27426 : scanCanonicalize (H12AffineFastState.compose env27426 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound27426 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env27427 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,293,8202,13673,10589,1024,292,12344,340,8296,8235,8193,65,10589,13624,4176,10280,9597,341,256,33,13688,8745]

theorem envBound27427 : H12AffineFastState.Bounded env27427 := by
  intro p hp
  have h : env27427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27426_27427 : H12AffineEnvironment.transform 16 13673 env27426 = env27427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env27426 == env27427) = true)

theorem identity27427 : scanCanonicalize (H12AffineFastState.compose env27427 (packedSelected [0,1,2,4,6,7,8,9,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound27427 : packedSelected [0,1,2,4,6,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env27428 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1093,4096,8192,5456,293,8202,13673,9496,1024,292,12344,340,8296,8235,8193,65,9496,13624,4176,9325,9597,341,256,33,13688,8745]

theorem envBound27428 : H12AffineFastState.Bounded env27428 := by
  intro p hp
  have h : env27428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27427_27428 : H12AffineEnvironment.transform 10 1093 env27427 = env27428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env27427 == env27428) = true)

theorem identity27428 : scanCanonicalize (H12AffineFastState.compose env27428 (packedSelected [2,4,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 1304) := by decide +kernel

theorem selectedBound27428 : packedSelected [2,4,7,11] rootPS < 2^1333 := by decide +kernel

def env27429 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1093,4096,1304,5456,293,1298,4209,0,1024,292,5408,340,1392,1331,1305,65,0,4128,4176,373,101,341,256,33,4192,1841]

theorem envBound27429 : H12AffineFastState.Bounded env27429 := by
  intro p hp
  have h : env27429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27428_27429 : H12AffineEnvironment.transform 12 1304 env27428 = env27429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1304 env27428 == env27429) = true)

theorem identity27429 : scanCanonicalize (H12AffineFastState.compose env27429 (packedSelected [0,1,2,4,7,8,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound27429 : packedSelected [0,1,2,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env27430 : List Nat := [2,4,8,16,32,64,9,256,512,52,113,4096,300,4452,293,294,4209,0,52,292,4372,340,324,263,301,65,0,4128,4176,373,101,341,256,33,4192,773]

theorem envBound27430 : H12AffineFastState.Bounded env27430 := by
  intro p hp
  have h : env27430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27429_27430 : H12AffineEnvironment.transform 9 52 env27429 = env27430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27429 == env27430) = true)

theorem identity27430 : scanCanonicalize (H12AffineFastState.compose env27430 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound27430 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env27431 : List Nat := [2,4,8,16,32,64,9,256,512,52,113,17,300,373,293,294,96,0,52,292,261,340,324,263,301,65,0,49,65,373,101,341,256,33,113,773]

theorem envBound27431 : H12AffineFastState.Bounded env27431 := by
  intro p hp
  have h : env27431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27430_27431 : H12AffineEnvironment.transform 11 17 env27430 = env27431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env27430 == env27431) = true)

theorem identity27431 : scanCanonicalize (H12AffineFastState.compose env27431 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27431 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27432 : List Nat := [2,4,8,16,32,64,9,36,512,52,113,17,8,81,1,2,96,0,52,0,33,112,96,35,9,65,0,49,65,81,101,113,36,33,113,545]

theorem envBound27432 : H12AffineFastState.Bounded env27432 := by
  intro p hp
  have h : env27432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27431_27432 : H12AffineEnvironment.transform 7 36 env27431 = env27432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27431 == env27432) = true)

theorem identity27432 : scanCanonicalize (H12AffineFastState.compose env27432 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound27432 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env27433 : List Nat := [2,4,8,16,32,64,9,36,20,52,113,17,8,81,1,2,96,0,52,0,33,112,96,35,9,65,0,49,65,81,101,113,36,33,113,53]

theorem envBound27433 : H12AffineFastState.Bounded env27433 := by
  intro p hp
  have h : env27433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27432_27433 : H12AffineEnvironment.transform 8 20 env27432 = env27433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env27432 == env27433) = true)

def env27434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452649,441658,8328,65,245139,115150,17664,10280,119042,329731,256,485830,493667,63189]

theorem envBound27434 : H12AffineFastState.Bounded env27434 := by
  intro p hp
  have h : env27434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27408_27434 : H12AffineEnvironment.transform 21 272513 env27408 = env27434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27408 == env27434) = true)

theorem identity27434 : scanCanonicalize (H12AffineFastState.compose env27434 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247859) := by decide +kernel

theorem selectedBound27434 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77898,254130,73754,95497,8328,65,245139,115150,17664,10280,119042,180272,256,41461,16464,63189]

theorem envBound27435 : H12AffineFastState.Bounded env27435 := by
  intro p hp
  have h : env27435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27434_27435 : H12AffineEnvironment.transform 17 247859 env27434 = env27435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247859 env27434 == env27435) = true)

def env27436 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77850,254130,73754,95497,8328,17,245139,115102,17664,10280,119042,180272,256,41381,16384,63109]

theorem envBound27436 : H12AffineFastState.Bounded env27436 := by
  intro p hp
  have h : env27436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27435_27436 : H12AffineEnvironment.transform 5 16 env27435 = env27436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27435 == env27436) = true)

theorem identity27436 : scanCanonicalize (H12AffineFastState.compose env27436 (packedSelected [1,3,4,7,9,10,12,15,17,18,19,23,24,26,27,28,31,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound27436 : packedSelected [1,3,4,7,9,10,12,15,17,18,19,23,24,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env27437 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29708,65536,131072,212031,1024,29709,77850,201918,73754,95497,8328,17,215455,79250,17664,10280,75022,144444,256,21929,16384,649]

theorem envBound27437 : H12AffineFastState.Bounded env27437 := by
  intro p hp
  have h : env27437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27436_27437 : H12AffineEnvironment.transform 14 29708 env27436 = env27437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env27436 == env27437) = true)

theorem identity27437 : scanCanonicalize (H12AffineFastState.compose env27437 (packedSelected [1,8,12,15,16,18,19,20,23] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27437 : packedSelected [1,8,12,15,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env27438 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,65536,131072,212031,1024,29709,77850,201783,73754,95497,8193,17,215318,79131,17664,10280,75022,144444,256,21792,16384,512]

theorem envBound27438 : H12AffineFastState.Bounded env27438 := by
  intro p hp
  have h : env27438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27437_27438 : H12AffineEnvironment.transform 6 9 env27437 = env27438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27437 == env27438) = true)

theorem identity27438 : scanCanonicalize (H12AffineFastState.compose env27438 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 16692) := by decide +kernel

theorem selectedBound27438 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env27439 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,65536,16692,97547,1024,29709,77850,87299,73754,95497,8193,17,67618,79131,17664,10280,75022,29960,256,21792,16384,512]

theorem envBound27439 : H12AffineFastState.Bounded env27439 := by
  intro p hp
  have h : env27439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27438_27439 : H12AffineEnvironment.transform 16 16692 env27438 = env27439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16692 env27438 == env27439) = true)

theorem identity27439 : scanCanonicalize (H12AffineFastState.compose env27439 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27439 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env27440 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8202,16692,23809,1024,29709,4112,29961,16,21763,8193,17,10280,5393,17664,10280,1284,29960,256,21792,16384,512]

theorem envBound27440 : H12AffineFastState.Bounded env27440 := by
  intro p hp
  have h : env27440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27439_27440 : H12AffineEnvironment.transform 15 8202 env27439 = env27440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27439 == env27440) = true)

theorem identity27440 : scanCanonicalize (H12AffineFastState.compose env27440 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27440 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27441 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8192,16384,29708,8202,16433,23556,1024,29709,4112,29708,16,21510,8193,17,10280,5140,17413,10280,1025,29709,5,21541,16384,512]

theorem envBound27441 : H12AffineFastState.Bounded env27441 := by
  intro p hp
  have h : env27441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27440_27441 : H12AffineEnvironment.transform 7 5 env27440 = env27441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27440 == env27441) = true)

theorem identity27441 : scanCanonicalize (H12AffineFastState.compose env27441 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound27441 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env27442 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,40,16384,21540,34,16433,23556,1024,21541,4112,21540,16,21510,41,17,2048,5140,17413,2048,1025,21541,5,21541,16384,512]

theorem envBound27442 : H12AffineFastState.Bounded env27442 := by
  intro p hp
  have h : env27442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27441_27442 : H12AffineEnvironment.transform 12 40 env27441 = env27442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env27441 == env27442) = true)

theorem identity27442 : scanCanonicalize (H12AffineFastState.compose env27442 (packedSelected [11] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound27442 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env27443 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,40,1076,4112,34,1029,6192,1024,4113,4112,4112,16,4146,41,17,2048,5140,49,2048,1025,4113,5,4113,1076,512]

theorem envBound27443 : H12AffineFastState.Bounded env27443 := by
  intro p hp
  have h : env27443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27442_27443 : H12AffineEnvironment.transform 13 1076 env27442 = env27443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env27442 == env27443) = true)

theorem identity27443 : scanCanonicalize (H12AffineFastState.compose env27443 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound27443 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env27444 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,2096,40,1076,2080,34,1029,0,1024,2081,2080,2080,16,2050,41,17,2048,3108,49,2048,1025,2081,5,2081,1076,512]

theorem envBound27444 : H12AffineFastState.Bounded env27444 := by
  intro p hp
  have h : env27444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27443_27444 : H12AffineEnvironment.transform 11 2096 env27443 = env27444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env27443 == env27444) = true)

theorem identity27444 : scanCanonicalize (H12AffineFastState.compose env27444 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound27444 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env27445 : List Nat := [2,4,8,16,32,16,9,5,512,1024,0,48,40,1076,32,34,1029,0,1024,33,32,32,16,2,41,17,0,1060,49,0,1025,33,5,33,1076,512]

theorem envBound27445 : H12AffineFastState.Bounded env27445 := by
  intro p hp
  have h : env27445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27444_27445 : H12AffineEnvironment.transform 10 0 env27444 = env27445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env27444 == env27445) = true)

theorem identity27445 : scanCanonicalize (H12AffineFastState.compose env27445 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound27445 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env27446 : List Nat := [2,4,8,16,32,16,9,5,512,37,0,48,40,17,32,34,32,0,37,33,32,32,16,2,41,17,0,1,49,0,36,33,5,33,17,512]

theorem envBound27446 : H12AffineFastState.Bounded env27446 := by
  intro p hp
  have h : env27446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27445_27446 : H12AffineEnvironment.transform 9 37 env27445 = env27446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env27445 == env27446) = true)

theorem identity27446 : scanCanonicalize (H12AffineFastState.compose env27446 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound27446 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env27447 : List Nat := [2,4,8,16,32,16,9,5,16,37,0,48,40,17,32,34,32,0,37,33,32,32,16,2,41,17,0,1,49,0,36,33,5,33,17,16]

theorem envBound27447 : H12AffineFastState.Bounded env27447 := by
  intro p hp
  have h : env27447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27446_27447 : H12AffineEnvironment.transform 8 16 env27446 = env27447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env27446 == env27447) = true)

def env27448 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77851,254130,73754,95497,8328,16,245139,115103,17664,10280,119042,180272,256,41380,16385,63108]

theorem envBound27448 : H12AffineFastState.Bounded env27448 := by
  intro p hp
  have h : env27448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27435_27448 : H12AffineEnvironment.transform 5 17 env27435 = env27448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27435 == env27448) = true)

def env27449 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77851,254010,73754,95497,8192,16,245019,114967,17664,10280,119042,180272,256,41260,16385,62988]

theorem envBound27449 : H12AffineFastState.Bounded env27449 := by
  intro p hp
  have h : env27449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27448_27449 : H12AffineEnvironment.transform 6 8 env27448 = env27449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27448 == env27449) = true)

theorem identity27449 : scanCanonicalize (H12AffineFastState.compose env27449 (packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound27449 : packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env27450 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,89379,1024,32769,77851,95530,73754,95497,8192,16,75787,114967,17664,10280,119042,21792,256,41260,16385,62988]

theorem envBound27450 : H12AffineFastState.Bounded env27450 := by
  intro p hp
  have h : env27450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27449_27450 : H12AffineEnvironment.transform 16 38160 env27449 = env27450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env27449 == env27450) = true)

theorem identity27450 : scanCanonicalize (H12AffineFastState.compose env27450 (packedSelected [0,1,7,8,9,12,14,15,16,17,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound27450 : packedSelected [0,1,7,8,9,12,14,15,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env27451 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,65536,38160,89379,1024,32769,69910,87079,65815,87044,269,16,67846,114967,17664,2341,119042,21792,256,32801,16385,55041]

theorem envBound27451 : H12AffineFastState.Bounded env27451 := by
  intro p hp
  have h : env27451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27450_27451 : H12AffineEnvironment.transform 12 269 env27450 = env27451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env27450 == env27451) = true)

theorem identity27451 : scanCanonicalize (H12AffineFastState.compose env27451 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound27451 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env27452 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,21510,38160,2341,1024,32769,17680,33,21777,2,269,16,23808,38161,17664,2341,34052,21792,256,32801,16385,55041]

theorem envBound27452 : H12AffineFastState.Bounded env27452 := by
  intro p hp
  have h : env27452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27451_27452 : H12AffineEnvironment.transform 15 21510 env27451 = env27452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env27451 == env27452) = true)

theorem identity27452 : scanCanonicalize (H12AffineFastState.compose env27452 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound27452 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27453 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21760,21510,16400,2341,1024,21761,17680,33,21777,2,269,16,23808,16401,17664,2341,20484,21792,256,21793,16385,513]

theorem envBound27453 : H12AffineFastState.Bounded env27453 := by
  intro p hp
  have h : env27453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27452_27453 : H12AffineEnvironment.transform 14 21760 env27452 = env27453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env27452 == env27453) = true)

theorem identity27453 : scanCanonicalize (H12AffineFastState.compose env27453 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound27453 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27454 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,263,5393,2341,1024,0,4113,33,16,2,269,16,2049,5392,4097,2341,1285,33,256,32,5376,513]

theorem envBound27454 : H12AffineFastState.Bounded env27454 := by
  intro p hp
  have h : env27454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27453_27454 : H12AffineEnvironment.transform 13 5377 env27453 = env27454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env27453 == env27454) = true)

theorem identity27454 : scanCanonicalize (H12AffineFastState.compose env27454 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound27454 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27455 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,277,269,1044,1,263,1028,2341,1024,0,260,33,16,2,269,16,2049,1029,276,2341,1285,33,256,32,1045,513]

theorem envBound27455 : H12AffineFastState.Bounded env27455 := by
  intro p hp
  have h : env27455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27454_27455 : H12AffineEnvironment.transform 11 277 env27454 = env27455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env27454 == env27455) = true)

theorem identity27455 : scanCanonicalize (H12AffineFastState.compose env27455 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound27455 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27456 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,277,269,0,1,263,16,2341,20,0,260,33,16,2,269,16,2049,17,276,2341,273,33,256,32,1,513]

theorem envBound27456 : H12AffineFastState.Bounded env27456 := by
  intro p hp
  have h : env27456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27455_27456 : H12AffineEnvironment.transform 9 20 env27455 = env27456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env27455 == env27456) = true)

theorem identity27456 : scanCanonicalize (H12AffineFastState.compose env27456 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27456 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27457 : List Nat := [2,4,8,16,32,17,8,256,1,20,2048,277,269,0,1,263,16,2341,20,0,260,33,16,2,269,16,2049,17,276,2341,273,33,256,32,1,0]

theorem envBound27457 : H12AffineFastState.Bounded env27457 := by
  intro p hp
  have h : env27457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27456_27457 : H12AffineEnvironment.transform 8 1 env27456 = env27457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27456 == env27457) = true)

theorem identity27457 : scanCanonicalize (H12AffineFastState.compose env27457 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound27457 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27458 : List Nat := [2,4,8,16,17,17,8,256,1,20,2048,277,269,0,1,263,16,2324,20,0,260,16,16,2,269,16,2049,17,276,2324,273,16,256,17,1,0]

theorem envBound27458 : H12AffineFastState.Bounded env27458 := by
  intro p hp
  have h : env27458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27457_27458 : H12AffineEnvironment.transform 4 17 env27457 = env27458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env27457 == env27458) = true)

theorem identity27458 : scanCanonicalize (H12AffineFastState.compose env27458 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound27458 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27459 : List Nat := [2,4,8,16,17,17,8,256,1,20,260,277,269,0,1,263,16,16,20,0,260,16,16,2,269,16,261,17,276,16,273,16,256,17,1,0]

theorem envBound27459 : H12AffineFastState.Bounded env27459 := by
  intro p hp
  have h : env27459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27458_27459 : H12AffineEnvironment.transform 10 260 env27458 = env27459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env27458 == env27459) = true)

theorem identity27459 : scanCanonicalize (H12AffineFastState.compose env27459 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound27459 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env27460 : List Nat := [2,4,8,16,17,17,8,20,1,20,16,1,25,0,1,19,16,16,20,0,16,16,16,2,25,16,17,17,0,16,5,16,20,17,1,0]

theorem envBound27460 : H12AffineFastState.Bounded env27460 := by
  intro p hp
  have h : env27460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27459_27460 : H12AffineEnvironment.transform 7 20 env27459 = env27460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env27459 == env27460) = true)

def env27461 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77851,254011,73754,95497,8193,16,245018,114966,17664,10280,119042,180272,256,41261,16385,62989]

theorem envBound27461 : H12AffineFastState.Bounded env27461 := by
  intro p hp
  have h : env27461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27448_27461 : H12AffineEnvironment.transform 6 9 env27448 = env27461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27448 == env27461) = true)

theorem identity27461 : scanCanonicalize (H12AffineFastState.compose env27461 (packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound27461 : packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env27462 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,292,65536,131072,215319,1024,293,77851,221471,73754,95497,8193,16,212030,81970,17664,10280,86054,147732,256,8201,16385,30505]

theorem envBound27462 : H12AffineFastState.Bounded env27462 := by
  intro p hp
  have h : env27462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27461_27462 : H12AffineEnvironment.transform 14 292 env27461 = env27462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env27461 == env27462) = true)

theorem identity27462 : scanCanonicalize (H12AffineFastState.compose env27462 (packedSelected [0,1,4,7,8,12,15,18,19,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound27462 : packedSelected [0,1,4,7,8,12,15,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env27463 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13608,292,65536,131072,212031,1024,293,77851,201783,73754,65569,8193,16,212030,79130,12328,10280,75022,144444,256,8201,13609,513]

theorem envBound27463 : H12AffineFastState.Bounded env27463 := by
  intro p hp
  have h : env27463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27462_27463 : H12AffineEnvironment.transform 13 13608 env27462 = env27463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env27462 == env27463) = true)

theorem identity27463 : scanCanonicalize (H12AffineFastState.compose env27463 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound27463 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env27464 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5376,292,65536,131072,203799,1024,293,69683,201783,65586,65569,41,16,203798,70962,4096,2048,66854,136212,256,33,5377,513]

theorem envBound27464 : H12AffineFastState.Bounded env27464 := by
  intro p hp
  have h : env27464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27463_27464 : H12AffineEnvironment.transform 12 40 env27463 = env27464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env27463 == env27464) = true)

theorem identity27464 : scanCanonicalize (H12AffineFastState.compose env27464 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 69894) := by decide +kernel

theorem selectedBound27464 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27465 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5376,292,65536,69894,3345,1024,293,69683,1329,65586,65569,41,16,3344,70962,4096,2048,66854,66834,256,33,5377,513]

theorem envBound27465 : H12AffineFastState.Bounded env27465 := by
  intro p hp
  have h : env27465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27464_27465 : H12AffineEnvironment.transform 16 69894 env27464 = env27465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69894 env27464 == env27465) = true)

theorem identity27465 : scanCanonicalize (H12AffineFastState.compose env27465 (packedSelected [12,15] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound27465 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env27466 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5376,292,35,4389,3345,1024,293,4112,1329,17,2,41,16,3344,5393,4096,2048,1285,1329,256,33,5377,513]

theorem envBound27466 : H12AffineFastState.Bounded env27466 := by
  intro p hp
  have h : env27466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27465_27466 : H12AffineEnvironment.transform 15 35 env27465 = env27466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env27465 == env27466) = true)

theorem identity27466 : scanCanonicalize (H12AffineFastState.compose env27466 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound27466 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env27467 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1296,4096,40,5376,292,35,4389,1,1024,293,4112,1329,17,2,41,16,0,5393,4096,1296,1285,1329,256,33,5377,513]

theorem envBound27467 : H12AffineFastState.Bounded env27467 := by
  intro p hp
  have h : env27467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27466_27467 : H12AffineEnvironment.transform 10 1296 env27466 = env27467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env27466 == env27467) = true)

def env27468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound27468 : H12AffineFastState.Bounded env27468 := by
  intro p hp
  have h : env27468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27240_27468 : H12AffineEnvironment.transform 18 1025 env27240 = env27468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env27240 == env27468) = true)

theorem identity27468 : scanCanonicalize (H12AffineFastState.compose env27468 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 347627) := by decide +kernel

theorem selectedBound27468 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env27469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347627,4194304,8388608,16777216,8328,65,29868032,17090919,8722619,8830976,25265169,21243946,257,25463110,25454818,25207751]

theorem envBound27469 : H12AffineFastState.Bounded env27469 := by
  intro p hp
  have h : env27469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27468_27469 : H12AffineEnvironment.transform 20 347627 env27468 = env27469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 347627 env27468 == env27469) = true)

def env27470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347627,4194304,8388608,392316,8328,65,12729468,79131,8722619,8830976,8681581,4314198,257,8484154,8492190,8740795]

theorem envBound27470 : H12AffineFastState.Bounded env27470 := by
  intro p hp
  have h : env27470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27469_27470 : H12AffineEnvironment.transform 23 392316 env27469 = env27470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392316 env27469 == env27470) = true)

def env27471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,4194304,8388608,98780,8328,65,12729468,79131,8480027,8568224,8390093,4314198,257,8484154,8492190,8462875]

theorem envBound27471 : H12AffineFastState.Bounded env27471 := by
  intro p hp
  have h : env27471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27470_27471 : H12AffineEnvironment.transform 17 32160 env27470 = env27471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env27470 == env27471) = true)

def env27472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21792,8388608,98780,8328,65,8546652,79131,8480027,8568224,8390093,98678,257,8484154,8492190,8462875]

theorem envBound27472 : H12AffineFastState.Bounded env27472 := by
  intro p hp
  have h : env27472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27471_27472 : H12AffineEnvironment.transform 21 21792 env27471 = env27472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env27471 == env27472) = true)

theorem identity27472 : scanCanonicalize (H12AffineFastState.compose env27472 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound27472 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,32160,1025,32769,58517,21792,8388608,21762,8328,65,8546652,57797,8434117,8568224,8390093,21928,257,8430052,8405056,8451781]

theorem envBound27473 : H12AffineFastState.Bounded env27473 := by
  intro p hp
  have h : env27473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27472_27473 : H12AffineEnvironment.transform 15 54494 env27472 = env27473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env27472 == env27473) = true)

def env27474 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1025,32769,58397,21792,8388608,21762,8192,65,8546652,57677,8433997,8568104,8389957,21792,257,8429932,8405056,8451661]

theorem envBound27474 : H12AffineFastState.Bounded env27474 := by
  intro p hp
  have h : env27474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27473_27474 : H12AffineEnvironment.transform 6 8 env27473 = env27474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27473 == env27474) = true)

theorem identity27474 : scanCanonicalize (H12AffineFastState.compose env27474 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 147456) := by decide +kernel

theorem selectedBound27474 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env27475 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1025,32769,58397,21792,147456,21762,8192,65,10588,57677,192845,64808,148805,21792,257,188780,131136,177741]

theorem envBound27475 : H12AffineFastState.Bounded env27475 := by
  intro p hp
  have h : env27475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27474_27475 : H12AffineEnvironment.transform 22 147456 env27474 = env27475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env27474 == env27475) = true)

theorem identity27475 : scanCanonicalize (H12AffineFastState.compose env27475 (packedSelected [1,3,5,8,10,11,17,18,19,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound27475 : packedSelected [1,3,5,8,10,11,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env27476 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29962,131072,32040,1025,8541,17729,21792,147456,21762,8192,65,10588,16401,151569,23668,148805,21792,257,147504,131136,136977]

theorem envBound27476 : H12AffineFastState.Bounded env27476 := by
  intro p hp
  have h : env27476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27475_27476 : H12AffineEnvironment.transform 14 8540 env27475 = env27476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env27475 == env27476) = true)

theorem identity27476 : scanCanonicalize (H12AffineFastState.compose env27476 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound27476 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env27477 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8540,343,131072,2421,1025,8541,12572,8573,144477,8543,8192,65,10588,13388,140364,10281,143640,8573,257,144493,131136,136977]

theorem envBound27477 : H12AffineFastState.Bounded env27477 := by
  intro p hp
  have h : env27477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27476_27477 : H12AffineEnvironment.transform 13 13405 env27476 = env27477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env27476 == env27477) = true)

theorem identity27477 : scanCanonicalize (H12AffineFastState.compose env27477 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound27477 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env27478 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8540,343,5440,2421,1025,8541,12572,8573,8477,8543,8192,65,10588,13388,12556,10281,9304,8573,257,8493,5376,593]

theorem envBound27478 : H12AffineFastState.Bounded env27478 := by
  intro p hp
  have h : env27478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27477_27478 : H12AffineEnvironment.transform 16 5440 env27477 = env27478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env27477 == env27478) = true)

theorem identity27478 : scanCanonicalize (H12AffineFastState.compose env27478 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound27478 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env27479 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13405,8233,34,5173,2048,1025,8232,12393,8200,8296,8234,8192,65,10281,13388,12409,10281,9304,8200,116,8280,5237,593]

theorem envBound27479 : H12AffineFastState.Bounded env27479 := by
  intro p hp
  have h : env27479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27478_27479 : H12AffineEnvironment.transform 7 117 env27478 = env27479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env27478 == env27479) = true)

theorem identity27479 : scanCanonicalize (H12AffineFastState.compose env27479 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound27479 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env27480 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,1,34,5173,2048,1025,0,4161,32,64,2,40,65,2049,5220,4177,2049,1136,32,116,112,5237,593]

theorem envBound27480 : H12AffineFastState.Bounded env27480 := by
  intro p hp
  have h : env27480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27479_27480 : H12AffineEnvironment.transform 12 40 env27479 = env27480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env27479 == env27480) = true)

def env27481 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,58396,21792,8388608,21762,8193,65,8546652,57676,8433996,8568105,8389956,21793,257,8429933,8405056,8451660]

theorem envBound27481 : H12AffineFastState.Bounded env27481 := by
  intro p hp
  have h : env27481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27473_27481 : H12AffineEnvironment.transform 6 9 env27473 = env27481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27473 == env27481) = true)

theorem identity27481 : scanCanonicalize (H12AffineFastState.compose env27481 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 62541) := by decide +kernel

theorem selectedBound27481 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env27482 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,58396,21792,62541,21762,8193,65,171281,57676,17665,149860,61705,21793,257,21792,46093,513]

theorem envBound27482 : H12AffineFastState.Bounded env27482 := by
  intro p hp
  have h : env27482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27481_27482 : H12AffineEnvironment.transform 22 62541 env27481 = env27482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62541 env27481 == env27482) = true)

theorem identity27482 : scanCanonicalize (H12AffineFastState.compose env27482 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound27482 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env27483 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32041,1025,29789,4160,21792,17,21762,8193,65,158029,5392,17665,149860,1365,21793,257,21792,16465,513]

theorem envBound27483 : H12AffineFastState.Bounded env27483 := by
  intro p hp
  have h : env27483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27482_27483 : H12AffineEnvironment.transform 14 29788 env27482 = env27483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env27482 == env27483) = true)

theorem identity27483 : scanCanonicalize (H12AffineFastState.compose env27483 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound27483 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27484 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,5393,32041,1025,29789,4160,21792,17,21762,8193,65,31836,5392,17665,23669,1365,21793,257,21792,16465,513]

theorem envBound27484 : H12AffineFastState.Bounded env27484 := by
  intro p hp
  have h : env27484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27483_27484 : H12AffineEnvironment.transform 16 5393 env27483 = env27484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env27483 == env27484) = true)

theorem identity27484 : scanCanonicalize (H12AffineFastState.compose env27484 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound27484 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27485 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,262,5393,23588,1025,21840,4160,21792,17,21762,268,65,23889,5392,17665,23669,1365,21793,257,21792,16465,513]

theorem envBound27485 : H12AffineFastState.Bounded env27485 := by
  intro p hp
  have h : env27485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27484_27485 : H12AffineEnvironment.transform 12 269 env27484 = env27485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env27484 == env27485) = true)

theorem identity27485 : scanCanonicalize (H12AffineFastState.compose env27485 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 1540) := by decide +kernel

theorem selectedBound27485 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env27486 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,1540,4949,262,5393,6688,1025,4948,4160,4900,17,4870,268,65,6997,5392,773,6769,1365,4901,257,4900,1621,513]

theorem envBound27486 : H12AffineFastState.Bounded env27486 := by
  intro p hp
  have h : env27486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27485_27486 : H12AffineEnvironment.transform 13 1540 env27485 = env27486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1540 env27485 == env27486) = true)

theorem identity27486 : scanCanonicalize (H12AffineFastState.compose env27486 (packedSelected [0,2,6,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1856) := by decide +kernel

theorem selectedBound27486 : packedSelected [0,2,6,9,10,12] rootPS < 2^1333 := by decide +kernel

def env27487 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1856,269,1540,1045,262,593,3424,1025,1044,1792,1124,17,1094,268,65,3093,592,773,3377,1365,1125,257,1124,1621,513]

theorem envBound27487 : H12AffineFastState.Bounded env27487 := by
  intro p hp
  have h : env27487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27486_27487 : H12AffineEnvironment.transform 11 1856 env27486 = env27487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1856 env27486 == env27487) = true)

theorem identity27487 : scanCanonicalize (H12AffineFastState.compose env27487 (packedSelected [0,3,5,9,18] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound27487 : packedSelected [0,3,5,9,18] rootPS < 2^1333 := by decide +kernel

def env27488 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,805,269,609,112,262,593,2309,100,113,869,1,17,35,268,65,2160,592,773,2388,304,0,257,1,560,513]

theorem envBound27488 : H12AffineFastState.Bounded env27488 := by
  intro p hp
  have h : env27488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27487_27488 : H12AffineEnvironment.transform 9 101 env27487 = env27488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env27487 == env27488) = true)

theorem identity27488 : scanCanonicalize (H12AffineFastState.compose env27488 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 836) := by decide +kernel

theorem selectedBound27488 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env27489 : List Nat := [2,4,8,16,32,64,9,256,512,101,836,805,269,609,112,262,593,577,100,113,869,1,17,35,268,65,820,592,773,528,304,0,257,1,560,513]

theorem envBound27489 : H12AffineFastState.Bounded env27489 := by
  intro p hp
  have h : env27489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27488_27489 : H12AffineEnvironment.transform 10 836 env27488 = env27489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 836 env27488 == env27489) = true)

theorem identity27489 : scanCanonicalize (H12AffineFastState.compose env27489 (packedSelected [2,6,23] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27489 : packedSelected [2,6,23] rootPS < 2^1333 := by decide +kernel

def env27490 : List Nat := [2,4,8,16,0,64,9,256,512,69,836,773,269,577,80,262,593,577,68,81,837,1,17,3,268,65,788,592,773,528,272,0,257,1,528,513]

theorem envBound27490 : H12AffineFastState.Bounded env27490 := by
  intro p hp
  have h : env27490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27489_27490 : H12AffineEnvironment.transform 4 0 env27489 = env27490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27489 == env27490) = true)

theorem identity27490 : scanCanonicalize (H12AffineFastState.compose env27490 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound27490 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27491 : List Nat := [2,4,8,16,0,64,9,30,512,69,602,539,19,577,80,24,593,577,68,81,603,1,17,3,18,65,522,592,539,528,14,0,31,1,528,513]

theorem envBound27491 : H12AffineFastState.Bounded env27491 := by
  intro p hp
  have h : env27491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27490_27491 : H12AffineEnvironment.transform 7 30 env27490 = env27491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env27490 == env27491) = true)

theorem identity27491 : scanCanonicalize (H12AffineFastState.compose env27491 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound27491 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env27492 : List Nat := [2,4,8,16,0,64,9,30,74,69,16,81,19,11,80,24,27,11,68,81,17,1,17,3,18,65,64,26,81,90,14,0,31,1,90,75]

theorem envBound27492 : H12AffineFastState.Bounded env27492 := by
  intro p hp
  have h : env27492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27491_27492 : H12AffineEnvironment.transform 8 74 env27491 = env27492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env27491 == env27492) = true)

theorem identity27492 : scanCanonicalize (H12AffineFastState.compose env27492 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound27492 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27493 : List Nat := [0,4,8,16,0,64,9,28,72,69,16,81,17,9,80,24,25,9,68,81,17,1,17,1,16,65,64,24,81,88,12,0,29,1,88,73]

theorem envBound27493 : H12AffineFastState.Bounded env27493 := by
  intro p hp
  have h : env27493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27492_27493 : H12AffineEnvironment.transform 0 0 env27492 = env27493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env27492 == env27493) = true)

theorem identity27493 : scanCanonicalize (H12AffineFastState.compose env27493 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27493 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27494 : List Nat := [0,4,8,16,0,17,9,28,25,20,16,0,17,9,1,24,25,9,21,0,17,1,17,1,16,16,17,24,0,9,12,0,29,1,9,24]

theorem envBound27494 : H12AffineFastState.Bounded env27494 := by
  intro p hp
  have h : env27494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27493_27494 : H12AffineEnvironment.transform 5 17 env27493 = env27494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27493 == env27494) = true)

theorem identity27494 : scanCanonicalize (H12AffineFastState.compose env27494 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound27494 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27495 : List Nat := [0,0,8,16,0,17,9,24,25,16,16,0,17,9,1,24,25,9,17,0,17,1,17,1,16,16,17,24,0,9,8,0,25,1,9,24]

theorem envBound27495 : H12AffineFastState.Bounded env27495 := by
  intro p hp
  have h : env27495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27494_27495 : H12AffineEnvironment.transform 1 0 env27494 = env27495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env27494 == env27495) = true)

theorem identity27495 : scanCanonicalize (H12AffineFastState.compose env27495 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound27495 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27496 : List Nat := [0,0,0,16,0,17,1,16,17,16,16,0,17,1,1,16,17,1,17,0,17,1,17,1,16,16,17,16,0,1,0,0,17,1,1,16]

theorem envBound27496 : H12AffineFastState.Bounded env27496 := by
  intro p hp
  have h : env27496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27495_27496 : H12AffineEnvironment.transform 2 0 env27495 = env27496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env27495 == env27496) = true)

def env27497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21793,8388608,98780,8328,65,8546653,79131,8480027,8568224,8390093,98679,257,8484154,8492190,8462875]

theorem envBound27497 : H12AffineFastState.Bounded env27497 := by
  intro p hp
  have h : env27497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27471_27497 : H12AffineEnvironment.transform 21 21793 env27471 = env27497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env27471 == env27497) = true)

theorem identity27497 : scanCanonicalize (H12AffineFastState.compose env27497 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120015) := by decide +kernel

theorem selectedBound27497 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21793,120015,98780,8328,65,245138,79131,45524,223599,119042,98679,257,41461,16465,63188]

theorem envBound27498 : H12AffineFastState.Bounded env27498 := by
  intro p hp
  have h : env27498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27497_27498 : H12AffineEnvironment.transform 22 120015 env27497 = env27498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120015 env27497 == env27498) = true)

def env27499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10400,1025,32769,77899,33,98767,98780,8328,65,245138,79131,45524,212079,99330,98679,257,41461,5457,41940]

theorem envBound27499 : H12AffineFastState.Bounded env27499 := by
  intro p hp
  have h : env27499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27498_27499 : H12AffineEnvironment.transform 13 5376 env27498 = env27499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27498 == env27499) = true)

theorem identity27499 : scanCanonicalize (H12AffineFastState.compose env27499 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound27499 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env27500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,46276,10400,1025,32769,77899,33,98767,98780,8328,65,67926,79131,45524,100523,99330,98679,257,41461,5457,41940]

theorem envBound27500 : H12AffineFastState.Bounded env27500 := by
  intro p hp
  have h : env27500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27499_27500 : H12AffineEnvironment.transform 16 46276 env27499 = env27500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env27499 == env27500) = true)

theorem identity27500 : scanCanonicalize (H12AffineFastState.compose env27500 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound27500 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env27501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8203,46276,10400,1025,32769,4160,33,41412,41431,8328,65,10589,5392,45524,43168,41993,41340,257,41461,5457,41940]

theorem envBound27501 : H12AffineFastState.Bounded env27501 := by
  intro p hp
  have h : env27501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27500_27501 : H12AffineEnvironment.transform 15 8203 env27500 = env27501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env27500 == env27501) = true)

theorem identity27501 : scanCanonicalize (H12AffineFastState.compose env27501 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound27501 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,5393,10400,1025,8660,4160,33,17,2,8328,65,10589,5392,4097,2421,1500,169,257,32,5457,513]

theorem envBound27502 : H12AffineFastState.Bounded env27502 := by
  intro p hp
  have h : env27502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27501_27502 : H12AffineEnvironment.transform 14 8661 env27501 = env27502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env27501 == env27502) = true)

theorem identity27502 : scanCanonicalize (H12AffineFastState.compose env27502 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27502 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,342,5393,2557,1025,137,4160,33,17,2,469,65,2048,5392,4097,2421,1500,169,257,32,5457,513]

theorem envBound27503 : H12AffineFastState.Bounded env27503 := by
  intro p hp
  have h : env27503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27502_27503 : H12AffineEnvironment.transform 12 349 env27502 = env27503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27502 == env27503) = true)

theorem identity27503 : scanCanonicalize (H12AffineFastState.compose env27503 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(8+1) ^^^ 201) := by decide +kernel

theorem selectedBound27503 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env27504 : List Nat := [2,4,8,16,32,64,128,256,201,1024,2048,4096,349,5376,136,342,5393,2557,1025,137,4160,33,17,2,469,65,2048,5392,4097,2421,1500,169,257,32,5457,200]

theorem envBound27504 : H12AffineFastState.Bounded env27504 := by
  intro p hp
  have h : env27504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27503_27504 : H12AffineEnvironment.transform 8 201 env27503 = env27504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 201 env27503 == env27504) = true)

theorem identity27504 : scanCanonicalize (H12AffineFastState.compose env27504 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27504 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env27505 : List Nat := [2,4,8,16,32,64,128,256,201,272,2048,4096,349,4112,136,342,4097,2557,273,137,4160,33,17,2,469,65,2048,4096,4097,2421,204,169,257,32,4161,200]

theorem envBound27505 : H12AffineFastState.Bounded env27505 := by
  intro p hp
  have h : env27505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27504_27505 : H12AffineEnvironment.transform 9 272 env27504 = env27505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27504 == env27505) = true)

theorem identity27505 : scanCanonicalize (H12AffineFastState.compose env27505 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 237) := by decide +kernel

theorem selectedBound27505 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27506 : List Nat := [2,4,8,16,32,64,128,237,201,253,2048,4096,176,4112,136,187,4097,2064,252,137,4160,33,17,2,56,65,2048,4096,4097,2200,204,169,236,32,4161,200]

theorem envBound27506 : H12AffineFastState.Bounded env27506 := by
  intro p hp
  have h : env27506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27505_27506 : H12AffineEnvironment.transform 7 237 env27505 = env27506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 237 env27505 == env27506) = true)

theorem identity27506 : scanCanonicalize (H12AffineFastState.compose env27506 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27506 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27507 : List Nat := [2,4,8,16,32,64,8,101,65,117,2048,4096,56,4112,0,51,4097,2064,116,1,4160,33,17,2,56,65,2048,4096,4097,2064,68,33,100,32,4161,64]

theorem envBound27507 : H12AffineFastState.Bounded env27507 := by
  intro p hp
  have h : env27507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27506_27507 : H12AffineEnvironment.transform 6 8 env27506 = env27507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27506 == env27507) = true)

theorem identity27507 : scanCanonicalize (H12AffineFastState.compose env27507 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27507 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27508 : List Nat := [2,4,8,16,32,17,8,52,16,36,2048,4096,56,4112,0,51,4097,2064,37,1,4113,33,17,2,56,16,2048,4096,4097,2064,21,33,53,32,4112,17]

theorem envBound27508 : H12AffineFastState.Bounded env27508 := by
  intro p hp
  have h : env27508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27507_27508 : H12AffineEnvironment.transform 5 17 env27507 = env27508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27507 == env27508) = true)

theorem identity27508 : scanCanonicalize (H12AffineFastState.compose env27508 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound27508 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27509 : List Nat := [2,4,8,10,32,11,8,46,10,36,2048,4096,34,4106,0,41,4097,2058,37,1,4107,33,11,2,34,10,2048,4096,4097,2058,15,33,47,32,4106,11]

theorem envBound27509 : H12AffineFastState.Bounded env27509 := by
  intro p hp
  have h : env27509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27508_27509 : H12AffineEnvironment.transform 3 10 env27508 = env27509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env27508 == env27509) = true)

theorem identity27509 : scanCanonicalize (H12AffineFastState.compose env27509 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27509 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27510 : List Nat := [2,4,2,0,32,1,2,36,0,36,2048,4096,34,4096,0,35,4097,2048,37,1,4097,33,1,2,34,0,2048,4096,4097,2048,5,33,37,32,4096,1]

theorem envBound27510 : H12AffineFastState.Bounded env27510 := by
  intro p hp
  have h : env27510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27509_27510 : H12AffineEnvironment.transform 2 2 env27509 = env27510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27509 == env27510) = true)

theorem identity27510 : scanCanonicalize (H12AffineFastState.compose env27510 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound27510 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27511 : List Nat := [2,4,2,0,32,1,2,36,0,36,0,4096,34,4096,0,35,4097,0,37,1,4097,33,1,2,34,0,0,4096,4097,0,5,33,37,32,4096,1]

theorem envBound27511 : H12AffineFastState.Bounded env27511 := by
  intro p hp
  have h : env27511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27510_27511 : H12AffineEnvironment.transform 10 0 env27510 = env27511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env27510 == env27511) = true)

def env27512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10401,1025,32769,77899,32,98766,98780,8328,65,245138,79131,45524,212078,99331,98679,257,41461,5456,41941]

theorem envBound27512 : H12AffineFastState.Bounded env27512 := by
  intro p hp
  have h : env27512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27498_27512 : H12AffineEnvironment.transform 13 5377 env27498 = env27512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env27498 == env27512) = true)

theorem identity27512 : scanCanonicalize (H12AffineFastState.compose env27512 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27512 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env27513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1025,32769,77899,32,98631,98645,8193,65,245019,79131,45405,212078,99331,98679,257,41340,5456,41820]

theorem envBound27513 : H12AffineFastState.Bounded env27513 := by
  intro p hp
  have h : env27513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27512_27513 : H12AffineEnvironment.transform 6 9 env27512 = env27513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27512 == env27513) = true)

theorem identity27513 : scanCanonicalize (H12AffineFastState.compose env27513 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound27513 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10280,1025,8540,77899,32,73754,73736,8193,65,203846,79131,4096,212078,75102,73770,257,33,5456,513]

theorem envBound27514 : H12AffineFastState.Bounded env27514 := by
  intro p hp
  have h : env27514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27513_27514 : H12AffineEnvironment.transform 14 8541 env27513 = env27514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env27513 == env27514) = true)

theorem identity27514 : scanCanonicalize (H12AffineFastState.compose env27514 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27514 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,65536,131072,2421,1025,1,69910,32,65863,65877,348,65,203846,70726,4096,204083,66563,65911,257,33,5456,513]

theorem envBound27515 : H12AffineFastState.Bounded env27515 := by
  intro p hp
  have h : env27515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27514_27515 : H12AffineEnvironment.transform 12 349 env27514 = env27515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27514 == env27515) = true)

theorem identity27515 : scanCanonicalize (H12AffineFastState.compose env27515 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound27515 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,65536,70726,2421,1025,1,69910,32,65863,65877,348,65,2048,70726,4096,2421,66563,65911,257,33,5456,513]

theorem envBound27516 : H12AffineFastState.Bounded env27516 := by
  intro p hp
  have h : env27516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27515_27516 : H12AffineEnvironment.transform 16 70726 env27515 = env27516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env27515 == env27516) = true)

theorem identity27516 : scanCanonicalize (H12AffineFastState.compose env27516 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound27516 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,5392,2421,1025,1,4160,32,17,3,348,65,2048,5392,4096,2421,1365,33,257,33,5456,513]

theorem envBound27517 : H12AffineFastState.Bounded env27517 := by
  intro p hp
  have h : env27517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27516_27517 : H12AffineEnvironment.transform 15 342 env27516 = env27517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env27516 == env27517) = true)

theorem identity27517 : scanCanonicalize (H12AffineFastState.compose env27517 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound27517 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27518 : List Nat := [2,4,8,16,32,64,9,256,512,785,2048,4096,349,4624,0,342,4609,2421,784,1,4160,32,17,3,348,65,2048,4609,4096,2421,580,33,257,33,4673,513]

theorem envBound27518 : H12AffineFastState.Bounded env27518 := by
  intro p hp
  have h : env27518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27517_27518 : H12AffineEnvironment.transform 9 785 env27517 = env27518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env27517 == env27518) = true)

theorem identity27518 : scanCanonicalize (H12AffineFastState.compose env27518 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 884) := by decide +kernel

theorem selectedBound27518 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27519 : List Nat := [2,4,8,16,32,64,9,256,512,785,2048,884,349,356,0,342,373,2421,784,1,820,32,17,3,348,65,2048,373,884,2421,580,33,257,33,309,513]

theorem envBound27519 : H12AffineFastState.Bounded env27519 := by
  intro p hp
  have h : env27519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27518_27519 : H12AffineEnvironment.transform 11 884 env27518 = env27519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 884 env27518 == env27519) = true)

theorem identity27519 : scanCanonicalize (H12AffineFastState.compose env27519 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound27519 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env27520 : List Nat := [2,4,8,16,32,64,9,116,512,613,2048,512,41,16,0,34,1,2049,612,1,576,32,17,3,40,65,2048,1,512,2049,580,33,117,33,65,513]

theorem envBound27520 : H12AffineFastState.Bounded env27520 := by
  intro p hp
  have h : env27520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27519_27520 : H12AffineEnvironment.transform 7 116 env27519 = env27520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env27519 == env27520) = true)

theorem identity27520 : scanCanonicalize (H12AffineFastState.compose env27520 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound27520 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env27521 : List Nat := [2,4,8,16,32,64,9,116,512,613,81,512,41,16,0,34,1,80,612,1,576,32,17,3,40,65,81,1,512,80,580,33,117,33,65,513]

theorem envBound27521 : H12AffineFastState.Bounded env27521 := by
  intro p hp
  have h : env27521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27520_27521 : H12AffineEnvironment.transform 10 81 env27520 = env27521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env27520 == env27521) = true)

theorem identity27521 : scanCanonicalize (H12AffineFastState.compose env27521 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound27521 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27522 : List Nat := [2,4,8,16,32,64,9,116,80,53,81,80,41,16,0,34,1,80,52,1,16,32,17,3,40,65,81,1,80,80,20,33,117,33,65,81]

theorem envBound27522 : H12AffineFastState.Bounded env27522 := by
  intro p hp
  have h : env27522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27521_27522 : H12AffineEnvironment.transform 8 80 env27521 = env27522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env27521 == env27522) = true)

theorem identity27522 : scanCanonicalize (H12AffineFastState.compose env27522 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27522 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27523 : List Nat := [2,4,8,1,32,64,9,101,65,36,64,65,41,1,0,34,1,65,37,1,1,32,0,3,40,65,64,1,65,65,5,33,100,33,65,64]

theorem envBound27523 : H12AffineFastState.Bounded env27523 := by
  intro p hp
  have h : env27523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27522_27523 : H12AffineEnvironment.transform 3 1 env27522 = env27523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27522 == env27523) = true)

def env27524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,4194304,8388608,98781,8328,65,12729468,79131,8480026,8568225,8390092,4314198,257,8484154,8492190,8462874]

theorem envBound27524 : H12AffineFastState.Bounded env27524 := by
  intro p hp
  have h : env27524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27470_27524 : H12AffineEnvironment.transform 17 32161 env27470 = env27524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env27470 == env27524) = true)

def env27525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21792,8388608,98781,8328,65,8546652,79131,8480026,8568225,8390092,98678,257,8484154,8492190,8462874]

theorem envBound27525 : H12AffineFastState.Bounded env27525 := by
  intro p hp
  have h : env27525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27524_27525 : H12AffineEnvironment.transform 21 21792 env27524 = env27525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env27524 == env27525) = true)

theorem identity27525 : scanCanonicalize (H12AffineFastState.compose env27525 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound27525 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21792,73755,98781,8328,65,215367,79131,17665,236986,75223,98678,257,21793,46213,513]

theorem envBound27526 : H12AffineFastState.Bounded env27526 := by
  intro p hp
  have h : env27526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27525_27526 : H12AffineEnvironment.transform 22 73755 env27525 = env27526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env27525 == env27526) = true)

def env27527 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,21792,73755,98645,8192,65,215367,79131,17665,236850,75103,98678,257,21793,46093,513]

theorem envBound27527 : H12AffineFastState.Bounded env27527 := by
  intro p hp
  have h : env27527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27526_27527 : H12AffineEnvironment.transform 6 8 env27526 = env27527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27526 == env27527) = true)

theorem identity27527 : scanCanonicalize (H12AffineFastState.compose env27527 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 91403) := by decide +kernel

theorem selectedBound27527 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env27528 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,91403,32041,1025,32769,77898,21792,73755,98645,8192,65,11340,79131,17665,63545,75103,98678,257,21793,46093,513]

theorem envBound27528 : H12AffineFastState.Bounded env27528 := by
  intro p hp
  have h : env27528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27527_27528 : H12AffineEnvironment.transform 16 91403 env27527 = env27528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 91403 env27527 == env27528) = true)

theorem identity27528 : scanCanonicalize (H12AffineFastState.compose env27528 (packedSelected [1,3,4,5,8,10,16,17,19,22] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound27528 : packedSelected [1,3,4,5,8,10,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env27529 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,32768,65536,90138,30776,272,32769,77898,20529,73755,98645,8192,65,10589,77834,16400,63545,73806,98678,257,20528,45340,513]

theorem envBound27529 : H12AffineFastState.Bounded env27529 := by
  intro p hp
  have h : env27529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27528_27529 : H12AffineEnvironment.transform 9 273 env27528 = env27529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env27528 == env27529) = true)

theorem identity27529 : scanCanonicalize (H12AffineFastState.compose env27529 (packedSelected [3,5,10,12,38] rootPS)) = affineNative (2^(15+1) ^^^ 53298) := by decide +kernel

theorem selectedBound27529 : packedSelected [3,5,10,12,38] rootPS < 2^1333 := by decide +kernel

def env27530 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,32768,53298,45096,30776,272,32769,57464,20529,61481,20839,8192,65,10589,57400,16400,63545,61564,20804,257,20528,45340,513]

theorem envBound27530 : H12AffineFastState.Bounded env27530 := by
  intro p hp
  have h : env27530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27529_27530 : H12AffineEnvironment.transform 15 53298 env27529 = env27530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53298 env27529 == env27530) = true)

theorem identity27530 : scanCanonicalize (H12AffineFastState.compose env27530 (packedSelected [3,4,5,7,9,10,17,23,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound27530 : packedSelected [3,4,5,7,9,10,17,23,27,32] rootPS < 2^1333 := by decide +kernel

def env27531 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,12572,32768,41262,45096,2340,272,32769,37220,8493,33077,8315,8192,65,10589,37156,12556,35109,33120,8280,257,8492,45340,513]

theorem envBound27531 : H12AffineFastState.Bounded env27531 := by
  intro p hp
  have h : env27531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27530_27531 : H12AffineEnvironment.transform 13 12572 env27530 = env27531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env27530 == env27531) = true)

theorem identity27531 : scanCanonicalize (H12AffineFastState.compose env27531 (packedSelected [2,3,5,6,10,11,12,15,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27531 : packedSelected [2,3,5,6,10,11,12,15,23] rootPS < 2^1333 := by decide +kernel

def env27532 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,268,4112,32768,32802,37156,2340,272,32769,37220,33,33077,375,268,65,2129,37156,4096,35109,33120,340,257,32,36880,513]

theorem envBound27532 : H12AffineFastState.Bounded env27532 := by
  intro p hp
  have h : env27532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27531_27532 : H12AffineEnvironment.transform 12 268 env27531 = env27532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27531 == env27532) = true)

theorem identity27532 : scanCanonicalize (H12AffineFastState.compose env27532 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 6209) := by decide +kernel

theorem selectedBound27532 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env27533 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,268,4112,6209,6243,2405,2340,272,6208,2341,33,6516,375,268,65,2129,2405,4096,4452,6433,340,257,32,2129,513]

theorem envBound27533 : H12AffineFastState.Bounded env27533 := by
  intro p hp
  have h : env27533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27532_27533 : H12AffineEnvironment.transform 14 6209 env27532 = env27533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6209 env27532 == env27533) = true)

theorem identity27533 : scanCanonicalize (H12AffineFastState.compose env27533 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27533 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env27534 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,4096,40,4112,6209,6243,2113,2048,52,6208,2049,33,6224,83,40,65,2129,2113,4096,4160,6149,112,37,32,2129,513]

theorem envBound27534 : H12AffineFastState.Bounded env27534 := by
  intro p hp
  have h : env27534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27533_27534 : H12AffineEnvironment.transform 7 36 env27533 = env27534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27533 == env27534) = true)

theorem identity27534 : scanCanonicalize (H12AffineFastState.compose env27534 (packedSelected [4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound27534 : packedSelected [4,5,6] rootPS < 2^1333 := by decide +kernel

def env27535 : List Nat := [2,4,8,16,32,64,8,36,512,53,560,4096,40,4112,4721,4691,625,560,52,4720,561,33,4704,83,40,65,609,625,4096,4160,4661,112,37,32,609,513]

theorem envBound27535 : H12AffineFastState.Bounded env27535 := by
  intro p hp
  have h : env27535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27534_27535 : H12AffineEnvironment.transform 10 560 env27534 = env27535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env27534 == env27535) = true)

theorem identity27535 : scanCanonicalize (H12AffineFastState.compose env27535 (packedSelected [3,7] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound27535 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env27536 : List Nat := [2,4,8,16,32,64,8,36,512,53,560,545,40,561,80,114,625,560,52,81,561,33,65,83,40,65,609,625,545,609,20,112,37,32,609,513]

theorem envBound27536 : H12AffineFastState.Bounded env27536 := by
  intro p hp
  have h : env27536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27535_27536 : H12AffineEnvironment.transform 11 545 env27535 = env27536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env27535 == env27536) = true)

theorem identity27536 : scanCanonicalize (H12AffineFastState.compose env27536 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27536 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env27537 : List Nat := [2,4,8,16,32,64,8,36,0,53,48,33,40,49,80,114,113,48,52,81,49,33,65,83,40,65,97,113,33,97,20,112,37,32,97,1]

theorem envBound27537 : H12AffineFastState.Bounded env27537 := by
  intro p hp
  have h : env27537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27536_27537 : H12AffineEnvironment.transform 8 0 env27536 = env27537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27536 == env27537) = true)

theorem identity27537 : scanCanonicalize (H12AffineFastState.compose env27537 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound27537 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27538 : List Nat := [2,4,8,16,32,32,8,36,0,53,48,33,40,49,48,18,17,48,52,49,49,33,33,51,40,33,1,17,33,1,20,16,37,32,1,1]

theorem envBound27538 : H12AffineFastState.Bounded env27538 := by
  intro p hp
  have h : env27538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27537_27538 : H12AffineEnvironment.transform 5 32 env27537 = env27538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env27537 == env27538) = true)

theorem identity27538 : scanCanonicalize (H12AffineFastState.compose env27538 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound27538 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27539 : List Nat := [2,4,8,16,16,16,8,20,0,5,0,17,24,1,0,18,17,0,4,1,1,17,17,3,24,17,1,17,17,1,20,16,21,16,1,1]

theorem envBound27539 : H12AffineFastState.Bounded env27539 := by
  intro p hp
  have h : env27539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27538_27539 : H12AffineEnvironment.transform 4 16 env27538 = env27539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env27538 == env27539) = true)

theorem identity27539 : scanCanonicalize (H12AffineFastState.compose env27539 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27539 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27540 : List Nat := [2,4,8,1,1,1,8,5,0,5,0,0,9,1,0,3,0,0,4,1,1,0,0,3,9,0,1,0,0,1,5,1,4,1,1,1]

theorem envBound27540 : H12AffineFastState.Bounded env27540 := by
  intro p hp
  have h : env27540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27539_27540 : H12AffineEnvironment.transform 3 1 env27539 = env27540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27539 == env27540) = true)

def env27541 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77898,21792,73755,98644,8193,65,215367,79131,17665,236851,75102,98678,257,21793,46092,513]

theorem envBound27541 : H12AffineFastState.Bounded env27541 := by
  intro p hp
  have h : env27541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27526_27541 : H12AffineEnvironment.transform 6 9 env27526 = env27541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27526 == env27541) = true)

theorem identity27541 : scanCanonicalize (H12AffineFastState.compose env27541 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound27541 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env27542 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1025,32769,58397,21792,62540,21763,8193,65,171280,57676,17665,149860,61705,21793,257,21793,46092,513]

theorem envBound27542 : H12AffineFastState.Bounded env27542 := by
  intro p hp
  have h : env27542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27541_27542 : H12AffineEnvironment.transform 15 54359 env27541 = env27542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env27541 == env27542) = true)

theorem identity27542 : scanCanonicalize (H12AffineFastState.compose env27542 (packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound27542 : packedSelected [1,2,3,4,5,6,7,8,9,10,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env27543 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,46109,32040,1025,32769,58397,21792,62540,21763,8193,65,10509,57676,17665,64889,61705,21793,257,21793,46092,513]

theorem envBound27543 : H12AffineFastState.Bounded env27543 := by
  intro p hp
  have h : env27543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27542_27543 : H12AffineEnvironment.transform 16 46109 env27542 = env27543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env27542 == env27543) = true)

theorem identity27543 : scanCanonicalize (H12AffineFastState.compose env27543 (packedSelected [0,2,4,6,7,9,14,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound27543 : packedSelected [0,2,4,6,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env27544 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,8282,16400,32040,1025,29708,4112,21792,65,21763,8193,65,10509,5441,17665,2420,1284,21793,257,21793,16385,513]

theorem envBound27544 : H12AffineFastState.Bounded env27544 := by
  intro p hp
  have h : env27544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27543_27544 : H12AffineEnvironment.transform 14 29709 env27543 = env27544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env27543 == env27544) = true)

theorem identity27544 : scanCanonicalize (H12AffineFastState.compose env27544 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27544 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27545 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8202,16400,32040,1025,29708,4112,21792,17,21763,8193,17,10509,5393,17665,2340,1284,21793,257,21793,16385,513]

theorem envBound27545 : H12AffineFastState.Bounded env27545 := by
  intro p hp
  have h : env27545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27544_27545 : H12AffineEnvironment.transform 5 16 env27544 = env27545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27544 == env27545) = true)

theorem identity27545 : scanCanonicalize (H12AffineFastState.compose env27545 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound27545 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env27546 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,300,16384,21793,294,16400,23556,1025,21792,4112,21792,17,21763,301,17,2081,5393,17665,2340,1284,21793,257,21793,16385,513]

theorem envBound27546 : H12AffineFastState.Bounded env27546 := by
  intro p hp
  have h : env27546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27545_27546 : H12AffineEnvironment.transform 12 300 env27545 = env27546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env27545 == env27546) = true)

theorem identity27546 : scanCanonicalize (H12AffineFastState.compose env27546 (packedSelected [0,2,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound27546 : packedSelected [0,2,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env27547 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,9,16384,21508,3,16400,23556,1025,21509,4112,21509,17,21542,8,17,2081,5172,17444,2049,1057,21508,36,21508,16385,513]

theorem envBound27547 : H12AffineFastState.Bounded env27547 := by
  intro p hp
  have h : env27547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27546_27547 : H12AffineEnvironment.transform 7 37 env27546 = env27547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env27546 == env27547) = true)

def env27548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21793,8388608,98781,8328,65,8546653,79131,8480026,8568225,8390092,98679,257,8484154,8492190,8462874]

theorem envBound27548 : H12AffineFastState.Bounded env27548 := by
  intro p hp
  have h : env27548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27524_27548 : H12AffineEnvironment.transform 21 21793 env27524 = env27548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env27524 == env27548) = true)

theorem identity27548 : scanCanonicalize (H12AffineFastState.compose env27548 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27548 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4160,21793,8388608,41431,8328,65,8546653,5393,8406288,8568225,8390092,41341,257,8410416,8434836,8389136]

theorem envBound27549 : H12AffineFastState.Bounded env27549 := by
  intro p hp
  have h : env27549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27548_27549 : H12AffineEnvironment.transform 15 8202 env27548 = env27549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27548 == env27549) = true)

def env27550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4160,21793,96,41431,8328,65,158013,5393,17776,179649,1452,41341,257,21840,46324,624]

theorem envBound27550 : H12AffineFastState.Bounded env27550 := by
  intro p hp
  have h : env27550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27549_27550 : H12AffineEnvironment.transform 22 96 env27549 = env27550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 96 env27549 == env27550) = true)

theorem identity27550 : scanCanonicalize (H12AffineFastState.compose env27550 (packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound27550 : packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8202,131072,2421,1025,32769,4160,8693,96,41431,8328,65,138729,5393,12708,179649,1452,41341,257,8580,46324,624]

theorem envBound27551 : H12AffineFastState.Bounded env27551 := by
  intro p hp
  have h : env27551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27550_27551 : H12AffineEnvironment.transform 13 13524 env27550 = env27551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env27550 == env27551) = true)

theorem identity27551 : scanCanonicalize (H12AffineFastState.compose env27551 (packedSelected [0,1,2,4,6,7,11,12,15,16,17,18,19,20,22,23,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 46188) := by decide +kernel

theorem selectedBound27551 : packedSelected [0,1,2,4,6,7,11,12,15,16,17,18,19,20,22,23,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env27552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8202,46188,2421,1025,32769,4160,8693,96,41431,8328,65,43397,5393,12708,2477,1452,41341,257,8580,46324,624]

theorem envBound27552 : H12AffineFastState.Bounded env27552 := by
  intro p hp
  have h : env27552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27551_27552 : H12AffineEnvironment.transform 16 46188 env27551 = env27552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46188 env27551 == env27552) = true)

theorem identity27552 : scanCanonicalize (H12AffineFastState.compose env27552 (packedSelected [0,4,7,16,18,19,20,22,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound27552 : packedSelected [0,4,7,16,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env27553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,8540,8202,5424,2421,1025,8541,4160,8693,96,139,8328,65,2265,5393,12708,2477,1452,33,257,8580,5544,624]

theorem envBound27553 : H12AffineFastState.Bounded env27553 := by
  intro p hp
  have h : env27553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27552_27553 : H12AffineEnvironment.transform 14 8540 env27552 = env27553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env27552 == env27553) = true)

theorem identity27553 : scanCanonicalize (H12AffineFastState.compose env27553 (packedSelected [0,1,4,6,7,8,9,10,11,14,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 6216) := by decide +kernel

theorem selectedBound27553 : packedSelected [0,1,4,6,7,8,9,10,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env27554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,6216,3228,6420,6210,5424,2421,1025,6421,4160,6589,96,139,6336,65,2265,5393,2540,2477,1452,33,257,6604,5544,624]

theorem envBound27554 : H12AffineFastState.Bounded env27554 := by
  intro p hp
  have h : env27554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27553_27554 : H12AffineEnvironment.transform 12 6216 env27553 = env27554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6216 env27553 == env27554) = true)

theorem identity27554 : scanCanonicalize (H12AffineFastState.compose env27554 (packedSelected [0,2,4,6,7,22] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound27554 : packedSelected [0,2,4,6,7,22] rootPS < 2^1333 := by decide +kernel

def env27555 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,4096,6200,3228,6420,6194,5424,2309,1025,6421,4144,6589,16,139,6320,49,2217,5393,2460,2477,1452,33,257,6588,5544,512]

theorem envBound27555 : H12AffineFastState.Bounded env27555 := by
  intro p hp
  have h : env27555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27554_27555 : H12AffineEnvironment.transform 5 48 env27554 = env27555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env27554 == env27555) = true)

theorem identity27555 : scanCanonicalize (H12AffineFastState.compose env27555 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound27555 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env27556 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,2324,300,3228,0,294,3108,2309,1025,1,2340,169,16,139,420,49,2217,3077,2460,2477,1452,33,257,168,3260,512]

theorem envBound27556 : H12AffineFastState.Bounded env27556 := by
  intro p hp
  have h : env27556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27555_27556 : H12AffineEnvironment.transform 11 2324 env27555 = env27556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env27555 == env27556) = true)

theorem identity27556 : scanCanonicalize (H12AffineFastState.compose env27556 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound27556 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env27557 : List Nat := [2,4,8,16,32,48,128,256,512,304,2048,2324,300,2476,0,294,2324,2309,305,1,2340,169,16,139,420,49,2217,2357,2460,2477,156,33,257,168,2444,512]

theorem envBound27557 : H12AffineFastState.Bounded env27557 := by
  intro p hp
  have h : env27557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27556_27557 : H12AffineEnvironment.transform 9 304 env27556 = env27557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env27556 == env27557) = true)

theorem identity27557 : scanCanonicalize (H12AffineFastState.compose env27557 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27557 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env27558 : List Nat := [2,4,8,16,32,48,9,256,512,304,2048,2324,300,2341,0,294,2324,2309,305,1,2340,32,16,2,301,49,2080,2357,2325,2340,21,33,257,33,2309,512]

theorem envBound27558 : H12AffineFastState.Bounded env27558 := by
  intro p hp
  have h : env27558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27557_27558 : H12AffineEnvironment.transform 6 9 env27557 = env27558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27557 == env27558) = true)

theorem identity27558 : scanCanonicalize (H12AffineFastState.compose env27558 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27558 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27559 : List Nat := [2,4,8,16,1,17,9,256,512,273,2048,2324,269,2308,0,263,2324,2309,272,1,2309,1,16,2,268,16,2049,2324,2325,2309,21,0,257,0,2309,512]

theorem envBound27559 : H12AffineFastState.Bounded env27559 := by
  intro p hp
  have h : env27559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27558_27559 : H12AffineEnvironment.transform 4 1 env27558 = env27559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27558 == env27559) = true)

def env27560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4160,21793,97,41431,8328,65,158012,5393,17777,179648,1453,41341,257,21841,46325,625]

theorem envBound27560 : H12AffineFastState.Bounded env27560 := by
  intro p hp
  have h : env27560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27549_27560 : H12AffineEnvironment.transform 22 97 env27549 = env27560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 97 env27549 == env27560) = true)

theorem identity27560 : scanCanonicalize (H12AffineFastState.compose env27560 (packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 13476) := by decide +kernel

theorem selectedBound27560 : packedSelected [0,1,2,5,6,8,9,16,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13476,32768,8202,131072,2309,1025,32769,4160,8581,97,41431,8328,65,138648,5393,12757,179648,1453,41341,257,8693,46325,625]

theorem envBound27561 : H12AffineFastState.Bounded env27561 := by
  intro p hp
  have h : env27561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27560_27561 : H12AffineEnvironment.transform 13 13476 env27560 = env27561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13476 env27560 == env27561) = true)

theorem identity27561 : scanCanonicalize (H12AffineFastState.compose env27561 (packedSelected [3,5,8,10,11,16,18,20,23,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound27561 : packedSelected [3,5,8,10,11,16,18,20,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env27562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13476,32768,8202,13509,2309,1025,32769,4160,8581,97,41431,8328,65,10589,5393,12757,35077,1453,41341,257,8693,46325,625]

theorem envBound27562 : H12AffineFastState.Bounded env27562 := by
  intro p hp
  have h : env27562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27561_27562 : H12AffineEnvironment.transform 16 13509 env27561 = env27562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env27561 == env27562) = true)

theorem identity27562 : scanCanonicalize (H12AffineFastState.compose env27562 (packedSelected [0,2,4,6,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound27562 : packedSelected [0,2,4,6,7,22] rootPS < 2^1333 := by decide +kernel

def env27563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5409,32768,399,5440,2309,1025,32769,4160,0,97,32850,269,65,2264,5393,4176,35077,1453,33016,257,112,38256,625]

theorem envBound27563 : H12AffineFastState.Bounded env27563 := by
  intro p hp
  have h : env27563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27562_27563 : H12AffineEnvironment.transform 12 389 env27562 = env27563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env27562 == env27563) = true)

theorem identity27563 : scanCanonicalize (H12AffineFastState.compose env27563 (packedSelected [1,5,8,16,17,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound27563 : packedSelected [1,5,8,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env27564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5409,80,399,5440,2309,1025,81,4160,0,97,2,269,65,2264,5393,4176,2389,1453,168,257,112,5408,625]

theorem envBound27564 : H12AffineFastState.Bounded env27564 := by
  intro p hp
  have h : env27564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27563_27564 : H12AffineEnvironment.transform 14 80 env27563 = env27564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env27563 == env27564) = true)

theorem identity27564 : scanCanonicalize (H12AffineFastState.compose env27564 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27564 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env27565 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,129,5157,80,139,5188,2049,1025,81,4160,0,97,2,9,65,2264,5141,4176,2129,1193,168,5,112,5156,625]

theorem envBound27565 : H12AffineFastState.Bounded env27565 := by
  intro p hp
  have h : env27565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27564_27565 : H12AffineEnvironment.transform 7 4 env27564 = env27565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27564 == env27565) = true)

theorem identity27565 : scanCanonicalize (H12AffineFastState.compose env27565 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27565 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27566 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,4096,129,5157,1,139,5141,2049,1025,0,4113,0,48,2,9,16,2185,5141,4097,2048,1193,168,5,33,5156,544]

theorem envBound27566 : H12AffineFastState.Bounded env27566 := by
  intro p hp
  have h : env27566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27565_27566 : H12AffineEnvironment.transform 5 17 env27565 = env27566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27565 == env27566) = true)

theorem identity27566 : scanCanonicalize (H12AffineFastState.compose env27566 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound27566 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27567 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,41,5157,1,35,5141,2049,1025,0,4113,0,48,2,9,16,2081,5141,4097,2048,1025,0,5,33,5156,544]

theorem envBound27567 : H12AffineFastState.Bounded env27567 := by
  intro p hp
  have h : env27567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27566_27567 : H12AffineEnvironment.transform 6 40 env27566 = env27567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env27566 == env27567) = true)

theorem identity27567 : scanCanonicalize (H12AffineFastState.compose env27567 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27567 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env27568 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,4096,9,5125,1,3,5141,2049,1025,0,4113,0,16,2,9,16,2049,5141,4097,2048,1025,0,5,1,5124,512]

theorem envBound27568 : H12AffineFastState.Bounded env27568 := by
  intro p hp
  have h : env27568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27567_27568 : H12AffineEnvironment.transform 4 0 env27567 = env27568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27567 == env27568) = true)

theorem identity27568 : scanCanonicalize (H12AffineFastState.compose env27568 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound27568 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27569 : List Nat := [2,4,8,16,0,17,8,4,512,1024,523,4096,9,5125,1,3,5141,522,1025,0,4113,0,16,2,9,16,522,5141,4097,523,1025,0,5,1,5124,512]

theorem envBound27569 : H12AffineFastState.Bounded env27569 := by
  intro p hp
  have h : env27569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27568_27569 : H12AffineEnvironment.transform 10 523 env27568 = env27569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env27568 == env27569) = true)

def env27570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347627,4194304,8388608,392317,8328,65,12729469,79130,8722619,8830976,8681580,4314199,257,8484155,8492191,8740794]

theorem envBound27570 : H12AffineFastState.Bounded env27570 := by
  intro p hp
  have h : env27570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27469_27570 : H12AffineEnvironment.transform 23 392317 env27469 = env27570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392317 env27469 == env27570) = true)

def env27571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,4194304,8388608,98781,8328,65,12729469,79130,8480027,8568224,8390092,4314199,257,8484155,8492191,8462874]

theorem envBound27571 : H12AffineFastState.Bounded env27571 := by
  intro p hp
  have h : env27571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27570_27571 : H12AffineEnvironment.transform 17 32160 env27570 = env27571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env27570 == env27571) = true)

def env27572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21792,8388608,98781,8328,65,8546653,79130,8480027,8568224,8390092,98679,257,8484155,8492191,8462874]

theorem envBound27572 : H12AffineFastState.Bounded env27572 := by
  intro p hp
  have h : env27572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27571_27572 : H12AffineEnvironment.transform 21 21792 env27571 = env27572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env27571 == env27572) = true)

theorem identity27572 : scanCanonicalize (H12AffineFastState.compose env27572 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound27572 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21792,17,98781,8328,65,158028,79130,91402,179633,1501,98679,257,95530,103566,74251]

theorem envBound27573 : H12AffineFastState.Bounded env27573 := by
  intro p hp
  have h : env27573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27572_27573 : H12AffineEnvironment.transform 22 17 env27572 = env27573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env27572 == env27573) = true)

theorem identity27573 : scanCanonicalize (H12AffineFastState.compose env27573 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27573 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env27574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4161,21792,17,41431,8328,65,158028,5392,17664,179633,1501,41341,257,21792,46212,513]

theorem envBound27574 : H12AffineFastState.Bounded env27574 := by
  intro p hp
  have h : env27574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27573_27574 : H12AffineEnvironment.transform 15 8202 env27573 = env27574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27573 == env27574) = true)

theorem identity27574 : scanCanonicalize (H12AffineFastState.compose env27574 (packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound27574 : packedSelected [0,1,2,3,4,5,6,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env27575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,216,8202,131072,32160,1025,217,4161,21792,17,8463,8328,65,158028,5392,17664,146793,1501,8613,257,21792,13404,513]

theorem envBound27575 : H12AffineFastState.Bounded env27575 := by
  intro p hp
  have h : env27575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27574_27575 : H12AffineEnvironment.transform 14 216 env27574 = env27575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env27574 == env27575) = true)

theorem identity27575 : scanCanonicalize (H12AffineFastState.compose env27575 (packedSelected [3,10,18,19,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27575 : packedSelected [3,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env27576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,216,8202,131072,10400,1025,217,4161,32,17,8463,8328,65,146508,5392,4096,146793,1501,8613,257,32,13404,513]

theorem envBound27576 : H12AffineFastState.Bounded env27576 := by
  intro p hp
  have h : env27576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27575_27576 : H12AffineEnvironment.transform 13 5376 env27575 = env27576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27575 == env27576) = true)

theorem identity27576 : scanCanonicalize (H12AffineFastState.compose env27576 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 6476) := by decide +kernel

theorem selectedBound27576 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env27577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,6476,5376,216,6470,131072,4588,1025,217,4161,32,17,6211,6596,65,132352,5392,4096,132133,1501,6377,257,32,3344,513]

theorem envBound27577 : H12AffineFastState.Bounded env27577 := by
  intro p hp
  have h : env27577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27576_27577 : H12AffineEnvironment.transform 12 6476 env27576 = env27577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6476 env27576 == env27577) = true)

theorem identity27577 : scanCanonicalize (H12AffineFastState.compose env27577 (packedSelected [0,3,5,7,12,14,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound27577 : packedSelected [0,3,5,7,12,14,18,19] rootPS < 2^1333 := by decide +kernel

def env27578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3188,1336,2420,216,1330,131072,3480,1025,217,3125,32,17,1079,1456,65,132352,2404,3188,132133,1501,1181,257,32,3344,513]

theorem envBound27578 : H12AffineFastState.Bounded env27578 := by
  intro p hp
  have h : env27578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27577_27578 : H12AffineEnvironment.transform 11 3188 env27577 = env27578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env27577 == env27578) = true)

theorem identity27578 : scanCanonicalize (H12AffineFastState.compose env27578 (packedSelected [1,8,10,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound27578 : packedSelected [1,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env27579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1297,357,1336,1125,216,1330,131072,137,1025,217,292,32,17,1079,1456,65,132352,1141,357,132133,1501,1181,257,32,1,513]

theorem envBound27579 : H12AffineFastState.Bounded env27579 := by
  intro p hp
  have h : env27579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27578_27579 : H12AffineEnvironment.transform 10 1297 env27578 = env27579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env27578 == env27579) = true)

theorem identity27579 : scanCanonicalize (H12AffineFastState.compose env27579 (packedSelected [0,2,4,10,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 1281) := by decide +kernel

theorem selectedBound27579 : packedSelected [0,2,4,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1297,357,1336,1125,216,1330,1281,137,1025,217,292,32,17,1079,1456,65,1,1141,357,292,1501,1181,257,32,1,513]

theorem envBound27580 : H12AffineFastState.Bounded env27580 := by
  intro p hp
  have h : env27580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27579_27580 : H12AffineEnvironment.transform 16 1281 env27579 = env27580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1281 env27579 == env27580) = true)

theorem identity27580 : scanCanonicalize (H12AffineFastState.compose env27580 (packedSelected [1,2,3,5,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound27580 : packedSelected [1,2,3,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env27581 : List Nat := [2,4,8,16,32,64,128,256,512,273,0,357,41,372,216,35,16,137,272,217,292,32,17,294,161,65,1,356,357,292,204,396,257,32,1,513]

theorem envBound27581 : H12AffineFastState.Bounded env27581 := by
  intro p hp
  have h : env27581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27580_27581 : H12AffineEnvironment.transform 9 273 env27580 = env27581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env27580 == env27581) = true)

theorem identity27581 : scanCanonicalize (H12AffineFastState.compose env27581 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound27581 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27582 : List Nat := [2,4,8,16,32,64,128,253,512,236,0,152,41,137,216,35,16,137,237,217,217,32,17,219,161,65,1,153,152,217,204,113,252,32,1,513]

theorem envBound27582 : H12AffineFastState.Bounded env27582 := by
  intro p hp
  have h : env27582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27581_27582 : H12AffineEnvironment.transform 7 253 env27581 = env27582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env27581 == env27582) = true)

theorem identity27582 : scanCanonicalize (H12AffineFastState.compose env27582 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27582 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env27583 : List Nat := [2,4,8,16,32,16,128,173,512,188,0,152,41,137,136,35,16,137,189,137,137,32,17,139,161,17,1,153,152,137,156,33,172,32,1,513]

theorem envBound27583 : H12AffineFastState.Bounded env27583 := by
  intro p hp
  have h : env27583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27582_27583 : H12AffineEnvironment.transform 5 16 env27582 = env27583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27582 == env27583) = true)

theorem identity27583 : scanCanonicalize (H12AffineFastState.compose env27583 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27583 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env27584 : List Nat := [2,4,8,16,32,16,8,37,512,52,0,16,41,1,0,35,16,1,53,1,1,32,17,3,41,17,1,17,16,1,20,33,36,32,1,513]

theorem envBound27584 : H12AffineFastState.Bounded env27584 := by
  intro p hp
  have h : env27584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27583_27584 : H12AffineEnvironment.transform 6 8 env27583 = env27584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27583 == env27584) = true)

theorem identity27584 : scanCanonicalize (H12AffineFastState.compose env27584 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound27584 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27585 : List Nat := [2,4,8,16,5,16,8,0,512,17,0,16,12,1,0,6,16,1,16,1,1,5,17,3,12,17,1,17,16,1,20,4,1,5,1,513]

theorem envBound27585 : H12AffineFastState.Bounded env27585 := by
  intro p hp
  have h : env27585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27584_27585 : H12AffineEnvironment.transform 4 5 env27584 = env27585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env27584 == env27585) = true)

theorem identity27585 : scanCanonicalize (H12AffineFastState.compose env27585 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound27585 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27586 : List Nat := [2,4,8,16,5,16,8,0,13,17,0,16,12,1,0,6,16,1,16,1,1,5,17,3,12,17,1,17,16,1,20,4,1,5,1,12]

theorem envBound27586 : H12AffineFastState.Bounded env27586 := by
  intro p hp
  have h : env27586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27585_27586 : H12AffineEnvironment.transform 8 13 env27585 = env27586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env27585 == env27586) = true)

theorem identity27586 : scanCanonicalize (H12AffineFastState.compose env27586 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27586 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27587 : List Nat := [2,4,8,0,5,0,8,0,13,1,0,0,12,1,0,6,0,1,0,1,1,5,1,3,12,1,1,1,0,1,4,4,1,5,1,12]

theorem envBound27587 : H12AffineFastState.Bounded env27587 := by
  intro p hp
  have h : env27587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27586_27587 : H12AffineEnvironment.transform 3 0 env27586 = env27587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27586 == env27587) = true)

theorem identity27587 : scanCanonicalize (H12AffineFastState.compose env27587 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27587 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27588 : List Nat := [2,4,2,0,5,0,2,0,7,1,0,0,6,1,0,6,0,1,0,1,1,5,1,3,6,1,1,1,0,1,4,4,1,5,1,6]

theorem envBound27588 : H12AffineFastState.Bounded env27588 := by
  intro p hp
  have h : env27588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27587_27588 : H12AffineEnvironment.transform 2 2 env27587 = env27588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27587 == env27588) = true)

theorem identity27588 : scanCanonicalize (H12AffineFastState.compose env27588 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound27588 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env27589 : List Nat := [2,0,2,0,1,0,2,0,3,1,0,0,2,1,0,2,0,1,0,1,1,1,1,3,2,1,1,1,0,1,0,0,1,1,1,2]

theorem envBound27589 : H12AffineFastState.Bounded env27589 := by
  intro p hp
  have h : env27589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27588_27589 : H12AffineEnvironment.transform 1 0 env27588 = env27589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env27588 == env27589) = true)

def env27590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,77899,21793,8388608,98781,8328,65,8546652,79130,8480027,8568224,8390092,98678,257,8484155,8492191,8462874]

theorem envBound27590 : H12AffineFastState.Bounded env27590 := by
  intro p hp
  have h : env27590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27571_27590 : H12AffineEnvironment.transform 21 21793 env27571 = env27590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env27571 == env27590) = true)

def env27591 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,21793,8388608,98645,8192,65,8546652,79130,8480027,8568104,8389956,98678,257,8484155,8492055,8462874]

theorem envBound27591 : H12AffineFastState.Bounded env27591 := by
  intro p hp
  have h : env27591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27590_27591 : H12AffineEnvironment.transform 6 8 env27590 = env27591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27590 == env27591) = true)

theorem identity27591 : scanCanonicalize (H12AffineFastState.compose env27591 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 221194) := by decide +kernel

theorem selectedBound27591 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env27592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,21793,221194,98645,8192,65,67926,79130,132369,122146,222542,98678,257,136497,193565,147984]

theorem envBound27592 : H12AffineFastState.Bounded env27592 := by
  intro p hp
  have h : env27592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27591_27592 : H12AffineEnvironment.transform 22 221194 env27591 = env27592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 221194 env27591 == env27592) = true)

theorem identity27592 : scanCanonicalize (H12AffineFastState.compose env27592 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound27592 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env27593 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32040,1025,29789,77899,21793,221194,95497,8192,65,67926,79130,132369,76158,222542,95530,257,136497,131137,147984]

theorem envBound27593 : H12AffineFastState.Bounded env27593 := by
  intro p hp
  have h : env27593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27592_27593 : H12AffineEnvironment.transform 14 29788 env27592 = env27593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env27592 == env27593) = true)

theorem identity27593 : scanCanonicalize (H12AffineFastState.compose env27593 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound27593 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env27594 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,5220,32040,1025,29789,77899,21793,95342,95497,8192,65,67926,79130,4469,76158,94506,95530,257,341,5157,22132]

theorem envBound27594 : H12AffineFastState.Bounded env27594 := by
  intro p hp
  have h : env27594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27593_27594 : H12AffineEnvironment.transform 16 5220 env27593 = env27594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env27593 == env27594) = true)

theorem identity27594 : scanCanonicalize (H12AffineFastState.compose env27594 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound27594 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env27595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8233,65536,5220,10589,1025,8232,77899,340,73755,74108,8192,65,67926,79130,4469,76158,75103,74079,257,341,5157,513]

theorem envBound27595 : H12AffineFastState.Bounded env27595 := by
  intro p hp
  have h : env27595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27594_27595 : H12AffineEnvironment.transform 13 5237 env27594 = env27595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env27594 == env27595) = true)

theorem identity27595 : scanCanonicalize (H12AffineFastState.compose env27595 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound27595 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env27596 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8233,9499,5220,10589,1025,8232,5456,340,1280,1127,8192,65,11341,4097,4469,3173,68,1092,257,341,5157,513]

theorem envBound27596 : H12AffineFastState.Bounded env27596 := by
  intro p hp
  have h : env27596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27595_27596 : H12AffineEnvironment.transform 15 9499 env27595 = env27596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env27595 == env27596) = true)

theorem identity27596 : scanCanonicalize (H12AffineFastState.compose env27596 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound27596 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env27597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,5237,1076,262,5220,3392,1025,1077,5456,340,1280,1127,1053,65,2128,4097,4469,3173,68,1092,257,341,5157,513]

theorem envBound27597 : H12AffineFastState.Bounded env27597 := by
  intro p hp
  have h : env27597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27596_27597 : H12AffineEnvironment.transform 12 1053 env27596 = env27597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env27596 == env27597) = true)

theorem identity27597 : scanCanonicalize (H12AffineFastState.compose env27597 (packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound27597 : packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env27598 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1053,5237,1076,115,5220,3125,1025,1077,5157,33,1141,1127,1053,65,2128,4097,4096,3173,68,1092,116,32,5157,513]

theorem envBound27598 : H12AffineFastState.Bounded env27598 := by
  intro p hp
  have h : env27598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27597_27598 : H12AffineEnvironment.transform 7 117 env27597 = env27598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env27597 == env27598) = true)

theorem identity27598 : scanCanonicalize (H12AffineFastState.compose env27598 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27598 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env27599 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,1053,5156,1076,34,5173,3125,1025,1077,5157,33,1060,1078,1053,16,2049,4097,4096,3124,21,1045,37,32,5157,513]

theorem envBound27599 : H12AffineFastState.Bounded env27599 := by
  intro p hp
  have h : env27599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27598_27599 : H12AffineEnvironment.transform 5 17 env27598 = env27599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27598 == env27599) = true)

def env27600 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77899,21793,8388608,98644,8193,65,8546652,79130,8480027,8568105,8389957,98678,257,8484155,8492054,8462874]

theorem envBound27600 : H12AffineFastState.Bounded env27600 := by
  intro p hp
  have h : env27600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27590_27600 : H12AffineEnvironment.transform 6 9 env27590 = env27600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27590 == env27600) = true)

def env27601 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1025,32769,77899,33,8388608,98644,8193,65,8535132,79130,8466459,8568105,8389957,98678,257,8462395,8492054,8462874]

theorem envBound27601 : H12AffineFastState.Bounded env27601 := by
  intro p hp
  have h : env27601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27600_27601 : H12AffineEnvironment.transform 13 5376 env27600 = env27601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27600 == env27601) = true)

theorem identity27601 : scanCanonicalize (H12AffineFastState.compose env27601 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27601 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27602 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,131072,10281,1025,32769,4161,33,8388608,41310,8193,65,8535132,5392,8392721,8568105,8389957,41340,257,8388657,8434716,8389136]

theorem envBound27602 : H12AffineFastState.Bounded env27602 := by
  intro p hp
  have h : env27602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27601_27602 : H12AffineEnvironment.transform 15 8202 env27601 = env27602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27601 == env27602) = true)

theorem identity27602 : scanCanonicalize (H12AffineFastState.compose env27602 (packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound27602 : packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env27603 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,292,8202,131072,10281,1025,293,4161,33,8388608,8314,8193,65,8535132,5392,8392721,8535053,8389957,8280,257,8388657,8402232,8389136]

theorem envBound27603 : H12AffineFastState.Bounded env27603 := by
  intro p hp
  have h : env27603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27602_27603 : H12AffineEnvironment.transform 14 292 env27602 = env27603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env27602 == env27603) = true)

theorem identity27603 : scanCanonicalize (H12AffineFastState.compose env27603 (packedSelected [0,2,3,6,7,10,11,18,20,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound27603 : packedSelected [0,2,3,6,7,10,11,18,20,24,26] rootPS < 2^1333 := by decide +kernel

def env27604 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,292,8202,5392,10281,1025,293,4161,33,8388608,8314,8193,65,8399180,5392,8392721,8399133,8389957,8280,257,8388657,8402232,8389136]

theorem envBound27604 : H12AffineFastState.Bounded env27604 := by
  intro p hp
  have h : env27604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27603_27604 : H12AffineEnvironment.transform 16 5392 env27603 = env27604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env27603 == env27604) = true)

theorem identity27604 : scanCanonicalize (H12AffineFastState.compose env27604 (packedSelected [0,1,3,4,5,6,7,8,9,10,12,15,19] rootPS)) = affineNative (2^(22+1) ^^^ 1313) := by decide +kernel

theorem selectedBound27604 : packedSelected [0,1,3,4,5,6,7,8,9,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env27605 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,292,8202,5392,10281,1025,293,4161,33,1313,8314,8193,65,11373,5392,5424,11324,100,8280,257,1296,12313,1841]

theorem envBound27605 : H12AffineFastState.Bounded env27605 := by
  intro p hp
  have h : env27605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27604_27605 : H12AffineEnvironment.transform 22 1313 env27604 = env27605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 1313 env27604 == env27605) = true)

theorem identity27605 : scanCanonicalize (H12AffineFastState.compose env27605 (packedSelected [0,2,4,7,9,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1352) := by decide +kernel

theorem selectedBound27605 : packedSelected [0,2,4,7,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env27606 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1352,5376,292,1346,5392,3425,1025,293,4161,33,1313,1330,1353,65,2341,5392,5424,2420,100,1296,257,1296,5457,1841]

theorem envBound27606 : H12AffineFastState.Bounded env27606 := by
  intro p hp
  have h : env27606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27605_27606 : H12AffineEnvironment.transform 12 1352 env27605 = env27606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1352 env27605 == env27606) = true)

theorem identity27606 : scanCanonicalize (H12AffineFastState.compose env27606 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27606 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env27607 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1305,5376,292,1299,5392,3376,1025,293,4112,33,1313,1330,1304,16,2341,5392,5424,2341,53,1296,257,1296,5376,1841]

theorem envBound27607 : H12AffineFastState.Bounded env27607 := by
  intro p hp
  have h : env27607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27606_27607 : H12AffineEnvironment.transform 5 17 env27606 = env27607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27606 == env27607) = true)

theorem identity27607 : scanCanonicalize (H12AffineFastState.compose env27607 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27607 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27608 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,1052,5125,33,1046,5141,3125,1025,32,4112,33,1060,1079,1053,16,2080,5141,5173,2080,53,1045,4,1045,5125,1588]

theorem envBound27608 : H12AffineFastState.Bounded env27608 := by
  intro p hp
  have h : env27608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27607_27608 : H12AffineEnvironment.transform 7 5 env27607 = env27608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27607 == env27608) = true)

theorem identity27608 : scanCanonicalize (H12AffineFastState.compose env27608 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound27608 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27609 : List Nat := [2,4,8,16,32,17,9,5,512,21,2048,4096,9,4112,33,3,4096,2080,20,32,4112,33,49,34,8,16,2080,4096,4128,2080,53,0,4,0,4112,545]

theorem envBound27609 : H12AffineFastState.Bounded env27609 := by
  intro p hp
  have h : env27609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27608_27609 : H12AffineEnvironment.transform 9 21 env27608 = env27609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env27608 == env27609) = true)

theorem identity27609 : scanCanonicalize (H12AffineFastState.compose env27609 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound27609 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env27610 : List Nat := [2,4,8,16,32,17,9,5,512,21,2048,0,9,16,33,3,0,2080,20,32,16,33,49,34,8,16,2080,0,32,2080,53,0,4,0,16,545]

theorem envBound27610 : H12AffineFastState.Bounded env27610 := by
  intro p hp
  have h : env27610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27609_27610 : H12AffineEnvironment.transform 11 0 env27609 = env27610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env27609 == env27610) = true)

theorem identity27610 : scanCanonicalize (H12AffineFastState.compose env27610 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27610 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env27611 : List Nat := [2,4,8,16,32,17,9,5,0,21,2048,0,9,16,33,3,0,2080,20,32,16,33,49,34,8,16,2080,0,32,2080,53,0,4,0,16,33]

theorem envBound27611 : H12AffineFastState.Bounded env27611 := by
  intro p hp
  have h : env27611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27610_27611 : H12AffineEnvironment.transform 8 0 env27610 = env27611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27610 == env27611) = true)

theorem identity27611 : scanCanonicalize (H12AffineFastState.compose env27611 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27611 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env27612 : List Nat := [2,4,8,16,0,17,9,5,0,21,2048,0,9,16,1,3,0,2048,20,0,16,1,17,2,8,16,2048,0,0,2048,21,0,4,0,16,1]

theorem envBound27612 : H12AffineFastState.Bounded env27612 := by
  intro p hp
  have h : env27612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27611_27612 : H12AffineEnvironment.transform 4 0 env27611 = env27612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27611 == env27612) = true)

theorem identity27612 : scanCanonicalize (H12AffineFastState.compose env27612 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound27612 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27613 : List Nat := [2,4,8,16,0,17,9,5,0,21,16,0,9,16,1,3,0,16,20,0,16,1,17,2,8,16,16,0,0,16,21,0,4,0,16,1]

theorem envBound27613 : H12AffineFastState.Bounded env27613 := by
  intro p hp
  have h : env27613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27612_27613 : H12AffineEnvironment.transform 10 16 env27612 = env27613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env27612 == env27613) = true)

def env27614 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1025,32769,77899,32,8388608,98644,8193,65,8535133,79130,8466458,8568105,8389957,98678,257,8462394,8492054,8462874]

theorem envBound27614 : H12AffineFastState.Bounded env27614 := by
  intro p hp
  have h : env27614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27600_27614 : H12AffineEnvironment.transform 13 5377 env27600 = env27614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env27600 == env27614) = true)

theorem identity27614 : scanCanonicalize (H12AffineFastState.compose env27614 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound27614 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27615 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1025,32769,77899,32,73755,98644,8193,65,203846,79130,4097,236850,75102,98678,257,33,46093,513]

theorem envBound27615 : H12AffineFastState.Bounded env27615 := by
  intro p hp
  have h : env27615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27614_27615 : H12AffineEnvironment.transform 22 73755 env27614 = env27615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env27614 == env27615) = true)

theorem identity27615 : scanCanonicalize (H12AffineFastState.compose env27615 (packedSelected [0,2,3,4,5,6,7,9,11,14,15,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound27615 : packedSelected [0,2,3,4,5,6,7,9,11,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env27616 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,70726,10280,1025,32769,77899,32,73755,98644,8193,65,2048,79130,4097,35188,75102,98678,257,33,46093,513]

theorem envBound27616 : H12AffineFastState.Bounded env27616 := by
  intro p hp
  have h : env27616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27615_27616 : H12AffineEnvironment.transform 16 70726 env27615 = env27616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env27615 == env27616) = true)

theorem identity27616 : scanCanonicalize (H12AffineFastState.compose env27616 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound27616 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env27617 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,263,5441,10280,1025,32769,12620,32,8476,32851,8193,65,2048,13341,4097,35188,9305,32881,257,33,46093,513]

theorem envBound27617 : H12AffineFastState.Bounded env27617 := by
  intro p hp
  have h : env27617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27616_27617 : H12AffineEnvironment.transform 15 263 env27616 = env27617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env27616 == env27617) = true)

theorem identity27617 : scanCanonicalize (H12AffineFastState.compose env27617 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound27617 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env27618 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8461,263,5441,10280,1025,8460,12620,32,8476,8542,8193,65,2048,13341,4097,10361,9305,8572,257,33,5376,513]

theorem envBound27618 : H12AffineFastState.Bounded env27618 := by
  intro p hp
  have h : env27618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27617_27618 : H12AffineEnvironment.transform 14 8461 env27617 = env27618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env27617 == env27618) = true)

theorem identity27618 : scanCanonicalize (H12AffineFastState.compose env27618 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27618 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env27619 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,263,5393,10280,1025,8460,12572,32,8476,8462,8193,17,2048,13341,4097,10281,9225,8492,257,33,5376,513]

theorem envBound27619 : H12AffineFastState.Bounded env27619 := by
  intro p hp
  have h : env27619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27618_27619 : H12AffineEnvironment.transform 5 16 env27618 = env27619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27618 == env27619) = true)

theorem identity27619 : scanCanonicalize (H12AffineFastState.compose env27619 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound27619 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27620 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,263,5393,2341,1025,1,4113,32,17,3,268,17,2048,5392,4097,2340,1284,33,257,33,5376,513]

theorem envBound27620 : H12AffineFastState.Bounded env27620 := by
  intro p hp
  have h : env27620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27619_27620 : H12AffineEnvironment.transform 12 269 env27619 = env27620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env27619 == env27620) = true)

theorem identity27620 : scanCanonicalize (H12AffineFastState.compose env27620 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27620 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27621 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,5377,0,263,5393,2308,1025,1,4113,1,17,3,268,17,2048,5392,4097,2309,1284,0,257,0,5376,513]

theorem envBound27621 : H12AffineFastState.Bounded env27621 := by
  intro p hp
  have h : env27621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27620_27621 : H12AffineEnvironment.transform 4 1 env27620 = env27621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27620 == env27621) = true)

end H12CloudChart1