import H12CloudChart1Data112

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env28638 : List Nat := [2,4,8,16,0,17,8,5,512,20,1,17,9,0,1,2,17,0,21,0,0,0,17,3,9,16,1,16,16,1,20,0,4,1,1,513]

theorem envBound28638 : H12AffineFastState.Bounded env28638 := by
  intro p hp
  have h : env28638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28637_28638 : H12AffineEnvironment.transform 9 20 env28637 = env28638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env28637 == env28638) = true)

theorem identity28638 : scanCanonicalize (H12AffineFastState.compose env28638 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28638 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28639 : List Nat := [2,4,8,16,0,17,8,5,0,20,1,17,9,0,1,2,17,0,21,0,0,0,17,3,9,16,1,16,16,1,20,0,4,1,1,1]

theorem envBound28639 : H12AffineFastState.Bounded env28639 := by
  intro p hp
  have h : env28639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28638_28639 : H12AffineEnvironment.transform 8 0 env28638 = env28639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28638 == env28639) = true)

def env28640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,4096,8192,16384,8541,65536,82247,9292,1025,8540,91466,4194304,17,2,8192,65,4195396,16401,77835,66631,75103,4194304,257,32,16464,513]

theorem envBound28640 : H12AffineFastState.Bounded env28640 := by
  intro p hp
  have h : env28640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28628_28640 : H12AffineEnvironment.transform 10 1125 env28628 = env28640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env28628 == env28640) = true)

def env28641 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,8192,16384,8461,65536,82199,9244,1025,8460,91418,4194304,17,2,8192,17,4195348,16401,77835,66583,75023,4194304,257,32,16384,513]

theorem envBound28641 : H12AffineFastState.Bounded env28641 := by
  intro p hp
  have h : env28641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28640_28641 : H12AffineEnvironment.transform 5 16 env28640 = env28641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28640 == env28641) = true)

theorem identity28641 : scanCanonicalize (H12AffineFastState.compose env28641 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound28641 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28642 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,268,16384,1,65536,82199,1296,1025,0,82966,4194304,17,2,268,17,4195348,16401,69895,66583,66563,4194304,257,32,16384,513]

theorem envBound28642 : H12AffineFastState.Bounded env28642 := by
  intro p hp
  have h : env28642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28641_28642 : H12AffineEnvironment.transform 12 268 env28641 = env28642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env28641 == env28642) = true)

theorem identity28642 : scanCanonicalize (H12AffineFastState.compose env28642 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound28642 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env28643 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,268,16384,1,65536,82199,1296,1025,0,82966,32,17,2,268,17,1076,16401,69895,66583,66563,32,257,32,16384,513]

theorem envBound28643 : H12AffineFastState.Bounded env28643 := by
  intro p hp
  have h : env28643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28642_28643 : H12AffineEnvironment.transform 21 32 env28642 = env28643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env28642 == env28643) = true)

theorem identity28643 : scanCanonicalize (H12AffineFastState.compose env28643 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound28643 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28644 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,268,16384,1,262,16401,1296,1025,0,17680,32,17,2,268,17,1076,16401,4097,1297,1285,32,257,32,16384,513]

theorem envBound28644 : H12AffineFastState.Bounded env28644 := by
  intro p hp
  have h : env28644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28643_28644 : H12AffineEnvironment.transform 15 262 env28643 = env28644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env28643 == env28644) = true)

theorem identity28644 : scanCanonicalize (H12AffineFastState.compose env28644 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound28644 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28645 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,268,1296,1,262,1281,1296,1025,0,0,32,17,2,268,17,1076,1281,4097,1297,1285,32,257,32,1296,513]

theorem envBound28645 : H12AffineFastState.Bounded env28645 := by
  intro p hp
  have h : env28645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28644_28645 : H12AffineEnvironment.transform 13 1296 env28644 = env28645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env28644 == env28645) = true)

theorem identity28645 : scanCanonicalize (H12AffineFastState.compose env28645 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 795) := by decide +kernel

theorem selectedBound28645 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28646 : List Nat := [2,4,8,16,32,16,8,256,512,795,814,4096,268,523,1,262,538,523,794,0,0,32,17,2,268,17,815,538,4097,522,542,32,257,32,523,513]

theorem envBound28646 : H12AffineFastState.Bounded env28646 := by
  intro p hp
  have h : env28646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28645_28646 : H12AffineEnvironment.transform 9 795 env28645 = env28646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 795 env28645 == env28646) = true)

theorem identity28646 : scanCanonicalize (H12AffineFastState.compose env28646 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound28646 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28647 : List Nat := [2,4,8,16,32,16,8,4,512,543,554,4096,8,523,1,2,538,523,542,0,0,32,17,2,8,17,555,538,4097,522,542,32,5,32,523,513]

theorem envBound28647 : H12AffineFastState.Bounded env28647 := by
  intro p hp
  have h : env28647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28646_28647 : H12AffineEnvironment.transform 7 4 env28646 = env28647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env28646 == env28647) = true)

theorem identity28647 : scanCanonicalize (H12AffineFastState.compose env28647 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound28647 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28648 : List Nat := [2,4,8,16,32,16,8,4,512,543,554,16,8,523,1,2,538,523,542,0,0,32,17,2,8,17,555,538,17,522,542,32,5,32,523,513]

theorem envBound28648 : H12AffineFastState.Bounded env28648 := by
  intro p hp
  have h : env28648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28647_28648 : H12AffineEnvironment.transform 11 16 env28647 = env28648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env28647 == env28648) = true)

theorem identity28648 : scanCanonicalize (H12AffineFastState.compose env28648 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound28648 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28649 : List Nat := [2,4,8,16,32,16,8,4,10,21,32,16,8,1,1,2,16,1,20,0,0,32,17,2,8,17,33,16,17,0,20,32,5,32,1,11]

theorem envBound28649 : H12AffineFastState.Bounded env28649 := by
  intro p hp
  have h : env28649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28648_28649 : H12AffineEnvironment.transform 8 10 env28648 = env28649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env28648 == env28649) = true)

theorem identity28649 : scanCanonicalize (H12AffineFastState.compose env28649 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28649 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env28650 : List Nat := [2,4,8,16,0,16,8,4,10,21,0,16,8,1,1,2,16,1,20,0,0,0,17,2,8,17,1,16,17,0,20,0,5,0,1,11]

theorem envBound28650 : H12AffineFastState.Bounded env28650 := by
  intro p hp
  have h : env28650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28649_28650 : H12AffineEnvironment.transform 4 0 env28649 = env28650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28649 == env28650) = true)

theorem identity28650 : scanCanonicalize (H12AffineFastState.compose env28650 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound28650 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28651 : List Nat := [2,1,8,16,0,16,8,1,10,16,0,16,8,1,1,2,16,1,17,0,0,0,17,2,8,17,1,16,17,0,17,0,0,0,1,11]

theorem envBound28651 : H12AffineFastState.Bounded env28651 := by
  intro p hp
  have h : env28651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28650_28651 : H12AffineEnvironment.transform 1 1 env28650 = env28651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env28650 == env28651) = true)

theorem identity28651 : scanCanonicalize (H12AffineFastState.compose env28651 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound28651 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28652 : List Nat := [2,1,8,2,0,2,8,1,10,2,0,2,8,1,1,2,2,1,3,0,0,0,3,2,8,3,1,2,3,0,3,0,0,0,1,11]

theorem envBound28652 : H12AffineFastState.Bounded env28652 := by
  intro p hp
  have h : env28652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28651_28652 : H12AffineEnvironment.transform 3 2 env28651 = env28652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env28651 == env28652) = true)

def env28653 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,4096,8192,16384,8460,65536,82198,9245,1025,8461,91419,4194304,17,2,8192,16,4195349,16401,77835,66582,75022,4194304,257,32,16385,513]

theorem envBound28653 : H12AffineFastState.Bounded env28653 := by
  intro p hp
  have h : env28653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28640_28653 : H12AffineEnvironment.transform 5 17 env28640 = env28653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28640 == env28653) = true)

theorem identity28653 : scanCanonicalize (H12AffineFastState.compose env28653 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound28653 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28654 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,4096,8192,16384,8460,263,16401,9245,1025,8461,25628,4194304,17,2,8192,16,4195349,16401,12556,1297,9225,4194304,257,32,16385,513]

theorem envBound28654 : H12AffineFastState.Bounded env28654 := by
  intro p hp
  have h : env28654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28653_28654 : H12AffineEnvironment.transform 15 263 env28653 = env28654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env28653 == env28654) = true)

theorem identity28654 : scanCanonicalize (H12AffineFastState.compose env28654 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound28654 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env28655 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,4096,8192,16384,8460,263,16401,9245,1025,8461,25628,32,17,2,8192,16,1077,16401,12556,1297,9225,32,257,32,16385,513]

theorem envBound28655 : H12AffineFastState.Bounded env28655 := by
  intro p hp
  have h : env28655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28654_28655 : H12AffineEnvironment.transform 21 32 env28654 = env28655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env28654 == env28655) = true)

theorem identity28655 : scanCanonicalize (H12AffineFastState.compose env28655 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 1077) := by decide +kernel

theorem selectedBound28655 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env28656 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,4096,8192,1077,8460,263,1060,9245,1025,8461,8233,32,17,2,8192,16,1077,1060,12556,1297,9225,32,257,32,1076,513]

theorem envBound28656 : H12AffineFastState.Bounded env28656 := by
  intro p hp
  have h : env28656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28655_28656 : H12AffineEnvironment.transform 13 1077 env28655 = env28656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env28655 == env28656) = true)

theorem identity28656 : scanCanonicalize (H12AffineFastState.compose env28656 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound28656 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28657 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,4096,268,1077,0,263,1060,1297,1025,1,293,32,17,2,268,16,1077,1060,4096,1297,1285,32,257,32,1076,513]

theorem envBound28657 : H12AffineFastState.Bounded env28657 := by
  intro p hp
  have h : env28657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28656_28657 : H12AffineEnvironment.transform 12 268 env28656 = env28657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env28656 == env28657) = true)

theorem identity28657 : scanCanonicalize (H12AffineFastState.compose env28657 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28657 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28658 : List Nat := [2,4,8,16,1,17,8,256,512,1024,1045,4096,268,1044,0,263,1029,1297,1025,1,260,1,17,2,268,16,1044,1029,4096,1297,1285,1,257,1,1045,513]

theorem envBound28658 : H12AffineFastState.Bounded env28658 := by
  intro p hp
  have h : env28658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28657_28658 : H12AffineEnvironment.transform 4 1 env28657 = env28658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28657 == env28658) = true)

theorem identity28658 : scanCanonicalize (H12AffineFastState.compose env28658 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound28658 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28659 : List Nat := [2,4,8,16,1,17,8,256,512,1024,1045,16,268,1044,0,263,1029,1297,1025,1,260,1,17,2,268,16,1044,1029,16,1297,1285,1,257,1,1045,513]

theorem envBound28659 : H12AffineFastState.Bounded env28659 := by
  intro p hp
  have h : env28659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28658_28659 : H12AffineEnvironment.transform 11 16 env28658 = env28659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env28658 == env28659) = true)

theorem identity28659 : scanCanonicalize (H12AffineFastState.compose env28659 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound28659 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28660 : List Nat := [2,4,8,16,1,17,8,256,261,1024,1045,16,268,1044,0,263,1029,1297,1025,1,260,1,17,2,268,16,1044,1029,16,1297,1285,1,257,1,1045,260]

theorem envBound28660 : H12AffineFastState.Bounded env28660 := by
  intro p hp
  have h : env28660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28659_28660 : H12AffineEnvironment.transform 8 261 env28659 = env28660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env28659 == env28660) = true)

theorem identity28660 : scanCanonicalize (H12AffineFastState.compose env28660 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound28660 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28661 : List Nat := [2,4,8,16,1,17,8,256,261,256,277,16,268,276,0,263,261,17,257,1,260,1,17,2,268,16,276,261,16,17,5,1,257,1,277,260]

theorem envBound28661 : H12AffineFastState.Bounded env28661 := by
  intro p hp
  have h : env28661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28660_28661 : H12AffineEnvironment.transform 9 256 env28660 = env28661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env28660 == env28661) = true)

def env28662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11577,65536,131072,9293,1025,11576,92462,4194304,17,3174,8192,65,4408578,19573,81007,149861,75103,4194304,257,3140,16464,513]

theorem envBound28662 : H12AffineFastState.Bounded env28662 := by
  intro p hp
  have h : env28662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28626_28662 : H12AffineEnvironment.transform 14 11577 env28626 = env28662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11577 env28626 == env28662) = true)

theorem identity28662 : scanCanonicalize (H12AffineFastState.compose env28662 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 85283) := by decide +kernel

theorem selectedBound28662 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env28663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11577,65536,85283,9293,1025,11576,92462,4194304,17,3174,8192,65,4196385,19573,81007,66630,75103,4194304,257,3140,16464,513]

theorem envBound28663 : H12AffineFastState.Bounded env28663 := by
  intro p hp
  have h : env28663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28662_28663 : H12AffineEnvironment.transform 16 85283 env28662 = env28663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 85283 env28662 == env28663) = true)

theorem identity28663 : scanCanonicalize (H12AffineFastState.compose env28663 (packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound28663 : packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS < 2^1333 := by decide +kernel

def env28664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,8192,16384,8541,65536,82247,9293,1025,8540,91466,4194304,17,2,8192,65,4195397,16401,77835,66630,75103,4194304,257,32,16464,513]

theorem envBound28664 : H12AffineFastState.Bounded env28664 := by
  intro p hp
  have h : env28664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28663_28664 : H12AffineEnvironment.transform 10 1124 env28663 = env28664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env28663 == env28664) = true)

def env28665 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,8192,16384,8461,65536,82199,9245,1025,8460,91418,4194304,17,2,8192,17,4195349,16401,77835,66582,75023,4194304,257,32,16384,513]

theorem envBound28665 : H12AffineFastState.Bounded env28665 := by
  intro p hp
  have h : env28665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28664_28665 : H12AffineEnvironment.transform 5 16 env28664 = env28665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28664 == env28665) = true)

theorem identity28665 : scanCanonicalize (H12AffineFastState.compose env28665 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound28665 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28666 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,268,16384,1,65536,82199,1297,1025,0,82966,4194304,17,2,268,17,4195349,16401,69895,66582,66563,4194304,257,32,16384,513]

theorem envBound28666 : H12AffineFastState.Bounded env28666 := by
  intro p hp
  have h : env28666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28665_28666 : H12AffineEnvironment.transform 12 268 env28665 = env28666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env28665 == env28666) = true)

theorem identity28666 : scanCanonicalize (H12AffineFastState.compose env28666 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound28666 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env28667 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,268,16384,1,65536,82199,1297,1025,0,82966,32,17,2,268,17,1077,16401,69895,66582,66563,32,257,32,16384,513]

theorem envBound28667 : H12AffineFastState.Bounded env28667 := by
  intro p hp
  have h : env28667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28666_28667 : H12AffineEnvironment.transform 21 32 env28666 = env28667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env28666 == env28667) = true)

theorem identity28667 : scanCanonicalize (H12AffineFastState.compose env28667 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound28667 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28668 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,268,16384,1,262,16401,1297,1025,0,17680,32,17,2,268,17,1077,16401,4097,1296,1285,32,257,32,16384,513]

theorem envBound28668 : H12AffineFastState.Bounded env28668 := by
  intro p hp
  have h : env28668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28667_28668 : H12AffineEnvironment.transform 15 262 env28667 = env28668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env28667 == env28668) = true)

theorem identity28668 : scanCanonicalize (H12AffineFastState.compose env28668 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound28668 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28669 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,268,1296,1,262,1281,1297,1025,0,0,32,17,2,268,17,1077,1281,4097,1296,1285,32,257,32,1296,513]

theorem envBound28669 : H12AffineFastState.Bounded env28669 := by
  intro p hp
  have h : env28669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28668_28669 : H12AffineEnvironment.transform 13 1296 env28668 = env28669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env28668 == env28669) = true)

theorem identity28669 : scanCanonicalize (H12AffineFastState.compose env28669 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 794) := by decide +kernel

theorem selectedBound28669 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28670 : List Nat := [2,4,8,16,32,16,8,256,512,794,814,4096,268,522,1,262,539,523,795,0,0,32,17,2,268,17,815,539,4097,522,543,32,257,32,522,513]

theorem envBound28670 : H12AffineFastState.Bounded env28670 := by
  intro p hp
  have h : env28670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28669_28670 : H12AffineEnvironment.transform 9 794 env28669 = env28670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 794 env28669 == env28670) = true)

theorem identity28670 : scanCanonicalize (H12AffineFastState.compose env28670 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound28670 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28671 : List Nat := [2,4,8,16,32,16,8,5,512,543,555,4096,9,522,1,3,539,523,542,0,0,32,17,2,9,17,554,539,4097,522,543,32,4,32,522,513]

theorem envBound28671 : H12AffineFastState.Bounded env28671 := by
  intro p hp
  have h : env28671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28670_28671 : H12AffineEnvironment.transform 7 5 env28670 = env28671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env28670 == env28671) = true)

theorem identity28671 : scanCanonicalize (H12AffineFastState.compose env28671 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound28671 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28672 : List Nat := [2,4,8,16,32,16,8,5,512,543,555,17,9,522,1,3,539,523,542,0,0,32,17,2,9,17,554,539,16,522,543,32,4,32,522,513]

theorem envBound28672 : H12AffineFastState.Bounded env28672 := by
  intro p hp
  have h : env28672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28671_28672 : H12AffineEnvironment.transform 11 17 env28671 = env28672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env28671 == env28672) = true)

theorem identity28672 : scanCanonicalize (H12AffineFastState.compose env28672 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound28672 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28673 : List Nat := [2,4,8,16,32,16,8,5,10,21,33,17,9,0,1,3,17,1,20,0,0,32,17,2,9,17,32,17,16,0,21,32,4,32,0,11]

theorem envBound28673 : H12AffineFastState.Bounded env28673 := by
  intro p hp
  have h : env28673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28672_28673 : H12AffineEnvironment.transform 8 10 env28672 = env28673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env28672 == env28673) = true)

theorem identity28673 : scanCanonicalize (H12AffineFastState.compose env28673 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28673 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env28674 : List Nat := [2,4,8,16,0,16,8,5,10,21,1,17,9,0,1,3,17,1,20,0,0,0,17,2,9,17,0,17,16,0,21,0,4,0,0,11]

theorem envBound28674 : H12AffineFastState.Bounded env28674 := by
  intro p hp
  have h : env28674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28673_28674 : H12AffineEnvironment.transform 4 0 env28673 = env28674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28673 == env28674) = true)

theorem identity28674 : scanCanonicalize (H12AffineFastState.compose env28674 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound28674 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28675 : List Nat := [2,4,8,14,0,14,8,5,10,11,1,15,9,0,1,3,15,1,10,0,0,0,15,2,9,15,0,15,14,0,11,0,4,0,0,11]

theorem envBound28675 : H12AffineFastState.Bounded env28675 := by
  intro p hp
  have h : env28675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28674_28675 : H12AffineEnvironment.transform 3 14 env28674 = env28675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env28674 == env28675) = true)

theorem identity28675 : scanCanonicalize (H12AffineFastState.compose env28675 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound28675 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28676 : List Nat := [2,4,0,6,0,6,0,5,2,3,1,7,1,0,1,3,7,1,2,0,0,0,7,2,1,7,0,7,6,0,3,0,4,0,0,3]

theorem envBound28676 : H12AffineFastState.Bounded env28676 := by
  intro p hp
  have h : env28676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28675_28676 : H12AffineEnvironment.transform 2 0 env28675 = env28676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env28675 == env28676) = true)

def env28677 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,8192,16384,8460,65536,82198,9244,1025,8461,91419,4194304,17,2,8192,16,4195348,16401,77835,66583,75022,4194304,257,32,16385,513]

theorem envBound28677 : H12AffineFastState.Bounded env28677 := by
  intro p hp
  have h : env28677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28664_28677 : H12AffineEnvironment.transform 5 17 env28664 = env28677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28664 == env28677) = true)

theorem identity28677 : scanCanonicalize (H12AffineFastState.compose env28677 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound28677 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28678 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,8192,16384,8460,263,16401,9244,1025,8461,25628,4194304,17,2,8192,16,4195348,16401,12556,1296,9225,4194304,257,32,16385,513]

theorem envBound28678 : H12AffineFastState.Bounded env28678 := by
  intro p hp
  have h : env28678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28677_28678 : H12AffineEnvironment.transform 15 263 env28677 = env28678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env28677 == env28678) = true)

theorem identity28678 : scanCanonicalize (H12AffineFastState.compose env28678 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound28678 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env28679 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,8192,16384,8460,263,16401,9244,1025,8461,25628,32,17,2,8192,16,1076,16401,12556,1296,9225,32,257,32,16385,513]

theorem envBound28679 : H12AffineFastState.Bounded env28679 := by
  intro p hp
  have h : env28679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28678_28679 : H12AffineEnvironment.transform 21 32 env28678 = env28679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env28678 == env28679) = true)

theorem identity28679 : scanCanonicalize (H12AffineFastState.compose env28679 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound28679 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env28680 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,8192,1076,8460,263,1061,9244,1025,8461,8232,32,17,2,8192,16,1076,1061,12556,1296,9225,32,257,32,1077,513]

theorem envBound28680 : H12AffineFastState.Bounded env28680 := by
  intro p hp
  have h : env28680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28679_28680 : H12AffineEnvironment.transform 13 1076 env28679 = env28680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env28679 == env28680) = true)

theorem identity28680 : scanCanonicalize (H12AffineFastState.compose env28680 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28680 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28681 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,269,1076,1,263,1061,1297,1025,0,293,32,17,2,269,16,1076,1061,4097,1296,1284,32,257,32,1077,513]

theorem envBound28681 : H12AffineFastState.Bounded env28681 := by
  intro p hp
  have h : env28681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28680_28681 : H12AffineEnvironment.transform 12 269 env28680 = env28681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28680 == env28681) = true)

theorem identity28681 : scanCanonicalize (H12AffineFastState.compose env28681 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound28681 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28682 : List Nat := [2,4,8,16,32,17,8,256,512,53,0,4096,269,1,1,263,16,292,52,0,293,32,17,2,269,16,1,16,4097,293,305,32,257,32,0,513]

theorem envBound28682 : H12AffineFastState.Bounded env28682 := by
  intro p hp
  have h : env28682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28681_28682 : H12AffineEnvironment.transform 9 53 env28681 = env28682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env28681 == env28682) = true)

theorem identity28682 : scanCanonicalize (H12AffineFastState.compose env28682 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 302) := by decide +kernel

theorem selectedBound28682 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28683 : List Nat := [2,4,8,16,32,17,8,256,302,53,0,4096,269,1,1,263,16,292,52,0,293,32,17,2,269,16,1,16,4097,293,305,32,257,32,0,303]

theorem envBound28683 : H12AffineFastState.Bounded env28683 := by
  intro p hp
  have h : env28683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28682_28683 : H12AffineEnvironment.transform 8 302 env28682 = env28683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 302 env28682 == env28683) = true)

theorem identity28683 : scanCanonicalize (H12AffineFastState.compose env28683 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound28683 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28684 : List Nat := [2,4,8,16,32,17,8,256,302,53,0,276,269,1,1,263,16,292,52,0,293,32,17,2,269,16,1,16,277,293,305,32,257,32,0,303]

theorem envBound28684 : H12AffineFastState.Bounded env28684 := by
  intro p hp
  have h : env28684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28683_28684 : H12AffineEnvironment.transform 11 276 env28683 = env28684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env28683 == env28684) = true)

def env28685 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8193,65,4450363,10857535,10507600,8830976,371755,15027571,257,2485279,2428211,297844]

theorem envBound28685 : H12AffineFastState.Bounded env28685 := by
  intro p hp
  have h : env28685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28611_28685 : H12AffineEnvironment.transform 6 9 env28611 = env28685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28611 == env28685) = true)

theorem identity28685 : scanCanonicalize (H12AffineFastState.compose env28685 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound28685 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env28686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,2097152,4194304,8388608,8661050,8193,65,4229153,10857535,10507600,8757274,371755,15027571,257,2485279,2428211,297844]

theorem envBound28686 : H12AffineFastState.Bounded env28686 := by
  intro p hp
  have h : env28686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28685_28686 : H12AffineEnvironment.transform 16 90138 env28685 = env28686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env28685 == env28686) = true)

def env28687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,4194304,8388608,8429902,8193,65,4229153,10560843,10507600,8464750,75103,14795783,257,2188651,2196551,512]

theorem envBound28687 : H12AffineFastState.Bounded env28687 := by
  intro p hp
  have h : env28687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28686_28687 : H12AffineEnvironment.transform 17 35188 env28686 = env28687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env28686 == env28687) = true)

theorem identity28687 : scanCanonicalize (H12AffineFastState.compose env28687 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17460) := by decide +kernel

theorem selectedBound28687 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28688 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,17460,4194304,8388608,8429902,8193,65,4229153,8479103,8393060,8464750,75103,12681267,257,74079,114803,512]

theorem envBound28688 : H12AffineFastState.Bounded env28688 := by
  intro p hp
  have h : env28688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28687_28688 : H12AffineEnvironment.transform 20 17460 env28687 = env28688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17460 env28687 == env28688) = true)

theorem identity28688 : scanCanonicalize (H12AffineFastState.compose env28688 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 21604) := by decide +kernel

theorem selectedBound28688 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,17460,4194304,21604,62762,8193,65,4229153,79131,17664,97546,75103,4314199,257,74079,114803,512]

theorem envBound28689 : H12AffineFastState.Bounded env28689 := by
  intro p hp
  have h : env28689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28688_28689 : H12AffineEnvironment.transform 22 21604 env28688 = env28689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21604 env28688 == env28689) = true)

theorem identity28689 : scanCanonicalize (H12AffineFastState.compose env28689 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 62729) := by decide +kernel

theorem selectedBound28689 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env28690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,17460,62729,21604,62762,8193,65,32040,79131,17664,97546,75103,74078,257,74079,114803,512]

theorem envBound28690 : H12AffineFastState.Bounded env28690 := by
  intro p hp
  have h : env28690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28689_28690 : H12AffineEnvironment.transform 21 62729 env28689 = env28690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62729 env28689 == env28690) = true)

theorem identity28690 : scanCanonicalize (H12AffineFastState.compose env28690 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28690 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env28691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35188,1025,32769,17460,62729,21604,62762,8193,65,32040,5392,17664,23809,1364,341,257,340,57464,512]

theorem envBound28691 : H12AffineFastState.Bounded env28691 := by
  intro p hp
  have h : env28691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28690_28691 : H12AffineEnvironment.transform 15 8203 env28690 = env28691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28690 == env28691) = true)

theorem identity28691 : scanCanonicalize (H12AffineFastState.compose env28691 (packedSelected [0,7,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8573) := by decide +kernel

theorem selectedBound28691 : packedSelected [0,7,17,20] rootPS < 2^1333 := by decide +kernel

def env28692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8573,8203,16401,10249,1025,8572,17460,21620,21604,21591,8193,65,32040,5392,17664,23809,1364,341,257,340,16645,512]

theorem envBound28692 : H12AffineFastState.Bounded env28692 := by
  intro p hp
  have h : env28692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28691_28692 : H12AffineEnvironment.transform 14 8573 env28691 = env28692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8573 env28691 == env28692) = true)

theorem identity28692 : scanCanonicalize (H12AffineFastState.compose env28692 (packedSelected [3,5,6,10,12,14,15,21] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound28692 : packedSelected [3,5,6,10,12,14,15,21] rootPS < 2^1333 := by decide +kernel

def env28693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5124,8573,8203,5141,10249,1025,8572,4144,112,96,83,8193,65,10540,5392,4356,2309,1364,341,257,340,5377,512]

theorem envBound28693 : H12AffineFastState.Bounded env28693 := by
  intro p hp
  have h : env28693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28692_28693 : H12AffineEnvironment.transform 13 5124 env28692 = env28693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env28692 == env28693) = true)

theorem identity28693 : scanCanonicalize (H12AffineFastState.compose env28693 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound28693 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env28694 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,381,5124,0,374,5141,2420,1025,1,4144,112,96,83,380,65,2129,5392,4356,2309,1364,341,257,340,5377,512]

theorem envBound28694 : H12AffineFastState.Bounded env28694 := by
  intro p hp
  have h : env28694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28693_28694 : H12AffineEnvironment.transform 12 381 env28693 = env28694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env28693 == env28694) = true)

theorem identity28694 : scanCanonicalize (H12AffineFastState.compose env28694 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28694 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env28695 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,349,5124,0,342,5141,2388,1025,1,4112,80,64,83,348,65,2129,5392,4356,2309,1364,341,257,340,5377,512]

theorem envBound28695 : H12AffineFastState.Bounded env28695 := by
  intro p hp
  have h : env28695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28694_28695 : H12AffineEnvironment.transform 4 0 env28694 = env28695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28694 == env28695) = true)

theorem identity28695 : scanCanonicalize (H12AffineFastState.compose env28695 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28695 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28696 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,268,5124,0,263,5141,2309,1025,1,4112,1,17,2,269,16,2048,5392,4356,2309,1285,260,257,261,5377,512]

theorem envBound28696 : H12AffineFastState.Bounded env28696 := by
  intro p hp
  have h : env28696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28695_28696 : H12AffineEnvironment.transform 5 17 env28695 = env28696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28695 == env28696) = true)

theorem identity28696 : scanCanonicalize (H12AffineFastState.compose env28696 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1054) := by decide +kernel

theorem selectedBound28696 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28697 : List Nat := [2,4,8,16,0,17,9,256,512,1024,1054,4096,268,5124,0,263,5141,1307,1025,1,4112,1,17,2,269,16,1054,5392,4356,1307,1285,260,257,261,5377,512]

theorem envBound28697 : H12AffineFastState.Bounded env28697 := by
  intro p hp
  have h : env28697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28696_28697 : H12AffineEnvironment.transform 10 1054 env28696 = env28697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1054 env28696 == env28697) = true)

theorem identity28697 : scanCanonicalize (H12AffineFastState.compose env28697 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound28697 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28698 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1054,4096,8,5124,0,3,5141,1055,1025,1,4112,1,17,2,9,16,1054,5140,4096,1055,1025,0,5,1,5125,512]

theorem envBound28698 : H12AffineFastState.Bounded env28698 := by
  intro p hp
  have h : env28698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28697_28698 : H12AffineEnvironment.transform 7 4 env28697 = env28698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env28697 == env28698) = true)

theorem identity28698 : scanCanonicalize (H12AffineFastState.compose env28698 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound28698 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28699 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1054,1,8,1029,0,3,1044,1055,1025,1,17,1,17,2,9,16,1054,1045,1,1055,1025,0,5,1,1028,512]

theorem envBound28699 : H12AffineFastState.Bounded env28699 := by
  intro p hp
  have h : env28699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28698_28699 : H12AffineEnvironment.transform 11 1 env28698 = env28699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env28698 == env28699) = true)

theorem identity28699 : scanCanonicalize (H12AffineFastState.compose env28699 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound28699 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28700 : List Nat := [2,4,8,16,0,17,9,4,11,1024,1054,1,8,1029,0,3,1044,1055,1025,1,17,1,17,2,9,16,1054,1045,1,1055,1025,0,5,1,1028,11]

theorem envBound28700 : H12AffineFastState.Bounded env28700 := by
  intro p hp
  have h : env28700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28699_28700 : H12AffineEnvironment.transform 8 11 env28699 = env28700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env28699 == env28700) = true)

theorem identity28700 : scanCanonicalize (H12AffineFastState.compose env28700 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound28700 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28701 : List Nat := [2,4,8,12,0,13,9,4,11,1024,1026,1,8,1029,0,3,1032,1027,1025,1,13,1,13,2,9,12,1026,1033,1,1027,1025,0,5,1,1028,11]

theorem envBound28701 : H12AffineFastState.Bounded env28701 := by
  intro p hp
  have h : env28701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28700_28701 : H12AffineEnvironment.transform 3 12 env28700 = env28701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env28700 == env28701) = true)

theorem identity28701 : scanCanonicalize (H12AffineFastState.compose env28701 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28701 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28702 : List Nat := [2,4,4,0,0,1,5,4,7,1024,1026,1,4,1029,0,3,1028,1027,1025,1,1,1,1,2,5,0,1026,1029,1,1027,1025,0,5,1,1028,7]

theorem envBound28702 : H12AffineFastState.Bounded env28702 := by
  intro p hp
  have h : env28702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28701_28702 : H12AffineEnvironment.transform 2 4 env28701 = env28702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28701 == env28702) = true)

theorem identity28702 : scanCanonicalize (H12AffineFastState.compose env28702 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound28702 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28703 : List Nat := [2,4,4,0,0,1,5,4,7,0,2,1,4,5,0,3,4,3,1,1,1,1,1,2,5,0,2,5,1,3,1,0,5,1,4,7]

theorem envBound28703 : H12AffineFastState.Bounded env28703 := by
  intro p hp
  have h : env28703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28702_28703 : H12AffineEnvironment.transform 9 0 env28702 = env28703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env28702 == env28703) = true)

theorem identity28703 : scanCanonicalize (H12AffineFastState.compose env28703 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound28703 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env28704 : List Nat := [2,1,1,0,0,1,0,1,2,0,2,1,1,0,0,3,1,3,1,1,1,1,1,2,0,0,2,0,1,3,1,0,0,1,1,2]

theorem envBound28704 : H12AffineFastState.Bounded env28704 := by
  intro p hp
  have h : env28704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28703_28704 : H12AffineEnvironment.transform 1 1 env28703 = env28704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env28703 == env28704) = true)

def env28705 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,4194304,8388608,8429903,8193,65,4229153,10560842,10507600,8464751,75102,14795782,257,2188650,2196550,513]

theorem envBound28705 : H12AffineFastState.Bounded env28705 := by
  intro p hp
  have h : env28705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28686_28705 : H12AffineEnvironment.transform 17 35189 env28686 = env28705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env28686 == env28705) = true)

def env28706 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,4194304,16,41311,8193,65,4229153,2172250,2118976,76159,75102,6407190,257,2188650,2196550,513]

theorem envBound28706 : H12AffineFastState.Bounded env28706 := by
  intro p hp
  have h : env28706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28705_28706 : H12AffineEnvironment.transform 22 16 env28705 = env28706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env28705 == env28706) = true)

theorem identity28706 : scanCanonicalize (H12AffineFastState.compose env28706 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound28706 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env28707 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1025,29005,2097152,4194304,16,20499,8193,65,4225389,2172250,2118976,76159,75102,6370650,257,2188650,2192650,513]

theorem envBound28707 : H12AffineFastState.Bounded env28707 := by
  intro p hp
  have h : env28707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28706_28707 : H12AffineEnvironment.transform 14 29004 env28706 = env28707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env28706 == env28707) = true)

def env28708 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1025,29005,5456,4194304,16,20499,8193,65,4225389,77834,16400,76159,75102,4268042,257,94266,90202,513]

theorem envBound28708 : H12AffineFastState.Bounded env28708 := by
  intro p hp
  have h : env28708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28707_28708 : H12AffineEnvironment.transform 20 5456 env28707 = env28708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env28707 == env28708) = true)

theorem identity28708 : scanCanonicalize (H12AffineFastState.compose env28708 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound28708 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28709 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1025,29005,5456,73770,16,20499,8193,65,88391,77834,16400,76159,75102,32,257,94266,90202,513]

theorem envBound28709 : H12AffineFastState.Bounded env28709 := by
  intro p hp
  have h : env28709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28708_28709 : H12AffineEnvironment.transform 21 73770 env28708 = env28709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env28708 == env28709) = true)

theorem identity28709 : scanCanonicalize (H12AffineFastState.compose env28709 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound28709 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28710 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8541,65536,77835,10280,1025,8540,5456,73770,16,2,8193,65,67926,77834,4097,76159,75102,32,257,73771,77899,513]

theorem envBound28710 : H12AffineFastState.Bounded env28710 := by
  intro p hp
  have h : env28710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28709_28710 : H12AffineEnvironment.transform 13 4113 env28709 = env28710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env28709 == env28710) = true)

theorem identity28710 : scanCanonicalize (H12AffineFastState.compose env28710 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 7458) := by decide +kernel

theorem selectedBound28710 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env28711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8541,7458,11561,10280,1025,8540,5456,15624,16,2,8193,65,5236,11560,4097,13405,14460,32,257,15625,11625,513]

theorem envBound28711 : H12AffineFastState.Bounded env28711 := by
  intro p hp
  have h : env28711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28710_28711 : H12AffineEnvironment.transform 15 7458 env28710 = env28711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7458 env28710 == env28711) = true)

def env28712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1025,29005,5457,4194304,16,20499,8193,65,4225389,77835,16401,76159,75102,4268043,257,94267,90203,513]

theorem envBound28712 : H12AffineFastState.Bounded env28712 := by
  intro p hp
  have h : env28712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28707_28712 : H12AffineEnvironment.transform 20 5457 env28707 = env28712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env28707 == env28712) = true)

theorem identity28712 : scanCanonicalize (H12AffineFastState.compose env28712 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 94266) := by decide +kernel

theorem selectedBound28712 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28713 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1025,29005,5457,94266,16,20499,8193,65,67927,77835,16401,76159,75102,20529,257,94267,90203,513]

theorem envBound28713 : H12AffineFastState.Bounded env28713 := by
  intro p hp
  have h : env28713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28712_28713 : H12AffineEnvironment.transform 21 94266 env28712 = env28713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 94266 env28712 == env28713) = true)

theorem identity28713 : scanCanonicalize (H12AffineFastState.compose env28713 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28713 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28714 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,8203,16401,30777,1025,29005,5457,20529,16,20499,8193,65,10588,4096,16401,2420,1365,20529,257,20528,16464,513]

theorem envBound28714 : H12AffineFastState.Bounded env28714 := by
  intro p hp
  have h : env28714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28713_28714 : H12AffineEnvironment.transform 15 8203 env28713 = env28714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28713 == env28714) = true)

theorem identity28714 : scanCanonicalize (H12AffineFastState.compose env28714 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound28714 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28715 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8540,8203,4097,10281,1025,8541,5457,33,16,3,8193,65,10588,4096,4097,2420,1365,33,257,32,4160,513]

theorem envBound28715 : H12AffineFastState.Bounded env28715 := by
  intro p hp
  have h : env28715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28714_28715 : H12AffineEnvironment.transform 13 4112 env28714 = env28715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env28714 == env28715) = true)

def env28716 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,4194304,17,41310,8193,65,4229153,2172251,2118977,76158,75102,6407191,257,2188650,2196550,513]

theorem envBound28716 : H12AffineFastState.Bounded env28716 := by
  intro p hp
  have h : env28716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28705_28716 : H12AffineEnvironment.transform 22 17 env28705 = env28716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env28705 == env28716) = true)

theorem identity28716 : scanCanonicalize (H12AffineFastState.compose env28716 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 46092) := by decide +kernel

theorem selectedBound28716 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env28717 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,46092,4194304,17,41310,8193,65,4229153,102743,57677,76158,75102,4288539,257,119142,77898,513]

theorem envBound28717 : H12AffineFastState.Bounded env28717 := by
  intro p hp
  have h : env28717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28716_28717 : H12AffineEnvironment.transform 20 46092 env28716 = env28717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46092 env28716 == env28717) = true)

theorem identity28717 : scanCanonicalize (H12AffineFastState.compose env28717 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound28717 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env28718 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10280,1025,8540,5457,4194304,17,3,8193,65,4204924,77834,16400,76158,75102,4288539,257,94267,77898,513]

theorem envBound28718 : H12AffineFastState.Bounded env28718 := by
  intro p hp
  have h : env28718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28717_28718 : H12AffineEnvironment.transform 14 8541 env28717 = env28718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env28717 == env28718) = true)

theorem identity28718 : scanCanonicalize (H12AffineFastState.compose env28718 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound28718 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env28719 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,20759,12557,10280,1025,8540,5457,4194304,17,3,8193,65,4204924,24861,16400,30825,29769,4202764,257,8492,24925,513]

theorem envBound28719 : H12AffineFastState.Bounded env28719 := by
  intro p hp
  have h : env28719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28718_28719 : H12AffineEnvironment.transform 15 20759 env28718 = env28719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env28718 == env28719) = true)

theorem identity28719 : scanCanonicalize (H12AffineFastState.compose env28719 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound28719 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env28720 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,16384,1124,20759,5172,3345,1025,1125,5457,4194304,17,3,1336,65,4197445,17444,16400,23888,20848,4195381,257,1045,17508,513]

theorem envBound28720 : H12AffineFastState.Bounded env28720 := by
  intro p hp
  have h : env28720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28719_28720 : H12AffineEnvironment.transform 12 1337 env28719 = env28720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env28719 == env28720) = true)

theorem identity28720 : scanCanonicalize (H12AffineFastState.compose env28720 (packedSelected [0,7,14,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 7252) := by decide +kernel

theorem selectedBound28720 : packedSelected [0,7,14,17,18] rootPS < 2^1333 := by decide +kernel

def env28721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,16384,1124,20759,5172,3345,1025,1125,5457,7252,17,3,1336,65,4113,17444,16400,23888,20848,6241,257,1045,17508,513]

theorem envBound28721 : H12AffineFastState.Bounded env28721 := by
  intro p hp
  have h : env28721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28720_28721 : H12AffineEnvironment.transform 21 7252 env28720 = env28721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 7252 env28720 == env28721) = true)

theorem identity28721 : scanCanonicalize (H12AffineFastState.compose env28721 (packedSelected [0,1,3,4,5,7,8,9,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound28721 : packedSelected [0,1,3,4,5,7,8,9,14,23] rootPS < 2^1333 := by decide +kernel

def env28722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,5157,1124,1330,5172,3345,1025,1125,5457,7252,17,3,1336,65,4113,4097,5173,2421,1365,6241,257,1045,4161,513]

theorem envBound28722 : H12AffineFastState.Bounded env28722 := by
  intro p hp
  have h : env28722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28721_28722 : H12AffineEnvironment.transform 13 5157 env28721 = env28722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env28721 == env28722) = true)

theorem identity28722 : scanCanonicalize (H12AffineFastState.compose env28722 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound28722 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env28723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3189,1337,2128,1124,1330,2113,3345,1025,1125,2340,33,17,3,1336,65,3172,3188,2112,2421,1365,1044,257,1045,3124,513]

theorem envBound28723 : H12AffineFastState.Bounded env28723 := by
  intro p hp
  have h : env28723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28722_28723 : H12AffineEnvironment.transform 11 3189 env28722 = env28723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env28722 == env28723) = true)

theorem identity28723 : scanCanonicalize (H12AffineFastState.compose env28723 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound28723 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env28724 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2065,349,2128,0,342,2113,2421,101,1,2340,33,17,3,348,65,2048,2064,2112,2421,305,112,257,113,2128,513]

theorem envBound28724 : H12AffineFastState.Bounded env28724 := by
  intro p hp
  have h : env28724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28723_28724 : H12AffineEnvironment.transform 9 100 env28723 = env28724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env28723 == env28724) = true)

theorem identity28724 : scanCanonicalize (H12AffineFastState.compose env28724 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28724 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28725 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,2065,269,2048,0,262,2065,2341,53,1,2340,33,17,3,268,17,2048,2064,2064,2341,305,32,257,33,2048,513]

theorem envBound28725 : H12AffineFastState.Bounded env28725 := by
  intro p hp
  have h : env28725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28724_28725 : H12AffineEnvironment.transform 5 16 env28724 = env28725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28724 == env28725) = true)

theorem identity28725 : scanCanonicalize (H12AffineFastState.compose env28725 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 772) := by decide +kernel

theorem selectedBound28725 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28726 : List Nat := [2,4,8,16,32,16,9,256,512,52,772,789,269,772,0,262,789,545,53,1,544,33,17,3,268,17,772,788,788,545,305,32,257,33,772,513]

theorem envBound28726 : H12AffineFastState.Bounded env28726 := by
  intro p hp
  have h : env28726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28725_28726 : H12AffineEnvironment.transform 10 772 env28725 = env28726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 772 env28725 == env28726) = true)

def env28727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356288,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound28727 : H12AffineFastState.Bounded env28727 := by
  intro p hp
  have h : env28727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28391_28727 : H12AffineEnvironment.transform 26 30393345 env28391 = env28727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env28391 == env28727) = true)

def env28728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound28728 : H12AffineFastState.Bounded env28728 := by
  intro p hp
  have h : env28728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28727_28728 : H12AffineEnvironment.transform 18 1024 env28727 = env28728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env28727 == env28728) = true)

theorem identity28728 : scanCanonicalize (H12AffineFastState.compose env28728 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2534779) := by decide +kernel

theorem selectedBound28728 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env28729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2534779,8328,65,14773626,469494,10507600,8830976,10955114,4704442,256,8874455,8882290,10882749]

theorem envBound28729 : H12AffineFastState.Bounded env28729 := by
  intro p hp
  have h : env28729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28728_28729 : H12AffineEnvironment.transform 23 2534779 env28728 = env28729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2534779 env28728 == env28729) = true)

def env28730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,8388608,2114883,8328,65,14773626,115150,10507600,8398904,10600786,4268162,256,8487407,8478794,10544773]

theorem envBound28730 : H12AffineFastState.Bounded env28730 := by
  intro p hp
  have h : env28730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28729_28730 : H12AffineEnvironment.transform 17 190520 env28729 = env28730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env28729 == env28730) = true)

def env28731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,2101328,2114883,8328,65,4291882,115150,17664,2111592,119042,4268162,256,2199999,2191386,63189]

theorem envBound28731 : H12AffineFastState.Bounded env28731 := by
  intro p hp
  have h : env28731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28730_28731 : H12AffineEnvironment.transform 22 2101328 env28730 = env28731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env28730 == env28731) = true)

def env28732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,21763,8328,65,4291882,115150,17664,10280,119042,4268162,256,98815,90202,63189]

theorem envBound28732 : H12AffineFastState.Bounded env28732 := by
  intro p hp
  have h : env28732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28731_28732 : H12AffineEnvironment.transform 20 4160 env28731 = env28732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28731 == env28732) = true)

theorem identity28732 : scanCanonicalize (H12AffineFastState.compose env28732 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28732 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4160,4194304,16,21763,8328,65,4218144,57796,17664,10280,61704,4194440,256,41461,16464,63189]

theorem envBound28733 : H12AffineFastState.Bounded env28733 := by
  intro p hp
  have h : env28733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28732_28733 : H12AffineEnvironment.transform 15 8202 env28732 = env28733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28732 == env28733) = true)

def env28734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4160,4194304,16,21763,8192,65,4218144,57676,17664,10280,61704,4194304,256,41341,16464,63069]

theorem envBound28734 : H12AffineFastState.Bounded env28734 := by
  intro p hp
  have h : env28734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28733_28734 : H12AffineEnvironment.transform 6 8 env28733 = env28734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28733 == env28734) = true)

theorem identity28734 : scanCanonicalize (H12AffineFastState.compose env28734 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound28734 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,13389,56437,1024,32769,4160,4194304,16,21763,8192,65,4218144,57676,17664,10280,61704,4194304,256,41341,16464,63069]

theorem envBound28735 : H12AffineFastState.Bounded env28735 := by
  intro p hp
  have h : env28735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28734_28735 : H12AffineEnvironment.transform 16 13389 env28734 = env28735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env28734 == env28735) = true)

theorem identity28735 : scanCanonicalize (H12AffineFastState.compose env28735 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(21+1) ^^^ 29820) := by decide +kernel

theorem selectedBound28735 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env28736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,13389,56437,1024,32769,4160,29820,16,21763,8192,65,10588,57676,17664,10280,61704,29820,256,41341,16464,63069]

theorem envBound28736 : H12AffineFastState.Bounded env28736 := by
  intro p hp
  have h : env28736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28735_28736 : H12AffineEnvironment.transform 21 29820 env28735 = env28736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29820 env28735 == env28736) = true)

theorem identity28736 : scanCanonicalize (H12AffineFastState.compose env28736 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound28736 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env28737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,8202,13389,23589,1024,81,4160,29820,16,21763,8192,65,10588,24860,17664,10280,29016,29820,256,8493,16464,30221]

theorem envBound28737 : H12AffineFastState.Bounded env28737 := by
  intro p hp
  have h : env28737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28736_28737 : H12AffineEnvironment.transform 14 80 env28736 = env28737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env28736 == env28737) = true)

theorem identity28737 : scanCanonicalize (H12AffineFastState.compose env28737 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound28737 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env28738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,80,262,5441,23589,1024,81,4160,21872,16,21763,268,65,2128,16400,17664,2340,20564,21872,256,33,16464,22273]

theorem envBound28738 : H12AffineFastState.Bounded env28738 := by
  intro p hp
  have h : env28738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28737_28738 : H12AffineEnvironment.transform 12 268 env28737 = env28738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env28737 == env28738) = true)

theorem identity28738 : scanCanonicalize (H12AffineFastState.compose env28738 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28738 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env28739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,80,262,5441,2340,1024,81,4160,113,16,2,268,65,2128,5393,4097,2340,1365,113,256,33,5457,512]

theorem envBound28739 : H12AffineFastState.Bounded env28739 := by
  intro p hp
  have h : env28739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28738_28739 : H12AffineEnvironment.transform 13 5377 env28738 = env28739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28738 == env28739) = true)

theorem identity28739 : scanCanonicalize (H12AffineFastState.compose env28739 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound28739 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28740 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,268,5377,32,262,5425,2340,1024,33,4144,1,16,2,268,49,2080,5393,4097,2340,1317,1,256,33,5409,512]

theorem envBound28740 : H12AffineFastState.Bounded env28740 := by
  intro p hp
  have h : env28740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28739_28740 : H12AffineEnvironment.transform 5 48 env28739 = env28740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env28739 == env28740) = true)

theorem identity28740 : scanCanonicalize (H12AffineFastState.compose env28740 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound28740 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28741 : List Nat := [2,4,8,16,32,48,8,256,512,305,2048,4096,268,4144,32,262,4096,2340,305,33,4144,1,16,2,268,49,2080,4128,4097,2340,20,1,256,33,4112,512]

theorem envBound28741 : H12AffineFastState.Bounded env28741 := by
  intro p hp
  have h : env28741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28740_28741 : H12AffineEnvironment.transform 9 305 env28740 = env28741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env28740 == env28741) = true)

theorem identity28741 : scanCanonicalize (H12AffineFastState.compose env28741 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2341) := by decide +kernel

theorem selectedBound28741 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env28742 : List Nat := [2,4,8,16,32,48,8,256,512,305,2048,2341,268,2325,32,262,2341,2340,305,33,2325,1,16,2,268,49,2080,2309,2340,2340,20,1,256,33,2357,512]

theorem envBound28742 : H12AffineFastState.Bounded env28742 := by
  intro p hp
  have h : env28742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28741_28742 : H12AffineEnvironment.transform 11 2341 env28741 = env28742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2341 env28741 == env28742) = true)

theorem identity28742 : scanCanonicalize (H12AffineFastState.compose env28742 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound28742 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28743 : List Nat := [2,4,8,16,32,48,8,256,512,305,32,261,268,309,32,262,261,260,305,33,309,1,16,2,268,49,0,293,260,260,20,1,256,33,277,512]

theorem envBound28743 : H12AffineFastState.Bounded env28743 := by
  intro p hp
  have h : env28743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28742_28743 : H12AffineEnvironment.transform 10 32 env28742 = env28743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env28742 == env28743) = true)

theorem identity28743 : scanCanonicalize (H12AffineFastState.compose env28743 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound28743 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28744 : List Nat := [2,4,8,16,16,0,8,256,512,257,16,261,268,261,16,262,261,260,257,17,261,1,16,2,268,1,0,277,260,260,20,1,256,17,277,512]

theorem envBound28744 : H12AffineFastState.Bounded env28744 := by
  intro p hp
  have h : env28744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28743_28744 : H12AffineEnvironment.transform 4 16 env28743 = env28744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env28743 == env28744) = true)

theorem identity28744 : scanCanonicalize (H12AffineFastState.compose env28744 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28744 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28745 : List Nat := [2,4,8,1,1,0,8,256,512,257,1,261,268,261,1,262,261,260,257,0,261,1,1,2,268,1,0,260,260,260,5,1,256,0,260,512]

theorem envBound28745 : H12AffineFastState.Bounded env28745 := by
  intro p hp
  have h : env28745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28744_28745 : H12AffineEnvironment.transform 3 1 env28744 = env28745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28744 == env28745) = true)

theorem identity28745 : scanCanonicalize (H12AffineFastState.compose env28745 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound28745 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28746 : List Nat := [2,1,8,1,1,0,8,256,512,257,1,256,265,256,1,259,256,257,257,0,256,1,1,2,265,1,0,257,257,257,0,1,256,0,257,512]

theorem envBound28746 : H12AffineFastState.Bounded env28746 := by
  intro p hp
  have h : env28746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28745_28746 : H12AffineEnvironment.transform 1 1 env28745 = env28746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env28745 == env28746) = true)

def env28747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4160,4194304,16,21763,8193,65,4218144,57677,17664,10280,61704,4194305,256,41340,16464,63068]

theorem envBound28747 : H12AffineFastState.Bounded env28747 := by
  intro p hp
  have h : env28747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28733_28747 : H12AffineEnvironment.transform 6 9 env28733 = env28747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28733 == env28747) = true)

theorem identity28747 : scanCanonicalize (H12AffineFastState.compose env28747 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound28747 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,32041,1024,32769,4160,4194304,16,21763,8193,65,4218144,57677,17664,10280,61704,4194305,256,41340,16464,63068]

theorem envBound28748 : H12AffineFastState.Bounded env28748 := by
  intro p hp
  have h : env28748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28747_28748 : H12AffineEnvironment.transform 16 38161 env28747 = env28748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env28747 == env28748) = true)

theorem identity28748 : scanCanonicalize (H12AffineFastState.compose env28748 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound28748 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env28749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,32041,1024,32769,4160,41341,16,21763,8193,65,64605,57677,17664,10280,61704,41340,256,41340,16464,63068]

theorem envBound28749 : H12AffineFastState.Bounded env28749 := by
  intro p hp
  have h : env28749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28748_28749 : H12AffineEnvironment.transform 21 41341 env28748 = env28749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env28748 == env28749) = true)

theorem identity28749 : scanCanonicalize (H12AffineFastState.compose env28749 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound28749 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env28750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,343,38161,23668,1024,32769,4160,32800,16,21763,348,65,56576,49168,17664,2421,53333,32801,256,32801,16464,55041]

theorem envBound28750 : H12AffineFastState.Bounded env28750 := by
  intro p hp
  have h : env28750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28749_28750 : H12AffineEnvironment.transform 12 349 env28749 = env28750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env28749 == env28750) = true)

theorem identity28750 : scanCanonicalize (H12AffineFastState.compose env28750 (packedSelected [2,3,4,6,8,9,10,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 7498) := by decide +kernel

theorem selectedBound28750 : packedSelected [2,3,4,6,8,9,10,15,16,18] rootPS < 2^1333 := by decide +kernel

def env28751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,7498,343,2139,23668,1024,7499,4160,7530,16,21763,348,65,16458,23898,17664,2421,19743,7531,256,7531,16464,19019]

theorem envBound28751 : H12AffineFastState.Bounded env28751 := by
  intro p hp
  have h : env28751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28750_28751 : H12AffineEnvironment.transform 14 7498 env28750 = env28751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7498 env28750 == env28751) = true)

theorem identity28751 : scanCanonicalize (H12AffineFastState.compose env28751 (packedSelected [1,2,5,11,15,19] rootPS)) = affineNative (2^(13+1) ^^^ 5204) := by decide +kernel

theorem selectedBound28751 : packedSelected [1,2,5,11,15,19] rootPS < 2^1333 := by decide +kernel

def env28752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5204,7498,343,2139,2080,1024,7499,4160,7530,16,343,348,65,5150,2318,4436,2421,6475,7531,256,7531,5124,7711]

theorem envBound28752 : H12AffineFastState.Bounded env28752 := by
  intro p hp
  have h : env28752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28751_28752 : H12AffineEnvironment.transform 13 5204 env28751 = env28752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5204 env28751 == env28752) = true)

theorem identity28752 : scanCanonicalize (H12AffineFastState.compose env28752 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(11+1) ^^^ 3102) := by decide +kernel

theorem selectedBound28752 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3102,349,2122,340,343,2139,2080,1024,341,3166,372,16,343,348,65,2048,2318,3402,2421,1365,373,256,373,2074,513]

theorem envBound28753 : H12AffineFastState.Bounded env28753 := by
  intro p hp
  have h : env28753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28752_28753 : H12AffineEnvironment.transform 11 3102 env28752 = env28753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3102 env28752 == env28753) = true)

theorem identity28753 : scanCanonicalize (H12AffineFastState.compose env28753 (packedSelected [2,5,8,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound28753 : packedSelected [2,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env28754 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,3102,301,2106,292,295,2091,2080,1024,293,3118,260,16,295,300,49,2048,2318,3386,2309,1317,261,256,261,2074,513]

theorem envBound28754 : H12AffineFastState.Bounded env28754 := by
  intro p hp
  have h : env28754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28753_28754 : H12AffineEnvironment.transform 5 48 env28753 = env28754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env28753 == env28754) = true)

theorem identity28754 : scanCanonicalize (H12AffineFastState.compose env28754 (packedSelected [3,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound28754 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env28755 : List Nat := [2,4,8,16,32,48,9,14,512,1024,2048,3102,35,2106,42,41,2091,2080,1024,43,3118,10,16,41,34,49,2048,2048,3124,2059,1067,11,14,11,2074,513]

theorem envBound28755 : H12AffineFastState.Bounded env28755 := by
  intro p hp
  have h : env28755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28754_28755 : H12AffineEnvironment.transform 7 14 env28754 = env28755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env28754 == env28755) = true)

theorem identity28755 : scanCanonicalize (H12AffineFastState.compose env28755 (packedSelected [2,5,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound28755 : packedSelected [2,5,8,11] rootPS < 2^1333 := by decide +kernel

def env28756 : List Nat := [2,4,8,16,32,48,9,14,512,1024,16,1038,35,42,42,41,59,48,1024,43,1086,10,16,41,34,49,16,16,1060,27,1067,11,14,11,10,513]

theorem envBound28756 : H12AffineFastState.Bounded env28756 := by
  intro p hp
  have h : env28756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28755_28756 : H12AffineEnvironment.transform 10 16 env28755 = env28756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env28755 == env28756) = true)

theorem identity28756 : scanCanonicalize (H12AffineFastState.compose env28756 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 574) := by decide +kernel

theorem selectedBound28756 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env28757 : List Nat := [2,4,8,16,32,48,9,14,512,574,16,560,35,42,42,41,59,48,574,43,512,10,16,41,34,49,16,16,538,27,533,11,14,11,10,513]

theorem envBound28757 : H12AffineFastState.Bounded env28757 := by
  intro p hp
  have h : env28757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28756_28757 : H12AffineEnvironment.transform 9 574 env28756 = env28757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 574 env28756 == env28757) = true)

theorem identity28757 : scanCanonicalize (H12AffineFastState.compose env28757 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 25) := by decide +kernel

theorem selectedBound28757 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env28758 : List Nat := [2,4,8,16,32,48,9,14,25,39,16,41,35,42,42,41,59,48,39,43,25,10,16,41,34,49,16,16,3,27,12,11,14,11,10,24]

theorem envBound28758 : H12AffineFastState.Bounded env28758 := by
  intro p hp
  have h : env28758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28757_28758 : H12AffineEnvironment.transform 8 25 env28757 = env28758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 25 env28757 == env28758) = true)

theorem identity28758 : scanCanonicalize (H12AffineFastState.compose env28758 (packedSelected [0,2,3,8] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound28758 : packedSelected [0,2,3,8] rootPS < 2^1333 := by decide +kernel

def env28759 : List Nat := [2,4,8,13,32,45,9,14,4,39,13,41,35,42,42,41,38,45,39,43,4,10,13,41,34,44,13,13,3,6,12,11,14,11,10,5]

theorem envBound28759 : H12AffineFastState.Bounded env28759 := by
  intro p hp
  have h : env28759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28758_28759 : H12AffineEnvironment.transform 3 13 env28758 = env28759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env28758 == env28759) = true)

theorem identity28759 : scanCanonicalize (H12AffineFastState.compose env28759 (packedSelected [0,2,9] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28759 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env28760 : List Nat := [2,4,4,1,32,33,5,2,4,39,1,37,35,38,38,37,38,33,39,39,4,6,1,37,34,32,1,1,3,6,0,7,2,7,6,5]

theorem envBound28760 : H12AffineFastState.Bounded env28760 := by
  intro p hp
  have h : env28760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28759_28760 : H12AffineEnvironment.transform 2 4 env28759 = env28760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28759 == env28760) = true)

theorem identity28760 : scanCanonicalize (H12AffineFastState.compose env28760 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28760 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env28761 : List Nat := [2,3,3,1,32,33,2,2,3,32,1,34,35,33,33,34,33,33,32,32,3,1,1,34,34,32,1,1,3,1,0,0,2,0,1,2]

theorem envBound28761 : H12AffineFastState.Bounded env28761 := by
  intro p hp
  have h : env28761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28760_28761 : H12AffineEnvironment.transform 1 3 env28760 = env28761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28760 == env28761) = true)

theorem identity28761 : scanCanonicalize (H12AffineFastState.compose env28761 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28761 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28762 : List Nat := [2,3,3,1,1,0,2,2,3,1,1,3,2,0,0,3,0,0,1,1,3,1,1,3,3,1,1,1,3,1,0,0,2,0,1,2]

theorem envBound28762 : H12AffineFastState.Bounded env28762 := by
  intro p hp
  have h : env28762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28761_28762 : H12AffineEnvironment.transform 4 1 env28761 = env28762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28761 == env28762) = true)

def env28763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,17,21762,8328,65,4291882,115150,17664,10281,119042,4268162,256,98814,90203,63189]

theorem envBound28763 : H12AffineFastState.Bounded env28763 := by
  intro p hp
  have h : env28763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28731_28763 : H12AffineEnvironment.transform 20 4161 env28731 = env28763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28731 == env28763) = true)

theorem identity28763 : scanCanonicalize (H12AffineFastState.compose env28763 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254131) := by decide +kernel

theorem selectedBound28763 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,254131,17,21762,8328,65,171417,115150,17664,10281,119042,180273,256,98814,90203,63189]

theorem envBound28764 : H12AffineFastState.Bounded env28764 := by
  intro p hp
  have h : env28764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28763_28764 : H12AffineEnvironment.transform 21 254131 env28763 = env28764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254131 env28763 == env28764) = true)

def env28765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,254011,17,21762,8192,65,171281,115014,17664,10281,119042,180273,256,98678,90203,63069]

theorem envBound28765 : H12AffineFastState.Bounded env28765 := by
  intro p hp
  have h : env28765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28764_28765 : H12AffineEnvironment.transform 6 8 env28764 = env28765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28764 == env28765) = true)

theorem identity28765 : scanCanonicalize (H12AffineFastState.compose env28765 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound28765 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,138340,1024,29789,4161,201831,17,21762,8192,65,158029,79130,17664,10281,75102,144493,256,95530,90203,513]

theorem envBound28766 : H12AffineFastState.Bounded env28766 := by
  intro p hp
  have h : env28766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28765_28766 : H12AffineEnvironment.transform 14 29788 env28765 = env28766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env28765 == env28766) = true)

theorem identity28766 : scanCanonicalize (H12AffineFastState.compose env28766 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound28766 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,97406,1024,29789,4161,29821,17,21762,8192,65,67927,79130,17664,10281,75102,87159,256,95530,90203,513]

theorem envBound28767 : H12AffineFastState.Bounded env28767 := by
  intro p hp
  have h : env28767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28766_28767 : H12AffineEnvironment.transform 16 90138 env28766 = env28767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env28766 == env28767) = true)

theorem identity28767 : scanCanonicalize (H12AffineFastState.compose env28767 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound28767 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env28768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,5392,2420,1024,29789,4161,29821,17,21762,8192,65,31837,16400,17664,10281,20564,8573,256,32,5457,513]

theorem envBound28768 : H12AffineFastState.Bounded env28768 := by
  intro p hp
  have h : env28768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28767_28768 : H12AffineEnvironment.transform 15 29962 env28767 = env28768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env28767 == env28768) = true)

theorem identity28768 : scanCanonicalize (H12AffineFastState.compose env28768 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound28768 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env28769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21540,21874,5392,2420,1024,21541,4161,21509,17,21762,120,65,23589,16400,17664,2129,20564,261,256,32,5457,513]

theorem envBound28769 : H12AffineFastState.Bounded env28769 := by
  intro p hp
  have h : env28769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28768_28769 : H12AffineEnvironment.transform 12 120 env28768 = env28769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env28768 == env28769) = true)

theorem identity28769 : scanCanonicalize (H12AffineFastState.compose env28769 (packedSelected [2,3,5,6,10,11,12,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound28769 : packedSelected [2,3,5,6,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env28770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5157,1,343,5392,2420,1024,0,4161,32,17,295,120,65,2048,5173,4389,2129,1137,261,256,32,5457,513]

theorem envBound28770 : H12AffineFastState.Bounded env28770 := by
  intro p hp
  have h : env28770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28769_28770 : H12AffineEnvironment.transform 13 5157 env28769 = env28770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env28769 == env28770) = true)

theorem identity28770 : scanCanonicalize (H12AffineFastState.compose env28770 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound28770 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env28771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,4096,120,5157,1,343,5392,292,1024,0,4161,32,17,295,120,65,80,5173,4389,1,1137,261,256,32,5457,513]

theorem envBound28771 : H12AffineFastState.Bounded env28771 := by
  intro p hp
  have h : env28771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28770_28771 : H12AffineEnvironment.transform 10 80 env28770 = env28771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env28770 == env28771) = true)

theorem identity28771 : scanCanonicalize (H12AffineFastState.compose env28771 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound28771 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env28772 : List Nat := [2,4,8,16,32,64,8,256,512,272,80,4096,120,4405,1,343,4096,292,272,0,4161,32,17,295,120,65,80,4389,4389,1,353,261,256,32,4161,513]

theorem envBound28772 : H12AffineFastState.Bounded env28772 := by
  intro p hp
  have h : env28772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28771_28772 : H12AffineEnvironment.transform 9 272 env28771 = env28772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28771 == env28772) = true)

theorem identity28772 : scanCanonicalize (H12AffineFastState.compose env28772 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound28772 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env28773 : List Nat := [2,4,8,16,32,64,8,256,512,272,80,308,120,1,1,343,308,292,272,0,373,32,17,295,120,65,80,17,17,1,353,261,256,32,373,513]

theorem envBound28773 : H12AffineFastState.Bounded env28773 := by
  intro p hp
  have h : env28773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28772_28773 : H12AffineEnvironment.transform 11 308 env28772 = env28773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env28772 == env28773) = true)

theorem identity28773 : scanCanonicalize (H12AffineFastState.compose env28773 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28773 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28774 : List Nat := [2,4,8,16,32,17,8,256,512,272,1,308,41,1,1,262,308,292,272,0,292,32,17,295,41,16,1,17,17,1,304,261,256,32,292,513]

theorem envBound28774 : H12AffineFastState.Bounded env28774 := by
  intro p hp
  have h : env28774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28773_28774 : H12AffineEnvironment.transform 5 17 env28773 = env28774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28773 == env28774) = true)

theorem identity28774 : scanCanonicalize (H12AffineFastState.compose env28774 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound28774 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env28775 : List Nat := [2,4,8,16,32,17,8,256,26,272,1,308,41,1,1,262,308,292,272,0,292,32,17,295,41,16,1,17,17,1,304,261,256,32,292,27]

theorem envBound28775 : H12AffineFastState.Bounded env28775 := by
  intro p hp
  have h : env28775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28774_28775 : H12AffineEnvironment.transform 8 26 env28774 = env28775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env28774 == env28775) = true)

theorem identity28775 : scanCanonicalize (H12AffineFastState.compose env28775 (packedSelected [0,1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28775 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env28776 : List Nat := [2,4,2,16,32,17,2,256,16,272,1,308,35,1,1,262,308,292,272,0,292,32,17,295,35,16,1,17,17,1,304,261,256,32,292,17]

theorem envBound28776 : H12AffineFastState.Bounded env28776 := by
  intro p hp
  have h : env28776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28775_28776 : H12AffineEnvironment.transform 2 2 env28775 = env28776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28775 == env28776) = true)

def env28777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,254010,17,21762,8193,65,171280,115015,17664,10281,119042,180273,256,98679,90203,63068]

theorem envBound28777 : H12AffineFastState.Bounded env28777 := by
  intro p hp
  have h : env28777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28764_28777 : H12AffineEnvironment.transform 6 9 env28764 = env28777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28764 == env28777) = true)

theorem identity28777 : scanCanonicalize (H12AffineFastState.compose env28777 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28777 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,179513,1024,32769,4161,243003,17,3,8193,65,171280,103494,4097,10281,99331,169264,256,98679,79194,41821]

theorem envBound28778 : H12AffineFastState.Bounded env28778 := by
  intro p hp
  have h : env28778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28777_28778 : H12AffineEnvironment.transform 13 5377 env28777 = env28778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28777 == env28778) = true)

theorem identity28778 : scanCanonicalize (H12AffineFastState.compose env28778 (packedSelected [0,1,4,8,10,12,14,15,18,19,20,22,23,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound28778 : packedSelected [0,1,4,8,10,12,14,15,18,19,20,22,23,27,31] rootPS < 2^1333 := by decide +kernel

def env28779 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,13673,34896,1024,32769,4161,98386,17,3,8193,65,43129,103494,4097,10281,99331,41049,256,98679,79194,41821]

theorem envBound28779 : H12AffineFastState.Bounded env28779 := by
  intro p hp
  have h : env28779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28778_28779 : H12AffineEnvironment.transform 16 13673 env28778 = env28779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env28778 == env28779) = true)

theorem identity28779 : scanCanonicalize (H12AffineFastState.compose env28779 (packedSelected [1,2,5,8,11,14,16,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28779 : packedSelected [1,2,5,8,11,14,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env28780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,32768,65536,5220,34896,1024,32769,4161,98386,17,3,268,65,35188,103494,4097,2340,99331,33108,256,98679,70743,33360]

theorem envBound28780 : H12AffineFastState.Bounded env28780 := by
  intro p hp
  have h : env28780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28779_28780 : H12AffineEnvironment.transform 12 269 env28779 = env28780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28779 == env28780) = true)

theorem identity28780 : scanCanonicalize (H12AffineFastState.compose env28780 (packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound28780 : packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env28781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,32768,35,5220,34896,1024,32769,4161,32881,17,3,268,65,35188,37989,4097,2340,33824,33108,256,33108,5236,33360]

theorem envBound28781 : H12AffineFastState.Bounded env28781 := by
  intro p hp
  have h : env28781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28780_28781 : H12AffineEnvironment.transform 15 35 env28780 = env28781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env28780 == env28781) = true)

theorem identity28781 : scanCanonicalize (H12AffineFastState.compose env28781 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound28781 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,0,35,5220,2128,1024,1,4161,113,17,3,268,65,2420,5221,4097,2340,1056,340,256,340,5236,592]

theorem envBound28782 : H12AffineFastState.Bounded env28782 := by
  intro p hp
  have h : env28782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28781_28782 : H12AffineEnvironment.transform 14 0 env28781 = env28782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env28781 == env28782) = true)

theorem identity28782 : scanCanonicalize (H12AffineFastState.compose env28782 (packedSelected [2,3,4,5,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound28782 : packedSelected [2,3,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env28783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1281,269,0,0,35,357,2128,1024,1,1344,113,17,3,268,65,2420,356,1280,2340,1056,340,256,340,373,592]

theorem envBound28783 : H12AffineFastState.Bounded env28783 := by
  intro p hp
  have h : env28783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28782_28783 : H12AffineEnvironment.transform 11 1281 env28782 = env28783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env28782 == env28783) = true)

theorem identity28783 : scanCanonicalize (H12AffineFastState.compose env28783 (packedSelected [1,2,3,5,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28783 : packedSelected [1,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env28784 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1281,269,0,0,35,309,2048,1024,1,1296,33,17,3,268,17,2340,308,1280,2340,1056,260,256,260,293,512]

theorem envBound28784 : H12AffineFastState.Bounded env28784 := by
  intro p hp
  have h : env28784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28783_28784 : H12AffineEnvironment.transform 5 16 env28783 = env28784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28783 == env28784) = true)

theorem identity28784 : scanCanonicalize (H12AffineFastState.compose env28784 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound28784 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env28785 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,308,269,0,0,35,309,2048,53,1,293,33,17,3,268,17,2340,308,309,2340,21,260,256,260,293,512]

theorem envBound28785 : H12AffineFastState.Bounded env28785 := by
  intro p hp
  have h : env28785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28784_28785 : H12AffineEnvironment.transform 9 53 env28784 = env28785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env28784 == env28785) = true)

theorem identity28785 : scanCanonicalize (H12AffineFastState.compose env28785 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound28785 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28786 : List Nat := [2,4,8,16,32,16,9,5,512,53,2048,49,8,0,0,35,48,2048,53,1,32,33,17,3,9,17,2081,49,48,2081,21,1,5,1,32,512]

theorem envBound28786 : H12AffineFastState.Bounded env28786 := by
  intro p hp
  have h : env28786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28785_28786 : H12AffineEnvironment.transform 7 5 env28785 = env28786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env28785 == env28786) = true)

theorem identity28786 : scanCanonicalize (H12AffineFastState.compose env28786 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 53) := by decide +kernel

theorem selectedBound28786 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env28787 : List Nat := [2,4,8,16,32,16,9,5,512,53,53,49,8,0,0,35,48,53,53,1,32,33,17,3,9,17,20,49,48,20,21,1,5,1,32,512]

theorem envBound28787 : H12AffineFastState.Bounded env28787 := by
  intro p hp
  have h : env28787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28786_28787 : H12AffineEnvironment.transform 10 53 env28786 = env28787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 53 env28786 == env28787) = true)

def env28788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,2101329,2114883,8328,65,4291883,115150,17665,2111593,119043,4268162,256,2199998,2191387,63188]

theorem envBound28788 : H12AffineFastState.Bounded env28788 := by
  intro p hp
  have h : env28788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28730_28788 : H12AffineEnvironment.transform 22 2101329 env28730 = env28788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env28730 == env28788) = true)

def env28789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,17,21763,8328,65,4291883,115150,17665,10281,119043,4268162,256,98814,90203,63188]

theorem envBound28789 : H12AffineFastState.Bounded env28789 := by
  intro p hp
  have h : env28789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28788_28789 : H12AffineEnvironment.transform 20 4160 env28788 = env28789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28788 == env28789) = true)

theorem identity28789 : scanCanonicalize (H12AffineFastState.compose env28789 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201830) := by decide +kernel

theorem selectedBound28789 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,201830,17,21763,8328,65,158029,115150,17665,10281,119043,144612,256,98814,90203,63188]

theorem envBound28790 : H12AffineFastState.Bounded env28790 := by
  intro p hp
  have h : env28790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28789_28790 : H12AffineEnvironment.transform 21 201830 env28789 = env28790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201830 env28789 == env28790) = true)

theorem identity28790 : scanCanonicalize (H12AffineFastState.compose env28790 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound28790 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env28791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,138477,1024,29908,4160,201830,17,21763,8328,65,158029,79131,17665,10281,75222,144612,256,95531,90203,513]

theorem envBound28791 : H12AffineFastState.Bounded env28791 := by
  intro p hp
  have h : env28791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28790_28791 : H12AffineEnvironment.transform 14 29909 env28790 = env28791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env28790 == env28791) = true)

theorem identity28791 : scanCanonicalize (H12AffineFastState.compose env28791 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound28791 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,97527,1024,29908,4160,29820,17,21763,8328,65,67927,79131,17665,10281,75222,87294,256,95531,90203,513]

theorem envBound28792 : H12AffineFastState.Bounded env28792 := by
  intro p hp
  have h : env28792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28791_28792 : H12AffineEnvironment.transform 16 90138 env28791 = env28792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env28791 == env28792) = true)

theorem identity28792 : scanCanonicalize (H12AffineFastState.compose env28792 (packedSelected [3,4,5,8,9,11,12,14,17,18,20,23,28,32,41] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound28792 : packedSelected [3,4,5,8,9,11,12,14,17,18,20,23,28,32,41] rootPS < 2^1333 := by decide +kernel

def env28793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30082,5528,2421,1024,29908,4160,29820,17,21763,8328,65,31957,16537,17665,10281,20564,8572,256,169,5593,513]

theorem envBound28793 : H12AffineFastState.Bounded env28793 := by
  intro p hp
  have h : env28793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28792_28793 : H12AffineEnvironment.transform 15 30082 env28792 = env28793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env28792 == env28793) = true)

theorem identity28793 : scanCanonicalize (H12AffineFastState.compose env28793 (packedSelected [0,1,3,4,6,7,8,9,10,12,15,17,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound28793 : packedSelected [0,1,3,4,6,7,8,9,10,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env28794 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,29709,30042,5440,2421,1024,29708,4160,29820,17,21763,8272,65,31757,16449,17665,10281,20564,8572,256,113,5377,513]

theorem envBound28794 : H12AffineFastState.Bounded env28794 := by
  intro p hp
  have h : env28794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28793_28794 : H12AffineEnvironment.transform 6 88 env28793 = env28794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env28793 == env28794) = true)

def env28795 : List Nat := [2,4,8,16,32,64,88,256,512,256,2048,4096,8192,16384,28941,28762,4160,2421,256,28940,4160,29052,17,20483,8272,65,30989,16449,16385,10281,20564,8572,256,113,4097,513]

theorem envBound28795 : H12AffineFastState.Bounded env28795 := by
  intro p hp
  have h : env28795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28794_28795 : H12AffineEnvironment.transform 9 256 env28794 = env28795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env28794 == env28795) = true)

theorem identity28795 : scanCanonicalize (H12AffineFastState.compose env28795 (packedSelected [14] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound28795 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env28796 : List Nat := [2,4,8,16,32,64,88,256,512,256,2048,4096,57,16384,20788,20579,4160,2421,256,20789,4160,20805,17,20483,105,65,22836,16449,16385,2064,20564,325,256,113,4097,513]

theorem envBound28796 : H12AffineFastState.Bounded env28796 := by
  intro p hp
  have h : env28796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28795_28796 : H12AffineEnvironment.transform 12 57 env28795 = env28796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env28795 == env28796) = true)

theorem identity28796 : scanCanonicalize (H12AffineFastState.compose env28796 (packedSelected [6,17] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound28796 : packedSelected [6,17] rootPS < 2^1333 := by decide +kernel

def env28797 : List Nat := [2,4,8,16,32,64,88,256,512,256,2048,4096,57,4404,0,343,4160,2421,256,1,4160,113,17,311,105,65,2048,4469,4405,2064,352,325,256,113,4097,513]

theorem envBound28797 : H12AffineFastState.Bounded env28797 := by
  intro p hp
  have h : env28797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28796_28797 : H12AffineEnvironment.transform 13 4404 env28796 = env28797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env28796 == env28797) = true)

theorem identity28797 : scanCanonicalize (H12AffineFastState.compose env28797 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28797 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28798 : List Nat := [2,4,8,16,32,17,9,256,512,256,2048,4096,57,4404,0,262,4113,2340,256,1,4113,32,17,311,56,16,2048,4388,4405,2064,305,276,256,32,4097,513]

theorem envBound28798 : H12AffineFastState.Bounded env28798 := by
  intro p hp
  have h : env28798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28797_28798 : H12AffineEnvironment.transform 5 17 env28797 = env28798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28797 == env28798) = true)

theorem identity28798 : scanCanonicalize (H12AffineFastState.compose env28798 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound28798 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env28799 : List Nat := [2,4,8,16,32,17,9,256,512,256,292,4096,57,4404,0,262,4113,0,256,1,4113,32,17,311,56,16,292,4388,4405,308,305,276,256,32,4097,513]

theorem envBound28799 : H12AffineFastState.Bounded env28799 := by
  intro p hp
  have h : env28799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28798_28799 : H12AffineEnvironment.transform 10 292 env28798 = env28799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env28798 == env28799) = true)

theorem identity28799 : scanCanonicalize (H12AffineFastState.compose env28799 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound28799 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28800 : List Nat := [2,4,8,16,32,17,9,52,512,52,16,4096,57,4096,0,50,4113,0,52,1,4113,32,17,3,56,16,16,4112,4097,0,5,32,52,32,4097,513]

theorem envBound28800 : H12AffineFastState.Bounded env28800 := by
  intro p hp
  have h : env28800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28799_28800 : H12AffineEnvironment.transform 7 52 env28799 = env28800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env28799 == env28800) = true)

theorem identity28800 : scanCanonicalize (H12AffineFastState.compose env28800 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound28800 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28801 : List Nat := [2,4,8,16,32,17,9,52,512,52,16,17,57,17,0,50,0,0,52,1,0,32,17,3,56,16,16,1,16,0,5,32,52,32,16,513]

theorem envBound28801 : H12AffineFastState.Bounded env28801 := by
  intro p hp
  have h : env28801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28800_28801 : H12AffineEnvironment.transform 11 17 env28800 = env28801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env28800 == env28801) = true)

theorem identity28801 : scanCanonicalize (H12AffineFastState.compose env28801 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28801 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env28802 : List Nat := [2,4,8,0,32,1,9,36,512,36,0,1,41,1,0,34,0,0,36,1,0,32,1,3,40,0,0,1,0,0,5,32,36,32,0,513]

theorem envBound28802 : H12AffineFastState.Bounded env28802 := by
  intro p hp
  have h : env28802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28801_28802 : H12AffineEnvironment.transform 3 0 env28801 = env28802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28801 == env28802) = true)

theorem identity28802 : scanCanonicalize (H12AffineFastState.compose env28802 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound28802 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28803 : List Nat := [2,4,8,0,32,1,9,36,32,36,0,1,41,1,0,34,0,0,36,1,0,32,1,3,40,0,0,1,0,0,5,32,36,32,0,33]

theorem envBound28803 : H12AffineFastState.Bounded env28803 := by
  intro p hp
  have h : env28803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28802_28803 : H12AffineEnvironment.transform 8 32 env28802 = env28803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env28802 == env28803) = true)

def env28804 : List Nat := [2,4,8,16,32,64,88,256,512,257,2048,4096,8192,16384,28940,28763,4161,2421,257,28941,4160,29053,17,20482,8272,65,30988,16449,16384,10281,20564,8572,256,113,4096,513]

theorem envBound28804 : H12AffineFastState.Bounded env28804 := by
  intro p hp
  have h : env28804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28794_28804 : H12AffineEnvironment.transform 9 257 env28794 = env28804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env28794 == env28804) = true)

theorem identity28804 : scanCanonicalize (H12AffineFastState.compose env28804 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound28804 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env28805 : List Nat := [2,4,8,16,32,64,88,256,512,257,2048,4096,8192,12392,356,51,4161,2421,257,357,4160,277,17,8298,8272,65,2404,12329,12392,10281,8252,8572,256,113,4096,513]

theorem envBound28805 : H12AffineFastState.Bounded env28805 := by
  intro p hp
  have h : env28805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28804_28805 : H12AffineEnvironment.transform 13 12392 env28804 = env28805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env28804 == env28805) = true)

theorem identity28805 : scanCanonicalize (H12AffineFastState.compose env28805 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound28805 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28806 : List Nat := [2,4,8,16,32,64,88,100,512,101,2048,4096,8192,12392,0,51,4161,2065,101,1,4160,113,17,8298,8272,65,2048,12329,12392,10281,8252,8216,100,113,4096,513]

theorem envBound28806 : H12AffineFastState.Bounded env28806 := by
  intro p hp
  have h : env28806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28805_28806 : H12AffineEnvironment.transform 7 100 env28805 = env28806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env28805 == env28806) = true)

theorem identity28806 : scanCanonicalize (H12AffineFastState.compose env28806 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 105) := by decide +kernel

theorem selectedBound28806 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env28807 : List Nat := [2,4,8,16,32,64,88,100,512,101,2048,4096,105,4097,0,51,4161,2065,101,1,4160,113,17,3,57,65,2048,4160,4097,2112,85,113,100,113,4096,513]

theorem envBound28807 : H12AffineFastState.Bounded env28807 := by
  intro p hp
  have h : env28807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28806_28807 : H12AffineEnvironment.transform 12 105 env28806 = env28807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 105 env28806 == env28807) = true)

theorem identity28807 : scanCanonicalize (H12AffineFastState.compose env28807 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28807 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28808 : List Nat := [2,4,8,16,32,17,9,53,512,52,2048,4096,56,4097,0,51,4112,2065,52,1,4113,32,17,3,57,16,2048,4113,4097,2065,4,32,53,32,4096,513]

theorem envBound28808 : H12AffineFastState.Bounded env28808 := by
  intro p hp
  have h : env28808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28807_28808 : H12AffineEnvironment.transform 5 17 env28807 = env28808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28807 == env28808) = true)

theorem identity28808 : scanCanonicalize (H12AffineFastState.compose env28808 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound28808 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28809 : List Nat := [2,4,8,16,32,17,9,53,512,52,2048,17,56,16,0,51,1,2065,52,1,0,32,17,3,57,16,2048,0,16,2065,4,32,53,32,17,513]

theorem envBound28809 : H12AffineFastState.Bounded env28809 := by
  intro p hp
  have h : env28809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28808_28809 : H12AffineEnvironment.transform 11 17 env28808 = env28809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env28808 == env28809) = true)

theorem identity28809 : scanCanonicalize (H12AffineFastState.compose env28809 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound28809 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28810 : List Nat := [2,4,8,16,32,17,9,53,512,52,17,17,56,16,0,51,1,0,52,1,0,32,17,3,57,16,17,0,16,0,4,32,53,32,17,513]

theorem envBound28810 : H12AffineFastState.Bounded env28810 := by
  intro p hp
  have h : env28810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28809_28810 : H12AffineEnvironment.transform 10 17 env28809 = env28810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env28809 == env28810) = true)

theorem identity28810 : scanCanonicalize (H12AffineFastState.compose env28810 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28810 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env28811 : List Nat := [2,4,8,1,32,0,9,36,512,37,0,0,41,1,0,34,1,0,37,1,0,32,0,3,40,1,0,0,1,0,4,32,36,32,0,513]

theorem envBound28811 : H12AffineFastState.Bounded env28811 := by
  intro p hp
  have h : env28811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28810_28811 : H12AffineEnvironment.transform 3 1 env28810 = env28811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28810 == env28811) = true)

theorem identity28811 : scanCanonicalize (H12AffineFastState.compose env28811 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound28811 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28812 : List Nat := [2,4,8,1,32,0,9,36,32,37,0,0,41,1,0,34,1,0,37,1,0,32,0,3,40,1,0,0,1,0,4,32,36,32,0,33]

theorem envBound28812 : H12AffineFastState.Bounded env28812 := by
  intro p hp
  have h : env28812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28811_28812 : H12AffineEnvironment.transform 8 32 env28811 = env28812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env28811 == env28812) = true)

def env28813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,16,21762,8328,65,4291883,115150,17665,10280,119043,4268162,256,98815,90202,63188]

theorem envBound28813 : H12AffineFastState.Bounded env28813 := by
  intro p hp
  have h : env28813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28788_28813 : H12AffineEnvironment.transform 20 4161 env28788 = env28813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28788 == env28813) = true)

theorem identity28813 : scanCanonicalize (H12AffineFastState.compose env28813 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound28813 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,190520,1024,32769,4161,4194304,16,21762,8328,65,4237812,5393,17665,10280,1500,4256861,256,21792,46213,63188]

theorem envBound28814 : H12AffineFastState.Bounded env28814 := by
  intro p hp
  have h : env28814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28813_28814 : H12AffineEnvironment.transform 15 54495 env28813 = env28814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env28813 == env28814) = true)

def env28815 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190520,1024,32769,4161,4194304,16,21762,8192,65,4237692,5393,17665,10280,1364,4256861,256,21792,46093,63068]

theorem envBound28815 : H12AffineFastState.Bounded env28815 := by
  intro p hp
  have h : env28815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28814_28815 : H12AffineEnvironment.transform 6 8 env28814 = env28815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28814 == env28815) = true)

theorem identity28815 : scanCanonicalize (H12AffineFastState.compose env28815 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound28815 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28816 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13388,56436,1024,32769,4161,4194304,16,21762,8192,65,4237692,5393,17665,10280,1364,4256861,256,21792,46093,63068]

theorem envBound28816 : H12AffineFastState.Bounded env28816 := by
  intro p hp
  have h : env28816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28815_28816 : H12AffineEnvironment.transform 16 13388 env28815 = env28816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env28815 == env28816) = true)

theorem identity28816 : scanCanonicalize (H12AffineFastState.compose env28816 (packedSelected [16,20] rootPS)) = affineNative (2^(21+1) ^^^ 29821) := by decide +kernel

theorem selectedBound28816 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env28817 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13388,56436,1024,32769,4161,29821,16,21762,8192,65,56577,5393,17665,10280,1364,32800,256,21792,46093,63068]

theorem envBound28817 : H12AffineFastState.Bounded env28817 := by
  intro p hp
  have h : env28817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28816_28817 : H12AffineEnvironment.transform 21 29821 env28816 = env28817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29821 env28816 == env28817) = true)

theorem identity28817 : scanCanonicalize (H12AffineFastState.compose env28817 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound28817 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env28818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,263,13388,2340,1024,21841,4161,29821,16,21762,8192,65,2129,5393,17665,10280,1364,21872,256,21792,24925,8972]

theorem envBound28818 : H12AffineFastState.Bounded env28818 := by
  intro p hp
  have h : env28818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28817_28818 : H12AffineEnvironment.transform 14 21840 env28817 = env28818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env28817 == env28818) = true)

theorem identity28818 : scanCanonicalize (H12AffineFastState.compose env28818 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound28818 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env28819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,80,263,13388,2340,1024,81,4161,8573,16,2,8192,65,2129,5393,4097,10280,1364,112,256,32,13405,8972]

theorem envBound28819 : H12AffineFastState.Bounded env28819 := by
  intro p hp
  have h : env28819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28818_28819 : H12AffineEnvironment.transform 13 5376 env28818 = env28819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28818 == env28819) = true)

theorem identity28819 : scanCanonicalize (H12AffineFastState.compose env28819 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound28819 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env28820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,263,5440,2340,1024,81,4161,113,16,2,268,65,2129,5393,4097,2340,1364,112,256,32,5457,512]

theorem envBound28820 : H12AffineFastState.Bounded env28820 := by
  intro p hp
  have h : env28820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28819_28820 : H12AffineEnvironment.transform 12 268 env28819 = env28820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env28819 == env28820) = true)

theorem identity28820 : scanCanonicalize (H12AffineFastState.compose env28820 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28820 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28821 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,268,5376,80,263,5440,2308,1024,81,4161,81,16,2,268,65,2129,5393,4097,2308,1364,80,256,0,5457,512]

theorem envBound28821 : H12AffineFastState.Bounded env28821 := by
  intro p hp
  have h : env28821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28820_28821 : H12AffineEnvironment.transform 4 0 env28820 = env28821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28820 == env28821) = true)

theorem identity28821 : scanCanonicalize (H12AffineFastState.compose env28821 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound28821 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28822 : List Nat := [2,4,8,16,0,64,8,256,512,272,2048,4096,268,4112,80,263,4176,2308,272,81,4161,81,16,2,268,65,2129,4097,4097,2308,68,80,256,0,4161,512]

theorem envBound28822 : H12AffineFastState.Bounded env28822 := by
  intro p hp
  have h : env28822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28821_28822 : H12AffineEnvironment.transform 9 272 env28821 = env28822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28821 == env28822) = true)

theorem identity28822 : scanCanonicalize (H12AffineFastState.compose env28822 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound28822 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env28823 : List Nat := [2,4,8,16,0,64,8,256,512,272,2048,2112,268,2128,80,263,2064,2308,272,81,2049,81,16,2,268,65,2129,2113,2113,2308,68,80,256,0,2049,512]

theorem envBound28823 : H12AffineFastState.Bounded env28823 := by
  intro p hp
  have h : env28823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28822_28823 : H12AffineEnvironment.transform 11 2112 env28822 = env28823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env28822 == env28823) = true)

theorem identity28823 : scanCanonicalize (H12AffineFastState.compose env28823 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound28823 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env28824 : List Nat := [2,4,8,16,0,64,8,85,512,69,2048,2112,89,2128,80,82,2064,2129,69,81,2049,81,16,2,89,65,2129,2113,2113,2129,68,80,85,0,2049,512]

theorem envBound28824 : H12AffineFastState.Bounded env28824 := by
  intro p hp
  have h : env28824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28823_28824 : H12AffineEnvironment.transform 7 85 env28823 = env28824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env28823 == env28824) = true)

def env28825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190520,1024,32769,4161,4194304,16,21762,8193,65,4237693,5393,17665,10280,1365,4256861,256,21792,46092,63069]

theorem envBound28825 : H12AffineFastState.Bounded env28825 := by
  intro p hp
  have h : env28825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28814_28825 : H12AffineEnvironment.transform 6 9 env28814 = env28825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28814 == env28825) = true)

theorem identity28825 : scanCanonicalize (H12AffineFastState.compose env28825 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound28825 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28826 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,32040,1024,32769,4161,4194304,16,21762,8193,65,4237693,5393,17665,10280,1365,4256861,256,21792,46092,63069]

theorem envBound28826 : H12AffineFastState.Bounded env28826 := by
  intro p hp
  have h : env28826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28825_28826 : H12AffineEnvironment.transform 16 38160 env28825 = env28826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env28825 == env28826) = true)

theorem identity28826 : scanCanonicalize (H12AffineFastState.compose env28826 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound28826 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env28827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,32040,1024,32769,4161,8492,16,21762,8193,65,34897,5393,17665,10280,1365,54641,256,21792,46092,63069]

theorem envBound28827 : H12AffineFastState.Bounded env28827 := by
  intro p hp
  have h : env28827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28826_28827 : H12AffineEnvironment.transform 21 8492 env28826 = env28827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env28826 == env28827) = true)

theorem identity28827 : scanCanonicalize (H12AffineFastState.compose env28827 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound28827 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env28828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,33031,38160,10361,1024,32769,4161,8492,16,83,8193,65,34897,5393,4176,10280,1365,32800,256,113,46092,41740]

theorem envBound28828 : H12AffineFastState.Bounded env28828 := by
  intro p hp
  have h : env28828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28827_28828 : H12AffineEnvironment.transform 13 5457 env28827 = env28828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env28827 == env28828) = true)

theorem identity28828 : scanCanonicalize (H12AffineFastState.compose env28828 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28828 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env28829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5457,32768,33031,38160,2341,1024,32769,4161,112,16,83,349,65,34897,5393,4176,2420,1365,32800,256,113,38224,33360]

theorem envBound28829 : H12AffineFastState.Bounded env28829 := by
  intro p hp
  have h : env28829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28828_28829 : H12AffineEnvironment.transform 12 348 env28828 = env28829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28828 == env28829) = true)

theorem identity28829 : scanCanonicalize (H12AffineFastState.compose env28829 (packedSelected [2,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound28829 : packedSelected [2,12] rootPS < 2^1333 := by decide +kernel

def env28830 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,89,5204,32768,32770,37909,2080,1024,32769,4161,112,16,83,88,65,34897,5140,4176,2161,1104,32800,5,113,37973,33360]

theorem envBound28830 : H12AffineFastState.Bounded env28830 := by
  intro p hp
  have h : env28830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28829_28830 : H12AffineEnvironment.transform 7 5 env28829 = env28830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env28829 == env28830) = true)

theorem identity28830 : scanCanonicalize (H12AffineFastState.compose env28830 (packedSelected [2,3,4,5,9,10,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 112) := by decide +kernel

theorem selectedBound28830 : packedSelected [2,3,4,5,9,10,14,15,16] rootPS < 2^1333 := by decide +kernel

def env28831 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,89,5204,112,114,5221,2080,1024,113,4161,112,16,83,88,65,2081,5140,4176,2161,1104,80,5,113,5157,544]

theorem envBound28831 : H12AffineFastState.Bounded env28831 := by
  intro p hp
  have h : env28831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28830_28831 : H12AffineEnvironment.transform 14 112 env28830 = env28831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 112 env28830 == env28831) = true)

theorem identity28831 : scanCanonicalize (H12AffineFastState.compose env28831 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28831 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28832 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,9,5124,32,34,5173,2080,1024,33,4113,32,16,3,8,17,2081,5140,4096,2081,1024,0,5,33,5157,544]

theorem envBound28832 : H12AffineFastState.Bounded env28832 := by
  intro p hp
  have h : env28832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28831_28832 : H12AffineEnvironment.transform 5 16 env28831 = env28832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28831 == env28832) = true)

theorem identity28832 : scanCanonicalize (H12AffineFastState.compose env28832 (packedSelected [0,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28832 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env28833 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,9,5124,0,2,5141,2048,1024,1,4113,0,16,3,8,17,2049,5140,4096,2049,1024,0,5,1,5125,512]

theorem envBound28833 : H12AffineFastState.Bounded env28833 := by
  intro p hp
  have h : env28833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28832_28833 : H12AffineEnvironment.transform 4 0 env28832 = env28833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28832 == env28833) = true)

theorem identity28833 : scanCanonicalize (H12AffineFastState.compose env28833 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound28833 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28834 : List Nat := [2,4,8,16,0,16,9,5,512,1024,523,4096,9,5124,0,2,5141,523,1024,1,4113,0,16,3,8,17,522,5140,4096,522,1024,0,5,1,5125,512]

theorem envBound28834 : H12AffineFastState.Bounded env28834 := by
  intro p hp
  have h : env28834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28833_28834 : H12AffineEnvironment.transform 10 523 env28833 = env28834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env28833 == env28834) = true)

def env28835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,8388608,2114882,8328,65,14773626,115151,10507600,8398905,10600787,4268163,256,8487406,8478795,10544772]

theorem envBound28835 : H12AffineFastState.Bounded env28835 := by
  intro p hp
  have h : env28835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28729_28835 : H12AffineEnvironment.transform 17 190521 env28729 = env28835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env28729 == env28835) = true)

def env28836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,2101328,2114882,8328,65,4291882,115151,17664,2111593,119043,4268163,256,2199998,2191387,63188]

theorem envBound28836 : H12AffineFastState.Bounded env28836 := by
  intro p hp
  have h : env28836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28835_28836 : H12AffineEnvironment.transform 22 2101328 env28835 = env28836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env28835 == env28836) = true)

def env28837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,21762,8328,65,4291882,115151,17664,10281,119043,4268163,256,98814,90203,63188]

theorem envBound28837 : H12AffineFastState.Bounded env28837 := by
  intro p hp
  have h : env28837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28836_28837 : H12AffineEnvironment.transform 20 4160 env28836 = env28837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28836 == env28837) = true)

theorem identity28837 : scanCanonicalize (H12AffineFastState.compose env28837 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound28837 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,138476,1024,29908,4160,4194304,16,21762,8328,65,4291882,79130,17664,10281,75222,4268163,256,95531,90203,513]

theorem envBound28838 : H12AffineFastState.Bounded env28838 := by
  intro p hp
  have h : env28838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28837_28838 : H12AffineEnvironment.transform 14 29909 env28837 = env28838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env28837 == env28838) = true)

def env28839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138476,1024,8660,4160,4194304,16,2,8328,65,4270122,79130,4096,10281,75222,4268163,256,73771,79195,513]

theorem envBound28839 : H12AffineFastState.Bounded env28839 := by
  intro p hp
  have h : env28839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28838_28839 : H12AffineEnvironment.transform 13 5376 env28838 = env28839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28838 == env28839) = true)

theorem identity28839 : scanCanonicalize (H12AffineFastState.compose env28839 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound28839 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13389,10401,1024,8660,4160,4194304,16,2,8328,65,4270122,79130,4096,10281,75222,4268163,256,73771,79195,513]

theorem envBound28840 : H12AffineFastState.Bounded env28840 := by
  intro p hp
  have h : env28840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28839_28840 : H12AffineEnvironment.transform 16 13389 env28839 = env28840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env28839 == env28840) = true)

theorem identity28840 : scanCanonicalize (H12AffineFastState.compose env28840 (packedSelected [0,1,2,6,8,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound28840 : packedSelected [0,1,2,6,8,14,19,27] rootPS < 2^1333 := by decide +kernel

def env28841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13389,10401,1024,8660,4160,8573,16,2,8328,65,67927,79130,4096,10281,75222,66046,256,73771,79195,513]

theorem envBound28841 : H12AffineFastState.Bounded env28841 := by
  intro p hp
  have h : env28841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28840_28841 : H12AffineEnvironment.transform 21 8573 env28840 = env28841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env28840 == env28841) = true)

theorem identity28841 : scanCanonicalize (H12AffineFastState.compose env28841 (packedSelected [0,2,3,5,6,7,11,14,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound28841 : packedSelected [0,2,3,5,6,7,11,14,15,19] rootPS < 2^1333 := by decide +kernel

def env28842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,65536,5392,2556,1024,137,4160,32,16,2,469,65,67927,70727,4096,2420,66699,66046,256,65910,70662,513]

theorem envBound28842 : H12AffineFastState.Bounded env28842 := by
  intro p hp
  have h : env28842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28841_28842 : H12AffineEnvironment.transform 12 349 env28841 = env28842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env28841 == env28842) = true)

theorem identity28842 : scanCanonicalize (H12AffineFastState.compose env28842 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound28842 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env28843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,343,5392,2556,1024,137,4160,32,16,2,469,65,2048,5392,4096,2420,1500,169,256,33,5457,513]

theorem envBound28843 : H12AffineFastState.Bounded env28843 := by
  intro p hp
  have h : env28843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28842_28843 : H12AffineEnvironment.transform 15 343 env28842 = env28843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env28842 == env28843) = true)

theorem identity28843 : scanCanonicalize (H12AffineFastState.compose env28843 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28843 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,343,5392,2421,1024,0,4160,32,16,2,348,65,2048,5392,4096,2420,1365,32,256,33,5457,513]

theorem envBound28844 : H12AffineFastState.Bounded env28844 := by
  intro p hp
  have h : env28844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28843_28844 : H12AffineEnvironment.transform 6 9 env28843 = env28844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28843 == env28844) = true)

theorem identity28844 : scanCanonicalize (H12AffineFastState.compose env28844 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound28844 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28845 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1140,349,372,1,343,356,2421,1024,0,1076,32,16,2,348,65,2048,356,1140,2420,1365,32,256,33,293,513]

theorem envBound28845 : H12AffineFastState.Bounded env28845 := by
  intro p hp
  have h : env28845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28844_28845 : H12AffineEnvironment.transform 11 1140 env28844 = env28845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env28844 == env28845) = true)

theorem identity28845 : scanCanonicalize (H12AffineFastState.compose env28845 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound28845 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,373,1140,349,372,1,343,356,0,1024,0,1076,32,16,2,348,65,373,356,1140,1,1365,32,256,33,293,513]

theorem envBound28846 : H12AffineFastState.Bounded env28846 := by
  intro p hp
  have h : env28846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28845_28846 : H12AffineEnvironment.transform 10 373 env28845 = env28846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env28845 == env28846) = true)

theorem identity28846 : scanCanonicalize (H12AffineFastState.compose env28846 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound28846 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env28847 : List Nat := [2,4,8,16,32,64,9,256,512,273,373,357,349,372,1,343,356,0,273,0,293,32,16,2,348,65,373,356,357,1,68,32,256,33,293,513]

theorem envBound28847 : H12AffineFastState.Bounded env28847 := by
  intro p hp
  have h : env28847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28846_28847 : H12AffineEnvironment.transform 9 273 env28846 = env28847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env28846 == env28847) = true)

theorem identity28847 : scanCanonicalize (H12AffineFastState.compose env28847 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28847 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28848 : List Nat := [2,4,8,16,32,64,9,37,512,52,80,64,120,81,1,114,65,0,52,0,0,32,16,2,121,65,80,65,64,1,68,32,37,33,0,513]

theorem envBound28848 : H12AffineFastState.Bounded env28848 := by
  intro p hp
  have h : env28848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28847_28848 : H12AffineEnvironment.transform 7 37 env28847 = env28848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28847 == env28848) = true)

def env28849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,138476,1024,8661,4160,4194304,16,3,8328,65,4270123,79130,4097,10281,75222,4268163,256,73770,79194,513]

theorem envBound28849 : H12AffineFastState.Bounded env28849 := by
  intro p hp
  have h : env28849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28838_28849 : H12AffineEnvironment.transform 13 5377 env28838 = env28849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28838 == env28849) = true)

theorem identity28849 : scanCanonicalize (H12AffineFastState.compose env28849 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound28849 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13509,10281,1024,8661,4160,4194304,16,3,8328,65,4270123,79130,4097,10281,75222,4268163,256,73770,79194,513]

theorem envBound28850 : H12AffineFastState.Bounded env28850 := by
  intro p hp
  have h : env28850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28849_28850 : H12AffineEnvironment.transform 16 13509 env28849 = env28850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env28849 == env28850) = true)

def env28851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,17,21763,8328,65,4291882,115151,17664,10280,119043,4268163,256,98815,90202,63188]

theorem envBound28851 : H12AffineFastState.Bounded env28851 := by
  intro p hp
  have h : env28851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28836_28851 : H12AffineEnvironment.transform 20 4161 env28836 = env28851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28836 == env28851) = true)

theorem identity28851 : scanCanonicalize (H12AffineFastState.compose env28851 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144492) := by decide +kernel

theorem selectedBound28851 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,144492,17,21763,8328,65,215366,115151,17664,10280,119043,201967,256,98815,90202,63188]

theorem envBound28852 : H12AffineFastState.Bounded env28852 := by
  intro p hp
  have h : env28852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28851_28852 : H12AffineEnvironment.transform 21 144492 env28851 = env28852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144492 env28851 == env28852) = true)

def env28853 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,144492,17,21763,8192,65,215366,115015,17664,10280,119043,201831,256,98679,90202,63068]

theorem envBound28853 : H12AffineFastState.Bounded env28853 := by
  intro p hp
  have h : env28853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28852_28853 : H12AffineEnvironment.transform 6 8 env28852 = env28853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28852 == env28853) = true)

theorem identity28853 : scanCanonicalize (H12AffineFastState.compose env28853 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound28853 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28854 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,138340,1024,29788,4161,144492,17,21763,8192,65,215366,79130,17664,10280,75102,201831,256,95530,90202,513]

theorem envBound28854 : H12AffineFastState.Bounded env28854 := by
  intro p hp
  have h : env28854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28853_28854 : H12AffineEnvironment.transform 14 29789 env28853 = env28854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env28853 == env28854) = true)

theorem identity28854 : scanCanonicalize (H12AffineFastState.compose env28854 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound28854 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28855 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,97406,1024,29788,4161,87158,17,21763,8192,65,10588,79130,17664,10280,75102,29821,256,95530,90202,513]

theorem envBound28855 : H12AffineFastState.Bounded env28855 := by
  intro p hp
  have h : env28855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28854_28855 : H12AffineEnvironment.transform 16 90138 env28854 = env28855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env28854 == env28855) = true)

theorem identity28855 : scanCanonicalize (H12AffineFastState.compose env28855 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound28855 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env28856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29963,5393,2421,1024,29788,4161,8573,17,21763,8192,65,10588,16401,17664,10280,20565,29821,256,33,5457,513]

theorem envBound28856 : H12AffineFastState.Bounded env28856 := by
  intro p hp
  have h : env28856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28855_28856 : H12AffineEnvironment.transform 15 29963 env28855 = env28856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env28855 == env28856) = true)

theorem identity28856 : scanCanonicalize (H12AffineFastState.compose env28856 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound28856 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28857 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,21590,5393,2421,1024,21761,4161,32,17,21763,349,65,2049,16401,17664,2421,20565,21792,256,33,5457,513]

theorem envBound28857 : H12AffineFastState.Bounded env28857 := by
  intro p hp
  have h : env28857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28856_28857 : H12AffineEnvironment.transform 12 349 env28856 = env28857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env28856 == env28857) = true)

theorem identity28857 : scanCanonicalize (H12AffineFastState.compose env28857 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound28857 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4113,1297,1095,5393,2421,1024,1296,4161,32,17,1298,349,65,2049,4096,5393,2421,68,1329,256,33,5457,513]

theorem envBound28858 : H12AffineFastState.Bounded env28858 := by
  intro p hp
  have h : env28858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28857_28858 : H12AffineEnvironment.transform 13 4113 env28857 = env28858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env28857 == env28858) = true)

theorem identity28858 : scanCanonicalize (H12AffineFastState.compose env28858 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound28858 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env28859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,4096,349,4113,1297,1095,5393,1076,1024,1296,4161,32,17,1298,349,65,1344,4096,5393,1076,68,1329,256,33,5457,513]

theorem envBound28859 : H12AffineFastState.Bounded env28859 := by
  intro p hp
  have h : env28859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28858_28859 : H12AffineEnvironment.transform 10 1345 env28858 = env28859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env28858 == env28859) = true)

theorem identity28859 : scanCanonicalize (H12AffineFastState.compose env28859 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound28859 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env28860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,1280,349,1297,1297,1095,17,1076,1024,1296,1345,32,17,1298,349,65,1344,1280,17,1076,68,1329,256,33,81,513]

theorem envBound28860 : H12AffineFastState.Bounded env28860 := by
  intro p hp
  have h : env28860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28859_28860 : H12AffineEnvironment.transform 11 1280 env28859 = env28860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env28859 == env28860) = true)

theorem identity28860 : scanCanonicalize (H12AffineFastState.compose env28860 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound28860 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env28861 : List Nat := [2,4,8,16,32,64,8,256,512,52,373,308,349,293,293,115,17,0,52,292,373,32,17,294,349,65,372,308,17,0,68,261,256,33,81,513]

theorem envBound28861 : H12AffineFastState.Bounded env28861 := by
  intro p hp
  have h : env28861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28860_28861 : H12AffineEnvironment.transform 9 52 env28860 = env28861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env28860 == env28861) = true)

theorem identity28861 : scanCanonicalize (H12AffineFastState.compose env28861 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28861 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env28862 : List Nat := [2,4,8,16,32,17,8,256,512,52,292,308,268,293,293,34,17,0,52,292,292,32,17,294,268,16,293,308,17,0,21,261,256,33,0,513]

theorem envBound28862 : H12AffineFastState.Bounded env28862 := by
  intro p hp
  have h : env28862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28861_28862 : H12AffineEnvironment.transform 5 17 env28861 = env28862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28861 == env28862) = true)

def env28863 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,144492,17,21763,8193,65,215366,115014,17664,10280,119043,201830,256,98678,90202,63069]

theorem envBound28863 : H12AffineFastState.Bounded env28863 := by
  intro p hp
  have h : env28863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28852_28863 : H12AffineEnvironment.transform 6 9 env28852 = env28863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28852 == env28863) = true)

theorem identity28863 : scanCanonicalize (H12AffineFastState.compose env28863 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound28863 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28864 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,179513,1024,32769,4161,144492,17,3,8193,65,203846,103494,4096,10280,99331,201830,256,98678,79194,41821]

theorem envBound28864 : H12AffineFastState.Bounded env28864 := by
  intro p hp
  have h : env28864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28863_28864 : H12AffineEnvironment.transform 13 5376 env28863 = env28864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28863 == env28864) = true)

theorem identity28864 : scanCanonicalize (H12AffineFastState.compose env28864 (packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 37989) := by decide +kernel

theorem selectedBound28864 : packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env28865 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,37989,10588,1024,32769,4161,40969,17,3,8193,65,100387,103494,4096,10280,99331,98307,256,98678,79194,41821]

theorem envBound28865 : H12AffineFastState.Bounded env28865 := by
  intro p hp
  have h : env28865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28864_28865 : H12AffineEnvironment.transform 16 37989 env28864 = env28865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 37989 env28864 == env28865) = true)

theorem identity28865 : scanCanonicalize (H12AffineFastState.compose env28865 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,19,20,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28865 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,19,20,26] rootPS < 2^1333 := by decide +kernel

def env28866 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,65536,37989,2048,1024,32769,4161,33109,17,3,349,65,100387,103494,4096,2420,99331,98307,256,98678,70662,33281]

theorem envBound28866 : H12AffineFastState.Bounded env28866 := by
  intro p hp
  have h : env28866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28865_28866 : H12AffineEnvironment.transform 12 348 env28865 = env28866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28865 == env28866) = true)

theorem identity28866 : scanCanonicalize (H12AffineFastState.compose env28866 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound28866 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env28867 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,65536,5221,2048,1024,1,4161,341,17,3,349,65,67619,70726,4096,2420,66563,65539,256,65910,70662,513]

theorem envBound28867 : H12AffineFastState.Bounded env28867 := by
  intro p hp
  have h : env28867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28866_28867 : H12AffineEnvironment.transform 14 0 env28866 = env28867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env28866 == env28867) = true)

theorem identity28867 : scanCanonicalize (H12AffineFastState.compose env28867 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound28867 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28868 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,35,5221,2048,1024,1,4161,341,17,3,349,65,2048,5221,4096,2420,1056,32,256,341,5157,513]

theorem envBound28868 : H12AffineFastState.Bounded env28868 := by
  intro p hp
  have h : env28868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28867_28868 : H12AffineEnvironment.transform 15 35 env28867 = env28868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env28867 == env28868) = true)

theorem identity28868 : scanCanonicalize (H12AffineFastState.compose env28868 (packedSelected [3,4,5,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28868 : packedSelected [3,4,5,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env28869 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,121,5157,0,35,5221,2048,1024,1,4161,112,17,3,120,65,2048,5221,4096,2129,1056,32,37,112,5157,513]

theorem envBound28869 : H12AffineFastState.Bounded env28869 := by
  intro p hp
  have h : env28869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28868_28869 : H12AffineEnvironment.transform 7 37 env28868 = env28869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28868 == env28869) = true)

def env28870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,2101329,2114882,8328,65,4291883,115151,17665,2111592,119042,4268163,256,2199999,2191386,63189]

theorem envBound28870 : H12AffineFastState.Bounded env28870 := by
  intro p hp
  have h : env28870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28835_28870 : H12AffineEnvironment.transform 22 2101329 env28835 = env28870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env28835 == env28870) = true)

def env28871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,17,21762,8328,65,4291883,115151,17665,10280,119042,4268163,256,98815,90202,63189]

theorem envBound28871 : H12AffineFastState.Bounded env28871 := by
  intro p hp
  have h : env28871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28870_28871 : H12AffineEnvironment.transform 20 4160 env28870 = env28871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28870 == env28871) = true)

theorem identity28871 : scanCanonicalize (H12AffineFastState.compose env28871 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180409) := by decide +kernel

theorem selectedBound28871 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,180409,17,21762,8328,65,245138,115151,17665,10280,119042,254010,256,98815,90202,63189]

theorem envBound28872 : H12AffineFastState.Bounded env28872 := by
  intro p hp
  have h : env28872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28871_28872 : H12AffineEnvironment.transform 21 180409 env28871 = env28872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env28871 == env28872) = true)

def env28873 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,180273,17,21762,8192,65,245018,115015,17665,10280,119042,254010,256,98679,90202,63069]

theorem envBound28873 : H12AffineFastState.Bounded env28873 := by
  intro p hp
  have h : env28873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28872_28873 : H12AffineEnvironment.transform 6 8 env28872 = env28873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28872 == env28873) = true)

theorem identity28873 : scanCanonicalize (H12AffineFastState.compose env28873 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound28873 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28874 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,138341,1024,29789,4160,144493,17,21762,8192,65,215366,79131,17665,10280,75102,201830,256,95531,90202,513]

theorem envBound28874 : H12AffineFastState.Bounded env28874 := by
  intro p hp
  have h : env28874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28873_28874 : H12AffineEnvironment.transform 14 29788 env28873 = env28874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env28873 == env28874) = true)

theorem identity28874 : scanCanonicalize (H12AffineFastState.compose env28874 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound28874 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28875 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,97407,1024,29789,4160,87159,17,21762,8192,65,10588,79131,17665,10280,75102,29820,256,95531,90202,513]

theorem envBound28875 : H12AffineFastState.Bounded env28875 := by
  intro p hp
  have h : env28875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28874_28875 : H12AffineEnvironment.transform 16 90138 env28874 = env28875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env28874 == env28875) = true)

theorem identity28875 : scanCanonicalize (H12AffineFastState.compose env28875 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound28875 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env28876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,5392,2421,1024,29789,4160,8573,17,21762,8192,65,10588,16401,17665,10280,20564,29820,256,33,5456,513]

theorem envBound28876 : H12AffineFastState.Bounded env28876 := by
  intro p hp
  have h : env28876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28875_28876 : H12AffineEnvironment.transform 15 29962 env28875 = env28876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env28875 == env28876) = true)

theorem identity28876 : scanCanonicalize (H12AffineFastState.compose env28876 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound28876 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,21591,5392,2421,1024,21760,4160,32,17,21762,349,65,2049,16401,17665,2421,20564,21793,256,33,5456,513]

theorem envBound28877 : H12AffineFastState.Bounded env28877 := by
  intro p hp
  have h : env28877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28876_28877 : H12AffineEnvironment.transform 12 349 env28876 = env28877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env28876 == env28877) = true)

theorem identity28877 : scanCanonicalize (H12AffineFastState.compose env28877 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound28877 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4113,1296,1094,5392,2421,1024,1297,4160,32,17,1299,349,65,2049,4096,5392,2421,69,1328,256,33,5456,513]

theorem envBound28878 : H12AffineFastState.Bounded env28878 := by
  intro p hp
  have h : env28878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28877_28878 : H12AffineEnvironment.transform 13 4113 env28877 = env28878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env28877 == env28878) = true)

theorem identity28878 : scanCanonicalize (H12AffineFastState.compose env28878 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound28878 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env28879 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,349,4113,1296,1094,5392,1077,1024,1297,4160,32,17,1299,349,65,1345,4096,5392,1077,69,1328,256,33,5456,513]

theorem envBound28879 : H12AffineFastState.Bounded env28879 := by
  intro p hp
  have h : env28879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28878_28879 : H12AffineEnvironment.transform 10 1344 env28878 = env28879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env28878 == env28879) = true)

theorem identity28879 : scanCanonicalize (H12AffineFastState.compose env28879 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound28879 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env28880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,17,349,0,1296,1094,1281,1077,1024,1297,81,32,17,1299,349,65,1345,17,1281,1077,69,1328,256,33,1345,513]

theorem envBound28880 : H12AffineFastState.Bounded env28880 := by
  intro p hp
  have h : env28880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28879_28880 : H12AffineEnvironment.transform 11 17 env28879 = env28880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env28879 == env28880) = true)

theorem identity28880 : scanCanonicalize (H12AffineFastState.compose env28880 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound28880 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env28881 : List Nat := [2,4,8,16,32,64,8,256,512,100,292,17,349,0,372,34,357,81,100,373,81,32,17,375,349,65,293,17,357,81,69,340,256,33,293,513]

theorem envBound28881 : H12AffineFastState.Bounded env28881 := by
  intro p hp
  have h : env28881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28880_28881 : H12AffineEnvironment.transform 9 100 env28880 = env28881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env28880 == env28881) = true)

theorem identity28881 : scanCanonicalize (H12AffineFastState.compose env28881 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound28881 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env28882 : List Nat := [2,4,8,16,32,1,8,256,512,37,292,17,284,0,309,34,292,16,37,308,16,32,17,310,284,0,293,17,292,16,4,277,256,33,293,513]

theorem envBound28882 : H12AffineFastState.Bounded env28882 := by
  intro p hp
  have h : env28882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28881_28882 : H12AffineEnvironment.transform 5 1 env28881 = env28882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env28881 == env28882) = true)

theorem identity28882 : scanCanonicalize (H12AffineFastState.compose env28882 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28882 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env28883 : List Nat := [2,4,8,16,32,1,8,37,512,37,1,17,57,0,16,34,1,16,37,17,16,32,17,19,57,0,0,17,1,16,4,48,37,33,0,513]

theorem envBound28883 : H12AffineFastState.Bounded env28883 := by
  intro p hp
  have h : env28883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28882_28883 : H12AffineEnvironment.transform 7 37 env28882 = env28883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28882 == env28883) = true)

theorem identity28883 : scanCanonicalize (H12AffineFastState.compose env28883 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28883 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env28884 : List Nat := [2,4,8,1,32,1,8,37,512,37,1,0,40,0,1,34,1,1,37,0,1,32,0,2,40,0,0,0,1,1,4,33,37,33,0,513]

theorem envBound28884 : H12AffineFastState.Bounded env28884 := by
  intro p hp
  have h : env28884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28883_28884 : H12AffineEnvironment.transform 3 1 env28883 = env28884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28883 == env28884) = true)

theorem identity28884 : scanCanonicalize (H12AffineFastState.compose env28884 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound28884 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28885 : List Nat := [2,4,8,1,32,1,8,37,32,37,1,0,40,0,1,34,1,1,37,0,1,32,0,2,40,0,0,0,1,1,4,33,37,33,0,33]

theorem envBound28885 : H12AffineFastState.Bounded env28885 := by
  intro p hp
  have h : env28885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28884_28885 : H12AffineEnvironment.transform 8 32 env28884 = env28885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env28884 == env28885) = true)

theorem identity28885 : scanCanonicalize (H12AffineFastState.compose env28885 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28885 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28886 : List Nat := [2,4,8,1,1,1,8,4,1,4,1,0,9,0,1,3,1,1,4,0,1,1,0,2,9,0,0,0,1,1,4,0,4,0,0,0]

theorem envBound28886 : H12AffineFastState.Bounded env28886 := by
  intro p hp
  have h : env28886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28885_28886 : H12AffineEnvironment.transform 4 1 env28885 = env28886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28885 == env28886) = true)

def env28887 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,180272,17,21762,8193,65,245019,115014,17665,10280,119042,254010,256,98678,90202,63068]

theorem envBound28887 : H12AffineFastState.Bounded env28887 := by
  intro p hp
  have h : env28887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28872_28887 : H12AffineEnvironment.transform 6 9 env28872 = env28887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28872 == env28887) = true)

theorem identity28887 : scanCanonicalize (H12AffineFastState.compose env28887 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28887 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28888 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,179512,1024,32769,4160,169265,17,3,8193,65,245019,103495,4096,10280,99331,243003,256,98678,79195,41821]

theorem envBound28888 : H12AffineFastState.Bounded env28888 := by
  intro p hp
  have h : env28888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28887_28888 : H12AffineEnvironment.transform 13 5377 env28887 = env28888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28887 == env28888) = true)

theorem identity28888 : scanCanonicalize (H12AffineFastState.compose env28888 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28888 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env28889 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,179512,1024,32769,4113,169265,17,3,8193,16,245019,103446,4096,10280,99331,243003,256,98599,79114,41740]

theorem envBound28889 : H12AffineFastState.Bounded env28889 := by
  intro p hp
  have h : env28889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28888_28889 : H12AffineEnvironment.transform 5 17 env28888 = env28889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28888 == env28889) = true)

theorem identity28889 : scanCanonicalize (H12AffineFastState.compose env28889 (packedSelected [0,7,9,10,11,12,15,19,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound28889 : packedSelected [0,7,9,10,11,12,15,19,22,23] rootPS < 2^1333 := by decide +kernel

def env28890 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,65536,38161,10281,1024,32769,4113,32,17,3,8193,16,75786,103446,4096,10280,99331,73770,256,98599,79114,41740]

theorem envBound28890 : H12AffineFastState.Bounded env28890 := by
  intro p hp
  have h : env28890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28889_28890 : H12AffineEnvironment.transform 16 38161 env28889 = env28890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env28889 == env28890) = true)

theorem identity28890 : scanCanonicalize (H12AffineFastState.compose env28890 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound28890 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env28891 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,32803,38161,10281,1024,32769,4113,32,17,3,8193,16,43049,5173,4096,10280,1056,40969,256,260,46377,41740]

theorem envBound28891 : H12AffineFastState.Bounded env28891 := by
  intro p hp
  have h : env28891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28890_28891 : H12AffineEnvironment.transform 15 32803 env28890 = env28891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env28890 == env28891) = true)

theorem identity28891 : scanCanonicalize (H12AffineFastState.compose env28891 (packedSelected [1,4,8,9,10,11,12,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound28891 : packedSelected [1,4,8,9,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env28892 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,0,35,5393,10281,1024,1,4113,32,17,3,8193,16,10281,5173,4096,10280,1056,8201,256,260,13609,8972]

theorem envBound28892 : H12AffineFastState.Bounded env28892 := by
  intro p hp
  have h : env28892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28891_28892 : H12AffineEnvironment.transform 14 0 env28891 = env28892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env28891 == env28892) = true)

theorem identity28892 : scanCanonicalize (H12AffineFastState.compose env28892 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound28892 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env28893 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,35,5393,2341,1024,1,4113,32,17,3,269,16,2341,5173,4096,2340,1056,261,256,260,5157,512]

theorem envBound28893 : H12AffineFastState.Bounded env28893 := by
  intro p hp
  have h : env28893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28892_28893 : H12AffineEnvironment.transform 12 268 env28892 = env28893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env28892 == env28893) = true)

theorem identity28893 : scanCanonicalize (H12AffineFastState.compose env28893 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound28893 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28894 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8,5125,0,35,5141,2081,1024,1,4113,32,17,3,9,16,2081,5173,4096,2080,1056,1,4,0,5157,512]

theorem envBound28894 : H12AffineFastState.Bounded env28894 := by
  intro p hp
  have h : env28894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28893_28894 : H12AffineEnvironment.transform 7 4 env28893 = env28894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env28893 == env28894) = true)

theorem identity28894 : scanCanonicalize (H12AffineFastState.compose env28894 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

end H12CloudChart1