import H12CloudChart1Data141

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans36017_36018 : H12AffineEnvironment.transform 10 81 env36017 = env36018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env36017 == env36018) = true)

theorem identity36018 : scanCanonicalize (H12AffineFastState.compose env36018 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound36018 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env36019 : List Nat := [2,4,8,16,32,64,8,4,512,1024,81,1141,1100,113,1125,1095,131072,1077,1025,1124,1076,33,16,114,1100,65,132132,97,1141,131120,1105,80,5,32,80,512]

theorem envBound36019 : H12AffineFastState.Bounded env36019 := by
  intro p hp
  have h : env36019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36018_36019 : H12AffineEnvironment.transform 7 4 env36018 = env36019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env36018 == env36019) = true)

theorem identity36019 : scanCanonicalize (H12AffineFastState.compose env36019 (packedSelected [1,2,3,4,5,7,8,11] rootPS)) = affineNative (2^(16+1) ^^^ 96) := by decide +kernel

theorem selectedBound36019 : packedSelected [1,2,3,4,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env36020 : List Nat := [2,4,8,16,32,64,8,4,512,1024,81,1141,1100,113,1125,1095,96,1077,1025,1124,1076,33,16,114,1100,65,1092,97,1141,80,1105,80,5,32,80,512]

theorem envBound36020 : H12AffineFastState.Bounded env36020 := by
  intro p hp
  have h : env36020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36019_36020 : H12AffineEnvironment.transform 16 96 env36019 = env36020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 96 env36019 == env36020) = true)

theorem identity36020 : scanCanonicalize (H12AffineFastState.compose env36020 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 622) := by decide +kernel

theorem selectedBound36020 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env36021 : List Nat := [2,4,8,16,32,64,8,4,512,622,81,539,546,113,523,553,96,603,623,522,602,33,16,114,546,65,554,97,539,80,575,80,5,32,80,512]

theorem envBound36021 : H12AffineFastState.Bounded env36021 := by
  intro p hp
  have h : env36021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36020_36021 : H12AffineEnvironment.transform 9 622 env36020 = env36021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 622 env36020 == env36021) = true)

theorem identity36021 : scanCanonicalize (H12AffineFastState.compose env36021 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound36021 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36022 : List Nat := [2,4,8,16,8,64,8,4,512,582,81,539,522,89,523,513,72,603,583,522,602,9,16,90,522,65,514,73,539,80,535,80,5,8,80,512]

theorem envBound36022 : H12AffineFastState.Bounded env36022 := by
  intro p hp
  have h : env36022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36021_36022 : H12AffineEnvironment.transform 4 8 env36021 = env36022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env36021 == env36022) = true)

theorem identity36022 : scanCanonicalize (H12AffineFastState.compose env36022 (packedSelected [0,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound36022 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env36023 : List Nat := [2,4,8,16,8,64,8,4,3,69,81,24,9,89,8,2,72,88,68,9,89,9,16,90,9,65,1,73,24,80,20,80,5,8,80,3]

theorem envBound36023 : H12AffineFastState.Bounded env36023 := by
  intro p hp
  have h : env36023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36022_36023 : H12AffineEnvironment.transform 8 3 env36022 = env36023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env36022 == env36023) = true)

theorem identity36023 : scanCanonicalize (H12AffineFastState.compose env36023 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound36023 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36024 : List Nat := [2,4,0,16,0,64,0,4,3,69,81,16,1,81,0,2,64,80,68,1,81,1,16,82,1,65,1,65,16,80,20,80,5,0,80,3]

theorem envBound36024 : H12AffineFastState.Bounded env36024 := by
  intro p hp
  have h : env36024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36023_36024 : H12AffineEnvironment.transform 2 0 env36023 = env36024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env36023 == env36024) = true)

theorem identity36024 : scanCanonicalize (H12AffineFastState.compose env36024 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36024 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36025 : List Nat := [2,4,0,16,0,16,0,4,3,21,1,16,1,1,0,2,16,0,20,1,1,1,16,2,1,17,1,17,16,0,20,0,5,0,0,3]

theorem envBound36025 : H12AffineFastState.Bounded env36025 := by
  intro p hp
  have h : env36025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36024_36025 : H12AffineEnvironment.transform 5 16 env36024 = env36025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36024 == env36025) = true)

theorem identity36025 : scanCanonicalize (H12AffineFastState.compose env36025 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound36025 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36026 : List Nat := [2,4,0,6,0,6,0,4,3,3,1,6,1,1,0,2,6,0,2,1,1,1,6,2,1,7,1,7,6,0,2,0,5,0,0,3]

theorem envBound36026 : H12AffineFastState.Bounded env36026 := by
  intro p hp
  have h : env36026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36025_36026 : H12AffineEnvironment.transform 3 6 env36025 = env36026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env36025 == env36026) = true)

def env36027 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,95531,16,98645,8193,65,215367,5392,17664,179513,1364,98679,257,21792,46093,74251]

theorem envBound36027 : H12AffineFastState.Bounded env36027 := by
  intro p hp
  have h : env36027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36011_36027 : H12AffineEnvironment.transform 6 9 env36011 = env36027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36011 == env36027) = true)

theorem identity36027 : scanCanonicalize (H12AffineFastState.compose env36027 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound36027 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36028 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32040,1025,29789,4161,95531,16,95497,8193,65,215367,5392,17664,149861,1364,95531,257,21792,16465,74251]

theorem envBound36028 : H12AffineFastState.Bounded env36028 := by
  intro p hp
  have h : env36028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36027_36028 : H12AffineEnvironment.transform 14 29788 env36027 = env36028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env36027 == env36028) = true)

theorem identity36028 : scanCanonicalize (H12AffineFastState.compose env36028 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound36028 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env36029 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,79130,32040,1025,29789,4161,95531,16,95497,8193,65,31837,5392,17664,97407,1364,95531,257,21792,16465,74251]

theorem envBound36029 : H12AffineFastState.Bounded env36029 := by
  intro p hp
  have h : env36029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36028_36029 : H12AffineEnvironment.transform 16 79130 env36028 = env36029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env36028 == env36029) = true)

theorem identity36029 : scanCanonicalize (H12AffineFastState.compose env36029 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound36029 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env36030 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,16400,32040,1025,29789,4161,33,16,3,8193,65,31837,5392,17664,2421,1364,33,257,21792,16465,22273]

theorem envBound36030 : H12AffineFastState.Bounded env36030 := by
  intro p hp
  have h : env36030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36029_36030 : H12AffineEnvironment.transform 15 29962 env36029 = env36030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env36029 == env36030) = true)

theorem identity36030 : scanCanonicalize (H12AffineFastState.compose env36030 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound36030 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env36031 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6200,16384,19556,19762,16400,17680,1025,19557,4161,33,16,3,6201,65,17509,5392,17664,2421,1364,33,257,21792,16465,22273]

theorem envBound36031 : H12AffineFastState.Bounded env36031 := by
  intro p hp
  have h : env36031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36030_36031 : H12AffineEnvironment.transform 12 6200 env36030 = env36031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env36030 == env36031) = true)

theorem identity36031 : scanCanonicalize (H12AffineFastState.compose env36031 (packedSelected [0,2,7,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound36031 : packedSelected [0,2,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env36032 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1061,3101,16384,19556,19762,16400,17680,1025,19557,1124,33,16,3,3100,65,17509,309,17664,2421,1364,33,257,16645,16465,17188]

theorem envBound36032 : H12AffineFastState.Bounded env36032 := by
  intro p hp
  have h : env36032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36031_36032 : H12AffineEnvironment.transform 11 1061 env36031 = env36032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env36031 == env36032) = true)

theorem identity36032 : scanCanonicalize (H12AffineFastState.compose env36032 (packedSelected [1,4,6,7,8,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound36032 : packedSelected [1,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env36033 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1061,3101,1076,2128,2310,1060,292,1025,2129,1124,33,16,3,3100,65,81,309,308,2421,1364,33,257,1329,1125,1808]

theorem envBound36033 : H12AffineFastState.Bounded env36033 := by
  intro p hp
  have h : env36033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36032_36033 : H12AffineEnvironment.transform 13 1076 env36032 = env36033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env36032 == env36033) = true)

def env36034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,2097152,4194304,8388608,10588556,8328,65,6433956,8393985,10507601,8568104,2102685,12645453,257,21793,46213,2175563]

theorem envBound36034 : H12AffineFastState.Bounded env36034 := by
  intro p hp
  have h : env36034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35924_36034 : H12AffineEnvironment.transform 17 32041 env35924 = env36034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env35924 == env36034) = true)

def env36035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,2097152,4194304,2101328,98780,8328,65,6433956,2098513,17665,2272632,2102685,6349853,257,21793,46213,2175563]

theorem envBound36035 : H12AffineFastState.Bounded env36035 := by
  intro p hp
  have h : env36035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36034_36035 : H12AffineEnvironment.transform 22 2101328 env36034 = env36035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env36034 == env36035) = true)

def env36036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,4194304,16,98780,8328,65,4340964,5393,17665,179512,1501,4256861,257,21793,46213,74251]

theorem envBound36036 : H12AffineFastState.Bounded env36036 := by
  intro p hp
  have h : env36036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36035_36036 : H12AffineEnvironment.transform 20 4160 env36035 = env36036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36035 == env36036) = true)

theorem identity36036 : scanCanonicalize (H12AffineFastState.compose env36036 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 21929) := by decide +kernel

theorem selectedBound36036 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,21929,16,98780,8328,65,158029,5393,17665,179512,1501,41460,257,21793,46213,74251]

theorem envBound36037 : H12AffineFastState.Bounded env36037 := by
  intro p hp
  have h : env36037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36036_36037 : H12AffineEnvironment.transform 21 21929 env36036 = env36037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21929 env36036 == env36037) = true)

theorem identity36037 : scanCanonicalize (H12AffineFastState.compose env36037 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36037 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env36038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32041,1025,32769,4160,21929,16,41430,8328,65,158029,5393,17665,179512,1501,41460,257,21793,46213,513]

theorem envBound36038 : H12AffineFastState.Bounded env36038 := by
  intro p hp
  have h : env36038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36037_36038 : H12AffineEnvironment.transform 15 8202 env36037 = env36038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36037 == env36038) = true)

theorem identity36038 : scanCanonicalize (H12AffineFastState.compose env36038 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound36038 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32041,1025,32769,4160,21929,16,41430,8328,65,10589,5393,17665,64808,1501,41460,257,21793,46213,513]

theorem envBound36039 : H12AffineFastState.Bounded env36039 := by
  intro p hp
  have h : env36039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36038_36039 : H12AffineEnvironment.transform 16 16400 env36038 = env36039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env36038 == env36039) = true)

def env36040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,4194304,17,98780,8328,65,4340965,5392,17665,179513,1500,4256860,257,21793,46213,74250]

theorem envBound36040 : H12AffineFastState.Bounded env36040 := by
  intro p hp
  have h : env36040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36035_36040 : H12AffineEnvironment.transform 20 4161 env36035 = env36040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36035 == env36040) = true)

def env36041 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,4194304,17,98644,8192,65,4340845,5392,17665,179513,1364,4256860,257,21793,46093,74250]

theorem envBound36041 : H12AffineFastState.Bounded env36041 := by
  intro p hp
  have h : env36041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36040_36041 : H12AffineEnvironment.transform 6 8 env36040 = env36041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36040 == env36041) = true)

theorem identity36041 : scanCanonicalize (H12AffineFastState.compose env36041 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36041 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env36042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,4194304,17,41311,8192,65,4340845,5392,17665,179513,1364,4256860,257,21793,46093,513]

theorem envBound36042 : H12AffineFastState.Bounded env36042 := by
  intro p hp
  have h : env36042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36041_36042 : H12AffineEnvironment.transform 15 8203 env36041 = env36042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36041 == env36042) = true)

theorem identity36042 : scanCanonicalize (H12AffineFastState.compose env36042 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound36042 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env36043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32041,1025,29789,4161,4194304,17,21763,8192,65,4340845,5392,17665,149861,1364,4194304,257,21793,16465,513]

theorem envBound36043 : H12AffineFastState.Bounded env36043 := by
  intro p hp
  have h : env36043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36042_36043 : H12AffineEnvironment.transform 14 29788 env36042 = env36043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env36042 == env36043) = true)

theorem identity36043 : scanCanonicalize (H12AffineFastState.compose env36043 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 21873) := by decide +kernel

theorem selectedBound36043 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env36044 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32041,1025,29789,4161,21873,17,21763,8192,65,157980,5392,17665,149861,1364,21873,257,21793,16465,513]

theorem envBound36044 : H12AffineFastState.Bounded env36044 := by
  intro p hp
  have h : env36044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36043_36044 : H12AffineEnvironment.transform 21 21873 env36043 = env36044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21873 env36043 == env36044) = true)

theorem identity36044 : scanCanonicalize (H12AffineFastState.compose env36044 (packedSelected [0,2,4,6,7,9,11,14,32] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound36044 : packedSelected [0,2,4,6,7,9,11,14,32] rootPS < 2^1333 := by decide +kernel

def env36045 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8460,8203,131072,10361,1025,8461,4161,33,17,83,8192,65,146508,5392,4177,138293,1364,33,257,113,5377,513]

theorem envBound36045 : H12AffineFastState.Bounded env36045 := by
  intro p hp
  have h : env36045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36044_36045 : H12AffineEnvironment.transform 13 5456 env36044 = env36045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env36044 == env36045) = true)

theorem identity36045 : scanCanonicalize (H12AffineFastState.compose env36045 (packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound36045 : packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env36046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8460,8203,13388,10361,1025,8461,4161,33,17,83,8192,65,2048,5392,4177,10361,1364,33,257,113,5377,513]

theorem envBound36046 : H12AffineFastState.Bounded env36046 := by
  intro p hp
  have h : env36046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36045_36046 : H12AffineEnvironment.transform 16 13388 env36045 = env36046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env36045 == env36046) = true)

theorem identity36046 : scanCanonicalize (H12AffineFastState.compose env36046 (packedSelected [2,3,4,5,6,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36046 : packedSelected [2,3,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env36047 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,13341,10280,1025,8461,4112,33,17,2,8192,16,2048,5392,4096,10280,1285,33,257,32,5377,513]

theorem envBound36047 : H12AffineFastState.Bounded env36047 := by
  intro p hp
  have h : env36047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36046_36047 : H12AffineEnvironment.transform 5 17 env36046 = env36047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36046 == env36047) = true)

theorem identity36047 : scanCanonicalize (H12AffineFastState.compose env36047 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36047 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env36048 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,262,5392,2341,1025,0,4112,33,17,2,269,16,2048,5392,4096,2341,1285,33,257,32,5377,513]

theorem envBound36048 : H12AffineFastState.Bounded env36048 := by
  intro p hp
  have h : env36048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36047_36048 : H12AffineEnvironment.transform 12 269 env36047 = env36048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36047 == env36048) = true)

theorem identity36048 : scanCanonicalize (H12AffineFastState.compose env36048 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36048 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36049 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,1,35,5173,2048,1025,0,4112,33,17,2,40,16,2048,5173,4096,2048,1056,33,36,32,5156,513]

theorem envBound36049 : H12AffineFastState.Bounded env36049 := by
  intro p hp
  have h : env36049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36048_36049 : H12AffineEnvironment.transform 7 37 env36048 = env36049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36048 == env36049) = true)

def env36050 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1044,1,35,1029,2048,1025,0,32,33,17,2,40,16,2048,1029,48,2048,1056,33,36,32,1044,513]

theorem envBound36050 : H12AffineFastState.Bounded env36050 := by
  intro p hp
  have h : env36050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36049_36050 : H12AffineEnvironment.transform 11 48 env36049 = env36050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env36049 == env36050) = true)

theorem identity36050 : scanCanonicalize (H12AffineFastState.compose env36050 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound36050 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36051 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,48,40,1044,1,35,1029,32,1025,0,32,33,17,2,40,16,32,1029,48,32,1056,33,36,32,1044,513]

theorem envBound36051 : H12AffineFastState.Bounded env36051 := by
  intro p hp
  have h : env36051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36050_36051 : H12AffineEnvironment.transform 10 32 env36050 = env36051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env36050 == env36051) = true)

def env36052 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,40,32,1,35,49,32,53,0,32,33,17,2,40,16,32,49,48,32,20,33,36,32,32,513]

theorem envBound36052 : H12AffineFastState.Bounded env36052 := by
  intro p hp
  have h : env36052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36051_36052 : H12AffineEnvironment.transform 9 52 env36051 = env36052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36051 == env36052) = true)

theorem identity36052 : scanCanonicalize (H12AffineFastState.compose env36052 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound36052 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36053 : List Nat := [2,4,8,16,32,17,8,37,10,52,32,48,40,32,1,35,49,32,53,0,32,33,17,2,40,16,32,49,48,32,20,33,36,32,32,11]

theorem envBound36053 : H12AffineFastState.Bounded env36053 := by
  intro p hp
  have h : env36053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36052_36053 : H12AffineEnvironment.transform 8 10 env36052 = env36053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env36052 == env36053) = true)

def leafEnv36053 : List Nat := [2,4,8,16,32,17,8,37,10,52,32,48,40,32,1,35,49,32,53,0,32,33,17,2,21,40,1,16,32,49,48,32,20,33,36,32,5,35,32,11,1,32,0]

def active36053 : List Nat := [0,1,2,3,4]

def tree36053 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36053 : H12WitnessSearch.Good tree36053 := H12GlobalWitnessIndex.good

theorem leafIdentity36053 : H12AffineFastState.composeSystem env36053 rootObs = leafEnv36053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36053 rootObs == leafEnv36053) = true)

theorem terminalChecked36053 : H12PackedTerminal.terminalCheckFast leafEnv36053 active36053 tree36053 = true := by decide +kernel

def env36054 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,48,40,33,1,35,48,32,52,0,32,33,17,2,40,16,32,48,48,32,21,33,36,32,33,513]

theorem envBound36054 : H12AffineFastState.Bounded env36054 := by
  intro p hp
  have h : env36054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36051_36054 : H12AffineEnvironment.transform 9 53 env36051 = env36054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36051 == env36054) = true)

theorem identity36054 : scanCanonicalize (H12AffineFastState.compose env36054 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36054 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36055 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,8,1,1,3,16,0,20,0,0,1,17,2,8,16,0,16,16,0,21,1,4,0,1,513]

theorem envBound36055 : H12AffineFastState.Bounded env36055 := by
  intro p hp
  have h : env36055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36054_36055 : H12AffineEnvironment.transform 4 0 env36054 = env36055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36054 == env36055) = true)

def leafEnv36055 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,8,1,1,3,16,0,20,0,0,1,17,2,20,8,1,16,0,16,16,0,21,1,4,0,5,3,1,513,1,0,0]

def active36055 : List Nat := [0,1,2,3,8]

def tree36055 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36055 : H12WitnessSearch.Good tree36055 := H12GlobalWitnessIndex.good

theorem leafIdentity36055 : H12AffineFastState.composeSystem env36055 rootObs = leafEnv36055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36055 rootObs == leafEnv36055) = true)

theorem terminalChecked36055 : H12PackedTerminal.terminalCheckFast leafEnv36055 active36055 tree36055 = true := by decide +kernel

def env36056 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1045,1,35,1028,2048,1025,0,33,33,17,2,40,16,2048,1028,49,2048,1056,33,36,32,1045,513]

theorem envBound36056 : H12AffineFastState.Bounded env36056 := by
  intro p hp
  have h : env36056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36049_36056 : H12AffineEnvironment.transform 11 49 env36049 = env36056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36049 == env36056) = true)

theorem identity36056 : scanCanonicalize (H12AffineFastState.compose env36056 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound36056 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36057 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1045,49,40,1045,1,35,1028,1045,1025,0,33,33,17,2,40,16,1045,1028,49,1045,1056,33,36,32,1045,513]

theorem envBound36057 : H12AffineFastState.Bounded env36057 := by
  intro p hp
  have h : env36057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36056_36057 : H12AffineEnvironment.transform 10 1045 env36056 = env36057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env36056 == env36057) = true)

def env36058 : List Nat := [2,4,8,16,32,17,8,37,512,52,33,49,40,33,1,35,48,33,53,0,33,33,17,2,40,16,33,48,49,33,20,33,36,32,33,513]

theorem envBound36058 : H12AffineFastState.Bounded env36058 := by
  intro p hp
  have h : env36058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36057_36058 : H12AffineEnvironment.transform 9 52 env36057 = env36058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36057 == env36058) = true)

theorem identity36058 : scanCanonicalize (H12AffineFastState.compose env36058 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound36058 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36059 : List Nat := [2,4,8,16,32,17,8,37,11,52,33,49,40,33,1,35,48,33,53,0,33,33,17,2,40,16,33,48,49,33,20,33,36,32,33,10]

theorem envBound36059 : H12AffineFastState.Bounded env36059 := by
  intro p hp
  have h : env36059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36058_36059 : H12AffineEnvironment.transform 8 11 env36058 = env36059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env36058 == env36059) = true)

def leafEnv36059 : List Nat := [2,4,8,16,32,17,8,37,11,52,33,49,40,33,1,35,48,33,53,0,33,33,17,2,21,40,1,16,33,48,49,33,20,33,36,32,5,35,33,10,1,33,0]

def active36059 : List Nat := [0,1,2,3,4]

def tree36059 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36059 : H12WitnessSearch.Good tree36059 := H12GlobalWitnessIndex.good

theorem leafIdentity36059 : H12AffineFastState.composeSystem env36059 rootObs = leafEnv36059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36059 rootObs == leafEnv36059) = true)

theorem terminalChecked36059 : H12PackedTerminal.terminalCheckFast leafEnv36059 active36059 tree36059 = true := by decide +kernel

def env36060 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,40,32,1,35,49,32,52,0,33,33,17,2,40,16,32,49,49,32,21,33,36,32,32,513]

theorem envBound36060 : H12AffineFastState.Bounded env36060 := by
  intro p hp
  have h : env36060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36057_36060 : H12AffineEnvironment.transform 9 53 env36057 = env36060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36057 == env36060) = true)

theorem identity36060 : scanCanonicalize (H12AffineFastState.compose env36060 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36060 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36061 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,8,0,1,3,17,0,20,0,1,1,17,2,8,16,0,17,17,0,21,1,4,0,0,513]

theorem envBound36061 : H12AffineFastState.Bounded env36061 := by
  intro p hp
  have h : env36061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36060_36061 : H12AffineEnvironment.transform 4 0 env36060 = env36061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36060 == env36061) = true)

def leafEnv36061 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,8,0,1,3,17,0,20,0,1,1,17,2,20,8,1,16,0,17,17,0,21,1,4,0,5,3,0,513,1,1,0]

def active36061 : List Nat := [0,1,2,3,8]

def tree36061 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36061 : H12WitnessSearch.Good tree36061 := H12GlobalWitnessIndex.good

theorem leafIdentity36061 : H12AffineFastState.composeSystem env36061 rootObs = leafEnv36061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36061 rootObs == leafEnv36061) = true)

theorem terminalChecked36061 : H12PackedTerminal.terminalCheckFast leafEnv36061 active36061 tree36061 = true := by decide +kernel

def env36062 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,4194304,17,98645,8193,65,4340844,5392,17665,179513,1365,4256860,257,21793,46092,74250]

theorem envBound36062 : H12AffineFastState.Bounded env36062 := by
  intro p hp
  have h : env36062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36040_36062 : H12AffineEnvironment.transform 6 9 env36040 = env36062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36040 == env36062) = true)

theorem identity36062 : scanCanonicalize (H12AffineFastState.compose env36062 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36062 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36063 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,32041,1025,8540,4161,4194304,17,73736,8193,65,4340844,5392,17665,138340,1365,4216065,257,21793,5457,74250]

theorem envBound36063 : H12AffineFastState.Bounded env36063 := by
  intro p hp
  have h : env36063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36062_36063 : H12AffineEnvironment.transform 14 8541 env36062 = env36063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36062 == env36063) = true)

theorem identity36063 : scanCanonicalize (H12AffineFastState.compose env36063 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 136496) := by decide +kernel

theorem selectedBound36063 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env36064 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,32041,1025,8540,4161,136496,17,73736,8193,65,10588,5392,17665,138340,1365,147505,257,21793,5457,74250]

theorem envBound36064 : H12AffineFastState.Bounded env36064 := by
  intro p hp
  have h : env36064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36063_36064 : H12AffineEnvironment.transform 21 136496 env36063 = env36064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136496 env36063 == env36064) = true)

def env36065 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,32041,1025,8540,4161,21792,17,73736,8193,65,10588,5392,17665,23668,1365,33,257,21793,5457,74250]

theorem envBound36065 : H12AffineFastState.Bounded env36065 := by
  intro p hp
  have h : env36065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36064_36065 : H12AffineEnvironment.transform 16 16400 env36064 = env36065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env36064 == env36065) = true)

theorem identity36065 : scanCanonicalize (H12AffineFastState.compose env36065 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound36065 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env36066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,380,16384,33,65536,16400,23637,1025,32,4161,21792,17,65908,381,65,2080,5392,17665,23668,1365,33,257,21793,5457,66422]

theorem envBound36066 : H12AffineFastState.Bounded env36066 := by
  intro p hp
  have h : env36066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36065_36066 : H12AffineEnvironment.transform 12 380 env36065 = env36066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env36065 == env36066) = true)

def env36067 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,32041,1025,8540,4161,21793,17,73736,8193,65,10588,5392,17665,23669,1365,32,257,21793,5457,74250]

theorem envBound36067 : H12AffineFastState.Bounded env36067 := by
  intro p hp
  have h : env36067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36064_36067 : H12AffineEnvironment.transform 16 16401 env36064 = env36067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env36064 == env36067) = true)

theorem identity36067 : scanCanonicalize (H12AffineFastState.compose env36067 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound36067 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env36068 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,372,65536,16401,23808,1025,373,4161,21793,17,65569,40,65,2421,5392,17665,23669,1365,32,257,21793,5457,66083]

theorem envBound36068 : H12AffineFastState.Bounded env36068 := by
  intro p hp
  have h : env36068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36067_36068 : H12AffineEnvironment.transform 12 41 env36067 = env36068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env36067 == env36068) = true)

theorem identity36068 : scanCanonicalize (H12AffineFastState.compose env36068 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound36068 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env36069 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,372,65536,5221,2420,1025,373,4161,341,17,65569,40,65,2421,5392,4469,2049,1365,32,257,341,5457,66083]

theorem envBound36069 : H12AffineFastState.Bounded env36069 := by
  intro p hp
  have h : env36069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36068_36069 : H12AffineEnvironment.transform 13 5236 env36068 = env36069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env36068 == env36069) = true)

theorem identity36069 : scanCanonicalize (H12AffineFastState.compose env36069 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound36069 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env36070 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,372,34,5221,2420,1025,373,4161,341,17,3,40,65,2421,5392,4469,2049,1365,32,257,341,5457,513]

theorem envBound36070 : H12AffineFastState.Bounded env36070 := by
  intro p hp
  have h : env36070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36069_36070 : H12AffineEnvironment.transform 15 34 env36069 = env36070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env36069 == env36070) = true)

theorem identity36070 : scanCanonicalize (H12AffineFastState.compose env36070 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36070 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36071 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,41,5236,80,34,5221,2128,1025,81,4161,113,17,3,40,65,2129,5172,4177,2049,1137,32,37,113,5237,513]

theorem envBound36071 : H12AffineFastState.Bounded env36071 := by
  intro p hp
  have h : env36071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36070_36071 : H12AffineEnvironment.transform 7 36 env36070 = env36071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36070 == env36071) = true)

theorem identity36071 : scanCanonicalize (H12AffineFastState.compose env36071 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound36071 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36072 : List Nat := [2,4,8,16,32,64,9,36,512,53,2048,4096,41,4161,80,34,4176,2128,52,81,4161,113,17,3,40,65,2129,4097,4177,2049,68,32,37,113,4160,513]

theorem envBound36072 : H12AffineFastState.Bounded env36072 := by
  intro p hp
  have h : env36072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36071_36072 : H12AffineEnvironment.transform 9 53 env36071 = env36072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36071 == env36072) = true)

def env36073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,2097152,4194304,2101329,98781,8328,65,6433956,2098512,17664,2272633,2102685,6349852,257,21793,46213,2175563]

theorem envBound36073 : H12AffineFastState.Bounded env36073 := by
  intro p hp
  have h : env36073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36034_36073 : H12AffineEnvironment.transform 22 2101329 env36034 = env36073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env36034 == env36073) = true)

def env36074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,4194304,17,98781,8328,65,4340964,5392,17664,179513,1501,4256860,257,21793,46213,74251]

theorem envBound36074 : H12AffineFastState.Bounded env36074 := by
  intro p hp
  have h : env36074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36073_36074 : H12AffineEnvironment.transform 20 4160 env36073 = env36074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36073 == env36074) = true)

theorem identity36074 : scanCanonicalize (H12AffineFastState.compose env36074 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound36074 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32041,1025,29909,4160,4194304,17,95497,8328,65,4340964,5392,17664,149997,1501,4194440,257,21793,16465,74251]

theorem envBound36075 : H12AffineFastState.Bounded env36075 := by
  intro p hp
  have h : env36075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36074_36075 : H12AffineEnvironment.transform 14 29908 env36074 = env36075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env36074 == env36075) = true)

def env36076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10281,1025,8661,4160,4194304,17,73737,8328,65,4340964,5392,4096,138477,1501,4194440,257,33,5457,74251]

theorem envBound36076 : H12AffineFastState.Bounded env36076 := by
  intro p hp
  have h : env36076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36075_36076 : H12AffineEnvironment.transform 13 5376 env36075 = env36076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36075 == env36076) = true)

theorem identity36076 : scanCanonicalize (H12AffineFastState.compose env36076 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound36076 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env36077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5392,10281,1025,8661,4160,4194304,17,73737,8328,65,4205044,5392,4096,2557,1501,4194440,257,33,5457,74251]

theorem envBound36077 : H12AffineFastState.Bounded env36077 := by
  intro p hp
  have h : env36077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36076_36077 : H12AffineEnvironment.transform 16 5392 env36076 = env36077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env36076 == env36077) = true)

theorem identity36077 : scanCanonicalize (H12AffineFastState.compose env36077 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 1464) := by decide +kernel

theorem selectedBound36077 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env36078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5392,10281,1025,8661,4160,1464,17,73737,8328,65,11340,5392,4096,2557,1501,1328,257,33,5457,74251]

theorem envBound36078 : H12AffineFastState.Bounded env36078 := by
  intro p hp
  have h : env36078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36077_36078 : H12AffineEnvironment.transform 21 1464 env36077 = env36078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1464 env36077 == env36078) = true)

theorem identity36078 : scanCanonicalize (H12AffineFastState.compose env36078 (packedSelected [0,1,2,4,5,6,9,10,15,16,24,27,28,38] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound36078 : packedSelected [0,1,2,4,5,6,9,10,15,16,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env36079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,80,65536,5392,2477,1025,81,4160,1464,17,65933,268,65,3528,5392,4096,2557,1501,1328,257,33,5457,66447]

theorem envBound36079 : H12AffineFastState.Bounded env36079 := by
  intro p hp
  have h : env36079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36078_36079 : H12AffineEnvironment.transform 12 388 env36078 = env36079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env36078 == env36079) = true)

theorem identity36079 : scanCanonicalize (H12AffineFastState.compose env36079 (packedSelected [0,2,6,7,11,20,23] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound36079 : packedSelected [0,2,6,7,11,20,23] rootPS < 2^1333 := by decide +kernel

def env36080 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,40,5292,80,65536,5308,2049,1025,81,4160,1044,17,65569,160,65,3172,5308,4096,2129,1137,1180,173,33,5373,66083]

theorem envBound36080 : H12AffineFastState.Bounded env36080 := by
  intro p hp
  have h : env36080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36079_36080 : H12AffineEnvironment.transform 7 172 env36079 = env36080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env36079 == env36080) = true)

theorem identity36080 : scanCanonicalize (H12AffineFastState.compose env36080 (packedSelected [3,5,10,11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound36080 : packedSelected [3,5,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env36081 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,40,5292,80,35,5308,2049,1025,81,4160,1044,17,2,160,65,3172,5308,4096,2129,1137,1180,173,33,5373,512]

theorem envBound36081 : H12AffineFastState.Bounded env36081 := by
  intro p hp
  have h : env36081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36080_36081 : H12AffineEnvironment.transform 15 35 env36080 = env36081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env36080 == env36081) = true)

theorem identity36081 : scanCanonicalize (H12AffineFastState.compose env36081 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound36081 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env36082 : List Nat := [2,4,8,16,32,64,128,172,512,21,2048,4096,40,4281,80,35,4265,2049,20,81,4160,1,17,2,160,65,2161,4265,4096,2129,100,137,173,33,4328,512]

theorem envBound36082 : H12AffineFastState.Bounded env36082 := by
  intro p hp
  have h : env36082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36081_36082 : H12AffineEnvironment.transform 9 21 env36081 = env36082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env36081 == env36082) = true)

theorem identity36082 : scanCanonicalize (H12AffineFastState.compose env36082 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36082 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36083 : List Nat := [2,4,8,16,1,64,128,141,512,21,2048,4096,9,4248,80,2,4232,2049,20,81,4160,1,17,2,129,65,2128,4232,4096,2129,69,137,140,0,4297,512]

theorem envBound36083 : H12AffineFastState.Bounded env36083 := by
  intro p hp
  have h : env36083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36082_36083 : H12AffineEnvironment.transform 4 1 env36082 = env36083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36082 == env36083) = true)

theorem identity36083 : scanCanonicalize (H12AffineFastState.compose env36083 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36083 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36084 : List Nat := [2,4,8,16,1,16,128,141,512,21,2048,4096,9,4248,0,2,4232,2049,20,1,4112,1,17,2,129,17,2048,4232,4096,2049,21,137,140,0,4249,512]

theorem envBound36084 : H12AffineFastState.Bounded env36084 := by
  intro p hp
  have h : env36084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36083_36084 : H12AffineEnvironment.transform 5 16 env36083 = env36084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36083 == env36084) = true)

theorem identity36084 : scanCanonicalize (H12AffineFastState.compose env36084 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36084 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36085 : List Nat := [2,4,8,16,1,16,8,5,512,21,2048,4096,9,4112,0,2,4096,2049,20,1,4112,1,17,2,9,17,2048,4096,4096,2049,21,1,4,0,4113,512]

theorem envBound36085 : H12AffineFastState.Bounded env36085 := by
  intro p hp
  have h : env36085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36084_36085 : H12AffineEnvironment.transform 6 8 env36084 = env36085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36084 == env36085) = true)

theorem identity36085 : scanCanonicalize (H12AffineFastState.compose env36085 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound36085 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36086 : List Nat := [2,4,8,16,1,16,8,5,0,21,2048,4096,9,4112,0,2,4096,2049,20,1,4112,1,17,2,9,17,2048,4096,4096,2049,21,1,4,0,4113,0]

theorem envBound36086 : H12AffineFastState.Bounded env36086 := by
  intro p hp
  have h : env36086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36085_36086 : H12AffineEnvironment.transform 8 0 env36085 = env36086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env36085 == env36086) = true)

theorem identity36086 : scanCanonicalize (H12AffineFastState.compose env36086 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound36086 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36087 : List Nat := [2,4,8,4,1,4,8,5,0,1,2048,4096,9,4100,0,2,4096,2049,0,1,4100,1,5,2,9,5,2048,4096,4096,2049,1,1,4,0,4101,0]

theorem envBound36087 : H12AffineFastState.Bounded env36087 := by
  intro p hp
  have h : env36087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36086_36087 : H12AffineEnvironment.transform 3 4 env36086 = env36087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env36086 == env36087) = true)

theorem identity36087 : scanCanonicalize (H12AffineFastState.compose env36087 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 2053) := by decide +kernel

theorem selectedBound36087 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36088 : List Nat := [2,4,8,4,1,4,8,5,0,1,2048,2053,9,2049,0,2,2053,2049,0,1,2049,1,5,2,9,5,2048,2053,2053,2049,1,1,4,0,2048,0]

theorem envBound36088 : H12AffineFastState.Bounded env36088 := by
  intro p hp
  have h : env36088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36087_36088 : H12AffineEnvironment.transform 11 2053 env36087 = env36088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2053 env36087 == env36088) = true)

def leafEnv36088 : List Nat := [2,4,8,4,1,4,8,5,0,1,2048,2053,9,2049,0,2,2053,2049,0,1,2049,1,5,2,0,9,1,5,2048,2053,2053,2049,1,1,4,0,5,2,2048,0,1,2048,0]

def active36088 : List Nat := [0,1,2,10]

def tree36088 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36088 : H12WitnessSearch.Good tree36088 := H12GlobalWitnessIndex.good

theorem leafIdentity36088 : H12AffineFastState.composeSystem env36088 rootObs = leafEnv36088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36088 rootObs == leafEnv36088) = true)

theorem terminalChecked36088 : H12PackedTerminal.terminalCheckFast leafEnv36088 active36088 tree36088 = true := by decide +kernel

def env36089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10280,1025,8660,4160,4194304,17,73736,8328,65,4340964,5392,4097,138476,1501,4194440,257,32,5456,74251]

theorem envBound36089 : H12AffineFastState.Bounded env36089 := by
  intro p hp
  have h : env36089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36075_36089 : H12AffineEnvironment.transform 13 5377 env36075 = env36089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36075 == env36089) = true)

theorem identity36089 : scanCanonicalize (H12AffineFastState.compose env36089 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36089 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36090 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10280,1025,8540,4160,4194304,17,73736,8192,65,4340844,5392,4097,138340,1365,4194304,257,32,5456,74251]

theorem envBound36090 : H12AffineFastState.Bounded env36090 := by
  intro p hp
  have h : env36090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36089_36090 : H12AffineEnvironment.transform 6 8 env36089 = env36090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36089 == env36090) = true)

theorem identity36090 : scanCanonicalize (H12AffineFastState.compose env36090 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 210235) := by decide +kernel

theorem selectedBound36090 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env36091 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10280,1025,8540,4160,210235,17,73736,8192,65,67927,5392,4097,138340,1365,210235,257,32,5456,74251]

theorem envBound36091 : H12AffineFastState.Bounded env36091 := by
  intro p hp
  have h : env36091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36090_36091 : H12AffineEnvironment.transform 21 210235 env36090 = env36091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 210235 env36090 == env36091) = true)

def env36092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,4194304,16,98781,8328,65,4340965,5393,17664,179512,1500,4256861,257,21793,46213,74250]

theorem envBound36092 : H12AffineFastState.Bounded env36092 := by
  intro p hp
  have h : env36092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36073_36092 : H12AffineEnvironment.transform 20 4161 env36073 = env36092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36073 == env36092) = true)

theorem identity36092 : scanCanonicalize (H12AffineFastState.compose env36092 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound36092 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,41341,16,98781,8328,65,171416,5393,17664,179512,1500,21792,257,21793,46213,74250]

theorem envBound36093 : H12AffineFastState.Bounded env36093 := by
  intro p hp
  have h : env36093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36092_36093 : H12AffineEnvironment.transform 21 41341 env36092 = env36093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env36092 == env36093) = true)

theorem identity36093 : scanCanonicalize (H12AffineFastState.compose env36093 (packedSelected [0,1,3,5,8,9,10,11,14,15,19,22,27,32,35,38] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound36093 : packedSelected [0,1,3,5,8,9,10,11,14,15,19,22,27,32,35,38] rootPS < 2^1333 := by decide +kernel

def env36094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13445,32768,65536,131072,2476,1025,32769,4161,41341,16,98781,8328,65,171416,5393,12677,179512,1500,8613,257,8612,46213,74250]

theorem envBound36094 : H12AffineFastState.Bounded env36094 := by
  intro p hp
  have h : env36094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36093_36094 : H12AffineEnvironment.transform 13 13445 env36093 = env36094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env36093 == env36094) = true)

theorem identity36094 : scanCanonicalize (H12AffineFastState.compose env36094 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound36094 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env36095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13445,32768,263,131072,2476,1025,32769,4161,41341,16,32986,8328,65,171416,5393,12677,179512,1500,8613,257,8612,46213,8973]

theorem envBound36095 : H12AffineFastState.Bounded env36095 := by
  intro p hp
  have h : env36095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36094_36095 : H12AffineEnvironment.transform 15 263 env36094 = env36095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env36094 == env36095) = true)

theorem identity36095 : scanCanonicalize (H12AffineFastState.compose env36095 (packedSelected [3,10,16,17,19,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound36095 : packedSelected [3,10,16,17,19,20,24] rootPS < 2^1333 := by decide +kernel

def env36096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13445,32768,263,46277,2476,1025,32769,4161,41341,16,32986,8328,65,10589,5393,12677,2557,1500,8613,257,8612,46213,8973]

theorem envBound36096 : H12AffineFastState.Bounded env36096 := by
  intro p hp
  have h : env36096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36095_36096 : H12AffineEnvironment.transform 16 46277 env36095 = env36096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env36095 == env36096) = true)

theorem identity36096 : scanCanonicalize (H12AffineFastState.compose env36096 (packedSelected [0,4,7,11,12,15,16,18,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound36096 : packedSelected [0,4,7,11,12,15,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env36097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,32768,263,38345,2476,1025,32769,4161,32881,16,32986,388,65,2129,5393,4233,2557,1500,169,257,168,38281,513]

theorem envBound36097 : H12AffineFastState.Bounded env36097 := by
  intro p hp
  have h : env36097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36096_36097 : H12AffineEnvironment.transform 12 268 env36096 = env36097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env36096 == env36097) = true)

theorem identity36097 : scanCanonicalize (H12AffineFastState.compose env36097 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound36097 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,81,263,5528,2476,1025,80,4161,32,16,139,388,65,2129,5393,4233,2557,1500,169,257,168,5592,513]

theorem envBound36098 : H12AffineFastState.Bounded env36098 := by
  intro p hp
  have h : env36098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36097_36098 : H12AffineEnvironment.transform 14 81 env36097 = env36098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env36097 == env36098) = true)

theorem identity36098 : scanCanonicalize (H12AffineFastState.compose env36098 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound36098 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36099 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5456,81,263,5441,2421,1025,80,4161,32,16,82,349,65,2129,5393,4176,2340,1285,112,257,113,5377,513]

theorem envBound36099 : H12AffineFastState.Bounded env36099 := by
  intro p hp
  have h : env36099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36098_36099 : H12AffineEnvironment.transform 6 89 env36098 = env36099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env36098 == env36099) = true)

theorem identity36099 : scanCanonicalize (H12AffineFastState.compose env36099 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound36099 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env36100 : List Nat := [2,4,8,16,32,64,89,256,32,1024,2048,4096,268,5456,81,263,5441,2421,1025,80,4161,32,16,82,349,65,2129,5393,4176,2340,1285,112,257,113,5377,33]

theorem envBound36100 : H12AffineFastState.Bounded env36100 := by
  intro p hp
  have h : env36100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36099_36100 : H12AffineEnvironment.transform 8 32 env36099 = env36100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env36099 == env36100) = true)

theorem identity36100 : scanCanonicalize (H12AffineFastState.compose env36100 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound36100 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env36101 : List Nat := [2,4,8,16,32,64,89,256,32,1024,2048,1045,268,325,81,263,340,2421,1025,80,1108,32,16,82,349,65,2129,260,1093,2340,1285,112,257,113,276,33]

theorem envBound36101 : H12AffineFastState.Bounded env36101 := by
  intro p hp
  have h : env36101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36100_36101 : H12AffineEnvironment.transform 11 1045 env36100 = env36101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env36100 == env36101) = true)

def env36102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356289,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound36102 : H12AffineFastState.Bounded env36102 := by
  intro p hp
  have h : env36102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35699_36102 : H12AffineEnvironment.transform 26 30393345 env35699 = env36102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env35699 == env36102) = true)

def env36103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound36103 : H12AffineFastState.Bounded env36103 := by
  intro p hp
  have h : env36103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36102_36103 : H12AffineEnvironment.transform 18 1024 env36102 = env36103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env36102 == env36103) = true)

theorem identity36103 : scanCanonicalize (H12AffineFastState.compose env36103 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 485860) := by decide +kernel

theorem selectedBound36103 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,485860,8328,65,12626405,2551144,10507601,8830977,8842741,6687780,256,10923337,10898669,8899106]

theorem envBound36104 : H12AffineFastState.Bounded env36104 := by
  intro p hp
  have h : env36104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36103_36104 : H12AffineEnvironment.transform 23 485860 env36103 = env36104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 485860 env36103 == env36104) = true)

def env36105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2553960,485860,8328,65,6705549,2551144,437561,2111593,2102685,6687780,256,21793,46213,2175562]

theorem envBound36105 : H12AffineFastState.Bounded env36105 := by
  intro p hp
  have h : env36105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36104_36105 : H12AffineEnvironment.transform 22 2553960 env36104 = env36105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2553960 env36104 == env36105) = true)

def env36106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,2101328,98780,8328,65,6338997,2098512,17665,2111593,2102685,6349852,256,21793,46213,2175562]

theorem envBound36106 : H12AffineFastState.Bounded env36106 := by
  intro p hp
  have h : env36106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36105_36106 : H12AffineEnvironment.transform 17 190520 env36105 = env36106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env36105 == env36106) = true)

def env36107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,98780,8328,65,4237813,5392,17665,10281,1501,4256860,256,21793,46213,74250]

theorem envBound36107 : H12AffineFastState.Bounded env36107 := by
  intro p hp
  have h : env36107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36106_36107 : H12AffineEnvironment.transform 20 4160 env36106 = env36107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36106 == env36107) = true)

theorem identity36107 : scanCanonicalize (H12AffineFastState.compose env36107 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound36107 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,190520,1024,32769,4160,4194304,16,21763,8328,65,4237813,5392,17665,10281,1501,4256860,256,21793,46213,63189]

theorem envBound36108 : H12AffineFastState.Bounded env36108 := by
  intro p hp
  have h : env36108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36107_36108 : H12AffineEnvironment.transform 15 54495 env36107 = env36108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env36107 == env36108) = true)

def env36109 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190520,1024,32769,4160,4194304,16,21763,8192,65,4237693,5392,17665,10281,1365,4256860,256,21793,46093,63069]

theorem envBound36109 : H12AffineFastState.Bounded env36109 := by
  intro p hp
  have h : env36109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36108_36109 : H12AffineEnvironment.transform 6 8 env36108 = env36109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36108 == env36109) = true)

theorem identity36109 : scanCanonicalize (H12AffineFastState.compose env36109 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound36109 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36110 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,10280,1024,32769,4160,4194304,16,21763,8192,65,4237693,5392,17665,10281,1365,4256860,256,21793,46093,63069]

theorem envBound36110 : H12AffineFastState.Bounded env36110 := by
  intro p hp
  have h : env36110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36109_36110 : H12AffineEnvironment.transform 16 49168 env36109 = env36110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env36109 == env36110) = true)

theorem identity36110 : scanCanonicalize (H12AffineFastState.compose env36110 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound36110 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env36111 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,21510,16449,10280,1024,80,4160,4194304,16,21763,8192,65,4204844,5392,17665,10281,1365,4224013,256,21793,13404,30220]

theorem envBound36111 : H12AffineFastState.Bounded env36111 := by
  intro p hp
  have h : env36111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36110_36111 : H12AffineEnvironment.transform 14 81 env36110 = env36111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env36110 == env36111) = true)

theorem identity36111 : scanCanonicalize (H12AffineFastState.compose env36111 (packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound36111 : packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env36112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,81,21510,16449,2420,1024,80,4160,4194304,16,21763,348,65,4196464,5392,17665,2421,1365,4216145,256,21793,5376,22352]

theorem envBound36112 : H12AffineFastState.Bounded env36112 := by
  intro p hp
  have h : env36112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36111_36112 : H12AffineEnvironment.transform 12 348 env36111 = env36112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env36111 == env36112) = true)

theorem identity36112 : scanCanonicalize (H12AffineFastState.compose env36112 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound36112 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,81,263,5440,2420,1024,80,4160,4194304,16,2,348,65,4196464,5392,4096,2421,1365,4194384,256,32,5376,593]

theorem envBound36113 : H12AffineFastState.Bounded env36113 := by
  intro p hp
  have h : env36113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36112_36113 : H12AffineEnvironment.transform 13 5377 env36112 = env36113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36112 == env36113) = true)

theorem identity36113 : scanCanonicalize (H12AffineFastState.compose env36113 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound36113 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env36114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,81,263,5440,2420,1024,80,4160,113,16,2,348,65,2049,5392,4096,2421,1365,33,256,32,5376,593]

theorem envBound36114 : H12AffineFastState.Bounded env36114 := by
  intro p hp
  have h : env36114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36113_36114 : H12AffineEnvironment.transform 21 113 env36113 = env36114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env36113 == env36114) = true)

theorem identity36114 : scanCanonicalize (H12AffineFastState.compose env36114 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3409) := by decide +kernel

theorem selectedBound36114 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env36115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3409,348,2128,81,263,2065,2420,1024,80,3345,113,16,2,348,65,2049,2113,3409,2421,1365,33,256,32,2129,593]

theorem envBound36115 : H12AffineFastState.Bounded env36115 := by
  intro p hp
  have h : env36115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36114_36115 : H12AffineEnvironment.transform 11 3409 env36114 = env36115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3409 env36114 == env36115) = true)

theorem identity36115 : scanCanonicalize (H12AffineFastState.compose env36115 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound36115 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env36116 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,2357,348,2128,81,263,2065,2420,100,80,2421,113,16,2,348,65,2049,2113,2357,2421,305,33,256,32,2129,593]

theorem envBound36116 : H12AffineFastState.Bounded env36116 := by
  intro p hp
  have h : env36116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36115_36116 : H12AffineEnvironment.transform 9 100 env36115 = env36116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env36115 == env36116) = true)

theorem identity36116 : scanCanonicalize (H12AffineFastState.compose env36116 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36116 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36117 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,2065,120,2128,81,35,2065,2128,100,80,2129,113,16,2,120,65,2049,2113,2065,2129,21,33,36,32,2129,593]

theorem envBound36117 : H12AffineFastState.Bounded env36117 := by
  intro p hp
  have h : env36117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36116_36117 : H12AffineEnvironment.transform 7 36 env36116 = env36117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36116 == env36117) = true)

theorem identity36117 : scanCanonicalize (H12AffineFastState.compose env36117 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound36117 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env36118 : List Nat := [2,4,8,16,32,64,8,36,512,100,64,81,120,16,81,35,81,16,100,80,17,113,16,2,120,65,65,1,81,17,21,33,36,32,17,593]

theorem envBound36118 : H12AffineFastState.Bounded env36118 := by
  intro p hp
  have h : env36118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36117_36118 : H12AffineEnvironment.transform 10 64 env36117 = env36118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env36117 == env36118) = true)

theorem identity36118 : scanCanonicalize (H12AffineFastState.compose env36118 (packedSelected [0,6,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36118 : packedSelected [0,6,9] rootPS < 2^1333 := by decide +kernel

def env36119 : List Nat := [2,4,8,16,32,17,8,36,512,53,17,0,41,16,0,35,0,16,53,1,17,32,16,2,41,16,16,1,0,17,21,33,36,32,17,512]

theorem envBound36119 : H12AffineFastState.Bounded env36119 := by
  intro p hp
  have h : env36119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36118_36119 : H12AffineEnvironment.transform 5 17 env36118 = env36119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36118 == env36119) = true)

theorem identity36119 : scanCanonicalize (H12AffineFastState.compose env36119 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound36119 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36120 : List Nat := [2,4,8,16,20,17,8,16,512,1,17,0,29,16,0,23,0,16,1,1,17,20,16,2,29,16,16,1,0,17,21,21,16,20,17,512]

theorem envBound36120 : H12AffineFastState.Bounded env36120 := by
  intro p hp
  have h : env36120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36119_36120 : H12AffineEnvironment.transform 4 20 env36119 = env36120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env36119 == env36120) = true)

theorem identity36120 : scanCanonicalize (H12AffineFastState.compose env36120 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 24) := by decide +kernel

theorem selectedBound36120 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36121 : List Nat := [2,4,8,16,20,17,8,16,24,1,17,0,29,16,0,23,0,16,1,1,17,20,16,2,29,16,16,1,0,17,21,21,16,20,17,24]

theorem envBound36121 : H12AffineFastState.Bounded env36121 := by
  intro p hp
  have h : env36121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36120_36121 : H12AffineEnvironment.transform 8 24 env36120 = env36121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 24 env36120 == env36121) = true)

theorem identity36121 : scanCanonicalize (H12AffineFastState.compose env36121 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound36121 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36122 : List Nat := [2,0,8,16,16,17,8,16,24,1,17,0,25,16,0,19,0,16,1,1,17,16,16,2,25,16,16,1,0,17,17,17,16,16,17,24]

theorem envBound36122 : H12AffineFastState.Bounded env36122 := by
  intro p hp
  have h : env36122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36121_36122 : H12AffineEnvironment.transform 1 0 env36121 = env36122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env36121 == env36122) = true)

theorem identity36122 : scanCanonicalize (H12AffineFastState.compose env36122 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36122 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36123 : List Nat := [2,0,3,16,16,17,3,16,19,1,17,0,18,16,0,19,0,16,1,1,17,16,16,2,18,16,16,1,0,17,17,17,16,16,17,19]

theorem envBound36123 : H12AffineFastState.Bounded env36123 := by
  intro p hp
  have h : env36123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36122_36123 : H12AffineEnvironment.transform 2 3 env36122 = env36123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36122 == env36123) = true)

theorem identity36123 : scanCanonicalize (H12AffineFastState.compose env36123 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36123 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36124 : List Nat := [2,0,3,1,1,0,3,1,2,1,0,0,3,1,0,2,0,1,1,1,0,1,1,2,3,1,1,1,0,0,0,0,1,1,0,2]

theorem envBound36124 : H12AffineFastState.Bounded env36124 := by
  intro p hp
  have h : env36124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36123_36124 : H12AffineEnvironment.transform 3 1 env36123 = env36124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36123 == env36124) = true)

def env36125 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190520,1024,32769,4160,4194304,16,21763,8193,65,4237692,5392,17665,10281,1364,4256860,256,21793,46092,63068]

theorem envBound36125 : H12AffineFastState.Bounded env36125 := by
  intro p hp
  have h : env36125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36108_36125 : H12AffineEnvironment.transform 6 9 env36108 = env36125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36108 == env36125) = true)

theorem identity36125 : scanCanonicalize (H12AffineFastState.compose env36125 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound36125 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36126 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,24909,35189,1024,32769,4160,4194304,16,21763,8193,65,4237692,5392,17665,10281,1364,4256860,256,21793,46092,63068]

theorem envBound36126 : H12AffineFastState.Bounded env36126 := by
  intro p hp
  have h : env36126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36125_36126 : H12AffineEnvironment.transform 16 24909 env36125 = env36126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env36125 == env36126) = true)

theorem identity36126 : scanCanonicalize (H12AffineFastState.compose env36126 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 29821) := by decide +kernel

theorem selectedBound36126 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36127 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,24909,35189,1024,32769,4160,29821,16,21763,8193,65,56577,5392,17665,10281,1364,32801,256,21793,46092,63068]

theorem envBound36127 : H12AffineFastState.Bounded env36127 := by
  intro p hp
  have h : env36127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36126_36127 : H12AffineEnvironment.transform 21 29821 env36126 = env36127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29821 env36126 == env36127) = true)

theorem identity36127 : scanCanonicalize (H12AffineFastState.compose env36127 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound36127 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env36128 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,343,24909,23668,1024,21760,4160,29821,16,21763,8193,65,2048,5392,17665,10281,1364,21792,256,21793,24845,9053]

theorem envBound36128 : H12AffineFastState.Bounded env36128 := by
  intro p hp
  have h : env36128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36127_36128 : H12AffineEnvironment.transform 14 21761 env36127 = env36128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env36127 == env36128) = true)

theorem identity36128 : scanCanonicalize (H12AffineFastState.compose env36128 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound36128 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env36129 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,343,13388,2421,1024,1,4160,8572,16,2,8193,65,2048,5392,4096,10281,1364,33,256,32,13324,9053]

theorem envBound36129 : H12AffineFastState.Bounded env36129 := by
  intro p hp
  have h : env36129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36128_36129 : H12AffineEnvironment.transform 13 5377 env36128 = env36129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36128 == env36129) = true)

theorem identity36129 : scanCanonicalize (H12AffineFastState.compose env36129 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36129 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36130 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,8192,5377,0,343,13388,2389,1024,1,4160,8540,16,2,8193,65,2048,5392,4096,10249,1364,1,256,0,13324,9053]

theorem envBound36130 : H12AffineFastState.Bounded env36130 := by
  intro p hp
  have h : env36130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36129_36130 : H12AffineEnvironment.transform 4 0 env36129 = env36130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36129 == env36130) = true)

theorem identity36130 : scanCanonicalize (H12AffineFastState.compose env36130 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound36130 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env36131 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,9,5377,0,343,5189,2389,1024,1,4160,341,16,2,8,65,2048,5392,4096,2048,1364,1,256,0,5125,852]

theorem envBound36131 : H12AffineFastState.Bounded env36131 := by
  intro p hp
  have h : env36131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36130_36131 : H12AffineEnvironment.transform 12 9 env36130 = env36131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env36130 == env36131) = true)

theorem identity36131 : scanCanonicalize (H12AffineFastState.compose env36131 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound36131 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env36132 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,3408,9,2129,0,343,2325,2389,1024,1,3344,341,16,2,8,65,2048,2112,3408,2048,1364,1,256,0,2389,852]

theorem envBound36132 : H12AffineFastState.Bounded env36132 := by
  intro p hp
  have h : env36132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36131_36132 : H12AffineEnvironment.transform 11 3408 env36131 = env36132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env36131 == env36132) = true)

theorem identity36132 : scanCanonicalize (H12AffineFastState.compose env36132 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound36132 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env36133 : List Nat := [2,4,8,16,0,64,9,4,512,1024,2048,3156,9,2129,0,83,2065,2129,1024,1,3092,81,16,2,8,65,2048,2112,3156,2048,1104,1,4,0,2129,592]

theorem envBound36133 : H12AffineFastState.Bounded env36133 := by
  intro p hp
  have h : env36133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36132_36133 : H12AffineEnvironment.transform 7 4 env36132 = env36133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env36132 == env36133) = true)

theorem identity36133 : scanCanonicalize (H12AffineFastState.compose env36133 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36133 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36134 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,3076,9,2049,0,3,2065,2049,1024,1,3092,1,16,2,8,17,2048,2064,3076,2048,1024,1,4,0,2049,512]

theorem envBound36134 : H12AffineFastState.Bounded env36134 := by
  intro p hp
  have h : env36134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36133_36134 : H12AffineEnvironment.transform 5 16 env36133 = env36134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36133 == env36134) = true)

theorem identity36134 : scanCanonicalize (H12AffineFastState.compose env36134 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36134 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36135 : List Nat := [2,4,8,1,0,1,9,4,512,1024,2048,3076,9,2049,0,3,2048,2049,1024,1,3077,1,1,2,8,0,2048,2049,3076,2048,1024,1,4,0,2049,512]

theorem envBound36135 : H12AffineFastState.Bounded env36135 := by
  intro p hp
  have h : env36135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36134_36135 : H12AffineEnvironment.transform 3 1 env36134 = env36135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36134 == env36135) = true)

theorem identity36135 : scanCanonicalize (H12AffineFastState.compose env36135 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36135 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36136 : List Nat := [2,4,3,1,0,1,2,4,512,1024,2048,3076,2,2049,0,3,2048,2049,1024,1,3077,1,1,2,3,0,2048,2049,3076,2048,1024,1,4,0,2049,512]

theorem envBound36136 : H12AffineFastState.Bounded env36136 := by
  intro p hp
  have h : env36136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36135_36136 : H12AffineEnvironment.transform 2 3 env36135 = env36136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36135 == env36136) = true)

theorem identity36136 : scanCanonicalize (H12AffineFastState.compose env36136 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound36136 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36137 : List Nat := [2,4,3,1,0,1,2,4,512,1024,1028,0,2,1029,0,3,1028,1029,1024,1,1,1,1,2,3,0,1028,1029,0,1028,1024,1,4,0,1029,512]

theorem envBound36137 : H12AffineFastState.Bounded env36137 := by
  intro p hp
  have h : env36137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36136_36137 : H12AffineEnvironment.transform 10 1028 env36136 = env36137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env36136 == env36137) = true)

theorem identity36137 : scanCanonicalize (H12AffineFastState.compose env36137 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound36137 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36138 : List Nat := [2,4,3,1,0,1,2,4,512,0,4,0,2,5,0,3,4,5,0,1,1,1,1,2,3,0,4,5,0,4,0,1,4,0,5,512]

theorem envBound36138 : H12AffineFastState.Bounded env36138 := by
  intro p hp
  have h : env36138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36137_36138 : H12AffineEnvironment.transform 9 0 env36137 = env36138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env36137 == env36138) = true)

theorem identity36138 : scanCanonicalize (H12AffineFastState.compose env36138 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound36138 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env36139 : List Nat := [2,1,3,1,0,1,2,1,512,0,1,0,2,0,0,3,1,0,0,1,1,1,1,2,3,0,1,0,0,1,0,1,1,0,0,512]

theorem envBound36139 : H12AffineFastState.Bounded env36139 := by
  intro p hp
  have h : env36139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36138_36139 : H12AffineEnvironment.transform 1 1 env36138 = env36139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env36138 == env36139) = true)

theorem identity36139 : scanCanonicalize (H12AffineFastState.compose env36139 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36139 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36140 : List Nat := [1,1,0,1,0,1,1,1,512,0,1,0,1,0,0,0,1,0,0,1,1,1,1,1,0,0,1,0,0,1,0,1,1,0,0,512]

theorem envBound36140 : H12AffineFastState.Bounded env36140 := by
  intro p hp
  have h : env36140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36139_36140 : H12AffineEnvironment.transform 0 1 env36139 = env36140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36139 == env36140) = true)

def env36141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,17,98780,8328,65,4237812,5393,17665,10280,1500,4256861,256,21793,46213,74251]

theorem envBound36141 : H12AffineFastState.Bounded env36141 := by
  intro p hp
  have h : env36141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36106_36141 : H12AffineEnvironment.transform 20 4161 env36106 = env36141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36106 == env36141) = true)

theorem identity36141 : scanCanonicalize (H12AffineFastState.compose env36141 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201831) := by decide +kernel

theorem selectedBound36141 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,201831,17,98780,8328,65,245139,5393,17665,10280,1500,254010,256,21793,46213,74251]

theorem envBound36142 : H12AffineFastState.Bounded env36142 := by
  intro p hp
  have h : env36142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36141_36142 : H12AffineEnvironment.transform 21 201831 env36141 = env36142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201831 env36141 == env36142) = true)

def env36143 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,201831,17,98644,8192,65,245019,5393,17665,10280,1364,254010,256,21793,46093,74251]

theorem envBound36143 : H12AffineFastState.Bounded env36143 := by
  intro p hp
  have h : env36143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36142_36143 : H12AffineEnvironment.transform 6 8 env36142 = env36143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36142 == env36143) = true)

theorem identity36143 : scanCanonicalize (H12AffineFastState.compose env36143 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound36143 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36144 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,190520,1024,32769,4161,169264,17,3,8192,65,146508,5393,17665,10280,1364,156013,256,21793,46093,41820]

theorem envBound36144 : H12AffineFastState.Bounded env36144 := by
  intro p hp
  have h : env36144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36143_36144 : H12AffineEnvironment.transform 15 33111 env36143 = env36144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env36143 == env36144) = true)

theorem identity36144 : scanCanonicalize (H12AffineFastState.compose env36144 (packedSelected [7,8,10,12,14,15,16,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound36144 : packedSelected [7,8,10,12,14,15,16,27,28] rootPS < 2^1333 := by decide +kernel

def env36145 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,2420,1024,32769,4161,29820,17,3,8192,65,56576,5393,17665,10280,1364,32801,256,21793,46093,41820]

theorem envBound36145 : H12AffineFastState.Bounded env36145 := by
  intro p hp
  have h : env36145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36144_36145 : H12AffineEnvironment.transform 16 57676 env36144 = env36145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env36144 == env36145) = true)

theorem identity36145 : scanCanonicalize (H12AffineFastState.compose env36145 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound36145 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env36146 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,5393,2420,1024,29788,4161,29820,17,3,8192,65,10589,5393,17665,10280,1364,29820,256,21793,16464,22273]

theorem envBound36146 : H12AffineFastState.Bounded env36146 := by
  intro p hp
  have h : env36146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36145_36146 : H12AffineEnvironment.transform 14 29789 env36145 = env36146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env36145 == env36146) = true)

theorem identity36146 : scanCanonicalize (H12AffineFastState.compose env36146 (packedSelected [0,7,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 6161) := by decide +kernel

theorem selectedBound36146 : packedSelected [0,7,11,18] rootPS < 2^1333 := by decide +kernel

def env36147 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,6161,11340,11547,5393,2420,1024,11341,4161,11373,17,3,8192,65,10589,5393,7440,10280,1364,11373,256,3376,6209,3856]

theorem envBound36147 : H12AffineFastState.Bounded env36147 := by
  intro p hp
  have h : env36147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36146_36147 : H12AffineEnvironment.transform 13 6161 env36146 = env36147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6161 env36146 == env36147) = true)

theorem identity36147 : scanCanonicalize (H12AffineFastState.compose env36147 (packedSelected [0,1,2,4,6,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound36147 : packedSelected [0,1,2,4,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env36148 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,300,6161,3424,3127,5393,2420,1024,3425,4161,3393,17,3,300,65,2161,5393,7440,2308,1364,3393,256,3376,6209,3856]

theorem envBound36148 : H12AffineFastState.Bounded env36148 := by
  intro p hp
  have h : env36148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36147_36148 : H12AffineEnvironment.transform 12 300 env36147 = env36148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env36147 == env36148) = true)

theorem identity36148 : scanCanonicalize (H12AffineFastState.compose env36148 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound36148 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36149 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,300,5457,32,375,5393,1076,1024,33,4161,1,17,3,300,65,1329,5393,4176,1092,1364,1,256,112,5377,592]

theorem envBound36149 : H12AffineFastState.Bounded env36149 := by
  intro p hp
  have h : env36149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36148_36149 : H12AffineEnvironment.transform 10 1344 env36148 = env36149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env36148 == env36149) = true)

theorem identity36149 : scanCanonicalize (H12AffineFastState.compose env36149 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36149 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36150 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1296,4096,300,5377,32,295,5393,1076,1024,33,4113,1,17,3,300,17,1329,5393,4096,1044,1284,1,256,32,5377,512]

theorem envBound36150 : H12AffineFastState.Bounded env36150 := by
  intro p hp
  have h : env36150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36149_36150 : H12AffineEnvironment.transform 5 16 env36149 = env36150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36149 == env36150) = true)

theorem identity36150 : scanCanonicalize (H12AffineFastState.compose env36150 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36150 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36151 : List Nat := [2,4,8,16,1,16,8,256,512,1024,1296,4096,269,5377,1,262,5393,1045,1024,0,4113,1,17,3,269,17,1296,5393,4096,1044,1284,1,256,1,5377,512]

theorem envBound36151 : H12AffineFastState.Bounded env36151 := by
  intro p hp
  have h : env36151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36150_36151 : H12AffineEnvironment.transform 4 1 env36150 = env36151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36150 == env36151) = true)

theorem identity36151 : scanCanonicalize (H12AffineFastState.compose env36151 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound36151 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36152 : List Nat := [2,4,8,16,1,16,8,256,512,1024,1296,1028,269,261,1,262,277,1045,1024,0,1045,1,17,3,269,17,1296,277,1028,1044,1284,1,256,1,261,512]

theorem envBound36152 : H12AffineFastState.Bounded env36152 := by
  intro p hp
  have h : env36152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36151_36152 : H12AffineEnvironment.transform 11 1028 env36151 = env36152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env36151 == env36152) = true)

theorem identity36152 : scanCanonicalize (H12AffineFastState.compose env36152 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound36152 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36153 : List Nat := [2,4,8,16,1,16,8,256,512,20,260,16,269,261,1,262,277,1,20,0,1,1,17,3,269,17,260,277,16,0,272,1,256,1,261,512]

theorem envBound36153 : H12AffineFastState.Bounded env36153 := by
  intro p hp
  have h : env36153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36152_36153 : H12AffineEnvironment.transform 9 20 env36152 = env36153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env36152 == env36153) = true)

def env36154 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,201831,17,98645,8193,65,245018,5393,17665,10280,1365,254010,256,21793,46092,74251]

theorem envBound36154 : H12AffineFastState.Bounded env36154 := by
  intro p hp
  have h : env36154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36142_36154 : H12AffineEnvironment.transform 6 9 env36142 = env36154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36142 == env36154) = true)

theorem identity36154 : scanCanonicalize (H12AffineFastState.compose env36154 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36154 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36155 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,149860,1024,8541,4161,201831,17,73737,8193,65,203846,5393,17665,10280,1365,213350,256,21793,5456,74251]

theorem envBound36155 : H12AffineFastState.Bounded env36155 := by
  intro p hp
  have h : env36155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36154_36155 : H12AffineEnvironment.transform 14 8540 env36154 = env36155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36154 == env36155) = true)

theorem identity36155 : scanCanonicalize (H12AffineFastState.compose env36155 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound36155 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36156 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,5441,23589,1024,8541,4161,65830,17,73737,8193,65,67847,5393,17665,10280,1365,87079,256,21793,5456,74251]

theorem envBound36156 : H12AffineFastState.Bounded env36156 := by
  intro p hp
  have h : env36156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36155_36156 : H12AffineEnvironment.transform 16 5441 env36155 = env36156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env36155 == env36156) = true)

theorem identity36156 : scanCanonicalize (H12AffineFastState.compose env36156 (packedSelected [0,1,5,8,9,22,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound36156 : packedSelected [0,1,5,8,9,22,24,27] rootPS < 2^1333 := by decide +kernel

def env36157 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8540,65536,5441,10280,1024,8541,4161,65830,17,73737,8193,65,67847,5393,12556,10280,1365,73770,256,8492,5456,74251]

theorem envBound36157 : H12AffineFastState.Bounded env36157 := by
  intro p hp
  have h : env36157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36156_36157 : H12AffineEnvironment.transform 13 13325 env36156 = env36157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env36156 == env36157) = true)

theorem identity36157 : scanCanonicalize (H12AffineFastState.compose env36157 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound36157 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env36158 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5237,292,65536,5441,2128,1024,293,4161,65830,17,65649,121,65,67847,5393,4468,2128,1365,65618,256,340,5456,66163]

theorem envBound36158 : H12AffineFastState.Bounded env36158 := by
  intro p hp
  have h : env36158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36157_36158 : H12AffineEnvironment.transform 12 120 env36157 = env36158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env36157 == env36158) = true)

theorem identity36158 : scanCanonicalize (H12AffineFastState.compose env36158 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36158 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env36159 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,5237,0,65536,5221,2128,1024,1,4161,65538,17,65649,121,65,67619,5173,4176,2128,1137,65618,36,112,5236,66163]

theorem envBound36159 : H12AffineFastState.Bounded env36159 := by
  intro p hp
  have h : env36159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36158_36159 : H12AffineEnvironment.transform 7 36 env36158 = env36159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36158 == env36159) = true)

theorem identity36159 : scanCanonicalize (H12AffineFastState.compose env36159 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound36159 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env36160 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,5237,0,34,5221,2128,1024,1,4161,32,17,83,121,65,2049,5173,4176,2128,1137,112,36,112,5236,593]

theorem envBound36160 : H12AffineFastState.Bounded env36160 := by
  intro p hp
  have h : env36160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36159_36160 : H12AffineEnvironment.transform 15 34 env36159 = env36160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env36159 == env36160) = true)

theorem identity36160 : scanCanonicalize (H12AffineFastState.compose env36160 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound36160 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env36161 : List Nat := [2,4,8,16,32,64,9,36,512,69,2048,4096,120,4144,0,34,4128,2128,69,1,4161,32,17,83,121,65,2049,4208,4176,2128,52,112,36,112,4145,593]

theorem envBound36161 : H12AffineFastState.Bounded env36161 := by
  intro p hp
  have h : env36161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36160_36161 : H12AffineEnvironment.transform 9 69 env36160 = env36161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env36160 == env36161) = true)

theorem identity36161 : scanCanonicalize (H12AffineFastState.compose env36161 (packedSelected [1,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound36161 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env36162 : List Nat := [2,4,8,16,32,64,9,36,512,69,2048,2144,120,2128,0,34,2112,2128,69,1,2081,32,17,83,121,65,2049,2064,2096,2128,52,112,36,112,2129,593]

theorem envBound36162 : H12AffineFastState.Bounded env36162 := by
  intro p hp
  have h : env36162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36161_36162 : H12AffineEnvironment.transform 11 2144 env36161 = env36162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env36161 == env36162) = true)

theorem identity36162 : scanCanonicalize (H12AffineFastState.compose env36162 (packedSelected [1,3,4,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36162 : packedSelected [1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env36163 : List Nat := [2,4,8,16,1,64,9,5,512,69,2048,2113,89,2128,0,3,2112,2128,69,1,2048,1,17,83,88,65,2049,2064,2065,2128,21,81,5,81,2129,593]

theorem envBound36163 : H12AffineFastState.Bounded env36163 := by
  intro p hp
  have h : env36163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36162_36163 : H12AffineEnvironment.transform 4 1 env36162 = env36163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36162 == env36163) = true)

theorem identity36163 : scanCanonicalize (H12AffineFastState.compose env36163 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound36163 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env36164 : List Nat := [2,4,8,16,1,64,9,5,512,69,592,529,89,512,0,3,528,512,69,1,592,1,17,83,88,65,593,576,577,512,21,81,5,81,513,593]

theorem envBound36164 : H12AffineFastState.Bounded env36164 := by
  intro p hp
  have h : env36164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36163_36164 : H12AffineEnvironment.transform 10 592 env36163 = env36164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env36163 == env36164) = true)

theorem identity36164 : scanCanonicalize (H12AffineFastState.compose env36164 (packedSelected [0,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36164 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env36165 : List Nat := [2,4,8,16,1,17,9,5,512,20,513,529,8,512,0,3,528,512,20,1,513,1,17,2,9,16,512,529,528,512,21,0,5,0,513,512]

theorem envBound36165 : H12AffineFastState.Bounded env36165 := by
  intro p hp
  have h : env36165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36164_36165 : H12AffineEnvironment.transform 5 17 env36164 = env36165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36164 == env36165) = true)

def env36166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,2101329,98781,8328,65,6338996,2098513,17664,2111593,2102685,6349853,256,21793,46213,2175562]

theorem envBound36166 : H12AffineFastState.Bounded env36166 := by
  intro p hp
  have h : env36166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36105_36166 : H12AffineEnvironment.transform 17 190521 env36105 = env36166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env36105 == env36166) = true)

def env36167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,17,98781,8328,65,4237812,5393,17664,10281,1501,4256861,256,21793,46213,74250]

theorem envBound36167 : H12AffineFastState.Bounded env36167 := by
  intro p hp
  have h : env36167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36166_36167 : H12AffineEnvironment.transform 20 4160 env36166 = env36167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36166 == env36167) = true)

theorem identity36167 : scanCanonicalize (H12AffineFastState.compose env36167 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254131) := by decide +kernel

theorem selectedBound36167 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,254131,17,98781,8328,65,215367,5393,17664,10281,1501,201966,256,21793,46213,74250]

theorem envBound36168 : H12AffineFastState.Bounded env36168 := by
  intro p hp
  have h : env36168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36167_36168 : H12AffineEnvironment.transform 21 254131 env36167 = env36168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254131 env36167 == env36168) = true)

theorem identity36168 : scanCanonicalize (H12AffineFastState.compose env36168 (packedSelected [3,10,11,12,15,16,17,18,20,23,24,26,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound36168 : packedSelected [3,10,11,12,15,16,17,18,20,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env36169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,100386,1024,32769,4160,32936,17,98781,8328,65,10588,5393,17664,10281,1501,29941,256,21793,46213,74250]

theorem envBound36169 : H12AffineFastState.Bounded env36169 := by
  intro p hp
  have h : env36169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36168_36169 : H12AffineEnvironment.transform 16 90139 env36168 = env36169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env36168 == env36169) = true)

theorem identity36169 : scanCanonicalize (H12AffineFastState.compose env36169 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound36169 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env36170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,97527,1024,29908,4160,29821,17,95496,8328,65,10588,5393,17664,10281,1501,29941,256,21793,16464,74250]

theorem envBound36170 : H12AffineFastState.Bounded env36170 := by
  intro p hp
  have h : env36170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36169_36170 : H12AffineEnvironment.transform 14 29909 env36169 = env36170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env36169 == env36170) = true)

theorem identity36170 : scanCanonicalize (H12AffineFastState.compose env36170 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36170 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env36171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,16400,23804,1024,29908,4160,29821,17,21763,8328,65,10588,5393,17664,10281,1501,29941,256,21793,16464,513]

theorem envBound36171 : H12AffineFastState.Bounded env36171 := by
  intro p hp
  have h : env36171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36170_36171 : H12AffineEnvironment.transform 15 8203 env36170 = env36171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36170 == env36171) = true)

def env36172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,98781,8328,65,4237813,5392,17664,10280,1500,4256860,256,21793,46213,74251]

theorem envBound36172 : H12AffineFastState.Bounded env36172 := by
  intro p hp
  have h : env36172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36166_36172 : H12AffineEnvironment.transform 20 4161 env36166 = env36172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36166 == env36172) = true)

theorem identity36172 : scanCanonicalize (H12AffineFastState.compose env36172 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36172 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4161,4194304,16,41431,8328,65,4237813,5392,17664,10280,1500,4256860,256,21793,46213,513]

theorem envBound36173 : H12AffineFastState.Bounded env36173 := by
  intro p hp
  have h : env36173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36172_36173 : H12AffineEnvironment.transform 15 8202 env36172 = env36173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36172 == env36173) = true)

theorem identity36173 : scanCanonicalize (H12AffineFastState.compose env36173 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 32936) := by decide +kernel

theorem selectedBound36173 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env36174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4161,32936,16,41431,8328,65,10589,5392,17664,10280,1500,29940,256,21793,46213,513]

theorem envBound36174 : H12AffineFastState.Bounded env36174 := by
  intro p hp
  have h : env36174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36173_36174 : H12AffineEnvironment.transform 21 32936 env36173 = env36174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32936 env36173 == env36174) = true)

theorem identity36174 : scanCanonicalize (H12AffineFastState.compose env36174 (packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36174 : packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env36175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,131072,149860,1024,8540,4161,8693,16,138,8328,65,10589,5392,17664,10280,1500,29940,256,21793,5592,513]

theorem envBound36175 : H12AffineFastState.Bounded env36175 := by
  intro p hp
  have h : env36175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36174_36175 : H12AffineEnvironment.transform 14 8541 env36174 = env36175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36174 == env36175) = true)

theorem identity36175 : scanCanonicalize (H12AffineFastState.compose env36175 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound36175 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,24908,10280,1024,8540,4161,8693,16,138,8328,65,10589,5392,17664,10280,1500,29940,256,21793,5592,513]

theorem envBound36176 : H12AffineFastState.Bounded env36176 := by
  intro p hp
  have h : env36176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36175_36176 : H12AffineEnvironment.transform 16 24908 env36175 = env36176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env36175 == env36176) = true)

def env36177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2553961,485860,8328,65,6705548,2551144,437560,2111592,2102684,6687780,256,21792,46212,2175563]

theorem envBound36177 : H12AffineFastState.Bounded env36177 := by
  intro p hp
  have h : env36177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36104_36177 : H12AffineEnvironment.transform 22 2553961 env36104 = env36177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2553961 env36104 == env36177) = true)

def env36178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,2101329,98780,8328,65,6338996,2098512,17664,2111592,2102684,6349852,256,21792,46212,2175563]

theorem envBound36178 : H12AffineFastState.Bounded env36178 := by
  intro p hp
  have h : env36178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36177_36178 : H12AffineEnvironment.transform 17 190520 env36177 = env36178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env36177 == env36178) = true)

def env36179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,17,98780,8328,65,4237812,5392,17664,10280,1500,4256860,256,21792,46212,74251]

theorem envBound36179 : H12AffineFastState.Bounded env36179 := by
  intro p hp
  have h : env36179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36178_36179 : H12AffineEnvironment.transform 20 4160 env36178 = env36179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36178 == env36179) = true)

theorem identity36179 : scanCanonicalize (H12AffineFastState.compose env36179 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144492) := by decide +kernel

theorem selectedBound36179 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,144492,17,98780,8328,65,171416,5392,17664,10280,1500,180272,256,21792,46212,74251]

theorem envBound36180 : H12AffineFastState.Bounded env36180 := by
  intro p hp
  have h : env36180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36179_36180 : H12AffineEnvironment.transform 21 144492 env36179 = env36180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144492 env36179 == env36180) = true)

def env36181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,144492,17,98644,8192,65,171280,5392,17664,10280,1364,180272,256,21792,46092,74251]

theorem envBound36181 : H12AffineFastState.Bounded env36181 := by
  intro p hp
  have h : env36181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36180_36181 : H12AffineEnvironment.transform 6 8 env36180 = env36181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36180 == env36181) = true)

theorem identity36181 : scanCanonicalize (H12AffineFastState.compose env36181 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound36181 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,190520,1024,32769,4160,144492,17,3,8192,65,171280,5392,17664,10280,1364,180272,256,21792,46092,41820]

theorem envBound36182 : H12AffineFastState.Bounded env36182 := by
  intro p hp
  have h : env36182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36181_36182 : H12AffineEnvironment.transform 15 33111 env36181 = env36182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env36181 == env36182) = true)

theorem identity36182 : scanCanonicalize (H12AffineFastState.compose env36182 (packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound36182 : packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env36183 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,342,131072,157753,1024,0,4160,144492,17,3,8192,65,138513,5392,17664,10280,1364,147505,256,21792,13325,9053]

theorem envBound36183 : H12AffineFastState.Bounded env36183 := by
  intro p hp
  have h : env36183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36182_36183 : H12AffineEnvironment.transform 14 1 env36182 = env36183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env36182 == env36183) = true)

theorem identity36183 : scanCanonicalize (H12AffineFastState.compose env36183 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound36183 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env36184 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,342,24909,2420,1024,0,4160,21793,17,3,8192,65,31836,5392,17664,10280,1364,8572,256,21792,13325,9053]

theorem envBound36184 : H12AffineFastState.Bounded env36184 := by
  intro p hp
  have h : env36184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36183_36184 : H12AffineEnvironment.transform 16 24909 env36183 = env36184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env36183 == env36184) = true)

theorem identity36184 : scanCanonicalize (H12AffineFastState.compose env36184 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound36184 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env36185 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,1,342,16449,2420,1024,0,4160,21793,17,3,268,65,23888,5392,17664,2340,1364,112,256,21792,5377,593]

theorem envBound36185 : H12AffineFastState.Bounded env36185 := by
  intro p hp
  have h : env36185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36184_36185 : H12AffineEnvironment.transform 12 268 env36184 = env36185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env36184 == env36185) = true)

theorem identity36185 : scanCanonicalize (H12AffineFastState.compose env36185 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36185 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env36186 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1,262,16401,2340,1024,0,4112,21793,17,3,268,17,23808,5392,17664,2340,1284,32,256,21792,5377,513]

theorem envBound36186 : H12AffineFastState.Bounded env36186 := by
  intro p hp
  have h : env36186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36185_36186 : H12AffineEnvironment.transform 5 16 env36185 = env36186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36185 == env36186) = true)

def env36187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,144492,17,98645,8193,65,171281,5392,17664,10280,1365,180272,256,21792,46093,74251]

theorem envBound36187 : H12AffineFastState.Bounded env36187 := by
  intro p hp
  have h : env36187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36180_36187 : H12AffineEnvironment.transform 6 9 env36180 = env36187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36180 == env36187) = true)

theorem identity36187 : scanCanonicalize (H12AffineFastState.compose env36187 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36187 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,149860,1024,8541,4160,144492,17,73737,8193,65,146509,5392,17664,10280,1365,156012,256,21792,5457,74251]

theorem envBound36188 : H12AffineFastState.Bounded env36188 := by
  intro p hp
  have h : env36188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36187_36188 : H12AffineEnvironment.transform 14 8540 env36187 = env36188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36187 == env36188) = true)

theorem identity36188 : scanCanonicalize (H12AffineFastState.compose env36188 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound36188 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36189 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,5440,23588,1024,8541,4160,8492,17,73737,8193,65,10509,5392,17664,10280,1365,29740,256,21792,5457,74251]

theorem envBound36189 : H12AffineFastState.Bounded env36189 := by
  intro p hp
  have h : env36189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36188_36189 : H12AffineEnvironment.transform 16 5440 env36188 = env36189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env36188 == env36189) = true)

theorem identity36189 : scanCanonicalize (H12AffineFastState.compose env36189 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound36189 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env36190 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,8540,65536,5440,10508,1024,8541,4160,8492,17,73737,8193,65,10509,5392,12328,10280,1365,260,256,8200,5457,74251]

theorem envBound36190 : H12AffineFastState.Bounded env36190 := by
  intro p hp
  have h : env36190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36189_36190 : H12AffineEnvironment.transform 13 13608 env36189 = env36190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env36189 == env36190) = true)

theorem identity36190 : scanCanonicalize (H12AffineFastState.compose env36190 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound36190 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36191 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5456,292,65536,5440,2420,1024,293,4160,340,17,65649,121,65,2421,5392,4176,2128,1365,260,256,112,5457,66163]

theorem envBound36191 : H12AffineFastState.Bounded env36191 := by
  intro p hp
  have h : env36191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36190_36191 : H12AffineEnvironment.transform 12 120 env36190 = env36191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env36190 == env36191) = true)

theorem identity36191 : scanCanonicalize (H12AffineFastState.compose env36191 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound36191 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env36192 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5157,81,65536,5173,2049,1024,80,4160,33,17,65649,121,65,2048,5221,4176,2128,1056,113,117,112,5156,66163]

theorem envBound36192 : H12AffineFastState.Bounded env36192 := by
  intro p hp
  have h : env36192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36191_36192 : H12AffineEnvironment.transform 7 117 env36191 = env36192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env36191 == env36192) = true)

theorem identity36192 : scanCanonicalize (H12AffineFastState.compose env36192 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound36192 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36193 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,120,4160,81,65536,4176,2049,101,80,4160,33,17,65649,121,65,2048,4096,4176,2128,69,113,117,112,4161,66163]

theorem envBound36193 : H12AffineFastState.Bounded env36193 := by
  intro p hp
  have h : env36193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36192_36193 : H12AffineEnvironment.transform 9 101 env36192 = env36193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env36192 == env36193) = true)

def env36194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,16,98780,8328,65,4237813,5393,17664,10281,1501,4256861,256,21792,46212,74250]

theorem envBound36194 : H12AffineFastState.Bounded env36194 := by
  intro p hp
  have h : env36194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36178_36194 : H12AffineEnvironment.transform 20 4161 env36178 = env36194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36178 == env36194) = true)

theorem identity36194 : scanCanonicalize (H12AffineFastState.compose env36194 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound36194 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,138477,1024,29908,4161,4194304,16,95497,8328,65,4218144,5393,17664,10281,1501,4194440,256,21792,16465,74250]

theorem envBound36195 : H12AffineFastState.Bounded env36195 := by
  intro p hp
  have h : env36195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36194_36195 : H12AffineEnvironment.transform 14 29909 env36194 = env36195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env36194 == env36195) = true)

def env36196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138477,1024,8660,4161,4194304,16,73737,8328,65,4196384,5393,4096,10281,1501,4194440,256,32,5457,74250]

theorem envBound36196 : H12AffineFastState.Bounded env36196 := by
  intro p hp
  have h : env36196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36195_36196 : H12AffineEnvironment.transform 13 5376 env36195 = env36196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36195 == env36196) = true)

theorem identity36196 : scanCanonicalize (H12AffineFastState.compose env36196 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound36196 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13389,10400,1024,8660,4161,4194304,16,73737,8328,65,4196384,5393,4096,10281,1501,4194440,256,32,5457,74250]

theorem envBound36197 : H12AffineFastState.Bounded env36197 := by
  intro p hp
  have h : env36197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36196_36197 : H12AffineEnvironment.transform 16 13389 env36196 = env36197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env36196 == env36197) = true)

theorem identity36197 : scanCanonicalize (H12AffineFastState.compose env36197 (packedSelected [0,3,4,5,7,8,10,11,18,22,23,28,31,32] rootPS)) = affineNative (2^(21+1) ^^^ 66046) := by decide +kernel

theorem selectedBound36197 : packedSelected [0,3,4,5,7,8,10,11,18,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env36198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13389,10400,1024,8660,4161,66046,16,73737,8328,65,68062,5393,4096,10281,1501,65910,256,32,5457,74250]

theorem envBound36198 : H12AffineFastState.Bounded env36198 := by
  intro p hp
  have h : env36198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36197_36198 : H12AffineEnvironment.transform 21 66046 env36197 = env36198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 66046 env36197 == env36198) = true)

theorem identity36198 : scanCanonicalize (H12AffineFastState.compose env36198 (packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,18,19,28] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound36198 : packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,18,19,28] rootPS < 2^1333 := by decide +kernel

def env36199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8323,13389,10400,1024,8660,4161,8573,16,138,8328,65,10589,5393,4096,10281,1501,8693,256,32,5457,649]

theorem envBound36199 : H12AffineFastState.Bounded env36199 := by
  intro p hp
  have h : env36199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36198_36199 : H12AffineEnvironment.transform 15 8323 env36198 = env36199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env36198 == env36199) = true)

theorem identity36199 : scanCanonicalize (H12AffineFastState.compose env36199 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36199 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36200 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,13389,10280,1024,8540,4161,8573,16,2,8192,65,10589,5393,4096,10281,1365,8573,256,32,5457,513]

theorem envBound36200 : H12AffineFastState.Bounded env36200 := by
  intro p hp
  have h : env36200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36199_36200 : H12AffineEnvironment.transform 6 8 env36199 = env36200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36199 == env36200) = true)

theorem identity36200 : scanCanonicalize (H12AffineFastState.compose env36200 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36200 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36201 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8203,13341,10280,1024,8460,4113,8493,16,2,8192,17,10509,5393,4096,10281,1285,8493,256,32,5377,513]

theorem envBound36201 : H12AffineFastState.Bounded env36201 := by
  intro p hp
  have h : env36201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36200_36201 : H12AffineEnvironment.transform 5 16 env36200 = env36201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36200 == env36201) = true)

theorem identity36201 : scanCanonicalize (H12AffineFastState.compose env36201 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound36201 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env36202 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,263,5393,2340,1024,0,4113,33,16,2,268,17,2049,5393,4096,2341,1285,33,256,32,5377,513]

theorem envBound36202 : H12AffineFastState.Bounded env36202 := by
  intro p hp
  have h : env36202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36201_36202 : H12AffineEnvironment.transform 12 268 env36201 = env36202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env36201 == env36202) = true)

theorem identity36202 : scanCanonicalize (H12AffineFastState.compose env36202 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound36202 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36203 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,293,268,1061,1,263,1076,2340,1024,0,308,33,16,2,268,17,2049,1076,293,2341,1285,33,256,32,1060,513]

theorem envBound36203 : H12AffineFastState.Bounded env36203 := by
  intro p hp
  have h : env36203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36202_36203 : H12AffineEnvironment.transform 11 293 env36202 = env36203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env36202 == env36203) = true)

theorem identity36203 : scanCanonicalize (H12AffineFastState.compose env36203 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound36203 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36204 : List Nat := [2,4,8,16,32,16,8,256,512,564,2048,293,268,529,1,263,512,2340,564,0,308,33,16,2,268,17,2049,512,293,2341,817,33,256,32,528,513]

theorem envBound36204 : H12AffineFastState.Bounded env36204 := by
  intro p hp
  have h : env36204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36203_36204 : H12AffineEnvironment.transform 9 564 env36203 = env36204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env36203 == env36204) = true)

theorem identity36204 : scanCanonicalize (H12AffineFastState.compose env36204 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound36204 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36205 : List Nat := [2,4,8,16,32,16,8,256,512,564,821,293,268,529,1,263,512,529,564,0,308,33,16,2,268,17,820,512,293,528,817,33,256,32,528,513]

theorem envBound36205 : H12AffineFastState.Bounded env36205 := by
  intro p hp
  have h : env36205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36204_36205 : H12AffineEnvironment.transform 10 821 env36204 = env36205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env36204 == env36205) = true)

def env36206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,138477,1024,8661,4161,4194304,16,73736,8328,65,4196385,5393,4097,10281,1501,4194440,256,33,5456,74250]

theorem envBound36206 : H12AffineFastState.Bounded env36206 := by
  intro p hp
  have h : env36206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36195_36206 : H12AffineEnvironment.transform 13 5377 env36195 = env36206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36195 == env36206) = true)

theorem identity36206 : scanCanonicalize (H12AffineFastState.compose env36206 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound36206 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13509,10280,1024,8661,4161,4194304,16,73736,8328,65,4196385,5393,4097,10281,1501,4194440,256,33,5456,74250]

theorem envBound36207 : H12AffineFastState.Bounded env36207 := by
  intro p hp
  have h : env36207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36206_36207 : H12AffineEnvironment.transform 16 13509 env36206 = env36207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env36206 == env36207) = true)

theorem identity36207 : scanCanonicalize (H12AffineFastState.compose env36207 (packedSelected [0,2,4,6,9,11,16,18,27] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound36207 : packedSelected [0,2,4,6,9,11,16,18,27] rootPS < 2^1333 := by decide +kernel

def env36208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13509,10280,1024,8661,4161,73890,16,73736,8328,65,75907,5393,4097,10281,1501,73770,256,33,5456,74250]

theorem envBound36208 : H12AffineFastState.Bounded env36208 := by
  intro p hp
  have h : env36208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36207_36208 : H12AffineEnvironment.transform 21 73890 env36207 = env36208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env36207 == env36208) = true)

theorem identity36208 : scanCanonicalize (H12AffineFastState.compose env36208 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound36208 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env36209 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5236,8353,65536,13509,10280,1024,8352,4161,73890,16,73736,8328,65,75907,5220,4097,10281,1192,73770,117,33,5157,74250]

theorem envBound36209 : H12AffineFastState.Bounded env36209 := by
  intro p hp
  have h : env36209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36208_36209 : H12AffineEnvironment.transform 7 117 env36208 = env36209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env36208 == env36209) = true)

theorem identity36209 : scanCanonicalize (H12AffineFastState.compose env36209 (packedSelected [1,4,8,9,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound36209 : packedSelected [1,4,8,9,14,16,19] rootPS < 2^1333 := by decide +kernel

def env36210 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5236,8353,171,13509,10280,1024,8352,4161,8201,16,8355,8328,65,10280,5220,4097,10281,1192,8321,117,33,5157,8865]

theorem envBound36210 : H12AffineFastState.Bounded env36210 := by
  intro p hp
  have h : env36210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36209_36210 : H12AffineEnvironment.transform 15 171 env36209 = env36210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env36209 == env36210) = true)

theorem identity36210 : scanCanonicalize (H12AffineFastState.compose env36210 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound36210 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env36211 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,160,5236,1,171,5221,2184,1024,0,4161,169,16,3,40,65,2184,5220,4097,2185,1192,33,117,33,5157,513]

theorem envBound36211 : H12AffineFastState.Bounded env36211 := by
  intro p hp
  have h : env36211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36210_36211 : H12AffineEnvironment.transform 12 160 env36210 = env36211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env36210 == env36211) = true)

theorem identity36211 : scanCanonicalize (H12AffineFastState.compose env36211 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36211 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36212 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,160,5156,1,171,5173,2184,1024,0,4113,169,16,3,40,17,2184,5172,4097,2185,1192,33,37,33,5157,513]

theorem envBound36212 : H12AffineFastState.Bounded env36212 := by
  intro p hp
  have h : env36212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36211_36212 : H12AffineEnvironment.transform 5 16 env36211 = env36212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36211 == env36212) = true)

theorem identity36212 : scanCanonicalize (H12AffineFastState.compose env36212 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound36212 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36213 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,2200,160,3260,1,171,3245,2184,1024,0,2185,169,16,3,40,17,2184,3244,2201,2185,1192,33,37,33,3261,513]

theorem envBound36213 : H12AffineFastState.Bounded env36213 := by
  intro p hp
  have h : env36213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36212_36213 : H12AffineEnvironment.transform 11 2200 env36212 = env36213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env36212 == env36213) = true)

theorem identity36213 : scanCanonicalize (H12AffineFastState.compose env36213 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 664) := by decide +kernel

theorem selectedBound36213 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env36214 : List Nat := [2,4,8,16,32,16,128,37,512,1024,664,512,160,1572,1,171,1589,528,1024,0,529,169,16,3,40,17,528,1588,513,529,1192,33,37,33,1573,513]

theorem envBound36214 : H12AffineFastState.Bounded env36214 := by
  intro p hp
  have h : env36214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36213_36214 : H12AffineEnvironment.transform 10 664 env36213 = env36214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 664 env36213 == env36214) = true)

theorem identity36214 : scanCanonicalize (H12AffineFastState.compose env36214 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound36214 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env36215 : List Nat := [2,4,8,16,32,16,128,37,512,564,664,512,160,16,1,171,1,528,564,0,529,169,16,3,40,17,528,0,513,529,668,33,37,33,17,513]

theorem envBound36215 : H12AffineFastState.Bounded env36215 := by
  intro p hp
  have h : env36215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36214_36215 : H12AffineEnvironment.transform 9 564 env36214 = env36215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env36214 == env36215) = true)

theorem identity36215 : scanCanonicalize (H12AffineFastState.compose env36215 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36215 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env36216 : List Nat := [2,4,8,16,32,16,8,37,512,564,528,512,40,16,1,35,1,528,564,0,529,33,16,3,40,17,528,0,513,529,532,33,37,33,17,513]

theorem envBound36216 : H12AffineFastState.Bounded env36216 := by
  intro p hp
  have h : env36216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36215_36216 : H12AffineEnvironment.transform 6 8 env36215 = env36216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36215 == env36216) = true)

theorem identity36216 : scanCanonicalize (H12AffineFastState.compose env36216 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound36216 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36217 : List Nat := [2,4,8,16,32,16,8,37,17,37,1,17,40,16,1,35,1,1,37,0,0,33,16,3,40,17,1,0,16,0,5,33,37,33,17,16]

theorem envBound36217 : H12AffineFastState.Bounded env36217 := by
  intro p hp
  have h : env36217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36216_36217 : H12AffineEnvironment.transform 8 17 env36216 = env36217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env36216 == env36217) = true)

def env36218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,2101328,98781,8328,65,6338997,2098513,17665,2111592,2102684,6349853,256,21792,46212,2175563]

theorem envBound36218 : H12AffineFastState.Bounded env36218 := by
  intro p hp
  have h : env36218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36177_36218 : H12AffineEnvironment.transform 17 190521 env36177 = env36218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env36177 == env36218) = true)

def env36219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,98781,8328,65,4237813,5393,17665,10280,1500,4256861,256,21792,46212,74251]

theorem envBound36219 : H12AffineFastState.Bounded env36219 := by
  intro p hp
  have h : env36219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36218_36219 : H12AffineEnvironment.transform 20 4160 env36218 = env36219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36218 == env36219) = true)

def env36220 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,98645,8192,65,4237693,5393,17665,10280,1364,4256861,256,21792,46092,74251]

theorem envBound36220 : H12AffineFastState.Bounded env36220 := by
  intro p hp
  have h : env36220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36219_36220 : H12AffineEnvironment.transform 6 8 env36219 = env36220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36219 == env36220) = true)

theorem identity36220 : scanCanonicalize (H12AffineFastState.compose env36220 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound36220 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36221 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4160,4194304,16,98645,8192,65,4237693,5393,17665,10280,1364,4256861,256,21792,46092,74251]

theorem envBound36221 : H12AffineFastState.Bounded env36221 := by
  intro p hp
  have h : env36221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36220_36221 : H12AffineEnvironment.transform 16 49169 env36220 = env36221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env36220 == env36221) = true)

theorem identity36221 : scanCanonicalize (H12AffineFastState.compose env36221 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 65911) := by decide +kernel

theorem selectedBound36221 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env36222 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4160,65911,16,98645,8192,65,108554,5393,17665,10280,1364,128298,256,21792,46092,74251]

theorem envBound36222 : H12AffineFastState.Bounded env36222 := by
  intro p hp
  have h : env36222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36221_36222 : H12AffineEnvironment.transform 21 65911 env36221 = env36222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65911 env36221 == env36222) = true)

theorem identity36222 : scanCanonicalize (H12AffineFastState.compose env36222 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36222 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env36223 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10280,1024,32769,4160,8573,16,41311,8192,65,34816,5393,17665,10280,1364,54560,256,21792,46092,513]

theorem envBound36223 : H12AffineFastState.Bounded env36223 := by
  intro p hp
  have h : env36223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36222_36223 : H12AffineEnvironment.transform 15 8202 env36222 = env36223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36222 == env36223) = true)

theorem identity36223 : scanCanonicalize (H12AffineFastState.compose env36223 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound36223 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36224 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8202,38160,10280,1024,32769,4160,8573,16,41311,8192,65,34816,5393,4096,10280,1364,32801,256,33,46092,513]

theorem envBound36224 : H12AffineFastState.Bounded env36224 := by
  intro p hp
  have h : env36224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36223_36224 : H12AffineEnvironment.transform 13 5377 env36223 = env36224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36223 == env36224) = true)

theorem identity36224 : scanCanonicalize (H12AffineFastState.compose env36224 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound36224 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36225 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,8202,5392,10280,1024,1,4160,8573,16,8543,8192,65,2048,5393,4096,10280,1364,33,256,33,13324,513]

theorem envBound36225 : H12AffineFastState.Bounded env36225 := by
  intro p hp
  have h : env36225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36224_36225 : H12AffineEnvironment.transform 14 0 env36224 = env36225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env36224 == env36225) = true)

theorem identity36225 : scanCanonicalize (H12AffineFastState.compose env36225 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 3378) := by decide +kernel

theorem selectedBound36225 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36226 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3378,5377,0,3384,5392,1306,1024,1,4160,3151,16,3181,3378,65,2048,5393,4096,1306,1364,33,256,33,6462,513]

theorem envBound36226 : H12AffineFastState.Bounded env36226 := by
  intro p hp
  have h : env36226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36225_36226 : H12AffineEnvironment.transform 12 3378 env36225 = env36226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3378 env36225 == env36226) = true)

def env36227 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,98644,8193,65,4237692,5393,17665,10280,1365,4256861,256,21792,46093,74251]

theorem envBound36227 : H12AffineFastState.Bounded env36227 := by
  intro p hp
  have h : env36227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36219_36227 : H12AffineEnvironment.transform 6 9 env36219 = env36227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36219 == env36227) = true)

theorem identity36227 : scanCanonicalize (H12AffineFastState.compose env36227 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound36227 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36228 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35189,1024,32769,4160,4194304,16,98644,8193,65,4237692,5393,17665,10280,1365,4256861,256,21792,46093,74251]

theorem envBound36228 : H12AffineFastState.Bounded env36228 := by
  intro p hp
  have h : env36228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36227_36228 : H12AffineEnvironment.transform 16 24908 env36227 = env36228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env36227 == env36228) = true)

theorem identity36228 : scanCanonicalize (H12AffineFastState.compose env36228 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 21872) := by decide +kernel

theorem selectedBound36228 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36229 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35189,1024,32769,4160,21872,16,98644,8193,65,64524,5393,17665,10280,1365,41261,256,21792,46093,74251]

theorem envBound36229 : H12AffineFastState.Bounded env36229 := by
  intro p hp
  have h : env36229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36228_36229 : H12AffineEnvironment.transform 21 21872 env36228 = env36229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21872 env36228 == env36229) = true)

theorem identity36229 : scanCanonicalize (H12AffineFastState.compose env36229 (packedSelected [0,1,5,8,9,10,16,20,22,24,27,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36229 : packedSelected [0,1,5,8,9,10,16,20,22,24,27,31] rootPS < 2^1333 := by decide +kernel

def env36230 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24908,10280,1024,8540,4160,21872,16,73737,8193,65,23889,5393,17665,10280,1365,112,256,21792,5456,74251]

theorem envBound36230 : H12AffineFastState.Bounded env36230 := by
  intro p hp
  have h : env36230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36229_36230 : H12AffineEnvironment.transform 14 8541 env36229 = env36230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36229 == env36230) = true)

theorem identity36230 : scanCanonicalize (H12AffineFastState.compose env36230 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound36230 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env36231 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,114,24908,10280,1024,8540,4160,21872,16,8315,8193,65,23889,5393,17665,10280,1365,112,256,21792,5456,8825]

theorem envBound36231 : H12AffineFastState.Bounded env36231 := by
  intro p hp
  have h : env36231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36230_36231 : H12AffineEnvironment.transform 15 114 env36230 = env36231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env36230 == env36231) = true)

def env36232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,17,98781,8328,65,4237812,5392,17665,10281,1501,4256860,256,21792,46212,74250]

theorem envBound36232 : H12AffineFastState.Bounded env36232 := by
  intro p hp
  have h : env36232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36218_36232 : H12AffineEnvironment.transform 20 4161 env36218 = env36232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36218 == env36232) = true)

theorem identity36232 : scanCanonicalize (H12AffineFastState.compose env36232 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180408) := by decide +kernel

theorem selectedBound36232 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,180408,17,98781,8328,65,158028,5392,17665,10281,1501,144612,256,21792,46212,74250]

theorem envBound36233 : H12AffineFastState.Bounded env36233 := by
  intro p hp
  have h : env36233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36232_36233 : H12AffineEnvironment.transform 21 180408 env36232 = env36233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env36232 == env36233) = true)

theorem identity36233 : scanCanonicalize (H12AffineFastState.compose env36233 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36233 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env36234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190521,1024,32769,4161,180408,17,41430,8328,65,158028,5392,17665,10281,1501,144612,256,21792,46212,513]

theorem envBound36234 : H12AffineFastState.Bounded env36234 := by
  intro p hp
  have h : env36234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36233_36234 : H12AffineEnvironment.transform 15 8203 env36233 = env36234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36233 == env36234) = true)

theorem identity36234 : scanCanonicalize (H12AffineFastState.compose env36234 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound36234 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,43048,1024,32769,4161,32937,17,41430,8328,65,10589,5392,17665,10281,1501,29941,256,21792,46212,513]

theorem envBound36235 : H12AffineFastState.Bounded env36235 := by
  intro p hp
  have h : env36235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36234_36235 : H12AffineEnvironment.transform 16 16401 env36234 = env36235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env36234 == env36235) = true)

theorem identity36235 : scanCanonicalize (H12AffineFastState.compose env36235 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound36235 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env36236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8203,16401,23588,1024,29709,4161,29861,17,21978,8328,65,10589,5392,17665,10281,1501,29941,256,21792,16520,513]

theorem envBound36236 : H12AffineFastState.Bounded env36236 := by
  intro p hp
  have h : env36236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36235_36236 : H12AffineEnvironment.transform 14 29708 env36235 = env36236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env36235 == env36236) = true)

theorem identity36236 : scanCanonicalize (H12AffineFastState.compose env36236 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound36236 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env36237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,0,8203,13341,10280,1024,1,4161,169,17,8662,8328,65,10589,5392,12557,10281,1501,249,256,8492,13444,513]

theorem envBound36237 : H12AffineFastState.Bounded env36237 := by
  intro p hp
  have h : env36237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36236_36237 : H12AffineEnvironment.transform 13 13324 env36236 = env36237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env36236 == env36237) = true)

theorem identity36237 : scanCanonicalize (H12AffineFastState.compose env36237 (packedSelected [0,5,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2540) := by decide +kernel

theorem selectedBound36237 : packedSelected [0,5,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env36238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2540,8192,11744,0,8203,11761,10280,1024,1,2477,169,17,8662,8328,65,10589,3324,10465,10281,1501,249,256,8492,11624,513]

theorem envBound36238 : H12AffineFastState.Bounded env36238 := by
  intro p hp
  have h : env36238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36237_36238 : H12AffineEnvironment.transform 11 2540 env36237 = env36238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2540 env36237 == env36238) = true)

theorem identity36238 : scanCanonicalize (H12AffineFastState.compose env36238 (packedSelected [1,6,7,8,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound36238 : packedSelected [1,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env36239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1297,1277,8192,8433,0,8203,8416,9529,1024,1,1212,169,17,8662,8328,65,9292,493,9712,9528,1501,249,256,8492,8313,513]

theorem envBound36239 : H12AffineFastState.Bounded env36239 := by
  intro p hp
  have h : env36239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36238_36239 : H12AffineEnvironment.transform 10 1297 env36238 = env36239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env36238 == env36239) = true)

theorem identity36239 : scanCanonicalize (H12AffineFastState.compose env36239 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound36239 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env36240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1297,1277,468,293,0,479,308,1261,1024,1,1212,169,17,2,348,65,1432,493,1060,1260,1501,249,256,248,429,513]

theorem envBound36240 : H12AffineFastState.Bounded env36240 := by
  intro p hp
  have h : env36240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36239_36240 : H12AffineEnvironment.transform 12 468 env36239 = env36240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env36239 == env36240) = true)

theorem identity36240 : scanCanonicalize (H12AffineFastState.compose env36240 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound36240 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36241 : List Nat := [2,4,8,16,32,64,128,116,512,1024,1125,1277,160,81,0,171,64,1261,1024,1,1212,169,17,2,40,65,1260,153,1060,1260,1193,249,116,248,217,513]

theorem envBound36241 : H12AffineFastState.Bounded env36241 := by
  intro p hp
  have h : env36241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36240_36241 : H12AffineEnvironment.transform 7 116 env36240 = env36241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env36240 == env36241) = true)

theorem identity36241 : scanCanonicalize (H12AffineFastState.compose env36241 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36241 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env36242 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1077,1197,160,1,0,171,16,1213,1024,1,1212,169,17,2,40,17,1212,153,1060,1212,1193,169,36,168,137,513]

theorem envBound36242 : H12AffineFastState.Bounded env36242 := by
  intro p hp
  have h : env36242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36241_36242 : H12AffineEnvironment.transform 5 16 env36241 = env36242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36241 == env36242) = true)

theorem identity36242 : scanCanonicalize (H12AffineFastState.compose env36242 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound36242 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36243 : List Nat := [2,4,8,16,32,16,128,36,512,189,136,16,160,1,0,171,16,0,189,1,1,169,17,2,40,17,1,153,153,1,20,169,36,168,137,513]

theorem envBound36243 : H12AffineFastState.Bounded env36243 := by
  intro p hp
  have h : env36243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36242_36243 : H12AffineEnvironment.transform 9 189 env36242 = env36243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env36242 == env36243) = true)

theorem identity36243 : scanCanonicalize (H12AffineFastState.compose env36243 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 130) := by decide +kernel

theorem selectedBound36243 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36244 : List Nat := [2,4,8,16,32,16,128,36,130,189,136,16,160,1,0,171,16,0,189,1,1,169,17,2,40,17,1,153,153,1,20,169,36,168,137,131]

theorem envBound36244 : H12AffineFastState.Bounded env36244 := by
  intro p hp
  have h : env36244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36243_36244 : H12AffineEnvironment.transform 8 130 env36243 = env36244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 130 env36243 == env36244) = true)

def env36245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound36245 : H12AffineFastState.Bounded env36245 := by
  intro p hp
  have h : env36245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36102_36245 : H12AffineEnvironment.transform 18 1025 env36102 = env36245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env36102 == env36245) = true)

theorem identity36245 : scanCanonicalize (H12AffineFastState.compose env36245 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 297316) := by decide +kernel

theorem selectedBound36245 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,297316,16777216,8328,65,21186916,18973837,2415669,149860,17108341,23160256,257,19221960,19246189,17050275]

theorem envBound36246 : H12AffineFastState.Bounded env36246 := by
  intro p hp
  have h : env36246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36245_36246 : H12AffineEnvironment.transform 22 297316 env36245 = env36246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297316 env36245 == env36246) = true)

def env36247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182628,1025,32769,2097152,4194304,147456,16777216,8328,65,21186916,18973837,2233681,149860,17024017,23160256,257,19104940,19096841,16966599]

theorem envBound36247 : H12AffineFastState.Bounded env36247 := by
  intro p hp
  have h : env36247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36246_36247 : H12AffineEnvironment.transform 17 182628 env36246 = env36247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182628 env36246 == env36247) = true)

def env36248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35324,1025,32769,2097152,4194304,152,16777216,8328,65,21039612,18973837,2119113,2556,16876681,23160256,257,18990132,18949521,16819039]

theorem envBound36248 : H12AffineFastState.Bounded env36248 := by
  intro p hp
  have h : env36248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36247_36248 : H12AffineEnvironment.transform 16 16536 env36247 = env36248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env36247 == env36248) = true)

def env36249 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,16,16777216,8192,65,21039476,18973701,2118977,2420,16876545,23160136,257,18990132,18949401,16819039]

theorem envBound36249 : H12AffineFastState.Bounded env36249 := by
  intro p hp
  have h : env36249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36248_36249 : H12AffineEnvironment.transform 6 8 env36248 = env36249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36248 == env36249) = true)

theorem identity36249 : scanCanonicalize (H12AffineFastState.compose env36249 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 98644) := by decide +kernel

theorem selectedBound36249 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env36250 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,16,98644,8192,65,4229152,2098513,2118977,2420,1365,6349852,257,2114912,2139213,74251]

theorem envBound36250 : H12AffineFastState.Bounded env36250 := by
  intro p hp
  have h : env36250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36249_36250 : H12AffineEnvironment.transform 23 98644 env36249 = env36250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98644 env36249 == env36250) = true)

theorem identity36250 : scanCanonicalize (H12AffineFastState.compose env36250 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound36250 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env36251 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,73770,16,98644,8192,65,108554,2098513,2118977,2420,1365,2212918,257,2114912,2139213,74251]

theorem envBound36251 : H12AffineFastState.Bounded env36251 := by
  intro p hp
  have h : env36251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36250_36251 : H12AffineEnvironment.transform 21 73770 env36250 = env36251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env36250 == env36251) = true)

theorem identity36251 : scanCanonicalize (H12AffineFastState.compose env36251 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 124186) := by decide +kernel

theorem selectedBound36251 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env36252 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,124186,73770,16,98644,8192,65,108554,122955,110683,2420,1365,8492,257,106618,82263,74251]

theorem envBound36252 : H12AffineFastState.Bounded env36252 := by
  intro p hp
  have h : env36252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36251_36252 : H12AffineEnvironment.transform 20 124186 env36251 = env36252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124186 env36251 == env36252) = true)

theorem identity36252 : scanCanonicalize (H12AffineFastState.compose env36252 (packedSelected [0,1,2,3,4,6,7,8,9,11,12,15,17,18,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound36252 : packedSelected [0,1,2,3,4,6,7,8,9,11,12,15,17,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env36253 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,262,16400,35188,1025,32769,58396,8492,16,32850,8192,65,43276,57677,45405,2420,1365,8492,257,41340,16465,8973]

theorem envBound36253 : H12AffineFastState.Bounded env36253 := by
  intro p hp
  have h : env36253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36252_36253 : H12AffineEnvironment.transform 15 262 env36252 = env36253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env36252 == env36253) = true)

theorem identity36253 : scanCanonicalize (H12AffineFastState.compose env36253 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36253 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env36254 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,262,16400,10280,1025,8541,17728,8492,16,8462,8192,65,2128,16401,4097,2420,1365,8492,257,32,16465,8973]

theorem envBound36254 : H12AffineFastState.Bounded env36254 := by
  intro p hp
  have h : env36254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36253_36254 : H12AffineEnvironment.transform 14 8540 env36253 = env36254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36253 == env36254) = true)

theorem identity36254 : scanCanonicalize (H12AffineFastState.compose env36254 (packedSelected [0,1,3,5,8,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound36254 : packedSelected [0,1,3,5,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,8540,262,5220,10280,1025,8541,4404,8492,16,8462,8192,65,2128,5221,4097,2420,1365,8492,257,32,5157,8973]

theorem envBound36255 : H12AffineFastState.Bounded env36255 := by
  intro p hp
  have h : env36255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36254_36255 : H12AffineEnvironment.transform 13 5236 env36254 = env36255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env36254 == env36255) = true)

theorem identity36255 : scanCanonicalize (H12AffineFastState.compose env36255 (packedSelected [1,3,4,5,6,7,8,10,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound36255 : packedSelected [1,3,4,5,6,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env36256 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,8232,114,5220,10280,1025,8233,4160,8280,16,8314,8192,65,2128,5221,4097,2048,1057,8280,117,32,5157,8825]

theorem envBound36256 : H12AffineFastState.Bounded env36256 := by
  intro p hp
  have h : env36256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36255_36256 : H12AffineEnvironment.transform 7 116 env36255 = env36256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env36255 == env36256) = true)

theorem identity36256 : scanCanonicalize (H12AffineFastState.compose env36256 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound36256 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36257 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,121,5236,81,114,5220,2129,1025,80,4160,33,16,3,121,65,2128,5221,4097,2048,1057,33,117,32,5157,512]

theorem envBound36257 : H12AffineFastState.Bounded env36257 := by
  intro p hp
  have h : env36257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36256_36257 : H12AffineEnvironment.transform 12 121 env36256 = env36257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env36256 == env36257) = true)

theorem identity36257 : scanCanonicalize (H12AffineFastState.compose env36257 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36257 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env36258 : List Nat := [2,4,8,16,1,64,8,85,512,1024,2048,4096,88,5205,81,83,5189,2129,1025,80,4160,0,16,3,88,65,2128,5188,4097,2048,1024,0,84,1,5124,512]

theorem envBound36258 : H12AffineFastState.Bounded env36258 := by
  intro p hp
  have h : env36258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36257_36258 : H12AffineEnvironment.transform 4 1 env36257 = env36258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36257 == env36258) = true)

theorem identity36258 : scanCanonicalize (H12AffineFastState.compose env36258 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound36258 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36259 : List Nat := [2,4,8,16,1,64,8,85,512,1024,81,4096,88,5205,81,83,5189,0,1025,80,4160,0,16,3,88,65,1,5188,4097,81,1024,0,84,1,5124,512]

theorem envBound36259 : H12AffineFastState.Bounded env36259 := by
  intro p hp
  have h : env36259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36258_36259 : H12AffineEnvironment.transform 10 81 env36258 = env36259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env36258 == env36259) = true)

def env36260 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,17,16777216,8193,65,21039477,18973700,2118976,2421,16876544,23160137,257,18990132,18949400,16819039]

theorem envBound36260 : H12AffineFastState.Bounded env36260 := by
  intro p hp
  have h : env36260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36248_36260 : H12AffineEnvironment.transform 6 9 env36248 = env36260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36248 == env36260) = true)

def env36261 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,2097152,4194304,17,16777216,8193,65,21039105,18973700,2118708,2049,16876544,23159869,117,18990132,18949228,16818731]

theorem envBound36261 : H12AffineFastState.Bounded env36261 := by
  intro p hp
  have h : env36261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36260_36261 : H12AffineEnvironment.transform 7 116 env36260 = env36261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env36260 == env36261) = true)

theorem identity36261 : scanCanonicalize (H12AffineFastState.compose env36261 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(23+1) ^^^ 2212885) := by decide +kernel

theorem selectedBound36261 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env36262 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,2097152,4194304,17,2212885,8193,65,6343700,16401,2118708,2049,2113557,4235304,117,33,57465,2188862]

theorem envBound36262 : H12AffineFastState.Bounded env36262 := by
  intro p hp
  have h : env36262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36261_36262 : H12AffineEnvironment.transform 23 2212885 env36261 = env36262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2212885 env36261 == env36262) = true)

def env36263 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,2097152,4194304,17,2212885,8193,17,6343700,16401,2118708,2049,2113557,4235304,37,33,57385,2188862]

theorem envBound36263 : H12AffineFastState.Bounded env36263 := by
  intro p hp
  have h : env36263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36262_36263 : H12AffineEnvironment.transform 5 16 env36262 = env36263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36262 == env36263) = true)

theorem identity36263 : scanCanonicalize (H12AffineFastState.compose env36263 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound36263 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env36264 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8233,65536,16401,10280,1025,8232,2097152,4194304,17,2188348,8193,17,6319165,16401,2118708,2049,2113557,4194305,37,33,16384,2188862]

theorem envBound36264 : H12AffineFastState.Bounded env36264 := by
  intro p hp
  have h : env36264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36263_36264 : H12AffineEnvironment.transform 14 8233 env36263 = env36264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env36263 == env36264) = true)

theorem identity36264 : scanCanonicalize (H12AffineFastState.compose env36264 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 91199) := by decide +kernel

theorem selectedBound36264 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env36265 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8233,65536,16401,10280,1025,8232,91199,4194304,17,3,8193,17,4261890,16401,77835,2049,74794,4194305,37,33,16384,513]

theorem envBound36265 : H12AffineFastState.Bounded env36265 := by
  intro p hp
  have h : env36265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36264_36265 : H12AffineEnvironment.transform 20 91199 env36264 = env36265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91199 env36264 == env36265) = true)

theorem identity36265 : scanCanonicalize (H12AffineFastState.compose env36265 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36265 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env36266 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8233,8202,16401,10280,1025,8232,17461,4194304,17,3,8193,17,4204552,16401,4097,2049,1056,4194305,37,33,16384,513]

theorem envBound36266 : H12AffineFastState.Bounded env36266 := by
  intro p hp
  have h : env36266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36265_36266 : H12AffineEnvironment.transform 15 8202 env36265 = env36266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36265 == env36266) = true)

def env36267 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,2097152,4194304,17,2212885,8193,16,6343700,16401,2118708,2049,2113557,4235304,36,33,57384,2188862]

theorem envBound36267 : H12AffineFastState.Bounded env36267 := by
  intro p hp
  have h : env36267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36262_36267 : H12AffineEnvironment.transform 5 17 env36262 = env36267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36262 == env36267) = true)

theorem identity36267 : scanCanonicalize (H12AffineFastState.compose env36267 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 65538) := by decide +kernel

theorem selectedBound36267 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env36268 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,2097152,65538,17,2212885,8193,16,2214934,16401,2118708,2049,2113557,106538,36,33,57384,2188862]

theorem envBound36268 : H12AffineFastState.Bounded env36268 := by
  intro p hp
  have h : env36268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36267_36268 : H12AffineEnvironment.transform 21 65538 env36267 = env36268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65538 env36267 == env36268) = true)

theorem identity36268 : scanCanonicalize (H12AffineFastState.compose env36268 (packedSelected [0,1,3,5,7,8,9,10,14,17,18,19,20,22,23] rootPS)) = affineNative (2^(20+1) ^^^ 123966) := by decide +kernel

theorem selectedBound36268 : packedSelected [0,1,3,5,7,8,9,10,14,17,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env36269 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,123966,65538,17,8235,8193,16,10280,16401,110602,2049,107563,106538,36,33,57384,33280]

theorem envBound36269 : H12AffineFastState.Bounded env36269 := by
  intro p hp
  have h : env36269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36268_36269 : H12AffineEnvironment.transform 20 123966 env36268 = env36269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 123966 env36268 == env36269) = true)

theorem identity36269 : scanCanonicalize (H12AffineFastState.compose env36269 (packedSelected [0,2,3,4,5,7,9,10,12,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 21509) := by decide +kernel

theorem selectedBound36269 : packedSelected [0,2,3,4,5,7,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env36270 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,21509,65536,16401,23556,1025,21508,77883,65538,17,8235,8193,16,10280,16401,91151,2049,94254,95279,36,33,13357,22021]

theorem envBound36270 : H12AffineFastState.Bounded env36270 := by
  intro p hp
  have h : env36270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36269_36270 : H12AffineEnvironment.transform 14 21509 env36269 = env36270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21509 env36269 == env36270) = true)

theorem identity36270 : scanCanonicalize (H12AffineFastState.compose env36270 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound36270 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36271 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,21509,34,16401,23556,1025,21508,12313,32,17,8235,8193,16,10280,16401,25645,2049,28684,29709,36,33,13357,22021]

theorem envBound36271 : H12AffineFastState.Bounded env36271 := by
  intro p hp
  have h : env36271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36270_36271 : H12AffineEnvironment.transform 15 34 env36270 = env36271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env36270 == env36271) = true)

theorem identity36271 : scanCanonicalize (H12AffineFastState.compose env36271 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound36271 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36272 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,16384,21509,34,16401,23556,1025,21508,4145,32,17,3,41,16,2048,16401,17413,2049,20516,21541,36,33,5125,22021]

theorem envBound36272 : H12AffineFastState.Bounded env36272 := by
  intro p hp
  have h : env36272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36271_36272 : H12AffineEnvironment.transform 12 40 env36271 = env36272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env36271 == env36272) = true)

theorem identity36272 : scanCanonicalize (H12AffineFastState.compose env36272 (packedSelected [1,2,8] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound36272 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env36273 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,0,5125,34,17,7172,1025,5124,4145,32,17,3,41,16,2048,17,1029,2049,4132,5157,36,33,5125,5637]

theorem envBound36273 : H12AffineFastState.Bounded env36273 := by
  intro p hp
  have h : env36273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36272_36273 : H12AffineEnvironment.transform 13 0 env36272 = env36273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env36272 == env36273) = true)

def env36274 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,2097152,4194304,17,16777216,8193,65,21039104,18973700,2118709,2048,16876544,23159868,116,18990132,18949229,16818730]

theorem envBound36274 : H12AffineFastState.Bounded env36274 := by
  intro p hp
  have h : env36274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1