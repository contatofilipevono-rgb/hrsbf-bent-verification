import H12CloudChart1Data139

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env35514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,356,349,1344,0,343,1361,1125,1025,1,292,32,16,2,348,64,1297,1141,64,1124,1365,261,257,260,1077,513]

theorem envBound35514 : H12AffineFastState.Bounded env35514 := by
  intro p hp
  have h : env35514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35513_35514 : H12AffineEnvironment.transform 11 356 env35513 = env35514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env35513 == env35514) = true)

theorem identity35514 : scanCanonicalize (H12AffineFastState.compose env35514 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound35514 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env35515 : List Nat := [2,4,8,16,32,64,9,256,512,321,80,356,349,1,0,343,16,292,320,1,292,32,16,2,348,64,80,308,64,293,20,261,257,260,372,513]

theorem envBound35515 : H12AffineFastState.Bounded env35515 := by
  intro p hp
  have h : env35515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35514_35515 : H12AffineEnvironment.transform 9 321 env35514 = env35515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35514 == env35515) = true)

theorem identity35515 : scanCanonicalize (H12AffineFastState.compose env35515 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35515 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35516 : List Nat := [2,4,8,16,32,64,9,37,512,100,80,65,120,1,0,114,16,1,101,1,1,32,16,2,121,64,80,17,64,0,20,32,36,33,81,513]

theorem envBound35516 : H12AffineFastState.Bounded env35516 := by
  intro p hp
  have h : env35516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35515_35516 : H12AffineEnvironment.transform 7 37 env35515 = env35516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35515 == env35516) = true)

theorem identity35516 : scanCanonicalize (H12AffineFastState.compose env35516 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35516 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35517 : List Nat := [2,4,8,16,32,17,9,37,512,53,1,16,41,1,0,35,16,1,52,1,1,32,16,2,40,17,1,17,17,0,20,32,36,33,0,513]

theorem envBound35517 : H12AffineFastState.Bounded env35517 := by
  intro p hp
  have h : env35517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35516_35517 : H12AffineEnvironment.transform 5 17 env35516 = env35517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35516 == env35517) = true)

theorem identity35517 : scanCanonicalize (H12AffineFastState.compose env35517 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound35517 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35518 : List Nat := [2,4,8,16,32,17,9,37,1,53,1,16,41,1,0,35,16,1,52,1,1,32,16,2,40,17,1,17,17,0,20,32,36,33,0,0]

theorem envBound35518 : H12AffineFastState.Bounded env35518 := by
  intro p hp
  have h : env35518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35517_35518 : H12AffineEnvironment.transform 8 1 env35517 = env35518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env35517 == env35518) = true)

theorem identity35518 : scanCanonicalize (H12AffineFastState.compose env35518 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35518 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35519 : List Nat := [2,4,3,16,32,17,2,37,1,53,1,16,34,1,0,35,16,1,52,1,1,32,16,2,35,17,1,17,17,0,20,32,36,33,0,0]

theorem envBound35519 : H12AffineFastState.Bounded env35519 := by
  intro p hp
  have h : env35519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35518_35519 : H12AffineEnvironment.transform 2 3 env35518 = env35519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35518 == env35519) = true)

def env35520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2144661,2098513,17664,2363592,2102684,2411677,257,21792,46213,2175563]

theorem envBound35520 : H12AffineFastState.Bounded env35520 := by
  intro p hp
  have h : env35520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35491_35520 : H12AffineEnvironment.transform 21 272513 env35491 = env35520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35491 == env35520) = true)

theorem identity35520 : scanCanonicalize (H12AffineFastState.compose env35520 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound35520 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49304,262144,1025,32769,2097152,272513,2101328,41431,8328,64,2144661,2098513,17664,2363592,2102684,2411677,257,21792,46213,2101824]

theorem envBound35521 : H12AffineFastState.Bounded env35521 := by
  intro p hp
  have h : env35521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35520_35521 : H12AffineEnvironment.transform 15 8203 env35520 = env35521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env35520 == env35521) = true)

theorem identity35521 : scanCanonicalize (H12AffineFastState.compose env35521 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35521 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env35522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,25029,262144,1025,8540,2097152,272513,2101328,138,8328,64,2103496,2098513,17664,2363592,2102684,2387392,257,21792,5592,2101824]

theorem envBound35522 : H12AffineFastState.Bounded env35522 := by
  intro p hp
  have h : env35522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35521_35522 : H12AffineEnvironment.transform 14 8541 env35521 = env35522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35521 == env35522) = true)

theorem identity35522 : scanCanonicalize (H12AffineFastState.compose env35522 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35522 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env35523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,24908,262144,1025,8540,2097152,272392,2101328,3,8193,64,2103361,2098513,17664,2363457,2102549,2387273,257,21792,5457,2101824]

theorem envBound35523 : H12AffineFastState.Bounded env35523 := by
  intro p hp
  have h : env35523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35522_35523 : H12AffineEnvironment.transform 6 9 env35522 = env35523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35522 == env35523) = true)

theorem identity35523 : scanCanonicalize (H12AffineFastState.compose env35523 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 23808) := by decide +kernel

theorem selectedBound35523 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env35524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,24908,23808,1025,8540,2097152,29960,2101328,3,8193,64,2103361,2098513,17664,2116929,2102549,2109513,257,21792,5457,2101824]

theorem envBound35524 : H12AffineFastState.Bounded env35524 := by
  intro p hp
  have h : env35524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35523_35524 : H12AffineEnvironment.transform 17 23808 env35523 = env35524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env35523 == env35524) = true)

theorem identity35524 : scanCanonicalize (H12AffineFastState.compose env35524 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(20+1) ^^^ 4404) := by decide +kernel

theorem selectedBound35524 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env35525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,24908,23808,1025,8540,4404,29960,356,3,8193,64,2421,5221,17664,23669,1057,8573,257,21792,5457,884]

theorem envBound35525 : H12AffineFastState.Bounded env35525 := by
  intro p hp
  have h : env35525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35524_35525 : H12AffineEnvironment.transform 20 4404 env35524 = env35525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4404 env35524 == env35525) = true)

theorem identity35525 : scanCanonicalize (H12AffineFastState.compose env35525 (packedSelected [0,1,3,4,5,6,7,8,9,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound35525 : packedSelected [0,1,3,4,5,6,7,8,9,10,17,19] rootPS < 2^1333 := by decide +kernel

def env35526 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8541,8203,13624,2420,1025,8540,4404,8572,356,3,8193,64,2421,5221,4468,2049,1057,8573,257,340,5457,884]

theorem envBound35526 : H12AffineFastState.Bounded env35526 := by
  intro p hp
  have h : env35526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35525_35526 : H12AffineEnvironment.transform 13 5236 env35525 = env35526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env35525 == env35526) = true)

theorem identity35526 : scanCanonicalize (H12AffineFastState.compose env35526 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound35526 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35527 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2317,5236,2128,2310,7221,2420,1025,2129,4404,2161,356,3,2316,64,2421,5221,4468,2049,1057,2160,257,340,5457,884]

theorem envBound35527 : H12AffineFastState.Bounded env35527 := by
  intro p hp
  have h : env35527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35526_35527 : H12AffineEnvironment.transform 12 2317 env35526 = env35527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env35526 == env35527) = true)

theorem identity35527 : scanCanonicalize (H12AffineFastState.compose env35527 (packedSelected [0,4,6,7,9,17] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound35527 : packedSelected [0,4,6,7,9,17] rootPS < 2^1333 := by decide +kernel

def env35528 : List Nat := [2,4,8,16,32,64,9,256,512,1024,81,4096,348,5236,1,343,5220,293,1025,0,4404,32,356,3,349,64,292,5221,4468,80,1057,33,257,340,5457,884]

theorem envBound35528 : H12AffineFastState.Bounded env35528 := by
  intro p hp
  have h : env35528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35527_35528 : H12AffineEnvironment.transform 10 81 env35527 = env35528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env35527 == env35528) = true)

theorem identity35528 : scanCanonicalize (H12AffineFastState.compose env35528 (packedSelected [0,2,3,5,6,7,12] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound35528 : packedSelected [0,2,3,5,6,7,12] rootPS < 2^1333 := by decide +kernel

def env35529 : List Nat := [2,4,8,16,32,64,9,256,512,100,81,4096,348,4112,1,343,4096,293,101,0,4404,32,356,3,349,64,292,4097,4468,80,69,33,257,340,4405,884]

theorem envBound35529 : H12AffineFastState.Bounded env35529 := by
  intro p hp
  have h : env35529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35528_35529 : H12AffineEnvironment.transform 9 100 env35528 = env35529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env35528 == env35529) = true)

theorem identity35529 : scanCanonicalize (H12AffineFastState.compose env35529 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35529 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env35530 : List Nat := [2,4,8,16,32,64,9,117,512,100,81,4096,41,4112,1,34,4096,80,101,0,4161,32,17,3,40,64,81,4097,4097,80,69,33,116,33,4160,513]

theorem envBound35530 : H12AffineFastState.Bounded env35530 := by
  intro p hp
  have h : env35530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35529_35530 : H12AffineEnvironment.transform 7 117 env35529 = env35530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35529 == env35530) = true)

theorem identity35530 : scanCanonicalize (H12AffineFastState.compose env35530 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound35530 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35531 : List Nat := [2,4,8,16,32,64,9,117,16,100,81,4096,41,4112,1,34,4096,80,101,0,4161,32,17,3,40,64,81,4097,4097,80,69,33,116,33,4160,17]

theorem envBound35531 : H12AffineFastState.Bounded env35531 := by
  intro p hp
  have h : env35531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35530_35531 : H12AffineEnvironment.transform 8 16 env35530 = env35531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env35530 == env35531) = true)

theorem identity35531 : scanCanonicalize (H12AffineFastState.compose env35531 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound35531 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35532 : List Nat := [2,4,8,16,32,64,9,117,16,100,81,17,41,1,1,34,17,80,101,0,80,32,17,3,40,64,81,16,16,80,69,33,116,33,81,17]

theorem envBound35532 : H12AffineFastState.Bounded env35532 := by
  intro p hp
  have h : env35532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35531_35532 : H12AffineEnvironment.transform 11 17 env35531 = env35532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env35531 == env35532) = true)

theorem identity35532 : scanCanonicalize (H12AffineFastState.compose env35532 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound35532 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35533 : List Nat := [2,4,8,16,32,33,9,20,16,5,48,17,41,1,1,34,17,49,4,0,49,32,17,3,40,33,48,16,16,49,36,33,21,33,48,17]

theorem envBound35533 : H12AffineFastState.Bounded env35533 := by
  intro p hp
  have h : env35533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35532_35533 : H12AffineEnvironment.transform 5 33 env35532 = env35533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env35532 == env35533) = true)

def env35534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6590741,2098512,17665,2363592,2102684,6349853,257,21792,46213,2175563]

theorem envBound35534 : H12AffineFastState.Bounded env35534 := by
  intro p hp
  have h : env35534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35490_35534 : H12AffineEnvironment.transform 16 49305 env35490 = env35534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env35490 == env35534) = true)

def env35535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2144661,2098512,17665,2363592,2102684,2411677,257,21792,46213,2175563]

theorem envBound35535 : H12AffineFastState.Bounded env35535 := by
  intro p hp
  have h : env35535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35534_35535 : H12AffineEnvironment.transform 21 272512 env35534 = env35535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35534 == env35535) = true)

theorem identity35535 : scanCanonicalize (H12AffineFastState.compose env35535 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound35535 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,115871,272512,120014,98781,8328,64,97546,115151,17665,382039,119043,329730,257,21792,46213,63188]

theorem envBound35536 : H12AffineFastState.Bounded env35536 := by
  intro p hp
  have h : env35536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35535_35536 : H12AffineEnvironment.transform 20 115871 env35535 = env35536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env35535 == env35536) = true)

def env35537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10400,1025,32769,115871,32,120014,98781,8328,64,97546,115151,17665,130295,119043,73890,257,21792,46213,63188]

theorem envBound35537 : H12AffineFastState.Bounded env35537 := by
  intro p hp
  have h : env35537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35536_35537 : H12AffineEnvironment.transform 17 10400 env35536 = env35537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env35536 == env35537) = true)

theorem identity35537 : scanCanonicalize (H12AffineFastState.compose env35537 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8433) := by decide +kernel

theorem selectedBound35537 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env35538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8433,65536,24680,10400,1025,8432,91246,32,95295,74028,8328,64,97546,90430,17665,89094,94706,73890,257,21792,5236,22053]

theorem envBound35538 : H12AffineFastState.Bounded env35538 := by
  intro p hp
  have h : env35538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35537_35538 : H12AffineEnvironment.transform 14 8433 env35537 = env35538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8433 env35537 == env35538) = true)

theorem identity35538 : scanCanonicalize (H12AffineFastState.compose env35538 (packedSelected [0,1,8,9,10,12,14,15,18,19,22,23,27,31,35] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound35538 : packedSelected [0,1,8,9,10,12,14,15,18,19,22,23,27,31,35] rootPS < 2^1333 := by decide +kernel

def env35539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13609,8433,65536,5441,10400,1025,8432,69959,32,65814,74028,8328,64,67619,70679,12328,76079,66779,73890,257,8201,5236,8972]

theorem envBound35539 : H12AffineFastState.Bounded env35539 := by
  intro p hp
  have h : env35539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35538_35539 : H12AffineEnvironment.transform 13 13609 env35538 = env35539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env35538 == env35539) = true)

theorem identity35539 : scanCanonicalize (H12AffineFastState.compose env35539 (packedSelected [1,7,8,12,14,15,16,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound35539 : packedSelected [1,7,8,12,14,15,16,26,27] rootPS < 2^1333 := by decide +kernel

def env35540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13609,8433,398,5441,10400,1025,8432,4297,32,152,8354,8328,64,2477,5529,12328,10401,1365,8492,257,8201,5236,8972]

theorem envBound35540 : H12AffineFastState.Bounded env35540 := by
  intro p hp
  have h : env35540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35539_35540 : H12AffineEnvironment.transform 15 398 env35539 = env35540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env35539 == env35540) = true)

theorem identity35540 : scanCanonicalize (H12AffineFastState.compose env35540 (packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound35540 : packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env35541 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,13525,8433,114,5309,10400,1025,8432,4297,32,152,8354,8328,64,2129,5221,12328,10401,1193,8400,253,8201,5236,8944]

theorem envBound35541 : H12AffineFastState.Bounded env35541 := by
  intro p hp
  have h : env35541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35540_35541 : H12AffineEnvironment.transform 7 252 env35540 = env35541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env35540 == env35541) = true)

theorem identity35541 : scanCanonicalize (H12AffineFastState.compose env35541 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound35541 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env35542 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,120,5293,137,114,5309,2264,1025,136,4297,32,152,218,240,64,2129,5221,4176,2265,1193,168,253,113,5236,648]

theorem envBound35542 : H12AffineFastState.Bounded env35542 := by
  intro p hp
  have h : env35542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35541_35542 : H12AffineEnvironment.transform 12 120 env35541 = env35542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env35541 == env35542) = true)

theorem identity35542 : scanCanonicalize (H12AffineFastState.compose env35542 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35542 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env35543 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,40,5293,137,34,5309,2184,1025,136,4249,32,152,138,160,16,2049,5173,4096,2185,1193,168,173,33,5156,648]

theorem envBound35543 : H12AffineFastState.Bounded env35543 := by
  intro p hp
  have h : env35543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35542_35543 : H12AffineEnvironment.transform 5 16 env35542 = env35543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35542 == env35543) = true)

theorem identity35543 : scanCanonicalize (H12AffineFastState.compose env35543 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound35543 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env35544 : List Nat := [2,4,8,16,32,16,128,172,512,188,2048,4096,40,4113,137,34,4097,2184,189,136,4249,32,152,138,160,16,2049,4233,4096,2185,21,168,173,33,4248,648]

theorem envBound35544 : H12AffineFastState.Bounded env35544 := by
  intro p hp
  have h : env35544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35543_35544 : H12AffineEnvironment.transform 9 188 env35543 = env35544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env35543 == env35544) = true)

def env35545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10401,1025,32769,115871,33,120014,98781,8328,64,97546,115151,17665,130294,119043,73891,257,21792,46213,63188]

theorem envBound35545 : H12AffineFastState.Bounded env35545 := by
  intro p hp
  have h : env35545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35536_35545 : H12AffineEnvironment.transform 17 10401 env35536 = env35545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env35536 == env35545) = true)

theorem identity35545 : scanCanonicalize (H12AffineFastState.compose env35545 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound35545 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env35546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,5529,10401,1025,21761,70047,33,65998,87261,8328,64,97546,70863,17665,76278,66563,73891,257,21792,24965,9172]

theorem envBound35546 : H12AffineFastState.Bounded env35546 := by
  intro p hp
  have h : env35546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35545_35546 : H12AffineEnvironment.transform 14 21760 env35545 = env35546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env35545 == env35546) = true)

theorem identity35546 : scanCanonicalize (H12AffineFastState.compose env35546 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound35546 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env35547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,479,5529,10401,1025,21761,4160,33,17,21762,8328,64,31957,5392,17665,10281,1500,8572,257,21792,24965,9172]

theorem envBound35547 : H12AffineFastState.Bounded env35547 := by
  intro p hp
  have h : env35547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35546_35547 : H12AffineEnvironment.transform 15 479 env35546 = env35547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env35546 == env35547) = true)

theorem identity35547 : scanCanonicalize (H12AffineFastState.compose env35547 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35547 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env35548 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,342,5392,10280,1025,21761,4160,33,17,21762,8193,64,31836,5392,17665,10281,1365,8572,257,21792,24844,9053]

theorem envBound35548 : H12AffineFastState.Bounded env35548 := by
  intro p hp
  have h : env35548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35547_35548 : H12AffineEnvironment.transform 6 9 env35547 = env35548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35547 == env35548) = true)

theorem identity35548 : scanCanonicalize (H12AffineFastState.compose env35548 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound35548 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env35549 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,342,5392,10280,1025,0,4160,33,17,3,8193,64,10589,5392,4096,10281,1365,8572,257,33,13325,9053]

theorem envBound35549 : H12AffineFastState.Bounded env35549 := by
  intro p hp
  have h : env35549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35548_35549 : H12AffineEnvironment.transform 13 5377 env35548 = env35549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env35548 == env35549) = true)

theorem identity35549 : scanCanonicalize (H12AffineFastState.compose env35549 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35549 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env35550 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,1,342,5392,2341,1025,0,4160,33,17,3,268,64,2128,5392,4096,2340,1365,113,257,33,5376,592]

theorem envBound35550 : H12AffineFastState.Bounded env35550 := by
  intro p hp
  have h : env35550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35549_35550 : H12AffineEnvironment.transform 12 269 env35549 = env35550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35549 == env35550) = true)

theorem identity35550 : scanCanonicalize (H12AffineFastState.compose env35550 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 356) := by decide +kernel

theorem selectedBound35550 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env35551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,356,4096,269,5377,1,342,5392,65,1025,0,4160,33,17,3,268,64,308,5392,4096,64,1365,113,257,33,5376,592]

theorem envBound35551 : H12AffineFastState.Bounded env35551 := by
  intro p hp
  have h : env35551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35550_35551 : H12AffineEnvironment.transform 10 356 env35550 = env35551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 356 env35550 == env35551) = true)

theorem identity35551 : scanCanonicalize (H12AffineFastState.compose env35551 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35551 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env35552 : List Nat := [2,4,8,16,32,64,9,256,512,273,356,4096,269,4112,1,342,4097,65,272,0,4160,33,17,3,268,64,308,4097,4096,64,68,113,257,33,4113,592]

theorem envBound35552 : H12AffineFastState.Bounded env35552 := by
  intro p hp
  have h : env35552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35551_35552 : H12AffineEnvironment.transform 9 273 env35551 = env35552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35551 == env35552) = true)

theorem identity35552 : scanCanonicalize (H12AffineFastState.compose env35552 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 593) := by decide +kernel

theorem selectedBound35552 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env35553 : List Nat := [2,4,8,16,32,64,9,256,512,273,356,593,269,577,1,342,592,65,272,0,529,33,17,3,268,64,308,592,593,64,68,113,257,33,576,592]

theorem envBound35553 : H12AffineFastState.Bounded env35553 := by
  intro p hp
  have h : env35553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35552_35553 : H12AffineEnvironment.transform 11 593 env35552 = env35553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 593 env35552 == env35553) = true)

def env35554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2144660,2098512,17665,2363592,2102684,2411676,257,21792,46213,2175563]

theorem envBound35554 : H12AffineFastState.Bounded env35554 := by
  intro p hp
  have h : env35554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35534_35554 : H12AffineEnvironment.transform 21 272513 env35534 = env35554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35534 == env35554) = true)

theorem identity35554 : scanCanonicalize (H12AffineFastState.compose env35554 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound35554 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,49305,262144,1025,32769,2097152,272513,2101329,21762,8328,64,2144660,2098512,17665,2363592,2102684,2411676,257,21792,46213,2156180]

theorem envBound35555 : H12AffineFastState.Bounded env35555 := by
  intro p hp
  have h : env35555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35554_35555 : H12AffineEnvironment.transform 15 54495 env35554 = env35555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env35554 == env35555) = true)

def env35556 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49169,262144,1025,32769,2097152,272393,2101329,21762,8192,64,2144540,2098512,17665,2363456,2102548,2411540,257,21792,46093,2156060]

theorem envBound35556 : H12AffineFastState.Bounded env35556 := by
  intro p hp
  have h : env35556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35555_35556 : H12AffineEnvironment.transform 6 8 env35555 = env35556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35555 == env35556) = true)

theorem identity35556 : scanCanonicalize (H12AffineFastState.compose env35556 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 45112) := by decide +kernel

theorem selectedBound35556 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env35557 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49169,262144,1025,32769,45112,272393,41065,21762,8192,64,2340,46440,17665,303224,42284,293932,257,21792,46093,22052]

theorem envBound35557 : H12AffineFastState.Bounded env35557 := by
  intro p hp
  have h : env35557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35556_35557 : H12AffineEnvironment.transform 20 45112 env35556 = env35557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45112 env35556 == env35557) = true)

theorem identity35557 : scanCanonicalize (H12AffineFastState.compose env35557 (packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,18,19,28] rootPS)) = affineNative (2^(17+1) ^^^ 43276) := by decide +kernel

theorem selectedBound35557 : packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,18,19,28] rootPS < 2^1333 := by decide +kernel

def env35558 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49169,43276,1025,32769,45112,33029,41065,21762,8192,64,2340,46440,17665,2420,42284,54560,257,21792,46093,22052]

theorem envBound35558 : H12AffineFastState.Bounded env35558 := by
  intro p hp
  have h : env35558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35557_35558 : H12AffineEnvironment.transform 17 43276 env35557 = env35558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43276 env35557 == env35558) = true)

theorem identity35558 : scanCanonicalize (H12AffineFastState.compose env35558 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound35558 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env35559 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,342,5392,31757,1025,21760,25913,21508,30056,21762,8192,64,2340,24681,17665,2420,28717,33,257,21792,24844,22052]

theorem envBound35559 : H12AffineFastState.Bounded env35559 := by
  intro p hp
  have h : env35559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35558_35559 : H12AffineEnvironment.transform 14 21761 env35558 = env35559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env35558 == env35559) = true)

theorem identity35559 : scanCanonicalize (H12AffineFastState.compose env35559 (packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 7261) := by decide +kernel

theorem selectedBound35559 : packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS < 2^1333 := by decide +kernel

def env35560 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7261,16384,21761,342,5392,16464,1025,21760,22884,21508,18741,21762,7261,64,2340,23604,17665,2420,19568,33,257,21792,23889,22052]

theorem envBound35560 : H12AffineFastState.Bounded env35560 := by
  intro p hp
  have h : env35560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35559_35560 : H12AffineEnvironment.transform 12 7261 env35559 = env35560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7261 env35559 == env35560) = true)

theorem identity35560 : scanCanonicalize (H12AffineFastState.compose env35560 (packedSelected [0,1,2,3,5,6,7,8,12,20] rootPS)) = affineNative (2^(13+1) ^^^ 6500) := by decide +kernel

theorem selectedBound35560 : packedSelected [0,1,2,3,5,6,7,8,12,20] rootPS < 2^1333 := by decide +kernel

def env35561 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7261,6500,3173,342,5392,6452,1025,3172,0,3424,4177,3174,7261,64,2340,1360,7269,2420,5396,33,257,3140,1077,3904]

theorem envBound35561 : H12AffineFastState.Bounded env35561 := by
  intro p hp
  have h : env35561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35560_35561 : H12AffineEnvironment.transform 13 6500 env35560 = env35561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6500 env35560 == env35561) = true)

theorem identity35561 : scanCanonicalize (H12AffineFastState.compose env35561 (packedSelected [1,2,3,4,5,6,8,12,16,17,22] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound35561 : packedSelected [1,2,3,4,5,6,8,12,16,17,22] rootPS < 2^1333 := by decide +kernel

def env35562 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3328,349,1124,3173,342,2064,1076,1025,3172,0,3424,3409,3174,349,64,2340,1360,357,2420,2068,33,257,3140,1077,3904]

theorem envBound35562 : H12AffineFastState.Bounded env35562 := by
  intro p hp
  have h : env35562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35561_35562 : H12AffineEnvironment.transform 11 3328 env35561 = env35562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env35561 == env35562) = true)

theorem identity35562 : scanCanonicalize (H12AffineFastState.compose env35562 (packedSelected [0,1,3,5,8,9,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound35562 : packedSelected [0,1,3,5,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env35563 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,2113,349,293,2340,342,2064,373,320,2341,0,2081,2064,2343,349,64,2340,17,357,2420,2068,33,257,2309,372,2561]

theorem envBound35563 : H12AffineFastState.Bounded env35563 := by
  intro p hp
  have h : env35563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35562_35563 : H12AffineEnvironment.transform 9 321 env35562 = env35563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35562 == env35563) = true)

theorem identity35563 : scanCanonicalize (H12AffineFastState.compose env35563 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound35563 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env35564 : List Nat := [2,4,8,16,32,64,8,256,512,321,372,309,349,293,80,342,356,373,320,81,0,341,356,83,349,64,80,17,357,0,352,33,257,113,372,885]

theorem envBound35564 : H12AffineFastState.Bounded env35564 := by
  intro p hp
  have h : env35564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35563_35564 : H12AffineEnvironment.transform 10 372 env35563 = env35564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env35563 == env35564) = true)

theorem identity35564 : scanCanonicalize (H12AffineFastState.compose env35564 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound35564 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env35565 : List Nat := [2,4,8,16,32,64,8,116,512,53,0,65,41,81,80,34,16,1,52,81,0,33,16,83,41,64,80,17,17,0,20,33,117,113,0,513]

theorem envBound35565 : H12AffineFastState.Bounded env35565 := by
  intro p hp
  have h : env35565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35564_35565 : H12AffineEnvironment.transform 7 116 env35564 = env35565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env35564 == env35565) = true)

def env35566 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,262144,1025,32769,2097152,272392,2101329,21762,8193,64,2144541,2098512,17665,2363457,2102549,2411541,257,21792,46092,2156061]

theorem envBound35566 : H12AffineFastState.Bounded env35566 := by
  intro p hp
  have h : env35566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35555_35566 : H12AffineEnvironment.transform 6 9 env35555 = env35566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35555 == env35566) = true)

theorem identity35566 : scanCanonicalize (H12AffineFastState.compose env35566 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound35566 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env35567 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,262144,1025,32769,25629,272392,29772,21762,8193,64,56576,24909,17665,291932,28936,305160,257,21792,46092,33280]

theorem envBound35567 : H12AffineFastState.Bounded env35567 := by
  intro p hp
  have h : env35567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35566_35567 : H12AffineEnvironment.transform 20 25629 env35566 = env35567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env35566 == env35567) = true)

theorem identity35567 : scanCanonicalize (H12AffineFastState.compose env35567 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound35567 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env35568 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,43049,1025,32769,25629,32801,29772,21762,8193,64,56576,24909,17665,56437,28936,33,257,21792,46092,33280]

theorem envBound35568 : H12AffineFastState.Bounded env35568 := by
  intro p hp
  have h : env35568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35567_35568 : H12AffineEnvironment.transform 17 43049 env35567 = env35568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env35567 == env35568) = true)

theorem identity35568 : scanCanonicalize (H12AffineFastState.compose env35568 (packedSelected [1,2,6,8,10,14,15,16,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35568 : packedSelected [1,2,6,8,10,14,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env35569 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,49168,43049,1025,32769,25629,32801,29724,21762,8193,16,56576,24861,17665,56357,28936,33,257,21792,46092,33280]

theorem envBound35569 : H12AffineFastState.Bounded env35569 := by
  intro p hp
  have h : env35569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35568_35569 : H12AffineEnvironment.transform 5 16 env35568 = env35569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35568 == env35569) = true)

theorem identity35569 : scanCanonicalize (H12AffineFastState.compose env35569 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound35569 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env35570 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,32768,40971,46109,43049,1025,32769,4112,32801,17,8463,8193,16,43277,5392,12556,43048,1285,33,257,8493,46092,33280]

theorem envBound35570 : H12AffineFastState.Bounded env35570 := by
  intro p hp
  have h : env35570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35569_35570 : H12AffineEnvironment.transform 13 13325 env35569 = env35570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env35569 == env35570) = true)

theorem identity35570 : scanCanonicalize (H12AffineFastState.compose env35570 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound35570 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env35571 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,1,8202,13340,10280,1025,0,4112,32,17,8463,8193,16,10508,5392,12556,10281,1285,33,257,8493,13325,513]

theorem envBound35571 : H12AffineFastState.Bounded env35571 := by
  intro p hp
  have h : env35571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35570_35571 : H12AffineEnvironment.transform 14 1 env35570 = env35571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env35570 == env35571) = true)

theorem identity35571 : scanCanonicalize (H12AffineFastState.compose env35571 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 3888) := by decide +kernel

theorem selectedBound35571 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env35572 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3888,8192,11069,1,8202,11052,10280,1025,0,3872,32,17,8463,8193,16,10508,2592,11836,10281,1285,33,257,8493,11069,513]

theorem envBound35572 : H12AffineFastState.Bounded env35572 := by
  intro p hp
  have h : env35572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35571_35572 : H12AffineEnvironment.transform 11 3888 env35571 = env35572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env35571 == env35572) = true)

theorem identity35572 : scanCanonicalize (H12AffineFastState.compose env35572 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35572 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35573 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3888,269,2608,1,263,2593,2341,1025,0,3872,32,17,2,268,16,2049,2592,3889,2340,1285,33,257,32,2608,513]

theorem envBound35573 : H12AffineFastState.Bounded env35573 := by
  intro p hp
  have h : env35573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35572_35573 : H12AffineEnvironment.transform 12 269 env35572 = env35573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35572 == env35573) = true)

theorem identity35573 : scanCanonicalize (H12AffineFastState.compose env35573 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound35573 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35574 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1588,260,269,1028,1,263,1045,1809,1025,0,276,32,17,2,268,16,1589,1044,261,1808,1285,33,257,32,1028,513]

theorem envBound35574 : H12AffineFastState.Bounded env35574 := by
  intro p hp
  have h : env35574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35573_35574 : H12AffineEnvironment.transform 10 1588 env35573 = env35574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env35573 == env35574) = true)

theorem identity35574 : scanCanonicalize (H12AffineFastState.compose env35574 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound35574 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35575 : List Nat := [2,4,8,16,32,16,9,256,512,785,293,260,269,789,1,263,772,0,784,0,276,32,17,2,268,16,292,773,261,1,532,33,257,32,789,513]

theorem envBound35575 : H12AffineFastState.Bounded env35575 := by
  intro p hp
  have h : env35575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35574_35575 : H12AffineEnvironment.transform 9 785 env35574 = env35575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env35574 == env35575) = true)

theorem identity35575 : scanCanonicalize (H12AffineFastState.compose env35575 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35575 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35576 : List Nat := [2,4,8,1,32,1,9,256,512,768,293,260,269,772,1,263,772,0,769,0,261,32,0,2,268,1,292,773,261,1,517,33,257,32,772,513]

theorem envBound35576 : H12AffineFastState.Bounded env35576 := by
  intro p hp
  have h : env35576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35575_35576 : H12AffineEnvironment.transform 3 1 env35575 = env35576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35575 == env35576) = true)

theorem identity35576 : scanCanonicalize (H12AffineFastState.compose env35576 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound35576 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35577 : List Nat := [2,4,8,1,32,1,9,256,261,5,293,260,269,1,1,263,1,0,4,0,261,32,0,2,268,1,292,0,261,1,256,33,257,32,1,260]

theorem envBound35577 : H12AffineFastState.Bounded env35577 := by
  intro p hp
  have h : env35577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35576_35577 : H12AffineEnvironment.transform 8 261 env35576 = env35577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env35576 == env35577) = true)

theorem identity35577 : scanCanonicalize (H12AffineFastState.compose env35577 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35577 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env35578 : List Nat := [2,4,8,1,1,1,9,256,261,5,260,260,269,1,1,263,1,0,4,0,261,1,0,2,268,1,261,0,261,1,256,0,257,1,1,260]

theorem envBound35578 : H12AffineFastState.Bounded env35578 := by
  intro p hp
  have h : env35578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35577_35578 : H12AffineEnvironment.transform 4 1 env35577 = env35578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35577 == env35578) = true)

theorem identity35578 : scanCanonicalize (H12AffineFastState.compose env35578 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound35578 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35579 : List Nat := [2,4,8,1,1,1,9,5,0,5,1,1,8,1,1,2,1,0,4,0,0,1,0,2,9,1,0,0,0,1,5,0,4,1,1,1]

theorem envBound35579 : H12AffineFastState.Bounded env35579 := by
  intro p hp
  have h : env35579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35578_35579 : H12AffineEnvironment.transform 7 5 env35578 = env35579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env35578 == env35579) = true)

def env35580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281673,213316,8328,64,6705549,2278857,165273,2363593,2102685,6431876,257,21793,46212,2175562]

theorem envBound35580 : H12AffineFastState.Bounded env35580 := by
  intro p hp
  have h : env35580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35489_35580 : H12AffineEnvironment.transform 22 2281673 env35489 = env35580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281673 env35489 == env35580) = true)

def env35581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6590741,2098513,17665,2363593,2102685,6349852,257,21793,46212,2175562]

theorem envBound35581 : H12AffineFastState.Bounded env35581 := by
  intro p hp
  have h : env35581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35580_35581 : H12AffineEnvironment.transform 16 49304 env35580 = env35581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env35580 == env35581) = true)

def env35582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2144661,2098513,17665,2363593,2102685,2411676,257,21793,46212,2175562]

theorem envBound35582 : H12AffineFastState.Bounded env35582 := by
  intro p hp
  have h : env35582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35581_35582 : H12AffineEnvironment.transform 21 272512 env35581 = env35582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35581 == env35582) = true)

def env35583 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272392,2101329,98644,8192,64,2144541,2098513,17665,2363457,2102549,2411540,257,21793,46092,2175562]

theorem envBound35583 : H12AffineFastState.Bounded env35583 := by
  intro p hp
  have h : env35583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35582_35583 : H12AffineEnvironment.transform 6 8 env35582 = env35583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35582 == env35583) = true)

theorem identity35583 : scanCanonicalize (H12AffineFastState.compose env35583 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 110666) := by decide +kernel

theorem selectedBound35583 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env35584 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,110666,272392,106523,98644,8192,64,67927,111899,17665,368651,107871,359518,257,21793,46092,33280]

theorem envBound35584 : H12AffineFastState.Bounded env35584 := by
  intro p hp
  have h : env35584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35583_35584 : H12AffineEnvironment.transform 20 110666 env35583 = env35584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 110666 env35583 == env35584) = true)

theorem identity35584 : scanCanonicalize (H12AffineFastState.compose env35584 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35584 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env35585 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,49168,262144,1025,32769,102679,264533,98630,98644,349,64,67927,103494,17665,360790,99330,351491,257,21793,38225,33280]

theorem envBound35585 : H12AffineFastState.Bounded env35585 := by
  intro p hp
  have h : env35585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35584_35585 : H12AffineEnvironment.transform 12 349 env35584 = env35585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35584 == env35585) = true)

theorem identity35585 : scanCanonicalize (H12AffineFastState.compose env35585 (packedSelected [1,3,4,7,9,17,18,23,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound35585 : packedSelected [1,3,4,7,9,17,18,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env35586 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,49168,56357,1025,32769,102679,54640,98630,98644,349,64,67927,103494,17665,89459,99330,98598,257,21793,38225,33280]

theorem envBound35586 : H12AffineFastState.Bounded env35586 := by
  intro p hp
  have h : env35586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35585_35586 : H12AffineEnvironment.transform 17 56357 env35585 = env35586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env35585 == env35586) = true)

theorem identity35586 : scanCanonicalize (H12AffineFastState.compose env35586 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound35586 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35587 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,33110,49168,56357,1025,32769,4161,54640,16,2,349,64,34817,5392,17665,56357,1364,112,257,21793,38225,33280]

theorem envBound35587 : H12AffineFastState.Bounded env35587 := by
  intro p hp
  have h : env35587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35586_35587 : H12AffineEnvironment.transform 15 33110 env35586 = env35587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env35586 == env35587) = true)

theorem identity35587 : scanCanonicalize (H12AffineFastState.compose env35587 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound35587 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35588 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,343,16401,23588,1025,0,4161,21873,16,2,349,64,2048,5392,17665,23588,1364,112,257,21793,5456,513]

theorem envBound35588 : H12AffineFastState.Bounded env35588 := by
  intro p hp
  have h : env35588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35587_35588 : H12AffineEnvironment.transform 14 1 env35587 = env35588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env35587 == env35588) = true)

theorem identity35588 : scanCanonicalize (H12AffineFastState.compose env35588 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound35588 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35589 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5156,1,343,5173,2048,1025,0,4161,341,16,2,349,64,2048,5392,4389,2048,1364,112,257,261,5456,513]

theorem envBound35589 : H12AffineFastState.Bounded env35589 := by
  intro p hp
  have h : env35589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35588_35589 : H12AffineEnvironment.transform 13 5156 env35588 = env35589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env35588 == env35589) = true)

theorem identity35589 : scanCanonicalize (H12AffineFastState.compose env35589 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound35589 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35590 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,349,4113,1,343,4096,2048,52,0,4161,341,16,2,349,64,2048,4389,4389,2048,353,112,257,261,4453,513]

theorem envBound35590 : H12AffineFastState.Bounded env35590 := by
  intro p hp
  have h : env35590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35589_35590 : H12AffineEnvironment.transform 9 53 env35589 = env35590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35589 == env35590) = true)

theorem identity35590 : scanCanonicalize (H12AffineFastState.compose env35590 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35590 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35591 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,4096,120,4113,1,114,4096,2048,52,0,4161,112,16,2,120,64,2048,4096,4096,2048,68,112,36,32,4160,513]

theorem envBound35591 : H12AffineFastState.Bounded env35591 := by
  intro p hp
  have h : env35591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35590_35591 : H12AffineEnvironment.transform 7 37 env35590 = env35591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35590 == env35591) = true)

theorem identity35591 : scanCanonicalize (H12AffineFastState.compose env35591 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound35591 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35592 : List Nat := [2,4,8,16,32,64,8,37,512,53,0,4096,120,4113,1,114,4096,0,52,0,4161,112,16,2,120,64,0,4096,4096,0,68,112,36,32,4160,513]

theorem envBound35592 : H12AffineFastState.Bounded env35592 := by
  intro p hp
  have h : env35592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35591_35592 : H12AffineEnvironment.transform 10 0 env35591 = env35592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env35591 == env35592) = true)

theorem identity35592 : scanCanonicalize (H12AffineFastState.compose env35592 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 91) := by decide +kernel

theorem selectedBound35592 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35593 : List Nat := [2,4,8,16,32,64,8,37,512,53,0,91,120,74,1,114,91,0,52,0,26,112,16,2,120,64,0,91,91,0,68,112,36,32,27,513]

theorem envBound35593 : H12AffineFastState.Bounded env35593 := by
  intro p hp
  have h : env35593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35592_35593 : H12AffineEnvironment.transform 11 91 env35592 = env35593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 91 env35592 == env35593) = true)

def env35594 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272393,2101329,98645,8193,64,2144540,2098513,17665,2363456,2102548,2411541,257,21793,46093,2175562]

theorem envBound35594 : H12AffineFastState.Bounded env35594 := by
  intro p hp
  have h : env35594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35582_35594 : H12AffineEnvironment.transform 6 9 env35582 = env35594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35582 == env35594) = true)

def env35595 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272393,17,98645,8193,64,43356,5393,17665,262144,1364,318549,257,21793,46093,74250]

theorem envBound35595 : H12AffineFastState.Bounded env35595 := by
  intro p hp
  have h : env35595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35594_35595 : H12AffineEnvironment.transform 20 4160 env35594 = env35595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env35594 == env35595) = true)

theorem identity35595 : scanCanonicalize (H12AffineFastState.compose env35595 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35595 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35596 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4160,33,17,98645,8193,64,43356,5393,17665,10280,1364,62589,257,21793,46093,74250]

theorem envBound35596 : H12AffineFastState.Bounded env35596 := by
  intro p hp
  have h : env35596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35595_35596 : H12AffineEnvironment.transform 17 10280 env35595 = env35596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35595 == env35596) = true)

theorem identity35596 : scanCanonicalize (H12AffineFastState.compose env35596 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35596 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env35597 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24908,10280,1025,8540,4160,33,17,73736,8193,64,2049,5393,17665,10280,1364,21792,257,21793,5456,74250]

theorem envBound35597 : H12AffineFastState.Bounded env35597 := by
  intro p hp
  have h : env35597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35596_35597 : H12AffineEnvironment.transform 14 8541 env35596 = env35597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35596 == env35597) = true)

theorem identity35597 : scanCanonicalize (H12AffineFastState.compose env35597 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35597 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env35598 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,65536,24861,10280,1025,8461,4113,33,17,73736,8193,17,2049,5393,17665,10280,1285,21792,257,21793,5377,74250]

theorem envBound35598 : H12AffineFastState.Bounded env35598 := by
  intro p hp
  have h : env35598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35597_35598 : H12AffineEnvironment.transform 5 17 env35597 = env35598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35597 == env35598) = true)

theorem identity35598 : scanCanonicalize (H12AffineFastState.compose env35598 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound35598 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env35599 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,263,24861,10280,1025,8461,4113,33,17,8463,8193,17,2049,5393,17665,10280,1285,21792,257,21793,5377,8973]

theorem envBound35599 : H12AffineFastState.Bounded env35599 := by
  intro p hp
  have h : env35599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35598_35599 : H12AffineEnvironment.transform 15 263 env35598 = env35599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env35598 == env35599) = true)

theorem identity35599 : scanCanonicalize (H12AffineFastState.compose env35599 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5409) := by decide +kernel

theorem selectedBound35599 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35600 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5409,8460,263,13372,10280,1025,8461,4113,33,17,8463,8193,17,2049,5393,4128,10280,1285,1,257,0,5377,8973]

theorem envBound35600 : H12AffineFastState.Bounded env35600 := by
  intro p hp
  have h : env35600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35599_35600 : H12AffineEnvironment.transform 13 5409 env35599 = env35600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5409 env35599 == env35600) = true)

theorem identity35600 : scanCanonicalize (H12AffineFastState.compose env35600 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 2081) := by decide +kernel

theorem selectedBound35600 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env35601 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2081,8192,3328,8460,263,11293,10280,1025,8461,2096,33,17,8463,8193,17,2049,3376,2049,10280,1285,1,257,0,3360,8973]

theorem envBound35601 : H12AffineFastState.Bounded env35601 := by
  intro p hp
  have h : env35601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35600_35601 : H12AffineEnvironment.transform 11 2081 env35600 = env35601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2081 env35600 == env35601) = true)

theorem identity35601 : scanCanonicalize (H12AffineFastState.compose env35601 (packedSelected [0,2,7,12,14,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35601 : packedSelected [0,2,7,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env35602 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,2048,8192,3328,8460,263,11293,10249,1025,8461,2065,0,17,8463,8193,17,2049,3345,2049,10249,1285,1,257,0,3329,8973]

theorem envBound35602 : H12AffineFastState.Bounded env35602 := by
  intro p hp
  have h : env35602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35601_35602 : H12AffineEnvironment.transform 4 1 env35601 = env35602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35601 == env35602) = true)

theorem identity35602 : scanCanonicalize (H12AffineFastState.compose env35602 (packedSelected [11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound35602 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env35603 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,2048,1053,3328,1297,263,2048,3092,1025,1296,2065,0,17,1298,1052,17,2049,3345,2049,3092,1285,1,257,0,3329,1808]

theorem envBound35603 : H12AffineFastState.Bounded env35603 := by
  intro p hp
  have h : env35603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35602_35603 : H12AffineEnvironment.transform 12 1053 env35602 = env35603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env35602 == env35603) = true)

theorem identity35603 : scanCanonicalize (H12AffineFastState.compose env35603 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1280) := by decide +kernel

theorem selectedBound35603 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env35604 : List Nat := [2,4,8,16,1,17,9,256,512,1024,1280,1280,1053,0,1297,263,1280,276,1025,1296,1297,0,17,1298,1052,17,1281,17,1281,276,1285,1,257,0,1,1808]

theorem envBound35604 : H12AffineFastState.Bounded env35604 := by
  intro p hp
  have h : env35604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35603_35604 : H12AffineEnvironment.transform 10 1280 env35603 = env35604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1280 env35603 == env35604) = true)

theorem identity35604 : scanCanonicalize (H12AffineFastState.compose env35604 (packedSelected [2,11] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound35604 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env35605 : List Nat := [2,4,8,16,1,17,9,256,512,272,16,16,269,0,1,263,16,276,273,0,1,0,17,2,268,17,17,17,17,276,21,1,257,0,1,512]

theorem envBound35605 : H12AffineFastState.Bounded env35605 := by
  intro p hp
  have h : env35605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35604_35605 : H12AffineEnvironment.transform 9 272 env35604 = env35605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env35604 == env35605) = true)

theorem identity35605 : scanCanonicalize (H12AffineFastState.compose env35605 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35605 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35606 : List Nat := [2,4,8,1,1,0,9,256,512,257,1,1,269,0,1,263,1,261,256,0,1,0,0,2,268,0,0,0,0,261,4,1,257,0,1,512]

theorem envBound35606 : H12AffineFastState.Bounded env35606 := by
  intro p hp
  have h : env35606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35605_35606 : H12AffineEnvironment.transform 3 1 env35605 = env35606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35605 == env35606) = true)

theorem identity35606 : scanCanonicalize (H12AffineFastState.compose env35606 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 257) := by decide +kernel

theorem selectedBound35606 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35607 : List Nat := [2,4,8,1,1,0,9,256,257,257,1,1,269,0,1,263,1,261,256,0,1,0,0,2,268,0,0,0,0,261,4,1,257,0,1,257]

theorem envBound35607 : H12AffineFastState.Bounded env35607 := by
  intro p hp
  have h : env35607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35606_35607 : H12AffineEnvironment.transform 8 257 env35606 = env35607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 257 env35606 == env35607) = true)

theorem identity35607 : scanCanonicalize (H12AffineFastState.compose env35607 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound35607 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35608 : List Nat := [2,0,8,1,1,0,9,256,257,257,1,1,265,0,1,259,1,257,256,0,1,0,0,2,264,0,0,0,0,257,0,1,257,0,1,257]

theorem envBound35608 : H12AffineFastState.Bounded env35608 := by
  intro p hp
  have h : env35608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35607_35608 : H12AffineEnvironment.transform 1 0 env35607 = env35608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env35607 == env35608) = true)

theorem identity35608 : scanCanonicalize (H12AffineFastState.compose env35608 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 1) := by decide +kernel

theorem selectedBound35608 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35609 : List Nat := [2,0,8,1,1,0,9,1,0,0,1,1,8,0,1,2,1,0,1,0,1,0,0,2,9,0,0,0,0,0,0,1,0,0,1,0]

theorem envBound35609 : H12AffineFastState.Bounded env35609 := by
  intro p hp
  have h : env35609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35608_35609 : H12AffineEnvironment.transform 7 1 env35608 = env35609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 1 env35608 == env35609) = true)

def env35610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272393,16,98645,8193,64,43357,5392,17665,262145,1365,318548,257,21793,46093,74251]

theorem envBound35610 : H12AffineFastState.Bounded env35610 := by
  intro p hp
  have h : env35610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35594_35610 : H12AffineEnvironment.transform 20 4161 env35594 = env35610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env35594 == env35610) = true)

theorem identity35610 : scanCanonicalize (H12AffineFastState.compose env35610 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 130094) := by decide +kernel

theorem selectedBound35610 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35611 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130094,1025,32769,4161,119847,16,98645,8193,64,43357,5392,17665,130095,1365,73850,257,21793,46093,74251]

theorem envBound35611 : H12AffineFastState.Bounded env35611 := by
  intro p hp
  have h : env35611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35610_35611 : H12AffineEnvironment.transform 17 130094 env35610 = env35611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130094 env35610 == env35611) = true)

theorem identity35611 : scanCanonicalize (H12AffineFastState.compose env35611 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound35611 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env35612 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,65536,46108,100387,1025,32769,4161,106538,16,98645,8193,64,43357,5392,12556,100386,1365,73850,257,8492,46093,74251]

theorem envBound35612 : H12AffineFastState.Bounded env35612 := by
  intro p hp
  have h : env35612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35611_35612 : H12AffineEnvironment.transform 13 13325 env35611 = env35612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env35611 == env35612) = true)

theorem identity35612 : scanCanonicalize (H12AffineFastState.compose env35612 (packedSelected [1,5,8,10,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound35612 : packedSelected [1,5,8,10,24,31] rootPS < 2^1333 := by decide +kernel

def env35613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,8202,46108,43049,1025,32769,4161,32800,16,41311,8193,64,43357,5392,12556,43048,1365,112,257,8492,46093,513]

theorem envBound35613 : H12AffineFastState.Bounded env35613 := by
  intro p hp
  have h : env35613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35612_35613 : H12AffineEnvironment.transform 15 8202 env35612 = env35613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env35612 == env35613) = true)

theorem identity35613 : scanCanonicalize (H12AffineFastState.compose env35613 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound35613 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35614 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,1,8202,13341,10280,1025,0,4161,33,16,8542,8193,64,10588,5392,12556,10281,1365,112,257,8492,13324,513]

theorem envBound35614 : H12AffineFastState.Bounded env35614 := by
  intro p hp
  have h : env35614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35613_35614 : H12AffineEnvironment.transform 14 1 env35613 = env35614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env35613 == env35614) = true)

theorem identity35614 : scanCanonicalize (H12AffineFastState.compose env35614 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 7449) := by decide +kernel

theorem selectedBound35614 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env35615 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7449,2324,1,7443,2308,5425,1025,0,4161,33,16,7239,7448,64,5189,5392,3093,5424,1365,112,257,7221,2325,513]

theorem envBound35615 : H12AffineFastState.Bounded env35615 := by
  intro p hp
  have h : env35615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35614_35615 : H12AffineEnvironment.transform 12 7449 env35614 = env35615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7449 env35614 == env35615) = true)

theorem identity35615 : scanCanonicalize (H12AffineFastState.compose env35615 (packedSelected [1,5,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1323) := by decide +kernel

theorem selectedBound35615 : packedSelected [1,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env35616 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1323,4096,4146,1087,1,4152,1071,5425,1025,0,4161,33,16,4460,4147,64,5189,5392,318,5424,1365,112,257,4382,1086,513]

theorem envBound35616 : H12AffineFastState.Bounded env35616 := by
  intro p hp
  have h : env35616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35615_35616 : H12AffineEnvironment.transform 10 1323 env35615 = env35616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1323 env35615 == env35616) = true)

theorem identity35616 : scanCanonicalize (H12AffineFastState.compose env35616 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(11+1) ^^^ 318) := by decide +kernel

theorem selectedBound35616 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env35617 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1323,318,268,1087,1,262,1071,1039,1025,0,383,33,16,82,269,64,1403,1070,318,1038,1365,112,257,32,1086,513]

theorem envBound35617 : H12AffineFastState.Bounded env35617 := by
  intro p hp
  have h : env35617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35616_35617 : H12AffineEnvironment.transform 11 318 env35616 = env35617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 318 env35616 == env35617) = true)

theorem identity35617 : scanCanonicalize (H12AffineFastState.compose env35617 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35617 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35618 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1323,318,268,1087,1,262,1071,1039,1025,0,303,33,16,2,269,16,1323,1070,318,1038,1285,32,257,32,1086,513]

theorem envBound35618 : H12AffineFastState.Bounded env35618 := by
  intro p hp
  have h : env35618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35617_35618 : H12AffineEnvironment.transform 5 16 env35617 = env35618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35617 == env35618) = true)

theorem identity35618 : scanCanonicalize (H12AffineFastState.compose env35618 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound35618 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35619 : List Nat := [2,4,8,16,32,16,9,63,512,1024,1044,1,51,1087,1,57,1071,1039,1025,0,16,33,16,2,50,16,1044,1070,1,1038,1082,32,62,32,1086,513]

theorem envBound35619 : H12AffineFastState.Bounded env35619 := by
  intro p hp
  have h : env35619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35618_35619 : H12AffineEnvironment.transform 7 63 env35618 = env35619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env35618 == env35619) = true)

theorem identity35619 : scanCanonicalize (H12AffineFastState.compose env35619 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35619 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35620 : List Nat := [2,4,8,16,1,16,9,30,512,1024,1044,1,18,1054,1,24,1038,1039,1025,0,16,0,16,2,19,16,1044,1039,1,1038,1051,1,31,1,1055,513]

theorem envBound35620 : H12AffineFastState.Bounded env35620 := by
  intro p hp
  have h : env35620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35619_35620 : H12AffineEnvironment.transform 4 1 env35619 = env35620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35619 == env35620) = true)

theorem identity35620 : scanCanonicalize (H12AffineFastState.compose env35620 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35620 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35621 : List Nat := [2,4,8,10,1,10,9,4,512,1024,1038,1,8,1028,1,2,1038,1039,1025,0,10,0,10,2,9,10,1038,1039,1,1038,1025,1,5,1,1029,513]

theorem envBound35621 : H12AffineFastState.Bounded env35621 := by
  intro p hp
  have h : env35621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35620_35621 : H12AffineEnvironment.transform 3 10 env35620 = env35621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35620 == env35621) = true)

theorem identity35621 : scanCanonicalize (H12AffineFastState.compose env35621 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35621 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env35622 : List Nat := [2,4,3,1,1,1,2,4,512,1024,1029,1,3,1028,1,2,1029,1028,1025,0,1,0,1,2,2,1,1029,1028,1,1029,1025,1,5,1,1029,513]

theorem envBound35622 : H12AffineFastState.Bounded env35622 := by
  intro p hp
  have h : env35622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35621_35622 : H12AffineEnvironment.transform 2 3 env35621 = env35622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35621 == env35622) = true)

theorem identity35622 : scanCanonicalize (H12AffineFastState.compose env35622 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound35622 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35623 : List Nat := [2,4,3,1,1,1,2,4,512,1,4,1,3,5,1,2,4,5,0,0,1,0,1,2,2,1,4,5,1,4,0,1,5,1,4,513]

theorem envBound35623 : H12AffineFastState.Bounded env35623 := by
  intro p hp
  have h : env35623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35622_35623 : H12AffineEnvironment.transform 9 1 env35622 = env35623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env35622 == env35623) = true)

def env35624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2144660,2098513,17665,2363593,2102685,2411677,257,21793,46212,2175562]

theorem envBound35624 : H12AffineFastState.Bounded env35624 := by
  intro p hp
  have h : env35624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35581_35624 : H12AffineEnvironment.transform 21 272513 env35581 = env35624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35581 == env35624) = true)

theorem identity35624 : scanCanonicalize (H12AffineFastState.compose env35624 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound35624 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4160,272513,17,98780,8328,64,43476,5393,17665,262281,1501,318685,257,21793,46212,74250]

theorem envBound35625 : H12AffineFastState.Bounded env35625 := by
  intro p hp
  have h : env35625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35624_35625 : H12AffineEnvironment.transform 20 4160 env35624 = env35625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env35624 == env35625) = true)

theorem identity35625 : scanCanonicalize (H12AffineFastState.compose env35625 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound35625 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env35626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49304,262144,1025,32769,4160,272513,17,41431,8328,64,43476,5393,17665,262281,1501,318685,257,21793,46212,513]

theorem envBound35626 : H12AffineFastState.Bounded env35626 := by
  intro p hp
  have h : env35626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35625_35626 : H12AffineEnvironment.transform 15 8203 env35625 = env35626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env35625 == env35626) = true)

theorem identity35626 : scanCanonicalize (H12AffineFastState.compose env35626 (packedSelected [3,4,9,10,14,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35626 : packedSelected [3,4,9,10,14,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env35627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,25029,262144,1025,8540,4160,272513,17,138,8328,64,2185,5393,17665,262281,1501,294272,257,21793,5593,513]

theorem envBound35627 : H12AffineFastState.Bounded env35627 := by
  intro p hp
  have h : env35627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35626_35627 : H12AffineEnvironment.transform 14 8541 env35626 = env35627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35626 == env35627) = true)

theorem identity35627 : scanCanonicalize (H12AffineFastState.compose env35627 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35627 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,25029,10280,1025,8540,4160,169,17,138,8328,64,2185,5393,17665,10401,1501,21928,257,21793,5593,513]

theorem envBound35628 : H12AffineFastState.Bounded env35628 := by
  intro p hp
  have h : env35628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35627_35628 : H12AffineEnvironment.transform 17 10280 env35627 = env35628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35627 == env35628) = true)

theorem identity35628 : scanCanonicalize (H12AffineFastState.compose env35628 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound35628 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,8203,13388,10280,1025,8540,4160,169,17,138,8328,64,2185,5393,4232,10401,1501,33,257,168,5593,513]

theorem envBound35629 : H12AffineFastState.Bounded env35629 := by
  intro p hp
  have h : env35629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35628_35629 : H12AffineEnvironment.transform 13 5513 env35628 = env35629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env35628 == env35629) = true)

theorem identity35629 : scanCanonicalize (H12AffineFastState.compose env35629 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35629 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env35630 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5372,8232,8203,13388,10280,1025,8233,4160,169,17,138,8328,64,2185,5220,4232,10401,1192,33,116,168,5292,513]

theorem envBound35630 : H12AffineFastState.Bounded env35630 := by
  intro p hp
  have h : env35630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35629_35630 : H12AffineEnvironment.transform 7 117 env35629 = env35630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35629 == env35630) = true)

theorem identity35630 : scanCanonicalize (H12AffineFastState.compose env35630 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound35630 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35631 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,41,5372,1,34,5221,2049,1025,0,4160,169,17,138,161,64,2185,5220,4232,2184,1192,33,116,168,5292,513]

theorem envBound35631 : H12AffineFastState.Bounded env35631 := by
  intro p hp
  have h : env35631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35630_35631 : H12AffineEnvironment.transform 12 41 env35630 = env35631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env35630 == env35631) = true)

theorem identity35631 : scanCanonicalize (H12AffineFastState.compose env35631 (packedSelected [1,2,3,5,8,14] rootPS)) = affineNative (2^(10+1) ^^^ 216) := by decide +kernel

theorem selectedBound35631 : packedSelected [1,2,3,5,8,14] rootPS < 2^1333 := by decide +kernel

def env35632 : List Nat := [2,4,8,16,32,64,128,117,512,1024,216,4096,41,5372,1,34,5221,217,1025,0,4160,169,17,138,161,64,81,5220,4232,80,1192,33,116,168,5292,513]

theorem envBound35632 : H12AffineFastState.Bounded env35632 := by
  intro p hp
  have h : env35632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35631_35632 : H12AffineEnvironment.transform 10 216 env35631 = env35632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 216 env35631 == env35632) = true)

theorem identity35632 : scanCanonicalize (H12AffineFastState.compose env35632 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35632 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env35633 : List Nat := [2,4,8,16,32,64,9,117,512,1024,81,4096,41,5237,1,34,5221,80,1025,0,4160,32,17,3,40,64,81,5220,4097,80,1057,33,116,33,5157,513]

theorem envBound35633 : H12AffineFastState.Bounded env35633 := by
  intro p hp
  have h : env35633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35632_35633 : H12AffineEnvironment.transform 6 9 env35632 = env35633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35632 == env35633) = true)

theorem identity35633 : scanCanonicalize (H12AffineFastState.compose env35633 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound35633 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35634 : List Nat := [2,4,8,16,32,64,9,117,512,101,81,4096,41,4112,1,34,4096,80,100,0,4160,32,17,3,40,64,81,4097,4097,80,68,33,116,33,4160,513]

theorem envBound35634 : H12AffineFastState.Bounded env35634 := by
  intro p hp
  have h : env35634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35633_35634 : H12AffineEnvironment.transform 9 101 env35633 = env35634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env35633 == env35634) = true)

theorem identity35634 : scanCanonicalize (H12AffineFastState.compose env35634 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound35634 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35635 : List Nat := [2,4,8,16,32,1,9,52,512,36,16,4096,41,4112,1,34,4096,17,37,0,4097,32,17,3,40,1,16,4097,4097,17,5,33,53,33,4097,513]

theorem envBound35635 : H12AffineFastState.Bounded env35635 := by
  intro p hp
  have h : env35635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35634_35635 : H12AffineEnvironment.transform 5 1 env35634 = env35635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env35634 == env35635) = true)

theorem identity35635 : scanCanonicalize (H12AffineFastState.compose env35635 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound35635 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35636 : List Nat := [2,4,8,16,32,1,9,52,512,36,16,0,41,16,1,34,0,17,37,0,1,32,17,3,40,1,16,1,1,17,5,33,53,33,1,513]

theorem envBound35636 : H12AffineFastState.Bounded env35636 := by
  intro p hp
  have h : env35636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35635_35636 : H12AffineEnvironment.transform 11 0 env35635 = env35636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env35635 == env35636) = true)

theorem identity35636 : scanCanonicalize (H12AffineFastState.compose env35636 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound35636 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35637 : List Nat := [2,4,8,16,16,1,9,4,512,20,16,0,25,16,1,18,0,17,21,0,1,16,17,3,24,1,16,1,1,17,5,17,5,17,1,513]

theorem envBound35637 : H12AffineFastState.Bounded env35637 := by
  intro p hp
  have h : env35637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35636_35637 : H12AffineEnvironment.transform 4 16 env35636 = env35637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env35636 == env35637) = true)

theorem identity35637 : scanCanonicalize (H12AffineFastState.compose env35637 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound35637 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35638 : List Nat := [2,4,8,0,0,1,9,4,512,4,0,0,9,0,1,2,0,1,5,0,1,0,1,3,8,1,0,1,1,1,5,1,5,1,1,513]

theorem envBound35638 : H12AffineFastState.Bounded env35638 := by
  intro p hp
  have h : env35638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35637_35638 : H12AffineEnvironment.transform 3 0 env35637 = env35638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35637 == env35638) = true)

def env35639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6590740,2098512,17664,2363593,2102685,6349853,257,21793,46212,2175562]

theorem envBound35639 : H12AffineFastState.Bounded env35639 := by
  intro p hp
  have h : env35639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35580_35639 : H12AffineEnvironment.transform 16 49305 env35580 = env35639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env35580 == env35639) = true)

def env35640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2144660,2098512,17664,2363593,2102685,2411677,257,21793,46212,2175562]

theorem envBound35640 : H12AffineFastState.Bounded env35640 := by
  intro p hp
  have h : env35640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35639_35640 : H12AffineEnvironment.transform 21 272512 env35639 = env35640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35639 == env35640) = true)

theorem identity35640 : scanCanonicalize (H12AffineFastState.compose env35640 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound35640 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13389,262144,1025,29909,2097152,272512,2101328,95497,8328,64,2116928,2098512,17664,2363593,2102685,2373705,257,21793,16464,2175562]

theorem envBound35641 : H12AffineFastState.Bounded env35641 := by
  intro p hp
  have h : env35641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35640_35641 : H12AffineEnvironment.transform 14 29908 env35640 = env35641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env35640 == env35641) = true)

def env35642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21540,65536,5309,262144,1025,21541,2097152,264304,2101328,87545,120,64,2116928,2098512,17664,2363593,2102685,2365625,257,21793,16464,2167482]

theorem envBound35642 : H12AffineFastState.Bounded env35642 := by
  intro p hp
  have h : env35642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35641_35642 : H12AffineEnvironment.transform 12 240 env35641 = env35642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env35641 == env35642) = true)

theorem identity35642 : scanCanonicalize (H12AffineFastState.compose env35642 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound35642 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env35643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21540,65536,5309,2557,1025,21541,2097152,397,2101328,87545,120,64,2116928,2098512,17664,2103604,2102685,2101572,257,21793,16464,2167482]

theorem envBound35643 : H12AffineFastState.Bounded env35643 := by
  intro p hp
  have h : env35643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35642_35643 : H12AffineEnvironment.transform 17 2557 env35642 = env35643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env35642 == env35643) = true)

theorem identity35643 : scanCanonicalize (H12AffineFastState.compose env35643 (packedSelected [3,4,7,9,10,14,17,24,26,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 4589) := by decide +kernel

theorem selectedBound35643 : packedSelected [3,4,7,9,10,14,17,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env35644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,21540,65536,5309,2557,1025,21541,4589,397,445,87545,120,64,23725,5309,17664,2265,1136,169,257,21793,16464,66391]

theorem envBound35644 : H12AffineFastState.Bounded env35644 := by
  intro p hp
  have h : env35644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35643_35644 : H12AffineEnvironment.transform 20 4589 env35643 = env35644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4589 env35643 == env35644) = true)

theorem identity35644 : scanCanonicalize (H12AffineFastState.compose env35644 (packedSelected [2,3,4,6,7,10,11,14,16,18,19,20,22,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound35644 : packedSelected [2,3,4,6,7,10,11,14,16,18,19,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env35645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,5592,508,65536,5309,2557,1025,509,4589,397,445,65569,120,64,2421,5309,4312,2265,1136,169,257,249,5512,66391]

theorem envBound35645 : H12AffineFastState.Bounded env35645 := by
  intro p hp
  have h : env35645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35644_35645 : H12AffineEnvironment.transform 13 5592 env35644 = env35645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env35644 == env35645) = true)

theorem identity35645 : scanCanonicalize (H12AffineFastState.compose env35645 (packedSelected [1,4,8,9,12,14,15,16,17,18,19,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35645 : packedSelected [1,4,8,9,12,14,15,16,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env35646 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,5513,429,65536,5309,2476,1025,428,4540,397,445,65569,41,17,2340,5309,4233,2184,1057,169,257,168,5512,66310]

theorem envBound35646 : H12AffineFastState.Bounded env35646 := by
  intro p hp
  have h : env35646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35645_35646 : H12AffineEnvironment.transform 5 17 env35645 = env35646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35645 == env35646) = true)

theorem identity35646 : scanCanonicalize (H12AffineFastState.compose env35646 (packedSelected [2,3,5,6,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound35646 : packedSelected [2,3,5,6,10,11,15] rootPS < 2^1333 := by decide +kernel

def env35647 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,161,4112,429,65536,4388,2476,408,428,4540,397,445,65569,41,17,2340,4388,4233,2184,440,169,257,168,4113,66310]

theorem envBound35647 : H12AffineFastState.Bounded env35647 := by
  intro p hp
  have h : env35647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35646_35647 : H12AffineEnvironment.transform 9 409 env35646 = env35647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env35646 == env35647) = true)

theorem identity35647 : scanCanonicalize (H12AffineFastState.compose env35647 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound35647 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env35648 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,161,4112,429,171,4388,2476,408,428,4540,397,445,138,41,17,2340,4388,4233,2184,440,169,257,168,4113,941]

theorem envBound35648 : H12AffineFastState.Bounded env35648 := by
  intro p hp
  have h : env35648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35647_35648 : H12AffineEnvironment.transform 15 171 env35647 = env35648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env35647 == env35648) = true)

theorem identity35648 : scanCanonicalize (H12AffineFastState.compose env35648 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35648 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env35649 : List Nat := [2,4,8,16,32,17,128,36,512,189,2048,4096,161,4112,137,171,4096,2184,188,136,4248,169,153,138,41,17,2048,4096,4233,2184,156,169,37,168,4113,649]

theorem envBound35649 : H12AffineFastState.Bounded env35649 := by
  intro p hp
  have h : env35649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35648_35649 : H12AffineEnvironment.transform 7 36 env35648 = env35649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35648 == env35649) = true)

theorem identity35649 : scanCanonicalize (H12AffineFastState.compose env35649 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35649 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env35650 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,40,4112,0,34,4096,2049,53,1,4113,32,16,3,41,17,2048,4096,4096,2049,21,32,37,33,4113,512]

theorem envBound35650 : H12AffineFastState.Bounded env35650 := by
  intro p hp
  have h : env35650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35649_35650 : H12AffineEnvironment.transform 6 9 env35649 = env35650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35649 == env35650) = true)

theorem identity35650 : scanCanonicalize (H12AffineFastState.compose env35650 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2623) := by decide +kernel

theorem selectedBound35650 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35651 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2623,40,2607,0,34,2623,2049,53,1,2606,32,16,3,41,17,2048,2623,2623,2049,21,32,37,33,2606,512]

theorem envBound35651 : H12AffineFastState.Bounded env35651 := by
  intro p hp
  have h : env35651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35650_35651 : H12AffineEnvironment.transform 11 2623 env35650 = env35651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2623 env35650 == env35651) = true)

theorem identity35651 : scanCanonicalize (H12AffineFastState.compose env35651 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35651 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35652 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,2590,9,2574,0,3,2590,2049,20,1,2575,1,16,3,8,17,2048,2590,2590,2049,21,1,4,0,2575,512]

theorem envBound35652 : H12AffineFastState.Bounded env35652 := by
  intro p hp
  have h : env35652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35651_35652 : H12AffineEnvironment.transform 4 1 env35651 = env35652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35651 == env35652) = true)

theorem identity35652 : scanCanonicalize (H12AffineFastState.compose env35652 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound35652 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35653 : List Nat := [2,4,8,16,1,17,9,5,14,21,2048,2064,9,2048,0,3,2064,2049,20,1,2049,1,16,3,8,17,2048,2064,2064,2049,21,1,4,0,2049,14]

theorem envBound35653 : H12AffineFastState.Bounded env35653 := by
  intro p hp
  have h : env35653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35652_35653 : H12AffineEnvironment.transform 8 14 env35652 = env35653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env35652 == env35653) = true)

def env35654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21541,65536,5308,262144,1025,21540,2097152,264305,2101328,87544,121,64,2116928,2098512,17664,2363593,2102685,2365624,257,21793,16464,2167483]

theorem envBound35654 : H12AffineFastState.Bounded env35654 := by
  intro p hp
  have h : env35654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35641_35654 : H12AffineEnvironment.transform 12 241 env35641 = env35654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env35641 == env35654) = true)

theorem identity35654 : scanCanonicalize (H12AffineFastState.compose env35654 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound35654 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env35655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21541,65536,5308,2420,1025,21540,2097152,261,2101328,87544,121,64,2116928,2098512,17664,2103741,2102685,2101708,257,21793,16464,2167483]

theorem envBound35655 : H12AffineFastState.Bounded env35655 := by
  intro p hp
  have h : env35655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35654_35655 : H12AffineEnvironment.transform 17 2420 env35654 = env35655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env35654 == env35655) = true)

theorem identity35655 : scanCanonicalize (H12AffineFastState.compose env35655 (packedSelected [0,1,2,6,7,8,10,11,12,15,16,17,23,26,31] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound35655 : packedSelected [0,1,2,6,7,8,10,11,12,15,16,17,23,26,31] rootPS < 2^1333 := by decide +kernel

def env35656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21541,251,5308,2420,1025,21540,2097152,261,2101328,21763,121,64,2116928,2098512,17664,2103741,2102685,2101708,257,21793,16464,2101824]

theorem envBound35656 : H12AffineFastState.Bounded env35656 := by
  intro p hp
  have h : env35656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35655_35656 : H12AffineEnvironment.transform 15 251 env35655 = env35656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env35655 == env35656) = true)

theorem identity35656 : scanCanonicalize (H12AffineFastState.compose env35656 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 4588) := by decide +kernel

theorem selectedBound35656 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env35657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21541,251,5308,2420,1025,21540,4588,261,444,21763,121,64,23724,5308,17664,2129,1137,32,257,21793,16464,940]

theorem envBound35657 : H12AffineFastState.Bounded env35657 := by
  intro p hp
  have h : env35657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35656_35657 : H12AffineEnvironment.transform 20 4588 env35656 = env35657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4588 env35656 == env35657) = true)

theorem identity35657 : scanCanonicalize (H12AffineFastState.compose env35657 (packedSelected [0,3,5,6,7,10,12,14,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound35657 : packedSelected [0,3,5,6,7,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env35658 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,40,16384,21541,34,5221,2420,1025,21540,4405,261,357,21763,121,64,23669,5221,17664,2129,1137,32,257,21793,16464,885]

theorem envBound35658 : H12AffineFastState.Bounded env35658 := by
  intro p hp
  have h : env35658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35657_35658 : H12AffineEnvironment.transform 6 89 env35657 = env35658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env35657 == env35658) = true)

theorem identity35658 : scanCanonicalize (H12AffineFastState.compose env35658 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound35658 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env35659 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,40,5156,1,34,5221,2420,1025,0,4405,261,357,295,121,64,2129,5221,4388,2129,1137,32,257,261,5236,885]

theorem envBound35659 : H12AffineFastState.Bounded env35659 := by
  intro p hp
  have h : env35659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35658_35659 : H12AffineEnvironment.transform 13 5156 env35658 = env35659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env35658 == env35659) = true)

theorem identity35659 : scanCanonicalize (H12AffineFastState.compose env35659 (packedSelected [0,1,2,4,8,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound35659 : packedSelected [0,1,2,4,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env35660 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2064,40,3124,1,34,3189,2420,1025,0,2341,261,357,295,121,64,2129,3189,2356,2129,1137,32,257,261,3172,885]

theorem envBound35660 : H12AffineFastState.Bounded env35660 := by
  intro p hp
  have h : env35660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35659_35660 : H12AffineEnvironment.transform 11 2064 env35659 = env35660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env35659 == env35660) = true)

theorem identity35660 : scanCanonicalize (H12AffineFastState.compose env35660 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35660 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env35661 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,2064,40,3124,1,34,3189,2128,1025,0,2049,33,65,3,121,64,2129,3189,2064,2129,1137,32,37,33,3172,593]

theorem envBound35661 : H12AffineFastState.Bounded env35661 := by
  intro p hp
  have h : env35661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35660_35661 : H12AffineEnvironment.transform 7 36 env35660 = env35661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35660 == env35661) = true)

theorem identity35661 : scanCanonicalize (H12AffineFastState.compose env35661 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35661 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env35662 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,2064,40,3124,1,34,3109,2048,1025,0,2049,33,17,3,41,16,2049,3109,2064,2049,1057,32,37,33,3124,513]

theorem envBound35662 : H12AffineFastState.Bounded env35662 := by
  intro p hp
  have h : env35662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35661_35662 : H12AffineEnvironment.transform 5 16 env35661 = env35662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35661 == env35662) = true)

theorem identity35662 : scanCanonicalize (H12AffineFastState.compose env35662 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound35662 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35663 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1061,1077,40,17,1,34,0,1061,1025,0,1060,33,17,3,41,16,1060,0,1077,1060,1057,32,37,33,17,513]

theorem envBound35663 : H12AffineFastState.Bounded env35663 := by
  intro p hp
  have h : env35663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35662_35663 : H12AffineEnvironment.transform 10 1061 env35662 = env35663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env35662 == env35663) = true)

theorem identity35663 : scanCanonicalize (H12AffineFastState.compose env35663 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound35663 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35664 : List Nat := [2,4,8,16,32,16,9,36,512,564,529,513,40,17,1,34,0,529,565,0,528,33,17,3,41,16,528,0,513,528,533,32,37,33,17,513]

theorem envBound35664 : H12AffineFastState.Bounded env35664 := by
  intro p hp
  have h : env35664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35663_35664 : H12AffineEnvironment.transform 9 564 env35663 = env35664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env35663 == env35664) = true)

theorem identity35664 : scanCanonicalize (H12AffineFastState.compose env35664 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound35664 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35665 : List Nat := [2,4,8,16,32,16,9,36,17,37,0,16,40,17,1,34,0,0,36,0,1,33,17,3,41,16,1,0,16,1,4,32,37,33,17,16]

theorem envBound35665 : H12AffineFastState.Bounded env35665 := by
  intro p hp
  have h : env35665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35664_35665 : H12AffineEnvironment.transform 8 17 env35664 = env35665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env35664 == env35665) = true)

theorem identity35665 : scanCanonicalize (H12AffineFastState.compose env35665 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound35665 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35666 : List Nat := [2,4,8,0,32,0,9,36,1,37,0,0,40,1,1,34,0,0,36,0,1,33,1,3,41,0,1,0,0,1,4,32,37,33,1,0]

theorem envBound35666 : H12AffineFastState.Bounded env35666 := by
  intro p hp
  have h : env35666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35665_35666 : H12AffineEnvironment.transform 3 0 env35665 = env35666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35665 == env35666) = true)

theorem identity35666 : scanCanonicalize (H12AffineFastState.compose env35666 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35666 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35667 : List Nat := [2,4,8,0,1,0,9,5,1,4,0,0,9,1,1,3,0,0,5,0,1,0,1,3,8,0,1,0,0,1,4,1,4,0,1,0]

theorem envBound35667 : H12AffineFastState.Bounded env35667 := by
  intro p hp
  have h : env35667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35666_35667 : H12AffineEnvironment.transform 4 1 env35666 = env35667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35666 == env35667) = true)

def env35668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2144661,2098512,17664,2363593,2102685,2411676,257,21793,46212,2175562]

theorem envBound35668 : H12AffineFastState.Bounded env35668 := by
  intro p hp
  have h : env35668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35639_35668 : H12AffineEnvironment.transform 21 272513 env35639 = env35668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35639 == env35668) = true)

theorem identity35668 : scanCanonicalize (H12AffineFastState.compose env35668 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound35668 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,58517,272513,62661,98781,8328,64,23808,57797,17664,324700,61704,272393,257,21793,46212,120543]

theorem envBound35669 : H12AffineFastState.Bounded env35669 := by
  intro p hp
  have h : env35669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35668_35669 : H12AffineEnvironment.transform 20 58517 env35668 = env35669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env35668 == env35669) = true)

def env35670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10280,1025,32769,58517,169,62661,98781,8328,64,23808,57797,17664,56436,61704,33,257,21793,46212,120543]

theorem envBound35670 : H12AffineFastState.Bounded env35670 := by
  intro p hp
  have h : env35670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35669_35670 : H12AffineEnvironment.transform 17 10280 env35669 = env35670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35669 == env35670) = true)

theorem identity35670 : scanCanonicalize (H12AffineFastState.compose env35670 (packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound35670 : packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS < 2^1333 := by decide +kernel

def env35671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62731,49305,10280,1025,32769,58517,169,62661,29910,8328,64,23808,57797,17664,56436,61704,33,257,21793,46212,9172]

theorem envBound35671 : H12AffineFastState.Bounded env35671 := by
  intro p hp
  have h : env35671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35670_35671 : H12AffineEnvironment.transform 15 62731 env35670 = env35671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env35670 == env35671) = true)

theorem identity35671 : scanCanonicalize (H12AffineFastState.compose env35671 (packedSelected [3,5,10,16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound35671 : packedSelected [3,5,10,16,17,20] rootPS < 2^1333 := by decide +kernel

def env35672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,33110,46276,10280,1025,32769,37064,169,32920,139,8328,64,10589,38296,12637,43049,34133,33,257,8572,46212,9172]

theorem envBound35672 : H12AffineFastState.Bounded env35672 := by
  intro p hp
  have h : env35672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35671_35672 : H12AffineEnvironment.transform 13 13405 env35671 = env35672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env35671 == env35672) = true)

theorem identity35672 : scanCanonicalize (H12AffineFastState.compose env35672 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound35672 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env35673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,1,343,13509,10280,1025,0,4297,169,153,139,8328,64,10589,5529,12637,10280,1364,33,257,8572,13445,9172]

theorem envBound35673 : H12AffineFastState.Bounded env35673 := by
  intro p hp
  have h : env35673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35672_35673 : H12AffineEnvironment.transform 14 1 env35672 = env35673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env35672 == env35673) = true)

theorem identity35673 : scanCanonicalize (H12AffineFastState.compose env35673 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound35673 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env35674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,1,343,5392,2557,1025,0,4297,169,153,139,349,64,2184,5529,4232,2557,1364,33,257,169,5456,513]

theorem envBound35674 : H12AffineFastState.Bounded env35674 := by
  intro p hp
  have h : env35674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35673_35674 : H12AffineEnvironment.transform 12 469 env35673 = env35674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env35673 == env35674) = true)

theorem identity35674 : scanCanonicalize (H12AffineFastState.compose env35674 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35674 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35675 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5512,1,263,5392,2477,1025,0,4249,169,153,139,269,16,2184,5529,4232,2477,1284,33,257,169,5376,513]

theorem envBound35675 : H12AffineFastState.Bounded env35675 := by
  intro p hp
  have h : env35675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35674_35675 : H12AffineEnvironment.transform 5 16 env35674 = env35675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35674 == env35675) = true)

theorem identity35675 : scanCanonicalize (H12AffineFastState.compose env35675 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1818) := by decide +kernel

theorem selectedBound35675 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env35676 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1818,4096,389,5512,1,263,5392,1719,1025,0,4249,169,153,139,269,16,1938,5529,4232,1719,1284,33,257,169,5376,513]

theorem envBound35676 : H12AffineFastState.Bounded env35676 := by
  intro p hp
  have h : env35676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35675_35676 : H12AffineEnvironment.transform 10 1818 env35675 = env35676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1818 env35675 == env35676) = true)

theorem identity35676 : scanCanonicalize (H12AffineFastState.compose env35676 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35676 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35677 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1818,4096,268,5377,1,263,5392,1598,1025,0,4112,32,16,2,269,16,1819,5392,4097,1598,1284,33,257,32,5376,513]

theorem envBound35677 : H12AffineFastState.Bounded env35677 := by
  intro p hp
  have h : env35677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35676_35677 : H12AffineEnvironment.transform 6 9 env35676 = env35677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35676 == env35677) = true)

theorem identity35677 : scanCanonicalize (H12AffineFastState.compose env35677 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound35677 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35678 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1818,1060,268,293,1,263,308,1598,1025,0,1076,32,16,2,269,16,1819,308,1061,1598,1284,33,257,32,292,513]

theorem envBound35678 : H12AffineFastState.Bounded env35678 := by
  intro p hp
  have h : env35678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35677_35678 : H12AffineEnvironment.transform 11 1060 env35677 = env35678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env35677 == env35678) = true)

theorem identity35678 : scanCanonicalize (H12AffineFastState.compose env35678 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35678 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35679 : List Nat := [2,4,8,16,32,16,9,256,512,273,523,309,268,293,1,263,308,815,272,0,293,32,16,2,269,16,522,308,308,815,21,33,257,32,292,513]

theorem envBound35679 : H12AffineFastState.Bounded env35679 := by
  intro p hp
  have h : env35679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35678_35679 : H12AffineEnvironment.transform 9 273 env35678 = env35679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35678 == env35679) = true)

theorem identity35679 : scanCanonicalize (H12AffineFastState.compose env35679 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound35679 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35680 : List Nat := [2,4,8,16,32,16,9,4,512,21,523,49,8,33,1,3,48,555,20,0,33,32,16,2,9,16,522,48,48,555,21,33,5,32,32,513]

theorem envBound35680 : H12AffineFastState.Bounded env35680 := by
  intro p hp
  have h : env35680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35679_35680 : H12AffineEnvironment.transform 7 4 env35679 = env35680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env35679 == env35680) = true)

theorem identity35680 : scanCanonicalize (H12AffineFastState.compose env35680 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound35680 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35681 : List Nat := [2,4,8,16,32,16,9,4,42,21,33,49,8,33,1,3,48,1,20,0,33,32,16,2,9,16,32,48,48,1,21,33,5,32,32,43]

theorem envBound35681 : H12AffineFastState.Bounded env35681 := by
  intro p hp
  have h : env35681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35680_35681 : H12AffineEnvironment.transform 8 42 env35680 = env35681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env35680 == env35681) = true)

theorem identity35681 : scanCanonicalize (H12AffineFastState.compose env35681 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35681 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35682 : List Nat := [2,4,8,16,0,16,9,4,10,21,1,17,8,1,1,3,16,1,20,0,1,0,16,2,9,16,0,16,16,1,21,1,5,0,0,11]

theorem envBound35682 : H12AffineFastState.Bounded env35682 := by
  intro p hp
  have h : env35682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35681_35682 : H12AffineEnvironment.transform 4 0 env35681 = env35682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35681 == env35682) = true)

theorem identity35682 : scanCanonicalize (H12AffineFastState.compose env35682 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound35682 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35683 : List Nat := [2,1,8,16,0,16,9,1,10,16,1,17,8,1,1,3,16,1,17,0,1,0,16,2,9,16,0,16,16,1,16,1,0,0,0,11]

theorem envBound35683 : H12AffineFastState.Bounded env35683 := by
  intro p hp
  have h : env35683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35682_35683 : H12AffineEnvironment.transform 1 1 env35682 = env35683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env35682 == env35683) = true)

theorem identity35683 : scanCanonicalize (H12AffineFastState.compose env35683 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35683 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35684 : List Nat := [0,1,8,16,0,16,9,1,8,16,1,17,8,1,1,1,16,1,17,0,1,0,16,0,9,16,0,16,16,1,16,1,0,0,0,9]

theorem envBound35684 : H12AffineFastState.Bounded env35684 := by
  intro p hp
  have h : env35684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35683_35684 : H12AffineEnvironment.transform 0 0 env35683 = env35684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35683 == env35684) = true)

def env35685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10281,1025,32769,58517,168,62661,98781,8328,64,23808,57797,17664,56437,61704,32,257,21793,46212,120543]

theorem envBound35685 : H12AffineFastState.Bounded env35685 := by
  intro p hp
  have h : env35685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35669_35685 : H12AffineEnvironment.transform 17 10281 env35669 = env35685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env35669 == env35685) = true)

theorem identity35685 : scanCanonicalize (H12AffineFastState.compose env35685 (packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 29742) := by decide +kernel

theorem selectedBound35685 : packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS < 2^1333 := by decide +kernel

def env35686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29742,49305,10281,1025,32769,58517,168,62661,62963,8328,64,23808,57797,17664,56437,61704,32,257,21793,46212,41713]

theorem envBound35686 : H12AffineFastState.Bounded env35686 := by
  intro p hp
  have h : env35686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35685_35686 : H12AffineEnvironment.transform 15 29742 env35685 = env35686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29742 env35685 == env35686) = true)

theorem identity35686 : scanCanonicalize (H12AffineFastState.compose env35686 (packedSelected [0,1,3,9,12,15,16,18,20,22,23,24,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 4296) := by decide +kernel

theorem selectedBound35686 : packedSelected [0,1,3,9,12,15,16,18,20,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env35687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4296,32768,9446,36945,10281,1025,32769,46173,168,41997,42299,8328,64,3528,45325,5576,36029,41408,32,257,1513,46212,41713]

theorem envBound35687 : H12AffineFastState.Bounded env35687 := by
  intro p hp
  have h : env35687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35686_35687 : H12AffineEnvironment.transform 13 4296 env35686 = env35687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4296 env35686 == env35687) = true)

theorem identity35687 : scanCanonicalize (H12AffineFastState.compose env35687 (packedSelected [0,1,2,3,5,6,8,10,14,17,18,19,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound35687 : packedSelected [0,1,2,3,5,6,8,10,14,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env35688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4296,8352,9446,12529,10281,1025,8353,5373,168,1197,1435,8328,64,3528,4525,5576,11293,352,32,257,1513,5156,593]

theorem envBound35688 : H12AffineFastState.Bounded env35688 := by
  intro p hp
  have h : env35688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35687_35688 : H12AffineEnvironment.transform 14 8352 env35687 = env35688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env35687 == env35688) = true)

theorem identity35688 : scanCanonicalize (H12AffineFastState.compose env35688 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35688 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env35689 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4248,8352,9398,12449,10281,1025,8353,5293,168,1197,1435,8328,16,3480,4525,5528,11293,304,32,257,1465,5156,513]

theorem envBound35689 : H12AffineFastState.Bounded env35689 := by
  intro p hp
  have h : env35689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35688_35689 : H12AffineEnvironment.transform 5 16 env35688 = env35689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35688 == env35689) = true)

theorem identity35689 : scanCanonicalize (H12AffineFastState.compose env35689 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound35689 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env35690 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,40,4248,136,1182,4233,2049,1025,137,5293,168,1197,1435,160,16,3480,4525,5528,3125,304,32,257,1465,5156,513]

theorem envBound35690 : H12AffineFastState.Bounded env35690 := by
  intro p hp
  have h : env35690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35689_35690 : H12AffineEnvironment.transform 12 40 env35689 = env35690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env35689 == env35690) = true)

theorem identity35690 : scanCanonicalize (H12AffineFastState.compose env35690 (packedSelected [0,1,3,5,6,7,8,10,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound35690 : packedSelected [0,1,3,5,6,7,8,10,11,14] rootPS < 2^1333 := by decide +kernel

def env35691 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3076,40,3228,136,1182,3213,2049,1025,137,2217,168,1197,1435,160,16,3480,3497,2460,3125,304,32,257,1465,2080,513]

theorem envBound35691 : H12AffineFastState.Bounded env35691 := by
  intro p hp
  have h : env35691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35690_35691 : H12AffineEnvironment.transform 11 3076 env35690 = env35691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env35690 == env35691) = true)

theorem identity35691 : scanCanonicalize (H12AffineFastState.compose env35691 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35691 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35692 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3076,40,3093,1,1047,3076,2049,1025,0,2080,33,1060,1298,41,16,3345,3360,2325,3125,304,32,257,1328,2080,513]

theorem envBound35692 : H12AffineFastState.Bounded env35692 := by
  intro p hp
  have h : env35692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35691_35692 : H12AffineEnvironment.transform 6 9 env35691 = env35692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35691 == env35692) = true)

theorem identity35692 : scanCanonicalize (H12AffineFastState.compose env35692 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound35692 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env35693 : List Nat := [2,4,8,16,32,16,9,256,512,1024,293,1313,40,1328,1,1047,1313,292,1025,0,261,33,1060,1298,41,16,1076,1029,48,1296,304,32,257,1328,261,513]

theorem envBound35693 : H12AffineFastState.Bounded env35693 := by
  intro p hp
  have h : env35693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35692_35693 : H12AffineEnvironment.transform 10 293 env35692 = env35693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env35692 == env35693) = true)

theorem identity35693 : scanCanonicalize (H12AffineFastState.compose env35693 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound35693 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env35694 : List Nat := [2,4,8,16,32,16,9,5,512,1024,32,1060,40,1077,1,1047,1060,33,1025,0,0,33,1060,1047,41,16,1076,1029,48,1045,53,32,4,1077,0,513]

theorem envBound35694 : H12AffineFastState.Bounded env35694 := by
  intro p hp
  have h : env35694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35693_35694 : H12AffineEnvironment.transform 7 5 env35693 = env35694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env35693 == env35694) = true)

theorem identity35694 : scanCanonicalize (H12AffineFastState.compose env35694 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35694 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env35695 : List Nat := [2,4,8,16,0,16,9,5,512,1024,0,1028,8,1045,1,1047,1028,1,1025,0,0,1,1028,1047,9,16,1044,1029,16,1045,21,0,4,1045,0,513]

theorem envBound35695 : H12AffineFastState.Bounded env35695 := by
  intro p hp
  have h : env35695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35694_35695 : H12AffineEnvironment.transform 4 0 env35694 = env35695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35694 == env35695) = true)

theorem identity35695 : scanCanonicalize (H12AffineFastState.compose env35695 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound35695 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env35696 : List Nat := [2,4,8,16,0,16,9,5,512,21,0,17,8,0,1,2,17,1,20,0,0,1,17,2,9,16,1,16,16,0,21,0,4,0,0,513]

theorem envBound35696 : H12AffineFastState.Bounded env35696 := by
  intro p hp
  have h : env35696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35695_35696 : H12AffineEnvironment.transform 9 21 env35695 = env35696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env35695 == env35696) = true)

theorem identity35696 : scanCanonicalize (H12AffineFastState.compose env35696 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound35696 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35697 : List Nat := [2,4,8,16,0,16,9,5,1,21,0,17,8,0,1,2,17,1,20,0,0,1,17,2,9,16,1,16,16,0,21,0,4,0,0,0]

theorem envBound35697 : H12AffineFastState.Bounded env35697 := by
  intro p hp
  have h : env35697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35696_35697 : H12AffineEnvironment.transform 8 1 env35696 = env35697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env35696 == env35697) = true)

theorem identity35697 : scanCanonicalize (H12AffineFastState.compose env35697 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound35697 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35698 : List Nat := [2,4,8,0,0,0,9,5,1,5,0,1,8,0,1,2,1,1,4,0,0,1,1,2,9,0,1,0,0,0,5,0,4,0,0,0]

theorem envBound35698 : H12AffineFastState.Bounded env35698 := by
  intro p hp
  have h : env35698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35697_35698 : H12AffineEnvironment.transform 3 0 env35697 = env35698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35697 == env35698) = true)

def env35699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254784,25265169,145662401,525568,140903596,27337993,25733062]

theorem envBound35699 : H12AffineFastState.Bounded env35699 := by
  intro p hp
  have h : env35699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34974_35699 : H12AffineEnvironment.transform 25 65 env34974 = env35699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env34974 == env35699) = true)

def env35700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356288,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound35700 : H12AffineFastState.Bounded env35700 := by
  intro p hp
  have h : env35700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35699_35700 : H12AffineEnvironment.transform 26 30393344 env35699 = env35700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env35699 == env35700) = true)

def env35701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound35701 : H12AffineFastState.Bounded env35701 := by
  intro p hp
  have h : env35701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35700_35701 : H12AffineEnvironment.transform 18 1024 env35700 = env35701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env35700 == env35701) = true)

theorem identity35701 : scanCanonicalize (H12AffineFastState.compose env35701 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 396324) := by decide +kernel

theorem selectedBound35701 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env35702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,4194304,8388608,16777216,8328,65,29868032,17270952,8804725,8830976,25265169,21457381,256,25675912,25635117,25207750]

theorem envBound35702 : H12AffineFastState.Bounded env35702 := by
  intro p hp
  have h : env35702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35701_35702 : H12AffineEnvironment.transform 20 396324 env35701 = env35702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 396324 env35701 == env35702) = true)

def env35703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,4194304,8388608,8887720,8328,65,4218280,8393984,8804725,8830976,399801,12645453,256,21792,46213,474734]

theorem envBound35703 : H12AffineFastState.Bounded env35703 := by
  intro p hp
  have h : env35703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35702_35703 : H12AffineEnvironment.transform 23 8887720 env35702 = env35703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887720 env35702 == env35703) = true)

def env35704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,4194304,452768,95496,8328,65,4218280,458144,45525,10400,399801,4594925,256,21792,46213,474734]

theorem envBound35704 : H12AffineFastState.Bounded env35704 := by
  intro p hp
  have h : env35704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35703_35704 : H12AffineEnvironment.transform 22 452768 env35703 = env35704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env35703 == env35704) = true)

def env35705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272512,452768,95496,8328,65,292136,458144,45525,10400,399801,144493,256,21792,46213,474734]

theorem envBound35705 : H12AffineFastState.Bounded env35705 := by
  intro p hp
  have h : env35705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35704_35705 : H12AffineEnvironment.transform 21 272512 env35704 = env35705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35704 == env35705) = true)

def env35706 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272392,452648,95496,8192,65,292136,458024,45405,10280,399665,144493,256,21792,46093,474734]

theorem envBound35706 : H12AffineFastState.Bounded env35706 := by
  intro p hp
  have h : env35706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35705_35706 : H12AffineEnvironment.transform 6 8 env35705 = env35706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35705 == env35706) = true)

def env35707 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314420,272392,272440,95496,8192,65,292136,277816,45405,10280,317729,62589,256,21792,46093,392830]

theorem envBound35707 : H12AffineFastState.Bounded env35707 := by
  intro p hp
  have h : env35707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35706_35707 : H12AffineEnvironment.transform 16 49168 env35706 = env35707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env35706 == env35707) = true)

theorem identity35707 : scanCanonicalize (H12AffineFastState.compose env35707 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound35707 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1024,32769,17729,41341,41293,95496,8192,65,64605,46157,45405,10280,20564,62589,256,21792,46093,96011]

theorem envBound35708 : H12AffineFastState.Bounded env35708 := by
  intro p hp
  have h : env35708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35707_35708 : H12AffineEnvironment.transform 17 35189 env35707 = env35708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env35707 == env35708) = true)

theorem identity35708 : scanCanonicalize (H12AffineFastState.compose env35708 (packedSelected [0,1,3,4,8,10,12,14,15,16,22,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 41263) := by decide +kernel

theorem selectedBound35708 : packedSelected [0,1,3,4,8,10,12,14,15,16,22,24,27] rootPS < 2^1333 := by decide +kernel

def env35709 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,41263,49168,35189,1024,32769,17729,41341,41293,54311,8192,65,64605,46157,45405,10280,20564,62589,256,21792,46093,54820]

theorem envBound35709 : H12AffineFastState.Bounded env35709 := by
  intro p hp
  have h : env35709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35708_35709 : H12AffineEnvironment.transform 15 41263 env35708 = env35709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41263 env35708 == env35709) = true)

theorem identity35709 : scanCanonicalize (H12AffineFastState.compose env35709 (packedSelected [8,10,12,15,16,20,28] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound35709 : packedSelected [8,10,12,15,16,20,28] rootPS < 2^1333 := by decide +kernel

def env35710 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,35,24860,10361,1024,8461,17729,113,65,29995,8192,65,23889,5441,4177,10280,20564,21873,256,21792,5377,30504]

theorem envBound35710 : H12AffineFastState.Bounded env35710 := by
  intro p hp
  have h : env35710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35709_35710 : H12AffineEnvironment.transform 14 8460 env35709 = env35710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env35709 == env35710) = true)

theorem identity35710 : scanCanonicalize (H12AffineFastState.compose env35710 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound35710 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env35711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,293,35,16693,2128,1024,292,17729,113,65,21762,41,65,23889,5441,4177,2049,20564,21873,256,21792,5377,22273]

theorem envBound35711 : H12AffineFastState.Bounded env35711 := by
  intro p hp
  have h : env35711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35710_35711 : H12AffineEnvironment.transform 12 41 env35710 = env35711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env35710 == env35711) = true)

theorem identity35711 : scanCanonicalize (H12AffineFastState.compose env35711 (packedSelected [2,3,5,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35711 : packedSelected [2,3,5,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env35712 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,16384,293,35,16693,2048,1024,292,17681,33,17,21762,41,17,23809,5393,4097,2049,20484,21793,256,21792,5377,22273]

theorem envBound35712 : H12AffineFastState.Bounded env35712 := by
  intro p hp
  have h : env35712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35711_35712 : H12AffineEnvironment.transform 5 16 env35711 = env35712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35711 == env35712) = true)

theorem identity35712 : scanCanonicalize (H12AffineFastState.compose env35712 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound35712 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env35713 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,41,16384,293,35,16693,2048,272,292,16385,33,17,20498,41,17,22545,4097,4097,2049,20484,20529,256,20528,4113,21009]

theorem envBound35713 : H12AffineFastState.Bounded env35713 := by
  intro p hp
  have h : env35713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35712_35713 : H12AffineEnvironment.transform 9 272 env35712 = env35713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env35712 == env35713) = true)

theorem identity35713 : scanCanonicalize (H12AffineFastState.compose env35713 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound35713 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env35714 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,41,2048,293,35,2357,2048,272,292,2049,33,17,6162,41,17,4113,4097,4097,2049,6148,6193,256,6192,4113,6673]

theorem envBound35714 : H12AffineFastState.Bounded env35714 := by
  intro p hp
  have h : env35714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35713_35714 : H12AffineEnvironment.transform 13 2048 env35713 = env35714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env35713 == env35714) = true)

def env35715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314421,272392,272441,95496,8192,65,292136,277817,45405,10280,317728,62588,256,21792,46093,392831]

theorem envBound35715 : H12AffineFastState.Bounded env35715 := by
  intro p hp
  have h : env35715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35706_35715 : H12AffineEnvironment.transform 16 49169 env35706 = env35715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35706 == env35715) = true)

theorem identity35715 : scanCanonicalize (H12AffineFastState.compose env35715 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound35715 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24909,262144,1024,8541,290153,272392,272441,95496,8192,65,292136,277817,4097,10280,292988,21792,256,21792,5457,352035]

theorem envBound35716 : H12AffineFastState.Bounded env35716 := by
  intro p hp
  have h : env35716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35715_35716 : H12AffineEnvironment.transform 14 8540 env35715 = env35716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env35715 == env35716) = true)

theorem identity35716 : scanCanonicalize (H12AffineFastState.compose env35716 (packedSelected [1,3,4,8,9,10,12,14,15,16,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound35716 : packedSelected [1,3,4,8,9,10,12,14,15,16,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env35717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8574,24909,262144,1024,8541,290153,272392,272441,21622,8192,65,292136,277817,4097,10280,292988,21792,256,21792,5457,294493]

theorem envBound35717 : H12AffineFastState.Bounded env35717 := by
  intro p hp
  have h : env35717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35716_35717 : H12AffineEnvironment.transform 15 8574 env35716 = env35717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env35716 == env35717) = true)

theorem identity35717 : scanCanonicalize (H12AffineFastState.compose env35717 (packedSelected [0,3,4,5,7,10,12,15,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 10588) := by decide +kernel

theorem selectedBound35717 : packedSelected [0,3,4,5,7,10,12,15,18,22,23] rootPS < 2^1333 := by decide +kernel

def env35718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8574,24909,10588,1024,8541,17461,340,357,21622,8192,65,23668,5221,4097,10280,20768,21792,256,21792,5457,22273]

theorem envBound35718 : H12AffineFastState.Bounded env35718 := by
  intro p hp
  have h : env35718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35717_35718 : H12AffineEnvironment.transform 17 10588 env35717 = env35718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10588 env35717 == env35718) = true)

theorem identity35718 : scanCanonicalize (H12AffineFastState.compose env35718 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound35718 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env35719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,373,343,16740,2421,1024,372,17461,340,357,21622,41,65,23668,5221,4097,2049,20768,21792,256,21792,5457,22273]

theorem envBound35719 : H12AffineFastState.Bounded env35719 := by
  intro p hp
  have h : env35719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35718_35719 : H12AffineEnvironment.transform 12 41 env35718 = env35719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env35718 == env35719) = true)

theorem identity35719 : scanCanonicalize (H12AffineFastState.compose env35719 (packedSelected [1,2,6,8,10,12,14,15,16,18] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound35719 : packedSelected [1,2,6,8,10,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env35720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,64,41,16384,373,343,16740,2421,1024,372,17461,340,357,17462,41,65,19508,1061,65,2049,16736,17760,256,17760,1297,18241]

theorem envBound35720 : H12AffineFastState.Bounded env35720 := by
  intro p hp
  have h : env35720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35719_35720 : H12AffineEnvironment.transform 11 64 env35719 = env35720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env35719 == env35720) = true)

theorem identity35720 : scanCanonicalize (H12AffineFastState.compose env35720 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound35720 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env35721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,64,41,1344,373,343,1060,2421,1024,372,373,340,357,374,41,65,2420,1061,65,2049,1056,32,256,32,1297,513]

theorem envBound35721 : H12AffineFastState.Bounded env35721 := by
  intro p hp
  have h : env35721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35720_35721 : H12AffineEnvironment.transform 13 1344 env35720 = env35721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env35720 == env35721) = true)

theorem identity35721 : scanCanonicalize (H12AffineFastState.compose env35721 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound35721 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35722 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,64,41,1076,1,35,1060,2049,1024,0,1,32,17,2,41,65,2048,1061,65,2049,1056,32,116,32,1125,513]

theorem envBound35722 : H12AffineFastState.Bounded env35722 := by
  intro p hp
  have h : env35722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35721_35722 : H12AffineEnvironment.transform 7 116 env35721 = env35722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env35721 == env35722) = true)

theorem identity35722 : scanCanonicalize (H12AffineFastState.compose env35722 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound35722 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35723 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,64,41,80,1,35,64,2049,100,0,1,32,17,2,41,65,2048,65,65,2049,68,32,116,32,1,513]

theorem envBound35723 : H12AffineFastState.Bounded env35723 := by
  intro p hp
  have h : env35723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35722_35723 : H12AffineEnvironment.transform 9 100 env35722 = env35723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env35722 == env35723) = true)

theorem identity35723 : scanCanonicalize (H12AffineFastState.compose env35723 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound35723 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35724 : List Nat := [2,4,8,16,32,64,8,116,0,100,2048,64,41,80,1,35,64,2049,100,0,1,32,17,2,41,65,2048,65,65,2049,68,32,116,32,1,1]

theorem envBound35724 : H12AffineFastState.Bounded env35724 := by
  intro p hp
  have h : env35724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35723_35724 : H12AffineEnvironment.transform 8 0 env35723 = env35724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env35723 == env35724) = true)

theorem identity35724 : scanCanonicalize (H12AffineFastState.compose env35724 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35724 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35725 : List Nat := [2,4,8,16,32,17,8,37,0,53,2048,17,41,1,1,35,17,2049,53,0,1,32,17,2,41,16,2048,16,16,2049,21,32,37,32,1,1]

theorem envBound35725 : H12AffineFastState.Bounded env35725 := by
  intro p hp
  have h : env35725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35724_35725 : H12AffineEnvironment.transform 5 17 env35724 = env35725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35724 == env35725) = true)

theorem identity35725 : scanCanonicalize (H12AffineFastState.compose env35725 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound35725 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35726 : List Nat := [2,4,8,16,10,17,8,15,0,31,2048,17,3,1,1,9,17,2049,31,0,1,10,17,2,3,16,2048,16,16,2049,21,10,15,10,1,1]

theorem envBound35726 : H12AffineFastState.Bounded env35726 := by
  intro p hp
  have h : env35726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35725_35726 : H12AffineEnvironment.transform 4 10 env35725 = env35726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env35725 == env35726) = true)

def env35727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272393,452649,95496,8193,65,292136,458025,45404,10281,399664,144493,256,21792,46092,474734]

theorem envBound35727 : H12AffineFastState.Bounded env35727 := by
  intro p hp
  have h : env35727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35705_35727 : H12AffineEnvironment.transform 6 9 env35705 = env35727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35705 == env35727) = true)

def env35728 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314420,272393,272441,95496,8193,65,292136,277817,45404,10281,317728,62589,256,21792,46092,392830]

theorem envBound35728 : H12AffineFastState.Bounded env35728 := by
  intro p hp
  have h : env35728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35727_35728 : H12AffineEnvironment.transform 16 49168 env35727 = env35728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env35727 == env35728) = true)

theorem identity35728 : scanCanonicalize (H12AffineFastState.compose env35728 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35728 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35729 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,58396,33,17,95496,8193,65,23808,5393,45404,10281,61704,62589,256,21792,46092,120406]

theorem envBound35729 : H12AffineFastState.Bounded env35729 := by
  intro p hp
  have h : env35729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35728_35729 : H12AffineEnvironment.transform 17 10280 env35728 = env35729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35728 == env35729) = true)

theorem identity35729 : scanCanonicalize (H12AffineFastState.compose env35729 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35729 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env35730 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,58396,33,17,95496,8193,16,23808,5393,45325,10281,61704,62508,256,21792,46092,120327]

theorem envBound35730 : H12AffineFastState.Bounded env35730 := by
  intro p hp
  have h : env35730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35729_35730 : H12AffineEnvironment.transform 5 17 env35729 = env35730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35729 == env35730) = true)

theorem identity35730 : scanCanonicalize (H12AffineFastState.compose env35730 (packedSelected [2,4,6,11,16,18,22] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound35730 : packedSelected [2,4,6,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env35731 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,62731,49168,10280,1024,32769,58396,33,17,32771,8193,16,23808,5393,45325,10281,61704,62508,256,21792,46092,8972]

theorem envBound35731 : H12AffineFastState.Bounded env35731 := by
  intro p hp
  have h : env35731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35730_35731 : H12AffineEnvironment.transform 15 62731 env35730 = env35731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env35730 == env35731) = true)

theorem identity35731 : scanCanonicalize (H12AffineFastState.compose env35731 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound35731 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env35732 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21760,8203,5392,10280,1024,21761,12572,33,17,21763,8193,16,23808,5393,25613,10281,9224,8492,256,21792,24844,8972]

theorem envBound35732 : H12AffineFastState.Bounded env35732 := by
  intro p hp
  have h : env35732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35731_35732 : H12AffineEnvironment.transform 14 21760 env35731 = env35732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env35731 == env35732) = true)

theorem identity35732 : scanCanonicalize (H12AffineFastState.compose env35732 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound35732 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env35733 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,8461,8203,5392,10280,1024,8460,12572,33,17,8462,8193,16,10509,5393,4096,10281,9224,8492,256,8493,5377,8972]

theorem envBound35733 : H12AffineFastState.Bounded env35733 := by
  intro p hp
  have h : env35733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35732_35733 : H12AffineEnvironment.transform 13 13325 env35732 = env35733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env35732 == env35733) = true)

theorem identity35733 : scanCanonicalize (H12AffineFastState.compose env35733 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 3387) := by decide +kernel

theorem selectedBound35733 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env35734 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3387,8192,10550,8461,8203,2091,10280,1024,8460,11303,33,17,8462,8193,16,10509,2090,3387,10281,9224,8492,256,8493,2106,8972]

theorem envBound35734 : H12AffineFastState.Bounded env35734 := by
  intro p hp
  have h : env35734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35733_35734 : H12AffineEnvironment.transform 11 3387 env35733 = env35734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3387 env35733 == env35734) = true)

theorem identity35734 : scanCanonicalize (H12AffineFastState.compose env35734 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 1842) := by decide +kernel

theorem selectedBound35734 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env35735 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3387,1842,3588,1599,1849,2091,3866,1024,1598,2837,33,17,1596,1843,16,3647,2090,3387,3867,826,1566,256,1567,2106,1086]

theorem envBound35735 : H12AffineFastState.Bounded env35735 := by
  intro p hp
  have h : env35735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35734_35735 : H12AffineEnvironment.transform 12 1842 env35734 = env35735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1842 env35734 == env35735) = true)

theorem identity35735 : scanCanonicalize (H12AffineFastState.compose env35735 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35735 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env35736 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,3354,1811,3588,1566,1816,2058,3866,1024,1567,2837,0,17,1565,1810,16,3614,2059,3354,3867,795,1566,256,1567,2075,1055]

theorem envBound35736 : H12AffineFastState.Bounded env35736 := by
  intro p hp
  have h : env35736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35735_35736 : H12AffineEnvironment.transform 4 1 env35735 = env35736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35735 == env35736) = true)

theorem identity35736 : scanCanonicalize (H12AffineFastState.compose env35736 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound35736 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env35737 : List Nat := [2,4,8,16,1,17,9,256,512,542,2048,2820,269,2074,0,262,2058,2308,542,1,2837,0,17,3,268,16,2048,2059,2820,2309,795,0,256,1,2075,513]

theorem envBound35737 : H12AffineFastState.Bounded env35737 := by
  intro p hp
  have h : env35737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35736_35737 : H12AffineEnvironment.transform 9 542 env35736 = env35737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env35736 == env35737) = true)

theorem identity35737 : scanCanonicalize (H12AffineFastState.compose env35737 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound35737 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35738 : List Nat := [2,4,8,16,1,17,9,256,512,542,528,276,269,522,0,262,538,788,542,1,261,0,17,3,268,16,528,539,276,789,795,0,256,1,523,513]

theorem envBound35738 : H12AffineFastState.Bounded env35738 := by
  intro p hp
  have h : env35738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35737_35738 : H12AffineEnvironment.transform 10 528 env35737 = env35738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env35737 == env35738) = true)

theorem identity35738 : scanCanonicalize (H12AffineFastState.compose env35738 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound35738 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35739 : List Nat := [2,4,8,16,1,17,9,30,512,542,528,10,19,522,0,24,538,522,542,1,27,0,17,3,18,16,528,539,10,523,517,0,30,1,523,513]

theorem envBound35739 : H12AffineFastState.Bounded env35739 := by
  intro p hp
  have h : env35739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35738_35739 : H12AffineEnvironment.transform 7 30 env35738 = env35739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env35738 == env35739) = true)

theorem identity35739 : scanCanonicalize (H12AffineFastState.compose env35739 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound35739 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35740 : List Nat := [2,4,8,16,1,17,9,30,27,5,11,10,19,17,0,24,1,17,5,1,27,0,17,3,18,16,11,0,10,16,30,0,30,1,16,26]

theorem envBound35740 : H12AffineFastState.Bounded env35740 := by
  intro p hp
  have h : env35740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35739_35740 : H12AffineEnvironment.transform 8 27 env35739 = env35740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env35739 == env35740) = true)

theorem identity35740 : scanCanonicalize (H12AffineFastState.compose env35740 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound35740 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35741 : List Nat := [2,4,8,3,1,2,9,13,8,5,11,10,0,2,0,11,1,2,5,1,8,0,2,3,1,3,11,0,10,3,13,0,13,1,3,9]

theorem envBound35741 : H12AffineFastState.Bounded env35741 := by
  intro p hp
  have h : env35741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35740_35741 : H12AffineEnvironment.transform 3 3 env35740 = env35741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env35740 == env35741) = true)

theorem identity35741 : scanCanonicalize (H12AffineFastState.compose env35741 (packedSelected [0,7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35741 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35742 : List Nat := [0,4,8,1,1,0,9,13,8,5,9,8,0,0,0,9,1,0,5,1,8,0,0,1,1,1,9,0,8,1,13,0,13,1,1,9]

theorem envBound35742 : H12AffineFastState.Bounded env35742 := by
  intro p hp
  have h : env35742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35741_35742 : H12AffineEnvironment.transform 0 0 env35741 = env35742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35741 == env35742) = true)

theorem identity35742 : scanCanonicalize (H12AffineFastState.compose env35742 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound35742 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35743 : List Nat := [0,4,4,1,1,0,5,1,4,5,5,4,0,0,0,5,1,0,5,1,4,0,0,1,1,1,5,0,4,1,1,0,1,1,1,5]

theorem envBound35743 : H12AffineFastState.Bounded env35743 := by
  intro p hp
  have h : env35743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35742_35743 : H12AffineEnvironment.transform 2 4 env35742 = env35743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35742 == env35743) = true)

def env35744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314421,272393,272440,95496,8193,65,292136,277816,45404,10281,317729,62588,256,21792,46092,392831]

theorem envBound35744 : H12AffineFastState.Bounded env35744 := by
  intro p hp
  have h : env35744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35727_35744 : H12AffineEnvironment.transform 16 49169 env35727 = env35744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35727 == env35744) = true)

theorem identity35744 : scanCanonicalize (H12AffineFastState.compose env35744 (packedSelected [3,5,7,12,14,15,18,20,23,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound35744 : packedSelected [3,5,7,12,14,15,18,20,23,27,31] rootPS < 2^1333 := by decide +kernel

def env35745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10360,1024,32769,58445,113,64,95496,8193,65,23888,5440,45404,10281,61785,62588,256,21792,46092,120327]

theorem envBound35745 : H12AffineFastState.Bounded env35745 := by
  intro p hp
  have h : env35745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35744_35745 : H12AffineEnvironment.transform 17 10360 env35744 = env35745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env35744 == env35745) = true)

theorem identity35745 : scanCanonicalize (H12AffineFastState.compose env35745 (packedSelected [0,1,4,5,7,8,11,16,19,20,22,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound35745 : packedSelected [0,1,4,5,7,8,11,16,19,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env35746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,49169,10360,1024,32769,58445,113,64,8542,8193,65,23888,5440,45404,10281,61785,62588,256,21792,46092,33361]

theorem envBound35746 : H12AffineFastState.Bounded env35746 := by
  intro p hp
  have h : env35746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35745_35746 : H12AffineEnvironment.transform 15 21590 env35745 = env35746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env35745 == env35746) = true)

theorem identity35746 : scanCanonicalize (H12AffineFastState.compose env35746 (packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound35746 : packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env35747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,21590,16401,10360,1024,1,25677,113,64,8542,8193,65,23888,5440,12636,10281,29017,29820,256,21792,13324,593]

theorem envBound35747 : H12AffineFastState.Bounded env35747 := by
  intro p hp
  have h : env35747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35746_35747 : H12AffineEnvironment.transform 14 0 env35746 = env35747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env35746 == env35747) = true)

theorem identity35747 : scanCanonicalize (H12AffineFastState.compose env35747 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35747 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env35748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,21590,16401,2341,1024,1,17680,113,64,3,348,65,23888,5440,4097,2420,20484,21793,256,21792,5457,593]

theorem envBound35748 : H12AffineFastState.Bounded env35748 := by
  intro p hp
  have h : env35748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35747_35748 : H12AffineEnvironment.transform 12 349 env35747 = env35748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35747 == env35748) = true)

theorem identity35748 : scanCanonicalize (H12AffineFastState.compose env35748 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35748 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env35749 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,16384,0,21590,16401,2049,1024,1,17460,113,64,3,120,65,23668,5220,4097,2128,20484,21509,36,21508,5237,593]

theorem envBound35749 : H12AffineFastState.Bounded env35749 := by
  intro p hp
  have h : env35749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35748_35749 : H12AffineEnvironment.transform 7 36 env35748 = env35749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35748 == env35749) = true)

theorem identity35749 : scanCanonicalize (H12AffineFastState.compose env35749 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound35749 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env35750 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,5157,0,115,5172,2049,1024,1,4113,113,64,3,120,65,2129,5220,4097,2128,1057,32,36,33,5237,593]

theorem envBound35750 : H12AffineFastState.Bounded env35750 := by
  intro p hp
  have h : env35750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35749_35750 : H12AffineEnvironment.transform 13 5157 env35749 = env35750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env35749 == env35750) = true)

theorem identity35750 : scanCanonicalize (H12AffineFastState.compose env35750 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound35750 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35751 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3077,121,2080,0,115,2097,2049,1024,1,3092,113,64,3,120,65,2129,2145,3076,2128,1057,32,36,33,2160,593]

theorem envBound35751 : H12AffineFastState.Bounded env35751 := by
  intro p hp
  have h : env35751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35750_35751 : H12AffineEnvironment.transform 11 3077 env35750 = env35751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env35750 == env35751) = true)

theorem identity35751 : scanCanonicalize (H12AffineFastState.compose env35751 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35751 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env35752 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3077,40,2080,0,34,2097,2049,1024,1,3092,32,17,3,41,16,2048,2096,3076,2049,1057,32,36,33,2081,512]

theorem envBound35752 : H12AffineFastState.Bounded env35752 := by
  intro p hp
  have h : env35752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35751_35752 : H12AffineEnvironment.transform 5 17 env35751 = env35752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35751 == env35752) = true)

theorem identity35752 : scanCanonicalize (H12AffineFastState.compose env35752 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35752 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35753 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,3077,9,2049,0,3,2064,2049,1024,1,3092,1,17,3,8,16,2048,2065,3076,2049,1024,1,5,0,2048,512]

theorem envBound35753 : H12AffineFastState.Bounded env35753 := by
  intro p hp
  have h : env35753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35752_35753 : H12AffineEnvironment.transform 4 1 env35752 = env35753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35752 == env35753) = true)

theorem identity35753 : scanCanonicalize (H12AffineFastState.compose env35753 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound35753 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35754 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,2065,9,2049,0,3,2064,2049,20,1,2048,1,17,3,8,16,2048,2065,2064,2049,20,1,5,0,2048,512]

theorem envBound35754 : H12AffineFastState.Bounded env35754 := by
  intro p hp
  have h : env35754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35753_35754 : H12AffineEnvironment.transform 9 20 env35753 = env35754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env35753 == env35754) = true)

theorem identity35754 : scanCanonicalize (H12AffineFastState.compose env35754 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound35754 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35755 : List Nat := [2,4,8,16,1,17,9,5,512,20,5,20,9,4,0,3,21,4,20,1,5,1,17,3,8,16,5,20,21,4,20,1,5,0,5,512]

theorem envBound35755 : H12AffineFastState.Bounded env35755 := by
  intro p hp
  have h : env35755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35754_35755 : H12AffineEnvironment.transform 10 5 env35754 = env35755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env35754 == env35755) = true)

def env35756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272513,452768,95496,8328,65,292137,458144,45525,10400,399801,144492,256,21792,46213,474734]

theorem envBound35756 : H12AffineFastState.Bounded env35756 := by
  intro p hp
  have h : env35756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35704_35756 : H12AffineEnvironment.transform 21 272513 env35704 = env35756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35704 == env35756) = true)

theorem identity35756 : scanCanonicalize (H12AffineFastState.compose env35756 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190640) := by decide +kernel

theorem selectedBound35756 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,58516,180273,16,95496,8328,65,171417,5392,45525,10400,61705,144492,256,21792,46213,120542]

theorem envBound35757 : H12AffineFastState.Bounded env35757 := by
  intro p hp
  have h : env35757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35756_35757 : H12AffineEnvironment.transform 17 190640 env35756 = env35757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env35756 == env35757) = true)

def env35758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,58396,180273,16,95496,8192,65,171281,5392,45405,10280,61705,144492,256,21792,46093,120406]

theorem envBound35758 : H12AffineFastState.Bounded env35758 := by
  intro p hp
  have h : env35758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35757_35758 : H12AffineEnvironment.transform 6 8 env35757 = env35758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35757 == env35758) = true)

theorem identity35758 : scanCanonicalize (H12AffineFastState.compose env35758 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound35758 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,35189,1024,32769,58396,41340,16,95496,8192,65,64604,5392,45405,10280,61705,21793,256,21792,46093,120406]

theorem envBound35759 : H12AffineFastState.Bounded env35759 := by
  intro p hp
  have h : env35759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35758_35759 : H12AffineEnvironment.transform 16 24909 env35758 = env35759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env35758 == env35759) = true)

theorem identity35759 : scanCanonicalize (H12AffineFastState.compose env35759 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound35759 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env35760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,24909,35189,1024,32769,58396,41340,16,32770,8192,65,64604,5392,45405,10280,61705,21793,256,21792,46093,9052]

theorem envBound35760 : H12AffineFastState.Bounded env35760 := by
  intro p hp
  have h : env35760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35759_35760 : H12AffineEnvironment.transform 15 62730 env35759 = env35760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env35759 == env35760) = true)

theorem identity35760 : scanCanonicalize (H12AffineFastState.compose env35760 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound35760 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env35761 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,343,24909,32040,1024,29788,4161,21793,16,29791,8192,65,2049,5392,17664,10280,1364,21793,256,21792,16464,9052]

theorem envBound35761 : H12AffineFastState.Bounded env35761 := by
  intro p hp
  have h : env35761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35760_35761 : H12AffineEnvironment.transform 14 29789 env35760 = env35761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env35760 == env35761) = true)

theorem identity35761 : scanCanonicalize (H12AffineFastState.compose env35761 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35761 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,343,16400,23669,1024,21761,4161,21793,16,21762,349,65,2049,5392,17664,2421,1364,21793,256,21792,16464,513]

theorem envBound35762 : H12AffineFastState.Bounded env35762 := by
  intro p hp
  have h : env35762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35761_35762 : H12AffineEnvironment.transform 12 349 env35761 = env35762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35761 == env35762) = true)

theorem identity35762 : scanCanonicalize (H12AffineFastState.compose env35762 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound35762 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,81,343,5441,2340,1024,80,4161,112,16,83,349,65,2049,5392,4177,2421,1364,112,256,113,5377,513]

theorem envBound35763 : H12AffineFastState.Bounded env35763 := by
  intro p hp
  have h : env35763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35762_35763 : H12AffineEnvironment.transform 13 5457 env35762 = env35763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env35762 == env35763) = true)

theorem identity35763 : scanCanonicalize (H12AffineFastState.compose env35763 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound35763 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env35764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,309,4096,349,5457,81,343,5441,17,1024,80,4161,112,16,83,349,65,308,5392,4177,64,1364,112,256,113,5377,513]

theorem envBound35764 : H12AffineFastState.Bounded env35764 := by
  intro p hp
  have h : env35764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35763_35764 : H12AffineEnvironment.transform 10 309 env35763 = env35764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env35763 == env35764) = true)

theorem identity35764 : scanCanonicalize (H12AffineFastState.compose env35764 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound35764 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env35765 : List Nat := [2,4,8,16,32,64,8,256,512,4,309,4096,349,4437,81,343,4421,17,4,80,4161,112,16,83,349,65,308,4372,4177,64,336,112,256,113,4357,513]

theorem envBound35765 : H12AffineFastState.Bounded env35765 := by
  intro p hp
  have h : env35765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35764_35765 : H12AffineEnvironment.transform 9 4 env35764 = env35765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env35764 == env35765) = true)

theorem identity35765 : scanCanonicalize (H12AffineFastState.compose env35765 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound35765 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env35766 : List Nat := [2,4,8,16,32,64,8,256,512,4,309,293,349,112,81,343,96,17,4,80,356,112,16,83,349,65,308,49,372,64,336,112,256,113,32,513]

theorem envBound35766 : H12AffineFastState.Bounded env35766 := by
  intro p hp
  have h : env35766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35765_35766 : H12AffineEnvironment.transform 11 293 env35765 = env35766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env35765 == env35766) = true)

theorem identity35766 : scanCanonicalize (H12AffineFastState.compose env35766 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound35766 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35767 : List Nat := [2,4,8,16,32,64,8,256,308,4,309,293,349,112,81,343,96,17,4,80,356,112,16,83,349,65,308,49,372,64,336,112,256,113,32,309]

theorem envBound35767 : H12AffineFastState.Bounded env35767 := by
  intro p hp
  have h : env35767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35766_35767 : H12AffineEnvironment.transform 8 308 env35766 = env35767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env35766 == env35767) = true)

theorem identity35767 : scanCanonicalize (H12AffineFastState.compose env35767 (packedSelected [3,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound35767 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env35768 : List Nat := [2,4,8,16,32,48,8,256,308,4,309,293,301,0,33,295,16,17,4,32,276,0,16,35,301,49,308,49,260,48,288,0,256,1,32,309]

theorem envBound35768 : H12AffineFastState.Bounded env35768 := by
  intro p hp
  have h : env35768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35767_35768 : H12AffineEnvironment.transform 5 48 env35767 = env35768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env35767 == env35768) = true)

theorem identity35768 : scanCanonicalize (H12AffineFastState.compose env35768 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

end H12CloudChart1