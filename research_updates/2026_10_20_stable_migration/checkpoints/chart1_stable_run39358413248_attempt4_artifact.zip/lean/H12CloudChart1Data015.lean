import H12CloudChart1Data014

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env3690 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1693,8192,1588,8200,65536,1692,75786,1024,8200,1692,137,184,34,8329,184,75819,1588,1588,2185,74795,0,172,168,75447,681]

theorem envBound3690 : H12AffineFastState.Bounded env3690 := by
  intro p hp
  have h : env3690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3689_3690 : H12AffineEnvironment.transform 14 8200 env3689 = env3690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env3689 == env3690) = true)

theorem identity3690 : scanCanonicalize (H12AffineFastState.compose env3690 (packedSelected [1,2,6,8,11,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 1574) := by decide +kernel

theorem selectedBound3690 : packedSelected [1,2,6,8,11,13,17] rootPS < 2^1333 := by decide +kernel

def env3691 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1693,1574,1588,1582,65536,1692,69164,1024,1582,1692,137,184,34,1711,184,69133,1588,1588,2185,66061,0,172,168,65681,681]

theorem envBound3691 : H12AffineFastState.Bounded env3691 := by
  intro p hp
  have h : env3691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3690_3691 : H12AffineEnvironment.transform 12 1574 env3690 = env3691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1574 env3690 == env3691) = true)

theorem identity3691 : scanCanonicalize (H12AffineFastState.compose env3691 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1701) := by decide +kernel

theorem selectedBound3691 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3692 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1693,1574,1588,1582,1701,1692,2185,1024,1582,1692,137,184,34,1711,184,2216,1588,1588,2185,1192,0,172,168,1588,681]

theorem envBound3692 : H12AffineFastState.Bounded env3692 := by
  intro p hp
  have h : env3692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3691_3692 : H12AffineEnvironment.transform 15 1701 env3691 = env3692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1701 env3691 == env3692) = true)

theorem identity3692 : scanCanonicalize (H12AffineFastState.compose env3692 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound3692 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env3693 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1703,1693,1574,1588,1582,1701,1692,1582,1024,1582,1692,137,184,34,1711,184,1551,1588,1588,1582,1192,0,172,168,1588,681]

theorem envBound3693 : H12AffineFastState.Bounded env3693 := by
  intro p hp
  have h : env3693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3692_3693 : H12AffineEnvironment.transform 10 1703 env3692 = env3693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env3692 == env3693) = true)

theorem identity3693 : scanCanonicalize (H12AffineFastState.compose env3693 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound3693 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env3694 : List Nat := [2,4,8,16,32,17,18,62,512,1024,1589,1551,1574,1588,1582,1591,1550,1582,1024,1582,1550,27,42,34,1597,42,1551,1588,1588,1582,1082,0,62,58,1588,571]

theorem envBound3694 : H12AffineFastState.Bounded env3694 := by
  intro p hp
  have h : env3694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3693_3694 : H12AffineEnvironment.transform 6 18 env3693 = env3694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env3693 == env3694) = true)

theorem identity3694 : scanCanonicalize (H12AffineFastState.compose env3694 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3694 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env3695 : List Nat := [2,4,8,16,32,17,18,62,1,1024,1076,1038,1063,1077,1071,1078,1039,1071,1024,1071,1039,27,42,34,1084,42,1038,1077,1077,1071,1082,0,62,58,1077,58]

theorem envBound3695 : H12AffineFastState.Bounded env3695 := by
  intro p hp
  have h : env3695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3694_3695 : H12AffineEnvironment.transform 8 1 env3694 = env3695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3694 == env3695) = true)

theorem identity3695 : scanCanonicalize (H12AffineFastState.compose env3695 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound3695 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3696 : List Nat := [2,4,8,16,27,17,18,5,1,1024,1039,1038,1052,1038,1044,1037,1039,1044,1024,1044,1039,27,17,25,1031,17,1038,1038,1038,1044,1025,0,5,1,1038,1]

theorem envBound3696 : H12AffineFastState.Bounded env3696 := by
  intro p hp
  have h : env3696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3695_3696 : H12AffineEnvironment.transform 4 27 env3695 = env3696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env3695 == env3696) = true)

theorem identity3696 : scanCanonicalize (H12AffineFastState.compose env3696 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3696 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3697 : List Nat := [2,4,8,0,11,1,2,5,1,1024,1039,1038,1036,1038,1028,1037,1039,1028,1024,1028,1039,11,1,9,1031,1,1038,1038,1038,1028,1025,0,5,1,1038,1]

theorem envBound3697 : H12AffineFastState.Bounded env3697 := by
  intro p hp
  have h : env3697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3696_3697 : H12AffineEnvironment.transform 3 0 env3696 = env3697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3696 == env3697) = true)

theorem identity3697 : scanCanonicalize (H12AffineFastState.compose env3697 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound3697 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3698 : List Nat := [2,4,8,0,11,1,2,5,1,4,11,10,8,10,0,9,11,0,4,0,11,11,1,9,3,1,10,10,10,0,5,0,5,1,10,1]

theorem envBound3698 : H12AffineFastState.Bounded env3698 := by
  intro p hp
  have h : env3698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3697_3698 : H12AffineEnvironment.transform 9 4 env3697 = env3698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env3697 == env3698) = true)

theorem identity3698 : scanCanonicalize (H12AffineFastState.compose env3698 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3698 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3699 : List Nat := [2,4,2,0,1,1,2,5,1,4,1,0,2,0,0,3,1,0,4,0,1,1,1,3,3,1,0,0,0,0,5,0,5,1,0,1]

theorem envBound3699 : H12AffineFastState.Bounded env3699 := by
  intro p hp
  have h : env3699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3698_3699 : H12AffineEnvironment.transform 2 2 env3698 = env3699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3698 == env3699) = true)

def env3700 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,32768,65536,4096,262144,1024,32768,4097,4194304,8388608,41002,8329,8388608,303145,4265,4264,2185,74795,12623928,173,168,8466579,8389136]

theorem envBound3700 : H12AffineFastState.Bounded env3700 := by
  intro p hp
  have h : env3700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3680_3700 : H12AffineEnvironment.transform 7 173 env3680 = env3700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env3680 == env3700) = true)

theorem identity3700 : scanCanonicalize (H12AffineFastState.compose env3700 (packedSelected [7,9,11,13,18,20,21,22,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 48821) := by decide +kernel

theorem selectedBound3700 : packedSelected [7,9,11,13,18,20,21,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env3701 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,32768,65536,4096,48821,1024,32768,4097,4194304,8388608,41002,8329,8388608,7836,4265,4264,2185,74795,12623928,173,168,8466579,8389136]

theorem envBound3701 : H12AffineFastState.Bounded env3701 := by
  intro p hp
  have h : env3701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3700_3701 : H12AffineEnvironment.transform 17 48821 env3700 = env3701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48821 env3700 == env3701) = true)

def env3702 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,32768,65536,4096,48821,1024,32768,4097,41088,8388608,41002,8329,8388608,7836,4265,4264,2185,74795,8388792,173,168,8466579,8389136]

theorem envBound3702 : H12AffineFastState.Bounded env3702 := by
  intro p hp
  have h : env3702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3701_3702 : H12AffineEnvironment.transform 21 41088 env3701 = env3702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env3701 == env3702) = true)

theorem identity3702 : scanCanonicalize (H12AffineFastState.compose env3702 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 38590) := by decide +kernel

theorem selectedBound3702 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3703 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,32768,38590,4096,48821,1024,32768,4097,41088,8388608,41002,8329,8388608,7836,4265,4264,2185,45717,8388792,173,168,8431149,8389136]

theorem envBound3703 : H12AffineFastState.Bounded env3703 := by
  intro p hp
  have h : env3703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3702_3703 : H12AffineEnvironment.transform 15 38590 env3702 = env3703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38590 env3702 == env3703) = true)

theorem identity3703 : scanCanonicalize (H12AffineFastState.compose env3703 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3703 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3704 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,4096,32768,38423,4096,48668,1024,32768,4097,41001,8388608,41002,8224,8388608,7733,4096,4097,2080,45628,8388625,4,1,8431149,8389136]

theorem envBound3704 : H12AffineFastState.Bounded env3704 := by
  intro p hp
  have h : env3704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3703_3704 : H12AffineEnvironment.transform 6 41 env3703 = env3704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3703 == env3704) = true)

theorem identity3704 : scanCanonicalize (H12AffineFastState.compose env3704 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(22+1) ^^^ 46637) := by decide +kernel

theorem selectedBound3704 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3705 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,4096,32768,38423,4096,48668,1024,32768,4097,41001,46637,41002,8224,46637,7733,4096,4097,2080,45628,46652,4,1,4096,46141]

theorem envBound3705 : H12AffineFastState.Bounded env3705 := by
  intro p hp
  have h : env3705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3704_3705 : H12AffineEnvironment.transform 22 46637 env3704 = env3705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 46637 env3704 == env3705) = true)

theorem identity3705 : scanCanonicalize (H12AffineFastState.compose env3705 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 4659) := by decide +kernel

theorem selectedBound3705 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env3706 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,4659,4096,32768,38423,4096,35887,1024,32768,4097,37402,33822,37401,4627,33822,7733,4096,4097,2080,32783,33807,4,1,4096,34318]

theorem envBound3706 : H12AffineFastState.Bounded env3706 := by
  intro p hp
  have h : env3706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3705_3706 : H12AffineEnvironment.transform 12 4659 env3705 = env3706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4659 env3705 == env3706) = true)

theorem identity3706 : scanCanonicalize (H12AffineFastState.compose env3706 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound3706 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3707 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1551,4096,4659,4096,32768,38423,4096,33312,1024,32768,4097,37402,33822,37401,4627,33822,4154,4096,4097,1583,32783,33807,4,1,4096,34318]

theorem envBound3707 : H12AffineFastState.Bounded env3707 := by
  intro p hp
  have h : env3707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3706_3707 : H12AffineEnvironment.transform 10 1551 env3706 = env3707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env3706 == env3707) = true)

theorem identity3707 : scanCanonicalize (H12AffineFastState.compose env3707 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound3707 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env3708 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1551,1588,1031,1588,32768,32803,1588,33312,1024,32768,1589,33838,33822,33837,1063,33822,1550,1588,1589,1583,32783,33807,4,1,1588,34318]

theorem envBound3708 : H12AffineFastState.Bounded env3708 := by
  intro p hp
  have h : env3708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3707_3708 : H12AffineEnvironment.transform 11 1588 env3707 = env3708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env3707 == env3708) = true)

theorem identity3708 : scanCanonicalize (H12AffineFastState.compose env3708 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 1038) := by decide +kernel

theorem selectedBound3708 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3709 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1551,1588,1031,1588,1038,1069,1588,1582,1024,1038,1589,32,16,35,1063,16,1550,1588,1589,1583,1025,1,4,1,1588,512]

theorem envBound3709 : H12AffineFastState.Bounded env3709 := by
  intro p hp
  have h : env3709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3708_3709 : H12AffineEnvironment.transform 14 1038 env3708 = env3709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1038 env3708 == env3709) = true)

theorem identity3709 : scanCanonicalize (H12AffineFastState.compose env3709 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3709 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3710 : List Nat := [2,4,8,16,32,17,41,4,1,1024,1038,1077,1031,1077,1038,1069,1077,1071,1024,1038,1076,32,16,35,1063,16,1039,1077,1076,1070,1025,1,4,1,1077,1]

theorem envBound3710 : H12AffineFastState.Bounded env3710 := by
  intro p hp
  have h : env3710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3709_3710 : H12AffineEnvironment.transform 8 1 env3709 = env3710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3709 == env3710) = true)

theorem identity3710 : scanCanonicalize (H12AffineFastState.compose env3710 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound3710 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3711 : List Nat := [2,4,8,16,32,17,41,4,1,53,59,0,50,0,59,24,0,26,53,59,1,32,16,35,18,16,58,0,1,27,52,1,4,1,0,1]

theorem envBound3711 : H12AffineFastState.Bounded env3711 := by
  intro p hp
  have h : env3711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3710_3711 : H12AffineEnvironment.transform 9 53 env3710 = env3711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env3710 == env3711) = true)

theorem identity3711 : scanCanonicalize (H12AffineFastState.compose env3711 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound3711 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3712 : List Nat := [2,4,8,11,32,10,41,4,1,46,32,0,41,0,32,3,0,1,46,32,1,32,11,35,9,11,33,0,1,0,47,1,4,1,0,1]

theorem envBound3712 : H12AffineFastState.Bounded env3712 := by
  intro p hp
  have h : env3712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3711_3712 : H12AffineEnvironment.transform 3 11 env3711 = env3712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env3711 == env3712) = true)

def env3713 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,32768,65536,4096,48821,1024,32768,4097,41089,8388608,41002,8329,8388608,7836,4265,4264,2185,74795,8388793,173,168,8466579,8389136]

theorem envBound3713 : H12AffineFastState.Bounded env3713 := by
  intro p hp
  have h : env3713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3701_3713 : H12AffineEnvironment.transform 21 41089 env3701 = env3713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env3701 == env3713) = true)

theorem identity3713 : scanCanonicalize (H12AffineFastState.compose env3713 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 79375) := by decide +kernel

theorem selectedBound3713 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3714 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,32768,65536,4096,48821,1024,32768,4097,41089,79375,41002,8329,79375,7836,4265,4264,2185,74795,79542,173,168,1692,78879]

theorem envBound3714 : H12AffineFastState.Bounded env3714 := by
  intro p hp
  have h : env3714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3713_3714 : H12AffineEnvironment.transform 22 79375 env3713 = env3714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 79375 env3713 == env3714) = true)

theorem identity3714 : scanCanonicalize (H12AffineFastState.compose env3714 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 14007) := by decide +kernel

theorem selectedBound3714 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3715 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,32768,14007,4096,48821,1024,32768,4097,41089,184,41002,8329,184,7836,4265,4264,2185,4764,1,173,168,1692,680]

theorem envBound3715 : H12AffineFastState.Bounded env3715 := by
  intro p hp
  have h : env3715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3714_3715 : H12AffineEnvironment.transform 15 14007 env3714 = env3715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14007 env3714 == env3715) = true)

theorem identity3715 : scanCanonicalize (H12AffineFastState.compose env3715 (packedSelected [4,9,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound3715 : packedSelected [4,9,18,20,23] rootPS < 2^1333 := by decide +kernel

def env3716 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4265,8201,14007,4096,7868,1024,8201,4097,136,184,35,8329,184,7836,4265,4264,2185,4764,1,173,168,1692,680]

theorem envBound3716 : H12AffineFastState.Bounded env3716 := by
  intro p hp
  have h : env3716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3715_3716 : H12AffineEnvironment.transform 14 8201 env3715 = env3716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env3715 == env3716) = true)

theorem identity3716 : scanCanonicalize (H12AffineFastState.compose env3716 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound3716 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3717 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1588,8192,1693,8201,8323,1588,2184,1024,8201,1589,136,184,35,8329,184,2216,1693,1692,2185,1192,1,173,168,1692,680]

theorem envBound3717 : H12AffineFastState.Bounded env3717 := by
  intro p hp
  have h : env3717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3716_3717 : H12AffineEnvironment.transform 11 1588 env3716 = env3717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env3716 == env3717) = true)

theorem identity3717 : scanCanonicalize (H12AffineFastState.compose env3717 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound3717 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env3718 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1702,1588,8192,1693,8201,8323,1588,1582,1024,8201,1589,136,184,35,8329,184,1550,1693,1692,1583,1192,1,173,168,1692,680]

theorem envBound3718 : H12AffineFastState.Bounded env3718 := by
  intro p hp
  have h : env3718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3717_3718 : H12AffineEnvironment.transform 10 1702 env3717 = env3718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env3717 == env3718) = true)

theorem identity3718 : scanCanonicalize (H12AffineFastState.compose env3718 (packedSelected [1,2,3,4,6,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound3718 : packedSelected [1,2,3,4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env3719 : List Nat := [2,4,8,16,32,17,128,173,169,1024,1039,1181,8192,1076,8201,8323,1181,1159,1024,8201,1180,136,184,35,8329,184,1191,1076,1077,1158,1192,1,173,168,1077,1]

theorem envBound3719 : H12AffineFastState.Bounded env3719 := by
  intro p hp
  have h : env3719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3718_3719 : H12AffineEnvironment.transform 8 169 env3718 = env3719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env3718 == env3719) = true)

theorem identity3719 : scanCanonicalize (H12AffineFastState.compose env3719 (packedSelected [4,7] rootPS)) = affineNative (2^(12+1) ^^^ 1198) := by decide +kernel

theorem selectedBound3719 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env3720 : List Nat := [2,4,8,16,32,17,128,173,169,1024,1039,1181,1198,1076,1191,1069,1181,1159,1024,1191,1180,136,184,35,1063,184,1191,1076,1077,1158,1192,1,173,168,1077,1]

theorem envBound3720 : H12AffineFastState.Bounded env3720 := by
  intro p hp
  have h : env3720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3719_3720 : H12AffineEnvironment.transform 12 1198 env3719 = env3720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1198 env3719 == env3720) = true)

theorem identity3720 : scanCanonicalize (H12AffineFastState.compose env3720 (packedSelected [0,1,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound3720 : packedSelected [0,1,3,6] rootPS < 2^1333 := by decide +kernel

def env3721 : List Nat := [2,4,8,16,32,17,128,173,169,166,169,59,8,146,1,139,59,33,166,1,58,136,184,35,129,184,1,146,147,32,14,1,173,168,147,1]

theorem envBound3721 : H12AffineFastState.Bounded env3721 := by
  intro p hp
  have h : env3721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3720_3721 : H12AffineEnvironment.transform 9 166 env3720 = env3721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env3720 == env3721) = true)

theorem identity3721 : scanCanonicalize (H12AffineFastState.compose env3721 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound3721 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env3722 : List Nat := [2,4,8,16,32,17,19,62,58,53,58,59,8,1,1,24,59,33,53,1,58,27,43,35,18,43,1,1,0,32,14,1,62,59,0,1]

theorem envBound3722 : H12AffineFastState.Bounded env3722 := by
  intro p hp
  have h : env3722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3721_3722 : H12AffineEnvironment.transform 6 19 env3721 = env3722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env3721 == env3722) = true)

theorem identity3722 : scanCanonicalize (H12AffineFastState.compose env3722 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound3722 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env3723 : List Nat := [2,4,8,16,26,17,19,4,0,15,0,1,8,1,1,24,1,27,15,1,0,27,17,25,18,17,1,1,0,26,14,1,4,1,0,1]

theorem envBound3723 : H12AffineFastState.Bounded env3723 := by
  intro p hp
  have h : env3723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3722_3723 : H12AffineEnvironment.transform 4 26 env3722 = env3723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env3722 == env3723) = true)

theorem identity3723 : scanCanonicalize (H12AffineFastState.compose env3723 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound3723 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3724 : List Nat := [2,4,8,5,15,4,6,4,0,15,0,1,8,1,1,13,1,14,15,1,0,14,4,12,7,4,1,1,0,15,14,1,4,1,0,1]

theorem envBound3724 : H12AffineFastState.Bounded env3724 := by
  intro p hp
  have h : env3724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3723_3724 : H12AffineEnvironment.transform 3 5 env3723 = env3724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env3723 == env3724) = true)

theorem identity3724 : scanCanonicalize (H12AffineFastState.compose env3724 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3724 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env3725 : List Nat := [2,0,8,1,11,0,2,0,0,11,0,1,8,1,1,9,1,10,11,1,0,10,0,8,3,0,1,1,0,11,10,1,0,1,0,1]

theorem envBound3725 : H12AffineFastState.Bounded env3725 := by
  intro p hp
  have h : env3725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3724_3725 : H12AffineEnvironment.transform 1 0 env3724 = env3725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3724 == env3725) = true)

def leafEnv3725 : List Nat := [2,0,8,1,11,0,2,0,0,11,0,1,8,1,1,9,1,10,11,1,0,10,0,8,10,3,1,0,1,1,0,11,10,1,0,1,0,2,0,1,1,1,0]

def active3725 : List Nat := [0,2]

def tree3725 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3725 : H12WitnessSearch.Good tree3725 := H12GlobalWitnessIndex.good

theorem leafIdentity3725 : H12AffineFastState.composeSystem env3725 rootObs = leafEnv3725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3725 rootObs == leafEnv3725) = true)

theorem terminalChecked3725 : H12PackedTerminal.terminalCheckFast leafEnv3725 active3725 tree3725 = true := by decide +kernel

def env3726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41002,8329,8388688,323792,16384,16893,22640,74794,12644668,257,20561,8479127,8389613]

theorem envBound3726 : H12AffineFastState.Bounded env3726 := by
  intro p hp
  have h : env3726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3667_3726 : H12AffineEnvironment.transform 18 1025 env3667 = env3726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3667 == env3726) = true)

theorem identity3726 : scanCanonicalize (H12AffineFastState.compose env3726 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 5544) := by decide +kernel

theorem selectedBound3726 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,5544,41002,8329,5624,323792,16384,16893,22640,74794,4252820,257,20561,95295,5701]

theorem envBound3727 : H12AffineFastState.Bounded env3727 := by
  intro p hp
  have h : env3727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3726_3727 : H12AffineEnvironment.transform 22 5544 env3726 = env3727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5544 env3726 == env3727) = true)

def env3728 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,5544,41002,8329,5544,323712,16384,16813,22560,74794,4252820,257,20481,95295,5653]

theorem envBound3728 : H12AffineFastState.Bounded env3728 := by
  intro p hp
  have h : env3728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3727_3728 : H12AffineEnvironment.transform 5 16 env3727 = env3728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3727 == env3728) = true)

def env3729 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,41260,5544,41002,8329,5544,323712,16384,16813,22560,74794,17848,257,20481,95295,5653]

theorem envBound3729 : H12AffineFastState.Bounded env3729 := by
  intro p hp
  have h : env3729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3728_3729 : H12AffineEnvironment.transform 21 41260 env3728 = env3729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env3728 == env3729) = true)

theorem identity3729 : scanCanonicalize (H12AffineFastState.compose env3729 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3729 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env3730 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4097,41260,5376,41002,8225,5376,323624,16384,16645,22560,74794,17680,257,20481,95295,5653]

theorem envBound3730 : H12AffineFastState.Bounded env3730 := by
  intro p hp
  have h : env3730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3729_3730 : H12AffineEnvironment.transform 6 40 env3729 = env3730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3729 == env3730) = true)

def env3731 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1296,8192,16384,32768,65536,1044,262144,1025,32768,1297,41260,16,41002,8225,16,320824,16384,16645,19760,74794,17680,257,17681,90415,773]

theorem envBound3731 : H12AffineFastState.Bounded env3731 := by
  intro p hp
  have h : env3731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3730_3731 : H12AffineEnvironment.transform 11 1296 env3730 = env3731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env3730 == env3731) = true)

def env3732 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1297,8192,16384,32768,65536,1045,262144,1025,32768,1296,41260,17,41002,8225,17,320825,16384,16645,19761,74794,17680,257,17680,90414,772]

theorem envBound3732 : H12AffineFastState.Bounded env3732 := by
  intro p hp
  have h : env3732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3730_3732 : H12AffineEnvironment.transform 11 1297 env3730 = env3732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env3730 == env3732) = true)

theorem identity3732 : scanCanonicalize (H12AffineFastState.compose env3732 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3732 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3733 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1044,8192,16384,32768,65536,1045,262144,1025,32768,1045,41001,17,41002,8225,17,320572,16384,16384,19508,74794,17429,4,17429,90155,513]

theorem envBound3733 : H12AffineFastState.Bounded env3733 := by
  intro p hp
  have h : env3733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3732_3733 : H12AffineEnvironment.transform 7 5 env3732 = env3733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3732 == env3733) = true)

theorem identity3733 : scanCanonicalize (H12AffineFastState.compose env3733 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 26143) := by decide +kernel

theorem selectedBound3733 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3734 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1044,8192,16384,32768,26143,1045,262144,1025,32768,1045,41001,17,41002,8225,17,320572,16384,16384,19508,16949,17429,4,17429,1588,513]

theorem envBound3734 : H12AffineFastState.Bounded env3734 := by
  intro p hp
  have h : env3734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3733_3734 : H12AffineEnvironment.transform 15 26143 env3733 = env3734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26143 env3733 == env3734) = true)

theorem identity3734 : scanCanonicalize (H12AffineFastState.compose env3734 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3734 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3735 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,8192,16384,32768,26127,1029,262144,1025,32768,1029,41001,1,41002,8225,1,320556,16384,16384,19492,16933,17413,4,17413,1572,513]

theorem envBound3735 : H12AffineFastState.Bounded env3735 := by
  intro p hp
  have h : env3735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3734_3735 : H12AffineEnvironment.transform 3 0 env3734 = env3735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3734 == env3735) = true)

theorem identity3735 : scanCanonicalize (H12AffineFastState.compose env3735 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8745) := by decide +kernel

theorem selectedBound3735 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3736 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,8192,16384,8745,26127,1029,262144,1025,8745,1029,512,1,515,8225,1,280069,16384,16384,19492,16933,17413,4,17413,1572,513]

theorem envBound3736 : H12AffineFastState.Bounded env3736 := by
  intro p hp
  have h : env3736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3735_3736 : H12AffineEnvironment.transform 14 8745 env3735 = env3736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8745 env3735 == env3736) = true)

theorem identity3736 : scanCanonicalize (H12AffineFastState.compose env3736 (packedSelected [2,3,6,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2087) := by decide +kernel

theorem selectedBound3736 : packedSelected [2,3,6,10,13] rootPS < 2^1333 := by decide +kernel

def env3737 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,2087,16384,2574,20008,1029,262144,1025,2574,1029,512,1,515,2054,1,280069,16384,16384,19492,16933,17413,4,17413,1572,513]

theorem envBound3737 : H12AffineFastState.Bounded env3737 := by
  intro p hp
  have h : env3737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3736_3737 : H12AffineEnvironment.transform 12 2087 env3736 = env3737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2087 env3736 == env3737) = true)

theorem identity3737 : scanCanonicalize (H12AffineFastState.compose env3737 (packedSelected [0,1,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound3737 : packedSelected [0,1,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env3738 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,2087,1028,2574,2604,1029,262144,1025,2574,1029,512,1,515,2054,1,262657,1028,1028,2080,1569,1,4,1,1572,513]

theorem envBound3738 : H12AffineFastState.Bounded env3738 := by
  intro p hp
  have h : env3738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3737_3738 : H12AffineEnvironment.transform 13 1028 env3737 = env3738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env3737 == env3738) = true)

theorem identity3738 : scanCanonicalize (H12AffineFastState.compose env3738 (packedSelected [1,2,3] rootPS)) = affineNative (2^(17+1) ^^^ 1066) := by decide +kernel

theorem selectedBound3738 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3739 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,2087,1028,2574,2604,1029,1066,1025,2574,1029,512,1,515,2054,1,1579,1028,1028,2080,1569,1,4,1,1572,513]

theorem envBound3739 : H12AffineFastState.Bounded env3739 := by
  intro p hp
  have h : env3739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3738_3739 : H12AffineEnvironment.transform 17 1066 env3738 = env3739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1066 env3738 == env3739) = true)

theorem identity3739 : scanCanonicalize (H12AffineFastState.compose env3739 (packedSelected [2,5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound3739 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env3740 : List Nat := [2,4,8,0,32,0,40,5,512,14,2048,10,2087,10,2574,2604,11,36,15,2574,11,512,1,515,2054,1,549,10,10,2080,559,1,4,1,554,513]

theorem envBound3740 : H12AffineFastState.Bounded env3740 := by
  intro p hp
  have h : env3740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3739_3740 : H12AffineEnvironment.transform 9 14 env3739 = env3740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env3739 == env3740) = true)

theorem identity3740 : scanCanonicalize (H12AffineFastState.compose env3740 (packedSelected [1,2,6,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound3740 : packedSelected [1,2,6,8,11] rootPS < 2^1333 := by decide +kernel

def env3741 : List Nat := [2,4,8,0,32,0,40,5,42,14,2048,10,2087,10,2084,2054,11,36,15,2084,11,42,1,41,2054,1,15,10,10,2080,5,1,4,1,0,43]

theorem envBound3741 : H12AffineFastState.Bounded env3741 := by
  intro p hp
  have h : env3741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3740_3741 : H12AffineEnvironment.transform 8 42 env3740 = env3741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env3740 == env3741) = true)

theorem identity3741 : scanCanonicalize (H12AffineFastState.compose env3741 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound3741 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3742 : List Nat := [2,4,8,0,4,0,12,5,14,14,2048,10,2051,10,2048,2054,11,0,15,2048,11,14,1,13,2054,1,15,10,10,2052,5,1,4,1,0,15]

theorem envBound3742 : H12AffineFastState.Bounded env3742 := by
  intro p hp
  have h : env3742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3741_3742 : H12AffineEnvironment.transform 4 4 env3741 = env3742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env3741 == env3742) = true)

theorem identity3742 : scanCanonicalize (H12AffineFastState.compose env3742 (packedSelected [0,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3742 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env3743 : List Nat := [2,4,2,0,4,0,6,5,4,4,2048,0,2051,0,2048,2054,1,0,5,2048,1,4,1,7,2054,1,5,0,0,2052,5,1,4,1,0,5]

theorem envBound3743 : H12AffineFastState.Bounded env3743 := by
  intro p hp
  have h : env3743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3742_3743 : H12AffineEnvironment.transform 2 2 env3742 = env3743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3742 == env3743) = true)

theorem identity3743 : scanCanonicalize (H12AffineFastState.compose env3743 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3743 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3744 : List Nat := [2,0,2,0,0,0,2,1,0,0,2048,0,2051,0,2048,2050,1,0,1,2048,1,0,1,3,2050,1,1,0,0,2048,1,1,0,1,0,1]

theorem envBound3744 : H12AffineFastState.Bounded env3744 := by
  intro p hp
  have h : env3744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3743_3744 : H12AffineEnvironment.transform 1 0 env3743 = env3744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3743 == env3744) = true)

theorem identity3744 : scanCanonicalize (H12AffineFastState.compose env3744 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound3744 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env3745 : List Nat := [2,0,2,0,0,0,2,1,0,0,1,0,2,0,1,3,1,0,1,1,1,0,1,3,3,1,1,0,0,1,1,1,0,1,0,1]

theorem envBound3745 : H12AffineFastState.Bounded env3745 := by
  intro p hp
  have h : env3745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3744_3745 : H12AffineEnvironment.transform 10 1 env3744 = env3745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env3744 == env3745) = true)

def env3746 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,41261,5544,41002,8329,5544,323712,16384,16813,22560,74794,17849,257,20481,95295,5653]

theorem envBound3746 : H12AffineFastState.Bounded env3746 := by
  intro p hp
  have h : env3746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3728_3746 : H12AffineEnvironment.transform 21 41261 env3728 = env3746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env3728 == env3746) = true)

theorem identity3746 : scanCanonicalize (H12AffineFastState.compose env3746 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 25914) := by decide +kernel

theorem selectedBound3746 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env3747 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1025,32768,4097,41261,5544,41002,8329,5544,323712,16384,16813,22560,16656,17849,257,20481,4357,5653]

theorem envBound3747 : H12AffineFastState.Bounded env3747 := by
  intro p hp
  have h : env3747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3746_3747 : H12AffineEnvironment.transform 15 25914 env3746 = env3747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25914 env3746 == env3747) = true)

def env3748 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1464,8192,16384,32768,25914,1044,262144,1025,32768,1465,41261,16,41002,8329,16,320824,16384,16813,19864,16656,17849,257,17849,1213,941]

theorem envBound3748 : H12AffineFastState.Bounded env3748 := by
  intro p hp
  have h : env3748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3747_3748 : H12AffineEnvironment.transform 11 1464 env3747 = env3748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env3747 == env3748) = true)

theorem identity3748 : scanCanonicalize (H12AffineFastState.compose env3748 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3748 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3749 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1213,8192,16384,32768,25663,1044,262144,1025,32768,1212,41000,16,41002,8329,16,320573,16384,16552,19613,16405,17596,4,17596,1213,680]

theorem envBound3749 : H12AffineFastState.Bounded env3749 := by
  intro p hp
  have h : env3749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3748_3749 : H12AffineEnvironment.transform 7 5 env3748 = env3749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3748 == env3749) = true)

theorem identity3749 : scanCanonicalize (H12AffineFastState.compose env3749 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 1693) := by decide +kernel

theorem selectedBound3749 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env3750 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1213,8192,1693,32768,8866,1044,262144,1025,32768,1212,41000,16,41002,8329,16,303776,1693,1589,2560,1672,545,4,545,1213,680]

theorem envBound3750 : H12AffineFastState.Bounded env3750 := by
  intro p hp
  have h : env3750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3749_3750 : H12AffineEnvironment.transform 13 1693 env3749 = env3750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1693 env3749 == env3750) = true)

theorem identity3750 : scanCanonicalize (H12AffineFastState.compose env3750 (packedSelected [2,3,5,10,11,17,18,21] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound3750 : packedSelected [2,3,5,10,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env3751 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1213,8192,1693,8200,8866,1044,262144,1025,8200,1212,32,16,34,8329,16,262824,1693,1589,2560,1672,545,4,545,1213,680]

theorem envBound3751 : H12AffineFastState.Bounded env3751 := by
  intro p hp
  have h : env3751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3750_3751 : H12AffineEnvironment.transform 14 8200 env3750 = env3751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env3750 == env3751) = true)

theorem identity3751 : scanCanonicalize (H12AffineFastState.compose env3751 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2561) := by decide +kernel

theorem selectedBound3751 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3752 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1213,8192,1693,8200,8866,1044,2561,1025,8200,1212,32,16,34,8329,16,2217,1693,1589,2560,1672,545,4,545,1213,680]

theorem envBound3752 : H12AffineFastState.Bounded env3752 := by
  intro p hp
  have h : env3752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3751_3752 : H12AffineEnvironment.transform 17 2561 env3751 = env3752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2561 env3751 == env3752) = true)

theorem identity3752 : scanCanonicalize (H12AffineFastState.compose env3752 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3752 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3753 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1045,8192,1589,8200,8714,1044,2561,1025,8200,1044,32,16,34,8225,16,2049,1589,1589,2560,1568,545,4,545,1045,512]

theorem envBound3753 : H12AffineFastState.Bounded env3753 := by
  intro p hp
  have h : env3753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3752_3753 : H12AffineEnvironment.transform 6 40 env3752 = env3753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3752 == env3753) = true)

theorem identity3753 : scanCanonicalize (H12AffineFastState.compose env3753 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 1564) := by decide +kernel

theorem selectedBound3753 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3754 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1045,1564,1589,1556,1046,1044,2561,1025,1556,1044,32,16,34,1597,16,2049,1589,1589,2560,1568,545,4,545,1045,512]

theorem envBound3754 : H12AffineFastState.Bounded env3754 := by
  intro p hp
  have h : env3754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3753_3754 : H12AffineEnvironment.transform 12 1564 env3753 = env3754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1564 env3753 == env3754) = true)

theorem identity3754 : scanCanonicalize (H12AffineFastState.compose env3754 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1583) := by decide +kernel

theorem selectedBound3754 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3755 : List Nat := [2,4,8,16,32,16,40,5,512,1024,1583,1045,1564,1589,1556,1046,1044,1070,1025,1556,1044,32,16,34,1597,16,1582,1589,1589,1071,1568,545,4,545,1045,512]

theorem envBound3755 : H12AffineFastState.Bounded env3755 := by
  intro p hp
  have h : env3755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3754_3755 : H12AffineEnvironment.transform 10 1583 env3754 = env3755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1583 env3754 == env3755) = true)

theorem identity3755 : scanCanonicalize (H12AffineFastState.compose env3755 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3755 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3756 : List Nat := [2,4,8,16,32,16,40,5,1,1024,1070,1045,1053,1076,1045,1046,1044,1070,1025,1045,1044,32,16,34,1084,16,1071,1076,1076,1071,1057,32,4,32,1045,1]

theorem envBound3756 : H12AffineFastState.Bounded env3756 := by
  intro p hp
  have h : env3756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3755_3756 : H12AffineEnvironment.transform 8 1 env3755 = env3756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3755 == env3756) = true)

theorem identity3756 : scanCanonicalize (H12AffineFastState.compose env3756 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound3756 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3757 : List Nat := [2,4,8,16,26,16,18,5,1,1024,1044,1045,1053,1038,1045,1046,1044,1044,1025,1045,1044,26,16,24,1030,16,1045,1038,1038,1045,1051,26,4,26,1045,1]

theorem envBound3757 : H12AffineFastState.Bounded env3757 := by
  intro p hp
  have h : env3757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3756_3757 : H12AffineEnvironment.transform 4 26 env3756 = env3757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env3756 == env3757) = true)

theorem identity3757 : scanCanonicalize (H12AffineFastState.compose env3757 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound3757 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3758 : List Nat := [2,4,8,16,26,16,18,5,1,15,27,26,18,1,26,25,27,27,14,26,27,26,16,24,9,16,26,1,1,26,20,26,4,26,26,1]

theorem envBound3758 : H12AffineFastState.Bounded env3758 := by
  intro p hp
  have h : env3758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3757_3758 : H12AffineEnvironment.transform 9 15 env3757 = env3758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env3757 == env3758) = true)

def env3759 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1465,8192,16384,32768,25914,1045,262144,1025,32768,1464,41261,17,41002,8329,17,320825,16384,16813,19865,16656,17849,257,17848,1212,940]

theorem envBound3759 : H12AffineFastState.Bounded env3759 := by
  intro p hp
  have h : env3759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3747_3759 : H12AffineEnvironment.transform 11 1465 env3747 = env3759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env3747 == env3759) = true)

theorem identity3759 : scanCanonicalize (H12AffineFastState.compose env3759 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3759 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3760 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1297,8192,16384,32768,25914,1045,262144,1025,32768,1296,41261,17,41002,8225,17,320825,16384,16645,19761,16656,17681,257,17680,1044,772]

theorem envBound3760 : H12AffineFastState.Bounded env3760 := by
  intro p hp
  have h : env3760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3759_3760 : H12AffineEnvironment.transform 6 40 env3759 = env3760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3759 == env3760) = true)

theorem identity3760 : scanCanonicalize (H12AffineFastState.compose env3760 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1038) := by decide +kernel

theorem selectedBound3760 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3761 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1297,8192,16384,32768,25914,1045,1038,1025,32768,1296,41261,17,41002,8225,17,57655,16384,16645,19761,16656,17681,257,17680,1044,772]

theorem envBound3761 : H12AffineFastState.Bounded env3761 := by
  intro p hp
  have h : env3761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3760_3761 : H12AffineEnvironment.transform 17 1038 env3760 = env3761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1038 env3760 == env3761) = true)

theorem identity3761 : scanCanonicalize (H12AffineFastState.compose env3761 (packedSelected [1,5,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2349) := by decide +kernel

theorem selectedBound3761 : packedSelected [1,5,13,15] rootPS < 2^1333 := by decide +kernel

def env3762 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1297,2349,16384,32768,19479,1045,1038,1025,32768,1296,34816,17,35079,2316,17,51226,16384,16645,19761,16656,17681,257,17680,1044,772]

theorem envBound3762 : H12AffineFastState.Bounded env3762 := by
  intro p hp
  have h : env3762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3761_3762 : H12AffineEnvironment.transform 12 2349 env3761 = env3762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2349 env3761 == env3762) = true)

theorem identity3762 : scanCanonicalize (H12AffineFastState.compose env3762 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3762 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3763 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1044,2088,16384,32768,19479,1045,1038,1025,32768,1045,34816,17,34818,2057,17,51226,16384,16384,19508,16405,17428,4,17429,1044,513]

theorem envBound3763 : H12AffineFastState.Bounded env3763 := by
  intro p hp
  have h : env3763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3762_3763 : H12AffineEnvironment.transform 7 5 env3762 = env3763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3762 == env3763) = true)

theorem identity3763 : scanCanonicalize (H12AffineFastState.compose env3763 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 19493) := by decide +kernel

theorem selectedBound3763 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3764 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1044,2088,16384,19493,19479,1045,1038,1025,19493,1045,17445,17,17447,2057,17,1087,16384,16384,19508,16405,17428,4,17429,1044,513]

theorem envBound3764 : H12AffineFastState.Bounded env3764 := by
  intro p hp
  have h : env3764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3763_3764 : H12AffineEnvironment.transform 14 19493 env3763 = env3764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 19493 env3763 == env3764) = true)

theorem identity3764 : scanCanonicalize (H12AffineFastState.compose env3764 (packedSelected [3,8,12,17] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound3764 : packedSelected [3,8,12,17] rootPS < 2^1333 := by decide +kernel

def env3765 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1044,2088,1076,2065,2083,1045,1038,1025,2065,1045,17,17,19,2057,17,1087,1076,1076,2048,1057,32,4,33,1044,513]

theorem envBound3765 : H12AffineFastState.Bounded env3765 := by
  intro p hp
  have h : env3765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3764_3765 : H12AffineEnvironment.transform 13 1076 env3764 = env3765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env3764 == env3765) = true)

theorem identity3765 : scanCanonicalize (H12AffineFastState.compose env3765 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1054) := by decide +kernel

theorem selectedBound3765 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env3766 : List Nat := [2,4,8,16,32,16,40,5,512,1024,1054,1044,1078,1076,1039,1085,1045,1038,1025,1039,1045,17,17,19,1047,17,1087,1076,1076,1054,1057,32,4,33,1044,513]

theorem envBound3766 : H12AffineFastState.Bounded env3766 := by
  intro p hp
  have h : env3766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3765_3766 : H12AffineEnvironment.transform 10 1054 env3765 = env3766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1054 env3765 == env3766) = true)

theorem identity3766 : scanCanonicalize (H12AffineFastState.compose env3766 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 52) := by decide +kernel

theorem selectedBound3766 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3767 : List Nat := [2,4,8,16,32,16,40,5,52,1024,1054,1044,1078,1076,1039,1085,1045,1038,1025,1039,1045,17,17,19,1047,17,1087,1076,1076,1054,1057,32,4,33,1044,53]

theorem envBound3767 : H12AffineFastState.Bounded env3767 := by
  intro p hp
  have h : env3767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3766_3767 : H12AffineEnvironment.transform 8 52 env3766 = env3767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 52 env3766 == env3767) = true)

theorem identity3767 : scanCanonicalize (H12AffineFastState.compose env3767 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound3767 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env3768 : List Nat := [2,4,8,16,5,16,13,5,17,1024,1054,1044,1043,1041,1039,1048,1045,1038,1025,1039,1045,17,17,19,1047,17,1050,1041,1041,1054,1028,5,4,4,1044,16]

theorem envBound3768 : H12AffineFastState.Bounded env3768 := by
  intro p hp
  have h : env3768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3767_3768 : H12AffineEnvironment.transform 4 5 env3767 = env3768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env3767 == env3768) = true)

theorem identity3768 : scanCanonicalize (H12AffineFastState.compose env3768 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 27) := by decide +kernel

theorem selectedBound3768 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env3769 : List Nat := [2,4,8,16,5,16,13,5,17,27,5,15,8,10,20,3,14,21,26,20,14,17,17,19,12,17,1,10,10,5,31,5,4,4,15,16]

theorem envBound3769 : H12AffineFastState.Bounded env3769 := by
  intro p hp
  have h : env3769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3768_3769 : H12AffineEnvironment.transform 9 27 env3768 = env3769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 27 env3768 == env3769) = true)

theorem identity3769 : scanCanonicalize (H12AffineFastState.compose env3769 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound3769 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3770 : List Nat := [2,4,8,4,5,4,13,5,5,15,5,15,8,10,0,3,14,1,14,0,14,5,5,7,12,5,1,10,10,5,11,5,4,4,15,4]

theorem envBound3770 : H12AffineFastState.Bounded env3770 := by
  intro p hp
  have h : env3770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3769_3770 : H12AffineEnvironment.transform 3 4 env3769 = env3770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env3769 == env3770) = true)

theorem identity3770 : scanCanonicalize (H12AffineFastState.compose env3770 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound3770 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env3771 : List Nat := [2,4,7,4,5,4,2,5,5,0,5,0,7,5,0,3,1,1,1,0,1,5,5,7,3,5,1,5,5,5,4,5,4,4,0,4]

theorem envBound3771 : H12AffineFastState.Bounded env3771 := by
  intro p hp
  have h : env3771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3770_3771 : H12AffineEnvironment.transform 2 7 env3770 = env3771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env3770 == env3771) = true)

theorem identity3771 : scanCanonicalize (H12AffineFastState.compose env3771 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound3771 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env3772 : List Nat := [2,1,2,1,0,1,2,0,0,0,0,0,2,0,0,3,1,1,1,0,1,0,0,2,3,0,1,0,0,0,1,0,1,1,0,1]

theorem envBound3772 : H12AffineFastState.Bounded env3772 := by
  intro p hp
  have h : env3772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3771_3772 : H12AffineEnvironment.transform 1 1 env3771 = env3772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3771 == env3772) = true)

def env3773 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,5544,41002,8329,5545,323713,16384,16812,22561,74794,4252820,257,20480,95295,5652]

theorem envBound3773 : H12AffineFastState.Bounded env3773 := by
  intro p hp
  have h : env3773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3727_3773 : H12AffineEnvironment.transform 5 17 env3727 = env3773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3727 == env3773) = true)

theorem identity3773 : scanCanonicalize (H12AffineFastState.compose env3773 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound3773 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3774 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,32768,65536,1465,262144,1025,32768,1045,4194304,444,41002,8329,445,320661,16384,16812,19509,74794,4252820,257,17428,90155,512]

theorem envBound3774 : H12AffineFastState.Bounded env3774 := by
  intro p hp
  have h : env3774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3773_3774 : H12AffineEnvironment.transform 11 1044 env3773 = env3774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env3773 == env3774) = true)

theorem identity3774 : scanCanonicalize (H12AffineFastState.compose env3774 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound3774 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3775 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,32768,65536,1465,262144,1025,32768,1045,41349,444,41002,8329,445,320661,16384,16812,19509,74794,17681,257,17428,90155,512]

theorem envBound3775 : H12AffineFastState.Bounded env3775 := by
  intro p hp
  have h : env3775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3774_3775 : H12AffineEnvironment.transform 21 41349 env3774 = env3775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env3774 == env3775) = true)

theorem identity3775 : scanCanonicalize (H12AffineFastState.compose env3775 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33710) := by decide +kernel

theorem selectedBound3775 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3776 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,32768,33710,1465,262144,1025,32768,1045,41349,444,41002,8329,445,320661,16384,16812,19509,42884,17681,257,17428,58245,512]

theorem envBound3776 : H12AffineFastState.Bounded env3776 := by
  intro p hp
  have h : env3776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3775_3776 : H12AffineEnvironment.transform 15 33710 env3775 = env3776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33710 env3775 == env3776) = true)

theorem identity3776 : scanCanonicalize (H12AffineFastState.compose env3776 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26424) := by decide +kernel

theorem selectedBound3776 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3777 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,26424,25750,1465,262144,1025,26424,1045,18109,444,18194,8329,445,263085,16384,16812,19509,16572,17681,257,17428,1213,512]

theorem envBound3777 : H12AffineFastState.Bounded env3777 := by
  intro p hp
  have h : env3777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3776_3777 : H12AffineEnvironment.transform 14 26424 env3776 = env3777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26424 env3776 == env3777) = true)

theorem identity3777 : scanCanonicalize (H12AffineFastState.compose env3777 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 20156) := by decide +kernel

theorem selectedBound3777 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env3778 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1044,8192,16384,26424,25750,1465,20156,1025,26424,1045,18109,444,18194,8329,445,19729,16384,16812,19509,16572,17681,257,17428,1213,512]

theorem envBound3778 : H12AffineFastState.Bounded env3778 := by
  intro p hp
  have h : env3778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3777_3778 : H12AffineEnvironment.transform 17 20156 env3777 = env3778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20156 env3777 == env3778) = true)

def env3779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41002,8329,8914001,849105,16385,16892,547953,598059,12644668,525568,545872,8479127,8914924]

theorem envBound3779 : H12AffineFastState.Bounded env3779 := by
  intro p hp
  have h : env3779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3666_3779 : H12AffineEnvironment.transform 27 16385 env3666 = env3779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env3666 == env3779) = true)

def env3780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41002,8329,8388689,323793,16385,16892,22641,74795,12644668,256,20560,8479127,8389612]

theorem envBound3780 : H12AffineFastState.Bounded env3780 := by
  intro p hp
  have h : env3780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3779_3780 : H12AffineEnvironment.transform 18 1024 env3779 = env3780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3779 == env3780) = true)

theorem identity3780 : scanCanonicalize (H12AffineFastState.compose env3780 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4255800) := by decide +kernel

theorem selectedBound3780 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,4255800,41002,8329,4255849,323793,16385,16892,22641,74795,260,256,20560,4297135,4256724]

theorem envBound3781 : H12AffineFastState.Bounded env3781 := by
  intro p hp
  have h : env3781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3780_3781 : H12AffineEnvironment.transform 22 4255800 env3780 = env3781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4255800 env3780 == env3781) = true)

def env3782 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,4194304,4255800,41002,8329,4255801,323713,16385,16812,22561,74795,260,256,20480,4297135,4256644]

theorem envBound3782 : H12AffineFastState.Bounded env3782 := by
  intro p hp
  have h : env3782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3781_3782 : H12AffineEnvironment.transform 5 16 env3781 = env3782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3781 == env3782) = true)

def env3783 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,136,61616,41002,8329,61617,323713,16385,16812,22561,74795,260,256,20480,102695,62220]

theorem envBound3783 : H12AffineFastState.Bounded env3783 := by
  intro p hp
  have h : env3783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3782_3783 : H12AffineEnvironment.transform 21 136 env3782 = env3783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env3782 == env3783) = true)

theorem identity3783 : scanCanonicalize (H12AffineFastState.compose env3783 (packedSelected [9,17,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 49072) := by decide +kernel

theorem selectedBound3783 : packedSelected [9,17,21,22] rootPS < 2^1333 := by decide +kernel

def env3784 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,49072,1024,32768,4097,136,61616,41002,8329,61617,20273,16385,16812,22561,74795,260,256,20480,102695,62220]

theorem envBound3784 : H12AffineFastState.Bounded env3784 := by
  intro p hp
  have h : env3784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3783_3784 : H12AffineEnvironment.transform 17 49072 env3783 = env3784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 49072 env3783 == env3784) = true)

def env3785 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,32768,65536,4372,48904,1024,32768,4097,48,61448,41002,8241,61449,20273,16385,16660,22561,74795,260,256,20480,102695,62220]

theorem envBound3785 : H12AffineFastState.Bounded env3785 := by
  intro p hp
  have h : env3785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3784_3785 : H12AffineEnvironment.transform 6 56 env3784 = env3785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env3784 == env3785) = true)

theorem identity3785 : scanCanonicalize (H12AffineFastState.compose env3785 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 28680) := by decide +kernel

theorem selectedBound3785 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env3786 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,28680,65536,4372,20224,1024,28680,4097,48,0,20514,8241,1,20273,16385,16660,22561,74795,260,256,20480,90415,772]

theorem envBound3786 : H12AffineFastState.Bounded env3786 := by
  intro p hp
  have h : env3786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3785_3786 : H12AffineEnvironment.transform 14 28680 env3785 = env3786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28680 env3785 == env3786) = true)

theorem identity3786 : scanCanonicalize (H12AffineFastState.compose env3786 (packedSelected [5,13,21,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound3786 : packedSelected [5,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env3787 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,28680,8250,4372,20224,1024,28680,4097,48,0,20514,8241,1,20273,16385,16660,22561,1041,260,256,20480,16661,772]

theorem envBound3787 : H12AffineFastState.Bounded env3787 := by
  intro p hp
  have h : env3787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3786_3787 : H12AffineEnvironment.transform 15 8250 env3786 = env3787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env3786 == env3787) = true)

theorem identity3787 : scanCanonicalize (H12AffineFastState.compose env3787 (packedSelected [0,27] rootPS)) = affineNative (2^(11+1) ^^^ 1841) := by decide +kernel

theorem selectedBound3787 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env3788 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,1841,8192,16384,26425,8250,1573,20224,1024,26425,1840,48,0,18195,8241,1,20273,16385,16660,20240,1041,260,256,18225,16661,772]

theorem envBound3788 : H12AffineFastState.Bounded env3788 := by
  intro p hp
  have h : env3788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3787_3788 : H12AffineEnvironment.transform 11 1841 env3787 = env3788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1841 env3787 == env3788) = true)

theorem identity3788 : scanCanonicalize (H12AffineFastState.compose env3788 (packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound3788 : packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env3789 : List Nat := [2,4,8,16,32,16,56,30,512,1024,2048,1583,8192,16384,26151,8250,1573,19998,1024,26151,1582,48,0,17933,8241,1,20015,16385,16394,19982,1041,26,30,17967,16395,538]

theorem envBound3789 : H12AffineFastState.Bounded env3789 := by
  intro p hp
  have h : env3789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3788_3789 : H12AffineEnvironment.transform 7 30 env3788 = env3789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env3788 == env3789) = true)

theorem identity3789 : scanCanonicalize (H12AffineFastState.compose env3789 (packedSelected [2,3,5,10,11,23] rootPS)) = affineNative (2^(13+1) ^^^ 1598) := by decide +kernel

theorem selectedBound3789 : packedSelected [2,3,5,10,11,23] rootPS < 2^1333 := by decide +kernel

def env3790 : List Nat := [2,4,8,16,32,16,56,30,512,1024,2048,1583,8192,1598,8217,8250,1573,2080,1024,8217,1582,48,0,51,8241,1,2065,1599,1588,2096,1041,26,30,17,1589,538]

theorem envBound3790 : H12AffineFastState.Bounded env3790 := by
  intro p hp
  have h : env3790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3789_3790 : H12AffineEnvironment.transform 13 1598 env3789 = env3790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1598 env3789 == env3790) = true)

theorem identity3790 : scanCanonicalize (H12AffineFastState.compose env3790 (packedSelected [3,4,5,6,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound3790 : packedSelected [3,4,5,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env3791 : List Nat := [2,4,8,16,32,16,56,30,512,1024,538,1583,8192,1598,8217,8250,1573,570,1024,8217,1582,48,0,51,8241,1,523,1599,1588,554,1041,26,30,17,1589,538]

theorem envBound3791 : H12AffineFastState.Bounded env3791 := by
  intro p hp
  have h : env3791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3790_3791 : H12AffineEnvironment.transform 10 538 env3790 = env3791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env3790 == env3791) = true)

theorem identity3791 : scanCanonicalize (H12AffineFastState.compose env3791 (packedSelected [0,1,3,4,6,10] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound3791 : packedSelected [0,1,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env3792 : List Nat := [2,4,8,16,26,16,2,30,512,1024,538,1557,8192,1540,8217,8192,1567,512,1024,8217,1556,10,0,9,8203,1,523,1541,1550,528,1041,26,30,17,1551,538]

theorem envBound3792 : H12AffineFastState.Bounded env3792 := by
  intro p hp
  have h : env3792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3791_3792 : H12AffineEnvironment.transform 4 26 env3791 = env3792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env3791 == env3792) = true)

theorem identity3792 : scanCanonicalize (H12AffineFastState.compose env3792 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound3792 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env3793 : List Nat := [2,4,8,16,26,16,2,30,512,1024,538,1557,2,1540,27,2,1567,512,1024,27,1556,10,0,9,9,1,523,1541,1550,528,1041,26,30,17,1551,538]

theorem envBound3793 : H12AffineFastState.Bounded env3793 := by
  intro p hp
  have h : env3793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3792_3793 : H12AffineEnvironment.transform 12 2 env3792 = env3793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env3792 == env3793) = true)

theorem identity3793 : scanCanonicalize (H12AffineFastState.compose env3793 (packedSelected [5,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3793 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env3794 : List Nat := [2,4,8,10,0,10,2,4,512,1024,512,1551,2,1540,1,2,1541,512,1024,1,1550,10,0,9,9,1,523,1541,1550,522,1035,0,4,11,1551,512]

theorem envBound3794 : H12AffineFastState.Bounded env3794 := by
  intro p hp
  have h : env3794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3793_3794 : H12AffineEnvironment.transform 3 10 env3793 = env3794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3793 == env3794) = true)

theorem identity3794 : scanCanonicalize (H12AffineFastState.compose env3794 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3794 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env3795 : List Nat := [2,4,8,10,0,10,2,4,0,1024,0,1039,2,1028,1,2,1029,0,1024,1,1038,10,0,9,9,1,11,1029,1038,10,1035,0,4,11,1039,0]

theorem envBound3795 : H12AffineFastState.Bounded env3795 := by
  intro p hp
  have h : env3795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3794_3795 : H12AffineEnvironment.transform 8 0 env3794 = env3795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3794 == env3795) = true)

theorem identity3795 : scanCanonicalize (H12AffineFastState.compose env3795 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3795 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3796 : List Nat := [2,4,2,0,0,0,2,4,0,1024,0,1029,2,1028,1,2,1029,0,1024,1,1028,0,0,3,3,1,1,1029,1028,0,1025,0,4,1,1029,0]

theorem envBound3796 : H12AffineFastState.Bounded env3796 := by
  intro p hp
  have h : env3796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3795_3796 : H12AffineEnvironment.transform 2 2 env3795 = env3796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3795 == env3796) = true)

def leafEnv3796 : List Nat := [2,4,2,0,0,0,2,4,0,1024,0,1029,2,1028,1,2,1029,0,1024,1,1028,0,0,3,1025,3,1,1,1,1029,1028,0,1025,0,4,1,4,2,1029,0,1,1028,0]

def active3796 : List Nat := [0,1,9]

def tree3796 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3796 : H12WitnessSearch.Good tree3796 := H12GlobalWitnessIndex.good

theorem leafIdentity3796 : H12AffineFastState.composeSystem env3796 rootObs = leafEnv3796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3796 rootObs == leafEnv3796) = true)

theorem terminalChecked3796 : H12PackedTerminal.terminalCheckFast leafEnv3796 active3796 tree3796 = true := by decide +kernel

def env3797 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,32768,65536,4373,48905,1024,32768,4097,49,61449,41002,8240,61448,20273,16385,16661,22561,74795,260,256,20480,102695,62220]

theorem envBound3797 : H12AffineFastState.Bounded env3797 := by
  intro p hp
  have h : env3797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3784_3797 : H12AffineEnvironment.transform 6 57 env3784 = env3797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env3784 == env3797) = true)

theorem identity3797 : scanCanonicalize (H12AffineFastState.compose env3797 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 53543) := by decide +kernel

theorem selectedBound3797 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env3798 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,32768,53543,4373,48905,1024,32768,4097,49,61449,41002,8240,61448,20273,16385,16661,22561,62732,260,256,20480,16384,62220]

theorem envBound3798 : H12AffineFastState.Bounded env3798 := by
  intro p hp
  have h : env3798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3797_3798 : H12AffineEnvironment.transform 15 53543 env3797 = env3798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53543 env3797 == env3798) = true)

theorem identity3798 : scanCanonicalize (H12AffineFastState.compose env3798 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 28680) := by decide +kernel

theorem selectedBound3798 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3799 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,28680,8495,4373,20225,1024,28680,4097,49,1,20514,8240,0,20273,16385,16661,22561,1284,260,256,20480,16384,772]

theorem envBound3799 : H12AffineFastState.Bounded env3799 := by
  intro p hp
  have h : env3799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3798_3799 : H12AffineEnvironment.transform 14 28680 env3798 = env3799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28680 env3798 == env3799) = true)

theorem identity3799 : scanCanonicalize (H12AffineFastState.compose env3799 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3799 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3800 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,4096,8192,16384,28680,8495,4357,20225,1024,28680,4097,33,1,20514,8224,0,20257,16385,16645,22561,1284,260,256,20480,16384,772]

theorem envBound3800 : H12AffineFastState.Bounded env3800 := by
  intro p hp
  have h : env3800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3799_3800 : H12AffineEnvironment.transform 3 0 env3799 = env3800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3799 == env3800) = true)

theorem identity3800 : scanCanonicalize (H12AffineFastState.compose env3800 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2861) := by decide +kernel

theorem selectedBound3800 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env3801 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,4096,2861,16384,23333,2562,4357,20225,1024,23333,4097,33,1,20514,2829,0,20257,16385,16645,22561,1284,260,256,20480,16384,772]

theorem envBound3801 : H12AffineFastState.Bounded env3801 := by
  intro p hp
  have h : env3801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3800_3801 : H12AffineEnvironment.transform 12 2861 env3800 = env3801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2861 env3800 == env3801) = true)

theorem identity3801 : scanCanonicalize (H12AffineFastState.compose env3801 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 2351) := by decide +kernel

theorem selectedBound3801 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env3802 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,4096,2861,2351,4618,2562,4357,1582,1024,4618,4097,33,1,6413,2829,0,1550,2350,2090,4366,1284,260,256,6447,2351,772]

theorem envBound3802 : H12AffineFastState.Bounded env3802 := by
  intro p hp
  have h : env3802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3801_3802 : H12AffineEnvironment.transform 13 2351 env3801 = env3802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2351 env3801 == env3802) = true)

theorem identity3802 : scanCanonicalize (H12AffineFastState.compose env3802 (packedSelected [13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound3802 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3803 : List Nat := [2,4,8,0,32,0,41,256,512,1024,1803,4096,1062,1572,4618,1289,4357,1582,1024,4618,4097,33,1,5638,1030,0,1550,1573,1825,4366,1284,260,256,5668,1572,772]

theorem envBound3803 : H12AffineFastState.Bounded env3803 := by
  intro p hp
  have h : env3803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3802_3803 : H12AffineEnvironment.transform 10 1803 env3802 = env3803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env3802 == env3803) = true)

theorem identity3803 : scanCanonicalize (H12AffineFastState.compose env3803 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound3803 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env3804 : List Nat := [2,4,8,0,32,0,41,256,512,1024,1803,1573,1062,1572,1071,1289,1824,1582,1024,1071,1572,33,1,35,1030,0,1550,1573,1825,1835,1284,260,256,1,1572,772]

theorem envBound3804 : H12AffineFastState.Bounded env3804 := by
  intro p hp
  have h : env3804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3803_3804 : H12AffineEnvironment.transform 11 1573 env3803 = env3804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env3803 == env3804) = true)

theorem identity3804 : scanCanonicalize (H12AffineFastState.compose env3804 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound3804 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3805 : List Nat := [2,4,8,0,32,0,41,46,512,1024,1573,1573,1062,1572,1071,1063,1550,1582,1024,1071,1572,33,1,35,1030,0,1550,1573,1551,1541,1066,42,46,1,1572,554]

theorem envBound3805 : H12AffineFastState.Bounded env3805 := by
  intro p hp
  have h : env3805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3804_3805 : H12AffineEnvironment.transform 7 46 env3804 = env3805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env3804 == env3805) = true)

theorem identity3805 : scanCanonicalize (H12AffineFastState.compose env3805 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound3805 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env3806 : List Nat := [2,4,8,0,11,0,2,5,512,1024,1550,1550,1037,1551,1028,1036,1550,1541,1024,1028,1551,10,1,8,1030,0,1550,1550,1551,1541,1025,1,5,1,1551,513]

theorem envBound3806 : H12AffineFastState.Bounded env3806 := by
  intro p hp
  have h : env3806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3805_3806 : H12AffineEnvironment.transform 4 11 env3805 = env3806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env3805 == env3806) = true)

theorem identity3806 : scanCanonicalize (H12AffineFastState.compose env3806 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound3806 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3807 : List Nat := [2,4,8,0,11,0,2,5,4,1024,1034,1034,1037,1035,1028,1036,1034,1025,1024,1028,1035,10,1,8,1030,0,1034,1034,1035,1025,1025,1,5,1,1035,5]

theorem envBound3807 : H12AffineFastState.Bounded env3807 := by
  intro p hp
  have h : env3807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3806_3807 : H12AffineEnvironment.transform 8 4 env3806 = env3807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env3806 == env3807) = true)

theorem identity3807 : scanCanonicalize (H12AffineFastState.compose env3807 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3807 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env3808 : List Nat := [2,0,8,0,11,0,2,1,0,1024,1034,1034,1033,1035,1024,1032,1034,1025,1024,1024,1035,10,1,8,1026,0,1034,1034,1035,1025,1025,1,1,1,1035,1]

theorem envBound3808 : H12AffineFastState.Bounded env3808 := by
  intro p hp
  have h : env3808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3807_3808 : H12AffineEnvironment.transform 1 0 env3807 = env3808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3807 == env3808) = true)

theorem identity3808 : scanCanonicalize (H12AffineFastState.compose env3808 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 11) := by decide +kernel

theorem selectedBound3808 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3809 : List Nat := [2,0,8,0,11,0,2,1,0,11,1,1,2,0,11,3,1,10,11,11,0,10,1,8,9,0,1,1,0,10,10,1,1,1,0,1]

theorem envBound3809 : H12AffineFastState.Bounded env3809 := by
  intro p hp
  have h : env3809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3808_3809 : H12AffineEnvironment.transform 9 11 env3808 = env3809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 11 env3808 == env3809) = true)

def leafEnv3809 : List Nat := [2,0,8,0,11,0,2,1,0,11,1,1,2,0,11,3,1,10,11,11,0,10,1,8,10,9,1,0,1,1,0,10,10,1,1,1,0,8,0,1,1,0,0]

def active3809 : List Nat := [0,2]

def tree3809 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3809 : H12WitnessSearch.Good tree3809 := H12GlobalWitnessIndex.good

theorem leafIdentity3809 : H12AffineFastState.composeSystem env3809 rootObs = leafEnv3809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3809 rootObs == leafEnv3809) = true)

theorem terminalChecked3809 : H12PackedTerminal.terminalCheckFast leafEnv3809 active3809 tree3809 = true := by decide +kernel

def env3810 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,137,61617,41002,8329,61616,323713,16385,16812,22561,74795,260,256,20480,102694,62221]

theorem envBound3810 : H12AffineFastState.Bounded env3810 := by
  intro p hp
  have h : env3810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3782_3810 : H12AffineEnvironment.transform 21 137 env3782 = env3810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 137 env3782 == env3810) = true)

theorem identity3810 : scanCanonicalize (H12AffineFastState.compose env3810 (packedSelected [9,17,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 48668) := by decide +kernel

theorem selectedBound3810 : packedSelected [9,17,21,22] rootPS < 2^1333 := by decide +kernel

def env3811 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,48668,1024,32768,4097,137,61617,41002,8329,61616,20125,16385,16812,22561,74795,260,256,20480,102694,62221]

theorem envBound3811 : H12AffineFastState.Bounded env3811 := by
  intro p hp
  have h : env3811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3810_3811 : H12AffineEnvironment.transform 17 48668 env3810 = env3811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48668 env3810 == env3811) = true)

def env3812 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,32768,65536,4372,48668,1024,32768,4097,49,61449,41002,8241,61448,20005,16385,16660,22561,74795,260,256,20480,102694,62221]

theorem envBound3812 : H12AffineFastState.Bounded env3812 := by
  intro p hp
  have h : env3812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3811_3812 : H12AffineEnvironment.transform 6 56 env3811 = env3812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env3811 == env3812) = true)

theorem identity3812 : scanCanonicalize (H12AffineFastState.compose env3812 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 53543) := by decide +kernel

theorem selectedBound3812 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env3813 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,32768,53543,4372,48668,1024,32768,4097,49,61449,41002,8241,61448,20005,16385,16660,22561,62732,260,256,20480,16385,62221]

theorem envBound3813 : H12AffineFastState.Bounded env3813 := by
  intro p hp
  have h : env3813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3812_3813 : H12AffineEnvironment.transform 15 53543 env3812 = env3813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53543 env3812 == env3813) = true)

theorem identity3813 : scanCanonicalize (H12AffineFastState.compose env3813 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 28680) := by decide +kernel

theorem selectedBound3813 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3814 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,28680,8495,4372,19988,1024,28680,4097,49,1,20514,8241,0,20005,16385,16660,22561,1284,260,256,20480,16385,773]

theorem envBound3814 : H12AffineFastState.Bounded env3814 := by
  intro p hp
  have h : env3814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3813_3814 : H12AffineEnvironment.transform 14 28680 env3813 = env3814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28680 env3813 == env3814) = true)

theorem identity3814 : scanCanonicalize (H12AffineFastState.compose env3814 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3814 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3815 : List Nat := [2,4,8,0,32,0,40,256,512,1024,2048,4096,8192,16384,28680,8495,4356,19972,1024,28680,4097,33,1,20514,8225,0,20005,16385,16644,22561,1284,260,256,20480,16385,773]

theorem envBound3815 : H12AffineFastState.Bounded env3815 := by
  intro p hp
  have h : env3815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3814_3815 : H12AffineEnvironment.transform 3 0 env3814 = env3815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3814 == env3815) = true)

theorem identity3815 : scanCanonicalize (H12AffineFastState.compose env3815 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2828) := by decide +kernel

theorem selectedBound3815 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env3816 : List Nat := [2,4,8,0,32,0,40,256,512,1024,2048,4096,2828,16384,23300,2595,4356,19972,1024,23300,4097,33,1,20514,2861,0,20005,16385,16644,22561,1284,260,256,20480,16385,773]

theorem envBound3816 : H12AffineFastState.Bounded env3816 := by
  intro p hp
  have h : env3816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3815_3816 : H12AffineEnvironment.transform 12 2828 env3815 = env3816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2828 env3815 == env3816) = true)

theorem identity3816 : scanCanonicalize (H12AffineFastState.compose env3816 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2351) := by decide +kernel

theorem selectedBound3816 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env3817 : List Nat := [2,4,8,0,32,0,40,256,512,1024,2048,2351,2828,16384,16939,2595,2091,19972,1024,16939,2350,33,1,18701,2861,0,20005,16385,16644,16654,1284,260,256,18735,16385,773]

theorem envBound3817 : H12AffineFastState.Bounded env3817 := by
  intro p hp
  have h : env3817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3816_3817 : H12AffineEnvironment.transform 11 2351 env3816 = env3817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2351 env3816 == env3817) = true)

theorem identity3817 : scanCanonicalize (H12AffineFastState.compose env3817 (packedSelected [13,17] rootPS)) = affineNative (2^(13+1) ^^^ 1824) := by decide +kernel

theorem selectedBound3817 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3818 : List Nat := [2,4,8,0,32,0,40,256,512,1024,2048,2351,2828,1824,1291,2595,2091,2340,1024,1291,2350,33,1,3629,2861,0,2309,1825,1572,1582,1284,260,256,3599,1825,773]

theorem envBound3818 : H12AffineFastState.Bounded env3818 := by
  intro p hp
  have h : env3818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3817_3818 : H12AffineEnvironment.transform 13 1824 env3817 = env3818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1824 env3817 == env3818) = true)

theorem identity3818 : scanCanonicalize (H12AffineFastState.compose env3818 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3818 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3819 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,2090,2569,1573,1038,2595,2091,2081,1024,1038,2091,33,1,3629,2600,0,2048,1572,1572,1582,1025,1,5,3599,1572,512]

theorem envBound3819 : H12AffineFastState.Bounded env3819 := by
  intro p hp
  have h : env3819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3818_3819 : H12AffineEnvironment.transform 7 5 env3818 = env3819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3818 == env3819) = true)

theorem identity3819 : scanCanonicalize (H12AffineFastState.compose env3819 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3819 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env3820 : List Nat := [2,4,2,0,32,0,34,5,512,1024,2048,2080,2563,1573,1028,2595,2081,2081,1024,1028,2081,33,1,3623,2594,0,2048,1572,1572,1572,1025,1,5,3589,1572,512]

theorem envBound3820 : H12AffineFastState.Bounded env3820 := by
  intro p hp
  have h : env3820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3819_3820 : H12AffineEnvironment.transform 2 2 env3819 = env3820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3819 == env3820) = true)

theorem identity3820 : scanCanonicalize (H12AffineFastState.compose env3820 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3820 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env3821 : List Nat := [2,4,2,0,32,0,34,5,512,5,2048,2080,2563,544,1,2595,2081,2081,5,1,2081,33,1,2594,2594,0,2048,545,545,545,4,1,5,2560,545,512]

theorem envBound3821 : H12AffineFastState.Bounded env3821 := by
  intro p hp
  have h : env3821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3820_3821 : H12AffineEnvironment.transform 9 5 env3820 = env3821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3820 == env3821) = true)

def env3822 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,32768,65536,4373,48668,1024,32768,4097,48,61448,41002,8240,61449,20004,16385,16661,22561,74795,260,256,20480,102694,62221]

theorem envBound3822 : H12AffineFastState.Bounded env3822 := by
  intro p hp
  have h : env3822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3811_3822 : H12AffineEnvironment.transform 6 57 env3811 = env3822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env3811 == env3822) = true)

theorem identity3822 : scanCanonicalize (H12AffineFastState.compose env3822 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 28680) := by decide +kernel

theorem selectedBound3822 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env3823 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,28680,65536,4373,19988,1024,28680,4097,48,0,20514,8240,1,20004,16385,16661,22561,74795,260,256,20480,90414,773]

theorem envBound3823 : H12AffineFastState.Bounded env3823 := by
  intro p hp
  have h : env3823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3822_3823 : H12AffineEnvironment.transform 14 28680 env3822 = env3823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28680 env3822 == env3823) = true)

theorem identity3823 : scanCanonicalize (H12AffineFastState.compose env3823 (packedSelected [5,13,21,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound3823 : packedSelected [5,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env3824 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,28680,8251,4373,19988,1024,28680,4097,48,0,20514,8240,1,20004,16385,16661,22561,1040,260,256,20480,16661,773]

theorem envBound3824 : H12AffineFastState.Bounded env3824 := by
  intro p hp
  have h : env3824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3823_3824 : H12AffineEnvironment.transform 15 8251 env3823 = env3824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env3823 == env3824) = true)

theorem identity3824 : scanCanonicalize (H12AffineFastState.compose env3824 (packedSelected [0,27] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound3824 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env3825 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,1573,8192,16384,26157,8251,1840,19988,1024,26157,1572,48,0,17927,8240,1,20004,16385,16661,19972,1040,260,256,17957,16661,773]

theorem envBound3825 : H12AffineFastState.Bounded env3825 := by
  intro p hp
  have h : env3825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3824_3825 : H12AffineEnvironment.transform 11 1573 env3824 = env3825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env3824 == env3825) = true)

theorem identity3825 : scanCanonicalize (H12AffineFastState.compose env3825 (packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 8999) := by decide +kernel

theorem selectedBound3825 : packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env3826 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,1573,8192,8999,1290,8251,1840,11571,1024,1290,1572,48,0,9504,8240,1,11523,8998,8754,11555,1040,260,256,9474,8754,773]

theorem envBound3826 : H12AffineFastState.Bounded env3826 := by
  intro p hp
  have h : env3826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3825_3826 : H12AffineEnvironment.transform 13 8999 env3825 = env3826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8999 env3825 == env3826) = true)

theorem identity3826 : scanCanonicalize (H12AffineFastState.compose env3826 (packedSelected [0,3,4,5,7,9,10,17,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound3826 : packedSelected [0,3,4,5,7,9,10,17,21] rootPS < 2^1333 := by decide +kernel

def env3827 : List Nat := [2,4,8,16,32,16,57,21,512,1024,2048,1573,8192,8754,1055,8251,1573,11302,1024,1055,1572,48,0,9269,8240,1,11286,8755,8754,11318,1040,17,21,9239,8754,528]

theorem envBound3827 : H12AffineFastState.Bounded env3827 := by
  intro p hp
  have h : env3827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3826_3827 : H12AffineEnvironment.transform 7 21 env3826 = env3827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env3826 == env3827) = true)

theorem identity3827 : scanCanonicalize (H12AffineFastState.compose env3827 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 3613) := by decide +kernel

theorem selectedBound3827 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3828 : List Nat := [2,4,8,16,32,16,57,21,512,1024,2048,1573,3613,3119,1055,3622,1573,571,1024,1055,1572,48,0,2600,3629,1,523,3118,3119,555,1040,17,21,2570,3119,528]

theorem envBound3828 : H12AffineFastState.Bounded env3828 := by
  intro p hp
  have h : env3828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3827_3828 : H12AffineEnvironment.transform 12 3613 env3827 = env3828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3613 env3827 == env3828) = true)

theorem identity3828 : scanCanonicalize (H12AffineFastState.compose env3828 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound3828 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3829 : List Nat := [2,4,8,16,32,16,57,21,512,1024,538,1573,1031,1589,1055,1084,1573,571,1024,1055,1572,48,0,50,1079,1,523,1588,1589,555,1040,17,21,16,1589,528]

theorem envBound3829 : H12AffineFastState.Bounded env3829 := by
  intro p hp
  have h : env3829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3828_3829 : H12AffineEnvironment.transform 10 538 env3828 = env3829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env3828 == env3829) = true)

theorem identity3829 : scanCanonicalize (H12AffineFastState.compose env3829 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3829 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3830 : List Nat := [2,4,8,16,0,16,25,21,512,1024,538,1541,1031,1557,1055,1052,1541,539,1024,1055,1540,16,0,18,1047,1,523,1556,1557,523,1040,17,21,16,1557,528]

theorem envBound3830 : H12AffineFastState.Bounded env3830 := by
  intro p hp
  have h : env3830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3829_3830 : H12AffineEnvironment.transform 4 0 env3829 = env3830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3829 == env3830) = true)

theorem identity3830 : scanCanonicalize (H12AffineFastState.compose env3830 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3830 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3831 : List Nat := [2,4,8,16,0,16,25,21,512,5,538,512,2,528,26,25,512,539,5,26,513,16,0,18,18,1,523,529,528,523,21,17,21,16,528,528]

theorem envBound3831 : H12AffineFastState.Bounded env3831 := by
  intro p hp
  have h : env3831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3830_3831 : H12AffineEnvironment.transform 9 5 env3830 = env3831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3830 == env3831) = true)

theorem identity3831 : scanCanonicalize (H12AffineFastState.compose env3831 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound3831 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3832 : List Nat := [2,4,8,16,0,16,25,21,27,5,1,27,2,11,26,25,27,0,5,26,26,16,0,18,18,1,16,10,11,16,21,17,21,16,11,11]

theorem envBound3832 : H12AffineFastState.Bounded env3832 := by
  intro p hp
  have h : env3832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3831_3832 : H12AffineEnvironment.transform 8 27 env3831 = env3832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env3831 == env3832) = true)

def env3833 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,4255800,41002,8329,4255800,323712,16385,16813,22560,74795,260,256,20481,4297135,4256645]

theorem envBound3833 : H12AffineFastState.Bounded env3833 := by
  intro p hp
  have h : env3833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3781_3833 : H12AffineEnvironment.transform 5 17 env3781 = env3833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3781 == env3833) = true)

theorem identity3833 : scanCanonicalize (H12AffineFastState.compose env3833 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 61829) := by decide +kernel

theorem selectedBound3833 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3834 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,61829,445,41002,8329,445,323712,16385,16813,22560,74795,260,256,20481,90154,512]

theorem envBound3834 : H12AffineFastState.Bounded env3834 := by
  intro p hp
  have h : env3834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3833_3834 : H12AffineEnvironment.transform 21 61829 env3833 = env3834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61829 env3833 == env3834) = true)

theorem identity3834 : scanCanonicalize (H12AffineFastState.compose env3834 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound3834 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3835 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,262144,1024,32768,4097,41349,445,41002,8329,445,303232,4097,4525,2080,74795,260,256,1,77866,512]

theorem envBound3835 : H12AffineFastState.Bounded env3835 := by
  intro p hp
  have h : env3835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3834_3835 : H12AffineEnvironment.transform 13 4096 env3834 = env3835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env3834 == env3835) = true)

theorem identity3835 : scanCanonicalize (H12AffineFastState.compose env3835 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38842) := by decide +kernel

theorem selectedBound3835 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3836 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,38842,4525,262144,1024,32768,4097,41349,445,41002,8329,445,303232,4097,4525,2080,45969,260,256,1,42896,512]

theorem envBound3836 : H12AffineFastState.Bounded env3836 := by
  intro p hp
  have h : env3836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3835_3836 : H12AffineEnvironment.transform 15 38842 env3835 = env3836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38842 env3835 == env3836) = true)

theorem identity3836 : scanCanonicalize (H12AffineFastState.compose env3836 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14137) := by decide +kernel

theorem selectedBound3836 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3837 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,14137,8323,4525,262144,1024,14137,4097,5820,445,5907,8329,445,268217,4097,4525,2080,1192,260,256,1,4265,512]

theorem envBound3837 : H12AffineFastState.Bounded env3837 := by
  intro p hp
  have h : env3837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3836_3837 : H12AffineEnvironment.transform 14 14137 env3836 = env3837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14137 env3836 == env3837) = true)

theorem identity3837 : scanCanonicalize (H12AffineFastState.compose env3837 (packedSelected [0,13,17,27] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound3837 : packedSelected [0,13,17,27] rootPS < 2^1333 := by decide +kernel

def env3838 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,14137,8323,4525,2184,1024,14137,4097,5820,445,5907,8329,445,7985,4097,4525,2080,1192,260,256,1,4265,512]

theorem envBound3838 : H12AffineFastState.Bounded env3838 := by
  intro p hp
  have h : env3838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3837_3838 : H12AffineEnvironment.transform 17 2184 env3837 = env3838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env3837 == env3838) = true)

theorem identity3838 : scanCanonicalize (H12AffineFastState.compose env3838 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound3838 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env3839 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4096,13972,8323,4096,2184,1024,13972,4097,5820,16,5822,8329,16,7836,4097,4096,2080,1192,169,173,1,4265,512]

theorem envBound3839 : H12AffineFastState.Bounded env3839 := by
  intro p hp
  have h : env3839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3838_3839 : H12AffineEnvironment.transform 7 173 env3838 = env3839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env3838 == env3839) = true)

theorem identity3839 : scanCanonicalize (H12AffineFastState.compose env3839 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound3839 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3840 : List Nat := [2,4,8,16,32,17,128,173,512,1024,523,4096,8192,4096,13972,8323,4096,643,1024,13972,4097,5820,16,5822,8329,16,5271,4097,4096,555,1192,169,173,1,4265,512]

theorem envBound3840 : H12AffineFastState.Bounded env3840 := by
  intro p hp
  have h : env3840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3839_3840 : H12AffineEnvironment.transform 10 523 env3839 = env3840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env3839 == env3840) = true)

theorem identity3840 : scanCanonicalize (H12AffineFastState.compose env3840 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound3840 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3841 : List Nat := [2,4,8,16,32,17,128,173,512,1024,523,1692,8192,1692,8200,8323,1692,643,1024,8200,1693,32,16,34,8329,16,523,1693,1692,555,1192,169,173,1,1589,512]

theorem envBound3841 : H12AffineFastState.Bounded env3841 := by
  intro p hp
  have h : env3841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3840_3841 : H12AffineEnvironment.transform 11 1692 env3840 = env3841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env3840 == env3841) = true)

theorem identity3841 : scanCanonicalize (H12AffineFastState.compose env3841 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 170) := by decide +kernel

theorem selectedBound3841 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3842 : List Nat := [2,4,8,16,32,17,128,173,512,1024,523,1692,170,1692,162,41,1692,643,1024,162,1693,32,16,34,35,16,523,1693,1692,555,1192,169,173,1,1589,512]

theorem envBound3842 : H12AffineFastState.Bounded env3842 := by
  intro p hp
  have h : env3842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3841_3842 : H12AffineEnvironment.transform 12 170 env3841 = env3842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 170 env3841 == env3842) = true)

theorem identity3842 : scanCanonicalize (H12AffineFastState.compose env3842 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound3842 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env3843 : List Nat := [2,4,8,16,32,17,3,46,512,1024,523,1567,41,1567,33,41,1567,512,1024,33,1566,32,16,34,35,16,523,1566,1567,555,1067,42,46,1,1589,512]

theorem envBound3843 : H12AffineFastState.Bounded env3843 := by
  intro p hp
  have h : env3843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3842_3843 : H12AffineEnvironment.transform 6 3 env3842 = env3843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env3842 == env3843) = true)

theorem identity3843 : scanCanonicalize (H12AffineFastState.compose env3843 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3843 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env3844 : List Nat := [2,4,8,16,0,17,3,14,512,1024,523,1567,9,1567,1,9,1567,512,1024,1,1566,0,16,2,3,16,523,1566,1567,523,1035,10,14,1,1557,512]

theorem envBound3844 : H12AffineFastState.Bounded env3844 := by
  intro p hp
  have h : env3844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3843_3844 : H12AffineEnvironment.transform 4 0 env3843 = env3844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3843 == env3844) = true)

theorem identity3844 : scanCanonicalize (H12AffineFastState.compose env3844 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3844 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3845 : List Nat := [2,4,8,16,0,17,3,14,0,1024,11,1055,9,1055,1,9,1055,0,1024,1,1054,0,16,2,3,16,11,1054,1055,11,1035,10,14,1,1045,0]

theorem envBound3845 : H12AffineFastState.Bounded env3845 := by
  intro p hp
  have h : env3845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3844_3845 : H12AffineEnvironment.transform 8 0 env3844 = env3845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3844 == env3845) = true)

theorem identity3845 : scanCanonicalize (H12AffineFastState.compose env3845 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3845 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3846 : List Nat := [2,4,8,1,0,0,3,14,0,1024,11,1038,9,1038,1,9,1038,0,1024,1,1039,0,1,2,3,1,11,1039,1038,11,1035,10,14,1,1028,0]

theorem envBound3846 : H12AffineFastState.Bounded env3846 := by
  intro p hp
  have h : env3846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3845_3846 : H12AffineEnvironment.transform 3 1 env3845 = env3846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3845 == env3846) = true)

theorem identity3846 : scanCanonicalize (H12AffineFastState.compose env3846 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3846 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env3847 : List Nat := [2,4,2,1,0,0,3,4,0,1024,1,1028,3,1028,1,3,1028,0,1024,1,1029,0,1,2,3,1,1,1029,1028,1,1025,0,4,1,1028,0]

theorem envBound3847 : H12AffineFastState.Bounded env3847 := by
  intro p hp
  have h : env3847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3846_3847 : H12AffineEnvironment.transform 2 2 env3846 = env3847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3846 == env3847) = true)

def leafEnv3847 : List Nat := [2,4,2,1,0,0,3,4,0,1024,1,1028,3,1028,1,3,1028,0,1024,1,1029,0,1,2,1025,3,1,1,1,1029,1028,1,1025,0,4,1,4,2,1028,0,1,1028,0]

def active3847 : List Nat := [0,1,9]

def tree3847 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3847 : H12WitnessSearch.Good tree3847 := H12GlobalWitnessIndex.good

theorem leafIdentity3847 : H12AffineFastState.composeSystem env3847 rootObs = leafEnv3847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3847 rootObs == leafEnv3847) = true)

theorem terminalChecked3847 : H12PackedTerminal.terminalCheckFast leafEnv3847 active3847 tree3847 = true := by decide +kernel

def env3848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41002,8329,8388688,323792,16385,16892,22640,74794,12644668,257,20561,8479127,8389613]

theorem envBound3848 : H12AffineFastState.Bounded env3848 := by
  intro p hp
  have h : env3848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3779_3848 : H12AffineEnvironment.transform 18 1025 env3779 = env3848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3779 == env3848) = true)

theorem identity3848 : scanCanonicalize (H12AffineFastState.compose env3848 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 46392) := by decide +kernel

theorem selectedBound3848 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,46392,8388608,41002,8329,8388688,323792,16385,16892,22640,74794,8406020,257,20561,8479127,8389613]

theorem envBound3849 : H12AffineFastState.Bounded env3849 := by
  intro p hp
  have h : env3849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3848_3849 : H12AffineEnvironment.transform 21 46392 env3848 = env3849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46392 env3848 == env3849) = true)

def env3850 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,46392,8388608,41002,8329,8388608,323712,16385,16812,22560,74794,8406020,257,20481,8479127,8389565]

theorem envBound3850 : H12AffineFastState.Bounded env3850 := by
  intro p hp
  have h : env3850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3849_3850 : H12AffineEnvironment.transform 5 16 env3849 = env3850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3849 == env3850) = true)

theorem identity3850 : scanCanonicalize (H12AffineFastState.compose env3850 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound3850 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3851 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,46392,445,41002,8329,445,323712,16385,16812,22560,74794,17849,257,20481,90154,512]

theorem envBound3851 : H12AffineFastState.Bounded env3851 := by
  intro p hp
  have h : env3851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3850_3851 : H12AffineEnvironment.transform 22 445 env3850 = env3851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env3850 == env3851) = true)

theorem identity3851 : scanCanonicalize (H12AffineFastState.compose env3851 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound3851 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3852 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,65536,1296,262144,1025,32768,1213,41348,445,41002,8329,445,320572,16385,16812,19612,74794,17849,257,17597,90154,512]

theorem envBound3852 : H12AffineFastState.Bounded env3852 := by
  intro p hp
  have h : env3852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3851_3852 : H12AffineEnvironment.transform 11 1212 env3851 = env3852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env3851 == env3852) = true)

theorem identity3852 : scanCanonicalize (H12AffineFastState.compose env3852 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33542) := by decide +kernel

theorem selectedBound3852 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3853 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,33542,1296,262144,1025,32768,1213,41348,445,41002,8329,445,320572,16385,16812,19612,42796,17849,257,17597,58156,512]

theorem envBound3853 : H12AffineFastState.Bounded env3853 := by
  intro p hp
  have h : env3853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3852_3853 : H12AffineEnvironment.transform 15 33542 env3852 = env3853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33542 env3852 == env3853) = true)

theorem identity3853 : scanCanonicalize (H12AffineFastState.compose env3853 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26425) := by decide +kernel

theorem selectedBound3853 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3854 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,26425,25663,1296,262144,1025,26425,1213,18109,445,18195,8329,445,262917,16385,16812,19612,16405,17849,257,17597,1045,512]

theorem envBound3854 : H12AffineFastState.Bounded env3854 := by
  intro p hp
  have h : env3854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3853_3854 : H12AffineEnvironment.transform 14 26425 env3853 = env3854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26425 env3853 == env3854) = true)

theorem identity3854 : scanCanonicalize (H12AffineFastState.compose env3854 (packedSelected [0,8,10,12,15,18,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 1693) := by decide +kernel

theorem selectedBound3854 : packedSelected [0,8,10,12,15,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env3855 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,1693,8612,8866,1296,262144,1025,8612,1213,32,445,398,8329,445,262917,1692,1841,2561,1672,804,257,544,1045,512]

theorem envBound3855 : H12AffineFastState.Bounded env3855 := by
  intro p hp
  have h : env3855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3854_3855 : H12AffineEnvironment.transform 13 1693 env3854 = env3855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1693 env3854 == env3855) = true)

theorem identity3855 : scanCanonicalize (H12AffineFastState.compose env3855 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3855 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env3856 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1044,8192,1589,8460,8714,1296,262144,1025,8460,1045,32,277,294,8225,277,262917,1588,1841,2561,1568,804,257,544,1045,512]

theorem envBound3856 : H12AffineFastState.Bounded env3856 := by
  intro p hp
  have h : env3856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3855_3856 : H12AffineEnvironment.transform 6 40 env3855 = env3856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3855 == env3856) = true)

theorem identity3856 : scanCanonicalize (H12AffineFastState.compose env3856 (packedSelected [2,3,6,10,13] rootPS)) = affineNative (2^(17+1) ^^^ 9496) := by decide +kernel

theorem selectedBound3856 : packedSelected [2,3,6,10,13] rootPS < 2^1333 := by decide +kernel

def env3857 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1044,8192,1589,8460,8714,1296,9496,1025,8460,1045,32,277,294,8225,277,9757,1588,1841,2561,1568,804,257,544,1045,512]

theorem envBound3857 : H12AffineFastState.Bounded env3857 := by
  intro p hp
  have h : env3857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3856_3857 : H12AffineEnvironment.transform 17 9496 env3856 = env3857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9496 env3856 == env3857) = true)

theorem identity3857 : scanCanonicalize (H12AffineFastState.compose env3857 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3857 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env3858 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1044,8192,1589,8201,8714,1045,9245,1025,8201,1045,32,16,35,8225,16,9757,1588,1588,2561,1568,545,4,544,1045,512]

theorem envBound3858 : H12AffineFastState.Bounded env3858 := by
  intro p hp
  have h : env3858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3857_3858 : H12AffineEnvironment.transform 7 5 env3857 = env3858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3857 == env3858) = true)

theorem identity3858 : scanCanonicalize (H12AffineFastState.compose env3858 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1582) := by decide +kernel

theorem selectedBound3858 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3859 : List Nat := [2,4,8,16,32,16,40,5,512,1024,1582,1044,8192,1589,8201,8714,1045,9245,1025,8201,1045,32,16,35,8225,16,9757,1588,1588,1071,1568,545,4,544,1045,512]

theorem envBound3859 : H12AffineFastState.Bounded env3859 := by
  intro p hp
  have h : env3859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3858_3859 : H12AffineEnvironment.transform 10 1582 env3858 = env3859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1582 env3858 == env3859) = true)

theorem identity3859 : scanCanonicalize (H12AffineFastState.compose env3859 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 563) := by decide +kernel

theorem selectedBound3859 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3860 : List Nat := [2,4,8,16,32,16,40,5,512,1024,1582,1044,563,1589,570,57,1045,1582,1025,570,1045,32,16,35,530,16,1070,1588,1588,1071,1568,545,4,544,1045,512]

theorem envBound3860 : H12AffineFastState.Bounded env3860 := by
  intro p hp
  have h : env3860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3859_3860 : H12AffineEnvironment.transform 12 563 env3859 = env3860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 563 env3859 == env3860) = true)

theorem identity3860 : scanCanonicalize (H12AffineFastState.compose env3860 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound3860 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3861 : List Nat := [2,4,8,16,32,16,40,5,512,564,26,544,563,1,570,57,545,26,565,570,545,32,16,35,530,16,538,0,0,539,20,545,4,544,545,512]

theorem envBound3861 : H12AffineFastState.Bounded env3861 := by
  intro p hp
  have h : env3861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3860_3861 : H12AffineEnvironment.transform 9 564 env3860 = env3861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env3860 == env3861) = true)

theorem identity3861 : scanCanonicalize (H12AffineFastState.compose env3861 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound3861 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3862 : List Nat := [2,4,8,16,32,16,40,5,26,46,26,58,41,1,32,57,59,26,47,32,59,32,16,35,8,16,0,0,0,1,20,59,4,58,59,26]

theorem envBound3862 : H12AffineFastState.Bounded env3862 := by
  intro p hp
  have h : env3862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3861_3862 : H12AffineEnvironment.transform 8 26 env3861 = env3862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env3861 == env3862) = true)

theorem identity3862 : scanCanonicalize (H12AffineFastState.compose env3862 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3862 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env3863 : List Nat := [2,4,8,10,32,10,40,5,0,46,0,32,41,1,32,35,33,0,47,32,33,32,10,35,8,10,0,0,0,1,14,33,4,32,33,0]

theorem envBound3863 : H12AffineFastState.Bounded env3863 := by
  intro p hp
  have h : env3863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3862_3863 : H12AffineEnvironment.transform 3 10 env3862 = env3863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3862 == env3863) = true)

theorem identity3863 : scanCanonicalize (H12AffineFastState.compose env3863 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3863 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3864 : List Nat := [2,4,8,10,0,10,8,5,0,14,0,0,9,1,0,3,1,0,15,0,1,0,10,3,8,10,0,0,0,1,14,1,4,0,1,0]

theorem envBound3864 : H12AffineFastState.Bounded env3864 := by
  intro p hp
  have h : env3864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3863_3864 : H12AffineEnvironment.transform 4 0 env3863 = env3864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3863 == env3864) = true)

def env3865 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,46392,8388608,41002,8329,8388609,323713,16385,16813,22561,74794,8406020,257,20480,8479127,8389564]

theorem envBound3865 : H12AffineFastState.Bounded env3865 := by
  intro p hp
  have h : env3865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3849_3865 : H12AffineEnvironment.transform 5 17 env3849 = env3865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3849 == env3865) = true)

def env3866 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1025,32768,4097,46212,8388608,41002,8329,8388609,323713,16385,16401,22561,74794,8406020,189,20480,8478763,8389120]

theorem envBound3866 : H12AffineFastState.Bounded env3866 := by
  intro p hp
  have h : env3866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3865_3866 : H12AffineEnvironment.transform 7 188 env3865 = env3866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env3865 == env3866) = true)

theorem identity3866 : scanCanonicalize (H12AffineFastState.compose env3866 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 46260) := by decide +kernel

theorem selectedBound3866 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3867 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1025,32768,4097,46212,46260,41002,8329,46261,323713,16385,16401,22561,74794,61616,189,20480,119967,46772]

theorem envBound3867 : H12AffineFastState.Bounded env3867 := by
  intro p hp
  have h : env3867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3866_3867 : H12AffineEnvironment.transform 22 46260 env3866 = env3867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 46260 env3866 == env3867) = true)

def env3868 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1025,32768,4097,46212,46244,41002,8329,46245,323713,16385,16385,22561,74794,61600,173,20480,119951,46756]

theorem envBound3868 : H12AffineFastState.Bounded env3868 := by
  intro p hp
  have h : env3868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3867_3868 : H12AffineEnvironment.transform 3 0 env3867 = env3868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3867 == env3868) = true)

theorem identity3868 : scanCanonicalize (H12AffineFastState.compose env3868 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3868 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3869 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1025,32768,4097,46125,46093,41002,8224,46092,323624,16385,16385,22561,74794,61449,4,20480,119846,46605]

theorem envBound3869 : H12AffineFastState.Bounded env3869 := by
  intro p hp
  have h : env3869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3868_3869 : H12AffineEnvironment.transform 6 41 env3868 = env3869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3868 == env3869) = true)

theorem identity3869 : scanCanonicalize (H12AffineFastState.compose env3869 (packedSelected [1,3,4,8,9,10,13,18,20,21,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound3869 : packedSelected [1,3,4,8,9,10,13,18,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env3870 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,16384,32768,53282,4097,262144,1025,32768,4097,46125,46093,41002,8224,46092,323624,16385,16385,22561,62472,61449,4,20480,1028,46605]

theorem envBound3870 : H12AffineFastState.Bounded env3870 := by
  intro p hp
  have h : env3870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3869_3870 : H12AffineEnvironment.transform 15 53282 env3869 = env3870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env3869 == env3870) = true)

theorem identity3870 : scanCanonicalize (H12AffineFastState.compose env3870 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 22528) := by decide +kernel

theorem selectedBound3870 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env3871 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,16384,32768,53282,4097,22528,1025,32768,4097,46125,46093,41002,8224,46092,43048,16385,16385,22561,62472,61449,4,20480,1028,46605]

theorem envBound3871 : H12AffineFastState.Bounded env3871 := by
  intro p hp
  have h : env3871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3870_3871 : H12AffineEnvironment.transform 17 22528 env3870 = env3871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22528 env3870 == env3871) = true)

theorem identity3871 : scanCanonicalize (H12AffineFastState.compose env3871 (packedSelected [0,1,3,4,5,6,7,8,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 7727) := by decide +kernel

theorem selectedBound3871 : packedSelected [0,1,3,4,5,6,7,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env3872 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,7727,32768,36365,4097,1583,1025,32768,4097,46125,46093,41002,8224,46092,43048,7726,7726,1550,43559,44582,4,3631,1028,46605]

theorem envBound3872 : H12AffineFastState.Bounded env3872 := by
  intro p hp
  have h : env3872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3871_3872 : H12AffineEnvironment.transform 13 7727 env3871 = env3872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7727 env3871 == env3872) = true)

theorem identity3872 : scanCanonicalize (H12AffineFastState.compose env3872 (packedSelected [0,3,4,5,6,7,9,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 1574) := by decide +kernel

theorem selectedBound3872 : packedSelected [0,3,4,5,6,7,9,12,17] rootPS < 2^1333 := by decide +kernel

def env3873 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,1574,7727,32768,36365,4097,1583,1025,32768,4097,37387,37419,34316,1542,37418,36366,7726,7726,1550,35841,34816,4,3631,1028,36907]

theorem envBound3873 : H12AffineFastState.Bounded env3873 := by
  intro p hp
  have h : env3873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3872_3873 : H12AffineEnvironment.transform 12 1574 env3872 = env3873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1574 env3872 == env3873) = true)

theorem identity3873 : scanCanonicalize (H12AffineFastState.compose env3873 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 4651) := by decide +kernel

theorem selectedBound3873 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env3874 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,1574,7727,4651,7206,4097,1583,1025,4651,4097,32,0,5159,1542,1,7205,7726,7726,1550,7722,6699,4,3631,1028,512]

theorem envBound3874 : H12AffineFastState.Bounded env3874 := by
  intro p hp
  have h : env3874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3873_3874 : H12AffineEnvironment.transform 14 4651 env3873 = env3874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4651 env3873 == env3874) = true)

theorem identity3874 : scanCanonicalize (H12AffineFastState.compose env3874 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound3874 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3875 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1038,4096,1574,4641,4651,4136,4097,1583,1025,4651,4097,32,0,5159,1542,1,4139,4640,4640,1550,4644,5669,4,545,1028,512]

theorem envBound3875 : H12AffineFastState.Bounded env3875 := by
  intro p hp
  have h : env3875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3874_3875 : H12AffineEnvironment.transform 10 1038 env3874 = env3875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env3874 == env3875) = true)

theorem identity3875 : scanCanonicalize (H12AffineFastState.compose env3875 (packedSelected [1,2,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound3875 : packedSelected [1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env3876 : List Nat := [2,4,8,0,32,1,41,5,11,1024,1038,4096,1069,4138,4128,4136,4097,1060,1025,4128,4097,32,0,5159,1037,1,4139,4139,4139,1029,4143,5166,4,42,1028,11]

theorem envBound3876 : H12AffineFastState.Bounded env3876 := by
  intro p hp
  have h : env3876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3875_3876 : H12AffineEnvironment.transform 8 11 env3875 = env3876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env3875 == env3876) = true)

theorem identity3876 : scanCanonicalize (H12AffineFastState.compose env3876 (packedSelected [1,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1039) := by decide +kernel

theorem selectedBound3876 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env3877 : List Nat := [2,4,8,0,32,1,41,5,11,1024,1038,1039,1069,1061,1071,1063,1038,1060,1025,1071,1038,32,0,40,1037,1,1060,1060,1060,1029,1056,33,4,42,1028,11]

theorem envBound3877 : H12AffineFastState.Bounded env3877 := by
  intro p hp
  have h : env3877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3876_3877 : H12AffineEnvironment.transform 11 1039 env3876 = env3877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1039 env3876 == env3877) = true)

theorem identity3877 : scanCanonicalize (H12AffineFastState.compose env3877 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3877 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env3878 : List Nat := [2,4,8,0,32,1,41,5,11,5,11,10,40,32,42,34,11,33,4,42,11,32,0,40,8,1,33,33,33,0,37,33,4,42,1,11]

theorem envBound3878 : H12AffineFastState.Bounded env3878 := by
  intro p hp
  have h : env3878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3877_3878 : H12AffineEnvironment.transform 9 5 env3877 = env3878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3877 == env3878) = true)

theorem identity3878 : scanCanonicalize (H12AffineFastState.compose env3878 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3878 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3879 : List Nat := [2,4,8,0,0,1,9,5,11,5,11,10,8,0,10,2,11,1,4,10,11,0,0,8,8,1,1,1,1,0,5,1,4,10,1,11]

theorem envBound3879 : H12AffineFastState.Bounded env3879 := by
  intro p hp
  have h : env3879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3878_3879 : H12AffineEnvironment.transform 4 0 env3878 = env3879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3878 == env3879) = true)

theorem identity3879 : scanCanonicalize (H12AffineFastState.compose env3879 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3879 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3880 : List Nat := [2,4,2,0,0,1,3,5,1,5,1,0,2,0,0,2,1,1,4,0,1,0,0,2,2,1,1,1,1,0,5,1,4,0,1,1]

theorem envBound3880 : H12AffineFastState.Bounded env3880 := by
  intro p hp
  have h : env3880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3879_3880 : H12AffineEnvironment.transform 2 2 env3879 = env3880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3879 == env3880) = true)

def env3881 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1025,32768,4097,46212,46245,41002,8329,46244,323713,16385,16384,22561,74794,61601,172,20480,119950,46757]

theorem envBound3881 : H12AffineFastState.Bounded env3881 := by
  intro p hp
  have h : env3881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3867_3881 : H12AffineEnvironment.transform 3 1 env3867 = env3881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3867 == env3881) = true)

theorem identity3881 : scanCanonicalize (H12AffineFastState.compose env3881 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound3881 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3882 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,32768,28802,4096,262144,1025,32768,4097,46212,46245,41002,8329,46244,323713,16385,16384,22561,21672,61601,172,20480,41996,46757]

theorem envBound3882 : H12AffineFastState.Bounded env3882 := by
  intro p hp
  have h : env3882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3881_3882 : H12AffineEnvironment.transform 15 28802 env3881 = env3882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env3881 == env3882) = true)

theorem identity3882 : scanCanonicalize (H12AffineFastState.compose env3882 (packedSelected [0,5,7,9,20,22,24,26] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound3882 : packedSelected [0,5,7,9,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env3883 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,8192,16384,32768,25646,1196,262144,1025,32768,1197,41000,40969,41002,8329,40968,320557,16385,16384,19597,16388,58381,172,17580,41996,41481]

theorem envBound3883 : H12AffineFastState.Bounded env3883 := by
  intro p hp
  have h : env3883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3882_3883 : H12AffineEnvironment.transform 11 1196 env3882 = env3883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env3882 == env3883) = true)

theorem identity3883 : scanCanonicalize (H12AffineFastState.compose env3883 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 8745) := by decide +kernel

theorem selectedBound3883 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env3884 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,8192,16384,8745,25646,1196,262144,1025,8745,1197,513,544,515,8329,545,280068,16385,16384,19597,16388,17956,172,17580,1573,32]

theorem envBound3884 : H12AffineFastState.Bounded env3884 := by
  intro p hp
  have h : env3884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3883_3884 : H12AffineEnvironment.transform 14 8745 env3883 = env3884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8745 env3883 == env3884) = true)

theorem identity3884 : scanCanonicalize (H12AffineFastState.compose env3884 (packedSelected [0,1,2,3,7,11,12,13,15,17,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound3884 : packedSelected [0,1,2,3,7,11,12,13,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env3885 : List Nat := [2,4,8,1,32,0,128,173,33,1024,2048,1196,8192,16384,8200,25646,1196,262144,1025,8200,1197,32,1,34,8329,0,279589,16385,16384,19597,16388,17413,172,17580,1028,32]

theorem envBound3885 : H12AffineFastState.Bounded env3885 := by
  intro p hp
  have h : env3885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3884_3885 : H12AffineEnvironment.transform 8 33 env3884 = env3885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env3884 == env3885) = true)

theorem identity3885 : scanCanonicalize (H12AffineFastState.compose env3885 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 16395) := by decide +kernel

theorem selectedBound3885 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3886 : List Nat := [2,4,8,1,32,0,128,173,33,1024,2048,1196,8192,16384,8200,25646,1196,16395,1025,8200,1197,32,1,34,8329,0,1070,16385,16384,19597,16388,17413,172,17580,1028,32]

theorem envBound3886 : H12AffineFastState.Bounded env3886 := by
  intro p hp
  have h : env3886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3885_3886 : H12AffineEnvironment.transform 17 16395 env3885 = env3886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16395 env3885 == env3886) = true)

theorem identity3886 : scanCanonicalize (H12AffineFastState.compose env3886 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3886 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3887 : List Nat := [2,4,8,1,32,0,41,4,33,1024,2048,1029,8192,16384,8200,25646,1029,16395,1025,8200,1028,32,1,34,8224,0,1070,16385,16384,19492,16388,17413,5,17413,1028,32]

theorem envBound3887 : H12AffineFastState.Bounded env3887 := by
  intro p hp
  have h : env3887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3886_3887 : H12AffineEnvironment.transform 6 41 env3886 = env3887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3886 == env3887) = true)

theorem identity3887 : scanCanonicalize (H12AffineFastState.compose env3887 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 3081) := by decide +kernel

theorem selectedBound3887 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3888 : List Nat := [2,4,8,1,32,0,41,4,33,1024,2048,1029,3081,16384,3073,18471,1029,16395,1025,3073,1028,32,1,34,3113,0,1070,16385,16384,19492,16388,17413,5,17413,1028,32]

theorem envBound3888 : H12AffineFastState.Bounded env3888 := by
  intro p hp
  have h : env3888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3887_3888 : H12AffineEnvironment.transform 12 3081 env3887 = env3888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3081 env3887 == env3888) = true)

theorem identity3888 : scanCanonicalize (H12AffineFastState.compose env3888 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound3888 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env3889 : List Nat := [2,4,8,1,32,0,41,4,33,1024,1038,1029,7,16384,15,17449,1029,16395,1025,15,1028,32,1,34,39,0,1070,16385,16384,16426,16388,17413,5,17413,1028,32]

theorem envBound3889 : H12AffineFastState.Bounded env3889 := by
  intro p hp
  have h : env3889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3888_3889 : H12AffineEnvironment.transform 10 1038 env3888 = env3889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env3888 == env3889) = true)

theorem identity3889 : scanCanonicalize (H12AffineFastState.compose env3889 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 32) := by decide +kernel

theorem selectedBound3889 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3890 : List Nat := [2,4,8,1,32,0,41,4,33,32,46,37,7,16384,15,16393,37,16395,33,15,36,32,1,34,39,0,14,16385,16384,16426,16388,16421,5,16421,36,32]

theorem envBound3890 : H12AffineFastState.Bounded env3890 := by
  intro p hp
  have h : env3890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3889_3890 : H12AffineEnvironment.transform 9 32 env3889 = env3890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env3889 == env3890) = true)

theorem identity3890 : scanCanonicalize (H12AffineFastState.compose env3890 (packedSelected [0] rootPS)) = affineNative (2^(13+1) ^^^ 10) := by decide +kernel

theorem selectedBound3890 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3891 : List Nat := [2,4,8,1,32,0,41,4,33,32,46,37,7,10,15,3,37,1,33,15,36,32,1,34,39,0,14,11,10,32,14,47,5,47,36,32]

theorem envBound3891 : H12AffineFastState.Bounded env3891 := by
  intro p hp
  have h : env3891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3890_3891 : H12AffineEnvironment.transform 13 10 env3890 = env3891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10 env3890 == env3891) = true)

theorem identity3891 : scanCanonicalize (H12AffineFastState.compose env3891 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound3891 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3892 : List Nat := [2,4,8,1,4,0,13,4,5,4,10,1,7,10,15,3,1,1,5,15,0,4,1,6,3,0,14,11,10,4,14,11,5,11,0,4]

theorem envBound3892 : H12AffineFastState.Bounded env3892 := by
  intro p hp
  have h : env3892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3891_3892 : H12AffineEnvironment.transform 4 4 env3891 = env3892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env3891 == env3892) = true)

theorem identity3892 : scanCanonicalize (H12AffineFastState.compose env3892 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound3892 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3893 : List Nat := [2,4,6,1,4,0,3,4,5,4,4,1,7,4,1,3,1,1,5,1,0,4,1,6,3,0,0,5,4,4,0,5,5,5,0,4]

theorem envBound3893 : H12AffineFastState.Bounded env3893 := by
  intro p hp
  have h : env3893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3892_3893 : H12AffineEnvironment.transform 2 6 env3892 = env3893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env3892 == env3893) = true)

def leafEnv3893 : List Nat := [2,4,6,1,4,0,3,4,5,4,4,1,7,4,1,3,1,1,5,1,0,4,1,6,0,3,1,0,0,5,4,4,0,5,5,5,4,6,0,4,1,5,0]

def active3893 : List Nat := [0,1]

def tree3893 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3893 : H12WitnessSearch.Good tree3893 := H12GlobalWitnessIndex.good

theorem leafIdentity3893 : H12AffineFastState.composeSystem env3893 rootObs = leafEnv3893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3893 rootObs == leafEnv3893) = true)

theorem terminalChecked3893 : H12PackedTerminal.terminalCheckFast leafEnv3893 active3893 tree3893 = true := by decide +kernel

def env3894 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1025,32768,4097,46213,8388608,41002,8329,8388609,323713,16385,16400,22561,74794,8406020,188,20480,8478762,8389121]

theorem envBound3894 : H12AffineFastState.Bounded env3894 := by
  intro p hp
  have h : env3894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3865_3894 : H12AffineEnvironment.transform 7 189 env3865 = env3894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env3865 == env3894) = true)

theorem identity3894 : scanCanonicalize (H12AffineFastState.compose env3894 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 53402) := by decide +kernel

theorem selectedBound3894 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3895 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,53402,4112,262144,1025,32768,4097,46213,8388608,41002,8329,8388609,323713,16385,16400,22561,62640,8406020,188,20480,8433840,8389121]

theorem envBound3895 : H12AffineFastState.Bounded env3895 := by
  intro p hp
  have h : env3895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3894_3895 : H12AffineEnvironment.transform 15 53402 env3894 = env3895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53402 env3894 == env3895) = true)

def env3896 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,4096,8192,16384,32768,53386,4096,262144,1025,32768,4097,46213,8388608,41002,8329,8388609,323713,16385,16384,22561,62624,8406020,172,20480,8433824,8389121]

theorem envBound3896 : H12AffineFastState.Bounded env3896 := by
  intro p hp
  have h : env3896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3895_3896 : H12AffineEnvironment.transform 3 0 env3895 = env3896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3895 == env3896) = true)

theorem identity3896 : scanCanonicalize (H12AffineFastState.compose env3896 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(22+1) ^^^ 5124) := by decide +kernel

theorem selectedBound3896 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3897 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,4096,8192,16384,32768,53386,4096,262144,1025,32768,4097,46213,5124,41002,8329,5125,323713,16385,16384,22561,62624,20480,172,20480,42148,5637]

theorem envBound3897 : H12AffineFastState.Bounded env3897 := by
  intro p hp
  have h : env3897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3896_3897 : H12AffineEnvironment.transform 22 5124 env3896 = env3897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5124 env3896 == env3897) = true)

theorem identity3897 : scanCanonicalize (H12AffineFastState.compose env3897 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3897 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3898 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,16384,32768,53283,4096,262144,1025,32768,4097,46124,5124,41002,8224,5125,323624,16385,16384,22561,62473,20480,5,20480,41997,5637]

theorem envBound3898 : H12AffineFastState.Bounded env3898 := by
  intro p hp
  have h : env3898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3897_3898 : H12AffineEnvironment.transform 6 41 env3897 = env3898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3897 == env3898) = true)

theorem identity3898 : scanCanonicalize (H12AffineFastState.compose env3898 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound3898 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env3899 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,16384,32768,53283,4096,43048,1025,32768,4097,46124,5124,41002,8224,5125,22528,16385,16384,22561,62473,20480,5,20480,41997,5637]

theorem envBound3899 : H12AffineFastState.Bounded env3899 := by
  intro p hp
  have h : env3899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3898_3899 : H12AffineEnvironment.transform 17 43048 env3898 = env3899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env3898 == env3899) = true)

theorem identity3899 : scanCanonicalize (H12AffineFastState.compose env3899 (packedSelected [1,2,3,4,5,6,7,8,11] rootPS)) = affineNative (2^(14+1) ^^^ 13356) := by decide +kernel

theorem selectedBound3899 : packedSelected [1,2,3,4,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env3900 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,16384,13356,25615,4096,7172,1025,13356,4097,0,5124,5126,8224,5125,22528,16385,16384,22561,16421,20480,5,20480,4129,5637]

theorem envBound3900 : H12AffineFastState.Bounded env3900 := by
  intro p hp
  have h : env3900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3899_3900 : H12AffineEnvironment.transform 14 13356 env3899 = env3900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13356 env3899 == env3900) = true)

theorem identity3900 : scanCanonicalize (H12AffineFastState.compose env3900 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4618) := by decide +kernel

theorem selectedBound3900 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env3901 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,4618,13356,13829,4096,7172,1025,13356,4097,0,5124,5126,8224,5125,2570,4619,4618,2603,4655,522,5,522,4129,5637]

theorem envBound3901 : H12AffineFastState.Bounded env3901 := by
  intro p hp
  have h : env3901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3900_3901 : H12AffineEnvironment.transform 13 4618 env3900 = env3901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4618 env3900 == env3901) = true)

theorem identity3901 : scanCanonicalize (H12AffineFastState.compose env3901 (packedSelected [0,2,3,4,5,6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2571) := by decide +kernel

theorem selectedBound3901 : packedSelected [0,2,3,4,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env3902 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,2571,8192,2049,11815,11278,2571,1551,1025,11815,2570,0,3599,3597,8224,3598,2570,2048,2049,2603,2084,522,5,522,2602,3086]

theorem envBound3902 : H12AffineFastState.Bounded env3902 := by
  intro p hp
  have h : env3902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3901_3902 : H12AffineEnvironment.transform 11 2571 env3901 = env3902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2571 env3901 == env3902) = true)

theorem identity3902 : scanCanonicalize (H12AffineFastState.compose env3902 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1069) := by decide +kernel

theorem selectedBound3902 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env3903 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,2571,1069,2049,2570,2083,2571,1551,1025,2570,2570,0,3599,3597,1037,3598,2570,2048,2049,2603,2084,522,5,522,2602,3086]

theorem envBound3903 : H12AffineFastState.Bounded env3903 := by
  intro p hp
  have h : env3903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3902_3903 : H12AffineEnvironment.transform 12 1069 env3902 = env3903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1069 env3902 == env3903) = true)

theorem identity3903 : scanCanonicalize (H12AffineFastState.compose env3903 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound3903 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env3904 : List Nat := [2,4,8,0,32,1,41,4,512,15,2048,2571,34,2049,2570,2083,2571,512,14,2570,2570,0,2560,2562,2,2561,2570,2048,2049,2603,2084,522,5,522,2602,2049]

theorem envBound3904 : H12AffineFastState.Bounded env3904 := by
  intro p hp
  have h : env3904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3903_3904 : H12AffineEnvironment.transform 9 15 env3903 = env3904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env3903 == env3904) = true)

theorem identity3904 : scanCanonicalize (H12AffineFastState.compose env3904 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound3904 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env3905 : List Nat := [2,4,8,0,32,1,41,4,512,15,513,10,34,512,11,546,10,512,14,11,11,0,1,3,2,0,11,513,512,42,549,522,5,522,43,512]

theorem envBound3905 : H12AffineFastState.Bounded env3905 := by
  intro p hp
  have h : env3905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3904_3905 : H12AffineEnvironment.transform 10 513 env3904 = env3905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env3904 == env3905) = true)

def env3906 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53387,4097,262144,1025,32768,4097,46213,8388608,41002,8329,8388609,323713,16385,16385,22561,62625,8406020,173,20480,8433825,8389121]

theorem envBound3906 : H12AffineFastState.Bounded env3906 := by
  intro p hp
  have h : env3906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3895_3906 : H12AffineEnvironment.transform 3 1 env3895 = env3906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3895 == env3906) = true)

def env3907 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8352,28715,4097,262144,1025,8352,4097,5157,8388608,138,8329,8388609,282657,16385,16385,22561,21505,8406020,173,20480,8392705,8389121]

theorem envBound3907 : H12AffineFastState.Bounded env3907 := by
  intro p hp
  have h : env3907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3906_3907 : H12AffineEnvironment.transform 14 8352 env3906 = env3907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env3906 == env3907) = true)

theorem identity3907 : scanCanonicalize (H12AffineFastState.compose env3907 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 19596) := by decide +kernel

theorem selectedBound3907 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3908 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8352,28715,4097,19596,1025,8352,4097,5157,8388608,138,8329,8388609,7341,16385,16385,22561,21505,8406020,173,20480,8392705,8389121]

theorem envBound3908 : H12AffineFastState.Bounded env3908 := by
  intro p hp
  have h : env3908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3907_3908 : H12AffineEnvironment.transform 17 19596 env3907 = env3908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19596 env3907 == env3908) = true)

theorem identity3908 : scanCanonicalize (H12AffineFastState.compose env3908 (packedSelected [2,3,5,6,10,13,17,21] rootPS)) = affineNative (2^(12+1) ^^^ 2050) := by decide +kernel

theorem selectedBound3908 : packedSelected [2,3,5,6,10,13,17,21] rootPS < 2^1333 := by decide +kernel

def env3909 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,2050,16384,2210,22569,4097,19596,1025,2210,4097,5157,8388608,138,2187,8388609,7341,16385,16385,22561,21505,8406020,173,20480,8392705,8389121]

theorem envBound3909 : H12AffineFastState.Bounded env3909 := by
  intro p hp
  have h : env3909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3908_3909 : H12AffineEnvironment.transform 12 2050 env3908 = env3909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2050 env3908 == env3909) = true)

theorem identity3909 : scanCanonicalize (H12AffineFastState.compose env3909 (packedSelected [2,4,9,11,20,23] rootPS)) = affineNative (2^(22+1) ^^^ 5124) := by decide +kernel

theorem selectedBound3909 : packedSelected [2,4,9,11,20,23] rootPS < 2^1333 := by decide +kernel

def env3910 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,2050,16384,2210,22569,4097,19596,1025,2210,4097,5157,5124,138,2187,5125,7341,16385,16385,22561,21505,20480,173,20480,1029,5637]

theorem envBound3910 : H12AffineFastState.Bounded env3910 := by
  intro p hp
  have h : env3910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3909_3910 : H12AffineEnvironment.transform 22 5124 env3909 = env3910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5124 env3909 == env3910) = true)

theorem identity3910 : scanCanonicalize (H12AffineFastState.compose env3910 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 2570) := by decide +kernel

theorem selectedBound3910 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3911 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,2050,2570,2210,4643,4097,1670,1025,2210,4097,5157,5124,138,2187,5125,7341,2571,2571,4651,7691,6666,173,6666,1029,5637]

theorem envBound3911 : H12AffineFastState.Bounded env3911 := by
  intro p hp
  have h : env3911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3910_3911 : H12AffineEnvironment.transform 13 2570 env3910 = env3911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2570 env3910 == env3911) = true)

theorem identity3911 : scanCanonicalize (H12AffineFastState.compose env3911 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 649) := by decide +kernel

theorem selectedBound3911 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env3912 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,649,2050,2570,2210,170,648,1670,1025,2210,648,1708,1677,138,2187,1676,3620,2571,2571,162,3202,2179,173,2179,1029,1164]

theorem envBound3912 : H12AffineFastState.Bounded env3912 := by
  intro p hp
  have h : env3912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3911_3912 : H12AffineEnvironment.transform 11 649 env3911 = env3912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 649 env3911 == env3912) = true)

theorem identity3912 : scanCanonicalize (H12AffineFastState.compose env3912 (packedSelected [0,1,3,5,6,7,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3912 : packedSelected [0,1,3,5,6,7,8,13] rootPS < 2^1333 := by decide +kernel

def env3913 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,545,2050,2570,2058,2,544,1582,1025,2058,544,1540,1573,34,2083,1572,3620,2571,2571,10,3114,2091,5,2091,1029,1060]

theorem envBound3913 : H12AffineFastState.Bounded env3913 := by
  intro p hp
  have h : env3913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3912_3913 : H12AffineEnvironment.transform 6 40 env3912 = env3913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3912 == env3913) = true)

theorem identity3913 : scanCanonicalize (H12AffineFastState.compose env3913 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound3913 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env3914 : List Nat := [2,4,8,1,32,0,40,4,512,1024,42,545,40,544,32,2,544,1582,1025,32,544,1540,1573,34,9,1572,1550,545,545,10,1024,1,5,1,1029,1060]

theorem envBound3914 : H12AffineFastState.Bounded env3914 := by
  intro p hp
  have h : env3914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3913_3914 : H12AffineEnvironment.transform 10 42 env3913 = env3914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env3913 == env3914) = true)

theorem identity3914 : scanCanonicalize (H12AffineFastState.compose env3914 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3914 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3915 : List Nat := [2,4,8,1,32,0,40,4,512,5,42,545,40,544,32,2,544,555,4,32,544,513,544,34,9,545,523,545,545,10,5,1,5,1,0,33]

theorem envBound3915 : H12AffineFastState.Bounded env3915 := by
  intro p hp
  have h : env3915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3914_3915 : H12AffineEnvironment.transform 9 5 env3914 = env3915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3914 == env3915) = true)

def env3916 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8353,28714,4097,262144,1025,8353,4097,5156,8388608,139,8329,8388609,282656,16385,16385,22561,21504,8406020,173,20480,8392704,8389121]

theorem envBound3916 : H12AffineFastState.Bounded env3916 := by
  intro p hp
  have h : env3916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3906_3916 : H12AffineEnvironment.transform 14 8353 env3906 = env3916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env3906 == env3916) = true)

theorem identity3916 : scanCanonicalize (H12AffineFastState.compose env3916 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound3916 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3917 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8353,28714,4097,2081,1025,8353,4097,5156,8388608,139,8329,8388609,22529,16385,16385,22561,21504,8406020,173,20480,8392704,8389121]

theorem envBound3917 : H12AffineFastState.Bounded env3917 := by
  intro p hp
  have h : env3917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3916_3917 : H12AffineEnvironment.transform 17 2081 env3916 = env3917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env3916 == env3917) = true)

theorem identity3917 : scanCanonicalize (H12AffineFastState.compose env3917 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(22+1) ^^^ 9870) := by decide +kernel

theorem selectedBound3917 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env3918 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8353,28714,4097,2081,1025,8353,4097,5156,9870,139,8329,9871,22529,16385,16385,22561,21504,25226,173,20480,13966,9359]

theorem envBound3918 : H12AffineFastState.Bounded env3918 := by
  intro p hp
  have h : env3918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3917_3918 : H12AffineEnvironment.transform 22 9870 env3917 = env3918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9870 env3917 == env3918) = true)

theorem identity3918 : scanCanonicalize (H12AffineFastState.compose env3918 (packedSelected [0,1,4,7,8,9,10,11,13,15,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 7814) := by decide +kernel

theorem selectedBound3918 : packedSelected [0,1,4,7,8,9,10,11,13,15,20,21] rootPS < 2^1333 := by decide +kernel

def env3919 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,7814,8353,11948,4097,2081,1025,8353,4097,5156,9870,139,8329,9871,1671,7815,7815,1703,2694,15372,173,3718,13966,9359]

theorem envBound3919 : H12AffineFastState.Bounded env3919 := by
  intro p hp
  have h : env3919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3918_3919 : H12AffineEnvironment.transform 13 7814 env3918 = env3919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7814 env3918 == env3919) = true)

theorem identity3919 : scanCanonicalize (H12AffineFastState.compose env3919 (packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 4642) := by decide +kernel

theorem selectedBound3919 : packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env3920 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,4642,7814,4739,7310,4097,2081,1025,4739,4097,5156,5292,139,4779,5293,1671,7815,7815,1703,2694,3630,173,3718,1196,5805]

theorem envBound3920 : H12AffineFastState.Bounded env3920 := by
  intro p hp
  have h : env3920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3919_3920 : H12AffineEnvironment.transform 12 4642 env3919 = env3920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4642 env3919 == env3920) = true)

theorem identity3920 : scanCanonicalize (H12AffineFastState.compose env3920 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound3920 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env3921 : List Nat := [2,4,8,1,32,0,128,172,43,1024,2048,4096,4105,7341,4264,7310,4097,2081,1025,4264,4097,5156,5292,139,4224,5293,1196,7340,7340,1164,2221,3077,173,3245,1196,5254]

theorem envBound3921 : H12AffineFastState.Bounded env3921 := by
  intro p hp
  have h : env3921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3920_3921 : H12AffineEnvironment.transform 8 43 env3920 = env3921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env3920 == env3921) = true)

def env3922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41002,8329,11015249,134217728,268435456,268435965,134523040,2699307,147588589,525568,134520961,143496519,8914924]

theorem envBound3922 : H12AffineFastState.Bounded env3922 := by
  intro p hp
  have h : env3922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2954_3922 : H12AffineEnvironment.transform 25 11015249 env2954 = env3922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 11015249 env2954 == env3922) = true)

def env3923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41002,8329,11015249,849104,268435456,268435965,547952,2699307,12644669,525568,545873,8479127,8914924]

theorem envBound3923 : H12AffineFastState.Bounded env3923 := by
  intro p hp
  have h : env3923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3922_3923 : H12AffineEnvironment.transform 26 849104 env3922 = env3923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 849104 env3922 == env3923) = true)

def env3924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41002,8329,8914001,849104,268435456,268435965,547952,598059,12644669,525568,545873,8479127,8914924]

theorem envBound3924 : H12AffineFastState.Bounded env3924 := by
  intro p hp
  have h : env3924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3923_3924 : H12AffineEnvironment.transform 20 4096 env3923 = env3924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env3923 == env3924) = true)

def env3925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41002,8329,8914001,849104,16384,16893,547952,598059,12644669,525568,545873,8479127,8914924]

theorem envBound3925 : H12AffineFastState.Bounded env3925 := by
  intro p hp
  have h : env3925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3924_3925 : H12AffineEnvironment.transform 27 16384 env3924 = env3925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env3924 == env3925) = true)

def env3926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41002,8329,8388689,323792,16384,16893,22640,74795,12644669,256,20561,8479127,8389612]

theorem envBound3926 : H12AffineFastState.Bounded env3926 := by
  intro p hp
  have h : env3926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3925_3926 : H12AffineEnvironment.transform 18 1024 env3925 = env3926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3925 == env3926) = true)

theorem identity3926 : scanCanonicalize (H12AffineFastState.compose env3926 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound3926 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8494,4604,262144,1024,32768,4096,4194304,8388608,41002,8329,8388689,323792,16384,16893,22640,1285,12644669,256,20561,8405177,8389612]

theorem envBound3927 : H12AffineFastState.Bounded env3927 := by
  intro p hp
  have h : env3927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3926_3927 : H12AffineEnvironment.transform 15 8494 env3926 = env3927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env3926 == env3927) = true)

def env3928 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8494,4524,262144,1024,32768,4096,4194304,8388608,41002,8329,8388609,323712,16384,16813,22560,1285,12644669,256,20481,8405177,8389564]

theorem envBound3928 : H12AffineFastState.Bounded env3928 := by
  intro p hp
  have h : env3928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3927_3928 : H12AffineEnvironment.transform 5 16 env3927 = env3928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3927 == env3928) = true)

def env3929 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8494,4524,262144,1024,32768,4096,136,8388608,41002,8329,8388609,323712,16384,16813,22560,1285,8450485,256,20481,8405177,8389564]

theorem envBound3929 : H12AffineFastState.Bounded env3929 := by
  intro p hp
  have h : env3929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3928_3929 : H12AffineEnvironment.transform 21 136 env3928 = env3929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env3928 == env3929) = true)

theorem identity3929 : scanCanonicalize (H12AffineFastState.compose env3929 (packedSelected [7,9,13,17,20,22,27] rootPS)) = affineNative (2^(22+1) ^^^ 269997) := by decide +kernel

theorem selectedBound3929 : packedSelected [7,9,13,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env3930 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8494,4524,262144,1024,32768,4096,136,269997,41002,8329,269996,323712,16384,16813,22560,1285,323352,256,20481,286228,269585]

theorem envBound3930 : H12AffineFastState.Bounded env3930 := by
  intro p hp
  have h : env3930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3929_3930 : H12AffineEnvironment.transform 22 269997 env3929 = env3930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 269997 env3929 == env3930) = true)

def env3931 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,8494,4356,262144,1024,32768,4096,32,269829,41002,8225,269828,323624,16384,16645,22560,1285,323352,256,20481,286228,269585]

theorem envBound3931 : H12AffineFastState.Bounded env3931 := by
  intro p hp
  have h : env3931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3930_3931 : H12AffineEnvironment.transform 6 40 env3930 = env3931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3930 == env3931) = true)

theorem identity3931 : scanCanonicalize (H12AffineFastState.compose env3931 (packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 61208) := by decide +kernel

theorem selectedBound3931 : packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3932 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,8494,4356,61208,1024,32768,4096,32,61725,41002,8225,61724,7984,16384,16645,22560,1285,0,256,20481,45324,61961]

theorem envBound3932 : H12AffineFastState.Bounded env3932 := by
  intro p hp
  have h : env3932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3931_3932 : H12AffineEnvironment.transform 17 61208 env3931 = env3932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 61208 env3931 == env3932) = true)

theorem identity3932 : scanCanonicalize (H12AffineFastState.compose env3932 (packedSelected [17,21] rootPS)) = affineNative (2^(11+1) ^^^ 1841) := by decide +kernel

theorem selectedBound3932 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3933 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1841,8192,16384,32768,8494,1589,61208,1024,32768,1841,32,58924,41002,8225,58925,2049,16384,16645,20241,1285,0,256,18224,42557,58680]

theorem envBound3933 : H12AffineFastState.Bounded env3933 := by
  intro p hp
  have h : env3933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3932_3933 : H12AffineEnvironment.transform 11 1841 env3932 = env3933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1841 env3932 == env3933) = true)

theorem identity3933 : scanCanonicalize (H12AffineFastState.compose env3933 (packedSelected [4,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound3933 : packedSelected [4,20,22] rootPS < 2^1333 := by decide +kernel

def env3934 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1841,8192,16384,8461,8494,1589,19989,1024,8461,1841,32,18209,295,8225,18208,2049,16384,16645,20241,1285,0,256,18224,1840,17461]

theorem envBound3934 : H12AffineFastState.Bounded env3934 := by
  intro p hp
  have h : env3934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3933_3934 : H12AffineEnvironment.transform 14 8461 env3933 = env3934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env3933 == env3934) = true)

theorem identity3934 : scanCanonicalize (H12AffineFastState.compose env3934 (packedSelected [0,2,3,6,7,8,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 1835) := by decide +kernel

theorem selectedBound3934 : packedSelected [0,2,3,6,7,8,10,13] rootPS < 2^1333 := by decide +kernel

def env3935 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1841,8192,1835,8461,8494,1589,2366,1024,8461,1841,32,10,295,8225,11,2049,1835,1582,2106,1285,0,256,27,1840,798]

theorem envBound3935 : H12AffineFastState.Bounded env3935 := by
  intro p hp
  have h : env3935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3934_3935 : H12AffineEnvironment.transform 13 1835 env3934 = env3935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1835 env3934 == env3935) = true)

theorem identity3935 : scanCanonicalize (H12AffineFastState.compose env3935 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3935 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env3936 : List Nat := [2,4,8,10,32,10,40,256,512,1024,2048,1835,8192,1835,8461,8494,1583,2340,1024,8461,1835,32,10,295,8225,11,2049,1835,1582,2080,1285,0,256,1,1834,772]

theorem envBound3936 : H12AffineFastState.Bounded env3936 := by
  intro p hp
  have h : env3936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3935_3936 : H12AffineEnvironment.transform 3 10 env3935 = env3936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3935 == env3936) = true)

theorem identity3936 : scanCanonicalize (H12AffineFastState.compose env3936 (packedSelected [1,8] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound3936 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env3937 : List Nat := [2,4,8,10,32,10,40,256,512,1024,2048,1835,300,1835,33,2,1583,2340,1024,33,1835,32,10,295,269,11,2049,1835,1582,2080,1285,0,256,1,1834,772]

theorem envBound3937 : H12AffineFastState.Bounded env3937 := by
  intro p hp
  have h : env3937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3936_3937 : H12AffineEnvironment.transform 12 300 env3936 = env3937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env3936 == env3937) = true)

theorem identity3937 : scanCanonicalize (H12AffineFastState.compose env3937 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3937 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env3938 : List Nat := [2,4,8,10,32,10,40,4,512,1024,2048,1583,40,1583,33,2,1583,2080,1024,33,1583,32,10,35,9,11,2049,1583,1582,2080,1025,0,4,1,1582,512]

theorem envBound3938 : H12AffineFastState.Bounded env3938 := by
  intro p hp
  have h : env3938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3937_3938 : H12AffineEnvironment.transform 7 4 env3937 = env3938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3937 == env3938) = true)

theorem identity3938 : scanCanonicalize (H12AffineFastState.compose env3938 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound3938 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3939 : List Nat := [2,4,8,10,32,10,40,4,512,1024,522,1583,40,1583,33,2,1583,554,1024,33,1583,32,10,35,9,11,523,1583,1582,554,1025,0,4,1,1582,512]

theorem envBound3939 : H12AffineFastState.Bounded env3939 := by
  intro p hp
  have h : env3939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3938_3939 : H12AffineEnvironment.transform 10 522 env3938 = env3939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env3938 == env3939) = true)

theorem identity3939 : scanCanonicalize (H12AffineFastState.compose env3939 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound3939 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3940 : List Nat := [2,4,8,10,11,10,3,4,512,1024,522,1540,3,1540,10,2,1540,513,1024,10,1540,11,10,8,9,11,523,1540,1541,513,1025,0,4,1,1541,512]

theorem envBound3940 : H12AffineFastState.Bounded env3940 := by
  intro p hp
  have h : env3940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1