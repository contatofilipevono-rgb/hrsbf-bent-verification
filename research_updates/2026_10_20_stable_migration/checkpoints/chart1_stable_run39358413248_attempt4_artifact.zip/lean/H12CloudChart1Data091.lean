import H12CloudChart1Data090

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound23034 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23035 : List Nat := [2,4,8,16,0,17,9,5,17,4,17,0,9,0,1,2,16,16,4,0,17,0,16,2,8,16,17,16,0,16,4,1,5,0,1,16]

theorem envBound23035 : H12AffineFastState.Bounded env23035 := by
  intro p hp
  have h : env23035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23034_23035 : H12AffineEnvironment.transform 8 17 env23034 = env23035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env23034 == env23035) = true)

def env23036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412021,21762,8328,65,215366,115150,396389,35188,497766,243122,256,510107,469310,442289]

theorem envBound23036 : H12AffineFastState.Bounded env23036 := by
  intro p hp
  have h : env23036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23008_23036 : H12AffineEnvironment.transform 20 4161 env23008 = env23036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env23008 == env23036) = true)

theorem identity23036 : scanCanonicalize (H12AffineFastState.compose env23036 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound23036 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4161,156132,412021,21762,8328,65,215366,79131,396389,32161,486579,213351,256,474190,469310,412516]

theorem envBound23037 : H12AffineFastState.Bounded env23037 := by
  intro p hp
  have h : env23037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23036_23037 : H12AffineEnvironment.transform 14 29909 env23036 = env23037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env23036 == env23037) = true)

def env23038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,4161,156132,156117,21762,8328,65,215366,79131,140485,32161,214035,213351,256,201966,197022,156612]

theorem envBound23038 : H12AffineFastState.Bounded env23038 := by
  intro p hp
  have h : env23038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23037_23038 : H12AffineEnvironment.transform 17 10400 env23037 = env23038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env23037 == env23038) = true)

theorem identity23038 : scanCanonicalize (H12AffineFastState.compose env23038 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound23038 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env23039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,136,65536,131072,10400,1024,137,4161,136633,136584,8543,8328,65,212251,79131,140485,2556,208974,210234,256,201966,197022,137113]

theorem envBound23039 : H12AffineFastState.Bounded env23039 := by
  intro p hp
  have h : env23039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23038_23039 : H12AffineEnvironment.transform 13 13405 env23038 = env23039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env23038 == env23039) = true)

theorem identity23039 : scanCanonicalize (H12AffineFastState.compose env23039 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,18,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23039 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env23040 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,13405,136,65536,131072,10400,1024,137,4161,136396,136445,8234,8328,65,212078,78958,140485,2185,208974,209999,117,201966,196843,136940]

theorem envBound23040 : H12AffineFastState.Bounded env23040 := by
  intro p hp
  have h : env23040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23039_23040 : H12AffineEnvironment.transform 7 117 env23039 = env23040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23039 == env23040) = true)

theorem identity23040 : scanCanonicalize (H12AffineFastState.compose env23040 (packedSelected [2,6,7,9,11,17,18,20,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound23040 : packedSelected [2,6,7,9,11,17,18,20,22,27] rootPS < 2^1333 := by decide +kernel

def env23041 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,13405,136,171,131072,10400,1024,137,4161,136396,136445,8234,8328,65,146629,13509,140485,2185,143589,144612,117,136261,131136,136940]

theorem envBound23041 : H12AffineFastState.Bounded env23041 := by
  intro p hp
  have h : env23041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23040_23041 : H12AffineEnvironment.transform 15 171 env23040 = env23041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env23040 == env23041) = true)

def env23042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,4161,156132,156116,21762,8328,65,215366,79131,140484,32161,214034,213351,256,201967,197023,156613]

theorem envBound23042 : H12AffineFastState.Bounded env23042 := by
  intro p hp
  have h : env23042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23037_23042 : H12AffineEnvironment.transform 17 10401 env23037 = env23042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env23037 == env23042) = true)

theorem identity23042 : scanCanonicalize (H12AffineFastState.compose env23042 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 25028) := by decide +kernel

theorem selectedBound23042 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env23043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,25028,10401,1024,29908,4161,32,16,21762,8328,65,75906,79131,17664,32161,75222,73891,256,95531,90203,513]

theorem envBound23043 : H12AffineFastState.Bounded env23043 := by
  intro p hp
  have h : env23043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23042_23043 : H12AffineEnvironment.transform 16 25028 env23042 = env23043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env23042 == env23043) = true)

theorem identity23043 : scanCanonicalize (H12AffineFastState.compose env23043 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound23043 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env23044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30082,25028,10401,1024,29908,4161,32,16,21762,8328,65,23808,16537,17664,32161,20564,21793,256,169,5593,513]

theorem envBound23044 : H12AffineFastState.Bounded env23044 := by
  intro p hp
  have h : env23044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23043_23044 : H12AffineEnvironment.transform 15 30082 env23043 = env23044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env23043 == env23044) = true)

theorem identity23044 : scanCanonicalize (H12AffineFastState.compose env23044 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23044 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env23045 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,30082,24980,10401,1024,29828,4113,32,16,21762,8328,17,23808,16537,17664,32161,20484,21793,256,169,5513,513]

theorem envBound23045 : H12AffineFastState.Bounded env23045 := by
  intro p hp
  have h : env23045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23044_23045 : H12AffineEnvironment.transform 5 16 env23044 = env23045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23044 == env23045) = true)

theorem identity23045 : scanCanonicalize (H12AffineFastState.compose env23045 (packedSelected [0,1,2,6,7,8,10,12,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound23045 : packedSelected [0,1,2,6,7,8,10,12,14,17,18] rootPS < 2^1333 := by decide +kernel

def env23046 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21761,21510,16400,2341,1024,21760,4113,32,16,21762,268,17,23808,16537,17664,23589,20484,21793,256,169,5513,513]

theorem envBound23046 : H12AffineFastState.Bounded env23046 := by
  intro p hp
  have h : env23046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23045_23046 : H12AffineEnvironment.transform 12 388 env23045 = env23046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env23045 == env23046) = true)

theorem identity23046 : scanCanonicalize (H12AffineFastState.compose env23046 (packedSelected [2,6,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23046 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env23047 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,21510,16400,2341,1024,21760,4113,32,16,21762,268,17,23808,16401,17664,23589,20484,21793,256,33,5377,513]

theorem envBound23047 : H12AffineFastState.Bounded env23047 := by
  intro p hp
  have h : env23047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23046_23047 : H12AffineEnvironment.transform 6 8 env23046 = env23047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23046 == env23047) = true)

theorem identity23047 : scanCanonicalize (H12AffineFastState.compose env23047 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23047 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env23048 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,262,5392,2341,1024,0,4113,32,16,2,268,17,2048,5393,4096,2341,1284,33,256,33,5377,513]

theorem envBound23048 : H12AffineFastState.Bounded env23048 := by
  intro p hp
  have h : env23048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23047_23048 : H12AffineEnvironment.transform 13 5376 env23047 = env23048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23047 == env23048) = true)

theorem identity23048 : scanCanonicalize (H12AffineFastState.compose env23048 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23048 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23049 : List Nat := [2,4,8,0,32,0,8,256,512,1024,2048,4096,268,5376,1,262,5376,2341,1024,0,4097,32,0,2,268,1,2048,5377,4096,2341,1284,33,256,33,5377,513]

theorem envBound23049 : H12AffineFastState.Bounded env23049 := by
  intro p hp
  have h : env23049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23048_23049 : H12AffineEnvironment.transform 3 0 env23048 = env23049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23048 == env23049) = true)

theorem identity23049 : scanCanonicalize (H12AffineFastState.compose env23049 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound23049 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23050 : List Nat := [2,4,8,0,32,0,8,256,512,1024,1070,4096,268,5376,1,262,5376,1291,1024,0,4097,32,0,2,268,1,1070,5377,4096,1291,1284,33,256,33,5377,513]

theorem envBound23050 : H12AffineFastState.Bounded env23050 := by
  intro p hp
  have h : env23050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23049_23050 : H12AffineEnvironment.transform 10 1070 env23049 = env23050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env23049 == env23050) = true)

theorem identity23050 : scanCanonicalize (H12AffineFastState.compose env23050 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23050 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23051 : List Nat := [2,4,8,0,0,0,8,256,512,1024,1038,4096,268,5376,1,262,5376,1291,1024,0,4097,0,0,2,268,1,1038,5377,4096,1291,1284,1,256,1,5377,513]

theorem envBound23051 : H12AffineFastState.Bounded env23051 := by
  intro p hp
  have h : env23051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23050_23051 : H12AffineEnvironment.transform 4 0 env23050 = env23051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23050 == env23051) = true)

theorem identity23051 : scanCanonicalize (H12AffineFastState.compose env23051 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound23051 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23052 : List Nat := [2,4,3,0,0,0,3,256,512,1024,1029,4096,263,5376,1,262,5376,1280,1024,0,4097,0,0,2,263,1,1029,5377,4096,1280,1284,1,256,1,5377,513]

theorem envBound23052 : H12AffineFastState.Bounded env23052 := by
  intro p hp
  have h : env23052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23051_23052 : H12AffineEnvironment.transform 2 3 env23051 = env23052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env23051 == env23052) = true)

theorem identity23052 : scanCanonicalize (H12AffineFastState.compose env23052 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound23052 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23053 : List Nat := [2,4,3,0,0,0,3,256,512,1024,1029,1029,263,261,1,262,261,1280,1024,0,1028,0,0,2,263,1,1029,260,1029,1280,1284,1,256,1,260,513]

theorem envBound23053 : H12AffineFastState.Bounded env23053 := by
  intro p hp
  have h : env23053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23052_23053 : H12AffineEnvironment.transform 11 1029 env23052 = env23053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env23052 == env23053) = true)

theorem identity23053 : scanCanonicalize (H12AffineFastState.compose env23053 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound23053 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env23054 : List Nat := [2,4,3,0,0,0,3,256,512,256,261,261,263,261,1,262,261,0,256,0,260,0,0,2,263,1,261,260,261,0,4,1,256,1,260,513]

theorem envBound23054 : H12AffineFastState.Bounded env23054 := by
  intro p hp
  have h : env23054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23053_23054 : H12AffineEnvironment.transform 9 256 env23053 = env23054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env23053 == env23054) = true)

theorem identity23054 : scanCanonicalize (H12AffineFastState.compose env23054 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 263) := by decide +kernel

theorem selectedBound23054 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23055 : List Nat := [2,4,3,0,0,0,3,256,263,256,261,261,263,261,1,262,261,0,256,0,260,0,0,2,263,1,261,260,261,0,4,1,256,1,260,262]

theorem envBound23055 : H12AffineFastState.Bounded env23055 := by
  intro p hp
  have h : env23055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23054_23055 : H12AffineEnvironment.transform 8 263 env23054 = env23055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 263 env23054 == env23055) = true)

theorem identity23055 : scanCanonicalize (H12AffineFastState.compose env23055 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23055 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env23056 : List Nat := [2,4,3,0,0,0,3,5,2,5,0,0,2,0,1,3,0,0,5,0,1,0,0,2,2,1,0,1,0,0,4,1,5,1,1,3]

theorem envBound23056 : H12AffineFastState.Bounded env23056 := by
  intro p hp
  have h : env23056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23055_23056 : H12AffineEnvironment.transform 7 5 env23055 = env23056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23055 == env23056) = true)

theorem identity23056 : scanCanonicalize (H12AffineFastState.compose env23056 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound23056 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23057 : List Nat := [2,1,3,0,0,0,3,0,2,0,0,0,2,0,1,3,0,0,0,0,1,0,0,2,2,1,0,1,0,0,1,1,0,1,1,3]

theorem envBound23057 : H12AffineFastState.Bounded env23057 := by
  intro p hp
  have h : env23057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23056_23057 : H12AffineEnvironment.transform 1 1 env23056 = env23057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env23056 == env23057) = true)

def env23058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262385,412021,2114883,8328,65,215367,115150,2497572,35188,2590759,2336242,256,510107,469310,2535408]

theorem envBound23058 : H12AffineFastState.Bounded env23058 := by
  intro p hp
  have h : env23058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23007_23058 : H12AffineEnvironment.transform 21 2262385 env23007 = env23058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262385 env23007 == env23058) = true)

def env23059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412021,21763,8328,65,215367,115150,396388,35188,497767,243122,256,510107,469310,442288]

theorem envBound23059 : H12AffineFastState.Bounded env23059 := by
  intro p hp
  have h : env23059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23058_23059 : H12AffineEnvironment.transform 20 4160 env23058 = env23059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env23058 == env23059) = true)

def env23060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,169265,155997,21763,8328,65,215367,115150,140364,35188,241743,243122,256,254131,196886,169880]

theorem envBound23060 : H12AffineFastState.Bounded env23060 := by
  intro p hp
  have h : env23060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23059_23060 : H12AffineEnvironment.transform 17 10280 env23059 = env23060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23059 == env23060) = true)

def env23061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4160,21793,41293,21763,8328,65,100695,115150,58460,35188,94303,95650,256,73891,114950,22408]

theorem envBound23061 : H12AffineFastState.Bounded env23061 := by
  intro p hp
  have h : env23061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23060_23061 : H12AffineEnvironment.transform 16 49168 env23060 = env23061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env23060 == env23061) = true)

theorem identity23061 : scanCanonicalize (H12AffineFastState.compose env23061 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound23061 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13509,10280,1024,29908,4160,21793,21912,21763,8328,65,97666,79131,4233,32161,94303,95650,256,73891,79315,22408]

theorem envBound23062 : H12AffineFastState.Bounded env23062 := by
  intro p hp
  have h : env23062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23061_23062 : H12AffineEnvironment.transform 14 29909 env23061 = env23062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env23061 == env23062) = true)

theorem identity23062 : scanCanonicalize (H12AffineFastState.compose env23062 (packedSelected [0,1,4,7,8,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 1230) := by decide +kernel

theorem selectedBound23062 : packedSelected [0,1,4,7,8,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env23063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,1230,13509,10280,1024,29908,4160,21793,21912,21763,8328,65,31052,12757,4233,32161,29841,29036,256,9325,12573,22408]

theorem envBound23063 : H12AffineFastState.Bounded env23063 := by
  intro p hp
  have h : env23063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23062_23063 : H12AffineEnvironment.transform 15 1230 env23062 = env23063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1230 env23062 == env23063) = true)

theorem identity23063 : scanCanonicalize (H12AffineFastState.compose env23063 (packedSelected [5,19,24] rootPS)) = affineNative (2^(13+1) ^^^ 4248) := by decide +kernel

theorem selectedBound23063 : packedSelected [5,19,24] rootPS < 2^1333 := by decide +kernel

def env23064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4248,9293,1230,13509,10280,1024,9292,4160,1465,1280,1435,8328,65,10708,12757,4233,11577,9225,8692,256,9325,12573,1808]

theorem envBound23064 : H12AffineFastState.Bounded env23064 := by
  intro p hp
  have h : env23064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23063_23064 : H12AffineEnvironment.transform 13 4248 env23063 = env23064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4248 env23063 == env23064) = true)

theorem identity23064 : scanCanonicalize (H12AffineFastState.compose env23064 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound23064 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env23065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,4248,1432,1230,5392,2557,1024,1433,4160,1465,1280,1435,349,65,2049,4096,4233,3308,1500,33,256,1464,4296,1808]

theorem envBound23065 : H12AffineFastState.Bounded env23065 := by
  intro p hp
  have h : env23065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23064_23065 : H12AffineEnvironment.transform 12 469 env23064 = env23065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env23064 == env23065) = true)

theorem identity23065 : scanCanonicalize (H12AffineFastState.compose env23065 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23065 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23066 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4112,1296,1094,5392,2421,1024,1297,4160,1329,1280,1299,349,65,2049,4096,4097,3172,1364,33,256,1328,4160,1808]

theorem envBound23066 : H12AffineFastState.Bounded env23066 := by
  intro p hp
  have h : env23066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23065_23066 : H12AffineEnvironment.transform 6 8 env23065 = env23066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23065 == env23066) = true)

theorem identity23066 : scanCanonicalize (H12AffineFastState.compose env23066 (packedSelected [1,3,5,6,8,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23066 : packedSelected [1,3,5,6,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env23067 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,88,4112,1045,1094,5141,2160,1024,1044,4160,1076,1029,1046,88,65,2049,4096,4097,3172,1105,33,5,1077,4160,1557]

theorem envBound23067 : H12AffineFastState.Bounded env23067 := by
  intro p hp
  have h : env23067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23066_23067 : H12AffineEnvironment.transform 7 5 env23066 = env23067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23066 == env23067) = true)

theorem identity23067 : scanCanonicalize (H12AffineFastState.compose env23067 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound23067 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23068 : List Nat := [2,4,8,16,32,49,8,5,512,1024,2048,4096,41,4112,1045,1079,5141,2049,1024,1044,4145,1076,1029,1046,41,48,2049,4096,4097,3093,1056,33,5,1077,4145,1557]

theorem envBound23068 : H12AffineFastState.Bounded env23068 := by
  intro p hp
  have h : env23068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23067_23068 : H12AffineEnvironment.transform 5 49 env23067 = env23068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env23067 == env23068) = true)

theorem identity23068 : scanCanonicalize (H12AffineFastState.compose env23068 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound23068 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env23069 : List Nat := [2,4,8,16,32,49,8,5,512,52,2048,4096,41,4112,33,3,4129,2049,52,32,4145,0,49,34,41,48,2049,4096,4097,2081,20,33,5,1,4145,545]

theorem envBound23069 : H12AffineFastState.Bounded env23069 := by
  intro p hp
  have h : env23069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23068_23069 : H12AffineEnvironment.transform 9 52 env23068 = env23069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env23068 == env23069) = true)

theorem identity23069 : scanCanonicalize (H12AffineFastState.compose env23069 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound23069 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23070 : List Nat := [2,4,8,16,32,49,8,5,512,52,2048,561,41,545,33,3,528,2049,52,32,512,0,49,34,41,48,2049,561,560,2081,20,33,5,1,512,545]

theorem envBound23070 : H12AffineFastState.Bounded env23070 := by
  intro p hp
  have h : env23070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23069_23070 : H12AffineEnvironment.transform 11 561 env23069 = env23070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env23069 == env23070) = true)

def env23071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4160,21792,41292,21763,8328,65,100694,115150,58461,35188,94302,95651,256,73890,114951,22409]

theorem envBound23071 : H12AffineFastState.Bounded env23071 := by
  intro p hp
  have h : env23071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23060_23071 : H12AffineEnvironment.transform 16 49169 env23060 = env23071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env23060 == env23071) = true)

theorem identity23071 : scanCanonicalize (H12AffineFastState.compose env23071 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound23071 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,13388,10280,1024,29788,4160,21792,21777,21763,8328,65,97547,79251,4096,32041,94302,95651,256,73890,79194,22409]

theorem envBound23072 : H12AffineFastState.Bounded env23072 := by
  intro p hp
  have h : env23072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23071_23072 : H12AffineEnvironment.transform 14 29789 env23071 = env23072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env23071 == env23072) = true)

theorem identity23072 : scanCanonicalize (H12AffineFastState.compose env23072 (packedSelected [0,3,8,9,16,19,20,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound23072 : packedSelected [0,3,8,9,16,19,20,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env23073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,9499,13388,10280,1024,29788,4160,21792,21777,21763,8328,65,22544,4232,4096,32041,21829,20664,256,1465,4161,22409]

theorem envBound23073 : H12AffineFastState.Bounded env23073 := by
  intro p hp
  have h : env23073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23072_23073 : H12AffineEnvironment.transform 15 9499 env23072 = env23073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env23072 == env23073) = true)

theorem identity23073 : scanCanonicalize (H12AffineFastState.compose env23073 (packedSelected [0,2,5,6,7,18,20,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound23073 : packedSelected [0,2,5,6,7,18,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env23074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8460,9499,13388,10280,1024,8461,4160,113,64,82,8328,65,3393,4232,4096,10360,20,1513,256,1465,4161,728]

theorem envBound23074 : H12AffineFastState.Bounded env23074 := by
  intro p hp
  have h : env23074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23073_23074 : H12AffineEnvironment.transform 13 5457 env23073 = env23074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env23073 == env23074) = true)

theorem identity23074 : scanCanonicalize (H12AffineFastState.compose env23074 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound23074 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env23075 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,4096,8192,4453,8460,8495,12408,10280,52,8461,4160,113,64,82,8328,65,2421,4232,4096,10360,20,477,256,397,4161,728]

theorem envBound23075 : H12AffineFastState.Bounded env23075 := by
  intro p hp
  have h : env23075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23074_23075 : H12AffineEnvironment.transform 9 52 env23074 = env23075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env23074 == env23075) = true)

theorem identity23075 : scanCanonicalize (H12AffineFastState.compose env23075 (packedSelected [1,3,5,8,14,16] rootPS)) = affineNative (2^(11+1) ^^^ 2248) := by decide +kernel

theorem selectedBound23075 : packedSelected [1,3,5,8,14,16] rootPS < 2^1333 := by decide +kernel

def env23076 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,2248,8192,2477,8460,8495,10416,10280,52,8461,2184,113,64,82,8328,65,2421,2112,2248,10360,20,477,256,397,2185,728]

theorem envBound23076 : H12AffineFastState.Bounded env23076 := by
  intro p hp
  have h : env23076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23075_23076 : H12AffineEnvironment.transform 11 2248 env23075 = env23076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2248 env23075 == env23076) = true)

theorem identity23076 : scanCanonicalize (H12AffineFastState.compose env23076 (packedSelected [0,2,3,5,6,7,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 2517) := by decide +kernel

theorem selectedBound23076 : packedSelected [0,2,3,5,6,7,10,14] rootPS < 2^1333 := by decide +kernel

def env23077 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,2248,2517,2477,2265,2298,357,509,52,2264,2184,113,64,82,2397,65,2421,2112,2248,429,20,477,256,397,2185,728]

theorem envBound23077 : H12AffineFastState.Bounded env23077 := by
  intro p hp
  have h : env23077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23076_23077 : H12AffineEnvironment.transform 12 2517 env23076 = env23077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2517 env23076 == env23077) = true)

def env23078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,169265,155996,21763,8328,65,215367,115150,140365,35188,241742,243122,256,254130,196887,169881]

theorem envBound23078 : H12AffineFastState.Bounded env23078 := by
  intro p hp
  have h : env23078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23059_23078 : H12AffineEnvironment.transform 17 10281 env23059 = env23078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23059 == env23078) = true)

def env23079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4160,21793,41292,21763,8328,65,100695,115150,58461,35188,94302,95650,256,73890,114951,22409]

theorem envBound23079 : H12AffineFastState.Bounded env23079 := by
  intro p hp
  have h : env23079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23078_23079 : H12AffineEnvironment.transform 16 49168 env23078 = env23079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env23078 == env23079) = true)

theorem identity23079 : scanCanonicalize (H12AffineFastState.compose env23079 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23079 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38160,10281,1024,32769,4160,33,41292,3,8328,65,100695,103630,45405,35188,75102,73890,256,73890,103431,649]

theorem envBound23080 : H12AffineFastState.Bounded env23080 := by
  intro p hp
  have h : env23080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23079_23080 : H12AffineEnvironment.transform 13 5376 env23079 = env23080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23079 == env23080) = true)

theorem identity23080 : scanCanonicalize (H12AffineFastState.compose env23080 (packedSelected [0,1,3,4,5,7,8,9,12,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound23080 : packedSelected [0,1,3,4,5,7,8,9,12,18,20] rootPS < 2^1333 := by decide +kernel

def env23081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,80,65536,5440,10281,1024,81,4160,33,8476,3,8328,65,67847,70814,12557,2340,75102,73890,256,73890,70743,649]

theorem envBound23081 : H12AffineFastState.Bounded env23081 := by
  intro p hp
  have h : env23081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23080_23081 : H12AffineEnvironment.transform 14 80 env23080 = env23081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env23080 == env23081) = true)

theorem identity23081 : scanCanonicalize (H12AffineFastState.compose env23081 (packedSelected [0,3,4,5,7,9,10,11,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23081 : packedSelected [0,3,4,5,7,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env23082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,80,8203,5440,10281,1024,81,4160,33,8476,3,8328,65,10508,13461,12557,2340,1365,169,256,169,13404,649]

theorem envBound23082 : H12AffineFastState.Bounded env23082 := by
  intro p hp
  have h : env23082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23081_23082 : H12AffineEnvironment.transform 15 8203 env23081 = env23082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23081 == env23082) = true)

theorem identity23082 : scanCanonicalize (H12AffineFastState.compose env23082 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23082 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env23083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,80,263,5440,2341,1024,81,4160,33,16,3,388,65,2048,5529,4097,2340,1365,169,256,169,5456,649]

theorem envBound23083 : H12AffineFastState.Bounded env23083 := by
  intro p hp
  have h : env23083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23082_23083 : H12AffineEnvironment.transform 12 268 env23082 = env23083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23082 == env23083) = true)

theorem identity23083 : scanCanonicalize (H12AffineFastState.compose env23083 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23083 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23084 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,121,5237,80,114,5173,2128,1024,81,4160,33,16,3,241,65,2048,5356,4097,2129,1056,169,117,169,5157,649]

theorem envBound23084 : H12AffineFastState.Bounded env23084 := by
  intro p hp
  have h : env23084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23083_23084 : H12AffineEnvironment.transform 7 117 env23083 = env23084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23083 == env23084) = true)

theorem identity23084 : scanCanonicalize (H12AffineFastState.compose env23084 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23084 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env23085 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5237,80,114,5173,2128,1024,81,4160,33,16,3,120,65,2048,5221,4097,2129,1056,32,117,32,5157,512]

theorem envBound23085 : H12AffineFastState.Bounded env23085 := by
  intro p hp
  have h : env23085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23084_23085 : H12AffineEnvironment.transform 6 9 env23084 = env23085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23084 == env23085) = true)

theorem identity23085 : scanCanonicalize (H12AffineFastState.compose env23085 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3605) := by decide +kernel

theorem selectedBound23085 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env23086 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3605,121,2656,80,114,2592,2128,1024,81,3669,33,16,3,120,65,2048,2672,3604,2129,1056,32,117,32,2608,512]

theorem envBound23086 : H12AffineFastState.Bounded env23086 := by
  intro p hp
  have h : env23086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23085_23086 : H12AffineEnvironment.transform 11 3605 env23085 = env23086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3605 env23085 == env23086) = true)

theorem identity23086 : scanCanonicalize (H12AffineFastState.compose env23086 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23086 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23087 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,3605,88,2625,80,83,2561,2128,1024,81,3669,0,16,3,89,65,2048,2641,3604,2129,1025,1,84,1,2577,512]

theorem envBound23087 : H12AffineFastState.Bounded env23087 := by
  intro p hp
  have h : env23087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23086_23087 : H12AffineEnvironment.transform 4 1 env23086 = env23087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23086 == env23087) = true)

theorem identity23087 : scanCanonicalize (H12AffineFastState.compose env23087 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound23087 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23088 : List Nat := [2,4,8,16,1,64,9,84,512,1024,64,1621,88,513,80,83,577,16,1024,81,1557,0,16,3,89,65,64,529,1620,17,1025,1,84,1,593,512]

theorem envBound23088 : H12AffineFastState.Bounded env23088 := by
  intro p hp
  have h : env23088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23087_23088 : H12AffineEnvironment.transform 10 64 env23087 = env23088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env23087 == env23088) = true)

theorem identity23088 : scanCanonicalize (H12AffineFastState.compose env23088 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 580) := by decide +kernel

theorem selectedBound23088 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env23089 : List Nat := [2,4,8,16,1,64,9,84,512,580,64,17,88,513,80,83,577,16,580,81,81,0,16,3,89,65,64,529,16,17,581,1,84,1,593,512]

theorem envBound23089 : H12AffineFastState.Bounded env23089 := by
  intro p hp
  have h : env23089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23088_23089 : H12AffineEnvironment.transform 9 580 env23088 = env23089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 580 env23088 == env23089) = true)

theorem identity23089 : scanCanonicalize (H12AffineFastState.compose env23089 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23089 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env23090 : List Nat := [2,4,8,16,1,17,9,5,512,533,17,17,9,513,1,2,528,16,533,0,0,0,16,3,8,16,17,529,16,17,532,1,5,1,512,512]

theorem envBound23090 : H12AffineFastState.Bounded env23090 := by
  intro p hp
  have h : env23090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23089_23090 : H12AffineEnvironment.transform 5 17 env23089 = env23090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23089 == env23090) = true)

theorem identity23090 : scanCanonicalize (H12AffineFastState.compose env23090 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23090 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23091 : List Nat := [2,4,8,1,1,0,9,5,512,516,0,0,9,513,1,2,513,1,516,0,0,0,1,3,8,1,0,512,1,0,517,1,5,1,512,512]

theorem envBound23091 : H12AffineFastState.Bounded env23091 := by
  intro p hp
  have h : env23091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23090_23091 : H12AffineEnvironment.transform 3 1 env23090 = env23091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23090 == env23091) = true)

theorem identity23091 : scanCanonicalize (H12AffineFastState.compose env23091 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23091 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23092 : List Nat := [2,4,8,1,1,0,9,5,1,5,0,0,9,0,1,2,0,1,5,0,0,0,1,3,8,1,0,1,1,0,4,1,5,1,1,1]

theorem envBound23092 : H12AffineFastState.Bounded env23092 := by
  intro p hp
  have h : env23092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23091_23092 : H12AffineEnvironment.transform 8 1 env23091 = env23092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23091 == env23092) = true)

theorem identity23092 : scanCanonicalize (H12AffineFastState.compose env23092 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound23092 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23093 : List Nat := [2,0,8,1,1,0,9,1,1,1,0,0,9,0,1,2,0,1,1,0,0,0,1,3,8,1,0,1,1,0,0,1,1,1,1,1]

theorem envBound23093 : H12AffineFastState.Bounded env23093 := by
  intro p hp
  have h : env23093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23092_23093 : H12AffineEnvironment.transform 1 0 env23092 = env23093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env23092 == env23093) = true)

def env23094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4160,21792,41293,21763,8328,65,100694,115150,58460,35188,94303,95651,256,73891,114950,22408]

theorem envBound23094 : H12AffineFastState.Bounded env23094 := by
  intro p hp
  have h : env23094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23078_23094 : H12AffineEnvironment.transform 16 49169 env23078 = env23094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env23078 == env23094) = true)

theorem identity23094 : scanCanonicalize (H12AffineFastState.compose env23094 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound23094 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,38296,10281,1024,32769,4160,169,41293,138,8328,65,100694,103495,45525,35188,75222,73770,256,73891,103567,513]

theorem envBound23095 : H12AffineFastState.Bounded env23095 := by
  intro p hp
  have h : env23095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23094_23095 : H12AffineEnvironment.transform 13 5513 env23094 = env23095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env23094 == env23095) = true)

theorem identity23095 : scanCanonicalize (H12AffineFastState.compose env23095 (packedSelected [0,1,7,8,9,14,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound23095 : packedSelected [0,1,7,8,9,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env23096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33110,38296,10281,1024,32769,4160,169,41293,138,8328,65,2048,5393,45525,35188,42112,41340,256,41461,5593,513]

theorem envBound23096 : H12AffineFastState.Bounded env23096 := by
  intro p hp
  have h : env23096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23095_23096 : H12AffineEnvironment.transform 15 33110 env23095 = env23096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env23095 == env23096) = true)

theorem identity23096 : scanCanonicalize (H12AffineFastState.compose env23096 (packedSelected [2,3,4,5,6,9,10,14,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23096 : packedSelected [2,3,4,5,6,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env23097 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,33031,38296,10281,1024,32769,4113,169,41244,138,8328,16,2048,5393,45444,35109,42112,41261,256,41380,5512,513]

theorem envBound23097 : H12AffineFastState.Bounded env23097 := by
  intro p hp
  have h : env23097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23096_23097 : H12AffineEnvironment.transform 5 17 env23096 = env23097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23096 == env23097) = true)

theorem identity23097 : scanCanonicalize (H12AffineFastState.compose env23097 (packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23097 : packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env23098 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5513,32768,33031,38296,2341,1024,32769,4113,169,32784,138,388,16,2048,5393,37000,35109,34188,32801,256,32936,5512,513]

theorem envBound23098 : H12AffineFastState.Bounded env23098 := by
  intro p hp
  have h : env23098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23097_23098 : H12AffineEnvironment.transform 12 268 env23097 = env23098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23097 == env23098) = true)

theorem identity23098 : scanCanonicalize (H12AffineFastState.compose env23098 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23098 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23099 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,32768,33031,38160,2341,1024,32769,4113,33,32784,2,268,16,2048,5393,36864,35109,34052,32801,256,32800,5376,513]

theorem envBound23099 : H12AffineFastState.Bounded env23099 := by
  intro p hp
  have h : env23099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23098_23099 : H12AffineEnvironment.transform 6 8 env23098 = env23099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23098 == env23099) = true)

theorem identity23099 : scanCanonicalize (H12AffineFastState.compose env23099 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23099 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23100 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,262,5393,2341,1024,0,4113,33,17,2,268,16,2048,5393,4097,2340,1285,32,256,33,5376,513]

theorem envBound23100 : H12AffineFastState.Bounded env23100 := by
  intro p hp
  have h : env23100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23099_23100 : H12AffineEnvironment.transform 14 1 env23099 = env23100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23099 == env23100) = true)

theorem identity23100 : scanCanonicalize (H12AffineFastState.compose env23100 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound23100 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23101 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1029,268,260,1,262,276,2341,1024,0,1044,33,17,2,268,16,2048,276,1028,2340,1285,32,256,33,261,513]

theorem envBound23101 : H12AffineFastState.Bounded env23101 := by
  intro p hp
  have h : env23101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23100_23101 : H12AffineEnvironment.transform 11 1029 env23100 = env23101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env23100 == env23101) = true)

theorem identity23101 : scanCanonicalize (H12AffineFastState.compose env23101 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1850) := by decide +kernel

theorem selectedBound23101 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23102 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1850,1029,268,260,1,262,276,1567,1024,0,1044,33,17,2,268,16,1850,276,1028,1566,1285,32,256,33,261,513]

theorem envBound23102 : H12AffineFastState.Bounded env23102 := by
  intro p hp
  have h : env23102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23101_23102 : H12AffineEnvironment.transform 10 1850 env23101 = env23102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1850 env23101 == env23102) = true)

theorem identity23102 : scanCanonicalize (H12AffineFastState.compose env23102 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound23102 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23103 : List Nat := [2,4,8,16,32,17,8,256,512,62,772,59,268,260,1,262,276,545,62,0,42,33,17,2,268,16,772,276,58,544,315,32,256,33,261,513]

theorem envBound23103 : H12AffineFastState.Bounded env23103 := by
  intro p hp
  have h : env23103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23102_23103 : H12AffineEnvironment.transform 9 62 env23102 = env23103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env23102 == env23103) = true)

theorem identity23103 : scanCanonicalize (H12AffineFastState.compose env23103 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound23103 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23104 : List Nat := [2,4,8,16,32,17,8,256,58,62,318,59,268,260,1,262,276,27,62,0,42,33,17,2,268,16,318,276,58,26,315,32,256,33,261,59]

theorem envBound23104 : H12AffineFastState.Bounded env23104 := by
  intro p hp
  have h : env23104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23103_23104 : H12AffineEnvironment.transform 8 58 env23103 = env23104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env23103 == env23104) = true)

theorem identity23104 : scanCanonicalize (H12AffineFastState.compose env23104 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound23104 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23105 : List Nat := [2,4,8,16,32,17,8,52,58,62,10,59,56,48,1,50,32,27,62,0,42,33,17,2,56,16,10,32,58,26,15,32,52,33,49,59]

theorem envBound23105 : H12AffineFastState.Bounded env23105 := by
  intro p hp
  have h : env23105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23104_23105 : H12AffineEnvironment.transform 7 52 env23104 = env23105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env23104 == env23105) = true)

theorem identity23105 : scanCanonicalize (H12AffineFastState.compose env23105 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound23105 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env23106 : List Nat := [2,4,8,16,11,17,8,31,17,21,10,16,19,27,1,25,11,27,21,0,1,10,17,2,19,16,10,11,17,26,15,11,31,10,26,16]

theorem envBound23106 : H12AffineFastState.Bounded env23106 := by
  intro p hp
  have h : env23106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23105_23106 : H12AffineEnvironment.transform 4 11 env23105 = env23106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env23105 == env23106) = true)

theorem identity23106 : scanCanonicalize (H12AffineFastState.compose env23106 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound23106 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23107 : List Nat := [2,4,4,16,7,17,4,19,17,21,6,16,19,23,1,21,7,23,21,0,1,6,17,2,19,16,6,7,17,22,3,7,19,6,22,16]

theorem envBound23107 : H12AffineFastState.Bounded env23107 := by
  intro p hp
  have h : env23107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23106_23107 : H12AffineEnvironment.transform 2 4 env23106 = env23107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env23106 == env23107) = true)

theorem identity23107 : scanCanonicalize (H12AffineFastState.compose env23107 (packedSelected [0,9] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound23107 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env23108 : List Nat := [2,2,2,16,1,17,2,19,17,19,0,16,19,17,1,19,1,17,19,0,1,0,17,2,19,16,0,1,17,16,3,1,19,0,16,16]

theorem envBound23108 : H12AffineFastState.Bounded env23108 := by
  intro p hp
  have h : env23108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23107_23108 : H12AffineEnvironment.transform 1 2 env23107 = env23108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env23107 == env23108) = true)

theorem identity23108 : scanCanonicalize (H12AffineFastState.compose env23108 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound23108 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23109 : List Nat := [0,0,0,16,1,17,0,17,17,17,0,16,17,17,1,17,1,17,17,0,1,0,17,0,17,16,0,1,17,16,1,1,17,0,16,16]

theorem envBound23109 : H12AffineFastState.Bounded env23109 := by
  intro p hp
  have h : env23109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23108_23109 : H12AffineEnvironment.transform 0 0 env23108 = env23109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env23108 == env23109) = true)

def env23110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412021,21762,8328,65,215367,115150,396389,35188,497766,243123,256,510107,469310,442289]

theorem envBound23110 : H12AffineFastState.Bounded env23110 := by
  intro p hp
  have h : env23110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23058_23110 : H12AffineEnvironment.transform 20 4161 env23058 = env23110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env23058 == env23110) = true)

theorem identity23110 : scanCanonicalize (H12AffineFastState.compose env23110 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179632) := by decide +kernel

theorem selectedBound23110 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,169264,62661,21762,8328,65,215367,115150,45525,35188,75222,243123,256,95531,103566,513]

theorem envBound23111 : H12AffineFastState.Bounded env23111 := by
  intro p hp
  have h : env23111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23110_23111 : H12AffineEnvironment.transform 17 179632 env23110 = env23111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env23110 == env23111) = true)

def env23112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,169264,62541,21762,8192,65,215367,115014,45405,35188,75102,243003,256,95531,103430,513]

theorem envBound23112 : H12AffineFastState.Bounded env23112 := by
  intro p hp
  have h : env23112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23111_23112 : H12AffineEnvironment.transform 6 8 env23111 = env23112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23111 == env23112) = true)

theorem identity23112 : scanCanonicalize (H12AffineFastState.compose env23112 (packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound23112 : packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env23113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4161,33,62541,21762,8192,65,121942,115014,45405,35188,75102,73770,256,95531,103430,513]

theorem envBound23113 : H12AffineFastState.Bounded env23113 := by
  intro p hp
  have h : env23113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23112_23113 : H12AffineEnvironment.transform 16 38161 env23112 = env23113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env23112 == env23113) = true)

theorem identity23113 : scanCanonicalize (H12AffineFastState.compose env23113 (packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound23113 : packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS < 2^1333 := by decide +kernel

def env23114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,65536,5440,10281,1024,80,4161,33,29724,21762,8192,65,89095,82199,12556,2341,75102,73770,256,95531,70743,513]

theorem envBound23114 : H12AffineFastState.Bounded env23114 := by
  intro p hp
  have h : env23114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23113_23114 : H12AffineEnvironment.transform 14 81 env23113 = env23114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env23113 == env23114) = true)

theorem identity23114 : scanCanonicalize (H12AffineFastState.compose env23114 (packedSelected [1,2,3,4,5,6,8,9,12,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound23114 : packedSelected [1,2,3,4,5,6,8,9,12,14,16] rootPS < 2^1333 := by decide +kernel

def env23115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,21510,5440,10281,1024,80,4161,33,29724,21762,8192,65,2049,5393,12556,2341,29016,29740,256,8493,16465,513]

theorem envBound23115 : H12AffineFastState.Bounded env23115 := by
  intro p hp
  have h : env23115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23114_23115 : H12AffineEnvironment.transform 15 21510 env23114 = env23115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env23114 == env23115) = true)

theorem identity23115 : scanCanonicalize (H12AffineFastState.compose env23115 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23115 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env23116 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,1,21510,5392,10281,1024,0,4113,33,29724,21762,8192,17,2049,5393,12556,2341,28936,29740,256,8493,16385,513]

theorem envBound23116 : H12AffineFastState.Bounded env23116 := by
  intro p hp
  have h : env23116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23115_23116 : H12AffineEnvironment.transform 5 16 env23115 = env23116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23115 == env23116) = true)

theorem identity23116 : scanCanonicalize (H12AffineFastState.compose env23116 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound23116 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env23117 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,1,8202,5392,10281,1024,0,4113,33,16,8462,8192,17,2049,5393,12556,2341,1284,32,256,8493,13325,513]

theorem envBound23117 : H12AffineFastState.Bounded env23117 := by
  intro p hp
  have h : env23117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23116_23117 : H12AffineEnvironment.transform 13 13324 env23116 = env23117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env23116 == env23117) = true)

theorem identity23117 : scanCanonicalize (H12AffineFastState.compose env23117 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound23117 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env23118 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1588,8192,8760,1,8202,804,10281,1024,0,1573,33,16,8462,8192,17,2049,805,10040,2341,1284,32,256,8493,8761,513]

theorem envBound23118 : H12AffineFastState.Bounded env23118 := by
  intro p hp
  have h : env23118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23117_23118 : H12AffineEnvironment.transform 11 1588 env23117 = env23118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env23117 == env23118) = true)

theorem identity23118 : scanCanonicalize (H12AffineFastState.compose env23118 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23118 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23119 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1588,268,820,1,262,804,2341,1024,0,1573,33,16,2,268,17,2049,805,1588,2341,1284,32,256,33,821,513]

theorem envBound23119 : H12AffineFastState.Bounded env23119 := by
  intro p hp
  have h : env23119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23118_23119 : H12AffineEnvironment.transform 12 268 env23118 = env23119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23118 == env23119) = true)

theorem identity23119 : scanCanonicalize (H12AffineFastState.compose env23119 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound23119 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23120 : List Nat := [2,4,8,16,32,16,8,21,512,1024,2048,1588,25,545,1,19,561,2096,1024,0,1573,33,16,2,25,17,2049,560,1588,2096,1041,32,21,33,544,513]

theorem envBound23120 : H12AffineFastState.Bounded env23120 := by
  intro p hp
  have h : env23120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23119_23120 : H12AffineEnvironment.transform 7 21 env23119 = env23120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env23119 == env23120) = true)

theorem identity23120 : scanCanonicalize (H12AffineFastState.compose env23120 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound23120 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23121 : List Nat := [2,4,8,16,32,16,8,21,512,1024,538,1588,25,545,1,19,561,554,1024,0,1573,33,16,2,25,17,539,560,1588,554,1041,32,21,33,544,513]

theorem envBound23121 : H12AffineFastState.Bounded env23121 := by
  intro p hp
  have h : env23121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23120_23121 : H12AffineEnvironment.transform 10 538 env23120 = env23121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env23120 == env23121) = true)

theorem identity23121 : scanCanonicalize (H12AffineFastState.compose env23121 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound23121 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23122 : List Nat := [2,4,8,16,32,16,8,21,16,1024,10,1060,25,49,1,19,33,58,1024,0,1077,33,16,2,25,17,11,32,1060,58,1041,32,21,33,48,17]

theorem envBound23122 : H12AffineFastState.Bounded env23122 := by
  intro p hp
  have h : env23122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23121_23122 : H12AffineEnvironment.transform 8 16 env23121 = env23122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env23121 == env23122) = true)

theorem identity23122 : scanCanonicalize (H12AffineFastState.compose env23122 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound23122 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23123 : List Nat := [2,4,8,16,32,16,8,21,16,14,10,42,25,49,1,19,33,58,14,0,59,33,16,2,25,17,11,32,42,58,31,32,21,33,48,17]

theorem envBound23123 : H12AffineFastState.Bounded env23123 := by
  intro p hp
  have h : env23123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23122_23123 : H12AffineEnvironment.transform 9 14 env23122 = env23123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env23122 == env23123) = true)

theorem identity23123 : scanCanonicalize (H12AffineFastState.compose env23123 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound23123 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23124 : List Nat := [2,4,8,16,10,16,8,21,16,14,10,0,25,27,1,19,11,16,14,0,17,11,16,2,25,17,11,10,0,16,31,10,21,11,26,17]

theorem envBound23124 : H12AffineFastState.Bounded env23124 := by
  intro p hp
  have h : env23124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23123_23124 : H12AffineEnvironment.transform 4 10 env23123 = env23124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env23123 == env23124) = true)

theorem identity23124 : scanCanonicalize (H12AffineFastState.compose env23124 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound23124 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23125 : List Nat := [2,0,8,16,10,16,8,17,16,10,10,0,25,27,1,19,11,16,10,0,17,11,16,2,25,17,11,10,0,16,27,10,17,11,26,17]

theorem envBound23125 : H12AffineFastState.Bounded env23125 := by
  intro p hp
  have h : env23125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23124_23125 : H12AffineEnvironment.transform 1 0 env23124 = env23125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env23124 == env23125) = true)

theorem identity23125 : scanCanonicalize (H12AffineFastState.compose env23125 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound23125 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23126 : List Nat := [1,0,8,16,9,16,8,17,16,9,9,0,25,24,1,16,8,16,9,0,17,8,16,1,25,17,8,9,0,16,24,9,17,8,25,17]

theorem envBound23126 : H12AffineFastState.Bounded env23126 := by
  intro p hp
  have h : env23126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23125_23126 : H12AffineEnvironment.transform 0 1 env23125 = env23126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env23125 == env23126) = true)

theorem identity23126 : scanCanonicalize (H12AffineFastState.compose env23126 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound23126 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env23127 : List Nat := [1,0,1,16,0,16,1,17,16,0,0,0,16,17,1,16,1,16,0,0,17,1,16,1,16,17,1,0,0,16,17,0,17,1,16,17]

theorem envBound23127 : H12AffineFastState.Bounded env23127 := by
  intro p hp
  have h : env23127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23126_23127 : H12AffineEnvironment.transform 2 1 env23126 = env23127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env23126 == env23127) = true)

def env23128 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,169264,62540,21762,8193,65,215367,115015,45404,35188,75103,243002,256,95531,103431,513]

theorem envBound23128 : H12AffineFastState.Bounded env23128 := by
  intro p hp
  have h : env23128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23111_23128 : H12AffineEnvironment.transform 6 9 env23111 = env23128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23111 == env23128) = true)

theorem identity23128 : scanCanonicalize (H12AffineFastState.compose env23128 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound23128 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env23129 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,122146,1024,32769,4161,128299,62540,21762,8193,65,10588,115015,45404,35188,75103,54561,256,95531,103431,513]

theorem envBound23129 : H12AffineFastState.Bounded env23129 := by
  intro p hp
  have h : env23129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23128_23129 : H12AffineEnvironment.transform 16 90139 env23128 = env23129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env23128 == env23129) = true)

theorem identity23129 : scanCanonicalize (H12AffineFastState.compose env23129 (packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS)) = affineNative (2^(15+1) ^^^ 34146) := by decide +kernel

theorem selectedBound23129 : packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env23130 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,34146,58745,22592,1024,32769,4161,28745,62540,21762,8193,65,10588,17445,45404,35188,41021,54561,256,61513,4453,513]

theorem envBound23130 : H12AffineFastState.Bounded env23130 := by
  intro p hp
  have h : env23130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23129_23130 : H12AffineEnvironment.transform 15 34146 env23129 = env23130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34146 env23129 == env23130) = true)

theorem identity23130 : scanCanonicalize (H12AffineFastState.compose env23130 (packedSelected [4,8,9,10,14,17,18,20,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 30072) := by decide +kernel

theorem selectedBound23130 : packedSelected [4,8,9,10,14,17,18,20,28,32] rootPS < 2^1333 := by decide +kernel

def env23131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,30072,28698,4097,22592,1024,30073,4161,28745,308,21762,8193,65,10588,17445,17444,31756,21829,8281,256,1329,4453,513]

theorem envBound23131 : H12AffineFastState.Bounded env23131 := by
  intro p hp
  have h : env23131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23130_23131 : H12AffineEnvironment.transform 14 30072 env23130 = env23131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30072 env23130 == env23131) = true)

theorem identity23131 : scanCanonicalize (H12AffineFastState.compose env23131 (packedSelected [0,1,2,4,5,6,9,10,11,12,15,17,18,20,24,27,28] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound23131 : packedSelected [0,1,2,4,5,6,9,10,11,12,15,17,18,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env23132 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,16384,28957,28698,4097,22592,101,28956,4161,28745,308,20839,8193,65,10588,16448,16449,30825,20768,8281,256,340,4453,513]

theorem envBound23132 : H12AffineFastState.Bounded env23132 := by
  intro p hp
  have h : env23132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23131_23132 : H12AffineEnvironment.transform 9 101 env23131 = env23132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env23131 == env23132) = true)

theorem identity23132 : scanCanonicalize (H12AffineFastState.compose env23132 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23132 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23133 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,4096,8192,16384,28777,28698,4097,22592,101,28776,4161,28745,64,20499,8193,65,10280,16448,16449,30825,20564,8281,116,32,4113,513]

theorem envBound23133 : H12AffineFastState.Bounded env23133 := by
  intro p hp
  have h : env23133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23132_23133 : H12AffineEnvironment.transform 7 116 env23132 = env23133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23132 == env23133) = true)

theorem identity23133 : scanCanonicalize (H12AffineFastState.compose env23133 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound23133 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23134 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,4096,40,16384,20545,20530,4097,22592,101,20544,4161,20577,64,20499,41,65,2048,16448,16449,22593,20564,113,116,32,4113,513]

theorem envBound23134 : H12AffineFastState.Bounded env23134 := by
  intro p hp
  have h : env23134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23133_23134 : H12AffineEnvironment.transform 12 40 env23133 = env23134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env23133 == env23134) = true)

theorem identity23134 : scanCanonicalize (H12AffineFastState.compose env23134 (packedSelected [12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23134 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env23135 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,16384,20496,20530,4097,22545,52,20497,4112,20528,17,20499,41,16,2048,16401,16400,22544,20485,32,37,32,4113,513]

theorem envBound23135 : H12AffineFastState.Bounded env23135 := by
  intro p hp
  have h : env23135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23134_23135 : H12AffineEnvironment.transform 5 17 env23134 = env23135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23134 == env23135) = true)

theorem identity23135 : scanCanonicalize (H12AffineFastState.compose env23135 (packedSelected [3,4] rootPS)) = affineNative (2^(13+1) ^^^ 6177) := by decide +kernel

theorem selectedBound23135 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env23136 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,6177,2097,2067,4097,48,52,2096,4112,2065,17,2098,41,16,2048,6192,6193,49,2084,32,37,32,4113,513]

theorem envBound23136 : H12AffineFastState.Bounded env23136 := by
  intro p hp
  have h : env23136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23135_23136 : H12AffineEnvironment.transform 13 6177 env23135 = env23136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6177 env23135 == env23136) = true)

theorem identity23136 : scanCanonicalize (H12AffineFastState.compose env23136 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound23136 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env23137 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,560,40,2577,2097,2067,561,48,52,2096,544,2065,17,2098,41,16,2048,2560,2561,49,2084,32,37,32,545,513]

theorem envBound23137 : H12AffineFastState.Bounded env23137 := by
  intro p hp
  have h : env23137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23136_23137 : H12AffineEnvironment.transform 11 560 env23136 = env23137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env23136 == env23137) = true)

theorem identity23137 : scanCanonicalize (H12AffineFastState.compose env23137 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound23137 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env23138 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,560,40,1,545,515,561,48,52,544,544,513,17,546,41,16,528,16,17,49,564,32,37,32,545,513]

theorem envBound23138 : H12AffineFastState.Bounded env23138 := by
  intro p hp
  have h : env23138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23137_23138 : H12AffineEnvironment.transform 10 528 env23137 = env23138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env23137 == env23138) = true)

theorem identity23138 : scanCanonicalize (H12AffineFastState.compose env23138 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound23138 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23139 : List Nat := [2,4,8,16,32,17,9,37,16,52,0,32,40,1,49,19,33,48,52,48,48,17,17,50,41,16,0,16,17,49,36,32,37,32,49,17]

theorem envBound23139 : H12AffineFastState.Bounded env23139 := by
  intro p hp
  have h : env23139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23138_23139 : H12AffineEnvironment.transform 8 16 env23138 = env23139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env23138 == env23139) = true)

theorem identity23139 : scanCanonicalize (H12AffineFastState.compose env23139 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound23139 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23140 : List Nat := [2,4,8,16,17,17,9,20,16,5,0,17,25,1,0,19,16,1,5,1,1,17,17,3,24,16,0,16,17,0,21,17,20,17,0,17]

theorem envBound23140 : H12AffineFastState.Bounded env23140 := by
  intro p hp
  have h : env23140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23139_23140 : H12AffineEnvironment.transform 4 17 env23139 = env23140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env23139 == env23140) = true)

theorem identity23140 : scanCanonicalize (H12AffineFastState.compose env23140 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23140 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23141 : List Nat := [2,4,8,0,1,1,9,4,0,5,0,1,9,1,0,3,0,1,5,1,1,1,1,3,8,0,0,0,1,0,5,1,4,1,0,1]

theorem envBound23141 : H12AffineFastState.Bounded env23141 := by
  intro p hp
  have h : env23141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23140_23141 : H12AffineEnvironment.transform 3 0 env23140 = env23141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23140 == env23141) = true)

def env23142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound23142 : H12AffineFastState.Bounded env23142 := by
  intro p hp
  have h : env23142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22933_23142 : H12AffineEnvironment.transform 18 1025 env22933 = env23142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env22933 == env23142) = true)

theorem identity23142 : scanCanonicalize (H12AffineFastState.compose env23142 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 388278) := by decide +kernel

theorem selectedBound23142 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388278,4194304,8388608,16777216,8328,65,29868033,17066042,8763879,8830976,25265169,21268854,257,25438234,25479614,25207751]

theorem envBound23143 : H12AffineFastState.Bounded env23143 := by
  intro p hp
  have h : env23143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23142_23143 : H12AffineEnvironment.transform 20 388278 env23142 = env23143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388278 env23142 == env23143) = true)

def env23144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388278,4194304,8388608,351520,8328,65,12754209,79130,8763879,8830976,8706353,4314198,257,8484154,8492190,8781543]

theorem envBound23144 : H12AffineFastState.Bounded env23144 := by
  intro p hp
  have h : env23144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23143_23144 : H12AffineEnvironment.transform 23 351520 env23143 = env23144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351520 env23143 == env23144) = true)

def env23145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,4194304,8388608,95496,8328,65,12754209,79130,8491471,8579112,8450329,4314198,257,8484154,8492190,8509135]

theorem envBound23145 : H12AffineFastState.Bounded env23145 := by
  intro p hp
  have h : env23145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23144_23145 : H12AffineEnvironment.transform 17 10280 env23144 = env23145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23144 == env23145) = true)

def env23146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,4194304,16,95496,8328,65,4365617,79130,102879,190520,61705,4314198,257,95530,103566,120543]

theorem envBound23146 : H12AffineFastState.Bounded env23146 := by
  intro p hp
  have h : env23146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23145_23146 : H12AffineEnvironment.transform 22 16 env23145 = env23146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env23145 == env23146) = true)

theorem identity23146 : scanCanonicalize (H12AffineFastState.compose env23146 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound23146 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,73891,16,95496,8328,65,245138,79130,102879,190520,61705,62709,257,95530,103566,120543]

theorem envBound23147 : H12AffineFastState.Bounded env23147 := by
  intro p hp
  have h : env23147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23146_23147 : H12AffineEnvironment.transform 21 73891 env23146 = env23147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env23146 == env23147) = true)

theorem identity23147 : scanCanonicalize (H12AffineFastState.compose env23147 (packedSelected [1,5,8,12,15,17,19,24,26,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 103630) := by decide +kernel

theorem selectedBound23147 : packedSelected [1,5,8,12,15,17,19,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env23148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103630,10280,1025,32769,115870,73891,16,95496,8328,65,10588,79130,102879,97526,61705,62709,257,95530,103566,120543]

theorem envBound23148 : H12AffineFastState.Bounded env23148 := by
  intro p hp
  have h : env23148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23147_23148 : H12AffineEnvironment.transform 16 103630 env23147 = env23148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103630 env23147 == env23148) = true)

def env23149 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,103494,10280,1025,32769,115734,73771,16,95496,8192,65,10588,79130,102743,97406,61705,62589,257,95530,103430,120407]

theorem envBound23149 : H12AffineFastState.Bounded env23149 := by
  intro p hp
  have h : env23149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23148_23149 : H12AffineEnvironment.transform 6 8 env23148 = env23149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23148 == env23149) = true)

theorem identity23149 : scanCanonicalize (H12AffineFastState.compose env23149 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound23149 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23150 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,57677,10280,1025,32769,45341,21792,16,3,8192,65,10588,16401,58460,2421,61705,62589,257,33,57613,41820]

theorem envBound23150 : H12AffineFastState.Bounded env23150 := by
  intro p hp
  have h : env23150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23149_23150 : H12AffineEnvironment.transform 15 29963 env23149 = env23150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env23149 == env23150) = true)

theorem identity23150 : scanCanonicalize (H12AffineFastState.compose env23150 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound23150 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env23151 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29963,5392,10280,1025,29788,17728,21792,16,3,8192,65,10588,16401,4097,2421,1364,32,257,33,5456,22273]

theorem envBound23151 : H12AffineFastState.Bounded env23151 := by
  intro p hp
  have h : env23151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23150_23151 : H12AffineEnvironment.transform 14 29789 env23150 = env23151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env23150 == env23151) = true)

theorem identity23151 : scanCanonicalize (H12AffineFastState.compose env23151 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23151 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env23152 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29789,29822,5221,10280,1025,29788,17461,21589,16,3,8192,65,10281,16401,4097,2048,1057,32,116,33,5157,22132]

theorem envBound23152 : H12AffineFastState.Bounded env23152 := by
  intro p hp
  have h : env23152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23151_23152 : H12AffineEnvironment.transform 7 117 env23151 = env23152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23151 == env23152) = true)

theorem identity23152 : scanCanonicalize (H12AffineFastState.compose env23152 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound23152 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env23153 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,3148,16384,22545,22578,5221,1124,1025,22544,17461,21589,16,3,3148,65,1125,16401,4097,2048,1057,32,116,33,5157,22132]

theorem envBound23153 : H12AffineFastState.Bounded env23153 := by
  intro p hp
  have h : env23153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23152_23153 : H12AffineEnvironment.transform 12 3148 env23152 = env23153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env23152 == env23153) = true)

theorem identity23153 : scanCanonicalize (H12AffineFastState.compose env23153 (packedSelected [0,1,3,5,7,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 1124) := by decide +kernel

theorem selectedBound23153 : packedSelected [0,1,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env23154 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,3148,1124,7285,7254,5221,1124,1025,7284,81,4145,16,3,3148,65,1125,1141,4097,2048,1057,32,116,33,5157,4624]

theorem envBound23154 : H12AffineFastState.Bounded env23154 := by
  intro p hp
  have h : env23154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23153_23154 : H12AffineEnvironment.transform 13 1124 env23153 = env23154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1124 env23153 == env23154) = true)

theorem identity23154 : scanCanonicalize (H12AffineFastState.compose env23154 (packedSelected [0,2,4,6,10] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound23154 : packedSelected [0,2,4,6,10] rootPS < 2^1333 := by decide +kernel

def env23155 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1077,4096,121,1124,4160,4195,5221,1124,1025,4161,81,4145,16,3,121,65,1125,1141,4097,1077,1057,32,116,33,5157,4624]

theorem envBound23155 : H12AffineFastState.Bounded env23155 := by
  intro p hp
  have h : env23155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23154_23155 : H12AffineEnvironment.transform 10 1077 env23154 = env23155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env23154 == env23155) = true)

theorem identity23155 : scanCanonicalize (H12AffineFastState.compose env23155 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound23155 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env23156 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1077,17,121,1124,81,114,1140,1124,1025,80,81,32,16,3,121,65,1125,1141,16,1077,1057,32,116,33,1076,513]

theorem envBound23156 : H12AffineFastState.Bounded env23156 := by
  intro p hp
  have h : env23156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23155_23156 : H12AffineEnvironment.transform 11 17 env23155 = env23156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env23155 == env23156) = true)

theorem identity23156 : scanCanonicalize (H12AffineFastState.compose env23156 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound23156 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env23157 : List Nat := [2,4,8,16,32,64,8,117,512,101,80,17,121,1,81,114,17,1,100,80,81,32,16,3,121,65,0,16,16,80,68,32,116,33,81,513]

theorem envBound23157 : H12AffineFastState.Bounded env23157 := by
  intro p hp
  have h : env23157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23156_23157 : H12AffineEnvironment.transform 9 101 env23156 = env23157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env23156 == env23157) = true)

theorem identity23157 : scanCanonicalize (H12AffineFastState.compose env23157 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound23157 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23158 : List Nat := [2,4,8,16,32,64,8,117,80,101,80,17,121,1,81,114,17,1,100,80,81,32,16,3,121,65,0,16,16,80,68,32,116,33,81,81]

theorem envBound23158 : H12AffineFastState.Bounded env23158 := by
  intro p hp
  have h : env23158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23157_23158 : H12AffineEnvironment.transform 8 80 env23157 = env23158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env23157 == env23158) = true)

theorem identity23158 : scanCanonicalize (H12AffineFastState.compose env23158 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound23158 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23159 : List Nat := [2,4,2,16,32,64,2,117,80,101,80,17,115,1,81,114,17,1,100,80,81,32,16,3,115,65,0,16,16,80,68,32,116,33,81,81]

theorem envBound23159 : H12AffineFastState.Bounded env23159 := by
  intro p hp
  have h : env23159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23158_23159 : H12AffineEnvironment.transform 2 2 env23158 = env23159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env23158 == env23159) = true)

def env23160 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,103495,10280,1025,32769,115735,73770,16,95496,8193,65,10588,79130,102742,97407,61705,62588,257,95530,103431,120406]

theorem envBound23160 : H12AffineFastState.Bounded env23160 := by
  intro p hp
  have h : env23160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23148_23160 : H12AffineEnvironment.transform 6 9 env23148 = env23160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23148 == env23160) = true)

theorem identity23160 : scanCanonicalize (H12AffineFastState.compose env23160 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound23160 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23161 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,16401,10280,1025,32769,4161,62588,16,41310,8193,65,10588,57676,17664,43049,61705,62588,257,41340,16465,512]

theorem envBound23161 : H12AffineFastState.Bounded env23161 := by
  intro p hp
  have h : env23161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23160_23161 : H12AffineEnvironment.transform 15 54358 env23160 = env23161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env23160 == env23161) = true)

theorem identity23161 : scanCanonicalize (H12AffineFastState.compose env23161 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 15624) := by decide +kernel

theorem selectedBound23161 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env23162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,15624,26974,16401,10280,1025,15625,4161,18804,16,7254,8193,65,10588,23620,17664,5409,19457,18804,257,7284,16465,512]

theorem envBound23162 : H12AffineFastState.Bounded env23162 := by
  intro p hp
  have h : env23162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23161_23162 : H12AffineEnvironment.transform 14 15624 env23161 = env23162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15624 env23161 == env23162) = true)

theorem identity23162 : scanCanonicalize (H12AffineFastState.compose env23162 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 2080) := by decide +kernel

theorem selectedBound23162 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,2080,15624,8574,2097,10280,1025,15625,4161,340,16,7254,8193,65,10588,5220,3360,5409,1057,340,257,7284,2161,512]

theorem envBound23163 : H12AffineFastState.Bounded env23163 := by
  intro p hp
  have h : env23163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23162_23163 : H12AffineEnvironment.transform 13 2080 env23162 = env23163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2080 env23162 == env23163) = true)

theorem identity23163 : scanCanonicalize (H12AffineFastState.compose env23163 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound23163 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env23164 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,2080,7537,263,2097,2129,1025,7536,4161,340,16,7254,120,65,2341,5220,3360,5409,1057,340,257,7284,2161,512]

theorem envBound23164 : H12AffineFastState.Bounded env23164 := by
  intro p hp
  have h : env23164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23163_23164 : H12AffineEnvironment.transform 12 121 env23163 = env23164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env23163 == env23164) = true)

theorem identity23164 : scanCanonicalize (H12AffineFastState.compose env23164 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound23164 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env23165 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,121,2080,113,263,2097,2129,1025,112,3393,340,16,342,120,65,2341,2404,3360,2081,1057,340,257,372,2161,512]

theorem envBound23165 : H12AffineFastState.Bounded env23165 := by
  intro p hp
  have h : env23165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23164_23165 : H12AffineEnvironment.transform 11 3328 env23164 = env23165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env23164 == env23165) = true)

theorem identity23165 : scanCanonicalize (H12AffineFastState.compose env23165 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23165 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env23166 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,3328,88,2049,80,263,2064,2129,1025,81,3393,340,16,342,89,65,2308,2373,3329,2048,1024,340,257,341,2128,512]

theorem envBound23166 : H12AffineFastState.Bounded env23166 := by
  intro p hp
  have h : env23166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23165_23166 : H12AffineEnvironment.transform 4 1 env23165 = env23166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23165 == env23166) = true)

theorem identity23166 : scanCanonicalize (H12AffineFastState.compose env23166 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound23166 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23167 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,3156,88,2049,80,83,2064,2129,1025,81,3093,0,16,2,89,65,2128,2065,3157,2048,1024,0,85,1,2128,512]

theorem envBound23167 : H12AffineFastState.Bounded env23167 := by
  intro p hp
  have h : env23167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23166_23167 : H12AffineEnvironment.transform 7 84 env23166 = env23167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env23166 == env23167) = true)

theorem identity23167 : scanCanonicalize (H12AffineFastState.compose env23167 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound23167 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23168 : List Nat := [2,4,8,16,1,64,9,84,512,1024,1045,65,88,1044,80,83,1029,1092,1025,81,0,0,16,2,89,65,1093,1028,64,1045,1024,0,85,1,1093,512]

theorem envBound23168 : H12AffineFastState.Bounded env23168 := by
  intro p hp
  have h : env23168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23167_23168 : H12AffineEnvironment.transform 10 1045 env23167 = env23168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env23167 == env23168) = true)

theorem identity23168 : scanCanonicalize (H12AffineFastState.compose env23168 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound23168 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23169 : List Nat := [2,4,8,16,1,64,9,84,512,20,1,65,88,0,80,83,17,80,21,81,0,0,16,2,89,65,81,16,64,1,20,0,85,1,81,512]

theorem envBound23169 : H12AffineFastState.Bounded env23169 := by
  intro p hp
  have h : env23169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23168_23169 : H12AffineEnvironment.transform 9 20 env23168 = env23169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env23168 == env23169) = true)

theorem identity23169 : scanCanonicalize (H12AffineFastState.compose env23169 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23169 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23170 : List Nat := [2,4,8,16,1,16,9,4,512,20,1,17,8,0,0,3,17,0,21,1,0,0,16,2,9,17,1,16,16,1,20,0,5,1,1,512]

theorem envBound23170 : H12AffineFastState.Bounded env23170 := by
  intro p hp
  have h : env23170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23169_23170 : H12AffineEnvironment.transform 5 16 env23169 = env23170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23169 == env23170) = true)

theorem identity23170 : scanCanonicalize (H12AffineFastState.compose env23170 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound23170 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23171 : List Nat := [2,4,8,16,1,16,9,4,15,20,1,17,8,0,0,3,17,0,21,1,0,0,16,2,9,17,1,16,16,1,20,0,5,1,1,15]

theorem envBound23171 : H12AffineFastState.Bounded env23171 := by
  intro p hp
  have h : env23171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23170_23171 : H12AffineEnvironment.transform 8 15 env23170 = env23171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env23170 == env23171) = true)

def env23172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,4194304,17,95496,8328,65,4365616,79130,102878,190521,61704,4314198,257,95531,103567,120542]

theorem envBound23172 : H12AffineFastState.Bounded env23172 := by
  intro p hp
  have h : env23172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23145_23172 : H12AffineEnvironment.transform 22 17 env23145 = env23172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env23145 == env23172) = true)

theorem identity23172 : scanCanonicalize (H12AffineFastState.compose env23172 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound23172 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10280,1025,32769,58516,4194304,17,21762,8328,65,4365616,5392,45524,190521,61704,4256860,257,21793,46213,63188]

theorem envBound23173 : H12AffineFastState.Bounded env23173 := by
  intro p hp
  have h : env23173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23172_23173 : H12AffineEnvironment.transform 15 8202 env23172 = env23173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env23172 == env23173) = true)

theorem identity23173 : scanCanonicalize (H12AffineFastState.compose env23173 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 62629) := by decide +kernel

theorem selectedBound23173 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env23174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10280,1025,32769,58516,62629,17,21762,8328,65,158101,5392,45524,190521,61704,249,257,21793,46213,63188]

theorem envBound23174 : H12AffineFastState.Bounded env23174 := by
  intro p hp
  have h : env23174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23173_23174 : H12AffineEnvironment.transform 21 62629 env23173 = env23174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62629 env23173 == env23174) = true)

theorem identity23174 : scanCanonicalize (H12AffineFastState.compose env23174 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound23174 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env23175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,46276,10280,1025,32769,58516,62629,17,21762,8328,65,56657,5392,45524,23805,61704,249,257,21793,46213,63188]

theorem envBound23175 : H12AffineFastState.Bounded env23175 := by
  intro p hp
  have h : env23175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23174_23175 : H12AffineEnvironment.transform 16 46276 env23174 = env23175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env23174 == env23175) = true)

theorem identity23175 : scanCanonicalize (H12AffineFastState.compose env23175 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound23175 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23176 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,8192,16384,32768,8202,45405,10280,408,32769,57613,61756,17,20635,8328,65,55496,4233,45524,22884,61704,249,257,20664,45340,62285]

theorem envBound23176 : H12AffineFastState.Bounded env23176 := by
  intro p hp
  have h : env23176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23175_23176 : H12AffineEnvironment.transform 9 409 env23175 = env23176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env23175 == env23176) = true)

theorem identity23176 : scanCanonicalize (H12AffineFastState.compose env23176 (packedSelected [0,1,7,8,11,14,17,19,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23176 : packedSelected [0,1,7,8,11,14,17,19,20,23] rootPS < 2^1333 := by decide +kernel

def env23177 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,8192,16384,32768,8202,45324,10280,408,32769,57613,61756,17,20635,8328,16,55449,4233,45445,22837,61704,168,257,20664,45340,62236]

theorem envBound23177 : H12AffineFastState.Bounded env23177 := by
  intro p hp
  have h : env23177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23176_23177 : H12AffineEnvironment.transform 5 17 env23176 = env23177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23176 == env23177) = true)

theorem identity23177 : scanCanonicalize (H12AffineFastState.compose env23177 (packedSelected [0,1,7,8,11,14,16,17,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23177 : packedSelected [0,1,7,8,11,14,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env23178 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,8192,16384,1,8202,12557,10280,408,0,24844,28989,17,20635,8328,16,22680,4233,12676,22837,28937,168,257,20664,12573,29469]

theorem envBound23178 : H12AffineFastState.Bounded env23178 := by
  intro p hp
  have h : env23178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23177_23178 : H12AffineEnvironment.transform 14 1 env23177 = env23178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23177 == env23178) = true)

theorem identity23178 : scanCanonicalize (H12AffineFastState.compose env23178 (packedSelected [0,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 12464) := by decide +kernel

theorem selectedBound23178 : packedSelected [0,7,14,16] rootPS < 2^1333 := by decide +kernel

def env23179 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,8192,12464,1,8202,12557,10280,408,0,4540,397,17,8235,8328,16,10280,4233,12676,10629,441,168,257,8200,12573,941]

theorem envBound23179 : H12AffineFastState.Bounded env23179 := by
  intro p hp
  have h : env23179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23178_23179 : H12AffineEnvironment.transform 13 12464 env23178 = env23179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12464 env23178 == env23179) = true)

theorem identity23179 : scanCanonicalize (H12AffineFastState.compose env23179 (packedSelected [2,5,6,8,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23179 : packedSelected [2,5,6,8,17] rootPS < 2^1333 := by decide +kernel

def env23180 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,269,4541,1,263,4096,2341,408,0,4540,397,17,294,389,16,2341,4233,4233,2184,441,168,257,261,4112,941]

theorem envBound23180 : H12AffineFastState.Bounded env23180 := by
  intro p hp
  have h : env23180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23179_23180 : H12AffineEnvironment.transform 12 269 env23179 = env23180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23179 == env23180) = true)

theorem identity23180 : scanCanonicalize (H12AffineFastState.compose env23180 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound23180 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env23181 : List Nat := [2,4,8,16,32,17,128,172,512,53,2048,4096,161,4113,1,171,4096,2185,52,0,4112,33,17,138,41,16,2185,4233,4233,2184,21,168,173,169,4112,513]

theorem envBound23181 : H12AffineFastState.Bounded env23181 := by
  intro p hp
  have h : env23181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23180_23181 : H12AffineEnvironment.transform 7 172 env23180 = env23181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env23180 == env23181) = true)

theorem identity23181 : scanCanonicalize (H12AffineFastState.compose env23181 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound23181 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env23182 : List Nat := [2,4,8,16,32,17,128,172,512,53,2048,512,161,529,1,171,512,2185,52,0,528,33,17,138,41,16,2185,649,649,2184,21,168,173,169,528,513]

theorem envBound23182 : H12AffineFastState.Bounded env23182 := by
  intro p hp
  have h : env23182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23181_23182 : H12AffineEnvironment.transform 11 512 env23181 = env23182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env23181 == env23182) = true)

def env23183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,4194304,8388608,95497,8328,65,12754209,79130,8491470,8579113,8450328,4314198,257,8484154,8492190,8509134]

theorem envBound23183 : H12AffineFastState.Bounded env23183 := by
  intro p hp
  have h : env23183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23144_23183 : H12AffineEnvironment.transform 17 10281 env23144 = env23183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23144 == env23183) = true)

def env23184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,4194304,16,95497,8328,65,4365617,79130,102878,190521,61704,4314198,257,95530,103566,120542]

theorem envBound23184 : H12AffineFastState.Bounded env23184 := by
  intro p hp
  have h : env23184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23183_23184 : H12AffineEnvironment.transform 22 16 env23183 = env23184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env23183 == env23184) = true)

theorem identity23184 : scanCanonicalize (H12AffineFastState.compose env23184 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 119926) := by decide +kernel

theorem selectedBound23184 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,119926,16,95497,8328,65,215367,79130,102878,190521,61704,32,257,95530,103566,120542]

theorem envBound23185 : H12AffineFastState.Bounded env23185 := by
  intro p hp
  have h : env23185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23184_23185 : H12AffineEnvironment.transform 21 119926 env23184 = env23185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119926 env23184 == env23185) = true)

theorem identity23185 : scanCanonicalize (H12AffineFastState.compose env23185 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound23185 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env23186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1025,32769,115871,119926,16,95497,8328,65,10588,79130,102878,100386,61704,32,257,95530,103566,120542]

theorem envBound23186 : H12AffineFastState.Bounded env23186 := by
  intro p hp
  have h : env23186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23185_23186 : H12AffineEnvironment.transform 16 90139 env23185 = env23186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env23185 == env23186) = true)

theorem identity23186 : scanCanonicalize (H12AffineFastState.compose env23186 (packedSelected [0,3,4,7,10,11,12,15,16,17,18,20,22,23,24,26,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound23186 : packedSelected [0,3,4,7,10,11,12,15,16,17,18,20,22,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env23187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,46157,10281,1025,32769,4297,32,16,41311,8328,65,10588,57676,17800,23668,61704,32,257,41340,16600,648]

theorem envBound23187 : H12AffineFastState.Bounded env23187 := by
  intro p hp
  have h : env23187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23186_23187 : H12AffineEnvironment.transform 15 54358 env23186 = env23187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env23186 == env23187) = true)

theorem identity23187 : scanCanonicalize (H12AffineFastState.compose env23187 (packedSelected [11,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound23187 : packedSelected [11,16,18,20] rootPS < 2^1333 := by decide +kernel

def env23188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,217,21647,13460,10281,1025,216,4297,32,16,8582,8328,65,10588,24981,17800,23668,29137,32,257,8613,16600,648]

theorem envBound23188 : H12AffineFastState.Bounded env23188 := by
  intro p hp
  have h : env23188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23187_23188 : H12AffineEnvironment.transform 14 217 env23187 = env23188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env23187 == env23188) = true)

theorem identity23188 : scanCanonicalize (H12AffineFastState.compose env23188 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound23188 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env23189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,217,8403,13460,10281,1025,216,4297,32,16,8582,8328,65,10588,5577,12756,10280,1421,32,257,8613,13444,648]

theorem envBound23189 : H12AffineFastState.Bounded env23189 := by
  intro p hp
  have h : env23189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23188_23189 : H12AffineEnvironment.transform 13 13404 env23188 = env23189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env23188 == env23189) = true)

theorem identity23189 : scanCanonicalize (H12AffineFastState.compose env23189 (packedSelected [12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23189 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env23190 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,81,8283,13340,10281,1025,80,4161,32,16,8462,8192,65,10588,5441,12636,10280,1285,32,257,8493,13324,512]

theorem envBound23190 : H12AffineFastState.Bounded env23190 := by
  intro p hp
  have h : env23190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23189_23190 : H12AffineEnvironment.transform 6 8 env23189 = env23190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23189 == env23190) = true)

theorem identity23190 : scanCanonicalize (H12AffineFastState.compose env23190 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound23190 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,380,5408,81,295,5472,2389,1025,80,4161,32,16,114,380,65,2080,5441,4128,2388,1285,32,257,81,5488,512]

theorem envBound23191 : H12AffineFastState.Bounded env23191 := by
  intro p hp
  have h : env23191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23190_23191 : H12AffineEnvironment.transform 12 380 env23190 = env23191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env23190 == env23191) = true)

theorem identity23191 : scanCanonicalize (H12AffineFastState.compose env23191 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23191 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env23192 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,349,5377,81,262,5441,2389,1025,80,4161,1,16,83,349,65,2049,5441,4097,2388,1285,1,257,81,5457,512]

theorem envBound23192 : H12AffineFastState.Bounded env23192 := by
  intro p hp
  have h : env23192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23191_23192 : H12AffineEnvironment.transform 4 1 env23191 = env23192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23191 == env23192) = true)

theorem identity23192 : scanCanonicalize (H12AffineFastState.compose env23192 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(10+1) ^^^ 863) := by decide +kernel

theorem selectedBound23192 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env23193 : List Nat := [2,4,8,16,1,64,8,256,512,1024,863,4096,349,5377,81,262,5441,522,1025,80,4161,1,16,83,349,65,862,5441,4097,523,1285,1,257,81,5457,512]

theorem envBound23193 : H12AffineFastState.Bounded env23193 := by
  intro p hp
  have h : env23193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23192_23193 : H12AffineEnvironment.transform 10 863 env23192 = env23193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 863 env23192 == env23193) = true)

theorem identity23193 : scanCanonicalize (H12AffineFastState.compose env23193 (packedSelected [1,3,4,7,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound23193 : packedSelected [1,3,4,7,14] rootPS < 2^1333 := by decide +kernel

def env23194 : List Nat := [2,4,8,16,1,64,8,84,512,1024,523,4096,9,5205,81,82,5141,522,1025,80,4161,1,16,83,9,65,522,5141,4097,523,1105,1,85,81,5125,512]

theorem envBound23194 : H12AffineFastState.Bounded env23194 := by
  intro p hp
  have h : env23194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23193_23194 : H12AffineEnvironment.transform 7 84 env23193 = env23194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env23193 == env23194) = true)

theorem identity23194 : scanCanonicalize (H12AffineFastState.compose env23194 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23194 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env23195 : List Nat := [2,4,8,16,1,17,8,5,512,1024,523,4096,9,5124,0,3,5141,522,1025,1,4112,1,16,2,9,16,522,5141,4097,523,1024,1,4,0,5125,512]

theorem envBound23195 : H12AffineFastState.Bounded env23195 := by
  intro p hp
  have h : env23195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23194_23195 : H12AffineEnvironment.transform 5 17 env23194 = env23195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23194 == env23195) = true)

def env23196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,4194304,17,95497,8328,65,4365616,79130,102879,190520,61705,4314198,257,95531,103567,120543]

theorem envBound23196 : H12AffineFastState.Bounded env23196 := by
  intro p hp
  have h : env23196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23183_23196 : H12AffineEnvironment.transform 22 17 env23183 = env23196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env23183 == env23196) = true)

theorem identity23196 : scanCanonicalize (H12AffineFastState.compose env23196 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound23196 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10281,1025,32769,4161,4194304,17,41431,8328,65,4365616,57796,17665,190520,61705,4194440,257,41461,16465,513]

theorem envBound23197 : H12AffineFastState.Bounded env23197 := by
  intro p hp
  have h : env23197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23196_23197 : H12AffineEnvironment.transform 15 54494 env23196 = env23197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env23196 == env23197) = true)

def env23198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,4161,4194304,17,41311,8192,65,4365616,57676,17665,190520,61705,4194304,257,41341,16465,513]

theorem envBound23198 : H12AffineFastState.Bounded env23198 := by
  intro p hp
  have h : env23198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23197_23198 : H12AffineEnvironment.transform 6 8 env23197 = env23198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23197 == env23198) = true)

theorem identity23198 : scanCanonicalize (H12AffineFastState.compose env23198 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound23198 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29963,131072,10281,1025,8540,4161,4194304,17,2,8192,65,4340845,16401,17665,149861,20564,4194304,257,32,16465,513]

theorem envBound23199 : H12AffineFastState.Bounded env23199 := by
  intro p hp
  have h : env23199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23198_23199 : H12AffineEnvironment.transform 14 8541 env23198 = env23199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env23198 == env23199) = true)

theorem identity23199 : scanCanonicalize (H12AffineFastState.compose env23199 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound23199 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23200 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28699,131072,10281,273,8540,4161,4194304,17,2,8192,65,4340093,16401,16401,149861,20564,4194304,257,32,16465,513]

theorem envBound23200 : H12AffineFastState.Bounded env23200 := by
  intro p hp
  have h : env23200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23199_23200 : H12AffineEnvironment.transform 9 272 env23199 = env23200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env23199 == env23200) = true)

theorem identity23200 : scanCanonicalize (H12AffineFastState.compose env23200 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound23200 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env23201 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28699,4096,10281,273,8540,4161,4194304,17,2,8192,65,4204925,16401,16401,22885,20564,4194304,257,32,16465,513]

theorem envBound23201 : H12AffineFastState.Bounded env23201 := by
  intro p hp
  have h : env23201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23200_23201 : H12AffineEnvironment.transform 16 4096 env23200 = env23201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env23200 == env23201) = true)

theorem identity23201 : scanCanonicalize (H12AffineFastState.compose env23201 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound23201 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env23202 : List Nat := [2,4,8,16,32,64,8,256,512,272,0,4096,8192,16384,8541,28699,4096,8233,273,8540,4161,4194304,17,2,8192,65,4202877,16401,16401,20837,20564,4194304,257,32,16465,513]

theorem envBound23202 : H12AffineFastState.Bounded env23202 := by
  intro p hp
  have h : env23202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23201_23202 : H12AffineEnvironment.transform 10 0 env23201 = env23202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env23201 == env23202) = true)

theorem identity23202 : scanCanonicalize (H12AffineFastState.compose env23202 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound23202 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env23203 : List Nat := [2,4,8,16,32,64,8,256,512,272,0,4096,8192,16384,8541,28699,4096,8233,273,8540,4161,8493,17,2,8192,65,80,16401,16401,20837,20564,8493,257,32,16465,513]

theorem envBound23203 : H12AffineFastState.Bounded env23203 := by
  intro p hp
  have h : env23203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23202_23203 : H12AffineEnvironment.transform 21 8493 env23202 = env23203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env23202 == env23203) = true)

theorem identity23203 : scanCanonicalize (H12AffineFastState.compose env23203 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 4380) := by decide +kernel

theorem selectedBound23203 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env23204 : List Nat := [2,4,8,16,32,64,8,256,512,272,0,4096,4380,16384,4161,16647,4096,4405,273,4160,4161,4145,17,2,4380,65,80,16401,16401,20837,20564,4145,257,32,16465,513]

theorem envBound23204 : H12AffineFastState.Bounded env23204 := by
  intro p hp
  have h : env23204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23203_23204 : H12AffineEnvironment.transform 12 4380 env23203 = env23204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4380 env23203 == env23204) = true)

theorem identity23204 : scanCanonicalize (H12AffineFastState.compose env23204 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound23204 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env23205 : List Nat := [2,4,8,16,32,64,8,256,512,272,0,308,40,16384,373,16647,308,1,273,372,373,261,17,2,40,65,80,16401,16401,16465,16736,261,257,32,16465,513]

theorem envBound23205 : H12AffineFastState.Bounded env23205 := by
  intro p hp
  have h : env23205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23204_23205 : H12AffineEnvironment.transform 11 308 env23204 = env23205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env23204 == env23205) = true)

theorem identity23205 : scanCanonicalize (H12AffineFastState.compose env23205 (packedSelected [2,4,6,9,15] rootPS)) = affineNative (2^(13+1) ^^^ 372) := by decide +kernel

theorem selectedBound23205 : packedSelected [2,4,6,9,15] rootPS < 2^1333 := by decide +kernel

def env23206 : List Nat := [2,4,8,16,32,64,8,256,512,272,0,308,40,372,373,115,308,1,273,372,373,261,17,2,40,65,80,357,357,293,20,261,257,32,293,513]

theorem envBound23206 : H12AffineFastState.Bounded env23206 := by
  intro p hp
  have h : env23206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23205_23206 : H12AffineEnvironment.transform 13 372 env23205 = env23206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 372 env23205 == env23206) = true)

theorem identity23206 : scanCanonicalize (H12AffineFastState.compose env23206 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound23206 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env23207 : List Nat := [2,4,8,16,32,64,8,21,512,5,0,33,40,97,96,115,33,1,4,97,96,16,17,2,40,65,80,112,112,48,20,16,20,32,48,513]

theorem envBound23207 : H12AffineFastState.Bounded env23207 := by
  intro p hp
  have h : env23207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23206_23207 : H12AffineEnvironment.transform 7 21 env23206 = env23207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env23206 == env23207) = true)

theorem identity23207 : scanCanonicalize (H12AffineFastState.compose env23207 (packedSelected [0,1,2,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound23207 : packedSelected [0,1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env23208 : List Nat := [2,4,8,16,32,0,8,21,512,5,0,33,40,33,32,51,33,1,4,33,32,16,17,2,40,1,16,48,48,48,20,16,20,32,48,513]

theorem envBound23208 : H12AffineFastState.Bounded env23208 := by
  intro p hp
  have h : env23208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23207_23208 : H12AffineEnvironment.transform 5 0 env23207 = env23208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env23207 == env23208) = true)

theorem identity23208 : scanCanonicalize (H12AffineFastState.compose env23208 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23208 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23209 : List Nat := [2,4,8,1,32,0,8,4,512,5,0,33,40,33,32,34,33,1,4,33,32,1,0,2,40,1,1,33,33,33,5,1,5,32,33,513]

theorem envBound23209 : H12AffineFastState.Bounded env23209 := by
  intro p hp
  have h : env23209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23208_23209 : H12AffineEnvironment.transform 3 1 env23208 = env23209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23208 == env23209) = true)

theorem identity23209 : scanCanonicalize (H12AffineFastState.compose env23209 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23209 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23210 : List Nat := [2,4,8,1,1,0,8,4,512,5,0,0,9,0,1,3,0,1,4,0,1,1,0,2,9,1,1,0,0,0,5,1,5,1,0,513]

theorem envBound23210 : H12AffineFastState.Bounded env23210 := by
  intro p hp
  have h : env23210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23209_23210 : H12AffineEnvironment.transform 4 1 env23209 = env23210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23209 == env23210) = true)

def env23211 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1025,32769,4161,4194304,17,41310,8193,65,4365616,57677,17665,190520,61705,4194305,257,41340,16465,513]

theorem envBound23211 : H12AffineFastState.Bounded env23211 := by
  intro p hp
  have h : env23211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23197_23211 : H12AffineEnvironment.transform 6 9 env23197 = env23211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23197 == env23211) = true)

def env23212 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10281,1025,32769,4113,4194304,17,41230,8193,17,4365616,57629,17665,190520,61705,4194305,257,41260,16385,513]

theorem envBound23212 : H12AffineFastState.Bounded env23212 := by
  intro p hp
  have h : env23212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23211_23212 : H12AffineEnvironment.transform 5 16 env23211 = env23212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23211 == env23212) = true)

theorem identity23212 : scanCanonicalize (H12AffineFastState.compose env23212 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound23212 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env23213 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10281,1025,32769,4113,8493,17,41230,8193,17,179229,57629,17665,190520,61705,8492,257,41260,16385,513]

theorem envBound23213 : H12AffineFastState.Bounded env23213 := by
  intro p hp
  have h : env23213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23212_23213 : H12AffineEnvironment.transform 21 8493 env23212 = env23213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env23212 == env23213) = true)

theorem identity23213 : scanCanonicalize (H12AffineFastState.compose env23213 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound23213 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23214 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,38161,10281,1025,32769,4113,8493,17,41230,8193,17,10508,57629,17665,32041,61705,8492,257,41260,16385,513]

theorem envBound23214 : H12AffineFastState.Bounded env23214 := by
  intro p hp
  have h : env23214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23213_23214 : H12AffineEnvironment.transform 16 38161 env23213 = env23214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env23213 == env23214) = true)

theorem identity23214 : scanCanonicalize (H12AffineFastState.compose env23214 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23214 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23215 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,32768,33031,38161,10281,1025,32769,4113,8493,17,41230,8193,17,10508,46109,4097,10281,41993,8492,257,41260,5377,513]

theorem envBound23215 : H12AffineFastState.Bounded env23215 := by
  intro p hp
  have h : env23215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23214_23215 : H12AffineEnvironment.transform 13 5376 env23214 = env23215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23214 == env23215) = true)

theorem identity23215 : scanCanonicalize (H12AffineFastState.compose env23215 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23215 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23216 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,32768,33031,38161,2340,1025,32769,4113,32,17,32771,268,17,2049,38160,4097,2340,34052,33,257,32801,5377,513]

theorem envBound23216 : H12AffineFastState.Bounded env23216 := by
  intro p hp
  have h : env23216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23215_23216 : H12AffineEnvironment.transform 12 269 env23215 = env23216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23215 == env23216) = true)

theorem identity23216 : scanCanonicalize (H12AffineFastState.compose env23216 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23216 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env23217 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,1,262,5392,2340,1025,0,4113,32,17,2,268,17,2049,5393,4097,2340,1285,33,257,32,5377,513]

theorem envBound23217 : H12AffineFastState.Bounded env23217 := by
  intro p hp
  have h : env23217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23216_23217 : H12AffineEnvironment.transform 14 1 env23216 = env23217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23216 == env23217) = true)

theorem identity23217 : scanCanonicalize (H12AffineFastState.compose env23217 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound23217 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23218 : List Nat := [2,4,8,16,32,16,9,53,512,1024,2048,4096,56,5173,1,51,5157,2065,1025,0,4113,32,17,2,57,17,2049,5156,4097,2065,1072,33,52,32,5172,513]

theorem envBound23218 : H12AffineFastState.Bounded env23218 := by
  intro p hp
  have h : env23218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23217_23218 : H12AffineEnvironment.transform 7 53 env23217 = env23218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env23217 == env23218) = true)

theorem identity23218 : scanCanonicalize (H12AffineFastState.compose env23218 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound23218 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23219 : List Nat := [2,4,8,16,32,16,9,53,512,1024,2048,1572,56,529,1,51,513,2065,1025,0,1589,32,17,2,57,17,2049,512,1573,2065,1072,33,52,32,528,513]

theorem envBound23219 : H12AffineFastState.Bounded env23219 := by
  intro p hp
  have h : env23219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23218_23219 : H12AffineEnvironment.transform 11 1572 env23218 = env23219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env23218 == env23219) = true)

theorem identity23219 : scanCanonicalize (H12AffineFastState.compose env23219 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound23219 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23220 : List Nat := [2,4,8,16,32,16,9,53,512,564,2048,16,56,529,1,51,513,2065,565,0,1,32,17,2,57,17,2049,512,17,2065,516,33,52,32,528,513]

theorem envBound23220 : H12AffineFastState.Bounded env23220 := by
  intro p hp
  have h : env23220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23219_23220 : H12AffineEnvironment.transform 9 564 env23219 = env23220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env23219 == env23220) = true)

def env23221 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10281,1025,32769,4112,4194304,17,41231,8193,16,4365616,57628,17665,190520,61705,4194305,257,41261,16384,513]

theorem envBound23221 : H12AffineFastState.Bounded env23221 := by
  intro p hp
  have h : env23221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23211_23221 : H12AffineEnvironment.transform 5 17 env23211 = env23221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23211 == env23221) = true)

theorem identity23221 : scanCanonicalize (H12AffineFastState.compose env23221 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23221 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env23222 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,21510,131072,10281,1025,1,4112,4194304,17,8463,8193,16,4332848,24860,17665,157752,28937,4194305,257,8493,16384,513]

theorem envBound23222 : H12AffineFastState.Bounded env23222 := by
  intro p hp
  have h : env23222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23221_23222 : H12AffineEnvironment.transform 14 0 env23221 = env23222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23221 == env23222) = true)

theorem identity23222 : scanCanonicalize (H12AffineFastState.compose env23222 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound23222 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env23223 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,21510,131072,10281,1025,1,4112,8492,17,8463,8193,16,146460,24860,17665,157752,28937,8493,257,8493,16384,513]

theorem envBound23223 : H12AffineFastState.Bounded env23223 := by
  intro p hp
  have h : env23223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23222_23223 : H12AffineEnvironment.transform 21 8492 env23222 = env23223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env23222 == env23223) = true)

theorem identity23223 : scanCanonicalize (H12AffineFastState.compose env23223 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound23223 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23224 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,21510,16401,10281,1025,1,4112,8492,17,8463,8193,16,31757,24860,17665,10281,28937,8493,257,8493,16384,513]

theorem envBound23224 : H12AffineFastState.Bounded env23224 := by
  intro p hp
  have h : env23224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23223_23224 : H12AffineEnvironment.transform 16 16401 env23223 = env23224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23223 == env23224) = true)

theorem identity23224 : scanCanonicalize (H12AffineFastState.compose env23224 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23224 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23225 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,0,263,5392,10281,1025,1,4112,8492,17,8463,8193,16,10508,13341,4096,10281,9224,8493,257,8493,5377,513]

theorem envBound23225 : H12AffineFastState.Bounded env23225 := by
  intro p hp
  have h : env23225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23224_23225 : H12AffineEnvironment.transform 13 5377 env23224 = env23225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23224 == env23225) = true)

theorem identity23225 : scanCanonicalize (H12AffineFastState.compose env23225 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound23225 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23226 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,5157,0,35,5172,10281,1025,1,4112,8200,17,8235,8193,16,10280,13341,4096,10281,9224,8201,37,8201,5157,513]

theorem envBound23226 : H12AffineFastState.Bounded env23226 := by
  intro p hp
  have h : env23226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23225_23226 : H12AffineEnvironment.transform 7 36 env23225 = env23226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env23225 == env23226) = true)

theorem identity23226 : scanCanonicalize (H12AffineFastState.compose env23226 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound23226 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env23227 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,7180,5157,0,35,5172,5157,1025,1,4112,7172,17,7207,7181,16,5156,2065,4096,5157,6148,7173,37,7173,5157,513]

theorem envBound23227 : H12AffineFastState.Bounded env23227 := by
  intro p hp
  have h : env23227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23226_23227 : H12AffineEnvironment.transform 12 7180 env23226 = env23227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env23226 == env23227) = true)

theorem identity23227 : scanCanonicalize (H12AffineFastState.compose env23227 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23227 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env23228 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1,4096,5133,5157,0,35,5172,5157,1025,1,4112,5125,17,5158,5132,16,5156,16,4096,5157,4101,5124,37,5124,5157,513]

theorem envBound23228 : H12AffineFastState.Bounded env23228 := by
  intro p hp
  have h : env23228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23227_23228 : H12AffineEnvironment.transform 10 1 env23227 = env23228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23227 == env23228) = true)

theorem identity23228 : scanCanonicalize (H12AffineFastState.compose env23228 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound23228 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env23229 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1,1061,40,0,0,35,17,0,1025,1,1077,32,17,3,41,16,1,16,1061,0,1056,33,37,33,0,513]

theorem envBound23229 : H12AffineFastState.Bounded env23229 := by
  intro p hp
  have h : env23229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23228_23229 : H12AffineEnvironment.transform 11 1061 env23228 = env23229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env23228 == env23229) = true)

theorem identity23229 : scanCanonicalize (H12AffineFastState.compose env23229 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound23229 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23230 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,16,40,0,0,35,17,0,52,1,0,32,17,3,41,16,1,16,16,0,21,33,37,33,0,513]

theorem envBound23230 : H12AffineFastState.Bounded env23230 := by
  intro p hp
  have h : env23230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23229_23230 : H12AffineEnvironment.transform 9 53 env23229 = env23230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env23229 == env23230) = true)

theorem identity23230 : scanCanonicalize (H12AffineFastState.compose env23230 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound23230 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23231 : List Nat := [2,0,8,16,32,17,9,32,512,49,1,16,40,0,0,35,17,0,48,1,0,32,17,3,41,16,1,16,16,0,17,33,33,33,0,513]

theorem envBound23231 : H12AffineFastState.Bounded env23231 := by
  intro p hp
  have h : env23231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23230_23231 : H12AffineEnvironment.transform 1 0 env23230 = env23231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env23230 == env23231) = true)

theorem identity23231 : scanCanonicalize (H12AffineFastState.compose env23231 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound23231 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23232 : List Nat := [2,0,8,3,32,2,9,32,512,34,1,3,40,0,0,35,2,0,35,1,0,32,2,3,41,3,1,3,3,0,2,33,33,33,0,513]

theorem envBound23232 : H12AffineFastState.Bounded env23232 := by
  intro p hp
  have h : env23232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23231_23232 : H12AffineEnvironment.transform 3 3 env23231 = env23232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env23231 == env23232) = true)

theorem identity23232 : scanCanonicalize (H12AffineFastState.compose env23232 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound23232 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23233 : List Nat := [2,0,8,3,32,2,9,32,11,34,1,3,40,0,0,35,2,0,35,1,0,32,2,3,41,3,1,3,3,0,2,33,33,33,0,10]

theorem envBound23233 : H12AffineFastState.Bounded env23233 := by
  intro p hp
  have h : env23233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23232_23233 : H12AffineEnvironment.transform 8 11 env23232 = env23233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env23232 == env23233) = true)

theorem identity23233 : scanCanonicalize (H12AffineFastState.compose env23233 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23233 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23234 : List Nat := [2,0,8,3,1,2,9,1,11,3,1,3,9,0,0,2,2,0,2,1,0,1,2,3,8,3,1,3,3,0,2,0,0,0,0,10]

theorem envBound23234 : H12AffineFastState.Bounded env23234 := by
  intro p hp
  have h : env23234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23233_23234 : H12AffineEnvironment.transform 4 1 env23233 = env23234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23233 == env23234) = true)

def env23235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388278,4194304,8388608,351521,8328,65,12754208,79131,8763879,8830976,8706352,4314199,257,8484155,8492191,8781542]

theorem envBound23235 : H12AffineFastState.Bounded env23235 := by
  intro p hp
  have h : env23235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23143_23235 : H12AffineEnvironment.transform 23 351521 env23143 = env23235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351521 env23143 == env23235) = true)

def env23236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,4194304,8388608,95497,8328,65,12754208,79131,8491471,8579112,8450328,4314199,257,8484155,8492191,8509134]

theorem envBound23236 : H12AffineFastState.Bounded env23236 := by
  intro p hp
  have h : env23236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23235_23236 : H12AffineEnvironment.transform 17 10280 env23235 = env23236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23235 == env23236) = true)

def env23237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,4194304,16,95497,8328,65,4365616,79131,102879,190520,61704,4314199,257,95531,103567,120542]

theorem envBound23237 : H12AffineFastState.Bounded env23237 := by
  intro p hp
  have h : env23237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23236_23237 : H12AffineEnvironment.transform 22 16 env23236 = env23237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env23236 == env23237) = true)

theorem identity23237 : scanCanonicalize (H12AffineFastState.compose env23237 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 62588) := by decide +kernel

theorem selectedBound23237 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,62588,16,95497,8328,65,158028,79131,102879,190520,61704,73771,257,95531,103567,120542]

theorem envBound23238 : H12AffineFastState.Bounded env23238 := by
  intro p hp
  have h : env23238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23237_23238 : H12AffineEnvironment.transform 21 62588 env23237 = env23238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62588 env23237 == env23238) = true)

theorem identity23238 : scanCanonicalize (H12AffineFastState.compose env23238 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound23238 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env23239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10280,1025,32769,4161,62588,16,41430,8328,65,158028,57796,17664,190520,61704,62708,257,41460,16464,513]

theorem envBound23239 : H12AffineFastState.Bounded env23239 := by
  intro p hp
  have h : env23239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23238_23239 : H12AffineEnvironment.transform 15 54495 env23238 = env23239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env23238 == env23239) = true)

theorem identity23239 : scanCanonicalize (H12AffineFastState.compose env23239 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound23239 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,46276,10280,1025,32769,4161,62588,16,41430,8328,65,56712,57796,17664,23804,61704,62708,257,41460,16464,513]

theorem envBound23240 : H12AffineFastState.Bounded env23240 := by
  intro p hp
  have h : env23240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23239_23240 : H12AffineEnvironment.transform 16 46276 env23239 = env23240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env23239 == env23240) = true)

theorem identity23240 : scanCanonicalize (H12AffineFastState.compose env23240 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9412) := by decide +kernel

theorem selectedBound23240 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9412,28699,4096,10280,1025,9413,4161,20664,16,1298,8328,65,31052,17664,17664,23804,21964,20528,257,1328,16464,513]

theorem envBound23241 : H12AffineFastState.Bounded env23241 := by
  intro p hp
  have h : env23241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23240_23241 : H12AffineEnvironment.transform 14 9412 env23240 = env23241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9412 env23240 == env23241) = true)

theorem identity23241 : scanCanonicalize (H12AffineFastState.compose env23241 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23241 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,9412,9498,4096,10280,1025,9413,4161,1465,16,1298,8328,65,11341,4097,4097,2557,205,1329,257,1328,5457,513]

theorem envBound23242 : H12AffineFastState.Bounded env23242 := by
  intro p hp
  have h : env23242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23241_23242 : H12AffineEnvironment.transform 13 5377 env23241 = env23242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23241 == env23242) = true)

theorem identity23242 : scanCanonicalize (H12AffineFastState.compose env23242 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(12+1) ^^^ 1505) := by decide +kernel

theorem selectedBound23242 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env23243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1505,5377,293,251,4096,3529,1025,292,4161,1465,16,1298,1385,65,2476,4097,4097,2557,205,1329,257,1328,5457,513]

theorem envBound23243 : H12AffineFastState.Bounded env23243 := by
  intro p hp
  have h : env23243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23242_23243 : H12AffineEnvironment.transform 12 1505 env23242 = env23243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1505 env23242 == env23243) = true)

theorem identity23243 : scanCanonicalize (H12AffineFastState.compose env23243 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound23243 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env23244 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,120,4248,293,251,4096,2128,408,292,4161,32,16,139,240,65,2476,4097,4097,2557,205,168,257,169,4296,513]

theorem envBound23244 : H12AffineFastState.Bounded env23244 := by
  intro p hp
  have h : env23244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23243_23244 : H12AffineEnvironment.transform 9 409 env23243 = env23244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env23243 == env23244) = true)

theorem identity23244 : scanCanonicalize (H12AffineFastState.compose env23244 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23244 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23245 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,120,4112,293,115,4096,2128,272,292,4161,32,16,3,120,65,2340,4097,4097,2421,69,32,257,33,4160,513]

theorem envBound23245 : H12AffineFastState.Bounded env23245 := by
  intro p hp
  have h : env23245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23244_23245 : H12AffineEnvironment.transform 6 8 env23244 = env23245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23244 == env23245) = true)

theorem identity23245 : scanCanonicalize (H12AffineFastState.compose env23245 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound23245 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23246 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,309,120,293,293,115,309,2128,272,292,372,32,16,3,120,65,2340,308,308,2421,69,32,257,33,373,513]

theorem envBound23246 : H12AffineFastState.Bounded env23246 := by
  intro p hp
  have h : env23246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23245_23246 : H12AffineEnvironment.transform 11 309 env23245 = env23246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env23245 == env23246) = true)

theorem identity23246 : scanCanonicalize (H12AffineFastState.compose env23246 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23246 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23247 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,64,120,80,80,115,64,2128,101,81,1,32,16,3,120,65,2129,65,65,2048,69,32,116,33,0,513]

theorem envBound23247 : H12AffineFastState.Bounded env23247 := by
  intro p hp
  have h : env23247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23246_23247 : H12AffineEnvironment.transform 7 117 env23246 = env23247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23246 == env23247) = true)

theorem identity23247 : scanCanonicalize (H12AffineFastState.compose env23247 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 577) := by decide +kernel

theorem selectedBound23247 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23248 : List Nat := [2,4,8,16,32,64,8,117,512,100,577,64,120,80,80,115,64,529,101,81,1,32,16,3,120,65,528,65,65,577,69,32,116,33,0,513]

theorem envBound23248 : H12AffineFastState.Bounded env23248 := by
  intro p hp
  have h : env23248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23247_23248 : H12AffineEnvironment.transform 10 577 env23247 = env23248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env23247 == env23248) = true)

theorem identity23248 : scanCanonicalize (H12AffineFastState.compose env23248 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23248 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23249 : List Nat := [2,4,8,16,32,16,8,37,512,52,529,16,40,0,0,35,16,529,53,1,1,32,16,3,40,17,528,17,17,529,21,32,36,33,0,513]

theorem envBound23249 : H12AffineFastState.Bounded env23249 := by
  intro p hp
  have h : env23249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23248_23249 : H12AffineEnvironment.transform 5 16 env23248 = env23249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23248 == env23249) = true)

theorem identity23249 : scanCanonicalize (H12AffineFastState.compose env23249 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound23249 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23250 : List Nat := [2,4,8,11,32,11,8,37,512,47,522,11,40,0,0,35,11,522,46,1,1,32,11,3,40,10,523,10,10,522,14,32,36,33,0,513]

theorem envBound23250 : H12AffineFastState.Bounded env23250 := by
  intro p hp
  have h : env23250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23249_23250 : H12AffineEnvironment.transform 3 11 env23249 = env23250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env23249 == env23250) = true)

def env23251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,4194304,17,95497,8328,65,4365617,79131,102878,190521,61705,4314199,257,95530,103566,120543]

theorem envBound23251 : H12AffineFastState.Bounded env23251 := by
  intro p hp
  have h : env23251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23236_23251 : H12AffineEnvironment.transform 22 17 env23236 = env23251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env23236 == env23251) = true)

theorem identity23251 : scanCanonicalize (H12AffineFastState.compose env23251 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound23251 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10280,1025,29909,77898,4194304,17,95497,8328,65,4352485,79131,91402,138477,1501,4268163,257,95530,90202,74251]

theorem envBound23252 : H12AffineFastState.Bounded env23252 := by
  intro p hp
  have h : env23252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23251_23252 : H12AffineEnvironment.transform 14 29908 env23251 = env23252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env23251 == env23252) = true)

theorem identity23252 : scanCanonicalize (H12AffineFastState.compose env23252 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound23252 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env23253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,10280,1025,29909,77898,4194304,17,95497,8328,65,4262398,79131,91402,97526,1501,4268163,257,95530,90202,74251]

theorem envBound23253 : H12AffineFastState.Bounded env23253 := by
  intro p hp
  have h : env23253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23252_23253 : H12AffineEnvironment.transform 16 90139 env23252 = env23253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env23252 == env23253) = true)

theorem identity23253 : scanCanonicalize (H12AffineFastState.compose env23253 (packedSelected [0,1,3,5,8,9,10,11,14,18,19,22,23,27,32,35] rootPS)) = affineNative (2^(21+1) ^^^ 95530) := by decide +kernel

theorem selectedBound23253 : packedSelected [0,1,3,5,8,9,10,11,14,18,19,22,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env23254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,10280,1025,29909,77898,95530,17,95497,8328,65,31956,79131,91402,97526,1501,21929,257,95530,90202,74251]

theorem envBound23254 : H12AffineFastState.Bounded env23254 := by
  intro p hp
  have h : env23254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23253_23254 : H12AffineEnvironment.transform 21 95530 env23253 = env23254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95530 env23253 == env23254) = true)

theorem identity23254 : scanCanonicalize (H12AffineFastState.compose env23254 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 1220) := by decide +kernel

theorem selectedBound23254 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env23255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1220,16384,20496,65536,83167,3308,1025,20497,70798,86510,17,86477,1100,65,22544,70111,82382,88114,1501,21929,257,86510,83102,67279]

theorem envBound23255 : H12AffineFastState.Bounded env23255 := by
  intro p hp
  have h : env23255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23254_23255 : H12AffineEnvironment.transform 12 1220 env23254 = env23255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env23254 == env23255) = true)

theorem identity23255 : scanCanonicalize (H12AffineFastState.compose env23255 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 1230) := by decide +kernel

theorem selectedBound23255 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env23256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1220,16384,20496,1230,16401,3308,1025,20497,4160,21792,17,21763,1100,65,22544,5393,17664,23804,1501,21929,257,21792,16464,513]

theorem envBound23256 : H12AffineFastState.Bounded env23256 := by
  intro p hp
  have h : env23256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23255_23256 : H12AffineEnvironment.transform 15 1230 env23255 = env23256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1230 env23255 == env23256) = true)

theorem identity23256 : scanCanonicalize (H12AffineFastState.compose env23256 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound23256 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23257 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,348,16384,20496,342,16401,2420,409,20497,4160,20664,17,20635,468,65,22544,4233,16536,22884,69,20529,257,20664,16464,513]

theorem envBound23257 : H12AffineFastState.Bounded env23257 := by
  intro p hp
  have h : env23257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23256_23257 : H12AffineEnvironment.transform 9 408 env23256 = env23257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env23256 == env23257) = true)

theorem identity23257 : scanCanonicalize (H12AffineFastState.compose env23257 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound23257 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23258 : List Nat := [2,4,8,16,32,64,88,256,512,320,2048,4096,348,16384,20496,342,16401,2420,321,20497,4160,20576,17,20547,268,65,22544,4177,16448,22884,69,20529,257,20576,16464,513]

theorem envBound23258 : H12AffineFastState.Bounded env23258 := by
  intro p hp
  have h : env23258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23257_23258 : H12AffineEnvironment.transform 6 88 env23257 = env23258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env23257 == env23258) = true)

theorem identity23258 : scanCanonicalize (H12AffineFastState.compose env23258 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound23258 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env23259 : List Nat := [2,4,8,16,32,64,88,256,512,320,2048,4096,348,4112,0,342,4097,2420,321,1,4160,112,17,83,268,65,2048,4177,4176,2420,69,33,257,112,4160,513]

theorem envBound23259 : H12AffineFastState.Bounded env23259 := by
  intro p hp
  have h : env23259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23258_23259 : H12AffineEnvironment.transform 13 4112 env23258 = env23259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env23258 == env23259) = true)

theorem identity23259 : scanCanonicalize (H12AffineFastState.compose env23259 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound23259 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env23260 : List Nat := [2,4,8,16,32,48,40,256,512,304,2048,4096,300,4112,0,294,4097,2308,305,1,4144,0,17,35,268,49,2048,4129,4128,2308,53,33,257,0,4144,513]

theorem envBound23260 : H12AffineFastState.Bounded env23260 := by
  intro p hp
  have h : env23260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23259_23260 : H12AffineEnvironment.transform 5 48 env23259 = env23260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env23259 == env23260) = true)

theorem identity23260 : scanCanonicalize (H12AffineFastState.compose env23260 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23260 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23261 : List Nat := [2,4,8,16,32,48,40,4,512,52,2048,4096,40,4112,0,34,4097,2048,53,1,4144,0,17,35,8,49,2048,4129,4128,2048,53,33,5,0,4144,513]

theorem envBound23261 : H12AffineFastState.Bounded env23261 := by
  intro p hp
  have h : env23261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23260_23261 : H12AffineEnvironment.transform 7 4 env23260 = env23261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23260 == env23261) = true)

def env23262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,4194304,8388608,95496,8328,65,12754208,79131,8491470,8579113,8450329,4314199,257,8484155,8492191,8509135]

theorem envBound23262 : H12AffineFastState.Bounded env23262 := by
  intro p hp
  have h : env23262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23235_23262 : H12AffineEnvironment.transform 17 10281 env23235 = env23262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23235 == env23262) = true)

def env23263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,4194304,16,95496,8328,65,4365616,79131,102878,190521,61705,4314199,257,95531,103567,120543]

theorem envBound23263 : H12AffineFastState.Bounded env23263 := by
  intro p hp
  have h : env23263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23262_23263 : H12AffineEnvironment.transform 22 16 env23262 = env23263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env23262 == env23263) = true)

theorem identity23263 : scanCanonicalize (H12AffineFastState.compose env23263 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound23263 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,169,16,95496,8328,65,171417,79131,102878,190521,61705,120062,257,95531,103567,120543]

theorem envBound23264 : H12AffineFastState.Bounded env23264 := by
  intro p hp
  have h : env23264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23263_23264 : H12AffineEnvironment.transform 21 169 env23263 = env23264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env23263 == env23264) = true)

theorem identity23264 : scanCanonicalize (H12AffineFastState.compose env23264 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound23264 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env23265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,46277,10281,1025,32769,115871,169,16,95496,8328,65,10588,79131,102878,23804,61705,120062,257,95531,103567,120543]

theorem envBound23265 : H12AffineFastState.Bounded env23265 := by
  intro p hp
  have h : env23265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23264_23265 : H12AffineEnvironment.transform 16 46277 env23264 = env23265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env23264 == env23265) = true)

theorem identity23265 : scanCanonicalize (H12AffineFastState.compose env23265 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound23265 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,46277,10281,1025,32769,17864,169,16,62559,8328,65,10588,46156,4233,23804,61705,21929,257,62588,5592,22408]

theorem envBound23266 : H12AffineFastState.Bounded env23266 := by
  intro p hp
  have h : env23266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23265_23266 : H12AffineEnvironment.transform 15 33111 env23265 = env23266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env23265 == env23266) = true)

theorem identity23266 : scanCanonicalize (H12AffineFastState.compose env23266 (packedSelected [0,1,4,7,8,16,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound23266 : packedSelected [0,1,4,7,8,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env23267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33111,46277,10281,1025,32769,4161,169,16,41430,8328,65,10588,46156,4233,2421,42112,32,257,41461,5592,513]

theorem envBound23267 : H12AffineFastState.Bounded env23267 := by
  intro p hp
  have h : env23267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23266_23267 : H12AffineEnvironment.transform 13 5513 env23266 = env23267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env23266 == env23267) = true)

theorem identity23267 : scanCanonicalize (H12AffineFastState.compose env23267 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound23267 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env23268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,80,263,13461,10281,1025,81,4161,169,16,8582,8328,65,10588,13340,4233,2421,9424,32,257,8613,5592,513]

theorem envBound23268 : H12AffineFastState.Bounded env23268 := by
  intro p hp
  have h : env23268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23267_23268 : H12AffineEnvironment.transform 14 80 env23267 = env23268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env23267 == env23268) = true)

theorem identity23268 : scanCanonicalize (H12AffineFastState.compose env23268 (packedSelected [2,6,17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound23268 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env23269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,80,263,5441,2557,1025,81,4161,169,16,82,348,65,2184,5576,4233,2421,1284,32,257,113,5592,513]

theorem envBound23269 : H12AffineFastState.Bounded env23269 := by
  intro p hp
  have h : env23269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23268_23269 : H12AffineEnvironment.transform 12 468 env23268 = env23269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env23268 == env23269) = true)

theorem identity23269 : scanCanonicalize (H12AffineFastState.compose env23269 (packedSelected [0,4,5,8,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound23269 : packedSelected [0,4,5,8,11,15] rootPS < 2^1333 := by decide +kernel

def env23270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2493,468,3124,80,263,3324,2557,1025,81,2556,169,16,82,348,65,2184,3189,2356,2421,1284,32,257,113,3173,513]

theorem envBound23270 : H12AffineFastState.Bounded env23270 := by
  intro p hp
  have h : env23270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23269_23270 : H12AffineEnvironment.transform 11 2493 env23269 = env23270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env23269 == env23270) = true)

theorem identity23270 : scanCanonicalize (H12AffineFastState.compose env23270 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound23270 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env23271 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,2405,268,3124,80,263,3108,2341,1025,81,2340,113,16,82,348,65,2128,3189,2356,2421,1284,32,257,113,3173,513]

theorem envBound23271 : H12AffineFastState.Bounded env23271 := by
  intro p hp
  have h : env23271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23270_23271 : H12AffineEnvironment.transform 6 88 env23270 = env23271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env23270 == env23271) = true)

theorem identity23271 : scanCanonicalize (H12AffineFastState.compose env23271 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23271 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env23272 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1,356,268,1077,80,263,1061,292,1025,81,293,113,16,82,348,65,81,1140,309,372,1284,32,257,113,1124,513]

theorem envBound23272 : H12AffineFastState.Bounded env23272 := by
  intro p hp
  have h : env23272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23271_23272 : H12AffineEnvironment.transform 10 1 env23271 = env23272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23271 == env23272) = true)

def env23273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,4194304,17,95496,8328,65,4365617,79131,102879,190520,61704,4314199,257,95530,103566,120542]

theorem envBound23273 : H12AffineFastState.Bounded env23273 := by
  intro p hp
  have h : env23273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23262_23273 : H12AffineEnvironment.transform 22 17 env23262 = env23273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env23262 == env23273) = true)

def env23274 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115735,4194304,17,95496,8192,65,4365617,79131,102743,190520,61704,4314199,257,95530,103430,120406]

theorem envBound23274 : H12AffineFastState.Bounded env23274 := by
  intro p hp
  have h : env23274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23273_23274 : H12AffineEnvironment.transform 6 8 env23273 = env23274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23273 == env23274) = true)

theorem identity23274 : scanCanonicalize (H12AffineFastState.compose env23274 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound23274 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23275 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,10281,1025,32769,45341,4194304,17,2,8192,65,4365617,16401,58461,190520,61704,4235613,257,32,57612,41820]

theorem envBound23275 : H12AffineFastState.Bounded env23275 := by
  intro p hp
  have h : env23275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23274_23275 : H12AffineEnvironment.transform 15 29962 env23274 = env23275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env23274 == env23275) = true)

theorem identity23275 : scanCanonicalize (H12AffineFastState.compose env23275 (packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound23275 : packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env23276 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,46156,10281,1025,32769,45341,4194304,17,2,8192,65,4204925,16401,58461,23668,61704,4235613,257,32,57612,41820]

theorem envBound23276 : H12AffineFastState.Bounded env23276 := by
  intro p hp
  have h : env23276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23275_23276 : H12AffineEnvironment.transform 16 46156 env23275 = env23276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env23275 == env23276) = true)

theorem identity23276 : scanCanonicalize (H12AffineFastState.compose env23276 (packedSelected [0,2,4,5,6,9,11,18,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 29820) := by decide +kernel

theorem selectedBound23276 : packedSelected [0,2,4,5,6,9,11,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env23277 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,46156,10281,1025,32769,45341,29820,17,2,8192,65,23809,16401,58461,23668,61704,54561,257,32,57612,41820]

theorem envBound23277 : H12AffineFastState.Bounded env23277 := by
  intro p hp
  have h : env23277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23276_23277 : H12AffineEnvironment.transform 21 29820 env23276 = env23277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29820 env23276 == env23277) = true)

theorem identity23277 : scanCanonicalize (H12AffineFastState.compose env23277 (packedSelected [1,4,8,9,12,14,15,16,18,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound23277 : packedSelected [1,4,8,9,12,14,15,16,18,23,26] rootPS < 2^1333 := by decide +kernel

def env23278 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,292,29962,13672,10281,1025,293,12345,29820,17,2,8192,65,23809,16401,25977,23668,28716,21509,257,32,24616,8824]

theorem envBound23278 : H12AffineFastState.Bounded env23278 := by
  intro p hp
  have h : env23278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23277_23278 : H12AffineEnvironment.transform 14 292 env23277 = env23278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env23277 == env23278) = true)

theorem identity23278 : scanCanonicalize (H12AffineFastState.compose env23278 (packedSelected [0,2,4,6,7,9,11,14,16,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound23278 : packedSelected [0,2,4,6,7,9,11,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env23279 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,292,8282,13672,10281,1025,293,12345,8492,17,2,8192,65,2129,5441,12329,2340,9596,341,257,32,13688,8824]

theorem envBound23279 : H12AffineFastState.Bounded env23279 := by
  intro p hp
  have h : env23279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23278_23279 : H12AffineEnvironment.transform 13 5456 env23278 = env23279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env23278 == env23279) = true)

theorem identity23279 : scanCanonicalize (H12AffineFastState.compose env23279 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23279 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env23280 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,292,342,5220,2341,1025,293,4405,32,17,2,268,65,2129,5441,4389,2340,1136,341,257,32,5236,884]

theorem envBound23280 : H12AffineFastState.Bounded env23280 := by
  intro p hp
  have h : env23280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23279_23280 : H12AffineEnvironment.transform 12 268 env23279 = env23280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23279 == env23280) = true)

theorem identity23280 : scanCanonicalize (H12AffineFastState.compose env23280 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound23280 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env23281 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,40,5236,0,114,5220,2049,1025,1,4113,32,17,2,40,65,2129,5221,4097,2048,1136,113,37,32,5236,592]

theorem envBound23281 : H12AffineFastState.Bounded env23281 := by
  intro p hp
  have h : env23281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23280_23281 : H12AffineEnvironment.transform 7 36 env23280 = env23281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env23280 == env23281) = true)

theorem identity23281 : scanCanonicalize (H12AffineFastState.compose env23281 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound23281 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env23282 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,40,5124,0,2,5140,2049,1025,1,4113,32,17,2,40,49,2081,5141,4097,2048,1024,1,37,32,5124,544]

theorem envBound23282 : H12AffineFastState.Bounded env23282 := by
  intro p hp
  have h : env23282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23281_23282 : H12AffineEnvironment.transform 5 48 env23281 = env23282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env23281 == env23282) = true)

theorem identity23282 : scanCanonicalize (H12AffineFastState.compose env23282 (packedSelected [2,3,5,11,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23282 : packedSelected [2,3,5,11,15] rootPS < 2^1333 := by decide +kernel

def env23283 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,8,5124,0,2,5140,2049,1025,1,4113,0,17,2,8,17,2049,5141,4097,2048,1024,1,5,0,5124,512]

theorem envBound23283 : H12AffineFastState.Bounded env23283 := by
  intro p hp
  have h : env23283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23282_23283 : H12AffineEnvironment.transform 4 0 env23282 = env23283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23282 == env23283) = true)

def env23284 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,8,1044,0,2,1028,2049,1025,1,1,0,17,2,8,17,2049,1029,17,2048,1024,1,5,0,1044,512]

theorem envBound23284 : H12AffineFastState.Bounded env23284 := by
  intro p hp
  have h : env23284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23283_23284 : H12AffineEnvironment.transform 11 16 env23283 = env23284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env23283 == env23284) = true)

theorem identity23284 : scanCanonicalize (H12AffineFastState.compose env23284 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound23284 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23285 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1044,16,8,1044,0,2,1028,1045,1025,1,1,0,17,2,8,17,1045,1029,17,1044,1024,1,5,0,1044,512]

theorem envBound23285 : H12AffineFastState.Bounded env23285 := by
  intro p hp
  have h : env23285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23284_23285 : H12AffineEnvironment.transform 10 1044 env23284 = env23285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env23284 == env23285) = true)

def env23286 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,8,0,0,2,16,1,21,1,1,0,17,2,8,17,1,17,17,0,20,1,5,0,0,512]

theorem envBound23286 : H12AffineFastState.Bounded env23286 := by
  intro p hp
  have h : env23286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23285_23286 : H12AffineEnvironment.transform 9 20 env23285 = env23286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env23285 == env23286) = true)

theorem identity23286 : scanCanonicalize (H12AffineFastState.compose env23286 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound23286 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23287 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,4,8,0,0,2,4,1,1,1,1,0,5,2,8,5,1,5,5,0,0,1,5,0,0,512]

theorem envBound23287 : H12AffineFastState.Bounded env23287 := by
  intro p hp
  have h : env23287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23286_23287 : H12AffineEnvironment.transform 3 4 env23286 = env23287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env23286 == env23287) = true)

def leafEnv23287 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,4,8,0,0,2,4,1,1,1,1,0,5,2,1,8,1,5,1,5,5,0,0,1,5,0,5,2,0,512,1,1,0]

def active23287 : List Nat := [0,1,2,8]

def tree23287 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23287 : H12WitnessSearch.Good tree23287 := H12GlobalWitnessIndex.good

theorem leafIdentity23287 : H12AffineFastState.composeSystem env23287 rootObs = leafEnv23287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23287 rootObs == leafEnv23287) = true)

theorem terminalChecked23287 : H12PackedTerminal.terminalCheckFast leafEnv23287 active23287 tree23287 = true := by decide +kernel

def env23288 : List Nat := [2,4,8,16,0,16,8,4,512,21,1,16,8,1,0,2,17,0,20,1,1,0,17,2,8,17,0,16,17,1,21,1,5,0,1,512]

theorem envBound23288 : H12AffineFastState.Bounded env23288 := by
  intro p hp
  have h : env23288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23285_23288 : H12AffineEnvironment.transform 9 21 env23285 = env23288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env23285 == env23288) = true)

theorem identity23288 : scanCanonicalize (H12AffineFastState.compose env23288 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound23288 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23289 : List Nat := [2,4,8,16,0,16,8,4,31,21,1,16,8,1,0,2,17,0,20,1,1,0,17,2,8,17,0,16,17,1,21,1,5,0,1,31]

end H12CloudChart1