import H12CloudChart1Data108

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity27621 : scanCanonicalize (H12AffineFastState.compose env27621 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound27621 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27622 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,1029,269,260,0,263,276,2308,1025,1,1044,1,17,3,268,17,2048,277,1028,2309,1284,0,257,0,261,513]

theorem envBound27622 : H12AffineFastState.Bounded env27622 := by
  intro p hp
  have h : env27622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27621_27622 : H12AffineEnvironment.transform 11 1029 env27621 = env27622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env27621 == env27622) = true)

theorem identity27622 : scanCanonicalize (H12AffineFastState.compose env27622 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound27622 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27623 : List Nat := [2,4,8,16,1,16,9,256,512,1024,1556,1029,269,260,0,263,276,1808,1025,1,1044,1,17,3,268,17,1556,277,1028,1809,1284,0,257,0,261,513]

theorem envBound27623 : H12AffineFastState.Bounded env27623 := by
  intro p hp
  have h : env27623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27622_27623 : H12AffineEnvironment.transform 10 1556 env27622 = env27623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env27622 == env27623) = true)

theorem identity27623 : scanCanonicalize (H12AffineFastState.compose env27623 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound27623 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27624 : List Nat := [2,4,8,16,1,16,9,256,512,517,17,512,269,260,0,263,276,277,516,1,529,1,17,3,268,17,17,277,513,276,769,0,257,0,261,513]

theorem envBound27624 : H12AffineFastState.Bounded env27624 := by
  intro p hp
  have h : env27624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27623_27624 : H12AffineEnvironment.transform 9 517 env27623 = env27624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env27623 == env27624) = true)

theorem identity27624 : scanCanonicalize (H12AffineFastState.compose env27624 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27624 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27625 : List Nat := [2,4,8,16,1,16,9,256,1,4,17,1,269,260,0,263,276,277,5,1,16,1,17,3,268,17,17,277,0,276,256,0,257,0,261,0]

theorem envBound27625 : H12AffineFastState.Bounded env27625 := by
  intro p hp
  have h : env27625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27624_27625 : H12AffineEnvironment.transform 8 1 env27624 = env27625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27624 == env27625) = true)

theorem identity27625 : scanCanonicalize (H12AffineFastState.compose env27625 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27625 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env27626 : List Nat := [2,4,8,16,1,16,9,4,1,4,17,1,9,0,0,3,16,17,5,1,16,1,17,3,8,17,17,17,0,16,4,0,5,0,1,0]

theorem envBound27626 : H12AffineFastState.Bounded env27626 := by
  intro p hp
  have h : env27626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27625_27626 : H12AffineEnvironment.transform 7 4 env27625 = env27626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27625 == env27626) = true)

theorem identity27626 : scanCanonicalize (H12AffineFastState.compose env27626 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27626 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27627 : List Nat := [2,4,8,0,1,0,9,4,1,4,1,1,9,0,0,3,0,1,5,1,0,1,1,3,8,1,1,1,0,0,4,0,5,0,1,0]

theorem envBound27627 : H12AffineFastState.Bounded env27627 := by
  intro p hp
  have h : env27627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27626_27627 : H12AffineEnvironment.transform 3 0 env27626 = env27627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27626 == env27627) = true)

theorem identity27627 : scanCanonicalize (H12AffineFastState.compose env27627 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27627 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27628 : List Nat := [2,4,3,0,1,0,2,4,1,4,1,1,2,0,0,3,0,1,5,1,0,1,1,3,3,1,1,1,0,0,4,0,5,0,1,0]

theorem envBound27628 : H12AffineFastState.Bounded env27628 := by
  intro p hp
  have h : env27628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27627_27628 : H12AffineEnvironment.transform 2 3 env27627 = env27628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27627 == env27628) = true)

def env27629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,4194304,8388608,98780,8328,65,12729469,79130,8480026,8568225,8390093,4314199,257,8484155,8492191,8462875]

theorem envBound27629 : H12AffineFastState.Bounded env27629 := by
  intro p hp
  have h : env27629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27570_27629 : H12AffineEnvironment.transform 17 32161 env27570 = env27629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env27570 == env27629) = true)

def env27630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21792,8388608,98780,8328,65,8546653,79130,8480026,8568225,8390093,98679,257,8484155,8492191,8462875]

theorem envBound27630 : H12AffineFastState.Bounded env27630 := by
  intro p hp
  have h : env27630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27629_27630 : H12AffineEnvironment.transform 21 21792 env27629 = env27630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env27629 == env27630) = true)

theorem identity27630 : scanCanonicalize (H12AffineFastState.compose env27630 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound27630 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32161,1025,29909,77898,21792,8388608,95496,8328,65,8546653,79130,8480026,8538485,8390093,95651,257,8484155,8478795,8462875]

theorem envBound27631 : H12AffineFastState.Bounded env27631 := by
  intro p hp
  have h : env27631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27630_27631 : H12AffineEnvironment.transform 14 29908 env27630 = env27631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env27630 == env27631) = true)

def env27632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10401,1025,8661,77898,32,8388608,73736,8328,65,8535133,79130,8466458,8526965,8390093,73891,257,8462395,8467787,8462875]

theorem envBound27632 : H12AffineFastState.Bounded env27632 := by
  intro p hp
  have h : env27632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27631_27632 : H12AffineEnvironment.transform 13 5376 env27631 = env27632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27631 == env27632) = true)

theorem identity27632 : scanCanonicalize (H12AffineFastState.compose env27632 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 73875) := by decide +kernel

theorem selectedBound27632 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10401,1025,8661,77898,32,73875,73736,8328,65,203982,79130,4233,212198,75102,73891,257,168,5592,648]

theorem envBound27633 : H12AffineFastState.Bounded env27633 := by
  intro p hp
  have h : env27633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27632_27633 : H12AffineEnvironment.transform 22 73875 env27632 = env27633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73875 env27632 == env27633) = true)

theorem identity27633 : scanCanonicalize (H12AffineFastState.compose env27633 (packedSelected [4,7,9,16,18,20,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound27633 : packedSelected [4,7,9,16,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env27634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,0,65536,131072,2421,1025,1,70046,32,65863,66012,348,65,203982,70862,4233,204082,66698,65911,257,168,5592,648]

theorem envBound27634 : H12AffineFastState.Bounded env27634 := by
  intro p hp
  have h : env27634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27633_27634 : H12AffineEnvironment.transform 12 468 env27633 = env27634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env27633 == env27634) = true)

theorem identity27634 : scanCanonicalize (H12AffineFastState.compose env27634 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound27634 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env27635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,0,65536,70862,2421,1025,1,70046,32,65863,66012,348,65,2048,70862,4233,2556,66698,65911,257,168,5592,648]

theorem envBound27635 : H12AffineFastState.Bounded env27635 := by
  intro p hp
  have h : env27635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27634_27635 : H12AffineEnvironment.transform 16 70862 env27634 = env27635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env27634 == env27635) = true)

theorem identity27635 : scanCanonicalize (H12AffineFastState.compose env27635 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27635 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27636 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,65536,70727,2421,1025,1,69911,32,65863,65877,348,65,2048,70727,4096,2421,66563,65911,257,33,5457,513]

theorem envBound27636 : H12AffineFastState.Bounded env27636 := by
  intro p hp
  have h : env27636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27635_27636 : H12AffineEnvironment.transform 6 9 env27635 = env27636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27635 == env27636) = true)

theorem identity27636 : scanCanonicalize (H12AffineFastState.compose env27636 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound27636 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27637 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,5393,2421,1025,1,4161,32,17,3,348,65,2048,5393,4096,2421,1365,33,257,33,5457,513]

theorem envBound27637 : H12AffineFastState.Bounded env27637 := by
  intro p hp
  have h : env27637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27636_27637 : H12AffineEnvironment.transform 15 342 env27636 = env27637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env27636 == env27637) = true)

theorem identity27637 : scanCanonicalize (H12AffineFastState.compose env27637 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound27637 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27638 : List Nat := [2,4,8,16,32,64,9,256,512,785,2048,4096,349,4625,0,342,4608,2421,784,1,4161,32,17,3,348,65,2048,4608,4096,2421,580,33,257,33,4672,513]

theorem envBound27638 : H12AffineFastState.Bounded env27638 := by
  intro p hp
  have h : env27638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27637_27638 : H12AffineEnvironment.transform 9 785 env27637 = env27638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env27637 == env27638) = true)

theorem identity27638 : scanCanonicalize (H12AffineFastState.compose env27638 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 885) := by decide +kernel

theorem selectedBound27638 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27639 : List Nat := [2,4,8,16,32,64,9,256,512,785,2048,885,349,356,0,342,373,2421,784,1,820,32,17,3,348,65,2048,373,885,2421,580,33,257,33,309,513]

theorem envBound27639 : H12AffineFastState.Bounded env27639 := by
  intro p hp
  have h : env27639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27638_27639 : H12AffineEnvironment.transform 11 885 env27638 = env27639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 885 env27638 == env27639) = true)

theorem identity27639 : scanCanonicalize (H12AffineFastState.compose env27639 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound27639 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env27640 : List Nat := [2,4,8,16,32,64,9,116,512,613,2048,513,41,16,0,34,1,2049,612,1,576,32,17,3,40,65,2048,1,513,2049,580,33,117,33,65,513]

theorem envBound27640 : H12AffineFastState.Bounded env27640 := by
  intro p hp
  have h : env27640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27639_27640 : H12AffineEnvironment.transform 7 116 env27639 = env27640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env27639 == env27640) = true)

theorem identity27640 : scanCanonicalize (H12AffineFastState.compose env27640 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound27640 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env27641 : List Nat := [2,4,8,16,32,64,9,116,512,613,81,513,41,16,0,34,1,80,612,1,576,32,17,3,40,65,81,1,513,80,580,33,117,33,65,513]

theorem envBound27641 : H12AffineFastState.Bounded env27641 := by
  intro p hp
  have h : env27641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27640_27641 : H12AffineEnvironment.transform 10 81 env27640 = env27641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env27640 == env27641) = true)

theorem identity27641 : scanCanonicalize (H12AffineFastState.compose env27641 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound27641 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27642 : List Nat := [2,4,8,16,32,64,9,116,80,53,81,81,41,16,0,34,1,80,52,1,16,32,17,3,40,65,81,1,81,80,20,33,117,33,65,81]

theorem envBound27642 : H12AffineFastState.Bounded env27642 := by
  intro p hp
  have h : env27642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27641_27642 : H12AffineEnvironment.transform 8 80 env27641 = env27642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env27641 == env27642) = true)

theorem identity27642 : scanCanonicalize (H12AffineFastState.compose env27642 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27642 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27643 : List Nat := [2,4,8,1,32,64,9,101,65,36,64,64,41,1,0,34,1,65,37,1,1,32,0,3,40,65,64,1,64,65,5,33,100,33,65,64]

theorem envBound27643 : H12AffineFastState.Bounded env27643 := by
  intro p hp
  have h : env27643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27642_27643 : H12AffineEnvironment.transform 3 1 env27642 = env27643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27642 == env27643) = true)

theorem identity27643 : scanCanonicalize (H12AffineFastState.compose env27643 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound27643 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27644 : List Nat := [2,4,8,1,32,0,9,37,1,36,0,0,41,1,0,34,1,1,37,1,1,32,0,3,40,1,0,1,0,1,5,33,36,33,1,0]

theorem envBound27644 : H12AffineFastState.Bounded env27644 := by
  intro p hp
  have h : env27644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27643_27644 : H12AffineEnvironment.transform 5 0 env27643 = env27644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env27643 == env27644) = true)

theorem identity27644 : scanCanonicalize (H12AffineFastState.compose env27644 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27644 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27645 : List Nat := [2,4,2,1,32,0,3,37,1,36,0,0,35,1,0,34,1,1,37,1,1,32,0,3,34,1,0,1,0,1,5,33,36,33,1,0]

theorem envBound27645 : H12AffineFastState.Bounded env27645 := by
  intro p hp
  have h : env27645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27644_27645 : H12AffineEnvironment.transform 2 2 env27644 = env27645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27644 == env27645) = true)

def env27646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10400,1025,8660,77898,33,8388608,73737,8328,65,8535132,79130,8466459,8526964,8390093,73890,257,8462394,8467786,8462875]

theorem envBound27646 : H12AffineFastState.Bounded env27646 := by
  intro p hp
  have h : env27646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27631_27646 : H12AffineEnvironment.transform 13 5377 env27631 = env27646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env27631 == env27646) = true)

theorem identity27646 : scanCanonicalize (H12AffineFastState.compose env27646 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound27646 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,131072,10400,1025,8660,4161,33,8388608,2,8328,65,8535132,5393,8392720,8526964,8390093,169,257,8388657,8394049,8389136]

theorem envBound27647 : H12AffineFastState.Bounded env27647 := by
  intro p hp
  have h : env27647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27646_27647 : H12AffineEnvironment.transform 15 8203 env27646 = env27647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env27646 == env27647) = true)

theorem identity27647 : scanCanonicalize (H12AffineFastState.compose env27647 (packedSelected [0,4,6,9,14,16,27] rootPS)) = affineNative (2^(22+1) ^^^ 136449) := by decide +kernel

theorem selectedBound27647 : packedSelected [0,4,6,9,14,16,27] rootPS < 2^1333 := by decide +kernel

def env27648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,131072,10400,1025,8660,4161,33,136449,2,8328,65,10589,5393,132369,2421,135372,169,257,136496,131136,136977]

theorem envBound27648 : H12AffineFastState.Bounded env27648 := by
  intro p hp
  have h : env27648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27647_27648 : H12AffineEnvironment.transform 22 136449 env27647 = env27648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136449 env27647 == env27648) = true)

theorem identity27648 : scanCanonicalize (H12AffineFastState.compose env27648 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound27648 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env27649 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5373,8233,8203,131072,10400,1025,8232,4161,33,136445,2,8328,65,10401,5357,132333,2185,135372,169,253,136396,131136,136941]

theorem envBound27649 : H12AffineFastState.Bounded env27649 := by
  intro p hp
  have h : env27649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27648_27649 : H12AffineEnvironment.transform 7 252 env27648 = env27649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env27648 == env27649) = true)

theorem identity27649 : scanCanonicalize (H12AffineFastState.compose env27649 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27649 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env27650 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5237,8233,8203,131072,10280,1025,8232,4161,33,136309,2,8192,65,10281,5221,132197,2049,135236,33,117,136260,131136,136805]

theorem envBound27650 : H12AffineFastState.Bounded env27650 := by
  intro p hp
  have h : env27650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27649_27650 : H12AffineEnvironment.transform 6 8 env27649 = env27650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27649 == env27650) = true)

theorem identity27650 : scanCanonicalize (H12AffineFastState.compose env27650 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound27650 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27651 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,0,34,131072,2049,1025,1,4161,33,136309,2,41,65,2048,5221,132197,2049,135236,33,117,136260,131136,136805]

theorem envBound27651 : H12AffineFastState.Bounded env27651 := by
  intro p hp
  have h : env27651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27650_27651 : H12AffineEnvironment.transform 12 41 env27650 = env27651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env27650 == env27651) = true)

theorem identity27651 : scanCanonicalize (H12AffineFastState.compose env27651 (packedSelected [1,2,3,5,8,14] rootPS)) = affineNative (2^(16+1) ^^^ 6224) := by decide +kernel

theorem selectedBound27651 : packedSelected [1,2,3,5,8,14] rootPS < 2^1333 := by decide +kernel

def env27652 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,0,34,6224,2049,1025,1,4161,33,3109,2,41,65,2048,5221,7221,2049,2068,33,117,3092,6160,3637]

theorem envBound27652 : H12AffineFastState.Bounded env27652 := by
  intro p hp
  have h : env27652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27651_27652 : H12AffineEnvironment.transform 16 6224 env27651 = env27652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 6224 env27651 == env27652) = true)

theorem identity27652 : scanCanonicalize (H12AffineFastState.compose env27652 (packedSelected [0,1,2,3,5,6,7,8,20] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound27652 : packedSelected [0,1,2,3,5,6,7,8,20] rootPS < 2^1333 := by decide +kernel

def env27653 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1077,4096,41,5237,0,34,5221,1076,1025,1,4161,33,16,2,41,65,1077,5221,4096,1076,1057,33,117,33,5157,512]

theorem envBound27653 : H12AffineFastState.Bounded env27653 := by
  intro p hp
  have h : env27653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27652_27653 : H12AffineEnvironment.transform 10 1077 env27652 = env27653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env27652 == env27653) = true)

theorem identity27653 : scanCanonicalize (H12AffineFastState.compose env27653 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound27653 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27654 : List Nat := [2,4,8,16,32,48,8,4,512,1024,1077,4096,41,5125,0,34,5141,1076,1025,1,4145,33,16,2,41,49,1077,5141,4096,1076,1057,33,5,33,5157,512]

theorem envBound27654 : H12AffineFastState.Bounded env27654 := by
  intro p hp
  have h : env27654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27653_27654 : H12AffineEnvironment.transform 5 48 env27653 = env27654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env27653 == env27654) = true)

theorem identity27654 : scanCanonicalize (H12AffineFastState.compose env27654 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound27654 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env27655 : List Nat := [2,4,8,16,32,48,8,4,512,21,32,4096,41,4112,0,34,4096,33,20,1,4145,33,16,2,41,49,32,4096,4096,33,52,33,5,33,4144,512]

theorem envBound27655 : H12AffineFastState.Bounded env27655 := by
  intro p hp
  have h : env27655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27654_27655 : H12AffineEnvironment.transform 9 21 env27654 = env27655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env27654 == env27655) = true)

theorem identity27655 : scanCanonicalize (H12AffineFastState.compose env27655 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound27655 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27656 : List Nat := [2,4,8,16,32,48,8,4,31,21,32,4096,41,4112,0,34,4096,33,20,1,4145,33,16,2,41,49,32,4096,4096,33,52,33,5,33,4144,31]

theorem envBound27656 : H12AffineFastState.Bounded env27656 := by
  intro p hp
  have h : env27656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27655_27656 : H12AffineEnvironment.transform 8 31 env27655 = env27656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env27655 == env27656) = true)

theorem identity27656 : scanCanonicalize (H12AffineFastState.compose env27656 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound27656 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27657 : List Nat := [2,4,8,16,32,48,8,4,31,21,32,49,41,33,0,34,49,33,20,1,0,33,16,2,41,49,32,49,49,33,52,33,5,33,1,31]

theorem envBound27657 : H12AffineFastState.Bounded env27657 := by
  intro p hp
  have h : env27657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27656_27657 : H12AffineEnvironment.transform 11 49 env27656 = env27657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env27656 == env27657) = true)

theorem identity27657 : scanCanonicalize (H12AffineFastState.compose env27657 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound27657 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27658 : List Nat := [2,4,8,16,30,14,8,4,31,21,30,15,23,31,0,28,15,31,20,1,0,31,16,2,23,15,30,15,15,31,10,31,5,31,1,31]

theorem envBound27658 : H12AffineFastState.Bounded env27658 := by
  intro p hp
  have h : env27658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27657_27658 : H12AffineEnvironment.transform 4 30 env27657 = env27658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env27657 == env27658) = true)

def env27659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21793,8388608,98780,8328,65,8546652,79130,8480026,8568225,8390093,98678,257,8484155,8492191,8462875]

theorem envBound27659 : H12AffineFastState.Bounded env27659 := by
  intro p hp
  have h : env27659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27629_27659 : H12AffineEnvironment.transform 21 21793 env27629 = env27659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env27629 == env27659) = true)

theorem identity27659 : scanCanonicalize (H12AffineFastState.compose env27659 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 62661) := by decide +kernel

theorem selectedBound27659 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,77898,21793,62661,98780,8328,65,171417,79130,102879,149860,61704,98678,257,98814,90202,120542]

theorem envBound27660 : H12AffineFastState.Bounded env27660 := by
  intro p hp
  have h : env27660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27659_27660 : H12AffineEnvironment.transform 22 62661 env27659 = env27660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62661 env27659 == env27660) = true)

def env27661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,10281,1025,32769,77898,169,41293,98780,8328,65,171417,79130,102879,138476,42112,98678,257,98814,79314,99158]

theorem envBound27661 : H12AffineFastState.Bounded env27661 := by
  intro p hp
  have h : env27661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27660_27661 : H12AffineEnvironment.transform 13 5512 env27660 = env27661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env27660 == env27661) = true)

theorem identity27661 : scanCanonicalize (H12AffineFastState.compose env27661 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound27661 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8322,131072,10281,1025,32769,4296,169,41293,41310,8328,65,171417,5528,45405,138476,42112,41460,257,41340,5456,41940]

theorem envBound27662 : H12AffineFastState.Bounded env27662 := by
  intro p hp
  have h : env27662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27661_27662 : H12AffineEnvironment.transform 15 8322 env27661 = env27662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env27661 == env27662) = true)

theorem identity27662 : scanCanonicalize (H12AffineFastState.compose env27662 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound27662 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8322,46277,10281,1025,32769,4296,169,41293,41310,8328,65,10588,5528,45405,43049,42112,41460,257,41340,5456,41940]

theorem envBound27663 : H12AffineFastState.Bounded env27663 := by
  intro p hp
  have h : env27663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27662_27663 : H12AffineEnvironment.transform 16 46277 env27662 = env27663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env27662 == env27663) = true)

theorem identity27663 : scanCanonicalize (H12AffineFastState.compose env27663 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27663 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27664 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4248,32768,8322,45525,10281,273,32769,4296,169,41293,41310,8328,65,10588,4232,45405,43049,41360,41460,257,41340,4160,41940]

theorem envBound27664 : H12AffineFastState.Bounded env27664 := by
  intro p hp
  have h : env27664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27663_27664 : H12AffineEnvironment.transform 9 272 env27663 = env27664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27663 == env27664) = true)

theorem identity27664 : scanCanonicalize (H12AffineFastState.compose env27664 (packedSelected [0,4,5,7,16,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound27664 : packedSelected [0,4,5,7,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env27665 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4248,8661,8322,4096,10281,273,8660,4296,169,152,139,8328,65,10588,4232,4232,2556,69,33,257,169,4160,513]

theorem envBound27665 : H12AffineFastState.Bounded env27665 := by
  intro p hp
  have h : env27665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27664_27665 : H12AffineEnvironment.transform 14 8661 env27664 = env27665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env27664 == env27665) = true)

theorem identity27665 : scanCanonicalize (H12AffineFastState.compose env27665 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27665 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27666 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,349,4248,136,479,4096,2420,273,137,4296,169,152,139,469,65,2049,4232,4232,2556,69,33,257,169,4160,513]

theorem envBound27666 : H12AffineFastState.Bounded env27666 := by
  intro p hp
  have h : env27666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27665_27666 : H12AffineEnvironment.transform 12 349 env27665 = env27666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27665 == env27666) = true)

theorem identity27666 : scanCanonicalize (H12AffineFastState.compose env27666 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound27666 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27667 : List Nat := [2,4,8,16,32,64,128,256,64,272,2048,4096,349,4248,136,479,4096,2420,273,137,4296,169,152,139,469,65,2049,4232,4232,2556,69,33,257,169,4160,65]

theorem envBound27667 : H12AffineFastState.Bounded env27667 := by
  intro p hp
  have h : env27667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27666_27667 : H12AffineEnvironment.transform 8 64 env27666 = env27667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env27666 == env27667) = true)

theorem identity27667 : scanCanonicalize (H12AffineFastState.compose env27667 (packedSelected [1,3,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27667 : packedSelected [1,3,14] rootPS < 2^1333 := by decide +kernel

def env27668 : List Nat := [2,4,8,16,32,64,9,256,64,272,2048,4096,349,4113,1,342,4096,2420,273,0,4161,32,17,2,348,65,2049,4097,4097,2421,69,33,257,32,4160,65]

theorem envBound27668 : H12AffineFastState.Bounded env27668 := by
  intro p hp
  have h : env27668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27667_27668 : H12AffineEnvironment.transform 6 9 env27667 = env27668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27667 == env27668) = true)

theorem identity27668 : scanCanonicalize (H12AffineFastState.compose env27668 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound27668 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27669 : List Nat := [2,4,8,16,17,64,9,256,64,272,2048,4096,349,4113,1,342,4096,2373,273,0,4161,17,17,2,348,65,2049,4097,4097,2372,69,16,257,17,4160,65]

theorem envBound27669 : H12AffineFastState.Bounded env27669 := by
  intro p hp
  have h : env27669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27668_27669 : H12AffineEnvironment.transform 4 17 env27668 = env27669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env27668 == env27669) = true)

theorem identity27669 : scanCanonicalize (H12AffineFastState.compose env27669 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound27669 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27670 : List Nat := [2,4,8,16,17,64,9,84,64,68,2048,4096,9,4113,1,2,4096,2065,69,0,4161,17,17,2,8,65,2049,4097,4097,2064,69,16,85,17,4160,65]

theorem envBound27670 : H12AffineFastState.Bounded env27670 := by
  intro p hp
  have h : env27670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27669_27670 : H12AffineEnvironment.transform 7 84 env27669 = env27670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env27669 == env27670) = true)

theorem identity27670 : scanCanonicalize (H12AffineFastState.compose env27670 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound27670 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27671 : List Nat := [2,4,8,16,17,64,9,84,64,68,2048,16,9,1,1,2,16,2065,69,0,81,17,17,2,8,65,2049,17,17,2064,69,16,85,17,80,65]

theorem envBound27671 : H12AffineFastState.Bounded env27671 := by
  intro p hp
  have h : env27671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27670_27671 : H12AffineEnvironment.transform 11 16 env27670 = env27671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env27670 == env27671) = true)

theorem identity27671 : scanCanonicalize (H12AffineFastState.compose env27671 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound27671 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27672 : List Nat := [2,4,8,16,17,64,9,84,64,68,16,16,9,1,1,2,16,1,69,0,81,17,17,2,8,65,17,17,17,0,69,16,85,17,80,65]

theorem envBound27672 : H12AffineFastState.Bounded env27672 := by
  intro p hp
  have h : env27672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27671_27672 : H12AffineEnvironment.transform 10 16 env27671 = env27672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env27671 == env27672) = true)

theorem identity27672 : scanCanonicalize (H12AffineFastState.compose env27672 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound27672 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27673 : List Nat := [2,4,8,16,17,0,9,20,0,4,16,16,9,1,1,2,16,1,5,0,17,17,17,2,8,1,17,17,17,0,5,16,21,17,16,1]

theorem envBound27673 : H12AffineFastState.Bounded env27673 := by
  intro p hp
  have h : env27673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27672_27673 : H12AffineEnvironment.transform 5 0 env27672 = env27673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env27672 == env27673) = true)

def env27674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,10280,1025,32769,77898,168,41292,98780,8328,65,171417,79130,102879,138477,42113,98678,257,98814,79315,99159]

theorem envBound27674 : H12AffineFastState.Bounded env27674 := by
  intro p hp
  have h : env27674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27660_27674 : H12AffineEnvironment.transform 13 5513 env27660 = env27674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env27660 == env27674) = true)

theorem identity27674 : scanCanonicalize (H12AffineFastState.compose env27674 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound27674 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33110,131072,10280,1025,32769,45340,168,41292,138,8328,65,171417,46156,4233,138477,42113,32,257,168,46213,513]

theorem envBound27675 : H12AffineFastState.Bounded env27675 := by
  intro p hp
  have h : env27675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27674_27675 : H12AffineEnvironment.transform 15 33110 env27674 = env27675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env27674 == env27675) = true)

theorem identity27675 : scanCanonicalize (H12AffineFastState.compose env27675 (packedSelected [0,2,4,6,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound27675 : packedSelected [0,2,4,6,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env27676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8661,8323,131072,10280,1025,8660,4297,168,153,138,8328,65,146508,5529,4233,138477,1364,32,257,168,5456,513]

theorem envBound27676 : H12AffineFastState.Bounded env27676 := by
  intro p hp
  have h : env27676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27675_27676 : H12AffineEnvironment.transform 14 8661 env27675 = env27676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env27675 == env27676) = true)

theorem identity27676 : scanCanonicalize (H12AffineFastState.compose env27676 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound27676 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8661,8323,5392,10280,1025,8660,4297,168,153,138,8328,65,10588,5529,4233,2557,1364,32,257,168,5456,513]

theorem envBound27677 : H12AffineFastState.Bounded env27677 := by
  intro p hp
  have h : env27677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27676_27677 : H12AffineEnvironment.transform 16 5392 env27676 = env27677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env27676 == env27677) = true)

theorem identity27677 : scanCanonicalize (H12AffineFastState.compose env27677 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27677 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,5392,10280,1025,8540,4161,32,17,2,8192,65,10588,5393,4097,2421,1364,32,257,32,5456,513]

theorem envBound27678 : H12AffineFastState.Bounded env27678 := by
  intro p hp
  have h : env27678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27677_27678 : H12AffineEnvironment.transform 6 8 env27677 = env27678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27677 == env27678) = true)

theorem identity27678 : scanCanonicalize (H12AffineFastState.compose env27678 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound27678 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,9,5377,340,2,5392,2081,1025,341,4161,32,17,2,9,65,2389,5393,4097,2421,1364,32,257,32,5456,513]

theorem envBound27679 : H12AffineFastState.Bounded env27679 := by
  intro p hp
  have h : env27679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27678_27679 : H12AffineEnvironment.transform 12 9 env27678 = env27679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env27678 == env27679) = true)

theorem identity27679 : scanCanonicalize (H12AffineFastState.compose env27679 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound27679 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env27680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1028,9,261,340,2,276,2081,1025,341,1093,32,17,2,9,65,2389,277,1029,2421,1364,32,257,32,340,513]

theorem envBound27680 : H12AffineFastState.Bounded env27680 := by
  intro p hp
  have h : env27680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27679_27680 : H12AffineEnvironment.transform 11 1028 env27679 = env27680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env27679 == env27680) = true)

theorem identity27680 : scanCanonicalize (H12AffineFastState.compose env27680 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound27680 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env27681 : List Nat := [2,4,8,16,32,64,8,256,512,1024,32,1028,9,261,340,2,276,1,1025,341,1093,32,17,2,9,65,373,277,1029,341,1364,32,257,32,340,513]

theorem envBound27681 : H12AffineFastState.Bounded env27681 := by
  intro p hp
  have h : env27681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27680_27681 : H12AffineEnvironment.transform 10 32 env27680 = env27681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env27680 == env27681) = true)

theorem identity27681 : scanCanonicalize (H12AffineFastState.compose env27681 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound27681 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env27682 : List Nat := [2,4,8,16,32,64,8,256,512,100,32,96,9,261,340,2,276,1,101,341,33,32,17,2,9,65,373,277,97,341,304,32,257,32,340,513]

theorem envBound27682 : H12AffineFastState.Bounded env27682 := by
  intro p hp
  have h : env27682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27681_27682 : H12AffineEnvironment.transform 9 100 env27681 = env27682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env27681 == env27682) = true)

theorem identity27682 : scanCanonicalize (H12AffineFastState.compose env27682 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27682 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env27683 : List Nat := [2,4,8,16,1,64,8,256,512,69,1,65,9,261,340,2,276,1,68,341,0,1,17,2,9,65,340,277,64,341,273,1,257,1,340,513]

theorem envBound27683 : H12AffineFastState.Bounded env27683 := by
  intro p hp
  have h : env27683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27682_27683 : H12AffineEnvironment.transform 4 1 env27682 = env27683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27682 == env27683) = true)

theorem identity27683 : scanCanonicalize (H12AffineFastState.compose env27683 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound27683 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27684 : List Nat := [2,4,8,16,1,64,8,256,65,69,1,65,9,261,340,2,276,1,68,341,0,1,17,2,9,65,340,277,64,341,273,1,257,1,340,64]

theorem envBound27684 : H12AffineFastState.Bounded env27684 := by
  intro p hp
  have h : env27684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27683_27684 : H12AffineEnvironment.transform 8 65 env27683 = env27684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env27683 == env27684) = true)

theorem identity27684 : scanCanonicalize (H12AffineFastState.compose env27684 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound27684 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env27685 : List Nat := [2,4,8,16,1,64,8,20,65,69,1,65,9,17,64,2,0,1,68,65,0,1,17,2,9,65,64,1,64,65,5,1,21,1,64,64]

theorem envBound27685 : H12AffineFastState.Bounded env27685 := by
  intro p hp
  have h : env27685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27684_27685 : H12AffineEnvironment.transform 7 20 env27684 = env27685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env27684 == env27685) = true)

theorem identity27685 : scanCanonicalize (H12AffineFastState.compose env27685 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27685 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27686 : List Nat := [2,4,8,0,1,64,8,4,65,69,1,65,9,1,64,2,0,1,68,65,0,1,1,2,9,65,64,1,64,65,5,1,5,1,64,64]

theorem envBound27686 : H12AffineFastState.Bounded env27686 := by
  intro p hp
  have h : env27686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27685_27686 : H12AffineEnvironment.transform 3 0 env27685 = env27686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27685 == env27686) = true)

theorem identity27686 : scanCanonicalize (H12AffineFastState.compose env27686 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound27686 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env27687 : List Nat := [2,4,8,0,1,0,8,4,1,5,1,1,9,1,0,2,0,1,4,1,0,1,1,2,9,1,0,1,0,1,5,1,5,1,0,0]

theorem envBound27687 : H12AffineFastState.Bounded env27687 := by
  intro p hp
  have h : env27687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27686_27687 : H12AffineEnvironment.transform 5 0 env27686 = env27687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env27686 == env27687) = true)

theorem identity27687 : scanCanonicalize (H12AffineFastState.compose env27687 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27687 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27688 : List Nat := [2,4,2,0,1,0,2,4,1,5,1,1,3,1,0,2,0,1,4,1,0,1,1,2,3,1,0,1,0,1,5,1,5,1,0,0]

theorem envBound27688 : H12AffineFastState.Bounded env27688 := by
  intro p hp
  have h : env27688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27687_27688 : H12AffineEnvironment.transform 2 2 env27687 = env27688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27687 == env27688) = true)

def env27689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254785,92374096,145662400,525568,140903597,27337993,25733062]

theorem envBound27689 : H12AffineFastState.Bounded env27689 := by
  intro p hp
  have h : env27689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26149_27689 : H12AffineEnvironment.transform 29 155254785 env26149 = env27689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env26149 == env27689) = true)

def env27690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254785,25265168,145662400,525568,140903597,27337993,25733062]

theorem envBound27690 : H12AffineFastState.Bounded env27690 := by
  intro p hp
  have h : env27690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27689_27690 : H12AffineEnvironment.transform 25 64 env27689 = env27690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env27689 == env27690) = true)

def env27691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356289,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound27691 : H12AffineFastState.Bounded env27691 := by
  intro p hp
  have h : env27691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27690_27691 : H12AffineEnvironment.transform 26 30393344 env27690 = env27691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env27690 == env27691) = true)

def env27692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound27692 : H12AffineFastState.Bounded env27692 := by
  intro p hp
  have h : env27692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27691_27692 : H12AffineEnvironment.transform 18 1024 env27691 = env27692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env27691 == env27692) = true)

theorem identity27692 : scanCanonicalize (H12AffineFastState.compose env27692 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8388762) := by decide +kernel

theorem selectedBound27692 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env27693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8388762,8328,64,4702362,10585111,10507601,8830977,99466,14771546,256,2212919,2172307,41820]

theorem envBound27693 : H12AffineFastState.Bounded env27693 := by
  intro p hp
  have h : env27693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27692_27693 : H12AffineEnvironment.transform 23 8388762 env27692 = env27693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8388762 env27692 == env27693) = true)

def env27694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,147474,8328,64,4702362,2344095,2233817,295049,99466,6497746,256,2212919,2172307,41820]

theorem envBound27694 : H12AffineFastState.Bounded env27694 := by
  intro p hp
  have h : env27694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27693_27694 : H12AffineEnvironment.transform 22 147592 env27693 = env27694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env27693 == env27694) = true)

def env27695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147592,147474,8328,64,4450362,2344095,2233817,43049,99466,6497746,256,2212919,2172307,41820]

theorem envBound27695 : H12AffineFastState.Bounded env27695 := by
  intro p hp
  have h : env27695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27694_27695 : H12AffineEnvironment.transform 17 10400 env27694 = env27695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env27694 == env27695) = true)

def env27696 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,2097152,4194304,147456,147474,8192,64,4450362,2343959,2233681,43049,99330,6497626,256,2212919,2172187,41820]

theorem envBound27696 : H12AffineFastState.Bounded env27696 := by
  intro p hp
  have h : env27696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27695_27696 : H12AffineEnvironment.transform 6 8 env27695 = env27696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27695 == env27696) = true)

theorem identity27696 : scanCanonicalize (H12AffineFastState.compose env27696 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound27696 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env27697 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,2097152,4194304,73755,73737,8192,64,4229153,2139148,2192714,43049,99330,6309185,256,2212919,2172187,41820]

theorem envBound27697 : H12AffineFastState.Bounded env27697 := by
  intro p hp
  have h : env27697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27696_27697 : H12AffineEnvironment.transform 16 90139 env27696 = env27697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env27696 == env27697) = true)

theorem identity27697 : scanCanonicalize (H12AffineFastState.compose env27697 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound27697 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env27698 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,2097152,73770,73755,73737,8192,64,108555,2139148,2192714,43049,99330,2188651,256,2212919,2172187,41820]

theorem envBound27698 : H12AffineFastState.Bounded env27698 := by
  intro p hp
  have h : env27698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27697_27698 : H12AffineEnvironment.transform 21 73770 env27697 = env27698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env27697 == env27698) = true)

theorem identity27698 : scanCanonicalize (H12AffineFastState.compose env27698 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound27698 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env27699 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10280,1024,8540,2097152,73770,73755,73737,8192,64,67926,2098513,2192714,2420,75103,2188651,256,2188650,2172187,513]

theorem envBound27699 : H12AffineFastState.Bounded env27699 := by
  intro p hp
  have h : env27699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27698_27699 : H12AffineEnvironment.transform 14 8541 env27698 = env27699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env27698 == env27699) = true)

theorem identity27699 : scanCanonicalize (H12AffineFastState.compose env27699 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound27699 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27700 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10280,1024,8540,5457,73770,73755,73737,8192,64,67926,4096,90139,2420,75103,94266,256,94267,77898,513]

theorem envBound27700 : H12AffineFastState.Bounded env27700 := by
  intro p hp
  have h : env27700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27699_27700 : H12AffineEnvironment.transform 20 5457 env27699 = env27700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env27699 == env27700) = true)

theorem identity27700 : scanCanonicalize (H12AffineFastState.compose env27700 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound27700 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27701 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,65536,77835,10280,1024,8540,5457,73770,73755,73737,8192,64,67926,4096,77835,2420,75103,73770,256,73771,77898,513]

theorem envBound27701 : H12AffineFastState.Bounded env27701 := by
  intro p hp
  have h : env27701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27700_27701 : H12AffineEnvironment.transform 13 4112 env27700 = env27701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env27700 == env27701) = true)

theorem identity27701 : scanCanonicalize (H12AffineFastState.compose env27701 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound27701 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env27702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,4112,1077,65536,71011,3392,1024,1076,5457,66882,66931,66913,1384,64,67926,4096,71011,2420,65591,66882,256,66883,70946,513]

theorem envBound27702 : H12AffineFastState.Bounded env27702 := by
  intro p hp
  have h : env27702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27701_27702 : H12AffineEnvironment.transform 12 1384 env27701 = env27702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env27701 == env27702) = true)

theorem identity27702 : scanCanonicalize (H12AffineFastState.compose env27702 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(15+1) ^^^ 7538) := by decide +kernel

theorem selectedBound27702 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env27703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,4112,1077,7538,2065,3392,1024,1076,5457,6192,6145,6163,1384,64,5156,4096,2065,2420,7493,6192,256,6193,2128,513]

theorem envBound27703 : H12AffineFastState.Bounded env27703 := by
  intro p hp
  have h : env27703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27702_27703 : H12AffineEnvironment.transform 15 7538 env27702 = env27703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7538 env27702 == env27703) = true)

theorem identity27703 : scanCanonicalize (H12AffineFastState.compose env27703 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound27703 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27704 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2113,1384,2129,1077,1331,2065,3392,1024,1076,3344,113,64,82,1384,64,3173,2113,2065,2420,1284,113,256,112,2128,513]

theorem envBound27704 : H12AffineFastState.Bounded env27704 := by
  intro p hp
  have h : env27704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27703_27704 : H12AffineEnvironment.transform 11 2113 env27703 = env27704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env27703 == env27704) = true)

theorem identity27704 : scanCanonicalize (H12AffineFastState.compose env27704 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1652) := by decide +kernel

theorem selectedBound27704 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env27705 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1652,1589,1384,1573,1077,1331,1637,820,1024,1076,868,113,64,82,1384,64,529,1589,1637,1792,1284,113,256,112,1572,513]

theorem envBound27705 : H12AffineFastState.Bounded env27705 := by
  intro p hp
  have h : env27705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27704_27705 : H12AffineEnvironment.transform 10 1652 env27704 = env27705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1652 env27704 == env27705) = true)

theorem identity27705 : scanCanonicalize (H12AffineFastState.compose env27705 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27705 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env27706 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1572,1589,1336,1573,1077,1331,1589,820,1024,1076,820,33,16,2,1336,16,529,1589,1589,1792,1284,33,256,32,1572,513]

theorem envBound27706 : H12AffineFastState.Bounded env27706 := by
  intro p hp
  have h : env27706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27705_27706 : H12AffineEnvironment.transform 5 16 env27705 = env27706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27705 == env27706) = true)

theorem identity27706 : scanCanonicalize (H12AffineFastState.compose env27706 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound27706 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27707 : List Nat := [2,4,8,16,32,16,8,21,512,1024,1572,1589,1069,1573,1077,1062,1589,545,1024,1076,545,33,16,2,1069,16,529,1589,1589,1557,1041,33,21,32,1572,513]

theorem envBound27707 : H12AffineFastState.Bounded env27707 := by
  intro p hp
  have h : env27707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27706_27707 : H12AffineEnvironment.transform 7 21 env27706 = env27707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env27706 == env27707) = true)

theorem identity27707 : scanCanonicalize (H12AffineFastState.compose env27707 (packedSelected [1,4] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound27707 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env27708 : List Nat := [2,4,8,16,32,16,8,21,512,516,32,49,553,33,561,546,49,545,516,560,545,33,16,2,553,16,529,49,49,17,533,33,21,32,32,513]

theorem envBound27708 : H12AffineFastState.Bounded env27708 := by
  intro p hp
  have h : env27708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27707_27708 : H12AffineEnvironment.transform 9 516 env27707 = env27708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env27707 == env27708) = true)

theorem identity27708 : scanCanonicalize (H12AffineFastState.compose env27708 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound27708 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27709 : List Nat := [2,4,8,16,32,16,8,21,49,53,32,49,24,33,0,19,49,16,53,1,16,33,16,2,24,16,32,49,49,17,36,33,21,32,32,48]

theorem envBound27709 : H12AffineFastState.Bounded env27709 := by
  intro p hp
  have h : env27709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27708_27709 : H12AffineEnvironment.transform 8 49 env27708 = env27709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env27708 == env27709) = true)

theorem identity27709 : scanCanonicalize (H12AffineFastState.compose env27709 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27709 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27710 : List Nat := [2,4,8,0,32,0,8,5,33,37,32,33,8,33,0,3,33,0,37,1,0,33,0,2,8,0,32,33,33,1,36,33,5,32,32,32]

theorem envBound27710 : H12AffineFastState.Bounded env27710 := by
  intro p hp
  have h : env27710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27709_27710 : H12AffineEnvironment.transform 3 0 env27709 = env27710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27709 == env27710) = true)

theorem identity27710 : scanCanonicalize (H12AffineFastState.compose env27710 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27710 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27711 : List Nat := [2,4,8,0,1,0,8,5,0,4,1,0,8,0,0,3,0,0,4,1,0,0,0,2,8,0,1,0,0,1,5,0,5,1,1,1]

theorem envBound27711 : H12AffineFastState.Bounded env27711 := by
  intro p hp
  have h : env27711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27710_27711 : H12AffineEnvironment.transform 4 1 env27710 = env27711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27710 == env27711) = true)

def env27712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,2097152,4194304,147457,147474,8193,64,4450362,2343958,2233680,43049,99331,6497627,256,2212919,2172186,41820]

theorem envBound27712 : H12AffineFastState.Bounded env27712 := by
  intro p hp
  have h : env27712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27695_27712 : H12AffineEnvironment.transform 6 9 env27695 = env27712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27695 == env27712) = true)

theorem identity27712 : scanCanonicalize (H12AffineFastState.compose env27712 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound27712 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env27713 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,2097152,4194304,147457,147474,8193,64,4409703,2319691,2233680,2420,75102,6497627,256,2188650,2172186,513]

theorem envBound27713 : H12AffineFastState.Bounded env27713 := by
  intro p hp
  have h : env27713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27712_27713 : H12AffineEnvironment.transform 14 8541 env27712 = env27713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env27712 == env27713) = true)

def env27714 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,4194304,147457,147474,8193,16,4409655,2319643,2233600,2340,75022,6497547,256,2188602,2172186,513]

theorem envBound27714 : H12AffineFastState.Bounded env27714 := by
  intro p hp
  have h : env27714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27713_27714 : H12AffineEnvironment.transform 5 16 env27713 = env27714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27713 == env27714) = true)

theorem identity27714 : scanCanonicalize (H12AffineFastState.compose env27714 (packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 213302) := by decide +kernel

theorem selectedBound27714 : packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS < 2^1333 := by decide +kernel

def env27715 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,213302,147457,147474,8193,16,2049,2319643,2233600,2340,75022,2122813,256,2188602,2172186,513]

theorem envBound27715 : H12AffineFastState.Bounded env27715 := by
  intro p hp
  have h : env27715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27714_27715 : H12AffineEnvironment.transform 21 213302 env27714 = env27715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213302 env27714 == env27715) = true)

theorem identity27715 : scanCanonicalize (H12AffineFastState.compose env27715 (packedSelected [1,2,6,8,10,11,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound27715 : packedSelected [1,2,6,8,10,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env27716 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,65536,131072,2340,1024,1,2097152,213302,147457,147474,268,16,2049,2311190,2233600,2340,66563,2114864,256,2180151,2163735,513]

theorem envBound27716 : H12AffineFastState.Bounded env27716 := by
  intro p hp
  have h : env27716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27715_27716 : H12AffineEnvironment.transform 12 269 env27715 = env27716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env27715 == env27716) = true)

theorem identity27716 : scanCanonicalize (H12AffineFastState.compose env27716 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 132352) := by decide +kernel

theorem selectedBound27716 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27717 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,65536,131072,2340,1024,1,132352,213302,147457,147474,268,16,2049,82198,4096,2340,66563,147504,256,213303,196887,513]

theorem envBound27717 : H12AffineFastState.Bounded env27717 := by
  intro p hp
  have h : env27717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27716_27717 : H12AffineEnvironment.transform 20 132352 env27716 = env27717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132352 env27716 == env27717) = true)

theorem identity27717 : scanCanonicalize (H12AffineFastState.compose env27717 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound27717 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env27718 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,65536,16401,2340,1024,1,17681,65831,16,3,268,16,2049,82198,4096,2340,66563,33,256,65830,82182,513]

theorem envBound27718 : H12AffineFastState.Bounded env27718 := by
  intro p hp
  have h : env27718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27717_27718 : H12AffineEnvironment.transform 16 16401 env27717 = env27718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env27717 == env27718) = true)

theorem identity27718 : scanCanonicalize (H12AffineFastState.compose env27718 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(13+1) ^^^ 7733) := by decide +kernel

theorem selectedBound27718 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env27719 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,7733,0,65536,7716,2340,1024,1,6948,65831,16,3,268,16,2049,73507,4096,2340,66563,33,256,65830,73523,513]

theorem envBound27719 : H12AffineFastState.Bounded env27719 := by
  intro p hp
  have h : env27719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27718_27719 : H12AffineEnvironment.transform 13 7733 env27718 = env27719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7733 env27718 == env27719) = true)

theorem identity27719 : scanCanonicalize (H12AffineFastState.compose env27719 (packedSelected [0,3,4,5,12] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound27719 : packedSelected [0,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env27720 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,7733,0,262,7716,2340,1024,1,6948,33,16,3,268,16,2049,7717,4096,2340,1285,33,256,32,7733,513]

theorem envBound27720 : H12AffineFastState.Bounded env27720 := by
  intro p hp
  have h : env27720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27719_27720 : H12AffineEnvironment.transform 15 262 env27719 = env27720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env27719 == env27720) = true)

theorem identity27720 : scanCanonicalize (H12AffineFastState.compose env27720 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound27720 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27721 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,276,269,3873,0,262,3888,2340,1024,1,2608,33,16,3,268,16,2049,3889,276,2340,1285,33,256,32,3873,513]

theorem envBound27721 : H12AffineFastState.Bounded env27721 := by
  intro p hp
  have h : env27721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27720_27721 : H12AffineEnvironment.transform 11 276 env27720 = env27721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env27720 == env27721) = true)

theorem identity27721 : scanCanonicalize (H12AffineFastState.compose env27721 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 299) := by decide +kernel

theorem selectedBound27721 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27722 : List Nat := [2,4,8,16,32,16,9,256,512,299,2048,276,269,2570,0,262,2587,2340,299,1,2608,33,16,3,268,16,2049,2586,276,2340,46,33,256,32,2570,513]

theorem envBound27722 : H12AffineFastState.Bounded env27722 := by
  intro p hp
  have h : env27722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27721_27722 : H12AffineEnvironment.transform 9 299 env27721 = env27722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 299 env27721 == env27722) = true)

theorem identity27722 : scanCanonicalize (H12AffineFastState.compose env27722 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound27722 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27723 : List Nat := [2,4,8,16,32,16,9,256,59,299,2048,276,269,2097,0,262,2080,2340,299,1,2059,33,16,3,268,16,2049,2081,276,2340,46,33,256,32,2097,58]

theorem envBound27723 : H12AffineFastState.Bounded env27723 := by
  intro p hp
  have h : env27723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27722_27723 : H12AffineEnvironment.transform 8 59 env27722 = env27723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env27722 == env27723) = true)

theorem identity27723 : scanCanonicalize (H12AffineFastState.compose env27723 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27723 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27724 : List Nat := [2,4,2,16,32,16,3,256,49,289,2048,276,263,2097,0,262,2080,2340,289,1,2049,33,16,3,262,16,2049,2081,276,2340,36,33,256,32,2097,48]

theorem envBound27724 : H12AffineFastState.Bounded env27724 := by
  intro p hp
  have h : env27724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27723_27724 : H12AffineEnvironment.transform 2 2 env27723 = env27724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27723 == env27724) = true)

theorem identity27724 : scanCanonicalize (H12AffineFastState.compose env27724 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound27724 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27725 : List Nat := [2,4,2,16,32,16,3,256,49,289,49,276,263,0,0,262,17,277,289,1,48,33,16,3,262,16,48,16,276,277,36,33,256,32,0,48]

theorem envBound27725 : H12AffineFastState.Bounded env27725 := by
  intro p hp
  have h : env27725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27724_27725 : H12AffineEnvironment.transform 10 49 env27724 = env27725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env27724 == env27725) = true)

theorem identity27725 : scanCanonicalize (H12AffineFastState.compose env27725 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound27725 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env27726 : List Nat := [2,4,2,16,32,16,3,21,49,52,49,1,18,0,0,19,17,0,52,1,48,33,16,3,19,16,48,16,1,0,36,33,21,32,0,48]

theorem envBound27726 : H12AffineFastState.Bounded env27726 := by
  intro p hp
  have h : env27726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27725_27726 : H12AffineEnvironment.transform 7 21 env27725 = env27726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env27725 == env27726) = true)

theorem identity27726 : scanCanonicalize (H12AffineFastState.compose env27726 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound27726 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27727 : List Nat := [2,4,2,16,23,16,3,21,6,3,6,1,18,0,0,19,17,0,3,1,7,22,16,3,19,16,7,16,1,0,19,22,21,23,0,7]

theorem envBound27727 : H12AffineFastState.Bounded env27727 := by
  intro p hp
  have h : env27727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27726_27727 : H12AffineEnvironment.transform 4 23 env27726 = env27727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env27726 == env27727) = true)

def env27728 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,4194304,147457,147474,8193,17,4409654,2319642,2233601,2341,75023,6497546,256,2188603,2172186,513]

theorem envBound27728 : H12AffineFastState.Bounded env27728 := by
  intro p hp
  have h : env27728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27713_27728 : H12AffineEnvironment.transform 5 17 env27713 = env27728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27713 == env27728) = true)

theorem identity27728 : scanCanonicalize (H12AffineFastState.compose env27728 (packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound27728 : packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS < 2^1333 := by decide +kernel

def env27729 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,8493,147457,147474,8193,17,223259,2319642,2233601,2341,75023,2294823,256,2188603,2172186,513]

theorem envBound27729 : H12AffineFastState.Bounded env27729 := by
  intro p hp
  have h : env27729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27728_27729 : H12AffineEnvironment.transform 21 8493 env27728 = env27729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env27728 == env27729) = true)

theorem identity27729 : scanCanonicalize (H12AffineFastState.compose env27729 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(20+1) ^^^ 197639) := by decide +kernel

theorem selectedBound27729 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27730 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,197639,8493,147457,147474,8193,17,223259,24861,69894,2341,75023,32,256,155964,139549,513]

theorem envBound27730 : H12AffineFastState.Bounded env27730 := by
  intro p hp
  have h : env27730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27729_27730 : H12AffineEnvironment.transform 20 197639 env27729 = env27730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 197639 env27729 == env27730) = true)

theorem identity27730 : scanCanonicalize (H12AffineFastState.compose env27730 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound27730 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env27731 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,65536,24860,10281,1024,8461,91419,8493,8477,8462,8193,17,67847,24861,69894,2341,75023,32,256,32,16385,513]

theorem envBound27731 : H12AffineFastState.Bounded env27731 := by
  intro p hp
  have h : env27731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27730_27731 : H12AffineEnvironment.transform 16 24860 env27730 = env27731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env27730 == env27731) = true)

theorem identity27731 : scanCanonicalize (H12AffineFastState.compose env27731 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27731 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27732 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,65536,16400,2341,1024,1,82967,33,17,2,269,17,67847,16401,69894,2341,66563,32,256,32,16385,513]

theorem envBound27732 : H12AffineFastState.Bounded env27732 := by
  intro p hp
  have h : env27732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27731_27732 : H12AffineEnvironment.transform 12 268 env27731 = env27732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27731 == env27732) = true)

theorem identity27732 : scanCanonicalize (H12AffineFastState.compose env27732 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound27732 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27733 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,262,16400,2341,1024,1,17681,33,17,2,269,17,2049,16401,4096,2341,1285,32,256,32,16385,513]

theorem envBound27733 : H12AffineFastState.Bounded env27733 := by
  intro p hp
  have h : env27733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27732_27733 : H12AffineEnvironment.transform 15 262 env27732 = env27733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env27732 == env27733) = true)

theorem identity27733 : scanCanonicalize (H12AffineFastState.compose env27733 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27733 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27734 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,262,5392,2341,1024,1,4113,33,17,2,269,17,2049,5393,4096,2341,1285,32,256,32,5377,513]

theorem envBound27734 : H12AffineFastState.Bounded env27734 := by
  intro p hp
  have h : env27734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27733_27734 : H12AffineEnvironment.transform 13 5376 env27733 = env27734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27733 == env27734) = true)

theorem identity27734 : scanCanonicalize (H12AffineFastState.compose env27734 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2878) := by decide +kernel

theorem selectedBound27734 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27735 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2878,268,3646,0,262,3630,2341,1024,1,2863,33,17,2,269,17,2049,3631,2878,2341,1285,32,256,32,3647,513]

theorem envBound27735 : H12AffineFastState.Bounded env27735 := by
  intro p hp
  have h : env27735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27734_27735 : H12AffineEnvironment.transform 11 2878 env27734 = env27735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2878 env27734 == env27735) = true)

theorem identity27735 : scanCanonicalize (H12AffineFastState.compose env27735 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27735 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27736 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,2619,9,3646,0,3,3630,2080,1024,1,2602,33,17,2,8,17,2049,3631,2619,2080,1024,32,5,32,3647,513]

theorem envBound27736 : H12AffineFastState.Bounded env27736 := by
  intro p hp
  have h : env27736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27735_27736 : H12AffineEnvironment.transform 7 5 env27735 = env27736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27735 == env27736) = true)

theorem identity27736 : scanCanonicalize (H12AffineFastState.compose env27736 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound27736 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27737 : List Nat := [2,4,8,16,32,17,9,5,512,1024,1566,1061,9,32,0,3,48,1598,1024,1,1076,33,17,2,8,17,1567,49,1061,1598,1024,32,5,32,33,513]

theorem envBound27737 : H12AffineFastState.Bounded env27737 := by
  intro p hp
  have h : env27737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27736_27737 : H12AffineEnvironment.transform 10 1566 env27736 = env27737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env27736 == env27737) = true)

theorem identity27737 : scanCanonicalize (H12AffineFastState.compose env27737 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound27737 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27738 : List Nat := [2,4,8,16,32,17,9,5,512,542,0,571,9,32,0,3,48,32,542,1,554,33,17,2,8,17,1,49,571,32,542,32,5,32,33,513]

theorem envBound27738 : H12AffineFastState.Bounded env27738 := by
  intro p hp
  have h : env27738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27737_27738 : H12AffineEnvironment.transform 9 542 env27737 = env27738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env27737 == env27738) = true)

def env27739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147592,147474,8328,64,4450363,2344095,2233817,43048,99466,6497746,256,2212919,2172307,41820]

theorem envBound27739 : H12AffineFastState.Bounded env27739 := by
  intro p hp
  have h : env27739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27694_27739 : H12AffineEnvironment.transform 17 10401 env27694 = env27739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env27694 == env27739) = true)

theorem identity27739 : scanCanonicalize (H12AffineFastState.compose env27739 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound27739 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env27740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,10401,1024,32769,2097152,4194304,16,138,8328,64,4303011,2196487,2118977,43048,99466,6382922,256,2212919,2172307,41820]

theorem envBound27740 : H12AffineFastState.Bounded env27740 := by
  intro p hp
  have h : env27740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27739_27740 : H12AffineEnvironment.transform 16 16536 env27739 = env27740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env27739 == env27740) = true)

theorem identity27740 : scanCanonicalize (H12AffineFastState.compose env27740 (packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound27740 : packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env27741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,16536,10401,1024,32769,2097152,4194304,16,138,8328,64,4204925,2098649,2118977,43048,1364,6349972,256,2115049,2139213,41820]

theorem envBound27741 : H12AffineFastState.Bounded env27741 := by
  intro p hp
  have h : env27741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27740_27741 : H12AffineEnvironment.transform 15 33246 env27740 = env27741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env27740 == env27741) = true)

theorem identity27741 : scanCanonicalize (H12AffineFastState.compose env27741 (packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound27741 : packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env27742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,16536,10401,1024,32769,2097152,32,16,138,8328,64,10589,2098649,2118977,43048,1364,2155700,256,2115049,2139213,41820]

theorem envBound27742 : H12AffineFastState.Bounded env27742 := by
  intro p hp
  have h : env27742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27741_27742 : H12AffineEnvironment.transform 21 32 env27741 = env27742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env27741 == env27742) = true)

theorem identity27742 : scanCanonicalize (H12AffineFastState.compose env27742 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 50449) := by decide +kernel

theorem selectedBound27742 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env27743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,16536,10401,1024,32769,50449,32,16,138,8328,64,10589,49352,36944,43048,1364,8613,256,33016,24924,41820]

theorem envBound27743 : H12AffineFastState.Bounded env27743 := by
  intro p hp
  have h : env27743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27742_27743 : H12AffineEnvironment.transform 20 50449 env27742 = env27743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env27742 == env27743) = true)

theorem identity27743 : scanCanonicalize (H12AffineFastState.compose env27743 (packedSelected [2,3,6,7,8,9,11,14,15,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13809) := by decide +kernel

theorem selectedBound27743 : packedSelected [2,3,6,7,8,9,11,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env27744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13809,32768,33246,13673,10401,1024,32769,45280,32,16,138,8328,64,10589,46393,36944,43048,1364,8613,256,33016,5293,41820]

theorem envBound27744 : H12AffineFastState.Bounded env27744 := by
  intro p hp
  have h : env27744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27743_27744 : H12AffineEnvironment.transform 13 13809 env27743 = env27744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13809 env27743 == env27744) = true)

theorem identity27744 : scanCanonicalize (H12AffineFastState.compose env27744 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,15,20] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound27744 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,15,20] rootPS < 2^1333 := by decide +kernel

def env27745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13809,8312,8614,13673,10401,1024,8313,4248,32,16,138,8328,64,10589,5441,12328,2128,1364,8613,256,8320,5293,804]

theorem envBound27745 : H12AffineFastState.Bounded env27745 := by
  intro p hp
  have h : env27745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27744_27745 : H12AffineEnvironment.transform 14 8312 env27744 = env27745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env27744 == env27745) = true)

theorem identity27745 : scanCanonicalize (H12AffineFastState.compose env27745 (packedSelected [2,3,4,6,7,8,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound27745 : packedSelected [2,3,4,6,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env27746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,5377,136,342,5529,2129,1024,137,4248,32,16,138,120,64,2477,5441,4312,2128,1364,341,256,112,5293,804]

theorem envBound27746 : H12AffineFastState.Bounded env27746 := by
  intro p hp
  have h : env27746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27745_27746 : H12AffineEnvironment.transform 12 240 env27745 = env27746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env27745 == env27746) = true)

theorem identity27746 : scanCanonicalize (H12AffineFastState.compose env27746 (packedSelected [0,1,2,3,4,6,11,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27746 : packedSelected [0,1,2,3,4,6,11,17] rootPS < 2^1333 := by decide +kernel

def env27747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5377,0,342,5393,2129,1024,1,4112,32,16,2,120,64,2341,5441,4176,2128,1364,341,256,112,5157,804]

theorem envBound27747 : H12AffineFastState.Bounded env27747 := by
  intro p hp
  have h : env27747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27746_27747 : H12AffineEnvironment.transform 6 8 env27746 = env27747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27746 == env27747) = true)

theorem identity27747 : scanCanonicalize (H12AffineFastState.compose env27747 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27747 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27748 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,88,5377,0,342,5393,2129,1024,1,4112,0,16,2,88,64,2309,5441,4176,2128,1364,341,256,80,5125,772]

theorem envBound27748 : H12AffineFastState.Bounded env27748 := by
  intro p hp
  have h : env27748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27747_27748 : H12AffineEnvironment.transform 4 0 env27747 = env27748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27747 == env27748) = true)

theorem identity27748 : scanCanonicalize (H12AffineFastState.compose env27748 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27748 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27749 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,8,5377,0,262,5393,2049,1024,1,4112,0,16,2,8,16,2309,5393,4096,2048,1284,261,256,0,5125,772]

theorem envBound27749 : H12AffineFastState.Bounded env27749 := by
  intro p hp
  have h : env27749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27748_27749 : H12AffineEnvironment.transform 5 16 env27748 = env27749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27748 == env27749) = true)

theorem identity27749 : scanCanonicalize (H12AffineFastState.compose env27749 (packedSelected [1,2,3,4,7,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27749 : packedSelected [1,2,3,4,7,12] rootPS < 2^1333 := by decide +kernel

def env27750 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,8,5125,0,2,5141,2049,1024,1,4112,0,16,2,8,16,2049,5141,4096,2048,1024,1,4,0,5125,512]

theorem envBound27750 : H12AffineFastState.Bounded env27750 := by
  intro p hp
  have h : env27750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27749_27750 : H12AffineEnvironment.transform 7 4 env27749 = env27750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27749 == env27750) = true)

def env27751 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,8,1045,0,2,1029,2049,1024,1,0,0,16,2,8,16,2049,1029,16,2048,1024,1,4,0,1045,512]

theorem envBound27751 : H12AffineFastState.Bounded env27751 := by
  intro p hp
  have h : env27751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27750_27751 : H12AffineEnvironment.transform 11 16 env27750 = env27751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env27750 == env27751) = true)

theorem identity27751 : scanCanonicalize (H12AffineFastState.compose env27751 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound27751 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27752 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,16,8,1045,0,2,1029,1,1024,1,0,0,16,2,8,16,1,1029,16,0,1024,1,4,0,1045,512]

theorem envBound27752 : H12AffineFastState.Bounded env27752 := by
  intro p hp
  have h : env27752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27751_27752 : H12AffineEnvironment.transform 10 0 env27751 = env27752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env27751 == env27752) = true)

def env27753 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,8,1,0,2,17,1,20,1,0,0,16,2,8,16,1,17,16,0,20,1,4,0,1,512]

theorem envBound27753 : H12AffineFastState.Bounded env27753 := by
  intro p hp
  have h : env27753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27752_27753 : H12AffineEnvironment.transform 9 20 env27752 = env27753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env27752 == env27753) = true)

theorem identity27753 : scanCanonicalize (H12AffineFastState.compose env27753 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound27753 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27754 : List Nat := [2,4,8,16,0,16,8,4,31,20,0,16,8,1,0,2,17,1,20,1,0,0,16,2,8,16,1,17,16,0,20,1,4,0,1,31]

theorem envBound27754 : H12AffineFastState.Bounded env27754 := by
  intro p hp
  have h : env27754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27753_27754 : H12AffineEnvironment.transform 8 31 env27753 = env27754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env27753 == env27754) = true)

def leafEnv27754 : List Nat := [2,4,8,16,0,16,8,4,31,20,0,16,8,1,0,2,17,1,20,1,0,0,16,2,20,8,1,16,1,17,16,0,20,1,4,0,4,2,1,31,1,0,0]

def active27754 : List Nat := [0,1,2,3]

def tree27754 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood27754 : H12WitnessSearch.Good tree27754 := H12GlobalWitnessIndex.good

theorem leafIdentity27754 : H12AffineFastState.composeSystem env27754 rootObs = leafEnv27754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env27754 rootObs == leafEnv27754) = true)

theorem terminalChecked27754 : H12PackedTerminal.terminalCheckFast leafEnv27754 active27754 tree27754 = true := by decide +kernel

def env27755 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,16,8,0,0,2,16,1,21,1,0,0,16,2,8,16,1,16,16,0,21,1,4,0,0,512]

theorem envBound27755 : H12AffineFastState.Bounded env27755 := by
  intro p hp
  have h : env27755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27752_27755 : H12AffineEnvironment.transform 9 21 env27752 = env27755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env27752 == env27755) = true)

theorem identity27755 : scanCanonicalize (H12AffineFastState.compose env27755 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound27755 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27756 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,8,0,0,2,5,1,0,1,0,0,5,2,8,5,1,5,5,0,0,1,4,0,0,512]

theorem envBound27756 : H12AffineFastState.Bounded env27756 := by
  intro p hp
  have h : env27756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27755_27756 : H12AffineEnvironment.transform 3 5 env27755 = env27756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env27755 == env27756) = true)

def leafEnv27756 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,8,0,0,2,5,1,0,1,0,0,5,2,0,8,1,5,1,5,5,0,0,1,4,0,4,2,0,512,1,0,0]

def active27756 : List Nat := [0,1,2,8]

def tree27756 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood27756 : H12WitnessSearch.Good tree27756 := H12GlobalWitnessIndex.good

theorem leafIdentity27756 : H12AffineFastState.composeSystem env27756 rootObs = leafEnv27756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env27756 rootObs == leafEnv27756) = true)

theorem terminalChecked27756 : H12PackedTerminal.terminalCheckFast leafEnv27756 active27756 tree27756 = true := by decide +kernel

def env27757 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,8,1044,0,2,1028,2049,1024,1,1,0,16,2,8,16,2049,1028,17,2048,1024,1,4,0,1044,512]

theorem envBound27757 : H12AffineFastState.Bounded env27757 := by
  intro p hp
  have h : env27757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27750_27757 : H12AffineEnvironment.transform 11 17 env27750 = env27757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env27750 == env27757) = true)

theorem identity27757 : scanCanonicalize (H12AffineFastState.compose env27757 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound27757 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27758 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1044,17,8,1044,0,2,1028,1045,1024,1,1,0,16,2,8,16,1045,1028,17,1044,1024,1,4,0,1044,512]

theorem envBound27758 : H12AffineFastState.Bounded env27758 := by
  intro p hp
  have h : env27758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27757_27758 : H12AffineEnvironment.transform 10 1044 env27757 = env27758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env27757 == env27758) = true)

def env27759 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,17,8,0,0,2,16,1,20,1,1,0,16,2,8,16,1,16,17,0,20,1,4,0,0,512]

theorem envBound27759 : H12AffineFastState.Bounded env27759 := by
  intro p hp
  have h : env27759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27758_27759 : H12AffineEnvironment.transform 9 20 env27758 = env27759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env27758 == env27759) = true)

theorem identity27759 : scanCanonicalize (H12AffineFastState.compose env27759 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound27759 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27760 : List Nat := [2,4,8,16,0,16,8,4,31,20,0,17,8,0,0,2,16,1,20,1,1,0,16,2,8,16,1,16,17,0,20,1,4,0,0,31]

theorem envBound27760 : H12AffineFastState.Bounded env27760 := by
  intro p hp
  have h : env27760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27759_27760 : H12AffineEnvironment.transform 8 31 env27759 = env27760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env27759 == env27760) = true)

def leafEnv27760 : List Nat := [2,4,8,16,0,16,8,4,31,20,0,17,8,0,0,2,16,1,20,1,1,0,16,2,20,8,1,16,1,16,17,0,20,1,4,0,4,2,0,31,1,1,0]

def active27760 : List Nat := [0,1,2,3]

def tree27760 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood27760 : H12WitnessSearch.Good tree27760 := H12GlobalWitnessIndex.good

theorem leafIdentity27760 : H12AffineFastState.composeSystem env27760 rootObs = leafEnv27760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env27760 rootObs == leafEnv27760) = true)

theorem terminalChecked27760 : H12PackedTerminal.terminalCheckFast leafEnv27760 active27760 tree27760 = true := by decide +kernel

def env27761 : List Nat := [2,4,8,16,0,16,8,4,512,21,1,17,8,1,0,2,17,0,21,1,1,0,16,2,8,16,0,17,17,1,21,1,4,0,1,512]

theorem envBound27761 : H12AffineFastState.Bounded env27761 := by
  intro p hp
  have h : env27761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27758_27761 : H12AffineEnvironment.transform 9 21 env27758 = env27761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env27758 == env27761) = true)

theorem identity27761 : scanCanonicalize (H12AffineFastState.compose env27761 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound27761 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27762 : List Nat := [2,4,8,5,0,5,8,4,512,0,1,4,8,1,0,2,4,0,0,1,1,0,5,2,8,5,0,4,4,1,0,1,4,0,1,512]

theorem envBound27762 : H12AffineFastState.Bounded env27762 := by
  intro p hp
  have h : env27762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27761_27762 : H12AffineEnvironment.transform 3 5 env27761 = env27762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env27761 == env27762) = true)

def leafEnv27762 : List Nat := [2,4,8,5,0,5,8,4,512,0,1,4,8,1,0,2,4,0,0,1,1,0,5,2,0,8,1,5,0,4,4,1,0,1,4,0,4,2,1,512,1,1,0]

def active27762 : List Nat := [0,1,2,8]

def tree27762 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood27762 : H12WitnessSearch.Good tree27762 := H12GlobalWitnessIndex.good

theorem leafIdentity27762 : H12AffineFastState.composeSystem env27762 rootObs = leafEnv27762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env27762 rootObs == leafEnv27762) = true)

theorem terminalChecked27762 : H12PackedTerminal.terminalCheckFast leafEnv27762 active27762 tree27762 = true := by decide +kernel

def env27763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,147475,8328,64,4702362,2344094,2233816,295048,99466,6497747,256,2212919,2172307,41820]

theorem envBound27763 : H12AffineFastState.Bounded env27763 := by
  intro p hp
  have h : env27763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27693_27763 : H12AffineEnvironment.transform 22 147593 env27693 = env27763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env27693 == env27763) = true)

def env27764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147593,147475,8328,64,4450362,2344094,2233816,43048,99466,6497747,256,2212919,2172307,41820]

theorem envBound27764 : H12AffineFastState.Bounded env27764 := by
  intro p hp
  have h : env27764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27763_27764 : H12AffineEnvironment.transform 17 10400 env27763 = env27764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env27763 == env27764) = true)

theorem identity27764 : scanCanonicalize (H12AffineFastState.compose env27764 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound27764 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env27765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10400,1024,8540,2097152,4194304,147593,147475,8328,64,4409703,2319811,2233816,2421,75223,6497747,256,2188650,2172307,513]

theorem envBound27765 : H12AffineFastState.Bounded env27765 := by
  intro p hp
  have h : env27765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27764_27765 : H12AffineEnvironment.transform 14 8541 env27764 = env27765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env27764 == env27765) = true)

def env27766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10280,1024,8540,2097152,4194304,147457,147475,8192,64,4409703,2319691,2233680,2421,75103,6497627,256,2188650,2172187,513]

theorem envBound27766 : H12AffineFastState.Bounded env27766 := by
  intro p hp
  have h : env27766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27765_27766 : H12AffineEnvironment.transform 6 8 env27765 = env27766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27765 == env27766) = true)

theorem identity27766 : scanCanonicalize (H12AffineFastState.compose env27766 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound27766 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env27767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10280,1024,8540,2097152,4194304,73754,73736,8192,64,4204924,2098512,2192715,2421,75103,6309184,256,2188650,2172187,513]

theorem envBound27767 : H12AffineFastState.Bounded env27767 := by
  intro p hp
  have h : env27767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27766_27767 : H12AffineEnvironment.transform 16 90139 env27766 = env27767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env27766 == env27767) = true)

theorem identity27767 : scanCanonicalize (H12AffineFastState.compose env27767 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 79195) := by decide +kernel

theorem selectedBound27767 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env27768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10280,1024,8540,79195,4194304,73754,73736,8192,64,4204924,77835,16400,2421,75103,4288539,256,20529,4160,513]

theorem envBound27768 : H12AffineFastState.Bounded env27768 := by
  intro p hp
  have h : env27768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27767_27768 : H12AffineEnvironment.transform 20 79195 env27767 = env27768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 79195 env27767 == env27768) = true)

theorem identity27768 : scanCanonicalize (H12AffineFastState.compose env27768 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(21+1) ^^^ 7253) := by decide +kernel

theorem selectedBound27768 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env27769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10280,1024,8540,79195,7253,73754,73736,8192,64,13609,77835,16400,2421,75103,93262,256,20529,4160,513]

theorem envBound27769 : H12AffineFastState.Bounded env27769 := by
  intro p hp
  have h : env27769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27768_27769 : H12AffineEnvironment.transform 21 7253 env27768 = env27769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 7253 env27768 == env27769) = true)

theorem identity27769 : scanCanonicalize (H12AffineFastState.compose env27769 (packedSelected [11,23] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound27769 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env27770 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,16384,8541,65536,90139,10280,100,8540,78143,6193,73754,73736,8192,64,12621,77835,16400,2421,74043,92202,256,20529,4160,513]

theorem envBound27770 : H12AffineFastState.Bounded env27770 := by
  intro p hp
  have h : env27770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27769_27770 : H12AffineEnvironment.transform 9 100 env27769 = env27770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env27769 == env27770) = true)

theorem identity27770 : scanCanonicalize (H12AffineFastState.compose env27770 (packedSelected [0,2,3,6,7,8,10,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound27770 : packedSelected [0,2,3,6,7,8,10,14,20] rootPS < 2^1333 := by decide +kernel

def env27771 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,4112,8541,65536,77835,10280,100,8540,78143,6193,73754,73736,8192,64,12621,77835,4096,2421,74043,79930,256,33,4160,513]

theorem envBound27771 : H12AffineFastState.Bounded env27771 := by
  intro p hp
  have h : env27771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27770_27771 : H12AffineEnvironment.transform 13 4112 env27770 = env27771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env27770 == env27771) = true)

theorem identity27771 : scanCanonicalize (H12AffineFastState.compose env27771 (packedSelected [2,3,6,8,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27771 : packedSelected [2,3,6,8,10,14] rootPS < 2^1333 := by decide +kernel

def env27772 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,4112,8541,8202,4097,10280,100,8540,4405,6193,16,2,8192,64,12621,4097,4096,2421,305,6192,256,33,4160,513]

theorem envBound27772 : H12AffineFastState.Bounded env27772 := by
  intro p hp
  have h : env27772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27771_27772 : H12AffineEnvironment.transform 15 8202 env27771 = env27772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27771 == env27772) = true)

theorem identity27772 : scanCanonicalize (H12AffineFastState.compose env27772 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27772 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27773 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,8192,4112,8460,8202,4097,10280,53,8461,4405,6193,16,2,8192,17,12572,4097,4096,2340,305,6192,256,33,4113,513]

theorem envBound27773 : H12AffineFastState.Bounded env27773 := by
  intro p hp
  have h : env27773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27772_27773 : H12AffineEnvironment.transform 5 17 env27772 = env27773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27772 == env27773) = true)

theorem identity27773 : scanCanonicalize (H12AffineFastState.compose env27773 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 2083) := by decide +kernel

theorem selectedBound27773 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env27774 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,2083,4112,2351,2089,4097,11,53,2350,4405,6193,16,2,2083,17,6463,4097,4096,2340,305,6192,256,33,4113,513]

theorem envBound27774 : H12AffineFastState.Bounded env27774 := by
  intro p hp
  have h : env27774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27773_27774 : H12AffineEnvironment.transform 12 2083 env27773 = env27774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2083 env27773 == env27774) = true)

def env27775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,2097152,4194304,147456,147475,8193,64,4409703,2319690,2233681,2421,75102,6497626,256,2188650,2172186,513]

theorem envBound27775 : H12AffineFastState.Bounded env27775 := by
  intro p hp
  have h : env27775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27765_27775 : H12AffineEnvironment.transform 6 9 env27765 = env27775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27765 == env27775) = true)

theorem identity27775 : scanCanonicalize (H12AffineFastState.compose env27775 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound27775 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env27776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,25629,4194304,147456,147475,8193,64,4409703,196951,160076,2421,75102,4407623,256,65911,82183,513]

theorem envBound27776 : H12AffineFastState.Bounded env27776 := by
  intro p hp
  have h : env27776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27775_27776 : H12AffineEnvironment.transform 20 25629 env27775 = env27776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env27775 == env27776) = true)

theorem identity27776 : scanCanonicalize (H12AffineFastState.compose env27776 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound27776 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env27777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,25629,4194304,16,3,8193,64,4262263,82247,12636,2421,75102,4260183,256,65911,82183,513]

theorem envBound27777 : H12AffineFastState.Bounded env27777 := by
  intro p hp
  have h : env27777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27776_27777 : H12AffineEnvironment.transform 16 16400 env27776 = env27777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env27776 == env27777) = true)

theorem identity27777 : scanCanonicalize (H12AffineFastState.compose env27777 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound27777 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env27778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,25629,8572,16,3,8193,64,75787,82247,12636,2421,75102,73771,256,65911,82183,513]

theorem envBound27778 : H12AffineFastState.Bounded env27778 := by
  intro p hp
  have h : env27778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27777_27778 : H12AffineEnvironment.transform 21 8572 env27777 = env27778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env27777 == env27778) = true)

theorem identity27778 : scanCanonicalize (H12AffineFastState.compose env27778 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound27778 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env27779 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,343,16400,10281,1024,8540,25629,8572,16,3,8193,64,10588,16400,12636,2421,9225,8572,256,32,16464,513]

theorem envBound27779 : H12AffineFastState.Bounded env27779 := by
  intro p hp
  have h : env27779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27778_27779 : H12AffineEnvironment.transform 15 343 env27778 = env27779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env27778 == env27779) = true)

theorem identity27779 : scanCanonicalize (H12AffineFastState.compose env27779 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound27779 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env27780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,17,8541,343,1,10281,1024,8540,9228,8572,16,3,8193,64,10588,1,12636,2421,9225,8572,256,32,65,513]

theorem envBound27780 : H12AffineFastState.Bounded env27780 := by
  intro p hp
  have h : env27780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27779_27780 : H12AffineEnvironment.transform 13 17 env27779 = env27780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env27779 == env27780) = true)

theorem identity27780 : scanCanonicalize (H12AffineFastState.compose env27780 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27780 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,17,0,343,1,2420,1024,1,1361,33,16,3,348,64,2049,1,4097,2421,1364,33,256,32,65,513]

theorem envBound27781 : H12AffineFastState.Bounded env27781 := by
  intro p hp
  have h : env27781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27780_27781 : H12AffineEnvironment.transform 12 349 env27780 = env27781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27780 == env27781) = true)

theorem identity27781 : scanCanonicalize (H12AffineFastState.compose env27781 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2351) := by decide +kernel

theorem selectedBound27781 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2351,349,17,0,343,1,2420,1024,1,1361,33,16,3,348,64,2049,1,2350,2421,1364,33,256,32,65,513]

theorem envBound27782 : H12AffineFastState.Bounded env27782 := by
  intro p hp
  have h : env27782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27781_27782 : H12AffineEnvironment.transform 11 2351 env27781 = env27782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2351 env27781 == env27782) = true)

theorem identity27782 : scanCanonicalize (H12AffineFastState.compose env27782 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27782 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27783 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2351,268,17,0,262,1,2341,1024,1,1280,33,16,3,269,17,2049,1,2350,2340,1285,33,256,32,16,513]

theorem envBound27783 : H12AffineFastState.Bounded env27783 := by
  intro p hp
  have h : env27783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27782_27783 : H12AffineEnvironment.transform 5 17 env27782 = env27783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27782 == env27783) = true)

theorem identity27783 : scanCanonicalize (H12AffineFastState.compose env27783 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound27783 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27784 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2351,268,17,0,262,1,2341,53,1,309,33,16,3,269,17,2049,1,2350,2340,304,33,256,32,16,513]

theorem envBound27784 : H12AffineFastState.Bounded env27784 := by
  intro p hp
  have h : env27784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27783_27784 : H12AffineEnvironment.transform 9 53 env27783 = env27784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env27783 == env27784) = true)

theorem identity27784 : scanCanonicalize (H12AffineFastState.compose env27784 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound27784 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27785 : List Nat := [2,4,8,16,32,17,9,35,512,53,2048,2060,47,17,0,37,1,2054,53,1,22,33,16,3,46,17,2049,1,2061,2055,19,33,35,32,16,513]

theorem envBound27785 : H12AffineFastState.Bounded env27785 := by
  intro p hp
  have h : env27785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27784_27785 : H12AffineEnvironment.transform 7 35 env27784 = env27785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env27784 == env27785) = true)

theorem identity27785 : scanCanonicalize (H12AffineFastState.compose env27785 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound27785 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27786 : List Nat := [2,4,8,16,12,17,9,15,512,25,2048,2060,3,17,0,9,1,2054,25,1,22,13,16,3,2,17,2049,1,2061,2055,19,13,15,12,16,513]

theorem envBound27786 : H12AffineFastState.Bounded env27786 := by
  intro p hp
  have h : env27786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27785_27786 : H12AffineEnvironment.transform 4 12 env27785 = env27786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env27785 == env27786) = true)

theorem identity27786 : scanCanonicalize (H12AffineFastState.compose env27786 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound27786 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env27787 : List Nat := [2,4,8,12,12,13,9,15,512,5,2048,2060,3,13,0,9,1,2054,5,1,10,13,12,3,2,13,2049,1,2061,2055,15,13,15,12,12,513]

theorem envBound27787 : H12AffineFastState.Bounded env27787 := by
  intro p hp
  have h : env27787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27786_27787 : H12AffineEnvironment.transform 3 12 env27786 = env27787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env27786 == env27787) = true)

def env27788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147593,147475,8328,64,4450363,2344094,2233816,43049,99466,6497747,256,2212919,2172307,41820]

theorem envBound27788 : H12AffineFastState.Bounded env27788 := by
  intro p hp
  have h : env27788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27763_27788 : H12AffineEnvironment.transform 17 10401 env27763 = env27788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env27763 == env27788) = true)

theorem identity27788 : scanCanonicalize (H12AffineFastState.compose env27788 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57796) := by decide +kernel

theorem selectedBound27788 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env27789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,10401,1024,32769,2097152,4194304,41293,41431,8328,64,4262399,2172250,2159644,43049,99466,6407191,256,2212919,2172307,41820]

theorem envBound27789 : H12AffineFastState.Bounded env27789 := by
  intro p hp
  have h : env27789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27788_27789 : H12AffineEnvironment.transform 16 57796 env27788 = env27789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57796 env27788 == env27789) = true)

theorem identity27789 : scanCanonicalize (H12AffineFastState.compose env27789 (packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound27789 : packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env27790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,57796,10401,1024,32769,2097152,4194304,41293,41431,8328,64,4204925,2098648,2159644,43049,41992,6349973,256,2155701,2098449,41820]

theorem envBound27790 : H12AffineFastState.Bounded env27790 := by
  intro p hp
  have h : env27790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27789_27790 : H12AffineEnvironment.transform 15 8322 env27789 = env27790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env27789 == env27790) = true)

theorem identity27790 : scanCanonicalize (H12AffineFastState.compose env27790 (packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound27790 : packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env27791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,57796,10401,1024,32769,2097152,41341,41293,41431,8328,64,34816,2098648,2159644,43049,41992,2115048,256,2155701,2098449,41820]

theorem envBound27791 : H12AffineFastState.Bounded env27791 := by
  intro p hp
  have h : env27791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27790_27791 : H12AffineEnvironment.transform 21 41341 env27790 = env27791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env27790 == env27791) = true)

theorem identity27791 : scanCanonicalize (H12AffineFastState.compose env27791 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 50448) := by decide +kernel

theorem selectedBound27791 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env27792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,57796,10401,1024,32769,50448,41341,41293,41431,8328,64,34816,49352,12556,43049,41992,33016,256,8613,49153,41820]

theorem envBound27792 : H12AffineFastState.Bounded env27792 := by
  intro p hp
  have h : env27792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27791_27792 : H12AffineEnvironment.transform 20 50448 env27791 = env27792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env27791 == env27792) = true)

theorem identity27792 : scanCanonicalize (H12AffineFastState.compose env27792 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound27792 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,21,23] rootPS < 2^1333 := by decide +kernel

def env27793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29993,8322,5357,10401,1024,29992,12345,21588,21604,21758,8328,64,32041,13793,12556,23808,20769,30161,256,8613,13608,22133]

theorem envBound27793 : H12AffineFastState.Bounded env27793 := by
  intro p hp
  have h : env27793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27792_27793 : H12AffineEnvironment.transform 14 29993 env27792 = env27793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env27792 == env27793) = true)

theorem identity27793 : scanCanonicalize (H12AffineFastState.compose env27793 (packedSelected [1,4,8,9,10,11,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound27793 : packedSelected [1,4,8,9,10,11,16,18,20] rootPS < 2^1333 := by decide +kernel

def env27794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,21976,115,5357,2128,1024,21977,4296,21588,21604,21758,121,64,24024,5392,4605,23808,20769,21792,256,340,5593,22133]

theorem envBound27794 : H12AffineFastState.Bounded env27794 := by
  intro p hp
  have h : env27794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27793_27794 : H12AffineEnvironment.transform 12 241 env27793 = env27794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env27793 == env27794) = true)

theorem identity27794 : scanCanonicalize (H12AffineFastState.compose env27794 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound27794 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,5236,428,115,5357,2128,1024,429,4296,32,16,138,121,64,2476,5392,4605,2420,1365,340,256,340,5593,513]

theorem envBound27795 : H12AffineFastState.Bounded env27795 := by
  intro p hp
  have h : env27795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27794_27795 : H12AffineEnvironment.transform 13 5236 env27794 = env27795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env27794 == env27795) = true)

theorem identity27795 : scanCanonicalize (H12AffineFastState.compose env27795 (packedSelected [4,5,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound27795 : packedSelected [4,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env27796 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,40,5236,373,115,5172,2128,1024,372,4113,32,16,83,121,64,2421,5392,4388,2420,1365,340,256,340,5376,513]

theorem envBound27796 : H12AffineFastState.Bounded env27796 := by
  intro p hp
  have h : env27796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27795_27796 : H12AffineEnvironment.transform 6 89 env27795 = env27796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env27795 == env27796) = true)

theorem identity27796 : scanCanonicalize (H12AffineFastState.compose env27796 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound27796 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27797 : List Nat := [2,4,8,16,32,64,89,117,512,1024,2048,4096,40,5236,0,115,5172,2128,1024,1,4113,32,16,83,121,64,2048,5221,4177,2049,1056,33,117,33,5237,513]

theorem envBound27797 : H12AffineFastState.Bounded env27797 := by
  intro p hp
  have h : env27797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27796_27797 : H12AffineEnvironment.transform 7 117 env27796 = env27797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env27796 == env27797) = true)

theorem identity27797 : scanCanonicalize (H12AffineFastState.compose env27797 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound27797 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env27798 : List Nat := [2,4,8,16,32,64,89,117,512,1024,1,4096,40,5236,0,115,5172,81,1024,1,4113,32,16,83,121,64,1,5221,4177,0,1056,33,117,33,5237,513]

theorem envBound27798 : H12AffineFastState.Bounded env27798 := by
  intro p hp
  have h : env27798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27797_27798 : H12AffineEnvironment.transform 10 1 env27797 = env27798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env27797 == env27798) = true)

theorem identity27798 : scanCanonicalize (H12AffineFastState.compose env27798 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound27798 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env27799 : List Nat := [2,4,8,16,32,64,89,117,512,1024,1,64,40,1076,0,115,1140,81,1024,1,81,32,16,83,121,64,1,1061,17,0,1056,33,117,33,1077,513]

theorem envBound27799 : H12AffineFastState.Bounded env27799 := by
  intro p hp
  have h : env27799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27798_27799 : H12AffineEnvironment.transform 11 64 env27798 = env27799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env27798 == env27799) = true)

theorem identity27799 : scanCanonicalize (H12AffineFastState.compose env27799 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound27799 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env27800 : List Nat := [2,4,8,16,32,64,89,117,512,101,1,64,40,81,0,115,17,81,101,1,81,32,16,83,121,64,1,64,17,0,69,33,117,33,80,513]

theorem envBound27800 : H12AffineFastState.Bounded env27800 := by
  intro p hp
  have h : env27800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27799_27800 : H12AffineEnvironment.transform 9 101 env27799 = env27800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env27799 == env27800) = true)

theorem identity27800 : scanCanonicalize (H12AffineFastState.compose env27800 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound27800 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env27801 : List Nat := [2,4,8,16,32,64,89,117,49,101,1,64,40,81,0,115,17,81,101,1,81,32,16,83,121,64,1,64,17,0,69,33,117,33,80,48]

theorem envBound27801 : H12AffineFastState.Bounded env27801 := by
  intro p hp
  have h : env27801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27800_27801 : H12AffineEnvironment.transform 8 49 env27800 = env27801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env27800 == env27801) = true)

theorem identity27801 : scanCanonicalize (H12AffineFastState.compose env27801 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27801 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env27802 : List Nat := [2,4,8,16,32,16,9,37,49,53,1,16,40,1,0,35,17,1,53,1,1,32,16,3,41,16,1,16,17,0,21,33,37,33,0,48]

theorem envBound27802 : H12AffineFastState.Bounded env27802 := by
  intro p hp
  have h : env27802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27801_27802 : H12AffineEnvironment.transform 5 16 env27801 = env27802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27801 == env27802) = true)

theorem identity27802 : scanCanonicalize (H12AffineFastState.compose env27802 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound27802 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27803 : List Nat := [2,4,8,16,16,16,9,21,1,5,1,16,24,1,0,19,17,1,5,1,1,16,16,3,25,16,1,16,17,0,21,17,21,17,0,0]

theorem envBound27803 : H12AffineFastState.Bounded env27803 := by
  intro p hp
  have h : env27803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27802_27803 : H12AffineEnvironment.transform 4 16 env27802 = env27803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env27802 == env27803) = true)

theorem identity27803 : scanCanonicalize (H12AffineFastState.compose env27803 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27803 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27804 : List Nat := [2,4,2,16,16,16,3,21,1,5,1,16,18,1,0,19,17,1,5,1,1,16,16,3,19,16,1,16,17,0,21,17,21,17,0,0]

theorem envBound27804 : H12AffineFastState.Bounded env27804 := by
  intro p hp
  have h : env27804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27803_27804 : H12AffineEnvironment.transform 2 2 env27803 = env27804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27803 == env27804) = true)

theorem identity27804 : scanCanonicalize (H12AffineFastState.compose env27804 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27804 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27805 : List Nat := [2,4,2,0,0,0,3,5,1,5,1,0,2,1,0,3,1,1,5,1,1,0,0,3,3,0,1,0,1,0,5,1,5,1,0,0]

theorem envBound27805 : H12AffineFastState.Bounded env27805 := by
  intro p hp
  have h : env27805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27804_27805 : H12AffineEnvironment.transform 3 0 env27804 = env27805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27804 == env27805) = true)

def env27806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound27806 : H12AffineFastState.Bounded env27806 := by
  intro p hp
  have h : env27806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27691_27806 : H12AffineEnvironment.transform 18 1025 env27691 = env27806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env27691 == env27806) = true)

theorem identity27806 : scanCanonicalize (H12AffineFastState.compose env27806 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound27806 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env27807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29630491,18973836,10507601,8724506,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound27807 : H12AffineFastState.Bounded env27807 := by
  intro p hp
  have h : env27807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27806_27807 : H12AffineEnvironment.transform 16 122906 env27806 = env27807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env27806 == env27807) = true)

def env27808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6664599,8393984,10507601,8724506,2102684,12645452,257,21792,46213,2175563]

theorem envBound27808 : H12AffineFastState.Bounded env27808 := by
  intro p hp
  have h : env27808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27807_27808 : H12AffineEnvironment.transform 23 10588556 env27807 = env27808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env27807 == env27808) = true)

def env27809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6664599,2098512,17665,2437194,2102684,6349852,257,21792,46213,2175563]

theorem envBound27809 : H12AffineFastState.Bounded env27809 := by
  intro p hp
  have h : env27809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27808_27809 : H12AffineEnvironment.transform 22 2101328 env27808 = env27809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env27808 == env27809) = true)

def env27810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2201879,2098512,17665,2437194,2102684,2411676,257,21792,46213,2175563]

theorem envBound27810 : H12AffineFastState.Bounded env27810 := by
  intro p hp
  have h : env27810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27809_27810 : H12AffineEnvironment.transform 21 272512 env27809 = env27810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27809 == env27810) = true)

theorem identity27810 : scanCanonicalize (H12AffineFastState.compose env27810 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound27810 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,115871,272512,120015,98780,8328,64,23944,115151,17665,324821,119043,329731,257,21792,46213,63188]

theorem envBound27811 : H12AffineFastState.Bounded env27811 := by
  intro p hp
  have h : env27811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27810_27811 : H12AffineEnvironment.transform 20 115871 env27810 = env27811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env27810 == env27811) = true)

def env27812 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,115871,272512,119967,98700,8328,16,23944,115103,17665,324741,119043,329731,257,21792,46213,63108]

theorem envBound27812 : H12AffineFastState.Bounded env27812 := by
  intro p hp
  have h : env27812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27811_27812 : H12AffineEnvironment.transform 5 16 env27811 = env27812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27811 == env27812) = true)

theorem identity27812 : scanCanonicalize (H12AffineFastState.compose env27812 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 122147) := by decide +kernel

theorem selectedBound27812 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env27813 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,122147,1025,32769,115871,128419,119967,98700,8328,16,23944,115103,17665,76198,119043,54560,257,21792,46213,63108]

theorem envBound27813 : H12AffineFastState.Bounded env27813 := by
  intro p hp
  have h : env27813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27812_27813 : H12AffineEnvironment.transform 17 122147 env27812 = env27813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122147 env27812 == env27813) = true)

theorem identity27813 : scanCanonicalize (H12AffineFastState.compose env27813 (packedSelected [0,3,5,8,9,10,11,16,17,20,22,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound27813 : packedSelected [0,3,5,8,9,10,11,16,17,20,22,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env27814 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,62730,5392,10281,1025,32769,12693,169,8597,29830,8328,16,23944,13461,17665,56492,9225,54560,257,21792,46213,63108]

theorem envBound27814 : H12AffineFastState.Bounded env27814 := by
  intro p hp
  have h : env27814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27813_27814 : H12AffineEnvironment.transform 15 62730 env27813 = env27814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env27813 == env27814) = true)

theorem identity27814 : scanCanonicalize (H12AffineFastState.compose env27814 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound27814 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env27815 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,32768,54414,5392,2477,1025,32769,4113,169,17,21762,268,16,23944,5393,17665,56492,1421,54560,257,21792,38145,55040]

theorem envBound27815 : H12AffineFastState.Bounded env27815 := by
  intro p hp
  have h : env27815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27814_27815 : H12AffineEnvironment.transform 12 388 env27814 = env27815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env27814 == env27815) = true)

theorem identity27815 : scanCanonicalize (H12AffineFastState.compose env27815 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound27815 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27816 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,1,21647,5392,2477,1025,0,4113,169,17,21762,268,16,23944,5393,17665,23725,1421,21793,257,21792,5376,22273]

theorem envBound27816 : H12AffineFastState.Bounded env27816 := by
  intro p hp
  have h : env27816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27815_27816 : H12AffineEnvironment.transform 14 1 env27815 = env27816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env27815 == env27816) = true)

theorem identity27816 : scanCanonicalize (H12AffineFastState.compose env27816 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound27816 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27817 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5512,1,263,5392,2477,1025,0,4113,169,17,138,268,16,2048,5393,4233,2341,1421,169,257,168,5376,649]

theorem envBound27817 : H12AffineFastState.Bounded env27817 := by
  intro p hp
  have h : env27817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27816_27817 : H12AffineEnvironment.transform 13 5512 env27816 = env27817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env27816 == env27817) = true)

theorem identity27817 : scanCanonicalize (H12AffineFastState.compose env27817 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound27817 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env27818 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,4096,388,4113,1,263,4233,2477,408,0,4113,169,17,138,268,16,2048,4232,4233,2341,20,169,257,168,4249,649]

theorem envBound27818 : H12AffineFastState.Bounded env27818 := by
  intro p hp
  have h : env27818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27817_27818 : H12AffineEnvironment.transform 9 409 env27817 = env27818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env27817 == env27818) = true)

theorem identity27818 : scanCanonicalize (H12AffineFastState.compose env27818 (packedSelected [0,2,7,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27818 : packedSelected [0,2,7,12] rootPS < 2^1333 := by decide +kernel

def env27819 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,4113,1,263,4096,2340,273,0,4113,32,17,3,268,16,2048,4097,4096,2341,20,32,257,33,4112,512]

theorem envBound27819 : H12AffineFastState.Bounded env27819 := by
  intro p hp
  have h : env27819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27818_27819 : H12AffineEnvironment.transform 6 9 env27818 = env27819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27818 == env27819) = true)

theorem identity27819 : scanCanonicalize (H12AffineFastState.compose env27819 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27819 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27820 : List Nat := [2,4,8,0,32,0,9,256,512,256,2048,4096,269,4097,1,263,4096,2340,257,0,4097,32,1,3,268,0,2048,4097,4096,2341,4,32,257,33,4096,512]

theorem envBound27820 : H12AffineFastState.Bounded env27820 := by
  intro p hp
  have h : env27820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27819_27820 : H12AffineEnvironment.transform 3 0 env27819 = env27820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27819 == env27820) = true)

theorem identity27820 : scanCanonicalize (H12AffineFastState.compose env27820 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound27820 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27821 : List Nat := [2,4,8,0,32,0,9,256,12,256,2048,4096,269,4097,1,263,4096,2340,257,0,4097,32,1,3,268,0,2048,4097,4096,2341,4,32,257,33,4096,12]

theorem envBound27821 : H12AffineFastState.Bounded env27821 := by
  intro p hp
  have h : env27821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27820_27821 : H12AffineEnvironment.transform 8 12 env27820 = env27821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env27820 == env27821) = true)

theorem identity27821 : scanCanonicalize (H12AffineFastState.compose env27821 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound27821 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27822 : List Nat := [2,4,8,0,32,0,9,256,12,256,2048,2090,269,2091,1,263,2090,2340,257,0,2091,32,1,3,268,0,2048,2091,2090,2341,4,32,257,33,2090,12]

theorem envBound27822 : H12AffineFastState.Bounded env27822 := by
  intro p hp
  have h : env27822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27821_27822 : H12AffineEnvironment.transform 11 2090 env27821 = env27822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env27821 == env27822) = true)

theorem identity27822 : scanCanonicalize (H12AffineFastState.compose env27822 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound27822 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27823 : List Nat := [2,4,8,0,32,0,9,41,12,41,2048,2090,36,2091,1,46,2090,2061,40,0,2091,32,1,3,37,0,2048,2091,2090,2060,4,32,40,33,2090,12]

theorem envBound27823 : H12AffineFastState.Bounded env27823 := by
  intro p hp
  have h : env27823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27822_27823 : H12AffineEnvironment.transform 7 41 env27822 = env27823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env27822 == env27823) = true)

theorem identity27823 : scanCanonicalize (H12AffineFastState.compose env27823 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 44) := by decide +kernel

theorem selectedBound27823 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27824 : List Nat := [2,4,8,0,32,0,9,41,12,41,44,6,36,7,1,46,6,33,40,0,7,32,1,3,37,0,44,7,6,32,4,32,40,33,6,12]

theorem envBound27824 : H12AffineFastState.Bounded env27824 := by
  intro p hp
  have h : env27824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27823_27824 : H12AffineEnvironment.transform 10 44 env27823 = env27824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 44 env27823 == env27824) = true)

theorem identity27824 : scanCanonicalize (H12AffineFastState.compose env27824 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27824 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27825 : List Nat := [2,4,8,0,0,0,9,9,12,9,12,6,4,7,1,14,6,1,8,0,7,0,1,3,5,0,12,7,6,0,4,0,8,1,6,12]

theorem envBound27825 : H12AffineFastState.Bounded env27825 := by
  intro p hp
  have h : env27825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27824_27825 : H12AffineEnvironment.transform 4 0 env27824 = env27825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27824 == env27825) = true)

theorem identity27825 : scanCanonicalize (H12AffineFastState.compose env27825 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound27825 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27826 : List Nat := [2,4,7,0,0,0,6,6,3,6,3,6,4,7,1,1,6,1,7,0,7,0,1,3,5,0,3,7,6,0,4,0,7,1,6,3]

theorem envBound27826 : H12AffineFastState.Bounded env27826 := by
  intro p hp
  have h : env27826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27825_27826 : H12AffineEnvironment.transform 2 7 env27825 = env27826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env27825 == env27826) = true)

theorem identity27826 : scanCanonicalize (H12AffineFastState.compose env27826 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27826 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env27827 : List Nat := [2,2,1,0,0,0,0,0,3,0,3,0,2,1,1,1,0,1,1,0,1,0,1,3,3,0,3,1,0,0,2,0,1,1,0,3]

theorem envBound27827 : H12AffineFastState.Bounded env27827 := by
  intro p hp
  have h : env27827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27826_27827 : H12AffineEnvironment.transform 1 2 env27826 = env27827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27826 == env27827) = true)

theorem identity27827 : scanCanonicalize (H12AffineFastState.compose env27827 (packedSelected [14] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound27827 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env27828 : List Nat := [0,0,1,0,0,0,0,0,1,0,1,0,0,1,1,1,0,1,1,0,1,0,1,1,1,0,1,1,0,0,0,0,1,1,0,1]

theorem envBound27828 : H12AffineFastState.Bounded env27828 := by
  intro p hp
  have h : env27828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27827_27828 : H12AffineEnvironment.transform 0 0 env27827 = env27828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env27827 == env27828) = true)

def env27829 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,115871,272512,119966,98701,8328,17,23944,115102,17665,324740,119043,329731,257,21792,46213,63109]

theorem envBound27829 : H12AffineFastState.Bounded env27829 := by
  intro p hp
  have h : env27829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27811_27829 : H12AffineEnvironment.transform 5 17 env27811 = env27829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27811 == env27829) = true)

theorem identity27829 : scanCanonicalize (H12AffineFastState.compose env27829 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound27829 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env27830 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,64809,1025,32769,115871,54697,119966,98701,8328,17,23944,115102,17665,2477,119043,128298,257,21792,46213,63109]

theorem envBound27830 : H12AffineFastState.Bounded env27830 := by
  intro p hp
  have h : env27830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27829_27830 : H12AffineEnvironment.transform 17 64809 env27829 = env27830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env27829 == env27830) = true)

theorem identity27830 : scanCanonicalize (H12AffineFastState.compose env27830 (packedSelected [0,1,9,16,18,20,22,23,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound27830 : packedSelected [0,1,9,16,18,20,22,23,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env27831 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,40971,16401,64809,1025,32769,25748,54697,29845,8582,8328,17,23944,24981,17665,2477,28936,21793,257,21792,46213,63109]

theorem envBound27831 : H12AffineFastState.Bounded env27831 := by
  intro p hp
  have h : env27831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27830_27831 : H12AffineEnvironment.transform 15 40971 env27830 = env27831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env27830 == env27831) = true)

theorem identity27831 : scanCanonicalize (H12AffineFastState.compose env27831 (packedSelected [19,26] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27831 : packedSelected [19,26] rootPS < 2^1333 := by decide +kernel

def env27832 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,32768,33031,16401,56357,1025,32769,17816,54697,21913,138,388,17,23944,16537,17665,2477,20484,21793,257,21792,38281,55177]

theorem envBound27832 : H12AffineFastState.Bounded env27832 := by
  intro p hp
  have h : env27832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27831_27832 : H12AffineEnvironment.transform 12 268 env27831 = env27832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27831 == env27832) = true)

theorem identity27832 : scanCanonicalize (H12AffineFastState.compose env27832 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27832 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env27833 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,33031,16401,56357,1025,32769,17681,54560,21776,3,269,17,23809,16400,17665,2340,20484,21793,257,21792,38144,55040]

theorem envBound27833 : H12AffineFastState.Bounded env27833 := by
  intro p hp
  have h : env27833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27832_27833 : H12AffineEnvironment.transform 6 9 env27832 = env27833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27832 == env27833) = true)

theorem identity27833 : scanCanonicalize (H12AffineFastState.compose env27833 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound27833 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27834 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21540,21795,16401,2049,1025,21541,17681,260,21776,3,269,17,23809,16400,17665,2340,20484,21793,257,21792,16676,804]

theorem envBound27834 : H12AffineFastState.Bounded env27834 := by
  intro p hp
  have h : env27834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27833_27834 : H12AffineEnvironment.transform 14 21540 env27833 = env27834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env27833 == env27834) = true)

theorem identity27834 : scanCanonicalize (H12AffineFastState.compose env27834 (packedSelected [1,3,4,5,8,9,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27834 : packedSelected [1,3,4,5,8,9,17] rootPS < 2^1333 := by decide +kernel

def env27835 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,292,35,5393,2049,1025,293,4113,260,16,3,269,17,2049,5392,4097,2340,1284,33,257,32,5156,804]

theorem envBound27835 : H12AffineFastState.Bounded env27835 := by
  intro p hp
  have h : env27835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27834_27835 : H12AffineEnvironment.transform 13 5376 env27834 = env27835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27834 == env27835) = true)

theorem identity27835 : scanCanonicalize (H12AffineFastState.compose env27835 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound27835 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env27836 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,1,35,5172,2049,1025,0,4113,33,16,3,40,17,2049,5173,4097,2049,1057,33,36,32,5156,513]

theorem envBound27836 : H12AffineFastState.Bounded env27836 := by
  intro p hp
  have h : env27836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27835_27836 : H12AffineEnvironment.transform 7 37 env27835 = env27836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env27835 == env27836) = true)

theorem identity27836 : scanCanonicalize (H12AffineFastState.compose env27836 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound27836 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27837 : List Nat := [2,4,8,16,32,17,9,37,512,4,2048,4096,41,4129,1,35,4144,2049,5,0,4113,33,16,3,40,17,2049,4145,4097,2049,37,33,36,32,4128,513]

theorem envBound27837 : H12AffineFastState.Bounded env27837 := by
  intro p hp
  have h : env27837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27836_27837 : H12AffineEnvironment.transform 9 4 env27836 = env27837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env27836 == env27837) = true)

theorem identity27837 : scanCanonicalize (H12AffineFastState.compose env27837 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound27837 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27838 : List Nat := [2,4,8,16,32,17,9,37,512,4,2048,528,41,561,1,35,544,2049,5,0,513,33,16,3,40,17,2049,545,529,2049,37,33,36,32,560,513]

theorem envBound27838 : H12AffineFastState.Bounded env27838 := by
  intro p hp
  have h : env27838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27837_27838 : H12AffineEnvironment.transform 11 528 env27837 = env27838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env27837 == env27838) = true)

theorem identity27838 : scanCanonicalize (H12AffineFastState.compose env27838 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27838 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27839 : List Nat := [2,4,8,16,1,17,9,4,512,4,2048,528,8,528,1,2,513,2049,5,0,513,0,16,3,9,17,2049,512,529,2049,4,0,5,1,529,513]

theorem envBound27839 : H12AffineFastState.Bounded env27839 := by
  intro p hp
  have h : env27839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27838_27839 : H12AffineEnvironment.transform 4 1 env27838 = env27839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27838 == env27839) = true)

theorem identity27839 : scanCanonicalize (H12AffineFastState.compose env27839 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound27839 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27840 : List Nat := [2,4,8,16,1,17,9,4,512,4,513,528,8,528,1,2,513,512,5,0,513,0,16,3,9,17,512,512,529,512,4,0,5,1,529,513]

theorem envBound27840 : H12AffineFastState.Bounded env27840 := by
  intro p hp
  have h : env27840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27839_27840 : H12AffineEnvironment.transform 10 513 env27839 = env27840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env27839 == env27840) = true)

theorem identity27840 : scanCanonicalize (H12AffineFastState.compose env27840 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27840 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env27841 : List Nat := [2,4,8,1,1,0,9,4,512,4,513,513,8,513,1,2,513,512,5,0,513,0,1,3,9,0,512,512,512,512,4,0,5,1,512,513]

theorem envBound27841 : H12AffineFastState.Bounded env27841 := by
  intro p hp
  have h : env27841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27840_27841 : H12AffineEnvironment.transform 3 1 env27840 = env27841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27840 == env27841) = true)

theorem identity27841 : scanCanonicalize (H12AffineFastState.compose env27841 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27841 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27842 : List Nat := [2,4,8,1,1,0,9,4,1,4,0,0,8,0,1,2,0,1,5,0,0,0,1,3,9,0,1,1,1,1,4,0,5,1,1,0]

theorem envBound27842 : H12AffineFastState.Bounded env27842 := by
  intro p hp
  have h : env27842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27841_27842 : H12AffineEnvironment.transform 8 1 env27841 = env27842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27841 == env27842) = true)

theorem identity27842 : scanCanonicalize (H12AffineFastState.compose env27842 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27842 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27843 : List Nat := [2,4,2,1,1,0,3,4,1,4,0,0,2,0,1,2,0,1,5,0,0,0,1,3,3,0,1,1,1,1,4,0,5,1,1,0]

theorem envBound27843 : H12AffineFastState.Bounded env27843 := by
  intro p hp
  have h : env27843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27842_27843 : H12AffineEnvironment.transform 2 2 env27842 = env27843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27842 == env27843) = true)

def env27844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2201878,2098512,17665,2437194,2102684,2411677,257,21792,46213,2175563]

theorem envBound27844 : H12AffineFastState.Bounded env27844 := by
  intro p hp
  have h : env27844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27809_27844 : H12AffineEnvironment.transform 21 272513 env27809 = env27844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27809 == env27844) = true)

theorem identity27844 : scanCanonicalize (H12AffineFastState.compose env27844 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound27844 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,13508,262144,1025,32769,2097152,272513,2101328,21762,8328,64,2117064,2098512,17665,2417812,2102684,2411677,257,21792,46213,2156181]

theorem envBound27845 : H12AffineFastState.Bounded env27845 := by
  intro p hp
  have h : env27845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27844_27845 : H12AffineEnvironment.transform 15 54494 env27844 = env27845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env27844 == env27845) = true)

def env27846 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13388,262144,1025,32769,2097152,272393,2101328,21762,8192,64,2116928,2098512,17665,2417692,2102548,2411541,257,21792,46093,2156061]

theorem envBound27846 : H12AffineFastState.Bounded env27846 := by
  intro p hp
  have h : env27846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27845_27846 : H12AffineEnvironment.transform 6 8 env27845 = env27846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27845 == env27846) = true)

theorem identity27846 : scanCanonicalize (H12AffineFastState.compose env27846 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 314421) := by decide +kernel

theorem selectedBound27846 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env27847 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13388,262144,1025,32769,314421,272393,318565,21762,8192,64,295285,313701,17665,10281,317729,32,257,21792,46093,272936]

theorem envBound27847 : H12AffineFastState.Bounded env27847 := by
  intro p hp
  have h : env27847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27846_27847 : H12AffineEnvironment.transform 20 314421 env27846 = env27847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 314421 env27846 == env27847) = true)

theorem identity27847 : scanCanonicalize (H12AffineFastState.compose env27847 (packedSelected [2,3,4,6,9,11,15,16,18,19,20,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound27847 : packedSelected [2,3,4,6,9,11,15,16,18,19,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env27848 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13388,56357,1025,32769,4112,62508,64,21762,8192,64,23888,5440,17665,10281,1284,32,257,21792,46093,62989]

theorem envBound27848 : H12AffineFastState.Bounded env27848 := by
  intro p hp
  have h : env27848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27847_27848 : H12AffineEnvironment.transform 17 56357 env27847 = env27848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env27847 == env27848) = true)

theorem identity27848 : scanCanonicalize (H12AffineFastState.compose env27848 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound27848 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env27849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,30042,13388,32041,1025,8461,4112,21792,64,21762,8192,64,23888,5440,17665,10281,1284,32,257,21792,5377,22273]

theorem envBound27849 : H12AffineFastState.Bounded env27849 := by
  intro p hp
  have h : env27849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27848_27849 : H12AffineEnvironment.transform 14 8460 env27848 = env27849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env27848 == env27849) = true)

theorem identity27849 : scanCanonicalize (H12AffineFastState.compose env27849 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound27849 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env27850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8460,8202,13388,10361,1025,8461,4112,112,64,82,8192,64,2048,5440,4177,10281,1284,32,257,112,5377,593]

theorem envBound27850 : H12AffineFastState.Bounded env27850 := by
  intro p hp
  have h : env27850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27849_27850 : H12AffineEnvironment.transform 13 5456 env27849 = env27850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env27849 == env27850) = true)

theorem identity27850 : scanCanonicalize (H12AffineFastState.compose env27850 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound27850 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env27851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2357,8192,3173,8460,8202,11641,10361,1025,8461,2341,112,64,82,8192,64,2048,3189,2404,10281,1284,32,257,112,3124,593]

theorem envBound27851 : H12AffineFastState.Bounded env27851 := by
  intro p hp
  have h : env27851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27850_27851 : H12AffineEnvironment.transform 11 2357 env27850 = env27851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env27850 == env27851) = true)

theorem identity27851 : scanCanonicalize (H12AffineFastState.compose env27851 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27851 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env27852 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2357,8192,3125,8460,8202,11561,10281,1025,8461,2341,32,16,2,8192,16,2048,3109,2356,10281,1284,32,257,32,3124,513]

theorem envBound27852 : H12AffineFastState.Bounded env27852 := by
  intro p hp
  have h : env27852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27851_27852 : H12AffineEnvironment.transform 5 16 env27851 = env27852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27851 == env27852) = true)

theorem identity27852 : scanCanonicalize (H12AffineFastState.compose env27852 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27852 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27853 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2357,268,3125,0,262,3109,2341,1025,1,2341,32,16,2,268,16,2048,3109,2356,2341,1284,32,257,32,3124,513]

theorem envBound27853 : H12AffineFastState.Bounded env27853 := by
  intro p hp
  have h : env27853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27852_27853 : H12AffineEnvironment.transform 12 268 env27852 = env27853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27852 == env27853) = true)

theorem identity27853 : scanCanonicalize (H12AffineFastState.compose env27853 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound27853 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27854 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,1280,268,0,0,262,16,1296,1025,1,1296,32,16,2,268,16,1077,16,1281,1296,1284,32,257,32,1,513]

theorem envBound27854 : H12AffineFastState.Bounded env27854 := by
  intro p hp
  have h : env27854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27853_27854 : H12AffineEnvironment.transform 10 1077 env27853 = env27854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env27853 == env27854) = true)

theorem identity27854 : scanCanonicalize (H12AffineFastState.compose env27854 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound27854 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27855 : List Nat := [2,4,8,16,32,16,8,256,10,1024,1077,1280,268,0,0,262,16,1296,1025,1,1296,32,16,2,268,16,1077,16,1281,1296,1284,32,257,32,1,11]

theorem envBound27855 : H12AffineFastState.Bounded env27855 := by
  intro p hp
  have h : env27855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27854_27855 : H12AffineEnvironment.transform 8 10 env27854 = env27855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env27854 == env27855) = true)

theorem identity27855 : scanCanonicalize (H12AffineFastState.compose env27855 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27855 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27856 : List Nat := [2,4,8,16,0,16,8,256,10,1024,1045,1280,268,0,0,262,16,1296,1025,1,1296,0,16,2,268,16,1045,16,1281,1296,1284,0,257,0,1,11]

theorem envBound27856 : H12AffineFastState.Bounded env27856 := by
  intro p hp
  have h : env27856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27855_27856 : H12AffineEnvironment.transform 4 0 env27855 = env27856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27855 == env27856) = true)

def env27857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13389,262144,1025,32769,2097152,272392,2101328,21762,8193,64,2116929,2098512,17665,2417693,2102549,2411540,257,21792,46092,2156060]

theorem envBound27857 : H12AffineFastState.Bounded env27857 := by
  intro p hp
  have h : env27857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27845_27857 : H12AffineEnvironment.transform 6 9 env27845 = env27857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27845 == env27857) = true)

theorem identity27857 : scanCanonicalize (H12AffineFastState.compose env27857 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound27857 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env27858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13389,23669,1025,32769,2097152,29821,2101328,21762,8193,64,2116929,2098512,17665,2144360,2102549,2134113,257,21792,46092,2156060]

theorem envBound27858 : H12AffineFastState.Bounded env27858 := by
  intro p hp
  have h : env27858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27857_27858 : H12AffineEnvironment.transform 17 23669 env27857 = env27858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env27857 == env27858) = true)

theorem identity27858 : scanCanonicalize (H12AffineFastState.compose env27858 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 17729) := by decide +kernel

theorem selectedBound27858 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env27859 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13389,23669,1025,32769,17729,29821,21777,21762,8193,64,2048,16401,17665,64809,20564,54560,257,21792,46092,41821]

theorem envBound27859 : H12AffineFastState.Bounded env27859 := by
  intro p hp
  have h : env27859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27858_27859 : H12AffineEnvironment.transform 20 17729 env27858 = env27859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env27858 == env27859) = true)

theorem identity27859 : scanCanonicalize (H12AffineFastState.compose env27859 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound27859 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env27860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,21590,13389,23669,1025,0,17729,29821,21777,21762,8193,64,2048,16401,17665,32040,20564,21793,257,21792,13325,9052]

theorem envBound27860 : H12AffineFastState.Bounded env27860 := by
  intro p hp
  have h : env27860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27859_27860 : H12AffineEnvironment.transform 14 1 env27859 = env27860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env27859 == env27860) = true)

theorem identity27860 : scanCanonicalize (H12AffineFastState.compose env27860 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound27860 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env27861 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,343,13389,2420,1025,0,4160,8572,16,3,8193,64,2048,5392,4096,10281,1365,32,257,33,13325,9052]

theorem envBound27861 : H12AffineFastState.Bounded env27861 := by
  intro p hp
  have h : env27861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27860_27861 : H12AffineEnvironment.transform 13 5377 env27860 = env27861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env27860 == env27861) = true)

theorem identity27861 : scanCanonicalize (H12AffineFastState.compose env27861 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7465) := by decide +kernel

theorem selectedBound27861 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env27862 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7465,5377,1,343,2404,2420,1025,0,4160,7253,16,3,7464,64,2048,5392,4096,5376,1365,32,257,33,2340,7797]

theorem envBound27862 : H12AffineFastState.Bounded env27862 := by
  intro p hp
  have h : env27862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27861_27862 : H12AffineEnvironment.transform 12 7465 env27861 = env27862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7465 env27861 == env27862) = true)

theorem identity27862 : scanCanonicalize (H12AffineFastState.compose env27862 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound27862 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env27863 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1280,2089,1,1,343,2404,2420,1025,0,1344,2389,16,3,2088,64,2048,16,1280,0,1365,32,257,33,2340,2933]

theorem envBound27863 : H12AffineFastState.Bounded env27863 := by
  intro p hp
  have h : env27863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27862_27863 : H12AffineEnvironment.transform 11 1280 env27862 = env27863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env27862 == env27863) = true)

theorem identity27863 : scanCanonicalize (H12AffineFastState.compose env27863 (packedSelected [2,3,4,5,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound27863 : packedSelected [2,3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env27864 : List Nat := [2,4,8,16,32,64,9,100,512,1024,2048,1124,2089,1,1,51,2048,2064,1025,0,1060,2097,16,3,2088,64,2048,16,1124,0,1073,32,101,33,2112,2577]

theorem envBound27864 : H12AffineFastState.Bounded env27864 := by
  intro p hp
  have h : env27864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27863_27864 : H12AffineEnvironment.transform 7 100 env27863 = env27864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env27863 == env27864) = true)

theorem identity27864 : scanCanonicalize (H12AffineFastState.compose env27864 (packedSelected [0,1,2,7,8,14] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound27864 : packedSelected [0,1,2,7,8,14] rootPS < 2^1333 := by decide +kernel

def env27865 : List Nat := [2,4,8,16,32,64,9,100,512,1024,1077,1124,1052,1,1,51,1077,1061,1025,0,1060,1028,16,3,1053,64,1077,16,1124,0,1073,32,101,33,1141,1572]

theorem envBound27865 : H12AffineFastState.Bounded env27865 := by
  intro p hp
  have h : env27865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27864_27865 : H12AffineEnvironment.transform 10 1077 env27864 = env27865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env27864 == env27865) = true)

theorem identity27865 : scanCanonicalize (H12AffineFastState.compose env27865 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound27865 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27866 : List Nat := [2,4,8,16,32,64,9,100,512,37,16,65,57,1,1,51,16,0,36,0,1,33,16,3,56,64,16,16,65,0,20,32,101,33,80,513]

theorem envBound27866 : H12AffineFastState.Bounded env27866 := by
  intro p hp
  have h : env27866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27865_27866 : H12AffineEnvironment.transform 9 37 env27865 = env27866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env27865 == env27866) = true)

theorem identity27866 : scanCanonicalize (H12AffineFastState.compose env27866 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27866 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27867 : List Nat := [2,4,8,16,32,64,9,100,0,37,16,65,57,1,1,51,16,0,36,0,1,33,16,3,56,64,16,16,65,0,20,32,101,33,80,1]

theorem envBound27867 : H12AffineFastState.Bounded env27867 := by
  intro p hp
  have h : env27867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27866_27867 : H12AffineEnvironment.transform 8 0 env27866 = env27867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27866 == env27867) = true)

theorem identity27867 : scanCanonicalize (H12AffineFastState.compose env27867 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27867 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27868 : List Nat := [2,4,8,0,32,64,9,100,0,37,0,65,41,1,1,35,0,0,36,0,1,33,0,3,40,64,0,0,65,0,4,32,101,33,64,1]

theorem envBound27868 : H12AffineFastState.Bounded env27868 := by
  intro p hp
  have h : env27868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27867_27868 : H12AffineEnvironment.transform 3 0 env27867 = env27868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27867 == env27868) = true)

theorem identity27868 : scanCanonicalize (H12AffineFastState.compose env27868 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound27868 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27869 : List Nat := [2,4,8,0,32,0,9,36,0,37,0,1,41,1,1,35,0,0,36,0,1,33,0,3,40,0,0,0,1,0,4,32,37,33,0,1]

theorem envBound27869 : H12AffineFastState.Bounded env27869 := by
  intro p hp
  have h : env27869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27868_27869 : H12AffineEnvironment.transform 5 0 env27868 = env27869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env27868 == env27869) = true)

theorem identity27869 : scanCanonicalize (H12AffineFastState.compose env27869 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27869 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27870 : List Nat := [2,4,8,0,1,0,9,5,0,4,0,1,8,1,1,2,0,0,5,0,1,0,0,3,9,0,0,0,1,0,4,1,4,0,0,1]

theorem envBound27870 : H12AffineFastState.Bounded env27870 := by
  intro p hp
  have h : env27870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27869_27870 : H12AffineEnvironment.transform 4 1 env27869 = env27870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27869 == env27870) = true)

def env27871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6664599,2098513,17664,2437195,2102684,6349853,257,21792,46213,2175563]

theorem envBound27871 : H12AffineFastState.Bounded env27871 := by
  intro p hp
  have h : env27871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27808_27871 : H12AffineEnvironment.transform 22 2101329 env27808 = env27871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env27808 == env27871) = true)

def env27872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2201879,2098513,17664,2437195,2102684,2411677,257,21792,46213,2175563]

theorem envBound27872 : H12AffineFastState.Bounded env27872 := by
  intro p hp
  have h : env27872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27871_27872 : H12AffineEnvironment.transform 21 272512 env27871 = env27872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27871 == env27872) = true)

theorem identity27872 : scanCanonicalize (H12AffineFastState.compose env27872 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

end H12CloudChart1