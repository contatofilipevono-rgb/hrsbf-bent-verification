import H12CloudChart1Data105

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans26855_26856 : H12AffineEnvironment.transform 7 220 env26855 = env26856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env26855 == env26856) = true)

theorem identity26856 : scanCanonicalize (H12AffineFastState.compose env26856 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26856 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26857 : List Nat := [2,4,8,16,0,64,128,220,512,1024,2048,4096,128,5341,136,139,5325,2048,1025,137,4160,0,17,3,8,64,2049,5324,4097,2185,1025,136,221,1,5260,513]

theorem envBound26857 : H12AffineFastState.Bounded env26857 := by
  intro p hp
  have h : env26857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26856_26857 : H12AffineEnvironment.transform 4 0 env26856 = env26857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26856 == env26857) = true)

theorem identity26857 : scanCanonicalize (H12AffineFastState.compose env26857 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(11+1) ^^^ 200) := by decide +kernel

theorem selectedBound26857 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env26858 : List Nat := [2,4,8,16,0,64,128,220,512,1024,2048,200,128,1045,136,139,1029,2048,1025,137,136,0,17,3,8,64,2049,1028,201,2185,1025,136,221,1,1092,513]

theorem envBound26858 : H12AffineFastState.Bounded env26858 := by
  intro p hp
  have h : env26858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26857_26858 : H12AffineEnvironment.transform 11 200 env26857 = env26858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 200 env26857 == env26858) = true)

theorem identity26858 : scanCanonicalize (H12AffineFastState.compose env26858 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound26858 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env26859 : List Nat := [2,4,8,16,0,64,128,220,512,1024,513,200,128,1045,136,139,1029,513,1025,137,136,0,17,3,8,64,512,1028,201,648,1025,136,221,1,1092,513]

theorem envBound26859 : H12AffineFastState.Bounded env26859 := by
  intro p hp
  have h : env26859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26858_26859 : H12AffineEnvironment.transform 10 513 env26858 = env26859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env26858 == env26859) = true)

theorem identity26859 : scanCanonicalize (H12AffineFastState.compose env26859 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound26859 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env26860 : List Nat := [2,4,8,16,0,64,128,220,137,1024,136,200,128,1045,136,139,1029,136,1025,137,136,0,17,3,8,64,137,1028,201,1,1025,136,221,1,1092,136]

theorem envBound26860 : H12AffineFastState.Bounded env26860 := by
  intro p hp
  have h : env26860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26859_26860 : H12AffineEnvironment.transform 8 137 env26859 = env26860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env26859 == env26860) = true)

theorem identity26860 : scanCanonicalize (H12AffineFastState.compose env26860 (packedSelected [2,4] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound26860 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env26861 : List Nat := [2,4,8,16,0,64,128,220,137,68,136,200,128,81,136,139,65,136,69,137,136,0,17,3,8,64,137,64,201,1,69,136,221,1,0,136]

theorem envBound26861 : H12AffineFastState.Bounded env26861 := by
  intro p hp
  have h : env26861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26860_26861 : H12AffineEnvironment.transform 9 68 env26860 = env26861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env26860 == env26861) = true)

theorem identity26861 : scanCanonicalize (H12AffineFastState.compose env26861 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound26861 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26862 : List Nat := [2,4,8,16,0,64,89,5,80,68,81,17,89,81,81,82,65,81,69,80,81,0,17,3,8,64,80,64,16,1,69,81,4,1,0,81]

theorem envBound26862 : H12AffineFastState.Bounded env26862 := by
  intro p hp
  have h : env26862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26861_26862 : H12AffineEnvironment.transform 6 89 env26861 = env26862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env26861 == env26862) = true)

theorem identity26862 : scanCanonicalize (H12AffineFastState.compose env26862 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound26862 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26863 : List Nat := [2,4,8,16,0,1,24,5,17,5,16,17,24,16,16,19,0,16,4,17,16,0,17,3,8,1,17,1,16,1,4,16,4,1,0,16]

theorem envBound26863 : H12AffineFastState.Bounded env26863 := by
  intro p hp
  have h : env26863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26862_26863 : H12AffineEnvironment.transform 5 1 env26862 = env26863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env26862 == env26863) = true)

theorem identity26863 : scanCanonicalize (H12AffineFastState.compose env26863 (packedSelected [14] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26863 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26864 : List Nat := [2,4,8,0,0,1,8,5,1,5,0,1,8,0,0,3,0,0,4,1,0,0,1,3,8,1,1,1,0,1,4,0,4,1,0,0]

theorem envBound26864 : H12AffineFastState.Bounded env26864 := by
  intro p hp
  have h : env26864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26863_26864 : H12AffineEnvironment.transform 3 0 env26863 = env26864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26863 == env26864) = true)

theorem identity26864 : scanCanonicalize (H12AffineFastState.compose env26864 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound26864 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26865 : List Nat := [2,4,3,0,0,1,3,5,1,5,0,1,3,0,0,3,0,0,4,1,0,0,1,3,3,1,1,1,0,1,4,0,4,1,0,0]

theorem envBound26865 : H12AffineFastState.Bounded env26865 := by
  intro p hp
  have h : env26865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26864_26865 : H12AffineEnvironment.transform 2 3 env26864 = env26865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env26864 == env26865) = true)

def env26866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10401,1025,32769,77899,33,73754,95497,8328,64,23808,115150,17664,10280,119043,73890,257,41461,16465,63188]

theorem envBound26866 : H12AffineFastState.Bounded env26866 := by
  intro p hp
  have h : env26866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26850_26866 : H12AffineEnvironment.transform 17 10401 env26850 = env26866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env26850 == env26866) = true)

theorem identity26866 : scanCanonicalize (H12AffineFastState.compose env26866 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound26866 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env26867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,478,57677,10401,1025,32769,12693,33,8644,29911,8328,64,23808,49168,17664,10280,53469,8572,257,41461,16465,63188]

theorem envBound26867 : H12AffineFastState.Bounded env26867 := by
  intro p hp
  have h : env26867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26866_26867 : H12AffineEnvironment.transform 15 478 env26866 = env26867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env26866 == env26867) = true)

theorem identity26867 : scanCanonicalize (H12AffineFastState.compose env26867 (packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound26867 : packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env26868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,478,13388,10401,1025,21760,12693,33,8644,29911,8328,64,23808,5393,17664,10280,1500,8572,257,29940,16465,9173]

theorem envBound26868 : H12AffineFastState.Bounded env26868 := by
  intro p hp
  have h : env26868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26867_26868 : H12AffineEnvironment.transform 14 21761 env26867 = env26868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env26867 == env26868) = true)

theorem identity26868 : scanCanonicalize (H12AffineFastState.compose env26868 (packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,18,24,26,28] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound26868 : packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,18,24,26,28] rootPS < 2^1333 := by decide +kernel

def env26869 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,21761,263,13388,10360,1025,21760,12620,33,8477,29710,8273,64,23808,5393,17664,10280,1285,8572,257,29741,16465,8972]

theorem envBound26869 : H12AffineFastState.Bounded env26869 := by
  intro p hp
  have h : env26869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26868_26869 : H12AffineEnvironment.transform 6 89 env26868 = env26869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env26868 == env26869) = true)

theorem identity26869 : scanCanonicalize (H12AffineFastState.compose env26869 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26869 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env26870 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,16384,21761,263,5392,2340,1025,21760,4112,33,65,21842,269,64,23808,5393,17664,2420,1285,32,257,21873,16465,592]

theorem envBound26870 : H12AffineFastState.Bounded env26870 := by
  intro p hp
  have h : env26870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26869_26870 : H12AffineEnvironment.transform 12 348 env26869 = env26870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26869 == env26870) = true)

theorem identity26870 : scanCanonicalize (H12AffineFastState.compose env26870 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26870 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26871 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,120,16384,21541,35,5172,2048,1025,21540,4112,33,65,21622,41,64,23588,5173,17444,2128,1057,32,37,21589,16465,592]

theorem envBound26871 : H12AffineFastState.Bounded env26871 := by
  intro p hp
  have h : env26871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26870_26871 : H12AffineEnvironment.transform 7 36 env26870 = env26871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26870 == env26871) = true)

theorem identity26871 : scanCanonicalize (H12AffineFastState.compose env26871 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26871 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26872 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,21541,35,5172,2048,1025,21540,4112,33,17,21542,41,16,23588,5173,17444,2048,1057,32,37,21509,16385,512]

theorem envBound26872 : H12AffineFastState.Bounded env26872 := by
  intro p hp
  have h : env26872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26871_26872 : H12AffineEnvironment.transform 5 16 env26871 = env26872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26871 == env26872) = true)

theorem identity26872 : scanCanonicalize (H12AffineFastState.compose env26872 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound26872 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26873 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5124,33,35,5172,2048,1025,32,4112,33,17,34,41,16,2080,5173,4128,2048,1057,32,37,1,5125,512]

theorem envBound26873 : H12AffineFastState.Bounded env26873 := by
  intro p hp
  have h : env26873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26872_26873 : H12AffineEnvironment.transform 13 5124 env26872 = env26873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env26872 == env26873) = true)

theorem identity26873 : scanCanonicalize (H12AffineFastState.compose env26873 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound26873 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env26874 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,1077,40,49,33,35,1,2048,1025,32,1061,33,17,34,41,16,2080,0,1045,2048,1057,32,37,1,48,512]

theorem envBound26874 : H12AffineFastState.Bounded env26874 := by
  intro p hp
  have h : env26874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26873_26874 : H12AffineEnvironment.transform 11 1077 env26873 = env26874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env26873 == env26874) = true)

theorem identity26874 : scanCanonicalize (H12AffineFastState.compose env26874 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26874 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26875 : List Nat := [2,4,8,1,32,1,9,36,512,1024,2048,1060,40,32,33,35,1,2048,1025,32,1061,33,0,34,41,1,2080,0,1028,2048,1057,32,37,1,33,512]

theorem envBound26875 : H12AffineFastState.Bounded env26875 := by
  intro p hp
  have h : env26875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26874_26875 : H12AffineEnvironment.transform 3 1 env26874 = env26875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26874 == env26875) = true)

theorem identity26875 : scanCanonicalize (H12AffineFastState.compose env26875 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound26875 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env26876 : List Nat := [2,4,8,1,32,1,9,36,512,1024,1,1060,40,32,33,35,1,1,1025,32,1061,33,0,34,41,1,33,0,1028,1,1057,32,37,1,33,512]

theorem envBound26876 : H12AffineFastState.Bounded env26876 := by
  intro p hp
  have h : env26876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26875_26876 : H12AffineEnvironment.transform 10 1 env26875 = env26876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env26875 == env26876) = true)

theorem identity26876 : scanCanonicalize (H12AffineFastState.compose env26876 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26876 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env26877 : List Nat := [2,4,8,1,1,1,9,5,512,1024,1,1029,9,1,0,2,1,1,1025,1,1028,0,0,3,8,1,0,0,1028,1,1024,1,4,1,0,512]

theorem envBound26877 : H12AffineFastState.Bounded env26877 := by
  intro p hp
  have h : env26877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26876_26877 : H12AffineEnvironment.transform 4 1 env26876 = env26877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26876 == env26877) = true)

def env26878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180361,169370,8328,64,245138,115150,17664,262281,119043,329730,257,213350,237762,63188]

theorem envBound26878 : H12AffineFastState.Bounded env26878 := by
  intro p hp
  have h : env26878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26848_26878 : H12AffineEnvironment.transform 21 272513 env26848 = env26878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env26848 == env26878) = true)

theorem identity26878 : scanCanonicalize (H12AffineFastState.compose env26878 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26878 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184536,272513,180361,169370,8328,64,171417,57797,17664,262281,61704,272393,257,156013,164041,63188]

theorem envBound26879 : H12AffineFastState.Bounded env26879 := by
  intro p hp
  have h : env26879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26878_26879 : H12AffineEnvironment.transform 15 8203 env26878 = env26879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26878 == env26879) = true)

def env26880 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184456,272513,180361,169370,8328,16,171417,57749,17664,262281,61704,272393,257,155965,163993,63108]

theorem envBound26880 : H12AffineFastState.Bounded env26880 := by
  intro p hp
  have h : env26880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26879_26880 : H12AffineEnvironment.transform 5 16 env26879 = env26880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26879 == env26880) = true)

theorem identity26880 : scanCanonicalize (H12AffineFastState.compose env26880 (packedSelected [3,15,17,19,24,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound26880 : packedSelected [3,15,17,19,24,31,38] rootPS < 2^1333 := by decide +kernel

def env26881 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29708,8203,131072,262144,1025,29709,140420,272513,144517,156054,8328,16,158101,5529,17664,262281,1284,272393,257,155965,160917,648]

theorem envBound26881 : H12AffineFastState.Bounded env26881 := by
  intro p hp
  have h : env26881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26880_26881 : H12AffineEnvironment.transform 14 29708 env26880 = env26881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env26880 == env26881) = true)

theorem identity26881 : scanCanonicalize (H12AffineFastState.compose env26881 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound26881 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env26882 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29708,8203,131072,10280,1025,29709,140420,169,144517,156054,8328,16,158101,5529,17664,10401,1284,33,257,155965,160917,648]

theorem envBound26882 : H12AffineFastState.Bounded env26882 := by
  intro p hp
  have h : env26882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26881_26882 : H12AffineEnvironment.transform 17 10280 env26881 = env26882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env26881 == env26882) = true)

theorem identity26882 : scanCanonicalize (H12AffineFastState.compose env26882 (packedSelected [1,8,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound26882 : packedSelected [1,8,10,15,17] rootPS < 2^1333 := by decide +kernel

def env26883 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8461,8203,131072,10280,1025,8460,140420,169,144517,144535,8328,16,146580,5529,4097,10401,1284,33,257,144444,139668,648]

theorem envBound26883 : H12AffineFastState.Bounded env26883 := by
  intro p hp
  have h : env26883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26882_26883 : H12AffineEnvironment.transform 13 5377 env26882 = env26883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26882 == env26883) = true)

theorem identity26883 : scanCanonicalize (H12AffineFastState.compose env26883 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26883 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26884 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8203,131072,10280,1025,8460,140301,32,144396,144414,8193,16,146461,5392,4097,10280,1284,33,257,144444,139549,513]

theorem envBound26884 : H12AffineFastState.Bounded env26884 := by
  intro p hp
  have h : env26884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26883_26884 : H12AffineEnvironment.transform 6 9 env26883 = env26884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26883 == env26884) = true)

theorem identity26884 : scanCanonicalize (H12AffineFastState.compose env26884 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound26884 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26885 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8203,5392,10280,1025,8460,12573,32,8476,8462,8193,16,10509,5392,4097,10280,1284,33,257,8492,13325,513]

theorem envBound26885 : H12AffineFastState.Bounded env26885 := by
  intro p hp
  have h : env26885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26884_26885 : H12AffineEnvironment.transform 16 5392 env26884 = env26885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env26884 == env26885) = true)

theorem identity26885 : scanCanonicalize (H12AffineFastState.compose env26885 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound26885 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env26886 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,48,8192,1329,8461,8203,1312,10280,1025,8460,8493,32,8476,8462,8193,16,10509,1312,49,10280,1284,33,257,8492,9277,513]

theorem envBound26886 : H12AffineFastState.Bounded env26886 := by
  intro p hp
  have h : env26886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26885_26886 : H12AffineEnvironment.transform 11 48 env26885 = env26886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env26885 == env26886) = true)

theorem identity26886 : scanCanonicalize (H12AffineFastState.compose env26886 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound26886 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26887 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,48,268,1329,1,263,1312,2340,1025,0,33,32,16,2,269,16,2049,1312,49,2340,1284,33,257,32,1329,513]

theorem envBound26887 : H12AffineFastState.Bounded env26887 := by
  intro p hp
  have h : env26887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26886_26887 : H12AffineEnvironment.transform 12 268 env26886 = env26887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env26886 == env26887) = true)

theorem identity26887 : scanCanonicalize (H12AffineFastState.compose env26887 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound26887 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26888 : List Nat := [2,4,8,16,32,16,9,256,512,21,2048,48,268,292,1,263,309,2340,20,0,33,32,16,2,269,16,2049,309,49,2340,273,33,257,32,292,513]

theorem envBound26888 : H12AffineFastState.Bounded env26888 := by
  intro p hp
  have h : env26888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26887_26888 : H12AffineEnvironment.transform 9 21 env26887 = env26888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env26887 == env26888) = true)

theorem identity26888 : scanCanonicalize (H12AffineFastState.compose env26888 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound26888 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26889 : List Nat := [2,4,8,16,32,16,9,256,512,21,522,48,268,292,1,263,309,814,20,0,33,32,16,2,269,16,523,309,49,814,273,33,257,32,292,513]

theorem envBound26889 : H12AffineFastState.Bounded env26889 := by
  intro p hp
  have h : env26889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26888_26889 : H12AffineEnvironment.transform 10 522 env26888 = env26889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env26888 == env26889) = true)

theorem identity26889 : scanCanonicalize (H12AffineFastState.compose env26889 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26889 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26890 : List Nat := [2,4,8,16,32,16,9,37,512,21,522,48,41,1,1,34,16,523,20,0,33,32,16,2,40,16,523,16,49,523,52,33,36,32,1,513]

theorem envBound26890 : H12AffineFastState.Bounded env26890 := by
  intro p hp
  have h : env26890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26889_26890 : H12AffineEnvironment.transform 7 37 env26889 = env26890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26889 == env26890) = true)

theorem identity26890 : scanCanonicalize (H12AffineFastState.compose env26890 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 53) := by decide +kernel

theorem selectedBound26890 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26891 : List Nat := [2,4,8,16,32,16,9,37,53,21,63,48,41,1,1,34,16,62,20,0,33,32,16,2,40,16,62,16,49,62,52,33,36,32,1,52]

theorem envBound26891 : H12AffineFastState.Bounded env26891 := by
  intro p hp
  have h : env26891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26890_26891 : H12AffineEnvironment.transform 8 53 env26890 = env26891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 53 env26890 == env26891) = true)

def env26892 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184457,272513,180361,169370,8328,17,171417,57748,17664,262281,61704,272393,257,155964,163992,63109]

theorem envBound26892 : H12AffineFastState.Bounded env26892 := by
  intro p hp
  have h : env26892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26879_26892 : H12AffineEnvironment.transform 5 17 env26879 = env26892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26879 == env26892) = true)

theorem identity26892 : scanCanonicalize (H12AffineFastState.compose env26892 (packedSelected [3,15,17,19,24,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound26892 : packedSelected [3,15,17,19,24,31,38] rootPS < 2^1333 := by decide +kernel

def env26893 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56357,1025,32769,184457,62628,180361,169370,8328,17,171417,57748,17664,56492,61704,62508,257,155964,163992,63109]

theorem envBound26893 : H12AffineFastState.Bounded env26893 := by
  intro p hp
  have h : env26893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26892_26893 : H12AffineEnvironment.transform 17 56357 env26892 = env26893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env26892 == env26893) = true)

theorem identity26893 : scanCanonicalize (H12AffineFastState.compose env26893 (packedSelected [1,3,11,12,15,17,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57748) := by decide +kernel

theorem selectedBound26893 : packedSelected [1,3,11,12,15,17,23,24,28] rootPS < 2^1333 := by decide +kernel

def env26894 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,57748,56357,1025,32769,12573,62628,8477,29710,8328,17,31757,57748,17664,56492,61704,62508,257,32936,24844,63109]

theorem envBound26894 : H12AffineFastState.Bounded env26894 := by
  intro p hp
  have h : env26894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26893_26894 : H12AffineEnvironment.transform 16 57748 env26893 = env26894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57748 env26893 == env26894) = true)

theorem identity26894 : scanCanonicalize (H12AffineFastState.compose env26894 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26894 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env26895 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8203,57629,56357,1025,32769,12573,62509,8477,29710,8193,17,31757,57629,17664,56357,61704,62508,257,32801,24844,62988]

theorem envBound26895 : H12AffineFastState.Bounded env26895 := by
  intro p hp
  have h : env26895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26894_26895 : H12AffineEnvironment.transform 6 9 env26894 = env26895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26894 == env26895) = true)

theorem identity26895 : scanCanonicalize (H12AffineFastState.compose env26895 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound26895 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env26896 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,8203,16401,32041,1025,8461,12573,21793,8477,29710,8193,17,31757,16401,17664,32041,20484,21792,257,8493,24844,22272]

theorem envBound26896 : H12AffineFastState.Bounded env26896 := by
  intro p hp
  have h : env26896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26895_26896 : H12AffineEnvironment.transform 14 8460 env26895 = env26896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env26895 == env26896) = true)

theorem identity26896 : scanCanonicalize (H12AffineFastState.compose env26896 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound26896 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env26897 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,8460,8203,13341,2341,1025,8461,12573,8493,8477,2,8193,17,2049,13341,12556,2341,9224,8492,257,8493,5376,8972]

theorem envBound26897 : H12AffineFastState.Bounded env26897 := by
  intro p hp
  have h : env26897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26896_26897 : H12AffineEnvironment.transform 13 13324 env26896 = env26897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env26896 == env26897) = true)

theorem identity26897 : scanCanonicalize (H12AffineFastState.compose env26897 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound26897 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env26898 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2356,8192,11576,8460,8203,11561,2341,1025,8461,10281,8493,8477,2,8193,17,2049,11561,10296,2341,9224,8492,257,8493,3124,8972]

theorem envBound26898 : H12AffineFastState.Bounded env26898 := by
  intro p hp
  have h : env26898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26897_26898 : H12AffineEnvironment.transform 11 2356 env26897 = env26898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env26897 == env26898) = true)

theorem identity26898 : scanCanonicalize (H12AffineFastState.compose env26898 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound26898 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env26899 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2356,40,3344,292,35,3329,2341,1025,293,2049,261,309,2,41,17,2049,3329,2064,2341,1056,260,257,261,3124,804]

theorem envBound26899 : H12AffineFastState.Bounded env26899 := by
  intro p hp
  have h : env26899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26898_26899 : H12AffineEnvironment.transform 12 40 env26898 = env26899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env26898 == env26899) = true)

theorem identity26899 : scanCanonicalize (H12AffineFastState.compose env26899 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound26899 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26900 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1296,1060,40,0,292,35,17,1077,1025,293,1297,261,309,2,41,17,1297,17,1280,1077,1056,260,257,261,292,804]

theorem envBound26900 : H12AffineFastState.Bounded env26900 := by
  intro p hp
  have h : env26900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26899_26900 : H12AffineEnvironment.transform 10 1296 env26899 = env26900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env26899 == env26900) = true)

theorem identity26900 : scanCanonicalize (H12AffineFastState.compose env26900 (packedSelected [0,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26900 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env26901 : List Nat := [2,4,8,16,0,17,9,256,512,1024,1296,1028,8,0,260,3,17,1045,1025,261,1297,261,277,2,9,17,1297,17,1280,1045,1024,260,257,261,260,772]

theorem envBound26901 : H12AffineFastState.Bounded env26901 := by
  intro p hp
  have h : env26901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26900_26901 : H12AffineEnvironment.transform 4 0 env26900 = env26901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26900 == env26901) = true)

theorem identity26901 : scanCanonicalize (H12AffineFastState.compose env26901 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound26901 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env26902 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1044,1028,8,0,0,3,17,1045,1025,1,1045,1,17,2,9,17,1045,17,1028,1045,1024,0,5,1,0,512]

theorem envBound26902 : H12AffineFastState.Bounded env26902 := by
  intro p hp
  have h : env26902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26901_26902 : H12AffineEnvironment.transform 7 4 env26901 = env26902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env26901 == env26902) = true)

theorem identity26902 : scanCanonicalize (H12AffineFastState.compose env26902 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound26902 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26903 : List Nat := [2,4,8,16,0,17,9,4,0,1024,1044,1028,8,0,0,3,17,1045,1025,1,1045,1,17,2,9,17,1045,17,1028,1045,1024,0,5,1,0,0]

theorem envBound26903 : H12AffineFastState.Bounded env26903 := by
  intro p hp
  have h : env26903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26902_26903 : H12AffineEnvironment.transform 8 0 env26902 = env26903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env26902 == env26903) = true)

theorem identity26903 : scanCanonicalize (H12AffineFastState.compose env26903 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound26903 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env26904 : List Nat := [2,4,8,16,0,17,9,4,0,21,1,17,8,0,0,3,17,0,20,1,0,1,17,2,9,17,0,17,17,0,21,0,5,1,0,0]

theorem envBound26904 : H12AffineFastState.Bounded env26904 := by
  intro p hp
  have h : env26904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26903_26904 : H12AffineEnvironment.transform 9 21 env26903 = env26904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env26903 == env26904) = true)

theorem identity26904 : scanCanonicalize (H12AffineFastState.compose env26904 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound26904 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26905 : List Nat := [2,4,8,4,0,5,9,4,0,1,1,5,8,0,0,3,5,0,0,1,0,1,5,2,9,5,0,5,5,0,1,0,5,1,0,0]

theorem envBound26905 : H12AffineFastState.Bounded env26905 := by
  intro p hp
  have h : env26905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26904_26905 : H12AffineEnvironment.transform 3 4 env26904 = env26905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env26904 == env26905) = true)

def env26906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180361,169371,8328,64,4691218,115150,17665,262281,119042,4268163,257,213350,237762,63189]

theorem envBound26906 : H12AffineFastState.Bounded env26906 := by
  intro p hp
  have h : env26906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26847_26906 : H12AffineEnvironment.transform 20 184537 env26847 = env26906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184537 env26847 == env26906) = true)

def env26907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180361,169371,8328,64,245138,115150,17665,262281,119042,329731,257,213350,237762,63189]

theorem envBound26907 : H12AffineFastState.Bounded env26907 := by
  intro p hp
  have h : env26907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26906_26907 : H12AffineEnvironment.transform 21 272512 env26906 = env26907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env26906 == env26907) = true)

theorem identity26907 : scanCanonicalize (H12AffineFastState.compose env26907 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound26907 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,115870,272512,120014,98780,8328,64,43477,115150,17665,262281,119042,329731,257,21793,46213,63189]

theorem envBound26908 : H12AffineFastState.Bounded env26908 := by
  intro p hp
  have h : env26908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26907_26908 : H12AffineEnvironment.transform 16 70727 env26907 = env26908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env26907 == env26908) = true)

def env26909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10400,1025,32769,115870,32,120014,98780,8328,64,43477,115150,17665,10281,119042,73891,257,21793,46213,63189]

theorem envBound26909 : H12AffineFastState.Bounded env26909 := by
  intro p hp
  have h : env26909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26908_26909 : H12AffineEnvironment.transform 17 10400 env26908 = env26909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env26908 == env26909) = true)

theorem identity26909 : scanCanonicalize (H12AffineFastState.compose env26909 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound26909 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env26910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,65536,70727,2421,1025,32769,115870,32,120014,98780,349,64,34816,115150,17665,2556,119042,65910,257,21793,38224,55040]

theorem envBound26910 : H12AffineFastState.Bounded env26910 := by
  intro p hp
  have h : env26910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26909_26910 : H12AffineEnvironment.transform 12 469 env26909 = env26910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env26909 == env26910) = true)

theorem identity26910 : scanCanonicalize (H12AffineFastState.compose env26910 (packedSelected [0,3,9,10,16,17,18,19,20,22,23,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound26910 : packedSelected [0,3,9,10,16,17,18,19,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env26911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,137,65536,70727,2421,1025,136,82967,32,87111,65877,349,64,2185,82247,17665,2556,86411,65910,257,21793,5593,22409]

theorem envBound26911 : H12AffineFastState.Bounded env26911 := by
  intro p hp
  have h : env26911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26910_26911 : H12AffineEnvironment.transform 14 137 env26910 = env26911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env26910 == env26911) = true)

theorem identity26911 : scanCanonicalize (H12AffineFastState.compose env26911 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound26911 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,137,479,5528,2421,1025,136,17864,32,21912,138,349,64,2185,16536,17665,2556,20564,169,257,21793,5593,22409]

theorem envBound26912 : H12AffineFastState.Bounded env26912 := by
  intro p hp
  have h : env26912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26911_26912 : H12AffineEnvironment.transform 15 479 env26911 = env26912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env26911 == env26912) = true)

theorem identity26912 : scanCanonicalize (H12AffineFastState.compose env26912 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound26912 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env26913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5373,137,479,5528,2421,1025,136,4405,32,357,138,349,64,2185,5221,4604,2556,1193,169,257,476,5593,884]

theorem envBound26913 : H12AffineFastState.Bounded env26913 := by
  intro p hp
  have h : env26913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26912_26913 : H12AffineEnvironment.transform 13 5373 env26912 = env26913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env26912 == env26913) = true)

theorem identity26913 : scanCanonicalize (H12AffineFastState.compose env26913 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound26913 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env26914 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,161,5373,137,171,5356,2049,1025,136,4161,32,17,138,41,64,2185,5221,4232,2184,1193,169,117,168,5293,512]

theorem envBound26914 : H12AffineFastState.Bounded env26914 := by
  intro p hp
  have h : env26914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26913_26914 : H12AffineEnvironment.transform 7 116 env26913 = env26914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env26913 == env26914) = true)

theorem identity26914 : scanCanonicalize (H12AffineFastState.compose env26914 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound26914 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26915 : List Nat := [2,4,8,16,32,64,120,116,512,1024,2048,4096,89,5125,113,83,5140,2049,1025,112,4161,32,17,114,41,64,2161,5221,4208,2160,1105,81,117,80,5205,512]

theorem envBound26915 : H12AffineFastState.Bounded env26915 := by
  intro p hp
  have h : env26915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26914_26915 : H12AffineEnvironment.transform 6 120 env26914 = env26915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env26914 == env26915) = true)

theorem identity26915 : scanCanonicalize (H12AffineFastState.compose env26915 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound26915 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26916 : List Nat := [2,4,8,16,32,49,9,5,512,1024,2048,4096,40,5125,0,34,5140,2049,1025,1,4144,32,17,3,41,49,2048,5140,4097,2049,1056,32,4,33,5156,512]

theorem envBound26916 : H12AffineFastState.Bounded env26916 := by
  intro p hp
  have h : env26916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26915_26916 : H12AffineEnvironment.transform 5 49 env26915 = env26916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env26915 == env26916) = true)

theorem identity26916 : scanCanonicalize (H12AffineFastState.compose env26916 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound26916 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26917 : List Nat := [2,4,8,16,32,49,9,5,512,1024,522,4096,40,5125,0,34,5140,523,1025,1,4144,32,17,3,41,49,522,5140,4097,523,1056,32,4,33,5156,512]

theorem envBound26917 : H12AffineFastState.Bounded env26917 := by
  intro p hp
  have h : env26917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26916_26917 : H12AffineEnvironment.transform 10 522 env26916 = env26917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env26916 == env26917) = true)

theorem identity26917 : scanCanonicalize (H12AffineFastState.compose env26917 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound26917 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26918 : List Nat := [2,4,8,16,32,49,9,5,512,21,522,4096,40,4112,0,34,4097,523,20,1,4144,32,17,3,41,49,522,4097,4097,523,53,32,4,33,4145,512]

theorem envBound26918 : H12AffineFastState.Bounded env26918 := by
  intro p hp
  have h : env26918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26917_26918 : H12AffineEnvironment.transform 9 21 env26917 = env26918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env26917 == env26918) = true)

theorem identity26918 : scanCanonicalize (H12AffineFastState.compose env26918 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26918 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26919 : List Nat := [2,4,8,16,1,16,9,5,512,21,522,4096,9,4112,0,3,4097,523,20,1,4113,1,17,3,8,16,522,4097,4097,523,20,1,4,0,4112,512]

theorem envBound26919 : H12AffineFastState.Bounded env26919 := by
  intro p hp
  have h : env26919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26918_26919 : H12AffineEnvironment.transform 4 1 env26918 = env26919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26918 == env26919) = true)

theorem identity26919 : scanCanonicalize (H12AffineFastState.compose env26919 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 20) := by decide +kernel

theorem selectedBound26919 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26920 : List Nat := [2,4,8,16,1,16,9,5,512,21,522,20,9,4,0,3,21,523,20,1,5,1,17,3,8,16,522,21,21,523,20,1,4,0,4,512]

theorem envBound26920 : H12AffineFastState.Bounded env26920 := by
  intro p hp
  have h : env26920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26919_26920 : H12AffineEnvironment.transform 11 20 env26919 = env26920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 20 env26919 == env26920) = true)

theorem identity26920 : scanCanonicalize (H12AffineFastState.compose env26920 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound26920 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26921 : List Nat := [0,4,8,16,1,16,9,5,512,21,520,20,9,4,0,1,21,521,20,1,5,1,17,1,8,16,520,21,21,521,20,1,4,0,4,512]

theorem envBound26921 : H12AffineFastState.Bounded env26921 := by
  intro p hp
  have h : env26921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26920_26921 : H12AffineEnvironment.transform 0 0 env26920 = env26921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env26920 == env26921) = true)

theorem identity26921 : scanCanonicalize (H12AffineFastState.compose env26921 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound26921 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26922 : List Nat := [0,4,8,16,1,16,9,5,13,21,5,20,9,4,0,1,21,4,20,1,5,1,17,1,8,16,5,21,21,4,20,1,4,0,4,13]

theorem envBound26922 : H12AffineFastState.Bounded env26922 := by
  intro p hp
  have h : env26922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26921_26922 : H12AffineEnvironment.transform 8 13 env26921 = env26922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env26921 == env26922) = true)

def env26923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10401,1025,32769,115870,33,120014,98780,8328,64,43477,115150,17665,10280,119042,73890,257,21793,46213,63189]

theorem envBound26923 : H12AffineFastState.Bounded env26923 := by
  intro p hp
  have h : env26923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26908_26923 : H12AffineEnvironment.transform 17 10401 env26908 = env26923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env26908 == env26923) = true)

theorem identity26923 : scanCanonicalize (H12AffineFastState.compose env26923 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound26923 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env26924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62730,57677,10401,1025,32769,12692,33,8644,29910,8328,64,43477,13508,17665,10280,9224,54696,257,21793,46213,63189]

theorem envBound26924 : H12AffineFastState.Bounded env26924 := by
  intro p hp
  have h : env26924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26923_26924 : H12AffineEnvironment.transform 15 62730 env26923 = env26924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env26923 == env26924) = true)

theorem identity26924 : scanCanonicalize (H12AffineFastState.compose env26924 (packedSelected [0,1,3,9,10,16,17,18,20,22,23,24,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound26924 : packedSelected [0,1,3,9,10,16,17,18,20,22,23,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8202,13389,10401,1025,21761,12692,33,8644,29910,8328,64,31957,13508,17665,10280,9224,168,257,21793,24965,9173]

theorem envBound26925 : H12AffineFastState.Bounded env26925 := by
  intro p hp
  have h : env26925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26924_26925 : H12AffineEnvironment.transform 14 21760 env26924 = env26925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env26924 == env26925) = true)

theorem identity26925 : scanCanonicalize (H12AffineFastState.compose env26925 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound26925 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env26926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8540,8202,13389,10401,1025,8541,12692,33,8644,138,8328,64,2185,13508,12637,10280,9224,168,257,8573,5593,9173]

theorem envBound26926 : H12AffineFastState.Bounded env26926 := by
  intro p hp
  have h : env26926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26925_26926 : H12AffineEnvironment.transform 13 13404 env26925 = env26926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env26925 == env26926) = true)

theorem identity26926 : scanCanonicalize (H12AffineFastState.compose env26926 (packedSelected [0,2,3,5,7,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound26926 : packedSelected [0,2,3,5,7,10,14] rootPS < 2^1333 := by decide +kernel

def env26927 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,4096,8192,12464,8540,8202,12449,10401,237,8541,12692,33,8644,138,8328,64,2185,12328,12637,10280,8420,168,257,8573,4405,9173]

theorem envBound26927 : H12AffineFastState.Bounded env26927 := by
  intro p hp
  have h : env26927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26926_26927 : H12AffineEnvironment.transform 9 236 env26926 = env26927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env26926 == env26927) = true)

def env26928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180361,169371,8328,64,245139,115150,17665,262281,119042,329730,257,213350,237762,63189]

theorem envBound26928 : H12AffineFastState.Bounded env26928 := by
  intro p hp
  have h : env26928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26906_26928 : H12AffineEnvironment.transform 21 272513 env26906 = env26928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env26906 == env26928) = true)

theorem identity26928 : scanCanonicalize (H12AffineFastState.compose env26928 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound26928 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,184537,272513,180361,169371,8328,64,158028,5393,17665,262281,1501,318685,257,169401,160797,63189]

theorem envBound26929 : H12AffineFastState.Bounded env26929 := by
  intro p hp
  have h : env26929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26928_26929 : H12AffineEnvironment.transform 15 54495 env26928 = env26929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env26928 == env26929) = true)

theorem identity26929 : scanCanonicalize (H12AffineFastState.compose env26929 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound26929 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env26930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,131072,262144,1025,29909,140301,272513,144477,155983,8328,64,158028,5393,17665,262281,1501,272393,257,156013,160797,513]

theorem envBound26930 : H12AffineFastState.Bounded env26930 := by
  intro p hp
  have h : env26930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26929_26930 : H12AffineEnvironment.transform 14 29908 env26929 = env26930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env26929 == env26930) = true)

theorem identity26930 : scanCanonicalize (H12AffineFastState.compose env26930 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound26930 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env26931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,479,131072,262144,1025,21761,132569,264533,136585,147611,348,64,149656,5393,17665,262281,1501,264669,257,147641,153033,513]

theorem envBound26931 : H12AffineFastState.Bounded env26931 := by
  intro p hp
  have h : env26931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26930_26931 : H12AffineEnvironment.transform 12 468 env26930 = env26931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env26930 == env26931) = true)

theorem identity26931 : scanCanonicalize (H12AffineFastState.compose env26931 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 138476) := by decide +kernel

theorem selectedBound26931 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env26932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,479,131072,138476,1025,21761,132569,136633,136585,147611,348,64,149656,5393,17665,138341,1501,136497,257,147641,153033,513]

theorem envBound26932 : H12AffineFastState.Bounded env26932 := by
  intro p hp
  have h : env26932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26931_26932 : H12AffineEnvironment.transform 17 138476 env26931 = env26932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138476 env26931 == env26932) = true)

theorem identity26932 : scanCanonicalize (H12AffineFastState.compose env26932 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound26932 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env26933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,479,16400,23804,1025,21761,17865,21929,21913,139,348,64,2184,5393,17665,23669,1501,21793,257,169,5593,513]

theorem envBound26933 : H12AffineFastState.Bounded env26933 := by
  intro p hp
  have h : env26933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26932_26933 : H12AffineEnvironment.transform 16 16400 env26932 = env26933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env26932 == env26933) = true)

theorem identity26933 : scanCanonicalize (H12AffineFastState.compose env26933 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound26933 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env26934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,479,5529,2421,1025,136,4160,32,16,139,348,64,2184,5393,4232,2556,1501,168,257,169,5593,513]

theorem envBound26934 : H12AffineFastState.Bounded env26934 := by
  intro p hp
  have h : env26934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26933_26934 : H12AffineEnvironment.transform 13 5513 env26933 = env26934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env26933 == env26934) = true)

theorem identity26934 : scanCanonicalize (H12AffineFastState.compose env26934 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound26934 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26935 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,5457,81,263,5441,2421,1025,80,4160,32,16,83,348,64,2128,5393,4176,2340,1285,112,257,113,5377,513]

theorem envBound26935 : H12AffineFastState.Bounded env26935 := by
  intro p hp
  have h : env26935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26934_26935 : H12AffineEnvironment.transform 6 88 env26934 = env26935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env26934 == env26935) = true)

theorem identity26935 : scanCanonicalize (H12AffineFastState.compose env26935 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound26935 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26936 : List Nat := [2,4,8,16,32,64,88,101,512,1024,2048,4096,105,5172,81,98,5156,2064,1025,80,4160,32,16,83,57,64,2128,5236,4176,2113,1120,112,100,113,5220,513]

theorem envBound26936 : H12AffineFastState.Bounded env26936 := by
  intro p hp
  have h : env26936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26935_26936 : H12AffineEnvironment.transform 7 101 env26935 = env26936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env26935 == env26936) = true)

theorem identity26936 : scanCanonicalize (H12AffineFastState.compose env26936 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound26936 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env26937 : List Nat := [2,4,8,16,32,64,88,101,512,1024,1573,4096,105,5172,81,98,5156,1589,1025,80,4160,32,16,83,57,64,1653,5236,4176,1636,1120,112,100,113,5220,513]

theorem envBound26937 : H12AffineFastState.Bounded env26937 := by
  intro p hp
  have h : env26937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26936_26937 : H12AffineEnvironment.transform 10 1573 env26936 = env26937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env26936 == env26937) = true)

theorem identity26937 : scanCanonicalize (H12AffineFastState.compose env26937 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 592) := by decide +kernel

theorem selectedBound26937 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env26938 : List Nat := [2,4,8,16,32,64,88,101,512,1024,1573,592,105,1636,81,98,1652,1589,1025,80,528,32,16,83,57,64,1653,1572,512,1636,1120,112,100,113,1588,513]

theorem envBound26938 : H12AffineFastState.Bounded env26938 := by
  intro p hp
  have h : env26938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26937_26938 : H12AffineEnvironment.transform 11 592 env26937 = env26938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 592 env26937 == env26938) = true)

theorem identity26938 : scanCanonicalize (H12AffineFastState.compose env26938 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound26938 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env26939 : List Nat := [2,4,8,16,32,64,88,101,512,612,65,592,105,0,81,98,16,81,613,80,528,32,16,83,57,64,17,64,512,0,516,112,100,113,80,513]

theorem envBound26939 : H12AffineFastState.Bounded env26939 := by
  intro p hp
  have h : env26939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26938_26939 : H12AffineEnvironment.transform 9 612 env26938 = env26939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env26938 == env26939) = true)

theorem identity26939 : scanCanonicalize (H12AffineFastState.compose env26939 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound26939 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env26940 : List Nat := [2,4,8,16,32,64,88,101,65,37,65,17,105,0,81,98,16,81,36,80,81,32,16,83,57,64,17,64,65,0,69,112,100,113,80,64]

theorem envBound26940 : H12AffineFastState.Bounded env26940 := by
  intro p hp
  have h : env26940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26939_26940 : H12AffineEnvironment.transform 8 65 env26939 = env26940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env26939 == env26940) = true)

theorem identity26940 : scanCanonicalize (H12AffineFastState.compose env26940 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26940 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26941 : List Nat := [2,4,8,16,17,64,88,84,65,20,65,17,88,0,81,83,16,81,21,80,81,17,16,83,8,64,17,64,65,0,69,65,85,64,80,64]

theorem envBound26941 : H12AffineFastState.Bounded env26941 := by
  intro p hp
  have h : env26941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26940_26941 : H12AffineEnvironment.transform 4 17 env26940 = env26941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26940 == env26941) = true)

theorem identity26941 : scanCanonicalize (H12AffineFastState.compose env26941 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26941 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env26942 : List Nat := [2,4,8,0,1,64,72,68,65,4,65,1,72,0,65,67,0,65,5,64,65,1,0,67,8,64,1,64,65,0,69,65,69,64,64,64]

theorem envBound26942 : H12AffineFastState.Bounded env26942 := by
  intro p hp
  have h : env26942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26941_26942 : H12AffineEnvironment.transform 3 0 env26941 = env26942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26941 == env26942) = true)

theorem identity26942 : scanCanonicalize (H12AffineFastState.compose env26942 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound26942 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26943 : List Nat := [2,4,8,0,1,0,8,4,1,4,1,1,8,0,1,3,0,1,5,0,1,1,0,3,8,0,1,0,1,0,5,1,5,0,0,0]

theorem envBound26943 : H12AffineFastState.Bounded env26943 := by
  intro p hp
  have h : env26943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26942_26943 : H12AffineEnvironment.transform 5 0 env26942 = env26943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env26942 == env26943) = true)

def env26944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254784,25265169,145662400,525568,140903597,27337993,25733062]

theorem envBound26944 : H12AffineFastState.Bounded env26944 := by
  intro p hp
  have h : env26944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26150_26944 : H12AffineEnvironment.transform 25 65 env26150 = env26944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env26150 == env26944) = true)

def env26945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356288,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound26945 : H12AffineFastState.Bounded env26945 := by
  intro p hp
  have h : env26945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26944_26945 : H12AffineEnvironment.transform 26 30393344 env26944 = env26945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env26944 == env26945) = true)

def env26946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound26946 : H12AffineFastState.Bounded env26946 := by
  intro p hp
  have h : env26946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26945_26946 : H12AffineEnvironment.transform 18 1024 env26945 = env26946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env26945 == env26946) = true)

theorem identity26946 : scanCanonicalize (H12AffineFastState.compose env26946 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 510122) := by decide +kernel

theorem selectedBound26946 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,510122,16777216,8328,65,20973738,18973837,2596346,67754,17190075,23160256,256,19270663,19328419,17263468]

theorem envBound26947 : H12AffineFastState.Bounded env26947 := by
  intro p hp
  have h : env26947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26946_26947 : H12AffineEnvironment.transform 22 510122 env26946 = env26947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 510122 env26946 == env26947) = true)

def env26948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,510122,16777216,8328,65,16959642,18973837,2596346,67754,17190075,19113456,256,19270663,19328419,17263468]

theorem envBound26948 : H12AffineFastState.Bounded env26948 := by
  intro p hp
  have h : env26948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26947_26948 : H12AffineEnvironment.transform 21 180272 env26947 = env26948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env26947 == env26948) = true)

def env26949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,510122,499128,8328,65,349474,2496821,2596346,67754,119043,2373704,256,2199999,2191387,63188]

theorem envBound26949 : H12AffineFastState.Bounded env26949 := by
  intro p hp
  have h : env26949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26948_26949 : H12AffineEnvironment.transform 23 499128 env26948 = env26949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499128 env26948 == env26949) = true)

def env26950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,510122,499128,8328,65,349474,395637,495034,67754,119043,272392,256,98815,90203,63188]

theorem envBound26950 : H12AffineFastState.Bounded env26950 := by
  intro p hp
  have h : env26950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26949_26950 : H12AffineEnvironment.transform 20 4160 env26949 = env26950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env26949 == env26950) = true)

theorem identity26950 : scanCanonicalize (H12AffineFastState.compose env26950 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound26950 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,4160,180272,62661,41431,8328,65,158029,79130,45525,67754,119043,201831,256,98815,90203,63188]

theorem envBound26951 : H12AffineFastState.Bounded env26951 := by
  intro p hp
  have h : env26951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26950_26951 : H12AffineEnvironment.transform 17 212079 env26950 = env26951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env26950 == env26951) = true)

theorem identity26951 : scanCanonicalize (H12AffineFastState.compose env26951 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound26951 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env26952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,212079,1024,29908,4160,144613,16,21762,8328,65,158029,79130,17664,67754,75222,201831,256,95530,90203,513]

theorem envBound26952 : H12AffineFastState.Bounded env26952 := by
  intro p hp
  have h : env26952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26951_26952 : H12AffineEnvironment.transform 14 29909 env26951 = env26952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env26951 == env26952) = true)

theorem identity26952 : scanCanonicalize (H12AffineFastState.compose env26952 (packedSelected [4,9,11,14,17,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound26952 : packedSelected [4,9,11,14,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env26953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,343,131072,146744,1024,29908,4160,144613,16,21762,8328,65,158029,13389,17664,2557,9345,136496,256,29821,24844,513]

theorem envBound26953 : H12AffineFastState.Bounded env26953 := by
  intro p hp
  have h : env26953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26952_26953 : H12AffineEnvironment.transform 15 343 env26952 = env26953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env26952 == env26953) = true)

theorem identity26953 : scanCanonicalize (H12AffineFastState.compose env26953 (packedSelected [4,5,8,9,10,14,15,17,18,20,23,24,26,28,38] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound26953 : packedSelected [4,5,8,9,10,14,15,17,18,20,23,24,26,28,38] rootPS < 2^1333 := by decide +kernel

def env26954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,343,16537,32161,1024,29908,4160,29820,16,21762,8328,65,10708,13389,17664,2557,9345,21929,256,29821,24844,513]

theorem envBound26954 : H12AffineFastState.Bounded env26954 := by
  intro p hp
  have h : env26954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26953_26954 : H12AffineEnvironment.transform 16 16537 env26953 = env26954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env26953 == env26954) = true)

theorem identity26954 : scanCanonicalize (H12AffineFastState.compose env26954 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26954 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env26955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,343,16400,32040,1024,29789,4160,29820,16,21762,8193,65,10589,13389,17664,2420,9224,21792,256,29821,24844,513]

theorem envBound26955 : H12AffineFastState.Bounded env26955 := by
  intro p hp
  have h : env26955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26954_26955 : H12AffineEnvironment.transform 6 9 env26954 = env26955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26954 == env26955) = true)

theorem identity26955 : scanCanonicalize (H12AffineFastState.compose env26955 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26955 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26956 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,263,16400,32040,1024,29709,4112,29740,16,21762,8193,17,10509,13341,17664,2340,9224,21792,256,29741,24844,513]

theorem envBound26956 : H12AffineFastState.Bounded env26956 := by
  intro p hp
  have h : env26956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26955_26956 : H12AffineEnvironment.transform 5 16 env26955 = env26956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26955 == env26956) = true)

theorem identity26956 : scanCanonicalize (H12AffineFastState.compose env26956 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound26956 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26957 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,0,263,13340,2340,1024,1,4112,32,16,8462,8193,17,10509,13341,12556,2340,9224,8492,256,33,5376,513]

theorem envBound26957 : H12AffineFastState.Bounded env26957 := by
  intro p hp
  have h : env26957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26956_26957 : H12AffineEnvironment.transform 13 13324 env26956 = env26957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env26956 == env26957) = true)

theorem identity26957 : scanCanonicalize (H12AffineFastState.compose env26957 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound26957 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26958 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,263,5392,2340,1024,1,4112,32,16,2,269,17,2049,5393,4096,2340,1284,32,256,33,5376,513]

theorem envBound26958 : H12AffineFastState.Bounded env26958 := by
  intro p hp
  have h : env26958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26957_26958 : H12AffineEnvironment.transform 12 268 env26957 = env26958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env26957 == env26958) = true)

theorem identity26958 : scanCanonicalize (H12AffineFastState.compose env26958 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound26958 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26959 : List Nat := [2,4,8,16,32,16,9,53,512,1024,2048,4096,57,5173,0,50,5157,2065,1024,1,4112,32,16,2,56,17,2049,5156,4096,2065,1073,32,53,33,5173,513]

theorem envBound26959 : H12AffineFastState.Bounded env26959 := by
  intro p hp
  have h : env26959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26958_26959 : H12AffineEnvironment.transform 7 53 env26958 = env26959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env26958 == env26959) = true)

theorem identity26959 : scanCanonicalize (H12AffineFastState.compose env26959 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3119) := by decide +kernel

theorem selectedBound26959 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26960 : List Nat := [2,4,8,16,32,16,9,53,512,1024,2048,3119,57,2074,0,50,2058,2065,1024,1,3135,32,16,2,56,17,2049,2059,3119,2065,1073,32,53,33,2074,513]

theorem envBound26960 : H12AffineFastState.Bounded env26960 := by
  intro p hp
  have h : env26960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26959_26960 : H12AffineEnvironment.transform 11 3119 env26959 = env26960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3119 env26959 == env26960) = true)

theorem identity26960 : scanCanonicalize (H12AffineFastState.compose env26960 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound26960 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26961 : List Nat := [2,4,8,16,32,16,9,53,512,1024,1038,33,57,1044,0,50,1028,1055,1024,1,49,32,16,2,56,17,1039,1029,33,1055,1073,32,53,33,1044,513]

theorem envBound26961 : H12AffineFastState.Bounded env26961 := by
  intro p hp
  have h : env26961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26960_26961 : H12AffineEnvironment.transform 10 1038 env26960 = env26961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env26960 == env26961) = true)

theorem identity26961 : scanCanonicalize (H12AffineFastState.compose env26961 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound26961 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26962 : List Nat := [2,4,8,16,32,16,9,53,512,46,32,33,57,58,0,50,42,49,46,1,49,32,16,2,56,17,33,43,33,49,31,32,53,33,58,513]

theorem envBound26962 : H12AffineFastState.Bounded env26962 := by
  intro p hp
  have h : env26962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26961_26962 : H12AffineEnvironment.transform 9 46 env26961 = env26962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env26961 == env26962) = true)

theorem identity26962 : scanCanonicalize (H12AffineFastState.compose env26962 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26962 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env26963 : List Nat := [2,4,8,10,32,10,9,47,512,46,32,33,35,32,0,40,42,43,46,1,43,32,10,2,34,11,33,43,33,43,5,32,47,33,32,513]

theorem envBound26963 : H12AffineFastState.Bounded env26963 := by
  intro p hp
  have h : env26963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26962_26963 : H12AffineEnvironment.transform 3 10 env26962 = env26963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26962 == env26963) = true)

theorem identity26963 : scanCanonicalize (H12AffineFastState.compose env26963 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound26963 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26964 : List Nat := [2,4,8,10,32,10,9,47,12,46,32,33,35,32,0,40,42,43,46,1,43,32,10,2,34,11,33,43,33,43,5,32,47,33,32,13]

theorem envBound26964 : H12AffineFastState.Bounded env26964 := by
  intro p hp
  have h : env26964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26963_26964 : H12AffineEnvironment.transform 8 12 env26963 = env26964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env26963 == env26964) = true)

def env26965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,510122,499128,8328,65,349474,395636,495035,67754,119043,272393,256,98814,90202,63188]

theorem envBound26965 : H12AffineFastState.Bounded env26965 := by
  intro p hp
  have h : env26965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26949_26965 : H12AffineEnvironment.transform 20 4161 env26949 = env26965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env26949 == env26965) = true)

theorem identity26965 : scanCanonicalize (H12AffineFastState.compose env26965 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound26965 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4161,180272,400500,412006,8328,65,295420,395636,416101,56436,1501,272393,256,21792,46212,63188]

theorem envBound26966 : H12AffineFastState.Bounded env26966 := by
  intro p hp
  have h : env26966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26965_26966 : H12AffineEnvironment.transform 15 54494 env26965 = env26966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env26965 == env26966) = true)

def env26967 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,180272,400500,412006,8192,65,295284,395636,416101,56436,1365,272393,256,21792,46092,63068]

theorem envBound26967 : H12AffineFastState.Bounded env26967 := by
  intro p hp
  have h : env26967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26966_26967 : H12AffineEnvironment.transform 6 8 env26966 = env26967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26966 == env26967) = true)

theorem identity26967 : scanCanonicalize (H12AffineFastState.compose env26967 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 171280) := by decide +kernel

theorem selectedBound26967 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env26968 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,171280,1024,32769,4161,180272,33124,54390,8192,65,138340,37988,50293,56436,1365,177433,256,21792,46092,63068]

theorem envBound26968 : H12AffineFastState.Bounded env26968 := by
  intro p hp
  have h : env26968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26967_26968 : H12AffineEnvironment.transform 17 171280 env26967 = env26968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171280 env26967 == env26968) = true)

theorem identity26968 : scanCanonicalize (H12AffineFastState.compose env26968 (packedSelected [2,3,4,6,7,10,11,14,16,17,20,22,23,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound26968 : packedSelected [2,3,4,6,7,10,11,14,16,17,20,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,262,131072,149568,1024,21841,4161,136544,21556,294,8192,65,138340,16692,4389,2340,1365,155721,256,21792,24924,8972]

theorem envBound26969 : H12AffineFastState.Bounded env26969 := by
  intro p hp
  have h : env26969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26968_26969 : H12AffineEnvironment.transform 14 21840 env26968 = env26969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env26968 == env26969) = true)

theorem identity26969 : scanCanonicalize (H12AffineFastState.compose env26969 (packedSelected [2,4,6,11,17,18,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16692) := by decide +kernel

theorem selectedBound26969 : packedSelected [2,4,6,11,17,18,20,22] rootPS < 2^1333 := by decide +kernel

def env26970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,262,16692,2420,1024,21841,4161,21588,21556,294,8192,65,23888,16692,4389,2340,1365,8573,256,21792,24924,8972]

theorem envBound26970 : H12AffineFastState.Bounded env26970 := by
  intro p hp
  have h : env26970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26969_26970 : H12AffineEnvironment.transform 16 16692 env26969 = env26970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16692 env26969 == env26970) = true)

theorem identity26970 : scanCanonicalize (H12AffineFastState.compose env26970 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound26970 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env26971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21840,262,16692,2420,1024,21841,4161,21588,21556,294,120,65,23888,16692,4389,2340,1365,261,256,21792,16676,884]

theorem envBound26971 : H12AffineFastState.Bounded env26971 := by
  intro p hp
  have h : env26971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26970_26971 : H12AffineEnvironment.transform 12 120 env26970 = env26971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env26970 == env26971) = true)

theorem identity26971 : scanCanonicalize (H12AffineFastState.compose env26971 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound26971 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env26972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5236,292,262,5440,2420,1024,293,4161,32,64,294,120,65,2340,5440,4389,2340,1365,261,256,340,5456,884]

theorem envBound26972 : H12AffineFastState.Bounded env26972 := by
  intro p hp
  have h : env26972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26971_26972 : H12AffineEnvironment.transform 13 5236 env26971 = env26972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env26971 == env26972) = true)

theorem identity26972 : scanCanonicalize (H12AffineFastState.compose env26972 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26972 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env26973 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,5236,0,34,5220,2128,1024,1,4161,32,64,2,120,65,2048,5220,4097,2048,1137,33,36,112,5236,592]

theorem envBound26973 : H12AffineFastState.Bounded env26973 := by
  intro p hp
  have h : env26973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26972_26973 : H12AffineEnvironment.transform 7 36 env26972 = env26973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26972 == env26973) = true)

theorem identity26973 : scanCanonicalize (H12AffineFastState.compose env26973 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26973 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26974 : List Nat := [2,4,8,16,0,64,8,4,512,1024,2048,4096,88,5204,0,2,5188,2128,1024,1,4161,0,64,2,88,65,2048,5188,4097,2048,1105,1,4,80,5204,592]

theorem envBound26974 : H12AffineFastState.Bounded env26974 := by
  intro p hp
  have h : env26974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26973_26974 : H12AffineEnvironment.transform 4 0 env26973 = env26974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26973 == env26974) = true)

theorem identity26974 : scanCanonicalize (H12AffineFastState.compose env26974 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26974 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26975 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,8,5124,0,2,5140,2048,1024,1,4113,0,16,2,8,17,2048,5140,4097,2048,1025,1,4,0,5124,512]

theorem envBound26975 : H12AffineFastState.Bounded env26975 := by
  intro p hp
  have h : env26975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26974_26975 : H12AffineEnvironment.transform 5 16 env26974 = env26975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26974 == env26975) = true)

theorem identity26975 : scanCanonicalize (H12AffineFastState.compose env26975 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound26975 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26976 : List Nat := [2,4,8,16,0,16,8,4,512,21,2048,4096,8,4113,0,2,4097,2048,21,1,4113,0,16,2,8,17,2048,4097,4097,2048,20,1,4,0,4113,512]

theorem envBound26976 : H12AffineFastState.Bounded env26976 := by
  intro p hp
  have h : env26976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26975_26976 : H12AffineEnvironment.transform 9 21 env26975 = env26976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env26975 == env26976) = true)

theorem identity26976 : scanCanonicalize (H12AffineFastState.compose env26976 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound26976 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26977 : List Nat := [2,4,8,16,0,16,8,4,512,21,20,4096,8,4113,0,2,4097,20,21,1,4113,0,16,2,8,17,20,4097,4097,20,20,1,4,0,4113,512]

theorem envBound26977 : H12AffineFastState.Bounded env26977 := by
  intro p hp
  have h : env26977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26976_26977 : H12AffineEnvironment.transform 10 20 env26976 = env26977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env26976 == env26977) = true)

theorem identity26977 : scanCanonicalize (H12AffineFastState.compose env26977 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 18) := by decide +kernel

theorem selectedBound26977 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26978 : List Nat := [2,4,8,16,0,16,8,4,512,21,20,18,8,3,0,2,19,20,21,1,3,0,16,2,8,17,20,19,19,20,20,1,4,0,3,512]

theorem envBound26978 : H12AffineFastState.Bounded env26978 := by
  intro p hp
  have h : env26978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26977_26978 : H12AffineEnvironment.transform 11 18 env26977 = env26978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 18 env26977 == env26978) = true)

theorem identity26978 : scanCanonicalize (H12AffineFastState.compose env26978 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound26978 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26979 : List Nat := [2,4,8,16,0,16,8,4,30,21,20,18,8,3,0,2,19,20,21,1,3,0,16,2,8,17,20,19,19,20,20,1,4,0,3,30]

theorem envBound26979 : H12AffineFastState.Bounded env26979 := by
  intro p hp
  have h : env26979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26978_26979 : H12AffineEnvironment.transform 8 30 env26978 = env26979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env26978 == env26979) = true)

theorem identity26979 : scanCanonicalize (H12AffineFastState.compose env26979 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound26979 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26980 : List Nat := [2,4,8,7,0,7,8,4,9,2,3,5,8,3,0,2,4,3,2,1,3,0,7,2,8,6,3,4,4,3,3,1,4,0,3,9]

theorem envBound26980 : H12AffineFastState.Bounded env26980 := by
  intro p hp
  have h : env26980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26979_26980 : H12AffineEnvironment.transform 3 7 env26979 = env26980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env26979 == env26980) = true)

def env26981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,180272,400500,412006,8193,65,295285,395636,416101,56436,1364,272393,256,21792,46093,63069]

theorem envBound26981 : H12AffineFastState.Bounded env26981 := by
  intro p hp
  have h : env26981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26966_26981 : H12AffineEnvironment.transform 6 9 env26966 = env26981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26966 == env26981) = true)

theorem identity26981 : scanCanonicalize (H12AffineFastState.compose env26981 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 182629) := by decide +kernel

theorem selectedBound26981 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env26982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,182629,1024,32769,4161,180272,54545,32771,8193,65,149520,49169,36864,56436,1364,188780,256,21792,46093,63069]

theorem envBound26982 : H12AffineFastState.Bounded env26982 := by
  intro p hp
  have h : env26982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26981_26982 : H12AffineEnvironment.transform 17 182629 env26981 = env26982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182629 env26981 == env26982) = true)

theorem identity26982 : scanCanonicalize (H12AffineFastState.compose env26982 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound26982 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env26983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,146745,1024,29789,4161,144492,8525,29791,8193,65,149520,13389,25692,10280,1364,136496,256,21792,16465,513]

theorem envBound26983 : H12AffineFastState.Bounded env26983 := by
  intro p hp
  have h : env26983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26982_26983 : H12AffineEnvironment.transform 14 29788 env26982 = env26983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env26982 == env26983) = true)

theorem identity26983 : scanCanonicalize (H12AffineFastState.compose env26983 (packedSelected [0,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound26983 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env26984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,131072,146745,1024,8540,4161,144492,8525,8542,8193,65,138513,13389,12637,10280,1364,136496,256,33,5456,513]

theorem envBound26984 : H12AffineFastState.Bounded env26984 := by
  intro p hp
  have h : env26984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26983_26984 : H12AffineEnvironment.transform 13 5377 env26983 = env26984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26983 == env26984) = true)

theorem identity26984 : scanCanonicalize (H12AffineFastState.compose env26984 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound26984 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env26985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,13388,2421,1024,8540,4161,32,8525,8542,8193,65,10589,13389,12637,10280,1364,8572,256,33,5456,513]

theorem envBound26985 : H12AffineFastState.Bounded env26985 := by
  intro p hp
  have h : env26985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26984_26985 : H12AffineEnvironment.transform 16 13388 env26984 = env26985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env26984 == env26985) = true)

theorem identity26985 : scanCanonicalize (H12AffineFastState.compose env26985 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26985 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26986 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,343,5392,2421,1024,0,4161,32,17,2,349,65,2049,5393,4097,2420,1364,32,256,33,5456,513]

theorem envBound26986 : H12AffineFastState.Bounded env26986 := by
  intro p hp
  have h : env26986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26985_26986 : H12AffineEnvironment.transform 12 348 env26985 = env26986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26985 == env26986) = true)

theorem identity26986 : scanCanonicalize (H12AffineFastState.compose env26986 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound26986 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26987 : List Nat := [2,4,8,16,32,64,9,256,293,1024,2048,4096,348,5377,1,343,5392,2421,1024,0,4161,32,17,2,349,65,2049,5393,4097,2420,1364,32,256,33,5456,292]

theorem envBound26987 : H12AffineFastState.Bounded env26987 := by
  intro p hp
  have h : env26987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26986_26987 : H12AffineEnvironment.transform 8 293 env26986 = env26987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env26986 == env26987) = true)

theorem identity26987 : scanCanonicalize (H12AffineFastState.compose env26987 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26987 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26988 : List Nat := [2,4,8,16,32,16,9,256,293,1024,2048,4096,268,5377,1,263,5392,2341,1024,0,4113,32,17,2,269,17,2049,5393,4097,2340,1284,32,256,33,5376,292]

theorem envBound26988 : H12AffineFastState.Bounded env26988 := by
  intro p hp
  have h : env26988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26987_26988 : H12AffineEnvironment.transform 5 16 env26987 = env26988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26987 == env26988) = true)

theorem identity26988 : scanCanonicalize (H12AffineFastState.compose env26988 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26988 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26989 : List Nat := [2,4,8,16,17,16,9,256,276,1024,2048,4096,268,5377,1,263,5392,2324,1024,0,4113,17,17,2,269,17,2049,5393,4097,2325,1284,17,256,16,5376,277]

theorem envBound26989 : H12AffineFastState.Bounded env26989 := by
  intro p hp
  have h : env26989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26988_26989 : H12AffineEnvironment.transform 4 17 env26988 = env26989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26988 == env26989) = true)

theorem identity26989 : scanCanonicalize (H12AffineFastState.compose env26989 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2309) := by decide +kernel

theorem selectedBound26989 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26990 : List Nat := [2,4,8,16,17,16,9,256,276,1024,2048,2309,268,3076,1,263,3093,2324,1024,0,2324,17,17,2,269,17,2049,3092,2308,2325,1284,17,256,16,3077,277]

theorem envBound26990 : H12AffineFastState.Bounded env26990 := by
  intro p hp
  have h : env26990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26989_26990 : H12AffineEnvironment.transform 11 2309 env26989 = env26990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2309 env26989 == env26990) = true)

theorem identity26990 : scanCanonicalize (H12AffineFastState.compose env26990 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26990 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26991 : List Nat := [2,4,8,1,0,1,9,256,261,1024,2048,2309,268,3076,1,263,3076,2309,1024,0,2309,0,0,2,269,0,2049,3077,2308,2308,1284,0,256,1,3077,260]

theorem envBound26991 : H12AffineFastState.Bounded env26991 := by
  intro p hp
  have h : env26991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26990_26991 : H12AffineEnvironment.transform 3 1 env26990 = env26991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26990 == env26991) = true)

theorem identity26991 : scanCanonicalize (H12AffineFastState.compose env26991 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound26991 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26992 : List Nat := [2,4,8,1,0,1,9,256,261,1024,261,0,268,1281,1,263,1281,0,1024,0,0,0,0,2,269,0,260,1280,1,1,1284,0,256,1,1280,260]

theorem envBound26992 : H12AffineFastState.Bounded env26992 := by
  intro p hp
  have h : env26992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26991_26992 : H12AffineEnvironment.transform 10 261 env26991 = env26992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env26991 == env26992) = true)

theorem identity26992 : scanCanonicalize (H12AffineFastState.compose env26992 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound26992 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env26993 : List Nat := [2,4,8,1,0,1,9,4,1,1024,1,0,8,1029,1,3,1029,0,1024,0,0,0,0,2,9,0,0,1028,1,1,1024,0,4,1,1028,0]

theorem envBound26993 : H12AffineFastState.Bounded env26993 := by
  intro p hp
  have h : env26993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26992_26993 : H12AffineEnvironment.transform 7 4 env26992 = env26993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env26992 == env26993) = true)

theorem identity26993 : scanCanonicalize (H12AffineFastState.compose env26993 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound26993 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26994 : List Nat := [2,4,8,1,0,1,9,4,1,5,1,0,8,0,1,3,0,0,5,0,0,0,0,2,9,0,0,1,1,1,5,0,4,1,1,0]

theorem envBound26994 : H12AffineFastState.Bounded env26994 := by
  intro p hp
  have h : env26994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26993_26994 : H12AffineEnvironment.transform 9 5 env26993 = env26994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env26993 == env26994) = true)

theorem identity26994 : scanCanonicalize (H12AffineFastState.compose env26994 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound26994 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26995 : List Nat := [2,4,3,1,0,1,2,4,1,5,1,0,3,0,1,3,0,0,5,0,0,0,0,2,2,0,0,1,1,1,5,0,4,1,1,0]

theorem envBound26995 : H12AffineFastState.Bounded env26995 := by
  intro p hp
  have h : env26995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26994_26995 : H12AffineEnvironment.transform 2 3 env26994 = env26995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env26994 == env26995) = true)

def env26996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,510122,499129,8328,65,349475,2496820,2596346,67754,119042,2373705,256,2199998,2191386,63189]

theorem envBound26996 : H12AffineFastState.Bounded env26996 := by
  intro p hp
  have h : env26996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26948_26996 : H12AffineEnvironment.transform 23 499129 env26948 = env26996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499129 env26948 == env26996) = true)

def env26997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,510122,499129,8328,65,349475,395636,495034,67754,119042,272393,256,98814,90202,63189]

theorem envBound26997 : H12AffineFastState.Bounded env26997 := by
  intro p hp
  have h : env26997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26996_26997 : H12AffineEnvironment.transform 20 4160 env26996 = env26997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env26996 == env26997) = true)

theorem identity26997 : scanCanonicalize (H12AffineFastState.compose env26997 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26997 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4160,180272,452769,441778,8328,65,292136,395636,437681,10401,61705,272393,256,41461,16465,63189]

theorem envBound26998 : H12AffineFastState.Bounded env26998 := by
  intro p hp
  have h : env26998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26997_26998 : H12AffineEnvironment.transform 15 8203 env26997 = env26998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26997 == env26998) = true)

theorem identity26998 : scanCanonicalize (H12AffineFastState.compose env26998 (packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound26998 : packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env26999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,146744,1024,32769,4160,180272,54681,32906,8328,65,149520,13388,37001,10401,61705,136497,256,41461,16465,63189]

theorem envBound26999 : H12AffineFastState.Bounded env26999 := by
  intro p hp
  have h : env26999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26998_26999 : H12AffineEnvironment.transform 17 146744 env26998 = env26999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env26998 == env26999) = true)

theorem identity26999 : scanCanonicalize (H12AffineFastState.compose env26999 (packedSelected [0,5,8,9,11,17,18,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound26999 : packedSelected [0,5,8,9,11,17,18,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env27000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8203,131072,146744,1024,1,4160,147504,21913,138,8328,65,149520,13388,4233,10401,28937,136497,256,8693,16465,30421]

theorem envBound27000 : H12AffineFastState.Bounded env27000 := by
  intro p hp
  have h : env27000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26999_27000 : H12AffineEnvironment.transform 14 0 env26999 = env27000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env26999 == env27000) = true)

theorem identity27000 : scanCanonicalize (H12AffineFastState.compose env27000 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound27000 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env27001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8203,24909,23669,1024,1,4160,8573,21913,138,8328,65,10589,13388,4233,10401,28937,29820,256,8693,16465,30421]

theorem envBound27001 : H12AffineFastState.Bounded env27001 := by
  intro p hp
  have h : env27001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27000_27001 : H12AffineEnvironment.transform 16 24909 env27000 = env27001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env27000 == env27001) = true)

theorem identity27001 : scanCanonicalize (H12AffineFastState.compose env27001 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound27001 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env27002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,0,8203,5529,10401,1024,1,4160,8573,8525,138,8328,65,10589,13388,4233,10401,1501,168,256,8693,13445,513]

theorem envBound27002 : H12AffineFastState.Bounded env27002 := by
  intro p hp
  have h : env27002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27001_27002 : H12AffineEnvironment.transform 13 13524 env27001 = env27002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env27001 == env27002) = true)

theorem identity27002 : scanCanonicalize (H12AffineFastState.compose env27002 (packedSelected [1,3,4,5,8,9,12,23] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27002 : packedSelected [1,3,4,5,8,9,12,23] rootPS < 2^1333 := by decide +kernel

def env27003 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,8203,5392,10280,1024,1,4160,8573,8525,3,8193,65,10589,13388,4096,10280,1364,33,256,8572,13324,513]

theorem envBound27003 : H12AffineFastState.Bounded env27003 := by
  intro p hp
  have h : env27003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27002_27003 : H12AffineEnvironment.transform 6 9 env27002 = env27003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27002 == env27003) = true)

theorem identity27003 : scanCanonicalize (H12AffineFastState.compose env27003 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27003 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27004 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,5392,2421,1024,1,4160,32,16,3,348,65,2048,5393,4096,2421,1364,33,256,33,5457,513]

theorem envBound27004 : H12AffineFastState.Bounded env27004 := by
  intro p hp
  have h : env27004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27003_27004 : H12AffineEnvironment.transform 12 349 env27003 = env27004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27003 == env27004) = true)

theorem identity27004 : scanCanonicalize (H12AffineFastState.compose env27004 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1135) := by decide +kernel

theorem selectedBound27004 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27005 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1135,4096,349,5376,0,342,5392,1306,1024,1,4160,32,16,3,348,65,1135,5393,4096,1306,1364,33,256,33,5457,513]

theorem envBound27005 : H12AffineFastState.Bounded env27005 := by
  intro p hp
  have h : env27005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27004_27005 : H12AffineEnvironment.transform 10 1135 env27004 = env27005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1135 env27004 == env27005) = true)

def env27006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,510122,499129,8328,65,349475,395637,495035,67754,119042,272392,256,98815,90203,63189]

theorem envBound27006 : H12AffineFastState.Bounded env27006 := by
  intro p hp
  have h : env27006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26996_27006 : H12AffineEnvironment.transform 20 4161 env26996 = env27006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env26996 == env27006) = true)

theorem identity27006 : scanCanonicalize (H12AffineFastState.compose env27006 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247994) := by decide +kernel

theorem selectedBound27006 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,180272,16,21763,8328,65,171417,115151,17665,67754,119042,254130,256,98815,90203,63189]

theorem envBound27007 : H12AffineFastState.Bounded env27007 := by
  intro p hp
  have h : env27007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27006_27007 : H12AffineEnvironment.transform 17 247994 env27006 = env27007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247994 env27006 == env27007) = true)

def env27008 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,180272,16,21763,8192,65,171281,115015,17665,67618,119042,254010,256,98679,90203,63069]

theorem envBound27008 : H12AffineFastState.Bounded env27008 := by
  intro p hp
  have h : env27008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27007_27008 : H12AffineEnvironment.transform 6 8 env27007 = env27008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27007 == env27008) = true)

theorem identity27008 : scanCanonicalize (H12AffineFastState.compose env27008 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound27008 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27009 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,32041,1024,32769,4161,95531,16,21763,8192,65,75786,115015,17665,67618,119042,21793,256,98679,90203,63069]

theorem envBound27009 : H12AffineFastState.Bounded env27009 := by
  intro p hp
  have h : env27009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27008_27009 : H12AffineEnvironment.transform 16 111899 env27008 = env27009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env27008 == env27009) = true)

theorem identity27009 : scanCanonicalize (H12AffineFastState.compose env27009 (packedSelected [0,1,3,4,7,18,19,22,23,24,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound27009 : packedSelected [0,1,3,4,7,18,19,22,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env27010 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,342,46157,32041,1024,32769,4161,29821,16,21763,8192,65,10588,49169,17665,2420,53332,21793,256,32801,24845,63069]

theorem envBound27010 : H12AffineFastState.Bounded env27010 := by
  intro p hp
  have h : env27010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27009_27010 : H12AffineEnvironment.transform 15 342 env27009 = env27010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env27009 == env27010) = true)

theorem identity27010 : scanCanonicalize (H12AffineFastState.compose env27010 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound27010 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env27011 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,373,342,13624,32041,1024,372,4161,29821,16,21763,8192,65,10588,16740,17665,2420,20769,21793,256,340,24845,30504]

theorem envBound27011 : H12AffineFastState.Bounded env27011 := by
  intro p hp
  have h : env27011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27010_27011 : H12AffineEnvironment.transform 14 373 env27010 = env27011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env27010 == env27011) = true)

theorem identity27011 : scanCanonicalize (H12AffineFastState.compose env27011 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound27011 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env27012 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,373,342,13624,10589,1024,372,4161,8201,16,375,8192,65,10588,5392,4469,2420,1365,341,256,340,13689,9052]

theorem envBound27012 : H12AffineFastState.Bounded env27012 := by
  intro p hp
  have h : env27012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27011_27012 : H12AffineEnvironment.transform 13 5236 env27011 = env27012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env27011 == env27012) = true)

theorem identity27012 : scanCanonicalize (H12AffineFastState.compose env27012 (packedSelected [12] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27012 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env27013 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4452,373,342,12328,10589,272,372,4161,8201,16,375,8192,65,10588,4096,4469,2420,69,341,256,340,12393,9052]

theorem envBound27013 : H12AffineFastState.Bounded env27013 := by
  intro p hp
  have h : env27013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27012_27013 : H12AffineEnvironment.transform 9 272 env27012 = env27013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27012 == env27013) = true)

theorem identity27013 : scanCanonicalize (H12AffineFastState.compose env27013 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound27013 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env27014 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,8192,4112,1,34,12328,10281,100,0,4161,8201,16,3,8192,65,10280,4096,4097,2048,69,33,116,32,12393,8744]

theorem envBound27014 : H12AffineFastState.Bounded env27014 := by
  intro p hp
  have h : env27014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27013_27014 : H12AffineEnvironment.transform 7 116 env27013 = env27014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env27013 == env27014) = true)

theorem identity27014 : scanCanonicalize (H12AffineFastState.compose env27014 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound27014 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27015 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,2089,4112,1,34,6145,0,100,0,4161,2080,16,3,2089,65,1,4096,4097,2048,69,33,116,32,6208,2561]

theorem envBound27015 : H12AffineFastState.Bounded env27015 := by
  intro p hp
  have h : env27015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27014_27015 : H12AffineEnvironment.transform 12 2089 env27014 = env27015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env27014 == env27015) = true)

theorem identity27015 : scanCanonicalize (H12AffineFastState.compose env27015 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound27015 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env27016 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,2113,2089,2129,1,34,64,0,100,0,2048,2080,16,3,2089,65,1,2113,2112,2048,69,33,116,32,1,2561]

theorem envBound27016 : H12AffineFastState.Bounded env27016 := by
  intro p hp
  have h : env27016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27015_27016 : H12AffineEnvironment.transform 11 2113 env27015 = env27016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env27015 == env27016) = true)

theorem identity27016 : scanCanonicalize (H12AffineFastState.compose env27016 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound27016 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27017 : List Nat := [2,4,8,16,32,64,8,116,512,100,0,65,41,81,1,34,64,0,100,0,0,32,16,3,41,65,1,65,64,0,69,33,116,32,1,513]

theorem envBound27017 : H12AffineFastState.Bounded env27017 := by
  intro p hp
  have h : env27017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27016_27017 : H12AffineEnvironment.transform 10 0 env27016 = env27017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env27016 == env27017) = true)

theorem identity27017 : scanCanonicalize (H12AffineFastState.compose env27017 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound27017 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27018 : List Nat := [2,4,8,16,32,64,8,116,80,100,0,65,41,81,1,34,64,0,100,0,0,32,16,3,41,65,1,65,64,0,69,33,116,32,1,81]

theorem envBound27018 : H12AffineFastState.Bounded env27018 := by
  intro p hp
  have h : env27018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27017_27018 : H12AffineEnvironment.transform 8 80 env27017 = env27018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env27017 == env27018) = true)

theorem identity27018 : scanCanonicalize (H12AffineFastState.compose env27018 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27018 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27019 : List Nat := [2,4,3,16,32,64,3,116,80,100,0,65,34,81,1,34,64,0,100,0,0,32,16,3,34,65,1,65,64,0,69,33,116,32,1,81]

theorem envBound27019 : H12AffineFastState.Bounded env27019 := by
  intro p hp
  have h : env27019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27018_27019 : H12AffineEnvironment.transform 2 3 env27018 = env27019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27018 == env27019) = true)

theorem identity27019 : scanCanonicalize (H12AffineFastState.compose env27019 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27019 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27020 : List Nat := [2,4,3,16,32,16,3,36,0,52,0,17,34,1,1,34,16,0,52,0,0,32,16,3,34,17,1,17,16,0,21,33,36,32,1,1]

theorem envBound27020 : H12AffineFastState.Bounded env27020 := by
  intro p hp
  have h : env27020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27019_27020 : H12AffineEnvironment.transform 5 16 env27019 = env27020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27019 == env27020) = true)

def env27021 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,180272,16,21763,8193,65,171280,115014,17665,67619,119042,254011,256,98678,90203,63068]

theorem envBound27021 : H12AffineFastState.Bounded env27021 := by
  intro p hp
  have h : env27021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27007_27021 : H12AffineEnvironment.transform 6 9 env27007 = env27021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27007 == env27021) = true)

theorem identity27021 : scanCanonicalize (H12AffineFastState.compose env27021 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound27021 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27022 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,56437,1024,32769,4161,119926,16,21763,8193,65,100694,115014,17665,67619,119042,62589,256,98678,90203,63068]

theorem envBound27022 : H12AffineFastState.Bounded env27022 := by
  intro p hp
  have h : env27022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27021_27022 : H12AffineEnvironment.transform 16 70726 env27021 = env27022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env27021 == env27022) = true)

theorem identity27022 : scanCanonicalize (H12AffineFastState.compose env27022 (packedSelected [1,5,8,16,19,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound27022 : packedSelected [1,5,8,16,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env27023 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,57676,56437,1024,32769,4161,8572,16,21763,8193,65,31836,13388,17665,64809,9224,62589,256,29820,38225,63068]

theorem envBound27023 : H12AffineFastState.Bounded env27023 := by
  intro p hp
  have h : env27023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27022_27023 : H12AffineEnvironment.transform 15 62730 env27022 = env27023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env27022 == env27023) = true)

theorem identity27023 : scanCanonicalize (H12AffineFastState.compose env27023 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound27023 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env27024 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,41051,46109,35108,1024,32769,4161,8572,16,82,8193,65,10509,13388,4176,43128,9224,41260,256,8493,38225,41741]

theorem envBound27024 : H12AffineFastState.Bounded env27024 := by
  intro p hp
  have h : env27024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27023_27024 : H12AffineEnvironment.transform 13 5457 env27023 = env27024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env27023 == env27024) = true)

theorem identity27024 : scanCanonicalize (H12AffineFastState.compose env27024 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound27024 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27025 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8540,263,5441,10360,1024,8541,4161,8572,16,82,8193,65,10509,13388,4176,2340,9224,112,256,8493,13325,593]

theorem envBound27025 : H12AffineFastState.Bounded env27025 := by
  intro p hp
  have h : env27025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27024_27025 : H12AffineEnvironment.transform 14 8540 env27024 = env27025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env27024 == env27025) = true)

theorem identity27025 : scanCanonicalize (H12AffineFastState.compose env27025 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27025 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env27026 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5457,0,263,5441,2340,1024,1,4161,32,16,82,349,65,2129,5392,4176,2340,1364,112,256,113,5457,593]

theorem envBound27026 : H12AffineFastState.Bounded env27026 := by
  intro p hp
  have h : env27026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27025_27026 : H12AffineEnvironment.transform 12 348 env27025 = env27026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27025 == env27026) = true)

theorem identity27026 : scanCanonicalize (H12AffineFastState.compose env27026 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound27026 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env27027 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,348,4453,0,263,4469,2340,52,1,4161,32,16,82,349,65,2129,4388,4176,2340,352,112,256,113,4453,593]

theorem envBound27027 : H12AffineFastState.Bounded env27027 := by
  intro p hp
  have h : env27027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27026_27027 : H12AffineEnvironment.transform 9 52 env27026 = env27027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27026 == env27027) = true)

def env27028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,510122,16777216,8328,65,16959643,18973837,2596346,67754,17190075,19113457,256,19270663,19328419,17263468]

theorem envBound27028 : H12AffineFastState.Bounded env27028 := by
  intro p hp
  have h : env27028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26947_27028 : H12AffineEnvironment.transform 21 180273 env26947 = env27028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env26947 == env27028) = true)

def env27029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,510122,499128,8328,65,349475,2496821,2596346,67754,119043,2373705,256,2199999,2191387,63188]

theorem envBound27029 : H12AffineFastState.Bounded env27029 := by
  intro p hp
  have h : env27029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27028_27029 : H12AffineEnvironment.transform 23 499128 env27028 = env27029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499128 env27028 == env27029) = true)

def env27030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,510122,499128,8328,65,349475,395637,495034,67754,119043,272393,256,98815,90203,63188]

theorem envBound27030 : H12AffineFastState.Bounded env27030 := by
  intro p hp
  have h : env27030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27029_27030 : H12AffineEnvironment.transform 20 4160 env27029 = env27030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env27029 == env27030) = true)

theorem identity27030 : scanCanonicalize (H12AffineFastState.compose env27030 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound27030 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4160,144612,474239,485741,8328,65,349475,395637,489839,67754,75222,272393,256,95530,90203,513]

theorem envBound27031 : H12AffineFastState.Bounded env27031 := by
  intro p hp
  have h : env27031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27030_27031 : H12AffineEnvironment.transform 14 29909 env27030 = env27031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env27030 == env27031) = true)

def env27032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4160,144492,474239,485741,8192,65,349475,395637,489839,67618,75102,272393,256,95530,90203,513]

theorem envBound27032 : H12AffineFastState.Bounded env27032 := by
  intro p hp
  have h : env27032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27031_27032 : H12AffineEnvironment.transform 6 8 env27031 = env27032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27031 == env27032) = true)

theorem identity27032 : scanCanonicalize (H12AffineFastState.compose env27032 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound27032 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env27033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,262144,1024,29788,4160,87158,285797,264567,8192,65,349475,354671,268661,67618,75102,272393,256,95530,90203,513]

theorem envBound27033 : H12AffineFastState.Bounded env27033 := by
  intro p hp
  have h : env27033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27032_27033 : H12AffineEnvironment.transform 16 90138 env27032 = env27033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env27032 == env27033) = true)

theorem identity27033 : scanCanonicalize (H12AffineFastState.compose env27033 (packedSelected [0,4,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 3173) := by decide +kernel

theorem selectedBound27033 : packedSelected [0,4,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env27034 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,3173,1024,29788,4160,87158,20480,1298,8192,65,88390,91402,5392,67618,75102,9324,256,95530,90203,513]

theorem envBound27034 : H12AffineFastState.Bounded env27034 := by
  intro p hp
  have h : env27034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27033_27034 : H12AffineEnvironment.transform 17 3173 env27033 = env27034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3173 env27033 == env27034) = true)

theorem identity27034 : scanCanonicalize (H12AffineFastState.compose env27034 (packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound27034 : packedSelected [3,4,5,8,9,14,15,17,18,20,23,28,38] rootPS < 2^1333 := by decide +kernel

def env27035 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,79131,3173,1024,8541,4160,65911,1281,1298,8192,65,68679,77835,5392,67618,75102,9324,256,73771,79194,513]

theorem envBound27035 : H12AffineFastState.Bounded env27035 := by
  intro p hp
  have h : env27035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27034_27035 : H12AffineEnvironment.transform 13 5377 env27034 = env27035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env27034 == env27035) = true)

theorem identity27035 : scanCanonicalize (H12AffineFastState.compose env27035 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27035 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27036 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,5393,3173,1024,8541,4160,8573,1281,1298,8192,65,11341,4097,5392,10280,1364,9324,256,33,5456,513]

theorem envBound27036 : H12AffineFastState.Bounded env27036 := by
  intro p hp
  have h : env27036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27035_27036 : H12AffineEnvironment.transform 15 8202 env27035 = env27036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27035 == env27036) = true)

theorem identity27036 : scanCanonicalize (H12AffineFastState.compose env27036 (packedSelected [1,5,8,12,15,17,24] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound27036 : packedSelected [1,5,8,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env27037 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,4452,8540,8202,4468,2048,101,8541,4160,8573,356,375,8192,65,10280,4097,4469,10280,305,8201,256,33,4405,513]

theorem envBound27037 : H12AffineFastState.Bounded env27037 := by
  intro p hp
  have h : env27037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27036_27037 : H12AffineEnvironment.transform 9 101 env27036 = env27037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env27036 == env27037) = true)

theorem identity27037 : scanCanonicalize (H12AffineFastState.compose env27037 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound27037 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env27038 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,120,4452,292,114,4468,2048,101,293,4160,261,356,375,120,65,2128,4097,4469,2128,305,113,256,33,4405,513]

theorem envBound27038 : H12AffineFastState.Bounded env27038 := by
  intro p hp
  have h : env27038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27037_27038 : H12AffineEnvironment.transform 12 120 env27037 = env27038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env27037 == env27038) = true)

theorem identity27038 : scanCanonicalize (H12AffineFastState.compose env27038 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound27038 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env27039 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2064,120,2420,292,114,2404,2048,101,293,2128,261,356,375,120,65,2128,2065,2405,2128,305,113,256,33,2341,513]

theorem envBound27039 : H12AffineFastState.Bounded env27039 := by
  intro p hp
  have h : env27039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27038_27039 : H12AffineEnvironment.transform 11 2064 env27038 = env27039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env27038 == env27039) = true)

theorem identity27039 : scanCanonicalize (H12AffineFastState.compose env27039 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound27039 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env27040 : List Nat := [2,4,8,16,32,64,8,256,512,101,0,16,120,372,292,114,356,0,101,293,80,261,356,375,120,65,80,17,357,80,305,113,256,33,293,513]

theorem envBound27040 : H12AffineFastState.Bounded env27040 := by
  intro p hp
  have h : env27040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27039_27040 : H12AffineEnvironment.transform 10 0 env27039 = env27040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env27039 == env27040) = true)

theorem identity27040 : scanCanonicalize (H12AffineFastState.compose env27040 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound27040 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env27041 : List Nat := [2,4,8,16,32,64,8,116,512,101,0,16,120,0,80,114,16,0,101,81,80,113,16,3,120,65,80,17,17,80,69,113,116,33,81,513]

theorem envBound27041 : H12AffineFastState.Bounded env27041 := by
  intro p hp
  have h : env27041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27040_27041 : H12AffineEnvironment.transform 7 116 env27040 = env27041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env27040 == env27041) = true)

theorem identity27041 : scanCanonicalize (H12AffineFastState.compose env27041 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound27041 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27042 : List Nat := [2,4,8,16,32,33,8,21,512,4,0,16,25,0,49,19,16,0,4,48,49,16,16,3,25,32,49,17,17,49,36,16,21,33,48,513]

theorem envBound27042 : H12AffineFastState.Bounded env27042 := by
  intro p hp
  have h : env27042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27041_27042 : H12AffineEnvironment.transform 5 33 env27041 = env27042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env27041 == env27042) = true)

theorem identity27042 : scanCanonicalize (H12AffineFastState.compose env27042 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound27042 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27043 : List Nat := [2,4,8,16,32,33,8,21,48,4,0,16,25,0,49,19,16,0,4,48,49,16,16,3,25,32,49,17,17,49,36,16,21,33,48,49]

theorem envBound27043 : H12AffineFastState.Bounded env27043 := by
  intro p hp
  have h : env27043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27042_27043 : H12AffineEnvironment.transform 8 48 env27042 = env27043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env27042 == env27043) = true)

theorem identity27043 : scanCanonicalize (H12AffineFastState.compose env27043 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27043 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27044 : List Nat := [2,4,8,16,0,1,8,21,16,4,0,16,25,0,17,19,16,0,4,16,17,16,16,3,25,0,17,17,17,17,4,16,21,1,16,17]

theorem envBound27044 : H12AffineFastState.Bounded env27044 := by
  intro p hp
  have h : env27044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27043_27044 : H12AffineEnvironment.transform 4 0 env27043 = env27044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27043 == env27044) = true)

theorem identity27044 : scanCanonicalize (H12AffineFastState.compose env27044 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27044 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env27045 : List Nat := [2,4,8,0,0,1,8,5,0,4,0,0,9,0,1,3,0,0,4,0,1,0,0,3,9,0,1,1,1,1,4,0,5,1,0,1]

theorem envBound27045 : H12AffineFastState.Bounded env27045 := by
  intro p hp
  have h : env27045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27044_27045 : H12AffineEnvironment.transform 3 0 env27044 = env27045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27044 == env27045) = true)

def env27046 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4160,144493,474239,485741,8193,65,349475,395637,489839,67619,75103,272393,256,95530,90203,513]

theorem envBound27046 : H12AffineFastState.Bounded env27046 := by
  intro p hp
  have h : env27046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27031_27046 : H12AffineEnvironment.transform 6 9 env27031 = env27046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27031 == env27046) = true)

theorem identity27046 : scanCanonicalize (H12AffineFastState.compose env27046 (packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound27046 : packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS < 2^1333 := by decide +kernel

def env27047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32041,1024,29789,4160,144493,213334,201796,8193,65,75786,160860,197702,67619,75103,21792,256,95530,90203,513]

theorem envBound27047 : H12AffineFastState.Bounded env27047 := by
  intro p hp
  have h : env27047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27046_27047 : H12AffineEnvironment.transform 17 32041 env27046 = env27047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env27046 == env27047) = true)

theorem identity27047 : scanCanonicalize (H12AffineFastState.compose env27047 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27047 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env27048 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,65536,131072,23669,1024,21761,4160,136497,213334,201796,349,65,67926,152832,197702,67619,66563,21792,256,87158,82183,513]

theorem envBound27048 : H12AffineFastState.Bounded env27048 := by
  intro p hp
  have h : env27048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27047_27048 : H12AffineEnvironment.transform 12 348 env27047 = env27048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27047 == env27048) = true)

theorem identity27048 : scanCanonicalize (H12AffineFastState.compose env27048 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound27048 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27049 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,65536,82246,23669,1024,21761,4160,87159,16,21762,349,65,67926,70726,17664,67619,66563,21792,256,87158,82183,513]

theorem envBound27049 : H12AffineFastState.Bounded env27049 := by
  intro p hp
  have h : env27049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27048_27049 : H12AffineEnvironment.transform 16 82246 env27048 = env27049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env27048 == env27049) = true)

theorem identity27049 : scanCanonicalize (H12AffineFastState.compose env27049 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound27049 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27050 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,21591,5393,23669,1024,21761,4160,32,16,21762,349,65,23809,16401,17664,23668,20564,21792,256,33,5456,513]

theorem envBound27050 : H12AffineFastState.Bounded env27050 := by
  intro p hp
  have h : env27050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27049_27050 : H12AffineEnvironment.transform 15 21591 env27049 = env27050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env27049 == env27050) = true)

theorem identity27050 : scanCanonicalize (H12AffineFastState.compose env27050 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound27050 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27051 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,16384,21588,21591,5189,23669,1024,21589,4160,32,16,21590,9,65,23637,16401,17492,23668,20564,21620,84,33,5124,513]

theorem envBound27051 : H12AffineFastState.Bounded env27051 := by
  intro p hp
  have h : env27051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27050_27051 : H12AffineEnvironment.transform 7 84 env27050 = env27051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env27050 == env27051) = true)

theorem identity27051 : scanCanonicalize (H12AffineFastState.compose env27051 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound27051 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27052 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5124,80,83,5189,2161,1024,81,4160,32,16,82,9,65,2129,5141,4176,2160,1104,112,84,33,5124,513]

theorem envBound27052 : H12AffineFastState.Bounded env27052 := by
  intro p hp
  have h : env27052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27051_27052 : H12AffineEnvironment.transform 13 5124 env27051 = env27052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env27051 == env27052) = true)

theorem identity27052 : scanCanonicalize (H12AffineFastState.compose env27052 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1604) := by decide +kernel

theorem selectedBound27052 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27053 : List Nat := [2,4,8,16,32,64,9,84,512,1024,1604,4096,8,5124,80,83,5189,1589,1024,81,4160,32,16,82,9,65,1557,5141,4176,1588,1104,112,84,33,5124,513]

theorem envBound27053 : H12AffineFastState.Bounded env27053 := by
  intro p hp
  have h : env27053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27052_27053 : H12AffineEnvironment.transform 10 1604 env27052 = env27053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1604 env27052 == env27053) = true)

theorem identity27053 : scanCanonicalize (H12AffineFastState.compose env27053 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27053 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27054 : List Nat := [2,4,8,16,32,17,9,5,512,1024,1557,4096,8,5124,1,2,5140,1589,1024,0,4113,32,16,3,9,16,1557,5141,4097,1588,1025,33,5,33,5124,513]

theorem envBound27054 : H12AffineFastState.Bounded env27054 := by
  intro p hp
  have h : env27054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27053_27054 : H12AffineEnvironment.transform 5 17 env27053 = env27054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27053 == env27054) = true)

theorem identity27054 : scanCanonicalize (H12AffineFastState.compose env27054 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound27054 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27055 : List Nat := [2,4,8,16,32,17,9,5,512,1024,1557,33,8,1061,1,2,1077,1589,1024,0,48,32,16,3,9,16,1557,1076,32,1588,1025,33,5,33,1061,513]

theorem envBound27055 : H12AffineFastState.Bounded env27055 := by
  intro p hp
  have h : env27055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27054_27055 : H12AffineEnvironment.transform 11 33 env27054 = env27055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env27054 == env27055) = true)

theorem identity27055 : scanCanonicalize (H12AffineFastState.compose env27055 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound27055 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27056 : List Nat := [2,4,8,16,32,17,9,5,512,549,48,33,8,512,1,2,528,16,549,0,48,32,16,3,9,16,48,529,32,17,548,33,5,33,512,513]

theorem envBound27056 : H12AffineFastState.Bounded env27056 := by
  intro p hp
  have h : env27056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27055_27056 : H12AffineEnvironment.transform 9 549 env27055 = env27056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env27055 == env27056) = true)

theorem identity27056 : scanCanonicalize (H12AffineFastState.compose env27056 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound27056 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27057 : List Nat := [2,4,8,16,32,17,9,5,17,52,48,33,8,17,1,2,1,16,52,0,48,32,16,3,9,16,48,0,32,17,53,33,5,33,17,16]

theorem envBound27057 : H12AffineFastState.Bounded env27057 := by
  intro p hp
  have h : env27057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27056_27057 : H12AffineEnvironment.transform 8 17 env27056 = env27057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env27056 == env27057) = true)

theorem identity27057 : scanCanonicalize (H12AffineFastState.compose env27057 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27057 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27058 : List Nat := [2,4,8,1,32,0,9,5,0,37,33,33,8,0,1,2,1,1,37,0,33,32,1,3,9,1,33,0,32,0,36,33,5,33,0,1]

theorem envBound27058 : H12AffineFastState.Bounded env27058 := by
  intro p hp
  have h : env27058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27057_27058 : H12AffineEnvironment.transform 3 1 env27057 = env27058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27057 == env27058) = true)

def env27059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,510122,499128,8328,65,349475,395636,495035,67754,119043,272392,256,98814,90202,63188]

theorem envBound27059 : H12AffineFastState.Bounded env27059 := by
  intro p hp
  have h : env27059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27029_27059 : H12AffineEnvironment.transform 20 4161 env27029 = env27059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env27029 == env27059) = true)

theorem identity27059 : scanCanonicalize (H12AffineFastState.compose env27059 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound27059 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4161,180273,120014,98780,8328,65,215367,5392,102879,67754,119043,144492,256,98814,90202,63188]

theorem envBound27060 : H12AffineFastState.Bounded env27060 := by
  intro p hp
  have h : env27060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27059_27060 : H12AffineEnvironment.transform 17 138340 env27059 = env27060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env27059 == env27060) = true)

def env27061 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4161,180273,119878,98644,8192,65,215367,5392,102743,67618,119043,144492,256,98678,90202,63068]

theorem envBound27061 : H12AffineFastState.Bounded env27061 := by
  intro p hp
  have h : env27061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27060_27061 : H12AffineEnvironment.transform 6 8 env27060 = env27061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27060 == env27061) = true)

theorem identity27061 : scanCanonicalize (H12AffineFastState.compose env27061 (packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound27061 : packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS < 2^1333 := by decide +kernel

def env27062 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,65536,131072,138340,1024,32769,4161,169028,98355,98644,8192,65,204082,5392,102743,67618,99702,144492,256,98678,78895,41513]

theorem envBound27062 : H12AffineFastState.Bounded env27062 := by
  intro p hp
  have h : env27062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27061_27062 : H12AffineEnvironment.transform 13 5237 env27061 = env27062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env27061 == env27062) = true)

theorem identity27062 : scanCanonicalize (H12AffineFastState.compose env27062 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound27062 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env27063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,65536,5221,2049,1024,32769,4161,32801,98355,98644,8192,65,67927,5392,102743,67618,99702,8201,256,98678,78895,41513]

theorem envBound27063 : H12AffineFastState.Bounded env27063 := by
  intro p hp
  have h : env27063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27062_27063 : H12AffineEnvironment.transform 16 5221 env27062 = env27063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env27062 == env27063) = true)

theorem identity27063 : scanCanonicalize (H12AffineFastState.compose env27063 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27063 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env27064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,8202,5221,2049,1024,32769,4161,32801,41017,41310,8192,65,10589,5392,45405,10280,42364,8201,256,41340,5157,41513]

theorem envBound27064 : H12AffineFastState.Bounded env27064 := by
  intro p hp
  have h : env27064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27063_27064 : H12AffineEnvironment.transform 15 8202 env27063 = env27064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27063 == env27064) = true)

theorem identity27064 : scanCanonicalize (H12AffineFastState.compose env27064 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound27064 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env27065 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8232,8202,5221,2049,1024,8233,4161,8201,17,374,8192,65,10589,5392,4469,10280,1364,8201,256,340,5157,513]

theorem envBound27065 : H12AffineFastState.Bounded env27065 := by
  intro p hp
  have h : env27065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27064_27065 : H12AffineEnvironment.transform 14 8232 env27064 = env27065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env27064 == env27065) = true)

theorem identity27065 : scanCanonicalize (H12AffineFastState.compose env27065 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27065 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27066 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5156,8232,8202,5172,2049,1024,8233,4112,8201,17,295,8192,16,10508,5392,4388,10280,1285,8201,256,261,5157,513]

theorem envBound27066 : H12AffineFastState.Bounded env27066 := by
  intro p hp
  have h : env27066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27065_27066 : H12AffineEnvironment.transform 5 17 env27065 = env27066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27065 == env27066) = true)

theorem identity27066 : scanCanonicalize (H12AffineFastState.compose env27066 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound27066 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env27067 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1053,5156,1077,1047,5172,2049,1024,1076,4112,1044,17,295,1053,16,3345,5392,4388,3125,1285,1044,256,261,5157,513]

theorem envBound27067 : H12AffineFastState.Bounded env27067 := by
  intro p hp
  have h : env27067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27066_27067 : H12AffineEnvironment.transform 12 1053 env27066 = env27067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env27066 == env27067) = true)

theorem identity27067 : scanCanonicalize (H12AffineFastState.compose env27067 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27067 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27068 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,269,4404,293,263,4388,2049,272,292,4112,260,17,295,269,16,2049,4096,4388,2341,21,260,256,261,4405,513]

theorem envBound27068 : H12AffineFastState.Bounded env27068 := by
  intro p hp
  have h : env27068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27067_27068 : H12AffineEnvironment.transform 9 272 env27067 = env27068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27067 == env27068) = true)

def env27069 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4161,180273,119879,98645,8193,65,215367,5392,102742,67619,119043,144492,256,98679,90202,63069]

theorem envBound27069 : H12AffineFastState.Bounded env27069 := by
  intro p hp
  have h : env27069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27060_27069 : H12AffineEnvironment.transform 6 9 env27060 = env27069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27060 == env27069) = true)

theorem identity27069 : scanCanonicalize (H12AffineFastState.compose env27069 (packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound27069 : packedSelected [0,7,8,9,10,12,14,15,16,18,22,23,28] rootPS < 2^1333 := by decide +kernel

def env27070 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,131072,138340,1024,32769,4161,180273,41293,62559,8193,65,146509,5392,58460,32041,41993,144492,256,62589,5456,63069]

theorem envBound27070 : H12AffineFastState.Bounded env27070 := by
  intro p hp
  have h : env27070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27069_27070 : H12AffineEnvironment.transform 15 29962 env27069 = env27070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env27069 == env27070) = true)

theorem identity27070 : scanCanonicalize (H12AffineFastState.compose env27070 (packedSelected [0,1,4,8,12,14,15,17,18,20,22,23,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound27070 : packedSelected [0,1,4,8,12,14,15,17,18,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env27071 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,5440,2340,1024,32769,4161,54641,41293,62559,8193,65,10509,5392,58460,32041,41993,8492,256,62589,5456,63069]

theorem envBound27071 : H12AffineFastState.Bounded env27071 := by
  intro p hp
  have h : env27071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27070_27071 : H12AffineEnvironment.transform 16 5440 env27070 = env27071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env27070 == env27071) = true)

theorem identity27071 : scanCanonicalize (H12AffineFastState.compose env27071 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound27071 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env27072 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,29962,5440,2340,1024,21761,4161,113,29773,8543,8193,65,10509,5392,12636,32041,28937,8492,256,8573,5456,9053]

theorem envBound27072 : H12AffineFastState.Bounded env27072 := by
  intro p hp
  have h : env27072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27071_27072 : H12AffineEnvironment.transform 14 21760 env27071 = env27072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env27071 == env27072) = true)

theorem identity27072 : scanCanonicalize (H12AffineFastState.compose env27072 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27072 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27073 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21760,21510,5440,2340,1024,21761,4161,113,21825,83,269,65,2049,5392,4176,23589,20485,32,256,113,5456,593]

theorem envBound27073 : H12AffineFastState.Bounded env27073 := by
  intro p hp
  have h : env27073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27072_27073 : H12AffineEnvironment.transform 12 268 env27072 = env27073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27072 == env27073) = true)

theorem identity27073 : scanCanonicalize (H12AffineFastState.compose env27073 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound27073 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27074 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5457,81,343,5440,2340,1024,80,4161,113,16,83,269,65,2049,5392,4176,2420,1364,32,256,113,5456,593]

theorem envBound27074 : H12AffineFastState.Bounded env27074 := by
  intro p hp
  have h : env27074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27073_27074 : H12AffineEnvironment.transform 13 5457 env27073 = env27074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env27073 == env27074) = true)

theorem identity27074 : scanCanonicalize (H12AffineFastState.compose env27074 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound27074 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env27075 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1540,4096,268,5457,81,343,5440,1824,1024,80,4161,113,16,83,269,65,1541,5392,4176,1904,1364,32,256,113,5456,593]

theorem envBound27075 : H12AffineFastState.Bounded env27075 := by
  intro p hp
  have h : env27075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27074_27075 : H12AffineEnvironment.transform 10 1540 env27074 = env27075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env27074 == env27075) = true)

theorem identity27075 : scanCanonicalize (H12AffineFastState.compose env27075 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound27075 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env27076 : List Nat := [2,4,8,16,32,64,9,256,512,305,821,4096,268,4192,81,343,4209,529,305,80,4161,113,16,83,269,65,820,4129,4176,577,101,32,256,113,4193,593]

theorem envBound27076 : H12AffineFastState.Bounded env27076 := by
  intro p hp
  have h : env27076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27075_27076 : H12AffineEnvironment.transform 9 305 env27075 = env27076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env27075 == env27076) = true)

theorem identity27076 : scanCanonicalize (H12AffineFastState.compose env27076 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound27076 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env27077 : List Nat := [2,4,8,16,16,64,9,256,512,257,773,4096,268,4176,81,343,4161,529,257,80,4161,65,16,83,269,65,772,4113,4176,577,85,16,256,65,4177,593]

theorem envBound27077 : H12AffineFastState.Bounded env27077 := by
  intro p hp
  have h : env27077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27076_27077 : H12AffineEnvironment.transform 4 16 env27076 = env27077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env27076 == env27077) = true)

theorem identity27077 : scanCanonicalize (H12AffineFastState.compose env27077 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound27077 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27078 : List Nat := [2,4,8,16,16,64,9,256,512,257,773,325,268,277,81,343,260,529,257,80,260,65,16,83,269,65,772,340,277,577,85,16,256,65,276,593]

theorem envBound27078 : H12AffineFastState.Bounded env27078 := by
  intro p hp
  have h : env27078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27077_27078 : H12AffineEnvironment.transform 11 325 env27077 = env27078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env27077 == env27078) = true)

theorem identity27078 : scanCanonicalize (H12AffineFastState.compose env27078 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 341) := by decide +kernel

theorem selectedBound27078 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env27079 : List Nat := [2,4,8,16,16,64,9,256,341,257,80,325,268,277,81,343,260,324,257,80,260,65,16,83,269,65,81,340,277,276,85,16,256,65,276,260]

theorem envBound27079 : H12AffineFastState.Bounded env27079 := by
  intro p hp
  have h : env27079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27078_27079 : H12AffineEnvironment.transform 8 341 env27078 = env27079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env27078 == env27079) = true)

theorem identity27079 : scanCanonicalize (H12AffineFastState.compose env27079 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27079 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27080 : List Nat := [2,4,8,16,16,17,9,256,260,257,1,276,268,277,0,262,260,277,257,1,260,16,16,2,269,16,0,261,277,276,4,16,256,16,276,260]

theorem envBound27080 : H12AffineFastState.Bounded env27080 := by
  intro p hp
  have h : env27080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27079_27080 : H12AffineEnvironment.transform 5 17 env27079 = env27080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27079 == env27080) = true)

theorem identity27080 : scanCanonicalize (H12AffineFastState.compose env27080 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27080 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27081 : List Nat := [2,4,8,1,1,0,9,256,260,257,1,261,268,260,0,262,260,260,257,1,260,1,1,2,269,1,0,261,260,261,4,1,256,1,261,260]

theorem envBound27081 : H12AffineFastState.Bounded env27081 := by
  intro p hp
  have h : env27081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27080_27081 : H12AffineEnvironment.transform 3 1 env27080 = env27081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27080 == env27081) = true)

theorem identity27081 : scanCanonicalize (H12AffineFastState.compose env27081 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27081 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27082 : List Nat := [2,4,8,1,1,0,9,5,1,4,1,0,9,1,0,3,1,1,4,1,1,1,1,2,8,1,0,0,1,0,4,1,5,1,0,1]

theorem envBound27082 : H12AffineFastState.Bounded env27082 := by
  intro p hp
  have h : env27082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27081_27082 : H12AffineEnvironment.transform 7 5 env27081 = env27082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27081 == env27082) = true)

theorem identity27082 : scanCanonicalize (H12AffineFastState.compose env27082 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound27082 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27083 : List Nat := [2,4,7,1,1,0,6,5,1,4,1,0,6,1,0,3,1,1,4,1,1,1,1,2,7,1,0,0,1,0,4,1,5,1,0,1]

theorem envBound27083 : H12AffineFastState.Bounded env27083 := by
  intro p hp
  have h : env27083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27082_27083 : H12AffineEnvironment.transform 2 7 env27082 = env27083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env27082 == env27083) = true)

def env27084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,510122,499129,8328,65,349474,2496820,2596346,67754,119042,2373704,256,2199998,2191386,63189]

theorem envBound27084 : H12AffineFastState.Bounded env27084 := by
  intro p hp
  have h : env27084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27028_27084 : H12AffineEnvironment.transform 23 499129 env27028 = env27084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499129 env27028 == env27084) = true)

def env27085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,510122,499129,8328,65,349474,395636,495034,67754,119042,272392,256,98814,90202,63189]

theorem envBound27085 : H12AffineFastState.Bounded env27085 := by
  intro p hp
  have h : env27085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27084_27085 : H12AffineEnvironment.transform 20 4160 env27084 = env27085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env27084 == env27085) = true)

theorem identity27085 : scanCanonicalize (H12AffineFastState.compose env27085 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190641) := by decide +kernel

theorem selectedBound27085 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,180273,73755,95496,8328,65,245139,57797,91403,67754,119042,180409,256,98814,90202,63189]

theorem envBound27086 : H12AffineFastState.Bounded env27086 := by
  intro p hp
  have h : env27086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27085_27086 : H12AffineEnvironment.transform 17 190641 env27085 = env27086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env27085 == env27086) = true)

def env27087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10401,1024,32769,4160,33,73755,95496,8328,65,97667,57797,91403,67754,119042,169,256,98814,90202,63189]

theorem envBound27087 : H12AffineFastState.Bounded env27087 := by
  intro p hp
  have h : env27087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27086_27087 : H12AffineEnvironment.transform 16 49168 env27086 = env27087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env27086 == env27087) = true)

theorem identity27087 : scanCanonicalize (H12AffineFastState.compose env27087 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound27087 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env27088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,65536,46156,10401,1024,32769,4160,33,73755,65876,8328,65,68063,38297,69975,67754,107870,169,256,98814,70662,33417]

theorem envBound27088 : H12AffineFastState.Bounded env27088 := by
  intro p hp
  have h : env27088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27087_27088 : H12AffineEnvironment.transform 13 13404 env27087 = env27088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env27087 == env27088) = true)

theorem identity27088 : scanCanonicalize (H12AffineFastState.compose env27088 (packedSelected [0,3,5,8,9,10,14,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound27088 : packedSelected [0,3,5,8,9,10,14,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env27089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,65536,13508,10401,1024,137,4160,33,73755,65876,8328,65,68063,5393,69975,67754,75222,169,256,65910,70662,513]

theorem envBound27089 : H12AffineFastState.Bounded env27089 := by
  intro p hp
  have h : env27089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27088_27089 : H12AffineEnvironment.transform 14 136 env27088 = env27089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env27088 == env27089) = true)

theorem identity27089 : scanCanonicalize (H12AffineFastState.compose env27089 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound27089 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env27090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,136,65536,5393,2420,1024,137,4160,33,65998,65876,349,65,68063,5393,69975,67754,66563,169,256,65910,70662,513]

theorem envBound27090 : H12AffineFastState.Bounded env27090 := by
  intro p hp
  have h : env27090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27089_27090 : H12AffineEnvironment.transform 12 469 env27089 = env27090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env27089 == env27090) = true)

theorem identity27090 : scanCanonicalize (H12AffineFastState.compose env27090 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound27090 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env27091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,136,478,5393,2420,1024,137,4160,33,16,138,349,65,2049,5393,4233,2420,1501,169,256,168,5592,513]

theorem envBound27091 : H12AffineFastState.Bounded env27091 := by
  intro p hp
  have h : env27091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27090_27091 : H12AffineEnvironment.transform 15 478 env27090 = env27091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env27090 == env27091) = true)

theorem identity27091 : scanCanonicalize (H12AffineFastState.compose env27091 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27091 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27092 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,343,5393,2420,1024,0,4160,33,16,3,349,65,2049,5393,4096,2420,1364,32,256,33,5457,513]

theorem envBound27092 : H12AffineFastState.Bounded env27092 := by
  intro p hp
  have h : env27092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27091_27092 : H12AffineEnvironment.transform 6 9 env27091 = env27092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27091 == env27092) = true)

theorem identity27092 : scanCanonicalize (H12AffineFastState.compose env27092 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound27092 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27093 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1060,348,292,1,343,309,2420,1024,0,1124,33,16,3,349,65,2049,309,1060,2420,1364,32,256,33,373,513]

theorem envBound27093 : H12AffineFastState.Bounded env27093 := by
  intro p hp
  have h : env27093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27092_27093 : H12AffineEnvironment.transform 11 1060 env27092 = env27093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env27092 == env27093) = true)

theorem identity27093 : scanCanonicalize (H12AffineFastState.compose env27093 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound27093 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27094 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1296,1060,348,292,1,343,309,1124,1024,0,1124,33,16,3,349,65,1297,309,1060,1124,1364,32,256,33,373,513]

theorem envBound27094 : H12AffineFastState.Bounded env27094 := by
  intro p hp
  have h : env27094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27093_27094 : H12AffineEnvironment.transform 10 1296 env27093 = env27094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env27093 == env27094) = true)

theorem identity27094 : scanCanonicalize (H12AffineFastState.compose env27094 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound27094 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env27095 : List Nat := [2,4,8,16,32,32,9,256,512,1024,1296,1060,316,292,1,311,309,1028,1024,0,1028,33,16,3,317,33,1297,309,1060,1028,1332,32,256,33,277,513]

theorem envBound27095 : H12AffineFastState.Bounded env27095 := by
  intro p hp
  have h : env27095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27094_27095 : H12AffineEnvironment.transform 5 32 env27094 = env27095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env27094 == env27095) = true)

theorem identity27095 : scanCanonicalize (H12AffineFastState.compose env27095 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound27095 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env27096 : List Nat := [2,4,8,16,32,32,9,256,292,1024,1296,1060,316,292,1,311,309,1028,1024,0,1028,33,16,3,317,33,1297,309,1060,1028,1332,32,256,33,277,293]

theorem envBound27096 : H12AffineFastState.Bounded env27096 := by
  intro p hp
  have h : env27096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27095_27096 : H12AffineEnvironment.transform 8 292 env27095 = env27096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env27095 == env27096) = true)

theorem identity27096 : scanCanonicalize (H12AffineFastState.compose env27096 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27096 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env27097 : List Nat := [2,4,8,16,1,1,9,256,261,1024,1296,1029,285,261,1,278,276,1028,1024,0,1028,0,16,3,284,0,1297,276,1029,1028,1301,1,256,0,277,260]

theorem envBound27097 : H12AffineFastState.Bounded env27097 := by
  intro p hp
  have h : env27097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27096_27097 : H12AffineEnvironment.transform 4 1 env27096 = env27097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27096 == env27097) = true)

theorem identity27097 : scanCanonicalize (H12AffineFastState.compose env27097 (packedSelected [0,4,12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27097 : packedSelected [0,4,12] rootPS < 2^1333 := by decide +kernel

def env27098 : List Nat := [2,4,8,1,1,1,9,256,261,1024,1281,1029,268,261,1,263,261,1028,1024,0,1028,0,1,3,269,0,1280,261,1029,1028,1284,1,256,0,260,260]

theorem envBound27098 : H12AffineFastState.Bounded env27098 := by
  intro p hp
  have h : env27098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27097_27098 : H12AffineEnvironment.transform 3 1 env27097 = env27098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27097 == env27098) = true)

theorem identity27098 : scanCanonicalize (H12AffineFastState.compose env27098 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound27098 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27099 : List Nat := [2,4,8,1,1,1,9,256,261,256,1,261,268,261,1,263,261,260,256,0,260,0,1,3,269,0,0,261,261,260,4,1,256,0,260,260]

theorem envBound27099 : H12AffineFastState.Bounded env27099 := by
  intro p hp
  have h : env27099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27098_27099 : H12AffineEnvironment.transform 9 256 env27098 = env27099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env27098 == env27099) = true)

theorem identity27099 : scanCanonicalize (H12AffineFastState.compose env27099 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27099 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27100 : List Nat := [2,4,8,1,1,1,9,5,0,5,1,0,9,0,1,2,0,1,5,0,1,0,1,3,8,0,0,0,0,1,4,1,5,0,1,1]

theorem envBound27100 : H12AffineFastState.Bounded env27100 := by
  intro p hp
  have h : env27100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27099_27100 : H12AffineEnvironment.transform 7 5 env27099 = env27100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27099 == env27100) = true)

def env27101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10400,1024,32769,4160,32,73755,95496,8328,65,97666,57797,91403,67754,119042,168,256,98814,90202,63189]

theorem envBound27101 : H12AffineFastState.Bounded env27101 := by
  intro p hp
  have h : env27101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27086_27101 : H12AffineEnvironment.transform 16 49169 env27086 = env27101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env27086 == env27101) = true)

theorem identity27101 : scanCanonicalize (H12AffineFastState.compose env27101 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 62711) := by decide +kernel

theorem selectedBound27101 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env27102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62711,49169,10400,1024,32769,4160,32,54508,33279,8328,65,35189,57797,37372,64605,9717,168,256,29961,38061,63189]

theorem envBound27102 : H12AffineFastState.Bounded env27102 := by
  intro p hp
  have h : env27102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27101_27102 : H12AffineEnvironment.transform 15 62711 env27101 = env27102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62711 env27101 == env27102) = true)

theorem identity27102 : scanCanonicalize (H12AffineFastState.compose env27102 (packedSelected [0,3,5,7,9,14,16,18,22,23,31,38,41] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound27102 : packedSelected [0,3,5,7,9,14,16,18,22,23,31,38,41] rootPS < 2^1333 := by decide +kernel

def env27103 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,62711,49169,10400,1024,32769,4160,32,54508,32771,8328,65,34953,57401,36864,64605,9225,168,252,29941,38061,63189]

theorem envBound27103 : H12AffineFastState.Bounded env27103 := by
  intro p hp
  have h : env27103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27102_27103 : H12AffineEnvironment.transform 7 252 env27102 = env27103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env27102 == env27103) = true)

theorem identity27103 : scanCanonicalize (H12AffineFastState.compose env27103 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 21757) := by decide +kernel

theorem selectedBound27103 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env27104 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,21757,8202,5356,10400,1024,21756,4160,32,17,21758,8328,65,23668,13508,17661,10400,9225,168,252,29941,16464,8744]

theorem envBound27104 : H12AffineFastState.Bounded env27104 := by
  intro p hp
  have h : env27104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27103_27104 : H12AffineEnvironment.transform 14 21757 env27103 = env27104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21757 env27103 == env27104) = true)

theorem identity27104 : scanCanonicalize (H12AffineFastState.compose env27104 (packedSelected [0,4,6,7,9,17] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound27104 : packedSelected [0,4,6,7,9,17] rootPS < 2^1333 := by decide +kernel

def env27105 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5156,217,8202,5356,10400,1024,216,4160,32,17,218,8328,65,2128,13508,4313,10400,9225,168,252,8401,5236,8744]

theorem envBound27105 : H12AffineFastState.Bounded env27105 := by
  intro p hp
  have h : env27105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27104_27105 : H12AffineEnvironment.transform 13 5156 env27104 = env27105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env27104 == env27105) = true)

theorem identity27105 : scanCanonicalize (H12AffineFastState.compose env27105 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27105 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env27106 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5156,137,8202,5308,10400,1024,136,4112,32,17,138,8328,17,2048,13460,4233,10400,9225,168,172,8321,5156,8744]

theorem envBound27106 : H12AffineFastState.Bounded env27106 := by
  intro p hp
  have h : env27106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27105_27106 : H12AffineEnvironment.transform 5 16 env27105 = env27106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27105 == env27106) = true)

theorem identity27106 : scanCanonicalize (H12AffineFastState.compose env27106 (packedSelected [1,2,4,8,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1173) := by decide +kernel

theorem selectedBound27106 : packedSelected [1,2,4,8,9,10,14] rootPS < 2^1333 := by decide +kernel

def env27107 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1173,5156,137,1183,5308,3125,1024,136,4112,32,17,138,1053,17,2048,4097,4233,3125,156,168,172,1044,5156,1725]

theorem envBound27107 : H12AffineFastState.Bounded env27107 := by
  intro p hp
  have h : env27107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27106_27107 : H12AffineEnvironment.transform 12 1173 env27106 = env27107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1173 env27106 == env27107) = true)

theorem identity27107 : scanCanonicalize (H12AffineFastState.compose env27107 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound27107 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27108 : List Nat := [2,4,8,16,32,16,128,172,512,52,2048,4096,161,4112,137,171,4232,2049,52,136,4112,32,17,138,41,17,2048,4097,4233,2049,156,168,172,32,4112,649]

theorem envBound27108 : H12AffineFastState.Bounded env27108 := by
  intro p hp
  have h : env27108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27107_27108 : H12AffineEnvironment.transform 9 52 env27107 = env27108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27107 == env27108) = true)

theorem identity27108 : scanCanonicalize (H12AffineFastState.compose env27108 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27108 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27109 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4112,1,35,4096,2049,52,0,4112,32,17,2,41,17,2048,4097,4097,2049,20,32,36,32,4112,513]

theorem envBound27109 : H12AffineFastState.Bounded env27109 := by
  intro p hp
  have h : env27109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27108_27109 : H12AffineEnvironment.transform 6 8 env27108 = env27109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27108 == env27109) = true)

theorem identity27109 : scanCanonicalize (H12AffineFastState.compose env27109 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound27109 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27110 : List Nat := [2,4,8,16,32,16,8,36,17,52,2048,4096,41,4112,1,35,4096,2049,52,0,4112,32,17,2,41,17,2048,4097,4097,2049,20,32,36,32,4112,16]

theorem envBound27110 : H12AffineFastState.Bounded env27110 := by
  intro p hp
  have h : env27110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1