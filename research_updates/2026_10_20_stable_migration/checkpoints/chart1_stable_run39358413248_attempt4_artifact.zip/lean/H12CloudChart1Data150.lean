import H12CloudChart1Data149

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env38032 : List Nat := [2,4,8,16,1,64,8,85,512,1024,2048,4096,9,5125,81,2,5188,2128,1024,80,4113,80,16,2,9,64,2048,5188,4096,2128,1105,80,85,81,5205,593]

theorem envBound38032 : H12AffineFastState.Bounded env38032 := by
  intro p hp
  have h : env38032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38012_38032 : H12AffineEnvironment.transform 4 1 env38012 = env38032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38012 == env38032) = true)

theorem identity38032 : scanCanonicalize (H12AffineFastState.compose env38032 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38032 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38033 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,9,5125,1,2,5140,2048,1024,0,4113,0,16,2,9,16,2048,5140,4096,2048,1025,0,5,1,5125,513]

theorem envBound38033 : H12AffineFastState.Bounded env38033 := by
  intro p hp
  have h : env38033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38032_38033 : H12AffineEnvironment.transform 5 16 env38032 = env38033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38032 == env38033) = true)

def env38034 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,16,9,1045,1,2,1028,2048,1024,0,1,0,16,2,9,16,2048,1028,16,2048,1025,0,5,1,1045,513]

theorem envBound38034 : H12AffineFastState.Bounded env38034 := by
  intro p hp
  have h : env38034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38033_38034 : H12AffineEnvironment.transform 11 16 env38033 = env38034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env38033 == env38034) = true)

theorem identity38034 : scanCanonicalize (H12AffineFastState.compose env38034 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound38034 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38035 : List Nat := [2,4,8,16,1,16,8,5,512,1024,1044,16,9,1045,1,2,1028,1044,1024,0,1,0,16,2,9,16,1044,1028,16,1044,1025,0,5,1,1045,513]

theorem envBound38035 : H12AffineFastState.Bounded env38035 := by
  intro p hp
  have h : env38035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38034_38035 : H12AffineEnvironment.transform 10 1044 env38034 = env38035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env38034 == env38035) = true)

def env38036 : List Nat := [2,4,8,16,1,16,8,5,512,20,0,16,9,1,1,2,16,0,20,0,1,0,16,2,9,16,0,16,16,0,21,0,5,1,1,513]

theorem envBound38036 : H12AffineFastState.Bounded env38036 := by
  intro p hp
  have h : env38036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38035_38036 : H12AffineEnvironment.transform 9 20 env38035 = env38036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env38035 == env38036) = true)

def env38037 : List Nat := [2,4,8,16,1,16,8,5,512,21,1,16,9,0,1,2,17,1,21,0,1,0,16,2,9,16,1,17,16,1,20,0,5,1,0,513]

theorem envBound38037 : H12AffineFastState.Bounded env38037 := by
  intro p hp
  have h : env38037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38035_38037 : H12AffineEnvironment.transform 9 21 env38035 = env38037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env38035 == env38037) = true)

theorem identity38037 : scanCanonicalize (H12AffineFastState.compose env38037 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound38037 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38038 : List Nat := [2,4,8,16,1,16,8,5,10,21,1,16,9,0,1,2,17,1,21,0,1,0,16,2,9,16,1,17,16,1,20,0,5,1,0,11]

theorem envBound38038 : H12AffineFastState.Bounded env38038 := by
  intro p hp
  have h : env38038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38037_38038 : H12AffineEnvironment.transform 8 10 env38037 = env38038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env38037 == env38038) = true)

def leafEnv38038 : List Nat := [2,4,8,16,1,16,8,5,10,21,1,16,9,0,1,2,17,1,21,0,1,0,16,2,20,9,1,16,1,17,16,1,20,0,5,1,4,2,0,11,1,1,0]

def active38038 : List Nat := [0,1,2,3]

def tree38038 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38038 : H12WitnessSearch.Good tree38038 := H12GlobalWitnessIndex.good

theorem leafIdentity38038 : H12AffineFastState.composeSystem env38038 rootObs = leafEnv38038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38038 rootObs == leafEnv38038) = true)

theorem terminalChecked38038 : H12PackedTerminal.terminalCheckFast leafEnv38038 active38038 tree38038 = true := by decide +kernel

def env38039 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,17,9,1044,1,2,1029,2048,1024,0,0,0,16,2,9,16,2048,1029,17,2048,1025,0,5,1,1044,513]

theorem envBound38039 : H12AffineFastState.Bounded env38039 := by
  intro p hp
  have h : env38039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38033_38039 : H12AffineEnvironment.transform 11 17 env38033 = env38039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env38033 == env38039) = true)

theorem identity38039 : scanCanonicalize (H12AffineFastState.compose env38039 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound38039 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38040 : List Nat := [2,4,8,16,1,16,8,5,512,1024,1,17,9,1044,1,2,1029,1,1024,0,0,0,16,2,9,16,1,1029,17,1,1025,0,5,1,1044,513]

theorem envBound38040 : H12AffineFastState.Bounded env38040 := by
  intro p hp
  have h : env38040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38039_38040 : H12AffineEnvironment.transform 10 1 env38039 = env38040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env38039 == env38040) = true)

def env38041 : List Nat := [2,4,8,16,1,16,8,5,512,20,1,17,9,0,1,2,17,1,20,0,0,0,16,2,9,16,1,17,17,1,21,0,5,1,0,513]

theorem envBound38041 : H12AffineFastState.Bounded env38041 := by
  intro p hp
  have h : env38041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38040_38041 : H12AffineEnvironment.transform 9 20 env38040 = env38041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env38040 == env38041) = true)

def env38042 : List Nat := [2,4,8,16,1,16,8,5,512,21,1,17,9,1,1,2,16,1,21,0,0,0,16,2,9,16,1,16,17,1,20,0,5,1,1,513]

theorem envBound38042 : H12AffineFastState.Bounded env38042 := by
  intro p hp
  have h : env38042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38040_38042 : H12AffineEnvironment.transform 9 21 env38040 = env38042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env38040 == env38042) = true)

theorem identity38042 : scanCanonicalize (H12AffineFastState.compose env38042 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound38042 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38043 : List Nat := [2,4,8,16,1,16,8,5,10,21,1,17,9,1,1,2,16,1,21,0,0,0,16,2,9,16,1,16,17,1,20,0,5,1,1,11]

theorem envBound38043 : H12AffineFastState.Bounded env38043 := by
  intro p hp
  have h : env38043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38042_38043 : H12AffineEnvironment.transform 8 10 env38042 = env38043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env38042 == env38043) = true)

def leafEnv38043 : List Nat := [2,4,8,16,1,16,8,5,10,21,1,17,9,1,1,2,16,1,21,0,0,0,16,2,20,9,1,16,1,16,17,1,20,0,5,1,4,2,1,11,1,0,0]

def active38043 : List Nat := [0,1,2,3]

def tree38043 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38043 : H12WitnessSearch.Good tree38043 := H12GlobalWitnessIndex.good

theorem leafIdentity38043 : H12AffineFastState.composeSystem env38043 rootObs = leafEnv38043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38043 rootObs == leafEnv38043) = true)

theorem terminalChecked38043 : H12PackedTerminal.terminalCheckFast leafEnv38043 active38043 tree38043 = true := by decide +kernel

def env38044 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,80,65536,131072,76079,1024,81,12620,8492,16,73736,8193,64,203846,5393,4096,204130,9304,8492,256,8493,13404,66311]

theorem envBound38044 : H12AffineFastState.Bounded env38044 := by
  intro p hp
  have h : env38044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38007_38044 : H12AffineEnvironment.transform 6 9 env38007 = env38044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38007 == env38044) = true)

theorem identity38044 : scanCanonicalize (H12AffineFastState.compose env38044 (packedSelected [1,4,6,8,9,10,12,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound38044 : packedSelected [1,4,6,8,9,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env38045 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13325,80,65536,131072,75866,1024,81,12345,8281,16,73736,8193,64,203846,5220,4096,203799,9304,8281,117,8280,13404,66162]

theorem envBound38045 : H12AffineFastState.Bounded env38045 := by
  intro p hp
  have h : env38045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38044_38045 : H12AffineEnvironment.transform 7 117 env38044 = env38045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env38044 == env38045) = true)

theorem identity38045 : scanCanonicalize (H12AffineFastState.compose env38045 (packedSelected [21] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound38045 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38046 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,80,65536,131072,67618,1024,81,4161,33,16,65648,121,64,203846,5220,4096,203799,1056,33,117,32,5156,66162]

theorem envBound38046 : H12AffineFastState.Bounded env38046 := by
  intro p hp
  have h : env38046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38045_38046 : H12AffineEnvironment.transform 12 120 env38045 = env38046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env38045 == env38046) = true)

theorem identity38046 : scanCanonicalize (H12AffineFastState.compose env38046 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound38046 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env38047 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,80,65536,70679,67618,1024,81,4161,33,16,65648,121,64,2129,5220,4096,2048,1056,33,117,32,5156,66162]

theorem envBound38047 : H12AffineFastState.Bounded env38047 := by
  intro p hp
  have h : env38047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38046_38047 : H12AffineEnvironment.transform 16 70679 env38046 = env38047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env38046 == env38047) = true)

theorem identity38047 : scanCanonicalize (H12AffineFastState.compose env38047 (packedSelected [3,4,5,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38047 : packedSelected [3,4,5,7,20] rootPS < 2^1333 := by decide +kernel

def env38048 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,0,65536,70679,67618,1024,1,4113,33,16,65568,41,16,2049,5172,4096,2048,1056,33,37,32,5156,66082]

theorem envBound38048 : H12AffineFastState.Bounded env38048 := by
  intro p hp
  have h : env38048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38047_38048 : H12AffineEnvironment.transform 5 16 env38047 = env38048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38047 == env38048) = true)

theorem identity38048 : scanCanonicalize (H12AffineFastState.compose env38048 (packedSelected [0,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound38048 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env38049 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3109,40,2048,0,65536,67634,67618,1024,1,3124,33,16,65568,41,16,2049,2065,3109,2048,1056,33,37,32,2049,66082]

theorem envBound38049 : H12AffineFastState.Bounded env38049 := by
  intro p hp
  have h : env38049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38048_38049 : H12AffineEnvironment.transform 11 3109 env38048 = env38049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env38048 == env38049) = true)

theorem identity38049 : scanCanonicalize (H12AffineFastState.compose env38049 (packedSelected [4,7] rootPS)) = affineNative (2^(15+1) ^^^ 1046) := by decide +kernel

theorem selectedBound38049 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env38050 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3109,40,2048,0,1046,3108,3124,1024,1,3124,33,16,1078,41,16,2049,2065,3109,2048,1056,33,37,32,2049,1588]

theorem envBound38050 : H12AffineFastState.Bounded env38050 := by
  intro p hp
  have h : env38050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38049_38050 : H12AffineEnvironment.transform 15 1046 env38049 = env38050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1046 env38049 == env38050) = true)

theorem identity38050 : scanCanonicalize (H12AffineFastState.compose env38050 (packedSelected [2,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound38050 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env38051 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2064,40,2048,0,35,2065,2049,53,1,2049,33,16,3,41,16,2049,2065,2064,2048,21,33,37,32,2049,513]

theorem envBound38051 : H12AffineFastState.Bounded env38051 := by
  intro p hp
  have h : env38051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38050_38051 : H12AffineEnvironment.transform 9 53 env38050 = env38051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38050 == env38051) = true)

theorem identity38051 : scanCanonicalize (H12AffineFastState.compose env38051 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound38051 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38052 : List Nat := [2,4,8,16,32,16,9,37,0,53,2048,2064,40,2048,0,35,2065,2049,53,1,2049,33,16,3,41,16,2049,2065,2064,2048,21,33,37,32,2049,1]

theorem envBound38052 : H12AffineFastState.Bounded env38052 := by
  intro p hp
  have h : env38052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38051_38052 : H12AffineEnvironment.transform 8 0 env38051 = env38052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env38051 == env38052) = true)

theorem identity38052 : scanCanonicalize (H12AffineFastState.compose env38052 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound38052 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38053 : List Nat := [2,4,8,16,32,16,9,37,0,53,10,26,40,10,0,35,27,11,53,1,11,33,16,3,41,16,11,27,26,10,21,33,37,32,11,1]

theorem envBound38053 : H12AffineFastState.Bounded env38053 := by
  intro p hp
  have h : env38053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38052_38053 : H12AffineEnvironment.transform 10 10 env38052 = env38053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env38052 == env38053) = true)

def env38054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101345,62541,2188736,8328,64,410092,57676,2138396,406605,2102685,2101345,256,21792,46213,2175563]

theorem envBound38054 : H12AffineFastState.Bounded env38054 := by
  intro p hp
  have h : env38054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37961_38054 : H12AffineEnvironment.transform 21 2101345 env37961 = env38054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101345 env37961 == env38054) = true)

def env38055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,62541,73856,8328,64,410092,57676,58460,406605,20701,21793,256,21792,46213,96011]

theorem envBound38055 : H12AffineFastState.Bounded env38055 := by
  intro p hp
  have h : env38055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38054_38055 : H12AffineEnvironment.transform 20 17728 env38054 = env38055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env38054 == env38055) = true)

theorem identity38055 : scanCanonicalize (H12AffineFastState.compose env38055 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound38055 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,17728,21793,152,73856,8328,64,410092,5529,4233,406605,20701,21793,256,21792,16464,96011]

theorem envBound38056 : H12AffineFastState.Bounded env38056 := by
  intro p hp
  have h : env38056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38055_38056 : H12AffineEnvironment.transform 14 29909 env38055 = env38056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env38055 == env38056) = true)

theorem identity38056 : scanCanonicalize (H12AffineFastState.compose env38056 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 89514) := by decide +kernel

theorem selectedBound38056 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env38057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,89514,1024,29908,17728,21793,152,73856,8328,64,203846,5529,4233,223719,20701,21793,256,21792,16464,96011]

theorem envBound38057 : H12AffineFastState.Bounded env38057 := by
  intro p hp
  have h : env38057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38056_38057 : H12AffineEnvironment.transform 17 89514 env38056 = env38057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89514 env38056 == env38057) = true)

theorem identity38057 : scanCanonicalize (H12AffineFastState.compose env38057 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound38057 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,29962,131072,10400,1024,29908,17728,21793,152,21898,8328,64,158028,5529,4233,138477,20701,21793,256,21792,16464,513]

theorem envBound38058 : H12AffineFastState.Bounded env38058 := by
  intro p hp
  have h : env38058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38057_38058 : H12AffineEnvironment.transform 15 29962 env38057 = env38058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env38057 == env38058) = true)

theorem identity38058 : scanCanonicalize (H12AffineFastState.compose env38058 (packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS)) = affineNative (2^(16+1) ^^^ 13460) := by decide +kernel

theorem selectedBound38058 : packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env38059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,29962,13460,10400,1024,29908,17728,21793,152,21898,8328,64,24024,5529,4233,10361,20701,21793,256,21792,16464,513]

theorem envBound38059 : H12AffineFastState.Bounded env38059 := by
  intro p hp
  have h : env38059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38058_38059 : H12AffineEnvironment.transform 16 13460 env38058 = env38059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13460 env38058 == env38059) = true)

theorem identity38059 : scanCanonicalize (H12AffineFastState.compose env38059 (packedSelected [0,1,2,4,6,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound38059 : packedSelected [0,1,2,4,6,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env38060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8322,13460,10400,1024,8540,4296,169,152,2,8328,64,2128,5529,4233,10361,1365,169,256,168,5592,513]

theorem envBound38060 : H12AffineFastState.Bounded env38060 := by
  intro p hp
  have h : env38060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38059_38060 : H12AffineEnvironment.transform 13 5512 env38059 = env38060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env38059 == env38060) = true)

theorem identity38060 : scanCanonicalize (H12AffineFastState.compose env38060 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38060 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env38061 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,5512,8541,8322,13460,10368,1024,8540,4296,137,152,2,8328,64,2128,5529,4233,10329,1365,137,256,136,5592,513]

theorem envBound38061 : H12AffineFastState.Bounded env38061 := by
  intro p hp
  have h : env38061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38060_38061 : H12AffineEnvironment.transform 4 0 env38060 = env38061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38060 == env38061) = true)

theorem identity38061 : scanCanonicalize (H12AffineFastState.compose env38061 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound38061 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env38062 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,13341,10249,1024,8540,4161,0,17,2,8193,64,2128,5392,4096,10329,1365,0,256,1,5457,513]

theorem envBound38062 : H12AffineFastState.Bounded env38062 := by
  intro p hp
  have h : env38062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38061_38062 : H12AffineEnvironment.transform 6 9 env38061 = env38062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38061 == env38062) = true)

theorem identity38062 : scanCanonicalize (H12AffineFastState.compose env38062 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38062 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38063 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,8192,5377,8460,8203,13341,10249,1024,8461,4112,0,17,2,8193,17,2049,5392,4096,10248,1284,0,256,1,5376,513]

theorem envBound38063 : H12AffineFastState.Bounded env38063 := by
  intro p hp
  have h : env38063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38062_38063 : H12AffineEnvironment.transform 5 17 env38062 = env38063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38062 == env38063) = true)

theorem identity38063 : scanCanonicalize (H12AffineFastState.compose env38063 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38063 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env38064 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,269,5377,1,262,5392,2308,1024,0,4112,0,17,2,268,17,2049,5392,4096,2309,1284,0,256,1,5376,513]

theorem envBound38064 : H12AffineFastState.Bounded env38064 := by
  intro p hp
  have h : env38064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38063_38064 : H12AffineEnvironment.transform 12 269 env38063 = env38064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38063 == env38064) = true)

theorem identity38064 : scanCanonicalize (H12AffineFastState.compose env38064 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound38064 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38065 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,1297,269,16,1,262,1,2308,1024,0,1281,0,17,2,268,17,2049,1,1297,2309,1284,0,256,1,17,513]

theorem envBound38065 : H12AffineFastState.Bounded env38065 := by
  intro p hp
  have h : env38065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38064_38065 : H12AffineEnvironment.transform 11 1297 env38064 = env38065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env38064 == env38065) = true)

theorem identity38065 : scanCanonicalize (H12AffineFastState.compose env38065 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound38065 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38066 : List Nat := [2,4,8,16,0,17,9,256,260,1024,2048,1297,269,16,1,262,1,2308,1024,0,1281,0,17,2,268,17,2049,1,1297,2309,1284,0,256,1,17,261]

theorem envBound38066 : H12AffineFastState.Bounded env38066 := by
  intro p hp
  have h : env38066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38065_38066 : H12AffineEnvironment.transform 8 260 env38065 = env38066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env38065 == env38066) = true)

theorem identity38066 : scanCanonicalize (H12AffineFastState.compose env38066 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound38066 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38067 : List Nat := [2,4,8,16,0,17,9,256,260,1024,277,1297,269,16,1,262,1,17,1024,0,1281,0,17,2,268,17,276,1,1297,16,1284,0,256,1,17,261]

theorem envBound38067 : H12AffineFastState.Bounded env38067 := by
  intro p hp
  have h : env38067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38066_38067 : H12AffineEnvironment.transform 10 277 env38066 = env38067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env38066 == env38067) = true)

theorem identity38067 : scanCanonicalize (H12AffineFastState.compose env38067 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound38067 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38068 : List Nat := [2,4,8,16,0,17,9,5,1,1024,16,1044,8,16,1,3,1,17,1024,0,1028,0,17,2,9,17,17,1,1044,16,1025,0,5,1,17,0]

theorem envBound38068 : H12AffineFastState.Bounded env38068 := by
  intro p hp
  have h : env38068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38067_38068 : H12AffineEnvironment.transform 7 5 env38067 = env38068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env38067 == env38068) = true)

def env38069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,62541,73857,8328,64,410092,57676,58461,406605,20700,21792,256,21792,46213,96010]

theorem envBound38069 : H12AffineFastState.Bounded env38069 := by
  intro p hp
  have h : env38069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38054_38069 : H12AffineEnvironment.transform 20 17729 env38054 = env38069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env38054 == env38069) = true)

theorem identity38069 : scanCanonicalize (H12AffineFastState.compose env38069 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound38069 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17729,21792,16,73857,8328,64,410092,5393,4096,406605,20700,21792,256,21792,16600,96010]

theorem envBound38070 : H12AffineFastState.Bounded env38070 := by
  intro p hp
  have h : env38070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38069_38070 : H12AffineEnvironment.transform 14 29789 env38069 = env38070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env38069 == env38070) = true)

def env38071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4161,32,16,73857,8328,64,398572,5393,4096,406605,1500,32,256,32,5592,74250]

theorem envBound38071 : H12AffineFastState.Bounded env38071 := by
  intro p hp
  have h : env38071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38070_38071 : H12AffineEnvironment.transform 13 5376 env38070 = env38071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38070 == env38071) = true)

theorem identity38071 : scanCanonicalize (H12AffineFastState.compose env38071 (packedSelected [0,1,4,7,11,15,16,19,20,22,28,31,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound38071 : packedSelected [0,1,4,7,11,15,16,19,20,22,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env38072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,4161,32,16,73857,8328,64,146509,5393,4096,138476,1500,32,256,32,5592,74250]

theorem envBound38072 : H12AffineFastState.Bounded env38072 := by
  intro p hp
  have h : env38072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38071_38072 : H12AffineEnvironment.transform 17 10401 env38071 = env38072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env38071 == env38072) = true)

theorem identity38072 : scanCanonicalize (H12AffineFastState.compose env38072 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound38072 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env38073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,70863,10401,1024,8540,4161,32,16,73857,8328,64,75906,5393,4096,67619,1500,32,256,32,5592,74250]

theorem envBound38073 : H12AffineFastState.Bounded env38073 := by
  intro p hp
  have h : env38073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38072_38073 : H12AffineEnvironment.transform 16 70863 env38072 = env38073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env38072 == env38073) = true)

theorem identity38073 : scanCanonicalize (H12AffineFastState.compose env38073 (packedSelected [0,2,5,7,12,14,15,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound38073 : packedSelected [0,2,5,7,12,14,15,19,20,24] rootPS < 2^1333 := by decide +kernel

def env38074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,342,5529,10401,1024,8540,4161,32,16,8663,8328,64,10708,5393,4096,2421,1500,32,256,32,5592,9052]

theorem envBound38074 : H12AffineFastState.Bounded env38074 := by
  intro p hp
  have h : env38074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38073_38074 : H12AffineEnvironment.transform 15 342 env38073 = env38074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env38073 == env38074) = true)

theorem identity38074 : scanCanonicalize (H12AffineFastState.compose env38074 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38074 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env38075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,0,342,5529,2556,1024,1,4161,32,16,138,469,64,2185,5393,4096,2421,1500,32,256,32,5592,513]

theorem envBound38075 : H12AffineFastState.Bounded env38075 := by
  intro p hp
  have h : env38075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38074_38075 : H12AffineEnvironment.transform 12 349 env38074 = env38075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38074 == env38075) = true)

theorem identity38075 : scanCanonicalize (H12AffineFastState.compose env38075 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38075 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38076 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5376,0,263,5529,2477,1024,1,4112,32,16,138,388,17,2185,5393,4096,2340,1421,32,256,32,5513,513]

theorem envBound38076 : H12AffineFastState.Bounded env38076 := by
  intro p hp
  have h : env38076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38075_38076 : H12AffineEnvironment.transform 5 17 env38075 = env38076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38075 == env38076) = true)

theorem identity38076 : scanCanonicalize (H12AffineFastState.compose env38076 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound38076 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env38077 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,161,5293,0,170,5172,2048,1024,1,4112,32,16,138,41,17,2185,5308,4096,2185,1056,32,173,32,5156,513]

theorem envBound38077 : H12AffineFastState.Bounded env38077 := by
  intro p hp
  have h : env38077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38076_38077 : H12AffineEnvironment.transform 7 173 env38076 = env38077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env38076 == env38077) = true)

theorem identity38077 : scanCanonicalize (H12AffineFastState.compose env38077 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound38077 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env38078 : List Nat := [2,4,8,16,32,17,128,173,512,1024,0,4096,161,5293,0,170,5172,0,1024,1,4112,32,16,138,41,17,137,5308,4096,137,1056,32,173,32,5156,513]

theorem envBound38078 : H12AffineFastState.Bounded env38078 := by
  intro p hp
  have h : env38078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38077_38078 : H12AffineEnvironment.transform 10 0 env38077 = env38078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env38077 == env38078) = true)

theorem identity38078 : scanCanonicalize (H12AffineFastState.compose env38078 (packedSelected [2,3,4,5,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound38078 : packedSelected [2,3,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env38079 : List Nat := [2,4,8,16,32,17,128,173,512,1024,0,1060,161,137,0,170,16,0,1024,1,1076,32,16,138,41,17,137,152,1060,137,1056,32,173,32,0,513]

theorem envBound38079 : H12AffineFastState.Bounded env38079 := by
  intro p hp
  have h : env38079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38078_38079 : H12AffineEnvironment.transform 11 1060 env38078 = env38079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env38078 == env38079) = true)

theorem identity38079 : scanCanonicalize (H12AffineFastState.compose env38079 (packedSelected [0,2,3,4,5,14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound38079 : packedSelected [0,2,3,4,5,14] rootPS < 2^1333 := by decide +kernel

def env38080 : List Nat := [2,4,8,16,32,17,128,173,512,52,0,16,161,137,0,170,16,0,52,1,0,32,16,138,41,17,137,152,16,137,20,32,173,32,0,513]

theorem envBound38080 : H12AffineFastState.Bounded env38080 := by
  intro p hp
  have h : env38080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38079_38080 : H12AffineEnvironment.transform 9 52 env38079 = env38080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38079 == env38080) = true)

theorem identity38080 : scanCanonicalize (H12AffineFastState.compose env38080 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38080 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env38081 : List Nat := [2,4,8,16,32,17,8,37,512,52,0,16,41,1,0,34,16,0,52,1,0,32,16,2,41,17,1,16,16,1,20,32,37,32,0,513]

theorem envBound38081 : H12AffineFastState.Bounded env38081 := by
  intro p hp
  have h : env38081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38080_38081 : H12AffineEnvironment.transform 6 8 env38080 = env38081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38080 == env38081) = true)

theorem identity38081 : scanCanonicalize (H12AffineFastState.compose env38081 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound38081 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38082 : List Nat := [2,4,8,16,32,17,8,37,32,52,0,16,41,1,0,34,16,0,52,1,0,32,16,2,41,17,1,16,16,1,20,32,37,32,0,33]

theorem envBound38082 : H12AffineFastState.Bounded env38082 := by
  intro p hp
  have h : env38082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38081_38082 : H12AffineEnvironment.transform 8 32 env38081 = env38082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env38081 == env38082) = true)

theorem identity38082 : scanCanonicalize (H12AffineFastState.compose env38082 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound38082 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38083 : List Nat := [2,4,8,1,32,0,8,37,32,37,0,1,41,1,0,34,1,0,37,1,0,32,1,2,41,0,1,1,1,1,5,32,37,32,0,33]

theorem envBound38083 : H12AffineFastState.Bounded env38083 := by
  intro p hp
  have h : env38083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38082_38083 : H12AffineEnvironment.transform 3 1 env38082 = env38083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38082 == env38083) = true)

def env38084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,4160,33,16,73857,8328,64,398573,5393,4096,406605,1501,33,256,33,5593,74251]

theorem envBound38084 : H12AffineFastState.Bounded env38084 := by
  intro p hp
  have h : env38084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38070_38084 : H12AffineEnvironment.transform 13 5377 env38070 = env38084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38070 == env38084) = true)

theorem identity38084 : scanCanonicalize (H12AffineFastState.compose env38084 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38084 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38085 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,4160,33,16,73737,8192,64,398437,5393,4096,406605,1365,33,256,33,5457,74251]

theorem envBound38085 : H12AffineFastState.Bounded env38085 := by
  intro p hp
  have h : env38085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38084_38085 : H12AffineEnvironment.transform 6 8 env38084 = env38085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38084 == env38085) = true)

theorem identity38085 : scanCanonicalize (H12AffineFastState.compose env38085 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 212078) := by decide +kernel

theorem selectedBound38085 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env38086 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,212078,1024,8541,4160,33,16,73737,8192,64,75787,5393,4096,67619,1365,33,256,33,5457,74251]

theorem envBound38086 : H12AffineFastState.Bounded env38086 := by
  intro p hp
  have h : env38086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38085_38086 : H12AffineEnvironment.transform 17 212078 env38085 = env38086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212078 env38085 == env38086) = true)

theorem identity38086 : scanCanonicalize (H12AffineFastState.compose env38086 (packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38086 : packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env38087 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,65536,131072,204082,1024,1,4160,33,16,65877,348,64,67927,5393,4096,67619,1365,33,256,33,5457,66391]

theorem envBound38087 : H12AffineFastState.Bounded env38087 := by
  intro p hp
  have h : env38087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38086_38087 : H12AffineEnvironment.transform 12 348 env38086 = env38087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38086 == env38087) = true)

theorem identity38087 : scanCanonicalize (H12AffineFastState.compose env38087 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound38087 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env38088 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,65536,5393,67619,1024,1,4160,33,16,65877,348,64,67927,5393,4096,67619,1365,33,256,33,5457,66391]

theorem envBound38088 : H12AffineFastState.Bounded env38088 := by
  intro p hp
  have h : env38088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38087_38088 : H12AffineEnvironment.transform 16 5393 env38087 = env38088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env38087 == env38088) = true)

theorem identity38088 : scanCanonicalize (H12AffineFastState.compose env38088 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 7175) := by decide +kernel

theorem selectedBound38088 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env38089 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,7175,5393,5156,1024,1,4160,33,16,7506,348,64,5456,5393,4096,5156,1365,33,256,33,5457,8016]

theorem envBound38089 : H12AffineFastState.Bounded env38089 := by
  intro p hp
  have h : env38089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38088_38089 : H12AffineEnvironment.transform 15 7175 env38088 = env38089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7175 env38088 == env38089) = true)

theorem identity38089 : scanCanonicalize (H12AffineFastState.compose env38089 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound38089 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env38090 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,348,5377,0,5126,5393,5156,1024,1,4160,33,16,5459,348,64,5456,5393,4096,5156,1365,33,256,33,5457,5969]

theorem envBound38090 : H12AffineFastState.Bounded env38090 := by
  intro p hp
  have h : env38090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38089_38090 : H12AffineEnvironment.transform 10 1 env38089 = env38090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env38089 == env38090) = true)

theorem identity38090 : scanCanonicalize (H12AffineFastState.compose env38090 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound38090 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env38091 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,1141,348,372,0,115,356,81,1024,1,1077,33,16,294,348,64,293,356,1141,81,1365,33,256,33,292,804]

theorem envBound38091 : H12AffineFastState.Bounded env38091 := by
  intro p hp
  have h : env38091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38090_38091 : H12AffineEnvironment.transform 11 1141 env38090 = env38091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env38090 == env38091) = true)

theorem identity38091 : scanCanonicalize (H12AffineFastState.compose env38091 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound38091 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env38092 : List Nat := [2,4,8,16,32,64,8,256,512,272,1,357,348,372,0,115,356,81,272,1,293,33,16,294,348,64,293,356,357,81,69,33,256,33,292,804]

theorem envBound38092 : H12AffineFastState.Bounded env38092 := by
  intro p hp
  have h : env38092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38091_38092 : H12AffineEnvironment.transform 9 272 env38091 = env38092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38091 == env38092) = true)

theorem identity38092 : scanCanonicalize (H12AffineFastState.compose env38092 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38092 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env38093 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,309,268,292,0,35,308,1,272,1,293,33,16,294,268,16,293,308,309,1,21,33,256,33,292,804]

theorem envBound38093 : H12AffineFastState.Bounded env38093 := by
  intro p hp
  have h : env38093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38092_38093 : H12AffineEnvironment.transform 5 16 env38092 = env38093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38092 == env38093) = true)

theorem identity38093 : scanCanonicalize (H12AffineFastState.compose env38093 (packedSelected [1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38093 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env38094 : List Nat := [2,4,8,16,32,16,8,37,512,53,1,16,41,1,0,35,17,1,53,1,0,33,16,3,41,16,0,17,16,1,21,33,37,33,1,513]

theorem envBound38094 : H12AffineFastState.Bounded env38094 := by
  intro p hp
  have h : env38094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38093_38094 : H12AffineEnvironment.transform 7 37 env38093 = env38094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38093 == env38094) = true)

theorem identity38094 : scanCanonicalize (H12AffineFastState.compose env38094 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound38094 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38095 : List Nat := [2,4,8,16,32,16,8,37,0,53,1,16,41,1,0,35,17,1,53,1,0,33,16,3,41,16,0,17,16,1,21,33,37,33,1,1]

theorem envBound38095 : H12AffineFastState.Bounded env38095 := by
  intro p hp
  have h : env38095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38094_38095 : H12AffineEnvironment.transform 8 0 env38094 = env38095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env38094 == env38095) = true)

theorem identity38095 : scanCanonicalize (H12AffineFastState.compose env38095 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38095 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38096 : List Nat := [2,4,8,11,32,11,8,37,0,46,1,11,41,1,0,35,10,1,46,1,0,33,11,3,41,11,0,10,11,1,14,33,37,33,1,1]

theorem envBound38096 : H12AffineFastState.Bounded env38096 := by
  intro p hp
  have h : env38096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38095_38096 : H12AffineEnvironment.transform 3 11 env38095 = env38096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38095 == env38096) = true)

theorem identity38096 : scanCanonicalize (H12AffineFastState.compose env38096 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound38096 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38097 : List Nat := [2,4,2,1,32,1,2,37,0,36,1,1,35,1,0,35,0,1,36,1,0,33,1,3,35,1,0,0,1,1,4,33,37,33,1,1]

theorem envBound38097 : H12AffineFastState.Bounded env38097 := by
  intro p hp
  have h : env38097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38096_38097 : H12AffineEnvironment.transform 2 2 env38096 = env38097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env38096 == env38097) = true)

def env38098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound38098 : H12AffineFastState.Bounded env38098 := by
  intro p hp
  have h : env38098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37897_38098 : H12AffineEnvironment.transform 18 1025 env37897 = env38098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env37897 == env38098) = true)

theorem identity38098 : scanCanonicalize (H12AffineFastState.compose env38098 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2262337) := by decide +kernel

theorem selectedBound38098 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env38099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262337,16777216,8328,64,23414080,18973837,184336,2377024,19071313,23160256,257,16990701,17014857,19015302]

theorem envBound38099 : H12AffineFastState.Bounded env38099 := by
  intro p hp
  have h : env38099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38098_38099 : H12AffineEnvironment.transform 22 2262337 env38098 = env38099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2262337 env38098 == env38099) = true)

def env38100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262337,201932,8328,64,6705548,2265153,184336,2377024,2102685,6451468,257,21793,46213,2175562]

theorem envBound38100 : H12AffineFastState.Bounded env38100 := by
  intro p hp
  have h : env38100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38099_38100 : H12AffineEnvironment.transform 23 201932 env38099 = env38100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 201932 env38099 == env38100) = true)

def env38101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6603932,2098513,17664,2377024,2102685,6349852,257,21793,46213,2175562]

theorem envBound38101 : H12AffineFastState.Bounded env38101 := by
  intro p hp
  have h : env38101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38100_38101 : H12AffineEnvironment.transform 16 38160 env38100 = env38101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env38100 == env38101) = true)

def env38102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2157596,2098513,17664,2377024,2102685,2411676,257,21793,46213,2175562]

theorem envBound38102 : H12AffineFastState.Bounded env38102 := by
  intro p hp
  have h : env38102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38101_38102 : H12AffineEnvironment.transform 21 272512 env38101 = env38102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38101 == env38102) = true)

def env38103 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272392,2101329,98644,8192,64,2157596,2098513,17664,2377024,2102549,2411540,257,21793,46093,2175562]

theorem envBound38103 : H12AffineFastState.Bounded env38103 := by
  intro p hp
  have h : env38103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38102_38103 : H12AffineEnvironment.transform 6 8 env38102 = env38103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38102 == env38103) = true)

theorem identity38103 : scanCanonicalize (H12AffineFastState.compose env38103 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 124235) := by decide +kernel

theorem selectedBound38103 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env38104 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,124235,272392,128282,98644,8192,64,67927,122906,17664,368651,127070,338271,257,21793,46093,55041]

theorem envBound38104 : H12AffineFastState.Bounded env38104 := by
  intro p hp
  have h : env38104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38103_38104 : H12AffineEnvironment.transform 20 124235 env38103 = env38104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124235 env38103 == env38104) = true)

theorem identity38104 : scanCanonicalize (H12AffineFastState.compose env38104 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound38104 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env38105 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,38160,262144,1025,32769,102679,272392,98630,98644,8192,64,67927,103494,12636,368651,99330,338271,257,8573,46093,41821]

theorem envBound38105 : H12AffineFastState.Bounded env38105 := by
  intro p hp
  have h : env38105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38104_38105 : H12AffineEnvironment.transform 13 13404 env38104 = env38105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env38104 == env38105) = true)

theorem identity38105 : scanCanonicalize (H12AffineFastState.compose env38105 (packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound38105 : packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env38106 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8540,65536,13388,262144,1025,8541,77899,272392,73754,73736,8192,64,67927,79130,12636,328023,75102,338271,257,8573,5457,513]

theorem envBound38106 : H12AffineFastState.Bounded env38106 := by
  intro p hp
  have h : env38106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38105_38106 : H12AffineEnvironment.transform 14 8540 env38105 = env38106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env38105 == env38106) = true)

theorem identity38106 : scanCanonicalize (H12AffineFastState.compose env38106 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 68914) := by decide +kernel

theorem selectedBound38106 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38107 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8540,65536,13388,68914,1025,8541,77899,75066,73754,73736,8192,64,67927,79130,12636,3173,75102,9325,257,8573,5457,513]

theorem envBound38107 : H12AffineFastState.Bounded env38107 := by
  intro p hp
  have h : env38107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38106_38107 : H12AffineEnvironment.transform 17 68914 env38106 = env38107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68914 env38106 == env38107) = true)

theorem identity38107 : scanCanonicalize (H12AffineFastState.compose env38107 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound38107 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38108 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,4113,1297,65536,4097,68914,1025,1296,70662,65911,66647,66629,1101,64,67927,69975,5393,3173,65811,32,257,1328,5457,513]

theorem envBound38108 : H12AffineFastState.Bounded env38108 := by
  intro p hp
  have h : env38108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38107_38108 : H12AffineEnvironment.transform 12 1101 env38107 = env38108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env38107 == env38108) = true)

theorem identity38108 : scanCanonicalize (H12AffineFastState.compose env38108 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound38108 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38109 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,4113,1297,342,4097,3172,1025,1296,5456,33,1281,1299,1101,64,2049,4097,5393,3173,69,32,257,1328,5457,513]

theorem envBound38109 : H12AffineFastState.Bounded env38109 := by
  intro p hp
  have h : env38109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38108_38109 : H12AffineEnvironment.transform 15 342 env38108 = env38109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env38108 == env38109) = true)

theorem identity38109 : scanCanonicalize (H12AffineFastState.compose env38109 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound38109 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env38110 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,1101,3173,1297,342,3189,3172,1025,1296,2340,33,1281,1299,1101,64,2049,3189,2405,3173,69,32,257,1328,2341,513]

theorem envBound38110 : H12AffineFastState.Bounded env38110 := by
  intro p hp
  have h : env38110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38109_38110 : H12AffineEnvironment.transform 11 3188 env38109 = env38110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env38109 == env38110) = true)

theorem identity38110 : scanCanonicalize (H12AffineFastState.compose env38110 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38110 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env38111 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3188,1101,3173,1077,114,3189,3172,1025,1076,2048,33,1061,1079,1101,64,2049,3189,2113,3173,69,32,37,1044,2049,513]

theorem envBound38111 : H12AffineFastState.Bounded env38111 := by
  intro p hp
  have h : env38111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38110_38111 : H12AffineEnvironment.transform 7 36 env38110 = env38111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38110 == env38111) = true)

theorem identity38111 : scanCanonicalize (H12AffineFastState.compose env38111 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38111 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env38112 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3108,1053,3125,1077,34,3109,3124,1025,1076,2048,33,1061,1079,1053,16,2049,3109,2065,3125,21,32,37,1044,2049,513]

theorem envBound38112 : H12AffineFastState.Bounded env38112 := by
  intro p hp
  have h : env38112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38111_38112 : H12AffineEnvironment.transform 5 16 env38111 = env38112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38111 == env38112) = true)

theorem identity38112 : scanCanonicalize (H12AffineFastState.compose env38112 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound38112 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env38113 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2065,40,2048,0,34,2064,2049,52,1,2048,33,16,2,40,16,2049,2064,2065,2048,21,32,37,33,2049,513]

theorem envBound38113 : H12AffineFastState.Bounded env38113 := by
  intro p hp
  have h : env38113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38112_38113 : H12AffineEnvironment.transform 9 53 env38112 = env38113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38112 == env38113) = true)

theorem identity38113 : scanCanonicalize (H12AffineFastState.compose env38113 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound38113 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38114 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,33,40,48,0,34,32,49,52,1,48,33,16,2,40,16,49,32,33,48,21,32,37,33,49,513]

theorem envBound38114 : H12AffineFastState.Bounded env38114 := by
  intro p hp
  have h : env38114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38113_38114 : H12AffineEnvironment.transform 10 48 env38113 = env38114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env38113 == env38114) = true)

def leafEnv38114 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,33,40,48,0,34,32,49,52,1,48,33,16,2,20,40,1,16,49,32,33,48,21,32,37,33,5,34,49,513,1,49,0]

def active38114 : List Nat := [0,1,2,3,4,8]

def tree38114 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38114 : H12WitnessSearch.Good tree38114 := H12GlobalWitnessIndex.good

theorem leafIdentity38114 : H12AffineFastState.composeSystem env38114 rootObs = leafEnv38114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38114 rootObs == leafEnv38114) = true)

theorem terminalChecked38114 : H12PackedTerminal.terminalCheckFast leafEnv38114 active38114 tree38114 = true := by decide +kernel

def env38115 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272393,2101329,98645,8193,64,2157596,2098513,17664,2377024,2102548,2411541,257,21793,46092,2175562]

theorem envBound38115 : H12AffineFastState.Bounded env38115 := by
  intro p hp
  have h : env38115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38102_38115 : H12AffineEnvironment.transform 6 9 env38102 = env38115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38102 == env38115) = true)

def env38116 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,272393,17,98645,8193,64,64604,5393,17664,283904,1364,318549,257,21793,46092,74250]

theorem envBound38116 : H12AffineFastState.Bounded env38116 := by
  intro p hp
  have h : env38116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38115_38116 : H12AffineEnvironment.transform 20 4160 env38115 = env38116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38115 == env38116) = true)

theorem identity38116 : scanCanonicalize (H12AffineFastState.compose env38116 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38116 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,4160,33,17,98645,8193,64,64604,5393,17664,32040,1364,62589,257,21793,46092,74250]

theorem envBound38117 : H12AffineFastState.Bounded env38117 := by
  intro p hp
  have h : env38117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38116_38117 : H12AffineEnvironment.transform 17 10280 env38116 = env38117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38116 == env38117) = true)

theorem identity38117 : scanCanonicalize (H12AffineFastState.compose env38117 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound38117 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env38118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,38160,10280,1025,32769,4160,33,17,98645,8193,64,43357,5393,4097,10281,1364,41340,257,32,46092,74250]

theorem envBound38118 : H12AffineFastState.Bounded env38118 := by
  intro p hp
  have h : env38118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38117_38118 : H12AffineEnvironment.transform 13 5377 env38117 = env38118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38117 == env38118) = true)

theorem identity38118 : scanCanonicalize (H12AffineFastState.compose env38118 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound38118 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env38119 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,40971,38160,10280,1025,32769,4160,33,17,8542,8193,64,43357,5393,4097,10281,1364,41340,257,32,46092,33281]

theorem envBound38119 : H12AffineFastState.Bounded env38119 := by
  intro p hp
  have h : env38119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38118_38119 : H12AffineEnvironment.transform 15 40971 env38118 = env38119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env38118 == env38119) = true)

theorem identity38119 : scanCanonicalize (H12AffineFastState.compose env38119 (packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound38119 : packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env38120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,81,8282,5441,10280,1025,80,4160,33,17,8542,8193,64,10508,5393,4097,10281,1364,8493,257,32,13405,592]

theorem envBound38120 : H12AffineFastState.Bounded env38120 := by
  intro p hp
  have h : env38120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38119_38120 : H12AffineEnvironment.transform 14 81 env38119 = env38120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env38119 == env38120) = true)

theorem identity38120 : scanCanonicalize (H12AffineFastState.compose env38120 (packedSelected [4,9,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound38120 : packedSelected [4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env38121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1141,8192,372,81,8282,308,10280,1025,80,1077,33,17,8542,8193,64,10508,356,1140,10281,1364,8493,257,32,8232,592]

theorem envBound38121 : H12AffineFastState.Bounded env38121 := by
  intro p hp
  have h : env38121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38120_38121 : H12AffineEnvironment.transform 11 1141 env38120 = env38121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env38120 == env38121) = true)

theorem identity38121 : scanCanonicalize (H12AffineFastState.compose env38121 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound38121 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env38122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1141,2317,372,81,2391,308,293,1025,80,1077,33,17,2131,2316,64,1,356,1140,292,1364,2080,257,32,2341,592]

theorem envBound38122 : H12AffineFastState.Bounded env38122 := by
  intro p hp
  have h : env38122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38121_38122 : H12AffineEnvironment.transform 12 2317 env38121 = env38122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env38121 == env38122) = true)

def env38123 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,272393,16,98645,8193,64,64605,5392,17664,283905,1365,318548,257,21793,46092,74251]

theorem envBound38123 : H12AffineFastState.Bounded env38123 := by
  intro p hp
  have h : env38123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38115_38123 : H12AffineEnvironment.transform 20 4161 env38115 = env38123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38115 == env38123) = true)

theorem identity38123 : scanCanonicalize (H12AffineFastState.compose env38123 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38123 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env38124 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,262144,1025,32769,4161,272393,16,41311,8193,64,64605,5392,17664,283905,1365,318548,257,21793,46092,513]

theorem envBound38124 : H12AffineFastState.Bounded env38124 := by
  intro p hp
  have h : env38124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38123_38124 : H12AffineEnvironment.transform 15 8202 env38123 = env38124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38123 == env38124) = true)

theorem identity38124 : scanCanonicalize (H12AffineFastState.compose env38124 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound38124 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env38125 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8202,16400,262144,1025,21761,4161,272393,16,29791,8193,64,10589,5392,17664,283905,1365,264532,257,21793,24844,513]

theorem envBound38125 : H12AffineFastState.Bounded env38125 := by
  intro p hp
  have h : env38125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38124_38125 : H12AffineEnvironment.transform 14 21760 env38124 = env38125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env38124 == env38125) = true)

theorem identity38125 : scanCanonicalize (H12AffineFastState.compose env38125 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound38125 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38126 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,8202,13388,262144,1025,8541,4161,272393,16,3,8193,64,10589,5392,12636,270685,1365,264532,257,8573,5456,513]

theorem envBound38126 : H12AffineFastState.Bounded env38126 := by
  intro p hp
  have h : env38126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38125_38126 : H12AffineEnvironment.transform 13 13404 env38125 = env38126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env38125 == env38126) = true)

theorem identity38126 : scanCanonicalize (H12AffineFastState.compose env38126 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38126 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38127 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,80,262,5440,262144,1025,81,4161,264453,16,3,269,64,2129,5392,4176,262225,1365,264532,257,113,5456,513]

theorem envBound38127 : H12AffineFastState.Bounded env38127 := by
  intro p hp
  have h : env38127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38126_38127 : H12AffineEnvironment.transform 12 268 env38126 = env38127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38126 == env38127) = true)

theorem identity38127 : scanCanonicalize (H12AffineFastState.compose env38127 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38127 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38128 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,41,5237,80,35,5221,262144,1025,81,4161,264224,16,3,40,64,2129,5173,4176,262225,1136,264305,36,113,5237,513]

theorem envBound38128 : H12AffineFastState.Bounded env38128 := by
  intro p hp
  have h : env38128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38127_38128 : H12AffineEnvironment.transform 7 37 env38127 = env38128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38127 == env38128) = true)

theorem identity38128 : scanCanonicalize (H12AffineFastState.compose env38128 (packedSelected [0,2,7] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound38128 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env38129 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,41,5237,80,35,5221,2049,1025,81,4161,33,16,3,40,64,2129,5173,4176,2128,1136,112,36,113,5237,513]

theorem envBound38129 : H12AffineFastState.Bounded env38129 := by
  intro p hp
  have h : env38129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38128_38129 : H12AffineEnvironment.transform 17 2049 env38128 = env38129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env38128 == env38129) = true)

theorem identity38129 : scanCanonicalize (H12AffineFastState.compose env38129 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38129 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env38130 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5156,1,35,5172,2049,1025,0,4112,33,16,3,40,17,2048,5173,4097,2049,1057,33,36,32,5156,513]

theorem envBound38130 : H12AffineFastState.Bounded env38130 := by
  intro p hp
  have h : env38130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38129_38130 : H12AffineEnvironment.transform 5 17 env38129 = env38130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38129 == env38130) = true)

def env38131 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,41,1044,1,35,1028,2049,1025,0,32,33,16,3,40,17,2048,1029,49,2049,1057,33,36,32,1044,513]

theorem envBound38131 : H12AffineFastState.Bounded env38131 := by
  intro p hp
  have h : env38131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38130_38131 : H12AffineEnvironment.transform 11 48 env38130 = env38131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env38130 == env38131) = true)

def env38132 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,41,1045,1,35,1029,2049,1025,0,33,33,16,3,40,17,2048,1028,48,2049,1057,33,36,32,1045,513]

theorem envBound38132 : H12AffineFastState.Bounded env38132 := by
  intro p hp
  have h : env38132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38130_38132 : H12AffineEnvironment.transform 11 49 env38130 = env38132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env38130 == env38132) = true)

theorem identity38132 : scanCanonicalize (H12AffineFastState.compose env38132 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound38132 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38133 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,49,41,32,1,35,48,2049,52,0,33,33,16,3,40,17,2048,49,48,2049,20,33,36,32,32,513]

theorem envBound38133 : H12AffineFastState.Bounded env38133 := by
  intro p hp
  have h : env38133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38132_38133 : H12AffineEnvironment.transform 9 53 env38132 = env38133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38132 == env38133) = true)

def env38134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2157597,2098513,17664,2377024,2102685,2411677,257,21793,46213,2175562]

theorem envBound38134 : H12AffineFastState.Bounded env38134 := by
  intro p hp
  have h : env38134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38101_38134 : H12AffineEnvironment.transform 21 272513 env38101 = env38134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38101 == env38134) = true)

theorem identity38134 : scanCanonicalize (H12AffineFastState.compose env38134 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound38134 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,272513,17,98780,8328,64,64605,5393,17664,283904,1501,318685,257,21793,46213,74250]

theorem envBound38135 : H12AffineFastState.Bounded env38135 := by
  intro p hp
  have h : env38135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38134_38135 : H12AffineEnvironment.transform 20 4160 env38134 = env38135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38134 == env38135) = true)

theorem identity38135 : scanCanonicalize (H12AffineFastState.compose env38135 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound38135 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env38136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,4160,272513,17,41431,8328,64,64605,5393,17664,283904,1501,318685,257,21793,46213,513]

theorem envBound38136 : H12AffineFastState.Bounded env38136 := by
  intro p hp
  have h : env38136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38135_38136 : H12AffineEnvironment.transform 15 8203 env38135 = env38136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env38135 == env38136) = true)

def env38137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6603933,2098512,17665,2377024,2102685,6349853,257,21793,46213,2175562]

theorem envBound38137 : H12AffineFastState.Bounded env38137 := by
  intro p hp
  have h : env38137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38100_38137 : H12AffineEnvironment.transform 16 38161 env38100 = env38137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env38100 == env38137) = true)

def env38138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2157597,2098512,17665,2377024,2102685,2411677,257,21793,46213,2175562]

theorem envBound38138 : H12AffineFastState.Bounded env38138 := by
  intro p hp
  have h : env38138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38137_38138 : H12AffineEnvironment.transform 21 272512 env38137 = env38138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38137 == env38138) = true)

theorem identity38138 : scanCanonicalize (H12AffineFastState.compose env38138 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound38138 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,25029,262144,1025,29909,2097152,272512,2101328,95497,8328,64,2103497,2098512,17665,2377024,2102685,2373705,257,21793,16465,2175562]

theorem envBound38139 : H12AffineFastState.Bounded env38139 := by
  intro p hp
  have h : env38139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38138_38139 : H12AffineEnvironment.transform 14 29908 env38138 = env38139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env38138 == env38139) = true)

def env38140 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,24981,262144,1025,29829,2097152,272512,2101248,95497,8328,16,2103449,2098432,17665,2376976,2102685,2373657,257,21793,16385,2175514]

theorem envBound38140 : H12AffineFastState.Bounded env38140 := by
  intro p hp
  have h : env38140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38139_38140 : H12AffineEnvironment.transform 5 16 env38139 = env38140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38139 == env38140) = true)

theorem identity38140 : scanCanonicalize (H12AffineFastState.compose env38140 (packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38140 : packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env38141 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,65536,13461,262144,1025,8581,2097152,272512,2101248,73737,8328,16,2103449,2098432,4097,2363408,2102685,2373657,257,33,5377,2175514]

theorem envBound38141 : H12AffineFastState.Bounded env38141 := by
  intro p hp
  have h : env38141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38140_38141 : H12AffineEnvironment.transform 13 5376 env38140 = env38141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38140 == env38141) = true)

theorem identity38141 : scanCanonicalize (H12AffineFastState.compose env38141 (packedSelected [0,9,10,14,16,17,18,19,20,22,23,26,27,31,35] rootPS)) = affineNative (2^(20+1) ^^^ 268733) := by decide +kernel

theorem selectedBound38141 : packedSelected [0,9,10,14,16,17,18,19,20,22,23,26,27,31,35] rootPS < 2^1333 := by decide +kernel

def env38142 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,65536,13461,262144,1025,8581,268733,272512,264637,73737,8328,16,262436,269501,4097,2477,265248,8612,257,33,5377,338855]

theorem envBound38142 : H12AffineFastState.Bounded env38142 := by
  intro p hp
  have h : env38142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38141_38142 : H12AffineEnvironment.transform 20 268733 env38141 = env38142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268733 env38141 == env38142) = true)

theorem identity38142 : scanCanonicalize (H12AffineFastState.compose env38142 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 76078) := by decide +kernel

theorem selectedBound38142 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env38143 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,65536,13461,76078,1025,8581,77971,65966,73875,73737,8328,16,75786,79251,4097,2477,75022,8612,257,33,5377,649]

theorem envBound38143 : H12AffineFastState.Bounded env38143 := by
  intro p hp
  have h : env38143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38142_38143 : H12AffineEnvironment.transform 17 76078 env38142 = env38143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76078 env38142 == env38143) = true)

theorem identity38143 : scanCanonicalize (H12AffineFastState.compose env38143 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound38143 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env38144 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,4096,8192,4404,8580,65536,12449,76078,53,8581,77971,65966,73875,73737,8328,16,75786,78247,4097,2477,74042,8612,257,33,4405,649]

theorem envBound38144 : H12AffineFastState.Bounded env38144 := by
  intro p hp
  have h : env38144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38143_38144 : H12AffineEnvironment.transform 9 52 env38143 = env38144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38143 == env38144) = true)

theorem identity38144 : scanCanonicalize (H12AffineFastState.compose env38144 (packedSelected [1,3,5,8,10,11,12,15,17,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound38144 : packedSelected [1,3,5,8,10,11,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env38145 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,4096,8192,4404,8461,65536,12328,76078,53,8460,77850,65831,73754,73737,8193,16,75786,78126,4097,2340,74042,8493,257,33,4405,512]

theorem envBound38145 : H12AffineFastState.Bounded env38145 := by
  intro p hp
  have h : env38145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38144_38145 : H12AffineEnvironment.transform 6 9 env38144 = env38145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38144 == env38145) = true)

theorem identity38145 : scanCanonicalize (H12AffineFastState.compose env38145 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38145 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38146 : List Nat := [2,4,8,16,0,16,9,256,512,20,2048,4096,8192,4372,8461,65536,12296,76046,21,8460,77850,65799,73754,73737,8193,16,75786,78094,4097,2308,74010,8461,257,1,4373,512]

theorem envBound38146 : H12AffineFastState.Bounded env38146 := by
  intro p hp
  have h : env38146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38145_38146 : H12AffineEnvironment.transform 4 0 env38145 = env38146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38145 == env38146) = true)

theorem identity38146 : scanCanonicalize (H12AffineFastState.compose env38146 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound38146 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38147 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,4096,8192,4113,8200,65536,12296,75787,21,8201,77850,65538,73754,73737,8193,16,75786,77835,4097,2049,73759,8200,4,1,4112,512]

theorem envBound38147 : H12AffineFastState.Bounded env38147 := by
  intro p hp
  have h : env38147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38146_38147 : H12AffineEnvironment.transform 7 5 env38146 = env38147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env38146 == env38147) = true)

theorem identity38147 : scanCanonicalize (H12AffineFastState.compose env38147 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38147 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38148 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,4096,8192,4113,8200,8202,12296,2049,21,8201,4112,8200,16,3,8193,16,2048,4097,4097,2049,21,8200,4,1,4112,512]

theorem envBound38148 : H12AffineFastState.Bounded env38148 := by
  intro p hp
  have h : env38148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38147_38148 : H12AffineEnvironment.transform 15 8202 env38147 = env38148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38147 == env38148) = true)

theorem identity38148 : scanCanonicalize (H12AffineFastState.compose env38148 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound38148 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38149 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,4096,8,4113,0,2,4096,2049,21,1,4112,0,16,3,9,16,2048,4097,4097,2049,21,0,4,1,4112,512]

theorem envBound38149 : H12AffineFastState.Bounded env38149 := by
  intro p hp
  have h : env38149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38148_38149 : H12AffineEnvironment.transform 12 8 env38148 = env38149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env38148 == env38149) = true)

theorem identity38149 : scanCanonicalize (H12AffineFastState.compose env38149 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2590) := by decide +kernel

theorem selectedBound38149 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38150 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,2590,8,2575,0,2,2590,2049,21,1,2574,0,16,3,9,16,2048,2591,2591,2049,21,0,4,1,2574,512]

theorem envBound38150 : H12AffineFastState.Bounded env38150 := by
  intro p hp
  have h : env38150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38149_38150 : H12AffineEnvironment.transform 11 2590 env38149 = env38150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2590 env38149 == env38150) = true)

theorem identity38150 : scanCanonicalize (H12AffineFastState.compose env38150 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound38150 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38151 : List Nat := [2,4,8,16,0,16,9,5,14,20,2048,2064,8,2049,0,2,2064,2049,21,1,2048,0,16,3,9,16,2048,2065,2065,2049,21,0,4,1,2048,14]

theorem envBound38151 : H12AffineFastState.Bounded env38151 := by
  intro p hp
  have h : env38151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38150_38151 : H12AffineEnvironment.transform 8 14 env38150 = env38151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env38150 == env38151) = true)

def env38152 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,24980,262144,1025,29828,2097152,272512,2101249,95497,8328,17,2103448,2098433,17665,2376977,2102685,2373656,257,21793,16384,2175515]

theorem envBound38152 : H12AffineFastState.Bounded env38152 := by
  intro p hp
  have h : env38152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38139_38152 : H12AffineEnvironment.transform 5 17 env38139 = env38152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38139 == env38152) = true)

theorem identity38152 : scanCanonicalize (H12AffineFastState.compose env38152 (packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 4248) := by decide +kernel

theorem selectedBound38152 : packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env38153 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,24980,262144,1025,29828,4248,272512,153,95497,8328,17,2048,5529,17665,284041,1285,272512,257,21793,16384,74371]

theorem envBound38153 : H12AffineFastState.Bounded env38153 := by
  intro p hp
  have h : env38153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38152_38153 : H12AffineEnvironment.transform 20 4248 env38152 = env38153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4248 env38152 == env38153) = true)

theorem identity38153 : scanCanonicalize (H12AffineFastState.compose env38153 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound38153 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env38154 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,24980,76198,1025,29828,4248,65830,153,95497,8328,17,2048,5529,17665,97327,1285,65830,257,21793,16384,74371]

theorem envBound38154 : H12AffineFastState.Bounded env38154 := by
  intro p hp
  have h : env38154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38153_38154 : H12AffineEnvironment.transform 17 76198 env38153 = env38154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env38153 == env38154) = true)

theorem identity38154 : scanCanonicalize (H12AffineFastState.compose env38154 (packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound38154 : packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS < 2^1333 := by decide +kernel

def env38155 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,1,65536,5392,76198,1025,0,4248,65830,153,65933,8328,17,2048,5529,12677,67755,1285,65830,257,8613,13444,74371]

theorem envBound38155 : H12AffineFastState.Bounded env38155 := by
  intro p hp
  have h : env38155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38154_38155 : H12AffineEnvironment.transform 13 13444 env38154 = env38155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env38154 == env38155) = true)

theorem identity38155 : scanCanonicalize (H12AffineFastState.compose env38155 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound38155 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env38156 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,1,263,5392,10401,1025,0,4248,33,153,138,8328,17,2048,5529,12677,2476,1285,33,257,8613,13444,9092]

theorem envBound38156 : H12AffineFastState.Bounded env38156 := by
  intro p hp
  have h : env38156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38155_38156 : H12AffineEnvironment.transform 15 263 env38155 = env38156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env38155 == env38156) = true)

def env38157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2157596,2098512,17665,2377024,2102685,2411676,257,21793,46213,2175562]

theorem envBound38157 : H12AffineFastState.Bounded env38157 := by
  intro p hp
  have h : env38157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38137_38157 : H12AffineEnvironment.transform 21 272513 env38137 = env38157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38137 == env38157) = true)

theorem identity38157 : scanCanonicalize (H12AffineFastState.compose env38157 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound38157 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58517,272513,62661,98781,8328,64,2185,57797,17665,303573,61704,272393,257,21793,46213,120543]

theorem envBound38158 : H12AffineFastState.Bounded env38158 := by
  intro p hp
  have h : env38158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38157_38158 : H12AffineEnvironment.transform 20 58517 env38157 = env38158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env38157 == env38158) = true)

def env38159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,58517,169,62661,98781,8328,64,2185,57797,17665,35325,61704,33,257,21793,46213,120543]

theorem envBound38159 : H12AffineFastState.Bounded env38159 := by
  intro p hp
  have h : env38159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38158_38159 : H12AffineEnvironment.transform 17 10280 env38158 = env38159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38158 == env38159) = true)

theorem identity38159 : scanCanonicalize (H12AffineFastState.compose env38159 (packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound38159 : packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env38160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,65536,38161,10280,1025,32769,36928,169,32784,98781,8328,64,2185,38160,12756,35325,34269,33,257,8692,46213,107018]

theorem envBound38160 : H12AffineFastState.Bounded env38160 := by
  intro p hp
  have h : env38160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38159_38160 : H12AffineEnvironment.transform 13 13525 env38159 = env38160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env38159 == env38160) = true)

theorem identity38160 : scanCanonicalize (H12AffineFastState.compose env38160 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 41090) := by decide +kernel

theorem selectedBound38160 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env38161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,41090,38161,10280,1025,32769,36928,169,32784,8543,8328,64,2185,38160,12756,35325,34269,33,257,8692,46213,648]

theorem envBound38161 : H12AffineFastState.Bounded env38161 := by
  intro p hp
  have h : env38161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38160_38161 : H12AffineEnvironment.transform 15 41090 env38160 = env38161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41090 env38160 == env38161) = true)

theorem identity38161 : scanCanonicalize (H12AffineFastState.compose env38161 (packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound38161 : packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS < 2^1333 := by decide +kernel

def env38162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,81,8403,5440,10280,1025,80,4113,169,65,8543,8328,64,2185,5441,12756,2476,1420,33,257,8692,13524,648]

theorem envBound38162 : H12AffineFastState.Bounded env38162 := by
  intro p hp
  have h : env38162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38161_38162 : H12AffineEnvironment.transform 14 81 env38161 = env38162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env38161 == env38162) = true)

theorem identity38162 : scanCanonicalize (H12AffineFastState.compose env38162 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound38162 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env38163 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,13324,81,8202,5440,10280,1025,80,4113,112,65,8543,8273,64,2128,5441,12557,2421,1365,33,257,8493,13325,593]

theorem envBound38163 : H12AffineFastState.Bounded env38163 := by
  intro p hp
  have h : env38163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38162_38163 : H12AffineEnvironment.transform 6 89 env38162 = env38163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env38162 == env38163) = true)

theorem identity38163 : scanCanonicalize (H12AffineFastState.compose env38163 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38163 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env38164 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5457,81,343,5440,2421,1025,80,4113,112,65,2,268,64,2128,5441,4176,2421,1365,33,257,112,5456,593]

theorem envBound38164 : H12AffineFastState.Bounded env38164 := by
  intro p hp
  have h : env38164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38163_38164 : H12AffineEnvironment.transform 12 349 env38163 = env38164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38163 == env38164) = true)

theorem identity38164 : scanCanonicalize (H12AffineFastState.compose env38164 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound38164 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env38165 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,261,349,1108,81,343,1093,2421,1025,80,276,112,65,2,268,64,2128,1092,341,2421,1365,33,257,112,1109,593]

theorem envBound38165 : H12AffineFastState.Bounded env38165 := by
  intro p hp
  have h : env38165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38164_38165 : H12AffineEnvironment.transform 11 261 env38164 = env38165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env38164 == env38165) = true)

theorem identity38165 : scanCanonicalize (H12AffineFastState.compose env38165 (packedSelected [0,1,3,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 341) := by decide +kernel

theorem selectedBound38165 : packedSelected [0,1,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env38166 : List Nat := [2,4,8,16,32,64,89,256,341,1024,2048,261,349,1108,81,343,1093,2421,1025,80,276,112,65,2,268,64,2128,1092,341,2421,1365,33,257,112,1109,260]

theorem envBound38166 : H12AffineFastState.Bounded env38166 := by
  intro p hp
  have h : env38166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38165_38166 : H12AffineEnvironment.transform 8 341 env38165 = env38166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env38165 == env38166) = true)

theorem identity38166 : scanCanonicalize (H12AffineFastState.compose env38166 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38166 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38167 : List Nat := [2,4,8,16,32,16,9,256,261,1024,2048,261,269,1028,1,263,1045,2341,1025,0,276,32,17,2,268,16,2048,1044,261,2341,1285,33,257,32,1029,260]

theorem envBound38167 : H12AffineFastState.Bounded env38167 := by
  intro p hp
  have h : env38167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38166_38167 : H12AffineEnvironment.transform 5 16 env38166 = env38167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38166 == env38167) = true)

theorem identity38167 : scanCanonicalize (H12AffineFastState.compose env38167 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound38167 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38168 : List Nat := [2,4,8,16,32,16,9,256,261,21,2048,261,269,17,1,263,0,2341,20,0,276,32,17,2,268,16,2048,1,261,2341,272,33,257,32,16,260]

theorem envBound38168 : H12AffineFastState.Bounded env38168 := by
  intro p hp
  have h : env38168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38167_38168 : H12AffineEnvironment.transform 9 21 env38167 = env38168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env38167 == env38168) = true)

theorem identity38168 : scanCanonicalize (H12AffineFastState.compose env38168 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound38168 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38169 : List Nat := [2,4,8,16,32,16,9,256,261,21,42,261,269,17,1,263,0,271,20,0,276,32,17,2,268,16,42,1,261,271,272,33,257,32,16,260]

theorem envBound38169 : H12AffineFastState.Bounded env38169 := by
  intro p hp
  have h : env38169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38168_38169 : H12AffineEnvironment.transform 10 42 env38168 = env38169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env38168 == env38169) = true)

theorem identity38169 : scanCanonicalize (H12AffineFastState.compose env38169 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38169 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38170 : List Nat := [2,4,8,16,0,16,9,256,261,21,10,261,269,17,1,263,0,271,20,0,276,0,17,2,268,16,10,1,261,271,272,1,257,0,16,260]

theorem envBound38170 : H12AffineFastState.Bounded env38170 := by
  intro p hp
  have h : env38170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38169_38170 : H12AffineEnvironment.transform 4 0 env38169 = env38170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38169 == env38170) = true)

theorem identity38170 : scanCanonicalize (H12AffineFastState.compose env38170 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound38170 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38171 : List Nat := [2,4,8,16,0,16,9,18,23,21,10,23,31,17,1,21,0,29,20,0,6,0,17,2,30,16,10,1,23,29,2,1,19,0,16,22]

theorem envBound38171 : H12AffineFastState.Bounded env38171 := by
  intro p hp
  have h : env38171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38170_38171 : H12AffineEnvironment.transform 7 18 env38170 = env38171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env38170 == env38171) = true)

def env38172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,58517,168,62661,98781,8328,64,2185,57797,17665,35324,61704,32,257,21793,46213,120543]

theorem envBound38172 : H12AffineFastState.Bounded env38172 := by
  intro p hp
  have h : env38172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38158_38172 : H12AffineEnvironment.transform 17 10281 env38158 = env38172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env38158 == env38172) = true)

theorem identity38172 : scanCanonicalize (H12AffineFastState.compose env38172 (packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 509) := by decide +kernel

theorem selectedBound38172 : packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env38173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,509,65536,5356,10281,1025,508,25960,168,30008,65568,8328,64,2185,24632,17665,2049,28917,32,257,21793,13688,87842]

theorem envBound38173 : H12AffineFastState.Bounded env38173 := by
  intro p hp
  have h : env38173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38172_38173 : H12AffineEnvironment.transform 14 509 env38172 = env38173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 509 env38172 == env38173) = true)

theorem identity38173 : scanCanonicalize (H12AffineFastState.compose env38173 (packedSelected [1,4,8,9,14,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 20943) := by decide +kernel

theorem selectedBound38173 : packedSelected [1,4,8,9,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env38174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,509,20943,5356,10281,1025,508,25960,168,30008,20975,8328,64,2185,24632,17665,2049,28917,32,257,21793,13688,1773]

theorem envBound38174 : H12AffineFastState.Bounded env38174 := by
  intro p hp
  have h : env38174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38173_38174 : H12AffineEnvironment.transform 15 20943 env38173 = env38174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20943 env38173 == env38174) = true)

theorem identity38174 : scanCanonicalize (H12AffineFastState.compose env38174 (packedSelected [1,8,10,12,15,17,26,31] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound38174 : packedSelected [1,8,10,12,15,17,26,31] rootPS < 2^1333 := by decide +kernel

def env38175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,509,9547,5356,10281,1025,508,4588,168,444,9579,8328,64,2185,5308,12677,2049,1137,32,257,8613,13688,1773]

theorem envBound38175 : H12AffineFastState.Bounded env38175 := by
  intro p hp
  have h : env38175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38174_38175 : H12AffineEnvironment.transform 13 13444 env38174 = env38175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env38174 == env38175) = true)

theorem identity38175 : scanCanonicalize (H12AffineFastState.compose env38175 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38175 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env38176 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,13444,216,9326,5356,10281,1025,217,4297,168,153,9294,8328,64,2185,5308,12448,2049,1137,32,36,8320,13405,1773]

theorem envBound38176 : H12AffineFastState.Bounded env38176 := by
  intro p hp
  have h : env38176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38175_38176 : H12AffineEnvironment.transform 7 37 env38175 = env38176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38175 == env38176) = true)

theorem identity38176 : scanCanonicalize (H12AffineFastState.compose env38176 (packedSelected [3,5,10,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound38176 : packedSelected [3,5,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env38177 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,1053,4249,216,115,5356,3124,1025,217,4297,168,153,83,1173,64,2185,5308,5309,2049,1137,32,36,1181,4160,1773]

theorem envBound38177 : H12AffineFastState.Bounded env38177 := by
  intro p hp
  have h : env38177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38176_38177 : H12AffineEnvironment.transform 12 1053 env38176 = env38177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env38176 == env38177) = true)

theorem identity38177 : scanCanonicalize (H12AffineFastState.compose env38177 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound38177 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38178 : List Nat := [2,4,8,16,32,64,128,37,512,236,2048,4096,241,4249,216,115,4096,2264,237,217,4297,168,153,83,121,64,2185,4176,4177,2049,157,32,36,113,4160,513]

theorem envBound38178 : H12AffineFastState.Bounded env38178 := by
  intro p hp
  have h : env38178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38177_38178 : H12AffineEnvironment.transform 9 236 env38177 = env38178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env38177 == env38178) = true)

def env38179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262337,201933,8328,64,6705549,2265152,184336,2377024,2102684,6451469,257,21792,46212,2175563]

theorem envBound38179 : H12AffineFastState.Bounded env38179 := by
  intro p hp
  have h : env38179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38099_38179 : H12AffineEnvironment.transform 23 201933 env38099 = env38179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 201933 env38099 == env38179) = true)

def env38180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6603933,2098512,17664,2377024,2102684,6349853,257,21792,46212,2175563]

theorem envBound38180 : H12AffineFastState.Bounded env38180 := by
  intro p hp
  have h : env38180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38179_38180 : H12AffineEnvironment.transform 16 38160 env38179 = env38180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env38179 == env38180) = true)

def env38181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2157597,2098512,17664,2377024,2102684,2411677,257,21792,46212,2175563]

theorem envBound38181 : H12AffineFastState.Bounded env38181 := by
  intro p hp
  have h : env38181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38180_38181 : H12AffineEnvironment.transform 21 272512 env38180 = env38181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38180 == env38181) = true)

theorem identity38181 : scanCanonicalize (H12AffineFastState.compose env38181 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound38181 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,115871,272512,120014,98781,8328,64,75906,115151,17664,360927,119043,329730,257,21792,46212,63188]

theorem envBound38182 : H12AffineFastState.Bounded env38182 := by
  intro p hp
  have h : env38182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38181_38182 : H12AffineEnvironment.transform 20 115871 env38181 = env38182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env38181 == env38182) = true)

def env38183 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,115871,272512,119966,98701,8328,16,75906,115103,17664,360847,119043,329730,257,21792,46212,63108]

theorem envBound38183 : H12AffineFastState.Bounded env38183 := by
  intro p hp
  have h : env38183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38182_38183 : H12AffineEnvironment.transform 5 16 env38182 = env38183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38182 == env38183) = true)

def env38184 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,115735,272392,119830,98565,8192,16,75786,114967,17664,360711,119043,329730,257,21792,46092,62988]

theorem envBound38184 : H12AffineFastState.Bounded env38184 := by
  intro p hp
  have h : env38184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38183_38184 : H12AffineEnvironment.transform 6 8 env38183 = env38184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38183 == env38184) = true)

theorem identity38184 : scanCanonicalize (H12AffineFastState.compose env38184 (packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 31756) := by decide +kernel

theorem selectedBound38184 : packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env38185 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,31756,1025,32769,115735,21508,119830,98565,8192,16,75786,114967,17664,130315,119043,95246,257,21792,46092,62988]

theorem envBound38185 : H12AffineFastState.Bounded env38185 := by
  intro p hp
  have h : env38185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38184_38185 : H12AffineEnvironment.transform 17 31756 env38184 = env38185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 31756 env38184 == env38185) = true)

theorem identity38185 : scanCanonicalize (H12AffineFastState.compose env38185 (packedSelected [1,2,3,5,6,8,9,10,11,14,16,17,18,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38185 : packedSelected [1,2,3,5,6,8,9,10,11,14,16,17,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env38186 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,32768,65536,38160,23809,1025,32769,115735,21508,119830,98565,269,16,67847,114967,17664,121862,119043,87299,257,21792,38145,55041]

theorem envBound38186 : H12AffineFastState.Bounded env38186 := by
  intro p hp
  have h : env38186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38185_38186 : H12AffineEnvironment.transform 12 269 env38185 = env38186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38185 == env38186) = true)

theorem identity38186 : scanCanonicalize (H12AffineFastState.compose env38186 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38186 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env38187 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,16384,32768,65536,37941,23588,1025,32769,115735,21508,119830,98336,40,16,67618,114738,17445,121862,118822,87078,36,21509,37924,54820]

theorem envBound38187 : H12AffineFastState.Bounded env38187 := by
  intro p hp
  have h : env38187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38186_38187 : H12AffineEnvironment.transform 7 37 env38186 = env38187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38186 == env38187) = true)

theorem identity38187 : scanCanonicalize (H12AffineFastState.compose env38187 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound38187 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env38188 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,16384,32768,54278,37941,23588,1025,32769,4113,21508,16,21542,40,16,56356,5172,17445,2048,1056,32800,36,21509,37924,54820]

theorem envBound38188 : H12AffineFastState.Bounded env38188 := by
  intro p hp
  have h : env38188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38187_38188 : H12AffineEnvironment.transform 15 54278 env38187 = env38188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env38187 == env38188) = true)

theorem identity38188 : scanCanonicalize (H12AffineFastState.compose env38188 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound38188 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38189 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5124,32768,32770,37941,2080,1025,32769,4113,0,16,34,40,16,34848,5172,4129,2048,1056,32800,36,1,37924,33312]

theorem envBound38189 : H12AffineFastState.Bounded env38189 := by
  intro p hp
  have h : env38189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38188_38189 : H12AffineEnvironment.transform 13 5124 env38188 = env38189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env38188 == env38189) = true)

theorem identity38189 : scanCanonicalize (H12AffineFastState.compose env38189 (packedSelected [2,3,5,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38189 : packedSelected [2,3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env38190 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,4096,8,5124,32768,32770,37909,2048,1025,32769,4113,0,16,2,8,16,34816,5140,4097,2048,1024,32768,4,1,37892,33280]

theorem envBound38190 : H12AffineFastState.Bounded env38190 := by
  intro p hp
  have h : env38190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38189_38190 : H12AffineEnvironment.transform 4 0 env38189 = env38190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38189 == env38190) = true)

theorem identity38190 : scanCanonicalize (H12AffineFastState.compose env38190 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound38190 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38191 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,4096,8,5124,0,2,5141,2048,1025,1,4113,0,16,2,8,16,2048,5140,4097,2048,1024,0,4,1,5124,512]

theorem envBound38191 : H12AffineFastState.Bounded env38191 := by
  intro p hp
  have h : env38191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38190_38191 : H12AffineEnvironment.transform 14 0 env38190 = env38191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env38190 == env38191) = true)

theorem identity38191 : scanCanonicalize (H12AffineFastState.compose env38191 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound38191 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38192 : List Nat := [2,4,8,16,0,16,8,5,512,21,2048,4096,8,4113,0,2,4096,2048,20,1,4113,0,16,2,8,16,2048,4097,4097,2048,21,0,4,1,4113,512]

theorem envBound38192 : H12AffineFastState.Bounded env38192 := by
  intro p hp
  have h : env38192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38191_38192 : H12AffineEnvironment.transform 9 21 env38191 = env38192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env38191 == env38192) = true)

theorem identity38192 : scanCanonicalize (H12AffineFastState.compose env38192 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound38192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38193 : List Nat := [2,4,8,16,0,16,8,5,512,21,2048,2049,8,2064,0,2,2049,2048,20,1,2064,0,16,2,8,16,2048,2048,2048,2048,21,0,4,1,2064,512]

theorem envBound38193 : H12AffineFastState.Bounded env38193 := by
  intro p hp
  have h : env38193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38192_38193 : H12AffineEnvironment.transform 11 2049 env38192 = env38193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env38192 == env38193) = true)

theorem identity38193 : scanCanonicalize (H12AffineFastState.compose env38193 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 526) := by decide +kernel

theorem selectedBound38193 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38194 : List Nat := [2,4,8,16,0,16,8,5,512,21,526,527,8,542,0,2,527,526,20,1,542,0,16,2,8,16,526,526,526,526,21,0,4,1,542,512]

theorem envBound38194 : H12AffineFastState.Bounded env38194 := by
  intro p hp
  have h : env38194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38193_38194 : H12AffineEnvironment.transform 10 526 env38193 = env38194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 526 env38193 == env38194) = true)

theorem identity38194 : scanCanonicalize (H12AffineFastState.compose env38194 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound38194 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38195 : List Nat := [2,4,8,16,0,16,8,5,15,21,1,0,8,17,0,2,0,1,20,1,17,0,16,2,8,16,1,1,1,1,21,0,4,1,17,15]

theorem envBound38195 : H12AffineFastState.Bounded env38195 := by
  intro p hp
  have h : env38195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38194_38195 : H12AffineEnvironment.transform 8 15 env38194 = env38195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env38194 == env38195) = true)

theorem identity38195 : scanCanonicalize (H12AffineFastState.compose env38195 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38195 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env38196 : List Nat := [2,4,8,0,0,0,8,5,15,5,1,0,8,1,0,2,0,1,4,1,1,0,0,2,8,0,1,1,1,1,5,0,4,1,1,15]

theorem envBound38196 : H12AffineFastState.Bounded env38196 := by
  intro p hp
  have h : env38196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38195_38196 : H12AffineEnvironment.transform 3 0 env38195 = env38196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38195 == env38196) = true)

def env38197 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,115734,272393,119831,98564,8193,16,75787,114966,17664,360710,119043,329730,257,21792,46093,62989]

theorem envBound38197 : H12AffineFastState.Bounded env38197 := by
  intro p hp
  have h : env38197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38183_38197 : H12AffineEnvironment.transform 6 9 env38183 = env38197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38183 == env38197) = true)

theorem identity38197 : scanCanonicalize (H12AffineFastState.compose env38197 (packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound38197 : packedSelected [0,3,7,8,9,12,14,15,16,17,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env38198 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,67619,1025,32769,115734,73770,119831,98564,8193,16,75787,114966,17664,35109,119043,33,257,21792,46093,62989]

theorem envBound38198 : H12AffineFastState.Bounded env38198 := by
  intro p hp
  have h : env38198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38197_38198 : H12AffineEnvironment.transform 17 67619 env38197 = env38198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env38197 == env38198) = true)

theorem identity38198 : scanCanonicalize (H12AffineFastState.compose env38198 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound38198 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env38199 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21761,65536,16401,67619,1025,21760,69911,73770,65814,87045,8193,16,75787,70679,17664,23588,66562,33,257,21792,24844,8972]

theorem envBound38199 : H12AffineFastState.Bounded env38199 := by
  intro p hp
  have h : env38199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38198_38199 : H12AffineEnvironment.transform 14 21761 env38198 = env38199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env38198 == env38199) = true)

theorem identity38199 : scanCanonicalize (H12AffineFastState.compose env38199 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound38199 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env38200 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21761,262,16401,2341,1025,21760,4113,8492,16,21763,8193,16,10509,5393,17664,23588,1284,33,257,21792,24844,8972]

theorem envBound38200 : H12AffineFastState.Bounded env38200 := by
  intro p hp
  have h : env38200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38199_38200 : H12AffineEnvironment.transform 15 262 env38199 = env38200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env38199 == env38200) = true)

theorem identity38200 : scanCanonicalize (H12AffineFastState.compose env38200 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound38200 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env38201 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,8461,262,13341,2341,1025,8460,4113,8492,16,8463,8193,16,10509,5393,12556,10280,1284,33,257,8492,5376,8972]

theorem envBound38201 : H12AffineFastState.Bounded env38201 := by
  intro p hp
  have h : env38201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38200_38201 : H12AffineEnvironment.transform 13 13324 env38200 = env38201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env38200 == env38201) = true)

theorem identity38201 : scanCanonicalize (H12AffineFastState.compose env38201 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound38201 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env38202 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1336,4404,1077,262,4389,2341,1025,1076,4113,1044,16,1079,1337,16,3125,5393,5172,3344,1284,33,257,1044,5376,1588]

theorem envBound38202 : H12AffineFastState.Bounded env38202 := by
  intro p hp
  have h : env38202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38201_38202 : H12AffineEnvironment.transform 12 1336 env38201 = env38202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env38201 == env38202) = true)

theorem identity38202 : scanCanonicalize (H12AffineFastState.compose env38202 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound38202 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env38203 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,1084,4144,1077,2,4129,2081,1025,1076,4113,1044,16,1079,1085,16,3125,5141,5172,3092,1024,33,5,1044,5124,1588]

theorem envBound38203 : H12AffineFastState.Bounded env38203 := by
  intro p hp
  have h : env38203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38202_38203 : H12AffineEnvironment.transform 7 4 env38202 = env38203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38202 == env38203) = true)

theorem identity38203 : scanCanonicalize (H12AffineFastState.compose env38203 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound38203 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env38204 : List Nat := [2,4,8,16,32,16,9,4,512,52,2048,4096,8,4144,1,2,4129,2081,53,0,4113,32,16,3,9,16,2049,4129,4096,2080,52,33,5,32,4144,512]

theorem envBound38204 : H12AffineFastState.Bounded env38204 := by
  intro p hp
  have h : env38204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38203_38204 : H12AffineEnvironment.transform 9 52 env38203 = env38204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38203 == env38204) = true)

theorem identity38204 : scanCanonicalize (H12AffineFastState.compose env38204 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38204 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38205 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,4096,8,4112,1,2,4097,2049,21,0,4113,0,16,3,9,16,2049,4097,4096,2048,20,1,5,0,4112,512]

theorem envBound38205 : H12AffineFastState.Bounded env38205 := by
  intro p hp
  have h : env38205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38204_38205 : H12AffineEnvironment.transform 4 0 env38204 = env38205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38204 == env38205) = true)

theorem identity38205 : scanCanonicalize (H12AffineFastState.compose env38205 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound38205 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38206 : List Nat := [2,4,8,16,0,16,9,4,512,20,513,4096,8,4112,1,2,4097,512,21,0,4113,0,16,3,9,16,512,4097,4096,513,20,1,5,0,4112,512]

theorem envBound38206 : H12AffineFastState.Bounded env38206 := by
  intro p hp
  have h : env38206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38205_38206 : H12AffineEnvironment.transform 10 513 env38205 = env38206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env38205 == env38206) = true)

theorem identity38206 : scanCanonicalize (H12AffineFastState.compose env38206 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound38206 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38207 : List Nat := [2,4,8,5,0,5,9,4,512,1,513,4096,8,4101,1,2,4097,512,0,0,4100,0,5,3,9,5,512,4097,4096,513,1,1,5,0,4101,512]

theorem envBound38207 : H12AffineFastState.Bounded env38207 := by
  intro p hp
  have h : env38207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38206_38207 : H12AffineEnvironment.transform 3 5 env38206 = env38207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env38206 == env38207) = true)

def env38208 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,115871,272512,119967,98700,8328,17,75906,115102,17664,360846,119043,329730,257,21792,46212,63109]

theorem envBound38208 : H12AffineFastState.Bounded env38208 := by
  intro p hp
  have h : env38208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38182_38208 : H12AffineEnvironment.transform 5 17 env38182 = env38208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38182 == env38208) = true)

theorem identity38208 : scanCanonicalize (H12AffineFastState.compose env38208 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38208 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env38209 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,115871,168,119967,98700,8328,17,75906,115102,17664,108966,119043,73770,257,21792,46212,63109]

theorem envBound38209 : H12AffineFastState.Bounded env38209 := by
  intro p hp
  have h : env38209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38208_38209 : H12AffineEnvironment.transform 17 10280 env38208 = env38209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38208 == env38209) = true)

theorem identity38209 : scanCanonicalize (H12AffineFastState.compose env38209 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound38209 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env38210 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,136,65536,5528,10280,1025,137,82967,168,87063,65796,8328,17,75906,82198,17664,76078,86411,73770,257,21792,13324,30221]

theorem envBound38210 : H12AffineFastState.Bounded env38210 := by
  intro p hp
  have h : env38210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38209_38210 : H12AffineEnvironment.transform 14 136 env38209 = env38210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env38209 == env38210) = true)

theorem identity38210 : scanCanonicalize (H12AffineFastState.compose env38210 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound38210 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env38211 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,136,65536,5528,10280,1025,137,77851,168,73755,65796,8328,17,75906,79130,12556,76078,75143,73770,257,8492,13324,513]

theorem envBound38211 : H12AffineFastState.Bounded env38211 := by
  intro p hp
  have h : env38211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38210_38211 : H12AffineEnvironment.transform 13 13324 env38210 = env38211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env38210 == env38211) = true)

theorem identity38211 : scanCanonicalize (H12AffineFastState.compose env38211 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38211 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38212 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,136,8202,5528,10280,1025,137,4113,168,17,8462,8328,17,2184,5392,12556,2340,1421,32,257,8492,13324,513]

theorem envBound38212 : H12AffineFastState.Bounded env38212 := by
  intro p hp
  have h : env38212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38211_38212 : H12AffineEnvironment.transform 15 8202 env38211 = env38212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38211 == env38212) = true)

theorem identity38212 : scanCanonicalize (H12AffineFastState.compose env38212 (packedSelected [3,4,5,7,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound38212 : packedSelected [3,4,5,7,11,14,15] rootPS < 2^1333 := by decide +kernel

def env38213 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2493,8192,11697,136,8202,3109,10280,1025,137,2476,168,17,8462,8328,17,2184,3245,10417,2340,1421,32,257,8492,11697,513]

theorem envBound38213 : H12AffineFastState.Bounded env38213 := by
  intro p hp
  have h : env38213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38212_38213 : H12AffineEnvironment.transform 11 2493 env38212 = env38213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env38212 == env38213) = true)

theorem identity38213 : scanCanonicalize (H12AffineFastState.compose env38213 (packedSelected [0,4,6,7,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38213 : packedSelected [0,4,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env38214 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,2200,8192,11412,136,8202,3109,10280,1025,137,2185,168,17,8235,8328,17,2184,3245,10417,2049,1192,32,36,8201,11412,513]

theorem envBound38214 : H12AffineFastState.Bounded env38214 := by
  intro p hp
  have h : env38214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38213_38214 : H12AffineEnvironment.transform 7 37 env38213 = env38214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38213 == env38214) = true)

def env38215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2157596,2098512,17664,2377024,2102684,2411676,257,21792,46212,2175563]

theorem envBound38215 : H12AffineFastState.Bounded env38215 := by
  intro p hp
  have h : env38215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38180_38215 : H12AffineEnvironment.transform 21 272513 env38180 = env38215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38180 == env38215) = true)

theorem identity38215 : scanCanonicalize (H12AffineFastState.compose env38215 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound38215 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,38160,262144,1025,32769,2097152,272513,2101329,21762,8328,64,2157596,2098512,17664,2377024,2102684,2411676,257,21792,46212,2156180]

theorem envBound38216 : H12AffineFastState.Bounded env38216 := by
  intro p hp
  have h : env38216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38215_38216 : H12AffineEnvironment.transform 15 54495 env38215 = env38216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env38215 == env38216) = true)

def env38217 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38160,262144,1025,32769,2097152,272393,2101329,21762,8192,64,2157596,2098512,17664,2377024,2102548,2411540,257,21792,46092,2156060]

theorem envBound38217 : H12AffineFastState.Bounded env38217 := by
  intro p hp
  have h : env38217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38216_38217 : H12AffineEnvironment.transform 6 8 env38216 = env38217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38216 == env38217) = true)

theorem identity38217 : scanCanonicalize (H12AffineFastState.compose env38217 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 322589) := by decide +kernel

theorem selectedBound38217 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env38218 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38160,262144,1025,32769,322589,272393,326732,21762,8192,64,262145,321869,17664,43357,325897,8201,257,21792,46092,264705]

theorem envBound38218 : H12AffineFastState.Bounded env38218 := by
  intro p hp
  have h : env38218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38217_38218 : H12AffineEnvironment.transform 20 322589 env38217 = env38218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 322589 env38217 == env38218) = true)

theorem identity38218 : scanCanonicalize (H12AffineFastState.compose env38218 (packedSelected [1,2,3,6,7,9,10,16,19,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound38218 : packedSelected [1,2,3,6,7,9,10,16,19,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env38219 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,32768,54359,38160,262144,1025,32769,314421,264225,318564,21762,40,64,262145,313701,17664,35189,317729,33,257,21792,37924,264705]

theorem envBound38219 : H12AffineFastState.Bounded env38219 := by
  intro p hp
  have h : env38219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38218_38219 : H12AffineEnvironment.transform 12 40 env38218 = env38219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env38218 == env38219) = true)

theorem identity38219 : scanCanonicalize (H12AffineFastState.compose env38219 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound38219 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env38220 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,373,21794,5221,262144,1025,372,281920,264225,285969,21762,40,64,262145,280592,17664,2048,284756,33,257,21792,5457,264705]

theorem envBound38220 : H12AffineFastState.Bounded env38220 := by
  intro p hp
  have h : env38220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38219_38220 : H12AffineEnvironment.transform 14 373 env38219 = env38220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env38219 == env38220) = true)

theorem identity38220 : scanCanonicalize (H12AffineFastState.compose env38220 (packedSelected [0,2,6,7,12,15,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 3344) := by decide +kernel

theorem selectedBound38220 : packedSelected [0,2,6,7,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env38221 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,373,21794,5221,3344,1025,372,16464,1329,20481,21762,40,64,3345,17664,17664,2048,21828,33,257,21792,5457,1809]

theorem envBound38221 : H12AffineFastState.Bounded env38221 := by
  intro p hp
  have h : env38221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38220_38221 : H12AffineEnvironment.transform 17 3344 env38220 = env38221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3344 env38220 == env38221) = true)

theorem identity38221 : scanCanonicalize (H12AffineFastState.compose env38221 (packedSelected [0,1,3,5,7,8,12,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound38221 : packedSelected [0,1,3,5,7,8,12,14,18] rootPS < 2^1333 := by decide +kernel

def env38222 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,40,16384,373,19763,3188,3344,1025,372,16464,1329,18448,19731,40,64,3345,17664,17664,2048,19797,33,257,19761,3392,1809]

theorem envBound38222 : H12AffineFastState.Bounded env38222 := by
  intro p hp
  have h : env38222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38221_38222 : H12AffineEnvironment.transform 11 2065 env38221 = env38222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env38221 == env38222) = true)

theorem identity38222 : scanCanonicalize (H12AffineFastState.compose env38222 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound38222 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env38223 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,40,293,373,3094,3188,3344,1025,372,373,1329,2357,3126,40,64,3345,1061,1061,2048,3184,33,257,3092,3392,1809]

theorem envBound38223 : H12AffineFastState.Bounded env38223 := by
  intro p hp
  have h : env38223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38222_38223 : H12AffineEnvironment.transform 13 293 env38222 = env38223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env38222 == env38223) = true)

theorem identity38223 : scanCanonicalize (H12AffineFastState.compose env38223 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound38223 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env38224 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,1281,40,293,373,262,356,0,1025,372,373,1329,1061,294,40,64,1,1061,1061,1296,352,33,257,260,80,1809]

theorem envBound38224 : H12AffineFastState.Bounded env38224 := by
  intro p hp
  have h : env38224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38223_38224 : H12AffineEnvironment.transform 10 1296 env38223 = env38224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env38223 == env38224) = true)

theorem identity38224 : scanCanonicalize (H12AffineFastState.compose env38224 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound38224 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env38225 : List Nat := [2,4,8,16,32,64,8,256,512,321,81,64,40,293,373,262,356,0,320,372,373,112,356,294,40,64,1,356,356,81,352,33,257,260,80,592]

theorem envBound38225 : H12AffineFastState.Bounded env38225 := by
  intro p hp
  have h : env38225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38224_38225 : H12AffineEnvironment.transform 9 321 env38224 = env38225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env38224 == env38225) = true)

theorem identity38225 : scanCanonicalize (H12AffineFastState.compose env38225 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38225 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env38226 : List Nat := [2,4,8,16,32,64,8,37,512,100,81,64,40,0,80,35,65,0,101,81,80,112,65,3,40,64,1,65,65,81,69,33,36,33,80,592]

theorem envBound38226 : H12AffineFastState.Bounded env38226 := by
  intro p hp
  have h : env38226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38225_38226 : H12AffineEnvironment.transform 7 37 env38225 = env38226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38225 == env38226) = true)

theorem identity38226 : scanCanonicalize (H12AffineFastState.compose env38226 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 36) := by decide +kernel

theorem selectedBound38226 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env38227 : List Nat := [2,4,8,16,32,64,8,37,36,100,81,64,40,0,80,35,65,0,101,81,80,112,65,3,40,64,1,65,65,81,69,33,36,33,80,116]

theorem envBound38227 : H12AffineFastState.Bounded env38227 := by
  intro p hp
  have h : env38227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38226_38227 : H12AffineEnvironment.transform 8 36 env38226 = env38227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 36 env38226 == env38227) = true)

theorem identity38227 : scanCanonicalize (H12AffineFastState.compose env38227 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound38227 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env38228 : List Nat := [2,4,8,16,32,49,8,37,36,21,32,49,40,0,33,35,48,0,20,32,33,1,48,3,40,49,1,48,48,32,52,33,36,33,33,5]

theorem envBound38228 : H12AffineFastState.Bounded env38228 := by
  intro p hp
  have h : env38228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38227_38228 : H12AffineEnvironment.transform 5 49 env38227 = env38228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env38227 == env38228) = true)

theorem identity38228 : scanCanonicalize (H12AffineFastState.compose env38228 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38228 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38229 : List Nat := [2,4,8,16,0,17,8,5,4,21,0,17,8,0,1,3,16,0,20,0,1,1,16,3,8,17,1,16,16,0,20,1,4,1,1,5]

theorem envBound38229 : H12AffineFastState.Bounded env38229 := by
  intro p hp
  have h : env38229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38228_38229 : H12AffineEnvironment.transform 4 0 env38228 = env38229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38228 == env38229) = true)

theorem identity38229 : scanCanonicalize (H12AffineFastState.compose env38229 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound38229 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38230 : List Nat := [2,4,0,16,0,17,0,5,4,21,0,17,0,0,1,3,16,0,20,0,1,1,16,3,0,17,1,16,16,0,20,1,4,1,1,5]

theorem envBound38230 : H12AffineFastState.Bounded env38230 := by
  intro p hp
  have h : env38230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38229_38230 : H12AffineEnvironment.transform 2 0 env38229 = env38230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env38229 == env38230) = true)

theorem identity38230 : scanCanonicalize (H12AffineFastState.compose env38230 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38230 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38231 : List Nat := [2,2,0,16,0,17,0,3,2,19,0,17,0,0,1,3,16,0,18,0,1,1,16,3,0,17,1,16,16,0,18,1,2,1,1,3]

theorem envBound38231 : H12AffineFastState.Bounded env38231 := by
  intro p hp
  have h : env38231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38230_38231 : H12AffineEnvironment.transform 1 2 env38230 = env38231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38230 == env38231) = true)

def env38232 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,262144,1025,32769,2097152,272392,2101329,21762,8193,64,2157596,2098512,17664,2377024,2102549,2411541,257,21792,46093,2156061]

theorem envBound38232 : H12AffineFastState.Bounded env38232 := by
  intro p hp
  have h : env38232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38216_38232 : H12AffineEnvironment.transform 6 9 env38216 = env38232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38216 == env38232) = true)

theorem identity38232 : scanCanonicalize (H12AffineFastState.compose env38232 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 17728) := by decide +kernel

theorem selectedBound38232 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env38233 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,262144,1025,32769,17728,272392,21777,21762,8193,64,43356,16400,17664,262144,20565,297301,257,21792,46093,41821]

theorem envBound38233 : H12AffineFastState.Bounded env38233 := by
  intro p hp
  have h : env38233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38232_38233 : H12AffineEnvironment.transform 20 17728 env38232 = env38233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env38232 == env38233) = true)

theorem identity38233 : scanCanonicalize (H12AffineFastState.compose env38233 (packedSelected [0,1,3,5,8,9,10,18,22,23,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound38233 : packedSelected [0,1,3,5,8,9,10,18,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env38234 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,2420,1025,32769,17728,8572,21777,21762,8193,64,43356,16400,17664,2420,20565,32801,257,21792,46093,41821]

theorem envBound38234 : H12AffineFastState.Bounded env38234 := by
  intro p hp
  have h : env38234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38233_38234 : H12AffineEnvironment.transform 17 2420 env38233 = env38234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env38233 == env38234) = true)

theorem identity38234 : scanCanonicalize (H12AffineFastState.compose env38234 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound38234 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env38235 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,40970,38160,2420,1025,32769,12572,8572,8525,8542,8193,64,43356,13388,12636,2420,9225,32801,257,8572,46093,41821]

theorem envBound38235 : H12AffineFastState.Bounded env38235 := by
  intro p hp
  have h : env38235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38234_38235 : H12AffineEnvironment.transform 13 13404 env38234 = env38235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env38234 == env38235) = true)

theorem identity38235 : scanCanonicalize (H12AffineFastState.compose env38235 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound38235 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env38236 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,8202,5392,2420,1025,1,12572,8572,8525,8542,8193,64,10588,13388,12636,2420,9225,33,257,8572,13325,9053]

theorem envBound38236 : H12AffineFastState.Bounded env38236 := by
  intro p hp
  have h : env38236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38235_38236 : H12AffineEnvironment.transform 14 0 env38235 = env38236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env38235 == env38236) = true)

theorem identity38236 : scanCanonicalize (H12AffineFastState.compose env38236 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound38236 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38237 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,5489,0,295,5392,2420,1025,1,4145,81,96,115,300,64,2161,5473,4209,2420,1316,33,257,81,5408,624]

theorem envBound38237 : H12AffineFastState.Bounded env38237 := by
  intro p hp
  have h : env38237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38236_38237 : H12AffineEnvironment.transform 12 301 env38236 = env38237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env38236 == env38237) = true)

theorem identity38237 : scanCanonicalize (H12AffineFastState.compose env38237 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38237 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38238 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,301,5409,0,295,5392,2340,1025,1,4145,1,48,35,300,16,2081,5425,4129,2340,1316,33,257,1,5408,544]

theorem envBound38238 : H12AffineFastState.Bounded env38238 := by
  intro p hp
  have h : env38238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38237_38238 : H12AffineEnvironment.transform 5 16 env38237 = env38238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38237 == env38238) = true)

theorem identity38238 : scanCanonicalize (H12AffineFastState.compose env38238 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound38238 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env38239 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,820,301,1557,0,295,1572,2340,1025,1,773,1,48,35,300,16,2081,1541,789,2340,1316,33,257,1,1556,544]

theorem envBound38239 : H12AffineFastState.Bounded env38239 := by
  intro p hp
  have h : env38239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38238_38239 : H12AffineEnvironment.transform 11 820 env38238 = env38239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env38238 == env38239) = true)

theorem identity38239 : scanCanonicalize (H12AffineFastState.compose env38239 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound38239 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38240 : List Nat := [2,4,8,16,32,16,9,256,292,1024,2048,16,301,1329,0,295,1280,2340,1025,1,33,1,48,35,300,16,2081,1313,49,2340,1316,33,257,1,1328,260]

theorem envBound38240 : H12AffineFastState.Bounded env38240 := by
  intro p hp
  have h : env38240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38239_38240 : H12AffineEnvironment.transform 8 292 env38239 = env38240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env38239 == env38240) = true)

theorem identity38240 : scanCanonicalize (H12AffineFastState.compose env38240 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound38240 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env38241 : List Nat := [2,4,8,16,32,16,9,256,292,52,2048,16,301,261,0,295,308,2340,53,1,33,1,48,35,300,16,2081,277,49,2340,272,33,257,1,260,260]

theorem envBound38241 : H12AffineFastState.Bounded env38241 := by
  intro p hp
  have h : env38241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38240_38241 : H12AffineEnvironment.transform 9 52 env38240 = env38241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38240 == env38241) = true)

theorem identity38241 : scanCanonicalize (H12AffineFastState.compose env38241 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound38241 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env38242 : List Nat := [2,4,8,16,32,16,9,256,292,52,48,16,301,261,0,295,308,276,53,1,33,1,48,35,300,16,17,277,49,276,272,33,257,1,260,260]

theorem envBound38242 : H12AffineFastState.Bounded env38242 := by
  intro p hp
  have h : env38242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38241_38242 : H12AffineEnvironment.transform 10 48 env38241 = env38242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env38241 == env38242) = true)

theorem identity38242 : scanCanonicalize (H12AffineFastState.compose env38242 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound38242 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env38243 : List Nat := [2,4,8,16,17,16,9,256,277,5,1,16,284,261,0,278,261,276,4,1,16,1,1,18,285,16,17,277,0,276,272,16,257,1,260,260]

theorem envBound38243 : H12AffineFastState.Bounded env38243 := by
  intro p hp
  have h : env38243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38242_38243 : H12AffineEnvironment.transform 4 17 env38242 = env38243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env38242 == env38243) = true)

theorem identity38243 : scanCanonicalize (H12AffineFastState.compose env38243 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound38243 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38244 : List Nat := [2,4,8,16,17,16,9,4,17,5,1,16,24,1,0,18,1,16,4,1,16,1,1,18,25,16,17,17,0,16,20,16,5,1,0,0]

theorem envBound38244 : H12AffineFastState.Bounded env38244 := by
  intro p hp
  have h : env38244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38243_38244 : H12AffineEnvironment.transform 7 4 env38243 = env38244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38243 == env38244) = true)

theorem identity38244 : scanCanonicalize (H12AffineFastState.compose env38244 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound38244 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env38245 : List Nat := [2,4,8,1,0,1,9,4,0,5,1,1,9,1,0,3,1,1,4,1,1,1,1,3,8,1,0,0,0,1,5,1,5,1,0,0]

theorem envBound38245 : H12AffineFastState.Bounded env38245 := by
  intro p hp
  have h : env38245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38244_38245 : H12AffineEnvironment.transform 3 1 env38244 = env38245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38244 == env38245) = true)

theorem identity38245 : scanCanonicalize (H12AffineFastState.compose env38245 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound38245 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38246 : List Nat := [2,4,7,1,0,1,6,4,0,5,1,1,6,1,0,3,1,1,4,1,1,1,1,3,7,1,0,0,0,1,5,1,5,1,0,0]

theorem envBound38246 : H12AffineFastState.Bounded env38246 := by
  intro p hp
  have h : env38246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38245_38246 : H12AffineEnvironment.transform 2 7 env38245 = env38246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env38245 == env38246) = true)

def env38247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6603932,2098513,17665,2377024,2102684,6349852,257,21792,46212,2175563]

theorem envBound38247 : H12AffineFastState.Bounded env38247 := by
  intro p hp
  have h : env38247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38179_38247 : H12AffineEnvironment.transform 16 38161 env38179 = env38247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env38179 == env38247) = true)

def env38248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2157596,2098513,17665,2377024,2102684,2411676,257,21792,46212,2175563]

theorem envBound38248 : H12AffineFastState.Bounded env38248 := by
  intro p hp
  have h : env38248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38247_38248 : H12AffineEnvironment.transform 21 272512 env38247 = env38248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38247 == env38248) = true)

theorem identity38248 : scanCanonicalize (H12AffineFastState.compose env38248 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound38248 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,77898,272512,73754,98780,8328,64,121942,79131,17665,357642,75222,392406,257,21792,46212,513]

theorem envBound38249 : H12AffineFastState.Bounded env38249 := by
  intro p hp
  have h : env38249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38248_38249 : H12AffineEnvironment.transform 20 77898 env38248 = env38249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env38248 == env38249) = true)

def env38250 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,77898,272392,73754,98644,8192,64,121942,79131,17665,357642,75102,392286,257,21792,46092,513]

theorem envBound38250 : H12AffineFastState.Bounded env38250 := by
  intro p hp
  have h : env38250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38249_38250 : H12AffineEnvironment.transform 6 8 env38249 = env38250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38249 == env38250) = true)

theorem identity38250 : scanCanonicalize (H12AffineFastState.compose env38250 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound38250 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env38251 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,38161,262144,1025,32769,50497,272392,54545,29791,8192,64,10589,49168,17665,294913,53333,264533,257,21792,46092,513]

theorem envBound38251 : H12AffineFastState.Bounded env38251 := by
  intro p hp
  have h : env38251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38250_38251 : H12AffineEnvironment.transform 15 62731 env38250 = env38251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env38250 == env38251) = true)

theorem identity38251 : scanCanonicalize (H12AffineFastState.compose env38251 (packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound38251 : packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS < 2^1333 := by decide +kernel

def env38252 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21620,8575,16741,262144,1025,21621,4405,272392,357,29791,8192,64,10589,5220,17665,283765,1057,264533,257,21792,24696,513]

theorem envBound38252 : H12AffineFastState.Bounded env38252 := by
  intro p hp
  have h : env38252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38251_38252 : H12AffineEnvironment.transform 14 21620 env38251 = env38252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env38251 == env38252) = true)

theorem identity38252 : scanCanonicalize (H12AffineFastState.compose env38252 (packedSelected [0,2,6,7,11,17,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound38252 : packedSelected [0,2,6,7,11,17,20,23] rootPS < 2^1333 := by decide +kernel

def env38253 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8460,8575,13341,262144,1025,8461,4405,272392,357,295,8192,64,10589,5220,12409,270605,1057,264533,257,8280,5376,513]

theorem envBound38253 : H12AffineFastState.Bounded env38253 := by
  intro p hp
  have h : env38253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38252_38253 : H12AffineEnvironment.transform 13 13688 env38252 = env38253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env38252 == env38253) = true)

theorem identity38253 : scanCanonicalize (H12AffineFastState.compose env38253 (packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38253 : packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env38254 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13608,8460,8495,13341,262144,1025,8461,4405,272392,309,295,8192,16,10509,5172,12329,270605,1057,264453,257,8200,5376,513]

theorem envBound38254 : H12AffineFastState.Bounded env38254 := by
  intro p hp
  have h : env38254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38253_38254 : H12AffineEnvironment.transform 5 16 env38253 = env38254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38253 == env38254) = true)

theorem identity38254 : scanCanonicalize (H12AffineFastState.compose env38254 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38254 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env38255 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,5377,293,262,5172,262144,1025,292,4405,264225,309,295,41,16,2340,5172,4096,262436,1057,264453,257,33,5376,513]

theorem envBound38255 : H12AffineFastState.Bounded env38255 := by
  intro p hp
  have h : env38255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38254_38255 : H12AffineEnvironment.transform 12 41 env38254 = env38255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38254 == env38255) = true)

theorem identity38255 : scanCanonicalize (H12AffineFastState.compose env38255 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38255 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38256 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5156,0,35,5172,262144,1025,1,4112,264225,16,2,41,16,2049,5172,4096,262145,1057,264224,36,33,5157,513]

theorem envBound38256 : H12AffineFastState.Bounded env38256 := by
  intro p hp
  have h : env38256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38255_38256 : H12AffineEnvironment.transform 7 37 env38255 = env38256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38255 == env38256) = true)

theorem identity38256 : scanCanonicalize (H12AffineFastState.compose env38256 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 3124) := by decide +kernel

theorem selectedBound38256 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38257 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5156,0,35,5172,3124,1025,1,4112,1045,16,2,41,16,2049,5172,4096,3125,1057,1044,36,33,5157,513]

theorem envBound38257 : H12AffineFastState.Bounded env38257 := by
  intro p hp
  have h : env38257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38256_38257 : H12AffineEnvironment.transform 17 3124 env38256 = env38257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3124 env38256 == env38257) = true)

theorem identity38257 : scanCanonicalize (H12AffineFastState.compose env38257 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound38257 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38258 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,2065,41,3125,0,35,3109,3124,1025,1,2049,1045,16,2,41,16,2049,3109,2065,3125,1057,1044,36,33,3124,513]

theorem envBound38258 : H12AffineFastState.Bounded env38258 := by
  intro p hp
  have h : env38258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38257_38258 : H12AffineEnvironment.transform 11 2065 env38257 = env38258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env38257 == env38258) = true)

theorem identity38258 : scanCanonicalize (H12AffineFastState.compose env38258 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound38258 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38259 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2065,41,2048,0,35,2064,2049,52,1,2049,32,16,2,41,16,2049,2064,2065,2048,20,33,36,33,2049,513]

theorem envBound38259 : H12AffineFastState.Bounded env38259 := by
  intro p hp
  have h : env38259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38258_38259 : H12AffineEnvironment.transform 9 53 env38258 = env38259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38258 == env38259) = true)

theorem identity38259 : scanCanonicalize (H12AffineFastState.compose env38259 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound38259 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38260 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,49,41,32,0,35,48,33,52,1,33,32,16,2,41,16,33,48,49,32,20,33,36,33,33,513]

theorem envBound38260 : H12AffineFastState.Bounded env38260 := by
  intro p hp
  have h : env38260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38259_38260 : H12AffineEnvironment.transform 10 32 env38259 = env38260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env38259 == env38260) = true)

theorem identity38260 : scanCanonicalize (H12AffineFastState.compose env38260 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound38260 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38261 : List Nat := [2,4,8,16,32,16,8,37,48,53,32,49,41,32,0,35,48,33,52,1,33,32,16,2,41,16,33,48,49,32,20,33,36,33,33,49]

theorem envBound38261 : H12AffineFastState.Bounded env38261 := by
  intro p hp
  have h : env38261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38260_38261 : H12AffineEnvironment.transform 8 48 env38260 = env38261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env38260 == env38261) = true)

def env38262 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,77898,272393,73754,98645,8193,64,121942,79131,17665,357642,75103,392287,257,21792,46093,513]

theorem envBound38262 : H12AffineFastState.Bounded env38262 := by
  intro p hp
  have h : env38262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38249_38262 : H12AffineEnvironment.transform 6 9 env38249 = env38262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38249 == env38262) = true)

def env38263 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,77898,33,73754,98645,8193,64,121942,79131,17665,89378,75103,119927,257,21792,46093,513]

theorem envBound38263 : H12AffineFastState.Bounded env38263 := by
  intro p hp
  have h : env38263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38262_38263 : H12AffineEnvironment.transform 17 10280 env38262 = env38263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38262 == env38263) = true)

theorem identity38263 : scanCanonicalize (H12AffineFastState.compose env38263 (packedSelected [2,6,12,14,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound38263 : packedSelected [2,6,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env38264 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16400,10280,1025,21760,77898,33,73754,87124,8193,64,67927,79131,17665,89378,75103,65910,257,21792,24844,513]

theorem envBound38264 : H12AffineFastState.Bounded env38264 := by
  intro p hp
  have h : env38264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38263_38264 : H12AffineEnvironment.transform 14 21761 env38263 = env38264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env38263 == env38264) = true)

theorem identity38264 : scanCanonicalize (H12AffineFastState.compose env38264 (packedSelected [0,1,4,7,8,9,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound38264 : packedSelected [0,1,4,7,8,9,14,19] rootPS < 2^1333 := by decide +kernel

def env38265 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,21591,16400,10280,1025,21760,25629,33,29773,3,8193,64,23808,24908,17665,2421,28936,21793,257,21792,24844,513]

theorem envBound38265 : H12AffineFastState.Bounded env38265 := by
  intro p hp
  have h : env38265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38264_38265 : H12AffineEnvironment.transform 15 21591 env38264 = env38265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env38264 == env38265) = true)

theorem identity38265 : scanCanonicalize (H12AffineFastState.compose env38265 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38265 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38266 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,21591,16400,2421,1025,21760,17728,33,21776,3,348,64,23808,16401,17665,2421,20565,21793,257,21792,16465,513]

theorem envBound38266 : H12AffineFastState.Bounded env38266 := by
  intro p hp
  have h : env38266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38265_38266 : H12AffineEnvironment.transform 12 349 env38265 = env38266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38265 == env38266) = true)

theorem identity38266 : scanCanonicalize (H12AffineFastState.compose env38266 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound38266 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env38267 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5457,80,262,5441,2421,1025,81,4113,33,65,3,348,64,2129,5440,4176,2421,1284,112,257,113,5376,513]

theorem envBound38267 : H12AffineFastState.Bounded env38267 := by
  intro p hp
  have h : env38267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38266_38267 : H12AffineEnvironment.transform 13 5457 env38266 = env38267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env38266 == env38267) = true)

theorem identity38267 : scanCanonicalize (H12AffineFastState.compose env38267 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38267 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env38268 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,262,5392,2340,1025,0,4113,33,16,3,269,17,2048,5393,4097,2340,1284,33,257,32,5376,513]

theorem envBound38268 : H12AffineFastState.Bounded env38268 := by
  intro p hp
  have h : env38268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38267_38268 : H12AffineEnvironment.transform 5 17 env38267 = env38268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38267 == env38268) = true)

theorem identity38268 : scanCanonicalize (H12AffineFastState.compose env38268 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38268 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38269 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,1,34,5172,2048,1025,0,4113,33,16,3,41,17,2048,5173,4097,2048,1056,33,37,32,5156,513]

theorem envBound38269 : H12AffineFastState.Bounded env38269 := by
  intro p hp
  have h : env38269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38268_38269 : H12AffineEnvironment.transform 7 36 env38268 = env38269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38268 == env38269) = true)

def env38270 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1044,1,34,1028,2048,1025,0,33,33,16,3,41,17,2048,1029,49,2048,1056,33,37,32,1044,513]

theorem envBound38270 : H12AffineFastState.Bounded env38270 := by
  intro p hp
  have h : env38270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38269_38270 : H12AffineEnvironment.transform 11 48 env38269 = env38270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env38269 == env38270) = true)

theorem identity38270 : scanCanonicalize (H12AffineFastState.compose env38270 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound38270 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38271 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1573,48,40,1044,1,34,1028,1573,1025,0,33,33,16,3,41,17,1573,1029,49,1573,1056,33,37,32,1044,513]

theorem envBound38271 : H12AffineFastState.Bounded env38271 := by
  intro p hp
  have h : env38271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38270_38271 : H12AffineEnvironment.transform 10 1573 env38270 = env38271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env38270 == env38271) = true)

def env38272 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,48,40,32,1,34,48,529,53,0,33,33,16,3,41,17,529,49,49,529,20,33,37,32,32,513]

theorem envBound38272 : H12AffineFastState.Bounded env38272 := by
  intro p hp
  have h : env38272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38271_38272 : H12AffineEnvironment.transform 9 52 env38271 = env38272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38271 == env38272) = true)

theorem identity38272 : scanCanonicalize (H12AffineFastState.compose env38272 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound38272 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38273 : List Nat := [2,4,8,16,32,17,9,36,43,52,58,48,40,32,1,34,48,58,53,0,33,33,16,3,41,17,58,49,49,58,20,33,37,32,32,42]

theorem envBound38273 : H12AffineFastState.Bounded env38273 := by
  intro p hp
  have h : env38273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38272_38273 : H12AffineEnvironment.transform 8 43 env38272 = env38273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env38272 == env38273) = true)

def leafEnv38273 : List Nat := [2,4,8,16,32,17,9,36,43,52,58,48,40,32,1,34,48,58,53,0,33,33,16,3,21,41,1,17,58,49,49,58,20,33,37,32,5,35,32,42,1,33,0]

def active38273 : List Nat := [0,1,2,3,4]

def tree38273 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38273 : H12WitnessSearch.Good tree38273 := H12GlobalWitnessIndex.good

theorem leafIdentity38273 : H12AffineFastState.composeSystem env38273 rootObs = leafEnv38273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38273 rootObs == leafEnv38273) = true)

theorem terminalChecked38273 : H12PackedTerminal.terminalCheckFast leafEnv38273 active38273 tree38273 = true := by decide +kernel

def env38274 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,48,40,33,1,34,49,528,52,0,33,33,16,3,41,17,528,48,49,528,21,33,37,32,33,513]

theorem envBound38274 : H12AffineFastState.Bounded env38274 := by
  intro p hp
  have h : env38274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38271_38274 : H12AffineEnvironment.transform 9 53 env38271 = env38274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38271 == env38274) = true)

def env38275 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1045,1,34,1029,2048,1025,0,32,33,16,3,41,17,2048,1028,48,2048,1056,33,37,32,1045,513]

theorem envBound38275 : H12AffineFastState.Bounded env38275 := by
  intro p hp
  have h : env38275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38269_38275 : H12AffineEnvironment.transform 11 49 env38269 = env38275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env38269 == env38275) = true)

theorem identity38275 : scanCanonicalize (H12AffineFastState.compose env38275 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound38275 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38276 : List Nat := [2,4,8,16,32,17,9,36,512,1024,529,49,40,1045,1,34,1029,529,1025,0,32,33,16,3,41,17,529,1028,48,529,1056,33,37,32,1045,513]

theorem envBound38276 : H12AffineFastState.Bounded env38276 := by
  intro p hp
  have h : env38276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38275_38276 : H12AffineEnvironment.transform 10 529 env38275 = env38276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env38275 == env38276) = true)

def env38277 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,49,40,33,1,34,49,529,53,0,32,33,16,3,41,17,529,48,48,529,20,33,37,32,33,513]

theorem envBound38277 : H12AffineFastState.Bounded env38277 := by
  intro p hp
  have h : env38277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38276_38277 : H12AffineEnvironment.transform 9 52 env38276 = env38277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38276 == env38277) = true)

theorem identity38277 : scanCanonicalize (H12AffineFastState.compose env38277 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound38277 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38278 : List Nat := [2,4,8,16,32,17,9,36,42,52,59,49,40,33,1,34,49,59,53,0,32,33,16,3,41,17,59,48,48,59,20,33,37,32,33,43]

theorem envBound38278 : H12AffineFastState.Bounded env38278 := by
  intro p hp
  have h : env38278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38277_38278 : H12AffineEnvironment.transform 8 42 env38277 = env38278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env38277 == env38278) = true)

def leafEnv38278 : List Nat := [2,4,8,16,32,17,9,36,42,52,59,49,40,33,1,34,49,59,53,0,32,33,16,3,21,41,1,17,59,48,48,59,20,33,37,32,5,35,33,43,1,32,0]

def active38278 : List Nat := [0,1,2,3,4]

def tree38278 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38278 : H12WitnessSearch.Good tree38278 := H12GlobalWitnessIndex.good

theorem leafIdentity38278 : H12AffineFastState.composeSystem env38278 rootObs = leafEnv38278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38278 rootObs == leafEnv38278) = true)

theorem terminalChecked38278 : H12PackedTerminal.terminalCheckFast leafEnv38278 active38278 tree38278 = true := by decide +kernel

def env38279 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,49,40,32,1,34,48,529,52,0,32,33,16,3,41,17,529,49,48,529,21,33,37,32,32,513]

theorem envBound38279 : H12AffineFastState.Bounded env38279 := by
  intro p hp
  have h : env38279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38276_38279 : H12AffineEnvironment.transform 9 53 env38276 = env38279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38276 == env38279) = true)

def env38280 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,77898,32,73754,98645,8193,64,121942,79131,17665,89379,75103,119926,257,21792,46093,513]

theorem envBound38280 : H12AffineFastState.Bounded env38280 := by
  intro p hp
  have h : env38280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38262_38280 : H12AffineEnvironment.transform 17 10281 env38262 = env38280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env38262 == env38280) = true)

theorem identity38280 : scanCanonicalize (H12AffineFastState.compose env38280 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38280 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,10281,1025,32769,4160,32,16,41311,8193,64,64604,5393,17665,32041,1365,62588,257,21792,46093,513]

theorem envBound38281 : H12AffineFastState.Bounded env38281 := by
  intro p hp
  have h : env38281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38280_38281 : H12AffineEnvironment.transform 15 8202 env38280 = env38281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38280 == env38281) = true)

theorem identity38281 : scanCanonicalize (H12AffineFastState.compose env38281 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound38281 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env38282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3148,16384,32768,3142,38161,1125,1025,32769,4160,32,16,36115,3149,64,53264,5393,17665,20837,1365,55344,257,21792,38977,513]

theorem envBound38282 : H12AffineFastState.Bounded env38282 := by
  intro p hp
  have h : env38282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38281_38282 : H12AffineEnvironment.transform 12 3148 env38281 = env38282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env38281 == env38282) = true)

theorem identity38282 : scanCanonicalize (H12AffineFastState.compose env38282 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound38282 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env38283 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3148,16384,21761,3142,16400,1125,1025,21760,4160,32,16,22546,3149,64,1297,5393,17665,20837,1365,3377,257,21792,19776,513]

theorem envBound38283 : H12AffineFastState.Bounded env38283 := by
  intro p hp
  have h : env38283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38282_38283 : H12AffineEnvironment.transform 14 21761 env38282 = env38283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env38282 == env38283) = true)

theorem identity38283 : scanCanonicalize (H12AffineFastState.compose env38283 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound38283 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38284 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1296,4096,348,16384,21761,342,16400,1125,1025,21760,4160,32,16,21762,349,64,1297,5393,17665,20837,1365,33,257,21792,16464,513]

theorem envBound38284 : H12AffineFastState.Bounded env38284 := by
  intro p hp
  have h : env38284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38283_38284 : H12AffineEnvironment.transform 10 1296 env38283 = env38284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env38283 == env38284) = true)

theorem identity38284 : scanCanonicalize (H12AffineFastState.compose env38284 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound38284 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38285 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1296,4096,348,5456,81,342,5440,1125,1025,80,4160,32,16,82,349,64,1297,5393,4177,1077,1365,33,257,112,5376,513]

theorem envBound38285 : H12AffineFastState.Bounded env38285 := by
  intro p hp
  have h : env38285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38284_38285 : H12AffineEnvironment.transform 13 5456 env38284 = env38285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env38284 == env38285) = true)

theorem identity38285 : scanCanonicalize (H12AffineFastState.compose env38285 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound38285 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env38286 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1296,1360,348,0,81,342,16,1125,1025,80,1296,32,16,82,349,64,1297,65,1281,1077,1365,33,257,112,80,513]

theorem envBound38286 : H12AffineFastState.Bounded env38286 := by
  intro p hp
  have h : env38286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38285_38286 : H12AffineEnvironment.transform 11 1360 env38285 = env38286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env38285 == env38286) = true)

theorem identity38286 : scanCanonicalize (H12AffineFastState.compose env38286 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

end H12CloudChart1