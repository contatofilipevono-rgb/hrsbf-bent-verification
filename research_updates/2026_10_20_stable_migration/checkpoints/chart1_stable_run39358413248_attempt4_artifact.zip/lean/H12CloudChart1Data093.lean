import H12CloudChart1Data092

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound23543 : H12AffineFastState.Bounded env23543 := by
  intro p hp
  have h : env23543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23542_23543 : H12AffineEnvironment.transform 20 58396 env23542 = env23543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env23542 == env23543) = true)

def env23544 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41231,8192,16,4677919,114966,45324,442384,75023,4268042,256,98599,90123,513]

theorem envBound23544 : H12AffineFastState.Bounded env23544 := by
  intro p hp
  have h : env23544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23543_23544 : H12AffineEnvironment.transform 5 16 env23543 = env23544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23543 == env23544) = true)

def env23545 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,4194304,16,41231,8192,16,4409655,114966,45324,190520,75023,4268042,256,98599,90123,513]

theorem envBound23545 : H12AffineFastState.Bounded env23545 := by
  intro p hp
  have h : env23545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23544_23545 : H12AffineEnvironment.transform 17 10280 env23544 = env23545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23544 == env23545) = true)

theorem identity23545 : scanCanonicalize (H12AffineFastState.compose env23545 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 65831) := by decide +kernel

theorem selectedBound23545 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env23546 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,65831,16,41231,8192,16,149520,114966,45324,190520,75023,8493,256,98599,90123,513]

theorem envBound23546 : H12AffineFastState.Bounded env23546 := by
  intro p hp
  have h : env23546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23545_23546 : H12AffineEnvironment.transform 21 65831 env23545 = env23546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65831 env23545 == env23546) = true)

theorem identity23546 : scanCanonicalize (H12AffineFastState.compose env23546 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound23546 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env23547 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,58396,65831,16,41231,8192,16,34816,114966,45324,10280,75023,8493,256,98599,90123,513]

theorem envBound23547 : H12AffineFastState.Bounded env23547 := by
  intro p hp
  have h : env23547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23546_23547 : H12AffineEnvironment.transform 16 49168 env23546 = env23547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env23546 == env23547) = true)

theorem identity23547 : scanCanonicalize (H12AffineFastState.compose env23547 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound23547 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env23548 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40971,49168,10280,1024,32769,58396,41260,16,41231,8192,16,34816,24861,45324,10280,34052,8493,256,8492,49152,513]

theorem envBound23548 : H12AffineFastState.Bounded env23548 := by
  intro p hp
  have h : env23548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23547_23548 : H12AffineEnvironment.transform 15 40971 env23547 = env23548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env23547 == env23548) = true)

def env23549 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41231,8192,16,4409654,114966,45324,190521,75023,4268042,256,98599,90123,513]

theorem envBound23549 : H12AffineFastState.Bounded env23549 := by
  intro p hp
  have h : env23549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23544_23549 : H12AffineEnvironment.transform 17 10281 env23544 = env23549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23544 == env23549) = true)

theorem identity23549 : scanCanonicalize (H12AffineFastState.compose env23549 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 199939) := by decide +kernel

theorem selectedBound23549 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env23550 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,199939,16,41231,8192,16,17461,114966,45324,190521,75023,142601,256,98599,90123,513]

theorem envBound23550 : H12AffineFastState.Bounded env23550 := by
  intro p hp
  have h : env23550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23549_23550 : H12AffineEnvironment.transform 21 199939 env23549 = env23550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 199939 env23549 == env23550) = true)

theorem identity23550 : scanCanonicalize (H12AffineFastState.compose env23550 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound23550 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env23551 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,58396,27929,16,41231,8192,16,17461,114966,45324,100387,75023,85267,256,98599,90123,513]

theorem envBound23551 : H12AffineFastState.Bounded env23551 := by
  intro p hp
  have h : env23551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23550_23551 : H12AffineEnvironment.transform 16 90138 env23550 = env23551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env23550 == env23551) = true)

theorem identity23551 : scanCanonicalize (H12AffineFastState.compose env23551 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 24879) := by decide +kernel

theorem selectedBound23551 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env23552 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,24879,309,10281,1024,32769,58396,27929,16,41231,8192,16,17461,41017,45324,59660,17440,11324,256,57352,292,513]

theorem envBound23552 : H12AffineFastState.Bounded env23552 := by
  intro p hp
  have h : env23552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23551_23552 : H12AffineEnvironment.transform 15 24879 env23551 = env23552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24879 env23551 == env23552) = true)

theorem identity23552 : scanCanonicalize (H12AffineFastState.compose env23552 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound23552 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23553 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,293,32768,8202,309,10281,1024,32769,42297,11324,16,41231,8192,16,1296,41017,45324,43049,1285,11324,256,41261,292,513]

theorem envBound23553 : H12AffineFastState.Bounded env23553 := by
  intro p hp
  have h : env23553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23552_23553 : H12AffineEnvironment.transform 13 293 env23552 = env23553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env23552 == env23553) = true)

theorem identity23553 : scanCanonicalize (H12AffineFastState.compose env23553 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound23553 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23554 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,309,8192,293,32768,8202,309,10281,1024,32769,42297,11324,16,41231,8192,16,1296,41017,41017,43049,1285,11324,256,41261,292,513]

theorem envBound23554 : H12AffineFastState.Bounded env23554 := by
  intro p hp
  have h : env23554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23553_23554 : H12AffineEnvironment.transform 11 309 env23553 = env23554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env23553 == env23554) = true)

theorem identity23554 : scanCanonicalize (H12AffineFastState.compose env23554 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23554 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env23555 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,309,8192,293,32768,8202,309,8232,1024,32769,42297,9277,16,41231,8192,16,1296,41017,41017,41000,1285,9277,256,41261,292,513]

theorem envBound23555 : H12AffineFastState.Bounded env23555 := by
  intro p hp
  have h : env23555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23554_23555 : H12AffineEnvironment.transform 10 1 env23554 = env23555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23554 == env23555) = true)

theorem identity23555 : scanCanonicalize (H12AffineFastState.compose env23555 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23555 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23556 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1,16,8192,0,32768,8202,16,8232,1024,32769,42012,9277,16,41002,8192,16,1077,41017,41017,41000,1056,9277,37,40968,1,513]

theorem envBound23556 : H12AffineFastState.Bounded env23556 := by
  intro p hp
  have h : env23556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23555_23556 : H12AffineEnvironment.transform 7 37 env23555 = env23556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23555 == env23556) = true)

theorem identity23556 : scanCanonicalize (H12AffineFastState.compose env23556 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(14+1) ^^^ 513) := by decide +kernel

theorem selectedBound23556 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env23557 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1,16,8192,0,513,8202,16,8232,1024,512,9757,9277,16,8747,8192,16,1077,8760,8760,8745,1056,9277,37,8713,1,513]

theorem envBound23557 : H12AffineFastState.Bounded env23557 := by
  intro p hp
  have h : env23557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23556_23557 : H12AffineEnvironment.transform 14 513 env23556 = env23557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 513 env23556 == env23557) = true)

theorem identity23557 : scanCanonicalize (H12AffineFastState.compose env23557 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound23557 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env23558 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1,16,57,0,513,51,16,17,1024,512,1572,1028,16,530,57,16,1077,513,513,528,1056,1028,37,560,1,513]

theorem envBound23558 : H12AffineFastState.Bounded env23558 := by
  intro p hp
  have h : env23558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23557_23558 : H12AffineEnvironment.transform 12 57 env23557 = env23558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env23557 == env23558) = true)

theorem identity23558 : scanCanonicalize (H12AffineFastState.compose env23558 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound23558 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env23559 : List Nat := [2,4,8,16,32,16,8,37,512,564,1,16,57,0,513,51,16,17,564,512,16,560,16,530,57,16,513,513,513,528,532,560,37,560,1,513]

theorem envBound23559 : H12AffineFastState.Bounded env23559 := by
  intro p hp
  have h : env23559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23558_23559 : H12AffineEnvironment.transform 9 564 env23558 = env23559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env23558 == env23559) = true)

theorem identity23559 : scanCanonicalize (H12AffineFastState.compose env23559 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound23559 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23560 : List Nat := [2,4,8,16,17,16,8,20,512,517,1,16,8,0,513,2,16,17,517,512,16,513,16,530,8,16,513,513,513,528,532,513,20,513,1,513]

theorem envBound23560 : H12AffineFastState.Bounded env23560 := by
  intro p hp
  have h : env23560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23559_23560 : H12AffineEnvironment.transform 4 17 env23559 = env23560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env23559 == env23560) = true)

def env23561 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41230,8192,17,4677918,114967,45325,442384,75022,4268042,256,98598,90122,513]

theorem envBound23561 : H12AffineFastState.Bounded env23561 := by
  intro p hp
  have h : env23561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23543_23561 : H12AffineEnvironment.transform 5 17 env23543 = env23561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23543 == env23561) = true)

theorem identity23561 : scanCanonicalize (H12AffineFastState.compose env23561 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound23561 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env23562 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,4194304,16,41230,8192,17,4409654,114967,45325,190520,75022,4268042,256,98598,90122,513]

theorem envBound23562 : H12AffineFastState.Bounded env23562 := by
  intro p hp
  have h : env23562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23561_23562 : H12AffineEnvironment.transform 17 10280 env23561 = env23562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23561 == env23562) = true)

theorem identity23562 : scanCanonicalize (H12AffineFastState.compose env23562 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound23562 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env23563 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58396,4194304,16,41230,8192,17,4204845,114967,45325,100387,75022,4268042,256,98598,90122,513]

theorem envBound23563 : H12AffineFastState.Bounded env23563 := by
  intro p hp
  have h : env23563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23562_23563 : H12AffineEnvironment.transform 16 90139 env23562 = env23563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env23562 == env23563) = true)

theorem identity23563 : scanCanonicalize (H12AffineFastState.compose env23563 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 65831) := by decide +kernel

theorem selectedBound23563 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env23564 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58396,65831,16,41230,8192,17,75786,114967,45325,100387,75022,8493,256,98598,90122,513]

theorem envBound23564 : H12AffineFastState.Bounded env23564 := by
  intro p hp
  have h : env23564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23563_23564 : H12AffineEnvironment.transform 21 65831 env23563 = env23564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65831 env23563 == env23564) = true)

theorem identity23564 : scanCanonicalize (H12AffineFastState.compose env23564 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound23564 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env23565 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,33030,57629,10280,1024,32769,58396,32801,16,41230,8192,17,43276,16401,45325,2341,41992,8493,256,32,57612,513]

theorem envBound23565 : H12AffineFastState.Bounded env23565 := by
  intro p hp
  have h : env23565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23564_23565 : H12AffineEnvironment.transform 15 33030 env23564 = env23565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env23564 == env23565) = true)

theorem identity23565 : scanCanonicalize (H12AffineFastState.compose env23565 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23565 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23566 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,33030,49168,2341,1024,32769,50449,32801,16,32771,269,17,34817,16401,36864,2341,34053,32,256,32,49153,513]

theorem envBound23566 : H12AffineFastState.Bounded env23566 := by
  intro p hp
  have h : env23566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23565_23566 : H12AffineEnvironment.transform 12 269 env23565 = env23566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23565 == env23566) = true)

theorem identity23566 : scanCanonicalize (H12AffineFastState.compose env23566 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound23566 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23567 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5156,32768,33030,37940,2341,1024,32769,37173,32801,16,32771,269,17,34817,5173,36864,2341,34053,32,256,32,37925,513]

theorem envBound23567 : H12AffineFastState.Bounded env23567 := by
  intro p hp
  have h : env23567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23566_23567 : H12AffineEnvironment.transform 13 5156 env23566 = env23567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env23566 == env23567) = true)

theorem identity23567 : scanCanonicalize (H12AffineFastState.compose env23567 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound23567 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env23568 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,269,5156,32768,33030,37940,1296,1024,32769,37173,32801,16,32771,269,17,33844,5173,36864,1296,34053,32,256,32,37925,513]

theorem envBound23568 : H12AffineFastState.Bounded env23568 := by
  intro p hp
  have h : env23568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23567_23568 : H12AffineEnvironment.transform 10 1077 env23567 = env23568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env23567 == env23568) = true)

theorem identity23568 : scanCanonicalize (H12AffineFastState.compose env23568 (packedSelected [2,4,7] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound23568 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env23569 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,269,5156,33,295,5141,1296,1024,32,4372,0,16,34,269,17,1045,5173,4129,1296,1316,32,256,32,5124,513]

theorem envBound23569 : H12AffineFastState.Bounded env23569 := by
  intro p hp
  have h : env23569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23568_23569 : H12AffineEnvironment.transform 14 33 env23568 = env23569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env23568 == env23569) = true)

def env23570 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41311,8192,64,4677967,115015,45405,442384,75103,4268043,256,98678,90202,513]

theorem envBound23570 : H12AffineFastState.Bounded env23570 := by
  intro p hp
  have h : env23570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23542_23570 : H12AffineEnvironment.transform 20 58397 env23542 = env23570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env23542 == env23570) = true)

theorem identity23570 : scanCanonicalize (H12AffineFastState.compose env23570 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23570 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23571 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58397,4194304,16,41311,8192,64,4604228,57676,45405,442384,1364,4194304,256,41341,16465,513]

theorem envBound23571 : H12AffineFastState.Bounded env23571 := by
  intro p hp
  have h : env23571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23570_23571 : H12AffineEnvironment.transform 15 8203 env23570 = env23571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23570 == env23571) = true)

theorem identity23571 : scanCanonicalize (H12AffineFastState.compose env23571 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419913) := by decide +kernel

theorem selectedBound23571 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env23572 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58397,419913,16,41311,8192,64,10509,57676,45405,442384,1364,419913,256,41341,16465,513]

theorem envBound23572 : H12AffineFastState.Bounded env23572 := by
  intro p hp
  have h : env23572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23571_23572 : H12AffineEnvironment.transform 21 419913 env23571 = env23572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419913 env23571 == env23572) = true)

def env23573 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16448,262144,1024,32769,58397,272393,16,41311,8192,64,10509,57676,45405,294992,1364,272393,256,41341,16465,513]

theorem envBound23573 : H12AffineFastState.Bounded env23573 := by
  intro p hp
  have h : env23573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23572_23573 : H12AffineEnvironment.transform 16 16448 env23572 = env23573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env23572 == env23573) = true)

theorem identity23573 : scanCanonicalize (H12AffineFastState.compose env23573 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound23573 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23574 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,342,16448,262144,1024,32769,50496,264532,16,32770,349,64,2128,49169,36864,294992,1364,264532,256,32800,16465,513]

theorem envBound23574 : H12AffineFastState.Bounded env23574 := by
  intro p hp
  have h : env23574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23573_23574 : H12AffineEnvironment.transform 12 349 env23573 = env23574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env23573 == env23574) = true)

theorem identity23574 : scanCanonicalize (H12AffineFastState.compose env23574 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound23574 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23575 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,342,16448,2341,1024,32769,50496,113,16,32770,349,64,2128,49169,36864,35189,1364,113,256,32800,16465,513]

theorem envBound23575 : H12AffineFastState.Bounded env23575 := by
  intro p hp
  have h : env23575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23574_23575 : H12AffineEnvironment.transform 17 2341 env23574 = env23575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env23574 == env23575) = true)

theorem identity23575 : scanCanonicalize (H12AffineFastState.compose env23575 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound23575 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env23576 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,81,342,16448,2341,1024,80,17681,113,16,83,349,64,2128,16448,4177,2340,1364,113,256,113,16465,513]

theorem envBound23576 : H12AffineFastState.Bounded env23576 := by
  intro p hp
  have h : env23576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23575_23576 : H12AffineEnvironment.transform 14 81 env23575 = env23576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env23575 == env23576) = true)

theorem identity23576 : scanCanonicalize (H12AffineFastState.compose env23576 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound23576 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env23577 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,349,16384,81,342,16448,2341,1024,80,17681,113,16,83,349,64,2128,16448,2113,2340,1364,113,256,113,16465,513]

theorem envBound23577 : H12AffineFastState.Bounded env23577 := by
  intro p hp
  have h : env23577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23576_23577 : H12AffineEnvironment.transform 11 2064 env23576 = env23577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env23576 == env23577) = true)

theorem identity23577 : scanCanonicalize (H12AffineFastState.compose env23577 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound23577 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env23578 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,2064,349,16384,81,342,16448,2341,100,80,16757,113,16,83,349,64,2128,16448,2113,2340,304,113,256,113,16465,513]

theorem envBound23578 : H12AffineFastState.Bounded env23578 := by
  intro p hp
  have h : env23578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23577_23578 : H12AffineEnvironment.transform 9 100 env23577 = env23578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env23577 == env23578) = true)

theorem identity23578 : scanCanonicalize (H12AffineFastState.compose env23578 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound23578 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env23579 : List Nat := [2,4,8,16,32,64,8,256,512,100,292,308,349,16384,81,342,16448,1,100,80,16757,113,16,83,349,64,372,16448,357,0,304,113,256,113,16465,513]

theorem envBound23579 : H12AffineFastState.Bounded env23579 := by
  intro p hp
  have h : env23579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23578_23579 : H12AffineEnvironment.transform 10 292 env23578 = env23579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env23578 == env23579) = true)

theorem identity23579 : scanCanonicalize (H12AffineFastState.compose env23579 (packedSelected [0,2,7] rootPS)) = affineNative (2^(13+1) ^^^ 373) := by decide +kernel

theorem selectedBound23579 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env23580 : List Nat := [2,4,8,16,32,64,8,256,512,100,292,308,349,373,81,342,309,1,100,80,0,113,16,83,349,64,372,309,357,0,304,113,256,113,292,513]

theorem envBound23580 : H12AffineFastState.Bounded env23580 := by
  intro p hp
  have h : env23580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23579_23580 : H12AffineEnvironment.transform 13 373 env23579 = env23580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 373 env23579 == env23580) = true)

def env23581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16449,262144,1024,32769,58397,272392,16,41311,8192,64,10509,57676,45405,294993,1364,272392,256,41341,16465,513]

theorem envBound23581 : H12AffineFastState.Bounded env23581 := by
  intro p hp
  have h : env23581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23572_23581 : H12AffineEnvironment.transform 16 16449 env23572 = env23581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env23572 == env23581) = true)

theorem identity23581 : scanCanonicalize (H12AffineFastState.compose env23581 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23581 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23582 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,58397,272392,16,41231,8192,16,10509,57628,45325,294913,1284,272392,256,41261,16385,513]

theorem envBound23582 : H12AffineFastState.Bounded env23582 := by
  intro p hp
  have h : env23582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23581_23582 : H12AffineEnvironment.transform 5 16 env23581 = env23582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23581 == env23582) = true)

theorem identity23582 : scanCanonicalize (H12AffineFastState.compose env23582 (packedSelected [5,6,8] rootPS)) = affineNative (2^(17+1) ^^^ 23840) := by decide +kernel

theorem selectedBound23582 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env23583 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,23840,1024,32769,58397,29992,16,41231,8192,16,10509,57628,45325,56609,1284,29992,256,41261,16385,513]

theorem envBound23583 : H12AffineFastState.Bounded env23583 := by
  intro p hp
  have h : env23583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23582_23583 : H12AffineEnvironment.transform 17 23840 env23582 = env23583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23840 env23582 == env23583) = true)

theorem identity23583 : scanCanonicalize (H12AffineFastState.compose env23583 (packedSelected [1,6,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23583 : packedSelected [1,6,24] rootPS < 2^1333 := by decide +kernel

def env23584 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,263,16401,23840,1024,32769,50449,21540,16,32771,268,16,2049,49168,36865,56609,1284,21540,256,32801,16385,513]

theorem envBound23584 : H12AffineFastState.Bounded env23584 := by
  intro p hp
  have h : env23584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23583_23584 : H12AffineEnvironment.transform 12 268 env23583 = env23584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23583 == env23584) = true)

theorem identity23584 : scanCanonicalize (H12AffineFastState.compose env23584 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound23584 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23585 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5124,32768,263,5141,2340,1024,32769,37141,32,16,32771,268,16,2049,37908,36865,35109,1284,32,256,32801,5125,513]

theorem envBound23585 : H12AffineFastState.Bounded env23585 := by
  intro p hp
  have h : env23585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23584_23585 : H12AffineEnvironment.transform 13 5124 env23584 = env23585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env23584 == env23585) = true)

theorem identity23585 : scanCanonicalize (H12AffineFastState.compose env23585 (packedSelected [0,2,3,4,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound23585 : packedSelected [0,2,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env23586 : List Nat := [2,4,8,16,32,16,8,256,512,1024,276,4096,268,5124,32768,263,5141,48,1024,32769,37141,32,16,32771,268,16,277,37908,36865,32817,1284,32,256,32801,5125,513]

theorem envBound23586 : H12AffineFastState.Bounded env23586 := by
  intro p hp
  have h : env23586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23585_23586 : H12AffineEnvironment.transform 10 276 env23585 = env23586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env23585 == env23586) = true)

theorem identity23586 : scanCanonicalize (H12AffineFastState.compose env23586 (packedSelected [0,2,3,5,7,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23586 : packedSelected [0,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env23587 : List Nat := [2,4,8,16,32,16,8,256,512,1024,276,4096,268,5124,1,263,5141,48,1024,0,4372,32,16,2,268,16,277,5141,4096,48,1284,32,256,32,5125,513]

theorem envBound23587 : H12AffineFastState.Bounded env23587 := by
  intro p hp
  have h : env23587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23586_23587 : H12AffineEnvironment.transform 14 1 env23586 = env23587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23586 == env23587) = true)

theorem identity23587 : scanCanonicalize (H12AffineFastState.compose env23587 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23587 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23588 : List Nat := [2,4,8,16,1,16,8,256,512,1024,276,4096,268,5124,1,263,5141,17,1024,0,4372,1,16,2,268,16,277,5141,4096,17,1284,1,256,1,5125,513]

theorem envBound23588 : H12AffineFastState.Bounded env23588 := by
  intro p hp
  have h : env23588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23587_23588 : H12AffineEnvironment.transform 4 1 env23587 = env23588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23587 == env23588) = true)

theorem identity23588 : scanCanonicalize (H12AffineFastState.compose env23588 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound23588 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23589 : List Nat := [2,4,8,16,1,16,8,256,512,1024,276,17,268,1045,1,263,1028,17,1024,0,261,1,16,2,268,16,277,1028,17,17,1284,1,256,1,1044,513]

theorem envBound23589 : H12AffineFastState.Bounded env23589 := by
  intro p hp
  have h : env23589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23588_23589 : H12AffineEnvironment.transform 11 17 env23588 = env23589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env23588 == env23589) = true)

theorem identity23589 : scanCanonicalize (H12AffineFastState.compose env23589 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound23589 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23590 : List Nat := [2,4,8,16,1,16,8,256,260,1024,276,17,268,1045,1,263,1028,17,1024,0,261,1,16,2,268,16,277,1028,17,17,1284,1,256,1,1044,261]

theorem envBound23590 : H12AffineFastState.Bounded env23590 := by
  intro p hp
  have h : env23590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23589_23590 : H12AffineEnvironment.transform 8 260 env23589 = env23590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env23589 == env23590) = true)

theorem identity23590 : scanCanonicalize (H12AffineFastState.compose env23590 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound23590 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23591 : List Nat := [2,4,8,16,1,16,8,256,260,256,276,17,268,277,1,263,260,17,256,0,261,1,16,2,268,16,277,260,17,17,4,1,256,1,276,261]

theorem envBound23591 : H12AffineFastState.Bounded env23591 := by
  intro p hp
  have h : env23591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23590_23591 : H12AffineEnvironment.transform 9 256 env23590 = env23591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env23590 == env23591) = true)

def env23592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41310,8192,64,4677967,2172251,2118977,442385,75103,6407191,256,2188651,2196551,513]

theorem envBound23592 : H12AffineFastState.Bounded env23592 := by
  intro p hp
  have h : env23592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23541_23592 : H12AffineEnvironment.transform 22 17 env23541 = env23592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env23541 == env23592) = true)

theorem identity23592 : scanCanonicalize (H12AffineFastState.compose env23592 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound23592 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23593 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,2097152,4194304,17,41310,8192,64,4456789,2172251,2118977,368651,75103,6407191,256,2188651,2196551,513]

theorem envBound23593 : H12AffineFastState.Bounded env23593 := by
  intro p hp
  have h : env23593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23592_23593 : H12AffineEnvironment.transform 16 90138 env23592 = env23593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env23592 == env23593) = true)

theorem identity23593 : scanCanonicalize (H12AffineFastState.compose env23593 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound23593 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23594 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57677,262144,1024,32769,2097152,4194304,17,41310,8192,64,4456789,2139148,2118977,270684,41992,6309184,256,2155580,2098448,513]

theorem envBound23594 : H12AffineFastState.Bounded env23594 := by
  intro p hp
  have h : env23594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23593_23594 : H12AffineEnvironment.transform 15 33111 env23593 = env23594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env23593 == env23594) = true)

theorem identity23594 : scanCanonicalize (H12AffineFastState.compose env23594 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound23594 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env23595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57677,10280,1024,32769,2097152,4194304,17,41310,8192,64,4204925,2139148,2118977,2420,41992,6309184,256,2155580,2098448,513]

theorem envBound23595 : H12AffineFastState.Bounded env23595 := by
  intro p hp
  have h : env23595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23594_23595 : H12AffineEnvironment.transform 17 10280 env23594 = env23595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23594 == env23595) = true)

theorem identity23595 : scanCanonicalize (H12AffineFastState.compose env23595 (packedSelected [4,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 25676) := by decide +kernel

theorem selectedBound23595 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env23596 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57677,10280,1024,32769,25676,4194304,17,41310,8192,64,4204925,49216,12557,2420,41992,4202764,256,32880,24924,513]

theorem envBound23596 : H12AffineFastState.Bounded env23596 := by
  intro p hp
  have h : env23596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23595_23596 : H12AffineEnvironment.transform 20 25676 env23595 = env23596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25676 env23595 == env23596) = true)

theorem identity23596 : scanCanonicalize (H12AffineFastState.compose env23596 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound23596 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env23597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57677,10280,1024,32769,25676,8493,17,41310,8192,64,2128,49216,12557,2420,41992,33,256,32880,24924,513]

theorem envBound23597 : H12AffineFastState.Bounded env23597 := by
  intro p hp
  have h : env23597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23596_23597 : H12AffineEnvironment.transform 21 8493 env23596 = env23597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env23596 == env23597) = true)

theorem identity23597 : scanCanonicalize (H12AffineFastState.compose env23597 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound23597 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23598 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1024,8540,25676,8493,17,3,8192,64,2128,24861,12557,2420,1365,33,256,8493,24924,513]

theorem envBound23598 : H12AffineFastState.Bounded env23598 := by
  intro p hp
  have h : env23598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23597_23598 : H12AffineEnvironment.transform 14 8541 env23597 = env23598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env23597 == env23598) = true)

theorem identity23598 : scanCanonicalize (H12AffineFastState.compose env23598 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23598 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env23599 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,81,262,16400,2340,1024,80,17728,33,17,3,268,64,2128,16401,4097,2420,1365,33,256,33,16464,513]

theorem envBound23599 : H12AffineFastState.Bounded env23599 := by
  intro p hp
  have h : env23599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23598_23599 : H12AffineEnvironment.transform 12 268 env23598 = env23599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23598 == env23599) = true)

theorem identity23599 : scanCanonicalize (H12AffineFastState.compose env23599 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1392) := by decide +kernel

theorem selectedBound23599 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env23600 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1392,268,16384,81,262,16400,2340,1024,80,17728,33,17,3,268,64,2128,16401,1393,2420,1365,33,256,33,16464,513]

theorem envBound23600 : H12AffineFastState.Bounded env23600 := by
  intro p hp
  have h : env23600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23599_23600 : H12AffineEnvironment.transform 11 1392 env23599 = env23600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1392 env23599 == env23600) = true)

theorem identity23600 : scanCanonicalize (H12AffineFastState.compose env23600 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 2624) := by decide +kernel

theorem selectedBound23600 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env23601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1392,268,2624,81,262,2640,2340,1024,80,3840,33,17,3,268,64,2128,2641,1393,2420,1365,33,256,33,2576,513]

theorem envBound23601 : H12AffineFastState.Bounded env23601 := by
  intro p hp
  have h : env23601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23600_23601 : H12AffineEnvironment.transform 13 2624 env23600 = env23601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2624 env23600 == env23601) = true)

theorem identity23601 : scanCanonicalize (H12AffineFastState.compose env23601 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound23601 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env23602 : List Nat := [2,4,8,16,32,64,8,256,276,1024,2048,1392,268,2388,81,262,2372,2340,1024,80,3092,33,17,3,268,64,2128,2373,1393,2420,1365,33,256,33,2308,277]

theorem envBound23602 : H12AffineFastState.Bounded env23602 := by
  intro p hp
  have h : env23602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23601_23602 : H12AffineEnvironment.transform 8 276 env23601 = env23602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env23601 == env23602) = true)

theorem identity23602 : scanCanonicalize (H12AffineFastState.compose env23602 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound23602 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23603 : List Nat := [2,4,8,16,32,64,8,84,64,1024,2048,1060,88,2048,81,82,2064,2160,1024,80,3092,33,17,3,88,64,2128,2065,1061,2080,1025,33,84,33,2128,65]

theorem envBound23603 : H12AffineFastState.Bounded env23603 := by
  intro p hp
  have h : env23603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23602_23603 : H12AffineEnvironment.transform 7 84 env23602 = env23603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env23602 == env23603) = true)

theorem identity23603 : scanCanonicalize (H12AffineFastState.compose env23603 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23603 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env23604 : List Nat := [2,4,8,16,32,17,8,5,17,1024,2048,1060,9,2048,0,3,2064,2081,1024,1,3092,33,17,3,9,17,2049,2065,1061,2080,1025,33,5,33,2049,16]

theorem envBound23604 : H12AffineFastState.Bounded env23604 := by
  intro p hp
  have h : env23604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23603_23604 : H12AffineEnvironment.transform 5 17 env23603 = env23604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23603 == env23604) = true)

def env23605 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429903,8193,64,4677967,10560843,10507600,8830976,75103,14795783,256,2188650,2196551,512]

theorem envBound23605 : H12AffineFastState.Bounded env23605 := by
  intro p hp
  have h : env23605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23540_23605 : H12AffineEnvironment.transform 6 9 env23540 = env23605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23540 == env23605) = true)

theorem identity23605 : scanCanonicalize (H12AffineFastState.compose env23605 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4235628) := by decide +kernel

theorem selectedBound23605 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env23606 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,4235628,4194339,8193,64,4677967,6390823,6353980,4612460,75103,2188651,256,2188650,2196551,512]

theorem envBound23606 : H12AffineFastState.Bounded env23606 := by
  intro p hp
  have h : env23606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23605_23606 : H12AffineEnvironment.transform 22 4235628 env23605 = env23606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235628 env23605 == env23606) = true)

theorem identity23606 : scanCanonicalize (H12AffineFastState.compose env23606 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(21+1) ^^^ 188780) := by decide +kernel

theorem selectedBound23606 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env23607 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,188780,147456,188751,8193,64,360483,2319691,2233680,294912,75103,2188651,256,2188650,2196551,512]

theorem envBound23607 : H12AffineFastState.Bounded env23607 := by
  intro p hp
  have h : env23607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23606_23607 : H12AffineEnvironment.transform 21 188780 env23606 = env23607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 188780 env23606 == env23607) = true)

theorem identity23607 : scanCanonicalize (H12AffineFastState.compose env23607 (packedSelected [1,5,8,11,17,18,19,21,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound23607 : packedSelected [1,5,8,11,17,18,19,21,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env23608 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,2097152,188780,147456,188751,8193,64,108555,2319691,2233680,43048,75103,2188651,256,2188650,2196551,512]

theorem envBound23608 : H12AffineFastState.Bounded env23608 := by
  intro p hp
  have h : env23608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23607_23608 : H12AffineEnvironment.transform 17 10280 env23607 = env23608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23607 == env23608) = true)

theorem identity23608 : scanCanonicalize (H12AffineFastState.compose env23608 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound23608 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env23609 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,32,41292,3,8193,64,108555,2196487,2159644,43048,75103,2188651,256,2188650,2196551,512]

theorem envBound23609 : H12AffineFastState.Bounded env23609 := by
  intro p hp
  have h : env23609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23608_23609 : H12AffineEnvironment.transform 16 57676 env23608 = env23609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env23608 == env23609) = true)

theorem identity23609 : scanCanonicalize (H12AffineFastState.compose env23609 (packedSelected [0,3,4,5,7,9,10,12,15,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 91419) := by decide +kernel

theorem selectedBound23609 : packedSelected [0,3,4,5,7,9,10,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env23610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,91419,32,41292,3,8193,64,108555,57628,102663,43048,75103,112,256,113,57692,512]

theorem envBound23610 : H12AffineFastState.Bounded env23610 := by
  intro p hp
  have h : env23610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23609_23610 : H12AffineEnvironment.transform 20 91419 env23609 = env23610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91419 env23609 == env23610) = true)

theorem identity23610 : scanCanonicalize (H12AffineFastState.compose env23610 (packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound23610 : packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env23611 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,57676,10280,1024,32769,50449,32,41292,3,8193,64,2049,57628,12557,43048,34133,112,256,113,57692,512]

theorem envBound23611 : H12AffineFastState.Bounded env23611 := by
  intro p hp
  have h : env23611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23610_23611 : H12AffineEnvironment.transform 15 40970 env23610 = env23611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env23610 == env23611) = true)

theorem identity23611 : scanCanonicalize (H12AffineFastState.compose env23611 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5489) := by decide +kernel

theorem selectedBound23611 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env23612 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5489,32768,40970,46141,10280,1024,32769,36960,32,41292,3,8193,64,2049,46189,12557,43048,34133,112,256,113,46125,512]

theorem envBound23612 : H12AffineFastState.Bounded env23612 := by
  intro p hp
  have h : env23612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23611_23612 : H12AffineEnvironment.transform 13 5489 env23611 = env23612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5489 env23611 == env23612) = true)

theorem identity23612 : scanCanonicalize (H12AffineFastState.compose env23612 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound23612 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5489,292,8494,13593,10280,1024,293,4420,32,8296,3,8193,64,2049,13641,12557,10508,1137,112,256,113,13577,512]

theorem envBound23613 : H12AffineFastState.Bounded env23613 := by
  intro p hp
  have h : env23613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23612_23613 : H12AffineEnvironment.transform 14 292 env23612 = env23613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env23612 == env23613) = true)

theorem identity23613 : scanCanonicalize (H12AffineFastState.compose env23613 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23613 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env23614 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5204,1,8203,13372,10280,1024,0,4193,32,8296,3,8193,64,2049,13420,12328,10281,1137,112,37,113,13356,512]

theorem envBound23614 : H12AffineFastState.Bounded env23614 := by
  intro p hp
  have h : env23614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23613_23614 : H12AffineEnvironment.transform 7 37 env23613 = env23614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23613 == env23614) = true)

theorem identity23614 : scanCanonicalize (H12AffineFastState.compose env23614 (packedSelected [0,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound23614 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env23615 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,9,5204,1,2,5173,2081,1024,0,4193,32,97,3,8,64,2049,5221,4129,2080,1137,112,37,113,5157,512]

theorem envBound23615 : H12AffineFastState.Bounded env23615 := by
  intro p hp
  have h : env23615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23614_23615 : H12AffineEnvironment.transform 12 9 env23614 = env23615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env23614 == env23615) = true)

theorem identity23615 : scanCanonicalize (H12AffineFastState.compose env23615 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23615 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23616 : List Nat := [2,4,8,16,1,64,9,4,512,1024,2048,4096,9,5204,1,2,5140,2048,1024,0,4160,1,64,3,8,64,2049,5188,4096,2049,1104,81,4,80,5124,512]

theorem envBound23616 : H12AffineFastState.Bounded env23616 := by
  intro p hp
  have h : env23616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23615_23616 : H12AffineEnvironment.transform 4 1 env23615 = env23616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23615 == env23616) = true)

theorem identity23616 : scanCanonicalize (H12AffineFastState.compose env23616 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23616 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env23617 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5124,1,2,5140,2048,1024,0,4112,1,16,3,8,16,2049,5140,4096,2049,1024,1,4,0,5124,512]

theorem envBound23617 : H12AffineFastState.Bounded env23617 := by
  intro p hp
  have h : env23617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23616_23617 : H12AffineEnvironment.transform 5 16 env23616 = env23617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23616 == env23617) = true)

def env23618 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,9,1044,1,2,1028,2048,1024,0,0,1,16,3,8,16,2049,1028,16,2049,1024,1,4,0,1044,512]

theorem envBound23618 : H12AffineFastState.Bounded env23618 := by
  intro p hp
  have h : env23618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23617_23618 : H12AffineEnvironment.transform 11 16 env23617 = env23618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env23617 == env23618) = true)

theorem identity23618 : scanCanonicalize (H12AffineFastState.compose env23618 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound23618 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23619 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,9,0,1,2,16,2048,20,0,0,1,16,3,8,16,2049,16,16,2049,20,1,4,0,0,512]

theorem envBound23619 : H12AffineFastState.Bounded env23619 := by
  intro p hp
  have h : env23619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23618_23619 : H12AffineEnvironment.transform 9 20 env23618 = env23619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env23618 == env23619) = true)

theorem identity23619 : scanCanonicalize (H12AffineFastState.compose env23619 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound23619 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23620 : List Nat := [2,4,8,4,1,4,9,4,512,0,2048,4,9,0,1,2,4,2048,0,0,0,1,4,3,8,4,2049,4,4,2049,0,1,4,0,0,512]

theorem envBound23620 : H12AffineFastState.Bounded env23620 := by
  intro p hp
  have h : env23620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23619_23620 : H12AffineEnvironment.transform 3 4 env23619 = env23620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env23619 == env23620) = true)

def leafEnv23620 : List Nat := [2,4,8,4,1,4,9,4,512,0,2048,4,9,0,1,2,4,2048,0,0,0,1,4,3,0,8,1,4,2049,4,4,2049,0,1,4,0,4,3,0,512,1,0,0]

def active23620 : List Nat := [0,1,2,8,10]

def tree23620 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23620 : H12WitnessSearch.Good tree23620 := H12GlobalWitnessIndex.good

theorem leafIdentity23620 : H12AffineFastState.composeSystem env23620 rootObs = leafEnv23620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23620 rootObs == leafEnv23620) = true)

theorem terminalChecked23620 : H12PackedTerminal.terminalCheckFast leafEnv23620 active23620 tree23620 = true := by decide +kernel

def env23621 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,9,1045,1,2,1029,2048,1024,0,1,1,16,3,8,16,2049,1029,17,2049,1024,1,4,0,1045,512]

theorem envBound23621 : H12AffineFastState.Bounded env23621 := by
  intro p hp
  have h : env23621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23617_23621 : H12AffineEnvironment.transform 11 17 env23617 = env23621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env23617 == env23621) = true)

def env23622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound23622 : H12AffineFastState.Bounded env23622 := by
  intro p hp
  have h : env23622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23538_23622 : H12AffineEnvironment.transform 18 1025 env23538 = env23622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env23538 == env23622) = true)

theorem identity23622 : scanCanonicalize (H12AffineFastState.compose env23622 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 82383) := by decide +kernel

theorem selectedBound23622 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29655502,18973836,10507600,8749518,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound23623 : H12AffineFastState.Bounded env23623 := by
  intro p hp
  have h : env23623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23622_23623 : H12AffineEnvironment.transform 16 82383 env23622 = env23623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82383 env23622 == env23623) = true)

def env23624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6623298,8393984,10507600,8749518,2102684,12645453,257,21793,46212,2175563]

theorem envBound23624 : H12AffineFastState.Bounded env23624 := by
  intro p hp
  have h : env23624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23623_23624 : H12AffineEnvironment.transform 23 10588556 env23623 = env23624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env23623 == env23624) = true)

def env23625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6623298,2098512,17664,2462110,2102684,6349853,257,21793,46212,2175563]

theorem envBound23625 : H12AffineFastState.Bounded env23625 := by
  intro p hp
  have h : env23625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23624_23625 : H12AffineEnvironment.transform 22 2101328 env23624 = env23625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env23624 == env23625) = true)

def env23626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2177218,2098512,17664,2462110,2102684,2411677,257,21793,46212,2175563]

theorem envBound23626 : H12AffineFastState.Bounded env23626 := by
  intro p hp
  have h : env23626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23625_23626 : H12AffineEnvironment.transform 21 272512 env23625 = env23626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env23625 == env23626) = true)

def env23627 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272392,2101328,98644,8192,64,2177098,2098512,17664,2461974,2102548,2411541,257,21793,46092,2175563]

theorem envBound23627 : H12AffineFastState.Bounded env23627 := by
  intro p hp
  have h : env23627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23626_23627 : H12AffineEnvironment.transform 6 8 env23626 = env23627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23626 == env23627) = true)

theorem identity23627 : scanCanonicalize (H12AffineFastState.compose env23627 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound23627 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env23628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,16400,262144,1025,32769,2097152,272392,2101328,32771,8192,64,2111773,2098512,17664,2396225,2102548,2411541,257,21793,46092,2110236]

theorem envBound23628 : H12AffineFastState.Bounded env23628 := by
  intro p hp
  have h : env23628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23627_23628 : H12AffineEnvironment.transform 15 343 env23627 = env23628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env23627 == env23628) = true)

theorem identity23628 : scanCanonicalize (H12AffineFastState.compose env23628 (packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound23628 : packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env23629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,16400,10280,1025,32769,2097152,32,2101328,32771,8192,64,2111773,2098512,17664,2144361,2102548,2155581,257,21793,46092,2110236]

theorem envBound23629 : H12AffineFastState.Bounded env23629 := by
  intro p hp
  have h : env23629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23628_23629 : H12AffineEnvironment.transform 17 10280 env23628 = env23629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23628 == env23629) = true)

theorem identity23629 : scanCanonicalize (H12AffineFastState.compose env23629 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23629 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,343,16400,10280,1025,0,2097152,32,2101328,2,8192,64,2111773,2098512,17664,2111592,2102548,2122812,257,21793,13325,2110236]

theorem envBound23630 : H12AffineFastState.Bounded env23630 := by
  intro p hp
  have h : env23630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23629_23630 : H12AffineEnvironment.transform 14 1 env23629 = env23630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23629 == env23630) = true)

theorem identity23630 : scanCanonicalize (H12AffineFastState.compose env23630 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound23630 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env23631 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,1,115,16400,10280,1025,0,2097152,32,2101328,2,8192,64,2111545,2098292,17444,2111592,2102320,2122812,37,21509,13325,2110008]

theorem envBound23631 : H12AffineFastState.Bounded env23631 := by
  intro p hp
  have h : env23631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23630_23631 : H12AffineEnvironment.transform 7 36 env23630 = env23631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env23630 == env23631) = true)

theorem identity23631 : scanCanonicalize (H12AffineFastState.compose env23631 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound23631 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env23632 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,1,115,16400,2129,1025,0,2097152,32,2101328,2,121,64,2103360,2098292,17444,2103313,2102320,2114629,37,21509,5236,2101825]

theorem envBound23632 : H12AffineFastState.Bounded env23632 := by
  intro p hp
  have h : env23632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23631_23632 : H12AffineEnvironment.transform 12 121 env23631 = env23632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env23631 == env23632) = true)

theorem identity23632 : scanCanonicalize (H12AffineFastState.compose env23632 (packedSelected [2,4,6,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound23632 : packedSelected [2,4,6,9,14] rootPS < 2^1333 := by decide +kernel

def env23633 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,5156,1,115,5172,2129,1025,0,2097152,32,2101328,2,121,64,2103360,2098292,4096,2103313,2102320,2101345,37,33,5236,2101825]

theorem envBound23633 : H12AffineFastState.Bounded env23633 := by
  intro p hp
  have h : env23633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23632_23633 : H12AffineEnvironment.transform 13 5156 env23632 = env23633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env23632 == env23633) = true)

theorem identity23633 : scanCanonicalize (H12AffineFastState.compose env23633 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound23633 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env23634 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,5156,1,115,5172,2129,1025,0,4160,32,16,2,121,64,2048,5172,4096,2129,1136,33,37,33,5236,513]

theorem envBound23634 : H12AffineFastState.Bounded env23634 := by
  intro p hp
  have h : env23634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23633_23634 : H12AffineEnvironment.transform 20 4160 env23633 = env23634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env23633 == env23634) = true)

theorem identity23634 : scanCanonicalize (H12AffineFastState.compose env23634 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound23634 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23635 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,4096,121,4112,1,115,4096,2129,53,0,4160,32,16,2,121,64,2048,4096,4096,2129,68,33,37,33,4160,513]

theorem envBound23635 : H12AffineFastState.Bounded env23635 := by
  intro p hp
  have h : env23635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23634_23635 : H12AffineEnvironment.transform 9 52 env23634 = env23635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env23634 == env23635) = true)

theorem identity23635 : scanCanonicalize (H12AffineFastState.compose env23635 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23635 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23636 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,4096,40,4112,1,34,4096,2048,53,0,4113,32,16,2,40,17,2048,4096,4096,2048,21,33,37,33,4113,513]

theorem envBound23636 : H12AffineFastState.Bounded env23636 := by
  intro p hp
  have h : env23636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23635_23636 : H12AffineEnvironment.transform 5 17 env23635 = env23636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23635 == env23636) = true)

theorem identity23636 : scanCanonicalize (H12AffineFastState.compose env23636 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound23636 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23637 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,4096,40,4112,1,34,4096,0,53,0,4113,32,16,2,40,17,0,4096,4096,0,21,33,37,33,4113,513]

theorem envBound23637 : H12AffineFastState.Bounded env23637 := by
  intro p hp
  have h : env23637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23636_23637 : H12AffineEnvironment.transform 10 0 env23636 = env23637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env23636 == env23637) = true)

theorem identity23637 : scanCanonicalize (H12AffineFastState.compose env23637 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 522) := by decide +kernel

theorem selectedBound23637 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23638 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,522,40,538,1,34,522,0,53,0,539,32,16,2,40,17,0,522,522,0,21,33,37,33,539,513]

theorem envBound23638 : H12AffineFastState.Bounded env23638 := by
  intro p hp
  have h : env23638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23637_23638 : H12AffineEnvironment.transform 11 522 env23637 = env23638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 522 env23637 == env23638) = true)

theorem identity23638 : scanCanonicalize (H12AffineFastState.compose env23638 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound23638 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23639 : List Nat := [2,4,8,16,32,17,8,36,26,52,0,16,40,0,1,34,16,0,53,0,1,32,16,2,40,17,0,16,16,0,21,33,37,33,1,27]

theorem envBound23639 : H12AffineFastState.Bounded env23639 := by
  intro p hp
  have h : env23639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23638_23639 : H12AffineEnvironment.transform 8 26 env23638 = env23639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env23638 == env23639) = true)

def env23640 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272393,2101328,98645,8193,64,2177099,2098512,17664,2461975,2102549,2411540,257,21793,46093,2175563]

theorem envBound23640 : H12AffineFastState.Bounded env23640 := by
  intro p hp
  have h : env23640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23626_23640 : H12AffineEnvironment.transform 6 9 env23626 = env23640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23626 == env23640) = true)

theorem identity23640 : scanCanonicalize (H12AffineFastState.compose env23640 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound23640 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env23641 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77898,272393,73754,98645,8193,64,2049,79130,17664,303453,75103,392286,257,21793,46093,513]

theorem envBound23641 : H12AffineFastState.Bounded env23641 := by
  intro p hp
  have h : env23641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23640_23641 : H12AffineEnvironment.transform 20 77898 env23640 = env23641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env23640 == env23641) = true)

theorem identity23641 : scanCanonicalize (H12AffineFastState.compose env23641 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound23641 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env23642 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,67619,1025,32769,77898,73770,73754,98645,8193,64,2049,79130,17664,108926,75103,62589,257,21793,46093,513]

theorem envBound23642 : H12AffineFastState.Bounded env23642 := by
  intro p hp
  have h : env23642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23641_23642 : H12AffineEnvironment.transform 17 67619 env23641 = env23642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env23641 == env23642) = true)

theorem identity23642 : scanCanonicalize (H12AffineFastState.compose env23642 (packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound23642 : packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS < 2^1333 := by decide +kernel

def env23643 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33031,49217,35108,1025,32769,45389,41261,41245,82,8193,64,2049,46109,17664,10361,42072,62589,257,21793,46093,513]

theorem envBound23643 : H12AffineFastState.Bounded env23643 := by
  intro p hp
  have h : env23643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23642_23643 : H12AffineEnvironment.transform 15 33031 env23642 = env23643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env23642 == env23643) = true)

theorem identity23643 : scanCanonicalize (H12AffineFastState.compose env23643 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound23643 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env23644 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,21511,5441,23588,1025,21761,25677,29741,29725,82,8193,64,2049,24861,17664,10361,29016,8573,257,21793,24845,513]

theorem envBound23644 : H12AffineFastState.Bounded env23644 := by
  intro p hp
  have h : env23644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23643_23644 : H12AffineEnvironment.transform 14 21760 env23643 = env23644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env23643 == env23644) = true)

theorem identity23644 : scanCanonicalize (H12AffineFastState.compose env23644 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound23644 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env23645 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,21511,5441,23588,1025,21761,17681,21873,21825,82,349,64,2049,16449,17664,2341,20484,33,257,21793,16465,513]

theorem envBound23645 : H12AffineFastState.Bounded env23645 := by
  intro p hp
  have h : env23645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23644_23645 : H12AffineEnvironment.transform 12 348 env23644 = env23645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env23644 == env23645) = true)

theorem identity23645 : scanCanonicalize (H12AffineFastState.compose env23645 (packedSelected [0,1,2,3,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound23645 : packedSelected [0,1,2,3,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env23646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1060,348,16384,16676,16419,357,18432,1025,16677,17681,16725,16741,82,349,64,2049,16449,17664,2341,17440,33,257,16645,16465,513]

theorem envBound23646 : H12AffineFastState.Bounded env23646 := by
  intro p hp
  have h : env23646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23645_23646 : H12AffineEnvironment.transform 11 1060 env23645 = env23646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env23645 == env23646) = true)

theorem identity23646 : scanCanonicalize (H12AffineFastState.compose env23646 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23646 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23647 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,1060,40,16384,16464,16419,17,18432,1025,16465,17509,16417,16401,82,41,64,2049,16449,17524,2129,17440,33,117,16497,16465,513]

theorem envBound23647 : H12AffineFastState.Bounded env23647 := by
  intro p hp
  have h : env23647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23646_23647 : H12AffineEnvironment.transform 7 116 env23646 = env23647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23646 == env23647) = true)

theorem identity23647 : scanCanonicalize (H12AffineFastState.compose env23647 (packedSelected [1,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 80) := by decide +kernel

theorem selectedBound23647 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env23648 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,1060,40,80,0,115,17,2128,1025,1,1077,113,65,82,41,64,2049,17,1060,2129,1136,33,117,33,1,513]

theorem envBound23648 : H12AffineFastState.Bounded env23648 := by
  intro p hp
  have h : env23648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23647_23648 : H12AffineEnvironment.transform 13 80 env23647 = env23648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 80 env23647 == env23648) = true)

theorem identity23648 : scanCanonicalize (H12AffineFastState.compose env23648 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23648 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23649 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,1060,40,1,0,34,17,2049,1025,1,1077,32,16,3,41,17,2049,17,1060,2048,1057,33,36,33,1,513]

theorem envBound23649 : H12AffineFastState.Bounded env23649 := by
  intro p hp
  have h : env23649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23648_23649 : H12AffineEnvironment.transform 5 17 env23648 = env23649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23648 == env23649) = true)

theorem identity23649 : scanCanonicalize (H12AffineFastState.compose env23649 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound23649 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23650 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,17,40,1,0,34,17,2049,52,1,0,32,16,3,41,17,2049,17,17,2048,20,33,36,33,1,513]

theorem envBound23650 : H12AffineFastState.Bounded env23650 := by
  intro p hp
  have h : env23650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23649_23650 : H12AffineEnvironment.transform 9 53 env23649 = env23650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env23649 == env23650) = true)

theorem identity23650 : scanCanonicalize (H12AffineFastState.compose env23650 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound23650 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23651 : List Nat := [2,4,8,16,32,17,9,37,512,53,512,17,40,1,0,34,17,513,52,1,0,32,16,3,41,17,513,17,17,512,20,33,36,33,1,513]

theorem envBound23651 : H12AffineFastState.Bounded env23651 := by
  intro p hp
  have h : env23651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23650_23651 : H12AffineEnvironment.transform 10 512 env23650 = env23651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env23650 == env23651) = true)

theorem identity23651 : scanCanonicalize (H12AffineFastState.compose env23651 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound23651 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23652 : List Nat := [2,4,8,16,32,17,9,37,58,53,58,17,40,1,0,34,17,59,52,1,0,32,16,3,41,17,59,17,17,58,20,33,36,33,1,59]

theorem envBound23652 : H12AffineFastState.Bounded env23652 := by
  intro p hp
  have h : env23652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23651_23652 : H12AffineEnvironment.transform 8 58 env23651 = env23652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env23651 == env23652) = true)

theorem identity23652 : scanCanonicalize (H12AffineFastState.compose env23652 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound23652 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23653 : List Nat := [2,4,8,16,26,17,9,31,0,15,0,17,18,1,0,24,17,1,14,1,0,26,16,3,19,17,1,17,17,0,20,27,30,27,1,1]

theorem envBound23653 : H12AffineFastState.Bounded env23653 := by
  intro p hp
  have h : env23653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23652_23653 : H12AffineEnvironment.transform 4 26 env23652 = env23653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env23652 == env23653) = true)

def env23654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2177219,2098512,17664,2462110,2102684,2411676,257,21793,46212,2175563]

theorem envBound23654 : H12AffineFastState.Bounded env23654 := by
  intro p hp
  have h : env23654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23625_23654 : H12AffineEnvironment.transform 21 272513 env23625 = env23654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env23625 == env23654) = true)

theorem identity23654 : scanCanonicalize (H12AffineFastState.compose env23654 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound23654 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,4161,272513,17,98780,8328,64,75906,5393,17664,360927,1501,318685,257,21793,46212,74250]

theorem envBound23655 : H12AffineFastState.Bounded env23655 := by
  intro p hp
  have h : env23655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23654_23655 : H12AffineEnvironment.transform 20 4161 env23654 = env23655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env23654 == env23655) = true)

theorem identity23655 : scanCanonicalize (H12AffineFastState.compose env23655 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23655 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env23656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25028,262144,1025,32769,4161,272513,17,41431,8328,64,2185,5393,17664,303572,1501,318685,257,21793,46212,513]

theorem envBound23656 : H12AffineFastState.Bounded env23656 := by
  intro p hp
  have h : env23656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23655_23656 : H12AffineEnvironment.transform 15 8203 env23655 = env23656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23655 == env23656) = true)

theorem identity23656 : scanCanonicalize (H12AffineFastState.compose env23656 (packedSelected [3,4,9,10,14,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound23656 : packedSelected [3,4,9,10,14,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env23657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,25028,262144,1025,8540,4161,272513,17,138,8328,64,2185,5393,17664,262281,1501,294272,257,21793,5593,513]

theorem envBound23657 : H12AffineFastState.Bounded env23657 := by
  intro p hp
  have h : env23657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23656_23657 : H12AffineEnvironment.transform 14 8541 env23656 = env23657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env23656 == env23657) = true)

theorem identity23657 : scanCanonicalize (H12AffineFastState.compose env23657 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound23657 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,25028,10280,1025,8540,4161,169,17,138,8328,64,2185,5393,17664,10401,1501,21928,257,21793,5593,513]

theorem envBound23658 : H12AffineFastState.Bounded env23658 := by
  intro p hp
  have h : env23658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23657_23658 : H12AffineEnvironment.transform 17 10280 env23657 = env23658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23657 == env23658) = true)

theorem identity23658 : scanCanonicalize (H12AffineFastState.compose env23658 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound23658 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env23659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8541,8203,5529,10280,1025,8540,4161,169,17,138,8328,64,2185,5393,12637,10401,1501,8693,257,8572,5593,513]

theorem envBound23659 : H12AffineFastState.Bounded env23659 := by
  intro p hp
  have h : env23659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23658_23659 : H12AffineEnvironment.transform 13 13405 env23658 = env23659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env23658 == env23659) = true)

theorem identity23659 : scanCanonicalize (H12AffineFastState.compose env23659 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23659 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23660 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8541,8203,5392,10280,1025,8540,4161,32,17,3,8193,64,2048,5393,12637,10280,1364,8572,257,8572,5456,513]

theorem envBound23660 : H12AffineFastState.Bounded env23660 := by
  intro p hp
  have h : env23660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23659_23660 : H12AffineEnvironment.transform 6 9 env23659 = env23660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23659 == env23660) = true)

theorem identity23660 : scanCanonicalize (H12AffineFastState.compose env23660 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound23660 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,372,34,5392,2049,1025,373,4161,32,17,3,40,64,2048,5393,4468,2049,1364,341,257,341,5456,513]

theorem envBound23661 : H12AffineFastState.Bounded env23661 := by
  intro p hp
  have h : env23661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23660_23661 : H12AffineEnvironment.transform 12 41 env23660 = env23661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env23660 == env23661) = true)

theorem identity23661 : scanCanonicalize (H12AffineFastState.compose env23661 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound23661 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env23662 : List Nat := [2,4,8,16,32,64,9,256,512,1024,292,4096,41,5236,372,34,5392,293,1025,373,4161,32,17,3,40,64,292,5393,4468,293,1364,341,257,341,5456,513]

theorem envBound23662 : H12AffineFastState.Bounded env23662 := by
  intro p hp
  have h : env23662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23661_23662 : H12AffineEnvironment.transform 10 292 env23661 = env23662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env23661 == env23662) = true)

theorem identity23662 : scanCanonicalize (H12AffineFastState.compose env23662 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound23662 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env23663 : List Nat := [2,4,8,16,32,64,9,36,512,1024,0,4096,41,5236,80,34,5172,1,1025,81,4161,32,17,3,40,64,0,5173,4176,1,1136,113,37,113,5236,513]

theorem envBound23663 : H12AffineFastState.Bounded env23663 := by
  intro p hp
  have h : env23663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23662_23663 : H12AffineEnvironment.transform 7 36 env23662 = env23663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env23662 == env23663) = true)

theorem identity23663 : scanCanonicalize (H12AffineFastState.compose env23663 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound23663 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env23664 : List Nat := [2,4,8,16,32,64,9,36,512,1024,0,16,41,1124,80,34,1060,1,1025,81,81,32,17,3,40,64,0,1061,64,1,1136,113,37,113,1124,513]

theorem envBound23664 : H12AffineFastState.Bounded env23664 := by
  intro p hp
  have h : env23664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23663_23664 : H12AffineEnvironment.transform 11 16 env23663 = env23664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env23663 == env23664) = true)

theorem identity23664 : scanCanonicalize (H12AffineFastState.compose env23664 (packedSelected [12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23664 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env23665 : List Nat := [2,4,8,16,32,16,9,36,512,1024,0,16,41,1076,0,34,1060,1,1025,1,1,32,17,3,40,16,0,1061,16,1,1056,33,37,33,1076,513]

theorem envBound23665 : H12AffineFastState.Bounded env23665 := by
  intro p hp
  have h : env23665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23664_23665 : H12AffineEnvironment.transform 5 16 env23664 = env23665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23664 == env23665) = true)

theorem identity23665 : scanCanonicalize (H12AffineFastState.compose env23665 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound23665 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23666 : List Nat := [2,4,8,16,32,16,9,36,512,36,0,16,41,16,0,34,0,1,37,1,1,32,17,3,40,16,0,1,16,1,4,33,37,33,16,513]

theorem envBound23666 : H12AffineFastState.Bounded env23666 := by
  intro p hp
  have h : env23666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23665_23666 : H12AffineEnvironment.transform 9 36 env23665 = env23666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env23665 == env23666) = true)

theorem identity23666 : scanCanonicalize (H12AffineFastState.compose env23666 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound23666 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23667 : List Nat := [2,4,8,10,32,10,9,36,512,36,0,10,41,10,0,34,0,1,37,1,1,32,11,3,40,10,0,1,10,1,4,33,37,33,10,513]

theorem envBound23667 : H12AffineFastState.Bounded env23667 := by
  intro p hp
  have h : env23667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23666_23667 : H12AffineEnvironment.transform 3 10 env23666 = env23667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env23666 == env23667) = true)

theorem identity23667 : scanCanonicalize (H12AffineFastState.compose env23667 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound23667 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23668 : List Nat := [2,4,8,10,11,10,9,15,512,15,0,10,2,10,0,9,0,1,14,1,1,11,11,3,3,10,0,1,10,1,4,10,14,10,10,513]

theorem envBound23668 : H12AffineFastState.Bounded env23668 := by
  intro p hp
  have h : env23668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23667_23668 : H12AffineEnvironment.transform 4 11 env23667 = env23668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env23667 == env23668) = true)

theorem identity23668 : scanCanonicalize (H12AffineFastState.compose env23668 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound23668 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23669 : List Nat := [2,0,8,10,11,10,9,11,512,11,0,10,2,10,0,9,0,1,10,1,1,11,11,3,3,10,0,1,10,1,0,10,10,10,10,513]

theorem envBound23669 : H12AffineFastState.Bounded env23669 := by
  intro p hp
  have h : env23669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23668_23669 : H12AffineEnvironment.transform 1 0 env23668 = env23669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env23668 == env23669) = true)

def env23670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6623298,2098513,17665,2462111,2102684,6349852,257,21793,46212,2175563]

theorem envBound23670 : H12AffineFastState.Bounded env23670 := by
  intro p hp
  have h : env23670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23624_23670 : H12AffineEnvironment.transform 22 2101329 env23624 = env23670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env23624 == env23670) = true)

def env23671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2177218,2098513,17665,2462111,2102684,2411676,257,21793,46212,2175563]

theorem envBound23671 : H12AffineFastState.Bounded env23671 := by
  intro p hp
  have h : env23671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23670_23671 : H12AffineEnvironment.transform 21 272512 env23670 = env23671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env23670 == env23671) = true)

theorem identity23671 : scanCanonicalize (H12AffineFastState.compose env23671 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound23671 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,82383,262144,1025,29909,2097152,272512,2101329,95497,8328,64,2177218,2098513,17665,2450763,2102684,2373704,257,21793,16464,2175563]

theorem envBound23672 : H12AffineFastState.Bounded env23672 := by
  intro p hp
  have h : env23672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23671_23672 : H12AffineEnvironment.transform 14 29908 env23671 = env23672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env23671 == env23672) = true)

def env23673 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,82335,262144,1025,29829,2097152,272512,2101249,95497,8328,16,2177170,2098433,17665,2450715,2102684,2373656,257,21793,16384,2175515]

theorem envBound23673 : H12AffineFastState.Bounded env23673 := by
  intro p hp
  have h : env23673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23672_23673 : H12AffineEnvironment.transform 5 16 env23672 = env23673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23672 == env23673) = true)

theorem identity23673 : scanCanonicalize (H12AffineFastState.compose env23673 (packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound23673 : packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env23674 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,82335,262144,1025,29829,25628,272512,29725,95497,8328,16,89230,24861,17665,327943,29056,285700,257,21793,16384,87559]

theorem envBound23674 : H12AffineFastState.Bounded env23674 := by
  intro p hp
  have h : env23674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23673_23674 : H12AffineEnvironment.transform 20 25628 env23673 = env23674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env23673 == env23674) = true)

theorem identity23674 : scanCanonicalize (H12AffineFastState.compose env23674 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound23674 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env23675 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,82335,67754,1025,29829,25628,73770,29725,95497,8328,16,89230,24861,17665,2477,29056,87214,257,21793,16384,87559]

theorem envBound23675 : H12AffineFastState.Bounded env23675 := by
  intro p hp
  have h : env23675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23674_23675 : H12AffineEnvironment.transform 17 67754 env23674 = env23675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env23674 == env23675) = true)

theorem identity23675 : scanCanonicalize (H12AffineFastState.compose env23675 (packedSelected [0,1,5,8,9,22,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound23675 : packedSelected [0,1,5,8,9,22,24,27] rootPS < 2^1333 := by decide +kernel

def env23676 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,30083,13340,32041,1025,29829,25628,21929,29725,138,8328,16,10509,24861,17665,2477,29056,8493,257,21793,16384,9092]

theorem envBound23676 : H12AffineFastState.Bounded env23676 := by
  intro p hp
  have h : env23676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23675_23676 : H12AffineEnvironment.transform 15 30083 env23675 = env23676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env23675 == env23676) = true)

theorem identity23676 : scanCanonicalize (H12AffineFastState.compose env23676 (packedSelected [1,5,8,16,17,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound23676 : packedSelected [1,5,8,16,17,20,24] rootPS < 2^1333 := by decide +kernel

def env23677 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13325,137,398,13340,2340,1025,136,4113,8612,16,138,8328,16,10509,5392,12556,2477,1421,8493,257,8492,13325,9092]

theorem envBound23677 : H12AffineFastState.Bounded env23677 := by
  intro p hp
  have h : env23677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23676_23677 : H12AffineEnvironment.transform 13 13325 env23676 = env23677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env23676 == env23677) = true)

theorem identity23677 : scanCanonicalize (H12AffineFastState.compose env23677 (packedSelected [0,1,2,3,4,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23677 : packedSelected [0,1,2,3,4,10,12] rootPS < 2^1333 := by decide +kernel

def env23678 : List Nat := [2,4,8,16,0,16,128,256,512,1024,2048,4096,8192,13325,137,398,13340,2308,1025,136,4113,8580,16,138,8328,16,10509,5392,12556,2445,1421,8461,257,8460,13325,9092]

theorem envBound23678 : H12AffineFastState.Bounded env23678 := by
  intro p hp
  have h : env23678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23677_23678 : H12AffineEnvironment.transform 4 0 env23677 = env23678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23677 == env23678) = true)

theorem identity23678 : scanCanonicalize (H12AffineFastState.compose env23678 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound23678 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env23679 : List Nat := [2,4,8,16,0,16,128,256,512,1024,2048,4096,388,5513,137,398,5528,2308,1025,136,4113,0,16,138,268,16,2185,5392,4232,2445,1421,137,257,136,5513,512]

theorem envBound23679 : H12AffineFastState.Bounded env23679 := by
  intro p hp
  have h : env23679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23678_23679 : H12AffineEnvironment.transform 12 388 env23678 = env23679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env23678 == env23679) = true)

theorem identity23679 : scanCanonicalize (H12AffineFastState.compose env23679 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound23679 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env23680 : List Nat := [2,4,8,16,0,16,128,140,512,1024,2048,4096,8,5125,137,2,5140,2184,1025,136,4113,0,16,138,128,16,2185,5276,4232,2049,1025,137,141,136,5125,512]

theorem envBound23680 : H12AffineFastState.Bounded env23680 := by
  intro p hp
  have h : env23680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23679_23680 : H12AffineEnvironment.transform 7 140 env23679 = env23680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env23679 == env23680) = true)

def env23681 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,82334,262144,1025,29828,2097152,272512,2101248,95497,8328,17,2177171,2098432,17665,2450714,2102684,2373657,257,21793,16385,2175514]

theorem envBound23681 : H12AffineFastState.Bounded env23681 := by
  intro p hp
  have h : env23681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23672_23681 : H12AffineEnvironment.transform 5 17 env23672 = env23681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23672 == env23681) = true)

theorem identity23681 : scanCanonicalize (H12AffineFastState.compose env23681 (packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound23681 : packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env23682 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,399,16401,262144,1025,29828,2097152,272512,2101248,29830,8328,17,2111772,2098432,17665,2385045,2102684,2373657,257,21793,16385,2110357]

theorem envBound23682 : H12AffineFastState.Bounded env23682 := by
  intro p hp
  have h : env23682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23681_23682 : H12AffineEnvironment.transform 15 399 env23681 = env23682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env23681 == env23682) = true)

theorem identity23682 : scanCanonicalize (H12AffineFastState.compose env23682 (packedSelected [1,3,4,7,9,12,16,17,20,24,27,28,41] rootPS)) = affineNative (2^(20+1) ^^^ 25749) := by decide +kernel

theorem selectedBound23682 : packedSelected [1,3,4,7,9,12,16,17,20,24,27,28,41] rootPS < 2^1333 := by decide +kernel

def env23683 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,399,16401,262144,1025,29828,25749,272512,29845,29830,8328,17,23945,24981,17665,262144,28937,285836,257,21793,16385,22272]

theorem envBound23683 : H12AffineFastState.Bounded env23683 := by
  intro p hp
  have h : env23683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23682_23683 : H12AffineEnvironment.transform 20 25749 env23682 = env23683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25749 env23682 == env23683) = true)

theorem identity23683 : scanCanonicalize (H12AffineFastState.compose env23683 (packedSelected [1,3,4,5,7,8,9,10,17,18,19,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound23683 : packedSelected [1,3,4,5,7,8,9,10,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env23684 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,399,16401,32041,1025,29828,25749,21929,29845,29830,8328,17,23945,24981,17665,32041,28937,8613,257,21793,16385,22272]

theorem envBound23684 : H12AffineFastState.Bounded env23684 := by
  intro p hp
  have h : env23684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23683_23684 : H12AffineEnvironment.transform 17 32041 env23683 = env23684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env23683 == env23684) = true)

theorem identity23684 : scanCanonicalize (H12AffineFastState.compose env23684 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23684 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env23685 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8580,399,5392,10280,1025,8581,12692,168,8596,8583,8328,17,2184,13460,4096,10280,9224,8613,257,32,5376,513]

theorem envBound23685 : H12AffineFastState.Bounded env23685 := by
  intro p hp
  have h : env23685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23684_23685 : H12AffineEnvironment.transform 13 5377 env23684 = env23685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23684 == env23685) = true)

def env23686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2177219,2098513,17665,2462111,2102684,2411677,257,21793,46212,2175563]

theorem envBound23686 : H12AffineFastState.Bounded env23686 := by
  intro p hp
  have h : env23686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23670_23686 : H12AffineEnvironment.transform 21 272513 env23670 = env23686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env23670 == env23686) = true)

theorem identity23686 : scanCanonicalize (H12AffineFastState.compose env23686 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound23686 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,58516,272513,62661,98781,8328,64,121943,57797,17665,357643,61704,272393,257,21793,46212,120543]

theorem envBound23687 : H12AffineFastState.Bounded env23687 := by
  intro p hp
  have h : env23687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23686_23687 : H12AffineEnvironment.transform 20 58516 env23686 = env23687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env23686 == env23687) = true)

def env23688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,10280,1025,32769,58516,169,62661,98781,8328,64,121943,57797,17665,89379,61704,33,257,21793,46212,120543]

theorem envBound23688 : H12AffineFastState.Bounded env23688 := by
  intro p hp
  have h : env23688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23687_23688 : H12AffineEnvironment.transform 17 10280 env23687 = env23688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env23687 == env23688) = true)

theorem identity23688 : scanCanonicalize (H12AffineFastState.compose env23688 (packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound23688 : packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env23689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,40971,57796,10280,1025,32769,58516,169,62661,8662,8328,64,31836,57797,17665,64808,61704,33,257,21793,46212,30420]

theorem envBound23689 : H12AffineFastState.Bounded env23689 := by
  intro p hp
  have h : env23689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23688_23689 : H12AffineEnvironment.transform 15 40971 env23688 = env23689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env23688 == env23689) = true)

theorem identity23689 : scanCanonicalize (H12AffineFastState.compose env23689 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23689 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env23690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,57677,10280,1025,32769,58397,32,62540,8543,8193,64,31836,57676,17665,64808,61704,33,257,21793,46093,30301]

theorem envBound23690 : H12AffineFastState.Bounded env23690 := by
  intro p hp
  have h : env23690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23689_23690 : H12AffineEnvironment.transform 6 9 env23689 = env23690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23689 == env23690) = true)

theorem identity23690 : scanCanonicalize (H12AffineFastState.compose env23690 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound23690 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,40971,38161,10280,1025,32769,36929,32,32784,8543,8193,64,2048,38160,12637,35188,34132,33,257,8573,46093,513]

theorem envBound23691 : H12AffineFastState.Bounded env23691 := by
  intro p hp
  have h : env23691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23690_23691 : H12AffineEnvironment.transform 13 13404 env23690 = env23691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env23690 == env23691) = true)

theorem identity23691 : scanCanonicalize (H12AffineFastState.compose env23691 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23691 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23692 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,32768,40971,38161,10280,1025,32769,36880,32,32784,8462,8193,17,2048,38160,12556,35109,34053,33,257,8492,46093,513]

theorem envBound23692 : H12AffineFastState.Bounded env23692 := by
  intro p hp
  have h : env23692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23691_23692 : H12AffineEnvironment.transform 5 17 env23691 = env23692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23691 == env23692) = true)

theorem identity23692 : scanCanonicalize (H12AffineFastState.compose env23692 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23692 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23693 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,1,8202,5392,10280,1025,0,4113,32,17,8462,8193,17,2048,5393,12556,2340,1284,33,257,8492,13324,513]

theorem envBound23693 : H12AffineFastState.Bounded env23693 := by
  intro p hp
  have h : env23693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23692_23693 : H12AffineEnvironment.transform 14 1 env23692 = env23693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23692 == env23693) = true)

theorem identity23693 : scanCanonicalize (H12AffineFastState.compose env23693 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 804) := by decide +kernel

theorem selectedBound23693 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env23694 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,804,8192,10025,1,8202,1588,10280,1025,0,821,32,17,8462,8193,17,2048,1589,8744,2340,1284,33,257,8492,10024,513]

theorem envBound23694 : H12AffineFastState.Bounded env23694 := by
  intro p hp
  have h : env23694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23693_23694 : H12AffineEnvironment.transform 11 804 env23693 = env23694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 804 env23693 == env23694) = true)

theorem identity23694 : scanCanonicalize (H12AffineFastState.compose env23694 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23694 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env23695 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,804,268,1573,1,262,1588,2340,1025,0,821,32,17,2,269,17,2048,1589,804,2340,1284,33,257,32,1572,513]

theorem envBound23695 : H12AffineFastState.Bounded env23695 := by
  intro p hp
  have h : env23695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23694_23695 : H12AffineEnvironment.transform 12 268 env23694 = env23695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23694 == env23695) = true)

theorem identity23695 : scanCanonicalize (H12AffineFastState.compose env23695 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23695 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23696 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,544,8,1573,1,2,1588,2080,1025,0,561,32,17,2,9,17,2048,1589,544,2080,1024,33,5,32,1572,513]

theorem envBound23696 : H12AffineFastState.Bounded env23696 := by
  intro p hp
  have h : env23696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23695_23696 : H12AffineEnvironment.transform 7 4 env23695 = env23696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23695 == env23696) = true)

theorem identity23696 : scanCanonicalize (H12AffineFastState.compose env23696 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound23696 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23697 : List Nat := [2,4,8,16,32,17,9,4,512,1024,555,544,8,1573,1,2,1588,523,1025,0,561,32,17,2,9,17,555,1589,544,523,1024,33,5,32,1572,513]

theorem envBound23697 : H12AffineFastState.Bounded env23697 := by
  intro p hp
  have h : env23697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23696_23697 : H12AffineEnvironment.transform 10 555 env23696 = env23697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env23696 == env23697) = true)

theorem identity23697 : scanCanonicalize (H12AffineFastState.compose env23697 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound23697 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23698 : List Nat := [2,4,8,16,32,17,9,4,32,1024,11,0,8,1029,1,2,1044,43,1025,0,17,32,17,2,9,17,11,1045,0,43,1024,33,5,32,1028,33]

theorem envBound23698 : H12AffineFastState.Bounded env23698 := by
  intro p hp
  have h : env23698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23697_23698 : H12AffineEnvironment.transform 8 32 env23697 = env23698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env23697 == env23698) = true)

theorem identity23698 : scanCanonicalize (H12AffineFastState.compose env23698 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound23698 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23699 : List Nat := [2,4,8,16,32,17,9,4,32,53,11,0,8,48,1,2,33,43,52,0,17,32,17,2,9,17,11,32,0,43,53,33,5,32,49,33]

theorem envBound23699 : H12AffineFastState.Bounded env23699 := by
  intro p hp
  have h : env23699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23698_23699 : H12AffineEnvironment.transform 9 53 env23698 = env23699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env23698 == env23699) = true)

theorem identity23699 : scanCanonicalize (H12AffineFastState.compose env23699 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound23699 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23700 : List Nat := [2,4,8,16,13,17,9,4,13,24,11,0,8,29,1,2,12,6,25,0,17,13,17,2,9,17,11,13,0,6,24,12,5,13,28,12]

theorem envBound23700 : H12AffineFastState.Bounded env23700 := by
  intro p hp
  have h : env23700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23699_23700 : H12AffineEnvironment.transform 4 13 env23699 = env23700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env23699 == env23700) = true)

theorem identity23700 : scanCanonicalize (H12AffineFastState.compose env23700 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound23700 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23701 : List Nat := [2,4,5,16,0,17,4,4,0,21,6,0,5,16,1,2,1,6,20,0,17,0,17,2,4,17,6,0,0,6,21,1,5,0,17,1]

theorem envBound23701 : H12AffineFastState.Bounded env23701 := by
  intro p hp
  have h : env23701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23700_23701 : H12AffineEnvironment.transform 2 5 env23700 = env23701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env23700 == env23701) = true)

theorem identity23701 : scanCanonicalize (H12AffineFastState.compose env23701 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound23701 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23702 : List Nat := [1,4,5,16,0,17,4,4,0,21,5,0,5,16,1,1,1,5,20,0,17,0,17,1,4,17,5,0,0,5,21,1,5,0,17,1]

theorem envBound23702 : H12AffineFastState.Bounded env23702 := by
  intro p hp
  have h : env23702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23701_23702 : H12AffineEnvironment.transform 0 1 env23701 = env23702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env23701 == env23702) = true)

def env23703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,10281,1025,32769,58516,168,62661,98781,8328,64,121943,57797,17665,89378,61704,32,257,21793,46212,120543]

theorem envBound23703 : H12AffineFastState.Bounded env23703 := by
  intro p hp
  have h : env23703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23687_23703 : H12AffineEnvironment.transform 17 10281 env23687 = env23703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23687 == env23703) = true)

theorem identity23703 : scanCanonicalize (H12AffineFastState.compose env23703 (packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound23703 : packedSelected [0,2,3,4,6,8,9,10,17,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env23704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,1331,17660,10281,1025,32769,58516,168,62661,34030,8328,64,55652,57797,17665,22545,61704,32,257,21793,46212,54252]

theorem envBound23704 : H12AffineFastState.Bounded env23704 := by
  intro p hp
  have h : env23704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23703_23704 : H12AffineEnvironment.transform 15 1331 env23703 = env23704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env23703 == env23704) = true)

theorem identity23704 : scanCanonicalize (H12AffineFastState.compose env23704 (packedSelected [1,3,5,15,26,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound23704 : packedSelected [1,3,5,15,26,28,38] rootPS < 2^1333 := by decide +kernel

def env23705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,292,1331,17660,10281,1025,293,26032,168,30177,1482,8328,64,22592,24801,17665,22545,28716,32,257,21793,13728,21192]

theorem envBound23705 : H12AffineFastState.Bounded env23705 := by
  intro p hp
  have h : env23705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23704_23705 : H12AffineEnvironment.transform 14 292 env23704 = env23705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env23704 == env23705) = true)

theorem identity23705 : scanCanonicalize (H12AffineFastState.compose env23705 (packedSelected [4,5,7,9,10,12,15,17,18,19,23,24,27,31] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound23705 : packedSelected [4,5,7,9,10,12,15,17,18,19,23,24,27,31] rootPS < 2^1333 := by decide +kernel

def env23706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1385,16384,292,1331,17660,3392,1025,293,16601,168,20616,1482,1505,64,22592,17800,17665,22545,21829,32,257,21793,4297,21192]

theorem envBound23706 : H12AffineFastState.Bounded env23706 := by
  intro p hp
  have h : env23706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23705_23706 : H12AffineEnvironment.transform 12 1385 env23705 = env23706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env23705 == env23706) = true)

theorem identity23706 : scanCanonicalize (H12AffineFastState.compose env23706 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,18,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23706 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env23707 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,16384,292,1331,17525,3392,1025,293,16464,33,20481,1347,1384,64,22592,17665,17665,22545,21829,32,257,21793,4160,21057]

theorem envBound23707 : H12AffineFastState.Bounded env23707 := by
  intro p hp
  have h : env23707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23706_23707 : H12AffineEnvironment.transform 6 9 env23706 = env23707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23706 == env23707) = true)

theorem identity23707 : scanCanonicalize (H12AffineFastState.compose env23707 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23707 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23708 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1336,16384,292,1331,17444,3345,1025,293,16385,33,20481,1298,1337,17,22545,17665,17665,22545,21780,32,257,21793,4113,21008]

theorem envBound23708 : H12AffineFastState.Bounded env23708 := by
  intro p hp
  have h : env23708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23707_23708 : H12AffineEnvironment.transform 5 17 env23707 = env23708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23707 == env23708) = true)

def env23709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6623299,8393985,10507600,8749518,2102685,12645452,257,21792,46213,2175562]

theorem envBound23709 : H12AffineFastState.Bounded env23709 := by
  intro p hp
  have h : env23709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23623_23709 : H12AffineEnvironment.transform 23 10588557 env23623 = env23709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env23623 == env23709) = true)

def env23710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6623299,2098513,17664,2462110,2102685,6349852,257,21792,46213,2175562]

theorem envBound23710 : H12AffineFastState.Bounded env23710 := by
  intro p hp
  have h : env23710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23709_23710 : H12AffineEnvironment.transform 22 2101328 env23709 = env23710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env23709 == env23710) = true)

def env23711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2177219,2098513,17664,2462110,2102685,2411676,257,21792,46213,2175562]

theorem envBound23711 : H12AffineFastState.Bounded env23711 := by
  intro p hp
  have h : env23711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23710_23711 : H12AffineEnvironment.transform 21 272512 env23710 = env23711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env23710 == env23711) = true)

theorem identity23711 : scanCanonicalize (H12AffineFastState.compose env23711 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound23711 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,115870,272512,120014,98781,8328,64,64605,115151,17664,283904,119043,329730,257,21792,46213,63188]

theorem envBound23712 : H12AffineFastState.Bounded env23712 := by
  intro p hp
  have h : env23712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23711_23712 : H12AffineEnvironment.transform 20 115870 env23711 = env23712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env23711 == env23712) = true)

def env23713 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,262144,1025,32769,115870,272512,119966,98701,8328,16,64525,115103,17664,283904,119043,329730,257,21792,46213,63108]

theorem envBound23713 : H12AffineFastState.Bounded env23713 := by
  intro p hp
  have h : env23713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23712_23713 : H12AffineEnvironment.transform 5 16 env23712 = env23713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23712 == env23713) = true)

theorem identity23713 : scanCanonicalize (H12AffineFastState.compose env23713 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 64929) := by decide +kernel

theorem selectedBound23713 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env23714 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,64929,1025,32769,115870,54561,119966,98701,8328,16,64525,115103,17664,43169,119043,128419,257,21792,46213,63108]

theorem envBound23714 : H12AffineFastState.Bounded env23714 := by
  intro p hp
  have h : env23714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23713_23714 : H12AffineEnvironment.transform 17 64929 env23713 = env23714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64929 env23713 == env23714) = true)

theorem identity23714 : scanCanonicalize (H12AffineFastState.compose env23714 (packedSelected [4,5,7,8,9,10,16,17,18,20,23,24,26,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23714 : packedSelected [4,5,7,8,9,10,16,17,18,20,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env23715 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,65536,70814,43168,1025,32769,102815,32800,98719,98701,8328,16,43276,103582,4097,43169,99330,106658,257,33,46213,41861]

theorem envBound23715 : H12AffineFastState.Bounded env23715 := by
  intro p hp
  have h : env23715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23714_23715 : H12AffineEnvironment.transform 13 5377 env23714 = env23715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23714 == env23715) = true)

theorem identity23715 : scanCanonicalize (H12AffineFastState.compose env23715 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound23715 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env23716 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,65536,70814,2340,1025,8581,77851,8612,73755,73737,8328,16,2184,79130,4097,2341,75142,65830,257,33,5377,513]

theorem envBound23716 : H12AffineFastState.Bounded env23716 := by
  intro p hp
  have h : env23716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23715_23716 : H12AffineEnvironment.transform 14 8580 env23715 = env23716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env23715 == env23716) = true)

theorem identity23716 : scanCanonicalize (H12AffineFastState.compose env23716 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound23716 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env23717 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5377,1,65536,70814,2340,1025,0,70046,33,65950,65932,269,16,2184,70815,4097,2341,66563,65830,257,33,5377,513]

theorem envBound23717 : H12AffineFastState.Bounded env23717 := by
  intro p hp
  have h : env23717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23716_23717 : H12AffineEnvironment.transform 12 389 env23716 = env23717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env23716 == env23717) = true)

theorem identity23717 : scanCanonicalize (H12AffineFastState.compose env23717 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound23717 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env23718 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5377,1,262,5528,2340,1025,0,4248,33,152,138,269,16,2184,5529,4097,2341,1285,32,257,33,5377,513]

theorem envBound23718 : H12AffineFastState.Bounded env23718 := by
  intro p hp
  have h : env23718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23717_23718 : H12AffineEnvironment.transform 15 262 env23717 = env23718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env23717 == env23718) = true)

theorem identity23718 : scanCanonicalize (H12AffineFastState.compose env23718 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23718 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23719 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,1,262,5392,2340,1025,0,4112,33,16,2,269,16,2048,5393,4097,2341,1285,32,257,33,5377,513]

theorem envBound23719 : H12AffineFastState.Bounded env23719 := by
  intro p hp
  have h : env23719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23718_23719 : H12AffineEnvironment.transform 6 8 env23718 = env23719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23718 == env23719) = true)

theorem identity23719 : scanCanonicalize (H12AffineFastState.compose env23719 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound23719 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23720 : List Nat := [2,4,8,16,17,16,8,256,512,1024,2048,4096,269,5377,1,262,5392,2325,1025,0,4112,16,16,2,269,16,2048,5393,4097,2324,1285,17,257,16,5377,513]

theorem envBound23720 : H12AffineFastState.Bounded env23720 := by
  intro p hp
  have h : env23720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23719_23720 : H12AffineEnvironment.transform 4 17 env23719 = env23720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env23719 == env23720) = true)

theorem identity23720 : scanCanonicalize (H12AffineFastState.compose env23720 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1556) := by decide +kernel

theorem selectedBound23720 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23721 : List Nat := [2,4,8,16,17,16,8,256,512,1024,2048,1556,269,789,1,262,772,2325,1025,0,1540,16,16,2,269,16,2048,773,1557,2324,1285,17,257,16,789,513]

theorem envBound23721 : H12AffineFastState.Bounded env23721 := by
  intro p hp
  have h : env23721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23720_23721 : H12AffineEnvironment.transform 11 1556 env23720 = env23721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env23720 == env23721) = true)

theorem identity23721 : scanCanonicalize (H12AffineFastState.compose env23721 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound23721 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23722 : List Nat := [2,4,8,16,17,16,8,256,512,1024,1541,1556,269,789,1,262,772,1808,1025,0,1540,16,16,2,269,16,1541,773,1557,1809,1285,17,257,16,789,513]

theorem envBound23722 : H12AffineFastState.Bounded env23722 := by
  intro p hp
  have h : env23722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23721_23722 : H12AffineEnvironment.transform 10 1541 env23721 = env23722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env23721 == env23722) = true)

theorem identity23722 : scanCanonicalize (H12AffineFastState.compose env23722 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23722 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23723 : List Nat := [2,4,8,16,17,16,8,5,512,1024,1541,1556,8,528,1,3,513,1557,1025,0,1540,16,16,2,8,16,1541,512,1557,1556,1024,17,4,16,528,513]

theorem envBound23723 : H12AffineFastState.Bounded env23723 := by
  intro p hp
  have h : env23723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23722_23723 : H12AffineEnvironment.transform 7 5 env23722 = env23723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23722 == env23723) = true)

theorem identity23723 : scanCanonicalize (H12AffineFastState.compose env23723 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound23723 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23724 : List Nat := [2,4,8,16,17,16,8,5,512,21,528,513,8,528,1,3,513,512,20,0,529,16,16,2,8,16,528,512,512,513,21,17,4,16,528,513]

theorem envBound23724 : H12AffineFastState.Bounded env23724 := by
  intro p hp
  have h : env23724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23723_23724 : H12AffineEnvironment.transform 9 21 env23723 = env23724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env23723 == env23724) = true)

theorem identity23724 : scanCanonicalize (H12AffineFastState.compose env23724 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound23724 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23725 : List Nat := [2,4,8,16,17,16,8,5,0,21,16,1,8,16,1,3,1,0,20,0,17,16,16,2,8,16,16,0,0,1,21,17,4,16,16,1]

theorem envBound23725 : H12AffineFastState.Bounded env23725 := by
  intro p hp
  have h : env23725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23724_23725 : H12AffineEnvironment.transform 8 0 env23724 = env23725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23724 == env23725) = true)

theorem identity23725 : scanCanonicalize (H12AffineFastState.compose env23725 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound23725 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23726 : List Nat := [2,4,8,11,10,11,8,5,0,14,11,1,8,11,1,3,1,0,15,0,10,11,11,2,8,11,11,0,0,1,14,10,4,11,11,1]

theorem envBound23726 : H12AffineFastState.Bounded env23726 := by
  intro p hp
  have h : env23726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23725_23726 : H12AffineEnvironment.transform 3 11 env23725 = env23726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env23725 == env23726) = true)

def env23727 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,262144,1025,32769,115870,272512,119967,98700,8328,17,64524,115102,17664,283904,119043,329730,257,21792,46213,63109]

theorem envBound23727 : H12AffineFastState.Bounded env23727 := by
  intro p hp
  have h : env23727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23712_23727 : H12AffineEnvironment.transform 5 17 env23712 = env23727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23712 == env23727) = true)

theorem identity23727 : scanCanonicalize (H12AffineFastState.compose env23727 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 100387) := by decide +kernel

theorem selectedBound23727 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env23728 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,100387,1025,32769,115870,106659,119967,98700,8328,17,64524,115102,17664,122147,119043,32801,257,21792,46213,63109]

theorem envBound23728 : H12AffineFastState.Bounded env23728 := by
  intro p hp
  have h : env23728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23727_23728 : H12AffineEnvironment.transform 17 100387 env23727 = env23728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100387 env23727 == env23728) = true)

theorem identity23728 : scanCanonicalize (H12AffineFastState.compose env23728 (packedSelected [4,5,7,8,9,10,16,17,18,20,23,24,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound23728 : packedSelected [4,5,7,8,9,10,16,17,18,20,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env23729 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8580,65536,82334,76199,1025,8581,91418,65831,95515,73736,8328,17,23944,90138,17664,97447,94343,8613,257,21792,5377,22273]

theorem envBound23729 : H12AffineFastState.Bounded env23729 := by
  intro p hp
  have h : env23729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23728_23729 : H12AffineEnvironment.transform 14 8580 env23728 = env23729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env23728 == env23729) = true)

theorem identity23729 : scanCanonicalize (H12AffineFastState.compose env23729 (packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound23729 : packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env23730 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8580,8322,24860,2341,1025,8581,17816,8613,21913,138,8328,17,23944,16536,17664,23589,20485,8613,257,21792,5377,22273]

theorem envBound23730 : H12AffineFastState.Bounded env23730 := by
  intro p hp
  have h : env23730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23729_23730 : H12AffineEnvironment.transform 15 8322 env23729 = env23730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env23729 == env23730) = true)

theorem identity23730 : scanCanonicalize (H12AffineFastState.compose env23730 (packedSelected [1,4,8,9,10,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23730 : packedSelected [1,4,8,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env23731 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,137,399,16401,2341,1025,136,17816,168,21913,138,389,17,23944,16536,17664,23589,20485,168,257,21792,5377,22273]

theorem envBound23731 : H12AffineFastState.Bounded env23731 := by
  intro p hp
  have h : env23731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23730_23731 : H12AffineEnvironment.transform 12 269 env23730 = env23731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23730 == env23731) = true)

theorem identity23731 : scanCanonicalize (H12AffineFastState.compose env23731 (packedSelected [1,3,4,5,8,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23731 : packedSelected [1,3,4,5,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env23732 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,263,16401,2341,1025,0,17680,32,21777,2,269,17,23808,16400,17664,23589,20485,32,257,21792,5377,22273]

theorem envBound23732 : H12AffineFastState.Bounded env23732 := by
  intro p hp
  have h : env23732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23731_23732 : H12AffineEnvironment.transform 6 8 env23731 = env23732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23731 == env23732) = true)

theorem identity23732 : scanCanonicalize (H12AffineFastState.compose env23732 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23732 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env23733 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,9,16384,1,3,16401,2081,1025,0,17428,32,21525,2,9,17,23556,16400,17412,23589,20485,32,5,21540,5125,22021]

theorem envBound23733 : H12AffineFastState.Bounded env23733 := by
  intro p hp
  have h : env23733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23732_23733 : H12AffineEnvironment.transform 7 4 env23732 = env23733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23732 == env23733) = true)

theorem identity23733 : scanCanonicalize (H12AffineFastState.compose env23733 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23733 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env23734 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,4096,9,16384,1,3,16401,2049,1025,0,17428,0,21525,2,9,17,23556,16400,17412,23557,20485,0,5,21508,5125,22021]

theorem envBound23734 : H12AffineFastState.Bounded env23734 := by
  intro p hp
  have h : env23734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23733_23734 : H12AffineEnvironment.transform 4 0 env23733 = env23734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23733 == env23734) = true)

theorem identity23734 : scanCanonicalize (H12AffineFastState.compose env23734 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound23734 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23735 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,4096,9,5125,1,3,5140,2049,1025,0,4113,0,16,2,9,17,2049,5141,4097,2048,1024,0,5,1,5125,512]

theorem envBound23735 : H12AffineFastState.Bounded env23735 := by
  intro p hp
  have h : env23735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23734_23735 : H12AffineEnvironment.transform 13 5125 env23734 = env23735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env23734 == env23735) = true)

def env23736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2177218,2098513,17664,2462110,2102685,2411677,257,21792,46213,2175562]

theorem envBound23736 : H12AffineFastState.Bounded env23736 := by
  intro p hp
  have h : env23736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23710_23736 : H12AffineEnvironment.transform 21 272513 env23710 = env23736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env23710 == env23736) = true)

theorem identity23736 : scanCanonicalize (H12AffineFastState.compose env23736 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound23736 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,38160,262144,1025,32769,2097152,272513,2101328,21762,8328,64,2157597,2098513,17664,2377025,2102685,2411677,257,21792,46213,2156181]

theorem envBound23737 : H12AffineFastState.Bounded env23737 := by
  intro p hp
  have h : env23737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23736_23737 : H12AffineEnvironment.transform 15 54495 env23736 = env23737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env23736 == env23737) = true)

def env23738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38160,262144,1025,32769,2097152,272393,2101328,21762,8192,64,2157597,2098513,17664,2377025,2102549,2411541,257,21792,46093,2156061]

theorem envBound23738 : H12AffineFastState.Bounded env23738 := by
  intro p hp
  have h : env23738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23737_23738 : H12AffineEnvironment.transform 6 8 env23737 = env23738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23737 == env23738) = true)

theorem identity23738 : scanCanonicalize (H12AffineFastState.compose env23738 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 314689) := by decide +kernel

theorem selectedBound23738 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env23739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38160,262144,1025,32769,314689,272393,318737,21762,8192,64,270684,313360,17664,34816,317524,340,257,21792,46093,273244]

theorem envBound23739 : H12AffineFastState.Bounded env23739 := by
  intro p hp
  have h : env23739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23738_23739 : H12AffineEnvironment.transform 20 314689 env23738 = env23739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 314689 env23738 == env23739) = true)

theorem identity23739 : scanCanonicalize (H12AffineFastState.compose env23739 (packedSelected [0,2,3,4,5,6,8,9,10,20,23,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound23739 : packedSelected [0,2,3,4,5,6,8,9,10,20,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env23740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21621,34,16741,262144,1025,21620,268596,272393,264548,21762,8192,64,270684,269413,17664,23669,265249,340,257,21792,24696,273244]

theorem envBound23740 : H12AffineFastState.Bounded env23740 := by
  intro p hp
  have h : env23740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23739_23740 : H12AffineEnvironment.transform 14 21621 env23739 = env23740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env23739 == env23740) = true)

theorem identity23740 : scanCanonicalize (H12AffineFastState.compose env23740 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23740 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env23741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,373,34,5221,262144,1025,372,268596,272393,264548,2,8192,64,270684,269413,4096,2421,265249,340,257,32,13688,273244]

theorem envBound23741 : H12AffineFastState.Bounded env23741 := by
  intro p hp
  have h : env23741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23740_23741 : H12AffineEnvironment.transform 13 5376 env23740 = env23741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23740 == env23741) = true)

theorem identity23741 : scanCanonicalize (H12AffineFastState.compose env23741 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound23741 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env23742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,373,34,5221,2048,1025,372,4404,8201,356,2,8192,64,10588,5221,4096,2421,1057,340,257,32,13688,9052]

theorem envBound23742 : H12AffineFastState.Bounded env23742 := by
  intro p hp
  have h : env23742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23741_23742 : H12AffineEnvironment.transform 17 2048 env23741 = env23742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env23741 == env23742) = true)

theorem identity23742 : scanCanonicalize (H12AffineFastState.compose env23742 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23742 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env23743 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,373,34,5221,2048,1025,372,4404,261,356,2,268,64,2128,5221,4096,2421,1057,340,257,32,5236,592]

theorem envBound23743 : H12AffineFastState.Bounded env23743 := by
  intro p hp
  have h : env23743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23742_23743 : H12AffineEnvironment.transform 12 268 env23742 = env23743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23742 == env23743) = true)

theorem identity23743 : scanCanonicalize (H12AffineFastState.compose env23743 (packedSelected [1,4,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound23743 : packedSelected [1,4,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env23744 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,268,3392,373,34,3109,2048,1025,372,2420,261,356,2,268,64,2128,3109,2112,2421,1057,340,257,32,3124,592]

theorem envBound23744 : H12AffineFastState.Bounded env23744 := by
  intro p hp
  have h : env23744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23743_23744 : H12AffineEnvironment.transform 11 2112 env23743 = env23744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env23743 == env23744) = true)

theorem identity23744 : scanCanonicalize (H12AffineFastState.compose env23744 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound23744 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env23745 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,356,268,1124,373,34,1281,292,1025,372,80,261,356,2,268,64,372,1281,356,81,1057,340,257,32,1296,592]

theorem envBound23745 : H12AffineFastState.Bounded env23745 := by
  intro p hp
  have h : env23745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23744_23745 : H12AffineEnvironment.transform 10 292 env23744 = env23745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env23744 == env23745) = true)

def env23746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,262144,1025,32769,2097152,272392,2101328,21762,8193,64,2157597,2098513,17664,2377025,2102548,2411540,257,21792,46092,2156060]

theorem envBound23746 : H12AffineFastState.Bounded env23746 := by
  intro p hp
  have h : env23746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23737_23746 : H12AffineEnvironment.transform 6 9 env23737 = env23746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23737 == env23746) = true)

theorem identity23746 : scanCanonicalize (H12AffineFastState.compose env23746 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound23746 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env23747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,262144,1025,32769,25629,272392,29773,21762,8193,64,34816,24908,17664,270684,28937,305161,257,21792,46092,33281]

theorem envBound23747 : H12AffineFastState.Bounded env23747 := by
  intro p hp
  have h : env23747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23746_23747 : H12AffineEnvironment.transform 20 25629 env23746 = env23747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env23746 == env23747) = true)

theorem identity23747 : scanCanonicalize (H12AffineFastState.compose env23747 (packedSelected [1,3,5,8,19,31] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound23747 : packedSelected [1,3,5,8,19,31] rootPS < 2^1333 := by decide +kernel

def env23748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,23668,1025,32769,25629,29820,29773,21762,8193,64,34816,24908,17664,32040,28937,62589,257,21792,46092,33281]

theorem envBound23748 : H12AffineFastState.Bounded env23748 := by
  intro p hp
  have h : env23748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23747_23748 : H12AffineEnvironment.transform 17 23668 env23747 = env23748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env23747 == env23748) = true)

theorem identity23748 : scanCanonicalize (H12AffineFastState.compose env23748 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23748 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,21590,5392,23668,1025,1,25629,29820,29773,21762,8193,64,2048,24908,17664,32040,28937,29821,257,21792,13324,513]

theorem envBound23749 : H12AffineFastState.Bounded env23749 := by
  intro p hp
  have h : env23749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23748_23749 : H12AffineEnvironment.transform 14 0 env23748 = env23749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23748 == env23749) = true)

theorem identity23749 : scanCanonicalize (H12AffineFastState.compose env23749 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound23749 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,8202,5392,10280,1025,1,4161,32,17,8542,8193,64,2048,5392,12636,2420,1365,33,257,8572,13324,513]

theorem envBound23750 : H12AffineFastState.Bounded env23750 := by
  intro p hp
  have h : env23750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23749_23750 : H12AffineEnvironment.transform 13 13404 env23749 = env23750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env23749 == env23750) = true)

theorem identity23750 : scanCanonicalize (H12AffineFastState.compose env23750 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23750 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,0,263,5392,2341,1025,1,4161,32,17,83,268,64,2048,5392,4177,2420,1365,33,257,113,5377,513]

theorem envBound23751 : H12AffineFastState.Bounded env23751 := by
  intro p hp
  have h : env23751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23750_23751 : H12AffineEnvironment.transform 12 269 env23750 = env23751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23750 == env23751) = true)

theorem identity23751 : scanCanonicalize (H12AffineFastState.compose env23751 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound23751 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env23752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,528,4096,269,5457,0,263,5392,821,1025,1,4161,32,17,83,268,64,528,5392,4177,868,1365,33,257,113,5377,513]

theorem envBound23752 : H12AffineFastState.Bounded env23752 := by
  intro p hp
  have h : env23752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23751_23752 : H12AffineEnvironment.transform 10 528 env23751 = env23752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env23751 == env23752) = true)

theorem identity23752 : scanCanonicalize (H12AffineFastState.compose env23752 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23752 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env23753 : List Nat := [2,4,8,16,32,16,9,256,512,1024,528,4096,269,5377,0,263,5392,821,1025,1,4113,32,17,3,268,16,528,5392,4097,820,1285,33,257,33,5377,513]

theorem envBound23753 : H12AffineFastState.Bounded env23753 := by
  intro p hp
  have h : env23753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23752_23753 : H12AffineEnvironment.transform 5 16 env23752 = env23753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23752 == env23753) = true)

theorem identity23753 : scanCanonicalize (H12AffineFastState.compose env23753 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23753 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23754 : List Nat := [2,4,8,16,0,16,9,256,512,1024,528,4096,269,5377,0,263,5392,789,1025,1,4113,0,17,3,268,16,528,5392,4097,788,1285,1,257,1,5377,513]

theorem envBound23754 : H12AffineFastState.Bounded env23754 := by
  intro p hp
  have h : env23754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23753_23754 : H12AffineEnvironment.transform 4 0 env23753 = env23754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23753 == env23754) = true)

theorem identity23754 : scanCanonicalize (H12AffineFastState.compose env23754 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1307) := by decide +kernel

theorem selectedBound23754 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23755 : List Nat := [2,4,8,16,0,16,9,256,512,1024,528,1307,269,26,0,263,11,789,1025,1,1290,0,17,3,268,16,528,11,1306,788,1285,1,257,1,26,513]

theorem envBound23755 : H12AffineFastState.Bounded env23755 := by
  intro p hp
  have h : env23755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23754_23755 : H12AffineEnvironment.transform 11 1307 env23754 = env23755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1307 env23754 == env23755) = true)

theorem identity23755 : scanCanonicalize (H12AffineFastState.compose env23755 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound23755 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23756 : List Nat := [2,4,8,16,0,16,9,256,512,31,528,260,269,26,0,263,11,789,30,1,277,0,17,3,268,16,528,11,261,788,282,1,257,1,26,513]

theorem envBound23756 : H12AffineFastState.Bounded env23756 := by
  intro p hp
  have h : env23756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23755_23756 : H12AffineEnvironment.transform 9 31 env23755 = env23756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env23755 == env23756) = true)

theorem identity23756 : scanCanonicalize (H12AffineFastState.compose env23756 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 287) := by decide +kernel

theorem selectedBound23756 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23757 : List Nat := [2,4,8,16,0,16,9,256,287,31,271,260,269,26,0,263,11,10,30,1,277,0,17,3,268,16,271,11,261,11,282,1,257,1,26,286]

theorem envBound23757 : H12AffineFastState.Bounded env23757 := by
  intro p hp
  have h : env23757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23756_23757 : H12AffineEnvironment.transform 8 287 env23756 = env23757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 287 env23756 == env23757) = true)

theorem identity23757 : scanCanonicalize (H12AffineFastState.compose env23757 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23757 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23758 : List Nat := [2,4,8,16,0,16,9,5,26,31,10,1,8,26,0,2,11,10,30,1,16,0,17,3,9,16,10,11,0,11,31,1,4,1,26,27]

theorem envBound23758 : H12AffineFastState.Bounded env23758 := by
  intro p hp
  have h : env23758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23757_23758 : H12AffineEnvironment.transform 7 5 env23757 = env23758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23757 == env23758) = true)

theorem identity23758 : scanCanonicalize (H12AffineFastState.compose env23758 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound23758 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23759 : List Nat := [2,4,8,7,0,7,9,5,13,8,10,1,8,13,0,2,11,10,9,1,7,0,6,3,9,7,10,11,0,11,8,1,4,1,13,12]

theorem envBound23759 : H12AffineFastState.Bounded env23759 := by
  intro p hp
  have h : env23759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23758_23759 : H12AffineEnvironment.transform 3 7 env23758 = env23759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env23758 == env23759) = true)

theorem identity23759 : scanCanonicalize (H12AffineFastState.compose env23759 (packedSelected [0,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound23759 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env23760 : List Nat := [2,4,4,7,0,7,5,5,1,4,6,1,4,1,0,2,7,6,5,1,7,0,6,3,5,7,6,7,0,7,4,1,4,1,1,0]

theorem envBound23760 : H12AffineFastState.Bounded env23760 := by
  intro p hp
  have h : env23760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23759_23760 : H12AffineEnvironment.transform 2 4 env23759 = env23760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env23759 == env23760) = true)

theorem identity23760 : scanCanonicalize (H12AffineFastState.compose env23760 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound23760 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23761 : List Nat := [1,4,4,4,0,4,5,5,1,4,5,1,4,1,0,1,4,5,5,1,4,0,5,0,5,4,5,4,0,4,4,1,4,1,1,0]

theorem envBound23761 : H12AffineFastState.Bounded env23761 := by
  intro p hp
  have h : env23761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23760_23761 : H12AffineEnvironment.transform 0 1 env23760 = env23761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env23760 == env23761) = true)

def env23762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6623299,2098512,17665,2462111,2102685,6349853,257,21792,46213,2175562]

theorem envBound23762 : H12AffineFastState.Bounded env23762 := by
  intro p hp
  have h : env23762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23709_23762 : H12AffineEnvironment.transform 22 2101329 env23709 = env23762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env23709 == env23762) = true)

def env23763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2177219,2098512,17665,2462111,2102685,2411677,257,21792,46213,2175562]

theorem envBound23763 : H12AffineFastState.Bounded env23763 := by
  intro p hp
  have h : env23763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23762_23763 : H12AffineEnvironment.transform 21 272512 env23762 = env23763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env23762 == env23763) = true)

theorem identity23763 : scanCanonicalize (H12AffineFastState.compose env23763 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound23763 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,77899,272512,73754,98780,8328,64,2184,79131,17665,303572,75222,392406,257,21792,46213,513]

theorem envBound23764 : H12AffineFastState.Bounded env23764 := by
  intro p hp
  have h : env23764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23763_23764 : H12AffineEnvironment.transform 20 77899 env23763 = env23764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env23763 == env23764) = true)

def env23765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77899,272392,73754,98644,8192,64,2048,79131,17665,303452,75102,392286,257,21792,46093,513]

theorem envBound23765 : H12AffineFastState.Bounded env23765 := by
  intro p hp
  have h : env23765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23764_23765 : H12AffineEnvironment.transform 6 8 env23764 = env23765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23764 == env23765) = true)

theorem identity23765 : scanCanonicalize (H12AffineFastState.compose env23765 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound23765 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env23766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82247,262144,1025,32769,69910,264533,65863,98644,349,64,2048,70726,17665,294913,66563,384259,257,21792,38224,513]

theorem envBound23766 : H12AffineFastState.Bounded env23766 := by
  intro p hp
  have h : env23766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23765_23766 : H12AffineEnvironment.transform 12 349 env23765 = env23766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env23765 == env23766) = true)

theorem identity23766 : scanCanonicalize (H12AffineFastState.compose env23766 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound23766 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env23767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82247,35188,1025,32769,69910,32801,65863,98644,349,64,2048,70726,17665,2421,66563,87159,257,21792,38224,513]

theorem envBound23767 : H12AffineFastState.Bounded env23767 := by
  intro p hp
  have h : env23767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23766_23767 : H12AffineEnvironment.transform 17 35188 env23766 = env23767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env23766 == env23767) = true)

theorem identity23767 : scanCanonicalize (H12AffineFastState.compose env23767 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23767 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,65536,70726,35188,1025,32769,69910,32801,65863,98644,349,64,2048,70726,4096,2421,66563,65910,257,33,38224,513]

theorem envBound23768 : H12AffineFastState.Bounded env23768 := by
  intro p hp
  have h : env23768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23767_23768 : H12AffineEnvironment.transform 13 5377 env23767 = env23768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23767 == env23768) = true)

theorem identity23768 : scanCanonicalize (H12AffineFastState.compose env23768 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound23768 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1297,65536,70726,3173,1025,1296,69910,1328,65863,66629,349,64,2048,70726,4096,2421,66563,65910,257,33,4161,513]

theorem envBound23769 : H12AffineFastState.Bounded env23769 := by
  intro p hp
  have h : env23769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23768_23769 : H12AffineEnvironment.transform 14 1297 env23768 = env23769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env23768 == env23769) = true)

theorem identity23769 : scanCanonicalize (H12AffineFastState.compose env23769 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23769 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env23770 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,1124,65536,70726,3173,1025,1125,69731,1093,65586,66629,40,64,2048,70726,4096,2048,66563,65539,116,33,4161,513]

theorem envBound23770 : H12AffineFastState.Bounded env23770 := by
  intro p hp
  have h : env23770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23769_23770 : H12AffineEnvironment.transform 7 117 env23769 = env23770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23769 == env23770) = true)

theorem identity23770 : scanCanonicalize (H12AffineFastState.compose env23770 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound23770 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env23771 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,1124,1095,4097,3173,1025,1125,5156,1093,1141,2,40,64,2048,4097,4096,2048,68,1092,116,33,4161,513]

theorem envBound23771 : H12AffineFastState.Bounded env23771 := by
  intro p hp
  have h : env23771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23770_23771 : H12AffineEnvironment.transform 15 1095 env23770 = env23771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env23770 == env23771) = true)

theorem identity23771 : scanCanonicalize (H12AffineFastState.compose env23771 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound23771 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23772 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,40,4112,0,35,4097,2049,101,1,4160,33,17,2,40,64,2048,4097,4096,2048,68,32,116,33,4161,513]

theorem envBound23772 : H12AffineFastState.Bounded env23772 := by
  intro p hp
  have h : env23772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23771_23772 : H12AffineEnvironment.transform 9 100 env23771 = env23772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env23771 == env23772) = true)

theorem identity23772 : scanCanonicalize (H12AffineFastState.compose env23772 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound23772 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23773 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,48,40,32,0,35,49,2049,101,1,112,33,17,2,40,64,2048,49,48,2048,68,32,116,33,113,513]

theorem envBound23773 : H12AffineFastState.Bounded env23773 := by
  intro p hp
  have h : env23773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23772_23773 : H12AffineEnvironment.transform 11 48 env23772 = env23773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env23772 == env23773) = true)

theorem identity23773 : scanCanonicalize (H12AffineFastState.compose env23773 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23773 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23774 : List Nat := [2,4,8,16,0,64,8,85,512,68,2048,16,8,0,0,3,17,2049,69,1,80,1,17,2,8,64,2048,17,16,2048,68,0,84,1,81,513]

theorem envBound23774 : H12AffineFastState.Bounded env23774 := by
  intro p hp
  have h : env23774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23773_23774 : H12AffineEnvironment.transform 4 0 env23773 = env23774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23773 == env23774) = true)

theorem identity23774 : scanCanonicalize (H12AffineFastState.compose env23774 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound23774 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23775 : List Nat := [2,4,8,16,0,64,8,85,512,68,592,16,8,0,0,3,17,593,69,1,80,1,17,2,8,64,592,17,16,592,68,0,84,1,81,513]

theorem envBound23775 : H12AffineFastState.Bounded env23775 := by
  intro p hp
  have h : env23775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23774_23775 : H12AffineEnvironment.transform 10 592 env23774 = env23775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env23774 == env23775) = true)

theorem identity23775 : scanCanonicalize (H12AffineFastState.compose env23775 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23775 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23776 : List Nat := [2,4,8,16,0,16,8,5,512,20,512,16,8,0,0,3,17,513,21,1,0,1,17,2,8,16,512,17,16,512,20,0,4,1,1,513]

theorem envBound23776 : H12AffineFastState.Bounded env23776 := by
  intro p hp
  have h : env23776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23775_23776 : H12AffineEnvironment.transform 5 16 env23775 = env23776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23775 == env23776) = true)

theorem identity23776 : scanCanonicalize (H12AffineFastState.compose env23776 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound23776 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23777 : List Nat := [2,4,2,16,0,16,2,5,512,20,512,16,2,0,0,3,17,513,21,1,0,1,17,2,2,16,512,17,16,512,20,0,4,1,1,513]

theorem envBound23777 : H12AffineFastState.Bounded env23777 := by
  intro p hp
  have h : env23777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23776_23777 : H12AffineEnvironment.transform 2 2 env23776 = env23777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env23776 == env23777) = true)

theorem identity23777 : scanCanonicalize (H12AffineFastState.compose env23777 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23777 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23778 : List Nat := [2,4,2,1,0,1,2,5,512,5,512,1,2,0,0,3,0,513,4,1,0,1,0,2,2,1,512,0,1,512,5,0,4,1,1,513]

theorem envBound23778 : H12AffineFastState.Bounded env23778 := by
  intro p hp
  have h : env23778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23777_23778 : H12AffineEnvironment.transform 3 1 env23777 = env23778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23777 == env23778) = true)

theorem identity23778 : scanCanonicalize (H12AffineFastState.compose env23778 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound23778 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23779 : List Nat := [2,4,2,1,0,1,2,5,0,5,0,1,2,0,0,3,0,1,4,1,0,1,0,2,2,1,0,0,1,0,5,0,4,1,1,1]

theorem envBound23779 : H12AffineFastState.Bounded env23779 := by
  intro p hp
  have h : env23779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23778_23779 : H12AffineEnvironment.transform 8 0 env23778 = env23779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23778 == env23779) = true)

def env23780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77899,272393,73754,98645,8193,64,2049,79131,17665,303453,75103,392287,257,21792,46092,513]

theorem envBound23780 : H12AffineFastState.Bounded env23780 := by
  intro p hp
  have h : env23780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23764_23780 : H12AffineEnvironment.transform 6 9 env23764 = env23780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23764 == env23780) = true)

theorem identity23780 : scanCanonicalize (H12AffineFastState.compose env23780 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound23780 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env23781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,67619,1025,32769,77899,73770,73754,98645,8193,64,2049,79131,17665,108926,75103,62588,257,21792,46092,513]

theorem envBound23781 : H12AffineFastState.Bounded env23781 := by
  intro p hp
  have h : env23781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23780_23781 : H12AffineEnvironment.transform 17 67619 env23780 = env23781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env23780 == env23781) = true)

theorem identity23781 : scanCanonicalize (H12AffineFastState.compose env23781 (packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound23781 : packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS < 2^1333 := by decide +kernel

def env23782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,65536,82246,67619,1025,8461,77899,73770,73754,73817,8193,64,2049,79131,17665,67698,75103,21872,257,21792,5376,513]

theorem envBound23782 : H12AffineFastState.Bounded env23782 := by
  intro p hp
  have h : env23782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23781_23782 : H12AffineEnvironment.transform 14 8460 env23781 = env23782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env23781 == env23782) = true)

theorem identity23782 : scanCanonicalize (H12AffineFastState.compose env23782 (packedSelected [0,1,2,4,5,6,7,8,9,14,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound23782 : packedSelected [0,1,2,4,5,6,7,8,9,14,18,23,24] rootPS < 2^1333 := by decide +kernel

def env23783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8460,65536,79179,67619,1025,8461,77899,73770,73754,73817,8193,64,2049,79131,12556,67698,75103,8573,257,8493,5376,513]

theorem envBound23783 : H12AffineFastState.Bounded env23783 := by
  intro p hp
  have h : env23783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23782_23783 : H12AffineEnvironment.transform 13 13325 env23782 = env23783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env23782 == env23783) = true)

theorem identity23783 : scanCanonicalize (H12AffineFastState.compose env23783 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound23783 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env23784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8460,262,13389,2341,1025,8461,12621,8492,8476,8543,8193,64,2049,13341,12556,2420,9305,8573,257,8493,5376,513]

theorem envBound23784 : H12AffineFastState.Bounded env23784 := by
  intro p hp
  have h : env23784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23783_23784 : H12AffineEnvironment.transform 15 262 env23783 = env23784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env23783 == env23784) = true)

theorem identity23784 : scanCanonicalize (H12AffineFastState.compose env23784 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23784 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env23785 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,8460,262,13341,2341,1025,8461,12573,8492,8476,8463,8193,16,2049,13341,12556,2340,9225,8493,257,8493,5376,513]

theorem envBound23785 : H12AffineFastState.Bounded env23785 := by
  intro p hp
  have h : env23785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23784_23785 : H12AffineEnvironment.transform 5 16 env23784 = env23785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23784 == env23785) = true)

theorem identity23785 : scanCanonicalize (H12AffineFastState.compose env23785 (packedSelected [1,2,3,4,5,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound23785 : packedSelected [1,2,3,4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env23786 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3109,8192,10280,8460,262,10296,2341,1025,8461,11576,8492,8476,8463,8193,16,2049,10296,11561,2340,9225,8493,257,8493,2341,513]

theorem envBound23786 : H12AffineFastState.Bounded env23786 := by
  intro p hp
  have h : env23786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23785_23786 : H12AffineEnvironment.transform 11 3109 env23785 = env23786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env23785 == env23786) = true)

theorem identity23786 : scanCanonicalize (H12AffineFastState.compose env23786 (packedSelected [2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound23786 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env23787 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3109,1052,3124,1296,262,3108,2341,1025,1297,2340,1328,1280,1299,1053,16,2049,3108,2357,2340,21,1329,257,1329,2341,513]

theorem envBound23787 : H12AffineFastState.Bounded env23787 := by
  intro p hp
  have h : env23787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23786_23787 : H12AffineEnvironment.transform 12 1052 env23786 = env23787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env23786 == env23787) = true)

theorem identity23787 : scanCanonicalize (H12AffineFastState.compose env23787 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound23787 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env23788 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2356,269,2341,1,262,2357,2341,272,0,2340,33,17,2,268,16,2049,2357,2357,2340,21,32,257,32,2341,513]

theorem envBound23788 : H12AffineFastState.Bounded env23788 := by
  intro p hp
  have h : env23788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23787_23788 : H12AffineEnvironment.transform 9 273 env23787 = env23788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env23787 == env23788) = true)

theorem identity23788 : scanCanonicalize (H12AffineFastState.compose env23788 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound23788 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23789 : List Nat := [2,4,8,16,16,16,9,256,512,273,2048,2308,269,2325,1,262,2309,2325,272,0,2324,17,17,2,268,16,2049,2309,2309,2324,21,16,257,16,2325,513]

theorem envBound23789 : H12AffineFastState.Bounded env23789 := by
  intro p hp
  have h : env23789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23788_23789 : H12AffineEnvironment.transform 4 16 env23788 = env23789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env23788 == env23789) = true)

theorem identity23789 : scanCanonicalize (H12AffineFastState.compose env23789 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound23789 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23790 : List Nat := [2,4,8,16,16,16,9,256,512,273,11,271,269,286,1,262,270,286,272,0,287,17,17,2,268,16,10,270,270,287,21,16,257,16,286,513]

theorem envBound23790 : H12AffineFastState.Bounded env23790 := by
  intro p hp
  have h : env23790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23789_23790 : H12AffineEnvironment.transform 10 11 env23789 = env23790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env23789 == env23790) = true)

theorem identity23790 : scanCanonicalize (H12AffineFastState.compose env23790 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound23790 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23791 : List Nat := [2,4,8,16,16,16,9,256,261,273,11,271,269,286,1,262,270,286,272,0,287,17,17,2,268,16,10,270,270,287,21,16,257,16,286,260]

theorem envBound23791 : H12AffineFastState.Bounded env23791 := by
  intro p hp
  have h : env23791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23790_23791 : H12AffineEnvironment.transform 8 261 env23790 = env23791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env23790 == env23791) = true)

theorem identity23791 : scanCanonicalize (H12AffineFastState.compose env23791 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound23791 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23792 : List Nat := [2,4,8,16,16,16,9,15,10,30,11,0,2,17,1,9,1,17,31,0,16,17,17,2,3,16,10,1,1,16,21,16,14,16,17,11]

theorem envBound23792 : H12AffineFastState.Bounded env23792 := by
  intro p hp
  have h : env23792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23791_23792 : H12AffineEnvironment.transform 7 15 env23791 = env23792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env23791 == env23792) = true)

theorem identity23792 : scanCanonicalize (H12AffineFastState.compose env23792 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound23792 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23793 : List Nat := [2,4,8,5,5,5,9,15,10,11,11,0,2,4,1,9,1,4,10,0,5,4,4,2,3,5,10,1,1,5,0,5,14,5,4,11]

theorem envBound23793 : H12AffineFastState.Bounded env23793 := by
  intro p hp
  have h : env23793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23792_23793 : H12AffineEnvironment.transform 3 5 env23792 = env23793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env23792 == env23793) = true)

theorem identity23793 : scanCanonicalize (H12AffineFastState.compose env23793 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound23793 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env23794 : List Nat := [2,4,3,5,5,5,2,4,1,0,0,0,2,4,1,2,1,4,1,0,5,4,4,2,3,5,1,1,1,5,0,5,5,5,4,0]

theorem envBound23794 : H12AffineFastState.Bounded env23794 := by
  intro p hp
  have h : env23794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23793_23794 : H12AffineEnvironment.transform 2 3 env23793 = env23794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env23793 == env23794) = true)

theorem identity23794 : scanCanonicalize (H12AffineFastState.compose env23794 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound23794 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23795 : List Nat := [0,4,1,5,5,5,0,4,1,0,0,0,0,4,1,0,1,4,1,0,5,4,4,0,1,5,1,1,1,5,0,5,5,5,4,0]

theorem envBound23795 : H12AffineFastState.Bounded env23795 := by
  intro p hp
  have h : env23795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23794_23795 : H12AffineEnvironment.transform 0 0 env23794 = env23795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env23794 == env23795) = true)

def env23796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2177218,2098512,17665,2462111,2102685,2411676,257,21792,46213,2175562]

theorem envBound23796 : H12AffineFastState.Bounded env23796 := by
  intro p hp
  have h : env23796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23762_23796 : H12AffineEnvironment.transform 21 272513 env23762 = env23796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env23762 == env23796) = true)

theorem identity23796 : scanCanonicalize (H12AffineFastState.compose env23796 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23796 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25028,262144,1025,32769,2097152,272513,2101329,41431,8328,64,2103497,2098512,17665,2404756,2102685,2411676,257,21792,46213,2101825]

end H12CloudChart1