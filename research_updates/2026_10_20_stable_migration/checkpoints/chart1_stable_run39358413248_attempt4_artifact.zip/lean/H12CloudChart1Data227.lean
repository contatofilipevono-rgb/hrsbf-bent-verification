import H12CloudChart1Data226

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans57521_57522 : H12AffineEnvironment.transform 14 2723 env57521 = env57522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2723 env57521 == env57522) = true)

theorem identity57522 : scanCanonicalize (H12AffineFastState.compose env57522 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound57522 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env57523 : List Nat := [2,4,8,16,32,16,128,256,512,172,2048,2090,2562,2091,2723,2860,2438,919,172,2723,544,32,2587,2860,2699,2586,2325,2091,2438,2341,2574,168,257,2831,2439,512]

theorem envBound57523 : H12AffineFastState.Bounded env57523 := by
  intro p hp
  have h : env57523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57522_57523 : H12AffineEnvironment.transform 11 2090 env57522 = env57523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env57522 == env57523) = true)

theorem identity57523 : scanCanonicalize (H12AffineFastState.compose env57523 (packedSelected [0,1,3,7,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound57523 : packedSelected [0,1,3,7,11,15] rootPS < 2^1333 := by decide +kernel

def env57524 : List Nat := [2,4,8,16,32,16,57,256,512,21,2048,2090,2562,2091,2586,2860,2367,814,21,2586,544,32,2587,2860,2610,2586,2325,2091,2367,2341,2574,17,257,2831,2366,512]

theorem envBound57524 : H12AffineFastState.Bounded env57524 := by
  intro p hp
  have h : env57524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57523_57524 : H12AffineEnvironment.transform 6 57 env57523 = env57524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env57523 == env57524) = true)

theorem identity57524 : scanCanonicalize (H12AffineFastState.compose env57524 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 799) := by decide +kernel

theorem selectedBound57524 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57525 : List Nat := [2,4,8,16,32,16,57,256,512,21,799,821,285,820,261,51,544,814,21,261,544,32,260,51,301,261,522,820,544,570,273,17,257,16,545,512]

theorem envBound57525 : H12AffineFastState.Bounded env57525 := by
  intro p hp
  have h : env57525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57524_57525 : H12AffineEnvironment.transform 10 799 env57524 = env57525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 799 env57524 == env57525) = true)

def env57526 : List Nat := [2,4,8,16,16,16,9,256,512,21,799,773,285,772,261,3,528,798,21,261,528,16,260,3,285,261,522,772,528,522,273,17,257,16,529,512]

theorem envBound57526 : H12AffineFastState.Bounded env57526 := by
  intro p hp
  have h : env57526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57525_57526 : H12AffineEnvironment.transform 4 16 env57525 = env57526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57525 == env57526) = true)

theorem identity57526 : scanCanonicalize (H12AffineFastState.compose env57526 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound57526 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57527 : List Nat := [2,4,8,16,16,16,9,30,512,21,513,539,3,538,27,3,528,512,21,27,528,16,26,3,3,27,522,538,528,522,15,17,31,16,529,512]

theorem envBound57527 : H12AffineFastState.Bounded env57527 := by
  intro p hp
  have h : env57527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57526_57527 : H12AffineEnvironment.transform 7 30 env57526 = env57527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env57526 == env57527) = true)

theorem identity57527 : scanCanonicalize (H12AffineFastState.compose env57527 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57527 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57528 : List Nat := [2,4,8,11,11,11,9,5,512,14,513,512,3,513,0,3,523,512,14,0,523,11,1,3,3,0,522,513,523,522,15,10,4,11,522,512]

theorem envBound57528 : H12AffineFastState.Bounded env57528 := by
  intro p hp
  have h : env57528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57527_57528 : H12AffineEnvironment.transform 3 11 env57527 = env57528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57527 == env57528) = true)

def env57529 : List Nat := [2,4,8,16,17,16,8,256,512,21,799,772,285,773,261,2,529,799,21,261,529,17,260,2,284,261,522,773,529,523,273,17,257,16,528,512]

theorem envBound57529 : H12AffineFastState.Bounded env57529 := by
  intro p hp
  have h : env57529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57525_57529 : H12AffineEnvironment.transform 4 17 env57525 = env57529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57525 == env57529) = true)

theorem identity57529 : scanCanonicalize (H12AffineFastState.compose env57529 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound57529 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57530 : List Nat := [2,4,8,16,17,16,8,256,10,21,277,270,285,271,261,2,27,277,21,261,27,17,260,2,284,261,0,271,27,1,273,17,257,16,26,10]

theorem envBound57530 : H12AffineFastState.Bounded env57530 := by
  intro p hp
  have h : env57530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57529_57530 : H12AffineEnvironment.transform 8 10 env57529 = env57530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env57529 == env57530) = true)

theorem identity57530 : scanCanonicalize (H12AffineFastState.compose env57530 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound57530 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57531 : List Nat := [2,4,8,16,17,16,8,14,10,21,27,0,19,1,11,2,27,27,21,11,27,17,10,2,18,11,0,1,27,1,31,17,15,16,26,10]

theorem envBound57531 : H12AffineFastState.Bounded env57531 := by
  intro p hp
  have h : env57531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57530_57531 : H12AffineEnvironment.transform 7 14 env57530 = env57531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env57530 == env57531) = true)

def env57532 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5293,32768,33167,45324,38323,1024,32768,37893,41089,33813,9602,9252,32952,5523,5293,45325,44329,8204,40969,257,8460,45325,1709]

theorem envBound57532 : H12AffineFastState.Bounded env57532 := by
  intro p hp
  have h : env57532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57518_57532 : H12AffineEnvironment.transform 5 17 env57518 = env57532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57518 == env57532) = true)

def env57533 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,8192,5277,32768,33167,45324,38275,1024,32768,37893,41089,33813,9602,9236,32904,5523,5277,45325,44313,8204,40969,257,8460,45325,1693]

theorem envBound57533 : H12AffineFastState.Bounded env57533 := by
  intro p hp
  have h : env57533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57532_57533 : H12AffineEnvironment.transform 4 16 env57532 = env57533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57532 == env57533) = true)

def env57534 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,8192,5277,1296,1183,13340,4243,1024,1296,4373,9617,261,9602,9236,1432,5523,5277,13341,10249,8204,9497,257,8460,13341,1693]

theorem envBound57534 : H12AffineFastState.Bounded env57534 := by
  intro p hp
  have h : env57534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57533_57534 : H12AffineEnvironment.transform 14 1296 env57533 = env57534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env57533 == env57534) = true)

theorem identity57534 : scanCanonicalize (H12AffineFastState.compose env57534 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound57534 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57535 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,2075,8192,3206,1296,1183,11271,2184,1024,1296,2318,9617,261,9602,9236,1432,3464,3206,11270,10249,8204,9497,257,8460,11270,1693]

theorem envBound57535 : H12AffineFastState.Bounded env57535 := by
  intro p hp
  have h : env57535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57534_57535 : H12AffineEnvironment.transform 11 2075 env57534 = env57535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env57534 == env57535) = true)

theorem identity57535 : scanCanonicalize (H12AffineFastState.compose env57535 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound57535 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env57536 : List Nat := [2,4,8,16,16,17,128,256,512,20,2048,2075,8192,2194,260,139,10259,2184,20,260,2318,8581,261,8598,8192,396,2460,2194,10258,10249,8204,8461,257,8460,10258,649]

theorem envBound57536 : H12AffineFastState.Bounded env57536 := by
  intro p hp
  have h : env57536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57535_57536 : H12AffineEnvironment.transform 9 20 env57535 = env57536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env57535 == env57536) = true)

theorem identity57536 : scanCanonicalize (H12AffineFastState.compose env57536 (packedSelected [0,1,4,5,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2838) := by decide +kernel

theorem selectedBound57536 : packedSelected [0,1,4,5,11,12,13] rootPS < 2^1333 := by decide +kernel

def env57537 : List Nat := [2,4,8,16,16,17,128,256,512,20,2048,2075,2838,2194,260,139,773,2184,20,260,2318,2707,261,2688,2838,396,2460,2194,772,799,2842,2587,257,2586,772,649]

theorem envBound57537 : H12AffineFastState.Bounded env57537 := by
  intro p hp
  have h : env57537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57536_57537 : H12AffineEnvironment.transform 12 2838 env57536 = env57537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2838 env57536 == env57537) = true)

theorem identity57537 : scanCanonicalize (H12AffineFastState.compose env57537 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57537 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57538 : List Nat := [2,4,8,16,16,17,128,20,512,20,2048,2075,2562,2194,16,139,529,2184,20,16,2074,2707,17,2688,2562,152,2184,2194,528,523,2574,2587,21,2586,528,649]

theorem envBound57538 : H12AffineFastState.Bounded env57538 := by
  intro p hp
  have h : env57538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57537_57538 : H12AffineEnvironment.transform 7 20 env57537 = env57538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57537 == env57538) = true)

theorem identity57538 : scanCanonicalize (H12AffineFastState.compose env57538 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound57538 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57539 : List Nat := [2,4,8,16,16,17,9,20,512,20,2048,2075,2562,2075,16,2,529,2049,20,16,2074,2586,17,2569,2562,17,2049,2075,528,523,2574,2587,21,2586,528,512]

theorem envBound57539 : H12AffineFastState.Bounded env57539 := by
  intro p hp
  have h : env57539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57538_57539 : H12AffineEnvironment.transform 6 9 env57538 = env57539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env57538 == env57539) = true)

theorem identity57539 : scanCanonicalize (H12AffineFastState.compose env57539 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound57539 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57540 : List Nat := [2,4,8,16,16,17,9,20,17,20,2048,2075,2067,2075,16,2,0,2049,20,16,2074,2059,17,2072,2067,17,2049,2075,1,26,2079,2058,21,2059,1,17]

theorem envBound57540 : H12AffineFastState.Bounded env57540 := by
  intro p hp
  have h : env57540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57539_57540 : H12AffineEnvironment.transform 8 17 env57539 = env57540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env57539 == env57540) = true)

theorem identity57540 : scanCanonicalize (H12AffineFastState.compose env57540 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound57540 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57541 : List Nat := [2,4,8,16,16,17,9,20,17,20,1,26,18,26,16,2,0,0,20,16,27,10,17,25,18,17,0,26,1,26,30,11,21,10,1,17]

theorem envBound57541 : H12AffineFastState.Bounded env57541 := by
  intro p hp
  have h : env57541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57540_57541 : H12AffineEnvironment.transform 10 1 env57540 = env57541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env57540 == env57541) = true)

theorem identity57541 : scanCanonicalize (H12AffineFastState.compose env57541 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57541 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57542 : List Nat := [2,4,8,11,11,10,9,15,10,15,1,1,9,1,11,2,0,0,15,11,0,10,10,2,9,10,0,1,1,1,5,11,14,10,1,10]

theorem envBound57542 : H12AffineFastState.Bounded env57542 := by
  intro p hp
  have h : env57542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57541_57542 : H12AffineEnvironment.transform 3 11 env57541 = env57542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57541 == env57542) = true)

theorem identity57542 : scanCanonicalize (H12AffineFastState.compose env57542 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57543 : List Nat := [2,4,2,1,1,0,3,5,0,5,1,1,3,1,1,2,0,0,5,1,0,0,0,2,3,0,0,1,1,1,5,1,4,0,1,0]

theorem envBound57543 : H12AffineFastState.Bounded env57543 := by
  intro p hp
  have h : env57543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57542_57543 : H12AffineEnvironment.transform 2 2 env57542 = env57543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57542 == env57543) = true)

def env57544 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,4096,8192,5277,1297,1182,13341,4242,1024,1297,4372,9616,260,9602,9236,1433,5523,5277,13340,10248,8204,9496,257,8460,13340,1693]

theorem envBound57544 : H12AffineFastState.Bounded env57544 := by
  intro p hp
  have h : env57544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57533_57544 : H12AffineEnvironment.transform 14 1297 env57533 = env57544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env57533 == env57544) = true)

theorem identity57544 : scanCanonicalize (H12AffineFastState.compose env57544 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound57544 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57545 : List Nat := [2,4,8,16,16,17,128,256,512,1024,2048,2194,8192,3087,1297,1182,11407,2048,1024,1297,2438,9616,260,9602,9236,1433,3329,3087,11406,10248,8204,9496,257,8460,11406,1693]

theorem envBound57545 : H12AffineFastState.Bounded env57545 := by
  intro p hp
  have h : env57545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57544_57545 : H12AffineEnvironment.transform 11 2194 env57544 = env57545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env57544 == env57545) = true)

theorem identity57545 : scanCanonicalize (H12AffineFastState.compose env57545 (packedSelected [3,4,5,7,10,11,13,16] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound57545 : packedSelected [3,4,5,7,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env57546 : List Nat := [2,4,8,16,16,17,128,256,512,21,2048,2194,8192,2074,260,139,10394,2048,21,260,2438,8581,260,8599,8193,396,2324,2074,10395,10248,8204,8461,257,8460,10395,648]

theorem envBound57546 : H12AffineFastState.Bounded env57546 := by
  intro p hp
  have h : env57546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57545_57546 : H12AffineEnvironment.transform 9 21 env57545 = env57546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env57545 == env57546) = true)

theorem identity57546 : scanCanonicalize (H12AffineFastState.compose env57546 (packedSelected [3,7,8,9,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2974) := by decide +kernel

theorem selectedBound57546 : packedSelected [3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env57547 : List Nat := [2,4,8,16,16,17,128,256,512,21,2048,2194,2974,2074,260,139,772,2048,21,260,2438,2587,260,2569,2975,396,2324,2074,773,918,2962,2707,257,2706,773,648]

theorem envBound57547 : H12AffineFastState.Bounded env57547 := by
  intro p hp
  have h : env57547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57546_57547 : H12AffineEnvironment.transform 12 2974 env57546 = env57547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2974 env57546 == env57547) = true)

theorem identity57547 : scanCanonicalize (H12AffineFastState.compose env57547 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57547 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57548 : List Nat := [2,4,8,16,16,17,128,20,512,21,2048,2194,2698,2074,16,139,528,2048,21,16,2194,2587,16,2569,2699,152,2048,2074,529,642,2694,2707,21,2706,529,648]

theorem envBound57548 : H12AffineFastState.Bounded env57548 := by
  intro p hp
  have h : env57548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57547_57548 : H12AffineEnvironment.transform 7 20 env57547 = env57548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57547 == env57548) = true)

theorem identity57548 : scanCanonicalize (H12AffineFastState.compose env57548 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 658) := by decide +kernel

theorem selectedBound57548 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env57549 : List Nat := [2,4,8,16,16,17,128,20,512,21,658,512,24,648,16,139,528,658,21,16,512,137,16,155,25,152,658,648,529,642,20,1,21,0,529,648]

theorem envBound57549 : H12AffineFastState.Bounded env57549 := by
  intro p hp
  have h : env57549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57548_57549 : H12AffineEnvironment.transform 10 658 env57548 = env57549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 658 env57548 == env57549) = true)

theorem identity57549 : scanCanonicalize (H12AffineFastState.compose env57549 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound57549 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57550 : List Nat := [2,4,8,16,16,17,19,20,512,21,513,512,24,539,16,24,528,513,21,16,512,26,16,8,25,11,513,539,529,529,20,1,21,0,529,539]

theorem envBound57550 : H12AffineFastState.Bounded env57550 := by
  intro p hp
  have h : env57550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57549_57550 : H12AffineEnvironment.transform 6 19 env57549 = env57550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env57549 == env57550) = true)

theorem identity57550 : scanCanonicalize (H12AffineFastState.compose env57550 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57550 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57551 : List Nat := [2,4,2,16,16,17,19,20,512,21,513,512,18,529,16,18,528,513,21,16,512,16,16,2,19,1,513,529,529,529,20,1,21,0,529,529]

theorem envBound57551 : H12AffineFastState.Bounded env57551 := by
  intro p hp
  have h : env57551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57550_57551 : H12AffineEnvironment.transform 2 2 env57550 = env57551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57550 == env57551) = true)

theorem identity57551 : scanCanonicalize (H12AffineFastState.compose env57551 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57551 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57552 : List Nat := [2,4,2,1,1,0,2,5,512,4,513,512,3,512,1,3,513,513,4,1,512,1,1,2,2,1,513,512,512,512,5,1,4,0,512,512]

theorem envBound57552 : H12AffineFastState.Bounded env57552 := by
  intro p hp
  have h : env57552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57551_57552 : H12AffineEnvironment.transform 3 1 env57551 = env57552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57551 == env57552) = true)

def env57553 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,8192,5276,32768,33167,45324,38274,1024,32768,37893,41089,33813,9602,9237,32905,5523,5276,45325,44312,8204,40969,257,8460,45325,1692]

theorem envBound57553 : H12AffineFastState.Bounded env57553 := by
  intro p hp
  have h : env57553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57532_57553 : H12AffineEnvironment.transform 4 17 env57532 = env57553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57532 == env57553) = true)

def env57554 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,8192,5276,1296,1183,13340,4242,1024,1296,4373,9617,261,9602,9237,1433,5523,5276,13341,10248,8204,9497,257,8460,13341,1692]

theorem envBound57554 : H12AffineFastState.Bounded env57554 := by
  intro p hp
  have h : env57554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57553_57554 : H12AffineEnvironment.transform 14 1296 env57553 = env57554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env57553 == env57554) = true)

theorem identity57554 : scanCanonicalize (H12AffineFastState.compose env57554 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 6406) := by decide +kernel

theorem selectedBound57554 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57555 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,6406,5276,1296,1183,3354,4242,1024,1296,4373,7319,261,7300,7443,1433,5523,5276,3355,4366,6410,7199,257,6154,3355,1692]

theorem envBound57555 : H12AffineFastState.Bounded env57555 := by
  intro p hp
  have h : env57555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57554_57555 : H12AffineEnvironment.transform 12 6406 env57554 = env57555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6406 env57554 == env57555) = true)

theorem identity57555 : scanCanonicalize (H12AffineFastState.compose env57555 (packedSelected [0,2,5,8,9,11,12,13,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound57555 : packedSelected [0,2,5,8,9,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env57556 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,1944,3742,772,1296,1183,3354,1802,1024,1296,1677,2831,261,2844,2699,1433,523,772,3355,1686,3730,2951,257,3986,3355,1692]

theorem envBound57556 : H12AffineFastState.Bounded env57556 := by
  intro p hp
  have h : env57556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57555_57556 : H12AffineEnvironment.transform 11 1944 env57555 = env57556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env57555 == env57556) = true)

theorem identity57556 : scanCanonicalize (H12AffineFastState.compose env57556 (packedSelected [8,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound57556 : packedSelected [8,10,13] rootPS < 2^1333 := by decide +kernel

def env57557 : List Nat := [2,4,8,16,17,17,128,256,512,31,2048,903,2689,772,271,128,2309,789,31,271,658,2831,261,2844,2699,390,523,772,2308,649,2701,2951,257,2957,2308,643]

theorem envBound57557 : H12AffineFastState.Bounded env57557 := by
  intro p hp
  have h : env57557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57556_57557 : H12AffineEnvironment.transform 9 31 env57556 = env57557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env57556 == env57557) = true)

theorem identity57557 : scanCanonicalize (H12AffineFastState.compose env57557 (packedSelected [0,1,2,4,5,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 665) := by decide +kernel

theorem selectedBound57557 : packedSelected [0,1,2,4,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env57558 : List Nat := [2,4,8,16,17,17,128,256,512,31,665,903,24,772,271,128,924,789,31,271,658,406,261,389,18,390,523,772,925,649,20,286,257,276,925,643]

theorem envBound57558 : H12AffineFastState.Bounded env57558 := by
  intro p hp
  have h : env57558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57557_57558 : H12AffineEnvironment.transform 10 665 env57557 = env57558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 665 env57557 == env57558) = true)

theorem identity57558 : scanCanonicalize (H12AffineFastState.compose env57558 (packedSelected [1,2,3,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound57558 : packedSelected [1,2,3,7,9,10] rootPS < 2^1333 := by decide +kernel

def env57559 : List Nat := [2,4,8,16,17,17,128,31,512,31,665,664,24,539,16,128,643,522,31,16,658,137,26,154,18,153,523,539,642,649,20,1,30,11,642,643]

theorem envBound57559 : H12AffineFastState.Bounded env57559 := by
  intro p hp
  have h : env57559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57558_57559 : H12AffineEnvironment.transform 7 31 env57558 = env57559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env57558 == env57559) = true)

theorem identity57559 : scanCanonicalize (H12AffineFastState.compose env57559 (packedSelected [5,8] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound57559 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57560 : List Nat := [2,4,8,16,17,17,3,31,512,31,538,539,24,539,16,3,512,522,31,16,529,10,26,25,18,26,523,539,513,522,20,1,30,11,513,512]

theorem envBound57560 : H12AffineFastState.Bounded env57560 := by
  intro p hp
  have h : env57560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57559_57560 : H12AffineEnvironment.transform 6 3 env57559 = env57560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env57559 == env57560) = true)

theorem identity57560 : scanCanonicalize (H12AffineFastState.compose env57560 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57560 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env57561 : List Nat := [2,4,8,11,10,10,3,4,512,4,513,512,3,512,11,3,512,522,4,11,522,10,1,2,9,1,523,512,513,522,15,1,5,11,513,512]

theorem envBound57561 : H12AffineFastState.Bounded env57561 := by
  intro p hp
  have h : env57561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57560_57561 : H12AffineEnvironment.transform 3 11 env57560 = env57561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57560 == env57561) = true)

theorem identity57561 : scanCanonicalize (H12AffineFastState.compose env57561 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57561 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57562 : List Nat := [2,4,2,1,0,0,3,4,512,4,513,512,3,512,1,3,512,512,4,1,512,0,1,2,3,1,513,512,513,512,5,1,5,1,513,512]

theorem envBound57562 : H12AffineFastState.Bounded env57562 := by
  intro p hp
  have h : env57562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57561_57562 : H12AffineEnvironment.transform 2 2 env57561 = env57562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57561 == env57562) = true)

theorem identity57562 : scanCanonicalize (H12AffineFastState.compose env57562 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound57562 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57563 : List Nat := [2,4,2,1,0,0,3,4,1,4,0,1,3,1,1,3,1,1,4,1,1,0,1,2,3,1,0,1,0,1,5,1,5,1,0,1]

theorem envBound57563 : H12AffineFastState.Bounded env57563 := by
  intro p hp
  have h : env57563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57562_57563 : H12AffineEnvironment.transform 8 1 env57562 = env57563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env57562 == env57563) = true)

def env57564 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,8192,5276,1297,1182,13341,4243,1024,1297,4372,9616,260,9602,9237,1432,5523,5276,13340,10249,8204,9496,257,8460,13340,1692]

theorem envBound57564 : H12AffineFastState.Bounded env57564 := by
  intro p hp
  have h : env57564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57553_57564 : H12AffineEnvironment.transform 14 1297 env57553 = env57564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env57553 == env57564) = true)

theorem identity57564 : scanCanonicalize (H12AffineFastState.compose env57564 (packedSelected [0,5,7,8,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 6543) := by decide +kernel

theorem selectedBound57564 : packedSelected [0,5,7,8,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57565 : List Nat := [2,4,8,16,17,17,128,256,512,1024,2048,4096,6543,5276,1297,1182,3474,4243,1024,1297,4372,7199,260,7181,7578,1432,5523,5276,3475,4486,6531,7319,257,6275,3475,1692]

theorem envBound57565 : H12AffineFastState.Bounded env57565 := by
  intro p hp
  have h : env57565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57564_57565 : H12AffineEnvironment.transform 12 6543 env57564 = env57565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6543 env57564 == env57565) = true)

theorem identity57565 : scanCanonicalize (H12AffineFastState.compose env57565 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound57565 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env57566 : List Nat := [2,4,8,16,17,17,128,256,512,21,2048,4096,6543,4233,260,139,2439,4243,21,260,4372,6154,260,6168,6543,397,4486,4233,2438,4486,6531,6274,257,6275,2438,649]

theorem envBound57566 : H12AffineFastState.Bounded env57566 := by
  intro p hp
  have h : env57566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57565_57566 : H12AffineEnvironment.transform 9 21 env57565 = env57566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env57565 == env57566) = true)

theorem identity57566 : scanCanonicalize (H12AffineFastState.compose env57566 (packedSelected [2,3,5,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 918) := by decide +kernel

theorem selectedBound57566 : packedSelected [2,3,5,10,13] rootPS < 2^1333 := by decide +kernel

def env57567 : List Nat := [2,4,8,16,17,17,128,256,512,21,918,4096,4633,4233,260,139,529,4243,21,260,4372,5020,260,5006,4633,397,4486,4233,528,4486,4629,4884,257,4885,528,649]

theorem envBound57567 : H12AffineFastState.Bounded env57567 := by
  intro p hp
  have h : env57567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57566_57567 : H12AffineEnvironment.transform 10 918 env57566 = env57567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 918 env57566 == env57567) = true)

theorem identity57567 : scanCanonicalize (H12AffineFastState.compose env57567 (packedSelected [2,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound57567 : packedSelected [2,11,12] rootPS < 2^1333 := by decide +kernel

def env57568 : List Nat := [2,4,8,16,17,17,128,256,512,21,918,528,9,665,260,139,529,643,21,260,772,396,260,414,9,397,918,665,528,918,5,260,257,261,528,649]

theorem envBound57568 : H12AffineFastState.Bounded env57568 := by
  intro p hp
  have h : env57568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57567_57568 : H12AffineEnvironment.transform 11 528 env57567 = env57568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env57567 == env57568) = true)

theorem identity57568 : scanCanonicalize (H12AffineFastState.compose env57568 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound57568 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57569 : List Nat := [2,4,8,16,17,17,128,157,512,21,523,528,9,665,153,139,529,643,21,153,665,17,153,3,9,16,523,665,528,523,5,153,156,152,528,649]

theorem envBound57569 : H12AffineFastState.Bounded env57569 := by
  intro p hp
  have h : env57569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57568_57569 : H12AffineEnvironment.transform 7 157 env57568 = env57569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env57568 == env57569) = true)

theorem identity57569 : scanCanonicalize (H12AffineFastState.compose env57569 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound57569 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57570 : List Nat := [2,4,8,16,17,17,9,20,512,21,523,528,9,528,16,2,529,522,21,16,528,17,16,3,9,16,523,528,528,523,5,16,21,17,528,512]

theorem envBound57570 : H12AffineFastState.Bounded env57570 := by
  intro p hp
  have h : env57570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57569_57570 : H12AffineEnvironment.transform 6 9 env57569 = env57570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env57569 == env57570) = true)

theorem identity57570 : scanCanonicalize (H12AffineFastState.compose env57570 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound57570 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57571 : List Nat := [2,4,8,16,17,17,9,20,17,21,26,1,9,1,16,2,0,27,21,16,1,17,16,3,9,16,26,1,1,26,5,16,21,17,1,17]

theorem envBound57571 : H12AffineFastState.Bounded env57571 := by
  intro p hp
  have h : env57571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57570_57571 : H12AffineEnvironment.transform 8 17 env57570 = env57571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env57570 == env57571) = true)

theorem identity57571 : scanCanonicalize (H12AffineFastState.compose env57571 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57571 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57572 : List Nat := [2,4,8,10,11,11,9,14,11,15,0,1,9,1,10,2,0,1,15,10,1,11,10,3,9,10,0,1,1,0,5,10,15,11,1,11]

theorem envBound57572 : H12AffineFastState.Bounded env57572 := by
  intro p hp
  have h : env57572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57571_57572 : H12AffineEnvironment.transform 3 10 env57571 = env57572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57571 == env57572) = true)

def env57573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336704,6295814,4247641,6348992,4273308,16384,77954,4315355,6395143,4292871,257,6406395,78035,4256464]

theorem envBound57573 : H12AffineFastState.Bounded env57573 := by
  intro p hp
  have h : env57573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57507_57573 : H12AffineEnvironment.transform 17 82113 env57507 = env57573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env57507 == env57573) = true)

def env57574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101312,2142598,28889,2113600,103452,16384,77954,96347,2176391,74119,257,2187387,78035,21072]

theorem envBound57574 : H12AffineFastState.Bounded env57574 := by
  intro p hp
  have h : env57574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57573_57574 : H12AffineEnvironment.transform 21 41088 env57573 = env57574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57573 == env57574) = true)

theorem identity57574 : scanCanonicalize (H12AffineFastState.compose env57574 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 445) := by decide +kernel

theorem selectedBound57574 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,32768,65536,78034,65916,1024,32768,2097152,41088,2101312,2142598,12644,2097661,103452,445,77954,80358,2176391,74119,257,2171334,78035,5101]

theorem envBound57575 : H12AffineFastState.Bounded env57575 := by
  intro p hp
  have h : env57575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57574_57575 : H12AffineEnvironment.transform 13 445 env57574 = env57575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 445 env57574 == env57575) = true)

theorem identity57575 : scanCanonicalize (H12AffineFastState.compose env57575 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound57575 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,445,32768,65536,71130,65916,1024,32768,2097152,34184,2101312,2135182,5228,2097661,103452,445,71050,72942,2166927,66703,257,2163918,71131,5101]

theorem envBound57576 : H12AffineFastState.Bounded env57576 := by
  intro p hp
  have h : env57576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57575_57576 : H12AffineEnvironment.transform 12 1288 env57575 = env57576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env57575 == env57576) = true)

theorem identity57576 : scanCanonicalize (H12AffineFastState.compose env57576 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 66662) := by decide +kernel

theorem selectedBound57576 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,445,32768,65536,71130,65916,1024,32768,66662,34184,70694,102632,5228,66971,103452,445,71050,72942,5353,66703,257,168,71131,5101]

theorem envBound57577 : H12AffineFastState.Bounded env57577 := by
  intro p hp
  have h : env57577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57576_57577 : H12AffineEnvironment.transform 20 66662 env57576 = env57577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66662 env57576 == env57577) = true)

theorem identity57577 : scanCanonicalize (H12AffineFastState.compose env57577 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57577 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1288,445,32768,65536,66615,65916,1024,32768,66662,34184,67019,98565,1409,66971,99825,445,66663,68867,1284,66703,257,168,66614,512]

theorem envBound57578 : H12AffineFastState.Bounded env57578 := by
  intro p hp
  have h : env57578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57577_57578 : H12AffineEnvironment.transform 11 493 env57577 = env57578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57577 == env57578) = true)

theorem identity57578 : scanCanonicalize (H12AffineFastState.compose env57578 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1874) := by decide +kernel

theorem selectedBound57578 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1288,445,32768,1874,869,1582,1024,32768,820,34184,665,34391,1409,713,33443,445,821,2641,1284,989,257,168,868,512]

theorem envBound57579 : H12AffineFastState.Bounded env57579 := by
  intro p hp
  have h : env57579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57578_57579 : H12AffineEnvironment.transform 15 1874 env57578 = env57579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1874 env57578 == env57579) = true)

def env57580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101313,2142599,28888,2113601,103453,16384,77954,96346,2176390,74118,257,2187386,78035,21073]

theorem envBound57580 : H12AffineFastState.Bounded env57580 := by
  intro p hp
  have h : env57580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57573_57580 : H12AffineEnvironment.transform 21 41089 env57573 = env57580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57573 == env57580) = true)

theorem identity57580 : scanCanonicalize (H12AffineFastState.compose env57580 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 253) := by decide +kernel

theorem selectedBound57580 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57581 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,16384,32768,65536,78034,82113,253,32768,2097152,41089,2101313,2142599,28888,2113601,102624,16384,77954,96346,2175355,74118,257,2187386,78035,21073]

theorem envBound57581 : H12AffineFastState.Bounded env57581 := by
  intro p hp
  have h : env57581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57580_57581 : H12AffineEnvironment.transform 9 253 env57580 = env57581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 253 env57580 == env57581) = true)

theorem identity57581 : scanCanonicalize (H12AffineFastState.compose env57581 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 70007) := by decide +kernel

theorem selectedBound57581 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57582 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,16384,32768,65536,78034,82113,253,32768,70007,41089,65846,106736,28888,86326,102624,16384,77954,96346,8204,74118,257,28941,78035,21073]

theorem envBound57582 : H12AffineFastState.Bounded env57582 := by
  intro p hp
  have h : env57582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57581_57582 : H12AffineEnvironment.transform 20 70007 env57581 = env57582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 70007 env57581 == env57582) = true)

theorem identity57582 : scanCanonicalize (H12AffineFastState.compose env57582 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound57582 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57583 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,16384,32768,33167,45405,49486,253,32768,37112,41089,32953,8575,28888,53433,4463,16384,45325,63957,8204,40969,257,28941,45404,21073]

theorem envBound57583 : H12AffineFastState.Bounded env57583 := by
  intro p hp
  have h : env57583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57582_57583 : H12AffineEnvironment.transform 15 33167 env57582 = env57583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env57582 == env57583) = true)

def env57584 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,4096,32768,33167,45405,37198,253,32768,37112,41089,32953,8575,8408,32953,4463,4096,45325,43477,8204,40969,257,8461,45404,593]

theorem envBound57584 : H12AffineFastState.Bounded env57584 := by
  intro p hp
  have h : env57584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57583_57584 : H12AffineEnvironment.transform 13 4096 env57583 = env57584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env57583 == env57584) = true)

def env57585 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,8192,4096,32768,33167,45325,37150,173,32768,37032,41089,32953,8495,8328,32953,4415,4096,45325,43397,8204,40969,257,8461,45324,513]

theorem envBound57585 : H12AffineFastState.Bounded env57585 := by
  intro p hp
  have h : env57585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57584_57585 : H12AffineEnvironment.transform 5 16 env57584 = env57585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57584 == env57585) = true)

theorem identity57585 : scanCanonicalize (H12AffineFastState.compose env57585 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound57585 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57586 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,8192,4096,32,431,12589,4414,173,32,4232,8353,153,8495,8328,153,4415,4096,12589,10661,8204,8233,257,8461,12588,513]

theorem envBound57586 : H12AffineFastState.Bounded env57586 := by
  intro p hp
  have h : env57586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57585_57586 : H12AffineEnvironment.transform 14 32 env57585 = env57586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env57585 == env57586) = true)

theorem identity57586 : scanCanonicalize (H12AffineFastState.compose env57586 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound57586 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57587 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,300,4096,32,431,4097,4414,173,32,4232,397,153,3,420,153,4415,4096,4097,2185,288,261,257,33,4096,513]

theorem envBound57587 : H12AffineFastState.Bounded env57587 := by
  intro p hp
  have h : env57587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57586_57587 : H12AffineEnvironment.transform 12 300 env57586 = env57587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env57586 == env57587) = true)

theorem identity57587 : scanCanonicalize (H12AffineFastState.compose env57587 (packedSelected [0,1,2,4,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 900) := by decide +kernel

theorem selectedBound57587 : packedSelected [0,1,2,4,9,10,13] rootPS < 2^1333 := by decide +kernel

def env57588 : List Nat := [2,4,8,16,32,16,128,256,512,173,900,4096,300,4096,32,431,4097,4414,173,32,4232,397,153,3,420,153,4415,4096,4097,781,288,261,257,33,4096,513]

theorem envBound57588 : H12AffineFastState.Bounded env57588 := by
  intro p hp
  have h : env57588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57587_57588 : H12AffineEnvironment.transform 10 900 env57587 = env57588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 900 env57587 == env57588) = true)

theorem identity57588 : scanCanonicalize (H12AffineFastState.compose env57588 (packedSelected [0,1,2,4,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 790) := by decide +kernel

theorem selectedBound57588 : packedSelected [0,1,2,4,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env57589 : List Nat := [2,4,8,16,32,16,128,256,512,173,900,790,300,790,32,431,791,552,173,32,926,397,153,3,420,153,553,790,791,781,288,261,257,33,790,513]

theorem envBound57589 : H12AffineFastState.Bounded env57589 := by
  intro p hp
  have h : env57589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57588_57589 : H12AffineEnvironment.transform 11 790 env57588 = env57589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 790 env57588 == env57589) = true)

theorem identity57589 : scanCanonicalize (H12AffineFastState.compose env57589 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 6) := by decide +kernel

theorem selectedBound57589 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env57590 : List Nat := [2,4,8,16,32,16,128,6,512,173,642,528,42,528,32,169,529,552,173,32,664,139,153,3,162,153,553,528,529,523,38,3,7,33,528,513]

theorem envBound57590 : H12AffineFastState.Bounded env57590 := by
  intro p hp
  have h : env57590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57589_57590 : H12AffineEnvironment.transform 7 6 env57589 = env57590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 6 env57589 == env57590) = true)

theorem identity57590 : scanCanonicalize (H12AffineFastState.compose env57590 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 155) := by decide +kernel

theorem selectedBound57590 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env57591 : List Nat := [2,4,8,16,32,16,128,6,155,173,25,139,42,139,32,169,138,179,173,32,3,139,153,3,162,153,178,139,138,144,38,3,7,33,139,154]

theorem envBound57591 : H12AffineFastState.Bounded env57591 := by
  intro p hp
  have h : env57591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57590_57591 : H12AffineEnvironment.transform 8 155 env57590 = env57591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 155 env57590 == env57591) = true)

theorem identity57591 : scanCanonicalize (H12AffineFastState.compose env57591 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 42) := by decide +kernel

theorem selectedBound57591 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env57592 : List Nat := [2,4,8,16,32,16,42,6,49,7,25,33,42,33,32,3,32,25,7,32,3,33,51,3,8,51,24,33,32,58,38,3,7,33,33,48]

theorem envBound57592 : H12AffineFastState.Bounded env57592 := by
  intro p hp
  have h : env57592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57591_57592 : H12AffineEnvironment.transform 6 42 env57591 = env57592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 42 env57591 == env57592) = true)

theorem identity57592 : scanCanonicalize (H12AffineFastState.compose env57592 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound57592 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57593 : List Nat := [2,4,8,3,32,3,42,6,34,7,10,33,42,33,32,3,32,10,7,32,3,33,32,3,8,32,11,33,32,41,38,3,7,33,33,35]

theorem envBound57593 : H12AffineFastState.Bounded env57593 := by
  intro p hp
  have h : env57593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57592_57593 : H12AffineEnvironment.transform 3 3 env57592 = env57593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env57592 == env57593) = true)

theorem identity57593 : scanCanonicalize (H12AffineFastState.compose env57593 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57593 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57594 : List Nat := [2,4,2,3,32,3,32,6,34,7,0,33,32,33,32,3,32,0,7,32,3,33,32,3,2,32,1,33,32,35,38,3,7,33,33,35]

theorem envBound57594 : H12AffineFastState.Bounded env57594 := by
  intro p hp
  have h : env57594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57593_57594 : H12AffineEnvironment.transform 2 2 env57593 = env57594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57593 == env57594) = true)

theorem identity57594 : scanCanonicalize (H12AffineFastState.compose env57594 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound57594 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57595 : List Nat := [2,4,2,3,3,3,3,6,1,7,0,2,3,2,3,3,3,0,7,3,3,2,3,3,2,3,1,2,3,0,5,3,7,2,2,0]

theorem envBound57595 : H12AffineFastState.Bounded env57595 := by
  intro p hp
  have h : env57595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57594_57595 : H12AffineEnvironment.transform 4 3 env57594 = env57595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env57594 == env57595) = true)

theorem identity57595 : scanCanonicalize (H12AffineFastState.compose env57595 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57595 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57596 : List Nat := [0,4,0,1,1,1,1,4,1,5,0,0,1,0,1,1,1,0,5,1,1,0,1,1,0,1,1,0,1,0,5,1,5,0,0,0]

theorem envBound57596 : H12AffineFastState.Bounded env57596 := by
  intro p hp
  have h : env57596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57595_57596 : H12AffineEnvironment.transform 0 0 env57595 = env57596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57595 == env57596) = true)

def env57597 : List Nat := [2,4,8,16,32,17,128,256,512,172,2048,4096,8192,4096,32768,33167,45324,37151,172,32768,37033,41089,32953,8494,8329,32953,4414,4096,45325,43396,8204,40969,257,8461,45325,512]

theorem envBound57597 : H12AffineFastState.Bounded env57597 := by
  intro p hp
  have h : env57597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57584_57597 : H12AffineEnvironment.transform 5 17 env57584 = env57597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57584 == env57597) = true)

theorem identity57597 : scanCanonicalize (H12AffineFastState.compose env57597 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound57597 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57598 : List Nat := [2,4,8,16,32,17,128,256,512,172,2048,4096,2562,4096,32768,33167,39694,37151,172,32768,37033,35459,32953,2860,2699,32953,4414,4096,39695,33670,2574,35339,257,2831,39695,512]

theorem envBound57598 : H12AffineFastState.Bounded env57598 := by
  intro p hp
  have h : env57598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57597_57598 : H12AffineEnvironment.transform 12 2562 env57597 = env57598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env57597 == env57598) = true)

theorem identity57598 : scanCanonicalize (H12AffineFastState.compose env57598 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 2723) := by decide +kernel

theorem selectedBound57598 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57599 : List Nat := [2,4,8,16,32,17,128,256,512,172,2048,4096,2562,4096,2723,2860,4525,7100,172,2723,6666,32,2586,2860,2699,2586,4414,4096,4524,2341,2574,168,257,2831,4524,512]

theorem envBound57599 : H12AffineFastState.Bounded env57599 := by
  intro p hp
  have h : env57599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57598_57599 : H12AffineEnvironment.transform 14 2723 env57598 = env57599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2723 env57598 == env57599) = true)

theorem identity57599 : scanCanonicalize (H12AffineFastState.compose env57599 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound57599 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env57600 : List Nat := [2,4,8,16,32,17,128,256,512,172,2048,544,2562,544,2723,2860,909,2460,172,2723,2090,32,2586,2860,2699,2586,798,544,908,2341,2574,168,257,2831,908,512]

theorem envBound57600 : H12AffineFastState.Bounded env57600 := by
  intro p hp
  have h : env57600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57599_57600 : H12AffineEnvironment.transform 11 544 env57599 = env57600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env57599 == env57600) = true)

theorem identity57600 : scanCanonicalize (H12AffineFastState.compose env57600 (packedSelected [1,3,4,9,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 934) := by decide +kernel

theorem selectedBound57600 : packedSelected [1,3,4,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env57601 : List Nat := [2,4,8,16,32,17,128,256,512,172,934,544,420,544,261,138,909,570,172,261,908,32,444,138,301,444,798,544,908,643,424,168,257,169,908,512]

theorem envBound57601 : H12AffineFastState.Bounded env57601 := by
  intro p hp
  have h : env57601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57600_57601 : H12AffineEnvironment.transform 10 934 env57600 = env57601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 934 env57600 == env57601) = true)

theorem identity57601 : scanCanonicalize (H12AffineFastState.compose env57601 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57601 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57602 : List Nat := [2,4,8,16,32,17,128,20,512,172,690,544,176,544,17,138,665,570,172,17,664,32,168,138,57,168,522,544,664,643,188,168,21,169,664,512]

theorem envBound57602 : H12AffineFastState.Bounded env57602 := by
  intro p hp
  have h : env57602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57601_57602 : H12AffineEnvironment.transform 7 20 env57601 = env57602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57601 == env57602) = true)

def env57603 : List Nat := [2,4,8,16,32,17,128,20,48,172,130,16,176,16,17,138,169,10,172,17,168,32,168,138,57,168,58,16,168,179,188,168,21,169,168,48]

theorem envBound57603 : H12AffineFastState.Bounded env57603 := by
  intro p hp
  have h : env57603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57602_57603 : H12AffineEnvironment.transform 8 48 env57602 = env57603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env57602 == env57603) = true)

theorem identity57603 : scanCanonicalize (H12AffineFastState.compose env57603 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound57603 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57604 : List Nat := [2,4,8,16,32,17,51,20,48,31,49,16,3,16,17,57,26,10,31,17,27,32,27,57,57,27,58,16,27,0,15,27,21,26,27,48]

theorem envBound57604 : H12AffineFastState.Bounded env57604 := by
  intro p hp
  have h : env57604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57603_57604 : H12AffineEnvironment.transform 6 51 env57603 = env57604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env57603 == env57604) = true)

def env57605 : List Nat := [2,4,8,16,16,17,3,20,0,31,1,16,3,16,17,9,26,10,31,17,27,16,27,9,9,27,10,16,27,0,15,27,21,26,27,0]

theorem envBound57605 : H12AffineFastState.Bounded env57605 := by
  intro p hp
  have h : env57605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57604_57605 : H12AffineEnvironment.transform 4 16 env57604 = env57605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57604 == env57605) = true)

def env57606 : List Nat := [2,4,8,16,17,17,2,20,1,31,0,16,3,16,17,8,26,10,31,17,27,17,27,8,8,27,11,16,27,0,15,27,21,26,27,1]

theorem envBound57606 : H12AffineFastState.Bounded env57606 := by
  intro p hp
  have h : env57606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57604_57606 : H12AffineEnvironment.transform 4 17 env57604 = env57606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57604 == env57606) = true)

theorem identity57606 : scanCanonicalize (H12AffineFastState.compose env57606 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57606 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57607 : List Nat := [2,4,8,10,11,11,2,14,1,5,0,10,3,10,11,8,0,10,5,11,1,11,1,8,8,1,11,10,1,0,15,1,15,0,1,1]

theorem envBound57607 : H12AffineFastState.Bounded env57607 := by
  intro p hp
  have h : env57607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57606_57607 : H12AffineEnvironment.transform 3 10 env57606 = env57607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57606 == env57607) = true)

def env57608 : List Nat := [2,4,8,16,32,17,128,20,49,172,131,17,176,17,17,138,168,11,172,17,169,32,168,138,57,168,59,17,169,178,188,168,21,169,169,49]

theorem envBound57608 : H12AffineFastState.Bounded env57608 := by
  intro p hp
  have h : env57608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57602_57608 : H12AffineEnvironment.transform 8 49 env57602 = env57608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env57602 == env57608) = true)

theorem identity57608 : scanCanonicalize (H12AffineFastState.compose env57608 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound57608 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57609 : List Nat := [2,4,8,16,27,17,128,20,10,151,131,17,139,17,17,138,147,11,151,17,146,27,147,138,2,147,0,17,146,137,135,147,21,146,146,10]

theorem envBound57609 : H12AffineFastState.Bounded env57609 := by
  intro p hp
  have h : env57609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57608_57609 : H12AffineEnvironment.transform 4 27 env57608 = env57609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env57608 == env57609) = true)

def env57610 : List Nat := [2,4,8,0,11,1,128,4,10,135,131,1,139,1,1,138,131,11,135,1,130,11,131,138,2,131,0,1,130,137,135,131,5,130,130,10]

theorem envBound57610 : H12AffineFastState.Bounded env57610 := by
  intro p hp
  have h : env57610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57609_57610 : H12AffineEnvironment.transform 3 0 env57609 = env57610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57609 == env57610) = true)

theorem identity57610 : scanCanonicalize (H12AffineFastState.compose env57610 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57610 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57611 : List Nat := [2,4,2,0,1,1,128,4,0,135,131,1,129,1,1,128,131,1,135,1,130,1,131,128,2,131,0,1,130,131,135,131,5,130,130,0]

theorem envBound57611 : H12AffineFastState.Bounded env57611 := by
  intro p hp
  have h : env57611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57610_57611 : H12AffineEnvironment.transform 2 2 env57610 = env57611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57610 == env57611) = true)

def env57612 : List Nat := [2,4,8,1,10,0,128,5,10,134,131,0,139,0,0,138,130,11,134,0,131,10,130,138,2,130,0,0,131,137,135,130,4,131,131,10]

theorem envBound57612 : H12AffineFastState.Bounded env57612 := by
  intro p hp
  have h : env57612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57609_57612 : H12AffineEnvironment.transform 3 1 env57609 = env57612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57609 == env57612) = true)

def env57613 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,4097,32768,33167,45405,37199,253,32768,37112,41089,32953,8575,8409,32952,4463,4097,45325,43476,8204,40969,257,8460,45404,592]

theorem envBound57613 : H12AffineFastState.Bounded env57613 := by
  intro p hp
  have h : env57613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57583_57613 : H12AffineEnvironment.transform 13 4097 env57583 = env57613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env57583 == env57613) = true)

theorem identity57613 : scanCanonicalize (H12AffineFastState.compose env57613 (packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57613 : packedSelected [1,2,3,5,8,10,11,12,17,18,19,38] rootPS < 2^1333 := by decide +kernel

def env57614 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,8192,4097,32768,33167,45325,37151,173,32768,37032,41089,32953,8495,8329,32952,4415,4097,45325,43396,8204,40969,257,8460,45324,512]

theorem envBound57614 : H12AffineFastState.Bounded env57614 := by
  intro p hp
  have h : env57614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57613_57614 : H12AffineEnvironment.transform 5 16 env57613 = env57614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57613 == env57614) = true)

theorem identity57614 : scanCanonicalize (H12AffineFastState.compose env57614 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound57614 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57615 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,2562,4097,32768,33167,39695,37151,173,32768,37032,35459,32953,2861,2699,32952,4415,4097,39695,33670,2574,35339,257,2830,39694,512]

theorem envBound57615 : H12AffineFastState.Bounded env57615 := by
  intro p hp
  have h : env57615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57614_57615 : H12AffineEnvironment.transform 12 2562 env57614 = env57615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env57614 == env57615) = true)

theorem identity57615 : scanCanonicalize (H12AffineFastState.compose env57615 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 2723) := by decide +kernel

theorem selectedBound57615 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57616 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,4096,2562,4097,2723,2860,4524,7100,173,2723,6667,32,2586,2861,2699,2587,4415,4097,4524,2341,2574,168,257,2830,4525,512]

theorem envBound57616 : H12AffineFastState.Bounded env57616 := by
  intro p hp
  have h : env57616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57615_57616 : H12AffineEnvironment.transform 14 2723 env57615 = env57616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2723 env57615 == env57616) = true)

theorem identity57616 : scanCanonicalize (H12AffineFastState.compose env57616 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound57616 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env57617 : List Nat := [2,4,8,16,32,16,128,256,512,173,2048,2090,2562,2091,2723,2860,2438,918,173,2723,545,32,2586,2861,2699,2587,2325,2091,2438,2341,2574,168,257,2830,2439,512]

theorem envBound57617 : H12AffineFastState.Bounded env57617 := by
  intro p hp
  have h : env57617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57616_57617 : H12AffineEnvironment.transform 11 2090 env57616 = env57617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env57616 == env57617) = true)

theorem identity57617 : scanCanonicalize (H12AffineFastState.compose env57617 (packedSelected [0,1,3,7,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound57617 : packedSelected [0,1,3,7,11,15] rootPS < 2^1333 := by decide +kernel

def env57618 : List Nat := [2,4,8,16,32,16,57,256,512,20,2048,2090,2562,2091,2586,2860,2367,815,20,2586,545,32,2586,2861,2610,2587,2325,2091,2367,2341,2574,17,257,2830,2366,512]

theorem envBound57618 : H12AffineFastState.Bounded env57618 := by
  intro p hp
  have h : env57618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57617_57618 : H12AffineEnvironment.transform 6 57 env57617 = env57618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env57617 == env57618) = true)

theorem identity57618 : scanCanonicalize (H12AffineFastState.compose env57618 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 798) := by decide +kernel

theorem selectedBound57618 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57619 : List Nat := [2,4,8,16,32,16,57,256,512,20,798,820,284,821,260,50,545,815,20,260,545,32,260,51,300,261,523,821,545,571,272,17,257,16,544,512]

theorem envBound57619 : H12AffineFastState.Bounded env57619 := by
  intro p hp
  have h : env57619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57618_57619 : H12AffineEnvironment.transform 10 798 env57618 = env57619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 798 env57618 == env57619) = true)

def env57620 : List Nat := [2,4,8,16,16,16,9,256,512,20,798,772,284,773,260,2,529,799,20,260,529,16,260,3,284,261,523,773,529,523,272,17,257,16,528,512]

theorem envBound57620 : H12AffineFastState.Bounded env57620 := by
  intro p hp
  have h : env57620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57619_57620 : H12AffineEnvironment.transform 4 16 env57619 = env57620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57619 == env57620) = true)

theorem identity57620 : scanCanonicalize (H12AffineFastState.compose env57620 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound57620 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57621 : List Nat := [2,4,8,16,16,16,9,31,512,20,513,539,3,538,27,2,529,512,20,27,529,16,27,3,3,26,523,538,529,523,15,17,30,16,528,512]

theorem envBound57621 : H12AffineFastState.Bounded env57621 := by
  intro p hp
  have h : env57621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57620_57621 : H12AffineEnvironment.transform 7 31 env57620 = env57621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env57620 == env57621) = true)

theorem identity57621 : scanCanonicalize (H12AffineFastState.compose env57621 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57621 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57622 : List Nat := [2,4,8,11,11,11,9,4,512,15,513,512,3,513,0,2,522,512,15,0,522,11,0,3,3,1,523,513,522,523,15,10,5,11,523,512]

theorem envBound57622 : H12AffineFastState.Bounded env57622 := by
  intro p hp
  have h : env57622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57621_57622 : H12AffineEnvironment.transform 3 11 env57621 = env57622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57621 == env57622) = true)

def env57623 : List Nat := [2,4,8,16,17,16,8,256,512,20,798,773,284,772,260,3,528,798,20,260,528,17,260,2,285,261,523,772,528,522,272,17,257,16,529,512]

theorem envBound57623 : H12AffineFastState.Bounded env57623 := by
  intro p hp
  have h : env57623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57619_57623 : H12AffineEnvironment.transform 4 17 env57619 = env57623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57619 == env57623) = true)

theorem identity57623 : scanCanonicalize (H12AffineFastState.compose env57623 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound57623 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57624 : List Nat := [2,4,8,16,17,16,8,256,11,20,277,270,284,271,260,3,27,277,20,260,27,17,260,2,285,261,0,271,27,1,272,17,257,16,26,11]

theorem envBound57624 : H12AffineFastState.Bounded env57624 := by
  intro p hp
  have h : env57624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57623_57624 : H12AffineEnvironment.transform 8 11 env57623 = env57624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env57623 == env57624) = true)

theorem identity57624 : scanCanonicalize (H12AffineFastState.compose env57624 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound57624 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57625 : List Nat := [2,4,8,16,17,16,8,14,11,20,27,0,18,1,10,3,27,27,20,10,27,17,10,2,19,11,0,1,27,1,30,17,15,16,26,11]

theorem envBound57625 : H12AffineFastState.Bounded env57625 := by
  intro p hp
  have h : env57625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57624_57625 : H12AffineEnvironment.transform 7 14 env57624 = env57625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env57624 == env57625) = true)

def env57626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1024,32768,2097152,4194304,6336705,6295815,4247641,6348993,4486236,16384,77954,4315355,6395142,4292870,257,6406395,78035,4256464]

theorem envBound57626 : H12AffineFastState.Bounded env57626 := by
  intro p hp
  have h : env57626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57506_57626 : H12AffineEnvironment.transform 22 6336705 env57506 = env57626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6336705 env57506 == env57626) = true)

def env57627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,4194304,6336705,6295815,4247641,6348993,4273308,16384,77954,4315355,6395142,4292870,257,6406395,78035,4256464]

theorem envBound57627 : H12AffineFastState.Bounded env57627 := by
  intro p hp
  have h : env57627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57626_57627 : H12AffineEnvironment.transform 17 82112 env57626 = env57627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82112 env57626 == env57627) = true)

def env57628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41088,2101313,2142599,28889,2113601,103452,16384,77954,96347,2176390,74118,257,2187387,78035,21072]

theorem envBound57628 : H12AffineFastState.Bounded env57628 := by
  intro p hp
  have h : env57628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57627_57628 : H12AffineEnvironment.transform 21 41088 env57627 = env57628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57627 == env57628) = true)

theorem identity57628 : scanCanonicalize (H12AffineFastState.compose env57628 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 9397) := by decide +kernel

theorem selectedBound57628 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,9397,32768,65536,78034,74869,1024,32768,2097152,41088,2101313,2142599,5228,2106612,103452,9397,77954,72942,2176390,74118,257,2163918,78035,14053]

theorem envBound57629 : H12AffineFastState.Bounded env57629 := by
  intro p hp
  have h : env57629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57628_57629 : H12AffineEnvironment.transform 13 9397 env57628 = env57629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9397 env57628 == env57629) = true)

theorem identity57629 : scanCanonicalize (H12AffineFastState.compose env57629 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound57629 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,444,32768,65536,71131,65916,1024,32768,2097152,34185,2101313,2135182,5228,2097661,103452,444,71051,72942,2166927,66703,257,2163918,71130,5100]

theorem envBound57630 : H12AffineFastState.Bounded env57630 := by
  intro p hp
  have h : env57630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57629_57630 : H12AffineEnvironment.transform 12 1289 env57629 = env57630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env57629 == env57630) = true)

theorem identity57630 : scanCanonicalize (H12AffineFastState.compose env57630 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 66663) := by decide +kernel

theorem selectedBound57630 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,444,32768,65536,71131,65916,1024,32768,66663,34185,70694,102633,5228,66970,103452,444,71051,72942,5352,66703,257,169,71130,5100]

theorem envBound57631 : H12AffineFastState.Bounded env57631 := by
  intro p hp
  have h : env57631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57630_57631 : H12AffineEnvironment.transform 20 66663 env57630 = env57631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66663 env57630 == env57631) = true)

theorem identity57631 : scanCanonicalize (H12AffineFastState.compose env57631 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound57631 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1289,444,32768,65536,66615,65916,1024,32768,66663,34185,67018,98565,1408,66970,99824,444,66663,68866,1284,66703,257,169,66614,512]

theorem envBound57632 : H12AffineFastState.Bounded env57632 := by
  intro p hp
  have h : env57632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57631_57632 : H12AffineEnvironment.transform 11 492 env57631 = env57632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env57631 == env57632) = true)

theorem identity57632 : scanCanonicalize (H12AffineFastState.compose env57632 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1874) := by decide +kernel

theorem selectedBound57632 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,1289,444,32768,1874,869,1582,1024,32768,821,34185,664,34391,1408,712,33442,444,821,2640,1284,989,257,169,868,512]

theorem envBound57633 : H12AffineFastState.Bounded env57633 := by
  intro p hp
  have h : env57633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57632_57633 : H12AffineEnvironment.transform 15 1874 env57632 = env57633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1874 env57632 == env57633) = true)

def env57634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82112,1024,32768,2097152,41089,2101312,2142598,28888,2113600,103453,16384,77954,96346,2176391,74119,257,2187386,78035,21073]

theorem envBound57634 : H12AffineFastState.Bounded env57634 := by
  intro p hp
  have h : env57634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57627_57634 : H12AffineEnvironment.transform 21 41089 env57627 = env57634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57627 == env57634) = true)

theorem identity57634 : scanCanonicalize (H12AffineFastState.compose env57634 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 501) := by decide +kernel

theorem selectedBound57634 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,501,16384,32768,65536,69927,82112,1024,32768,2097152,33140,2101312,2134131,20781,2113600,103453,16384,70007,88495,2167922,65650,257,2179471,69926,21073]

theorem envBound57635 : H12AffineFastState.Bounded env57635 := by
  intro p hp
  have h : env57635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57634_57635 : H12AffineEnvironment.transform 12 501 env57634 = env57635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 501 env57634 == env57635) = true)

theorem identity57635 : scanCanonicalize (H12AffineFastState.compose env57635 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound57635 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,501,16384,32768,65536,69927,82112,1024,32768,71050,33140,67018,99833,20781,87498,103453,16384,70007,88495,504,65650,257,21509,69926,21073]

theorem envBound57636 : H12AffineFastState.Bounded env57636 := by
  intro p hp
  have h : env57636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57635_57636 : H12AffineEnvironment.transform 20 71050 env57635 = env57636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env57635 == env57636) = true)

theorem identity57636 : scanCanonicalize (H12AffineFastState.compose env57636 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 53726) := by decide +kernel

theorem selectedBound57636 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,501,16384,32768,53726,49401,37150,1024,32768,50260,33140,54292,21543,20781,33812,17859,16384,49321,34929,504,53676,257,21509,49400,21073]

theorem envBound57637 : H12AffineFastState.Bounded env57637 := by
  intro p hp
  have h : env57637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57636_57637 : H12AffineEnvironment.transform 15 53726 env57636 = env57637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53726 env57636 == env57637) = true)

theorem identity57637 : scanCanonicalize (H12AffineFastState.compose env57637 (packedSelected [5,8,10,13,17,19,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57637 : packedSelected [5,8,10,13,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env57638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,501,4177,32768,33167,37032,37150,1024,32768,37893,33140,33861,1142,380,33812,5522,4177,37112,34929,504,33277,257,1108,37033,512]

theorem envBound57638 : H12AffineFastState.Bounded env57638 := by
  intro p hp
  have h : env57638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57637_57638 : H12AffineEnvironment.transform 13 4177 env57637 = env57638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57637 == env57638) = true)

theorem identity57638 : scanCanonicalize (H12AffineFastState.compose env57638 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound57638 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,4096,501,4177,32768,33167,37032,37150,1024,32768,37893,33140,33861,1142,380,33812,5522,4177,37112,34682,504,33277,257,1108,37033,512]

theorem envBound57639 : H12AffineFastState.Bounded env57639 := by
  intro p hp
  have h : env57639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57638_57639 : H12AffineEnvironment.transform 10 1803 env57638 = env57639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env57638 == env57639) = true)

theorem identity57639 : scanCanonicalize (H12AffineFastState.compose env57639 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 340) := by decide +kernel

theorem selectedBound57639 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,4096,501,4177,340,219,4604,4170,1024,340,5457,32,1297,1142,380,1344,5522,4177,4524,1582,504,169,257,1108,4605,512]

theorem envBound57640 : H12AffineFastState.Bounded env57640 := by
  intro p hp
  have h : env57640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57639_57640 : H12AffineEnvironment.transform 14 340 env57639 = env57640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 340 env57639 == env57640) = true)

def env57641 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1803,4096,301,4177,340,3,4388,4170,1024,340,5457,32,1297,1142,380,1344,5450,4177,4468,1582,288,113,257,1108,4389,512]

theorem envBound57641 : H12AffineFastState.Bounded env57641 := by
  intro p hp
  have h : env57641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57640_57641 : H12AffineEnvironment.transform 6 88 env57640 = env57641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env57640 == env57641) = true)

def env57642 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1803,0,301,81,340,3,292,74,1024,340,1361,32,1297,1142,380,1344,1354,81,372,1582,288,113,257,1108,293,512]

theorem envBound57642 : H12AffineFastState.Bounded env57642 := by
  intro p hp
  have h : env57642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57641_57642 : H12AffineEnvironment.transform 11 0 env57641 = env57642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env57641 == env57642) = true)

theorem identity57642 : scanCanonicalize (H12AffineFastState.compose env57642 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57642 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57643 : List Nat := [2,4,8,16,32,64,88,20,512,1024,1567,0,57,81,64,3,48,74,1024,64,1093,32,1029,1142,104,1108,1118,81,96,1582,52,113,21,1108,49,512]

theorem envBound57643 : H12AffineFastState.Bounded env57643 := by
  intro p hp
  have h : env57643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57642_57643 : H12AffineEnvironment.transform 7 20 env57642 = env57643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57642 == env57643) = true)

theorem identity57643 : scanCanonicalize (H12AffineFastState.compose env57643 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 638) := by decide +kernel

theorem selectedBound57643 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57644 : List Nat := [2,4,8,16,32,64,88,20,512,638,97,0,57,81,64,3,48,74,638,64,571,32,635,520,104,554,544,81,96,80,52,113,21,554,49,512]

theorem envBound57644 : H12AffineFastState.Bounded env57644 := by
  intro p hp
  have h : env57644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57643_57644 : H12AffineEnvironment.transform 9 638 env57643 = env57644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 638 env57643 == env57644) = true)

theorem identity57644 : scanCanonicalize (H12AffineFastState.compose env57644 (packedSelected [0,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound57644 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env57645 : List Nat := [2,4,8,16,32,64,88,20,33,95,97,0,57,81,64,3,48,74,95,64,26,32,90,41,104,11,1,81,96,80,52,113,21,11,49,33]

theorem envBound57645 : H12AffineFastState.Bounded env57645 := by
  intro p hp
  have h : env57645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57644_57645 : H12AffineEnvironment.transform 8 33 env57644 = env57645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env57644 == env57645) = true)

theorem identity57645 : scanCanonicalize (H12AffineFastState.compose env57645 (packedSelected [0,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound57645 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env57646 : List Nat := [2,4,8,16,32,59,35,20,33,36,26,0,57,42,59,3,48,49,36,59,26,32,33,41,19,11,1,42,27,43,52,10,21,11,49,33]

theorem envBound57646 : H12AffineFastState.Bounded env57646 := by
  intro p hp
  have h : env57646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57645_57646 : H12AffineEnvironment.transform 5 59 env57645 = env57646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env57645 == env57646) = true)

theorem identity57646 : scanCanonicalize (H12AffineFastState.compose env57646 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound57646 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57647 : List Nat := [2,4,8,16,16,11,19,20,17,20,26,0,9,26,11,3,0,1,20,11,26,16,17,25,19,11,1,26,27,27,4,10,21,11,1,17]

theorem envBound57647 : H12AffineFastState.Bounded env57647 := by
  intro p hp
  have h : env57647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57646_57647 : H12AffineEnvironment.transform 4 16 env57646 = env57647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57646 == env57647) = true)

def env57648 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1803,1,301,80,340,3,293,75,1024,340,1360,32,1297,1142,380,1344,1355,80,373,1582,288,113,257,1108,292,512]

theorem envBound57648 : H12AffineFastState.Bounded env57648 := by
  intro p hp
  have h : env57648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57641_57648 : H12AffineEnvironment.transform 11 1 env57641 = env57648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57641 == env57648) = true)

theorem identity57648 : scanCanonicalize (H12AffineFastState.compose env57648 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound57648 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57649 : List Nat := [2,4,8,16,32,64,88,256,512,517,270,1,301,80,340,3,293,75,517,340,853,32,788,627,380,837,846,80,373,43,288,113,257,593,292,512]

theorem envBound57649 : H12AffineFastState.Bounded env57649 := by
  intro p hp
  have h : env57649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57648_57649 : H12AffineEnvironment.transform 9 517 env57648 = env57649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env57648 == env57649) = true)

theorem identity57649 : scanCanonicalize (H12AffineFastState.compose env57649 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound57649 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57650 : List Nat := [2,4,8,16,32,64,88,256,91,94,270,1,301,80,340,3,293,75,94,340,270,32,335,40,380,286,277,80,373,43,288,113,257,10,292,91]

theorem envBound57650 : H12AffineFastState.Bounded env57650 := by
  intro p hp
  have h : env57650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57649_57650 : H12AffineEnvironment.transform 8 91 env57649 = env57650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env57649 == env57650) = true)

theorem identity57650 : scanCanonicalize (H12AffineFastState.compose env57650 (packedSelected [0,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound57650 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env57651 : List Nat := [2,4,8,16,32,64,88,21,91,94,27,1,56,80,65,3,48,75,94,65,27,32,90,40,105,11,0,80,96,43,53,113,20,10,49,91]

theorem envBound57651 : H12AffineFastState.Bounded env57651 := by
  intro p hp
  have h : env57651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57650_57651 : H12AffineEnvironment.transform 7 21 env57650 = env57651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env57650 == env57651) = true)

theorem identity57651 : scanCanonicalize (H12AffineFastState.compose env57651 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57651 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env57652 : List Nat := [2,4,8,16,32,16,8,21,11,14,27,1,56,0,17,3,48,27,14,17,27,32,10,40,57,11,0,0,48,43,53,33,20,10,49,11]

theorem envBound57652 : H12AffineFastState.Bounded env57652 := by
  intro p hp
  have h : env57652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57651_57652 : H12AffineEnvironment.transform 5 16 env57651 = env57652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57651 == env57652) = true)

theorem identity57652 : scanCanonicalize (H12AffineFastState.compose env57652 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57652 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57653 : List Nat := [2,4,8,16,10,16,8,21,11,14,27,1,18,0,17,3,26,27,14,17,27,10,10,2,19,11,0,0,26,1,31,11,20,10,27,11]

theorem envBound57653 : H12AffineFastState.Bounded env57653 := by
  intro p hp
  have h : env57653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57652_57653 : H12AffineEnvironment.transform 4 10 env57652 = env57653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57652 == env57653) = true)

def env57654 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1803,4096,300,4177,340,2,4389,4170,1024,340,5457,32,1297,1142,380,1344,5451,4177,4469,1582,289,112,257,1108,4388,512]

theorem envBound57654 : H12AffineFastState.Bounded env57654 := by
  intro p hp
  have h : env57654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57640_57654 : H12AffineEnvironment.transform 6 89 env57640 = env57654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env57640 == env57654) = true)

def env57655 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1803,0,300,81,340,2,293,74,1024,340,1361,32,1297,1142,380,1344,1355,81,373,1582,289,112,257,1108,292,512]

theorem envBound57655 : H12AffineFastState.Bounded env57655 := by
  intro p hp
  have h : env57655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57654_57655 : H12AffineEnvironment.transform 11 0 env57654 = env57655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env57654 == env57655) = true)

theorem identity57655 : scanCanonicalize (H12AffineFastState.compose env57655 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 369) := by decide +kernel

theorem selectedBound57655 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57656 : List Nat := [2,4,8,16,32,64,89,256,512,369,634,0,300,81,340,2,293,74,369,340,32,32,96,263,380,49,58,81,373,863,289,112,257,293,292,512]

theorem envBound57656 : H12AffineFastState.Bounded env57656 := by
  intro p hp
  have h : env57656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57655_57656 : H12AffineEnvironment.transform 9 369 env57655 = env57656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 369 env57655 == env57656) = true)

theorem identity57656 : scanCanonicalize (H12AffineFastState.compose env57656 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 79) := by decide +kernel

theorem selectedBound57656 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env57657 : List Nat := [2,4,8,16,32,64,89,79,512,62,634,0,99,81,27,2,106,74,62,27,32,32,96,72,51,49,58,81,58,528,110,112,78,106,107,512]

theorem envBound57657 : H12AffineFastState.Bounded env57657 := by
  intro p hp
  have h : env57657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57656_57657 : H12AffineEnvironment.transform 7 79 env57656 = env57657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 79 env57656 == env57657) = true)

theorem identity57657 : scanCanonicalize (H12AffineFastState.compose env57657 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57657 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env57658 : List Nat := [2,4,8,11,32,64,66,79,512,37,609,0,99,74,0,2,106,74,37,0,32,32,96,72,40,42,33,74,33,523,110,107,78,106,107,512]

theorem envBound57658 : H12AffineFastState.Bounded env57658 := by
  intro p hp
  have h : env57658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57657_57658 : H12AffineEnvironment.transform 3 11 env57657 = env57658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57657 == env57658) = true)

theorem identity57658 : scanCanonicalize (H12AffineFastState.compose env57658 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound57658 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57659 : List Nat := [2,4,8,11,32,64,66,79,97,37,0,0,99,74,0,2,106,74,37,0,32,32,96,72,40,42,33,74,33,106,110,107,78,106,107,97]

theorem envBound57659 : H12AffineFastState.Bounded env57659 := by
  intro p hp
  have h : env57659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57658_57659 : H12AffineEnvironment.transform 8 97 env57658 = env57659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env57658 == env57659) = true)

def env57660 : List Nat := [2,4,8,11,32,32,34,47,1,37,0,0,3,42,0,2,10,42,37,0,32,32,0,40,40,42,33,42,33,10,14,11,46,10,11,1]

theorem envBound57660 : H12AffineFastState.Bounded env57660 := by
  intro p hp
  have h : env57660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57659_57660 : H12AffineEnvironment.transform 5 32 env57659 = env57660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env57659 == env57660) = true)

theorem identity57660 : scanCanonicalize (H12AffineFastState.compose env57660 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57660 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57661 : List Nat := [2,4,3,0,32,32,34,36,1,37,0,0,3,33,0,2,1,33,37,0,32,32,0,35,35,33,33,33,33,1,5,0,37,1,0,1]

theorem envBound57661 : H12AffineFastState.Bounded env57661 := by
  intro p hp
  have h : env57661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57660_57661 : H12AffineEnvironment.transform 2 3 env57660 = env57661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57660 == env57661) = true)

def env57662 : List Nat := [2,4,8,11,32,33,35,46,0,37,0,0,2,43,0,2,11,43,37,0,32,32,1,41,40,42,33,43,33,11,15,10,47,11,10,0]

theorem envBound57662 : H12AffineFastState.Bounded env57662 := by
  intro p hp
  have h : env57662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57659_57662 : H12AffineEnvironment.transform 5 33 env57659 = env57662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env57659 == env57662) = true)

def env57663 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1803,1,300,80,340,2,292,75,1024,340,1360,32,1297,1142,380,1344,1354,80,372,1582,289,112,257,1108,293,512]

theorem envBound57663 : H12AffineFastState.Bounded env57663 := by
  intro p hp
  have h : env57663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57654_57663 : H12AffineEnvironment.transform 11 1 env57654 = env57663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57654 == env57663) = true)

theorem identity57663 : scanCanonicalize (H12AffineFastState.compose env57663 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound57663 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57664 : List Nat := [2,4,8,16,32,64,89,256,96,1024,1387,1,300,80,340,2,292,75,1024,340,1360,32,1297,1142,380,1344,1354,80,372,1102,289,112,257,1108,293,96]

theorem envBound57664 : H12AffineFastState.Bounded env57664 := by
  intro p hp
  have h : env57664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57663_57664 : H12AffineEnvironment.transform 8 96 env57663 = env57664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env57663 == env57664) = true)

theorem identity57664 : scanCanonicalize (H12AffineFastState.compose env57664 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57664 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env57665 : List Nat := [2,4,8,11,32,64,66,256,96,1024,1387,1,300,75,335,2,292,75,1024,335,1355,32,1290,1133,359,1344,1354,75,367,1102,289,107,257,1103,293,96]

theorem envBound57665 : H12AffineFastState.Bounded env57665 := by
  intro p hp
  have h : env57665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57664_57665 : H12AffineEnvironment.transform 3 11 env57664 = env57665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57664 == env57665) = true)

theorem identity57665 : scanCanonicalize (H12AffineFastState.compose env57665 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 362) := by decide +kernel

theorem selectedBound57665 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env57666 : List Nat := [2,4,8,11,32,64,66,256,96,362,1,1,300,75,335,2,292,75,362,335,33,32,96,263,359,42,32,75,367,292,289,107,257,293,293,96]

theorem envBound57666 : H12AffineFastState.Bounded env57666 := by
  intro p hp
  have h : env57666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57665_57666 : H12AffineEnvironment.transform 9 362 env57665 = env57666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 362 env57665 == env57666) = true)

theorem identity57666 : scanCanonicalize (H12AffineFastState.compose env57666 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 79) := by decide +kernel

theorem selectedBound57666 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env57667 : List Nat := [2,4,8,11,32,64,66,79,96,37,1,1,99,75,0,2,107,75,37,0,33,32,96,72,40,42,32,75,32,107,110,107,78,106,106,96]

theorem envBound57667 : H12AffineFastState.Bounded env57667 := by
  intro p hp
  have h : env57667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57666_57667 : H12AffineEnvironment.transform 7 79 env57666 = env57667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 79 env57666 == env57667) = true)

def env57668 : List Nat := [2,4,8,11,32,32,34,47,0,37,1,1,3,43,0,2,11,43,37,0,33,32,0,40,40,42,32,43,32,11,14,11,46,10,10,0]

theorem envBound57668 : H12AffineFastState.Bounded env57668 := by
  intro p hp
  have h : env57668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57667_57668 : H12AffineEnvironment.transform 5 32 env57667 = env57668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env57667 == env57668) = true)

theorem identity57668 : scanCanonicalize (H12AffineFastState.compose env57668 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57668 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57669 : List Nat := [2,4,3,0,32,32,34,36,0,37,1,1,3,32,0,2,0,32,37,0,33,32,0,35,35,33,32,32,32,0,5,0,37,1,1,0]

theorem envBound57669 : H12AffineFastState.Bounded env57669 := by
  intro p hp
  have h : env57669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57668_57669 : H12AffineEnvironment.transform 2 3 env57668 = env57669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57668 == env57669) = true)

def env57670 : List Nat := [2,4,8,11,32,33,35,46,1,37,1,1,2,42,0,2,10,42,37,0,33,32,1,41,40,42,32,42,32,10,15,10,47,11,11,1]

theorem envBound57670 : H12AffineFastState.Bounded env57670 := by
  intro p hp
  have h : env57670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57667_57670 : H12AffineEnvironment.transform 5 33 env57667 = env57670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env57667 == env57670) = true)

def env57671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,4194304,6336705,6295815,4247641,6348993,4273309,16384,77954,4315355,6395142,4292870,257,6406395,78035,4256464]

theorem envBound57671 : H12AffineFastState.Bounded env57671 := by
  intro p hp
  have h : env57671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57626_57671 : H12AffineEnvironment.transform 17 82113 env57626 = env57671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 82113 env57626 == env57671) = true)

def env57672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41088,2101313,2142599,28889,2113601,103453,16384,77954,96347,2176390,74118,257,2187387,78035,21072]

theorem envBound57672 : H12AffineFastState.Bounded env57672 := by
  intro p hp
  have h : env57672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57671_57672 : H12AffineEnvironment.transform 21 41088 env57671 = env57672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env57671 == env57672) = true)

theorem identity57672 : scanCanonicalize (H12AffineFastState.compose env57672 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5348) := by decide +kernel

theorem selectedBound57672 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5348,16384,32768,65536,66614,82113,1024,32768,2097152,37988,2101313,2131299,17469,2113601,103453,16384,66662,85183,2163042,71010,257,2184351,66615,21072]

theorem envBound57673 : H12AffineFastState.Bounded env57673 := by
  intro p hp
  have h : env57673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57672_57673 : H12AffineEnvironment.transform 12 5348 env57672 = env57673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5348 env57672 == env57673) = true)

theorem identity57673 : scanCanonicalize (H12AffineFastState.compose env57673 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57673 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,16384,32768,65536,66614,82113,1024,32768,2097152,34185,2097580,2131299,17469,2113601,99824,16384,66662,85183,2163042,66703,257,2180466,66615,17341]

theorem envBound57674 : H12AffineFastState.Bounded env57674 := by
  intro p hp
  have h : env57674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57673_57674 : H12AffineEnvironment.transform 11 493 env57673 = env57674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57673 == env57674) = true)

theorem identity57674 : scanCanonicalize (H12AffineFastState.compose env57674 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 83419) := by decide +kernel

theorem selectedBound57674 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,16384,32768,65536,66614,82113,1024,32768,83419,34185,83063,114872,17469,66970,99824,16384,66662,85183,17593,66703,257,169,66615,17341]

theorem envBound57675 : H12AffineFastState.Bounded env57675 := by
  intro p hp
  have h : env57675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57674_57675 : H12AffineEnvironment.transform 20 83419 env57674 = env57675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83419 env57674 == env57675) = true)

theorem identity57675 : scanCanonicalize (H12AffineFastState.compose env57675 (packedSelected [25] rootPS)) = affineNative (2^(13+1) ^^^ 445) := by decide +kernel

theorem selectedBound57675 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,445,32768,65536,66614,65916,1024,32768,66662,34185,67018,98565,1408,66970,99824,445,66662,68866,1284,66703,257,169,66615,512]

theorem envBound57676 : H12AffineFastState.Bounded env57676 := by
  intro p hp
  have h : env57676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57675_57676 : H12AffineEnvironment.transform 13 445 env57675 = env57676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 445 env57675 == env57676) = true)

theorem identity57676 : scanCanonicalize (H12AffineFastState.compose env57676 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1874) := by decide +kernel

theorem selectedBound57676 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,1289,445,32768,1874,868,1582,1024,32768,820,34185,664,34391,1408,712,33442,445,820,2640,1284,989,257,169,869,512]

theorem envBound57677 : H12AffineFastState.Bounded env57677 := by
  intro p hp
  have h : env57677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57676_57677 : H12AffineEnvironment.transform 15 1874 env57676 = env57677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1874 env57676 == env57677) = true)

def env57678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,82113,1024,32768,2097152,41089,2101312,2142598,28888,2113600,103452,16384,77954,96346,2176391,74119,257,2187386,78035,21073]

theorem envBound57678 : H12AffineFastState.Bounded env57678 := by
  intro p hp
  have h : env57678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57671_57678 : H12AffineEnvironment.transform 21 41089 env57671 = env57678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env57671 == env57678) = true)

theorem identity57678 : scanCanonicalize (H12AffineFastState.compose env57678 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 12709) := by decide +kernel

theorem selectedBound57678 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12709,32768,65536,78034,78180,1024,32768,2097152,41089,2101312,2142598,381,2109925,103452,12709,77954,68095,2176391,74119,257,2167263,78035,9204]

theorem envBound57679 : H12AffineFastState.Bounded env57679 := by
  intro p hp
  have h : env57679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57678_57679 : H12AffineEnvironment.transform 13 12709 env57678 = env57679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12709 env57678 == env57679) = true)

theorem identity57679 : scanCanonicalize (H12AffineFastState.compose env57679 (packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound57679 : packedSelected [0,1,5,7,8,9,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env57680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12709,32768,65536,78034,78180,1024,32768,71050,41089,67018,107532,381,74863,103452,12709,77954,68095,8205,74119,257,1109,78035,9204]

theorem envBound57680 : H12AffineFastState.Bounded env57680 := by
  intro p hp
  have h : env57680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57679_57680 : H12AffineEnvironment.transform 20 71050 env57679 = env57680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env57679 == env57680) = true)

theorem identity57680 : scanCanonicalize (H12AffineFastState.compose env57680 (packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 41083) := by decide +kernel

theorem selectedBound57680 : packedSelected [1,3,4,5,8,9,10,13,16,19,21] rootPS < 2^1333 := by decide +kernel

def env57681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12709,32768,41083,37033,37151,1024,32768,46577,41089,42417,1143,381,33812,13415,12709,37113,43396,8205,33276,257,1109,37032,9204]

theorem envBound57681 : H12AffineFastState.Bounded env57681 := by
  intro p hp
  have h : env57681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57680_57681 : H12AffineEnvironment.transform 15 41083 env57680 = env57681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41083 env57680 == env57681) = true)

theorem identity57681 : scanCanonicalize (H12AffineFastState.compose env57681 (packedSelected [5,8,10,13,17,19,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 500) := by decide +kernel

theorem selectedBound57681 : packedSelected [5,8,10,13,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env57682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,500,4177,32768,33167,37033,37151,1024,32768,37893,33141,33861,1143,381,33812,5523,4177,37113,34928,505,33276,257,1109,37032,512]

theorem envBound57682 : H12AffineFastState.Bounded env57682 := by
  intro p hp
  have h : env57682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57681_57682 : H12AffineEnvironment.transform 12 500 env57681 = env57682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 500 env57681 == env57682) = true)

theorem identity57682 : scanCanonicalize (H12AffineFastState.compose env57682 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound57682 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,4096,500,4177,32768,33167,37033,37151,1024,32768,37893,33141,33861,1143,381,33812,5523,4177,37113,34683,505,33276,257,1109,37032,512]

theorem envBound57683 : H12AffineFastState.Bounded env57683 := by
  intro p hp
  have h : env57683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57682_57683 : H12AffineEnvironment.transform 10 1803 env57682 = env57683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env57682 == env57683) = true)

theorem identity57683 : scanCanonicalize (H12AffineFastState.compose env57683 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 341) := by decide +kernel

theorem selectedBound57683 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env57684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,4096,500,4177,341,218,4604,4170,1024,341,5456,32,1296,1143,381,1345,5523,4177,4524,1582,505,169,257,1109,4605,512]

theorem envBound57684 : H12AffineFastState.Bounded env57684 := by
  intro p hp
  have h : env57684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57683_57684 : H12AffineEnvironment.transform 14 341 env57683 = env57684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 341 env57683 == env57684) = true)

def env57685 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1803,4096,300,4177,341,2,4388,4170,1024,341,5456,32,1296,1143,381,1345,5451,4177,4468,1582,289,113,257,1109,4389,512]

theorem envBound57685 : H12AffineFastState.Bounded env57685 := by
  intro p hp
  have h : env57685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57684_57685 : H12AffineEnvironment.transform 6 88 env57684 = env57685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env57684 == env57685) = true)

def env57686 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1803,0,300,81,341,2,292,74,1024,341,1360,32,1296,1143,381,1345,1355,81,372,1582,289,113,257,1109,293,512]

theorem envBound57686 : H12AffineFastState.Bounded env57686 := by
  intro p hp
  have h : env57686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57685_57686 : H12AffineEnvironment.transform 11 0 env57685 = env57686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env57685 == env57686) = true)

theorem identity57686 : scanCanonicalize (H12AffineFastState.compose env57686 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57686 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57687 : List Nat := [2,4,8,16,32,64,88,20,512,1024,1567,0,56,81,65,2,48,74,1024,65,1092,32,1028,1143,105,1109,1119,81,96,1582,53,113,21,1109,49,512]

theorem envBound57687 : H12AffineFastState.Bounded env57687 := by
  intro p hp
  have h : env57687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57686_57687 : H12AffineEnvironment.transform 7 20 env57686 = env57687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57686 == env57687) = true)

theorem identity57687 : scanCanonicalize (H12AffineFastState.compose env57687 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 638) := by decide +kernel

theorem selectedBound57687 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57688 : List Nat := [2,4,8,16,32,64,88,20,512,638,97,0,56,81,65,2,48,74,638,65,570,32,634,521,105,555,545,81,96,80,53,113,21,555,49,512]

theorem envBound57688 : H12AffineFastState.Bounded env57688 := by
  intro p hp
  have h : env57688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57687_57688 : H12AffineEnvironment.transform 9 638 env57687 = env57688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 638 env57687 == env57688) = true)

theorem identity57688 : scanCanonicalize (H12AffineFastState.compose env57688 (packedSelected [0,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound57688 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env57689 : List Nat := [2,4,8,16,32,64,88,20,32,94,97,0,56,81,65,2,48,74,94,65,26,32,90,41,105,11,1,81,96,80,53,113,21,11,49,32]

theorem envBound57689 : H12AffineFastState.Bounded env57689 := by
  intro p hp
  have h : env57689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57688_57689 : H12AffineEnvironment.transform 8 32 env57688 = env57689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env57688 == env57689) = true)

theorem identity57689 : scanCanonicalize (H12AffineFastState.compose env57689 (packedSelected [0,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound57689 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env57690 : List Nat := [2,4,8,16,32,59,35,20,32,37,26,0,56,42,58,2,48,49,37,58,26,32,33,41,18,11,1,42,27,43,53,10,21,11,49,32]

theorem envBound57690 : H12AffineFastState.Bounded env57690 := by
  intro p hp
  have h : env57690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57689_57690 : H12AffineEnvironment.transform 5 59 env57689 = env57690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env57689 == env57690) = true)

theorem identity57690 : scanCanonicalize (H12AffineFastState.compose env57690 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound57690 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57691 : List Nat := [2,4,8,16,16,11,19,20,16,21,26,0,8,26,10,2,0,1,21,10,26,16,17,25,18,11,1,26,27,27,5,10,21,11,1,16]

theorem envBound57691 : H12AffineFastState.Bounded env57691 := by
  intro p hp
  have h : env57691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57690_57691 : H12AffineEnvironment.transform 4 16 env57690 = env57691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57690 == env57691) = true)

def env57692 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1803,1,300,80,341,2,293,75,1024,341,1361,32,1296,1143,381,1345,1354,80,373,1582,289,113,257,1109,292,512]

theorem envBound57692 : H12AffineFastState.Bounded env57692 := by
  intro p hp
  have h : env57692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57685_57692 : H12AffineEnvironment.transform 11 1 env57685 = env57692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57685 == env57692) = true)

theorem identity57692 : scanCanonicalize (H12AffineFastState.compose env57692 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound57692 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57693 : List Nat := [2,4,8,16,32,64,88,256,512,517,270,1,300,80,341,2,293,75,517,341,852,32,789,626,381,836,847,80,373,43,289,113,257,592,292,512]

theorem envBound57693 : H12AffineFastState.Bounded env57693 := by
  intro p hp
  have h : env57693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57692_57693 : H12AffineEnvironment.transform 9 517 env57692 = env57693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env57692 == env57693) = true)

theorem identity57693 : scanCanonicalize (H12AffineFastState.compose env57693 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound57693 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env57694 : List Nat := [2,4,8,16,32,64,88,256,90,95,270,1,300,80,341,2,293,75,95,341,270,32,335,40,381,286,277,80,373,43,289,113,257,10,292,90]

theorem envBound57694 : H12AffineFastState.Bounded env57694 := by
  intro p hp
  have h : env57694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57693_57694 : H12AffineEnvironment.transform 8 90 env57693 = env57694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env57693 == env57694) = true)

theorem identity57694 : scanCanonicalize (H12AffineFastState.compose env57694 (packedSelected [0,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound57694 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env57695 : List Nat := [2,4,8,16,32,64,88,21,90,95,27,1,57,80,64,2,48,75,95,64,27,32,90,40,104,11,0,80,96,43,52,113,20,10,49,90]

theorem envBound57695 : H12AffineFastState.Bounded env57695 := by
  intro p hp
  have h : env57695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57694_57695 : H12AffineEnvironment.transform 7 21 env57694 = env57695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env57694 == env57695) = true)

theorem identity57695 : scanCanonicalize (H12AffineFastState.compose env57695 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57695 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env57696 : List Nat := [2,4,8,16,32,16,8,21,10,15,27,1,57,0,16,2,48,27,15,16,27,32,10,40,56,11,0,0,48,43,52,33,20,10,49,10]

theorem envBound57696 : H12AffineFastState.Bounded env57696 := by
  intro p hp
  have h : env57696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57695_57696 : H12AffineEnvironment.transform 5 16 env57695 = env57696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57695 == env57696) = true)

theorem identity57696 : scanCanonicalize (H12AffineFastState.compose env57696 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57696 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57697 : List Nat := [2,4,8,16,10,16,8,21,10,15,27,1,19,0,16,2,26,27,15,16,27,10,10,2,18,11,0,0,26,1,30,11,20,10,27,10]

theorem envBound57697 : H12AffineFastState.Bounded env57697 := by
  intro p hp
  have h : env57697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57696_57697 : H12AffineEnvironment.transform 4 10 env57696 = env57697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57696 == env57697) = true)

def env57698 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1803,4096,301,4177,341,3,4389,4170,1024,341,5456,32,1296,1143,381,1345,5450,4177,4469,1582,288,112,257,1109,4388,512]

theorem envBound57698 : H12AffineFastState.Bounded env57698 := by
  intro p hp
  have h : env57698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57684_57698 : H12AffineEnvironment.transform 6 89 env57684 = env57698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env57684 == env57698) = true)

def env57699 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1803,0,301,81,341,3,293,74,1024,341,1360,32,1296,1143,381,1345,1354,81,373,1582,288,112,257,1109,292,512]

theorem envBound57699 : H12AffineFastState.Bounded env57699 := by
  intro p hp
  have h : env57699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57698_57699 : H12AffineEnvironment.transform 11 0 env57698 = env57699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env57698 == env57699) = true)

theorem identity57699 : scanCanonicalize (H12AffineFastState.compose env57699 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 369) := by decide +kernel

theorem selectedBound57699 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57700 : List Nat := [2,4,8,16,32,64,89,256,512,369,634,0,301,81,341,3,293,74,369,341,33,32,97,262,381,48,59,81,373,863,288,112,257,292,292,512]

theorem envBound57700 : H12AffineFastState.Bounded env57700 := by
  intro p hp
  have h : env57700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57699_57700 : H12AffineEnvironment.transform 9 369 env57699 = env57700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 369 env57699 == env57700) = true)

theorem identity57700 : scanCanonicalize (H12AffineFastState.compose env57700 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound57700 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env57701 : List Nat := [2,4,8,16,32,64,89,78,512,63,634,0,99,81,27,3,107,74,63,27,33,32,97,72,51,48,59,81,59,529,110,112,79,106,106,512]

theorem envBound57701 : H12AffineFastState.Bounded env57701 := by
  intro p hp
  have h : env57701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57700_57701 : H12AffineEnvironment.transform 7 78 env57700 = env57701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env57700 == env57701) = true)

theorem identity57701 : scanCanonicalize (H12AffineFastState.compose env57701 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57701 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env57702 : List Nat := [2,4,8,11,32,64,66,78,512,36,609,0,99,74,0,3,107,74,36,0,33,32,97,72,40,43,32,74,32,522,110,107,79,106,106,512]

theorem envBound57702 : H12AffineFastState.Bounded env57702 := by
  intro p hp
  have h : env57702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57701_57702 : H12AffineEnvironment.transform 3 11 env57701 = env57702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57701 == env57702) = true)

theorem identity57702 : scanCanonicalize (H12AffineFastState.compose env57702 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound57702 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57703 : List Nat := [2,4,8,11,32,64,66,78,97,36,0,0,99,74,0,3,107,74,36,0,33,32,97,72,40,43,32,74,32,107,110,107,79,106,106,97]

theorem envBound57703 : H12AffineFastState.Bounded env57703 := by
  intro p hp
  have h : env57703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57702_57703 : H12AffineEnvironment.transform 8 97 env57702 = env57703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env57702 == env57703) = true)

def env57704 : List Nat := [2,4,8,11,32,32,34,46,1,36,0,0,3,42,0,3,11,42,36,0,33,32,1,40,40,43,32,42,32,11,14,11,47,10,10,1]

theorem envBound57704 : H12AffineFastState.Bounded env57704 := by
  intro p hp
  have h : env57704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57703_57704 : H12AffineEnvironment.transform 5 32 env57703 = env57704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env57703 == env57704) = true)

theorem identity57704 : scanCanonicalize (H12AffineFastState.compose env57704 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57704 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57705 : List Nat := [2,4,2,1,32,32,34,36,1,36,0,0,3,32,0,3,1,32,36,0,33,32,1,34,34,33,32,32,32,1,4,1,37,0,0,1]

theorem envBound57705 : H12AffineFastState.Bounded env57705 := by
  intro p hp
  have h : env57705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57704_57705 : H12AffineEnvironment.transform 2 2 env57704 = env57705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57704 == env57705) = true)

def env57706 : List Nat := [2,4,8,11,32,33,35,47,0,36,0,0,2,43,0,3,10,43,36,0,33,32,0,41,40,43,32,43,32,10,15,10,46,11,11,0]

theorem envBound57706 : H12AffineFastState.Bounded env57706 := by
  intro p hp
  have h : env57706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57703_57706 : H12AffineEnvironment.transform 5 33 env57703 = env57706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env57703 == env57706) = true)

def env57707 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1803,1,301,80,341,3,292,75,1024,341,1361,32,1296,1143,381,1345,1355,80,372,1582,288,112,257,1109,293,512]

theorem envBound57707 : H12AffineFastState.Bounded env57707 := by
  intro p hp
  have h : env57707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57698_57707 : H12AffineEnvironment.transform 11 1 env57698 = env57707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57698 == env57707) = true)

theorem identity57707 : scanCanonicalize (H12AffineFastState.compose env57707 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound57707 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57708 : List Nat := [2,4,8,16,32,64,89,256,96,1024,1387,1,301,80,341,3,292,75,1024,341,1361,32,1296,1143,381,1345,1355,80,372,1102,288,112,257,1109,293,96]

theorem envBound57708 : H12AffineFastState.Bounded env57708 := by
  intro p hp
  have h : env57708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57707_57708 : H12AffineEnvironment.transform 8 96 env57707 = env57708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env57707 == env57708) = true)

theorem identity57708 : scanCanonicalize (H12AffineFastState.compose env57708 (packedSelected [0,2,7,10,11,13] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57708 : packedSelected [0,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env57709 : List Nat := [2,4,8,11,32,64,66,256,96,1024,1387,1,301,75,334,3,292,75,1024,334,1354,32,1291,1132,358,1345,1355,75,367,1102,288,107,257,1102,293,96]

theorem envBound57709 : H12AffineFastState.Bounded env57709 := by
  intro p hp
  have h : env57709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57708_57709 : H12AffineEnvironment.transform 3 11 env57708 = env57709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57708 == env57709) = true)

theorem identity57709 : scanCanonicalize (H12AffineFastState.compose env57709 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 362) := by decide +kernel

theorem selectedBound57709 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env57710 : List Nat := [2,4,8,11,32,64,66,256,96,362,1,1,301,75,334,3,292,75,362,334,32,32,97,262,358,43,33,75,367,292,288,107,257,292,293,96]

theorem envBound57710 : H12AffineFastState.Bounded env57710 := by
  intro p hp
  have h : env57710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57709_57710 : H12AffineEnvironment.transform 9 362 env57709 = env57710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 362 env57709 == env57710) = true)

theorem identity57710 : scanCanonicalize (H12AffineFastState.compose env57710 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound57710 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env57711 : List Nat := [2,4,8,11,32,64,66,78,96,36,1,1,99,75,0,3,106,75,36,0,32,32,97,72,40,43,33,75,33,106,110,107,79,106,107,96]

theorem envBound57711 : H12AffineFastState.Bounded env57711 := by
  intro p hp
  have h : env57711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57710_57711 : H12AffineEnvironment.transform 7 78 env57710 = env57711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env57710 == env57711) = true)

def env57712 : List Nat := [2,4,8,11,32,32,34,46,0,36,1,1,3,43,0,3,10,43,36,0,32,32,1,40,40,43,33,43,33,10,14,11,47,10,11,0]

theorem envBound57712 : H12AffineFastState.Bounded env57712 := by
  intro p hp
  have h : env57712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57711_57712 : H12AffineEnvironment.transform 5 32 env57711 = env57712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env57711 == env57712) = true)

theorem identity57712 : scanCanonicalize (H12AffineFastState.compose env57712 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57712 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57713 : List Nat := [2,4,2,1,32,32,34,36,0,36,1,1,3,33,0,3,0,33,36,0,32,32,1,34,34,33,33,33,33,0,4,1,37,0,1,0]

theorem envBound57713 : H12AffineFastState.Bounded env57713 := by
  intro p hp
  have h : env57713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57712_57713 : H12AffineEnvironment.transform 2 2 env57712 = env57713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57712 == env57713) = true)

def env57714 : List Nat := [2,4,8,11,32,33,35,47,1,36,1,1,2,42,0,3,11,42,36,0,32,32,0,41,40,43,33,42,33,11,15,10,46,11,10,1]

theorem envBound57714 : H12AffineFastState.Bounded env57714 := by
  intro p hp
  have h : env57714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57711_57714 : H12AffineEnvironment.transform 5 33 env57711 = env57714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env57711 == env57714) = true)

def env57715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16384,131153,4315354,8463815,4294967296,256,4307611964,34359738368,33563273]

theorem envBound57715 : H12AffineFastState.Bounded env57715 := by
  intro p hp
  have h : env57715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56763_57715 : H12AffineEnvironment.transform 18 1025 env56763 = env57715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env56763 == env57715) = true)

def env57716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16384,131153,4315354,8463815,4294967296,256,4307611964,131072,33563273]

theorem envBound57716 : H12AffineFastState.Bounded env57716 := by
  intro p hp
  have h : env57716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57715_57716 : H12AffineEnvironment.transform 34 131072 env57715 = env57716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env57715 == env57716) = true)

theorem identity57716 : scanCanonicalize (H12AffineFastState.compose env57716 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 91335) := by decide +kernel

theorem selectedBound57716 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env57717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16384,131153,4315354,8463815,91335,256,12686843,131072,33563273]

theorem envBound57717 : H12AffineFastState.Bounded env57717 := by
  intro p hp
  have h : env57717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57716_57717 : H12AffineEnvironment.transform 31 91335 env57716 = env57717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 91335 env57716 == env57717) = true)

theorem identity57717 : scanCanonicalize (H12AffineFastState.compose env57717 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12919239) := by decide +kernel

theorem selectedBound57717 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env57718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409088,12919239,16384,131153,4315354,8463815,91335,256,12686843,131072,33563273]

theorem envBound57718 : H12AffineFastState.Bounded env57718 := by
  intro p hp
  have h : env57718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57717_57718 : H12AffineEnvironment.transform 26 12919239 env57717 = env57718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12919239 env57717 == env57718) = true)

theorem identity57718 : scanCanonicalize (H12AffineFastState.compose env57718 (packedSelected [6,13,17,21,25,33] rootPS)) = affineNative (2^(24+1) ^^^ 28889) := by decide +kernel

theorem selectedBound57718 : packedSelected [6,13,17,21,25,33] rootPS < 2^1333 := by decide +kernel

def env57719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,28889,8409088,12919239,16384,131153,4315354,8463815,91335,256,12686843,131072,21072]

theorem envBound57719 : H12AffineFastState.Bounded env57719 := by
  intro p hp
  have h : env57719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57718_57719 : H12AffineEnvironment.transform 24 28889 env57718 = env57719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 28889 env57718 == env57719) = true)

def env57720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,8329,8388688,12919239,4176,131153,4294794,8463815,78999,256,12686843,131072,512]

theorem envBound57720 : H12AffineFastState.Bounded env57720 := by
  intro p hp
  have h : env57720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57719_57720 : H12AffineEnvironment.transform 13 4176 env57719 = env57720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env57719 == env57720) = true)

theorem identity57720 : scanCanonicalize (H12AffineFastState.compose env57720 (packedSelected [4,9,16] rootPS)) = affineNative (2^(16+1) ^^^ 78034) := by decide +kernel

theorem selectedBound57720 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78034,262144,1025,32768,2097152,4194304,8388608,8430023,8329,8388688,12919239,4176,77955,4294794,8463815,78999,256,12686843,78034,512]

theorem envBound57721 : H12AffineFastState.Bounded env57721 := by
  intro p hp
  have h : env57721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57720_57721 : H12AffineEnvironment.transform 16 78034 env57720 = env57721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78034 env57720 == env57721) = true)

theorem identity57721 : scanCanonicalize (H12AffineFastState.compose env57721 (packedSelected [13,21] rootPS)) = affineNative (2^(22+1) ^^^ 4240769) := by decide +kernel

theorem selectedBound57721 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78034,262144,1025,32768,2097152,4194304,4240769,4199494,8329,4240849,365638,4176,77955,4294794,4296774,78999,256,73850,78034,512]

theorem envBound57722 : H12AffineFastState.Bounded env57722 := by
  intro p hp
  have h : env57722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57721_57722 : H12AffineEnvironment.transform 22 4240769 env57721 = env57722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240769 env57721 == env57722) = true)

theorem identity57722 : scanCanonicalize (H12AffineFastState.compose env57722 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound57722 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env57723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78034,262144,1025,32768,2097152,33,46496,5223,8329,46576,365638,4176,77955,100523,102503,78999,256,73850,78034,512]

theorem envBound57723 : H12AffineFastState.Bounded env57723 := by
  intro p hp
  have h : env57723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57722_57723 : H12AffineEnvironment.transform 21 33 env57722 = env57723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env57722 == env57723) = true)

def env57724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,32768,65536,74814,262144,1025,32768,2097152,33,41292,139,8329,41244,360618,1212,74863,100523,99467,73851,256,73850,74814,512]

theorem envBound57724 : H12AffineFastState.Bounded env57724 := by
  intro p hp
  have h : env57724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57723_57724 : H12AffineEnvironment.transform 11 1260 env57723 = env57724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env57723 == env57724) = true)

theorem identity57724 : scanCanonicalize (H12AffineFastState.compose env57724 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 265917) := by decide +kernel

theorem selectedBound57724 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env57725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,32768,65536,74814,262144,1025,32768,265917,33,41292,139,8329,41244,360618,1212,74863,100523,99467,73851,256,73850,74814,512]

theorem envBound57725 : H12AffineFastState.Bounded env57725 := by
  intro p hp
  have h : env57725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57724_57725 : H12AffineEnvironment.transform 20 265917 env57724 = env57725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 265917 env57724 == env57725) = true)

theorem identity57725 : scanCanonicalize (H12AffineFastState.compose env57725 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound57725 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env57726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,32768,65536,74814,43048,1025,32768,42645,33,41292,139,8329,41244,75906,1212,74863,100523,99467,73851,256,73850,74814,512]

theorem envBound57726 : H12AffineFastState.Bounded env57726 := by
  intro p hp
  have h : env57726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57725_57726 : H12AffineEnvironment.transform 17 43048 env57725 = env57726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env57725 == env57726) = true)

theorem identity57726 : scanCanonicalize (H12AffineFastState.compose env57726 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound57726 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env57727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,32768,33167,42417,43048,1025,32768,42645,33,41292,139,8329,41244,43277,1212,42464,2340,1284,41460,256,41461,42417,512]

theorem envBound57727 : H12AffineFastState.Bounded env57727 := by
  intro p hp
  have h : env57727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57726_57727 : H12AffineEnvironment.transform 15 33167 env57726 = env57727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env57726 == env57727) = true)

def env57728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,8312,8695,1481,2128,1025,8312,1773,33,308,139,8329,356,2421,1212,1432,2340,1284,396,256,397,1481,512]

theorem envBound57728 : H12AffineFastState.Bounded env57728 := by
  intro p hp
  have h : env57728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57727_57728 : H12AffineEnvironment.transform 14 8312 env57727 = env57728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env57727 == env57728) = true)

theorem identity57728 : scanCanonicalize (H12AffineFastState.compose env57728 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound57728 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,2209,1212,2265,2390,1481,2128,1025,2265,1773,33,308,139,2088,356,2421,1212,1432,2340,1284,396,256,397,1481,512]

theorem envBound57729 : H12AffineFastState.Bounded env57729 := by
  intro p hp
  have h : env57729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57728_57729 : H12AffineEnvironment.transform 12 2209 env57728 = env57729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env57728 == env57729) = true)

def env57730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,8313,8694,1480,2129,1025,8313,1772,33,309,139,8329,357,2420,1212,1433,2340,1284,397,256,396,1480,512]

theorem envBound57730 : H12AffineFastState.Bounded env57730 := by
  intro p hp
  have h : env57730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57727_57730 : H12AffineEnvironment.transform 14 8313 env57727 = env57730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env57727 == env57730) = true)

theorem identity57730 : scanCanonicalize (H12AffineFastState.compose env57730 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2516) := by decide +kernel

theorem selectedBound57730 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,2516,1212,2477,2082,1480,2129,1025,2477,1772,33,309,139,2397,357,2420,1212,1433,2340,1284,397,256,396,1480,512]

theorem envBound57731 : H12AffineFastState.Bounded env57731 := by
  intro p hp
  have h : env57731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57730_57731 : H12AffineEnvironment.transform 12 2516 env57730 = env57731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2516 env57730 == env57731) = true)

def env57732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,32768,65536,74815,262144,1025,32768,2097152,33,41293,138,8329,41245,360619,1213,74862,100523,99466,73850,256,73850,74815,512]

theorem envBound57732 : H12AffineFastState.Bounded env57732 := by
  intro p hp
  have h : env57732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57723_57732 : H12AffineEnvironment.transform 11 1261 env57723 = env57732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1261 env57723 == env57732) = true)

theorem identity57732 : scanCanonicalize (H12AffineFastState.compose env57732 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 75546) := by decide +kernel

theorem selectedBound57732 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env57733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,32768,65536,74815,262144,1025,32768,75546,33,41293,138,8329,41245,360619,1213,74862,100523,99466,73850,256,73850,74815,512]

theorem envBound57733 : H12AffineFastState.Bounded env57733 := by
  intro p hp
  have h : env57733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57732_57733 : H12AffineEnvironment.transform 20 75546 env57732 = env57733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 75546 env57732 == env57733) = true)

theorem identity57733 : scanCanonicalize (H12AffineFastState.compose env57733 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 100522) := by decide +kernel

theorem selectedBound57733 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env57734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,32768,65536,74815,100522,1025,32768,75546,33,41293,138,8329,41245,2049,1213,74862,100523,99466,73850,256,73850,74815,512]

theorem envBound57734 : H12AffineFastState.Bounded env57734 := by
  intro p hp
  have h : env57734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57733_57734 : H12AffineEnvironment.transform 17 100522 env57733 = env57734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100522 env57733 == env57734) = true)

theorem identity57734 : scanCanonicalize (H12AffineFastState.compose env57734 (packedSelected [0,1,3,7,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound57734 : packedSelected [0,1,3,7,12,15] rootPS < 2^1333 := by decide +kernel

def env57735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,1,65536,74815,67755,1025,1,75546,33,8524,138,8329,8476,2049,1213,74862,67754,66699,73850,256,73850,74815,512]

theorem envBound57735 : H12AffineFastState.Bounded env57735 := by
  intro p hp
  have h : env57735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57734_57735 : H12AffineEnvironment.transform 14 1 env57734 = env57735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env57734 == env57735) = true)

def env57736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,8328,8388689,12919239,4177,131153,4294795,8463815,78998,256,12686843,131072,513]

theorem envBound57736 : H12AffineFastState.Bounded env57736 := by
  intro p hp
  have h : env57736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57719_57736 : H12AffineEnvironment.transform 13 4177 env57719 = env57736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57719 == env57736) = true)

theorem identity57736 : scanCanonicalize (H12AffineFastState.compose env57736 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound57736 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,396,8388608,8430023,8328,8388689,8724555,4177,131153,100615,8463815,78998,256,8492151,131072,513]

theorem envBound57737 : H12AffineFastState.Bounded env57737 := by
  intro p hp
  have h : env57737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57736_57737 : H12AffineEnvironment.transform 21 396 env57736 = env57737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env57736 == env57737) = true)

theorem identity57737 : scanCanonicalize (H12AffineFastState.compose env57737 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound57737 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,4097,396,8388608,8430023,8328,8388689,8724555,4177,131153,100615,8463815,78998,256,8492151,131072,513]

theorem envBound57738 : H12AffineFastState.Bounded env57738 := by
  intro p hp
  have h : env57738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57737_57738 : H12AffineEnvironment.transform 20 4097 env57737 = env57738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env57737 == env57738) = true)

theorem identity57738 : scanCanonicalize (H12AffineFastState.compose env57738 (packedSelected [13,21] rootPS)) = affineNative (2^(22+1) ^^^ 176412) := by decide +kernel

theorem selectedBound57738 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,4097,396,176412,135387,8328,176461,495959,4177,131153,100615,234715,78998,256,206187,131072,513]

theorem envBound57739 : H12AffineFastState.Bounded env57739 := by
  intro p hp
  have h : env57739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57738_57739 : H12AffineEnvironment.transform 22 176412 env57738 = env57739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 176412 env57738 == env57739) = true)

theorem identity57739 : scanCanonicalize (H12AffineFastState.compose env57739 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound57739 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env57740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,65536,131072,262144,1025,8461,4097,396,135185,135387,8328,135232,471130,4177,131153,75786,210390,78998,256,206187,131072,513]

theorem envBound57740 : H12AffineFastState.Bounded env57740 := by
  intro p hp
  have h : env57740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57739_57740 : H12AffineEnvironment.transform 14 8461 env57739 = env57740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env57739 == env57740) = true)

theorem identity57740 : scanCanonicalize (H12AffineFastState.compose env57740 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 1212) := by decide +kernel

theorem selectedBound57740 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env57741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,65536,1212,262144,1025,8461,4097,396,5293,5223,8328,5372,341222,4177,1261,75786,78186,78998,256,74199,1212,513]

theorem envBound57741 : H12AffineFastState.Bounded env57741 := by
  intro p hp
  have h : env57741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57740_57741 : H12AffineEnvironment.transform 16 1212 env57740 = env57741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1212 env57740 == env57741) = true)

theorem identity57741 : scanCanonicalize (H12AffineFastState.compose env57741 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 81127) := by decide +kernel

theorem selectedBound57741 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env57742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,65536,1212,81127,1025,8461,4097,396,5293,5223,8328,5372,2049,4177,1261,75786,78186,78998,256,74199,1212,513]

theorem envBound57742 : H12AffineFastState.Bounded env57742 := by
  intro p hp
  have h : env57742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57741_57742 : H12AffineEnvironment.transform 17 81127 env57741 = env57742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 81127 env57741 == env57742) = true)

theorem identity57742 : scanCanonicalize (H12AffineFastState.compose env57742 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound57742 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env57743 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,4177,8352,65536,1212,81127,1025,8352,4097,33,5293,5223,8328,5372,2049,4177,1261,75786,78023,78998,173,73850,1212,513]

theorem envBound57743 : H12AffineFastState.Bounded env57743 := by
  intro p hp
  have h : env57743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57742_57743 : H12AffineEnvironment.transform 7 173 env57742 = env57743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env57742 == env57743) = true)

theorem identity57743 : scanCanonicalize (H12AffineFastState.compose env57743 (packedSelected [0,2,5,7,8,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 1783) := by decide +kernel

theorem selectedBound57743 : packedSelected [0,2,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env57744 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1783,4096,8192,4177,8352,65536,1212,78352,1025,8352,4097,33,5293,5223,8328,5372,1782,4177,1261,75517,78023,78998,173,73850,1212,513]

theorem envBound57744 : H12AffineFastState.Bounded env57744 := by
  intro p hp
  have h : env57744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57743_57744 : H12AffineEnvironment.transform 10 1783 env57743 = env57744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1783 env57743 == env57744) = true)

theorem identity57744 : scanCanonicalize (H12AffineFastState.compose env57744 (packedSelected [0,2,5,6,7,8,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 1791) := by decide +kernel

theorem selectedBound57744 : packedSelected [0,2,5,6,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env57745 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1783,4096,8192,4177,8352,1791,1212,13551,1025,8352,4097,33,5293,5223,8328,5372,1782,4177,1261,8194,13880,12905,173,9861,1212,513]

theorem envBound57745 : H12AffineFastState.Bounded env57745 := by
  intro p hp
  have h : env57745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57744_57745 : H12AffineEnvironment.transform 15 1791 env57744 = env57745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1791 env57744 == env57745) = true)

theorem identity57745 : scanCanonicalize (H12AffineFastState.compose env57745 (packedSelected [0,2,3,6,7,8,10,11,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound57745 : packedSelected [0,2,3,6,7,8,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env57746 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1783,1212,8192,1261,8352,1791,1212,8275,1025,8352,1213,33,17,219,8328,64,1782,1261,1261,8194,8836,9941,173,9861,1212,513]

theorem envBound57746 : H12AffineFastState.Bounded env57746 := by
  intro p hp
  have h : env57746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57745_57746 : H12AffineEnvironment.transform 11 1212 env57745 = env57746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env57745 == env57746) = true)

theorem identity57746 : scanCanonicalize (H12AffineFastState.compose env57746 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound57746 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57747 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1783,1212,8,1261,168,1791,1212,91,1025,168,1213,33,17,219,128,64,1782,1261,1261,10,652,1757,173,1677,1212,513]

theorem envBound57747 : H12AffineFastState.Bounded env57747 := by
  intro p hp
  have h : env57747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57746_57747 : H12AffineEnvironment.transform 12 8 env57746 = env57747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env57746 == env57747) = true)

theorem identity57747 : scanCanonicalize (H12AffineFastState.compose env57747 (packedSelected [0,1,2,3,4,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound57747 : packedSelected [0,1,2,3,4,5,10] rootPS < 2^1333 := by decide +kernel

def env57748 : List Nat := [2,4,8,16,32,64,19,62,512,1024,1636,1071,8,1150,59,1644,1071,91,1025,59,1070,33,17,72,19,64,1637,1150,1150,10,543,1614,62,1566,1071,513]

theorem envBound57748 : H12AffineFastState.Bounded env57748 := by
  intro p hp
  have h : env57748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57747_57748 : H12AffineEnvironment.transform 6 19 env57747 = env57748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env57747 == env57748) = true)

theorem identity57748 : scanCanonicalize (H12AffineFastState.compose env57748 (packedSelected [3,4,5,7,8,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound57748 : packedSelected [3,4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env57749 : List Nat := [2,4,8,16,32,17,19,62,512,1024,1589,1071,8,1071,59,1597,1071,10,1025,59,1070,33,17,25,19,17,1588,1071,1071,10,543,1567,62,1566,1071,513]

theorem envBound57749 : H12AffineFastState.Bounded env57749 := by
  intro p hp
  have h : env57749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57748_57749 : H12AffineEnvironment.transform 5 17 env57748 = env57749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57748 == env57749) = true)

theorem identity57749 : scanCanonicalize (H12AffineFastState.compose env57749 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound57749 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env57750 : List Nat := [2,4,8,16,32,17,19,62,512,36,529,11,8,11,59,537,11,10,37,59,10,33,17,25,19,17,528,11,11,10,543,571,62,570,11,513]

theorem envBound57750 : H12AffineFastState.Bounded env57750 := by
  intro p hp
  have h : env57750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57749_57750 : H12AffineEnvironment.transform 9 36 env57749 = env57750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env57749 == env57750) = true)

def env57751 : List Nat := [2,4,8,16,32,17,19,62,0,36,17,11,8,11,59,25,11,10,37,59,10,33,17,25,19,17,16,11,11,10,31,59,62,58,11,1]

theorem envBound57751 : H12AffineFastState.Bounded env57751 := by
  intro p hp
  have h : env57751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57750_57751 : H12AffineEnvironment.transform 8 0 env57750 = env57751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57750 == env57751) = true)

theorem identity57751 : scanCanonicalize (H12AffineFastState.compose env57751 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound57751 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57752 : List Nat := [2,4,8,16,16,17,19,14,0,20,17,11,8,11,11,25,11,10,21,11,10,17,17,25,19,17,16,11,11,10,31,11,14,10,11,1]

theorem envBound57752 : H12AffineFastState.Bounded env57752 := by
  intro p hp
  have h : env57752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57751_57752 : H12AffineEnvironment.transform 4 16 env57751 = env57752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57751 == env57752) = true)

theorem identity57752 : scanCanonicalize (H12AffineFastState.compose env57752 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57752 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57753 : List Nat := [2,4,0,16,16,17,19,6,0,20,17,3,0,3,3,17,3,2,21,3,2,17,17,17,19,17,16,3,3,2,23,3,6,2,3,1]

theorem envBound57753 : H12AffineFastState.Bounded env57753 := by
  intro p hp
  have h : env57753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57752_57753 : H12AffineEnvironment.transform 2 0 env57752 = env57753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57752 == env57753) = true)

def leafEnv57753 : List Nat := [2,4,0,16,16,17,19,6,0,20,17,3,0,3,3,17,3,2,21,3,2,17,17,17,23,19,1,17,16,3,3,2,23,3,6,2,5,2,3,1,1,3,0]

def active57753 : List Nat := [0,1,3]

def tree57753 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood57753 : H12WitnessSearch.Good tree57753 := H12GlobalWitnessIndex.good

theorem leafIdentity57753 : H12AffineFastState.composeSystem env57753 rootObs = leafEnv57753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env57753 rootObs == leafEnv57753) = true)

theorem terminalChecked57753 : H12PackedTerminal.terminalCheckFast leafEnv57753 active57753 tree57753 = true := by decide +kernel

def env57754 : List Nat := [2,4,8,16,32,17,19,62,1,36,16,11,8,11,59,24,11,10,37,59,10,33,17,25,19,17,17,11,11,10,30,58,62,59,11,0]

theorem envBound57754 : H12AffineFastState.Bounded env57754 := by
  intro p hp
  have h : env57754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57750_57754 : H12AffineEnvironment.transform 8 1 env57750 = env57754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env57750 == env57754) = true)

theorem identity57754 : scanCanonicalize (H12AffineFastState.compose env57754 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57754 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57755 : List Nat := [2,4,8,16,10,17,19,20,1,14,16,11,8,11,17,24,11,10,15,17,10,11,17,25,19,17,17,11,11,10,30,16,20,17,11,0]

theorem envBound57755 : H12AffineFastState.Bounded env57755 := by
  intro p hp
  have h : env57755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57754_57755 : H12AffineEnvironment.transform 4 10 env57754 = env57755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57754 == env57755) = true)

theorem identity57755 : scanCanonicalize (H12AffineFastState.compose env57755 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57755 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57756 : List Nat := [0,4,8,16,8,17,17,20,1,12,16,9,8,9,17,24,9,8,13,17,8,9,17,25,17,17,17,9,9,8,28,16,20,17,9,0]

theorem envBound57756 : H12AffineFastState.Bounded env57756 := by
  intro p hp
  have h : env57756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57755_57756 : H12AffineEnvironment.transform 0 0 env57755 = env57756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57755 == env57756) = true)

def env57757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16384,131153,4315354,8463815,4294967296,256,4307611964,131073,33563273]

theorem envBound57757 : H12AffineFastState.Bounded env57757 := by
  intro p hp
  have h : env57757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57715_57757 : H12AffineEnvironment.transform 34 131073 env57715 = env57757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env57715 == env57757) = true)

theorem identity57757 : scanCanonicalize (H12AffineFastState.compose env57757 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 2192583) := by decide +kernel

theorem selectedBound57757 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env57758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16384,131153,4315354,8463815,2192583,256,14779899,131073,33563273]

theorem envBound57758 : H12AffineFastState.Bounded env57758 := by
  intro p hp
  have h : env57758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57757_57758 : H12AffineEnvironment.transform 31 2192583 env57757 = env57758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2192583 env57757 == env57758) = true)

theorem identity57758 : scanCanonicalize (H12AffineFastState.compose env57758 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound57758 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env57759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8388689,134217728,4177,131153,4294795,8463815,2172054,256,14779899,131073,33563273]

theorem envBound57759 : H12AffineFastState.Bounded env57759 := by
  intro p hp
  have h : env57759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57758_57759 : H12AffineEnvironment.transform 13 4177 env57758 = env57759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env57758 == env57759) = true)

theorem identity57759 : scanCanonicalize (H12AffineFastState.compose env57759 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound57759 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env57760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,8328,8388689,134217728,4177,131153,4294795,8463815,2172054,256,14779899,131073,513]

theorem envBound57760 : H12AffineFastState.Bounded env57760 := by
  intro p hp
  have h : env57760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57759_57760 : H12AffineEnvironment.transform 24 8328 env57759 = env57760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env57759 == env57760) = true)

theorem identity57760 : scanCanonicalize (H12AffineFastState.compose env57760 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 8724555) := by decide +kernel

theorem selectedBound57760 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,8328,8388689,8724555,4177,131153,4294795,8463815,2172054,256,14779899,131073,513]

theorem envBound57761 : H12AffineFastState.Bounded env57761 := by
  intro p hp
  have h : env57761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57760_57761 : H12AffineEnvironment.transform 26 8724555 env57760 = env57761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8724555 env57760 == env57761) = true)

theorem identity57761 : scanCanonicalize (H12AffineFastState.compose env57761 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound57761 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,4097,4194304,8388608,8430023,8328,8388689,8724555,4177,131153,4294795,8463815,78999,256,12686842,131073,513]

theorem envBound57762 : H12AffineFastState.Bounded env57762 := by
  intro p hp
  have h : env57762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57761_57762 : H12AffineEnvironment.transform 20 4097 env57761 = env57762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env57761 == env57762) = true)

theorem identity57762 : scanCanonicalize (H12AffineFastState.compose env57762 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4370576) := by decide +kernel

theorem selectedBound57762 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env57763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,4097,4194304,4370576,4329815,8328,4370625,4690139,4177,131153,4294795,4429143,78999,256,206186,131073,513]

theorem envBound57763 : H12AffineFastState.Bounded env57763 := by
  intro p hp
  have h : env57763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57762_57763 : H12AffineEnvironment.transform 22 4370576 env57762 = env57763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4370576 env57762 == env57763) = true)

theorem identity57763 : scanCanonicalize (H12AffineFastState.compose env57763 (packedSelected [6,25] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound57763 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env57764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,4097,396,176412,135387,8328,176461,495959,4177,131153,100615,234715,78999,256,206186,131073,513]

theorem envBound57764 : H12AffineFastState.Bounded env57764 := by
  intro p hp
  have h : env57764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57763_57764 : H12AffineEnvironment.transform 21 396 env57763 = env57764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env57763 == env57764) = true)

theorem identity57764 : scanCanonicalize (H12AffineFastState.compose env57764 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound57764 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env57765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,65536,131072,262144,1025,8460,4097,396,135184,135387,8328,135233,471131,4177,131153,75787,210391,78999,256,206186,131073,513]

theorem envBound57765 : H12AffineFastState.Bounded env57765 := by
  intro p hp
  have h : env57765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57764_57765 : H12AffineEnvironment.transform 14 8460 env57764 = env57765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env57764 == env57765) = true)

theorem identity57765 : scanCanonicalize (H12AffineFastState.compose env57765 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 1212) := by decide +kernel

theorem selectedBound57765 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env57766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,65536,1212,262144,1025,8460,4097,396,5292,5223,8328,5373,341223,4177,1261,75787,78187,78999,256,74198,1213,513]

theorem envBound57766 : H12AffineFastState.Bounded env57766 := by
  intro p hp
  have h : env57766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57765_57766 : H12AffineEnvironment.transform 16 1212 env57765 = env57766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1212 env57765 == env57766) = true)

theorem identity57766 : scanCanonicalize (H12AffineFastState.compose env57766 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 75786) := by decide +kernel

theorem selectedBound57766 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env57767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,65536,1212,75786,1025,8460,4097,396,5292,5223,8328,5373,7405,4177,1261,75787,78187,78999,256,74198,1213,513]

theorem envBound57767 : H12AffineFastState.Bounded env57767 := by
  intro p hp
  have h : env57767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57766_57767 : H12AffineEnvironment.transform 17 75786 env57766 = env57767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75786 env57766 == env57767) = true)

theorem identity57767 : scanCanonicalize (H12AffineFastState.compose env57767 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound57767 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env57768 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,4177,8353,65536,1212,75786,1025,8353,4097,33,5292,5223,8328,5373,7405,4177,1261,75787,78022,78999,173,73851,1213,513]

theorem envBound57768 : H12AffineFastState.Bounded env57768 := by
  intro p hp
  have h : env57768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57767_57768 : H12AffineEnvironment.transform 7 173 env57767 = env57768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env57767 == env57768) = true)

theorem identity57768 : scanCanonicalize (H12AffineFastState.compose env57768 (packedSelected [0,5,6,7,8,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1710) := by decide +kernel

theorem selectedBound57768 : packedSelected [0,5,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env57769 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,4177,8353,1710,1212,11940,1025,8353,4097,33,5292,5223,8328,5373,7405,4177,1261,11941,13928,12857,173,9941,1213,513]

theorem envBound57769 : H12AffineFastState.Bounded env57769 := by
  intro p hp
  have h : env57769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57768_57769 : H12AffineEnvironment.transform 15 1710 env57768 = env57769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1710 env57768 == env57769) = true)

theorem identity57769 : scanCanonicalize (H12AffineFastState.compose env57769 (packedSelected [0,3,6,7,8,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound57769 : packedSelected [0,3,6,7,8,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env57770 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1703,4096,8192,4177,8353,1710,1212,8195,1025,8353,4097,33,5292,5223,8328,5373,4682,4177,1261,8194,13928,12857,173,9941,1213,513]

theorem envBound57770 : H12AffineFastState.Bounded env57770 := by
  intro p hp
  have h : env57770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57769_57770 : H12AffineEnvironment.transform 10 1703 env57769 = env57770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env57769 == env57770) = true)

theorem identity57770 : scanCanonicalize (H12AffineFastState.compose env57770 (packedSelected [3,5,6,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1261) := by decide +kernel

theorem selectedBound57770 : packedSelected [3,5,6,10,13,17] rootPS < 2^1333 := by decide +kernel

def env57771 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1703,1261,8192,1212,8353,1710,1212,8195,1025,8353,1260,33,65,138,8328,16,1703,1212,1261,8194,8837,9940,173,9941,1213,513]

theorem envBound57771 : H12AffineFastState.Bounded env57771 := by
  intro p hp
  have h : env57771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57770_57771 : H12AffineEnvironment.transform 11 1261 env57770 = env57771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1261 env57770 == env57771) = true)

theorem identity57771 : scanCanonicalize (H12AffineFastState.compose env57771 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound57771 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env57772 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1703,1212,8192,1212,8353,1710,1212,8195,1025,8353,1213,33,16,138,8328,16,1703,1212,1212,8194,8837,9861,173,9860,1213,513]

theorem envBound57772 : H12AffineFastState.Bounded env57772 := by
  intro p hp
  have h : env57772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57771_57772 : H12AffineEnvironment.transform 5 17 env57771 = env57772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57771 == env57772) = true)

theorem identity57772 : scanCanonicalize (H12AffineFastState.compose env57772 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound57772 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env57773 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1703,1212,8,1212,169,1710,1212,11,1025,169,1213,33,16,138,128,16,1703,1212,1212,10,653,1677,173,1676,1213,513]

theorem envBound57773 : H12AffineFastState.Bounded env57773 := by
  intro p hp
  have h : env57773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57772_57773 : H12AffineEnvironment.transform 12 8 env57772 = env57773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env57772 == env57773) = true)

theorem identity57773 : scanCanonicalize (H12AffineFastState.compose env57773 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound57773 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env57774 : List Nat := [2,4,8,16,32,17,128,173,26,1024,1213,1212,8,1212,169,1204,1212,11,1025,169,1213,33,16,138,128,16,1213,1212,1212,10,151,1175,173,1174,1213,27]

theorem envBound57774 : H12AffineFastState.Bounded env57774 := by
  intro p hp
  have h : env57774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57773_57774 : H12AffineEnvironment.transform 8 26 env57773 = env57774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env57773 == env57774) = true)

theorem identity57774 : scanCanonicalize (H12AffineFastState.compose env57774 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound57774 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env57775 : List Nat := [2,4,8,16,32,17,128,173,26,62,131,130,8,130,169,138,130,11,63,169,131,33,16,138,128,16,131,130,130,10,151,169,173,168,131,27]

theorem envBound57775 : H12AffineFastState.Bounded env57775 := by
  intro p hp
  have h : env57775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57774_57775 : H12AffineEnvironment.transform 9 62 env57774 = env57775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env57774 == env57775) = true)

theorem identity57775 : scanCanonicalize (H12AffineFastState.compose env57775 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57775 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57776 : List Nat := [2,4,8,10,32,11,128,173,0,36,131,130,8,130,169,138,130,11,37,169,131,33,10,138,128,10,131,130,130,10,141,169,173,168,131,1]

theorem envBound57776 : H12AffineFastState.Bounded env57776 := by
  intro p hp
  have h : env57776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57775_57776 : H12AffineEnvironment.transform 3 10 env57775 = env57776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57775 == env57776) = true)

theorem identity57776 : scanCanonicalize (H12AffineFastState.compose env57776 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57776 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57777 : List Nat := [2,4,8,10,10,11,128,135,0,14,131,130,8,130,131,138,130,11,15,131,131,11,10,138,128,10,131,130,130,10,141,131,135,130,131,1]

theorem envBound57777 : H12AffineFastState.Bounded env57777 := by
  intro p hp
  have h : env57777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57776_57777 : H12AffineEnvironment.transform 4 10 env57776 = env57777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57776 == env57777) = true)

theorem identity57777 : scanCanonicalize (H12AffineFastState.compose env57777 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57777 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57778 : List Nat := [2,4,0,2,2,3,128,135,0,6,131,130,0,130,131,130,130,3,7,131,131,3,2,130,128,2,131,130,130,2,133,131,135,130,131,1]

theorem envBound57778 : H12AffineFastState.Bounded env57778 := by
  intro p hp
  have h : env57778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57777_57778 : H12AffineEnvironment.transform 2 0 env57777 = env57778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57777 == env57778) = true)

def leafEnv57778 : List Nat := [2,4,0,2,2,3,128,135,0,6,131,130,0,130,131,130,130,3,7,131,131,3,2,130,133,128,1,2,131,130,130,2,133,131,135,130,5,2,131,1,1,131,0]

def active57778 : List Nat := [0,1,6]

def tree57778 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood57778 : H12WitnessSearch.Good tree57778 := H12GlobalWitnessIndex.good

theorem leafIdentity57778 : H12AffineFastState.composeSystem env57778 rootObs = leafEnv57778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env57778 rootObs == leafEnv57778) = true)

theorem terminalChecked57778 : H12PackedTerminal.terminalCheckFast leafEnv57778 active57778 tree57778 = true := by decide +kernel

def env57779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955334,33554432,8409089,134217728,16384,656465,4840666,8463815,4294967296,525569,4307611965,34359738368,33563273]

theorem envBound57779 : H12AffineFastState.Bounded env57779 := by
  intro p hp
  have h : env57779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56762_57779 : H12AffineEnvironment.transform 25 8409089 env56762 = env57779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8409089 env56762 == env57779) = true)

def env57780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16384,131153,4315354,8463815,4294967296,257,4307611965,34359738368,33563273]

theorem envBound57780 : H12AffineFastState.Bounded env57780 := by
  intro p hp
  have h : env57780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57779_57780 : H12AffineEnvironment.transform 18 1024 env57779 = env57780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env57779 == env57780) = true)

def env57781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16384,131153,4315354,8463815,4294967296,257,4307611965,131072,33563273]

theorem envBound57781 : H12AffineFastState.Bounded env57781 := by
  intro p hp
  have h : env57781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57780_57781 : H12AffineEnvironment.transform 34 131072 env57780 = env57781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env57780 == env57781) = true)

theorem identity57781 : scanCanonicalize (H12AffineFastState.compose env57781 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 221575) := by decide +kernel

theorem selectedBound57781 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env57782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16384,131153,4315354,8463815,221575,257,12816570,131072,33563273]

theorem envBound57782 : H12AffineFastState.Bounded env57782 := by
  intro p hp
  have h : env57782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57781_57782 : H12AffineEnvironment.transform 31 221575 env57781 = env57782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 221575 env57781 == env57782) = true)

theorem identity57782 : scanCanonicalize (H12AffineFastState.compose env57782 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12992837) := by decide +kernel

theorem selectedBound57782 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env57783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409089,12992837,16384,131153,4315354,8463815,221575,257,12816570,131072,33563273]

theorem envBound57783 : H12AffineFastState.Bounded env57783 := by
  intro p hp
  have h : env57783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57782_57783 : H12AffineEnvironment.transform 26 12992837 env57782 = env57783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12992837 env57782 == env57783) = true)

def env57784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,6329752,6304862,33554432,6342041,2544861,16384,131153,4315354,6402143,221575,257,2295074,131072,33563273]

theorem envBound57784 : H12AffineFastState.Bounded env57784 := by
  intro p hp
  have h : env57784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57783_57784 : H12AffineEnvironment.transform 22 6329752 env57783 = env57784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329752 env57783 == env57784) = true)

def env57785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,6329752,6304862,4247640,6342041,2544861,16384,131153,4315354,6402143,221575,257,2295074,131072,4256465]

theorem envBound57785 : H12AffineFastState.Bounded env57785 := by
  intro p hp
  have h : env57785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57784_57785 : H12AffineEnvironment.transform 24 4247640 env57784 = env57785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247640 env57784 == env57785) = true)

def env57786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269392,144712,169102,2257032,157001,2544861,16384,131153,2324490,200847,221575,257,2295074,131072,2249217]

theorem envBound57786 : H12AffineFastState.Bounded env57786 := by
  intro p hp
  have h : env57786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57785_57786 : H12AffineEnvironment.transform 21 2269392 env57785 = env57786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269392 env57785 == env57786) = true)

def env57787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46480,144712,169102,26056,157001,311709,16384,131153,93514,200847,221575,257,69730,131072,18241]

theorem envBound57787 : H12AffineFastState.Bounded env57787 := by
  intro p hp
  have h : env57787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57786_57787 : H12AffineEnvironment.transform 20 136512 env57786 = env57787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env57786 == env57787) = true)

end H12CloudChart1