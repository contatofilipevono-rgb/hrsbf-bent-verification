import H12CloudChart1Data035

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity8949 : scanCanonicalize (H12AffineFastState.compose env8949 (packedSelected [1,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8949 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env8950 : List Nat := [2,4,8,16,32,17,41,5,33,4,2048,4096,6168,16,6161,6194,4096,11,4116,6161,16,32,4096,34,6200,4096,43,4097,4096,2081,4,0,4117,1,4096,33]

theorem envBound8950 : H12AffineFastState.Bounded env8950 := by
  intro p hp
  have h : env8950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8949_8950 : H12AffineEnvironment.transform 5 17 env8949 = env8950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8949 == env8950) = true)

theorem identity8950 : scanCanonicalize (H12AffineFastState.compose env8950 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8950 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8951 : List Nat := [2,4,8,16,17,17,24,5,16,4,2048,4096,6168,16,6161,6147,4096,11,4116,6161,16,17,4096,19,6153,4096,26,4097,4096,2064,4,0,4117,1,4096,16]

theorem envBound8951 : H12AffineFastState.Bounded env8951 := by
  intro p hp
  have h : env8951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8950_8951 : H12AffineEnvironment.transform 4 17 env8950 = env8951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8950 == env8951) = true)

theorem identity8951 : scanCanonicalize (H12AffineFastState.compose env8951 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound8951 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8952 : List Nat := [2,4,8,16,17,17,24,5,16,4,27,4096,4099,16,4106,4120,4096,11,4116,4106,16,17,4096,19,4114,4096,26,4097,4096,11,4,0,4117,1,4096,16]

theorem envBound8952 : H12AffineFastState.Bounded env8952 := by
  intro p hp
  have h : env8952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8951_8952 : H12AffineEnvironment.transform 10 27 env8951 = env8952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env8951 == env8952) = true)

theorem identity8952 : scanCanonicalize (H12AffineFastState.compose env8952 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8952 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8953 : List Nat := [2,4,8,0,1,1,8,5,0,4,11,4096,4099,0,4106,4104,4096,11,4100,4106,0,1,4096,3,4098,4096,10,4097,4096,11,4,0,4101,1,4096,0]

theorem envBound8953 : H12AffineFastState.Bounded env8953 := by
  intro p hp
  have h : env8953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8952_8953 : H12AffineEnvironment.transform 3 0 env8952 = env8953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8952 == env8953) = true)

theorem identity8953 : scanCanonicalize (H12AffineFastState.compose env8953 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 10) := by decide +kernel

theorem selectedBound8953 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8954 : List Nat := [2,4,8,0,1,1,8,5,0,4,11,10,9,0,0,2,10,11,14,0,0,1,10,3,8,10,10,11,10,11,4,0,15,1,10,0]

theorem envBound8954 : H12AffineFastState.Bounded env8954 := by
  intro p hp
  have h : env8954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8953_8954 : H12AffineEnvironment.transform 11 10 env8953 = env8954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 10 env8953 == env8954) = true)

theorem identity8954 : scanCanonicalize (H12AffineFastState.compose env8954 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8954 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8955 : List Nat := [2,4,2,0,1,1,2,5,0,4,1,0,3,0,0,2,0,1,4,0,0,1,0,3,2,0,0,1,0,1,4,0,5,1,0,0]

theorem envBound8955 : H12AffineFastState.Bounded env8955 := by
  intro p hp
  have h : env8955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8954_8955 : H12AffineEnvironment.transform 2 2 env8954 = env8955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8954 == env8955) = true)

def env8956 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524524,90337,8329,21040,807680,4735912,4735572,605035,529048,4796990,524289,602955,2695634,90942]

theorem envBound8956 : H12AffineFastState.Bounded env8956 := by
  intro p hp
  have h : env8956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8789_8956 : H12AffineEnvironment.transform 23 90337 env8789 = env8956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env8789 == env8956) = true)

def env8957 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,4960,8692,2097152,4194304,5004,90337,8329,21040,278624,4214984,4215092,75787,504,4268382,4961,73771,2175666,90942]

theorem envBound8957 : H12AffineFastState.Bounded env8957 := by
  intro p hp
  have h : env8957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8956_8957 : H12AffineEnvironment.transform 18 4960 env8956 = env8957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env8956 == env8957) = true)

theorem identity8957 : scanCanonicalize (H12AffineFastState.compose env8957 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound8957 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8958 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24771,4605,262144,4960,8692,2097152,4194304,5004,34,8329,21040,278624,4214984,4215092,18632,504,4211101,4961,16616,2118257,1021]

theorem envBound8958 : H12AffineFastState.Bounded env8958 := by
  intro p hp
  have h : env8958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8957_8958 : H12AffineEnvironment.transform 15 24771 env8957 = env8958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env8957 == env8958) = true)

def env8959 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24771,4605,262144,4960,8692,64,4194304,5004,34,8329,21040,278624,4214984,4215092,18632,504,4211101,4961,16616,21041,1021]

theorem envBound8959 : H12AffineFastState.Bounded env8959 := by
  intro p hp
  have h : env8959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8958_8959 : H12AffineEnvironment.transform 20 64 env8958 = env8959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8958 == env8959) = true)

theorem identity8959 : scanCanonicalize (H12AffineFastState.compose env8959 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 17350) := by decide +kernel

theorem selectedBound8959 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8960 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24771,4605,17350,4960,8692,64,4194304,5004,34,8329,21040,934,4214984,4215092,18632,504,4211101,4961,16616,21041,1021]

theorem envBound8960 : H12AffineFastState.Bounded env8960 := by
  intro p hp
  have h : env8960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8959_8960 : H12AffineEnvironment.transform 17 17350 env8959 = env8960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17350 env8959 == env8960) = true)

def env8961 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,232,8692,8235,4605,814,4960,8692,64,4194304,5004,34,8329,4824,934,4198432,4198876,2080,504,4194677,4961,0,4825,1021]

theorem envBound8961 : H12AffineFastState.Bounded env8961 := by
  intro p hp
  have h : env8961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8960_8961 : H12AffineEnvironment.transform 13 232 env8960 = env8961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env8960 == env8961) = true)

theorem identity8961 : scanCanonicalize (H12AffineFastState.compose env8961 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound8961 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8962 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,232,8692,8235,4605,814,4960,8692,64,476,5004,34,8329,4824,934,4604,4096,2080,504,169,4961,0,4825,1021]

theorem envBound8962 : H12AffineFastState.Bounded env8962 := by
  intro p hp
  have h : env8962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8961_8962 : H12AffineEnvironment.transform 21 476 env8961 = env8962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env8961 == env8962) = true)

theorem identity8962 : scanCanonicalize (H12AffineFastState.compose env8962 (packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS)) = affineNative (2^(11+1) ^^^ 2155) := by decide +kernel

theorem selectedBound8962 : packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env8963 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,2155,8192,232,8692,8235,2454,814,2827,8692,64,476,3047,34,8329,2739,934,2455,2155,2080,504,169,2826,0,2738,1021]

theorem envBound8963 : H12AffineFastState.Bounded env8963 := by
  intro p hp
  have h : env8963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8962_8963 : H12AffineEnvironment.transform 11 2155 env8962 = env8963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2155 env8962 == env8963) = true)

theorem identity8963 : scanCanonicalize (H12AffineFastState.compose env8963 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(10+1) ^^^ 935) := by decide +kernel

theorem selectedBound8963 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env8964 : List Nat := [2,4,8,16,32,64,128,256,512,257,935,972,8192,232,8692,8235,561,814,172,8692,64,476,64,34,8329,276,934,560,972,903,504,169,173,0,277,1021]

theorem envBound8964 : H12AffineFastState.Bounded env8964 := by
  intro p hp
  have h : env8964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8963_8964 : H12AffineEnvironment.transform 10 935 env8963 = env8964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 935 env8963 == env8964) = true)

theorem identity8964 : scanCanonicalize (H12AffineFastState.compose env8964 (packedSelected [1,3,4,9,12,13,15,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8964 : packedSelected [1,3,4,9,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env8965 : List Nat := [2,4,8,16,32,64,128,4,512,5,675,712,8192,232,8432,8235,561,554,172,8432,64,216,64,34,8329,16,674,560,712,643,252,169,173,0,17,761]

theorem envBound8965 : H12AffineFastState.Bounded env8965 := by
  intro p hp
  have h : env8965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8964_8965 : H12AffineEnvironment.transform 7 4 env8964 = env8965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8964 == env8965) = true)

theorem identity8965 : scanCanonicalize (H12AffineFastState.compose env8965 (packedSelected [1,2,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound8965 : packedSelected [1,2,8,11] rootPS < 2^1333 := by decide +kernel

def env8966 : List Nat := [2,4,8,16,32,64,128,4,512,5,675,712,138,232,122,161,561,554,172,122,64,216,64,34,3,16,674,560,712,643,252,169,173,0,17,761]

theorem envBound8966 : H12AffineFastState.Bounded env8966 := by
  intro p hp
  have h : env8966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8965_8966 : H12AffineEnvironment.transform 12 138 env8965 = env8966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env8965 == env8966) = true)

theorem identity8966 : scanCanonicalize (H12AffineFastState.compose env8966 (packedSelected [0,1,5,7,10,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 178) := by decide +kernel

theorem selectedBound8966 : packedSelected [0,1,5,7,10,12,13] rootPS < 2^1333 := by decide +kernel

def env8967 : List Nat := [2,4,8,16,32,64,128,4,178,5,17,122,138,232,122,161,131,152,172,122,64,216,64,34,3,16,16,130,122,49,252,169,173,0,17,75]

theorem envBound8967 : H12AffineFastState.Bounded env8967 := by
  intro p hp
  have h : env8967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8966_8967 : H12AffineEnvironment.transform 8 178 env8966 = env8967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 178 env8966 == env8967) = true)

theorem identity8967 : scanCanonicalize (H12AffineFastState.compose env8967 (packedSelected [1,3,4,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8967 : packedSelected [1,3,4,7,10] rootPS < 2^1333 := by decide +kernel

def env8968 : List Nat := [2,4,8,16,32,17,128,4,178,5,17,43,138,185,43,161,131,152,172,43,17,137,17,34,3,16,16,130,43,49,173,169,173,0,17,26]

theorem envBound8968 : H12AffineFastState.Bounded env8968 := by
  intro p hp
  have h : env8968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8967_8968 : H12AffineEnvironment.transform 5 17 env8967 = env8968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8967 == env8968) = true)

theorem identity8968 : scanCanonicalize (H12AffineFastState.compose env8968 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8968 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env8969 : List Nat := [2,4,8,16,32,17,41,4,27,5,17,43,35,16,43,8,42,49,5,43,17,32,17,34,3,16,16,43,43,49,4,0,4,0,17,26]

theorem envBound8969 : H12AffineFastState.Bounded env8969 := by
  intro p hp
  have h : env8969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8968_8969 : H12AffineEnvironment.transform 6 41 env8968 = env8969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8968 == env8969) = true)

theorem identity8969 : scanCanonicalize (H12AffineFastState.compose env8969 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound8969 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8970 : List Nat := [2,4,8,16,21,17,28,4,27,5,17,30,22,16,30,8,31,4,5,30,17,21,17,23,3,16,16,30,30,4,4,0,4,0,17,26]

theorem envBound8970 : H12AffineFastState.Bounded env8970 := by
  intro p hp
  have h : env8970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8969_8970 : H12AffineEnvironment.transform 4 21 env8969 = env8970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env8969 == env8970) = true)

theorem identity8970 : scanCanonicalize (H12AffineFastState.compose env8970 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8970 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8971 : List Nat := [2,0,8,16,17,17,24,0,27,1,17,26,18,16,26,8,27,0,1,26,17,17,17,19,3,16,16,26,26,0,0,0,0,0,17,26]

theorem envBound8971 : H12AffineFastState.Bounded env8971 := by
  intro p hp
  have h : env8971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8970_8971 : H12AffineEnvironment.transform 1 0 env8970 = env8971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8970 == env8971) = true)

theorem identity8971 : scanCanonicalize (H12AffineFastState.compose env8971 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8971 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8972 : List Nat := [2,0,8,0,1,1,8,0,11,1,1,10,2,0,10,8,11,0,1,10,1,1,1,3,3,0,0,10,10,0,0,0,0,0,1,10]

theorem envBound8972 : H12AffineFastState.Bounded env8972 := by
  intro p hp
  have h : env8972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8971_8972 : H12AffineEnvironment.transform 3 0 env8971 = env8972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8971 == env8972) = true)

theorem identity8972 : scanCanonicalize (H12AffineFastState.compose env8972 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8972 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8973 : List Nat := [2,0,2,0,1,1,2,0,1,1,1,0,2,0,0,2,1,0,1,0,1,1,1,3,3,0,0,0,0,0,0,0,0,0,1,0]

theorem envBound8973 : H12AffineFastState.Bounded env8973 := by
  intro p hp
  have h : env8973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8972_8973 : H12AffineEnvironment.transform 2 2 env8972 = env8973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8972 == env8973) = true)

def env8974 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,233,8692,8234,4605,815,4960,8692,64,4194304,5004,34,8329,4825,934,4198433,4198877,2081,504,4194676,4961,1,4824,1021]

theorem envBound8974 : H12AffineFastState.Bounded env8974 := by
  intro p hp
  have h : env8974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8960_8974 : H12AffineEnvironment.transform 13 233 env8960 = env8974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env8960 == env8974) = true)

theorem identity8974 : scanCanonicalize (H12AffineFastState.compose env8974 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8974 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8975 : List Nat := [2,4,8,16,32,64,128,85,512,84,2048,4096,8192,233,8353,8234,4264,634,4661,8353,64,4194304,4825,34,8329,4825,755,4198433,4198536,2081,173,4194337,4660,1,4824,680]

theorem envBound8975 : H12AffineFastState.Bounded env8975 := by
  intro p hp
  have h : env8975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8974_8975 : H12AffineEnvironment.transform 7 85 env8974 = env8975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8974 == env8975) = true)

theorem identity8975 : scanCanonicalize (H12AffineFastState.compose env8975 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(11+1) ^^^ 2243) := by decide +kernel

theorem selectedBound8975 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env8976 : List Nat := [2,4,8,16,32,64,128,85,512,84,2048,2243,8192,233,8353,8234,2155,634,2806,8353,64,4194304,2586,34,8329,2586,755,4196578,4196427,2081,173,4194337,2807,1,2587,680]

theorem envBound8976 : H12AffineFastState.Bounded env8976 := by
  intro p hp
  have h : env8976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8975_8976 : H12AffineEnvironment.transform 11 2243 env8975 = env8976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2243 env8975 == env8976) = true)

theorem identity8976 : scanCanonicalize (H12AffineFastState.compose env8976 (packedSelected [1,3,4,7,9,12,14,15,27] rootPS)) = affineNative (2^(21+1) ^^^ 136) := by decide +kernel

theorem selectedBound8976 : packedSelected [1,3,4,7,9,12,14,15,27] rootPS < 2^1333 := by decide +kernel

def env8977 : List Nat := [2,4,8,16,32,64,128,85,512,84,2048,2243,8192,233,8353,8234,2155,634,2806,8353,64,136,2586,34,8329,2586,755,2154,2243,2081,173,169,2807,1,2587,680]

theorem envBound8977 : H12AffineFastState.Bounded env8977 := by
  intro p hp
  have h : env8977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8976_8977 : H12AffineEnvironment.transform 21 136 env8976 = env8977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env8976 == env8977) = true)

theorem identity8977 : scanCanonicalize (H12AffineFastState.compose env8977 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound8977 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env8978 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,2243,8192,233,8353,8234,2155,163,2095,8353,64,136,2243,34,8329,2243,42,2154,2243,2081,173,169,2094,1,2242,113]

theorem envBound8978 : H12AffineFastState.Bounded env8978 := by
  intro p hp
  have h : env8978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8977_8978 : H12AffineEnvironment.transform 8 217 env8977 = env8978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8977 == env8978) = true)

theorem identity8978 : scanCanonicalize (H12AffineFastState.compose env8978 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8978 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8979 : List Nat := [2,4,8,16,32,64,120,85,33,84,2048,2107,8192,17,8281,8234,2155,91,2095,8281,64,112,2107,34,8305,2107,42,2154,2107,2081,85,81,2094,1,2106,113]

theorem envBound8979 : H12AffineFastState.Bounded env8979 := by
  intro p hp
  have h : env8979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8978_8979 : H12AffineEnvironment.transform 6 120 env8978 = env8979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8978 == env8979) = true)

theorem identity8979 : scanCanonicalize (H12AffineFastState.compose env8979 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 83) := by decide +kernel

theorem selectedBound8979 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env8980 : List Nat := [2,4,8,16,32,64,120,85,33,84,2048,2107,83,17,10,121,2155,91,2095,10,64,112,2107,34,34,2107,42,2154,2107,2081,85,81,2094,1,2106,113]

theorem envBound8980 : H12AffineFastState.Bounded env8980 := by
  intro p hp
  have h : env8980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8979_8980 : H12AffineEnvironment.transform 12 83 env8979 = env8980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 83 env8979 == env8980) = true)

theorem identity8980 : scanCanonicalize (H12AffineFastState.compose env8980 (packedSelected [0,1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound8980 : packedSelected [0,1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env8981 : List Nat := [2,4,8,16,32,0,56,21,33,20,2048,2107,19,17,10,57,2091,27,2095,10,0,48,2107,34,34,2107,42,2090,2107,2081,21,17,2094,1,2106,49]

theorem envBound8981 : H12AffineFastState.Bounded env8981 := by
  intro p hp
  have h : env8981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8980_8981 : H12AffineEnvironment.transform 5 0 env8980 = env8981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8980 == env8981) = true)

theorem identity8981 : scanCanonicalize (H12AffineFastState.compose env8981 (packedSelected [1,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound8981 : packedSelected [1,5,9] rootPS < 2^1333 := by decide +kernel

def env8982 : List Nat := [2,4,8,16,32,0,56,21,33,20,43,16,19,17,10,57,0,27,4,10,0,48,16,34,34,16,42,1,16,10,21,17,5,1,17,49]

theorem envBound8982 : H12AffineFastState.Bounded env8982 := by
  intro p hp
  have h : env8982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8981_8982 : H12AffineEnvironment.transform 10 43 env8981 = env8982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env8981 == env8982) = true)

theorem identity8982 : scanCanonicalize (H12AffineFastState.compose env8982 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8982 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8983 : List Nat := [2,4,8,0,32,0,40,5,33,4,43,0,3,1,10,41,0,11,4,10,0,32,0,34,34,0,42,1,0,10,5,1,5,1,1,33]

theorem envBound8983 : H12AffineFastState.Bounded env8983 := by
  intro p hp
  have h : env8983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8982_8983 : H12AffineEnvironment.transform 3 0 env8982 = env8983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8982 == env8983) = true)

theorem identity8983 : scanCanonicalize (H12AffineFastState.compose env8983 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8983 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8984 : List Nat := [2,4,8,0,10,0,2,5,11,4,1,0,3,1,10,3,0,11,4,10,0,10,0,8,8,0,0,1,0,10,5,1,5,1,1,11]

theorem envBound8984 : H12AffineFastState.Bounded env8984 := by
  intro p hp
  have h : env8984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8983_8984 : H12AffineEnvironment.transform 4 10 env8983 = env8984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8983 == env8984) = true)

theorem identity8984 : scanCanonicalize (H12AffineFastState.compose env8984 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8984 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8985 : List Nat := [2,4,2,0,0,0,2,5,1,4,1,0,3,1,0,3,0,1,4,0,0,0,0,2,2,0,0,1,0,0,5,1,5,1,1,1]

theorem envBound8985 : H12AffineFastState.Bounded env8985 := by
  intro p hp
  have h : env8985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8984_8985 : H12AffineEnvironment.transform 2 2 env8984 = env8985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8984 == env8985) = true)

def env8986 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24771,4605,262144,4960,8692,65,4194304,5004,34,8329,21040,278624,4214984,4215092,18632,504,4211101,4961,16616,21040,1021]

theorem envBound8986 : H12AffineFastState.Bounded env8986 := by
  intro p hp
  have h : env8986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8958_8986 : H12AffineEnvironment.transform 20 65 env8958 = env8986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8958 == env8986) = true)

theorem identity8986 : scanCanonicalize (H12AffineFastState.compose env8986 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 20903) := by decide +kernel

theorem selectedBound8986 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8987 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24771,4605,20903,4960,8692,65,4194304,5004,34,8329,21040,4551,4214984,4215092,18632,504,4211101,4961,16616,21040,1021]

theorem envBound8987 : H12AffineFastState.Bounded env8987 := by
  intro p hp
  have h : env8987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8986_8987 : H12AffineEnvironment.transform 17 20903 env8986 = env8987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20903 env8986 == env8987) = true)

def env8988 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,232,8692,8235,4605,4431,4960,8692,65,4194304,5004,34,8329,4824,4551,4198432,4198876,2080,504,4194677,4961,0,4824,1021]

theorem envBound8988 : H12AffineFastState.Bounded env8988 := by
  intro p hp
  have h : env8988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8987_8988 : H12AffineEnvironment.transform 13 232 env8987 = env8988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env8987 == env8988) = true)

theorem identity8988 : scanCanonicalize (H12AffineFastState.compose env8988 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound8988 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8989 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,232,8692,8235,4605,4431,4960,8692,65,477,5004,34,8329,4824,4551,4605,4097,2080,504,168,4961,0,4824,1021]

theorem envBound8989 : H12AffineFastState.Bounded env8989 := by
  intro p hp
  have h : env8989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8988_8989 : H12AffineEnvironment.transform 21 477 env8988 = env8989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env8988 == env8989) = true)

theorem identity8989 : scanCanonicalize (H12AffineFastState.compose env8989 (packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound8989 : packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env8990 : List Nat := [2,4,8,16,32,64,128,256,512,257,603,4096,8192,232,8692,8235,4605,4431,4960,8692,65,477,5004,34,8329,4824,4551,4605,4097,635,504,168,4961,0,4824,1021]

theorem envBound8990 : H12AffineFastState.Bounded env8990 := by
  intro p hp
  have h : env8990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8989_8990 : H12AffineEnvironment.transform 10 603 env8989 = env8990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env8989 == env8990) = true)

theorem identity8990 : scanCanonicalize (H12AffineFastState.compose env8990 (packedSelected [0,3,5,7,8,12,14,15,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8990 : packedSelected [0,3,5,7,8,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env8991 : List Nat := [2,4,8,16,32,64,128,253,512,252,603,4096,8192,232,8201,8235,4096,4274,4765,8201,65,32,4721,34,8329,4824,4154,4096,4097,635,5,168,4764,0,4824,512]

theorem envBound8991 : H12AffineFastState.Bounded env8991 := by
  intro p hp
  have h : env8991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8990_8991 : H12AffineEnvironment.transform 7 253 env8990 = env8991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8990 == env8991) = true)

theorem identity8991 : scanCanonicalize (H12AffineFastState.compose env8991 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8991 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8992 : List Nat := [2,4,8,16,32,64,41,84,512,85,603,4096,8192,65,8201,8235,4096,4123,4660,8201,65,32,4721,34,8224,4721,4154,4096,4097,635,5,1,4661,0,4721,512]

theorem envBound8992 : H12AffineFastState.Bounded env8992 := by
  intro p hp
  have h : env8992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8991_8992 : H12AffineEnvironment.transform 6 41 env8991 = env8992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8991 == env8992) = true)

theorem identity8992 : scanCanonicalize (H12AffineFastState.compose env8992 (packedSelected [3,4,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 107) := by decide +kernel

theorem selectedBound8992 : packedSelected [3,4,9,11] rootPS < 2^1333 := by decide +kernel

def env8993 : List Nat := [2,4,8,16,32,64,41,84,107,85,48,4096,8192,65,8201,8235,4096,4123,4191,8201,65,32,4122,34,8224,4122,4154,4096,4097,16,5,1,4190,0,4122,107]

theorem envBound8993 : H12AffineFastState.Bounded env8993 := by
  intro p hp
  have h : env8993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8992_8993 : H12AffineEnvironment.transform 8 107 env8992 = env8993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 107 env8992 == env8993) = true)

theorem identity8993 : scanCanonicalize (H12AffineFastState.compose env8993 (packedSelected [2,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound8993 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env8994 : List Nat := [2,4,8,16,32,64,41,84,107,85,48,4096,24,65,17,51,4096,4123,4191,17,65,32,4122,34,56,4122,4154,4096,4097,16,5,1,4190,0,4122,107]

theorem envBound8994 : H12AffineFastState.Bounded env8994 := by
  intro p hp
  have h : env8994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8993_8994 : H12AffineEnvironment.transform 12 24 env8993 = env8994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env8993 == env8994) = true)

theorem identity8994 : scanCanonicalize (H12AffineFastState.compose env8994 (packedSelected [0,2] rootPS)) = affineNative (2^(11+1) ^^^ 11) := by decide +kernel

theorem selectedBound8994 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8995 : List Nat := [2,4,8,16,32,64,41,84,107,85,48,11,24,65,17,51,11,16,84,17,65,32,17,34,56,17,49,11,10,16,5,1,85,0,17,107]

theorem envBound8995 : H12AffineFastState.Bounded env8995 := by
  intro p hp
  have h : env8995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8994_8995 : H12AffineEnvironment.transform 11 11 env8994 = env8995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 11 env8994 == env8995) = true)

theorem identity8995 : scanCanonicalize (H12AffineFastState.compose env8995 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8995 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8996 : List Nat := [2,4,8,16,32,17,41,5,58,4,48,11,24,16,17,51,11,16,5,17,16,32,17,34,56,17,49,11,10,16,5,1,4,0,17,58]

theorem envBound8996 : H12AffineFastState.Bounded env8996 := by
  intro p hp
  have h : env8996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8995_8996 : H12AffineEnvironment.transform 5 17 env8995 = env8996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8995 == env8996) = true)

theorem identity8996 : scanCanonicalize (H12AffineFastState.compose env8996 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8996 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8997 : List Nat := [2,4,8,16,10,17,3,5,16,4,26,11,24,16,17,25,11,16,5,17,16,10,17,8,18,17,27,11,10,16,5,1,4,0,17,16]

theorem envBound8997 : H12AffineFastState.Bounded env8997 := by
  intro p hp
  have h : env8997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8996_8997 : H12AffineEnvironment.transform 4 10 env8996 = env8997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8996 == env8997) = true)

theorem identity8997 : scanCanonicalize (H12AffineFastState.compose env8997 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8997 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8998 : List Nat := [2,4,2,16,0,17,3,5,16,4,16,1,18,16,17,19,1,16,5,17,16,0,17,2,18,17,17,1,0,16,5,1,4,0,17,16]

theorem envBound8998 : H12AffineFastState.Bounded env8998 := by
  intro p hp
  have h : env8998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8997_8998 : H12AffineEnvironment.transform 2 2 env8997 = env8998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8997 == env8998) = true)

theorem identity8998 : scanCanonicalize (H12AffineFastState.compose env8998 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8998 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8999 : List Nat := [2,4,2,0,0,1,3,5,0,4,0,1,2,0,1,3,1,0,5,1,0,0,1,2,2,1,1,1,0,0,5,1,4,0,1,0]

theorem envBound8999 : H12AffineFastState.Bounded env8999 := by
  intro p hp
  have h : env8999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8998_8999 : H12AffineEnvironment.transform 3 0 env8998 = env8999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8998 == env8999) = true)

def leafEnv8999 : List Nat := [2,4,2,0,0,1,3,5,0,4,0,1,2,0,1,3,1,0,5,1,0,0,1,2,4,2,1,1,1,1,0,0,5,1,4,0,5,2,1,0,1,0,0]

def active8999 : List Nat := [0,1]

def tree8999 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8999 : H12WitnessSearch.Good tree8999 := H12GlobalWitnessIndex.good

theorem leafIdentity8999 : H12AffineFastState.composeSystem env8999 rootObs = leafEnv8999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8999 rootObs == leafEnv8999) = true)

theorem terminalChecked8999 : H12PackedTerminal.terminalCheckFast leafEnv8999 active8999 tree8999 = true := by decide +kernel

def env9000 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,233,8692,8234,4605,4430,4960,8692,65,4194304,5004,34,8329,4825,4551,4198433,4198877,2081,504,4194676,4961,1,4825,1021]

theorem envBound9000 : H12AffineFastState.Bounded env9000 := by
  intro p hp
  have h : env9000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8987_9000 : H12AffineEnvironment.transform 13 233 env8987 = env9000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env8987 == env9000) = true)

theorem identity9000 : scanCanonicalize (H12AffineFastState.compose env9000 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9000 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9001 : List Nat := [2,4,8,16,32,64,128,84,512,85,2048,4096,8192,233,8352,8234,4265,4122,4660,8352,65,4194304,4824,34,8329,4825,4243,4198433,4198537,2081,172,4194336,4661,1,4825,681]

theorem envBound9001 : H12AffineFastState.Bounded env9001 := by
  intro p hp
  have h : env9001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9000_9001 : H12AffineEnvironment.transform 7 84 env9000 = env9001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9000 == env9001) = true)

theorem identity9001 : scanCanonicalize (H12AffineFastState.compose env9001 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 755) := by decide +kernel

theorem selectedBound9001 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9002 : List Nat := [2,4,8,16,32,64,128,84,512,85,755,4096,8192,233,8352,8234,4265,4122,4660,8352,65,4194304,4824,34,8329,4825,4243,4198433,4198537,722,172,4194336,4661,1,4825,681]

theorem envBound9002 : H12AffineFastState.Bounded env9002 := by
  intro p hp
  have h : env9002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9001_9002 : H12AffineEnvironment.transform 10 755 env9001 = env9002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 755 env9001 == env9002) = true)

theorem identity9002 : scanCanonicalize (H12AffineFastState.compose env9002 (packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS)) = affineNative (2^(11+1) ^^^ 713) := by decide +kernel

theorem selectedBound9002 : packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env9003 : List Nat := [2,4,8,16,32,64,128,84,512,85,755,713,8192,233,8352,8234,608,723,253,8352,65,4194304,17,34,8329,16,602,4195048,4194880,722,172,4194336,252,1,16,681]

theorem envBound9003 : H12AffineFastState.Bounded env9003 := by
  intro p hp
  have h : env9003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9002_9003 : H12AffineEnvironment.transform 11 713 env9002 = env9003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 713 env9002 == env9003) = true)

theorem identity9003 : scanCanonicalize (H12AffineFastState.compose env9003 (packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9003 : packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS < 2^1333 := by decide +kernel

def env9004 : List Nat := [2,4,8,16,32,64,41,84,512,85,602,608,8192,64,8201,8234,608,634,84,8201,65,4194304,17,34,8224,16,602,4194881,4194880,635,5,4194336,85,1,16,512]

theorem envBound9004 : H12AffineFastState.Bounded env9004 := by
  intro p hp
  have h : env9004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9003_9004 : H12AffineEnvironment.transform 6 41 env9003 = env9004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9003 == env9004) = true)

theorem identity9004 : scanCanonicalize (H12AffineFastState.compose env9004 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound9004 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9005 : List Nat := [2,4,8,16,32,64,41,84,512,85,602,608,8192,64,8201,8234,608,634,84,8201,65,32,17,34,8224,16,602,609,608,635,5,0,85,1,16,512]

theorem envBound9005 : H12AffineFastState.Bounded env9005 := by
  intro p hp
  have h : env9005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9004_9005 : H12AffineEnvironment.transform 21 32 env9004 = env9005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env9004 == env9005) = true)

theorem identity9005 : scanCanonicalize (H12AffineFastState.compose env9005 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound9005 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9006 : List Nat := [2,4,8,16,32,64,41,84,74,85,16,42,8192,64,8201,8234,42,48,84,8201,65,32,17,34,8224,16,16,43,42,49,5,0,85,1,16,74]

theorem envBound9006 : H12AffineFastState.Bounded env9006 := by
  intro p hp
  have h : env9006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9005_9006 : H12AffineEnvironment.transform 8 74 env9005 = env9006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env9005 == env9006) = true)

theorem identity9006 : scanCanonicalize (H12AffineFastState.compose env9006 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9006 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env9007 : List Nat := [2,4,3,16,32,64,34,84,65,85,16,33,8192,64,8194,8225,33,48,84,8194,65,32,17,34,8224,16,16,32,33,49,5,0,85,1,16,65]

theorem envBound9007 : H12AffineFastState.Bounded env9007 := by
  intro p hp
  have h : env9007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9006_9007 : H12AffineEnvironment.transform 2 3 env9006 = env9007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9006 == env9007) = true)

theorem identity9007 : scanCanonicalize (H12AffineFastState.compose env9007 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound9007 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env9008 : List Nat := [2,4,3,16,32,49,34,37,48,36,16,33,8192,49,8194,8225,33,48,37,8194,48,32,17,34,8224,16,16,32,33,49,5,0,36,1,16,48]

theorem envBound9008 : H12AffineFastState.Bounded env9008 := by
  intro p hp
  have h : env9008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9007_9008 : H12AffineEnvironment.transform 5 49 env9007 = env9008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env9007 == env9008) = true)

theorem identity9008 : scanCanonicalize (H12AffineFastState.compose env9008 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9008 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env9009 : List Nat := [2,4,3,16,1,16,3,4,17,5,16,0,8192,16,8194,8192,0,17,4,8194,17,1,17,3,8193,16,16,1,0,16,5,0,5,1,16,17]

theorem envBound9009 : H12AffineFastState.Bounded env9009 := by
  intro p hp
  have h : env9009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9008_9009 : H12AffineEnvironment.transform 4 1 env9008 = env9009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9008 == env9009) = true)

theorem identity9009 : scanCanonicalize (H12AffineFastState.compose env9009 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 19) := by decide +kernel

theorem selectedBound9009 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9010 : List Nat := [2,4,3,16,1,16,3,4,17,5,16,0,19,16,17,19,0,17,4,17,17,1,17,3,18,16,16,1,0,16,5,0,5,1,16,17]

theorem envBound9010 : H12AffineFastState.Bounded env9010 := by
  intro p hp
  have h : env9010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9009_9010 : H12AffineEnvironment.transform 12 19 env9009 = env9010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 19 env9009 == env9010) = true)

theorem identity9010 : scanCanonicalize (H12AffineFastState.compose env9010 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9010 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9011 : List Nat := [2,4,3,0,1,0,3,4,1,5,0,0,3,0,1,3,0,1,4,1,1,1,1,3,2,0,0,1,0,0,5,0,5,1,0,1]

theorem envBound9011 : H12AffineFastState.Bounded env9011 := by
  intro p hp
  have h : env9011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9010_9011 : H12AffineEnvironment.transform 3 0 env9010 = env9011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9010 == env9011) = true)

def leafEnv9011 : List Nat := [2,4,3,0,1,0,3,4,1,5,0,0,3,0,1,3,0,1,4,1,1,1,1,3,4,2,1,0,0,1,0,0,5,0,5,1,5,3,0,1,1,0,0]

def active9011 : List Nat := [0,1]

def tree9011 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9011 : H12WitnessSearch.Good tree9011 := H12GlobalWitnessIndex.good

theorem leafIdentity9011 : H12AffineFastState.composeSystem env9011 rootObs = leafEnv9011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9011 rootObs == leafEnv9011) = true)

theorem terminalChecked9011 : H12PackedTerminal.terminalCheckFast leafEnv9011 active9011 tree9011 = true := by decide +kernel

def env9012 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,4961,8692,2097152,4194304,5005,90337,8329,21040,278625,4214985,4215093,75786,505,4268383,4960,73770,2175667,90942]

theorem envBound9012 : H12AffineFastState.Bounded env9012 := by
  intro p hp
  have h : env9012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8956_9012 : H12AffineEnvironment.transform 18 4961 env8956 = env9012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env8956 == env9012) = true)

theorem identity9012 : scanCanonicalize (H12AffineFastState.compose env9012 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9012 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9013 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,2097152,4194304,4720,90337,8329,21040,278625,4214985,4214984,75786,4,4268194,4765,73770,2175667,90819]

theorem envBound9013 : H12AffineFastState.Bounded env9013 := by
  intro p hp
  have h : env9013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9012_9013 : H12AffineEnvironment.transform 7 253 env9012 = env9013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9012 == env9013) = true)

def env9014 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,64,4194304,4720,90337,8329,21040,278625,4214985,4214984,75786,4,4268194,4765,73770,78579,90819]

theorem envBound9014 : H12AffineFastState.Bounded env9014 := by
  intro p hp
  have h : env9014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9013_9014 : H12AffineEnvironment.transform 20 64 env9013 = env9014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env9013 == env9014) = true)

theorem identity9014 : scanCanonicalize (H12AffineFastState.compose env9014 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 279114) := by decide +kernel

theorem selectedBound9014 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9015 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,64,279114,4720,90337,8329,21040,278625,266883,266882,75786,4,353000,4765,73770,78579,90819]

theorem envBound9015 : H12AffineFastState.Bounded env9015 := by
  intro p hp
  have h : env9015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9014_9015 : H12AffineEnvironment.transform 21 279114 env9014 = env9015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 279114 env9014 == env9015) = true)

def env9016 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,74240,4764,8201,64,90186,4720,90337,8329,21040,90721,77955,77954,75786,4,16616,4765,73770,78579,90819]

theorem envBound9016 : H12AffineFastState.Bounded env9016 := by
  intro p hp
  have h : env9016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9015_9016 : H12AffineEnvironment.transform 17 74240 env9015 = env9016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74240 env9015 == env9016) = true)

theorem identity9016 : scanCanonicalize (H12AffineFastState.compose env9016 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound9016 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9017 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,8323,4096,643,4764,8201,64,16585,4720,16482,8329,21040,17122,4096,4097,2185,4,16616,4765,169,4720,16960]

theorem envBound9017 : H12AffineFastState.Bounded env9017 := by
  intro p hp
  have h : env9017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9016_9017 : H12AffineEnvironment.transform 15 8323 env9016 = env9017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env9016 == env9017) = true)

theorem identity9017 : scanCanonicalize (H12AffineFastState.compose env9017 (packedSelected [0,2,11,13,14,17,18,27] rootPS)) = affineNative (2^(13+1) ^^^ 608) := by decide +kernel

theorem selectedBound9017 : packedSelected [0,2,11,13,14,17,18,27] rootPS < 2^1333 := by decide +kernel

def env9018 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,608,8201,8323,4096,643,4764,8201,64,681,4720,514,8329,4176,130,4096,4097,2185,4,648,4765,169,4720,32]

theorem envBound9018 : H12AffineFastState.Bounded env9018 := by
  intro p hp
  have h : env9018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9017_9018 : H12AffineEnvironment.transform 13 608 env9017 = env9018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 608 env9017 == env9018) = true)

theorem identity9018 : scanCanonicalize (H12AffineFastState.compose env9018 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound9018 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env9019 : List Nat := [2,4,8,16,32,64,128,253,216,252,2048,4096,8192,184,8201,8323,4096,91,4164,8201,64,113,4264,218,8329,4176,130,4096,4097,2185,4,80,4165,169,4264,32]

theorem envBound9019 : H12AffineFastState.Bounded env9019 := by
  intro p hp
  have h : env9019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9018_9019 : H12AffineEnvironment.transform 8 216 env9018 = env9019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9018 == env9019) = true)

theorem identity9019 : scanCanonicalize (H12AffineFastState.compose env9019 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9019 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env9020 : List Nat := [2,4,8,16,32,64,121,4,33,5,2048,4096,8192,65,8201,8314,4096,91,4164,8201,64,113,4177,35,8304,4176,123,4096,4097,2160,4,80,4165,80,4177,32]

theorem envBound9020 : H12AffineFastState.Bounded env9020 := by
  intro p hp
  have h : env9020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9019_9020 : H12AffineEnvironment.transform 6 121 env9019 = env9020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9019 == env9020) = true)

theorem identity9020 : scanCanonicalize (H12AffineFastState.compose env9020 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2154) := by decide +kernel

theorem selectedBound9020 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env9021 : List Nat := [2,4,8,16,32,64,121,4,33,5,2048,2154,8192,65,8201,8314,2154,91,2094,8201,64,113,2107,35,8304,2106,123,2154,2155,2160,4,80,2095,80,2107,32]

theorem envBound9021 : H12AffineFastState.Bounded env9021 := by
  intro p hp
  have h : env9021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9020_9021 : H12AffineEnvironment.transform 11 2154 env9020 = env9021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2154 env9020 == env9021) = true)

theorem identity9021 : scanCanonicalize (H12AffineFastState.compose env9021 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound9021 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env9022 : List Nat := [2,4,8,16,32,64,121,4,33,5,64,42,8192,65,8201,8314,42,91,110,8201,64,113,123,35,8304,122,123,42,43,48,4,80,111,80,123,32]

theorem envBound9022 : H12AffineFastState.Bounded env9022 := by
  intro p hp
  have h : env9022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9021_9022 : H12AffineEnvironment.transform 10 64 env9021 = env9022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env9021 == env9022) = true)

theorem identity9022 : scanCanonicalize (H12AffineFastState.compose env9022 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9022 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env9023 : List Nat := [2,4,8,16,1,64,88,4,0,5,64,11,8192,65,8201,8283,11,91,79,8201,64,80,90,2,8273,91,90,11,10,17,4,80,78,80,90,1]

theorem envBound9023 : H12AffineFastState.Bounded env9023 := by
  intro p hp
  have h : env9023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9022_9023 : H12AffineEnvironment.transform 4 1 env9022 = env9023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9022 == env9023) = true)

theorem identity9023 : scanCanonicalize (H12AffineFastState.compose env9023 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound9023 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9024 : List Nat := [2,4,8,16,1,64,88,4,0,5,64,11,25,65,16,66,11,91,79,16,64,80,90,2,72,91,90,11,10,17,4,80,78,80,90,1]

theorem envBound9024 : H12AffineFastState.Bounded env9024 := by
  intro p hp
  have h : env9024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9023_9024 : H12AffineEnvironment.transform 12 25 env9023 = env9024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env9023 == env9024) = true)

theorem identity9024 : scanCanonicalize (H12AffineFastState.compose env9024 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 15) := by decide +kernel

theorem selectedBound9024 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9025 : List Nat := [2,4,8,16,1,15,23,4,0,5,15,11,25,14,16,13,11,20,0,16,15,31,21,2,7,20,21,11,10,17,4,31,1,31,21,1]

theorem envBound9025 : H12AffineFastState.Bounded env9025 := by
  intro p hp
  have h : env9025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9024_9025 : H12AffineEnvironment.transform 5 15 env9024 = env9025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 15 env9024 == env9025) = true)

theorem identity9025 : scanCanonicalize (H12AffineFastState.compose env9025 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound9025 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9026 : List Nat := [2,4,6,16,1,1,23,4,0,5,1,5,23,0,16,3,5,20,0,16,1,17,21,2,7,20,21,5,4,17,4,17,1,17,21,1]

theorem envBound9026 : H12AffineFastState.Bounded env9026 := by
  intro p hp
  have h : env9026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9025_9026 : H12AffineEnvironment.transform 2 6 env9025 = env9026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env9025 == env9026) = true)

theorem identity9026 : scanCanonicalize (H12AffineFastState.compose env9026 (packedSelected [7,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9026 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env9027 : List Nat := [2,4,6,0,1,1,7,4,0,5,1,5,7,0,0,3,5,4,0,0,1,1,5,2,7,4,5,5,4,1,4,1,1,1,5,1]

theorem envBound9027 : H12AffineFastState.Bounded env9027 := by
  intro p hp
  have h : env9027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9026_9027 : H12AffineEnvironment.transform 3 0 env9026 = env9027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9026 == env9027) = true)

def env9028 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,74241,4764,8201,64,90187,4720,90337,8329,21040,90720,77954,77955,75786,4,16617,4765,73770,78579,90819]

theorem envBound9028 : H12AffineFastState.Bounded env9028 := by
  intro p hp
  have h : env9028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9015_9028 : H12AffineEnvironment.transform 17 74241 env9015 = env9028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74241 env9015 == env9028) = true)

theorem identity9028 : scanCanonicalize (H12AffineFastState.compose env9028 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound9028 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9029 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,24771,4096,17090,4764,8201,64,136,4720,34,8329,21040,675,20545,20544,18633,4,16617,4765,16617,21040,512]

theorem envBound9029 : H12AffineFastState.Bounded env9029 := by
  intro p hp
  have h : env9029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9028_9029 : H12AffineEnvironment.transform 15 24771 env9028 = env9029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env9028 == env9029) = true)

theorem identity9029 : scanCanonicalize (H12AffineFastState.compose env9029 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9029 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9030 : List Nat := [2,4,8,16,32,64,40,85,512,84,2048,4096,8192,16384,8201,24683,4096,17002,4660,8201,64,32,4720,34,8225,21040,523,20545,20544,18529,4,16449,4661,16449,21040,512]

theorem envBound9030 : H12AffineFastState.Bounded env9030 := by
  intro p hp
  have h : env9030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9029_9030 : H12AffineEnvironment.transform 6 40 env9029 = env9030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9029 == env9030) = true)

theorem identity9030 : scanCanonicalize (H12AffineFastState.compose env9030 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2107) := by decide +kernel

theorem selectedBound9030 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9031 : List Nat := [2,4,8,16,32,64,40,85,512,84,2048,2107,8192,16384,8201,24683,2107,17002,2575,8201,64,32,2635,34,8225,18955,523,18554,18555,18529,4,16449,2574,16449,18955,512]

theorem envBound9031 : H12AffineFastState.Bounded env9031 := by
  intro p hp
  have h : env9031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9030_9031 : H12AffineEnvironment.transform 11 2107 env9030 = env9031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2107 env9030 == env9031) = true)

theorem identity9031 : scanCanonicalize (H12AffineFastState.compose env9031 (packedSelected [0,1,2,3,4,8,11] rootPS)) = affineNative (2^(13+1) ^^^ 8707) := by decide +kernel

theorem selectedBound9031 : packedSelected [0,1,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env9032 : List Nat := [2,4,8,16,32,64,40,85,512,84,2048,2107,8192,8707,8201,616,2107,8297,2575,8201,64,32,2635,34,8225,10248,523,10873,10872,10850,4,8770,2574,8770,10248,512]

theorem envBound9032 : H12AffineFastState.Bounded env9032 := by
  intro p hp
  have h : env9032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9031_9032 : H12AffineEnvironment.transform 13 8707 env9031 = env9032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8707 env9031 == env9032) = true)

theorem identity9032 : scanCanonicalize (H12AffineFastState.compose env9032 (packedSelected [0,1,2,3,4,8,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9032 : packedSelected [0,1,2,3,4,8,12,13] rootPS < 2^1333 := by decide +kernel

def env9033 : List Nat := [2,4,8,16,16,64,24,85,512,84,2048,2059,8192,8707,8201,600,2059,8281,2575,8201,64,16,2635,18,8209,10248,523,10825,10824,10834,4,8770,2574,8770,10248,512]

theorem envBound9033 : H12AffineFastState.Bounded env9033 := by
  intro p hp
  have h : env9033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9032_9033 : H12AffineEnvironment.transform 4 16 env9032 = env9033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9032 == env9033) = true)

theorem identity9033 : scanCanonicalize (H12AffineFastState.compose env9033 (packedSelected [0,2,3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9033 : packedSelected [0,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env9034 : List Nat := [2,4,8,10,10,64,2,79,512,78,2048,2059,8192,8707,8201,578,2059,8259,2575,8201,64,10,2635,8,8203,10248,523,10825,10824,10824,4,8770,2574,8770,10248,512]

theorem envBound9034 : H12AffineFastState.Bounded env9034 := by
  intro p hp
  have h : env9034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9033_9034 : H12AffineEnvironment.transform 3 10 env9033 = env9034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9033 == env9034) = true)

theorem identity9034 : scanCanonicalize (H12AffineFastState.compose env9034 (packedSelected [3,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound9034 : packedSelected [3,4,8] rootPS < 2^1333 := by decide +kernel

def env9035 : List Nat := [2,4,8,10,10,64,2,79,512,78,2048,2059,2,513,11,578,2059,65,2575,11,64,10,2635,8,9,2058,523,2635,2634,2634,4,576,2574,576,2058,512]

theorem envBound9035 : H12AffineFastState.Bounded env9035 := by
  intro p hp
  have h : env9035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9034_9035 : H12AffineEnvironment.transform 12 2 env9034 = env9035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env9034 == env9035) = true)

theorem identity9035 : scanCanonicalize (H12AffineFastState.compose env9035 (packedSelected [1,2,3,4,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound9035 : packedSelected [1,2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env9036 : List Nat := [2,4,8,10,10,64,2,79,512,78,64,75,2,513,11,578,75,65,591,11,64,10,523,8,9,74,523,523,522,522,4,576,590,576,74,512]

theorem envBound9036 : H12AffineFastState.Bounded env9036 := by
  intro p hp
  have h : env9036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9035_9036 : H12AffineEnvironment.transform 10 64 env9035 = env9036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env9035 == env9036) = true)

theorem identity9036 : scanCanonicalize (H12AffineFastState.compose env9036 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound9036 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9037 : List Nat := [2,4,8,10,10,64,2,79,11,78,64,75,2,10,11,73,75,65,68,11,64,10,0,8,9,74,0,0,1,1,4,75,69,75,74,11]

theorem envBound9037 : H12AffineFastState.Bounded env9037 := by
  intro p hp
  have h : env9037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9036_9037 : H12AffineEnvironment.transform 8 11 env9036 = env9037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env9036 == env9037) = true)

def env9038 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,65,4194304,4720,90337,8329,21040,278625,4214985,4214984,75786,4,4268194,4765,73770,78578,90819]

theorem envBound9038 : H12AffineFastState.Bounded env9038 := by
  intro p hp
  have h : env9038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9013_9038 : H12AffineEnvironment.transform 20 65 env9013 = env9038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env9013 == env9038) = true)

theorem identity9038 : scanCanonicalize (H12AffineFastState.compose env9038 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 282666) := by decide +kernel

theorem selectedBound9038 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9039 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,65,282666,4720,90337,8329,21040,278625,262371,262370,75786,4,356488,4765,73770,78578,90819]

theorem envBound9039 : H12AffineFastState.Bounded env9039 := by
  intro p hp
  have h : env9039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9038_9039 : H12AffineEnvironment.transform 21 282666 env9038 = env9039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 282666 env9038 == env9039) = true)

def env9040 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,77976,4764,8201,65,90290,4720,90337,8329,21040,94457,77947,77946,75786,4,16400,4765,73770,78578,90819]

theorem envBound9040 : H12AffineFastState.Bounded env9040 := by
  intro p hp
  have h : env9040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9039_9040 : H12AffineEnvironment.transform 17 77976 env9039 = env9040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 77976 env9039 == env9040) = true)

def env9041 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8201,65536,4096,77976,4764,8201,65,74370,4720,74449,8329,4096,78537,77947,77946,75786,4,544,4765,73770,78578,73971]

theorem envBound9041 : H12AffineFastState.Bounded env9041 := by
  intro p hp
  have h : env9041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9040_9041 : H12AffineEnvironment.transform 13 560 env9040 = env9041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9040 == env9041) = true)

theorem identity9041 : scanCanonicalize (H12AffineFastState.compose env9041 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound9041 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9042 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,185,8192,560,8201,65536,185,73761,549,8201,65,74370,713,74449,8329,185,74352,73922,73923,75786,4,544,548,73770,74315,73971]

theorem envBound9042 : H12AffineFastState.Bounded env9042 := by
  intro p hp
  have h : env9042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9041_9042 : H12AffineEnvironment.transform 11 185 env9041 = env9042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env9041 == env9042) = true)

theorem identity9042 : scanCanonicalize (H12AffineFastState.compose env9042 (packedSelected [0,7,13,14,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound9042 : packedSelected [0,7,13,14,17,20] rootPS < 2^1333 := by decide +kernel

def env9043 : List Nat := [2,4,8,16,32,64,128,253,512,252,131,185,8192,560,8201,65536,185,73761,549,8201,65,74370,713,74449,8329,185,74352,73922,73923,73865,4,544,548,73770,74315,73971]

theorem envBound9043 : H12AffineFastState.Bounded env9043 := by
  intro p hp
  have h : env9043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9042_9043 : H12AffineEnvironment.transform 10 131 env9042 = env9043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env9042 == env9043) = true)

theorem identity9043 : scanCanonicalize (H12AffineFastState.compose env9043 (packedSelected [0,4,5,7,8,9,10,12,14,15,17,19,21] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9043 : packedSelected [0,4,5,7,8,9,10,12,14,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env9044 : List Nat := [2,4,8,16,32,64,121,4,512,5,122,64,8192,560,8201,65536,64,73761,549,8201,65,74363,560,74280,8304,64,74352,73787,73786,73840,4,544,548,73770,74315,73738]

theorem envBound9044 : H12AffineFastState.Bounded env9044 := by
  intro p hp
  have h : env9044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9043_9044 : H12AffineEnvironment.transform 6 121 env9043 = env9044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9043 == env9044) = true)

theorem identity9044 : scanCanonicalize (H12AffineFastState.compose env9044 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound9044 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env9045 : List Nat := [2,4,8,16,32,64,121,4,512,5,122,64,553,560,544,65536,64,66056,549,544,65,65618,560,65537,601,64,65625,66066,66067,66137,4,544,548,66051,65634,66083]

theorem envBound9045 : H12AffineFastState.Bounded env9045 := by
  intro p hp
  have h : env9045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9044_9045 : H12AffineEnvironment.transform 12 553 env9044 = env9045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env9044 == env9045) = true)

theorem identity9045 : scanCanonicalize (H12AffineFastState.compose env9045 (packedSelected [13,14,17] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound9045 : packedSelected [13,14,17] rootPS < 2^1333 := by decide +kernel

def env9046 : List Nat := [2,4,8,16,32,64,121,4,512,5,122,64,553,560,544,35,64,555,549,544,65,113,560,34,601,64,122,561,560,634,4,544,548,544,65,512]

theorem envBound9046 : H12AffineFastState.Bounded env9046 := by
  intro p hp
  have h : env9046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9045_9046 : H12AffineEnvironment.transform 15 35 env9045 = env9046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env9045 == env9046) = true)

theorem identity9046 : scanCanonicalize (H12AffineFastState.compose env9046 (packedSelected [0,1,3,4,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound9046 : packedSelected [0,1,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env9047 : List Nat := [2,4,8,16,32,64,121,4,27,5,122,64,50,43,59,35,64,48,62,59,65,113,43,34,66,64,122,42,43,97,4,59,63,59,65,27]

theorem envBound9047 : H12AffineFastState.Bounded env9047 := by
  intro p hp
  have h : env9047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9046_9047 : H12AffineEnvironment.transform 8 27 env9046 = env9047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env9046 == env9047) = true)

theorem identity9047 : scanCanonicalize (H12AffineFastState.compose env9047 (packedSelected [1,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9047 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env9048 : List Nat := [2,4,2,16,32,64,115,4,17,5,112,64,50,33,49,35,64,48,52,49,65,113,33,34,66,64,112,32,33,97,4,49,53,49,65,17]

theorem envBound9048 : H12AffineFastState.Bounded env9048 := by
  intro p hp
  have h : env9048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9047_9048 : H12AffineEnvironment.transform 2 2 env9047 = env9048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9047 == env9048) = true)

theorem identity9048 : scanCanonicalize (H12AffineFastState.compose env9048 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound9048 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env9049 : List Nat := [2,4,2,16,32,0,51,4,17,5,48,0,50,33,49,35,0,48,52,49,1,49,33,34,2,0,48,32,33,33,4,49,53,49,1,17]

theorem envBound9049 : H12AffineFastState.Bounded env9049 := by
  intro p hp
  have h : env9049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9048_9049 : H12AffineEnvironment.transform 5 0 env9048 = env9049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env9048 == env9049) = true)

def env9050 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8201,65536,4096,77976,4764,8201,65,74371,4720,74448,8329,4097,78536,77947,77946,75786,4,545,4765,73770,78578,73970]

theorem envBound9050 : H12AffineFastState.Bounded env9050 := by
  intro p hp
  have h : env9050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9040_9050 : H12AffineEnvironment.transform 13 561 env9040 = env9050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9040 == env9050) = true)

theorem identity9050 : scanCanonicalize (H12AffineFastState.compose env9050 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound9050 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9051 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,65,8192,561,8201,65536,65,73945,733,8201,65,74371,561,74448,8329,64,74377,73786,73787,75786,4,545,732,73770,74419,73970]

theorem envBound9051 : H12AffineFastState.Bounded env9051 := by
  intro p hp
  have h : env9051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9050_9051 : H12AffineEnvironment.transform 11 65 env9050 = env9051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env9050 == env9051) = true)

theorem identity9051 : scanCanonicalize (H12AffineFastState.compose env9051 (packedSelected [14,17,21] rootPS)) = affineNative (2^(15+1) ^^^ 10784) := by decide +kernel

theorem selectedBound9051 : packedSelected [14,17,21] rootPS < 2^1333 := by decide +kernel

def env9052 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,65,8192,561,8201,10784,65,2809,733,8201,65,2211,561,2288,8329,64,2217,2586,2587,554,4,545,732,2570,2195,2770]

theorem envBound9052 : H12AffineFastState.Bounded env9052 := by
  intro p hp
  have h : env9052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9051_9052 : H12AffineEnvironment.transform 15 10784 env9051 = env9052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10784 env9051 == env9052) = true)

theorem identity9052 : scanCanonicalize (H12AffineFastState.compose env9052 (packedSelected [1,3,4,5,8,9,10,14,18,19,20,23] rootPS)) = affineNative (2^(10+1) ^^^ 211) := by decide +kernel

theorem selectedBound9052 : packedSelected [1,3,4,5,8,9,10,14,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env9053 : List Nat := [2,4,8,16,32,64,128,253,512,252,211,65,8192,561,8201,8947,65,554,733,8201,65,112,561,35,8329,64,122,713,712,554,4,545,732,729,64,513]

theorem envBound9053 : H12AffineFastState.Bounded env9053 := by
  intro p hp
  have h : env9053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9052_9053 : H12AffineEnvironment.transform 10 211 env9052 = env9053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 211 env9052 == env9053) = true)

theorem identity9053 : scanCanonicalize (H12AffineFastState.compose env9053 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound9053 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9054 : List Nat := [2,4,8,16,32,64,128,253,32,252,211,65,8192,17,8201,8403,65,10,253,8201,65,112,17,35,8329,64,122,233,232,10,4,1,252,249,64,33]

theorem envBound9054 : H12AffineFastState.Bounded env9054 := by
  intro p hp
  have h : env9054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9053_9054 : H12AffineEnvironment.transform 8 32 env9053 = env9054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env9053 == env9054) = true)

theorem identity9054 : scanCanonicalize (H12AffineFastState.compose env9054 (packedSelected [0,1,3,4,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 165) := by decide +kernel

theorem selectedBound9054 : packedSelected [0,1,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env9055 : List Nat := [2,4,8,16,32,64,128,253,32,252,211,65,165,17,172,118,65,10,253,172,65,112,17,35,44,64,122,233,232,10,4,1,252,249,64,33]

theorem envBound9055 : H12AffineFastState.Bounded env9055 := by
  intro p hp
  have h : env9055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9054_9055 : H12AffineEnvironment.transform 12 165 env9054 = env9055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 165 env9054 == env9055) = true)

theorem identity9055 : scanCanonicalize (H12AffineFastState.compose env9055 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9055 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9056 : List Nat := [2,4,8,0,32,64,128,237,32,236,195,65,165,1,172,102,65,10,237,172,65,96,1,35,44,64,106,233,232,10,4,1,236,233,64,33]

theorem envBound9056 : H12AffineFastState.Bounded env9056 := by
  intro p hp
  have h : env9056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9055_9056 : H12AffineEnvironment.transform 3 0 env9055 = env9056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9055 == env9056) = true)

theorem identity9056 : scanCanonicalize (H12AffineFastState.compose env9056 (packedSelected [0,1,2,3,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 70) := by decide +kernel

theorem selectedBound9056 : packedSelected [0,1,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env9057 : List Nat := [2,4,8,0,32,64,70,43,32,42,5,65,99,1,106,102,65,10,43,106,65,96,1,35,44,64,106,47,46,10,4,1,42,47,64,33]

theorem envBound9057 : H12AffineFastState.Bounded env9057 := by
  intro p hp
  have h : env9057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9056_9057 : H12AffineEnvironment.transform 6 70 env9056 = env9057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 70 env9056 == env9057) = true)

theorem identity9057 : scanCanonicalize (H12AffineFastState.compose env9057 (packedSelected [3,4] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound9057 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env9058 : List Nat := [2,4,8,0,32,33,39,43,32,42,5,32,2,1,11,7,32,10,43,11,32,1,1,35,44,33,11,47,46,10,4,1,42,47,33,33]

theorem envBound9058 : H12AffineFastState.Bounded env9058 := by
  intro p hp
  have h : env9058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9057_9058 : H12AffineEnvironment.transform 5 33 env9057 = env9058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env9057 == env9058) = true)

theorem identity9058 : scanCanonicalize (H12AffineFastState.compose env9058 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9058 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9059 : List Nat := [2,4,3,0,32,33,39,32,32,33,5,32,2,1,0,7,32,1,32,0,32,1,1,35,39,33,0,36,37,1,4,1,33,36,33,33]

theorem envBound9059 : H12AffineFastState.Bounded env9059 := by
  intro p hp
  have h : env9059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9058_9059 : H12AffineEnvironment.transform 2 3 env9058 = env9059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9058 == env9059) = true)

theorem identity9059 : scanCanonicalize (H12AffineFastState.compose env9059 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9059 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9060 : List Nat := [2,1,3,0,32,33,34,32,32,33,0,32,2,1,0,2,32,1,32,0,32,1,1,35,34,33,0,33,32,1,1,1,33,33,33,33]

theorem envBound9060 : H12AffineFastState.Bounded env9060 := by
  intro p hp
  have h : env9060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9059_9060 : H12AffineEnvironment.transform 1 1 env9059 = env9060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9059 == env9060) = true)

def env9061 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,77977,4764,8201,65,90291,4720,90337,8329,21040,94456,77946,77947,75786,4,16401,4765,73770,78578,90819]

theorem envBound9061 : H12AffineFastState.Bounded env9061 := by
  intro p hp
  have h : env9061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9039_9061 : H12AffineEnvironment.transform 17 77977 env9039 = env9061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 77977 env9039 == env9061) = true)

def env9062 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8201,65536,4096,77977,4764,8201,65,74371,4720,74449,8329,4096,78536,77946,77947,75786,4,545,4765,73770,78578,73971]

theorem envBound9062 : H12AffineFastState.Bounded env9062 := by
  intro p hp
  have h : env9062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9061_9062 : H12AffineEnvironment.transform 13 560 env9061 = env9062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9061 == env9062) = true)

theorem identity9062 : scanCanonicalize (H12AffineFastState.compose env9062 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12875) := by decide +kernel

theorem selectedBound9062 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9063 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8201,12875,4096,722,4764,8201,65,4296,4720,4250,8329,4096,131,561,560,6721,4,545,4765,4705,185,4792]

theorem envBound9063 : H12AffineFastState.Bounded env9063 := by
  intro p hp
  have h : env9063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9062_9063 : H12AffineEnvironment.transform 15 12875 env9062 = env9063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12875 env9062 == env9063) = true)

theorem identity9063 : scanCanonicalize (H12AffineFastState.compose env9063 (packedSelected [0,7,13,14,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 232) := by decide +kernel

theorem selectedBound9063 : packedSelected [0,7,13,14,20,21] rootPS < 2^1333 := by decide +kernel

def env9064 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,232,8192,560,8201,8867,232,722,628,8201,65,32,664,114,8329,232,131,561,560,2729,4,545,629,649,185,592]

theorem envBound9064 : H12AffineFastState.Bounded env9064 := by
  intro p hp
  have h : env9064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9063_9064 : H12AffineEnvironment.transform 11 232 env9063 = env9064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env9063 == env9064) = true)

theorem identity9064 : scanCanonicalize (H12AffineFastState.compose env9064 (packedSelected [5,8,10,12,14,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound9064 : packedSelected [5,8,10,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env9065 : List Nat := [2,4,8,16,32,64,128,253,512,252,603,232,8192,560,8201,8867,232,722,628,8201,65,32,664,114,8329,232,131,561,560,242,4,545,629,649,185,592]

theorem envBound9065 : H12AffineFastState.Bounded env9065 := by
  intro p hp
  have h : env9065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9064_9065 : H12AffineEnvironment.transform 10 603 env9064 = env9065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env9064 == env9065) = true)

theorem identity9065 : scanCanonicalize (H12AffineFastState.compose env9065 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9065 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env9066 : List Nat := [2,4,8,16,32,17,128,172,512,173,522,185,8192,560,8201,8867,185,643,549,8201,16,32,664,35,8329,185,131,561,560,163,4,545,548,649,185,513]

theorem envBound9066 : H12AffineFastState.Bounded env9066 := by
  intro p hp
  have h : env9066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9065_9066 : H12AffineEnvironment.transform 5 17 env9065 = env9066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9065 == env9066) = true)

theorem identity9066 : scanCanonicalize (H12AffineFastState.compose env9066 (packedSelected [0,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 682) := by decide +kernel

theorem selectedBound9066 : packedSelected [0,5,8,9] rootPS < 2^1333 := by decide +kernel

def env9067 : List Nat := [2,4,8,16,32,17,128,172,512,173,522,185,682,560,675,9,185,643,549,675,16,32,664,35,547,185,131,561,560,163,4,545,548,649,185,513]

theorem envBound9067 : H12AffineFastState.Bounded env9067 := by
  intro p hp
  have h : env9067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9066_9067 : H12AffineEnvironment.transform 12 682 env9066 = env9067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 682 env9066 == env9067) = true)

theorem identity9067 : scanCanonicalize (H12AffineFastState.compose env9067 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound9067 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9068 : List Nat := [2,4,8,16,32,17,18,62,512,63,522,43,568,560,561,9,43,529,549,561,16,32,522,35,547,43,17,561,560,49,4,545,548,539,43,513]

theorem envBound9068 : H12AffineFastState.Bounded env9068 := by
  intro p hp
  have h : env9068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9067_9068 : H12AffineEnvironment.transform 6 18 env9067 = env9068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env9067 == env9068) = true)

theorem identity9068 : scanCanonicalize (H12AffineFastState.compose env9068 (packedSelected [0,1,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound9068 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env9069 : List Nat := [2,4,8,16,27,17,18,5,512,4,522,16,515,523,522,9,16,529,542,522,16,27,522,24,536,16,17,522,523,10,4,538,543,539,16,513]

theorem envBound9069 : H12AffineFastState.Bounded env9069 := by
  intro p hp
  have h : env9069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9068_9069 : H12AffineEnvironment.transform 4 27 env9068 = env9069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env9068 == env9069) = true)

theorem identity9069 : scanCanonicalize (H12AffineFastState.compose env9069 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound9069 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9070 : List Nat := [2,4,7,16,20,17,18,5,512,4,517,16,515,516,517,6,16,529,529,517,16,20,517,23,535,16,17,517,516,5,4,533,528,532,16,513]

theorem envBound9070 : H12AffineFastState.Bounded env9070 := by
  intro p hp
  have h : env9070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9069_9070 : H12AffineEnvironment.transform 2 7 env9069 = env9070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env9069 == env9070) = true)

theorem identity9070 : scanCanonicalize (H12AffineFastState.compose env9070 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound9070 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9071 : List Nat := [2,0,3,16,16,17,18,1,512,0,513,16,515,512,513,2,16,529,529,513,16,16,513,19,531,16,17,513,512,1,0,529,528,528,16,513]

theorem envBound9071 : H12AffineFastState.Bounded env9071 := by
  intro p hp
  have h : env9071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9070_9071 : H12AffineEnvironment.transform 1 0 env9070 = env9071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env9070 == env9071) = true)

theorem identity9071 : scanCanonicalize (H12AffineFastState.compose env9071 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound9071 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9072 : List Nat := [2,0,3,16,16,17,18,1,16,0,17,16,19,16,17,2,16,1,1,17,16,16,17,19,3,16,17,17,16,1,0,1,0,0,16,17]

theorem envBound9072 : H12AffineFastState.Bounded env9072 := by
  intro p hp
  have h : env9072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9071_9072 : H12AffineEnvironment.transform 8 16 env9071 = env9072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env9071 == env9072) = true)

def env9073 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8201,65536,4096,77977,4764,8201,65,74370,4720,74448,8329,4097,78537,77946,77947,75786,4,544,4765,73770,78578,73970]

theorem envBound9073 : H12AffineFastState.Bounded env9073 := by
  intro p hp
  have h : env9073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9061_9073 : H12AffineEnvironment.transform 13 561 env9061 = env9073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9061 == env9073) = true)

theorem identity9073 : scanCanonicalize (H12AffineFastState.compose env9073 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12979) := by decide +kernel

theorem selectedBound9073 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9074 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8201,12979,4096,554,4764,8201,65,4145,4720,4195,8329,4097,122,713,712,6841,4,544,4765,4761,65,4673]

theorem envBound9074 : H12AffineFastState.Bounded env9074 := by
  intro p hp
  have h : env9074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9073_9074 : H12AffineEnvironment.transform 15 12979 env9073 = env9074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12979 env9073 == env9074) = true)

theorem identity9074 : scanCanonicalize (H12AffineFastState.compose env9074 (packedSelected [14] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9074 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9075 : List Nat := [2,4,8,16,32,64,121,4,512,5,2048,4096,8192,561,8201,12874,4096,554,4709,8201,65,4145,4720,4195,8304,4097,122,560,561,6720,4,544,4708,4704,65,4673]

theorem envBound9075 : H12AffineFastState.Bounded env9075 := by
  intro p hp
  have h : env9075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9074_9075 : H12AffineEnvironment.transform 6 121 env9074 = env9075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9074 == env9075) = true)

theorem identity9075 : scanCanonicalize (H12AffineFastState.compose env9075 (packedSelected [1,2,3,5,8,10,11,13,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound9075 : packedSelected [1,2,3,5,8,10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env9076 : List Nat := [2,4,8,16,32,64,121,4,512,5,2048,560,8192,561,8201,8314,560,554,85,8201,65,513,64,595,8304,561,122,560,561,2160,4,544,84,80,65,113]

theorem envBound9076 : H12AffineFastState.Bounded env9076 := by
  intro p hp
  have h : env9076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9075_9076 : H12AffineEnvironment.transform 11 560 env9075 = env9076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env9075 == env9076) = true)

theorem identity9076 : scanCanonicalize (H12AffineFastState.compose env9076 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 112) := by decide +kernel

theorem selectedBound9076 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env9077 : List Nat := [2,4,8,16,32,64,121,4,112,5,2048,64,8192,65,8201,8314,64,90,85,8201,65,113,64,35,8304,65,122,64,65,2160,4,80,84,80,65,113]

theorem envBound9077 : H12AffineFastState.Bounded env9077 := by
  intro p hp
  have h : env9077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9076_9077 : H12AffineEnvironment.transform 8 112 env9076 = env9077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 112 env9076 == env9077) = true)

theorem identity9077 : scanCanonicalize (H12AffineFastState.compose env9077 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 37) := by decide +kernel

theorem selectedBound9077 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env9078 : List Nat := [2,4,8,16,32,64,121,4,112,5,37,64,8192,65,8201,8314,64,90,85,8201,65,113,64,35,8304,65,122,64,65,85,4,80,84,80,65,113]

theorem envBound9078 : H12AffineFastState.Bounded env9078 := by
  intro p hp
  have h : env9078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9077_9078 : H12AffineEnvironment.transform 10 37 env9077 = env9078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 37 env9077 == env9078) = true)

theorem identity9078 : scanCanonicalize (H12AffineFastState.compose env9078 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9078 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env9079 : List Nat := [2,4,8,1,32,64,104,4,97,5,37,64,8192,65,8201,8299,64,75,68,8201,65,96,64,35,8289,65,107,64,65,68,4,65,69,65,65,96]

theorem envBound9079 : H12AffineFastState.Bounded env9079 := by
  intro p hp
  have h : env9079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9078_9079 : H12AffineEnvironment.transform 3 1 env9078 = env9079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9078 == env9079) = true)

theorem identity9079 : scanCanonicalize (H12AffineFastState.compose env9079 (packedSelected [0,2,4,7,9,12] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9079 : packedSelected [0,2,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env9080 : List Nat := [2,4,3,1,32,64,99,4,97,5,37,64,8192,65,8194,8288,64,64,68,8194,65,96,64,35,8289,65,96,64,65,68,4,65,69,65,65,96]

theorem envBound9080 : H12AffineFastState.Bounded env9080 := by
  intro p hp
  have h : env9080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9079_9080 : H12AffineEnvironment.transform 2 3 env9079 = env9080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9079 == env9080) = true)

def env9081 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524524,16777216,8329,16855761,807681,4735913,4735573,17324939,529048,21517022,524289,17322923,19415346,16778207]

theorem envBound9081 : H12AffineFastState.Bounded env9081 := by
  intro p hp
  have h : env9081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8788_9081 : H12AffineEnvironment.transform 26 807681 env8788 = env9081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 807681 env8788 == env9081) = true)

def env9082 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524524,90336,8329,21041,807681,4735913,4735573,605035,529048,4796990,524289,602955,2695634,90943]

theorem envBound9082 : H12AffineFastState.Bounded env9082 := by
  intro p hp
  have h : env9082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9081_9082 : H12AffineEnvironment.transform 23 90336 env9081 = env9082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env9081 == env9082) = true)

def env9083 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,4960,8692,2097152,4194304,5004,90336,8329,21041,278625,4214985,4215093,75787,504,4268382,4961,73771,2175666,90943]

theorem envBound9083 : H12AffineFastState.Bounded env9083 := by
  intro p hp
  have h : env9083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9082_9083 : H12AffineEnvironment.transform 18 4960 env9082 = env9083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env9082 == env9083) = true)

theorem identity9083 : scanCanonicalize (H12AffineFastState.compose env9083 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24770) := by decide +kernel

theorem selectedBound9083 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9084 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24770,4605,262144,4960,8692,2097152,4194304,5004,34,8329,21041,278625,4214985,4215093,18633,504,4211100,4961,16617,2118256,1021]

theorem envBound9084 : H12AffineFastState.Bounded env9084 := by
  intro p hp
  have h : env9084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9083_9084 : H12AffineEnvironment.transform 15 24770 env9083 = env9084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24770 env9083 == env9084) = true)

def env9085 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24770,4605,262144,4960,8692,64,4194304,5004,34,8329,21041,278625,4214985,4215093,18633,504,4211100,4961,16617,21040,1021]

theorem envBound9085 : H12AffineFastState.Bounded env9085 := by
  intro p hp
  have h : env9085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9084_9085 : H12AffineEnvironment.transform 20 64 env9084 = env9085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env9084 == env9085) = true)

theorem identity9085 : scanCanonicalize (H12AffineFastState.compose env9085 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4170) := by decide +kernel

theorem selectedBound9085 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9086 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24770,4605,4170,4960,8692,64,4194304,5004,34,8329,21041,20523,4214985,4215093,18633,504,4211100,4961,16617,21040,1021]

theorem envBound9086 : H12AffineFastState.Bounded env9086 := by
  intro p hp
  have h : env9086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9085_9086 : H12AffineEnvironment.transform 17 4170 env9085 = env9086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4170 env9085 == env9086) = true)

def env9087 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,232,8692,8234,4605,4170,4960,8692,64,4194304,5004,34,8329,4825,4291,4198433,4198877,2081,504,4194676,4961,1,4824,1021]

theorem envBound9087 : H12AffineFastState.Bounded env9087 := by
  intro p hp
  have h : env9087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9086_9087 : H12AffineEnvironment.transform 13 232 env9086 = env9087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env9086 == env9087) = true)

theorem identity9087 : scanCanonicalize (H12AffineFastState.compose env9087 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound9087 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9088 : List Nat := [2,4,8,16,32,64,128,84,512,85,2048,4096,8192,232,8352,8234,4265,4170,4660,8352,64,4194304,4824,34,8329,4825,4291,4198433,4198537,2081,172,4194336,4661,1,4824,681]

theorem envBound9088 : H12AffineFastState.Bounded env9088 := by
  intro p hp
  have h : env9088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9087_9088 : H12AffineEnvironment.transform 7 84 env9087 = env9088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env9087 == env9088) = true)

theorem identity9088 : scanCanonicalize (H12AffineFastState.compose env9088 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound9088 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9089 : List Nat := [2,4,8,16,32,64,128,84,512,85,675,4096,8192,232,8352,8234,4265,4170,4660,8352,64,4194304,4824,34,8329,4825,4291,4198433,4198537,642,172,4194336,4661,1,4824,681]

theorem envBound9089 : H12AffineFastState.Bounded env9089 := by
  intro p hp
  have h : env9089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9088_9089 : H12AffineEnvironment.transform 10 675 env9088 = env9089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env9088 == env9089) = true)

theorem identity9089 : scanCanonicalize (H12AffineFastState.compose env9089 (packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS)) = affineNative (2^(11+1) ^^^ 713) := by decide +kernel

theorem selectedBound9089 : packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env9090 : List Nat := [2,4,8,16,32,64,128,84,512,85,675,713,8192,232,8352,8234,608,643,253,8352,64,4194304,17,34,8329,16,522,4195048,4194880,642,172,4194336,252,1,17,681]

theorem envBound9090 : H12AffineFastState.Bounded env9090 := by
  intro p hp
  have h : env9090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9089_9090 : H12AffineEnvironment.transform 11 713 env9089 = env9090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 713 env9089 == env9090) = true)

theorem identity9090 : scanCanonicalize (H12AffineFastState.compose env9090 (packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS)) = affineNative (2^(21+1) ^^^ 217) := by decide +kernel

theorem selectedBound9090 : packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS < 2^1333 := by decide +kernel

def env9091 : List Nat := [2,4,8,16,32,64,128,84,512,85,675,713,8192,232,8352,8234,608,643,253,8352,64,217,17,34,8329,16,522,561,665,642,172,249,252,1,17,681]

theorem envBound9091 : H12AffineFastState.Bounded env9091 := by
  intro p hp
  have h : env9091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9090_9091 : H12AffineEnvironment.transform 21 217 env9090 = env9091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 217 env9090 == env9091) = true)

theorem identity9091 : scanCanonicalize (H12AffineFastState.compose env9091 (packedSelected [10,11,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 731) := by decide +kernel

theorem selectedBound9091 : packedSelected [10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env9092 : List Nat := [2,4,8,16,32,64,128,84,512,85,675,713,731,232,635,753,608,643,253,635,64,217,17,34,594,16,522,561,665,642,172,249,252,1,17,681]

theorem envBound9092 : H12AffineFastState.Bounded env9092 := by
  intro p hp
  have h : env9092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9091_9092 : H12AffineEnvironment.transform 12 731 env9091 = env9092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 731 env9091 == env9092) = true)

theorem identity9092 : scanCanonicalize (H12AffineFastState.compose env9092 (packedSelected [2,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound9092 : packedSelected [2,9,11] rootPS < 2^1333 := by decide +kernel

def env9093 : List Nat := [2,4,8,16,32,59,128,47,512,46,675,690,672,147,512,650,539,643,134,512,59,162,17,34,553,16,522,561,665,642,172,130,135,1,17,681]

theorem envBound9093 : H12AffineFastState.Bounded env9093 := by
  intro p hp
  have h : env9093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9092_9093 : H12AffineEnvironment.transform 5 59 env9092 = env9093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env9092 == env9093) = true)

theorem identity9093 : scanCanonicalize (H12AffineFastState.compose env9093 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound9093 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env9094 : List Nat := [2,4,8,16,32,59,128,47,42,46,137,152,138,147,42,160,49,169,134,42,59,162,17,34,3,16,32,27,179,168,172,130,135,1,17,131]

theorem envBound9094 : H12AffineFastState.Bounded env9094 := by
  intro p hp
  have h : env9094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9093_9094 : H12AffineEnvironment.transform 8 42 env9093 = env9094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env9093 == env9094) = true)

theorem identity9094 : scanCanonicalize (H12AffineFastState.compose env9094 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound9094 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env9095 : List Nat := [2,4,8,16,32,59,50,47,42,46,59,42,56,33,42,18,49,27,52,42,59,16,17,34,3,16,32,27,1,26,30,48,53,1,17,49]

theorem envBound9095 : H12AffineFastState.Bounded env9095 := by
  intro p hp
  have h : env9095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9094_9095 : H12AffineEnvironment.transform 6 50 env9094 = env9095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env9094 == env9095) = true)

theorem identity9095 : scanCanonicalize (H12AffineFastState.compose env9095 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound9095 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9096 : List Nat := [2,4,8,16,11,16,25,4,1,5,16,1,19,10,1,18,26,27,31,1,16,16,17,9,3,16,11,27,1,26,30,27,30,1,17,26]

theorem envBound9096 : H12AffineFastState.Bounded env9096 := by
  intro p hp
  have h : env9096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9095_9096 : H12AffineEnvironment.transform 4 11 env9095 = env9096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env9095 == env9096) = true)

theorem identity9096 : scanCanonicalize (H12AffineFastState.compose env9096 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9096 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9097 : List Nat := [2,4,8,11,11,11,2,4,1,5,11,1,8,10,1,9,1,0,4,1,11,11,10,9,3,11,11,0,1,1,5,0,5,1,10,1]

theorem envBound9097 : H12AffineFastState.Bounded env9097 := by
  intro p hp
  have h : env9097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9096_9097 : H12AffineEnvironment.transform 3 11 env9096 = env9097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9096 == env9097) = true)

theorem identity9097 : scanCanonicalize (H12AffineFastState.compose env9097 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9097 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9098 : List Nat := [2,4,2,1,1,1,2,4,1,5,1,1,2,0,1,3,1,0,4,1,1,1,0,3,3,1,1,0,1,1,5,0,5,1,0,1]

theorem envBound9098 : H12AffineFastState.Bounded env9098 := by
  intro p hp
  have h : env9098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9097_9098 : H12AffineEnvironment.transform 2 2 env9097 = env9098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9097 == env9098) = true)

def leafEnv9098 : List Nat := [2,4,2,1,1,1,2,4,1,5,1,1,2,0,1,3,1,0,4,1,1,1,0,3,4,3,1,1,1,0,1,1,5,0,5,1,5,3,0,1,1,0,0]

def active9098 : List Nat := [0,1]

def tree9098 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9098 : H12WitnessSearch.Good tree9098 := H12GlobalWitnessIndex.good

theorem leafIdentity9098 : H12AffineFastState.composeSystem env9098 rootObs = leafEnv9098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9098 rootObs == leafEnv9098) = true)

theorem terminalChecked9098 : H12PackedTerminal.terminalCheckFast leafEnv9098 active9098 tree9098 = true := by decide +kernel

def env9099 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,233,8692,8235,4605,4170,4960,8692,64,4194304,5004,34,8329,4824,4290,4198432,4198876,2080,504,4194677,4961,0,4825,1021]

theorem envBound9099 : H12AffineFastState.Bounded env9099 := by
  intro p hp
  have h : env9099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9086_9099 : H12AffineEnvironment.transform 13 233 env9086 = env9099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env9086 == env9099) = true)

theorem identity9099 : scanCanonicalize (H12AffineFastState.compose env9099 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound9099 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9100 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,233,8692,8235,4605,4170,4960,8692,64,477,5004,34,8329,4824,4290,4605,4097,2080,504,168,4961,0,4825,1021]

theorem envBound9100 : H12AffineFastState.Bounded env9100 := by
  intro p hp
  have h : env9100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9099_9100 : H12AffineEnvironment.transform 21 477 env9099 = env9100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env9099 == env9100) = true)

theorem identity9100 : scanCanonicalize (H12AffineFastState.compose env9100 (packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS)) = affineNative (2^(10+1) ^^^ 934) := by decide +kernel

theorem selectedBound9100 : packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env9101 : List Nat := [2,4,8,16,32,64,128,256,512,257,934,4096,8192,233,8692,8235,4605,4170,4960,8692,64,477,5004,34,8329,4824,4290,4605,4097,902,504,168,4961,0,4825,1021]

theorem envBound9101 : H12AffineFastState.Bounded env9101 := by
  intro p hp
  have h : env9101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9100_9101 : H12AffineEnvironment.transform 10 934 env9100 = env9101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 934 env9100 == env9101) = true)

theorem identity9101 : scanCanonicalize (H12AffineFastState.compose env9101 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9101 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env9102 : List Nat := [2,4,8,16,32,64,128,253,512,252,603,4096,8192,233,8201,8235,4096,4170,4765,8201,64,32,4721,34,8329,4824,4290,4096,4097,635,5,168,4764,0,4825,512]

theorem envBound9102 : H12AffineFastState.Bounded env9102 := by
  intro p hp
  have h : env9102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9101_9102 : H12AffineEnvironment.transform 7 253 env9101 = env9102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9101 == env9102) = true)

theorem identity9102 : scanCanonicalize (H12AffineFastState.compose env9102 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9102 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9103 : List Nat := [2,4,8,16,32,64,41,84,512,85,603,4096,8192,64,8201,8235,4096,4170,4660,8201,64,32,4721,34,8224,4721,4203,4096,4097,635,5,1,4661,0,4720,512]

theorem envBound9103 : H12AffineFastState.Bounded env9103 := by
  intro p hp
  have h : env9103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9102_9103 : H12AffineEnvironment.transform 6 41 env9102 = env9103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9102 == env9103) = true)

theorem identity9103 : scanCanonicalize (H12AffineFastState.compose env9103 (packedSelected [0,1,2,3,4,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound9103 : packedSelected [0,1,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env9104 : List Nat := [2,4,8,16,32,64,41,84,512,85,603,544,8192,64,8201,8235,544,618,20,8201,64,32,81,34,8224,81,587,544,545,635,5,1,21,0,80,512]

theorem envBound9104 : H12AffineFastState.Bounded env9104 := by
  intro p hp
  have h : env9104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9103_9104 : H12AffineEnvironment.transform 11 544 env9103 = env9104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env9103 == env9104) = true)

theorem identity9104 : scanCanonicalize (H12AffineFastState.compose env9104 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 99) := by decide +kernel

theorem selectedBound9104 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9105 : List Nat := [2,4,8,16,32,64,41,84,512,85,603,544,99,64,106,72,544,618,20,106,64,32,81,34,67,81,587,544,545,635,5,1,21,0,80,512]

theorem envBound9105 : H12AffineFastState.Bounded env9105 := by
  intro p hp
  have h : env9105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9104_9105 : H12AffineEnvironment.transform 12 99 env9104 = env9105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 99 env9104 == env9105) = true)

theorem identity9105 : scanCanonicalize (H12AffineFastState.compose env9105 (packedSelected [0,2,4,8,12] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound9105 : packedSelected [0,2,4,8,12] rootPS < 2^1333 := by decide +kernel

def env9106 : List Nat := [2,4,8,16,32,64,41,84,17,85,74,49,99,64,106,72,49,123,20,106,64,32,81,34,67,81,90,49,48,106,5,1,21,0,80,17]

theorem envBound9106 : H12AffineFastState.Bounded env9106 := by
  intro p hp
  have h : env9106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9105_9106 : H12AffineEnvironment.transform 8 17 env9105 = env9106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env9105 == env9106) = true)

theorem identity9106 : scanCanonicalize (H12AffineFastState.compose env9106 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9106 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env9107 : List Nat := [2,4,8,16,32,11,41,31,17,30,1,49,40,11,33,3,49,48,20,33,11,32,26,34,8,26,17,49,48,33,5,1,21,0,27,17]

theorem envBound9107 : H12AffineFastState.Bounded env9107 := by
  intro p hp
  have h : env9107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9106_9107 : H12AffineEnvironment.transform 5 11 env9106 = env9107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9106 == env9107) = true)

theorem identity9107 : scanCanonicalize (H12AffineFastState.compose env9107 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9107 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9108 : List Nat := [2,4,3,16,32,0,34,20,17,21,1,49,35,0,33,3,49,48,20,33,0,32,17,34,3,17,17,49,48,33,5,1,21,0,16,17]

theorem envBound9108 : H12AffineFastState.Bounded env9108 := by
  intro p hp
  have h : env9108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9107_9108 : H12AffineEnvironment.transform 2 3 env9107 = env9108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9107 == env9108) = true)

theorem identity9108 : scanCanonicalize (H12AffineFastState.compose env9108 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound9108 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9109 : List Nat := [2,4,3,16,17,0,19,20,17,21,1,0,18,0,16,3,0,1,20,16,0,17,17,19,3,17,17,0,1,16,5,1,21,0,16,17]

theorem envBound9109 : H12AffineFastState.Bounded env9109 := by
  intro p hp
  have h : env9109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9108_9109 : H12AffineEnvironment.transform 4 17 env9108 = env9109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env9108 == env9109) = true)

theorem identity9109 : scanCanonicalize (H12AffineFastState.compose env9109 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9109 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9110 : List Nat := [2,4,3,1,0,0,2,5,0,4,1,0,3,0,1,3,0,1,5,1,0,0,0,2,3,0,0,0,1,1,5,1,4,0,1,0]

theorem envBound9110 : H12AffineFastState.Bounded env9110 := by
  intro p hp
  have h : env9110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9109_9110 : H12AffineEnvironment.transform 3 1 env9109 = env9110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9109 == env9110) = true)

def leafEnv9110 : List Nat := [2,4,3,1,0,0,2,5,0,4,1,0,3,0,1,3,0,1,5,1,0,0,0,2,4,3,1,0,0,0,1,1,5,1,4,0,5,2,1,0,1,0,0]

def active9110 : List Nat := [0,1]

def tree9110 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9110 : H12WitnessSearch.Good tree9110 := H12GlobalWitnessIndex.good

theorem leafIdentity9110 : H12AffineFastState.composeSystem env9110 rootObs = leafEnv9110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9110 rootObs == leafEnv9110) = true)

theorem terminalChecked9110 : H12PackedTerminal.terminalCheckFast leafEnv9110 active9110 tree9110 = true := by decide +kernel

def env9111 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24770,4605,262144,4960,8692,65,4194304,5004,34,8329,21041,278625,4214985,4215093,18633,504,4211100,4961,16617,21041,1021]

theorem envBound9111 : H12AffineFastState.Bounded env9111 := by
  intro p hp
  have h : env9111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9084_9111 : H12AffineEnvironment.transform 20 65 env9084 = env9111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env9084 == env9111) = true)

theorem identity9111 : scanCanonicalize (H12AffineFastState.compose env9111 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 555) := by decide +kernel

theorem selectedBound9111 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9112 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24770,4605,555,4960,8692,65,4194304,5004,34,8329,21041,16970,4214985,4215093,18633,504,4211100,4961,16617,21041,1021]

theorem envBound9112 : H12AffineFastState.Bounded env9112 := by
  intro p hp
  have h : env9112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9111_9112 : H12AffineEnvironment.transform 17 555 env9111 = env9112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 555 env9111 == env9112) = true)

def env9113 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,232,8692,8234,4605,555,4960,8692,65,4194304,5004,34,8329,4825,674,4198433,4198877,2081,504,4194676,4961,1,4825,1021]

theorem envBound9113 : H12AffineFastState.Bounded env9113 := by
  intro p hp
  have h : env9113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9112_9113 : H12AffineEnvironment.transform 13 232 env9112 = env9113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env9112 == env9113) = true)

theorem identity9113 : scanCanonicalize (H12AffineFastState.compose env9113 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound9113 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9114 : List Nat := [2,4,8,16,32,64,128,85,512,84,2048,4096,8192,232,8353,8234,4264,555,4661,8353,65,4194304,4825,34,8329,4825,674,4198433,4198536,2081,173,4194337,4660,1,4825,680]

theorem envBound9114 : H12AffineFastState.Bounded env9114 := by
  intro p hp
  have h : env9114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9113_9114 : H12AffineEnvironment.transform 7 85 env9113 = env9114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env9113 == env9114) = true)

theorem identity9114 : scanCanonicalize (H12AffineFastState.compose env9114 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound9114 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env9115 : List Nat := [2,4,8,16,32,64,128,85,512,84,2048,2194,8192,232,8353,8234,2106,555,2727,8353,65,4194304,2635,34,8329,2635,674,4196531,4196378,2081,173,4194337,2726,1,2635,680]

theorem envBound9115 : H12AffineFastState.Bounded env9115 := by
  intro p hp
  have h : env9115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9114_9115 : H12AffineEnvironment.transform 11 2194 env9114 = env9115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env9114 == env9115) = true)

theorem identity9115 : scanCanonicalize (H12AffineFastState.compose env9115 (packedSelected [1,3,4,7,9,12,14,15,27] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9115 : packedSelected [1,3,4,7,9,12,14,15,27] rootPS < 2^1333 := by decide +kernel

def env9116 : List Nat := [2,4,8,16,32,64,121,85,512,84,2048,2155,8192,17,8280,8234,2106,555,2654,8280,65,4194304,2635,34,8304,2635,603,4196426,4196378,2081,84,4194337,2655,1,2635,593]

theorem envBound9116 : H12AffineFastState.Bounded env9116 := by
  intro p hp
  have h : env9116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9115_9116 : H12AffineEnvironment.transform 6 121 env9115 = env9116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9115 == env9116) = true)

theorem identity9116 : scanCanonicalize (H12AffineFastState.compose env9116 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound9116 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env9117 : List Nat := [2,4,8,16,32,64,121,85,512,84,2048,2155,8192,17,8280,8234,2106,555,2654,8280,65,113,2635,34,8304,2635,603,2107,2155,2081,84,80,2655,1,2635,593]

theorem envBound9117 : H12AffineFastState.Bounded env9117 := by
  intro p hp
  have h : env9117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9116_9117 : H12AffineEnvironment.transform 21 113 env9116 = env9117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env9116 == env9117) = true)

theorem identity9117 : scanCanonicalize (H12AffineFastState.compose env9117 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound9117 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env9118 : List Nat := [2,4,8,16,32,64,121,85,113,84,2048,2155,8192,17,8280,8234,2106,90,2095,8280,65,113,2106,34,8304,2106,42,2107,2155,2081,84,80,2094,1,2106,32]

theorem envBound9118 : H12AffineFastState.Bounded env9118 := by
  intro p hp
  have h : env9118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9117_9118 : H12AffineEnvironment.transform 8 113 env9117 = env9118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env9117 == env9118) = true)

def env9119 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,233,8692,8235,4605,555,4960,8692,65,4194304,5004,34,8329,4824,675,4198432,4198876,2080,504,4194677,4961,0,4824,1021]

theorem envBound9119 : H12AffineFastState.Bounded env9119 := by
  intro p hp
  have h : env9119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9112_9119 : H12AffineEnvironment.transform 13 233 env9112 = env9119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env9112 == env9119) = true)

theorem identity9119 : scanCanonicalize (H12AffineFastState.compose env9119 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound9119 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env9120 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,233,8692,8235,4605,555,4960,8692,65,476,5004,34,8329,4824,675,4604,4096,2080,504,169,4961,0,4824,1021]

theorem envBound9120 : H12AffineFastState.Bounded env9120 := by
  intro p hp
  have h : env9120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9119_9120 : H12AffineEnvironment.transform 21 476 env9119 = env9120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env9119 == env9120) = true)

theorem identity9120 : scanCanonicalize (H12AffineFastState.compose env9120 (packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS)) = affineNative (2^(11+1) ^^^ 2455) := by decide +kernel

theorem selectedBound9120 : packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env9121 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,2455,8192,233,8692,8235,2154,555,2807,8692,65,476,2587,34,8329,2895,675,2155,2455,2080,504,169,2806,0,2895,1021]

theorem envBound9121 : H12AffineFastState.Bounded env9121 := by
  intro p hp
  have h : env9121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9120_9121 : H12AffineEnvironment.transform 11 2455 env9120 = env9121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2455 env9120 == env9121) = true)

theorem identity9121 : scanCanonicalize (H12AffineFastState.compose env9121 (packedSelected [0,3,4,5,7,8,9,12,13,15,17,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound9121 : packedSelected [0,3,4,5,7,8,9,12,13,15,17,24] rootPS < 2^1333 := by decide +kernel

def env9122 : List Nat := [2,4,8,16,32,64,128,173,512,172,2048,2106,8192,233,8281,8235,2154,555,2807,8281,65,113,2587,34,8329,2786,675,2155,2106,2080,85,169,2806,0,2786,592]

theorem envBound9122 : H12AffineFastState.Bounded env9122 := by
  intro p hp
  have h : env9122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9121_9122 : H12AffineEnvironment.transform 7 173 env9121 = env9122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env9121 == env9122) = true)

theorem identity9122 : scanCanonicalize (H12AffineFastState.compose env9122 (packedSelected [0,1,3,4,10,11,12,13,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 2720) := by decide +kernel

theorem selectedBound9122 : packedSelected [0,1,3,4,10,11,12,13,14,15,18] rootPS < 2^1333 := by decide +kernel

def env9123 : List Nat := [2,4,8,16,32,64,128,173,512,172,2048,2106,2720,233,2809,2699,2154,555,2807,2809,65,113,2587,34,2601,2786,675,2155,2106,2080,85,169,2806,0,2786,592]

theorem envBound9123 : H12AffineFastState.Bounded env9123 := by
  intro p hp
  have h : env9123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9122_9123 : H12AffineEnvironment.transform 12 2720 env9122 = env9123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2720 env9122 == env9123) = true)

theorem identity9123 : scanCanonicalize (H12AffineFastState.compose env9123 (packedSelected [2,3,4,7,8,14] rootPS)) = affineNative (2^(10+1) ^^^ 755) := by decide +kernel

theorem selectedBound9123 : packedSelected [2,3,4,7,8,14] rootPS < 2^1333 := by decide +kernel

def env9124 : List Nat := [2,4,8,16,32,64,128,173,512,172,755,713,83,233,10,120,665,555,4,10,65,113,232,34,218,17,675,664,713,723,85,169,5,0,17,592]

theorem envBound9124 : H12AffineFastState.Bounded env9124 := by
  intro p hp
  have h : env9124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9123_9124 : H12AffineEnvironment.transform 10 755 env9123 = env9124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 755 env9123 == env9124) = true)

theorem identity9124 : scanCanonicalize (H12AffineFastState.compose env9124 (packedSelected [0,1,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound9124 : packedSelected [0,1,8,9,10] rootPS < 2^1333 := by decide +kernel

def env9125 : List Nat := [2,4,8,16,32,64,128,173,0,172,243,201,83,233,10,120,153,43,4,10,65,113,232,34,218,17,163,152,201,211,85,169,5,0,17,80]

theorem envBound9125 : H12AffineFastState.Bounded env9125 := by
  intro p hp
  have h : env9125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9124_9125 : H12AffineEnvironment.transform 8 0 env9124 = env9125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env9124 == env9125) = true)

theorem identity9125 : scanCanonicalize (H12AffineFastState.compose env9125 (packedSelected [0,4,5,8,9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9125 : packedSelected [0,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env9126 : List Nat := [2,4,2,16,32,64,128,167,0,166,243,195,83,227,0,114,147,33,4,0,65,113,226,34,208,17,163,146,195,211,85,163,5,0,17,80]

theorem envBound9126 : H12AffineFastState.Bounded env9126 := by
  intro p hp
  have h : env9126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9125_9126 : H12AffineEnvironment.transform 2 2 env9125 = env9126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9125 == env9126) = true)

theorem identity9126 : scanCanonicalize (H12AffineFastState.compose env9126 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound9126 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env9127 : List Nat := [2,4,2,16,32,64,115,84,0,85,0,48,83,16,0,114,96,33,4,0,65,113,17,34,35,17,80,97,48,32,85,80,5,0,17,80]

theorem envBound9127 : H12AffineFastState.Bounded env9127 := by
  intro p hp
  have h : env9127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9126_9127 : H12AffineEnvironment.transform 6 115 env9126 = env9127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env9126 == env9127) = true)

theorem identity9127 : scanCanonicalize (H12AffineFastState.compose env9127 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9127 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env9128 : List Nat := [2,4,2,16,32,16,35,4,0,5,0,48,3,16,0,34,48,33,4,0,17,33,17,34,35,17,0,49,48,32,5,0,5,0,17,0]

theorem envBound9128 : H12AffineFastState.Bounded env9128 := by
  intro p hp
  have h : env9128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9127_9128 : H12AffineEnvironment.transform 5 16 env9127 = env9128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9127 == env9128) = true)

theorem identity9128 : scanCanonicalize (H12AffineFastState.compose env9128 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound9128 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9129 : List Nat := [2,4,2,16,17,16,18,4,0,5,0,1,3,16,0,19,1,16,4,0,17,16,17,19,18,17,0,0,1,17,5,0,5,0,17,0]

theorem envBound9129 : H12AffineFastState.Bounded env9129 := by
  intro p hp
  have h : env9129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9128_9129 : H12AffineEnvironment.transform 4 17 env9128 = env9129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env9128 == env9129) = true)

def env9130 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,4961,8692,2097152,4194304,5005,90336,8329,21041,278624,4214984,4215092,75786,505,4268383,4960,73770,2175667,90943]

theorem envBound9130 : H12AffineFastState.Bounded env9130 := by
  intro p hp
  have h : env9130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9082_9130 : H12AffineEnvironment.transform 18 4961 env9082 = env9130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env9082 == env9130) = true)

theorem identity9130 : scanCanonicalize (H12AffineFastState.compose env9130 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9130 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9131 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,2097152,4194304,4720,90336,8329,21041,278624,4214984,4214985,75786,4,4268194,4765,73770,2175667,90818]

theorem envBound9131 : H12AffineFastState.Bounded env9131 := by
  intro p hp
  have h : env9131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9130_9131 : H12AffineEnvironment.transform 7 253 env9130 = env9131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9130 == env9131) = true)

def env9132 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,64,4194304,4720,90336,8329,21041,278624,4214984,4214985,75786,4,4268194,4765,73770,78579,90818]

theorem envBound9132 : H12AffineFastState.Bounded env9132 := by
  intro p hp
  have h : env9132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9131_9132 : H12AffineEnvironment.transform 20 64 env9131 = env9132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env9131 == env9132) = true)

theorem identity9132 : scanCanonicalize (H12AffineFastState.compose env9132 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 266299) := by decide +kernel

theorem selectedBound9132 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9133 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,64,266299,4720,90336,8329,21041,278624,278771,278770,75786,4,340121,4765,73770,78579,90818]

theorem envBound9133 : H12AffineFastState.Bounded env9133 := by
  intro p hp
  have h : env9133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9132_9133 : H12AffineEnvironment.transform 21 266299 env9132 = env9133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 266299 env9132 == env9133) = true)

def env9134 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,94320,4764,8201,64,90187,4720,90336,8329,21041,77840,77955,77954,75786,4,16617,4765,73770,78579,90818]

theorem envBound9134 : H12AffineFastState.Bounded env9134 := by
  intro p hp
  have h : env9134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9133_9134 : H12AffineEnvironment.transform 17 94320 env9133 = env9134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 94320 env9133 == env9134) = true)

theorem identity9134 : scanCanonicalize (H12AffineFastState.compose env9134 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound9134 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9135 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,8322,4096,20722,4764,8201,64,16585,4720,16482,8329,21041,4242,4097,4096,2184,4,16617,4765,168,4721,16960]

theorem envBound9135 : H12AffineFastState.Bounded env9135 := by
  intro p hp
  have h : env9135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9134_9135 : H12AffineEnvironment.transform 15 8322 env9134 = env9135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env9134 == env9135) = true)

theorem identity9135 : scanCanonicalize (H12AffineFastState.compose env9135 (packedSelected [0,2,11,13,14,17,18,27] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound9135 : packedSelected [0,2,11,13,14,17,18,27] rootPS < 2^1333 := by decide +kernel

def env9136 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,17,8192,16384,8201,8322,17,16611,653,8201,64,16585,609,16482,8329,16928,131,16,17,2184,4,16617,652,168,608,16960]

theorem envBound9136 : H12AffineFastState.Bounded env9136 := by
  intro p hp
  have h : env9136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9135_9136 : H12AffineEnvironment.transform 11 17 env9135 = env9136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env9135 == env9136) = true)

theorem identity9136 : scanCanonicalize (H12AffineFastState.compose env9136 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound9136 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env9137 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,17,8192,185,8201,8322,17,90,653,8201,64,112,609,219,8329,665,131,16,17,2184,4,80,652,168,608,761]

theorem envBound9137 : H12AffineFastState.Bounded env9137 := by
  intro p hp
  have h : env9137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9136_9137 : H12AffineEnvironment.transform 13 185 env9136 = env9137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env9136 == env9137) = true)

theorem identity9137 : scanCanonicalize (H12AffineFastState.compose env9137 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9137 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env9138 : List Nat := [2,4,8,16,32,64,120,5,512,4,2048,17,8192,65,8201,8314,17,90,629,8201,64,112,609,35,8305,609,123,16,17,2160,4,80,628,80,608,513]

theorem envBound9138 : H12AffineFastState.Bounded env9138 := by
  intro p hp
  have h : env9138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9137_9138 : H12AffineEnvironment.transform 6 120 env9137 = env9138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9137 == env9138) = true)

theorem identity9138 : scanCanonicalize (H12AffineFastState.compose env9138 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound9138 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env9139 : List Nat := [2,4,8,16,32,64,120,5,512,4,603,17,8192,65,8201,8314,17,90,629,8201,64,112,609,35,8305,609,123,16,17,555,4,80,628,80,608,513]

theorem envBound9139 : H12AffineFastState.Bounded env9139 := by
  intro p hp
  have h : env9139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9138_9139 : H12AffineEnvironment.transform 10 603 env9138 = env9139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env9138 == env9139) = true)

theorem identity9139 : scanCanonicalize (H12AffineFastState.compose env9139 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound9139 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env9140 : List Nat := [2,4,8,16,32,64,120,5,27,4,64,17,8192,65,8201,8314,17,90,110,8201,64,112,122,35,8305,122,123,16,17,48,4,80,111,80,123,26]

theorem envBound9140 : H12AffineFastState.Bounded env9140 := by
  intro p hp
  have h : env9140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9139_9140 : H12AffineEnvironment.transform 8 27 env9139 = env9140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env9139 == env9140) = true)

theorem identity9140 : scanCanonicalize (H12AffineFastState.compose env9140 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9140 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env9141 : List Nat := [2,4,8,16,0,64,88,5,27,4,64,17,8192,65,8201,8282,17,90,78,8201,64,80,90,3,8273,90,91,16,17,16,4,80,79,80,91,26]

theorem envBound9141 : H12AffineFastState.Bounded env9141 := by
  intro p hp
  have h : env9141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9140_9141 : H12AffineEnvironment.transform 4 0 env9140 = env9141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9140 == env9141) = true)

theorem identity9141 : scanCanonicalize (H12AffineFastState.compose env9141 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound9141 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env9142 : List Nat := [2,4,8,16,0,64,88,5,27,4,64,17,89,65,80,3,17,90,78,80,64,80,90,3,8,90,91,16,17,16,4,80,79,80,91,26]

theorem envBound9142 : H12AffineFastState.Bounded env9142 := by
  intro p hp
  have h : env9142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9141_9142 : H12AffineEnvironment.transform 12 89 env9141 = env9142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env9141 == env9142) = true)

theorem identity9142 : scanCanonicalize (H12AffineFastState.compose env9142 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9142 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9143 : List Nat := [2,4,8,10,0,64,66,5,1,4,64,11,67,65,74,3,11,64,78,74,64,74,64,3,8,64,65,10,11,10,4,74,79,74,65,0]

theorem envBound9143 : H12AffineFastState.Bounded env9143 := by
  intro p hp
  have h : env9143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9142_9143 : H12AffineEnvironment.transform 3 10 env9142 = env9143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9142 == env9143) = true)

theorem identity9143 : scanCanonicalize (H12AffineFastState.compose env9143 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9143 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9144 : List Nat := [2,4,2,0,0,64,66,5,1,4,64,1,67,65,64,3,1,64,68,64,64,64,64,3,2,64,65,0,1,0,4,64,69,64,65,0]

theorem envBound9144 : H12AffineFastState.Bounded env9144 := by
  intro p hp
  have h : env9144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9143_9144 : H12AffineEnvironment.transform 2 2 env9143 = env9144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9143 == env9144) = true)

theorem identity9144 : scanCanonicalize (H12AffineFastState.compose env9144 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 5) := by decide +kernel

theorem selectedBound9144 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9145 : List Nat := [2,4,2,0,0,5,7,5,1,4,5,1,6,4,5,3,1,5,1,5,5,5,5,3,2,5,4,0,1,0,4,5,0,5,4,0]

theorem envBound9145 : H12AffineFastState.Bounded env9145 := by
  intro p hp
  have h : env9145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9144_9145 : H12AffineEnvironment.transform 5 5 env9144 = env9145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 5 env9144 == env9145) = true)

theorem identity9145 : scanCanonicalize (H12AffineFastState.compose env9145 (packedSelected [9] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9145 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env9146 : List Nat := [2,1,2,0,0,0,2,0,1,1,0,1,3,1,0,3,1,0,1,0,0,0,0,3,2,0,1,0,1,0,1,0,0,0,1,0]

theorem envBound9146 : H12AffineFastState.Bounded env9146 := by
  intro p hp
  have h : env9146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9145_9146 : H12AffineEnvironment.transform 1 1 env9145 = env9146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9145 == env9146) = true)

def env9147 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,94321,4764,8201,64,90186,4720,90336,8329,21041,77841,77954,77955,75786,4,16616,4765,73770,78579,90818]

theorem envBound9147 : H12AffineFastState.Bounded env9147 := by
  intro p hp
  have h : env9147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9133_9147 : H12AffineEnvironment.transform 17 94321 env9133 = env9147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 94321 env9133 == env9147) = true)

theorem identity9147 : scanCanonicalize (H12AffineFastState.compose env9147 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 24770) := by decide +kernel

theorem selectedBound9147 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9148 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,24770,4096,4275,4764,8201,64,136,4720,34,8329,21041,20691,20544,20545,18632,4,16616,4765,16616,21041,512]

theorem envBound9148 : H12AffineFastState.Bounded env9148 := by
  intro p hp
  have h : env9148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9147_9148 : H12AffineEnvironment.transform 15 24770 env9147 = env9148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24770 env9147 == env9148) = true)

theorem identity9148 : scanCanonicalize (H12AffineFastState.compose env9148 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9148 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9149 : List Nat := [2,4,8,16,32,64,41,84,512,85,2048,4096,8192,16384,8201,24683,4096,4122,4661,8201,64,33,4720,34,8224,21041,20602,20544,20545,18529,4,16449,4660,16449,21041,512]

theorem envBound9149 : H12AffineFastState.Bounded env9149 := by
  intro p hp
  have h : env9149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9148_9149 : H12AffineEnvironment.transform 6 41 env9148 = env9149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9148 == env9149) = true)

theorem identity9149 : scanCanonicalize (H12AffineFastState.compose env9149 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 6187) := by decide +kernel

theorem selectedBound9149 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env9150 : List Nat := [2,4,8,16,32,64,41,84,512,85,2048,4096,8192,6187,8201,14400,4096,4122,4661,8201,64,33,4720,34,8224,2586,2129,2155,2154,4170,4,6250,4660,6250,2586,512]

theorem envBound9150 : H12AffineFastState.Bounded env9150 := by
  intro p hp
  have h : env9150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9149_9150 : H12AffineEnvironment.transform 13 6187 env9149 = env9150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6187 env9149 == env9150) = true)

theorem identity9150 : scanCanonicalize (H12AffineFastState.compose env9150 (packedSelected [3,4,5,7,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound9150 : packedSelected [3,4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env9151 : List Nat := [2,4,8,16,32,64,41,84,512,85,2048,538,8192,2609,8201,10842,538,512,47,8201,64,33,106,34,8224,2586,2129,2155,2154,592,4,2672,46,2672,2586,512]

theorem envBound9151 : H12AffineFastState.Bounded env9151 := by
  intro p hp
  have h : env9151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9150_9151 : H12AffineEnvironment.transform 11 538 env9150 = env9151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env9150 == env9151) = true)

theorem identity9151 : scanCanonicalize (H12AffineFastState.compose env9151 (packedSelected [0,4,7,9,13,14,17] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound9151 : packedSelected [0,4,7,9,13,14,17] rootPS < 2^1333 := by decide +kernel

def env9152 : List Nat := [2,4,8,16,32,64,41,84,512,85,544,538,8192,17,8201,8314,538,512,47,8201,64,33,106,34,8224,58,625,587,586,592,4,80,46,80,58,512]

theorem envBound9152 : H12AffineFastState.Bounded env9152 := by
  intro p hp
  have h : env9152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9151_9152 : H12AffineEnvironment.transform 10 544 env9151 = env9152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env9151 == env9152) = true)

theorem identity9152 : scanCanonicalize (H12AffineFastState.compose env9152 (packedSelected [0,2,7] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound9152 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env9153 : List Nat := [2,4,8,16,32,64,41,84,48,85,16,42,8192,17,8201,8314,42,48,47,8201,64,33,106,34,8224,58,65,123,122,96,4,80,46,80,58,48]

theorem envBound9153 : H12AffineFastState.Bounded env9153 := by
  intro p hp
  have h : env9153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9152_9153 : H12AffineEnvironment.transform 8 48 env9152 = env9153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env9152 == env9153) = true)

theorem identity9153 : scanCanonicalize (H12AffineFastState.compose env9153 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 83) := by decide +kernel

theorem selectedBound9153 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env9154 : List Nat := [2,4,8,16,32,64,41,84,48,85,16,42,83,17,90,41,42,48,47,90,64,33,106,34,115,58,65,123,122,96,4,80,46,80,58,48]

theorem envBound9154 : H12AffineFastState.Bounded env9154 := by
  intro p hp
  have h : env9154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9153_9154 : H12AffineEnvironment.transform 12 83 env9153 = env9154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 83 env9153 == env9154) = true)

theorem identity9154 : scanCanonicalize (H12AffineFastState.compose env9154 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9154 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env9155 : List Nat := [2,4,8,16,32,16,41,4,48,5,16,42,3,17,10,41,42,48,47,10,16,33,58,34,35,58,17,43,42,48,4,0,46,0,58,48]

theorem envBound9155 : H12AffineFastState.Bounded env9155 := by
  intro p hp
  have h : env9155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9154_9155 : H12AffineEnvironment.transform 5 16 env9154 = env9155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9154 == env9155) = true)

theorem identity9155 : scanCanonicalize (H12AffineFastState.compose env9155 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound9155 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9156 : List Nat := [2,4,3,16,32,16,34,4,48,5,16,33,3,17,1,34,33,48,36,1,16,33,49,34,35,49,17,32,33,48,4,0,37,0,49,48]

theorem envBound9156 : H12AffineFastState.Bounded env9156 := by
  intro p hp
  have h : env9156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9155_9156 : H12AffineEnvironment.transform 2 3 env9155 = env9156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env9155 == env9156) = true)

theorem identity9156 : scanCanonicalize (H12AffineFastState.compose env9156 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound9156 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9157 : List Nat := [2,4,3,16,17,16,19,4,1,5,16,16,3,17,1,19,16,1,21,1,16,16,0,19,18,0,17,17,16,1,4,0,20,0,0,1]

theorem envBound9157 : H12AffineFastState.Bounded env9157 := by
  intro p hp
  have h : env9157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9156_9157 : H12AffineEnvironment.transform 4 17 env9156 = env9157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env9156 == env9157) = true)

theorem identity9157 : scanCanonicalize (H12AffineFastState.compose env9157 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9157 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9158 : List Nat := [2,4,3,0,1,0,3,4,1,5,0,0,3,1,1,3,0,1,5,1,0,0,0,3,2,0,1,1,0,1,4,0,4,0,0,1]

theorem envBound9158 : H12AffineFastState.Bounded env9158 := by
  intro p hp
  have h : env9158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9157_9158 : H12AffineEnvironment.transform 3 0 env9157 = env9158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9157 == env9158) = true)

def env9159 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,65,4194304,4720,90336,8329,21041,278624,4214984,4214985,75786,4,4268194,4765,73770,78578,90818]

theorem envBound9159 : H12AffineFastState.Bounded env9159 := by
  intro p hp
  have h : env9159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9131_9159 : H12AffineEnvironment.transform 20 65 env9131 = env9159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env9131 == env9159) = true)

theorem identity9159 : scanCanonicalize (H12AffineFastState.compose env9159 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 262747) := by decide +kernel

theorem selectedBound9159 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9160 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,65,262747,4720,90336,8329,21041,278624,283283,283282,75786,4,336633,4765,73770,78578,90818]

theorem envBound9160 : H12AffineFastState.Bounded env9160 := by
  intro p hp
  have h : env9160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9159_9160 : H12AffineEnvironment.transform 21 262747 env9159 = env9160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 262747 env9159 == env9160) = true)

def env9161 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,90856,4764,8201,65,90291,4720,90336,8329,21041,74376,77947,77946,75786,4,16401,4765,73770,78578,90818]

theorem envBound9161 : H12AffineFastState.Bounded env9161 := by
  intro p hp
  have h : env9161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9160_9161 : H12AffineEnvironment.transform 17 90856 env9160 = env9161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90856 env9160 == env9161) = true)

def env9162 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8201,65536,4096,73944,4764,8201,65,74371,4720,74448,8329,4097,74376,77947,77946,75786,4,545,4765,73770,78578,73970]

theorem envBound9162 : H12AffineFastState.Bounded env9162 := by
  intro p hp
  have h : env9162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9161_9162 : H12AffineEnvironment.transform 13 560 env9161 = env9162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9161 == env9162) = true)

theorem identity9162 : scanCanonicalize (H12AffineFastState.compose env9162 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8946) := by decide +kernel

theorem selectedBound9162 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9163 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8201,8946,4096,554,4764,8201,65,113,4720,34,8329,4097,122,4745,4744,2808,4,545,4765,728,4096,512]

theorem envBound9163 : H12AffineFastState.Bounded env9163 := by
  intro p hp
  have h : env9163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9162_9163 : H12AffineEnvironment.transform 15 8946 env9162 = env9163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8946 env9162 == env9163) = true)

theorem identity9163 : scanCanonicalize (H12AffineFastState.compose env9163 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound9163 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env9164 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,2195,8192,560,8201,8946,2195,554,2575,8201,65,113,2787,34,8329,2194,122,2586,2587,2808,4,545,2574,728,2195,512]

theorem envBound9164 : H12AffineFastState.Bounded env9164 := by
  intro p hp
  have h : env9164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9163_9164 : H12AffineEnvironment.transform 11 2195 env9163 = env9164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env9163 == env9164) = true)

theorem identity9164 : scanCanonicalize (H12AffineFastState.compose env9164 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9164 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env9165 : List Nat := [2,4,8,16,32,64,121,4,512,5,2048,2154,8192,560,8201,8715,2154,554,2575,8201,65,113,2586,34,8304,2155,122,2586,2587,2561,4,545,2574,545,2154,512]

theorem envBound9165 : H12AffineFastState.Bounded env9165 := by
  intro p hp
  have h : env9165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9164_9165 : H12AffineEnvironment.transform 6 121 env9164 = env9165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9164 == env9165) = true)

theorem identity9165 : scanCanonicalize (H12AffineFastState.compose env9165 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9165 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9166 : List Nat := [2,4,8,16,32,17,40,4,512,5,2048,2107,8192,560,8201,8715,2107,554,2575,8201,16,32,2586,34,8225,2106,43,2586,2587,2561,4,545,2574,545,2107,512]

theorem envBound9166 : H12AffineFastState.Bounded env9166 := by
  intro p hp
  have h : env9166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9165_9166 : H12AffineEnvironment.transform 5 17 env9165 = env9166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9165 == env9166) = true)

theorem identity9166 : scanCanonicalize (H12AffineFastState.compose env9166 (packedSelected [3,4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound9166 : packedSelected [3,4,9,11] rootPS < 2^1333 := by decide +kernel

def env9167 : List Nat := [2,4,8,16,32,17,40,4,512,5,2048,2107,2098,560,2107,2617,2107,554,2575,2107,16,32,2586,34,2067,2106,43,2586,2587,2561,4,545,2574,545,2107,512]

theorem envBound9167 : H12AffineFastState.Bounded env9167 := by
  intro p hp
  have h : env9167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9166_9167 : H12AffineEnvironment.transform 12 2098 env9166 = env9167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env9166 == env9167) = true)

theorem identity9167 : scanCanonicalize (H12AffineFastState.compose env9167 (packedSelected [0,2,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound9167 : packedSelected [0,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env9168 : List Nat := [2,4,8,16,32,17,40,4,512,5,513,570,563,560,570,56,570,554,14,570,16,32,27,34,530,571,43,27,26,0,4,545,15,545,570,512]

theorem envBound9168 : H12AffineFastState.Bounded env9168 := by
  intro p hp
  have h : env9168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9167_9168 : H12AffineEnvironment.transform 10 513 env9167 = env9168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env9167 == env9168) = true)

theorem identity9168 : scanCanonicalize (H12AffineFastState.compose env9168 (packedSelected [0,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9168 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env9169 : List Nat := [2,4,8,16,1,17,9,4,512,5,513,539,530,529,539,25,539,523,14,539,16,1,27,3,530,538,10,27,26,0,4,512,15,512,539,512]

theorem envBound9169 : H12AffineFastState.Bounded env9169 := by
  intro p hp
  have h : env9169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9168_9169 : H12AffineEnvironment.transform 4 1 env9168 = env9169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9168 == env9169) = true)

theorem identity9169 : scanCanonicalize (H12AffineFastState.compose env9169 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound9169 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9170 : List Nat := [2,4,8,16,1,17,9,4,11,5,10,16,25,26,16,25,16,0,14,16,16,1,27,3,25,17,10,27,26,0,4,11,15,11,16,11]

theorem envBound9170 : H12AffineFastState.Bounded env9170 := by
  intro p hp
  have h : env9170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9169_9170 : H12AffineEnvironment.transform 8 11 env9169 = env9170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env9169 == env9170) = true)

theorem identity9170 : scanCanonicalize (H12AffineFastState.compose env9170 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9170 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9171 : List Nat := [2,4,2,16,1,17,3,4,1,5,0,16,19,16,16,19,16,0,4,16,16,1,17,3,19,17,0,17,16,0,4,1,5,1,16,1]

theorem envBound9171 : H12AffineFastState.Bounded env9171 := by
  intro p hp
  have h : env9171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9170_9171 : H12AffineEnvironment.transform 2 2 env9170 = env9171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9170 == env9171) = true)

theorem identity9171 : scanCanonicalize (H12AffineFastState.compose env9171 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9171 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9172 : List Nat := [2,4,2,0,1,1,3,4,1,5,0,0,3,0,0,3,0,0,4,0,0,1,1,3,3,1,0,1,0,0,4,1,5,1,0,1]

theorem envBound9172 : H12AffineFastState.Bounded env9172 := by
  intro p hp
  have h : env9172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9171_9172 : H12AffineEnvironment.transform 3 0 env9171 = env9172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9171 == env9172) = true)

def env9173 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8201,65536,4096,73945,4764,8201,65,74370,4720,74449,8329,4096,74376,77947,77946,75786,4,544,4765,73770,78578,73971]

theorem envBound9173 : H12AffineFastState.Bounded env9173 := by
  intro p hp
  have h : env9173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9161_9173 : H12AffineEnvironment.transform 13 561 env9161 = env9173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env9161 == env9173) = true)

theorem identity9173 : scanCanonicalize (H12AffineFastState.compose env9173 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound9173 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env9174 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8201,8714,4096,723,4764,8201,65,136,4720,219,8329,4096,130,4721,4720,2560,4,544,4765,544,4344,761]

theorem envBound9174 : H12AffineFastState.Bounded env9174 := by
  intro p hp
  have h : env9174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9173_9174 : H12AffineEnvironment.transform 15 8714 env9173 = env9174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env9173 == env9174) = true)

theorem identity9174 : scanCanonicalize (H12AffineFastState.compose env9174 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2242) := by decide +kernel

theorem selectedBound9174 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9175 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,2242,8192,561,8201,8714,2242,723,2654,8201,65,136,2738,219,8329,2242,130,2739,2738,2560,4,544,2655,544,2106,761]

theorem envBound9175 : H12AffineFastState.Bounded env9175 := by
  intro p hp
  have h : env9175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9174_9175 : H12AffineEnvironment.transform 11 2242 env9174 = env9175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2242 env9174 == env9175) = true)

theorem identity9175 : scanCanonicalize (H12AffineFastState.compose env9175 (packedSelected [1,2,8,11,14,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound9175 : packedSelected [1,2,8,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env9176 : List Nat := [2,4,8,16,32,64,128,253,96,252,2048,2242,8192,81,8201,8298,2242,179,2110,8201,65,136,2258,219,8329,2242,130,2259,2258,2144,4,64,2111,64,2106,153]

theorem envBound9176 : H12AffineFastState.Bounded env9176 := by
  intro p hp
  have h : env9176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9175_9176 : H12AffineEnvironment.transform 8 96 env9175 = env9176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env9175 == env9176) = true)

theorem identity9176 : scanCanonicalize (H12AffineFastState.compose env9176 (packedSelected [0,1,2,3,4,7,9,11,12,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound9176 : packedSelected [0,1,2,3,4,7,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env9177 : List Nat := [2,4,8,16,32,0,128,189,32,188,2048,2178,8192,17,8201,8234,2178,179,2110,8201,1,136,2194,155,8329,2178,130,2195,2194,2080,4,0,2111,0,2106,153]

theorem envBound9177 : H12AffineFastState.Bounded env9177 := by
  intro p hp
  have h : env9177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9176_9177 : H12AffineEnvironment.transform 5 0 env9176 = env9177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env9176 == env9177) = true)

theorem identity9177 : scanCanonicalize (H12AffineFastState.compose env9177 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9177 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9178 : List Nat := [2,4,8,16,32,0,40,21,32,20,2048,2090,8192,17,8201,8234,2090,27,2110,8201,1,32,2106,51,8225,2090,42,2107,2106,2080,4,0,2111,0,2106,49]

theorem envBound9178 : H12AffineFastState.Bounded env9178 := by
  intro p hp
  have h : env9178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9177_9178 : H12AffineEnvironment.transform 6 40 env9177 = env9178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9177 == env9178) = true)

theorem identity9178 : scanCanonicalize (H12AffineFastState.compose env9178 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9178 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env9179 : List Nat := [2,4,8,0,32,0,40,5,32,4,2048,2090,8192,1,8201,8234,2090,11,2094,8201,1,32,2090,35,8225,2090,42,2091,2090,2080,4,0,2095,0,2090,33]

theorem envBound9179 : H12AffineFastState.Bounded env9179 := by
  intro p hp
  have h : env9179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9178_9179 : H12AffineEnvironment.transform 3 0 env9178 = env9179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9178 == env9179) = true)

theorem identity9179 : scanCanonicalize (H12AffineFastState.compose env9179 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 35) := by decide +kernel

theorem selectedBound9179 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9180 : List Nat := [2,4,8,0,32,0,40,5,32,4,2048,2090,35,1,42,9,2090,11,2094,42,1,32,2090,35,2,2090,42,2091,2090,2080,4,0,2095,0,2090,33]

theorem envBound9180 : H12AffineFastState.Bounded env9180 := by
  intro p hp
  have h : env9180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9179_9180 : H12AffineEnvironment.transform 12 35 env9179 = env9180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 35 env9179 == env9180) = true)

theorem identity9180 : scanCanonicalize (H12AffineFastState.compose env9180 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound9180 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env9181 : List Nat := [2,4,8,0,4,0,12,5,4,4,2048,2062,7,1,14,9,2062,11,2058,14,1,4,2062,7,2,2062,14,2063,2062,2052,4,0,2059,0,2062,5]

theorem envBound9181 : H12AffineFastState.Bounded env9181 := by
  intro p hp
  have h : env9181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9180_9181 : H12AffineEnvironment.transform 4 4 env9180 = env9181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env9180 == env9181) = true)

theorem identity9181 : scanCanonicalize (H12AffineFastState.compose env9181 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound9181 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9182 : List Nat := [2,4,8,0,4,0,12,5,4,4,0,14,7,1,14,9,14,11,10,14,1,4,14,7,2,14,14,15,14,4,4,0,11,0,14,5]

theorem envBound9182 : H12AffineFastState.Bounded env9182 := by
  intro p hp
  have h : env9182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9181_9182 : H12AffineEnvironment.transform 10 0 env9181 = env9182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9181 == env9182) = true)

theorem identity9182 : scanCanonicalize (H12AffineFastState.compose env9182 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound9182 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9183 : List Nat := [2,1,8,0,1,0,9,0,1,1,0,11,2,1,11,9,11,11,10,11,1,1,11,2,2,11,11,10,11,1,1,0,11,0,11,0]

theorem envBound9183 : H12AffineFastState.Bounded env9183 := by
  intro p hp
  have h : env9183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9182_9183 : H12AffineEnvironment.transform 1 1 env9182 = env9183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env9182 == env9183) = true)

theorem identity9183 : scanCanonicalize (H12AffineFastState.compose env9183 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9183 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9184 : List Nat := [2,1,2,0,1,0,3,0,1,1,0,1,2,1,1,3,1,1,0,1,1,1,1,2,2,1,1,0,1,1,1,0,1,0,1,0]

theorem envBound9184 : H12AffineFastState.Bounded env9184 := by
  intro p hp
  have h : env9184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9183_9184 : H12AffineEnvironment.transform 2 2 env9183 = env9184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9183 == env9184) = true)

def env9185 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,90857,4764,8201,65,90290,4720,90336,8329,21041,74377,77946,77947,75786,4,16400,4765,73770,78578,90818]

theorem envBound9185 : H12AffineFastState.Bounded env9185 := by
  intro p hp
  have h : env9185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9160_9185 : H12AffineEnvironment.transform 17 90857 env9160 = env9185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90857 env9160 == env9185) = true)

def env9186 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8201,65536,4096,73945,4764,8201,65,74370,4720,74448,8329,4097,74377,77946,77947,75786,4,544,4765,73770,78578,73970]

theorem envBound9186 : H12AffineFastState.Bounded env9186 := by
  intro p hp
  have h : env9186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9185_9186 : H12AffineEnvironment.transform 13 560 env9185 = env9186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env9185 == env9186) = true)

def env9187 : List Nat := [2,4,8,16,32,64,128,253,216,252,2048,4096,8192,232,8201,65536,4096,73945,4164,8201,65,73818,4264,73736,8329,4097,73809,77946,77947,75786,4,248,4165,73770,77866,73970]

theorem envBound9187 : H12AffineFastState.Bounded env9187 := by
  intro p hp
  have h : env9187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9186_9187 : H12AffineEnvironment.transform 8 216 env9186 = env9187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env9186 == env9187) = true)

theorem identity9187 : scanCanonicalize (H12AffineFastState.compose env9187 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 12435) := by decide +kernel

theorem selectedBound9187 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9188 : List Nat := [2,4,8,16,32,64,128,253,216,252,2048,4096,8192,232,8201,12435,4096,4170,4164,8201,65,4297,4264,4251,8329,4097,4290,233,232,6297,4,248,4165,4281,185,4193]

theorem envBound9188 : H12AffineFastState.Bounded env9188 := by
  intro p hp
  have h : env9188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9187_9188 : H12AffineEnvironment.transform 15 12435 env9187 = env9188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12435 env9187 == env9188) = true)

theorem identity9188 : scanCanonicalize (H12AffineFastState.compose env9188 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 232) := by decide +kernel

theorem selectedBound9188 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env9189 : List Nat := [2,4,8,16,32,64,128,253,216,252,2048,232,8192,232,8201,8315,232,162,172,8201,65,33,64,115,8329,233,42,233,232,2161,4,248,173,81,185,137]

theorem envBound9189 : H12AffineFastState.Bounded env9189 := by
  intro p hp
  have h : env9189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9188_9189 : H12AffineEnvironment.transform 11 232 env9188 = env9189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env9188 == env9189) = true)

theorem identity9189 : scanCanonicalize (H12AffineFastState.compose env9189 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9189 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9190 : List Nat := [2,4,8,16,32,17,128,172,137,173,2048,185,8192,185,8201,8234,185,162,172,8201,16,33,17,34,8329,184,42,184,185,2080,4,169,173,0,185,137]

theorem envBound9190 : H12AffineFastState.Bounded env9190 := by
  intro p hp
  have h : env9190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9189_9190 : H12AffineEnvironment.transform 5 17 env9189 = env9190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9189 == env9190) = true)

theorem identity9190 : scanCanonicalize (H12AffineFastState.compose env9190 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound9190 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9191 : List Nat := [2,4,8,16,32,17,40,4,33,5,2048,17,8192,17,8201,8234,17,10,4,8201,16,33,17,34,8225,16,42,16,17,2080,4,1,5,0,17,33]

theorem envBound9191 : H12AffineFastState.Bounded env9191 := by
  intro p hp
  have h : env9191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9190_9191 : H12AffineEnvironment.transform 6 40 env9190 = env9191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env9190 == env9191) = true)

theorem identity9191 : scanCanonicalize (H12AffineFastState.compose env9191 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound9191 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9192 : List Nat := [2,4,8,16,32,17,40,4,33,5,32,17,8192,17,8201,8234,17,10,4,8201,16,33,17,34,8225,16,42,16,17,0,4,1,5,0,17,33]

theorem envBound9192 : H12AffineFastState.Bounded env9192 := by
  intro p hp
  have h : env9192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9191_9192 : H12AffineEnvironment.transform 10 32 env9191 = env9192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env9191 == env9192) = true)

theorem identity9192 : scanCanonicalize (H12AffineFastState.compose env9192 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 19) := by decide +kernel

theorem selectedBound9192 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9193 : List Nat := [2,4,8,16,32,17,40,4,33,5,32,17,19,17,26,57,17,10,4,26,16,33,17,34,50,16,42,16,17,0,4,1,5,0,17,33]

theorem envBound9193 : H12AffineFastState.Bounded env9193 := by
  intro p hp
  have h : env9193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9192_9193 : H12AffineEnvironment.transform 12 19 env9192 = env9193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 19 env9192 == env9193) = true)

theorem identity9193 : scanCanonicalize (H12AffineFastState.compose env9193 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound9193 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9194 : List Nat := [2,4,8,1,32,0,40,4,33,5,32,0,2,0,11,40,0,10,4,11,1,33,0,34,35,1,42,1,0,0,4,1,5,0,0,33]

theorem envBound9194 : H12AffineFastState.Bounded env9194 := by
  intro p hp
  have h : env9194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9193_9194 : H12AffineEnvironment.transform 3 1 env9193 = env9194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9193 == env9194) = true)

def env9195 : List Nat := [2,4,8,16,32,64,128,253,217,252,2048,4096,8192,233,8201,65536,4096,73945,4165,8201,65,73819,4265,73737,8329,4097,73808,77946,77947,75786,4,249,4164,73770,77867,73970]

theorem envBound9195 : H12AffineFastState.Bounded env9195 := by
  intro p hp
  have h : env9195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9186_9195 : H12AffineEnvironment.transform 8 217 env9186 = env9195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env9186 == env9195) = true)

theorem identity9195 : scanCanonicalize (H12AffineFastState.compose env9195 (packedSelected [14] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound9195 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9196 : List Nat := [2,4,8,16,32,64,121,4,32,5,2048,4096,8192,16,8201,65536,4096,73760,4165,8201,65,73819,4176,73737,8304,4097,73808,77946,77947,75786,4,0,4164,73770,77867,73739]

theorem envBound9196 : H12AffineFastState.Bounded env9196 := by
  intro p hp
  have h : env9196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9195_9196 : H12AffineEnvironment.transform 6 121 env9195 = env9196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9195 == env9196) = true)

theorem identity9196 : scanCanonicalize (H12AffineFastState.compose env9196 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 14401) := by decide +kernel

theorem selectedBound9196 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env9197 : List Nat := [2,4,8,16,32,64,121,4,32,5,2048,4096,8192,16,8201,14401,4096,6241,4165,8201,65,6170,4176,6216,8304,4097,6161,2107,2106,4171,4,0,4164,6251,2154,6218]

theorem envBound9197 : H12AffineFastState.Bounded env9197 := by
  intro p hp
  have h : env9197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9196_9197 : H12AffineEnvironment.transform 15 14401 env9196 = env9197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14401 env9196 == env9197) = true)

theorem identity9197 : scanCanonicalize (H12AffineFastState.compose env9197 (packedSelected [0,1,2,3,4,7,9,11,12,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 2106) := by decide +kernel

theorem selectedBound9197 : packedSelected [0,1,2,3,4,7,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env9198 : List Nat := [2,4,8,16,32,64,121,4,32,5,2048,2106,8192,16,8201,8315,2106,91,2175,8201,65,32,2154,114,8304,2107,43,2107,2106,2161,4,0,2174,81,2154,112]

theorem envBound9198 : H12AffineFastState.Bounded env9198 := by
  intro p hp
  have h : env9198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9197_9198 : H12AffineEnvironment.transform 11 2106 env9197 = env9198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2106 env9197 == env9198) = true)

theorem identity9198 : scanCanonicalize (H12AffineFastState.compose env9198 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound9198 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env9199 : List Nat := [2,4,8,16,27,64,66,4,27,5,2048,2049,8192,16,8201,8256,2049,91,2116,8201,65,27,2129,73,8267,2048,16,2048,2049,2122,4,0,2117,81,2129,75]

theorem envBound9199 : H12AffineFastState.Bounded env9199 := by
  intro p hp
  have h : env9199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9198_9199 : H12AffineEnvironment.transform 4 27 env9198 = env9199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env9198 == env9199) = true)

theorem identity9199 : scanCanonicalize (H12AffineFastState.compose env9199 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound9199 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9200 : List Nat := [2,4,8,16,27,64,66,4,27,5,65,64,8192,16,8201,8256,64,91,5,8201,65,27,16,73,8267,65,16,65,64,11,4,0,4,81,16,75]

theorem envBound9200 : H12AffineFastState.Bounded env9200 := by
  intro p hp
  have h : env9200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9199_9200 : H12AffineEnvironment.transform 10 65 env9199 = env9200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env9199 == env9200) = true)

theorem identity9200 : scanCanonicalize (H12AffineFastState.compose env9200 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

end H12CloudChart1