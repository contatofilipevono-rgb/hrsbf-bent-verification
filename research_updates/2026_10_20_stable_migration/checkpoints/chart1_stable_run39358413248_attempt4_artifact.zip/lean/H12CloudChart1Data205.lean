import H12CloudChart1Data204

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound51920 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51921 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,343,16401,2420,1025,0,17729,33,17,2,348,65,2048,16401,4096,2420,1364,33,257,32,16465,513]

theorem envBound51921 : H12AffineFastState.Bounded env51921 := by
  intro p hp
  have h : env51921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51920_51921 : H12AffineEnvironment.transform 12 348 env51920 = env51921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51920 == env51921) = true)

theorem identity51921 : scanCanonicalize (H12AffineFastState.compose env51921 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound51921 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51922 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,343,5393,2420,1025,0,4161,33,17,2,348,65,2048,5393,4096,2420,1364,33,257,32,5457,513]

theorem envBound51922 : H12AffineFastState.Bounded env51922 := by
  intro p hp
  have h : env51922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51921_51922 : H12AffineEnvironment.transform 13 5376 env51921 = env51922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51921 == env51922) = true)

theorem identity51922 : scanCanonicalize (H12AffineFastState.compose env51922 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51922 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51923 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,1,262,5393,2341,1025,0,4112,33,17,2,269,16,2048,5393,4096,2341,1285,33,257,32,5376,513]

theorem envBound51923 : H12AffineFastState.Bounded env51923 := by
  intro p hp
  have h : env51923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51922_51923 : H12AffineEnvironment.transform 5 17 env51922 = env51923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51922 == env51923) = true)

theorem identity51923 : scanCanonicalize (H12AffineFastState.compose env51923 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51923 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51924 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5157,1,35,5172,2048,1025,0,4112,33,17,2,40,16,2048,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound51924 : H12AffineFastState.Bounded env51924 := by
  intro p hp
  have h : env51924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51923_51924 : H12AffineEnvironment.transform 7 37 env51923 = env51924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51923 == env51924) = true)

def env51925 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1045,1,35,1028,2048,1025,0,32,33,17,2,40,16,2048,1028,48,2048,1056,33,36,32,1045,513]

theorem envBound51925 : H12AffineFastState.Bounded env51925 := by
  intro p hp
  have h : env51925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51924_51925 : H12AffineEnvironment.transform 11 48 env51924 = env51925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env51924 == env51925) = true)

theorem identity51925 : scanCanonicalize (H12AffineFastState.compose env51925 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound51925 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51926 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1044,48,40,1045,1,35,1028,1044,1025,0,32,33,17,2,40,16,1044,1028,48,1044,1056,33,36,32,1045,513]

theorem envBound51926 : H12AffineFastState.Bounded env51926 := by
  intro p hp
  have h : env51926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51925_51926 : H12AffineEnvironment.transform 10 1044 env51925 = env51926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env51925 == env51926) = true)

def env51927 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,40,33,1,35,48,32,53,0,32,33,17,2,40,16,32,48,48,32,20,33,36,32,33,513]

theorem envBound51927 : H12AffineFastState.Bounded env51927 := by
  intro p hp
  have h : env51927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51926_51927 : H12AffineEnvironment.transform 9 52 env51926 = env51927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51926 == env51927) = true)

theorem identity51927 : scanCanonicalize (H12AffineFastState.compose env51927 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51927 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51928 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,8,1,1,3,16,0,21,0,0,1,17,2,8,16,0,16,16,0,20,1,4,0,1,513]

theorem envBound51928 : H12AffineFastState.Bounded env51928 := by
  intro p hp
  have h : env51928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51927_51928 : H12AffineEnvironment.transform 4 0 env51927 = env51928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51927 == env51928) = true)

def leafEnv51928 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,8,1,1,3,16,0,21,0,0,1,17,2,21,8,1,16,0,16,16,0,20,1,4,0,5,3,1,513,1,0,0]

def active51928 : List Nat := [0,1,2,3,8]

def tree51928 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51928 : H12WitnessSearch.Good tree51928 := H12GlobalWitnessIndex.good

theorem leafIdentity51928 : H12AffineFastState.composeSystem env51928 rootObs = leafEnv51928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51928 rootObs == leafEnv51928) = true)

theorem terminalChecked51928 : H12PackedTerminal.terminalCheckFast leafEnv51928 active51928 tree51928 = true := by decide +kernel

def env51929 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,48,40,32,1,35,49,33,52,0,32,33,17,2,40,16,33,49,48,33,21,33,36,32,32,513]

theorem envBound51929 : H12AffineFastState.Bounded env51929 := by
  intro p hp
  have h : env51929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51926_51929 : H12AffineEnvironment.transform 9 53 env51926 = env51929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51926 == env51929) = true)

theorem identity51929 : scanCanonicalize (H12AffineFastState.compose env51929 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound51929 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51930 : List Nat := [2,4,8,16,32,17,8,37,11,53,33,48,40,32,1,35,49,33,52,0,32,33,17,2,40,16,33,49,48,33,21,33,36,32,32,10]

theorem envBound51930 : H12AffineFastState.Bounded env51930 := by
  intro p hp
  have h : env51930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51929_51930 : H12AffineEnvironment.transform 8 11 env51929 = env51930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env51929 == env51930) = true)

def leafEnv51930 : List Nat := [2,4,8,16,32,17,8,37,11,53,33,48,40,32,1,35,49,33,52,0,32,33,17,2,20,40,1,16,33,49,48,33,21,33,36,32,5,35,32,10,1,32,0]

def active51930 : List Nat := [0,1,2,3,4]

def tree51930 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51930 : H12WitnessSearch.Good tree51930 := H12GlobalWitnessIndex.good

theorem leafIdentity51930 : H12AffineFastState.composeSystem env51930 rootObs = leafEnv51930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51930 rootObs == leafEnv51930) = true)

theorem terminalChecked51930 : H12PackedTerminal.terminalCheckFast leafEnv51930 active51930 tree51930 = true := by decide +kernel

def env51931 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1044,1,35,1029,2048,1025,0,33,33,17,2,40,16,2048,1029,49,2048,1056,33,36,32,1044,513]

theorem envBound51931 : H12AffineFastState.Bounded env51931 := by
  intro p hp
  have h : env51931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51924_51931 : H12AffineEnvironment.transform 11 49 env51924 = env51931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env51924 == env51931) = true)

theorem identity51931 : scanCanonicalize (H12AffineFastState.compose env51931 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound51931 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51932 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,49,40,1044,1,35,1029,32,1025,0,33,33,17,2,40,16,32,1029,49,32,1056,33,36,32,1044,513]

theorem envBound51932 : H12AffineFastState.Bounded env51932 := by
  intro p hp
  have h : env51932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51931_51932 : H12AffineEnvironment.transform 10 32 env51931 = env51932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env51931 == env51932) = true)

def env51933 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,49,40,32,1,35,49,32,53,0,33,33,17,2,40,16,32,49,49,32,20,33,36,32,32,513]

theorem envBound51933 : H12AffineFastState.Bounded env51933 := by
  intro p hp
  have h : env51933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51932_51933 : H12AffineEnvironment.transform 9 52 env51932 = env51933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51932 == env51933) = true)

theorem identity51933 : scanCanonicalize (H12AffineFastState.compose env51933 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51933 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51934 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,8,0,1,3,17,0,21,0,1,1,17,2,8,16,0,17,17,0,20,1,4,0,0,513]

theorem envBound51934 : H12AffineFastState.Bounded env51934 := by
  intro p hp
  have h : env51934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51933_51934 : H12AffineEnvironment.transform 4 0 env51933 = env51934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51933 == env51934) = true)

def leafEnv51934 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,8,0,1,3,17,0,21,0,1,1,17,2,21,8,1,16,0,17,17,0,20,1,4,0,5,3,0,513,1,1,0]

def active51934 : List Nat := [0,1,2,3,8]

def tree51934 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51934 : H12WitnessSearch.Good tree51934 := H12GlobalWitnessIndex.good

theorem leafIdentity51934 : H12AffineFastState.composeSystem env51934 rootObs = leafEnv51934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51934 rootObs == leafEnv51934) = true)

theorem terminalChecked51934 : H12PackedTerminal.terminalCheckFast leafEnv51934 active51934 tree51934 = true := by decide +kernel

def env51935 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,40,33,1,35,48,32,52,0,33,33,17,2,40,16,32,48,49,32,21,33,36,32,33,513]

theorem envBound51935 : H12AffineFastState.Bounded env51935 := by
  intro p hp
  have h : env51935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51932_51935 : H12AffineEnvironment.transform 9 53 env51932 = env51935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51932 == env51935) = true)

theorem identity51935 : scanCanonicalize (H12AffineFastState.compose env51935 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound51935 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51936 : List Nat := [2,4,8,16,32,17,8,37,10,53,32,49,40,33,1,35,48,32,52,0,33,33,17,2,40,16,32,48,49,32,21,33,36,32,33,11]

theorem envBound51936 : H12AffineFastState.Bounded env51936 := by
  intro p hp
  have h : env51936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51935_51936 : H12AffineEnvironment.transform 8 10 env51935 = env51936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env51935 == env51936) = true)

def leafEnv51936 : List Nat := [2,4,8,16,32,17,8,37,10,53,32,49,40,33,1,35,48,32,52,0,33,33,17,2,20,40,1,16,32,48,49,32,21,33,36,32,5,35,33,11,1,33,0]

def active51936 : List Nat := [0,1,2,3,4]

def tree51936 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51936 : H12WitnessSearch.Good tree51936 := H12GlobalWitnessIndex.good

theorem leafIdentity51936 : H12AffineFastState.composeSystem env51936 rootObs = leafEnv51936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51936 rootObs == leafEnv51936) = true)

theorem terminalChecked51936 : H12PackedTerminal.terminalCheckFast leafEnv51936 active51936 tree51936 = true := by decide +kernel

def env51937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356289,25265169,23160257,525568,27902124,27337992,25733062]

theorem envBound51937 : H12AffineFastState.Bounded env51937 := by
  intro p hp
  have h : env51937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51575_51937 : H12AffineEnvironment.transform 26 30393345 env51575 = env51937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env51575 == env51937) = true)

def env51938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound51938 : H12AffineFastState.Bounded env51938 := by
  intro p hp
  have h : env51938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51937_51938 : H12AffineEnvironment.transform 18 1024 env51937 = env51938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env51937 == env51938) = true)

theorem identity51938 : scanCanonicalize (H12AffineFastState.compose env51938 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 223598) := by decide +kernel

theorem selectedBound51938 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env51939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,2097152,4194304,8388608,16777216,8328,65,29403503,18973837,10507600,8497519,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound51939 : H12AffineFastState.Bounded env51939 := by
  intro p hp
  have h : env51939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51938_51939 : H12AffineEnvironment.transform 17 223598 env51938 = env51939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223598 env51938 == env51939) = true)

def env51940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,2097152,4194304,8388608,2199964,8328,65,14760179,5393,10507600,8497519,10491277,4256861,256,8410416,8434836,10564186]

theorem envBound51940 : H12AffineFastState.Bounded env51940 := by
  intro p hp
  have h : env51940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51939_51940 : H12AffineEnvironment.transform 23 2199964 env51939 = env51940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env51939 == env51940) = true)

def env51941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,2097152,4194304,2101328,2199964,8328,65,4270243,5393,17664,2210111,1501,4256861,256,2114912,2139332,74250]

theorem envBound51941 : H12AffineFastState.Bounded env51941 := by
  intro p hp
  have h : env51941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51940_51941 : H12AffineEnvironment.transform 22 2101328 env51940 = env51941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env51940 == env51941) = true)

def env51942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,4194304,16,98780,8328,65,4270243,5393,17664,108927,1501,4256861,256,21792,46212,74250]

theorem envBound51942 : H12AffineFastState.Bounded env51942 := by
  intro p hp
  have h : env51942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51941_51942 : H12AffineEnvironment.transform 20 4160 env51941 = env51942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env51941 == env51942) = true)

theorem identity51942 : scanCanonicalize (H12AffineFastState.compose env51942 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound51942 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,179632,1024,32769,4160,4194304,16,21762,8328,65,4258941,5393,17664,32161,1501,4256861,256,21792,46212,63188]

theorem envBound51943 : H12AffineFastState.Bounded env51943 := by
  intro p hp
  have h : env51943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51942_51943 : H12AffineEnvironment.transform 15 54494 env51942 = env51943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env51942 == env51943) = true)

def env51944 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179512,1024,32769,4160,4194304,16,21762,8192,65,4258941,5393,17664,32041,1365,4256861,256,21792,46092,63068]

theorem envBound51944 : H12AffineFastState.Bounded env51944 := by
  intro p hp
  have h : env51944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51943_51944 : H12AffineEnvironment.transform 6 8 env51943 = env51944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51943 == env51944) = true)

theorem identity51944 : scanCanonicalize (H12AffineFastState.compose env51944 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound51944 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51945 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,10280,1024,32769,4160,4194304,16,21762,8192,65,4258941,5393,17664,32041,1365,4256861,256,21792,46092,63068]

theorem envBound51945 : H12AffineFastState.Bounded env51945 := by
  intro p hp
  have h : env51945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51944_51945 : H12AffineEnvironment.transform 16 38160 env51944 = env51945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env51944 == env51945) = true)

theorem identity51945 : scanCanonicalize (H12AffineFastState.compose env51945 (packedSelected [0,3,4,5,7,10,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound51945 : packedSelected [0,3,4,5,7,10,18,22,23] rootPS < 2^1333 := by decide +kernel

def env51946 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,10280,1024,32769,4160,41260,16,21762,8192,65,23889,5393,17664,32041,1365,21873,256,21792,46092,63068]

theorem envBound51946 : H12AffineFastState.Bounded env51946 := by
  intro p hp
  have h : env51946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51945_51946 : H12AffineEnvironment.transform 21 41260 env51945 = env51946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env51945 == env51946) = true)

theorem identity51946 : scanCanonicalize (H12AffineFastState.compose env51946 (packedSelected [1,2,4,6,8,11,18,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51946 : packedSelected [1,2,4,6,8,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env51947 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,38160,10280,1024,32769,4160,41260,16,3,8192,65,2128,5393,4097,10280,1365,112,256,33,46092,41821]

theorem envBound51947 : H12AffineFastState.Bounded env51947 := by
  intro p hp
  have h : env51947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51946_51947 : H12AffineEnvironment.transform 13 5377 env51946 = env51947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51946 == env51947) = true)

theorem identity51947 : scanCanonicalize (H12AffineFastState.compose env51947 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound51947 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env51948 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,343,5392,10280,1024,1,4160,8492,16,3,8192,65,2128,5393,4097,10280,1365,112,256,33,13324,9053]

theorem envBound51948 : H12AffineFastState.Bounded env51948 := by
  intro p hp
  have h : env51948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51947_51948 : H12AffineEnvironment.transform 14 0 env51947 = env51948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env51947 == env51948) = true)

theorem identity51948 : scanCanonicalize (H12AffineFastState.compose env51948 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51948 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51949 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,343,5392,2420,1024,1,4160,112,16,3,348,65,2128,5393,4097,2420,1365,112,256,33,5456,513]

theorem envBound51949 : H12AffineFastState.Bounded env51949 := by
  intro p hp
  have h : env51949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51948_51949 : H12AffineEnvironment.transform 12 348 env51948 = env51949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51948 == env51949) = true)

def env51950 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179513,1024,32769,4160,4194304,16,21762,8193,65,4258941,5393,17664,32040,1364,4256861,256,21792,46093,63069]

theorem envBound51950 : H12AffineFastState.Bounded env51950 := by
  intro p hp
  have h : env51950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51943_51950 : H12AffineEnvironment.transform 6 9 env51943 = env51950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51943 == env51950) = true)

theorem identity51950 : scanCanonicalize (H12AffineFastState.compose env51950 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound51950 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51951 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13388,35189,1024,32769,4160,4194304,16,21762,8193,65,4258941,5393,17664,32040,1364,4256861,256,21792,46093,63069]

theorem envBound51951 : H12AffineFastState.Bounded env51951 := by
  intro p hp
  have h : env51951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51950_51951 : H12AffineEnvironment.transform 16 13388 env51950 = env51951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env51950 == env51951) = true)

theorem identity51951 : scanCanonicalize (H12AffineFastState.compose env51951 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound51951 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env51952 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,13388,35189,1024,32769,4160,4194304,16,2,8193,65,4237693,5393,4096,10280,1364,4235613,256,32,46093,41821]

theorem envBound51952 : H12AffineFastState.Bounded env51952 := by
  intro p hp
  have h : env51952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51951_51952 : H12AffineEnvironment.transform 13 5376 env51951 = env51952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51951 == env51952) = true)

theorem identity51952 : scanCanonicalize (H12AffineFastState.compose env51952 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound51952 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env51953 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,32768,33111,5220,35189,1024,32769,4160,4194304,16,2,41,65,4229461,5393,4096,2048,1364,4227445,256,32,37925,33653]

theorem envBound51953 : H12AffineFastState.Bounded env51953 := by
  intro p hp
  have h : env51953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51952_51953 : H12AffineEnvironment.transform 12 40 env51952 = env51953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env51952 == env51953) = true)

theorem identity51953 : scanCanonicalize (H12AffineFastState.compose env51953 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(21+1) ^^^ 32800) := by decide +kernel

theorem selectedBound51953 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env51954 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,32768,33111,5220,35189,1024,32769,4160,32800,16,2,41,65,2421,5393,4096,2048,1364,341,256,32,37925,33653]

theorem envBound51954 : H12AffineFastState.Bounded env51954 := by
  intro p hp
  have h : env51954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51953_51954 : H12AffineEnvironment.transform 21 32800 env51953 = env51954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32800 env51953 == env51954) = true)

theorem identity51954 : scanCanonicalize (H12AffineFastState.compose env51954 (packedSelected [2,4,6,9,10,11,15,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound51954 : packedSelected [2,4,6,9,10,11,15,19] rootPS < 2^1333 := by decide +kernel

def env51955 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5236,32768,32803,5220,34817,1024,32769,4160,32800,16,2,41,65,2049,5221,4096,2048,1056,33,116,32,37925,33281]

theorem envBound51955 : H12AffineFastState.Bounded env51955 := by
  intro p hp
  have h : env51955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51954_51955 : H12AffineEnvironment.transform 7 116 env51954 = env51955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env51954 == env51955) = true)

theorem identity51955 : scanCanonicalize (H12AffineFastState.compose env51955 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound51955 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51956 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5236,32,3,5220,2081,1024,33,4160,0,16,2,41,65,2049,5221,4096,2048,1056,33,116,32,5125,545]

theorem envBound51956 : H12AffineFastState.Bounded env51956 := by
  intro p hp
  have h : env51956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51955_51956 : H12AffineEnvironment.transform 14 32 env51955 = env51956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env51955 == env51956) = true)

theorem identity51956 : scanCanonicalize (H12AffineFastState.compose env51956 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound51956 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env51957 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2144,40,3092,32,3,3076,2081,1024,33,2080,0,16,2,41,65,2049,3077,2144,2048,1056,33,116,32,3173,545]

theorem envBound51957 : H12AffineFastState.Bounded env51957 := by
  intro p hp
  have h : env51957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51956_51957 : H12AffineEnvironment.transform 11 2144 env51956 = env51957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env51956 == env51957) = true)

theorem identity51957 : scanCanonicalize (H12AffineFastState.compose env51957 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 94) := by decide +kernel

theorem selectedBound51957 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env51958 : List Nat := [2,4,8,16,32,64,9,116,512,94,2048,2144,40,2122,32,3,2138,2081,94,33,2080,0,16,2,41,65,2049,2139,2144,2048,126,33,116,32,2107,545]

theorem envBound51958 : H12AffineFastState.Bounded env51958 := by
  intro p hp
  have h : env51958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51957_51958 : H12AffineEnvironment.transform 9 94 env51957 = env51958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 94 env51957 == env51958) = true)

theorem identity51958 : scanCanonicalize (H12AffineFastState.compose env51958 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51958 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env51959 : List Nat := [2,4,8,16,32,17,9,37,512,15,2048,2097,40,2075,32,3,2059,2081,15,33,2080,0,16,2,41,16,2049,2058,2097,2048,47,33,37,32,2107,545]

theorem envBound51959 : H12AffineFastState.Bounded env51959 := by
  intro p hp
  have h : env51959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51958_51959 : H12AffineEnvironment.transform 5 17 env51958 = env51959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51958 == env51959) = true)

theorem identity51959 : scanCanonicalize (H12AffineFastState.compose env51959 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound51959 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env51960 : List Nat := [2,4,8,16,32,17,9,37,512,15,49,0,40,42,32,3,58,16,15,33,17,0,16,2,41,16,48,59,0,49,47,33,37,32,10,545]

theorem envBound51960 : H12AffineFastState.Bounded env51960 := by
  intro p hp
  have h : env51960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51959_51960 : H12AffineEnvironment.transform 10 49 env51959 = env51960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env51959 == env51960) = true)

def env51961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,4194304,17,98781,8328,65,4270243,5393,17664,108926,1501,4256861,256,21793,46213,74250]

theorem envBound51961 : H12AffineFastState.Bounded env51961 := by
  intro p hp
  have h : env51961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51941_51961 : H12AffineEnvironment.transform 20 4161 env51941 = env51961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env51941 == env51961) = true)

theorem identity51961 : scanCanonicalize (H12AffineFastState.compose env51961 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213487) := by decide +kernel

theorem selectedBound51961 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,213487,17,98781,8328,65,158028,5393,17664,108926,1501,243122,256,21793,46213,74250]

theorem envBound51962 : H12AffineFastState.Bounded env51962 := by
  intro p hp
  have h : env51962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51961_51962 : H12AffineEnvironment.transform 21 213487 env51961 = env51962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213487 env51961 == env51962) = true)

theorem identity51962 : scanCanonicalize (H12AffineFastState.compose env51962 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51962 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env51963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149861,1024,32769,4161,156132,17,41430,8328,65,158028,5393,17664,35189,1501,169401,256,21793,46213,513]

theorem envBound51963 : H12AffineFastState.Bounded env51963 := by
  intro p hp
  have h : env51963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51962_51963 : H12AffineEnvironment.transform 15 8203 env51962 = env51963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51962 == env51963) = true)

theorem identity51963 : scanCanonicalize (H12AffineFastState.compose env51963 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound51963 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env51964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,2420,1024,32769,4161,8693,17,41430,8328,65,10589,5393,17664,35189,1501,54696,256,21793,46213,513]

theorem envBound51964 : H12AffineFastState.Bounded env51964 := by
  intro p hp
  have h : env51964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51963_51964 : H12AffineEnvironment.transform 16 16401 env51963 = env51964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env51963 == env51964) = true)

theorem identity51964 : scanCanonicalize (H12AffineFastState.compose env51964 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound51964 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env51965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8203,16401,2420,1024,29708,4161,8693,17,21979,8328,65,10589,5393,17664,32120,1501,8613,256,21793,16520,513]

theorem envBound51965 : H12AffineFastState.Bounded env51965 := by
  intro p hp
  have h : env51965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51964_51965 : H12AffineEnvironment.transform 14 29709 env51964 = env51965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env51964 == env51965) = true)

theorem identity51965 : scanCanonicalize (H12AffineFastState.compose env51965 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51965 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env51966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21840,342,16401,2420,1024,21841,4161,168,17,21979,469,65,2048,5393,17664,23589,1501,248,256,21793,16520,513]

theorem envBound51966 : H12AffineFastState.Bounded env51966 := by
  intro p hp
  have h : env51966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51965_51966 : H12AffineEnvironment.transform 12 349 env51965 = env51966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51965 == env51966) = true)

theorem identity51966 : scanCanonicalize (H12AffineFastState.compose env51966 (packedSelected [1,2,5,7,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2184) := by decide +kernel

theorem selectedBound51966 : packedSelected [1,2,5,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env51967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,2184,7640,342,2201,2420,1024,7641,4161,168,17,7507,469,65,2048,5393,3464,5293,1501,248,256,7593,2048,513]

theorem envBound51967 : H12AffineFastState.Bounded env51967 := by
  intro p hp
  have h : env51967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51966_51967 : H12AffineEnvironment.transform 13 2184 env51966 = env51967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2184 env51966 == env51967) = true)

theorem identity51967 : scanCanonicalize (H12AffineFastState.compose env51967 (packedSelected [0,1,3,4,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51967 : packedSelected [0,1,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env51968 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,120,2184,7421,115,2201,2129,1024,7420,4161,168,17,7286,240,65,2048,5172,3245,5293,1272,248,37,7308,2048,513]

theorem envBound51968 : H12AffineFastState.Bounded env51968 := by
  intro p hp
  have h : env51968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51967_51968 : H12AffineEnvironment.transform 7 37 env51967 = env51968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51967 == env51968) = true)

theorem identity51968 : scanCanonicalize (H12AffineFastState.compose env51968 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound51968 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env51969 : List Nat := [2,4,8,16,32,64,128,37,512,189,2048,4096,120,2184,6208,115,2201,2129,189,6209,4161,168,17,6347,240,65,2048,4233,2064,4112,69,248,37,6193,2048,513]

theorem envBound51969 : H12AffineFastState.Bounded env51969 := by
  intro p hp
  have h : env51969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51968_51969 : H12AffineEnvironment.transform 9 189 env51968 = env51969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env51968 == env51969) = true)

theorem identity51969 : scanCanonicalize (H12AffineFastState.compose env51969 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound51969 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env51970 : List Nat := [2,4,8,16,32,64,128,37,512,189,2048,2113,120,2184,1,115,2201,2129,189,0,2048,168,17,138,240,65,2048,2248,2064,2129,69,248,37,112,2048,513]

theorem envBound51970 : H12AffineFastState.Bounded env51970 := by
  intro p hp
  have h : env51970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51969_51970 : H12AffineEnvironment.transform 11 2113 env51969 = env51970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env51969 == env51970) = true)

def env51971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,2097152,4194304,2101329,2199964,8328,65,4270242,5393,17665,2210110,1500,4256861,256,2114913,2139333,74251]

theorem envBound51971 : H12AffineFastState.Bounded env51971 := by
  intro p hp
  have h : env51971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51940_51971 : H12AffineEnvironment.transform 22 2101329 env51940 = env51971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env51940 == env51971) = true)

def env51972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,4194304,17,98780,8328,65,4270242,5393,17665,108926,1500,4256861,256,21793,46213,74251]

theorem envBound51972 : H12AffineFastState.Bounded env51972 := by
  intro p hp
  have h : env51972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51971_51972 : H12AffineEnvironment.transform 20 4160 env51971 = env51972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env51971 == env51972) = true)

theorem identity51972 : scanCanonicalize (H12AffineFastState.compose env51972 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243003) := by decide +kernel

theorem selectedBound51972 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,243003,17,98780,8328,65,171417,5393,17665,108926,1500,213350,256,21793,46213,74251]

theorem envBound51973 : H12AffineFastState.Bounded env51973 := by
  intro p hp
  have h : env51973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51972_51973 : H12AffineEnvironment.transform 21 243003 env51972 = env51973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243003 env51972 == env51973) = true)

def env51974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,243003,17,98644,8192,65,171281,5393,17665,108926,1364,213350,256,21793,46093,74251]

theorem envBound51974 : H12AffineFastState.Bounded env51974 := by
  intro p hp
  have h : env51974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51973_51974 : H12AffineEnvironment.transform 6 8 env51973 = env51974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51973 == env51974) = true)

theorem identity51974 : scanCanonicalize (H12AffineFastState.compose env51974 (packedSelected [0,7,8,9,11,12,14,16,22,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound51974 : packedSelected [0,7,8,9,11,12,14,16,22,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env51975 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,131072,223598,1024,21760,4160,221242,17,87125,8192,65,149520,5393,17665,97407,1364,213350,256,21793,24844,74251]

theorem envBound51975 : H12AffineFastState.Bounded env51975 := by
  intro p hp
  have h : env51975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51974_51975 : H12AffineEnvironment.transform 14 21761 env51974 = env51975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env51974 == env51975) = true)

theorem identity51975 : scanCanonicalize (H12AffineFastState.compose env51975 (packedSelected [5,8,11,16,20,24,26,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound51975 : packedSelected [5,8,11,16,20,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env51976 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,79130,23668,1024,21760,4160,21792,17,87125,8192,65,97546,5393,17665,97407,1364,29820,256,21793,24844,74251]

theorem envBound51976 : H12AffineFastState.Bounded env51976 := by
  intro p hp
  have h : env51976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51975_51976 : H12AffineEnvironment.transform 16 79130 env51975 = env51976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env51975 == env51976) = true)

theorem identity51976 : scanCanonicalize (H12AffineFastState.compose env51976 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51976 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env51977 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,65536,70726,23668,1024,21760,4160,21792,17,87125,348,65,89174,5393,17665,89379,1364,21792,256,21793,16464,66391]

theorem envBound51977 : H12AffineFastState.Bounded env51977 := by
  intro p hp
  have h : env51977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51976_51977 : H12AffineEnvironment.transform 12 348 env51976 = env51977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51976 == env51977) = true)

theorem identity51977 : scanCanonicalize (H12AffineFastState.compose env51977 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound51977 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env51978 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,262,5440,23668,1024,21760,4160,21792,17,21843,348,65,23888,5393,17665,23589,1364,21792,256,21793,16464,593]

theorem envBound51978 : H12AffineFastState.Bounded env51978 := by
  intro p hp
  have h : env51978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51977_51978 : H12AffineEnvironment.transform 15 262 env51977 = env51978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env51977 == env51978) = true)

theorem identity51978 : scanCanonicalize (H12AffineFastState.compose env51978 (packedSelected [0,3,4,5,6,7,9,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound51978 : packedSelected [0,3,4,5,6,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51979 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,348,16384,20545,262,4096,22836,320,20544,4160,20576,17,20499,348,65,22544,4177,16449,22885,20,20576,256,20577,16464,593]

theorem envBound51979 : H12AffineFastState.Bounded env51979 := by
  intro p hp
  have h : env51979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51978_51979 : H12AffineEnvironment.transform 9 320 env51978 = env51979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env51978 == env51979) = true)

theorem identity51979 : scanCanonicalize (H12AffineFastState.compose env51979 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound51979 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51980 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,348,4113,80,262,4096,2341,320,81,4160,113,17,2,348,65,2049,4177,4176,2420,20,113,256,112,4161,593]

theorem envBound51980 : H12AffineFastState.Bounded env51980 := by
  intro p hp
  have h : env51980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51979_51980 : H12AffineEnvironment.transform 13 4113 env51979 = env51980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env51979 == env51980) = true)

theorem identity51980 : scanCanonicalize (H12AffineFastState.compose env51980 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 799) := by decide +kernel

theorem selectedBound51980 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env51981 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,799,348,782,80,262,799,2341,320,81,863,113,17,2,348,65,2049,846,847,2420,20,113,256,112,862,593]

theorem envBound51981 : H12AffineFastState.Bounded env51981 := by
  intro p hp
  have h : env51981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51980_51981 : H12AffineEnvironment.transform 11 799 env51980 = env51981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 799 env51980 == env51981) = true)

theorem identity51981 : scanCanonicalize (H12AffineFastState.compose env51981 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound51981 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env51982 : List Nat := [2,4,8,16,32,64,8,256,512,320,815,799,348,782,80,262,799,522,320,81,863,113,17,2,348,65,814,846,847,603,20,113,256,112,862,593]

theorem envBound51982 : H12AffineFastState.Bounded env51982 := by
  intro p hp
  have h : env51982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51981_51982 : H12AffineEnvironment.transform 10 815 env51981 = env51982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env51981 == env51982) = true)

theorem identity51982 : scanCanonicalize (H12AffineFastState.compose env51982 (packedSelected [0,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound51982 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env51983 : List Nat := [2,4,8,16,32,64,8,256,270,320,33,17,348,0,80,262,17,260,320,81,81,113,17,2,348,65,32,64,65,341,20,113,256,112,80,351]

theorem envBound51983 : H12AffineFastState.Bounded env51983 := by
  intro p hp
  have h : env51983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51982_51983 : H12AffineEnvironment.transform 8 270 env51982 = env51983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env51982 == env51983) = true)

theorem identity51983 : scanCanonicalize (H12AffineFastState.compose env51983 (packedSelected [0,1,5,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound51983 : packedSelected [0,1,5,6,9] rootPS < 2^1333 := by decide +kernel

def env51984 : List Nat := [2,4,8,16,32,64,8,85,91,21,33,17,9,0,80,83,17,81,21,81,81,113,17,2,9,65,32,64,65,0,20,113,85,112,80,10]

theorem envBound51984 : H12AffineFastState.Bounded env51984 := by
  intro p hp
  have h : env51984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51983_51984 : H12AffineEnvironment.transform 7 85 env51983 = env51984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env51983 == env51984) = true)

theorem identity51984 : scanCanonicalize (H12AffineFastState.compose env51984 (packedSelected [3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound51984 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env51985 : List Nat := [2,4,8,16,32,49,8,36,42,21,33,17,9,0,33,34,17,32,21,32,32,0,17,2,9,48,32,49,48,0,20,0,36,1,33,10]

theorem envBound51985 : H12AffineFastState.Bounded env51985 := by
  intro p hp
  have h : env51985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51984_51985 : H12AffineEnvironment.transform 5 49 env51984 = env51985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env51984 == env51985) = true)

theorem identity51985 : scanCanonicalize (H12AffineFastState.compose env51985 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound51985 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env51986 : List Nat := [2,4,8,16,20,5,8,16,30,21,21,17,9,0,21,22,17,20,21,20,20,0,17,2,9,4,20,5,4,0,20,0,16,1,21,10]

theorem envBound51986 : H12AffineFastState.Bounded env51986 := by
  intro p hp
  have h : env51986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51985_51986 : H12AffineEnvironment.transform 4 20 env51985 = env51986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env51985 == env51986) = true)

theorem identity51986 : scanCanonicalize (H12AffineFastState.compose env51986 (packedSelected [0,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51986 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env51987 : List Nat := [2,2,8,16,18,3,8,16,24,19,19,17,9,0,19,16,17,18,19,18,18,0,17,2,9,2,18,3,2,0,18,0,16,1,19,10]

theorem envBound51987 : H12AffineFastState.Bounded env51987 := by
  intro p hp
  have h : env51987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51986_51987 : H12AffineEnvironment.transform 1 2 env51986 = env51987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51986 == env51987) = true)

theorem identity51987 : scanCanonicalize (H12AffineFastState.compose env51987 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound51987 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env51988 : List Nat := [2,2,8,3,1,3,8,3,11,0,0,2,9,0,0,3,2,1,0,1,1,0,2,2,9,2,1,3,2,0,1,0,3,1,0,10]

theorem envBound51988 : H12AffineFastState.Bounded env51988 := by
  intro p hp
  have h : env51988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51987_51988 : H12AffineEnvironment.transform 3 3 env51987 = env51988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env51987 == env51988) = true)

def env51989 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,243003,17,98645,8193,65,171280,5393,17665,108926,1365,213350,256,21793,46092,74251]

theorem envBound51989 : H12AffineFastState.Bounded env51989 := by
  intro p hp
  have h : env51989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51973_51989 : H12AffineEnvironment.transform 6 9 env51973 = env51989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51973 == env51989) = true)

theorem identity51989 : scanCanonicalize (H12AffineFastState.compose env51989 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound51989 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51990 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,223598,1024,8541,4160,201831,17,73737,8193,65,146508,5393,17665,67618,1365,213350,256,21793,5456,74251]

theorem envBound51990 : H12AffineFastState.Bounded env51990 := by
  intro p hp
  have h : env51990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51989_51990 : H12AffineEnvironment.transform 14 8540 env51989 = env51990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env51989 == env51990) = true)

theorem identity51990 : scanCanonicalize (H12AffineFastState.compose env51990 (packedSelected [0,1,7,8,9,10,12,14,15,16,19,22,31] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound51990 : packedSelected [0,1,7,8,9,10,12,14,15,16,19,22,31] rootPS < 2^1333 := by decide +kernel

def env51991 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,34,131072,158028,1024,8541,4160,136261,17,8235,8193,65,146508,5393,17665,2048,1365,147780,256,21793,5456,8745]

theorem envBound51991 : H12AffineFastState.Bounded env51991 := by
  intro p hp
  have h : env51991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51990_51991 : H12AffineEnvironment.transform 15 34 env51990 = env51991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env51990 == env51991) = true)

def env51992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,4194304,16,98781,8328,65,4270242,5393,17665,108927,1500,4256861,256,21792,46212,74251]

theorem envBound51992 : H12AffineFastState.Bounded env51992 := by
  intro p hp
  have h : env51992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51971_51992 : H12AffineEnvironment.transform 20 4161 env51971 = env51992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env51971 == env51992) = true)

theorem identity51992 : scanCanonicalize (H12AffineFastState.compose env51992 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51992 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149860,1024,32769,4161,4194304,16,41431,8328,65,4196520,5393,17665,35189,1500,4256861,256,21792,46212,513]

theorem envBound51993 : H12AffineFastState.Bounded env51993 := by
  intro p hp
  have h : env51993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51992_51993 : H12AffineEnvironment.transform 15 8202 env51992 = env51993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51992 == env51993) = true)

theorem identity51993 : scanCanonicalize (H12AffineFastState.compose env51993 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 8693) := by decide +kernel

theorem selectedBound51993 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env51994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149860,1024,32769,4161,8693,16,41431,8328,65,10589,5393,17665,35189,1500,54696,256,21792,46212,513]

theorem envBound51994 : H12AffineFastState.Bounded env51994 := by
  intro p hp
  have h : env51994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51993_51994 : H12AffineEnvironment.transform 21 8693 env51993 = env51994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8693 env51993 == env51994) = true)

theorem identity51994 : scanCanonicalize (H12AffineFastState.compose env51994 (packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51994 : packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env51995 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149860,1024,32769,4161,8573,16,41311,8192,65,10589,5393,17665,35189,1364,54560,256,21792,46092,513]

theorem envBound51995 : H12AffineFastState.Bounded env51995 := by
  intro p hp
  have h : env51995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51994_51995 : H12AffineEnvironment.transform 6 8 env51994 = env51995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51994 == env51995) = true)

theorem identity51995 : scanCanonicalize (H12AffineFastState.compose env51995 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound51995 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51996 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,24908,10280,1024,32769,4161,8573,16,41311,8192,65,10589,5393,17665,35189,1364,54560,256,21792,46092,513]

theorem envBound51996 : H12AffineFastState.Bounded env51996 := by
  intro p hp
  have h : env51996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51995_51996 : H12AffineEnvironment.transform 16 24908 env51995 = env51996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env51995 == env51996) = true)

theorem identity51996 : scanCanonicalize (H12AffineFastState.compose env51996 (packedSelected [11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound51996 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env51997 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,24908,10280,1024,8541,4161,8573,16,3,8192,65,10589,5393,17665,10281,1364,29820,256,21792,5456,513]

theorem envBound51997 : H12AffineFastState.Bounded env51997 := by
  intro p hp
  have h : env51997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51996_51997 : H12AffineEnvironment.transform 14 8540 env51996 = env51997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env51996 == env51997) = true)

theorem identity51997 : scanCanonicalize (H12AffineFastState.compose env51997 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound51997 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env51998 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8540,8202,5393,10280,1024,8541,4161,8573,16,3,8192,65,10589,5393,12636,10281,1364,33,256,8573,5456,513]

theorem envBound51998 : H12AffineFastState.Bounded env51998 := by
  intro p hp
  have h : env51998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51997_51998 : H12AffineEnvironment.transform 13 13405 env51997 = env51998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env51997 == env51998) = true)

theorem identity51998 : scanCanonicalize (H12AffineFastState.compose env51998 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51998 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env51999 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,8461,8202,5393,10280,1024,8460,4112,8492,16,3,8192,16,10508,5393,12557,10281,1285,33,256,8492,5377,513]

theorem envBound51999 : H12AffineFastState.Bounded env51999 := by
  intro p hp
  have h : env51999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51998_51999 : H12AffineEnvironment.transform 5 17 env51998 = env51999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51998 == env51999) = true)

theorem identity51999 : scanCanonicalize (H12AffineFastState.compose env51999 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51999 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52000 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,263,5393,2341,1024,1,4112,33,16,3,269,16,2049,5393,4096,2340,1285,33,256,33,5377,513]

theorem envBound52000 : H12AffineFastState.Bounded env52000 := by
  intro p hp
  have h : env52000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51999_52000 : H12AffineEnvironment.transform 12 269 env51999 = env52000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51999 == env52000) = true)

theorem identity52000 : scanCanonicalize (H12AffineFastState.compose env52000 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound52000 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52001 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1312,269,33,0,263,49,2341,1024,1,1328,33,16,3,269,16,2049,49,1312,2340,1285,33,256,33,33,513]

theorem envBound52001 : H12AffineFastState.Bounded env52001 := by
  intro p hp
  have h : env52001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52000_52001 : H12AffineEnvironment.transform 11 1312 env52000 = env52001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env52000 == env52001) = true)

theorem identity52001 : scanCanonicalize (H12AffineFastState.compose env52001 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52001 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52002 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,1029,40,33,0,34,49,2048,1024,1,1045,33,16,3,40,16,2049,49,1029,2049,1056,33,37,33,33,513]

theorem envBound52002 : H12AffineFastState.Bounded env52002 := by
  intro p hp
  have h : env52002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52001_52002 : H12AffineEnvironment.transform 7 37 env52001 = env52002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52001 == env52002) = true)

theorem identity52002 : scanCanonicalize (H12AffineFastState.compose env52002 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound52002 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52003 : List Nat := [2,4,8,16,32,17,8,37,512,532,2048,529,40,33,0,34,49,2048,532,1,513,33,16,3,40,16,2049,49,529,2049,564,33,37,33,33,513]

theorem envBound52003 : H12AffineFastState.Bounded env52003 := by
  intro p hp
  have h : env52003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52002_52003 : H12AffineEnvironment.transform 9 532 env52002 = env52003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env52002 == env52003) = true)

theorem identity52003 : scanCanonicalize (H12AffineFastState.compose env52003 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound52003 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52004 : List Nat := [2,4,8,16,32,17,8,37,512,532,512,529,40,33,0,34,49,512,532,1,513,33,16,3,40,16,513,49,529,513,564,33,37,33,33,513]

theorem envBound52004 : H12AffineFastState.Bounded env52004 := by
  intro p hp
  have h : env52004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52003_52004 : H12AffineEnvironment.transform 10 512 env52003 = env52004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env52003 == env52004) = true)

theorem identity52004 : scanCanonicalize (H12AffineFastState.compose env52004 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52004 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52005 : List Nat := [2,4,8,16,16,17,8,21,512,532,512,529,24,17,0,18,1,512,532,1,513,17,16,3,24,16,513,1,529,513,516,17,21,17,17,513]

theorem envBound52005 : H12AffineFastState.Bounded env52005 := by
  intro p hp
  have h : env52005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52004_52005 : H12AffineEnvironment.transform 4 16 env52004 = env52005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52004 == env52005) = true)

theorem identity52005 : scanCanonicalize (H12AffineFastState.compose env52005 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound52005 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env52006 : List Nat := [2,4,8,16,16,17,8,21,16,4,16,1,24,17,0,18,1,16,4,1,17,17,16,3,24,16,17,1,1,17,20,17,21,17,17,17]

theorem envBound52006 : H12AffineFastState.Bounded env52006 := by
  intro p hp
  have h : env52006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52005_52006 : H12AffineEnvironment.transform 8 16 env52005 = env52006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env52005 == env52006) = true)

theorem identity52006 : scanCanonicalize (H12AffineFastState.compose env52006 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52006 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env52007 : List Nat := [2,4,8,0,0,1,8,5,0,4,0,1,8,1,0,2,1,0,4,1,1,1,0,3,8,0,1,1,1,1,4,1,5,1,1,1]

theorem envBound52007 : H12AffineFastState.Bounded env52007 := by
  intro p hp
  have h : env52007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52006_52007 : H12AffineEnvironment.transform 3 0 env52006 = env52007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52006 == env52007) = true)

def env52008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,2097152,4194304,8388608,2199965,8328,65,14760178,5392,10507600,8497519,10491276,4256860,256,8410417,8434837,10564187]

theorem envBound52008 : H12AffineFastState.Bounded env52008 := by
  intro p hp
  have h : env52008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51939_52008 : H12AffineEnvironment.transform 23 2199965 env51939 = env52008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env51939 == env52008) = true)

def env52009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,2097152,4194304,2101328,2199965,8328,65,4270242,5392,17664,2210111,1500,4256860,256,2114913,2139333,74251]

theorem envBound52009 : H12AffineFastState.Bounded env52009 := by
  intro p hp
  have h : env52009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52008_52009 : H12AffineEnvironment.transform 22 2101328 env52008 = env52009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env52008 == env52009) = true)

def env52010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,4194304,16,98781,8328,65,4270242,5392,17664,108927,1500,4256860,256,21793,46213,74251]

theorem envBound52010 : H12AffineFastState.Bounded env52010 := by
  intro p hp
  have h : env52010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52009_52010 : H12AffineEnvironment.transform 20 4160 env52009 = env52010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env52009 == env52010) = true)

def env52011 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,4194304,16,98645,8192,65,4270122,5392,17664,108927,1364,4256860,256,21793,46093,74251]

theorem envBound52011 : H12AffineFastState.Bounded env52011 := by
  intro p hp
  have h : env52011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52010_52011 : H12AffineEnvironment.transform 6 8 env52010 = env52011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52010 == env52011) = true)

theorem identity52011 : scanCanonicalize (H12AffineFastState.compose env52011 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound52011 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52012 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1024,32769,4160,4194304,16,98645,8192,65,4270122,5392,17664,108927,1364,4256860,256,21793,46093,74251]

theorem envBound52012 : H12AffineFastState.Bounded env52012 := by
  intro p hp
  have h : env52012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52011_52012 : H12AffineEnvironment.transform 16 82246 env52011 = env52012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env52011 == env52012) = true)

theorem identity52012 : scanCanonicalize (H12AffineFastState.compose env52012 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound52012 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env52013 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1024,32769,4160,8573,16,98645,8192,65,67927,5392,17664,108927,1364,54561,256,21793,46093,74251]

theorem envBound52013 : H12AffineFastState.Bounded env52013 := by
  intro p hp
  have h : env52013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52012_52013 : H12AffineEnvironment.transform 21 8573 env52012 = env52013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env52012 == env52013) = true)

theorem identity52013 : scanCanonicalize (H12AffineFastState.compose env52013 (packedSelected [1,2,6,7,8,9,11,19,20,22,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound52013 : packedSelected [1,2,6,7,8,9,11,19,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env52014 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,79130,10280,1024,32769,4160,8573,16,98645,8192,65,67927,5392,12636,108927,1364,41341,256,8573,46093,74251]

theorem envBound52014 : H12AffineFastState.Bounded env52014 := by
  intro p hp
  have h : env52014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52013_52014 : H12AffineEnvironment.transform 13 13404 env52013 = env52014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env52013 == env52014) = true)

theorem identity52014 : scanCanonicalize (H12AffineFastState.compose env52014 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound52014 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env52015 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,65536,79130,10280,1024,1,4160,8573,16,65877,8192,65,67927,5392,12636,76159,1364,8573,256,8573,13325,74251]

theorem envBound52015 : H12AffineFastState.Bounded env52015 := by
  intro p hp
  have h : env52015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52014_52015 : H12AffineEnvironment.transform 14 0 env52014 = env52015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env52014 == env52015) = true)

theorem identity52015 : scanCanonicalize (H12AffineFastState.compose env52015 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound52015 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52016 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,8202,5392,10280,1024,1,4160,8573,16,8543,8192,65,10589,5392,12636,2421,1364,8573,256,8573,13325,513]

theorem envBound52016 : H12AffineFastState.Bounded env52016 := by
  intro p hp
  have h : env52016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52015_52016 : H12AffineEnvironment.transform 15 8202 env52015 = env52016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env52015 == env52016) = true)

theorem identity52016 : scanCanonicalize (H12AffineFastState.compose env52016 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52016 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env52017 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13325,0,8202,5392,10280,1024,1,4113,8492,16,8462,8192,16,10508,5392,12557,2340,1285,8492,256,8492,13325,513]

theorem envBound52017 : H12AffineFastState.Bounded env52017 := by
  intro p hp
  have h : env52017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52016_52017 : H12AffineEnvironment.transform 5 17 env52016 = env52017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52016 == env52017) = true)

theorem identity52017 : scanCanonicalize (H12AffineFastState.compose env52017 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound52017 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52018 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1,4096,8192,13325,0,8202,5392,8233,1024,1,4113,8492,16,8462,8192,16,8461,5392,12557,293,1285,8492,256,8492,13325,513]

theorem envBound52018 : H12AffineFastState.Bounded env52018 := by
  intro p hp
  have h : env52018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52017_52018 : H12AffineEnvironment.transform 10 1 env52017 = env52018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env52017 == env52018) = true)

theorem identity52018 : scanCanonicalize (H12AffineFastState.compose env52018 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52018 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52019 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1,4096,269,5376,0,263,5392,292,1024,1,4113,33,16,3,269,16,0,5392,4096,293,1285,33,256,33,5376,513]

theorem envBound52019 : H12AffineFastState.Bounded env52019 := by
  intro p hp
  have h : env52019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52018_52019 : H12AffineEnvironment.transform 12 269 env52018 = env52019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52018 == env52019) = true)

theorem identity52019 : scanCanonicalize (H12AffineFastState.compose env52019 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound52019 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52020 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1,1313,269,33,0,263,49,292,1024,1,1328,33,16,3,269,16,0,49,1313,293,1285,33,256,33,33,513]

theorem envBound52020 : H12AffineFastState.Bounded env52020 := by
  intro p hp
  have h : env52020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52019_52020 : H12AffineEnvironment.transform 11 1313 env52019 = env52020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env52019 == env52020) = true)

theorem identity52020 : scanCanonicalize (H12AffineFastState.compose env52020 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52020 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52021 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1,1028,40,33,0,34,49,1,1024,1,1045,33,16,3,40,16,0,49,1028,0,1056,33,37,33,33,513]

theorem envBound52021 : H12AffineFastState.Bounded env52021 := by
  intro p hp
  have h : env52021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52020_52021 : H12AffineEnvironment.transform 7 37 env52020 = env52021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52020 == env52021) = true)

theorem identity52021 : scanCanonicalize (H12AffineFastState.compose env52021 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound52021 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52022 : List Nat := [2,4,8,16,32,17,8,37,512,516,1,512,40,33,0,34,49,1,516,1,529,33,16,3,40,16,0,49,512,0,548,33,37,33,33,513]

theorem envBound52022 : H12AffineFastState.Bounded env52022 := by
  intro p hp
  have h : env52022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52021_52022 : H12AffineEnvironment.transform 9 516 env52021 = env52022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env52021 == env52022) = true)

theorem identity52022 : scanCanonicalize (H12AffineFastState.compose env52022 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound52022 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52023 : List Nat := [2,4,8,16,32,17,8,37,1,5,1,1,40,33,0,34,49,1,5,1,16,33,16,3,40,16,0,49,1,0,37,33,37,33,33,0]

theorem envBound52023 : H12AffineFastState.Bounded env52023 := by
  intro p hp
  have h : env52023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52022_52023 : H12AffineEnvironment.transform 8 1 env52022 = env52023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env52022 == env52023) = true)

theorem identity52023 : scanCanonicalize (H12AffineFastState.compose env52023 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52023 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52024 : List Nat := [2,4,8,16,1,17,8,4,1,5,1,1,9,0,0,3,16,1,5,1,16,0,16,3,9,16,0,16,1,0,4,0,4,0,0,0]

theorem envBound52024 : H12AffineFastState.Bounded env52024 := by
  intro p hp
  have h : env52024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52023_52024 : H12AffineEnvironment.transform 4 1 env52023 = env52024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52023 == env52024) = true)

theorem identity52024 : scanCanonicalize (H12AffineFastState.compose env52024 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52024 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env52025 : List Nat := [2,4,8,0,1,1,8,4,1,5,1,1,9,0,0,3,0,1,5,1,0,0,0,3,9,0,0,0,1,0,4,0,4,0,0,0]

theorem envBound52025 : H12AffineFastState.Bounded env52025 := by
  intro p hp
  have h : env52025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52024_52025 : H12AffineEnvironment.transform 3 0 env52024 = env52025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52024 == env52025) = true)

theorem identity52025 : scanCanonicalize (H12AffineFastState.compose env52025 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound52025 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52026 : List Nat := [2,4,3,0,1,1,3,4,1,5,1,1,2,0,0,3,0,1,5,1,0,0,0,3,2,0,0,0,1,0,4,0,4,0,0,0]

theorem envBound52026 : H12AffineFastState.Bounded env52026 := by
  intro p hp
  have h : env52026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52025_52026 : H12AffineEnvironment.transform 2 3 env52025 = env52026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env52025 == env52026) = true)

def env52027 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,4194304,16,98644,8193,65,4270123,5392,17664,108927,1365,4256860,256,21793,46092,74251]

theorem envBound52027 : H12AffineFastState.Bounded env52027 := by
  intro p hp
  have h : env52027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52010_52027 : H12AffineEnvironment.transform 6 9 env52010 = env52027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52010 == env52027) = true)

theorem identity52027 : scanCanonicalize (H12AffineFastState.compose env52027 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound52027 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52028 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,35189,1024,32769,4160,4194304,16,98644,8193,65,4270123,5392,17664,108927,1365,4256860,256,21793,46092,74251]

theorem envBound52028 : H12AffineFastState.Bounded env52028 := by
  intro p hp
  have h : env52028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52027_52028 : H12AffineEnvironment.transform 16 122907 env52027 = env52028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env52027 == env52028) = true)

theorem identity52028 : scanCanonicalize (H12AffineFastState.compose env52028 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(21+1) ^^^ 119847) := by decide +kernel

theorem selectedBound52028 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env52029 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,35189,1024,32769,4160,119847,16,98644,8193,65,64524,5392,17664,108927,1365,73851,256,21793,46092,74251]

theorem envBound52029 : H12AffineFastState.Bounded env52029 := by
  intro p hp
  have h : env52029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52028_52029 : H12AffineEnvironment.transform 21 119847 env52028 = env52029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119847 env52028 == env52029) = true)

theorem identity52029 : scanCanonicalize (H12AffineFastState.compose env52029 (packedSelected [0,3,9,10,22,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound52029 : packedSelected [0,3,9,10,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52030 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,65536,111947,35189,1024,32769,4160,98679,16,98644,8193,65,43356,5392,4176,108927,1365,73851,256,113,46092,74251]

theorem envBound52030 : H12AffineFastState.Bounded env52030 := by
  intro p hp
  have h : env52030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52029_52030 : H12AffineEnvironment.transform 13 5456 env52029 = env52030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env52029 == env52030) = true)

theorem identity52030 : scanCanonicalize (H12AffineFastState.compose env52030 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52030 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env52031 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,1,65536,79178,2420,1024,0,4160,65910,16,65877,8193,65,10589,5392,4176,76158,1365,73851,256,113,13325,74251]

theorem envBound52031 : H12AffineFastState.Bounded env52031 := by
  intro p hp
  have h : env52031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52030_52031 : H12AffineEnvironment.transform 14 1 env52030 = env52031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52030 == env52031) = true)

theorem identity52031 : scanCanonicalize (H12AffineFastState.compose env52031 (packedSelected [3,4,5,6,9,10,12,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 1126) := by decide +kernel

theorem selectedBound52031 : packedSelected [3,4,5,6,9,10,12,14,16] rootPS < 2^1333 := by decide +kernel

def env52032 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,1,1126,12588,2420,1024,0,4160,1296,16,1331,8193,65,10589,5392,4176,11544,1365,9245,256,113,13325,9837]

theorem envBound52032 : H12AffineFastState.Bounded env52032 := by
  intro p hp
  have h : env52032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52031_52032 : H12AffineEnvironment.transform 15 1126 env52031 = env52032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1126 env52031 == env52032) = true)

theorem identity52032 : scanCanonicalize (H12AffineFastState.compose env52032 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound52032 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env52033 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,4405,1,3,12588,2420,101,0,4160,373,16,342,8193,65,10589,4469,4176,10621,304,8312,256,113,12392,8712]

theorem envBound52033 : H12AffineFastState.Bounded env52033 := by
  intro p hp
  have h : env52033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52032_52033 : H12AffineEnvironment.transform 9 101 env52032 = env52033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env52032 == env52033) = true)

theorem identity52033 : scanCanonicalize (H12AffineFastState.compose env52033 (packedSelected [1,2,7,8,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound52033 : packedSelected [1,2,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env52034 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,552,4405,1,3,4868,2420,101,0,4160,373,16,342,553,65,2933,4469,4176,2901,304,592,256,113,4672,32]

theorem envBound52034 : H12AffineFastState.Bounded env52034 := by
  intro p hp
  have h : env52034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52033_52034 : H12AffineEnvironment.transform 12 552 env52033 = env52034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env52033 == env52034) = true)

theorem identity52034 : scanCanonicalize (H12AffineFastState.compose env52034 (packedSelected [1,2,6,7,8,9,10,12,18] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound52034 : packedSelected [1,2,6,7,8,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env52035 : List Nat := [2,4,8,16,32,64,9,256,261,101,2048,4096,301,4405,1,3,4097,2420,101,0,4160,373,16,342,300,65,2160,4469,4176,2128,304,341,256,113,4421,32]

theorem envBound52035 : H12AffineFastState.Bounded env52035 := by
  intro p hp
  have h : env52035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52034_52035 : H12AffineEnvironment.transform 8 261 env52034 = env52035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env52034 == env52035) = true)

theorem identity52035 : scanCanonicalize (H12AffineFastState.compose env52035 (packedSelected [1,2,3,4,5,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound52035 : packedSelected [1,2,3,4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env52036 : List Nat := [2,4,8,16,32,64,9,256,261,101,2048,293,301,16,1,3,292,2420,101,0,357,373,16,342,300,65,2160,80,373,2128,304,341,256,113,96,32]

theorem envBound52036 : H12AffineFastState.Bounded env52036 := by
  intro p hp
  have h : env52036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52035_52036 : H12AffineEnvironment.transform 11 293 env52035 = env52036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env52035 == env52036) = true)

theorem identity52036 : scanCanonicalize (H12AffineFastState.compose env52036 (packedSelected [1,2,4,6,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound52036 : packedSelected [1,2,4,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env52037 : List Nat := [2,4,8,16,32,64,9,36,33,101,2048,1,9,16,1,3,0,2128,101,0,65,81,16,114,8,65,2160,80,81,2128,20,113,36,113,96,32]

theorem envBound52037 : H12AffineFastState.Bounded env52037 := by
  intro p hp
  have h : env52037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52036_52037 : H12AffineEnvironment.transform 7 36 env52036 = env52037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env52036 == env52037) = true)

theorem identity52037 : scanCanonicalize (H12AffineFastState.compose env52037 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound52037 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52038 : List Nat := [2,4,8,16,32,64,9,36,33,101,91,1,9,16,1,3,0,11,101,0,65,81,16,114,8,65,43,80,81,11,20,113,36,113,96,32]

theorem envBound52038 : H12AffineFastState.Bounded env52038 := by
  intro p hp
  have h : env52038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52037_52038 : H12AffineEnvironment.transform 10 91 env52037 = env52038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env52037 == env52038) = true)

theorem identity52038 : scanCanonicalize (H12AffineFastState.compose env52038 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52038 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52039 : List Nat := [2,4,8,16,16,64,9,20,17,85,91,1,9,16,1,3,0,11,85,0,65,81,16,66,8,65,27,80,81,11,20,65,20,65,80,16]

theorem envBound52039 : H12AffineFastState.Bounded env52039 := by
  intro p hp
  have h : env52039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52038_52039 : H12AffineEnvironment.transform 4 16 env52038 = env52039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52038 == env52039) = true)

theorem identity52039 : scanCanonicalize (H12AffineFastState.compose env52039 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52039 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env52040 : List Nat := [2,4,8,16,16,16,9,20,17,5,11,1,9,16,1,3,0,11,5,0,17,1,16,18,8,17,27,0,1,11,20,17,20,17,0,16]

theorem envBound52040 : H12AffineFastState.Bounded env52040 := by
  intro p hp
  have h : env52040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52039_52040 : H12AffineEnvironment.transform 5 16 env52039 = env52040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52039 == env52040) = true)

theorem identity52040 : scanCanonicalize (H12AffineFastState.compose env52040 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound52040 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52041 : List Nat := [2,4,2,16,16,16,3,20,17,5,1,1,3,16,1,3,0,1,5,0,17,1,16,18,2,17,17,0,1,1,20,17,20,17,0,16]

theorem envBound52041 : H12AffineFastState.Bounded env52041 := by
  intro p hp
  have h : env52041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52040_52041 : H12AffineEnvironment.transform 2 2 env52040 = env52041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env52040 == env52041) = true)

def env52042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,4194304,17,98780,8328,65,4270242,5392,17664,108926,1500,4256860,256,21792,46212,74251]

theorem envBound52042 : H12AffineFastState.Bounded env52042 := by
  intro p hp
  have h : env52042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52009_52042 : H12AffineEnvironment.transform 20 4161 env52009 = env52042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env52009 == env52042) = true)

theorem identity52042 : scanCanonicalize (H12AffineFastState.compose env52042 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169264) := by decide +kernel

theorem selectedBound52042 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,169264,17,98780,8328,65,245138,5392,17664,108926,1500,156012,256,21792,46212,74251]

theorem envBound52043 : H12AffineFastState.Bounded env52043 := by
  intro p hp
  have h : env52043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52042_52043 : H12AffineEnvironment.transform 21 169264 env52042 = env52043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env52042 == env52043) = true)

def env52044 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,169264,17,98644,8192,65,245018,5392,17664,108926,1364,156012,256,21792,46092,74251]

theorem envBound52044 : H12AffineFastState.Bounded env52044 := by
  intro p hp
  have h : env52044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52043_52044 : H12AffineEnvironment.transform 6 8 env52043 = env52044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52043 == env52044) = true)

theorem identity52044 : scanCanonicalize (H12AffineFastState.compose env52044 (packedSelected [1,3,7,8,10,11,12,16,19,24,26,27,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound52044 : packedSelected [1,3,7,8,10,11,12,16,19,24,26,27,32,35,38] rootPS < 2^1333 := by decide +kernel

def env52045 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,103494,64808,1024,32769,4161,65910,17,98644,8192,65,10588,5392,17664,108926,1364,128298,256,21792,46092,74251]

theorem envBound52045 : H12AffineFastState.Bounded env52045 := by
  intro p hp
  have h : env52045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52044_52045 : H12AffineEnvironment.transform 16 103494 env52044 = env52045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env52044 == env52045) = true)

theorem identity52045 : scanCanonicalize (H12AffineFastState.compose env52045 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound52045 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env52046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,2420,1024,29789,4161,65910,17,95496,8192,65,10588,5392,17664,89378,1364,65910,256,21792,16464,74251]

theorem envBound52046 : H12AffineFastState.Bounded env52046 := by
  intro p hp
  have h : env52046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52045_52046 : H12AffineEnvironment.transform 14 29788 env52045 = env52046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env52045 == env52046) = true)

theorem identity52046 : scanCanonicalize (H12AffineFastState.compose env52046 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound52046 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env52047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,16400,2420,1024,29789,4161,8572,17,21762,8192,65,10588,5392,17664,32040,1364,8572,256,21792,16464,513]

theorem envBound52047 : H12AffineFastState.Bounded env52047 := by
  intro p hp
  have h : env52047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52046_52047 : H12AffineEnvironment.transform 15 8202 env52046 = env52047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env52046 == env52047) = true)

theorem identity52047 : scanCanonicalize (H12AffineFastState.compose env52047 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound52047 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,81,8202,13341,2420,1024,80,4161,8572,17,8463,8192,65,10588,5392,12557,2341,1364,8572,256,8493,13405,513]

theorem envBound52048 : H12AffineFastState.Bounded env52048 := by
  intro p hp
  have h : env52048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52047_52048 : H12AffineEnvironment.transform 13 13325 env52047 = env52048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env52047 == env52048) = true)

theorem identity52048 : scanCanonicalize (H12AffineFastState.compose env52048 (packedSelected [1,6,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound52048 : packedSelected [1,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env52049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7180,2049,81,7174,2065,2420,1024,80,4161,7536,17,7427,7180,65,5456,5392,3329,2341,1364,7536,256,7457,2129,513]

theorem envBound52049 : H12AffineFastState.Bounded env52049 := by
  intro p hp
  have h : env52049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52048_52049 : H12AffineEnvironment.transform 12 7180 env52048 = env52049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env52048 == env52049) = true)

theorem identity52049 : scanCanonicalize (H12AffineFastState.compose env52049 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound52049 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env52050 : List Nat := [2,4,8,16,32,64,8,256,373,1024,2048,4096,7180,2049,81,7174,2065,2420,1024,80,4161,7536,17,7427,7180,65,5456,5392,3329,2341,1364,7536,256,7457,2129,372]

theorem envBound52050 : H12AffineFastState.Bounded env52050 := by
  intro p hp
  have h : env52050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52049_52050 : H12AffineEnvironment.transform 8 373 env52049 = env52050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env52049 == env52050) = true)

theorem identity52050 : scanCanonicalize (H12AffineFastState.compose env52050 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound52050 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env52051 : List Nat := [2,4,8,16,32,64,8,256,373,1024,2048,2065,1053,2049,81,1047,2065,2420,1024,80,2128,1377,17,1298,1053,65,3393,3329,3329,2341,1364,1377,256,1328,2129,372]

theorem envBound52051 : H12AffineFastState.Bounded env52051 := by
  intro p hp
  have h : env52051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52050_52051 : H12AffineEnvironment.transform 11 2065 env52050 = env52051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env52050 == env52051) = true)

theorem identity52051 : scanCanonicalize (H12AffineFastState.compose env52051 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound52051 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env52052 : List Nat := [2,4,8,16,32,64,8,101,16,1024,2048,2065,1053,2049,81,1047,2065,2065,1024,80,2128,1028,17,1143,1053,65,3108,3172,3172,2112,1073,1028,101,1109,2129,17]

theorem envBound52052 : H12AffineFastState.Bounded env52052 := by
  intro p hp
  have h : env52052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52051_52052 : H12AffineEnvironment.transform 7 101 env52051 = env52052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env52051 == env52052) = true)

theorem identity52052 : scanCanonicalize (H12AffineFastState.compose env52052 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound52052 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52053 : List Nat := [2,4,8,16,32,64,8,101,16,37,2048,2065,56,2049,81,50,2065,2065,37,80,2128,33,17,82,56,65,2049,2113,2113,2112,20,33,101,112,2129,17]

theorem envBound52053 : H12AffineFastState.Bounded env52053 := by
  intro p hp
  have h : env52053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52052_52053 : H12AffineEnvironment.transform 9 37 env52052 = env52053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env52052 == env52053) = true)

theorem identity52053 : scanCanonicalize (H12AffineFastState.compose env52053 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound52053 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env52054 : List Nat := [2,4,8,16,32,64,8,101,16,37,64,81,56,65,81,50,81,81,37,80,16,33,17,82,56,65,65,1,1,0,20,33,101,112,17,17]

theorem envBound52054 : H12AffineFastState.Bounded env52054 := by
  intro p hp
  have h : env52054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52053_52054 : H12AffineEnvironment.transform 10 64 env52053 = env52054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env52053 == env52054) = true)

theorem identity52054 : scanCanonicalize (H12AffineFastState.compose env52054 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52054 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52055 : List Nat := [2,4,8,1,32,64,8,101,1,37,64,64,41,65,64,35,64,64,37,65,1,33,0,67,41,65,65,1,1,0,5,33,101,97,0,0]

theorem envBound52055 : H12AffineFastState.Bounded env52055 := by
  intro p hp
  have h : env52055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52054_52055 : H12AffineEnvironment.transform 3 1 env52054 = env52055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52054 == env52055) = true)

def env52056 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,169264,17,98645,8193,65,245019,5392,17664,108926,1365,156012,256,21792,46093,74251]

theorem envBound52056 : H12AffineFastState.Bounded env52056 := by
  intro p hp
  have h : env52056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52043_52056 : H12AffineEnvironment.transform 6 9 env52043 = env52056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52043 == env52056) = true)

theorem identity52056 : scanCanonicalize (H12AffineFastState.compose env52056 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound52056 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,223598,1024,8541,4161,144492,17,73737,8193,65,203847,5392,17664,67618,1365,156012,256,21792,5457,74251]

theorem envBound52057 : H12AffineFastState.Bounded env52057 := by
  intro p hp
  have h : env52057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52056_52057 : H12AffineEnvironment.transform 14 8540 env52056 = env52057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52056 == env52057) = true)

theorem identity52057 : scanCanonicalize (H12AffineFastState.compose env52057 (packedSelected [1,4,8,9,10,12,14,15,19,20,31] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound52057 : packedSelected [1,4,8,9,10,12,14,15,19,20,31] rootPS < 2^1333 := by decide +kernel

def env52058 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8232,65536,131072,223258,1024,8233,4161,144492,17,73737,8193,65,203847,5220,17524,67618,1057,155672,116,21588,5157,74251]

theorem envBound52058 : H12AffineFastState.Bounded env52058 := by
  intro p hp
  have h : env52058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52057_52058 : H12AffineEnvironment.transform 7 116 env52057 = env52058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env52057 == env52058) = true)

theorem identity52058 : scanCanonicalize (H12AffineFastState.compose env52058 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound52058 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52059 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,16384,0,65536,131072,215090,1024,1,4161,136260,17,65569,41,65,203847,5220,17524,67618,1057,147504,116,21588,5157,66083]

theorem envBound52059 : H12AffineFastState.Bounded env52059 := by
  intro p hp
  have h : env52059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52058_52059 : H12AffineEnvironment.transform 12 40 env52058 = env52059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env52058 == env52059) = true)

theorem identity52059 : scanCanonicalize (H12AffineFastState.compose env52059 (packedSelected [1,3,4,5,8,9,10,14,16,18,19,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52059 : packedSelected [1,3,4,5,8,9,10,14,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env52060 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,0,65536,131072,215090,1024,1,4113,136212,17,65569,41,17,203799,5172,17444,67618,1057,147504,36,21508,5157,66083]

theorem envBound52060 : H12AffineFastState.Bounded env52060 := by
  intro p hp
  have h : env52060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52059_52060 : H12AffineEnvironment.transform 5 16 env52059 = env52060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52059 == env52060) = true)

theorem identity52060 : scanCanonicalize (H12AffineFastState.compose env52060 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound52060 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env52061 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,0,65536,5173,89095,1024,1,4113,33,17,65569,41,17,67618,5172,17444,67618,1057,21509,36,21508,5157,66083]

theorem envBound52061 : H12AffineFastState.Bounded env52061 := by
  intro p hp
  have h : env52061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52060_52061 : H12AffineEnvironment.transform 16 5173 env52060 = env52061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env52060 == env52061) = true)

theorem identity52061 : scanCanonicalize (H12AffineFastState.compose env52061 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound52061 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env52062 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,0,35,5173,23588,1024,1,4113,33,17,2,41,17,2049,5172,17444,2049,1057,21509,36,21508,5157,512]

theorem envBound52062 : H12AffineFastState.Bounded env52062 := by
  intro p hp
  have h : env52062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52061_52062 : H12AffineEnvironment.transform 15 35 env52061 = env52062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env52061 == env52062) = true)

theorem identity52062 : scanCanonicalize (H12AffineFastState.compose env52062 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound52062 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52063 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5125,0,35,5173,2081,1024,1,4113,33,17,2,41,17,2049,5172,4129,2049,1057,0,36,1,5157,512]

theorem envBound52063 : H12AffineFastState.Bounded env52063 := by
  intro p hp
  have h : env52063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52062_52063 : H12AffineEnvironment.transform 13 5125 env52062 = env52063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env52062 == env52063) = true)

theorem identity52063 : scanCanonicalize (H12AffineFastState.compose env52063 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52063 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52064 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,4096,9,5125,0,2,5140,2048,1024,1,4113,0,17,2,8,17,2049,5141,4096,2049,1024,0,5,1,5124,512]

theorem envBound52064 : H12AffineFastState.Bounded env52064 := by
  intro p hp
  have h : env52064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52063_52064 : H12AffineEnvironment.transform 4 1 env52063 = env52064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52063 == env52064) = true)

theorem identity52064 : scanCanonicalize (H12AffineFastState.compose env52064 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound52064 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52065 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,1045,9,16,0,2,1,2048,1024,1,1028,0,17,2,8,17,2049,0,1045,2049,1024,0,5,1,17,512]

theorem envBound52065 : H12AffineFastState.Bounded env52065 := by
  intro p hp
  have h : env52065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52064_52065 : H12AffineEnvironment.transform 11 1045 env52064 = env52065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env52064 == env52065) = true)

theorem identity52065 : scanCanonicalize (H12AffineFastState.compose env52065 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound52065 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52066 : List Nat := [2,4,8,16,1,16,9,5,512,1024,10,1045,9,16,0,2,1,10,1024,1,1028,0,17,2,8,17,11,0,1045,11,1024,0,5,1,17,512]

theorem envBound52066 : H12AffineFastState.Bounded env52066 := by
  intro p hp
  have h : env52066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52065_52066 : H12AffineEnvironment.transform 10 10 env52065 = env52066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env52065 == env52066) = true)

theorem identity52066 : scanCanonicalize (H12AffineFastState.compose env52066 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52066 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52067 : List Nat := [2,4,8,16,1,16,9,5,0,1024,10,1045,9,16,0,2,1,10,1024,1,1028,0,17,2,8,17,11,0,1045,11,1024,0,5,1,17,0]

theorem envBound52067 : H12AffineFastState.Bounded env52067 := by
  intro p hp
  have h : env52067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52066_52067 : H12AffineEnvironment.transform 8 0 env52066 = env52067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52066 == env52067) = true)

theorem identity52067 : scanCanonicalize (H12AffineFastState.compose env52067 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound52067 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52068 : List Nat := [2,4,8,16,1,16,9,5,0,20,10,1,9,16,0,2,1,10,20,1,16,0,17,2,8,17,11,0,1,11,20,0,5,1,17,0]

theorem envBound52068 : H12AffineFastState.Bounded env52068 := by
  intro p hp
  have h : env52068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52067_52068 : H12AffineEnvironment.transform 9 20 env52067 = env52068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env52067 == env52068) = true)

theorem identity52068 : scanCanonicalize (H12AffineFastState.compose env52068 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound52068 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52069 : List Nat := [2,0,8,16,1,16,9,1,0,16,10,1,9,16,0,2,1,10,16,1,16,0,17,2,8,17,11,0,1,11,16,0,1,1,17,0]

theorem envBound52069 : H12AffineFastState.Bounded env52069 := by
  intro p hp
  have h : env52069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52068_52069 : H12AffineEnvironment.transform 1 0 env52068 = env52069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env52068 == env52069) = true)

theorem identity52069 : scanCanonicalize (H12AffineFastState.compose env52069 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound52069 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52070 : List Nat := [1,0,8,16,1,16,9,1,0,16,9,1,9,16,0,1,1,9,16,1,16,0,17,1,8,17,8,0,1,8,16,0,1,1,17,0]

theorem envBound52070 : H12AffineFastState.Bounded env52070 := by
  intro p hp
  have h : env52070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52069_52070 : H12AffineEnvironment.transform 0 1 env52069 = env52070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env52069 == env52070) = true)

def env52071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,2097152,4194304,2101329,2199965,8328,65,4270243,5392,17665,2210110,1501,4256860,256,2114912,2139332,74250]

theorem envBound52071 : H12AffineFastState.Bounded env52071 := by
  intro p hp
  have h : env52071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52008_52071 : H12AffineEnvironment.transform 22 2101329 env52008 = env52071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env52008 == env52071) = true)

def env52072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,4194304,17,98781,8328,65,4270243,5392,17665,108926,1501,4256860,256,21792,46212,74250]

theorem envBound52072 : H12AffineFastState.Bounded env52072 := by
  intro p hp
  have h : env52072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52071_52072 : H12AffineEnvironment.transform 20 4160 env52071 = env52072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env52071 == env52072) = true)

theorem identity52072 : scanCanonicalize (H12AffineFastState.compose env52072 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156132) := by decide +kernel

theorem selectedBound52072 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,156132,17,98781,8328,65,215367,5392,17665,108926,1501,169400,256,21792,46212,74250]

theorem envBound52073 : H12AffineFastState.Bounded env52073 := by
  intro p hp
  have h : env52073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52072_52073 : H12AffineEnvironment.transform 21 156132 env52072 = env52073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156132 env52072 == env52073) = true)

theorem identity52073 : scanCanonicalize (H12AffineFastState.compose env52073 (packedSelected [3,10,11,12,15,16,17,18,20,23,24,26,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound52073 : packedSelected [3,10,11,12,15,16,17,18,20,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env52074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,2421,1024,32769,4160,66047,17,98781,8328,65,10588,5392,17665,108926,1501,128419,256,21792,46212,74250]

theorem envBound52074 : H12AffineFastState.Bounded env52074 := by
  intro p hp
  have h : env52074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52073_52074 : H12AffineEnvironment.transform 16 90139 env52073 = env52074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env52073 == env52074) = true)

theorem identity52074 : scanCanonicalize (H12AffineFastState.compose env52074 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound52074 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env52075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,2421,1024,29909,4160,66047,17,95497,8328,65,10588,5392,17665,89514,1501,65911,256,21792,16464,74250]

theorem envBound52075 : H12AffineFastState.Bounded env52075 := by
  intro p hp
  have h : env52075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52074_52075 : H12AffineEnvironment.transform 14 29908 env52074 = env52075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env52074 == env52075) = true)

theorem identity52075 : scanCanonicalize (H12AffineFastState.compose env52075 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52075 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env52076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,16400,2421,1024,29909,4160,8692,17,21762,8328,65,10588,5392,17665,32161,1501,8572,256,21792,16464,513]

theorem envBound52076 : H12AffineFastState.Bounded env52076 := by
  intro p hp
  have h : env52076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52075_52076 : H12AffineEnvironment.transform 15 8203 env52075 = env52076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52075 == env52076) = true)

def env52077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,4194304,16,98780,8328,65,4270243,5392,17665,108927,1501,4256860,256,21793,46213,74250]

theorem envBound52077 : H12AffineFastState.Bounded env52077 := by
  intro p hp
  have h : env52077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52071_52077 : H12AffineEnvironment.transform 20 4161 env52071 = env52077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env52071 == env52077) = true)

theorem identity52077 : scanCanonicalize (H12AffineFastState.compose env52077 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound52077 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,223598,1024,29909,4161,4194304,16,95496,8328,65,4270243,5392,17665,89515,1501,4194440,256,21793,16465,74250]

theorem envBound52078 : H12AffineFastState.Bounded env52078 := by
  intro p hp
  have h : env52078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52077_52078 : H12AffineEnvironment.transform 14 29908 env52077 = env52078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env52077 == env52078) = true)

def env52079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,212078,1024,8661,4161,4194304,16,73736,8328,65,4270243,5392,4097,67755,1501,4194440,256,33,5457,74250]

theorem envBound52079 : H12AffineFastState.Bounded env52079 := by
  intro p hp
  have h : env52079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52078_52079 : H12AffineEnvironment.transform 13 5376 env52078 = env52079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52078 == env52079) = true)

theorem identity52079 : scanCanonicalize (H12AffineFastState.compose env52079 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound52079 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,70726,10280,1024,8661,4161,4194304,16,73736,8328,65,4270243,5392,4097,67755,1501,4194440,256,33,5457,74250]

theorem envBound52080 : H12AffineFastState.Bounded env52080 := by
  intro p hp
  have h : env52080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52079_52080 : H12AffineEnvironment.transform 16 70726 env52079 = env52080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env52079 == env52080) = true)

theorem identity52080 : scanCanonicalize (H12AffineFastState.compose env52080 (packedSelected [1,2,6,7,8,9,11,16,18,19,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52080 : packedSelected [1,2,6,7,8,9,11,16,18,19,22,27] rootPS < 2^1333 := by decide +kernel

def env52081 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,70726,10280,1024,8541,4161,4194304,16,73736,8192,65,4270123,5392,4097,67619,1365,4194304,256,33,5457,74250]

theorem envBound52081 : H12AffineFastState.Bounded env52081 := by
  intro p hp
  have h : env52081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52080_52081 : H12AffineEnvironment.transform 6 8 env52080 = env52081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52080 == env52081) = true)

theorem identity52081 : scanCanonicalize (H12AffineFastState.compose env52081 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound52081 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env52082 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,13389,10280,1024,8541,4161,4194304,16,3,8192,65,4196384,5392,4097,10280,1365,4194304,256,33,5457,513]

theorem envBound52082 : H12AffineFastState.Bounded env52082 := by
  intro p hp
  have h : env52082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52081_52082 : H12AffineEnvironment.transform 15 8203 env52081 = env52082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env52081 == env52082) = true)

theorem identity52082 : scanCanonicalize (H12AffineFastState.compose env52082 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound52082 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52083 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,13389,10280,1024,8541,4161,8493,16,3,8192,65,10509,5392,4097,10280,1365,8493,256,33,5457,513]

theorem envBound52083 : H12AffineFastState.Bounded env52083 := by
  intro p hp
  have h : env52083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52082_52083 : H12AffineEnvironment.transform 21 8493 env52082 = env52083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env52082 == env52083) = true)

theorem identity52083 : scanCanonicalize (H12AffineFastState.compose env52083 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52083 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52084 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,263,5441,2340,1024,81,4161,33,16,3,268,65,2049,5392,4097,2340,1365,33,256,33,5457,513]

theorem envBound52084 : H12AffineFastState.Bounded env52084 := by
  intro p hp
  have h : env52084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52083_52084 : H12AffineEnvironment.transform 12 268 env52083 = env52084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52083 == env52084) = true)

theorem identity52084 : scanCanonicalize (H12AffineFastState.compose env52084 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound52084 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env52085 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,268,5376,80,263,5441,1124,1024,81,4161,33,16,3,268,65,1345,5392,4097,1124,1365,33,256,33,5457,513]

theorem envBound52085 : H12AffineFastState.Bounded env52085 := by
  intro p hp
  have h : env52085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52084_52085 : H12AffineEnvironment.transform 10 1344 env52084 = env52085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env52084 == env52085) = true)

theorem identity52085 : scanCanonicalize (H12AffineFastState.compose env52085 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound52085 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52086 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1076,4096,120,5236,80,115,5173,1124,1024,81,4161,33,16,3,120,65,1077,5220,4097,1124,1057,33,116,33,5157,513]

theorem envBound52086 : H12AffineFastState.Bounded env52086 := by
  intro p hp
  have h : env52086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52085_52086 : H12AffineEnvironment.transform 7 116 env52085 = env52086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env52085 == env52086) = true)

theorem identity52086 : scanCanonicalize (H12AffineFastState.compose env52086 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound52086 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env52087 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1076,1061,120,81,80,115,16,1124,1024,81,1124,33,16,3,120,65,1077,65,1060,1124,1057,33,116,33,0,513]

theorem envBound52087 : H12AffineFastState.Bounded env52087 := by
  intro p hp
  have h : env52087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52086_52087 : H12AffineEnvironment.transform 11 1061 env52086 = env52087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env52086 == env52087) = true)

theorem identity52087 : scanCanonicalize (H12AffineFastState.compose env52087 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52087 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env52088 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1076,1061,41,0,1,34,16,1077,1024,0,1077,33,16,3,41,16,1077,16,1060,1077,1057,33,37,33,0,513]

theorem envBound52088 : H12AffineFastState.Bounded env52088 := by
  intro p hp
  have h : env52088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52087_52088 : H12AffineEnvironment.transform 5 17 env52087 = env52088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52087 == env52088) = true)

def env52089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,212079,1024,8660,4161,4194304,16,73737,8328,65,4270243,5392,4096,67754,1501,4194440,256,32,5456,74250]

theorem envBound52089 : H12AffineFastState.Bounded env52089 := by
  intro p hp
  have h : env52089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52078_52089 : H12AffineEnvironment.transform 13 5377 env52078 = env52089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52078 == env52089) = true)

theorem identity52089 : scanCanonicalize (H12AffineFastState.compose env52089 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound52089 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,70863,10400,1024,8660,4161,4194304,16,73737,8328,65,4270243,5392,4096,67754,1501,4194440,256,32,5456,74250]

theorem envBound52090 : H12AffineFastState.Bounded env52090 := by
  intro p hp
  have h : env52090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52089_52090 : H12AffineEnvironment.transform 16 70863 env52089 = env52090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env52089 == env52090) = true)

theorem identity52090 : scanCanonicalize (H12AffineFastState.compose env52090 (packedSelected [0,1,2,5,6,10,12,14,15,16,18,20,24,27,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 8612) := by decide +kernel

theorem selectedBound52090 : packedSelected [0,1,2,5,6,10,12,14,15,16,18,20,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env52091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,70863,10400,1024,8660,4161,8612,16,73737,8328,65,67847,5392,4096,67754,1501,8492,256,32,5456,74250]

theorem envBound52091 : H12AffineFastState.Bounded env52091 := by
  intro p hp
  have h : env52091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52090_52091 : H12AffineEnvironment.transform 21 8612 env52090 = env52091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8612 env52090 == env52091) = true)

theorem identity52091 : scanCanonicalize (H12AffineFastState.compose env52091 (packedSelected [0,1,3,5,8,9,10,19,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound52091 : packedSelected [0,1,3,5,8,9,10,19,22,27] rootPS < 2^1333 := by decide +kernel

def env52092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,0,65536,70863,2421,1024,1,4161,113,16,66012,349,65,67847,5392,4096,67754,1501,249,256,32,5456,66527]

theorem envBound52092 : H12AffineFastState.Bounded env52092 := by
  intro p hp
  have h : env52092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52091_52092 : H12AffineEnvironment.transform 12 469 env52091 = env52092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env52091 == env52092) = true)

theorem identity52092 : scanCanonicalize (H12AffineFastState.compose env52092 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound52092 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env52093 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5377,0,65536,70678,2421,1024,1,4161,113,16,65797,349,65,67847,5392,4096,67699,1284,32,256,32,5456,66310]

theorem envBound52093 : H12AffineFastState.Bounded env52093 := by
  intro p hp
  have h : env52093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52092_52093 : H12AffineEnvironment.transform 6 89 env52092 = env52093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env52092 == env52093) = true)

theorem identity52093 : scanCanonicalize (H12AffineFastState.compose env52093 (packedSelected [0,3,4,5,7,9,10,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 2163) := by decide +kernel

theorem selectedBound52093 : packedSelected [0,3,4,5,7,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env52094 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5377,0,2163,7269,2421,1024,1,4161,113,16,2422,349,65,372,5392,4096,0,1284,32,256,32,5456,2933]

theorem envBound52094 : H12AffineFastState.Bounded env52094 := by
  intro p hp
  have h : env52094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52093_52094 : H12AffineEnvironment.transform 15 2163 env52093 = env52094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2163 env52093 == env52094) = true)

theorem identity52094 : scanCanonicalize (H12AffineFastState.compose env52094 (packedSelected [1,2,3,4,5,6,8,9,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound52094 : packedSelected [1,2,3,4,5,6,8,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env52095 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3109,268,2340,0,2163,64,2421,1024,1,3172,113,16,2422,349,65,372,2357,3109,0,1284,32,256,32,2421,2933]

theorem envBound52095 : H12AffineFastState.Bounded env52095 := by
  intro p hp
  have h : env52095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52094_52095 : H12AffineEnvironment.transform 11 3109 env52094 = env52095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env52094 == env52095) = true)

theorem identity52095 : scanCanonicalize (H12AffineFastState.compose env52095 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound52095 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env52096 : List Nat := [2,4,8,16,32,64,89,256,512,53,2048,2064,268,2340,0,2163,64,2421,53,1,2129,113,16,2422,349,65,372,2357,2064,0,305,32,256,32,2421,2933]

theorem envBound52096 : H12AffineFastState.Bounded env52096 := by
  intro p hp
  have h : env52096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52095_52096 : H12AffineEnvironment.transform 9 53 env52095 = env52096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52095 == env52096) = true)

theorem identity52096 : scanCanonicalize (H12AffineFastState.compose env52096 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound52096 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52097 : List Nat := [2,4,8,16,32,64,89,256,512,53,372,356,268,80,0,263,64,1,53,1,293,113,16,2,349,65,372,65,356,0,305,32,256,32,1,513]

theorem envBound52097 : H12AffineFastState.Bounded env52097 := by
  intro p hp
  have h : env52097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52096_52097 : H12AffineEnvironment.transform 10 372 env52096 = env52097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env52096 == env52097) = true)

theorem identity52097 : scanCanonicalize (H12AffineFastState.compose env52097 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound52097 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env52098 : List Nat := [2,4,8,16,32,64,89,256,11,53,372,356,268,80,0,263,64,1,53,1,293,113,16,2,349,65,372,65,356,0,305,32,256,32,1,10]

theorem envBound52098 : H12AffineFastState.Bounded env52098 := by
  intro p hp
  have h : env52098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52097_52098 : H12AffineEnvironment.transform 8 11 env52097 = env52098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env52097 == env52098) = true)

theorem identity52098 : scanCanonicalize (H12AffineFastState.compose env52098 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52098 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env52099 : List Nat := [2,4,8,16,32,17,8,256,11,53,293,309,268,1,0,263,17,1,53,1,293,32,16,2,268,16,293,16,309,0,305,32,256,32,1,10]

theorem envBound52099 : H12AffineFastState.Bounded env52099 := by
  intro p hp
  have h : env52099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52098_52099 : H12AffineEnvironment.transform 5 17 env52098 = env52099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52098 == env52099) = true)

theorem identity52099 : scanCanonicalize (H12AffineFastState.compose env52099 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound52099 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52100 : List Nat := [2,4,8,16,32,17,8,4,11,53,33,49,8,1,0,3,17,1,53,1,33,32,16,2,8,16,33,16,49,0,53,32,4,32,1,10]

theorem envBound52100 : H12AffineFastState.Bounded env52100 := by
  intro p hp
  have h : env52100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52099_52100 : H12AffineEnvironment.transform 7 4 env52099 = env52100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env52099 == env52100) = true)

theorem identity52100 : scanCanonicalize (H12AffineFastState.compose env52100 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound52100 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52101 : List Nat := [2,4,8,16,10,17,8,4,11,31,11,27,8,1,0,3,17,1,31,1,11,10,16,2,8,16,11,16,27,0,31,10,4,10,1,10]

theorem envBound52101 : H12AffineFastState.Bounded env52101 := by
  intro p hp
  have h : env52101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52100_52101 : H12AffineEnvironment.transform 4 10 env52100 = env52101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env52100 == env52101) = true)

theorem identity52101 : scanCanonicalize (H12AffineFastState.compose env52101 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound52101 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52102 : List Nat := [2,4,7,16,5,17,7,4,4,16,4,20,7,1,0,3,17,1,16,1,4,5,16,2,7,16,4,16,20,0,16,5,4,5,1,5]

theorem envBound52102 : H12AffineFastState.Bounded env52102 := by
  intro p hp
  have h : env52102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52101_52102 : H12AffineEnvironment.transform 2 7 env52101 = env52102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env52101 == env52102) = true)

theorem identity52102 : scanCanonicalize (H12AffineFastState.compose env52102 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52102 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52103 : List Nat := [2,4,7,0,5,1,7,4,4,0,4,4,7,1,0,3,1,1,0,1,4,5,0,2,7,0,4,0,4,0,0,5,4,5,1,5]

theorem envBound52103 : H12AffineFastState.Bounded env52103 := by
  intro p hp
  have h : env52103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52102_52103 : H12AffineEnvironment.transform 3 0 env52102 = env52103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52102 == env52103) = true)

theorem identity52103 : scanCanonicalize (H12AffineFastState.compose env52103 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52103 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52104 : List Nat := [2,2,1,0,3,1,1,2,2,0,2,2,1,1,0,3,1,1,0,1,2,3,0,2,1,0,2,0,2,0,0,3,2,3,1,3]

theorem envBound52104 : H12AffineFastState.Bounded env52104 := by
  intro p hp
  have h : env52104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52103_52104 : H12AffineEnvironment.transform 1 2 env52103 = env52104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52103 == env52104) = true)

def env52105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound52105 : H12AffineFastState.Bounded env52105 := by
  intro p hp
  have h : env52105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51937_52105 : H12AffineEnvironment.transform 18 1025 env51937 = env52105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env51937 == env52105) = true)

theorem identity52105 : scanCanonicalize (H12AffineFastState.compose env52105 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8686062) := by decide +kernel

theorem selectedBound52105 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env52106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8686062,8328,65,4409838,10816866,10507600,8830976,331263,15068207,257,2444611,2469094,272937]

theorem envBound52106 : H12AffineFastState.Bounded env52106 := by
  intro p hp
  have h : env52106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52105_52106 : H12AffineEnvironment.transform 23 8686062 env52105 = env52106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8686062 env52105 == env52106) = true)

def env52107 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685926,8192,65,4409702,10816866,10507600,8830976,331127,15068207,257,2444611,2468974,272937]

theorem envBound52107 : H12AffineFastState.Bounded env52107 := by
  intro p hp
  have h : env52107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52106_52107 : H12AffineEnvironment.transform 6 8 env52106 = env52107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52106 == env52107) = true)

theorem identity52107 : scanCanonicalize (H12AffineFastState.compose env52107 (packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS)) = affineNative (2^(22+1) ^^^ 371054) := by decide +kernel

theorem selectedBound52107 : packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env52108 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,371054,73736,8192,65,4409702,2139148,2489406,223598,331127,6309185,257,2444611,2468974,272937]

theorem envBound52108 : H12AffineFastState.Bounded env52108 := by
  intro p hp
  have h : env52108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52107_52108 : H12AffineEnvironment.transform 22 371054 env52107 = env52108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 371054 env52107 == env52108) = true)

theorem identity52108 : scanCanonicalize (H12AffineFastState.compose env52108 (packedSelected [1,5,8,17,19,21,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound52108 : packedSelected [1,5,8,17,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env52109 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,2097152,4194304,297316,2,8192,65,4352364,2139148,2415668,149860,273789,6309185,257,2387273,2395236,272937]

theorem envBound52109 : H12AffineFastState.Bounded env52109 := by
  intro p hp
  have h : env52109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52108_52109 : H12AffineEnvironment.transform 15 8202 env52108 = env52109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env52108 == env52109) = true)

theorem identity52109 : scanCanonicalize (H12AffineFastState.compose env52109 (packedSelected [0,3,4,5,7,8,10,11,16,18,20,22,23,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound52109 : packedSelected [0,3,4,5,7,8,10,11,16,18,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env52110 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,157752,1025,32769,2097152,4194304,188764,2,8192,65,4352364,2139148,2274316,149860,148805,6309185,257,2229617,2286684,147985]

theorem envBound52110 : H12AffineFastState.Bounded env52110 := by
  intro p hp
  have h : env52110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52109_52110 : H12AffineEnvironment.transform 17 157752 env52109 = env52110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env52109 == env52110) = true)

theorem identity52110 : scanCanonicalize (H12AffineFastState.compose env52110 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound52110 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env52111 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1025,32769,2097152,4194304,41292,2,8192,65,4204924,2139148,2159644,2420,1365,6309185,257,2114913,2139212,513]

theorem envBound52111 : H12AffineFastState.Bounded env52111 := by
  intro p hp
  have h : env52111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52110_52111 : H12AffineEnvironment.transform 16 16400 env52110 = env52111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env52110 == env52111) = true)

theorem identity52111 : scanCanonicalize (H12AffineFastState.compose env52111 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52111 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env52112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1025,8540,2097152,4194304,17,2,8192,65,4204924,2098513,2118977,2420,1365,6309185,257,2114913,2098449,513]

theorem envBound52112 : H12AffineFastState.Bounded env52112 := by
  intro p hp
  have h : env52112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52111_52112 : H12AffineEnvironment.transform 14 8541 env52111 = env52112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52111 == env52112) = true)

theorem identity52112 : scanCanonicalize (H12AffineFastState.compose env52112 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 16497) := by decide +kernel

theorem selectedBound52112 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env52113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1025,8540,2097152,16497,17,2,8192,65,26893,2098513,2118977,2420,1365,2098480,257,2114913,2098449,513]

theorem envBound52113 : H12AffineFastState.Bounded env52113 := by
  intro p hp
  have h : env52113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52112_52113 : H12AffineEnvironment.transform 21 16497 env52112 = env52113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16497 env52112 == env52113) = true)

theorem identity52113 : scanCanonicalize (H12AffineFastState.compose env52113 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(20+1) ^^^ 12572) := by decide +kernel

theorem selectedBound52113 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env52114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1025,8540,12572,16497,17,2,8192,65,26893,13389,25693,2420,1365,13356,257,29821,13325,513]

theorem envBound52114 : H12AffineFastState.Bounded env52114 := by
  intro p hp
  have h : env52114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52113_52114 : H12AffineEnvironment.transform 20 12572 env52113 = env52114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12572 env52113 == env52114) = true)

theorem identity52114 : scanCanonicalize (H12AffineFastState.compose env52114 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound52114 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,1296,1095,16400,3173,1025,1297,5457,16497,17,2,1101,65,19776,4096,16400,2420,1365,4193,257,20528,4160,513]

theorem envBound52115 : H12AffineFastState.Bounded env52115 := by
  intro p hp
  have h : env52115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52114_52115 : H12AffineEnvironment.transform 12 1101 env52114 = env52115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env52114 == env52115) = true)

theorem identity52115 : scanCanonicalize (H12AffineFastState.compose env52115 (packedSelected [4,9,23] rootPS)) = affineNative (2^(13+1) ^^^ 81) := by decide +kernel

theorem selectedBound52115 : packedSelected [4,9,23] rootPS < 2^1333 := by decide +kernel

def env52116 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,81,1296,1095,65,3173,1025,1297,5457,32,17,2,1101,65,3345,4096,65,2420,1365,4193,257,4193,4160,513]

theorem envBound52116 : H12AffineFastState.Bounded env52116 := by
  intro p hp
  have h : env52116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52115_52116 : H12AffineEnvironment.transform 13 81 env52115 = env52116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 81 env52115 == env52116) = true)

theorem identity52116 : scanCanonicalize (H12AffineFastState.compose env52116 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound52116 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52117 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,16,1101,81,1296,1095,65,3173,1025,1297,1345,32,17,2,1101,65,3345,16,65,2420,1365,113,257,113,80,513]

theorem envBound52117 : H12AffineFastState.Bounded env52117 := by
  intro p hp
  have h : env52117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52116_52117 : H12AffineEnvironment.transform 11 16 env52116 = env52117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env52116 == env52117) = true)

theorem identity52117 : scanCanonicalize (H12AffineFastState.compose env52117 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound52117 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52118 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1077,16,1101,81,1296,1095,65,80,1025,1297,1345,32,17,2,1101,65,292,16,65,1345,1365,113,257,113,80,513]

theorem envBound52118 : H12AffineFastState.Bounded env52118 := by
  intro p hp
  have h : env52118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52117_52118 : H12AffineEnvironment.transform 10 1077 env52117 = env52118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env52117 == env52118) = true)

theorem identity52118 : scanCanonicalize (H12AffineFastState.compose env52118 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound52118 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env52119 : List Nat := [2,4,8,16,32,64,8,256,512,273,292,16,348,81,1,342,65,80,272,0,80,32,17,2,348,65,292,16,65,80,68,113,257,113,80,513]

theorem envBound52119 : H12AffineFastState.Bounded env52119 := by
  intro p hp
  have h : env52119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52118_52119 : H12AffineEnvironment.transform 9 273 env52118 = env52119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env52118 == env52119) = true)

theorem identity52119 : scanCanonicalize (H12AffineFastState.compose env52119 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52119 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52120 : List Nat := [2,4,8,16,32,17,8,256,512,273,292,16,269,0,1,263,16,1,272,0,1,32,17,2,269,16,292,16,16,1,21,32,257,32,1,513]

theorem envBound52120 : H12AffineFastState.Bounded env52120 := by
  intro p hp
  have h : env52120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52119_52120 : H12AffineEnvironment.transform 5 17 env52119 = env52120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52119 == env52120) = true)

def env52121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685927,8193,65,4409703,10816866,10507600,8830976,331126,15068207,257,2444611,2468975,272937]

theorem envBound52121 : H12AffineFastState.Bounded env52121 := by
  intro p hp
  have h : env52121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52106_52121 : H12AffineEnvironment.transform 6 9 env52106 = env52121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52106 == env52121) = true)

def env52122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685927,8193,65,4262263,10816866,10507600,8683536,331126,15068207,257,2444611,2468975,272937]

theorem envBound52122 : H12AffineFastState.Bounded env52122 := by
  intro p hp
  have h : env52122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52121_52122 : H12AffineEnvironment.transform 16 16400 env52121 = env52122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env52121 == env52122) = true)

theorem identity52122 : scanCanonicalize (H12AffineFastState.compose env52122 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound52122 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env52123 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,8388608,8429903,8193,65,4262263,10560842,10507600,8431672,75102,14795783,257,2188651,2196551,513]

theorem envBound52123 : H12AffineFastState.Bounded env52123 := by
  intro p hp
  have h : env52123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52122_52123 : H12AffineEnvironment.transform 17 10280 env52122 = env52123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52122 == env52123) = true)

def env52124 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,8388608,8429855,8193,17,4262183,10560794,10507520,8431672,75022,14795783,257,2188603,2196503,513]

theorem envBound52124 : H12AffineFastState.Bounded env52124 := by
  intro p hp
  have h : env52124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52123_52124 : H12AffineEnvironment.transform 5 16 env52123 = env52124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52123 == env52124) = true)

theorem identity52124 : scanCanonicalize (H12AffineFastState.compose env52124 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4268090) := by decide +kernel

theorem selectedBound52124 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env52125 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,4268090,4292901,8193,17,4262183,6292768,6387002,4294658,75022,2155581,257,2188603,2196503,513]

theorem envBound52125 : H12AffineFastState.Bounded env52125 := by
  intro p hp
  have h : env52125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52124_52125 : H12AffineEnvironment.transform 22 4268090 env52124 = env52125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4268090 env52124 == env52125) = true)

theorem identity52125 : scanCanonicalize (H12AffineFastState.compose env52125 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(20+1) ^^^ 91418) := by decide +kernel

theorem selectedBound52125 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env52126 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,91418,4194304,4268090,4292901,8193,17,4262183,4284474,4198432,4294658,75022,98599,257,33,57613,513]

theorem envBound52126 : H12AffineFastState.Bounded env52126 := by
  intro p hp
  have h : env52126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52125_52126 : H12AffineEnvironment.transform 20 91418 env52125 = env52126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91418 env52125 == env52126) = true)

theorem identity52126 : scanCanonicalize (H12AffineFastState.compose env52126 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound52126 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env52127 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,262,16400,10280,1025,32769,25628,4194304,4202812,4227107,8193,17,4196385,4219196,4198432,4229380,9224,32801,257,33,57613,513]

theorem envBound52127 : H12AffineFastState.Bounded env52127 := by
  intro p hp
  have h : env52127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52126_52127 : H12AffineEnvironment.transform 15 262 env52126 = env52127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env52126 == env52127) = true)

theorem identity52127 : scanCanonicalize (H12AffineFastState.compose env52127 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound52127 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52128 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,262,16400,10280,1025,32769,25628,41260,32784,8463,8193,17,43277,49168,45324,10280,9224,32801,257,33,57613,513]

theorem envBound52128 : H12AffineFastState.Bounded env52128 := by
  intro p hp
  have h : env52128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52127_52128 : H12AffineEnvironment.transform 21 41260 env52127 = env52128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env52127 == env52128) = true)

theorem identity52128 : scanCanonicalize (H12AffineFastState.compose env52128 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52128 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52129 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,262,16400,2340,1025,32769,17680,32800,32784,3,269,17,34817,49168,36864,2340,1284,32801,257,33,49153,513]

theorem envBound52129 : H12AffineFastState.Bounded env52129 := by
  intro p hp
  have h : env52129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52128_52129 : H12AffineEnvironment.transform 12 268 env52128 = env52129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52128 == env52129) = true)

theorem identity52129 : scanCanonicalize (H12AffineFastState.compose env52129 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52129 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52130 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,262,16400,2340,1025,0,17680,33,17,3,269,17,2048,16401,4097,2340,1284,32,257,33,16384,513]

theorem envBound52130 : H12AffineFastState.Bounded env52130 := by
  intro p hp
  have h : env52130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52129_52130 : H12AffineEnvironment.transform 14 1 env52129 = env52130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52129 == env52130) = true)

theorem identity52130 : scanCanonicalize (H12AffineFastState.compose env52130 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound52130 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52131 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5156,1,262,5172,2340,1025,0,4404,33,17,3,269,17,2048,5173,4097,2340,1284,32,257,33,5156,513]

theorem envBound52131 : H12AffineFastState.Bounded env52131 := by
  intro p hp
  have h : env52131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52130_52131 : H12AffineEnvironment.transform 13 5156 env52130 = env52131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env52130 == env52131) = true)

def env52132 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3888,268,2836,1,262,2820,2340,1025,0,3588,33,17,3,269,17,2048,2821,3889,2340,1284,32,257,33,2836,513]

theorem envBound52132 : H12AffineFastState.Bounded env52132 := by
  intro p hp
  have h : env52132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52131_52132 : H12AffineEnvironment.transform 11 3888 env52131 = env52132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env52131 == env52132) = true)

def env52133 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,48,268,1044,1,262,1028,1572,1025,0,260,33,17,3,269,17,1792,1029,49,1572,1284,32,257,33,1044,513]

theorem envBound52133 : H12AffineFastState.Bounded env52133 := by
  intro p hp
  have h : env52133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52132_52133 : H12AffineEnvironment.transform 10 1792 env52132 = env52133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env52132 == env52133) = true)

theorem identity52133 : scanCanonicalize (H12AffineFastState.compose env52133 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound52133 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52134 : List Nat := [2,4,8,16,32,16,9,256,512,305,561,48,268,293,1,262,309,789,304,0,260,33,17,3,269,17,561,308,49,789,53,32,257,33,293,513]

theorem envBound52134 : H12AffineFastState.Bounded env52134 := by
  intro p hp
  have h : env52134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52133_52134 : H12AffineEnvironment.transform 9 305 env52133 = env52134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env52133 == env52134) = true)

def env52135 : List Nat := [2,4,8,16,32,16,9,4,512,53,561,48,8,33,1,2,49,529,52,0,0,33,17,3,9,17,561,48,49,529,53,32,5,33,33,513]

theorem envBound52135 : H12AffineFastState.Bounded env52135 := by
  intro p hp
  have h : env52135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52134_52135 : H12AffineEnvironment.transform 7 4 env52134 = env52135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env52134 == env52135) = true)

theorem identity52135 : scanCanonicalize (H12AffineFastState.compose env52135 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52135 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52136 : List Nat := [2,4,8,11,32,11,9,4,512,46,554,43,8,33,1,2,42,522,47,0,0,33,10,3,9,10,554,43,42,522,46,32,5,33,33,513]

theorem envBound52136 : H12AffineFastState.Bounded env52136 := by
  intro p hp
  have h : env52136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52135_52136 : H12AffineEnvironment.transform 3 11 env52135 = env52136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52135 == env52136) = true)

def leafEnv52136 : List Nat := [2,4,8,11,32,11,9,4,512,46,554,43,8,33,1,2,42,522,47,0,0,33,10,3,47,9,1,10,554,43,42,522,46,32,5,33,5,3,33,513,1,0,0]

def active52136 : List Nat := [0,1,2,4,8]

def tree52136 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52136 : H12WitnessSearch.Good tree52136 := H12GlobalWitnessIndex.good

theorem leafIdentity52136 : H12AffineFastState.composeSystem env52136 rootObs = leafEnv52136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52136 rootObs == leafEnv52136) = true)

theorem terminalChecked52136 : H12PackedTerminal.terminalCheckFast leafEnv52136 active52136 tree52136 = true := by decide +kernel

def env52137 : List Nat := [2,4,8,16,32,16,9,5,512,52,561,48,9,32,1,3,48,528,53,0,1,33,17,3,8,17,561,49,49,528,53,32,4,33,32,513]

theorem envBound52137 : H12AffineFastState.Bounded env52137 := by
  intro p hp
  have h : env52137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52134_52137 : H12AffineEnvironment.transform 7 5 env52134 = env52137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52134 == env52137) = true)

theorem identity52137 : scanCanonicalize (H12AffineFastState.compose env52137 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound52137 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52138 : List Nat := [2,4,8,16,32,16,9,5,16,52,33,48,9,32,1,3,48,0,53,0,1,33,17,3,8,17,33,49,49,0,53,32,4,33,32,17]

theorem envBound52138 : H12AffineFastState.Bounded env52138 := by
  intro p hp
  have h : env52138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52137_52138 : H12AffineEnvironment.transform 8 16 env52137 = env52138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env52137 == env52138) = true)

def leafEnv52138 : List Nat := [2,4,8,16,32,16,9,5,16,52,33,48,9,32,1,3,48,0,53,0,1,33,17,3,52,8,1,17,33,49,49,0,53,32,4,33,5,2,32,17,1,1,0]

def active52138 : List Nat := [0,1,2,3,4]

def tree52138 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52138 : H12WitnessSearch.Good tree52138 := H12GlobalWitnessIndex.good

theorem leafIdentity52138 : H12AffineFastState.composeSystem env52138 rootObs = leafEnv52138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52138 rootObs == leafEnv52138) = true)

theorem terminalChecked52138 : H12PackedTerminal.terminalCheckFast leafEnv52138 active52138 tree52138 = true := by decide +kernel

def env52139 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,49,268,1045,1,262,1029,1573,1025,0,261,33,17,3,269,17,1793,1028,48,1573,1284,32,257,33,1045,513]

theorem envBound52139 : H12AffineFastState.Bounded env52139 := by
  intro p hp
  have h : env52139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52132_52139 : H12AffineEnvironment.transform 10 1793 env52132 = env52139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env52132 == env52139) = true)

theorem identity52139 : scanCanonicalize (H12AffineFastState.compose env52139 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52139 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52140 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1793,17,268,1045,1,262,1029,1541,1025,0,261,1,17,3,269,17,1793,1028,16,1541,1284,0,257,1,1045,513]

theorem envBound52140 : H12AffineFastState.Bounded env52140 := by
  intro p hp
  have h : env52140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52139_52140 : H12AffineEnvironment.transform 4 0 env52139 = env52140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52139 == env52140) = true)

def env52141 : List Nat := [2,4,8,16,0,16,9,256,512,20,789,17,268,1,1,262,17,529,21,0,261,1,17,3,269,17,789,16,16,529,272,0,257,1,1,513]

theorem envBound52141 : H12AffineFastState.Bounded env52141 := by
  intro p hp
  have h : env52141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52140_52141 : H12AffineEnvironment.transform 9 20 env52140 = env52141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env52140 == env52141) = true)

theorem identity52141 : scanCanonicalize (H12AffineFastState.compose env52141 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound52141 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52142 : List Nat := [2,4,8,16,0,16,9,256,277,20,0,17,268,1,1,262,17,260,21,0,261,1,17,3,269,17,0,16,16,260,272,0,257,1,1,276]

theorem envBound52142 : H12AffineFastState.Bounded env52142 := by
  intro p hp
  have h : env52142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52141_52142 : H12AffineEnvironment.transform 8 277 env52141 = env52142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env52141 == env52142) = true)

def leafEnv52142 : List Nat := [2,4,8,16,0,16,9,256,277,20,0,17,268,1,1,262,17,260,21,0,261,1,17,3,273,269,1,17,0,16,16,260,272,0,257,1,5,263,1,276,1,261,0]

def active52142 : List Nat := [0,1,2,3,7]

def tree52142 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52142 : H12WitnessSearch.Good tree52142 := H12GlobalWitnessIndex.good

theorem leafIdentity52142 : H12AffineFastState.composeSystem env52142 rootObs = leafEnv52142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52142 rootObs == leafEnv52142) = true)

theorem terminalChecked52142 : H12PackedTerminal.terminalCheckFast leafEnv52142 active52142 tree52142 = true := by decide +kernel

def env52143 : List Nat := [2,4,8,16,0,16,9,256,512,21,788,17,268,0,1,262,16,528,20,0,261,1,17,3,269,17,788,17,16,528,273,0,257,1,0,513]

theorem envBound52143 : H12AffineFastState.Bounded env52143 := by
  intro p hp
  have h : env52143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52140_52143 : H12AffineEnvironment.transform 9 21 env52140 = env52143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env52140 == env52143) = true)

theorem identity52143 : scanCanonicalize (H12AffineFastState.compose env52143 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52143 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52144 : List Nat := [2,4,8,10,0,10,9,256,512,15,782,11,268,0,1,262,10,522,14,0,261,1,11,3,269,11,782,11,10,522,267,0,257,1,0,513]

theorem envBound52144 : H12AffineFastState.Bounded env52144 := by
  intro p hp
  have h : env52144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52143_52144 : H12AffineEnvironment.transform 3 10 env52143 = env52144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52143 == env52144) = true)

def leafEnv52144 : List Nat := [2,4,8,10,0,10,9,256,512,15,782,11,268,0,1,262,10,522,14,0,261,1,11,3,266,269,1,11,782,11,10,522,267,0,257,1,5,263,0,513,1,261,0]

def active52144 : List Nat := [0,1,2,7,8]

def tree52144 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52144 : H12WitnessSearch.Good tree52144 := H12GlobalWitnessIndex.good

theorem leafIdentity52144 : H12AffineFastState.composeSystem env52144 rootObs = leafEnv52144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52144 rootObs == leafEnv52144) = true)

theorem terminalChecked52144 : H12PackedTerminal.terminalCheckFast leafEnv52144 active52144 tree52144 = true := by decide +kernel

def env52145 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3889,268,2837,1,262,2821,2340,1025,0,3589,33,17,3,269,17,2048,2820,3888,2340,1284,32,257,33,2837,513]

theorem envBound52145 : H12AffineFastState.Bounded env52145 := by
  intro p hp
  have h : env52145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52131_52145 : H12AffineEnvironment.transform 11 3889 env52131 = env52145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env52131 == env52145) = true)

def env52146 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1792,49,268,1045,1,262,1029,1572,1025,0,261,33,17,3,269,17,1792,1028,48,1572,1284,32,257,33,1045,513]

theorem envBound52146 : H12AffineFastState.Bounded env52146 := by
  intro p hp
  have h : env52146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52145_52146 : H12AffineEnvironment.transform 10 1792 env52145 = env52146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env52145 == env52146) = true)

theorem identity52146 : scanCanonicalize (H12AffineFastState.compose env52146 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52146 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52147 : List Nat := [2,4,8,16,32,16,9,5,512,1024,1541,49,9,1045,1,3,1029,1572,1025,0,0,33,17,3,8,17,1541,1028,48,1572,1025,32,4,33,1045,513]

theorem envBound52147 : H12AffineFastState.Bounded env52147 := by
  intro p hp
  have h : env52147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52146_52147 : H12AffineEnvironment.transform 7 5 env52146 = env52147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52146 == env52147) = true)

def env52148 : List Nat := [2,4,8,16,32,16,9,5,512,52,561,49,9,33,1,3,49,528,53,0,0,33,17,3,8,17,561,48,48,528,53,32,4,33,33,513]

theorem envBound52148 : H12AffineFastState.Bounded env52148 := by
  intro p hp
  have h : env52148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52147_52148 : H12AffineEnvironment.transform 9 52 env52147 = env52148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52147 == env52148) = true)

theorem identity52148 : scanCanonicalize (H12AffineFastState.compose env52148 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound52148 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52149 : List Nat := [2,4,8,16,32,16,9,5,17,52,32,49,9,33,1,3,49,1,53,0,0,33,17,3,8,17,32,48,48,1,53,32,4,33,33,16]

theorem envBound52149 : H12AffineFastState.Bounded env52149 := by
  intro p hp
  have h : env52149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52148_52149 : H12AffineEnvironment.transform 8 17 env52148 = env52149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env52148 == env52149) = true)

def leafEnv52149 : List Nat := [2,4,8,16,32,16,9,5,17,52,32,49,9,33,1,3,49,1,53,0,0,33,17,3,52,8,1,17,32,48,48,1,53,32,4,33,5,2,33,16,1,0,0]

def active52149 : List Nat := [0,1,2,3,4]

def tree52149 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52149 : H12WitnessSearch.Good tree52149 := H12GlobalWitnessIndex.good

theorem leafIdentity52149 : H12AffineFastState.composeSystem env52149 rootObs = leafEnv52149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52149 rootObs == leafEnv52149) = true)

theorem terminalChecked52149 : H12PackedTerminal.terminalCheckFast leafEnv52149 active52149 tree52149 = true := by decide +kernel

def env52150 : List Nat := [2,4,8,16,32,16,9,5,512,53,560,49,9,32,1,3,48,529,52,0,0,33,17,3,8,17,560,49,48,529,52,32,4,33,32,513]

theorem envBound52150 : H12AffineFastState.Bounded env52150 := by
  intro p hp
  have h : env52150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52147_52150 : H12AffineEnvironment.transform 9 53 env52147 = env52150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52147 == env52150) = true)

theorem identity52150 : scanCanonicalize (H12AffineFastState.compose env52150 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52150 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52151 : List Nat := [2,4,8,11,32,11,9,5,512,46,555,42,9,32,1,3,43,522,47,0,0,33,10,3,8,10,555,42,43,522,47,32,4,33,32,513]

theorem envBound52151 : H12AffineFastState.Bounded env52151 := by
  intro p hp
  have h : env52151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52150_52151 : H12AffineEnvironment.transform 3 11 env52150 = env52151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52150 == env52151) = true)

def leafEnv52151 : List Nat := [2,4,8,11,32,11,9,5,512,46,555,42,9,32,1,3,43,522,47,0,0,33,10,3,46,8,1,10,555,42,43,522,47,32,4,33,5,2,32,513,1,0,0]

def active52151 : List Nat := [0,1,2,4,8]

def tree52151 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52151 : H12WitnessSearch.Good tree52151 := H12GlobalWitnessIndex.good

theorem leafIdentity52151 : H12AffineFastState.composeSystem env52151 rootObs = leafEnv52151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52151 rootObs == leafEnv52151) = true)

theorem terminalChecked52151 : H12PackedTerminal.terminalCheckFast leafEnv52151 active52151 tree52151 = true := by decide +kernel

def env52152 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1793,48,268,1044,1,262,1028,1573,1025,0,260,33,17,3,269,17,1793,1029,49,1573,1284,32,257,33,1044,513]

theorem envBound52152 : H12AffineFastState.Bounded env52152 := by
  intro p hp
  have h : env52152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52145_52152 : H12AffineEnvironment.transform 10 1793 env52145 = env52152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env52145 == env52152) = true)

theorem identity52152 : scanCanonicalize (H12AffineFastState.compose env52152 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound52152 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52153 : List Nat := [2,4,8,16,32,16,9,256,512,20,789,48,268,0,1,262,16,561,21,0,260,33,17,3,269,17,789,17,49,561,272,32,257,33,0,513]

theorem envBound52153 : H12AffineFastState.Bounded env52153 := by
  intro p hp
  have h : env52153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52152_52153 : H12AffineEnvironment.transform 9 20 env52152 = env52153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env52152 == env52153) = true)

def env52154 : List Nat := [2,4,8,16,0,16,9,256,512,20,789,16,268,0,1,262,16,529,21,0,260,1,17,3,269,17,789,17,17,529,272,0,257,1,0,513]

theorem envBound52154 : H12AffineFastState.Bounded env52154 := by
  intro p hp
  have h : env52154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52153_52154 : H12AffineEnvironment.transform 4 0 env52153 = env52154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52153 == env52154) = true)

theorem identity52154 : scanCanonicalize (H12AffineFastState.compose env52154 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound52154 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52155 : List Nat := [2,4,8,16,0,16,9,256,276,20,1,16,268,0,1,262,16,261,21,0,260,1,17,3,269,17,1,17,17,261,272,0,257,1,0,277]

theorem envBound52155 : H12AffineFastState.Bounded env52155 := by
  intro p hp
  have h : env52155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52154_52155 : H12AffineEnvironment.transform 8 276 env52154 = env52155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env52154 == env52155) = true)

def leafEnv52155 : List Nat := [2,4,8,16,0,16,9,256,276,20,1,16,268,0,1,262,16,261,21,0,260,1,17,3,273,269,1,17,1,17,17,261,272,0,257,1,5,263,0,277,1,260,0]

def active52155 : List Nat := [0,1,2,3,7]

def tree52155 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52155 : H12WitnessSearch.Good tree52155 := H12GlobalWitnessIndex.good

theorem leafIdentity52155 : H12AffineFastState.composeSystem env52155 rootObs = leafEnv52155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52155 rootObs == leafEnv52155) = true)

theorem terminalChecked52155 : H12PackedTerminal.terminalCheckFast leafEnv52155 active52155 tree52155 = true := by decide +kernel

def env52156 : List Nat := [2,4,8,16,1,16,9,256,512,20,789,17,268,0,1,262,16,528,21,0,260,0,17,3,269,17,789,17,16,528,272,1,257,0,0,513]

theorem envBound52156 : H12AffineFastState.Bounded env52156 := by
  intro p hp
  have h : env52156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52153_52156 : H12AffineEnvironment.transform 4 1 env52153 = env52156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52153 == env52156) = true)

theorem identity52156 : scanCanonicalize (H12AffineFastState.compose env52156 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52156 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52157 : List Nat := [2,4,8,10,1,10,9,256,512,14,783,11,268,0,1,262,10,522,15,0,260,0,11,3,269,11,783,11,10,522,266,1,257,0,0,513]

theorem envBound52157 : H12AffineFastState.Bounded env52157 := by
  intro p hp
  have h : env52157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52156_52157 : H12AffineEnvironment.transform 3 10 env52156 = env52157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52156 == env52157) = true)

def leafEnv52157 : List Nat := [2,4,8,10,1,10,9,256,512,14,783,11,268,0,1,262,10,522,15,0,260,0,11,3,267,269,1,11,783,11,10,522,266,1,257,0,5,263,0,513,1,260,0]

def active52157 : List Nat := [0,1,2,7,8]

def tree52157 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52157 : H12WitnessSearch.Good tree52157 := H12GlobalWitnessIndex.good

theorem leafIdentity52157 : H12AffineFastState.composeSystem env52157 rootObs = leafEnv52157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52157 rootObs == leafEnv52157) = true)

theorem terminalChecked52157 : H12PackedTerminal.terminalCheckFast leafEnv52157 active52157 tree52157 = true := by decide +kernel

def env52158 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,8388608,8429854,8193,16,4262182,10560795,10507521,8431672,75023,14795783,257,2188602,2196502,513]

theorem envBound52158 : H12AffineFastState.Bounded env52158 := by
  intro p hp
  have h : env52158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52123_52158 : H12AffineEnvironment.transform 5 17 env52123 = env52158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52123 == env52158) = true)

theorem identity52158 : scanCanonicalize (H12AffineFastState.compose env52158 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4194353) := by decide +kernel

theorem selectedBound52158 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env52159 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,4194353,4235567,8193,16,4262182,6366506,6313264,4237321,75023,2212918,257,2188602,2196502,513]

theorem envBound52159 : H12AffineFastState.Bounded env52159 := by
  intro p hp
  have h : env52159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52158_52159 : H12AffineEnvironment.transform 22 4194353 env52158 = env52159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194353 env52158 == env52159) = true)

theorem identity52159 : scanCanonicalize (H12AffineFastState.compose env52159 (packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 2122812) := by decide +kernel

theorem selectedBound52159 : packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env52160 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,2122812,2122765,2147603,8193,16,2190618,82198,12556,2149429,75023,2212918,257,2188602,2196502,513]

theorem envBound52160 : H12AffineFastState.Bounded env52160 := by
  intro p hp
  have h : env52160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52159_52160 : H12AffineEnvironment.transform 21 2122812 env52159 = env52160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122812 env52159 == env52160) = true)

theorem identity52160 : scanCanonicalize (H12AffineFastState.compose env52160 (packedSelected [0,1,4,7,8,9,10,11,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52160 : packedSelected [0,1,4,7,8,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env52161 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,65536,16400,2340,1025,32769,2097152,2114864,2114817,2147603,269,16,2182166,82198,4096,2149429,66563,2212918,257,2180150,2196502,513]

theorem envBound52161 : H12AffineFastState.Bounded env52161 := by
  intro p hp
  have h : env52161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52160_52161 : H12AffineEnvironment.transform 12 268 env52160 = env52161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52160 == env52161) = true)

theorem identity52161 : scanCanonicalize (H12AffineFastState.compose env52161 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52161 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env52162 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,65536,16400,2340,1025,0,2097152,2114864,2114817,2114834,269,16,2182166,82198,4096,2116660,66563,2180151,257,2180150,2163735,513]

theorem envBound52162 : H12AffineFastState.Bounded env52162 := by
  intro p hp
  have h : env52162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52161_52162 : H12AffineEnvironment.transform 14 1 env52161 = env52162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52161 == env52162) = true)

theorem identity52162 : scanCanonicalize (H12AffineFastState.compose env52162 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound52162 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52163 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,262,16400,2340,1025,0,2097152,2114864,2114817,2114834,269,16,2116880,16400,4096,2116660,1285,2114865,257,2114864,2098449,513]

theorem envBound52163 : H12AffineFastState.Bounded env52163 := by
  intro p hp
  have h : env52163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52162_52163 : H12AffineEnvironment.transform 15 262 env52162 = env52163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env52162 == env52163) = true)

theorem identity52163 : scanCanonicalize (H12AffineFastState.compose env52163 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound52163 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env52164 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1573,4096,268,16384,1,262,16400,1793,1025,0,2097152,2114864,2114817,2114834,269,16,2114357,16400,4096,2114065,1285,2114865,257,2114864,2098449,513]

theorem envBound52164 : H12AffineFastState.Bounded env52164 := by
  intro p hp
  have h : env52164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52163_52164 : H12AffineEnvironment.transform 10 1573 env52163 = env52164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env52163 == env52164) = true)

theorem identity52164 : scanCanonicalize (H12AffineFastState.compose env52164 (packedSelected [4,7] rootPS)) = affineNative (2^(20+1) ^^^ 21008) := by decide +kernel

theorem selectedBound52164 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env52165 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1573,4096,268,16384,1,262,16400,1793,1025,0,21008,5920,5905,5890,269,16,4389,16400,4096,4097,1285,5921,257,5920,22273,513]

theorem envBound52165 : H12AffineFastState.Bounded env52165 := by
  intro p hp
  have h : env52165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52164_52165 : H12AffineEnvironment.transform 20 21008 env52164 = env52165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 21008 env52164 == env52165) = true)

theorem identity52165 : scanCanonicalize (H12AffineFastState.compose env52165 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound52165 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env52166 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1573,4096,268,5156,1,262,5172,1793,1025,0,1588,5920,5905,5890,269,16,4389,5172,4096,4097,1285,5921,257,5920,805,513]

theorem envBound52166 : H12AffineFastState.Bounded env52166 := by
  intro p hp
  have h : env52166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52165_52166 : H12AffineEnvironment.transform 13 5156 env52165 = env52166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env52165 == env52166) = true)

theorem identity52166 : scanCanonicalize (H12AffineFastState.compose env52166 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound52166 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52167 : List Nat := [2,4,8,16,32,17,9,256,512,272,821,4096,268,4404,1,262,4388,529,273,0,804,4656,4609,4626,269,16,4389,4388,4096,4097,21,4657,257,4656,805,513]

end H12CloudChart1