import H12CloudChart1Data103

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env26346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,32768,33166,5393,262144,1025,32769,4161,305361,8644,8582,8328,64,43357,13509,12676,303492,1500,272392,257,113,46212,41861]

theorem envBound26346 : H12AffineFastState.Bounded env26346 := by
  intro p hp
  have h : env26346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26345_26346 : H12AffineEnvironment.transform 13 5456 env26345 = env26346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env26345 == env26346) = true)

theorem identity26346 : scanCanonicalize (H12AffineFastState.compose env26346 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound26346 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env26347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,32768,33166,5393,10280,1025,32769,4161,33017,8644,8582,8328,64,43357,13509,12676,35244,1500,32,257,113,46212,41861]

theorem envBound26347 : H12AffineFastState.Bounded env26347 := by
  intro p hp
  have h : env26347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26346_26347 : H12AffineEnvironment.transform 17 10280 env26346 = env26347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env26346 == env26347) = true)

theorem identity26347 : scanCanonicalize (H12AffineFastState.compose env26347 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26347 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env26348 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,33166,5393,10280,1025,32769,4112,32936,8597,8582,8328,17,43276,13460,12676,35244,1421,32,257,32,46212,41861]

theorem envBound26348 : H12AffineFastState.Bounded env26348 := by
  intro p hp
  have h : env26348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26347_26348 : H12AffineEnvironment.transform 5 17 env26347 = env26348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26347 == env26348) = true)

theorem identity26348 : scanCanonicalize (H12AffineFastState.compose env26348 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound26348 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26349 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,0,398,5393,10280,1025,1,4112,168,8597,8582,8328,17,10508,13460,12676,2476,1421,32,257,32,13444,9093]

theorem envBound26349 : H12AffineFastState.Bounded env26349 := by
  intro p hp
  have h : env26349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26348_26349 : H12AffineEnvironment.transform 14 0 env26348 = env26349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env26348 == env26349) = true)

theorem identity26349 : scanCanonicalize (H12AffineFastState.compose env26349 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26349 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26350 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,8192,5157,0,170,5173,10280,1025,1,4112,168,8369,8354,8328,17,10280,13460,12448,2184,1193,32,37,32,13444,8865]

theorem envBound26350 : H12AffineFastState.Bounded env26350 := by
  intro p hp
  have h : env26350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26349_26350 : H12AffineEnvironment.transform 7 36 env26349 = env26350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26349 == env26350) = true)

theorem identity26350 : scanCanonicalize (H12AffineFastState.compose env26350 (packedSelected [1,3,4,9,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 130) := by decide +kernel

theorem selectedBound26350 : packedSelected [1,3,4,9,12,14] rootPS < 2^1333 := by decide +kernel

def env26351 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,130,8192,1191,0,170,1207,10280,1025,1,146,168,8369,8354,8328,17,10280,9238,8226,2184,1193,32,37,32,9222,8865]

theorem envBound26351 : H12AffineFastState.Bounded env26351 := by
  intro p hp
  have h : env26351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26350_26351 : H12AffineEnvironment.transform 11 130 env26350 = env26351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 130 env26350 == env26351) = true)

theorem identity26351 : scanCanonicalize (H12AffineFastState.compose env26351 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26351 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env26352 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,10,8192,1071,0,34,1087,10280,1025,1,26,32,8249,8234,8192,17,10280,9238,8226,2048,1057,32,37,32,9222,8745]

theorem envBound26352 : H12AffineFastState.Bounded env26352 := by
  intro p hp
  have h : env26352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26351_26352 : H12AffineEnvironment.transform 6 8 env26351 = env26352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26351 == env26352) = true)

theorem identity26352 : scanCanonicalize (H12AffineFastState.compose env26352 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound26352 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env26353 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1087,10,8192,1071,0,34,1087,9239,1025,1,26,32,8249,8234,8192,17,9239,9238,8226,1087,1057,32,37,32,9222,8745]

theorem envBound26353 : H12AffineFastState.Bounded env26353 := by
  intro p hp
  have h : env26353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26352_26353 : H12AffineEnvironment.transform 10 1087 env26352 = env26353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env26352 == env26353) = true)

theorem identity26353 : scanCanonicalize (H12AffineFastState.compose env26353 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1047) := by decide +kernel

theorem selectedBound26353 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26354 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1087,10,1047,1071,0,34,1087,0,1025,1,26,32,1070,1085,1047,17,0,1,1077,1087,1057,32,37,32,17,1598]

theorem envBound26354 : H12AffineFastState.Bounded env26354 := by
  intro p hp
  have h : env26354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26353_26354 : H12AffineEnvironment.transform 12 1047 env26353 = env26354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1047 env26353 == env26354) = true)

theorem identity26354 : scanCanonicalize (H12AffineFastState.compose env26354 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound26354 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env26355 : List Nat := [2,4,8,16,11,17,8,15,512,1024,1044,10,1047,1028,0,9,1044,0,1025,1,26,11,1029,1046,1047,17,0,1,1054,1044,1034,11,14,11,17,1557]

theorem envBound26355 : H12AffineFastState.Bounded env26355 := by
  intro p hp
  have h : env26355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26354_26355 : H12AffineEnvironment.transform 4 11 env26354 = env26355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env26354 == env26355) = true)

theorem identity26355 : scanCanonicalize (H12AffineFastState.compose env26355 (packedSelected [1,3,11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26355 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env26356 : List Nat := [2,4,8,1,11,0,8,15,512,1024,1029,10,1030,1028,0,9,1029,0,1025,1,11,11,1029,1031,1030,0,0,1,1039,1029,1034,11,14,11,0,1540]

theorem envBound26356 : H12AffineFastState.Bounded env26356 := by
  intro p hp
  have h : env26356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26355_26356 : H12AffineEnvironment.transform 3 1 env26355 = env26356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26355 == env26356) = true)

theorem identity26356 : scanCanonicalize (H12AffineFastState.compose env26356 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound26356 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26357 : List Nat := [2,4,7,1,4,0,7,0,512,1024,1029,5,1030,1028,0,6,1029,0,1025,1,4,4,1029,1031,1030,0,0,1,1024,1029,1029,4,1,4,0,1540]

theorem envBound26357 : H12AffineFastState.Bounded env26357 := by
  intro p hp
  have h : env26357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26356_26357 : H12AffineEnvironment.transform 2 7 env26356 = env26357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env26356 == env26357) = true)

def env26358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,253963,16777216,8328,64,16959643,18973836,2340186,335882,16933915,19369297,257,19014823,19055874,16991180]

theorem envBound26358 : H12AffineFastState.Bounded env26358 := by
  intro p hp
  have h : env26358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26294_26358 : H12AffineEnvironment.transform 21 452753 env26294 = env26358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452753 env26294 == env26358) = true)

def env26359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,253963,242968,8328,64,97667,2240916,2340186,335882,119043,2373705,257,2199999,2191386,63188]

theorem envBound26359 : H12AffineFastState.Bounded env26359 := by
  intro p hp
  have h : env26359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26358_26359 : H12AffineEnvironment.transform 23 242968 env26358 = env26359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242968 env26358 == env26359) = true)

def env26360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,253963,242968,8328,64,97667,139732,238874,335882,119043,272393,257,98815,90202,63188]

theorem envBound26360 : H12AffineFastState.Bounded env26360 := by
  intro p hp
  have h : env26360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26359_26360 : H12AffineEnvironment.transform 20 4160 env26359 = env26360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env26359 == env26360) = true)

theorem identity26360 : scanCanonicalize (H12AffineFastState.compose env26360 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound26360 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272513,73755,95496,8328,64,97667,57796,91402,335882,119043,272393,257,98815,90202,63188]

theorem envBound26361 : H12AffineFastState.Bounded env26361 := by
  intro p hp
  have h : env26361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26360_26361 : H12AffineEnvironment.transform 16 49168 env26360 = env26361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env26360 == env26361) = true)

def env26362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10400,1025,32769,4160,33,73755,95496,8328,64,97667,57796,91402,67754,119043,169,257,98815,90202,63188]

theorem envBound26362 : H12AffineFastState.Bounded env26362 := by
  intro p hp
  have h : env26362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26361_26362 : H12AffineEnvironment.transform 17 10400 env26361 = env26362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env26361 == env26362) = true)

theorem identity26362 : scanCanonicalize (H12AffineFastState.compose env26362 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound26362 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env26363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,65536,46156,10400,1025,32769,4160,33,73755,65876,8328,64,68063,38296,69974,67754,107871,169,257,98815,70662,33416]

theorem envBound26363 : H12AffineFastState.Bounded env26363 := by
  intro p hp
  have h : env26363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26362_26363 : H12AffineEnvironment.transform 13 13404 env26362 = env26363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env26362 == env26363) = true)

theorem identity26363 : scanCanonicalize (H12AffineFastState.compose env26363 (packedSelected [0,3,5,8,9,10,14,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound26363 : packedSelected [0,3,5,8,9,10,14,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env26364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,65536,13509,10400,1025,136,4160,33,73755,65876,8328,64,68063,5393,69974,67754,75222,169,257,65910,70662,513]

theorem envBound26364 : H12AffineFastState.Bounded env26364 := by
  intro p hp
  have h : env26364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26363_26364 : H12AffineEnvironment.transform 14 137 env26363 = env26364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env26363 == env26364) = true)

theorem identity26364 : scanCanonicalize (H12AffineFastState.compose env26364 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound26364 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env26365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,137,65536,5393,2420,1025,136,4160,33,65999,65876,348,64,68063,5393,69974,67754,66562,169,257,65910,70662,513]

theorem envBound26365 : H12AffineFastState.Bounded env26365 := by
  intro p hp
  have h : env26365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26364_26365 : H12AffineEnvironment.transform 12 468 env26364 = env26365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env26364 == env26365) = true)

theorem identity26365 : scanCanonicalize (H12AffineFastState.compose env26365 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound26365 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env26366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,137,478,5393,2420,1025,136,4160,33,17,138,348,64,2049,5393,4232,2420,1500,169,257,168,5592,513]

theorem envBound26366 : H12AffineFastState.Bounded env26366 := by
  intro p hp
  have h : env26366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26365_26366 : H12AffineEnvironment.transform 15 478 env26365 = env26366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env26365 == env26366) = true)

theorem identity26366 : scanCanonicalize (H12AffineFastState.compose env26366 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26366 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26367 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,342,5393,2420,1025,0,4160,33,17,2,348,64,2049,5393,4096,2420,1364,33,257,32,5456,513]

theorem envBound26367 : H12AffineFastState.Bounded env26367 := by
  intro p hp
  have h : env26367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26366_26367 : H12AffineEnvironment.transform 6 8 env26366 = env26367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26366 == env26367) = true)

theorem identity26367 : scanCanonicalize (H12AffineFastState.compose env26367 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound26367 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26368 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1061,348,293,1,342,308,2420,1025,0,1125,33,17,2,348,64,2049,308,1061,2420,1364,33,257,32,373,513]

theorem envBound26368 : H12AffineFastState.Bounded env26368 := by
  intro p hp
  have h : env26368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26367_26368 : H12AffineEnvironment.transform 11 1061 env26367 = env26368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env26367 == env26368) = true)

theorem identity26368 : scanCanonicalize (H12AffineFastState.compose env26368 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound26368 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26369 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,1061,348,293,1,342,308,1125,1025,0,1125,33,17,2,348,64,1296,308,1061,1125,1364,33,257,32,373,513]

theorem envBound26369 : H12AffineFastState.Bounded env26369 := by
  intro p hp
  have h : env26369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26368_26369 : H12AffineEnvironment.transform 10 1297 env26368 = env26369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env26368 == env26369) = true)

theorem identity26369 : scanCanonicalize (H12AffineFastState.compose env26369 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound26369 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env26370 : List Nat := [2,4,8,16,32,32,8,256,512,1024,1297,1061,316,293,1,310,308,1029,1025,0,1029,33,17,2,316,32,1296,308,1061,1029,1332,33,257,32,277,513]

theorem envBound26370 : H12AffineFastState.Bounded env26370 := by
  intro p hp
  have h : env26370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26369_26370 : H12AffineEnvironment.transform 5 32 env26369 = env26370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env26369 == env26370) = true)

theorem identity26370 : scanCanonicalize (H12AffineFastState.compose env26370 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound26370 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env26371 : List Nat := [2,4,8,16,32,32,8,256,276,1024,1297,1061,316,293,1,310,308,1029,1025,0,1029,33,17,2,316,32,1296,308,1061,1029,1332,33,257,32,277,277]

theorem envBound26371 : H12AffineFastState.Bounded env26371 := by
  intro p hp
  have h : env26371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26370_26371 : H12AffineEnvironment.transform 8 276 env26370 = env26371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env26370 == env26371) = true)

theorem identity26371 : scanCanonicalize (H12AffineFastState.compose env26371 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26371 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env26372 : List Nat := [2,4,8,16,0,0,8,256,276,1024,1297,1029,284,261,1,278,276,1029,1025,0,1029,1,17,2,284,0,1296,276,1029,1029,1300,1,257,0,277,277]

theorem envBound26372 : H12AffineFastState.Bounded env26372 := by
  intro p hp
  have h : env26372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26371_26372 : H12AffineEnvironment.transform 4 0 env26371 = env26372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26371 == env26372) = true)

theorem identity26372 : scanCanonicalize (H12AffineFastState.compose env26372 (packedSelected [0,4,12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26372 : packedSelected [0,4,12] rootPS < 2^1333 := by decide +kernel

def env26373 : List Nat := [2,4,8,1,0,0,8,256,261,1024,1280,1029,269,261,1,263,261,1029,1025,0,1029,1,0,2,269,0,1281,261,1029,1029,1285,1,257,0,260,260]

theorem envBound26373 : H12AffineFastState.Bounded env26373 := by
  intro p hp
  have h : env26373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26372_26373 : H12AffineEnvironment.transform 3 1 env26372 = env26373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26372 == env26373) = true)

theorem identity26373 : scanCanonicalize (H12AffineFastState.compose env26373 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound26373 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26374 : List Nat := [2,4,8,1,0,0,8,256,261,256,0,261,269,261,1,263,261,261,257,0,261,1,0,2,269,0,1,261,261,261,5,1,257,0,260,260]

theorem envBound26374 : H12AffineFastState.Bounded env26374 := by
  intro p hp
  have h : env26374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26373_26374 : H12AffineEnvironment.transform 9 256 env26373 = env26374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env26373 == env26374) = true)

theorem identity26374 : scanCanonicalize (H12AffineFastState.compose env26374 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound26374 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26375 : List Nat := [2,4,8,1,0,0,8,5,0,5,0,0,8,0,1,2,0,0,4,0,0,1,0,2,8,0,1,0,0,0,5,1,4,0,1,1]

theorem envBound26375 : H12AffineFastState.Bounded env26375 := by
  intro p hp
  have h : env26375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26374_26375 : H12AffineEnvironment.transform 7 5 env26374 = env26375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env26374 == env26375) = true)

def env26376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10401,1025,32769,4160,32,73755,95496,8328,64,97667,57796,91402,67755,119043,168,257,98815,90202,63188]

theorem envBound26376 : H12AffineFastState.Bounded env26376 := by
  intro p hp
  have h : env26376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26361_26376 : H12AffineEnvironment.transform 17 10401 env26361 = env26376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env26361 == env26376) = true)

theorem identity26376 : scanCanonicalize (H12AffineFastState.compose env26376 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 22010) := by decide +kernel

theorem selectedBound26376 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env26377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,22010,49168,10401,1025,32769,4160,32,30177,8434,8328,64,10361,57796,12528,23889,34041,168,257,54277,13728,63188]

theorem envBound26377 : H12AffineFastState.Bounded env26377 := by
  intro p hp
  have h : env26377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26376_26377 : H12AffineEnvironment.transform 15 22010 env26376 = env26377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 22010 env26376 == env26377) = true)

theorem identity26377 : scanCanonicalize (H12AffineFastState.compose env26377 (packedSelected [1,3,4,8,9,10,14,15,18,20,23,24,41] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound26377 : packedSelected [1,3,4,8,9,10,14,15,18,20,23,24,41] rootPS < 2^1333 := by decide +kernel

def env26378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,115,38297,10401,1025,32769,4160,32,8296,8434,8328,64,10361,46157,12528,2264,34041,168,257,33164,13728,41821]

theorem envBound26378 : H12AffineFastState.Bounded env26378 := by
  intro p hp
  have h : env26378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26377_26378 : H12AffineEnvironment.transform 13 5513 env26377 = env26378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env26377 == env26378) = true)

theorem identity26378 : scanCanonicalize (H12AffineFastState.compose env26378 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26378 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env26379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5513,32768,115,38297,2557,1025,32769,4160,32,308,430,468,64,2341,38161,4524,2264,34041,168,257,33164,5372,33281]

theorem envBound26379 : H12AffineFastState.Bounded env26379 := by
  intro p hp
  have h : env26379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26378_26379 : H12AffineEnvironment.transform 12 348 env26378 = env26379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26378 == env26379) = true)

theorem identity26379 : scanCanonicalize (H12AffineFastState.compose env26379 (packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 509) := by decide +kernel

theorem selectedBound26379 : packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env26380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5513,509,115,5220,2557,1025,508,4160,32,308,430,468,64,2341,5356,4524,2264,1284,168,257,113,5372,1020]

theorem envBound26380 : H12AffineFastState.Bounded env26380 := by
  intro p hp
  have h : env26380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26379_26380 : H12AffineEnvironment.transform 14 509 env26379 = env26380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 509 env26379 == env26380) = true)

theorem identity26380 : scanCanonicalize (H12AffineFastState.compose env26380 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26380 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env26381 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,120,5293,217,115,5220,2265,1025,216,4160,32,16,138,240,64,2049,5356,4232,2264,1056,168,37,113,5372,728]

theorem envBound26381 : H12AffineFastState.Bounded env26381 := by
  intro p hp
  have h : env26381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26380_26381 : H12AffineEnvironment.transform 7 36 env26380 = env26381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26380 == env26381) = true)

theorem identity26381 : scanCanonicalize (H12AffineFastState.compose env26381 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26381 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26382 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,5156,80,115,5220,2128,1025,81,4160,32,16,3,121,64,2049,5221,4097,2129,1056,33,37,113,5237,593]

theorem envBound26382 : H12AffineFastState.Bounded env26382 := by
  intro p hp
  have h : env26382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26381_26382 : H12AffineEnvironment.transform 6 9 env26381 = env26382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26381 == env26382) = true)

theorem identity26382 : scanCanonicalize (H12AffineFastState.compose env26382 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26382 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env26383 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,1,34,5173,2049,1025,0,4113,32,16,3,40,17,2049,5172,4097,2048,1056,33,37,32,5156,512]

theorem envBound26383 : H12AffineFastState.Bounded env26383 := by
  intro p hp
  have h : env26383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26382_26383 : H12AffineEnvironment.transform 5 17 env26382 = env26383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26382 == env26383) = true)

theorem identity26383 : scanCanonicalize (H12AffineFastState.compose env26383 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26383 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26384 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5125,1,3,5140,2049,1025,0,4113,1,16,3,9,17,2049,5141,4097,2048,1025,0,4,1,5125,512]

theorem envBound26384 : H12AffineFastState.Bounded env26384 := by
  intro p hp
  have h : env26384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26383_26384 : H12AffineEnvironment.transform 4 1 env26383 = env26384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26383 == env26384) = true)

def env26385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,253963,242968,8328,64,97667,139733,238875,335882,119043,272392,257,98814,90203,63188]

theorem envBound26385 : H12AffineFastState.Bounded env26385 := by
  intro p hp
  have h : env26385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26359_26385 : H12AffineEnvironment.transform 20 4161 env26359 = env26385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env26359 == env26385) = true)

def env26386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4161,180273,253963,242968,8328,64,97667,139733,238875,67754,119043,168,257,98814,90203,63188]

theorem envBound26386 : H12AffineFastState.Bounded env26386 := by
  intro p hp
  have h : env26386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26385_26386 : H12AffineEnvironment.transform 17 10400 env26385 = env26386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env26385 == env26386) = true)

def env26387 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,180273,253963,242968,8192,64,97547,139613,238875,67618,119043,32,257,98678,90203,63068]

theorem envBound26387 : H12AffineFastState.Bounded env26387 := by
  intro p hp
  have h : env26387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26386_26387 : H12AffineEnvironment.transform 6 8 env26386 = env26387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26386 == env26387) = true)

theorem identity26387 : scanCanonicalize (H12AffineFastState.compose env26387 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound26387 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26388 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,4161,144492,201814,213317,8192,64,97547,139613,217414,67618,75102,32,257,95531,90203,513]

theorem envBound26388 : H12AffineFastState.Bounded env26388 := by
  intro p hp
  have h : env26388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26387_26388 : H12AffineEnvironment.transform 14 29789 env26387 = env26388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env26387 == env26388) = true)

theorem identity26388 : scanCanonicalize (H12AffineFastState.compose env26388 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound26388 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env26389 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,131072,10280,1025,29788,4161,144492,155996,144463,8192,64,2049,139613,140364,32040,20564,32,257,33,5457,513]

theorem envBound26389 : H12AffineFastState.Bounded env26389 := by
  intro p hp
  have h : env26389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26388_26389 : H12AffineEnvironment.transform 15 29962 env26388 = env26389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env26388 == env26389) = true)

theorem identity26389 : scanCanonicalize (H12AffineFastState.compose env26389 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound26389 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env26390 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,21591,131072,2421,1025,21761,4161,136497,147457,136466,349,64,2049,131072,132369,23669,20564,32,257,33,5457,513]

theorem envBound26390 : H12AffineFastState.Bounded env26390 := by
  intro p hp
  have h : env26390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26389_26390 : H12AffineEnvironment.transform 12 349 env26389 = env26390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env26389 == env26390) = true)

theorem identity26390 : scanCanonicalize (H12AffineFastState.compose env26390 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound26390 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env26391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,343,131072,2421,1025,1,4161,136497,136449,136466,349,64,2049,131072,132369,2421,1364,32,257,33,5457,513]

theorem envBound26391 : H12AffineFastState.Bounded env26391 := by
  intro p hp
  have h : env26391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26390_26391 : H12AffineEnvironment.transform 13 5376 env26390 = env26391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env26390 == env26391) = true)

theorem identity26391 : scanCanonicalize (H12AffineFastState.compose env26391 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound26391 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,343,5392,2421,1025,1,4161,33,17,2,349,64,2049,5392,4097,2421,1364,32,257,33,5457,513]

theorem envBound26392 : H12AffineFastState.Bounded env26392 := by
  intro p hp
  have h : env26392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26391_26392 : H12AffineEnvironment.transform 16 5392 env26391 = env26392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env26391 == env26392) = true)

theorem identity26392 : scanCanonicalize (H12AffineFastState.compose env26392 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3418) := by decide +kernel

theorem selectedBound26392 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3418,349,2138,0,343,2122,2421,1025,1,3355,33,17,2,349,64,2049,2122,3419,2421,1364,32,257,33,2059,513]

theorem envBound26393 : H12AffineFastState.Bounded env26393 := by
  intro p hp
  have h : env26393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26392_26393 : H12AffineEnvironment.transform 11 3418 env26392 = env26393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3418 env26392 == env26393) = true)

theorem identity26393 : scanCanonicalize (H12AffineFastState.compose env26393 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound26393 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26394 : List Nat := [2,4,8,16,32,10,8,256,512,1024,2048,3344,279,2064,0,285,2048,2367,1025,1,3355,33,17,2,279,10,2049,2048,3345,2367,1310,32,257,33,2059,513]

theorem envBound26394 : H12AffineFastState.Bounded env26394 := by
  intro p hp
  have h : env26394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26393_26394 : H12AffineEnvironment.transform 5 10 env26393 = env26394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env26393 == env26394) = true)

theorem identity26394 : scanCanonicalize (H12AffineFastState.compose env26394 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26394 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env26395 : List Nat := [2,4,8,16,0,10,8,256,512,1024,2048,3344,279,2064,0,285,2048,2335,1025,1,3355,1,17,2,279,10,2049,2048,3345,2335,1310,0,257,1,2059,513]

theorem envBound26395 : H12AffineFastState.Bounded env26395 := by
  intro p hp
  have h : env26395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26394_26395 : H12AffineEnvironment.transform 4 0 env26394 = env26395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26394 == env26395) = true)

theorem identity26395 : scanCanonicalize (H12AffineFastState.compose env26395 (packedSelected [5,8,15] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26395 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env26396 : List Nat := [2,4,8,10,0,10,8,256,512,1024,2048,3338,269,2058,0,263,2048,2309,1025,1,3329,1,11,2,269,10,2049,2048,3339,2309,1284,0,257,1,2059,513]

theorem envBound26396 : H12AffineFastState.Bounded env26396 := by
  intro p hp
  have h : env26396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26395_26396 : H12AffineEnvironment.transform 3 10 env26395 = env26396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26395 == env26396) = true)

theorem identity26396 : scanCanonicalize (H12AffineFastState.compose env26396 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound26396 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26397 : List Nat := [2,4,8,10,0,10,8,15,512,1024,2048,3077,2,2058,0,8,2048,2058,1025,1,3086,1,11,2,2,10,2049,2048,3076,2058,1035,0,14,1,2059,513]

theorem envBound26397 : H12AffineFastState.Bounded env26397 := by
  intro p hp
  have h : env26397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26396_26397 : H12AffineEnvironment.transform 7 15 env26396 = env26397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env26396 == env26397) = true)

theorem identity26397 : scanCanonicalize (H12AffineFastState.compose env26397 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound26397 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26398 : List Nat := [2,4,8,10,0,10,8,15,10,1024,2048,3077,2,2058,0,8,2048,2058,1025,1,3086,1,11,2,2,10,2049,2048,3076,2058,1035,0,14,1,2059,11]

theorem envBound26398 : H12AffineFastState.Bounded env26398 := by
  intro p hp
  have h : env26398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26397_26398 : H12AffineEnvironment.transform 8 10 env26397 = env26398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env26397 == env26398) = true)

theorem identity26398 : scanCanonicalize (H12AffineFastState.compose env26398 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 12) := by decide +kernel

theorem selectedBound26398 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26399 : List Nat := [2,4,8,10,0,10,8,15,10,12,2048,2057,2,2058,0,8,2048,2058,13,1,2050,1,11,2,2,10,2049,2048,2056,2058,7,0,14,1,2059,11]

theorem envBound26399 : H12AffineFastState.Bounded env26399 := by
  intro p hp
  have h : env26399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26398_26399 : H12AffineEnvironment.transform 9 12 env26398 = env26399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 12 env26398 == env26399) = true)

theorem identity26399 : scanCanonicalize (H12AffineFastState.compose env26399 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 3) := by decide +kernel

theorem selectedBound26399 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env26400 : List Nat := [2,4,8,10,0,10,8,15,10,12,3,10,2,9,0,8,3,9,13,1,1,1,11,2,2,10,2,3,11,9,7,0,14,1,8,11]

theorem envBound26400 : H12AffineFastState.Bounded env26400 := by
  intro p hp
  have h : env26400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26399_26400 : H12AffineEnvironment.transform 10 3 env26399 = env26400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 3 env26399 == env26400) = true)

theorem identity26400 : scanCanonicalize (H12AffineFastState.compose env26400 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound26400 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26401 : List Nat := [2,4,7,5,0,5,7,0,5,3,3,5,2,6,0,7,3,6,2,1,1,1,4,2,2,5,2,3,4,6,7,0,1,1,7,4]

theorem envBound26401 : H12AffineFastState.Bounded env26401 := by
  intro p hp
  have h : env26401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26400_26401 : H12AffineEnvironment.transform 2 7 env26400 = env26401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env26400 == env26401) = true)

theorem identity26401 : scanCanonicalize (H12AffineFastState.compose env26401 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26401 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env26402 : List Nat := [2,3,0,2,0,2,0,0,2,3,3,2,2,1,0,0,3,1,2,1,1,1,3,2,2,2,2,3,3,1,0,0,1,1,0,3]

theorem envBound26402 : H12AffineFastState.Bounded env26402 := by
  intro p hp
  have h : env26402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26401_26402 : H12AffineEnvironment.transform 1 3 env26401 = env26402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26401 == env26402) = true)

def env26403 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,180273,253963,242968,8193,64,97546,139612,238875,67619,119043,33,257,98679,90203,63069]

theorem envBound26403 : H12AffineFastState.Bounded env26403 := by
  intro p hp
  have h : env26403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26386_26403 : H12AffineEnvironment.transform 6 9 env26386 = env26403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26386 == env26403) = true)

theorem identity26403 : scanCanonicalize (H12AffineFastState.compose env26403 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound26403 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26404 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1025,32769,4161,169265,242955,242968,8193,64,75786,139612,238875,67619,99331,33,257,98679,79195,41821]

theorem envBound26404 : H12AffineFastState.Bounded env26404 := by
  intro p hp
  have h : env26404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26403_26404 : H12AffineEnvironment.transform 13 5376 env26403 = env26404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env26403 == env26404) = true)

theorem identity26404 : scanCanonicalize (H12AffineFastState.compose env26404 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 12556) := by decide +kernel

theorem selectedBound26404 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env26405 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,12556,10281,1025,32769,4161,42045,99335,99348,8193,64,75786,4176,103447,67619,99331,33,257,98679,79195,41821]

theorem envBound26405 : H12AffineFastState.Bounded env26405 := by
  intro p hp
  have h : env26405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26404_26405 : H12AffineEnvironment.transform 16 12556 env26404 = env26405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12556 env26404 == env26405) = true)

theorem identity26405 : scanCanonicalize (H12AffineFastState.compose env26405 (packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26405 : packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env26406 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,12556,10281,1025,8541,4161,1377,75099,75080,8193,64,75786,4176,79179,67619,75103,33,257,73771,79195,513]

theorem envBound26406 : H12AffineFastState.Bounded env26406 := by
  intro p hp
  have h : env26406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26405_26406 : H12AffineEnvironment.transform 14 8540 env26405 = env26406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26405 == env26406) = true)

theorem identity26406 : scanCanonicalize (H12AffineFastState.compose env26406 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 6248) := by decide +kernel

theorem selectedBound26406 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env26407 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6248,5376,6452,65536,2404,4161,1025,6453,4161,1377,73011,72992,6249,64,69730,4176,68899,67619,73015,33,257,71747,68915,513]

theorem envBound26407 : H12AffineFastState.Bounded env26407 := by
  intro p hp
  have h : env26407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26406_26407 : H12AffineEnvironment.transform 12 6248 env26406 = env26407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6248 env26406 == env26407) = true)

theorem identity26407 : scanCanonicalize (H12AffineFastState.compose env26407 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound26407 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env26408 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,1052,2420,1344,65536,2404,3125,1025,1345,3125,1377,65863,65876,1053,64,68630,3108,68899,67619,65859,33,257,66615,68915,513]

theorem envBound26408 : H12AffineFastState.Bounded env26408 := by
  intro p hp
  have h : env26408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26407_26408 : H12AffineEnvironment.transform 11 3188 env26407 = env26408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env26407 == env26408) = true)

theorem identity26408 : scanCanonicalize (H12AffineFastState.compose env26408 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound26408 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env26409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,1052,2420,1344,115,2404,3125,1025,1345,3125,1377,308,295,1053,64,3173,3108,3408,2128,304,33,257,1092,3392,513]

theorem envBound26409 : H12AffineFastState.Bounded env26409 := by
  intro p hp
  have h : env26409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26408_26409 : H12AffineEnvironment.transform 15 115 env26408 = env26409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env26408 == env26409) = true)

theorem identity26409 : scanCanonicalize (H12AffineFastState.compose env26409 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26409 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env26410 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,2112,40,2420,372,115,2404,2049,53,373,2049,341,308,295,41,64,2129,2064,2404,2128,304,33,257,112,2420,513]

theorem envBound26410 : H12AffineFastState.Bounded env26410 := by
  intro p hp
  have h : env26410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26409_26410 : H12AffineEnvironment.transform 9 52 env26409 = env26410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26409 == env26410) = true)

theorem identity26410 : scanCanonicalize (H12AffineFastState.compose env26410 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26410 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env26411 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,2064,40,2340,292,35,2356,2049,53,293,2049,261,308,295,41,16,2049,2064,2356,2048,304,33,257,32,2340,513]

theorem envBound26411 : H12AffineFastState.Bounded env26411 := by
  intro p hp
  have h : env26411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26410_26411 : H12AffineEnvironment.transform 5 16 env26410 = env26411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26410 == env26411) = true)

theorem identity26411 : scanCanonicalize (H12AffineFastState.compose env26411 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound26411 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26412 : List Nat := [2,4,8,16,32,16,9,256,309,52,2048,2064,40,2340,292,35,2356,2049,53,293,2049,261,308,295,41,16,2049,2064,2356,2048,304,33,257,32,2340,308]

theorem envBound26412 : H12AffineFastState.Bounded env26412 := by
  intro p hp
  have h : env26412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26411_26412 : H12AffineEnvironment.transform 8 309 env26411 = env26412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env26411 == env26412) = true)

theorem identity26412 : scanCanonicalize (H12AffineFastState.compose env26412 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound26412 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env26413 : List Nat := [2,4,8,16,32,16,9,256,309,52,1,17,40,293,292,35,309,0,53,293,0,261,308,295,41,16,0,17,309,1,304,33,257,32,293,308]

theorem envBound26413 : H12AffineFastState.Bounded env26413 := by
  intro p hp
  have h : env26413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26412_26413 : H12AffineEnvironment.transform 10 1 env26412 = env26413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env26412 == env26413) = true)

theorem identity26413 : scanCanonicalize (H12AffineFastState.compose env26413 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound26413 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env26414 : List Nat := [2,4,3,16,32,16,2,256,309,52,1,17,35,293,292,35,309,0,53,293,0,261,308,295,34,16,0,17,309,1,304,33,257,32,293,308]

theorem envBound26414 : H12AffineFastState.Bounded env26414 := by
  intro p hp
  have h : env26414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26413_26414 : H12AffineEnvironment.transform 2 3 env26413 = env26414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env26413 == env26414) = true)

theorem identity26414 : scanCanonicalize (H12AffineFastState.compose env26414 (packedSelected [1,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26414 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env26415 : List Nat := [2,4,3,16,32,16,2,37,16,52,1,17,35,0,1,35,16,0,53,0,0,32,17,2,34,16,0,17,16,1,21,33,36,32,0,17]

theorem envBound26415 : H12AffineFastState.Bounded env26415 := by
  intro p hp
  have h : env26415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26414_26415 : H12AffineEnvironment.transform 7 37 env26414 = env26415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26414 == env26415) = true)

theorem identity26415 : scanCanonicalize (H12AffineFastState.compose env26415 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26415 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26416 : List Nat := [2,4,3,16,17,16,2,20,16,5,1,17,18,0,1,18,16,0,4,0,0,17,17,2,19,16,0,17,16,1,21,16,21,17,0,17]

theorem envBound26416 : H12AffineFastState.Bounded env26416 := by
  intro p hp
  have h : env26416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26415_26416 : H12AffineEnvironment.transform 4 17 env26415 = env26416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26415 == env26416) = true)

theorem identity26416 : scanCanonicalize (H12AffineFastState.compose env26416 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26416 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26417 : List Nat := [2,4,3,1,0,1,2,5,1,5,1,0,3,0,1,3,1,0,4,0,0,0,0,2,2,1,0,0,1,1,4,1,4,0,0,0]

theorem envBound26417 : H12AffineFastState.Bounded env26417 := by
  intro p hp
  have h : env26417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26416_26417 : H12AffineEnvironment.transform 3 1 env26416 = env26417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26416 == env26417) = true)

def env26418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4161,180272,253963,242968,8328,64,97667,139733,238875,67755,119043,169,257,98814,90203,63188]

theorem envBound26418 : H12AffineFastState.Bounded env26418 := by
  intro p hp
  have h : env26418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26385_26418 : H12AffineEnvironment.transform 17 10401 env26385 = env26418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env26385 == env26418) = true)

def env26419 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,180272,253963,242968,8192,64,97547,139613,238875,67619,119043,33,257,98678,90203,63068]

theorem envBound26419 : H12AffineFastState.Bounded env26419 := by
  intro p hp
  have h : env26419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26418_26419 : H12AffineEnvironment.transform 6 8 env26418 = env26419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26418 == env26419) = true)

theorem identity26419 : scanCanonicalize (H12AffineFastState.compose env26419 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound26419 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26420 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10281,1025,32769,4161,119926,62541,41310,8192,64,97547,79131,45405,67619,119043,33,257,98678,90203,63068]

theorem envBound26420 : H12AffineFastState.Bounded env26420 := by
  intro p hp
  have h : env26420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26419_26420 : H12AffineEnvironment.transform 16 70726 env26419 = env26420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env26419 == env26420) = true)

theorem identity26420 : scanCanonicalize (H12AffineFastState.compose env26420 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound26420 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env26421 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,70726,10281,1025,29788,4161,73771,16,21763,8192,64,97547,79131,17664,67619,75102,33,257,95531,90203,513]

theorem envBound26421 : H12AffineFastState.Bounded env26421 := by
  intro p hp
  have h : env26421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26420_26421 : H12AffineEnvironment.transform 14 29789 env26420 = env26421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env26420 == env26421) = true)

theorem identity26421 : scanCanonicalize (H12AffineFastState.compose env26421 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 16647) := by decide +kernel

theorem selectedBound26421 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env26422 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,16647,21825,10281,1025,29788,4161,24876,16,21763,8192,64,15372,29724,17664,18724,25689,33,257,13356,8540,513]

theorem envBound26422 : H12AffineFastState.Bounded env26422 := by
  intro p hp
  have h : env26422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26421_26422 : H12AffineEnvironment.transform 15 16647 env26421 = env26422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 16647 env26421 == env26422) = true)

theorem identity26422 : scanCanonicalize (H12AffineFastState.compose env26422 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound26422 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env26423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,13658,8476,10281,1025,1,4161,5489,16,8542,8192,64,15372,65,12637,15737,4100,33,257,13356,8540,513]

theorem envBound26423 : H12AffineFastState.Bounded env26423 := by
  intro p hp
  have h : env26423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26422_26423 : H12AffineEnvironment.transform 13 13405 env26422 = env26423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env26422 == env26423) = true)

theorem identity26423 : scanCanonicalize (H12AffineFastState.compose env26423 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound26423 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env26424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5133,80,0,343,5393,7204,1025,1,4161,5489,16,5459,5133,64,2049,65,1360,2420,4100,33,257,33,5457,513]

theorem envBound26424 : H12AffineFastState.Bounded env26424 := by
  intro p hp
  have h : env26424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26423_26424 : H12AffineEnvironment.transform 12 5133 env26423 = env26424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env26423 == env26424) = true)

theorem identity26424 : scanCanonicalize (H12AffineFastState.compose env26424 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26424 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26425 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,5133,1,0,262,5393,7204,1025,1,4112,5408,16,5378,5133,17,2049,16,1281,2341,4100,33,257,33,5376,513]

theorem envBound26425 : H12AffineFastState.Bounded env26425 := by
  intro p hp
  have h : env26425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26424_26425 : H12AffineEnvironment.transform 5 17 env26424 = env26425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26424 == env26425) = true)

theorem identity26425 : scanCanonicalize (H12AffineFastState.compose env26425 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound26425 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env26426 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,16,1053,1,0,262,1281,3124,1025,1,0,1328,16,1298,1053,17,2049,16,1281,2341,20,33,257,33,1296,513]

theorem envBound26426 : H12AffineFastState.Bounded env26426 := by
  intro p hp
  have h : env26426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26425_26426 : H12AffineEnvironment.transform 11 16 env26425 = env26426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env26425 == env26426) = true)

theorem identity26426 : scanCanonicalize (H12AffineFastState.compose env26426 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound26426 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env26427 : List Nat := [2,4,8,16,32,17,8,256,512,1024,293,16,1053,1,0,262,1281,1297,1025,1,0,1328,16,1298,1053,17,292,16,1281,0,20,33,257,33,1296,513]

theorem envBound26427 : H12AffineFastState.Bounded env26427 := by
  intro p hp
  have h : env26427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26426_26427 : H12AffineEnvironment.transform 10 293 env26426 = env26427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env26426 == env26427) = true)

theorem identity26427 : scanCanonicalize (H12AffineFastState.compose env26427 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26427 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26428 : List Nat := [2,4,8,16,32,17,8,37,512,1024,0,16,1053,1,0,35,1060,1076,1025,1,0,1045,16,1079,1053,17,1,16,1060,0,20,33,36,33,1077,513]

theorem envBound26428 : H12AffineFastState.Bounded env26428 := by
  intro p hp
  have h : env26428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26427_26428 : H12AffineEnvironment.transform 7 37 env26427 = env26428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26427 == env26428) = true)

theorem identity26428 : scanCanonicalize (H12AffineFastState.compose env26428 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26428 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env26429 : List Nat := [2,4,8,16,32,17,8,37,512,52,0,16,41,1,0,35,16,0,53,1,0,33,16,3,41,17,1,16,16,0,20,33,36,33,1,513]

theorem envBound26429 : H12AffineFastState.Bounded env26429 := by
  intro p hp
  have h : env26429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26428_26429 : H12AffineEnvironment.transform 9 52 env26428 = env26429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26428 == env26429) = true)

theorem identity26429 : scanCanonicalize (H12AffineFastState.compose env26429 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound26429 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26430 : List Nat := [2,4,8,16,32,17,8,37,1,52,0,16,41,1,0,35,16,0,53,1,0,33,16,3,41,17,1,16,16,0,20,33,36,33,1,0]

theorem envBound26430 : H12AffineFastState.Bounded env26430 := by
  intro p hp
  have h : env26430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26429_26430 : H12AffineEnvironment.transform 8 1 env26429 = env26430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26429 == env26430) = true)

theorem identity26430 : scanCanonicalize (H12AffineFastState.compose env26430 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26430 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26431 : List Nat := [2,4,8,11,32,10,8,37,1,47,0,11,41,1,0,35,11,0,46,1,0,33,11,3,41,10,1,11,11,0,15,33,36,33,1,0]

theorem envBound26431 : H12AffineFastState.Bounded env26431 := by
  intro p hp
  have h : env26431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26430_26431 : H12AffineEnvironment.transform 3 11 env26430 = env26431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26430 == env26431) = true)

theorem identity26431 : scanCanonicalize (H12AffineFastState.compose env26431 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound26431 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26432 : List Nat := [2,4,2,1,32,0,2,37,1,37,0,1,35,1,0,35,1,0,36,1,0,33,1,3,35,0,1,1,1,0,5,33,36,33,1,0]

theorem envBound26432 : H12AffineFastState.Bounded env26432 := by
  intro p hp
  have h : env26432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26431_26432 : H12AffineEnvironment.transform 2 2 env26431 = env26432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env26431 == env26432) = true)

def env26433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,180272,253963,242968,8193,64,97546,139612,238875,67618,119043,32,257,98679,90203,63069]

theorem envBound26433 : H12AffineFastState.Bounded env26433 := by
  intro p hp
  have h : env26433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26418_26433 : H12AffineEnvironment.transform 6 9 env26418 = env26433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26418 == env26433) = true)

theorem identity26433 : scanCanonicalize (H12AffineFastState.compose env26433 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound26433 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26434 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10280,1025,32769,4161,95531,21776,3,8193,64,97546,103495,4096,67618,119043,32,257,98679,90203,63069]

theorem envBound26434 : H12AffineFastState.Bounded env26434 := by
  intro p hp
  have h : env26434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26433_26434 : H12AffineEnvironment.transform 16 111899 env26433 = env26434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env26433 == env26434) = true)

theorem identity26434 : scanCanonicalize (H12AffineFastState.compose env26434 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26434 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env26435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,103495,2420,1025,32769,4161,87159,21776,3,349,64,89174,103495,4096,67618,119043,32,257,98679,82183,55041]

theorem envBound26435 : H12AffineFastState.Bounded env26435 := by
  intro p hp
  have h : env26435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26434_26435 : H12AffineEnvironment.transform 12 348 env26434 = env26435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26434 == env26435) = true)

theorem identity26435 : scanCanonicalize (H12AffineFastState.compose env26435 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26435 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env26436 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,65536,103447,2340,1025,32769,4113,87079,21776,3,269,16,89094,103447,4096,67618,119043,32,257,98599,82183,55041]

theorem envBound26436 : H12AffineFastState.Bounded env26436 := by
  intro p hp
  have h : env26436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26435_26436 : H12AffineEnvironment.transform 5 16 env26435 = env26436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26435 == env26436) = true)

theorem identity26436 : scanCanonicalize (H12AffineFastState.compose env26436 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound26436 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env26437 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,35,37940,2340,1025,32769,4113,21508,21776,3,269,16,23589,37940,4096,2049,53536,32,257,33028,16676,55041]

theorem envBound26437 : H12AffineFastState.Bounded env26437 := by
  intro p hp
  have h : env26437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26436_26437 : H12AffineEnvironment.transform 15 35 env26436 = env26437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env26436 == env26437) = true)

theorem identity26437 : scanCanonicalize (H12AffineFastState.compose env26437 (packedSelected [0,2,6,7,11,12,15,16,23] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound26437 : packedSelected [0,2,6,7,11,12,15,16,23] rootPS < 2^1333 := by decide +kernel

def env26438 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21541,35,16401,2340,1025,21540,4113,21508,21776,3,269,16,23589,16401,4096,2049,1285,32,257,21793,16676,804]

theorem envBound26438 : H12AffineFastState.Bounded env26438 := by
  intro p hp
  have h : env26438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26437_26438 : H12AffineEnvironment.transform 14 21541 env26437 = env26438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env26437 == env26438) = true)

theorem identity26438 : scanCanonicalize (H12AffineFastState.compose env26438 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound26438 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26439 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5156,1,35,5173,2340,1025,0,4113,32,308,3,269,16,2049,5173,4096,2049,1285,32,257,261,5376,804]

theorem envBound26439 : H12AffineFastState.Bounded env26439 := by
  intro p hp
  have h : env26439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26438_26439 : H12AffineEnvironment.transform 13 5156 env26438 = env26439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env26438 == env26439) = true)

theorem identity26439 : scanCanonicalize (H12AffineFastState.compose env26439 (packedSelected [1,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound26439 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env26440 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8,5156,1,35,5173,2080,1025,0,4113,32,48,3,9,16,2049,5173,4096,2049,1025,32,5,1,5124,544]

theorem envBound26440 : H12AffineFastState.Bounded env26440 := by
  intro p hp
  have h : env26440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26439_26440 : H12AffineEnvironment.transform 7 4 env26439 = env26440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env26439 == env26440) = true)

def env26441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,253963,242969,8328,64,97666,2240917,2340186,335882,119042,2373704,257,2199998,2191387,63189]

theorem envBound26441 : H12AffineFastState.Bounded env26441 := by
  intro p hp
  have h : env26441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26358_26441 : H12AffineEnvironment.transform 23 242969 env26358 = env26441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242969 env26358 == env26441) = true)

def env26442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,253963,242969,8328,64,97666,139733,238874,335882,119042,272392,257,98814,90203,63189]

theorem envBound26442 : H12AffineFastState.Bounded env26442 := by
  intro p hp
  have h : env26442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26441_26442 : H12AffineEnvironment.transform 20 4160 env26441 = env26442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env26441 == env26442) = true)

theorem identity26442 : scanCanonicalize (H12AffineFastState.compose env26442 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound26442 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4160,400453,201951,213453,8328,64,97666,139733,217550,335882,75222,272392,257,95530,90203,513]

theorem envBound26443 : H12AffineFastState.Bounded env26443 := by
  intro p hp
  have h : env26443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26442_26443 : H12AffineEnvironment.transform 14 29908 env26442 = env26443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env26442 == env26443) = true)

def env26444 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4160,400453,201815,213317,8192,64,97546,139613,217414,335882,75102,272392,257,95530,90203,513]

theorem envBound26444 : H12AffineFastState.Bounded env26444 := by
  intro p hp
  have h : env26444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26443_26444 : H12AffineEnvironment.transform 6 8 env26443 = env26444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26443 == env26444) = true)

theorem identity26444 : scanCanonicalize (H12AffineFastState.compose env26444 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound26444 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env26445 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32041,1025,29789,4160,156012,201815,213317,8192,64,97546,139613,217414,89379,75102,21793,257,95530,90203,513]

theorem envBound26445 : H12AffineFastState.Bounded env26445 := by
  intro p hp
  have h : env26445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26444_26445 : H12AffineEnvironment.transform 17 32041 env26444 = env26445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env26444 == env26445) = true)

theorem identity26445 : scanCanonicalize (H12AffineFastState.compose env26445 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26445 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env26446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,65536,131072,23669,1025,21761,4160,147504,201815,213317,348,64,89174,131073,217414,89379,66562,21793,257,87158,82183,513]

theorem envBound26446 : H12AffineFastState.Bounded env26446 := by
  intro p hp
  have h : env26446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26445_26446 : H12AffineEnvironment.transform 12 348 env26445 = env26446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26445 == env26446) = true)

theorem identity26446 : scanCanonicalize (H12AffineFastState.compose env26446 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound26446 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26447 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,343,131072,23669,1025,21761,4160,147504,136448,147474,348,64,23809,131073,151569,23668,1365,21793,257,21793,16464,513]

theorem envBound26447 : H12AffineFastState.Bounded env26447 := by
  intro p hp
  have h : env26447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26446_26447 : H12AffineEnvironment.transform 15 343 env26446 = env26447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env26446 == env26447) = true)

theorem identity26447 : scanCanonicalize (H12AffineFastState.compose env26447 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26447 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26448 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21760,263,131072,23589,1025,21761,4112,147504,136448,147474,268,16,23809,131073,151569,23588,1285,21793,257,21793,16384,513]

theorem envBound26448 : H12AffineFastState.Bounded env26448 := by
  intro p hp
  have h : env26448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26447_26448 : H12AffineEnvironment.transform 5 16 env26447 = env26448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26447 == env26448) = true)

theorem identity26448 : scanCanonicalize (H12AffineFastState.compose env26448 (packedSelected [0,7,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound26448 : packedSelected [0,7,16,17] rootPS < 2^1333 := by decide +kernel

def env26449 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21760,263,16400,23589,1025,21761,4112,32,21776,2,268,16,23809,16401,4097,23588,1285,21793,257,21793,16384,513]

theorem envBound26449 : H12AffineFastState.Bounded env26449 := by
  intro p hp
  have h : env26449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26448_26449 : H12AffineEnvironment.transform 16 16400 env26448 = env26449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env26448 == env26449) = true)

theorem identity26449 : scanCanonicalize (H12AffineFastState.compose env26449 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound26449 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env26450 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3109,268,16384,18725,263,16400,16384,1025,18724,3125,32,18741,2,268,16,16676,16401,3108,16385,1285,18692,257,18692,16384,513]

theorem envBound26450 : H12AffineFastState.Bounded env26450 := by
  intro p hp
  have h : env26450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26449_26450 : H12AffineEnvironment.transform 11 3109 env26449 = env26450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env26449 == env26450) = true)

theorem identity26450 : scanCanonicalize (H12AffineFastState.compose env26450 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26450 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env26451 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,2064,268,16384,18725,263,16400,16384,52,18724,2048,32,18741,2,268,16,16676,16401,2065,16385,304,18692,257,18692,16384,513]

theorem envBound26451 : H12AffineFastState.Bounded env26451 := by
  intro p hp
  have h : env26451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26450_26451 : H12AffineEnvironment.transform 9 53 env26450 = env26451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26450 == env26451) = true)

theorem identity26451 : scanCanonicalize (H12AffineFastState.compose env26451 (packedSelected [0,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound26451 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env26452 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,2064,268,1,2340,263,17,1,52,2341,2048,32,2356,2,268,16,293,16,2065,0,304,2309,257,2309,1,513]

theorem envBound26452 : H12AffineFastState.Bounded env26452 := by
  intro p hp
  have h : env26452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26451_26452 : H12AffineEnvironment.transform 13 1 env26451 = env26452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env26451 == env26452) = true)

theorem identity26452 : scanCanonicalize (H12AffineFastState.compose env26452 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound26452 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env26453 : List Nat := [2,4,8,16,32,16,8,256,512,53,292,308,268,1,0,263,17,1,52,1,292,32,16,2,268,16,293,16,309,0,304,33,257,33,1,513]

theorem envBound26453 : H12AffineFastState.Bounded env26453 := by
  intro p hp
  have h : env26453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26452_26453 : H12AffineEnvironment.transform 10 292 env26452 = env26453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env26452 == env26453) = true)

def env26454 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4160,400453,201814,213316,8193,64,97547,139612,217415,335882,75103,272392,257,95530,90203,513]

theorem envBound26454 : H12AffineFastState.Bounded env26454 := by
  intro p hp
  have h : env26454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26443_26454 : H12AffineEnvironment.transform 6 9 env26443 = env26454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26443 == env26454) = true)

theorem identity26454 : scanCanonicalize (H12AffineFastState.compose env26454 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound26454 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env26455 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1025,29788,4160,359518,29773,8543,8193,64,97547,82247,12636,335882,75103,272392,257,95530,90203,513]

theorem envBound26455 : H12AffineFastState.Bounded env26455 := by
  intro p hp
  have h : env26455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26454_26455 : H12AffineEnvironment.transform 16 90139 env26454 = env26455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env26454 == env26455) = true)

theorem identity26455 : scanCanonicalize (H12AffineFastState.compose env26455 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 96623) := by decide +kernel

theorem selectedBound26455 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26456 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,96623,1025,29788,4160,1329,29773,8543,8193,64,97547,82247,12636,22885,75103,86375,257,95530,90203,513]

theorem envBound26456 : H12AffineFastState.Bounded env26456 := by
  intro p hp
  have h : env26456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26455_26456 : H12AffineEnvironment.transform 17 96623 env26455 = env26456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96623 env26455 == env26456) = true)

theorem identity26456 : scanCanonicalize (H12AffineFastState.compose env26456 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound26456 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env26457 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,20759,12556,10360,1025,29788,4160,1329,29773,8543,8193,64,11292,4176,12636,22885,29768,112,257,9277,12620,513]

theorem envBound26457 : H12AffineFastState.Bounded env26457 := by
  intro p hp
  have h : env26457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26456_26457 : H12AffineEnvironment.transform 15 20759 env26456 = env26457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env26456 == env26457) = true)

theorem identity26457 : scanCanonicalize (H12AffineFastState.compose env26457 (packedSelected [2,4,6,7,9,12,15,17,18,23,27] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound26457 : packedSelected [2,4,6,7,9,12,15,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env26458 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,16384,28728,20759,12556,10360,100,28729,4160,340,28712,8543,8193,64,10361,4176,12636,22885,28717,112,257,8280,12620,513]

theorem envBound26458 : H12AffineFastState.Bounded env26458 := by
  intro p hp
  have h : env26458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26457_26458 : H12AffineEnvironment.transform 9 101 env26457 = env26458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env26457 == env26458) = true)

theorem identity26458 : scanCanonicalize (H12AffineFastState.compose env26458 (packedSelected [3,5,10,11,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound26458 : packedSelected [3,5,10,11,17,18] rootPS < 2^1333 := by decide +kernel

def env26459 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,4404,8460,35,12556,10360,100,8461,4160,340,8476,8543,8193,64,10361,4176,12636,2129,8473,112,257,8280,12620,513]

theorem envBound26459 : H12AffineFastState.Bounded env26459 := by
  intro p hp
  have h : env26459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26458_26459 : H12AffineEnvironment.transform 13 4404 env26458 = env26459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env26458 == env26459) = true)

theorem identity26459 : scanCanonicalize (H12AffineFastState.compose env26459 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26459 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26460 : List Nat := [2,4,8,16,32,64,9,37,512,101,2048,4096,8192,4113,8233,35,12329,10360,100,8232,4160,113,8249,8314,8193,64,10361,4176,12409,2129,8252,112,36,8280,12393,513]

theorem envBound26460 : H12AffineFastState.Bounded env26460 := by
  intro p hp
  have h : env26460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26459_26460 : H12AffineEnvironment.transform 7 37 env26459 = env26460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26459 == env26460) = true)

theorem identity26460 : scanCanonicalize (H12AffineFastState.compose env26460 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound26460 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26461 : List Nat := [2,4,8,16,32,64,9,37,512,101,2048,4096,120,4113,81,35,4177,2048,100,80,4160,113,65,2,121,64,2049,4176,4097,2129,68,112,36,32,4113,513]

theorem envBound26461 : H12AffineFastState.Bounded env26461 := by
  intro p hp
  have h : env26461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26460_26461 : H12AffineEnvironment.transform 12 120 env26460 = env26461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env26460 == env26461) = true)

theorem identity26461 : scanCanonicalize (H12AffineFastState.compose env26461 (packedSelected [2,3] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound26461 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env26462 : List Nat := [2,4,8,16,32,64,9,37,90,101,2048,4096,120,4113,81,35,4177,2048,100,80,4160,113,65,2,121,64,2049,4176,4097,2129,68,112,36,32,4113,91]

theorem envBound26462 : H12AffineFastState.Bounded env26462 := by
  intro p hp
  have h : env26462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26461_26462 : H12AffineEnvironment.transform 8 90 env26461 = env26462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env26461 == env26462) = true)

theorem identity26462 : scanCanonicalize (H12AffineFastState.compose env26462 (packedSelected [1,2,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26462 : packedSelected [1,2,7] rootPS < 2^1333 := by decide +kernel

def env26463 : List Nat := [2,4,8,11,32,64,9,37,65,101,2048,4096,99,4106,74,35,4170,2048,100,75,4160,106,65,2,98,64,2049,4171,4097,2122,68,107,36,32,4106,64]

theorem envBound26463 : H12AffineFastState.Bounded env26463 := by
  intro p hp
  have h : env26463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26462_26463 : H12AffineEnvironment.transform 3 11 env26462 = env26463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26462 == env26463) = true)

theorem identity26463 : scanCanonicalize (H12AffineFastState.compose env26463 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound26463 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env26464 : List Nat := [2,4,8,11,32,64,9,37,65,101,65,4096,99,4106,74,35,4170,65,100,75,4160,106,65,2,98,64,64,4171,4097,11,68,107,36,32,4106,64]

theorem envBound26464 : H12AffineFastState.Bounded env26464 := by
  intro p hp
  have h : env26464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26463_26464 : H12AffineEnvironment.transform 10 65 env26463 = env26464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env26463 == env26464) = true)

def env26465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,253963,242969,8328,64,97666,139732,238875,335882,119042,272393,257,98815,90202,63189]

theorem envBound26465 : H12AffineFastState.Bounded env26465 := by
  intro p hp
  have h : env26465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26441_26465 : H12AffineEnvironment.transform 20 4161 env26441 = env26465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env26441 == env26465) = true)

theorem identity26465 : scanCanonicalize (H12AffineFastState.compose env26465 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound26465 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,262144,1025,32769,4161,318549,120015,98781,8328,64,97666,5392,102879,335882,119042,272393,257,98815,90202,63189]

theorem envBound26466 : H12AffineFastState.Bounded env26466 := by
  intro p hp
  have h : env26466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26465_26466 : H12AffineEnvironment.transform 16 13508 env26465 = env26466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env26465 == env26466) = true)

def env26467 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4161,318549,119879,98645,8192,64,97546,5392,102743,335882,119042,272393,257,98679,90202,63069]

theorem envBound26467 : H12AffineFastState.Bounded env26467 := by
  intro p hp
  have h : env26467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26466_26467 : H12AffineEnvironment.transform 6 8 env26466 = env26467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26466 == env26467) = true)

theorem identity26467 : scanCanonicalize (H12AffineFastState.compose env26467 (packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound26467 : packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS < 2^1333 := by decide +kernel

def env26468 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,89379,1025,32769,4161,98678,119879,98645,8192,64,97546,5392,102743,32041,119042,95530,257,98679,90202,63069]

theorem envBound26468 : H12AffineFastState.Bounded env26468 := by
  intro p hp
  have h : env26468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26467_26468 : H12AffineEnvironment.transform 17 89379 env26467 = env26468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env26467 == env26468) = true)

theorem identity26468 : scanCanonicalize (H12AffineFastState.compose env26468 (packedSelected [0,3,4,5,10,12,14,15,17,20,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound26468 : packedSelected [0,3,4,5,10,12,14,15,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env26469 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,263,13388,23588,1025,32769,4161,32881,54592,32850,8192,64,31757,5392,36944,32041,53253,29741,257,32880,24925,63069]

theorem envBound26469 : H12AffineFastState.Bounded env26469 := by
  intro p hp
  have h : env26469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26468_26469 : H12AffineEnvironment.transform 15 263 env26468 = env26469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env26468 == env26469) = true)

theorem identity26469 : scanCanonicalize (H12AffineFastState.compose env26469 (packedSelected [0,5,7,9,12,14,15,17,18,19,20,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound26469 : packedSelected [0,5,7,9,12,14,15,17,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env26470 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,263,13388,23588,1025,29708,4161,29820,8525,29791,8192,64,31757,5392,25693,32041,9224,29741,257,29821,24925,592]

theorem envBound26470 : H12AffineFastState.Bounded env26470 := by
  intro p hp
  have h : env26470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26469_26470 : H12AffineEnvironment.transform 14 29709 env26469 = env26470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env26469 == env26470) = true)

theorem identity26470 : scanCanonicalize (H12AffineFastState.compose env26470 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26470 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env26471 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,263,13341,23588,1025,29708,4112,29741,8476,29710,8192,17,31757,5392,25612,32041,9224,29741,257,29740,24844,513]

theorem envBound26471 : H12AffineFastState.Bounded env26471 := by
  intro p hp
  have h : env26471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26470_26471 : H12AffineEnvironment.transform 5 17 env26470 = env26471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26470 == env26471) = true)

theorem identity26471 : scanCanonicalize (H12AffineFastState.compose env26471 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26471 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26472 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21760,263,5392,23588,1025,21761,4112,21792,17,21763,269,17,23808,5392,17665,23588,1285,21792,257,21793,16385,513]

theorem envBound26472 : H12AffineFastState.Bounded env26472 := by
  intro p hp
  have h : env26472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26471_26472 : H12AffineEnvironment.transform 12 269 env26471 = env26472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26471 == env26472) = true)

theorem identity26472 : scanCanonicalize (H12AffineFastState.compose env26472 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound26472 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26473 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,263,5392,2341,1025,0,4112,33,17,2,269,17,2049,5392,4096,2341,1285,33,257,32,5376,513]

theorem envBound26473 : H12AffineFastState.Bounded env26473 := by
  intro p hp
  have h : env26473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26472_26473 : H12AffineEnvironment.transform 13 5377 env26472 = env26473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26472 == env26473) = true)

theorem identity26473 : scanCanonicalize (H12AffineFastState.compose env26473 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound26473 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26474 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,277,269,1044,1,263,1029,2341,1025,0,261,33,17,2,269,17,2049,1029,277,2341,1285,33,257,32,1045,513]

theorem envBound26474 : H12AffineFastState.Bounded env26474 := by
  intro p hp
  have h : env26474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26473_26474 : H12AffineEnvironment.transform 11 277 env26473 = env26474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env26473 == env26474) = true)

theorem identity26474 : scanCanonicalize (H12AffineFastState.compose env26474 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound26474 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26475 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,277,269,293,1,263,308,2341,304,0,261,33,17,2,269,17,2049,308,277,2341,52,33,257,32,292,513]

theorem envBound26475 : H12AffineFastState.Bounded env26475 := by
  intro p hp
  have h : env26475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26474_26475 : H12AffineEnvironment.transform 9 305 env26474 = env26475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env26474 == env26475) = true)

theorem identity26475 : scanCanonicalize (H12AffineFastState.compose env26475 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound26475 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26476 : List Nat := [2,4,8,16,32,17,8,256,293,305,2048,277,269,293,1,263,308,2341,304,0,261,33,17,2,269,17,2049,308,277,2341,52,33,257,32,292,292]

theorem envBound26476 : H12AffineFastState.Bounded env26476 := by
  intro p hp
  have h : env26476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26475_26476 : H12AffineEnvironment.transform 8 293 env26475 = env26476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env26475 == env26476) = true)

theorem identity26476 : scanCanonicalize (H12AffineFastState.compose env26476 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26476 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26477 : List Nat := [2,4,8,16,17,17,8,256,276,256,2048,277,269,276,1,263,261,2324,257,0,261,16,17,2,269,17,2049,261,277,2324,5,16,257,17,277,277]

theorem envBound26477 : H12AffineFastState.Bounded env26477 := by
  intro p hp
  have h : env26477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26476_26477 : H12AffineEnvironment.transform 4 17 env26476 = env26477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26476 == env26477) = true)

theorem identity26477 : scanCanonicalize (H12AffineFastState.compose env26477 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound26477 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26478 : List Nat := [2,4,8,16,17,17,8,256,276,256,17,277,269,276,1,263,261,261,257,0,261,16,17,2,269,17,16,261,277,261,5,16,257,17,277,277]

theorem envBound26478 : H12AffineFastState.Bounded env26478 := by
  intro p hp
  have h : env26478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26477_26478 : H12AffineEnvironment.transform 10 17 env26477 = env26478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env26477 == env26478) = true)

def env26479 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,4161,318549,119878,98644,8193,64,97547,5392,102742,335882,119042,272393,257,98678,90202,63068]

theorem envBound26479 : H12AffineFastState.Bounded env26479 := by
  intro p hp
  have h : env26479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26466_26479 : H12AffineEnvironment.transform 6 9 env26466 = env26479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26466 == env26479) = true)

theorem identity26479 : scanCanonicalize (H12AffineFastState.compose env26479 (packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS)) = affineNative (2^(17+1) ^^^ 10508) := by decide +kernel

theorem selectedBound26479 : packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS < 2^1333 := by decide +kernel

def env26480 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10508,1025,32769,4161,62809,119878,98644,8193,64,97547,5392,102742,67846,119042,261,257,98678,90202,63068]

theorem envBound26480 : H12AffineFastState.Bounded env26480 := by
  intro p hp
  have h : env26480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26479_26480 : H12AffineEnvironment.transform 17 10508 env26479 = env26480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10508 env26479 == env26480) = true)

theorem identity26480 : scanCanonicalize (H12AffineFastState.compose env26480 (packedSelected [0,1,2,4,5,6,7,9,10,12,15,16,17,18,19,20,24,26,28,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 29743) := by decide +kernel

theorem selectedBound26480 : packedSelected [0,1,2,4,5,6,7,9,10,12,15,16,17,18,19,20,24,26,28,32,35] rootPS < 2^1333 := by decide +kernel

def env26481 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29743,13389,10508,1025,32769,4161,62809,41065,62843,8193,64,2340,5392,58745,32041,42285,261,257,62809,5237,63068]

theorem envBound26481 : H12AffineFastState.Bounded env26481 := by
  intro p hp
  have h : env26481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26480_26481 : H12AffineEnvironment.transform 15 29743 env26480 = env26481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29743 env26480 == env26481) = true)

theorem identity26481 : scanCanonicalize (H12AffineFastState.compose env26481 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound26481 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env26482 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21540,29743,13389,10508,1025,21541,4161,8573,29773,8543,8193,64,2340,5392,12637,32041,28937,261,257,8573,5237,8824]

theorem envBound26482 : H12AffineFastState.Bounded env26482 := by
  intro p hp
  have h : env26482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26481_26482 : H12AffineEnvironment.transform 14 21540 env26481 = env26482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env26481 == env26482) = true)

theorem identity26482 : scanCanonicalize (H12AffineFastState.compose env26482 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound26482 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env26483 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,0,8203,13389,10508,1025,1,4161,8573,8297,8543,8193,64,2340,5392,12637,10509,9517,261,257,8573,5237,8824]

theorem envBound26483 : H12AffineFastState.Bounded env26483 := by
  intro p hp
  have h : env26483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26482_26483 : H12AffineEnvironment.transform 13 5156 env26482 = env26483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env26482 == env26483) = true)

theorem identity26483 : scanCanonicalize (H12AffineFastState.compose env26483 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26483 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env26484 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5156,0,343,5393,2128,1025,1,4161,33,309,3,349,64,2340,5392,4097,2129,1137,261,257,33,5237,804]

theorem envBound26484 : H12AffineFastState.Bounded env26484 := by
  intro p hp
  have h : env26484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26483_26484 : H12AffineEnvironment.transform 12 348 env26483 = env26484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26483 == env26484) = true)

theorem identity26484 : scanCanonicalize (H12AffineFastState.compose env26484 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound26484 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env26485 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5156,0,34,5220,2128,1025,1,4161,33,64,3,40,64,2129,5221,4097,2129,1137,112,116,33,5237,593]

theorem envBound26485 : H12AffineFastState.Bounded env26485 := by
  intro p hp
  have h : env26485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26484_26485 : H12AffineEnvironment.transform 7 117 env26484 = env26485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env26484 == env26485) = true)

theorem identity26485 : scanCanonicalize (H12AffineFastState.compose env26485 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound26485 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env26486 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2113,41,3173,0,34,3109,2128,1025,1,2048,33,64,3,40,64,2129,3108,2112,2129,1137,112,116,33,3124,593]

theorem envBound26486 : H12AffineFastState.Bounded env26486 := by
  intro p hp
  have h : env26486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26485_26486 : H12AffineEnvironment.transform 11 2113 env26485 = env26486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env26485 == env26486) = true)

theorem identity26486 : scanCanonicalize (H12AffineFastState.compose env26486 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26486 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env26487 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,2064,41,3124,0,34,3109,2049,1025,1,2048,33,17,3,40,17,2048,3108,2065,2048,1056,33,37,33,3124,512]

theorem envBound26487 : H12AffineFastState.Bounded env26487 := by
  intro p hp
  have h : env26487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26486_26487 : H12AffineEnvironment.transform 5 17 env26486 = env26487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26486 == env26487) = true)

theorem identity26487 : scanCanonicalize (H12AffineFastState.compose env26487 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound26487 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26488 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1061,1077,41,17,0,34,0,1060,1025,1,1061,33,17,3,40,17,1061,1,1076,1061,1056,33,37,33,17,512]

theorem envBound26488 : H12AffineFastState.Bounded env26488 := by
  intro p hp
  have h : env26488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26487_26488 : H12AffineEnvironment.transform 10 1061 env26487 = env26488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env26487 == env26488) = true)

theorem identity26488 : scanCanonicalize (H12AffineFastState.compose env26488 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound26488 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26489 : List Nat := [2,4,8,16,32,17,9,36,512,516,545,561,41,17,0,34,0,544,517,1,545,33,17,3,40,17,545,1,560,545,548,33,37,33,17,512]

theorem envBound26489 : H12AffineFastState.Bounded env26489 := by
  intro p hp
  have h : env26489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26488_26489 : H12AffineEnvironment.transform 9 516 env26488 = env26489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env26488 == env26489) = true)

theorem identity26489 : scanCanonicalize (H12AffineFastState.compose env26489 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound26489 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26490 : List Nat := [2,4,8,16,32,17,9,36,32,36,1,17,41,17,0,34,0,0,37,1,1,33,17,3,40,17,1,1,16,1,4,33,37,33,17,32]

theorem envBound26490 : H12AffineFastState.Bounded env26490 := by
  intro p hp
  have h : env26490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26489_26490 : H12AffineEnvironment.transform 8 32 env26489 = env26490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env26489 == env26490) = true)

theorem identity26490 : scanCanonicalize (H12AffineFastState.compose env26490 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26490 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26491 : List Nat := [2,4,8,1,32,0,9,36,32,36,1,0,41,0,0,34,0,0,37,1,1,33,0,3,40,0,1,1,1,1,4,33,37,33,0,32]

theorem envBound26491 : H12AffineFastState.Bounded env26491 := by
  intro p hp
  have h : env26491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26490_26491 : H12AffineEnvironment.transform 3 1 env26490 = env26491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26490 == env26491) = true)

theorem identity26491 : scanCanonicalize (H12AffineFastState.compose env26491 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26491 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26492 : List Nat := [2,4,8,1,0,0,9,4,0,4,1,0,9,0,0,2,0,0,5,1,1,1,0,3,8,0,1,1,1,1,4,1,5,1,0,0]

theorem envBound26492 : H12AffineFastState.Bounded env26492 := by
  intro p hp
  have h : env26492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26491_26492 : H12AffineEnvironment.transform 4 0 env26491 = env26492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26491 == env26492) = true)

theorem identity26492 : scanCanonicalize (H12AffineFastState.compose env26492 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound26492 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26493 : List Nat := [2,1,8,1,0,0,9,1,0,1,1,0,9,0,0,2,0,0,0,1,1,1,0,3,8,0,1,1,1,1,1,1,0,1,0,0]

theorem envBound26493 : H12AffineFastState.Bounded env26493 := by
  intro p hp
  have h : env26493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26492_26493 : H12AffineEnvironment.transform 1 1 env26492 = env26493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env26492 == env26493) = true)

def env26494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356289,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound26494 : H12AffineFastState.Bounded env26494 := by
  intro p hp
  have h : env26494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26151_26494 : H12AffineEnvironment.transform 26 30393345 env26151 = env26494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env26151 == env26494) = true)

def env26495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound26495 : H12AffineFastState.Bounded env26495 := by
  intro p hp
  have h : env26495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26494_26495 : H12AffineEnvironment.transform 18 1024 env26494 = env26495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env26494 == env26495) = true)

theorem identity26495 : scanCanonicalize (H12AffineFastState.compose env26495 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 91467) := by decide +kernel

theorem selectedBound26495 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91467,4194304,8388608,16777216,8328,64,29868033,16835014,8466458,8830977,25265168,20971658,256,25207271,25182274,25207750]

theorem envBound26496 : H12AffineFastState.Bounded env26496 := by
  intro p hp
  have h : env26496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26495_26496 : H12AffineEnvironment.transform 20 91467 env26495 = env26496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91467 env26495 == env26496) = true)

def env26497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91467,4194304,8388608,120028,8328,64,12981469,79130,8466458,8830977,8409292,4314198,256,8484155,8492190,8484634]

theorem envBound26497 : H12AffineFastState.Bounded env26497 := by
  intro p hp
  have h : env26497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26496_26497 : H12AffineEnvironment.transform 23 120028 env26496 = env26497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 120028 env26496 == env26497) = true)

def env26498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98644,8328,64,12981469,79130,8466458,8820105,8389956,4293086,256,8462515,8492190,8462994]

theorem envBound26498 : H12AffineFastState.Bounded env26498 := by
  intro p hp
  have h : env26498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26497_26498 : H12AffineEnvironment.transform 13 5512 env26497 = env26498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env26497 == env26498) = true)

def env26499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,32,8388608,98644,8328,64,8787197,79130,8466458,8820105,8389956,98814,256,8462515,8492190,8462994]

theorem envBound26499 : H12AffineFastState.Bounded env26499 := by
  intro p hp
  have h : env26499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26498_26499 : H12AffineEnvironment.transform 21 32 env26498 = env26499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26498 == env26499) = true)

theorem identity26499 : scanCanonicalize (H12AffineFastState.compose env26499 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26499 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26500 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,8388608,98644,8192,64,8787061,79130,8466458,8819969,8389956,98678,256,8462395,8492054,8462874]

theorem envBound26500 : H12AffineFastState.Bounded env26500 := by
  intro p hp
  have h : env26500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26499_26500 : H12AffineEnvironment.transform 6 8 env26499 = env26500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26499 == env26500) = true)

def env26501 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,16,98644,8192,64,398437,79130,77834,431377,1364,98678,256,73771,103430,74250]

theorem envBound26501 : H12AffineFastState.Bounded env26501 := by
  intro p hp
  have h : env26501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26500_26501 : H12AffineEnvironment.transform 22 16 env26500 = env26501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env26500 == env26501) = true)

theorem identity26501 : scanCanonicalize (H12AffineFastState.compose env26501 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26501 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26502 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,32,16,41311,8192,64,398437,5393,4097,431377,1364,41341,256,32,46093,513]

theorem envBound26502 : H12AffineFastState.Bounded env26502 := by
  intro p hp
  have h : env26502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26501_26502 : H12AffineEnvironment.transform 15 8203 env26501 = env26502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26501 == env26502) = true)

theorem identity26502 : scanCanonicalize (H12AffineFastState.compose env26502 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26502 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env26503 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,32,16,2,8192,64,398437,5393,4097,406604,1364,32,256,32,5456,513]

theorem envBound26503 : H12AffineFastState.Bounded env26503 := by
  intro p hp
  have h : env26503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26502_26503 : H12AffineEnvironment.transform 14 8541 env26502 = env26503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26502 == env26503) = true)

theorem identity26503 : scanCanonicalize (H12AffineFastState.compose env26503 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146793) := by decide +kernel

theorem selectedBound26503 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26504 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,146793,1024,8540,4160,32,16,2,8192,64,10508,5393,4097,2341,1364,32,256,32,5456,513]

theorem envBound26504 : H12AffineFastState.Bounded env26504 := by
  intro p hp
  have h : env26504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26503_26504 : H12AffineEnvironment.transform 17 146793 env26503 = env26504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146793 env26503 == env26504) = true)

theorem identity26504 : scanCanonicalize (H12AffineFastState.compose env26504 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound26504 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env26505 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5392,10361,1024,8540,4160,32,16,2,8192,64,10508,5393,4097,2341,1364,32,256,32,5456,513]

theorem envBound26505 : H12AffineFastState.Bounded env26505 := by
  intro p hp
  have h : env26505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26504_26505 : H12AffineEnvironment.transform 16 5392 env26504 = env26505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env26504 == env26505) = true)

theorem identity26505 : scanCanonicalize (H12AffineFastState.compose env26505 (packedSelected [3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound26505 : packedSelected [3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env26506 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8232,8203,5221,10361,1024,8233,4160,32,16,2,8192,64,10361,5220,4097,2128,1057,32,117,32,5157,513]

theorem envBound26506 : H12AffineFastState.Bounded env26506 := by
  intro p hp
  have h : env26506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26505_26506 : H12AffineEnvironment.transform 7 117 env26505 = env26506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env26505 == env26506) = true)

theorem identity26506 : scanCanonicalize (H12AffineFastState.compose env26506 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26506 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26507 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,5156,8232,8203,5172,10280,1024,8233,4113,32,16,2,8192,17,10280,5173,4097,2049,1057,32,36,32,5157,513]

theorem envBound26507 : H12AffineFastState.Bounded env26507 := by
  intro p hp
  have h : env26507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26506_26507 : H12AffineEnvironment.transform 5 17 env26506 = env26507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26506 == env26507) = true)

theorem identity26507 : scanCanonicalize (H12AffineFastState.compose env26507 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound26507 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26508 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8,5156,32,3,5172,2080,1024,33,4113,32,16,2,8,17,2080,5173,4097,2049,1057,32,36,32,5157,513]

theorem envBound26508 : H12AffineFastState.Bounded env26508 := by
  intro p hp
  have h : env26508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26507_26508 : H12AffineEnvironment.transform 12 8 env26507 = env26508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env26507 == env26508) = true)

theorem identity26508 : scanCanonicalize (H12AffineFastState.compose env26508 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound26508 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26509 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1044,4096,8,5156,32,3,5172,1076,1024,33,4113,32,16,2,8,17,1076,5173,4097,1045,1057,32,36,32,5157,513]

theorem envBound26509 : H12AffineFastState.Bounded env26509 := by
  intro p hp
  have h : env26509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26508_26509 : H12AffineEnvironment.transform 10 1044 env26508 = env26509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env26508 == env26509) = true)

theorem identity26509 : scanCanonicalize (H12AffineFastState.compose env26509 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound26509 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env26510 : List Nat := [2,4,8,16,32,17,8,36,0,1024,1044,4096,8,5156,32,3,5172,1076,1024,33,4113,32,16,2,8,17,1076,5173,4097,1045,1057,32,36,32,5157,1]

theorem envBound26510 : H12AffineFastState.Bounded env26510 := by
  intro p hp
  have h : env26510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26509_26510 : H12AffineEnvironment.transform 8 0 env26509 = env26510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env26509 == env26510) = true)

theorem identity26510 : scanCanonicalize (H12AffineFastState.compose env26510 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26510 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env26511 : List Nat := [2,4,8,16,0,17,8,4,0,1024,1044,4096,8,5124,0,3,5140,1044,1024,1,4113,0,16,2,8,17,1044,5141,4097,1045,1025,0,4,0,5125,1]

theorem envBound26511 : H12AffineFastState.Bounded env26511 := by
  intro p hp
  have h : env26511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26510_26511 : H12AffineEnvironment.transform 4 0 env26510 = env26511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26510 == env26511) = true)

theorem identity26511 : scanCanonicalize (H12AffineFastState.compose env26511 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound26511 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26512 : List Nat := [2,4,8,16,0,17,8,4,0,1024,1044,1028,8,0,0,3,16,1044,1024,1,1045,0,16,2,8,17,1044,17,1029,1045,1025,0,4,0,1,1]

theorem envBound26512 : H12AffineFastState.Bounded env26512 := by
  intro p hp
  have h : env26512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26511_26512 : H12AffineEnvironment.transform 11 1028 env26511 = env26512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env26511 == env26512) = true)

theorem identity26512 : scanCanonicalize (H12AffineFastState.compose env26512 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26512 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26513 : List Nat := [2,4,8,0,0,1,8,4,0,1024,1028,1028,8,0,0,3,0,1028,1024,1,1029,0,0,2,8,1,1028,1,1029,1029,1025,0,4,0,1,1]

theorem envBound26513 : H12AffineFastState.Bounded env26513 := by
  intro p hp
  have h : env26513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26512_26513 : H12AffineEnvironment.transform 3 0 env26512 = env26513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26512 == env26513) = true)

theorem identity26513 : scanCanonicalize (H12AffineFastState.compose env26513 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound26513 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26514 : List Nat := [2,4,8,0,0,1,8,4,0,4,0,0,8,0,0,3,0,0,4,1,1,0,0,2,8,1,0,1,1,1,5,0,4,0,1,1]

theorem envBound26514 : H12AffineFastState.Bounded env26514 := by
  intro p hp
  have h : env26514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26513_26514 : H12AffineEnvironment.transform 9 4 env26513 = env26514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env26513 == env26514) = true)

def env26515 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,17,98644,8192,64,398436,79130,77835,431376,1365,98678,256,73770,103431,74251]

theorem envBound26515 : H12AffineFastState.Bounded env26515 := by
  intro p hp
  have h : env26515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26500_26515 : H12AffineEnvironment.transform 22 17 env26500 = env26515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env26500 == env26515) = true)

theorem identity26515 : scanCanonicalize (H12AffineFastState.compose env26515 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound26515 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26516 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67618,1024,32769,77899,32,17,98644,8192,64,203846,79130,77835,236850,1365,98678,256,73770,103431,74251]

theorem envBound26516 : H12AffineFastState.Bounded env26516 := by
  intro p hp
  have h : env26516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26515_26516 : H12AffineEnvironment.transform 17 67618 env26515 = env26516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env26515 == env26516) = true)

theorem identity26516 : scanCanonicalize (H12AffineFastState.compose env26516 (packedSelected [1,2,6,8,10,11,12,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound26516 : packedSelected [1,2,6,8,10,11,12,14,20] rootPS < 2^1333 := by decide +kernel

def env26517 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,103495,67618,1024,32769,77899,32,17,98644,8192,64,34817,79130,77835,2421,1365,98678,256,73770,103431,74251]

theorem envBound26517 : H12AffineFastState.Bounded env26517 := by
  intro p hp
  have h : env26517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26516_26517 : H12AffineEnvironment.transform 16 103495 env26516 = env26517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env26516 == env26517) = true)

theorem identity26517 : scanCanonicalize (H12AffineFastState.compose env26517 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound26517 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26518 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,5393,35188,1024,32769,45341,32,17,2,8192,64,34817,46156,45405,2421,1365,32,256,41340,5457,41821]

theorem envBound26518 : H12AffineFastState.Bounded env26518 := by
  intro p hp
  have h : env26518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26517_26518 : H12AffineEnvironment.transform 15 33110 env26517 = env26518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env26517 == env26518) = true)

theorem identity26518 : scanCanonicalize (H12AffineFastState.compose env26518 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound26518 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env26519 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,293,115,5393,2129,1024,292,12344,32,17,2,8192,64,2340,13673,12408,2421,1365,32,256,8281,5457,8824]

theorem envBound26519 : H12AffineFastState.Bounded env26519 := by
  intro p hp
  have h : env26519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26518_26519 : H12AffineEnvironment.transform 14 293 env26518 = env26519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env26518 == env26519) = true)

theorem identity26519 : scanCanonicalize (H12AffineFastState.compose env26519 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26519 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26520 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,293,115,5393,2129,1024,292,4452,32,17,2,348,64,2340,5173,4388,2421,1365,32,256,261,5457,804]

theorem envBound26520 : H12AffineFastState.Bounded env26520 := by
  intro p hp
  have h : env26520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26519_26520 : H12AffineEnvironment.transform 12 348 env26519 = env26520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26519 == env26520) = true)

theorem identity26520 : scanCanonicalize (H12AffineFastState.compose env26520 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26520 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env26521 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,293,34,5393,2048,1024,292,4405,32,17,2,269,17,2340,5173,4388,2340,1284,32,256,261,5376,804]

theorem envBound26521 : H12AffineFastState.Bounded env26521 := by
  intro p hp
  have h : env26521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26520_26521 : H12AffineEnvironment.transform 5 17 env26520 = env26521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26520 == env26521) = true)

theorem identity26521 : scanCanonicalize (H12AffineFastState.compose env26521 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound26521 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env26522 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3328,269,2048,293,34,2065,2048,1024,292,3125,32,17,2,269,17,2340,2357,3108,2340,1284,32,256,261,2048,804]

theorem envBound26522 : H12AffineFastState.Bounded env26522 := by
  intro p hp
  have h : env26522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26521_26522 : H12AffineEnvironment.transform 11 3328 env26521 = env26522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env26521 == env26522) = true)

def env26523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,33,8388608,98644,8328,64,8787196,79130,8466458,8820105,8389956,98815,256,8462515,8492190,8462994]

theorem envBound26523 : H12AffineFastState.Bounded env26523 := by
  intro p hp
  have h : env26523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26498_26523 : H12AffineEnvironment.transform 21 33 env26498 = env26523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26498 == env26523) = true)

theorem identity26523 : scanCanonicalize (H12AffineFastState.compose env26523 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 152) := by decide +kernel

theorem selectedBound26523 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,33,152,98644,8328,64,398436,79130,77954,431377,1500,98815,256,73771,103430,74250]

theorem envBound26524 : H12AffineFastState.Bounded env26524 := by
  intro p hp
  have h : env26524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26523_26524 : H12AffineEnvironment.transform 22 152 env26523 = env26524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env26523 == env26524) = true)

def env26525 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,33,16,98644,8192,64,398436,79130,77834,431377,1364,98679,256,73771,103430,74250]

theorem envBound26525 : H12AffineFastState.Bounded env26525 := by
  intro p hp
  have h : env26525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26524_26525 : H12AffineEnvironment.transform 6 8 env26524 = env26525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26524 == env26525) = true)

theorem identity26525 : scanCanonicalize (H12AffineFastState.compose env26525 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26525 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26526 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,33,16,41311,8192,64,398436,5393,4097,431377,1364,41340,256,32,46093,513]

theorem envBound26526 : H12AffineFastState.Bounded env26526 := by
  intro p hp
  have h : env26526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26525_26526 : H12AffineEnvironment.transform 15 8203 env26525 = env26526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26525 == env26526) = true)

theorem identity26526 : scanCanonicalize (H12AffineFastState.compose env26526 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26526 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env26527 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,33,16,2,8192,64,398436,5393,4097,406604,1364,33,256,32,5456,513]

theorem envBound26527 : H12AffineFastState.Bounded env26527 := by
  intro p hp
  have h : env26527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26526_26527 : H12AffineEnvironment.transform 14 8541 env26526 = env26527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26526 == env26527) = true)

theorem identity26527 : scanCanonicalize (H12AffineFastState.compose env26527 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146793) := by decide +kernel

theorem selectedBound26527 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26528 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,146793,1024,8540,4160,33,16,2,8192,64,10509,5393,4097,2341,1364,33,256,32,5456,513]

theorem envBound26528 : H12AffineFastState.Bounded env26528 := by
  intro p hp
  have h : env26528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26527_26528 : H12AffineEnvironment.transform 17 146793 env26527 = env26528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146793 env26527 == env26528) = true)

theorem identity26528 : scanCanonicalize (H12AffineFastState.compose env26528 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound26528 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env26529 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,342,131072,138292,1024,1,4160,33,16,2,349,64,2128,5393,4097,2341,1364,33,256,32,5456,513]

theorem envBound26529 : H12AffineFastState.Bounded env26529 := by
  intro p hp
  have h : env26529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26528_26529 : H12AffineEnvironment.transform 12 349 env26528 = env26529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env26528 == env26529) = true)

def env26530 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,33,17,98644,8193,64,398436,79130,77835,431377,1365,98678,256,73771,103430,74250]

theorem envBound26530 : H12AffineFastState.Bounded env26530 := by
  intro p hp
  have h : env26530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26524_26530 : H12AffineEnvironment.transform 6 9 env26524 = env26530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26524 == env26530) = true)

theorem identity26530 : scanCanonicalize (H12AffineFastState.compose env26530 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound26530 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26531 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108927,1024,32769,77898,33,17,98644,8193,64,245019,79130,77835,212078,1365,98678,256,73771,103430,74250]

theorem envBound26531 : H12AffineFastState.Bounded env26531 := by
  intro p hp
  have h : env26531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26530_26531 : H12AffineEnvironment.transform 17 108927 env26530 = env26531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env26530 == env26531) = true)

theorem identity26531 : scanCanonicalize (H12AffineFastState.compose env26531 (packedSelected [0,3,5,8,9,16,19,20,22,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound26531 : packedSelected [0,3,5,8,9,16,19,20,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env26532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,131072,10280,1024,32769,45341,33,17,3,8193,64,146508,46157,45404,179513,1365,33,256,41340,5457,41821]

theorem envBound26532 : H12AffineFastState.Bounded env26532 := by
  intro p hp
  have h : env26532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26531_26532 : H12AffineEnvironment.transform 15 33111 env26531 = env26532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env26531 == env26532) = true)

theorem identity26532 : scanCanonicalize (H12AffineFastState.compose env26532 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 112) := by decide +kernel

theorem selectedBound26532 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env26533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,112,295,131072,10280,1024,113,12653,33,17,3,8193,64,146508,13373,12588,146761,1365,33,256,8460,5457,9005]

theorem envBound26533 : H12AffineFastState.Bounded env26533 := by
  intro p hp
  have h : env26533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26532_26533 : H12AffineEnvironment.transform 14 112 env26532 = env26533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 112 env26532 == env26533) = true)

theorem identity26533 : scanCanonicalize (H12AffineFastState.compose env26533 (packedSelected [0,4,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 13624) := by decide +kernel

theorem selectedBound26533 : packedSelected [0,4,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env26534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,112,295,13624,10280,1024,113,12653,33,17,3,8193,64,2420,13373,12588,2161,1365,33,256,8460,5457,9005]

theorem envBound26534 : H12AffineFastState.Bounded env26534 := by
  intro p hp
  have h : env26534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26533_26534 : H12AffineEnvironment.transform 16 13624 env26533 = env26534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13624 env26533 == env26534) = true)

theorem identity26534 : scanCanonicalize (H12AffineFastState.compose env26534 (packedSelected [0,2,4,6,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound26534 : packedSelected [0,2,4,6,7,22] rootPS < 2^1333 := by decide +kernel

def env26535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,300,5377,112,295,5140,2308,1024,113,4161,33,17,3,301,64,2420,5393,4096,2161,1365,33,256,32,5457,513]

theorem envBound26535 : H12AffineFastState.Bounded env26535 := by
  intro p hp
  have h : env26535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26534_26535 : H12AffineEnvironment.transform 12 300 env26534 = env26535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env26534 == env26535) = true)

theorem identity26535 : scanCanonicalize (H12AffineFastState.compose env26535 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound26535 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26536 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,41,5124,112,34,5140,2049,1024,113,4161,33,17,3,40,64,2161,5140,4096,2161,1104,33,5,32,5204,513]

theorem envBound26536 : H12AffineFastState.Bounded env26536 := by
  intro p hp
  have h : env26536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26535_26536 : H12AffineEnvironment.transform 7 5 env26535 = env26536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env26535 == env26536) = true)

theorem identity26536 : scanCanonicalize (H12AffineFastState.compose env26536 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 3140) := by decide +kernel

theorem selectedBound26536 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26537 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,3140,41,2112,112,34,2128,2049,1024,113,3077,33,17,3,40,64,2161,2128,3140,2161,1104,33,5,32,2064,513]

theorem envBound26537 : H12AffineFastState.Bounded env26537 := by
  intro p hp
  have h : env26537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26536_26537 : H12AffineEnvironment.transform 11 3140 env26536 = env26537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3140 env26536 == env26537) = true)

def env26538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98645,8328,64,12981469,79130,8466458,8820104,8389957,4293087,256,8462514,8492190,8462995]

theorem envBound26538 : H12AffineFastState.Bounded env26538 := by
  intro p hp
  have h : env26538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26497_26538 : H12AffineEnvironment.transform 13 5513 env26497 = env26538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env26497 == env26538) = true)

def env26539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,32,8388608,98645,8328,64,8787197,79130,8466458,8820104,8389957,98815,256,8462514,8492190,8462995]

theorem envBound26539 : H12AffineFastState.Bounded env26539 := by
  intro p hp
  have h : env26539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26538_26539 : H12AffineEnvironment.transform 21 32 env26538 = env26539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26538 == env26539) = true)

theorem identity26539 : scanCanonicalize (H12AffineFastState.compose env26539 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26539 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,262144,1024,8540,78018,32,8388608,73736,8328,64,8787197,79130,8466458,8795349,8389957,73890,256,8462514,8467907,8462995]

theorem envBound26540 : H12AffineFastState.Bounded env26540 := by
  intro p hp
  have h : env26540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26539_26540 : H12AffineEnvironment.transform 14 8541 env26539 = env26540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26539 == env26540) = true)

def env26541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,10400,1024,8540,78018,32,8388608,73736,8328,64,8535133,79130,8466458,8526965,8389957,73890,256,8462514,8467907,8462995]

theorem envBound26541 : H12AffineFastState.Bounded env26541 := by
  intro p hp
  have h : env26541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26540_26541 : H12AffineEnvironment.transform 17 10400 env26540 = env26541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env26540 == env26541) = true)

theorem identity26541 : scanCanonicalize (H12AffineFastState.compose env26541 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73874) := by decide +kernel

theorem selectedBound26541 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,10400,1024,8540,78018,32,73874,73736,8328,64,203983,79130,4232,212199,75223,73890,256,32,5457,513]

theorem envBound26542 : H12AffineFastState.Bounded env26542 := by
  intro p hp
  have h : env26542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26541_26542 : H12AffineEnvironment.transform 22 73874 env26541 = env26542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73874 env26541 == env26542) = true)

theorem identity26542 : scanCanonicalize (H12AffineFastState.compose env26542 (packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound26542 : packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS < 2^1333 := by decide +kernel

def env26543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,79131,10400,1024,8540,78018,32,73874,73736,8328,64,10708,79130,4232,2556,75223,73890,256,32,5457,513]

theorem envBound26543 : H12AffineFastState.Bounded env26543 := by
  intro p hp
  have h : env26543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26542_26543 : H12AffineEnvironment.transform 16 79131 env26542 = env26543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env26542 == env26543) = true)

theorem identity26543 : scanCanonicalize (H12AffineFastState.compose env26543 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26543 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env26544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,8203,5392,10400,1024,8540,4297,32,153,3,8328,64,10708,5393,4232,2556,1500,169,256,32,5457,513]

theorem envBound26544 : H12AffineFastState.Bounded env26544 := by
  intro p hp
  have h : env26544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26543_26544 : H12AffineEnvironment.transform 15 8203 env26543 = env26544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26543 == env26544) = true)

theorem identity26544 : scanCanonicalize (H12AffineFastState.compose env26544 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26544 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env26545 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8203,5392,10281,1024,8540,4160,32,16,3,8193,64,10589,5393,4097,2421,1365,32,256,32,5457,513]

theorem envBound26545 : H12AffineFastState.Bounded env26545 := by
  intro p hp
  have h : env26545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26544_26545 : H12AffineEnvironment.transform 6 9 env26544 = env26545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26544 == env26545) = true)

theorem identity26545 : scanCanonicalize (H12AffineFastState.compose env26545 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26545 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26546 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8203,5392,10281,1024,8461,4113,32,16,3,8193,17,10508,5393,4097,2340,1284,32,256,32,5376,513]

theorem envBound26546 : H12AffineFastState.Bounded env26546 := by
  intro p hp
  have h : env26546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26545_26546 : H12AffineEnvironment.transform 5 17 env26545 = env26546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26545 == env26546) = true)

theorem identity26546 : scanCanonicalize (H12AffineFastState.compose env26546 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1304) := by decide +kernel

theorem selectedBound26546 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26547 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1304,5376,1044,1299,5392,3377,1024,1045,4113,32,16,3,1305,17,3092,5393,4097,2340,1284,32,256,32,5376,513]

theorem envBound26547 : H12AffineFastState.Bounded env26547 := by
  intro p hp
  have h : env26547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26546_26547 : H12AffineEnvironment.transform 12 1304 env26546 = env26547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1304 env26546 == env26547) = true)

theorem identity26547 : scanCanonicalize (H12AffineFastState.compose env26547 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26547 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26548 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,300,4404,32,295,4388,2309,52,33,4113,32,16,3,301,17,2080,4389,4097,2340,304,32,256,32,4404,513]

theorem envBound26548 : H12AffineFastState.Bounded env26548 := by
  intro p hp
  have h : env26548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26547_26548 : H12AffineEnvironment.transform 9 52 env26547 = env26548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26547 == env26548) = true)

theorem identity26548 : scanCanonicalize (H12AffineFastState.compose env26548 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound26548 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env26549 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2325,300,2081,32,295,2097,2309,52,33,2308,32,16,3,301,17,2080,2096,2324,2340,304,32,256,32,2081,513]

theorem envBound26549 : H12AffineFastState.Bounded env26549 := by
  intro p hp
  have h : env26549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26548_26549 : H12AffineEnvironment.transform 11 2325 env26548 = env26549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env26548 == env26549) = true)

theorem identity26549 : scanCanonicalize (H12AffineFastState.compose env26549 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound26549 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26550 : List Nat := [2,4,8,16,32,17,9,256,276,52,2048,2325,300,2081,32,295,2097,2309,52,33,2308,32,16,3,301,17,2080,2096,2324,2340,304,32,256,32,2081,277]

theorem envBound26550 : H12AffineFastState.Bounded env26550 := by
  intro p hp
  have h : env26550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26549_26550 : H12AffineEnvironment.transform 8 276 env26549 = env26550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env26549 == env26550) = true)

theorem identity26550 : scanCanonicalize (H12AffineFastState.compose env26550 (packedSelected [0,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26550 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env26551 : List Nat := [2,4,8,16,32,17,9,36,48,52,2048,2097,8,2081,32,3,2097,2081,52,33,2080,32,16,3,9,17,2080,2096,2096,2048,20,32,36,32,2081,49]

theorem envBound26551 : H12AffineFastState.Bounded env26551 := by
  intro p hp
  have h : env26551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26550_26551 : H12AffineEnvironment.transform 7 36 env26550 = env26551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26550 == env26551) = true)

theorem identity26551 : scanCanonicalize (H12AffineFastState.compose env26551 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound26551 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26552 : List Nat := [2,4,8,16,32,17,9,36,48,52,48,1,8,17,32,3,1,17,52,33,16,32,16,3,9,17,16,0,0,48,20,32,36,32,17,49]

theorem envBound26552 : H12AffineFastState.Bounded env26552 := by
  intro p hp
  have h : env26552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26551_26552 : H12AffineEnvironment.transform 10 48 env26551 = env26552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env26551 == env26552) = true)

theorem identity26552 : scanCanonicalize (H12AffineFastState.compose env26552 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound26552 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26553 : List Nat := [2,4,8,16,16,17,9,20,0,4,0,1,8,17,16,3,1,17,4,17,16,16,16,3,9,17,16,0,0,0,20,16,20,16,17,1]

theorem envBound26553 : H12AffineFastState.Bounded env26553 := by
  intro p hp
  have h : env26553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26552_26553 : H12AffineEnvironment.transform 4 16 env26552 = env26553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env26552 == env26553) = true)

theorem identity26553 : scanCanonicalize (H12AffineFastState.compose env26553 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26553 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26554 : List Nat := [2,4,8,0,0,1,9,4,0,4,0,1,8,1,0,3,1,1,4,1,0,0,0,3,9,1,0,0,0,0,4,0,4,0,1,1]

theorem envBound26554 : H12AffineFastState.Bounded env26554 := by
  intro p hp
  have h : env26554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26553_26554 : H12AffineEnvironment.transform 3 0 env26553 = env26554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26553 == env26554) = true)

def env26555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,10401,1024,8540,78018,32,8388608,73736,8328,64,8535132,79130,8466458,8526964,8389957,73890,256,8462514,8467907,8462995]

theorem envBound26555 : H12AffineFastState.Bounded env26555 := by
  intro p hp
  have h : env26555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26540_26555 : H12AffineEnvironment.transform 17 10401 env26540 = env26555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env26540 == env26555) = true)

theorem identity26555 : scanCanonicalize (H12AffineFastState.compose env26555 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound26555 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,8322,131072,10401,1024,8540,4160,32,8388608,138,8328,64,8535132,5528,8392856,8526964,8389957,32,256,8388656,8394049,8389137]

theorem envBound26556 : H12AffineFastState.Bounded env26556 := by
  intro p hp
  have h : env26556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26555_26556 : H12AffineEnvironment.transform 15 8322 env26555 = env26556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env26555 == env26556) = true)

theorem identity26556 : scanCanonicalize (H12AffineFastState.compose env26556 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound26556 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env26557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,8322,5392,10401,1024,8540,4160,32,8388608,138,8328,64,8399180,5528,8392856,8391012,8389957,32,256,8388656,8394049,8389137]

theorem envBound26557 : H12AffineFastState.Bounded env26557 := by
  intro p hp
  have h : env26557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26556_26557 : H12AffineEnvironment.transform 16 5392 env26556 = env26557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env26556 == env26557) = true)

theorem identity26557 : scanCanonicalize (H12AffineFastState.compose env26557 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(22+1) ^^^ 8597) := by decide +kernel

theorem selectedBound26557 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env26558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,8322,5392,10401,1024,8540,4160,32,8597,138,8328,64,2265,5528,12557,10481,9424,32,256,8613,13524,9092]

theorem envBound26558 : H12AffineFastState.Bounded env26558 := by
  intro p hp
  have h : env26558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26557_26558 : H12AffineEnvironment.transform 22 8597 env26557 = env26558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 8597 env26557 == env26558) = true)

theorem identity26558 : scanCanonicalize (H12AffineFastState.compose env26558 (packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound26558 : packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env26559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,81,398,5392,2477,1024,80,4160,32,153,138,388,64,2265,5528,4097,2557,1500,32,256,169,5592,648]

theorem envBound26559 : H12AffineFastState.Bounded env26559 := by
  intro p hp
  have h : env26559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26558_26559 : H12AffineEnvironment.transform 12 268 env26558 = env26559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env26558 == env26559) = true)

theorem identity26559 : scanCanonicalize (H12AffineFastState.compose env26559 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26559 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env26560 : List Nat := [2,4,8,16,32,64,128,256,512,53,2048,4096,268,4540,81,398,4389,2477,53,80,4160,32,153,138,388,64,2265,4525,4097,2557,489,32,256,169,4589,648]

theorem envBound26560 : H12AffineFastState.Bounded env26560 := by
  intro p hp
  have h : env26560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26559_26560 : H12AffineEnvironment.transform 9 53 env26559 = env26560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26559 == env26560) = true)

theorem identity26560 : scanCanonicalize (H12AffineFastState.compose env26560 (packedSelected [1,2,3,5,6,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound26560 : packedSelected [1,2,3,5,6,8,11,12] rootPS < 2^1333 := by decide +kernel

def env26561 : List Nat := [2,4,8,16,32,64,128,256,512,53,2048,2356,268,2184,81,398,2065,2477,53,80,2420,32,153,138,388,64,2265,2201,2357,2557,489,32,256,169,2265,648]

theorem envBound26561 : H12AffineFastState.Bounded env26561 := by
  intro p hp
  have h : env26561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26560_26561 : H12AffineEnvironment.transform 11 2356 env26560 = env26561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env26560 == env26561) = true)

theorem identity26561 : scanCanonicalize (H12AffineFastState.compose env26561 (packedSelected [0,2,6,7,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26561 : packedSelected [0,2,6,7,14] rootPS < 2^1333 := by decide +kernel

def env26562 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2356,268,2049,81,263,2065,2340,53,80,2420,32,16,3,269,64,2128,2064,2357,2420,352,32,256,32,2128,513]

theorem envBound26562 : H12AffineFastState.Bounded env26562 := by
  intro p hp
  have h : env26562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26561_26562 : H12AffineEnvironment.transform 6 9 env26561 = env26562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26561 == env26562) = true)

def env26563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,33,8388608,98645,8328,64,8787196,79130,8466458,8820104,8389957,98814,256,8462514,8492190,8462995]

theorem envBound26563 : H12AffineFastState.Bounded env26563 := by
  intro p hp
  have h : env26563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26538_26563 : H12AffineEnvironment.transform 21 33 env26538 = env26563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26538 == env26563) = true)

theorem identity26563 : scanCanonicalize (H12AffineFastState.compose env26563 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 41293) := by decide +kernel

theorem selectedBound26563 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,33,41293,98645,8328,64,439729,79130,102743,406725,41992,98814,256,98815,79315,99294]

theorem envBound26564 : H12AffineFastState.Bounded env26564 := by
  intro p hp
  have h : env26564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26563_26564 : H12AffineEnvironment.transform 22 41293 env26563 = env26564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41293 env26563 == env26564) = true)

theorem identity26564 : scanCanonicalize (H12AffineFastState.compose env26564 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound26564 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env26565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,108927,1024,32769,78018,33,41293,98645,8328,64,203982,79130,102743,236986,41992,98814,256,98815,79315,99294]

theorem envBound26565 : H12AffineFastState.Bounded env26565 := by
  intro p hp
  have h : env26565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26564_26565 : H12AffineEnvironment.transform 17 108927 env26564 = env26565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env26564 == env26565) = true)

def env26566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,131072,67619,1024,8541,78018,33,17,73737,8328,64,203982,79130,77835,212198,1364,73890,256,73891,79315,74370]

theorem envBound26566 : H12AffineFastState.Bounded env26566 := by
  intro p hp
  have h : env26566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26565_26566 : H12AffineEnvironment.transform 14 8540 env26565 = env26566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26565 == env26566) = true)

theorem identity26566 : scanCanonicalize (H12AffineFastState.compose env26566 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26566 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26567 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,67619,1024,8541,77898,33,17,73737,8192,64,203846,79130,77835,212078,1364,73770,256,73771,79195,74250]

theorem envBound26567 : H12AffineFastState.Bounded env26567 := by
  intro p hp
  have h : env26567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26566_26567 : H12AffineEnvironment.transform 6 8 env26566 = env26567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26566 == env26567) = true)

theorem identity26567 : scanCanonicalize (H12AffineFastState.compose env26567 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound26567 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env26568 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,262,131072,2341,1024,8541,12620,33,17,8463,8192,64,138560,13340,12557,146792,1364,8492,256,8493,13405,8972]

theorem envBound26568 : H12AffineFastState.Bounded env26568 := by
  intro p hp
  have h : env26568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26567_26568 : H12AffineEnvironment.transform 15 262 env26567 = env26568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env26567 == env26568) = true)

theorem identity26568 : scanCanonicalize (H12AffineFastState.compose env26568 (packedSelected [0,4,6,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound26568 : packedSelected [0,4,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env26569 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4112,8540,262,131072,2341,273,8541,12620,33,17,8463,8192,64,137297,12557,12557,145529,69,8492,256,8493,12620,8972]

theorem envBound26569 : H12AffineFastState.Bounded env26569 := by
  intro p hp
  have h : env26569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26568_26569 : H12AffineEnvironment.transform 9 273 env26568 = env26569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env26568 == env26569) = true)

theorem identity26569 : scanCanonicalize (H12AffineFastState.compose env26569 (packedSelected [0,1,2,8,9,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound26569 : packedSelected [0,1,2,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env26570 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4112,8540,262,4096,2341,273,8541,12620,33,17,8463,8192,64,2129,12557,12557,10361,69,8492,256,8493,12620,8972]

theorem envBound26570 : H12AffineFastState.Bounded env26570 := by
  intro p hp
  have h : env26570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26569_26570 : H12AffineEnvironment.transform 16 4096 env26569 = env26570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env26569 == env26570) = true)

theorem identity26570 : scanCanonicalize (H12AffineFastState.compose env26570 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound26570 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env26571 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,268,4112,80,262,4096,2341,273,81,4160,33,17,3,268,64,2129,4097,4097,2421,69,32,256,33,4160,512]

theorem envBound26571 : H12AffineFastState.Bounded env26571 := by
  intro p hp
  have h : env26571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26570_26571 : H12AffineEnvironment.transform 12 268 env26570 = env26571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env26570 == env26571) = true)

theorem identity26571 : scanCanonicalize (H12AffineFastState.compose env26571 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound26571 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26572 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,325,268,341,80,262,325,2341,273,81,261,33,17,3,268,64,2129,324,324,2421,69,32,256,33,261,512]

theorem envBound26572 : H12AffineFastState.Bounded env26572 := by
  intro p hp
  have h : env26572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26571_26572 : H12AffineEnvironment.transform 11 325 env26571 = env26572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env26571 == env26572) = true)

theorem identity26572 : scanCanonicalize (H12AffineFastState.compose env26572 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound26572 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env26573 : List Nat := [2,4,8,16,32,64,8,84,512,69,2048,17,88,1,80,82,17,2161,69,81,81,33,17,3,88,64,2129,16,16,2081,69,32,84,33,81,512]

theorem envBound26573 : H12AffineFastState.Bounded env26573 := by
  intro p hp
  have h : env26573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26572_26573 : H12AffineEnvironment.transform 7 84 env26572 = env26573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env26572 == env26573) = true)

theorem identity26573 : scanCanonicalize (H12AffineFastState.compose env26573 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26573 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26574 : List Nat := [2,4,8,16,0,64,8,84,512,69,2048,17,88,1,80,82,17,2129,69,81,81,1,17,3,88,64,2129,16,16,2049,69,0,84,1,81,512]

theorem envBound26574 : H12AffineFastState.Bounded env26574 := by
  intro p hp
  have h : env26574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26573_26574 : H12AffineEnvironment.transform 4 0 env26573 = env26574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26573 == env26574) = true)

theorem identity26574 : scanCanonicalize (H12AffineFastState.compose env26574 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26574 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26575 : List Nat := [2,4,8,16,0,17,8,5,512,20,2048,17,9,1,1,3,17,2048,20,0,0,1,17,3,9,17,2048,16,16,2049,20,0,5,1,0,512]

theorem envBound26575 : H12AffineFastState.Bounded env26575 := by
  intro p hp
  have h : env26575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26574_26575 : H12AffineEnvironment.transform 5 17 env26574 = env26575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26574 == env26575) = true)

theorem identity26575 : scanCanonicalize (H12AffineFastState.compose env26575 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 527) := by decide +kernel

theorem selectedBound26575 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26576 : List Nat := [2,4,8,16,0,17,8,5,512,20,527,17,9,1,1,3,17,527,20,0,0,1,17,3,9,17,527,16,16,526,20,0,5,1,0,512]

theorem envBound26576 : H12AffineFastState.Bounded env26576 := by
  intro p hp
  have h : env26576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26575_26576 : H12AffineEnvironment.transform 10 527 env26575 = env26576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 527 env26575 == env26576) = true)

theorem identity26576 : scanCanonicalize (H12AffineFastState.compose env26576 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound26576 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env26577 : List Nat := [2,4,8,16,0,17,8,5,14,20,1,17,9,1,1,3,17,1,20,0,0,1,17,3,9,17,1,16,16,0,20,0,5,1,0,14]

theorem envBound26577 : H12AffineFastState.Bounded env26577 := by
  intro p hp
  have h : env26577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26576_26577 : H12AffineEnvironment.transform 8 14 env26576 = env26577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env26576 == env26577) = true)

def env26578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,67618,1024,8540,78018,33,16,73736,8328,64,203982,79130,77834,212199,1365,73891,256,73890,79315,74371]

theorem envBound26578 : H12AffineFastState.Bounded env26578 := by
  intro p hp
  have h : env26578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26565_26578 : H12AffineEnvironment.transform 14 8541 env26565 = env26578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26565 == env26578) = true)

theorem identity26578 : scanCanonicalize (H12AffineFastState.compose env26578 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound26578 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,8322,131072,10400,1024,8540,4160,33,16,138,8328,64,146508,5528,4232,138341,1365,33,256,32,5457,513]

theorem envBound26579 : H12AffineFastState.Bounded env26579 := by
  intro p hp
  have h : env26579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26578_26579 : H12AffineEnvironment.transform 15 8322 env26578 = env26579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env26578 == env26579) = true)

theorem identity26579 : scanCanonicalize (H12AffineFastState.compose env26579 (packedSelected [0,1,2,4,6,7,8,9,10,11,15,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound26579 : packedSelected [0,1,2,4,6,7,8,9,10,11,15,20] rootPS < 2^1333 := by decide +kernel

def env26580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,8322,5393,10400,1024,8540,4160,33,16,138,8328,64,10589,5528,4232,2420,1365,33,256,32,5457,513]

theorem envBound26580 : H12AffineFastState.Bounded env26580 := by
  intro p hp
  have h : env26580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26579_26580 : H12AffineEnvironment.transform 16 5393 env26579 = env26580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env26579 == env26580) = true)

theorem identity26580 : scanCanonicalize (H12AffineFastState.compose env26580 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound26580 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env26581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,342,5393,2420,1024,136,4160,33,16,138,348,64,2185,5528,4232,2420,1365,33,256,32,5457,513]

theorem envBound26581 : H12AffineFastState.Bounded env26581 := by
  intro p hp
  have h : env26581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26580_26581 : H12AffineEnvironment.transform 12 468 env26580 = env26581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env26580 == env26581) = true)

theorem identity26581 : scanCanonicalize (H12AffineFastState.compose env26581 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26581 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env26582 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,5393,2420,1024,1,4160,33,16,3,348,64,2048,5393,4097,2420,1365,33,256,32,5457,513]

theorem envBound26582 : H12AffineFastState.Bounded env26582 := by
  intro p hp
  have h : env26582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26581_26582 : H12AffineEnvironment.transform 6 9 env26581 = env26582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26581 == env26582) = true)

theorem identity26582 : scanCanonicalize (H12AffineFastState.compose env26582 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1135) := by decide +kernel

theorem selectedBound26582 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1135,4096,349,5376,0,342,5393,1307,1024,1,4160,33,16,3,348,64,1135,5393,4097,1307,1365,33,256,32,5457,513]

theorem envBound26583 : H12AffineFastState.Bounded env26583 := by
  intro p hp
  have h : env26583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26582_26583 : H12AffineEnvironment.transform 10 1135 env26582 = env26583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1135 env26582 == env26583) = true)

theorem identity26583 : scanCanonicalize (H12AffineFastState.compose env26583 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26583 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26584 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1087,4096,269,5376,0,262,5393,1307,1024,1,4112,33,16,3,268,16,1087,5393,4097,1307,1285,33,256,32,5377,513]

theorem envBound26584 : H12AffineFastState.Bounded env26584 := by
  intro p hp
  have h : env26584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26583_26584 : H12AffineEnvironment.transform 5 16 env26583 = env26584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26583 == env26584) = true)

theorem identity26584 : scanCanonicalize (H12AffineFastState.compose env26584 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound26584 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26585 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1087,1,269,1281,0,262,1296,1307,1024,1,17,33,16,3,268,16,1087,1296,0,1307,1285,33,256,32,1280,513]

theorem envBound26585 : H12AffineFastState.Bounded env26585 := by
  intro p hp
  have h : env26585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26584_26585 : H12AffineEnvironment.transform 11 1 env26584 = env26585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env26584 == env26585) = true)

theorem identity26585 : scanCanonicalize (H12AffineFastState.compose env26585 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound26585 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26586 : List Nat := [2,4,8,16,32,16,9,5,512,1024,1087,1,8,1028,0,3,1045,1054,1024,1,17,33,16,3,9,16,1087,1045,0,1054,1024,33,5,32,1029,513]

theorem envBound26586 : H12AffineFastState.Bounded env26586 := by
  intro p hp
  have h : env26586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26585_26586 : H12AffineEnvironment.transform 7 5 env26585 = env26586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env26585 == env26586) = true)

theorem identity26586 : scanCanonicalize (H12AffineFastState.compose env26586 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26586 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26587 : List Nat := [2,4,8,16,32,16,9,5,512,52,11,1,8,48,0,3,33,42,52,1,17,33,16,3,9,16,11,33,0,42,52,33,5,32,49,513]

theorem envBound26587 : H12AffineFastState.Bounded env26587 := by
  intro p hp
  have h : env26587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26586_26587 : H12AffineEnvironment.transform 9 52 env26586 = env26587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26586 == env26587) = true)

theorem identity26587 : scanCanonicalize (H12AffineFastState.compose env26587 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound26587 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26588 : List Nat := [2,4,8,16,7,16,9,5,512,19,11,1,8,23,0,3,6,13,19,1,17,6,16,3,9,16,11,6,0,13,19,6,5,7,22,513]

theorem envBound26588 : H12AffineFastState.Bounded env26588 := by
  intro p hp
  have h : env26588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26587_26588 : H12AffineEnvironment.transform 4 7 env26587 = env26588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env26587 == env26588) = true)

theorem identity26588 : scanCanonicalize (H12AffineFastState.compose env26588 (packedSelected [0,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26588 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env26589 : List Nat := [2,2,8,16,1,16,9,3,512,19,11,1,8,17,0,3,0,11,19,1,17,0,16,3,9,16,11,0,0,11,19,0,3,1,16,513]

theorem envBound26589 : H12AffineFastState.Bounded env26589 := by
  intro p hp
  have h : env26589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26588_26589 : H12AffineEnvironment.transform 1 2 env26588 = env26589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26588 == env26589) = true)

theorem identity26589 : scanCanonicalize (H12AffineFastState.compose env26589 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound26589 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26590 : List Nat := [2,2,8,16,1,16,9,3,8,19,11,1,8,17,0,3,0,11,19,1,17,0,16,3,9,16,11,0,0,11,19,0,3,1,16,9]

theorem envBound26590 : H12AffineFastState.Bounded env26590 := by
  intro p hp
  have h : env26590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26589_26590 : H12AffineEnvironment.transform 8 8 env26589 = env26590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env26589 == env26590) = true)

def env26591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91467,4194304,8388608,120029,8328,64,12981468,79131,8466458,8830977,8409293,4314199,256,8484154,8492191,8484635]

theorem envBound26591 : H12AffineFastState.Bounded env26591 := by
  intro p hp
  have h : env26591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26496_26591 : H12AffineEnvironment.transform 23 120029 env26496 = env26591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 120029 env26496 == env26591) = true)

def env26592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98645,8328,64,12981468,79131,8466458,8820105,8389957,4293087,256,8462514,8492191,8462995]

theorem envBound26592 : H12AffineFastState.Bounded env26592 := by
  intro p hp
  have h : env26592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26591_26592 : H12AffineEnvironment.transform 13 5512 env26591 = env26592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env26591 == env26592) = true)

def env26593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,32,8388608,98645,8328,64,8787196,79131,8466458,8820105,8389957,98815,256,8462514,8492191,8462995]

theorem envBound26593 : H12AffineFastState.Bounded env26593 := by
  intro p hp
  have h : env26593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26592_26593 : H12AffineEnvironment.transform 21 32 env26592 = env26593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26592 == env26593) = true)

theorem identity26593 : scanCanonicalize (H12AffineFastState.compose env26593 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98767) := by decide +kernel

theorem selectedBound26593 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,32,98767,98645,8328,64,496947,79131,45525,463942,99466,98815,256,41341,5456,41820]

theorem envBound26594 : H12AffineFastState.Bounded env26594 := by
  intro p hp
  have h : env26594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26593_26594 : H12AffineEnvironment.transform 22 98767 env26593 = env26594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98767 env26593 == env26594) = true)

theorem identity26594 : scanCanonicalize (H12AffineFastState.compose env26594 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26594 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env26595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,262144,1024,8540,78019,32,73874,73736,8328,64,472174,79131,4232,463942,75223,73890,256,32,5456,513]

theorem envBound26595 : H12AffineFastState.Bounded env26595 := by
  intro p hp
  have h : env26595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26594_26595 : H12AffineEnvironment.transform 14 8541 env26594 = env26595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26594 == env26595) = true)

def env26596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,10400,1024,8540,78019,32,73874,73736,8328,64,203982,79131,4232,212198,75223,73890,256,32,5456,513]

theorem envBound26596 : H12AffineFastState.Bounded env26596 := by
  intro p hp
  have h : env26596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26595_26596 : H12AffineEnvironment.transform 17 10400 env26595 = env26596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env26595 == env26596) = true)

theorem identity26596 : scanCanonicalize (H12AffineFastState.compose env26596 (packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound26596 : packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS < 2^1333 := by decide +kernel

def env26597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,79130,10400,1024,8540,78019,32,73874,73736,8328,64,10708,79131,4232,2556,75223,73890,256,32,5456,513]

theorem envBound26597 : H12AffineFastState.Bounded env26597 := by
  intro p hp
  have h : env26597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26596_26597 : H12AffineEnvironment.transform 16 79130 env26596 = env26597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env26596 == env26597) = true)

theorem identity26597 : scanCanonicalize (H12AffineFastState.compose env26597 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26597 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env26598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8203,5393,10400,1024,8540,4296,32,153,3,8328,64,10708,5392,4232,2556,1500,169,256,32,5456,513]

theorem envBound26598 : H12AffineFastState.Bounded env26598 := by
  intro p hp
  have h : env26598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26597_26598 : H12AffineEnvironment.transform 15 8203 env26597 = env26598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26597 == env26598) = true)

theorem identity26598 : scanCanonicalize (H12AffineFastState.compose env26598 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26598 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env26599 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,5393,10281,1024,8540,4161,32,16,3,8193,64,10589,5392,4097,2421,1365,32,256,32,5456,513]

theorem envBound26599 : H12AffineFastState.Bounded env26599 := by
  intro p hp
  have h : env26599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26598_26599 : H12AffineEnvironment.transform 6 9 env26598 = env26599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26598 == env26599) = true)

theorem identity26599 : scanCanonicalize (H12AffineFastState.compose env26599 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26599 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26600 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,8203,5393,10281,1024,8461,4112,32,16,3,8193,17,10508,5392,4097,2340,1284,32,256,32,5377,513]

theorem envBound26600 : H12AffineFastState.Bounded env26600 := by
  intro p hp
  have h : env26600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26599_26600 : H12AffineEnvironment.transform 5 17 env26599 = env26600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26599 == env26600) = true)

theorem identity26600 : scanCanonicalize (H12AffineFastState.compose env26600 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound26600 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26601 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1305,5377,1045,1298,5393,3376,1024,1044,4112,32,16,3,1304,17,3093,5392,4097,2340,1284,32,256,32,5377,513]

theorem envBound26601 : H12AffineFastState.Bounded env26601 := by
  intro p hp
  have h : env26601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26600_26601 : H12AffineEnvironment.transform 12 1305 env26600 = env26601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env26600 == env26601) = true)

theorem identity26601 : scanCanonicalize (H12AffineFastState.compose env26601 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26601 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1