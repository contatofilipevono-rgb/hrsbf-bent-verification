import H12CloudChart1Data032

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound8188 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8189 : List Nat := [2,4,8,16,32,1,57,5,512,5,522,545,8192,1,8201,8714,545,555,5,8201,1,513,16,531,8240,16,523,17,16,10,4,16,5,544,545,49]

theorem envBound8189 : H12AffineFastState.Bounded env8189 := by
  intro p hp
  have h : env8189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8188_8189 : H12AffineEnvironment.transform 10 522 env8188 = env8189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env8188 == env8189) = true)

theorem identity8189 : scanCanonicalize (H12AffineFastState.compose env8189 (packedSelected [0,3,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8189 : packedSelected [0,3,7,8] rootPS < 2^1333 := by decide +kernel

def env8190 : List Nat := [2,4,8,16,1,1,24,5,512,5,522,512,8192,1,8201,8714,512,522,5,8201,1,513,16,531,8209,16,523,17,16,10,4,16,5,513,512,16]

theorem envBound8190 : H12AffineFastState.Bounded env8190 := by
  intro p hp
  have h : env8190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8189_8190 : H12AffineEnvironment.transform 4 1 env8189 = env8190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8189 == env8190) = true)

theorem identity8190 : scanCanonicalize (H12AffineFastState.compose env8190 (packedSelected [2,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound8190 : packedSelected [2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env8191 : List Nat := [2,4,8,16,1,1,24,5,512,5,522,512,25,1,16,531,512,522,5,16,1,513,16,531,8,16,523,17,16,10,4,16,5,513,512,16]

theorem envBound8191 : H12AffineFastState.Bounded env8191 := by
  intro p hp
  have h : env8191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8190_8191 : H12AffineEnvironment.transform 12 25 env8190 = env8191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env8190 == env8191) = true)

theorem identity8191 : scanCanonicalize (H12AffineFastState.compose env8191 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound8191 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8192 : List Nat := [2,4,8,16,1,1,24,5,11,5,1,11,25,1,16,24,11,1,5,16,1,10,16,24,8,16,0,17,16,10,4,16,5,10,11,16]

theorem envBound8192 : H12AffineFastState.Bounded env8192 := by
  intro p hp
  have h : env8192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8191_8192 : H12AffineEnvironment.transform 8 11 env8191 = env8192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env8191 == env8192) = true)

theorem identity8192 : scanCanonicalize (H12AffineFastState.compose env8192 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8193 : List Nat := [2,4,2,16,1,1,18,5,1,5,1,1,19,1,16,18,1,1,5,16,1,0,16,18,2,16,0,17,16,0,4,16,5,0,1,16]

theorem envBound8193 : H12AffineFastState.Bounded env8193 := by
  intro p hp
  have h : env8193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8192_8193 : H12AffineEnvironment.transform 2 2 env8192 = env8193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8192 == env8193) = true)

theorem identity8193 : scanCanonicalize (H12AffineFastState.compose env8193 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8193 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8194 : List Nat := [2,4,2,1,1,1,3,5,1,5,1,1,2,1,1,3,1,1,5,1,1,0,1,3,2,1,0,0,1,0,4,1,5,0,1,1]

theorem envBound8194 : H12AffineFastState.Bounded env8194 := by
  intro p hp
  have h : env8194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8193_8194 : H12AffineEnvironment.transform 3 1 env8193 = env8194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8193 == env8194) = true)

def env8195 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,4641,8201,8778,4096,262144,4644,8201,64,262186,4720,4146,8240,17,266817,262778,262779,2624,4,262779,4644,608,4097,4624]

theorem envBound8195 : H12AffineFastState.Bounded env8195 := by
  intro p hp
  have h : env8195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8175_8195 : H12AffineEnvironment.transform 13 4641 env8175 = env8195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4641 env8175 == env8195) = true)

def env8196 : List Nat := [2,4,8,16,32,0,57,4,512,4,2048,4096,8192,4641,8201,8714,4096,262144,4644,8201,0,262186,4656,4146,8240,17,266753,262714,262715,2560,4,262715,4644,544,4097,4624]

theorem envBound8196 : H12AffineFastState.Bounded env8196 := by
  intro p hp
  have h : env8196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8195_8196 : H12AffineEnvironment.transform 5 0 env8195 = env8196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8195 == env8196) = true)

theorem identity8196 : scanCanonicalize (H12AffineFastState.compose env8196 (packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound8196 : packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8197 : List Nat := [2,4,8,16,32,0,57,4,512,4,58,4096,8192,4641,8201,8714,4096,262144,4644,8201,0,262186,4656,4146,8240,17,266753,262714,262715,570,4,262715,4644,544,4097,4624]

theorem envBound8197 : H12AffineFastState.Bounded env8197 := by
  intro p hp
  have h : env8197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8196_8197 : H12AffineEnvironment.transform 10 58 env8196 = env8197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env8196 == env8197) = true)

theorem identity8197 : scanCanonicalize (H12AffineFastState.compose env8197 (packedSelected [0,1,5,7,10,12,14,15,20] rootPS)) = affineNative (2^(17+1) ^^^ 4667) := by decide +kernel

theorem selectedBound8197 : packedSelected [0,1,5,7,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env8198 : List Nat := [2,4,8,16,32,0,57,4,512,4,58,4096,8192,4641,8201,8714,4096,4667,4644,8201,0,4625,4656,4146,8240,17,58,4097,4096,570,4,4096,4644,544,4097,4624]

theorem envBound8198 : H12AffineFastState.Bounded env8198 := by
  intro p hp
  have h : env8198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8197_8198 : H12AffineEnvironment.transform 17 4667 env8197 = env8198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4667 env8197 == env8198) = true)

theorem identity8198 : scanCanonicalize (H12AffineFastState.compose env8198 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound8198 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8199 : List Nat := [2,4,8,16,32,0,57,4,512,4,58,560,8192,17,8201,8714,560,11,20,8201,0,33,0,514,8240,17,58,561,560,570,4,560,20,544,561,32]

theorem envBound8199 : H12AffineFastState.Bounded env8199 := by
  intro p hp
  have h : env8199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8198_8199 : H12AffineEnvironment.transform 11 560 env8198 = env8199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env8198 == env8199) = true)

theorem identity8199 : scanCanonicalize (H12AffineFastState.compose env8199 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound8199 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8200 : List Nat := [2,4,8,16,32,0,57,4,0,4,58,48,8192,17,8201,8202,48,11,20,8201,0,33,0,2,8240,17,58,49,48,58,4,48,20,32,49,32]

theorem envBound8200 : H12AffineFastState.Bounded env8200 := by
  intro p hp
  have h : env8200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8199_8200 : H12AffineEnvironment.transform 8 0 env8199 = env8200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env8199 == env8200) = true)

theorem identity8200 : scanCanonicalize (H12AffineFastState.compose env8200 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8200 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8201 : List Nat := [2,4,8,16,27,0,2,4,0,4,1,11,8192,17,8201,8202,11,11,20,8201,0,26,0,2,8203,17,1,10,11,1,4,11,20,27,10,27]

theorem envBound8201 : H12AffineFastState.Bounded env8201 := by
  intro p hp
  have h : env8201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8200_8201 : H12AffineEnvironment.transform 4 27 env8200 = env8201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8200 == env8201) = true)

theorem identity8201 : scanCanonicalize (H12AffineFastState.compose env8201 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound8201 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8202 : List Nat := [2,4,8,16,27,0,2,4,0,4,1,11,25,17,16,19,11,11,20,16,0,26,0,2,18,17,1,10,11,1,4,11,20,27,10,27]

theorem envBound8202 : H12AffineFastState.Bounded env8202 := by
  intro p hp
  have h : env8202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8201_8202 : H12AffineEnvironment.transform 12 25 env8201 = env8202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env8201 == env8202) = true)

theorem identity8202 : scanCanonicalize (H12AffineFastState.compose env8202 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8202 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8203 : List Nat := [2,4,3,16,16,0,2,4,0,4,1,0,18,17,16,19,0,0,20,16,0,17,0,2,18,17,1,1,0,1,4,0,20,16,1,16]

theorem envBound8203 : H12AffineFastState.Bounded env8203 := by
  intro p hp
  have h : env8203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8202_8203 : H12AffineEnvironment.transform 2 3 env8202 = env8203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8202 == env8203) = true)

def env8204 : List Nat := [2,4,8,16,32,1,57,5,512,5,2048,4096,8192,4641,8201,8715,4096,262144,4644,8201,1,262186,4657,4146,8240,17,266752,262715,262714,2561,4,262714,4644,545,4097,4624]

theorem envBound8204 : H12AffineFastState.Bounded env8204 := by
  intro p hp
  have h : env8204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8195_8204 : H12AffineEnvironment.transform 5 1 env8195 = env8204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8195 == env8204) = true)

theorem identity8204 : scanCanonicalize (H12AffineFastState.compose env8204 (packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound8204 : packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8205 : List Nat := [2,4,8,16,32,1,57,5,512,5,2048,4096,8192,4641,8201,8715,4096,2081,4644,8201,1,2059,4657,4146,8240,17,6689,2586,2587,2561,4,2587,4644,545,4097,4624]

theorem envBound8205 : H12AffineFastState.Bounded env8205 := by
  intro p hp
  have h : env8205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8204_8205 : H12AffineEnvironment.transform 17 2081 env8204 = env8205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env8204 == env8205) = true)

theorem identity8205 : scanCanonicalize (H12AffineFastState.compose env8205 (packedSelected [0,1,5,7,10,12,14,15,20] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound8205 : packedSelected [0,1,5,7,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env8206 : List Nat := [2,4,8,16,32,1,57,5,512,5,523,4096,8192,4641,8201,8715,4096,554,4644,8201,1,512,4657,4146,8240,17,4138,17,16,10,4,16,4644,545,4097,4624]

theorem envBound8206 : H12AffineFastState.Bounded env8206 := by
  intro p hp
  have h : env8206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8205_8206 : H12AffineEnvironment.transform 10 523 env8205 = env8206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env8205 == env8206) = true)

theorem identity8206 : scanCanonicalize (H12AffineFastState.compose env8206 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound8206 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8207 : List Nat := [2,4,8,16,32,1,57,5,512,5,523,544,8192,1,8201,8715,544,554,4,8201,1,512,17,530,8240,17,522,17,16,10,4,16,4,545,545,48]

theorem envBound8207 : H12AffineFastState.Bounded env8207 := by
  intro p hp
  have h : env8207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8206_8207 : H12AffineEnvironment.transform 11 544 env8206 = env8207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env8206 == env8207) = true)

theorem identity8207 : scanCanonicalize (H12AffineFastState.compose env8207 (packedSelected [0,3,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound8207 : packedSelected [0,3,7,8] rootPS < 2^1333 := by decide +kernel

def env8208 : List Nat := [2,4,8,16,32,1,57,5,10,5,1,42,8192,1,8201,8193,42,32,4,8201,1,10,17,24,8240,17,0,17,16,10,4,16,4,43,43,48]

theorem envBound8208 : H12AffineFastState.Bounded env8208 := by
  intro p hp
  have h : env8208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8207_8208 : H12AffineEnvironment.transform 8 10 env8207 = env8208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env8207 == env8208) = true)

theorem identity8208 : scanCanonicalize (H12AffineFastState.compose env8208 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound8208 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env8209 : List Nat := [2,4,8,16,32,1,57,5,10,5,1,42,57,1,48,56,42,32,4,48,1,10,17,24,9,17,0,17,16,10,4,16,4,43,43,48]

theorem envBound8209 : H12AffineFastState.Bounded env8209 := by
  intro p hp
  have h : env8209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8208_8209 : H12AffineEnvironment.transform 12 57 env8208 = env8209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env8208 == env8209) = true)

theorem identity8209 : scanCanonicalize (H12AffineFastState.compose env8209 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8209 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8210 : List Nat := [2,4,8,16,17,1,8,5,10,5,1,27,8,1,1,9,27,17,4,1,1,10,17,24,9,17,0,17,16,10,4,16,4,26,26,1]

theorem envBound8210 : H12AffineFastState.Bounded env8210 := by
  intro p hp
  have h : env8210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8209_8210 : H12AffineEnvironment.transform 4 17 env8209 = env8210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8209 == env8210) = true)

theorem identity8210 : scanCanonicalize (H12AffineFastState.compose env8210 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound8210 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8211 : List Nat := [2,4,8,11,10,1,8,5,10,5,1,0,8,1,1,9,0,10,4,1,1,10,10,3,9,10,0,10,11,10,4,11,4,1,1,1]

theorem envBound8211 : H12AffineFastState.Bounded env8211 := by
  intro p hp
  have h : env8211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8210_8211 : H12AffineEnvironment.transform 3 11 env8210 = env8211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env8210 == env8211) = true)

def env8212 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,65,4194304,4720,90336,8329,21040,278624,4214984,4214985,75786,4,4268194,4765,73770,78579,90818]

theorem envBound8212 : H12AffineFastState.Bounded env8212 := by
  intro p hp
  have h : env8212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8151_8212 : H12AffineEnvironment.transform 20 65 env8151 = env8212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8151 == env8212) = true)

theorem identity8212 : scanCanonicalize (H12AffineFastState.compose env8212 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 352920) := by decide +kernel

theorem selectedBound8212 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8213 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,65,352920,4720,90336,8329,21040,278624,340560,340561,75786,4,279098,4765,73770,78579,90818]

theorem envBound8213 : H12AffineFastState.Bounded env8213 := by
  intro p hp
  have h : env8213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8212_8213 : H12AffineEnvironment.transform 21 352920 env8212 = env8213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 352920 env8212 == env8213) = true)

def env8214 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,73944,4765,8201,65,16960,4720,90336,8329,21040,90296,4744,4745,75786,4,90850,4765,73770,78579,90818]

theorem envBound8214 : H12AffineFastState.Bounded env8214 := by
  intro p hp
  have h : env8214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8213_8214 : H12AffineEnvironment.transform 17 73944 env8213 = env8214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 73944 env8213 == env8214) = true)

def env8215 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8201,65536,4096,73944,4765,8201,65,112,4720,74448,8329,4096,74376,4744,4745,75786,4,73938,4765,73770,78579,73970]

theorem envBound8215 : H12AffineFastState.Bounded env8215 := by
  intro p hp
  have h : env8215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8214_8215 : H12AffineEnvironment.transform 13 560 env8214 = env8215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8214 == env8215) = true)

theorem identity8215 : scanCanonicalize (H12AffineFastState.compose env8215 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound8215 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8216 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8201,8715,4096,723,4765,8201,65,112,4720,219,8329,4096,131,4744,4745,2561,4,729,4765,545,4344,761]

theorem envBound8216 : H12AffineFastState.Bounded env8216 := by
  intro p hp
  have h : env8216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8215_8216 : H12AffineEnvironment.transform 15 8715 env8215 = env8216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env8215 == env8216) = true)

theorem identity8216 : scanCanonicalize (H12AffineFastState.compose env8216 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8216 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8217 : List Nat := [2,4,8,16,32,64,128,253,136,253,2048,4096,8192,184,8201,8323,4096,91,4117,8201,65,112,4344,219,8329,4096,131,4096,4097,2185,4,81,4117,169,4344,113]

theorem envBound8217 : H12AffineFastState.Bounded env8217 := by
  intro p hp
  have h : env8217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8216_8217 : H12AffineEnvironment.transform 8 136 env8216 = env8217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8216 == env8217) = true)

theorem identity8217 : scanCanonicalize (H12AffineFastState.compose env8217 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound8217 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env8218 : List Nat := [2,4,8,16,32,64,121,4,113,4,2048,4096,8192,65,8201,8314,4096,91,4117,8201,65,112,4097,34,8304,4096,122,4096,4097,2160,4,81,4117,80,4097,113]

theorem envBound8218 : H12AffineFastState.Bounded env8218 := by
  intro p hp
  have h : env8218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8217_8218 : H12AffineEnvironment.transform 6 121 env8217 = env8218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env8217 == env8218) = true)

theorem identity8218 : scanCanonicalize (H12AffineFastState.compose env8218 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound8218 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8219 : List Nat := [2,4,8,16,32,64,121,4,113,4,2048,4096,25,65,16,99,4096,91,4117,16,65,112,4097,34,105,4096,122,4096,4097,2160,4,81,4117,80,4097,113]

theorem envBound8219 : H12AffineFastState.Bounded env8219 := by
  intro p hp
  have h : env8219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8218_8219 : H12AffineEnvironment.transform 12 25 env8218 = env8219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env8218 == env8219) = true)

theorem identity8219 : scanCanonicalize (H12AffineFastState.compose env8219 (packedSelected [2,13,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8219 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8220 : List Nat := [2,4,8,16,32,17,40,4,32,4,2048,4096,25,16,16,50,4096,10,4117,16,16,33,4097,34,56,4096,43,4096,4097,2081,4,0,4117,1,4097,32]

theorem envBound8220 : H12AffineFastState.Bounded env8220 := by
  intro p hp
  have h : env8220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8219_8220 : H12AffineEnvironment.transform 5 17 env8219 = env8220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8219 == env8220) = true)

theorem identity8220 : scanCanonicalize (H12AffineFastState.compose env8220 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound8220 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8221 : List Nat := [2,4,8,16,32,17,40,4,32,4,2048,2064,25,16,16,50,2064,10,2053,16,16,33,2065,34,56,2064,43,2064,2065,2081,4,0,2053,1,2065,32]

theorem envBound8221 : H12AffineFastState.Bounded env8221 := by
  intro p hp
  have h : env8221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8220_8221 : H12AffineEnvironment.transform 11 2064 env8220 = env8221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env8220 == env8221) = true)

theorem identity8221 : scanCanonicalize (H12AffineFastState.compose env8221 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound8221 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8222 : List Nat := [2,4,8,16,32,17,40,4,32,4,42,58,25,16,16,50,58,10,47,16,16,33,59,34,56,58,43,58,59,11,4,0,47,1,59,32]

theorem envBound8222 : H12AffineFastState.Bounded env8222 := by
  intro p hp
  have h : env8222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8221_8222 : H12AffineEnvironment.transform 10 42 env8221 = env8222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env8221 == env8222) = true)

theorem identity8222 : scanCanonicalize (H12AffineFastState.compose env8222 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound8222 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env8223 : List Nat := [2,4,8,11,32,10,40,4,32,4,42,33,2,11,11,41,33,10,47,11,11,33,32,34,35,33,43,33,32,11,4,0,47,1,32,32]

theorem envBound8223 : H12AffineFastState.Bounded env8223 := by
  intro p hp
  have h : env8223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8222_8223 : H12AffineEnvironment.transform 3 11 env8222 = env8223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env8222 == env8223) = true)

theorem identity8223 : scanCanonicalize (H12AffineFastState.compose env8223 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8223 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8224 : List Nat := [2,4,8,11,1,10,9,4,1,4,11,0,2,11,11,8,0,10,14,11,11,0,1,3,2,0,10,0,1,11,4,0,14,1,1,1]

theorem envBound8224 : H12AffineFastState.Bounded env8224 := by
  intro p hp
  have h : env8224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8223_8224 : H12AffineEnvironment.transform 4 1 env8223 = env8224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8223 == env8224) = true)

theorem identity8224 : scanCanonicalize (H12AffineFastState.compose env8224 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8224 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8225 : List Nat := [2,4,2,1,1,0,3,4,1,4,1,0,2,1,1,2,0,0,4,1,1,0,1,3,2,0,0,0,1,1,4,0,4,1,1,1]

theorem envBound8225 : H12AffineFastState.Bounded env8225 := by
  intro p hp
  have h : env8225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8224_8225 : H12AffineEnvironment.transform 2 2 env8224 = env8225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8224 == env8225) = true)

def env8226 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8201,65536,4096,73944,4765,8201,65,113,4720,74449,8329,4097,74377,4744,4745,75786,4,73939,4765,73770,78579,73971]

theorem envBound8226 : H12AffineFastState.Bounded env8226 := by
  intro p hp
  have h : env8226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8214_8226 : H12AffineEnvironment.transform 13 561 env8214 = env8226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8214 == env8226) = true)

theorem identity8226 : scanCanonicalize (H12AffineFastState.compose env8226 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8946) := by decide +kernel

theorem selectedBound8226 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8227 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8201,8946,4096,554,4765,8201,65,113,4720,35,8329,4097,123,4744,4745,2808,4,545,4765,728,4097,513]

theorem envBound8227 : H12AffineFastState.Bounded env8227 := by
  intro p hp
  have h : env8227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8226_8227 : H12AffineEnvironment.transform 15 8946 env8226 = env8227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8946 env8226 == env8227) = true)

theorem identity8227 : scanCanonicalize (H12AffineFastState.compose env8227 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound8227 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env8228 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,2090,8192,561,8201,8946,2090,554,2743,8201,65,113,2650,35,8329,2091,123,2722,2723,2808,4,545,2743,728,2091,513]

theorem envBound8228 : H12AffineFastState.Bounded env8228 := by
  intro p hp
  have h : env8228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8227_8228 : H12AffineEnvironment.transform 11 2090 env8227 = env8228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env8227 == env8228) = true)

theorem identity8228 : scanCanonicalize (H12AffineFastState.compose env8228 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound8228 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env8229 : List Nat := [2,4,8,16,32,64,128,253,137,253,2048,2090,8192,184,8201,8315,2090,163,2110,8201,65,113,2259,35,8329,2091,123,2091,2090,2161,4,168,2110,81,2091,136]

theorem envBound8229 : H12AffineFastState.Bounded env8229 := by
  intro p hp
  have h : env8229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8228_8229 : H12AffineEnvironment.transform 8 137 env8228 = env8229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env8228 == env8229) = true)

theorem identity8229 : scanCanonicalize (H12AffineFastState.compose env8229 (packedSelected [2,13,14] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8229 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env8230 : List Nat := [2,4,8,0,32,64,128,237,137,237,2048,2090,8192,168,8201,8299,2090,163,2094,8201,65,97,2243,35,8329,2091,107,2091,2090,2145,4,168,2094,65,2091,136]

theorem envBound8230 : H12AffineFastState.Bounded env8230 := by
  intro p hp
  have h : env8230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8229_8230 : H12AffineEnvironment.transform 3 0 env8229 = env8230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8229 == env8230) = true)

theorem identity8230 : scanCanonicalize (H12AffineFastState.compose env8230 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2187) := by decide +kernel

theorem selectedBound8230 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env8231 : List Nat := [2,4,8,0,32,64,128,237,137,237,2048,2090,2187,168,2178,2272,2090,163,2094,2178,65,97,2243,35,2050,2091,107,2091,2090,2145,4,168,2094,65,2091,136]

theorem envBound8231 : H12AffineFastState.Bounded env8231 := by
  intro p hp
  have h : env8231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8230_8231 : H12AffineEnvironment.transform 12 2187 env8230 = env8231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2187 env8230 == env8231) = true)

theorem identity8231 : scanCanonicalize (H12AffineFastState.compose env8231 (packedSelected [0,1,2,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8231 : packedSelected [0,1,2,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env8232 : List Nat := [2,4,8,0,32,64,40,69,33,69,2048,2090,2083,0,2090,2120,2090,11,2094,2090,65,97,2155,35,2050,2091,107,2091,2090,2145,4,0,2094,65,2091,32]

theorem envBound8232 : H12AffineFastState.Bounded env8232 := by
  intro p hp
  have h : env8232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8231_8232 : H12AffineEnvironment.transform 6 40 env8231 = env8232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8231 == env8232) = true)

theorem identity8232 : scanCanonicalize (H12AffineFastState.compose env8232 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound8232 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8233 : List Nat := [2,4,8,0,32,64,40,69,33,69,1,43,34,0,43,73,43,11,47,43,65,97,106,35,3,42,107,42,43,96,4,0,47,65,42,32]

theorem envBound8233 : H12AffineFastState.Bounded env8233 := by
  intro p hp
  have h : env8233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8232_8233 : H12AffineEnvironment.transform 10 1 env8232 = env8233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env8232 == env8233) = true)

theorem identity8233 : scanCanonicalize (H12AffineFastState.compose env8233 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 46) := by decide +kernel

theorem selectedBound8233 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8234 : List Nat := [2,4,8,0,32,46,40,43,33,43,1,43,34,0,43,39,43,11,47,43,47,15,4,35,3,42,5,42,43,14,4,0,47,47,42,32]

theorem envBound8234 : H12AffineFastState.Bounded env8234 := by
  intro p hp
  have h : env8234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8233_8234 : H12AffineEnvironment.transform 5 46 env8233 = env8234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 46 env8233 == env8234) = true)

theorem identity8234 : scanCanonicalize (H12AffineFastState.compose env8234 (packedSelected [0,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound8234 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env8235 : List Nat := [2,4,6,0,32,32,38,37,33,37,1,37,34,0,37,39,37,5,33,37,33,1,4,35,3,36,5,36,37,0,4,0,33,33,36,32]

theorem envBound8235 : H12AffineFastState.Bounded env8235 := by
  intro p hp
  have h : env8235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8234_8235 : H12AffineEnvironment.transform 2 6 env8234 = env8235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env8234 == env8235) = true)

theorem identity8235 : scanCanonicalize (H12AffineFastState.compose env8235 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound8235 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8236 : List Nat := [2,1,3,0,32,32,35,32,33,32,1,32,34,0,32,34,32,0,33,32,33,1,1,35,3,33,0,33,32,0,1,0,33,33,33,32]

theorem envBound8236 : H12AffineFastState.Bounded env8236 := by
  intro p hp
  have h : env8236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8235_8236 : H12AffineEnvironment.transform 1 1 env8235 = env8236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env8235 == env8236) = true)

theorem identity8236 : scanCanonicalize (H12AffineFastState.compose env8236 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8236 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8237 : List Nat := [2,1,3,0,0,0,3,0,1,0,1,0,2,0,0,2,0,0,1,0,1,1,1,3,3,1,0,1,0,0,1,0,1,1,1,0]

theorem envBound8237 : H12AffineFastState.Bounded env8237 := by
  intro p hp
  have h : env8237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8236_8237 : H12AffineEnvironment.transform 4 0 env8236 = env8237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8236 == env8237) = true)

def env8238 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,73945,4765,8201,65,16961,4720,90336,8329,21040,90297,4745,4744,75786,4,90851,4765,73770,78579,90818]

theorem envBound8238 : H12AffineFastState.Bounded env8238 := by
  intro p hp
  have h : env8238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8213_8238 : H12AffineEnvironment.transform 17 73945 env8213 = env8238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 73945 env8213 == env8238) = true)

def env8239 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8201,65536,4096,73945,4765,8201,65,113,4720,74448,8329,4096,74377,4745,4744,75786,4,73939,4765,73770,78579,73970]

theorem envBound8239 : H12AffineFastState.Bounded env8239 := by
  intro p hp
  have h : env8239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8238_8239 : H12AffineEnvironment.transform 13 560 env8238 = env8239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8238 == env8239) = true)

theorem identity8239 : scanCanonicalize (H12AffineFastState.compose env8239 (packedSelected [7,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8239 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8240 : List Nat := [2,4,8,16,32,64,120,5,512,5,2048,4096,8192,560,8201,65536,4096,73761,4709,8201,65,113,4720,74280,8305,4096,74353,4721,4720,75786,4,73771,4709,73770,78347,73738]

theorem envBound8240 : H12AffineFastState.Bounded env8240 := by
  intro p hp
  have h : env8240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8239_8240 : H12AffineEnvironment.transform 6 120 env8239 = env8240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8239 == env8240) = true)

theorem identity8240 : scanCanonicalize (H12AffineFastState.compose env8240 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 2154) := by decide +kernel

theorem selectedBound8240 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env8241 : List Nat := [2,4,8,16,32,64,120,5,512,5,2048,2154,8192,560,8201,65536,2154,73761,2575,8201,65,113,2586,74280,8305,2154,74353,2587,2586,75786,4,73771,2575,73770,76385,73738]

theorem envBound8241 : H12AffineFastState.Bounded env8241 := by
  intro p hp
  have h : env8241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8240_8241 : H12AffineEnvironment.transform 11 2154 env8240 = env8241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2154 env8240 == env8241) = true)

theorem identity8241 : scanCanonicalize (H12AffineFastState.compose env8241 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound8241 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8242 : List Nat := [2,4,8,16,32,64,120,5,512,5,2048,2154,8192,560,8201,8235,2154,10,2575,8201,65,113,2586,515,8305,2154,602,2587,2586,2081,4,0,2575,1,2634,33]

theorem envBound8242 : H12AffineFastState.Bounded env8242 := by
  intro p hp
  have h : env8242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8241_8242 : H12AffineEnvironment.transform 15 8235 env8241 = env8242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env8241 == env8242) = true)

theorem identity8242 : scanCanonicalize (H12AffineFastState.compose env8242 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound8242 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8243 : List Nat := [2,4,8,16,32,64,120,5,33,5,2048,2154,8192,17,8201,8235,2154,10,2094,8201,65,113,2107,34,8305,2154,123,2106,2107,2081,4,0,2094,1,2155,33]

theorem envBound8243 : H12AffineFastState.Bounded env8243 := by
  intro p hp
  have h : env8243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8242_8243 : H12AffineEnvironment.transform 8 33 env8242 = env8243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env8242 == env8243) = true)

theorem identity8243 : scanCanonicalize (H12AffineFastState.compose env8243 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8243 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8244 : List Nat := [2,4,8,16,32,16,40,5,33,5,2048,2106,8192,17,8201,8235,2106,10,2094,8201,17,33,2107,34,8225,2106,43,2106,2107,2081,4,0,2094,1,2107,33]

theorem envBound8244 : H12AffineFastState.Bounded env8244 := by
  intro p hp
  have h : env8244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8243_8244 : H12AffineEnvironment.transform 5 16 env8243 = env8244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8243 == env8244) = true)

theorem identity8244 : scanCanonicalize (H12AffineFastState.compose env8244 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8244 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8245 : List Nat := [2,4,8,16,27,16,19,5,26,5,2048,2049,8192,17,8201,8208,2049,10,2069,8201,17,26,2048,25,8218,2049,16,2049,2048,2074,4,0,2069,1,2048,26]

theorem envBound8245 : H12AffineFastState.Bounded env8245 := by
  intro p hp
  have h : env8245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8244_8245 : H12AffineEnvironment.transform 4 27 env8244 = env8245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8244 == env8245) = true)

theorem identity8245 : scanCanonicalize (H12AffineFastState.compose env8245 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound8245 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8246 : List Nat := [2,4,8,11,0,11,8,5,1,5,2048,2049,8192,10,8201,8203,2049,10,2062,8201,10,1,2048,2,8193,2049,11,2049,2048,2049,4,0,2062,1,2048,1]

theorem envBound8246 : H12AffineFastState.Bounded env8246 := by
  intro p hp
  have h : env8246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8245_8246 : H12AffineEnvironment.transform 3 11 env8245 = env8246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env8245 == env8246) = true)

theorem identity8246 : scanCanonicalize (H12AffineFastState.compose env8246 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound8246 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8247 : List Nat := [2,4,8,11,0,11,8,5,1,5,2048,2049,8,10,1,3,2049,10,2062,1,10,1,2048,2,9,2049,11,2049,2048,2049,4,0,2062,1,2048,1]

theorem envBound8247 : H12AffineFastState.Bounded env8247 := by
  intro p hp
  have h : env8247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8246_8247 : H12AffineEnvironment.transform 12 8 env8246 = env8247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env8246 == env8247) = true)

theorem identity8247 : scanCanonicalize (H12AffineFastState.compose env8247 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound8247 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8248 : List Nat := [2,4,8,11,0,11,8,5,1,5,1,0,8,10,1,3,0,10,15,1,10,1,1,2,9,0,11,0,1,0,4,0,15,1,1,1]

theorem envBound8248 : H12AffineFastState.Bounded env8248 := by
  intro p hp
  have h : env8248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8247_8248 : H12AffineEnvironment.transform 10 1 env8247 = env8248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env8247 == env8248) = true)

theorem identity8248 : scanCanonicalize (H12AffineFastState.compose env8248 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8248 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8249 : List Nat := [2,4,3,0,0,0,3,5,1,5,1,0,3,1,1,3,0,1,4,1,1,1,1,2,2,0,0,0,1,0,4,0,4,1,1,1]

theorem envBound8249 : H12AffineFastState.Bounded env8249 := by
  intro p hp
  have h : env8249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8248_8249 : H12AffineEnvironment.transform 2 3 env8248 = env8249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8248 == env8249) = true)

def env8250 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8201,65536,4096,73945,4765,8201,65,112,4720,74449,8329,4097,74376,4745,4744,75786,4,73938,4765,73770,78579,73971]

theorem envBound8250 : H12AffineFastState.Bounded env8250 := by
  intro p hp
  have h : env8250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8238_8250 : H12AffineEnvironment.transform 13 561 env8238 = env8250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8238 == env8250) = true)

def env8251 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,4961,8692,2097152,4194304,5004,90336,8329,21040,278625,4214985,4215093,75787,504,4268382,4961,73771,2175667,90943]

theorem envBound8251 : H12AffineFastState.Bounded env8251 := by
  intro p hp
  have h : env8251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8149_8251 : H12AffineEnvironment.transform 18 4961 env8149 = env8251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env8149 == env8251) = true)

theorem identity8251 : scanCanonicalize (H12AffineFastState.compose env8251 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24770) := by decide +kernel

theorem selectedBound8251 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8252 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24770,4605,262144,4961,8692,2097152,4194304,5004,34,8329,21040,278625,4214985,4215093,18633,504,4211100,4961,16617,2118257,1021]

theorem envBound8252 : H12AffineFastState.Bounded env8252 := by
  intro p hp
  have h : env8252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8251_8252 : H12AffineEnvironment.transform 15 24770 env8251 = env8252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24770 env8251 == env8252) = true)

def env8253 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24770,4605,262144,4961,8692,64,4194304,5004,34,8329,21040,278625,4214985,4215093,18633,504,4211100,4961,16617,21041,1021]

theorem envBound8253 : H12AffineFastState.Bounded env8253 := by
  intro p hp
  have h : env8253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8252_8253 : H12AffineEnvironment.transform 20 64 env8252 = env8253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8252 == env8253) = true)

theorem identity8253 : scanCanonicalize (H12AffineFastState.compose env8253 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4171) := by decide +kernel

theorem selectedBound8253 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8254 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24770,4605,4171,4961,8692,64,4194304,5004,34,8329,21040,20522,4214985,4215093,18633,504,4211100,4961,16617,21041,1021]

theorem envBound8254 : H12AffineFastState.Bounded env8254 := by
  intro p hp
  have h : env8254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8253_8254 : H12AffineEnvironment.transform 17 4171 env8253 = env8254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4171 env8253 == env8254) = true)

def env8255 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,232,8692,8234,4605,4171,4961,8692,64,4194304,5004,34,8329,4824,4290,4198433,4198877,2081,504,4194676,4961,1,4825,1021]

theorem envBound8255 : H12AffineFastState.Bounded env8255 := by
  intro p hp
  have h : env8255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8254_8255 : H12AffineEnvironment.transform 13 232 env8254 = env8255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env8254 == env8255) = true)

theorem identity8255 : scanCanonicalize (H12AffineFastState.compose env8255 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8255 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8256 : List Nat := [2,4,8,16,32,64,128,85,512,85,2048,4096,8192,232,8353,8234,4264,4171,4660,8353,64,4194304,4825,34,8329,4824,4290,4198433,4198536,2081,173,4194337,4660,1,4825,680]

theorem envBound8256 : H12AffineFastState.Bounded env8256 := by
  intro p hp
  have h : env8256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8255_8256 : H12AffineEnvironment.transform 7 85 env8255 = env8256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8255 == env8256) = true)

theorem identity8256 : scanCanonicalize (H12AffineFastState.compose env8256 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 754) := by decide +kernel

theorem selectedBound8256 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env8257 : List Nat := [2,4,8,16,32,64,128,85,512,85,754,4096,8192,232,8353,8234,4264,4171,4660,8353,64,4194304,4825,34,8329,4824,4290,4198433,4198536,723,173,4194337,4660,1,4825,680]

theorem envBound8257 : H12AffineFastState.Bounded env8257 := by
  intro p hp
  have h : env8257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8256_8257 : H12AffineEnvironment.transform 10 754 env8256 = env8257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 754 env8256 == env8257) = true)

theorem identity8257 : scanCanonicalize (H12AffineFastState.compose env8257 (packedSelected [3,10,12,13,14,15,17,19,28] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8257 : packedSelected [3,10,12,13,14,15,17,19,28] rootPS < 2^1333 := by decide +kernel

def env8258 : List Nat := [2,4,8,16,32,16,128,5,512,5,674,4096,8192,184,8353,8234,4264,4123,4660,8353,16,4194304,4745,34,8329,4744,4242,4198433,4198536,643,173,4194337,4660,1,4745,680]

theorem envBound8258 : H12AffineFastState.Bounded env8258 := by
  intro p hp
  have h : env8258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8257_8258 : H12AffineEnvironment.transform 5 16 env8257 = env8258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8257 == env8258) = true)

theorem identity8258 : scanCanonicalize (H12AffineFastState.compose env8258 (packedSelected [0,2,5,7,8,11,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 4248) := by decide +kernel

theorem selectedBound8258 : packedSelected [0,2,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env8259 : List Nat := [2,4,8,16,32,16,128,5,512,5,674,4096,8192,184,8353,8234,4264,4123,4660,8353,16,4248,4745,34,8329,4744,4242,185,16,643,173,4281,4660,1,4745,680]

theorem envBound8259 : H12AffineFastState.Bounded env8259 := by
  intro p hp
  have h : env8259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8258_8259 : H12AffineEnvironment.transform 21 4248 env8258 = env8259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4248 env8258 == env8259) = true)

def env8260 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,233,8692,8235,4605,4171,4961,8692,64,4194304,5004,34,8329,4825,4291,4198432,4198876,2080,504,4194677,4961,0,4824,1021]

theorem envBound8260 : H12AffineFastState.Bounded env8260 := by
  intro p hp
  have h : env8260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8254_8260 : H12AffineEnvironment.transform 13 233 env8254 = env8260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env8254 == env8260) = true)

theorem identity8260 : scanCanonicalize (H12AffineFastState.compose env8260 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound8260 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8261 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,233,8692,8235,4605,4171,4961,8692,64,476,5004,34,8329,4825,4291,4604,4096,2080,504,169,4961,0,4824,1021]

theorem envBound8261 : H12AffineFastState.Bounded env8261 := by
  intro p hp
  have h : env8261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8260_8261 : H12AffineEnvironment.transform 21 476 env8260 = env8261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env8260 == env8261) = true)

theorem identity8261 : scanCanonicalize (H12AffineFastState.compose env8261 (packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8261 : packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env8262 : List Nat := [2,4,8,16,32,64,41,256,512,256,2048,4096,8192,64,8541,8235,4436,4171,4961,8541,64,373,4901,34,8224,4720,4202,4437,4096,2080,337,0,4961,0,4721,852]

theorem envBound8262 : H12AffineFastState.Bounded env8262 := by
  intro p hp
  have h : env8262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8261_8262 : H12AffineEnvironment.transform 6 41 env8261 = env8262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8261 == env8262) = true)

theorem identity8262 : scanCanonicalize (H12AffineFastState.compose env8262 (packedSelected [0,4,7,9,13,14,17] rootPS)) = affineNative (2^(11+1) ^^^ 2367) := by decide +kernel

theorem selectedBound8262 : packedSelected [0,4,7,9,13,14,17] rootPS < 2^1333 := by decide +kernel

def env8263 : List Nat := [2,4,8,16,32,64,41,256,512,256,2048,2367,8192,64,8541,8235,2155,2420,2654,8541,64,373,2586,34,8224,2895,2389,2154,2367,2080,337,0,2654,0,2894,852]

theorem envBound8263 : H12AffineFastState.Bounded env8263 := by
  intro p hp
  have h : env8263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8262_8263 : H12AffineEnvironment.transform 11 2367 env8262 = env8263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2367 env8262 == env8263) = true)

theorem identity8263 : scanCanonicalize (H12AffineFastState.compose env8263 (packedSelected [0,2,3,4,5,7,9,10,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8263 : packedSelected [0,2,3,4,5,7,9,10,11,18] rootPS < 2^1333 := by decide +kernel

def env8264 : List Nat := [2,4,8,16,32,16,41,256,512,256,2048,2367,8192,16,8461,8235,2107,2340,2574,8461,16,293,2586,34,8224,2847,2309,2106,2367,2080,257,0,2574,0,2846,772]

theorem envBound8264 : H12AffineFastState.Bounded env8264 := by
  intro p hp
  have h : env8264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8263_8264 : H12AffineEnvironment.transform 5 16 env8263 = env8264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8263 == env8264) = true)

theorem identity8264 : scanCanonicalize (H12AffineFastState.compose env8264 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 790) := by decide +kernel

theorem selectedBound8264 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env8265 : List Nat := [2,4,8,16,32,16,41,256,512,256,2048,2367,790,16,539,829,2107,2340,2574,539,16,293,2586,34,822,2847,2309,2106,2367,2080,257,0,2574,0,2846,772]

theorem envBound8265 : H12AffineFastState.Bounded env8265 := by
  intro p hp
  have h : env8265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8264_8265 : H12AffineEnvironment.transform 12 790 env8264 = env8265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 790 env8264 == env8265) = true)

theorem identity8265 : scanCanonicalize (H12AffineFastState.compose env8265 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound8265 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env8266 : List Nat := [2,4,8,16,32,16,41,256,42,256,2048,2367,316,16,49,279,2107,2340,2084,49,16,293,2096,34,284,2357,2309,2106,2367,2080,257,0,2084,0,2356,302]

theorem envBound8266 : H12AffineFastState.Bounded env8266 := by
  intro p hp
  have h : env8266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8265_8266 : H12AffineEnvironment.transform 8 42 env8265 = env8266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env8265 == env8266) = true)

theorem identity8266 : scanCanonicalize (H12AffineFastState.compose env8266 (packedSelected [0,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound8266 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env8267 : List Nat := [2,4,8,16,32,16,41,256,42,256,319,0,316,16,49,279,260,27,283,49,16,293,271,34,284,10,58,261,0,287,257,0,283,0,11,302]

theorem envBound8267 : H12AffineFastState.Bounded env8267 := by
  intro p hp
  have h : env8267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8266_8267 : H12AffineEnvironment.transform 10 319 env8266 = env8267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env8266 == env8267) = true)

theorem identity8267 : scanCanonicalize (H12AffineFastState.compose env8267 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8267 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env8268 : List Nat := [2,4,8,16,11,16,2,256,1,256,276,0,279,16,26,279,260,27,283,26,16,270,271,9,284,10,17,261,0,287,257,0,283,0,11,261]

theorem envBound8268 : H12AffineFastState.Bounded env8268 := by
  intro p hp
  have h : env8268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8267_8268 : H12AffineEnvironment.transform 4 11 env8267 = env8268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8267 == env8268) = true)

theorem identity8268 : scanCanonicalize (H12AffineFastState.compose env8268 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound8268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8269 : List Nat := [2,4,8,16,11,16,2,20,1,20,0,0,3,16,26,3,16,27,15,26,16,26,27,9,8,10,17,17,0,11,21,0,15,0,11,17]

theorem envBound8269 : H12AffineFastState.Bounded env8269 := by
  intro p hp
  have h : env8269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8268_8269 : H12AffineEnvironment.transform 7 20 env8268 = env8269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env8268 == env8269) = true)

theorem identity8269 : scanCanonicalize (H12AffineFastState.compose env8269 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8269 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8270 : List Nat := [2,4,8,0,11,0,2,4,1,4,0,0,3,0,10,3,0,11,15,10,0,10,11,9,8,10,1,1,0,11,5,0,15,0,11,1]

theorem envBound8270 : H12AffineFastState.Bounded env8270 := by
  intro p hp
  have h : env8270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8269_8270 : H12AffineEnvironment.transform 3 0 env8269 = env8270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8269 == env8270) = true)

def env8271 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24770,4605,262144,4961,8692,65,4194304,5004,34,8329,21040,278625,4214985,4215093,18633,504,4211100,4961,16617,21040,1021]

theorem envBound8271 : H12AffineFastState.Bounded env8271 := by
  intro p hp
  have h : env8271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8252_8271 : H12AffineEnvironment.transform 20 65 env8252 = env8271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8252 == env8271) = true)

theorem identity8271 : scanCanonicalize (H12AffineFastState.compose env8271 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound8271 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8272 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24770,4605,554,4961,8692,65,4194304,5004,34,8329,21040,16971,4214985,4215093,18633,504,4211100,4961,16617,21040,1021]

theorem envBound8272 : H12AffineFastState.Bounded env8272 := by
  intro p hp
  have h : env8272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8271_8272 : H12AffineEnvironment.transform 17 554 env8271 = env8272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env8271 == env8272) = true)

def env8273 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,232,8692,8234,4605,554,4961,8692,65,4194304,5004,34,8329,4824,675,4198433,4198877,2081,504,4194676,4961,1,4824,1021]

theorem envBound8273 : H12AffineFastState.Bounded env8273 := by
  intro p hp
  have h : env8273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8272_8273 : H12AffineEnvironment.transform 13 232 env8272 = env8273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env8272 == env8273) = true)

theorem identity8273 : scanCanonicalize (H12AffineFastState.compose env8273 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8273 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8274 : List Nat := [2,4,8,16,32,64,128,84,512,84,2048,4096,8192,232,8352,8234,4265,554,4661,8352,65,4194304,4824,34,8329,4824,675,4198433,4198537,2081,172,4194336,4661,1,4824,681]

theorem envBound8274 : H12AffineFastState.Bounded env8274 := by
  intro p hp
  have h : env8274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8273_8274 : H12AffineEnvironment.transform 7 84 env8273 = env8274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8273 == env8274) = true)

theorem identity8274 : scanCanonicalize (H12AffineFastState.compose env8274 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(11+1) ^^^ 2242) := by decide +kernel

theorem selectedBound8274 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env8275 : List Nat := [2,4,8,16,32,64,128,84,512,84,2048,2242,8192,232,8352,8234,2155,554,2807,8352,65,4194304,2586,34,8329,2586,675,4196579,4196427,2081,172,4194336,2807,1,2586,681]

theorem envBound8275 : H12AffineFastState.Bounded env8275 := by
  intro p hp
  have h : env8275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8274_8275 : H12AffineEnvironment.transform 11 2242 env8274 = env8275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2242 env8274 == env8275) = true)

theorem identity8275 : scanCanonicalize (H12AffineFastState.compose env8275 (packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound8275 : packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env8276 : List Nat := [2,4,8,16,32,64,128,84,512,84,522,712,8192,232,8352,8234,609,554,253,8352,65,4194304,16,34,8329,16,675,4195049,4194881,555,172,4194336,253,1,16,681]

theorem envBound8276 : H12AffineFastState.Bounded env8276 := by
  intro p hp
  have h : env8276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8275_8276 : H12AffineEnvironment.transform 10 522 env8275 = env8276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env8275 == env8276) = true)

theorem identity8276 : scanCanonicalize (H12AffineFastState.compose env8276 (packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound8276 : packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS < 2^1333 := by decide +kernel

def env8277 : List Nat := [2,4,8,16,32,64,128,84,512,84,522,712,8192,232,8352,8234,609,554,253,8352,65,113,16,34,8329,16,675,664,560,555,172,81,253,1,16,681]

theorem envBound8277 : H12AffineFastState.Bounded env8277 := by
  intro p hp
  have h : env8277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8276_8277 : H12AffineEnvironment.transform 21 113 env8276 = env8277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env8276 == env8277) = true)

theorem identity8277 : scanCanonicalize (H12AffineFastState.compose env8277 (packedSelected [1,2,4,5,7,11,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound8277 : packedSelected [1,2,4,5,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env8278 : List Nat := [2,4,8,16,32,64,88,84,512,84,522,528,8192,48,8312,8234,609,554,37,8312,65,113,16,34,8273,16,635,576,560,555,116,81,37,1,16,625]

theorem envBound8278 : H12AffineFastState.Bounded env8278 := by
  intro p hp
  have h : env8278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8277_8278 : H12AffineEnvironment.transform 6 88 env8277 = env8278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env8277 == env8278) = true)

theorem identity8278 : scanCanonicalize (H12AffineFastState.compose env8278 (packedSelected [0,2,4,5,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound8278 : packedSelected [0,2,4,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env8279 : List Nat := [2,4,8,16,32,64,88,84,512,84,522,528,552,48,592,514,609,554,37,592,65,113,16,34,633,16,635,576,560,555,116,81,37,1,16,625]

theorem envBound8279 : H12AffineFastState.Bounded env8279 := by
  intro p hp
  have h : env8279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8278_8279 : H12AffineEnvironment.transform 12 552 env8278 = env8279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env8278 == env8279) = true)

theorem identity8279 : scanCanonicalize (H12AffineFastState.compose env8279 (packedSelected [0,2,3,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound8279 : packedSelected [0,2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env8280 : List Nat := [2,4,8,16,32,64,88,84,113,84,123,97,89,48,33,115,16,91,37,33,65,113,16,34,8,16,10,49,65,90,116,81,37,1,16,0]

theorem envBound8280 : H12AffineFastState.Bounded env8280 := by
  intro p hp
  have h : env8280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8279_8280 : H12AffineEnvironment.transform 8 113 env8279 = env8280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env8279 == env8280) = true)

theorem identity8280 : scanCanonicalize (H12AffineFastState.compose env8280 (packedSelected [2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound8280 : packedSelected [2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env8281 : List Nat := [2,4,8,16,26,64,88,84,75,84,65,91,89,10,27,73,16,91,31,27,65,75,16,24,8,16,10,11,65,90,78,81,31,1,16,0]

theorem envBound8281 : H12AffineFastState.Bounded env8281 := by
  intro p hp
  have h : env8281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8280_8281 : H12AffineEnvironment.transform 4 26 env8280 = env8281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env8280 == env8281) = true)

theorem identity8281 : scanCanonicalize (H12AffineFastState.compose env8281 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8281 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8282 : List Nat := [2,4,8,1,11,64,73,69,75,69,65,74,72,10,10,73,1,74,14,10,65,75,1,9,8,1,10,11,65,75,78,64,14,1,1,0]

theorem envBound8282 : H12AffineFastState.Bounded env8282 := by
  intro p hp
  have h : env8282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8281_8282 : H12AffineEnvironment.transform 3 1 env8281 = env8282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8281 == env8282) = true)

theorem identity8282 : scanCanonicalize (H12AffineFastState.compose env8282 (packedSelected [1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound8282 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env8283 : List Nat := [2,4,8,1,11,0,9,5,11,5,1,10,8,10,10,9,1,10,14,10,1,11,1,9,8,1,10,11,1,11,14,0,14,1,1,0]

theorem envBound8283 : H12AffineFastState.Bounded env8283 := by
  intro p hp
  have h : env8283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8282_8283 : H12AffineEnvironment.transform 5 0 env8282 = env8283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8282 == env8283) = true)

theorem identity8283 : scanCanonicalize (H12AffineFastState.compose env8283 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8283 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env8284 : List Nat := [2,4,3,1,0,0,2,5,0,5,1,1,3,1,1,2,1,1,5,1,1,0,1,2,3,1,1,0,1,0,5,0,5,1,1,0]

theorem envBound8284 : H12AffineFastState.Bounded env8284 := by
  intro p hp
  have h : env8284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8283_8284 : H12AffineEnvironment.transform 2 3 env8283 = env8284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8283 == env8284) = true)

def leafEnv8284 : List Nat := [2,4,3,1,0,0,2,5,0,5,1,1,3,1,1,2,1,1,5,1,1,0,1,2,5,3,1,1,1,0,1,0,5,0,5,1,4,3,1,0,1,0,0]

def active8284 : List Nat := [0,1]

def tree8284 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8284 : H12WitnessSearch.Good tree8284 := H12GlobalWitnessIndex.good

theorem leafIdentity8284 : H12AffineFastState.composeSystem env8284 rootObs = leafEnv8284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8284 rootObs == leafEnv8284) = true)

theorem terminalChecked8284 : H12PackedTerminal.terminalCheckFast leafEnv8284 active8284 tree8284 = true := by decide +kernel

def env8285 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,233,8692,8235,4605,554,4961,8692,65,4194304,5004,34,8329,4825,674,4198432,4198876,2080,504,4194677,4961,0,4825,1021]

theorem envBound8285 : H12AffineFastState.Bounded env8285 := by
  intro p hp
  have h : env8285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8272_8285 : H12AffineEnvironment.transform 13 233 env8272 = env8285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env8272 == env8285) = true)

theorem identity8285 : scanCanonicalize (H12AffineFastState.compose env8285 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound8285 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8286 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,233,8692,8235,4605,554,4961,8692,65,477,5004,34,8329,4825,674,4605,4097,2080,504,168,4961,0,4825,1021]

theorem envBound8286 : H12AffineFastState.Bounded env8286 := by
  intro p hp
  have h : env8286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8285_8286 : H12AffineEnvironment.transform 21 477 env8285 = env8286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env8285 == env8286) = true)

theorem identity8286 : scanCanonicalize (H12AffineFastState.compose env8286 (packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound8286 : packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env8287 : List Nat := [2,4,8,16,32,64,121,256,512,256,2048,4096,8192,16,8461,8235,4356,554,4961,8461,65,292,4981,34,8304,4640,603,4356,4097,2080,257,81,4961,0,4640,772]

theorem envBound8287 : H12AffineFastState.Bounded env8287 := by
  intro p hp
  have h : env8287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8286_8287 : H12AffineEnvironment.transform 6 121 env8286 = env8287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env8286 == env8287) = true)

theorem identity8287 : scanCanonicalize (H12AffineFastState.compose env8287 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2367) := by decide +kernel

theorem selectedBound8287 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8288 : List Nat := [2,4,8,16,32,64,121,256,512,256,2048,2367,8192,16,8461,8235,2107,554,2654,8461,65,292,2634,34,8304,2847,603,2107,2366,2080,257,81,2654,0,2847,772]

theorem envBound8288 : H12AffineFastState.Bounded env8288 := by
  intro p hp
  have h : env8288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8287_8288 : H12AffineEnvironment.transform 11 2367 env8287 = env8288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2367 env8287 == env8288) = true)

theorem identity8288 : scanCanonicalize (H12AffineFastState.compose env8288 (packedSelected [2,3,5,7,9,11,12,13,14] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8288 : packedSelected [2,3,5,7,9,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env8289 : List Nat := [2,4,8,16,32,64,121,4,512,4,2048,2107,8192,16,8201,8235,2107,554,2654,8201,65,32,2634,34,8304,2587,603,2107,2106,2080,5,81,2654,0,2587,512]

theorem envBound8289 : H12AffineFastState.Bounded env8289 := by
  intro p hp
  have h : env8289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8288_8289 : H12AffineEnvironment.transform 7 4 env8288 = env8289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8288 == env8289) = true)

theorem identity8289 : scanCanonicalize (H12AffineFastState.compose env8289 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8289 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8290 : List Nat := [2,4,8,16,32,16,41,4,512,4,2048,2107,8192,16,8201,8235,2107,554,2574,8201,17,32,2586,34,8224,2587,523,2107,2106,2080,5,1,2574,0,2587,512]

theorem envBound8290 : H12AffineFastState.Bounded env8290 := by
  intro p hp
  have h : env8290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8289_8290 : H12AffineEnvironment.transform 5 16 env8289 = env8290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8289 == env8290) = true)

theorem identity8290 : scanCanonicalize (H12AffineFastState.compose env8290 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2616) := by decide +kernel

theorem selectedBound8290 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8291 : List Nat := [2,4,8,16,32,16,41,4,512,4,2048,2107,2616,16,2609,2579,2107,554,2574,2609,17,32,2586,34,2584,2587,523,2107,2106,2080,5,1,2574,0,2587,512]

theorem envBound8291 : H12AffineFastState.Bounded env8291 := by
  intro p hp
  have h : env8291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8290_8291 : H12AffineEnvironment.transform 12 2616 env8290 = env8291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2616 env8290 == env8291) = true)

theorem identity8291 : scanCanonicalize (H12AffineFastState.compose env8291 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound8291 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8292 : List Nat := [2,4,8,16,32,16,41,4,16,4,2048,2107,2088,16,2081,2051,2107,58,2078,2081,17,32,2058,34,2056,2059,27,2107,2106,2080,5,1,2078,0,2059,16]

theorem envBound8292 : H12AffineFastState.Bounded env8292 := by
  intro p hp
  have h : env8292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8291_8292 : H12AffineEnvironment.transform 8 16 env8291 = env8292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env8291 == env8292) = true)

theorem identity8292 : scanCanonicalize (H12AffineFastState.compose env8292 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound8292 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8293 : List Nat := [2,4,8,16,32,16,41,4,16,4,49,10,25,16,16,50,10,58,47,16,17,32,59,34,57,58,27,10,11,17,5,1,47,0,58,16]

theorem envBound8293 : H12AffineFastState.Bounded env8293 := by
  intro p hp
  have h : env8293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8292_8293 : H12AffineEnvironment.transform 10 49 env8292 = env8293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env8292 == env8293) = true)

theorem identity8293 : scanCanonicalize (H12AffineFastState.compose env8293 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8293 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8294 : List Nat := [2,4,8,16,11,16,2,4,16,4,26,10,25,16,16,25,10,17,4,16,17,11,16,9,18,17,27,10,11,17,5,1,4,0,17,16]

theorem envBound8294 : H12AffineFastState.Bounded env8294 := by
  intro p hp
  have h : env8294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8293_8294 : H12AffineEnvironment.transform 4 11 env8293 = env8294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8293 == env8294) = true)

theorem identity8294 : scanCanonicalize (H12AffineFastState.compose env8294 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8294 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8295 : List Nat := [2,4,2,16,1,16,2,4,16,4,16,0,19,16,16,19,0,17,4,16,17,1,16,3,18,17,17,0,1,17,5,1,4,0,17,16]

theorem envBound8295 : H12AffineFastState.Bounded env8295 := by
  intro p hp
  have h : env8295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8294_8295 : H12AffineEnvironment.transform 2 2 env8294 = env8295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8294 == env8295) = true)

theorem identity8295 : scanCanonicalize (H12AffineFastState.compose env8295 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8295 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8296 : List Nat := [2,4,2,1,1,1,2,4,1,4,1,0,2,1,1,2,0,0,4,1,0,1,1,3,3,0,0,0,1,0,5,1,4,0,0,1]

theorem envBound8296 : H12AffineFastState.Bounded env8296 := by
  intro p hp
  have h : env8296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8295_8296 : H12AffineEnvironment.transform 3 1 env8295 = env8296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8295 == env8296) = true)

def leafEnv8296 : List Nat := [2,4,2,1,1,1,2,4,1,4,1,0,2,1,1,2,0,0,4,1,0,1,1,3,5,3,1,0,0,0,1,0,5,1,4,0,4,2,0,1,1,0,0]

def active8296 : List Nat := [0,1]

def tree8296 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8296 : H12WitnessSearch.Good tree8296 := H12GlobalWitnessIndex.good

theorem leafIdentity8296 : H12AffineFastState.composeSystem env8296 rootObs = leafEnv8296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8296 rootObs == leafEnv8296) = true)

theorem terminalChecked8296 : H12PackedTerminal.terminalCheckFast leafEnv8296 active8296 tree8296 = true := by decide +kernel

def env8297 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524525,90337,8329,21041,807680,4735912,4735572,605035,529049,4796990,524288,602955,2695635,90942]

theorem envBound8297 : H12AffineFastState.Bounded env8297 := by
  intro p hp
  have h : env8297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8148_8297 : H12AffineEnvironment.transform 23 90337 env8148 = env8297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env8148 == env8297) = true)

def env8298 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,4960,8692,2097152,4194304,5005,90337,8329,21041,278624,4214984,4215092,75787,505,4268382,4960,73771,2175667,90942]

theorem envBound8298 : H12AffineFastState.Bounded env8298 := by
  intro p hp
  have h : env8298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8297_8298 : H12AffineEnvironment.transform 18 4960 env8297 = env8298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env8297 == env8298) = true)

theorem identity8298 : scanCanonicalize (H12AffineFastState.compose env8298 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound8298 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8299 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24771,4605,262144,4960,8692,2097152,4194304,5005,34,8329,21041,278624,4214984,4215092,18632,505,4211101,4960,16616,2118256,1021]

theorem envBound8299 : H12AffineFastState.Bounded env8299 := by
  intro p hp
  have h : env8299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8298_8299 : H12AffineEnvironment.transform 15 24771 env8298 = env8299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env8298 == env8299) = true)

def env8300 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24771,4605,262144,4960,8692,64,4194304,5005,34,8329,21041,278624,4214984,4215092,18632,505,4211101,4960,16616,21040,1021]

theorem envBound8300 : H12AffineFastState.Bounded env8300 := by
  intro p hp
  have h : env8300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8299_8300 : H12AffineEnvironment.transform 20 64 env8299 = env8300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8299 == env8300) = true)

theorem identity8300 : scanCanonicalize (H12AffineFastState.compose env8300 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 262818) := by decide +kernel

theorem selectedBound8300 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8301 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24771,4605,262144,4960,8692,64,262818,5005,34,8329,21041,278624,283242,283542,18632,505,279359,4960,16616,21040,1021]

theorem envBound8301 : H12AffineFastState.Bounded env8301 := by
  intro p hp
  have h : env8301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8300_8301 : H12AffineEnvironment.transform 21 262818 env8300 = env8301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 262818 env8300 == env8301) = true)

def env8302 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,560,8692,8947,4605,262144,4960,8692,64,262818,5005,34,8329,4097,262736,266330,266662,2808,505,262415,4960,728,4096,1021]

theorem envBound8302 : H12AffineFastState.Bounded env8302 := by
  intro p hp
  have h : env8302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8301_8302 : H12AffineEnvironment.transform 13 560 env8301 = env8302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8301 == env8302) = true)

def env8303 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,232,8692,8235,4605,262144,4536,8692,64,262266,4437,34,8329,4097,262280,266330,266662,2080,505,262415,4536,0,4096,293]

theorem envBound8303 : H12AffineFastState.Bounded env8303 := by
  intro p hp
  have h : env8303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8302_8303 : H12AffineEnvironment.transform 8 216 env8302 = env8303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8302 == env8303) = true)

theorem identity8303 : scanCanonicalize (H12AffineFastState.compose env8303 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 422) := by decide +kernel

theorem selectedBound8303 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8304 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,232,8692,8235,4605,422,4536,8692,64,476,4437,34,8329,4097,302,4604,4096,2080,505,169,4536,0,4096,293]

theorem envBound8304 : H12AffineFastState.Bounded env8304 := by
  intro p hp
  have h : env8304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8303_8304 : H12AffineEnvironment.transform 17 422 env8303 = env8304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 422 env8303 == env8304) = true)

theorem identity8304 : scanCanonicalize (H12AffineFastState.compose env8304 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8304 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8305 : List Nat := [2,4,8,16,32,64,128,84,216,84,2048,4096,8192,232,8352,8235,4265,242,4332,8352,64,136,4097,34,8329,4097,122,4264,4096,2080,173,169,4332,0,4096,113]

theorem envBound8305 : H12AffineFastState.Bounded env8305 := by
  intro p hp
  have h : env8305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8304_8305 : H12AffineEnvironment.transform 7 84 env8304 = env8305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8304 == env8305) = true)

theorem identity8305 : scanCanonicalize (H12AffineFastState.compose env8305 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound8305 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env8306 : List Nat := [2,4,8,16,32,64,128,84,216,84,42,4096,8192,232,8352,8235,4265,242,4332,8352,64,136,4097,34,8329,4097,122,4264,4096,10,173,169,4332,0,4096,113]

theorem envBound8306 : H12AffineFastState.Bounded env8306 := by
  intro p hp
  have h : env8306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8305_8306 : H12AffineEnvironment.transform 10 42 env8305 = env8306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env8305 == env8306) = true)

theorem identity8306 : scanCanonicalize (H12AffineFastState.compose env8306 (packedSelected [0,1,4,5,7,9,10,14,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8306 : packedSelected [0,1,4,5,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env8307 : List Nat := [2,4,8,16,32,17,128,5,137,5,42,4096,8192,185,8352,8235,4265,163,4285,8352,17,136,4097,34,8329,4097,43,4264,4096,10,173,169,4285,0,4096,32]

theorem envBound8307 : H12AffineFastState.Bounded env8307 := by
  intro p hp
  have h : env8307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8306_8307 : H12AffineEnvironment.transform 5 17 env8306 = env8307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8306 == env8307) = true)

theorem identity8307 : scanCanonicalize (H12AffineFastState.compose env8307 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound8307 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8308 : List Nat := [2,4,8,16,32,17,128,5,137,5,42,16,8192,185,8352,8235,185,163,173,8352,17,136,17,34,8329,17,43,184,16,10,173,169,173,0,16,32]

theorem envBound8308 : H12AffineFastState.Bounded env8308 := by
  intro p hp
  have h : env8308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8307_8308 : H12AffineEnvironment.transform 11 16 env8307 = env8308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env8307 == env8308) = true)

theorem identity8308 : scanCanonicalize (H12AffineFastState.compose env8308 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound8308 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env8309 : List Nat := [2,4,8,16,32,17,18,5,27,5,42,16,8192,43,8242,8235,43,49,63,8242,17,26,17,34,8219,17,43,42,16,10,63,59,63,0,16,32]

theorem envBound8309 : H12AffineFastState.Bounded env8309 := by
  intro p hp
  have h : env8309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8308_8309 : H12AffineEnvironment.transform 6 18 env8308 = env8309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env8308 == env8309) = true)

theorem identity8309 : scanCanonicalize (H12AffineFastState.compose env8309 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8309 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env8310 : List Nat := [2,4,8,0,32,1,2,5,11,5,42,0,8192,43,8226,8235,43,33,47,8226,1,10,1,34,8203,1,43,42,0,10,47,43,47,0,0,32]

theorem envBound8310 : H12AffineFastState.Bounded env8310 := by
  intro p hp
  have h : env8310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8309_8310 : H12AffineEnvironment.transform 3 0 env8309 = env8310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8309 == env8310) = true)

def env8311 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,233,8692,8234,4605,262144,4537,8692,64,262267,4436,34,8329,4097,262281,266330,266662,2081,505,262415,4537,1,4096,292]

theorem envBound8311 : H12AffineFastState.Bounded env8311 := by
  intro p hp
  have h : env8311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8302_8311 : H12AffineEnvironment.transform 8 217 env8302 = env8311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8302 == env8311) = true)

theorem identity8311 : scanCanonicalize (H12AffineFastState.compose env8311 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8311 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8312 : List Nat := [2,4,8,16,32,64,128,85,217,85,2048,4096,8192,233,8353,8234,4264,262144,4332,8353,64,262267,4097,34,8329,4097,262281,266330,266483,2081,172,262234,4332,1,4096,113]

theorem envBound8312 : H12AffineFastState.Bounded env8312 := by
  intro p hp
  have h : env8312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8311_8312 : H12AffineEnvironment.transform 7 85 env8311 = env8312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8311 == env8312) = true)

theorem identity8312 : scanCanonicalize (H12AffineFastState.compose env8312 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 91) := by decide +kernel

theorem selectedBound8312 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8313 : List Nat := [2,4,8,16,32,64,128,85,217,85,2048,4096,8192,233,8353,8234,4264,91,4332,8353,64,32,4097,34,8329,4097,210,4097,4264,2081,172,1,4332,1,4096,113]

theorem envBound8313 : H12AffineFastState.Bounded env8313 := by
  intro p hp
  have h : env8313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8312_8313 : H12AffineEnvironment.transform 17 91 env8312 = env8313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 91 env8312 == env8313) = true)

theorem identity8313 : scanCanonicalize (H12AffineFastState.compose env8313 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2106) := by decide +kernel

theorem selectedBound8313 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8314 : List Nat := [2,4,8,16,32,64,128,85,217,85,2048,2106,8192,233,8353,8234,2194,91,2262,8353,64,32,2107,34,8329,2107,210,2107,2194,2081,172,1,2262,1,2106,113]

theorem envBound8314 : H12AffineFastState.Bounded env8314 := by
  intro p hp
  have h : env8314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8313_8314 : H12AffineEnvironment.transform 11 2106 env8313 = env8314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2106 env8313 == env8314) = true)

theorem identity8314 : scanCanonicalize (H12AffineFastState.compose env8314 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8314 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8315 : List Nat := [2,4,8,16,32,17,128,4,136,4,2048,2106,8192,184,8353,8234,2194,10,2183,8353,17,32,2107,34,8329,2107,131,2107,2194,2081,172,1,2183,1,2106,32]

theorem envBound8315 : H12AffineFastState.Bounded env8315 := by
  intro p hp
  have h : env8315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8314_8315 : H12AffineEnvironment.transform 5 17 env8314 = env8315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8314 == env8315) = true)

theorem identity8315 : scanCanonicalize (H12AffineFastState.compose env8315 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8315 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8316 : List Nat := [2,4,8,16,32,17,40,4,32,4,2048,2106,8192,16,8201,8234,2106,10,2095,8201,17,32,2107,34,8225,2107,43,2107,2106,2081,4,1,2095,1,2106,32]

theorem envBound8316 : H12AffineFastState.Bounded env8316 := by
  intro p hp
  have h : env8316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8315_8316 : H12AffineEnvironment.transform 6 40 env8315 = env8316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8315 == env8316) = true)

theorem identity8316 : scanCanonicalize (H12AffineFastState.compose env8316 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound8316 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8317 : List Nat := [2,4,8,16,32,17,40,4,32,4,17,43,8192,16,8201,8234,43,10,62,8201,17,32,42,34,8225,42,43,42,43,48,4,1,62,1,43,32]

theorem envBound8317 : H12AffineFastState.Bounded env8317 := by
  intro p hp
  have h : env8317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8316_8317 : H12AffineEnvironment.transform 10 17 env8316 = env8317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env8316 == env8317) = true)

def env8318 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,561,8692,8946,4605,262144,4960,8692,64,262818,5005,34,8329,4096,262737,266331,266663,2809,505,262414,4960,729,4097,1021]

theorem envBound8318 : H12AffineFastState.Bounded env8318 := by
  intro p hp
  have h : env8318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8301_8318 : H12AffineEnvironment.transform 13 561 env8301 = env8318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8301 == env8318) = true)

def env8319 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,233,8692,8234,4605,262144,4536,8692,64,262266,4437,34,8329,4096,262281,266331,266663,2081,505,262414,4536,1,4097,293]

theorem envBound8319 : H12AffineFastState.Bounded env8319 := by
  intro p hp
  have h : env8319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8318_8319 : H12AffineEnvironment.transform 8 216 env8318 = env8319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8318 == env8319) = true)

theorem identity8319 : scanCanonicalize (H12AffineFastState.compose env8319 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8319 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8320 : List Nat := [2,4,8,16,32,64,128,85,216,85,2048,4096,8192,233,8353,8234,4264,262144,4333,8353,64,262266,4096,34,8329,4096,262281,266331,266482,2081,172,262235,4333,1,4097,112]

theorem envBound8320 : H12AffineFastState.Bounded env8320 := by
  intro p hp
  have h : env8320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8319_8320 : H12AffineEnvironment.transform 7 85 env8319 = env8320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8319 == env8320) = true)

theorem identity8320 : scanCanonicalize (H12AffineFastState.compose env8320 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8320 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8321 : List Nat := [2,4,8,16,32,64,41,85,113,85,2048,4096,8192,64,8200,8234,4097,262144,4164,8200,64,262266,4096,34,8224,4096,262176,266331,266331,2081,5,262235,4164,1,4097,112]

theorem envBound8321 : H12AffineFastState.Bounded env8321 := by
  intro p hp
  have h : env8321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8320_8321 : H12AffineEnvironment.transform 6 41 env8320 = env8321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8320 == env8321) = true)

theorem identity8321 : scanCanonicalize (H12AffineFastState.compose env8321 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 27) := by decide +kernel

theorem selectedBound8321 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8322 : List Nat := [2,4,8,16,32,64,41,85,113,85,2048,4096,8192,64,8200,8234,4097,27,4164,8200,64,97,4096,34,8224,4096,59,4160,4160,2081,5,64,4164,1,4097,112]

theorem envBound8322 : H12AffineFastState.Bounded env8322 := by
  intro p hp
  have h : env8322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8321_8322 : H12AffineEnvironment.transform 17 27 env8321 = env8322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 27 env8321 == env8322) = true)

theorem identity8322 : scanCanonicalize (H12AffineFastState.compose env8322 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound8322 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env8323 : List Nat := [2,4,8,16,32,64,41,85,113,85,2048,1,8192,64,8200,8234,0,27,69,8200,64,97,1,34,8224,1,59,65,65,2081,5,64,69,1,0,112]

theorem envBound8323 : H12AffineFastState.Bounded env8323 := by
  intro p hp
  have h : env8323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8322_8323 : H12AffineEnvironment.transform 11 1 env8322 = env8323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env8322 == env8323) = true)

theorem identity8323 : scanCanonicalize (H12AffineFastState.compose env8323 (packedSelected [0,2,4,7,9,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2114) := by decide +kernel

theorem selectedBound8323 : packedSelected [0,2,4,7,9,12,13] rootPS < 2^1333 := by decide +kernel

def env8324 : List Nat := [2,4,8,16,32,64,41,85,113,85,2048,1,2114,64,2122,2152,0,27,69,2122,64,97,1,34,2146,1,59,65,65,2081,5,64,69,1,0,112]

theorem envBound8324 : H12AffineFastState.Bounded env8324 := by
  intro p hp
  have h : env8324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8323_8324 : H12AffineEnvironment.transform 12 2114 env8323 = env8324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2114 env8323 == env8324) = true)

theorem identity8324 : scanCanonicalize (H12AffineFastState.compose env8324 (packedSelected [0,1,3,4,7,8,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 52) := by decide +kernel

theorem selectedBound8324 : packedSelected [0,1,3,4,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env8325 : List Nat := [2,4,8,16,32,52,41,33,5,33,2048,1,2102,52,2110,2076,0,27,49,2110,52,21,1,34,2070,1,59,53,53,2081,5,52,49,1,0,4]

theorem envBound8325 : H12AffineFastState.Bounded env8325 := by
  intro p hp
  have h : env8325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8324_8325 : H12AffineEnvironment.transform 5 52 env8324 = env8325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 52 env8324 == env8325) = true)

theorem identity8325 : scanCanonicalize (H12AffineFastState.compose env8325 (packedSelected [0,4,7,8,9,11,15] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8325 : packedSelected [0,4,7,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env8326 : List Nat := [2,4,8,0,32,36,41,33,5,33,2048,1,2086,36,2094,2060,0,11,33,2094,36,5,1,34,2054,1,43,37,37,2081,5,36,33,1,0,4]

theorem envBound8326 : H12AffineFastState.Bounded env8326 := by
  intro p hp
  have h : env8326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8325_8326 : H12AffineEnvironment.transform 3 0 env8325 = env8326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8325 == env8326) = true)

theorem identity8326 : scanCanonicalize (H12AffineFastState.compose env8326 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8326 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8327 : List Nat := [2,4,8,0,11,15,2,10,5,10,2048,1,2061,15,2053,2060,0,11,10,2053,15,5,1,9,2054,1,0,14,14,2058,5,15,10,1,0,4]

theorem envBound8327 : H12AffineFastState.Bounded env8327 := by
  intro p hp
  have h : env8327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8326_8327 : H12AffineEnvironment.transform 4 11 env8326 = env8327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8326 == env8327) = true)

def env8328 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,232,8692,8235,4605,262144,4537,8692,64,262267,4436,34,8329,4096,262280,266331,266663,2080,505,262414,4537,0,4097,292]

theorem envBound8328 : H12AffineFastState.Bounded env8328 := by
  intro p hp
  have h : env8328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8318_8328 : H12AffineEnvironment.transform 8 217 env8318 = env8328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8318 == env8328) = true)

theorem identity8328 : scanCanonicalize (H12AffineFastState.compose env8328 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 423) := by decide +kernel

theorem selectedBound8328 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8329 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,232,8692,8235,4605,423,4537,8692,64,476,4436,34,8329,4096,303,4604,4096,2080,505,169,4537,0,4097,292]

theorem envBound8329 : H12AffineFastState.Bounded env8329 := by
  intro p hp
  have h : env8329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8328_8329 : H12AffineEnvironment.transform 17 423 env8328 = env8329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 423 env8328 == env8329) = true)

def env8330 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24771,4605,262144,4960,8692,65,4194304,5005,34,8329,21041,278624,4214984,4215092,18632,505,4211101,4960,16616,21041,1021]

theorem envBound8330 : H12AffineFastState.Bounded env8330 := by
  intro p hp
  have h : env8330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8299_8330 : H12AffineEnvironment.transform 20 65 env8299 = env8330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8299 == env8330) = true)

theorem identity8330 : scanCanonicalize (H12AffineFastState.compose env8330 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 266434) := by decide +kernel

theorem selectedBound8330 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8331 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24771,4605,262144,4960,8692,65,266434,5005,34,8329,21041,278624,278538,279030,18632,505,282975,4960,16616,21041,1021]

theorem envBound8331 : H12AffineFastState.Bounded env8331 := by
  intro p hp
  have h : env8331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8330_8331 : H12AffineEnvironment.transform 21 266434 env8330 = env8331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 266434 env8330 == env8331) = true)

def env8332 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,560,8692,8947,4605,262144,4960,8692,65,266434,5005,34,8329,4097,262736,262714,263110,2808,505,267119,4960,728,4097,1021]

theorem envBound8332 : H12AffineFastState.Bounded env8332 := by
  intro p hp
  have h : env8332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8331_8332 : H12AffineEnvironment.transform 13 560 env8331 = env8332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8331 == env8332) = true)

def env8333 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,232,8692,8235,4605,262144,4536,8692,65,266434,4437,34,8329,4097,262280,262370,262430,2080,505,266679,4536,0,4097,293]

theorem envBound8333 : H12AffineFastState.Bounded env8333 := by
  intro p hp
  have h : env8333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8332_8333 : H12AffineEnvironment.transform 8 216 env8332 = env8333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8332 == env8333) = true)

theorem identity8333 : scanCanonicalize (H12AffineFastState.compose env8333 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4383) := by decide +kernel

theorem selectedBound8333 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8334 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,232,8692,8235,4605,4383,4536,8692,65,477,4437,34,8329,4097,4503,4605,4097,2080,505,168,4536,0,4097,293]

theorem envBound8334 : H12AffineFastState.Bounded env8334 := by
  intro p hp
  have h : env8334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8333_8334 : H12AffineEnvironment.transform 17 4383 env8333 = env8334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4383 env8333 == env8334) = true)

theorem identity8334 : scanCanonicalize (H12AffineFastState.compose env8334 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound8334 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8335 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,185,8192,232,8692,8235,324,422,257,8692,65,477,492,34,8329,184,302,324,184,2080,505,168,257,0,184,293]

theorem envBound8335 : H12AffineFastState.Bounded env8335 := by
  intro p hp
  have h : env8335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8334_8335 : H12AffineEnvironment.transform 11 185 env8334 = env8335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env8334 == env8335) = true)

theorem identity8335 : scanCanonicalize (H12AffineFastState.compose env8335 (packedSelected [3,5,8,14,28] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound8335 : packedSelected [3,5,8,14,28] rootPS < 2^1333 := by decide +kernel

def env8336 : List Nat := [2,4,8,16,32,64,128,256,216,256,303,185,8192,232,8692,8235,324,422,257,8692,65,477,492,34,8329,184,302,324,184,271,505,168,257,0,184,293]

theorem envBound8336 : H12AffineFastState.Bounded env8336 := by
  intro p hp
  have h : env8336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8335_8336 : H12AffineEnvironment.transform 10 303 env8335 = env8336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env8335 == env8336) = true)

theorem identity8336 : scanCanonicalize (H12AffineFastState.compose env8336 (packedSelected [18,23] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8336 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env8337 : List Nat := [2,4,8,16,32,64,128,253,216,253,210,185,8192,232,8201,8235,185,91,252,8201,65,32,17,34,8329,184,211,185,184,242,4,168,252,0,184,216]

theorem envBound8337 : H12AffineFastState.Bounded env8337 := by
  intro p hp
  have h : env8337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8336_8337 : H12AffineEnvironment.transform 7 253 env8336 = env8337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8336 == env8337) = true)

theorem identity8337 : scanCanonicalize (H12AffineFastState.compose env8337 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8337 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8338 : List Nat := [2,4,8,16,32,64,41,84,113,84,123,16,8192,65,8201,8235,16,91,85,8201,65,32,17,34,8224,17,122,16,17,91,4,1,85,0,17,113]

theorem envBound8338 : H12AffineFastState.Bounded env8338 := by
  intro p hp
  have h : env8338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8337_8338 : H12AffineEnvironment.transform 6 41 env8337 = env8338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8337 == env8338) = true)

theorem identity8338 : scanCanonicalize (H12AffineFastState.compose env8338 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound8338 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8339 : List Nat := [2,4,8,16,32,64,41,84,113,84,123,16,57,65,48,18,16,91,85,48,65,32,17,34,25,17,122,16,17,91,4,1,85,0,17,113]

theorem envBound8339 : H12AffineFastState.Bounded env8339 := by
  intro p hp
  have h : env8339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8338_8339 : H12AffineEnvironment.transform 12 57 env8338 = env8339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env8338 == env8339) = true)

theorem identity8339 : scanCanonicalize (H12AffineFastState.compose env8339 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound8339 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env8340 : List Nat := [2,4,8,16,32,32,41,52,17,52,27,16,57,33,48,18,16,59,53,48,33,32,17,34,25,17,26,16,17,59,4,1,53,0,17,17]

theorem envBound8340 : H12AffineFastState.Bounded env8340 := by
  intro p hp
  have h : env8340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8339_8340 : H12AffineEnvironment.transform 5 32 env8339 = env8340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env8339 == env8340) = true)

theorem identity8340 : scanCanonicalize (H12AffineFastState.compose env8340 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8340 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8341 : List Nat := [2,4,8,10,32,32,41,46,11,46,1,10,35,33,42,8,10,33,47,42,33,32,11,34,3,11,0,10,11,33,4,1,47,0,11,11]

theorem envBound8341 : H12AffineFastState.Bounded env8341 := by
  intro p hp
  have h : env8341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8340_8341 : H12AffineEnvironment.transform 3 10 env8340 = env8341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8340 == env8341) = true)

theorem identity8341 : scanCanonicalize (H12AffineFastState.compose env8341 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8341 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8342 : List Nat := [2,4,3,1,32,32,34,37,0,37,1,1,35,33,33,3,1,33,36,33,33,32,0,34,3,0,0,1,0,33,4,1,36,0,0,0]

theorem envBound8342 : H12AffineFastState.Bounded env8342 := by
  intro p hp
  have h : env8342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8341_8342 : H12AffineEnvironment.transform 2 3 env8341 = env8342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8341 == env8342) = true)

theorem identity8342 : scanCanonicalize (H12AffineFastState.compose env8342 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8342 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8343 : List Nat := [2,4,3,1,0,0,2,5,0,5,1,1,3,1,1,3,1,1,4,1,1,0,0,2,3,0,0,1,0,1,4,1,4,0,0,0]

theorem envBound8343 : H12AffineFastState.Bounded env8343 := by
  intro p hp
  have h : env8343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8342_8343 : H12AffineEnvironment.transform 4 0 env8342 = env8343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8342 == env8343) = true)

def leafEnv8343 : List Nat := [2,4,3,1,0,0,2,5,0,5,1,1,3,1,1,3,1,1,4,1,1,0,0,2,5,3,1,0,0,1,0,1,4,1,4,0,5,2,0,0,1,1,0]

def active8343 : List Nat := [0,1]

def tree8343 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8343 : H12WitnessSearch.Good tree8343 := H12GlobalWitnessIndex.good

theorem leafIdentity8343 : H12AffineFastState.composeSystem env8343 rootObs = leafEnv8343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8343 rootObs == leafEnv8343) = true)

theorem terminalChecked8343 : H12PackedTerminal.terminalCheckFast leafEnv8343 active8343 tree8343 = true := by decide +kernel

def env8344 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,233,8692,8234,4605,262144,4537,8692,65,266434,4436,34,8329,4097,262281,262371,262431,2081,505,266678,4537,1,4097,292]

theorem envBound8344 : H12AffineFastState.Bounded env8344 := by
  intro p hp
  have h : env8344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8332_8344 : H12AffineEnvironment.transform 8 217 env8332 = env8344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8332 == env8344) = true)

theorem identity8344 : scanCanonicalize (H12AffineFastState.compose env8344 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8344 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8345 : List Nat := [2,4,8,16,32,64,128,84,217,84,2048,4096,8192,233,8352,8234,4265,262144,4333,8352,65,266434,4096,34,8329,4097,262281,262371,262219,2081,173,266466,4333,1,4097,112]

theorem envBound8345 : H12AffineFastState.Bounded env8345 := by
  intro p hp
  have h : env8345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8344_8345 : H12AffineEnvironment.transform 7 84 env8344 = env8345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8344 == env8345) = true)

theorem identity8345 : scanCanonicalize (H12AffineFastState.compose env8345 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound8345 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8346 : List Nat := [2,4,8,16,32,64,128,84,217,84,2048,17,8192,233,8352,8234,184,262144,252,8352,65,262355,17,34,8329,16,262281,262371,262219,2081,173,262387,252,1,16,112]

theorem envBound8346 : H12AffineFastState.Bounded env8346 := by
  intro p hp
  have h : env8346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8345_8346 : H12AffineEnvironment.transform 11 17 env8345 = env8346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env8345 == env8346) = true)

theorem identity8346 : scanCanonicalize (H12AffineFastState.compose env8346 (packedSelected [13,14,17] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound8346 : packedSelected [13,14,17] rootPS < 2^1333 := by decide +kernel

def env8347 : List Nat := [2,4,8,16,32,64,128,84,217,84,2048,17,8192,233,8352,8234,184,2080,252,8352,65,2291,17,34,8329,16,2217,2243,2155,2081,173,2259,252,1,16,112]

theorem envBound8347 : H12AffineFastState.Bounded env8347 := by
  intro p hp
  have h : env8347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8346_8347 : H12AffineEnvironment.transform 17 2080 env8346 = env8347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env8346 == env8347) = true)

theorem identity8347 : scanCanonicalize (H12AffineFastState.compose env8347 (packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound8347 : packedSelected [0,3,4,7,9,10,12,15,19,28] rootPS < 2^1333 := by decide +kernel

def env8348 : List Nat := [2,4,8,16,32,64,128,84,217,84,42,17,8192,233,8352,8234,184,10,252,8352,65,217,17,34,8329,16,131,233,65,11,173,249,252,1,16,112]

theorem envBound8348 : H12AffineFastState.Bounded env8348 := by
  intro p hp
  have h : env8348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8347_8348 : H12AffineEnvironment.transform 10 42 env8347 = env8348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env8347 == env8348) = true)

theorem identity8348 : scanCanonicalize (H12AffineFastState.compose env8348 (packedSelected [1,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 115) := by decide +kernel

theorem selectedBound8348 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env8349 : List Nat := [2,4,8,16,32,64,128,84,217,84,42,17,115,233,211,89,184,10,252,211,65,217,17,34,250,16,131,233,65,11,173,249,252,1,16,112]

theorem envBound8349 : H12AffineFastState.Bounded env8349 := by
  intro p hp
  have h : env8349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8348_8349 : H12AffineEnvironment.transform 12 115 env8348 = env8349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 115 env8348 == env8349) = true)

theorem identity8349 : scanCanonicalize (H12AffineFastState.compose env8349 (packedSelected [0,4,9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8349 : packedSelected [0,4,9] rootPS < 2^1333 := by decide +kernel

def env8350 : List Nat := [2,4,2,16,32,64,128,84,211,84,32,17,115,227,211,83,178,0,246,211,65,211,17,34,240,16,131,227,65,1,167,243,246,1,16,112]

theorem envBound8350 : H12AffineFastState.Bounded env8350 := by
  intro p hp
  have h : env8350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8349_8350 : H12AffineEnvironment.transform 2 2 env8349 = env8350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8349 == env8350) = true)

theorem identity8350 : scanCanonicalize (H12AffineFastState.compose env8350 (packedSelected [2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 82) := by decide +kernel

theorem selectedBound8350 : packedSelected [2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env8351 : List Nat := [2,4,2,16,32,64,82,84,1,84,32,17,115,49,1,83,96,0,36,1,65,1,17,34,34,16,81,49,65,1,117,33,36,1,16,112]

theorem envBound8351 : H12AffineFastState.Bounded env8351 := by
  intro p hp
  have h : env8351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8350_8351 : H12AffineEnvironment.transform 6 82 env8350 = env8351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 82 env8350 == env8351) = true)

theorem identity8351 : scanCanonicalize (H12AffineFastState.compose env8351 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8351 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8352 : List Nat := [2,4,2,16,32,16,2,4,1,4,32,17,35,49,1,3,48,0,36,1,17,1,17,34,34,16,1,49,17,1,37,33,36,1,16,32]

theorem envBound8352 : H12AffineFastState.Bounded env8352 := by
  intro p hp
  have h : env8352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8351_8352 : H12AffineEnvironment.transform 5 16 env8351 = env8352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8351 == env8352) = true)

theorem identity8352 : scanCanonicalize (H12AffineFastState.compose env8352 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8352 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8353 : List Nat := [2,4,2,1,32,1,2,4,1,4,32,0,35,32,1,3,33,0,36,1,0,1,0,34,34,1,1,32,0,1,37,33,36,1,1,32]

theorem envBound8353 : H12AffineFastState.Bounded env8353 := by
  intro p hp
  have h : env8353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8352_8353 : H12AffineEnvironment.transform 3 1 env8352 = env8353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8352 == env8353) = true)

theorem identity8353 : scanCanonicalize (H12AffineFastState.compose env8353 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8353 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8354 : List Nat := [2,4,2,1,1,1,2,4,1,4,1,0,2,1,1,3,0,0,5,1,0,1,0,3,3,1,1,1,0,1,4,0,5,1,1,1]

theorem envBound8354 : H12AffineFastState.Bounded env8354 := by
  intro p hp
  have h : env8354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8353_8354 : H12AffineEnvironment.transform 4 1 env8353 = env8354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8353 == env8354) = true)

def leafEnv8354 : List Nat := [2,4,2,1,1,1,2,4,1,4,1,0,2,1,1,3,0,0,5,1,0,1,0,3,5,3,1,1,1,1,0,1,4,0,5,1,5,3,1,1,1,1,0]

def active8354 : List Nat := [0,1]

def tree8354 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8354 : H12WitnessSearch.Good tree8354 := H12GlobalWitnessIndex.good

theorem leafIdentity8354 : H12AffineFastState.composeSystem env8354 rootObs = leafEnv8354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8354 rootObs == leafEnv8354) = true)

theorem terminalChecked8354 : H12PackedTerminal.terminalCheckFast leafEnv8354 active8354 tree8354 = true := by decide +kernel

def env8355 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,561,8692,8946,4605,262144,4960,8692,65,266434,5005,34,8329,4096,262737,262715,263111,2809,505,267118,4960,729,4096,1021]

theorem envBound8355 : H12AffineFastState.Bounded env8355 := by
  intro p hp
  have h : env8355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8331_8355 : H12AffineEnvironment.transform 13 561 env8331 = env8355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8331 == env8355) = true)

def env8356 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,233,8692,8234,4605,262144,4536,8692,65,266434,4437,34,8329,4096,262281,262371,262431,2081,505,266678,4536,1,4096,293]

theorem envBound8356 : H12AffineFastState.Bounded env8356 := by
  intro p hp
  have h : env8356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8355_8356 : H12AffineEnvironment.transform 8 216 env8355 = env8356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8355 == env8356) = true)

theorem identity8356 : scanCanonicalize (H12AffineFastState.compose env8356 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8356 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8357 : List Nat := [2,4,8,16,32,64,128,84,216,84,2048,4096,8192,233,8352,8234,4265,262144,4332,8352,65,266434,4097,34,8329,4096,262281,262371,262219,2081,173,266466,4332,1,4096,113]

theorem envBound8357 : H12AffineFastState.Bounded env8357 := by
  intro p hp
  have h : env8357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8356_8357 : H12AffineEnvironment.transform 7 84 env8356 = env8357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8356 == env8357) = true)

theorem identity8357 : scanCanonicalize (H12AffineFastState.compose env8357 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 91) := by decide +kernel

theorem selectedBound8357 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8358 : List Nat := [2,4,8,16,32,64,128,84,216,84,2048,4096,8192,233,8352,8234,4265,91,4332,8352,65,4249,4097,34,8329,4096,210,184,16,2081,173,4281,4332,1,4096,113]

theorem envBound8358 : H12AffineFastState.Bounded env8358 := by
  intro p hp
  have h : env8358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8357_8358 : H12AffineEnvironment.transform 17 91 env8357 = env8358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 91 env8357 == env8358) = true)

theorem identity8358 : scanCanonicalize (H12AffineFastState.compose env8358 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound8358 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8359 : List Nat := [2,4,8,16,32,64,128,84,216,84,130,4096,8192,233,8352,8234,4265,91,4332,8352,65,4249,4097,34,8329,4096,210,184,16,163,173,4281,4332,1,4096,113]

theorem envBound8359 : H12AffineFastState.Bounded env8359 := by
  intro p hp
  have h : env8359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8358_8359 : H12AffineEnvironment.transform 10 130 env8358 = env8359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env8358 == env8359) = true)

theorem identity8359 : scanCanonicalize (H12AffineFastState.compose env8359 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 233) := by decide +kernel

theorem selectedBound8359 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8360 : List Nat := [2,4,8,16,32,64,128,84,216,84,130,233,8192,233,8352,8234,64,91,5,8352,65,112,232,34,8329,233,210,184,16,163,173,80,5,1,233,113]

theorem envBound8360 : H12AffineFastState.Bounded env8360 := by
  intro p hp
  have h : env8360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8359_8360 : H12AffineEnvironment.transform 11 233 env8359 = env8360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env8359 == env8360) = true)

theorem identity8360 : scanCanonicalize (H12AffineFastState.compose env8360 (packedSelected [0,1,2,4,8,11,13] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound8360 : packedSelected [0,1,2,4,8,11,13] rootPS < 2^1333 := by decide +kernel

def env8361 : List Nat := [2,4,8,16,32,49,128,37,169,37,130,152,8192,152,8352,8234,49,42,5,8352,48,1,153,34,8329,152,163,184,16,163,173,33,5,1,152,0]

theorem envBound8361 : H12AffineFastState.Bounded env8361 := by
  intro p hp
  have h : env8361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8360_8361 : H12AffineEnvironment.transform 5 49 env8360 = env8361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env8360 == env8361) = true)

theorem identity8361 : scanCanonicalize (H12AffineFastState.compose env8361 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound8361 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env8362 : List Nat := [2,4,8,16,32,49,8,37,33,37,10,16,8192,16,8232,8234,49,42,5,8232,48,1,17,34,8193,16,43,48,16,43,37,33,5,1,16,0]

theorem envBound8362 : H12AffineFastState.Bounded env8362 := by
  intro p hp
  have h : env8362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8361_8362 : H12AffineEnvironment.transform 6 8 env8361 = env8362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env8361 == env8362) = true)

theorem identity8362 : scanCanonicalize (H12AffineFastState.compose env8362 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8362 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8363 : List Nat := [2,4,8,16,17,0,8,20,16,20,10,16,8192,16,8217,8219,0,27,5,8217,1,1,17,19,8193,16,26,1,16,26,20,16,5,1,16,0]

theorem envBound8363 : H12AffineFastState.Bounded env8363 := by
  intro p hp
  have h : env8363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8362_8363 : H12AffineEnvironment.transform 4 17 env8362 = env8363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8362 == env8363) = true)

theorem identity8363 : scanCanonicalize (H12AffineFastState.compose env8363 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8363 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8364 : List Nat := [2,4,2,16,17,0,2,20,16,20,0,16,8192,16,8211,8209,0,17,5,8211,1,1,17,19,8193,16,16,1,16,16,20,16,5,1,16,0]

theorem envBound8364 : H12AffineFastState.Bounded env8364 := by
  intro p hp
  have h : env8364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8363_8364 : H12AffineEnvironment.transform 2 2 env8363 = env8364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8363 == env8364) = true)

theorem identity8364 : scanCanonicalize (H12AffineFastState.compose env8364 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 19) := by decide +kernel

theorem selectedBound8364 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8365 : List Nat := [2,4,2,16,17,0,2,20,16,20,0,16,19,16,0,2,0,17,5,0,1,1,17,19,18,16,16,1,16,16,20,16,5,1,16,0]

theorem envBound8365 : H12AffineFastState.Bounded env8365 := by
  intro p hp
  have h : env8365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8364_8365 : H12AffineEnvironment.transform 12 19 env8364 = env8365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 19 env8364 == env8365) = true)

theorem identity8365 : scanCanonicalize (H12AffineFastState.compose env8365 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8365 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8366 : List Nat := [2,4,2,0,1,0,2,4,0,4,0,0,3,0,0,2,0,1,5,0,1,1,1,3,2,0,0,1,0,0,4,0,5,1,0,0]

theorem envBound8366 : H12AffineFastState.Bounded env8366 := by
  intro p hp
  have h : env8366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8365_8366 : H12AffineEnvironment.transform 3 0 env8365 = env8366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8365 == env8366) = true)

def env8367 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,232,8692,8235,4605,262144,4537,8692,65,266434,4436,34,8329,4096,262280,262370,262430,2080,505,266679,4537,0,4096,292]

theorem envBound8367 : H12AffineFastState.Bounded env8367 := by
  intro p hp
  have h : env8367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8355_8367 : H12AffineEnvironment.transform 8 217 env8355 = env8367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8355 == env8367) = true)

theorem identity8367 : scanCanonicalize (H12AffineFastState.compose env8367 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4383) := by decide +kernel

theorem selectedBound8367 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8368 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,232,8692,8235,4605,4383,4537,8692,65,477,4436,34,8329,4096,4503,4605,4097,2080,505,168,4537,0,4096,292]

theorem envBound8368 : H12AffineFastState.Bounded env8368 := by
  intro p hp
  have h : env8368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8367_8368 : H12AffineEnvironment.transform 17 4383 env8367 = env8368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4383 env8367 == env8368) = true)

theorem identity8368 : scanCanonicalize (H12AffineFastState.compose env8368 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound8368 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8369 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,492,8192,232,8692,8235,17,243,85,8692,65,477,184,34,8329,492,123,17,493,2080,505,168,85,0,492,292]

theorem envBound8369 : H12AffineFastState.Bounded env8369 := by
  intro p hp
  have h : env8369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8368_8369 : H12AffineEnvironment.transform 11 492 env8368 = env8369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env8368 == env8369) = true)

theorem identity8369 : scanCanonicalize (H12AffineFastState.compose env8369 (packedSelected [0,7,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound8369 : packedSelected [0,7,14,20] rootPS < 2^1333 := by decide +kernel

def env8370 : List Nat := [2,4,8,16,32,64,128,5,217,5,2048,233,8192,232,8433,8235,17,243,85,8433,65,216,184,34,8329,233,123,17,232,2080,252,168,85,0,233,33]

theorem envBound8370 : H12AffineFastState.Bounded env8370 := by
  intro p hp
  have h : env8370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8369_8370 : H12AffineEnvironment.transform 7 5 env8369 = env8370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env8369 == env8370) = true)

theorem identity8370 : scanCanonicalize (H12AffineFastState.compose env8370 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 211) := by decide +kernel

theorem selectedBound8370 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8371 : List Nat := [2,4,8,16,32,64,128,5,217,5,211,233,8192,232,8433,8235,17,243,85,8433,65,216,184,34,8329,233,123,17,232,243,252,168,85,0,233,33]

theorem envBound8371 : H12AffineFastState.Bounded env8371 := by
  intro p hp
  have h : env8371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8370_8371 : H12AffineEnvironment.transform 10 211 env8370 = env8371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 211 env8370 == env8371) = true)

theorem identity8371 : scanCanonicalize (H12AffineFastState.compose env8371 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8371 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8372 : List Nat := [2,4,8,16,32,64,120,5,33,5,43,17,8192,16,8201,8235,17,11,85,8201,65,32,64,34,8305,17,123,17,16,11,4,80,85,0,17,33]

theorem envBound8372 : H12AffineFastState.Bounded env8372 := by
  intro p hp
  have h : env8372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8371_8372 : H12AffineEnvironment.transform 6 120 env8371 = env8372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8371 == env8372) = true)

theorem identity8372 : scanCanonicalize (H12AffineFastState.compose env8372 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 115) := by decide +kernel

theorem selectedBound8372 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env8373 : List Nat := [2,4,8,16,32,64,120,5,33,5,43,17,115,16,122,88,17,11,85,122,65,32,64,34,2,17,123,17,16,11,4,80,85,0,17,33]

theorem envBound8373 : H12AffineFastState.Bounded env8373 := by
  intro p hp
  have h : env8373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8372_8373 : H12AffineEnvironment.transform 12 115 env8372 = env8373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 115 env8372 == env8373) = true)

theorem identity8373 : scanCanonicalize (H12AffineFastState.compose env8373 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound8373 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8374 : List Nat := [2,4,8,16,32,58,2,5,33,5,43,17,9,16,0,34,17,11,47,0,59,32,58,34,2,17,1,17,16,11,4,42,47,0,17,33]

theorem envBound8374 : H12AffineFastState.Bounded env8374 := by
  intro p hp
  have h : env8374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8373_8374 : H12AffineEnvironment.transform 5 58 env8373 = env8374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env8373 == env8374) = true)

theorem identity8374 : scanCanonicalize (H12AffineFastState.compose env8374 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound8374 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env8375 : List Nat := [2,4,8,16,16,10,2,5,17,5,27,17,9,16,0,18,17,11,31,0,11,16,10,18,2,17,1,17,16,11,4,26,31,0,17,17]

theorem envBound8375 : H12AffineFastState.Bounded env8375 := by
  intro p hp
  have h : env8375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8374_8375 : H12AffineEnvironment.transform 4 16 env8374 = env8375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env8374 == env8375) = true)

def env8376 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,4961,8692,2097152,4194304,5004,90337,8329,21041,278625,4214985,4215093,75786,504,4268383,4961,73770,2175666,90942]

theorem envBound8376 : H12AffineFastState.Bounded env8376 := by
  intro p hp
  have h : env8376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8297_8376 : H12AffineEnvironment.transform 18 4961 env8297 = env8376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env8297 == env8376) = true)

theorem identity8376 : scanCanonicalize (H12AffineFastState.compose env8376 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8376 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8377 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,2097152,4194304,4721,90337,8329,21041,278625,4214985,4214984,75786,5,4268194,4764,73770,2175666,90819]

theorem envBound8377 : H12AffineFastState.Bounded env8377 := by
  intro p hp
  have h : env8377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8376_8377 : H12AffineEnvironment.transform 7 253 env8376 = env8377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8376 == env8377) = true)

def env8378 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,64,4194304,4721,90337,8329,21041,278625,4214985,4214984,75786,5,4268194,4764,73770,78578,90819]

theorem envBound8378 : H12AffineFastState.Bounded env8378 := by
  intro p hp
  have h : env8378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8377_8378 : H12AffineEnvironment.transform 20 64 env8377 = env8378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8377 == env8378) = true)

theorem identity8378 : scanCanonicalize (H12AffineFastState.compose env8378 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 90640) := by decide +kernel

theorem selectedBound8378 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8379 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,90640,4764,8201,64,4194304,4721,90337,8329,21041,74353,4214985,4214984,75786,5,4268194,4764,73770,78578,90819]

theorem envBound8379 : H12AffineFastState.Bounded env8379 := by
  intro p hp
  have h : env8379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8378_8379 : H12AffineEnvironment.transform 17 90640 env8378 = env8379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90640 env8378 == env8379) = true)

def env8380 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,90640,4764,8201,64,16960,4721,90337,8329,21041,74353,4745,4744,75786,5,90850,4764,73770,78578,90819]

theorem envBound8380 : H12AffineFastState.Bounded env8380 := by
  intro p hp
  have h : env8380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8379_8380 : H12AffineEnvironment.transform 21 16960 env8379 = env8380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16960 env8379 == env8380) = true)

def env8381 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8201,65536,4096,73760,4764,8201,64,112,4721,74449,8329,4097,74353,4745,4744,75786,5,73938,4764,73770,78578,73971]

theorem envBound8381 : H12AffineFastState.Bounded env8381 := by
  intro p hp
  have h : env8381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8380_8381 : H12AffineEnvironment.transform 13 560 env8380 = env8381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8380 == env8381) = true)

theorem identity8381 : scanCanonicalize (H12AffineFastState.compose env8381 (packedSelected [7,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8381 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8382 : List Nat := [2,4,8,16,32,64,120,5,512,5,2048,4096,8192,560,8201,65536,4096,73760,4708,8201,64,112,4721,74281,8305,4097,74353,4721,4720,75786,5,73770,4708,73770,78346,73739]

theorem envBound8382 : H12AffineFastState.Bounded env8382 := by
  intro p hp
  have h : env8382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8381_8382 : H12AffineEnvironment.transform 6 120 env8381 = env8382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8381 == env8382) = true)

theorem identity8382 : scanCanonicalize (H12AffineFastState.compose env8382 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 14881) := by decide +kernel

theorem selectedBound8382 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env8383 : List Nat := [2,4,8,16,32,64,120,5,512,5,2048,4096,8192,560,8201,14881,4096,6657,4708,8201,64,112,4721,6152,8305,4097,6224,4721,4720,4651,5,6667,4708,6667,2091,6698]

theorem envBound8383 : H12AffineFastState.Bounded env8383 := by
  intro p hp
  have h : env8383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8382_8383 : H12AffineEnvironment.transform 15 14881 env8382 = env8383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14881 env8382 == env8383) = true)

theorem identity8383 : scanCanonicalize (H12AffineFastState.compose env8383 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound8383 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env8384 : List Nat := [2,4,8,16,32,64,120,5,96,5,2048,4096,8192,80,8201,14401,4096,6241,4100,8201,64,112,4113,6152,8305,4097,6224,4113,4112,4171,5,6251,4100,6251,2091,6218]

theorem envBound8384 : H12AffineFastState.Bounded env8384 := by
  intro p hp
  have h : env8384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8383_8384 : H12AffineEnvironment.transform 8 96 env8383 = env8384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env8383 == env8384) = true)

theorem identity8384 : scanCanonicalize (H12AffineFastState.compose env8384 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound8384 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8385 : List Nat := [2,4,8,16,32,64,120,5,96,5,2048,2090,8192,80,8201,8299,2090,75,2094,8201,64,112,2107,34,8305,2091,122,2107,2106,2145,5,65,2094,65,2091,96]

theorem envBound8385 : H12AffineFastState.Bounded env8385 := by
  intro p hp
  have h : env8385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8384_8385 : H12AffineEnvironment.transform 11 2090 env8384 = env8385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env8384 == env8385) = true)

theorem identity8385 : scanCanonicalize (H12AffineFastState.compose env8385 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8385 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8386 : List Nat := [2,4,8,16,32,16,40,5,48,5,2048,2090,8192,0,8201,8251,2090,27,2094,8201,16,32,2107,34,8225,2091,42,2107,2106,2097,5,17,2094,17,2091,48]

theorem envBound8386 : H12AffineFastState.Bounded env8386 := by
  intro p hp
  have h : env8386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8385_8386 : H12AffineEnvironment.transform 5 16 env8385 = env8386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8385 == env8386) = true)

theorem identity8386 : scanCanonicalize (H12AffineFastState.compose env8386 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2105) := by decide +kernel

theorem selectedBound8386 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env8387 : List Nat := [2,4,8,16,32,16,40,5,48,5,2048,2090,2105,0,2096,2050,2090,27,2094,2096,16,32,2107,34,2072,2091,42,2107,2106,2097,5,17,2094,17,2091,48]

theorem envBound8387 : H12AffineFastState.Bounded env8387 := by
  intro p hp
  have h : env8387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8386_8387 : H12AffineEnvironment.transform 12 2105 env8386 = env8387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2105 env8386 == env8387) = true)

theorem identity8387 : scanCanonicalize (H12AffineFastState.compose env8387 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound8387 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8388 : List Nat := [2,4,8,16,32,16,40,5,48,5,0,42,57,0,48,2,42,27,46,48,16,32,59,34,24,43,42,59,58,49,5,17,46,17,43,48]

theorem envBound8388 : H12AffineFastState.Bounded env8388 := by
  intro p hp
  have h : env8388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8387_8388 : H12AffineEnvironment.transform 10 0 env8387 = env8388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8387 == env8388) = true)

theorem identity8388 : scanCanonicalize (H12AffineFastState.compose env8388 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8388 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8389 : List Nat := [2,4,8,1,32,1,40,5,33,5,0,42,40,0,33,2,42,10,46,33,1,32,42,34,9,43,42,42,43,32,5,0,46,0,43,33]

theorem envBound8389 : H12AffineFastState.Bounded env8389 := by
  intro p hp
  have h : env8389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8388_8389 : H12AffineEnvironment.transform 3 1 env8388 = env8389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8388 == env8389) = true)

theorem identity8389 : scanCanonicalize (H12AffineFastState.compose env8389 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8389 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8390 : List Nat := [2,4,8,1,11,1,3,5,10,5,0,1,3,0,10,2,1,10,5,10,1,11,1,9,9,0,1,1,0,11,5,0,5,0,0,10]

theorem envBound8390 : H12AffineFastState.Bounded env8390 := by
  intro p hp
  have h : env8390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8389_8390 : H12AffineEnvironment.transform 4 11 env8389 = env8390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8389 == env8390) = true)

theorem identity8390 : scanCanonicalize (H12AffineFastState.compose env8390 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8390 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8391 : List Nat := [2,4,3,1,0,1,3,5,1,5,0,1,3,0,1,2,1,1,5,1,1,0,1,2,2,0,1,1,0,0,5,0,5,0,0,1]

theorem envBound8391 : H12AffineFastState.Bounded env8391 := by
  intro p hp
  have h : env8391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8390_8391 : H12AffineEnvironment.transform 2 3 env8390 = env8391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8390 == env8391) = true)

def env8392 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8201,65536,4096,73761,4764,8201,64,113,4721,74448,8329,4096,74353,4745,4744,75786,5,73939,4764,73770,78578,73970]

theorem envBound8392 : H12AffineFastState.Bounded env8392 := by
  intro p hp
  have h : env8392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8380_8392 : H12AffineEnvironment.transform 13 561 env8380 = env8392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8380 == env8392) = true)

def env8393 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,664,8192,561,8201,65536,664,73761,4,8201,64,113,233,74448,8329,664,74353,17,16,75786,5,73939,4,73770,73834,73970]

theorem envBound8393 : H12AffineFastState.Bounded env8393 := by
  intro p hp
  have h : env8393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8392_8393 : H12AffineEnvironment.transform 11 664 env8392 = env8393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 664 env8392 == env8393) = true)

theorem identity8393 : scanCanonicalize (H12AffineFastState.compose env8393 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound8393 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8394 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,664,8192,561,8201,8714,664,555,4,8201,64,113,233,218,8329,664,123,17,16,2560,5,729,4,544,608,760]

theorem envBound8394 : H12AffineFastState.Bounded env8394 := by
  intro p hp
  have h : env8394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8393_8394 : H12AffineEnvironment.transform 15 8714 env8393 = env8394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env8393 == env8394) = true)

theorem identity8394 : scanCanonicalize (H12AffineFastState.compose env8394 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound8394 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8395 : List Nat := [2,4,8,16,32,64,128,253,512,253,603,664,8192,561,8201,8714,664,555,4,8201,64,113,233,218,8329,664,123,17,16,91,5,729,4,544,608,760]

theorem envBound8395 : H12AffineFastState.Bounded env8395 := by
  intro p hp
  have h : env8395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8394_8395 : H12AffineEnvironment.transform 10 603 env8394 = env8395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env8394 == env8395) = true)

theorem identity8395 : scanCanonicalize (H12AffineFastState.compose env8395 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound8395 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env8396 : List Nat := [2,4,8,16,32,64,128,253,32,253,123,184,8192,17,8201,8234,184,11,4,8201,64,113,233,218,8329,184,123,17,16,91,5,249,4,0,64,216]

theorem envBound8396 : H12AffineFastState.Bounded env8396 := by
  intro p hp
  have h : env8396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8395_8396 : H12AffineEnvironment.transform 8 32 env8395 = env8396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env8395 == env8396) = true)

theorem identity8396 : scanCanonicalize (H12AffineFastState.compose env8396 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound8396 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env8397 : List Nat := [2,4,8,16,32,64,34,95,32,95,123,26,8192,17,8201,8234,26,11,4,8201,64,113,75,120,8235,26,123,17,16,91,5,91,4,0,64,122]

theorem envBound8397 : H12AffineFastState.Bounded env8397 := by
  intro p hp
  have h : env8397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8396_8397 : H12AffineEnvironment.transform 6 34 env8396 = env8397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env8396 == env8397) = true)

theorem identity8397 : scanCanonicalize (H12AffineFastState.compose env8397 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound8397 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env8398 : List Nat := [2,4,8,16,32,64,34,95,32,95,123,26,3,17,10,41,26,11,4,10,64,113,75,120,40,26,123,17,16,91,5,91,4,0,64,122]

theorem envBound8398 : H12AffineFastState.Bounded env8398 := by
  intro p hp
  have h : env8398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8397_8398 : H12AffineEnvironment.transform 12 3 env8397 = env8398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env8397 == env8398) = true)

theorem identity8398 : scanCanonicalize (H12AffineFastState.compose env8398 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound8398 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env8399 : List Nat := [2,4,8,16,32,59,34,36,32,36,0,26,3,17,10,41,26,11,4,10,59,10,48,3,40,26,0,17,16,32,5,32,4,0,59,1]

theorem envBound8399 : H12AffineFastState.Bounded env8399 := by
  intro p hp
  have h : env8399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8398_8399 : H12AffineEnvironment.transform 5 59 env8398 = env8399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env8398 == env8399) = true)

theorem identity8399 : scanCanonicalize (H12AffineFastState.compose env8399 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound8399 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8400 : List Nat := [2,4,8,16,26,1,24,30,26,30,0,26,3,17,10,19,26,11,4,10,1,10,10,3,18,26,0,17,16,26,5,26,4,0,1,1]

theorem envBound8400 : H12AffineFastState.Bounded env8400 := by
  intro p hp
  have h : env8400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8399_8400 : H12AffineEnvironment.transform 4 26 env8399 = env8400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env8399 == env8400) = true)

theorem identity8400 : scanCanonicalize (H12AffineFastState.compose env8400 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8400 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8401 : List Nat := [2,4,8,0,10,1,8,14,10,14,0,10,3,1,10,3,10,11,4,10,1,10,10,3,2,10,0,1,0,10,5,10,4,0,1,1]

theorem envBound8401 : H12AffineFastState.Bounded env8401 := by
  intro p hp
  have h : env8401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8400_8401 : H12AffineEnvironment.transform 3 0 env8400 = env8401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8400 == env8401) = true)

def env8402 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,665,8192,561,8201,65536,665,73761,5,8201,64,113,232,74448,8329,665,74353,16,17,75786,5,73939,5,73770,73835,73970]

theorem envBound8402 : H12AffineFastState.Bounded env8402 := by
  intro p hp
  have h : env8402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8392_8402 : H12AffineEnvironment.transform 11 665 env8392 = env8402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 665 env8392 == env8402) = true)

theorem identity8402 : scanCanonicalize (H12AffineFastState.compose env8402 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound8402 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8403 : List Nat := [2,4,8,16,32,64,128,253,32,253,2048,185,8192,17,8201,65536,185,73761,5,8201,64,113,232,73968,8329,185,73809,16,17,75786,5,73939,5,73770,73835,73970]

theorem envBound8403 : H12AffineFastState.Bounded env8403 := by
  intro p hp
  have h : env8403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8402_8403 : H12AffineEnvironment.transform 8 32 env8402 = env8403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env8402 == env8403) = true)

theorem identity8403 : scanCanonicalize (H12AffineFastState.compose env8403 (packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 10408) := by decide +kernel

theorem selectedBound8403 : packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env8404 : List Nat := [2,4,8,16,32,64,128,253,32,253,2048,185,8192,17,8201,10408,185,2185,5,8201,64,113,232,2136,8329,185,2297,16,17,162,5,2171,5,2178,2243,2138]

theorem envBound8404 : H12AffineFastState.Bounded env8404 := by
  intro p hp
  have h : env8404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8403_8404 : H12AffineEnvironment.transform 15 10408 env8403 = env8404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10408 env8403 == env8404) = true)

theorem identity8404 : scanCanonicalize (H12AffineFastState.compose env8404 (packedSelected [0,1,3,4,5,7,8,9,10,13,17,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8404 : packedSelected [0,1,3,4,5,7,8,9,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env8405 : List Nat := [2,4,8,16,32,16,128,173,32,173,2048,185,8192,17,8201,10408,185,2185,5,8201,16,33,184,2056,8329,185,2217,16,17,162,5,2091,5,2178,2195,2058]

theorem envBound8405 : H12AffineFastState.Bounded env8405 := by
  intro p hp
  have h : env8405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8404_8405 : H12AffineEnvironment.transform 5 16 env8404 = env8405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8404 == env8405) = true)

theorem identity8405 : scanCanonicalize (H12AffineFastState.compose env8405 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8405 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8406 : List Nat := [2,4,8,16,32,16,41,4,32,4,2048,16,8192,17,8201,10241,16,2080,5,8201,16,33,17,2056,8224,16,2048,16,17,11,5,2091,5,2091,2106,2058]

theorem envBound8406 : H12AffineFastState.Bounded env8406 := by
  intro p hp
  have h : env8406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8405_8406 : H12AffineEnvironment.transform 6 41 env8405 = env8406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8405 == env8406) = true)

theorem identity8406 : scanCanonicalize (H12AffineFastState.compose env8406 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8406 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env8407 : List Nat := [2,4,8,16,27,16,18,4,27,4,2048,16,8192,17,8201,10241,16,2075,5,8201,16,26,17,2056,8219,16,2048,16,17,11,5,2064,5,2064,2049,2058]

theorem envBound8407 : H12AffineFastState.Bounded env8407 := by
  intro p hp
  have h : env8407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8406_8407 : H12AffineEnvironment.transform 4 27 env8406 = env8407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8406 == env8407) = true)

theorem identity8407 : scanCanonicalize (H12AffineFastState.compose env8407 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound8407 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env8408 : List Nat := [2,4,8,16,27,16,18,4,27,4,2048,16,24,17,17,2073,16,2075,5,17,16,26,17,2056,3,16,2048,16,17,11,5,2064,5,2064,2049,2058]

theorem envBound8408 : H12AffineFastState.Bounded env8408 := by
  intro p hp
  have h : env8408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8407_8408 : H12AffineEnvironment.transform 12 24 env8407 = env8408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env8407 == env8408) = true)

theorem identity8408 : scanCanonicalize (H12AffineFastState.compose env8408 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound8408 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8409 : List Nat := [2,4,8,16,27,16,18,4,27,4,16,16,24,17,17,9,16,11,5,17,16,26,17,24,3,16,16,16,17,11,5,0,5,0,17,26]

theorem envBound8409 : H12AffineFastState.Bounded env8409 := by
  intro p hp
  have h : env8409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8408_8409 : H12AffineEnvironment.transform 10 16 env8408 = env8409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env8408 == env8409) = true)

theorem identity8409 : scanCanonicalize (H12AffineFastState.compose env8409 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound8409 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8410 : List Nat := [2,4,8,4,15,4,6,4,15,4,4,4,12,5,5,9,4,11,5,5,4,14,5,12,3,4,4,4,5,11,5,0,5,0,5,14]

theorem envBound8410 : H12AffineFastState.Bounded env8410 := by
  intro p hp
  have h : env8410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8409_8410 : H12AffineEnvironment.transform 3 4 env8409 = env8410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env8409 == env8410) = true)

def env8411 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,90640,4764,8201,64,16961,4721,90337,8329,21041,74353,4744,4745,75786,5,90851,4764,73770,78578,90819]

theorem envBound8411 : H12AffineFastState.Bounded env8411 := by
  intro p hp
  have h : env8411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8379_8411 : H12AffineEnvironment.transform 21 16961 env8379 = env8411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16961 env8379 == env8411) = true)

def env8412 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8201,65536,4096,73760,4764,8201,64,113,4721,74449,8329,4097,74353,4744,4745,75786,5,73939,4764,73770,78578,73971]

theorem envBound8412 : H12AffineFastState.Bounded env8412 := by
  intro p hp
  have h : env8412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8411_8412 : H12AffineEnvironment.transform 13 560 env8411 = env8412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8411 == env8412) = true)

theorem identity8412 : scanCanonicalize (H12AffineFastState.compose env8412 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound8412 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8413 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8201,8714,4096,554,4764,8201,64,113,4721,219,8329,4097,123,4744,4745,2560,5,729,4764,544,4344,761]

theorem envBound8413 : H12AffineFastState.Bounded env8413 := by
  intro p hp
  have h : env8413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8412_8413 : H12AffineEnvironment.transform 15 8714 env8412 = env8413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env8412 == env8413) = true)

theorem identity8413 : scanCanonicalize (H12AffineFastState.compose env8413 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound8413 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8414 : List Nat := [2,4,8,16,32,64,128,253,49,253,2048,4096,8192,1,8201,8251,4096,27,4269,8201,64,113,4160,219,8329,4097,123,4281,4280,2097,5,232,4269,17,4344,200]

theorem envBound8414 : H12AffineFastState.Bounded env8414 := by
  intro p hp
  have h : env8414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8413_8414 : H12AffineEnvironment.transform 8 49 env8413 = env8414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env8413 == env8414) = true)

theorem identity8414 : scanCanonicalize (H12AffineFastState.compose env8414 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound8414 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env8415 : List Nat := [2,4,8,16,32,64,128,253,49,253,2048,2194,8192,1,8201,8251,2194,27,2111,8201,64,113,2258,219,8329,2195,123,2091,2090,2097,5,232,2111,17,2154,200]

theorem envBound8415 : H12AffineFastState.Bounded env8415 := by
  intro p hp
  have h : env8415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8414_8415 : H12AffineEnvironment.transform 11 2194 env8414 = env8415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env8414 == env8415) = true)

theorem identity8415 : scanCanonicalize (H12AffineFastState.compose env8415 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound8415 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8416 : List Nat := [2,4,8,16,32,64,57,68,49,68,2048,2091,8192,1,8201,8251,2091,27,2111,8201,64,113,2155,98,8240,2090,123,2091,2090,2097,5,81,2111,17,2154,113]

theorem envBound8416 : H12AffineFastState.Bounded env8416 := by
  intro p hp
  have h : env8416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8415_8416 : H12AffineEnvironment.transform 6 57 env8415 = env8416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env8415 == env8416) = true)

theorem identity8416 : scanCanonicalize (H12AffineFastState.compose env8416 (packedSelected [1,3,13,14] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound8416 : packedSelected [1,3,13,14] rootPS < 2^1333 := by decide +kernel

def env8417 : List Nat := [2,4,8,16,32,64,57,68,49,68,2048,2091,88,1,81,99,2091,27,2111,81,64,113,2155,98,104,2090,123,2091,2090,2097,5,81,2111,17,2154,113]

theorem envBound8417 : H12AffineFastState.Bounded env8417 := by
  intro p hp
  have h : env8417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8416_8417 : H12AffineEnvironment.transform 12 88 env8416 = env8417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env8416 == env8417) = true)

theorem identity8417 : scanCanonicalize (H12AffineFastState.compose env8417 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8417 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env8418 : List Nat := [2,4,8,16,32,16,57,20,49,20,2048,2091,8,1,1,51,2091,27,2111,1,16,33,2107,50,56,2090,43,2091,2090,2097,5,1,2111,17,2106,33]

theorem envBound8418 : H12AffineFastState.Bounded env8418 := by
  intro p hp
  have h : env8418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8417_8418 : H12AffineEnvironment.transform 5 16 env8417 = env8418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8417 == env8418) = true)

theorem identity8418 : scanCanonicalize (H12AffineFastState.compose env8418 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8418 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8419 : List Nat := [2,4,8,1,32,1,40,5,32,5,2048,2091,8,1,1,34,2091,10,2094,1,1,33,2090,35,41,2090,43,2091,2090,2080,5,1,2094,0,2091,33]

theorem envBound8419 : H12AffineFastState.Bounded env8419 := by
  intro p hp
  have h : env8419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8418_8419 : H12AffineEnvironment.transform 3 1 env8418 = env8419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8418 == env8419) = true)

theorem identity8419 : scanCanonicalize (H12AffineFastState.compose env8419 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 36) := by decide +kernel

theorem selectedBound8419 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8420 : List Nat := [2,4,8,1,32,1,40,5,32,5,36,15,8,1,1,34,15,10,10,1,1,33,14,35,41,14,43,15,14,4,5,1,10,0,15,33]

theorem envBound8420 : H12AffineFastState.Bounded env8420 := by
  intro p hp
  have h : env8420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8419_8420 : H12AffineEnvironment.transform 10 36 env8419 = env8420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 36 env8419 == env8420) = true)

theorem identity8420 : scanCanonicalize (H12AffineFastState.compose env8420 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8420 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8421 : List Nat := [2,4,2,1,32,1,34,5,32,5,36,5,2,1,1,34,5,0,0,1,1,33,4,35,35,4,33,5,4,4,5,1,0,0,5,33]

theorem envBound8421 : H12AffineFastState.Bounded env8421 := by
  intro p hp
  have h : env8421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8420_8421 : H12AffineEnvironment.transform 2 2 env8420 = env8421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8420 == env8421) = true)

theorem identity8421 : scanCanonicalize (H12AffineFastState.compose env8421 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound8421 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8422 : List Nat := [2,4,2,1,5,1,7,5,5,5,1,5,2,1,1,7,5,0,0,1,1,4,4,6,6,4,4,5,4,4,5,1,0,0,5,4]

theorem envBound8422 : H12AffineFastState.Bounded env8422 := by
  intro p hp
  have h : env8422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8421_8422 : H12AffineEnvironment.transform 4 5 env8421 = env8422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env8421 == env8422) = true)

theorem identity8422 : scanCanonicalize (H12AffineFastState.compose env8422 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8422 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8423 : List Nat := [2,0,2,1,1,1,3,1,1,1,1,1,2,1,1,3,1,0,0,1,1,0,0,2,2,0,0,1,0,0,1,1,0,0,1,0]

theorem envBound8423 : H12AffineFastState.Bounded env8423 := by
  intro p hp
  have h : env8423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8422_8423 : H12AffineEnvironment.transform 1 0 env8422 = env8423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8422 == env8423) = true)

def env8424 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8201,65536,4096,73761,4764,8201,64,112,4721,74448,8329,4096,74353,4744,4745,75786,5,73938,4764,73770,78578,73970]

theorem envBound8424 : H12AffineFastState.Bounded env8424 := by
  intro p hp
  have h : env8424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8411_8424 : H12AffineEnvironment.transform 13 561 env8411 = env8424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8411 == env8424) = true)

theorem identity8424 : scanCanonicalize (H12AffineFastState.compose env8424 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8946) := by decide +kernel

theorem selectedBound8424 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8425 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8201,8946,4096,723,4764,8201,64,112,4721,34,8329,4096,131,4744,4745,2808,5,544,4764,728,4096,512]

theorem envBound8425 : H12AffineFastState.Bounded env8425 := by
  intro p hp
  have h : env8425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8424_8425 : H12AffineEnvironment.transform 15 8946 env8424 = env8425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8946 env8424 == env8425) = true)

theorem identity8425 : scanCanonicalize (H12AffineFastState.compose env8425 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2787) := by decide +kernel

theorem selectedBound8425 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env8426 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,2787,8192,561,8201,8946,2787,723,2175,8201,64,112,2194,34,8329,2787,131,2155,2154,2808,5,544,2175,728,2787,512]

theorem envBound8426 : H12AffineFastState.Bounded env8426 := by
  intro p hp
  have h : env8426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8425_8426 : H12AffineEnvironment.transform 11 2787 env8425 = env8426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2787 env8425 == env8426) = true)

theorem identity8426 : scanCanonicalize (H12AffineFastState.compose env8426 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8426 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env8427 : List Nat := [2,4,8,16,32,64,120,5,512,5,2048,2587,8192,561,8201,8714,2587,555,2175,8201,64,112,2154,34,8305,2587,123,2155,2154,2560,5,544,2175,544,2587,512]

theorem envBound8427 : H12AffineFastState.Bounded env8427 := by
  intro p hp
  have h : env8427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8426_8427 : H12AffineEnvironment.transform 6 120 env8426 = env8427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8426 == env8427) = true)

theorem identity8427 : scanCanonicalize (H12AffineFastState.compose env8427 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8427 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8428 : List Nat := [2,4,8,16,32,16,40,5,512,5,2048,2587,8192,561,8201,8714,2587,555,2095,8201,16,32,2106,34,8225,2587,43,2107,2106,2560,5,544,2095,544,2587,512]

theorem envBound8428 : H12AffineFastState.Bounded env8428 := by
  intro p hp
  have h : env8428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8427_8428 : H12AffineEnvironment.transform 5 16 env8427 = env8428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8427 == env8428) = true)

theorem identity8428 : scanCanonicalize (H12AffineFastState.compose env8428 (packedSelected [0,1,2,3,4,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound8428 : packedSelected [0,1,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env8429 : List Nat := [2,4,8,16,32,16,40,5,49,5,2048,2090,8192,0,8201,8251,2090,26,2095,8201,16,32,2106,34,8225,2090,43,2107,2106,2097,5,17,2095,17,2090,49]

theorem envBound8429 : H12AffineFastState.Bounded env8429 := by
  intro p hp
  have h : env8429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8428_8429 : H12AffineEnvironment.transform 8 49 env8428 = env8429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env8428 == env8429) = true)

theorem identity8429 : scanCanonicalize (H12AffineFastState.compose env8429 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2105) := by decide +kernel

theorem selectedBound8429 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env8430 : List Nat := [2,4,8,16,32,16,40,5,49,5,2048,2090,2105,0,2096,2050,2090,26,2095,2096,16,32,2106,34,2072,2090,43,2107,2106,2097,5,17,2095,17,2090,49]

theorem envBound8430 : H12AffineFastState.Bounded env8430 := by
  intro p hp
  have h : env8430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8429_8430 : H12AffineEnvironment.transform 12 2105 env8429 = env8430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2105 env8429 == env8430) = true)

theorem identity8430 : scanCanonicalize (H12AffineFastState.compose env8430 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound8430 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8431 : List Nat := [2,4,8,16,32,16,40,5,49,5,0,42,57,0,48,2,42,26,47,48,16,32,58,34,24,42,43,59,58,49,5,17,47,17,42,49]

theorem envBound8431 : H12AffineFastState.Bounded env8431 := by
  intro p hp
  have h : env8431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8430_8431 : H12AffineEnvironment.transform 10 0 env8430 = env8431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8430 == env8431) = true)

theorem identity8431 : scanCanonicalize (H12AffineFastState.compose env8431 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8431 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8432 : List Nat := [2,4,8,0,32,0,40,5,33,5,0,42,41,0,32,2,42,10,47,32,0,32,42,34,8,42,43,43,42,33,5,1,47,1,42,33]

theorem envBound8432 : H12AffineFastState.Bounded env8432 := by
  intro p hp
  have h : env8432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8431_8432 : H12AffineEnvironment.transform 3 0 env8431 = env8432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8431 == env8432) = true)

theorem identity8432 : scanCanonicalize (H12AffineFastState.compose env8432 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8432 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8433 : List Nat := [2,4,3,0,32,0,35,5,33,5,0,33,34,0,32,2,33,1,36,32,0,32,33,34,3,33,32,32,33,33,5,1,36,1,33,33]

theorem envBound8433 : H12AffineFastState.Bounded env8433 := by
  intro p hp
  have h : env8433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8432_8433 : H12AffineEnvironment.transform 2 3 env8432 = env8433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8432 == env8433) = true)

theorem identity8433 : scanCanonicalize (H12AffineFastState.compose env8433 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8433 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8434 : List Nat := [2,4,3,0,0,0,3,5,1,5,0,1,2,0,0,2,1,1,4,0,0,0,1,2,3,1,0,0,1,1,5,1,4,1,1,1]

theorem envBound8434 : H12AffineFastState.Bounded env8434 := by
  intro p hp
  have h : env8434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8433_8434 : H12AffineEnvironment.transform 4 0 env8433 = env8434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8433 == env8434) = true)

def env8435 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,65,4194304,4721,90337,8329,21041,278625,4214985,4214984,75786,5,4268194,4764,73770,78579,90819]

theorem envBound8435 : H12AffineFastState.Bounded env8435 := by
  intro p hp
  have h : env8435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8377_8435 : H12AffineEnvironment.transform 20 65 env8377 = env8435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8377 == env8435) = true)

theorem identity8435 : scanCanonicalize (H12AffineFastState.compose env8435 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 94321) := by decide +kernel

theorem selectedBound8435 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8436 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,94321,4764,8201,65,4194304,4721,90337,8329,21041,77840,4214985,4214984,75786,5,4268194,4764,73770,78579,90819]

theorem envBound8436 : H12AffineFastState.Bounded env8436 := by
  intro p hp
  have h : env8436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8435_8436 : H12AffineEnvironment.transform 17 94321 env8435 = env8436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 94321 env8435 == env8436) = true)

def env8437 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8201,65536,4096,94321,4644,8201,65,4194304,4721,90201,8241,21041,77840,4214897,4214896,75786,5,4268058,4644,73770,78411,90747]

theorem envBound8437 : H12AffineFastState.Bounded env8437 := by
  intro p hp
  have h : env8437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8436_8437 : H12AffineEnvironment.transform 6 56 env8436 = env8437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env8436 == env8437) = true)

theorem identity8437 : scanCanonicalize (H12AffineFastState.compose env8437 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 94298) := by decide +kernel

theorem selectedBound8437 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8438 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8201,65536,4096,94321,4644,8201,65,94298,4721,90201,8241,21041,77840,73771,73770,75786,5,20544,4644,73770,78411,90747]

theorem envBound8438 : H12AffineFastState.Bounded env8438 := by
  intro p hp
  have h : env8438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8437_8438 : H12AffineEnvironment.transform 21 94298 env8437 = env8438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 94298 env8437 == env8438) = true)

def env8439 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,80,8192,16384,8201,65536,80,90145,628,8201,65,90122,545,90201,8241,16993,73792,73771,73770,75786,5,16400,628,73770,74267,90747]

theorem envBound8439 : H12AffineFastState.Bounded env8439 := by
  intro p hp
  have h : env8439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8438_8439 : H12AffineEnvironment.transform 11 80 env8438 = env8439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env8438 == env8439) = true)

def env8440 : List Nat := [2,4,8,16,32,0,56,5,512,5,2048,16,8192,16384,8201,65536,16,90145,564,8201,1,90122,545,90137,8241,16929,73728,73771,73770,75786,5,16400,564,73770,74267,90683]

theorem envBound8440 : H12AffineFastState.Bounded env8440 := by
  intro p hp
  have h : env8440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8439_8440 : H12AffineEnvironment.transform 5 0 env8439 = env8440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8439 == env8440) = true)

theorem identity8440 : scanCanonicalize (H12AffineFastState.compose env8440 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound8440 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8441 : List Nat := [2,4,8,16,32,0,56,5,512,5,2048,16,8192,0,8201,65536,16,73761,564,8201,1,73738,545,73753,8241,545,73728,73771,73770,75786,5,16,564,73770,74267,74299]

theorem envBound8441 : H12AffineFastState.Bounded env8441 := by
  intro p hp
  have h : env8441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8440_8441 : H12AffineEnvironment.transform 13 0 env8440 = env8441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env8440 == env8441) = true)

theorem identity8441 : scanCanonicalize (H12AffineFastState.compose env8441 (packedSelected [1,5,10,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound8441 : packedSelected [1,5,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8442 : List Nat := [2,4,8,16,32,0,56,5,512,5,58,16,8192,0,8201,65536,16,73761,564,8201,1,73738,545,73753,8241,545,73728,73771,73770,73776,5,16,564,73770,74267,74299]

theorem envBound8442 : H12AffineFastState.Bounded env8442 := by
  intro p hp
  have h : env8442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8441_8442 : H12AffineEnvironment.transform 10 58 env8441 = env8442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env8441 == env8442) = true)

theorem identity8442 : scanCanonicalize (H12AffineFastState.compose env8442 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

end H12CloudChart1