import H12CloudChart1Data001

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env490 : List Nat := [2,4,8,0,32,4,44,5,46,0,4,11,41,43,36,9,37,33,5,36,1,32,4,41,13,0,5,37,11,46,5,10,0,10,42,33]

theorem envBound490 : H12AffineFastState.Bounded env490 := by
  intro p hp
  have h : env490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans489_490 : H12AffineEnvironment.transform 3 0 env489 = env490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env489 == env490) = true)

theorem identity490 : scanCanonicalize (H12AffineFastState.compose env490 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound490 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env491 : List Nat := [2,4,8,0,8,4,4,5,6,0,4,11,1,3,12,9,13,9,5,12,1,8,4,1,13,0,5,13,11,6,5,10,0,10,2,9]

theorem envBound491 : H12AffineFastState.Bounded env491 := by
  intro p hp
  have h : env491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans490_491 : H12AffineEnvironment.transform 4 8 env490 = env491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env490 == env491) = true)

def env492 : List Nat := [2,4,0,0,0,4,4,5,6,0,4,3,1,3,4,1,5,1,5,4,1,0,4,1,5,0,5,5,3,6,5,2,0,2,2,1]

theorem envBound492 : H12AffineFastState.Bounded env492 := by
  intro p hp
  have h : env492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans491_492 : H12AffineEnvironment.transform 2 0 env491 = env492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env491 == env492) = true)

def env493 : List Nat := [2,0,0,0,0,0,0,1,2,0,0,3,1,3,0,1,1,1,1,0,1,0,0,1,1,0,1,1,3,2,1,2,0,2,2,1]

theorem envBound493 : H12AffineFastState.Bounded env493 := by
  intro p hp
  have h : env493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans492_493 : H12AffineEnvironment.transform 1 0 env492 = env493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env492 == env493) = true)

def leafEnv493 : List Nat := [2,0,0,0,0,0,0,1,2,0,0,3,1,3,0,1,1,1,1,0,1,0,0,1,0,1,1,0,1,1,3,2,1,2,0,2,1,2,2,1,1,2,0]

def active493 : List Nat := [0]

def tree493 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood493 : H12WitnessSearch.Good tree493 := H12GlobalWitnessIndex.good

theorem leafIdentity493 : H12AffineFastState.composeSystem env493 rootObs = leafEnv493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env493 rootObs == leafEnv493) = true)

theorem terminalChecked493 : H12PackedTerminal.terminalCheckFast leafEnv493 active493 tree493 = true := by decide +kernel

def env494 : List Nat := [2,1,0,0,0,1,1,0,3,0,1,3,1,3,1,1,0,1,0,1,1,0,1,1,0,0,0,0,3,3,0,2,0,2,2,1]

theorem envBound494 : H12AffineFastState.Bounded env494 := by
  intro p hp
  have h : env494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans492_494 : H12AffineEnvironment.transform 1 1 env492 = env494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env492 == env494) = true)

theorem identity494 : scanCanonicalize (H12AffineFastState.compose env494 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound494 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env495 : List Nat := [1,1,0,0,0,1,1,0,0,0,1,0,1,0,1,1,0,1,0,1,1,0,1,1,0,0,0,0,0,0,0,1,0,1,1,1]

theorem envBound495 : H12AffineFastState.Bounded env495 := by
  intro p hp
  have h : env495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans494_495 : H12AffineEnvironment.transform 0 1 env494 = env495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env494 == env495) = true)

def leafEnv495 : List Nat := [1,1,0,0,0,1,1,0,0,0,1,0,1,0,1,1,0,1,0,1,1,0,1,1,0,0,1,0,0,0,0,0,0,1,0,1,1,1,1,1,1,0,0]

def active495 : List Nat := []

def tree495 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood495 : H12WitnessSearch.Good tree495 := H12GlobalWitnessIndex.good

theorem leafIdentity495 : H12AffineFastState.composeSystem env495 rootObs = leafEnv495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env495 rootObs == leafEnv495) = true)

theorem terminalChecked495 : H12PackedTerminal.terminalCheckFast leafEnv495 active495 tree495 = true := by decide +kernel

def env496 : List Nat := [2,4,1,0,1,4,4,5,6,0,4,2,1,3,5,0,4,0,5,5,1,1,4,1,4,0,5,4,2,6,5,3,0,3,2,0]

theorem envBound496 : H12AffineFastState.Bounded env496 := by
  intro p hp
  have h : env496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans491_496 : H12AffineEnvironment.transform 2 1 env491 = env496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env491 == env496) = true)

theorem identity496 : scanCanonicalize (H12AffineFastState.compose env496 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound496 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env497 : List Nat := [2,3,1,0,1,3,3,2,1,0,3,2,1,3,2,0,3,0,2,2,1,1,3,1,3,0,2,3,2,1,2,3,0,3,2,0]

theorem envBound497 : H12AffineFastState.Bounded env497 := by
  intro p hp
  have h : env497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans496_497 : H12AffineEnvironment.transform 1 3 env496 = env497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env496 == env497) = true)

def leafEnv497 : List Nat := [2,3,1,0,1,3,3,2,1,0,3,2,1,3,2,0,3,0,2,2,1,1,3,1,0,3,1,0,2,3,2,1,2,3,0,3,1,3,2,0,1,0,0]

def active497 : List Nat := [0]

def tree497 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood497 : H12WitnessSearch.Good tree497 := H12GlobalWitnessIndex.good

theorem leafIdentity497 : H12AffineFastState.composeSystem env497 rootObs = leafEnv497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env497 rootObs == leafEnv497) = true)

theorem terminalChecked497 : H12PackedTerminal.terminalCheckFast leafEnv497 active497 tree497 = true := by decide +kernel

def env498 : List Nat := [2,4,8,1,32,5,44,5,47,0,4,10,41,43,36,8,36,33,4,36,0,32,4,40,13,0,5,37,11,47,5,11,1,11,42,33]

theorem envBound498 : H12AffineFastState.Bounded env498 := by
  intro p hp
  have h : env498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans489_498 : H12AffineEnvironment.transform 3 1 env489 = env498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env489 == env498) = true)

theorem identity498 : scanCanonicalize (H12AffineFastState.compose env498 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound498 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env499 : List Nat := [1,4,8,1,32,5,44,5,44,0,4,9,41,40,36,8,36,33,4,36,0,32,4,40,13,0,5,37,8,44,5,8,1,8,41,33]

theorem envBound499 : H12AffineFastState.Bounded env499 := by
  intro p hp
  have h : env499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans498_499 : H12AffineEnvironment.transform 0 1 env498 = env499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env498 == env499) = true)

theorem identity499 : scanCanonicalize (H12AffineFastState.compose env499 (packedSelected [7,9] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound499 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env500 : List Nat := [1,4,4,1,32,5,32,5,32,0,4,5,37,36,36,4,36,33,4,36,0,32,4,36,1,0,5,37,4,32,5,4,1,4,37,33]

theorem envBound500 : H12AffineFastState.Bounded env500 := by
  intro p hp
  have h : env500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans499_500 : H12AffineEnvironment.transform 2 4 env499 = env500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env499 == env500) = true)

def leafEnv500 : List Nat := [1,4,4,1,32,5,32,5,32,0,4,5,37,36,36,4,36,33,4,36,0,32,4,36,1,1,1,0,5,37,4,32,5,4,1,4,0,33,37,33,1,1,0]

def active500 : List Nat := [1,4]

def tree500 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood500 : H12WitnessSearch.Good tree500 := H12GlobalWitnessIndex.good

theorem leafIdentity500 : H12AffineFastState.composeSystem env500 rootObs = leafEnv500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env500 rootObs == leafEnv500) = true)

theorem terminalChecked500 : H12PackedTerminal.terminalCheckFast leafEnv500 active500 tree500 = true := by decide +kernel

def env501 : List Nat := [2,4,8,16,32,21,44,4,63,0,4,26,40,43,37,24,53,33,20,37,17,32,5,57,12,0,5,37,10,62,5,26,16,26,42,32]

theorem envBound501 : H12AffineFastState.Bounded env501 := by
  intro p hp
  have h : env501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans488_501 : H12AffineEnvironment.transform 5 21 env488 = env501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 21 env488 == env501) = true)

theorem identity501 : scanCanonicalize (H12AffineFastState.compose env501 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound501 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env502 : List Nat := [2,4,8,14,32,11,44,4,33,0,4,4,40,43,37,6,43,33,10,37,15,32,5,39,12,0,5,37,10,32,5,4,14,4,42,32]

theorem envBound502 : H12AffineFastState.Bounded env502 := by
  intro p hp
  have h : env502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans501_502 : H12AffineEnvironment.transform 3 14 env501 = env502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env501 == env502) = true)

def env503 : List Nat := [2,4,8,14,4,11,8,4,5,0,4,4,12,15,1,6,15,5,10,1,15,4,5,3,12,0,5,1,10,4,5,4,14,4,14,4]

theorem envBound503 : H12AffineFastState.Bounded env503 := by
  intro p hp
  have h : env503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans502_503 : H12AffineEnvironment.transform 4 4 env502 = env503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env502 == env503) = true)

theorem identity503 : scanCanonicalize (H12AffineFastState.compose env503 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound503 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env504 : List Nat := [2,3,8,9,3,11,8,3,2,0,3,3,11,8,1,1,8,2,10,1,8,3,2,3,11,0,2,1,10,3,2,3,9,3,9,3]

theorem envBound504 : H12AffineFastState.Bounded env504 := by
  intro p hp
  have h : env504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans503_504 : H12AffineEnvironment.transform 1 3 env503 = env504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env503 == env504) = true)

def leafEnv504 : List Nat := [2,3,8,9,3,11,8,3,2,0,3,3,11,8,1,1,8,2,10,1,8,3,2,3,8,11,1,0,2,1,10,3,2,3,9,3,9,0,9,3,1,9,0]

def active504 : List Nat := [0,2]

def tree504 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood504 : H12WitnessSearch.Good tree504 := H12GlobalWitnessIndex.good

theorem leafIdentity504 : H12AffineFastState.composeSystem env504 rootObs = leafEnv504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env504 rootObs == leafEnv504) = true)

theorem terminalChecked504 : H12PackedTerminal.terminalCheckFast leafEnv504 active504 tree504 = true := by decide +kernel

def env505 : List Nat := [2,4,8,14,5,11,9,4,4,0,4,4,13,14,0,6,14,4,10,0,15,5,5,2,12,0,5,0,10,5,5,4,14,4,15,5]

theorem envBound505 : H12AffineFastState.Bounded env505 := by
  intro p hp
  have h : env505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans502_505 : H12AffineEnvironment.transform 4 5 env502 = env505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env502 == env505) = true)

theorem identity505 : scanCanonicalize (H12AffineFastState.compose env505 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound505 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env506 : List Nat := [2,4,1,7,5,2,0,4,4,0,4,4,4,7,0,6,7,4,3,0,6,5,5,2,5,0,5,0,3,5,5,4,7,4,6,5]

theorem envBound506 : H12AffineFastState.Bounded env506 := by
  intro p hp
  have h : env506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans505_506 : H12AffineEnvironment.transform 2 1 env505 = env506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env505 == env506) = true)

def leafEnv506 : List Nat := [2,4,1,7,5,2,0,4,4,0,4,4,4,7,0,6,7,4,3,0,6,5,5,2,6,5,1,0,5,0,3,5,5,4,7,4,7,6,6,5,1,7,0]

def active506 : List Nat := [0,1]

def tree506 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood506 : H12WitnessSearch.Good tree506 := H12GlobalWitnessIndex.good

theorem leafIdentity506 : H12AffineFastState.composeSystem env506 rootObs = leafEnv506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env506 rootObs == leafEnv506) = true)

theorem terminalChecked506 : H12PackedTerminal.terminalCheckFast leafEnv506 active506 tree506 = true := by decide +kernel

def env507 : List Nat := [2,4,8,16,32,64,45,80,107,1,4,78,124,43,112,77,53,32,64,112,16,32,80,56,89,0,5,37,94,63,5,27,17,27,42,116]

theorem envBound507 : H12AffineFastState.Bounded env507 := by
  intro p hp
  have h : env507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans487_507 : H12AffineEnvironment.transform 6 45 env487 = env507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 45 env487 == env507) = true)

theorem identity507 : scanCanonicalize (H12AffineFastState.compose env507 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound507 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env508 : List Nat := [2,4,8,14,32,64,45,78,107,1,4,78,98,43,110,77,43,32,64,110,14,32,78,38,71,0,5,37,64,33,5,5,15,5,42,106]

theorem envBound508 : H12AffineFastState.Bounded env508 := by
  intro p hp
  have h : env508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans507_508 : H12AffineEnvironment.transform 3 14 env507 = env508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env507 == env508) = true)

def env509 : List Nat := [2,4,8,14,32,0,45,14,43,1,4,14,34,43,46,13,43,32,0,46,14,32,14,38,7,0,5,37,0,33,5,5,15,5,42,42]

theorem envBound509 : H12AffineFastState.Bounded env509 := by
  intro p hp
  have h : env509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans508_509 : H12AffineEnvironment.transform 5 0 env508 = env509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env508 == env509) = true)

def env510 : List Nat := [2,4,8,14,0,0,13,14,11,1,4,14,2,11,14,13,11,0,0,14,14,0,14,6,7,0,5,5,0,1,5,5,15,5,10,10]

theorem envBound510 : H12AffineFastState.Bounded env510 := by
  intro p hp
  have h : env510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans509_510 : H12AffineEnvironment.transform 4 0 env509 = env510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env509 == env510) = true)

theorem identity510 : scanCanonicalize (H12AffineFastState.compose env510 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound510 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env511 : List Nat := [2,4,4,2,0,0,1,2,7,1,4,2,2,7,2,1,7,0,0,2,2,0,2,6,7,0,5,5,0,1,5,5,3,5,6,6]

theorem envBound511 : H12AffineFastState.Bounded env511 := by
  intro p hp
  have h : env511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans510_511 : H12AffineEnvironment.transform 2 4 env510 = env511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env510 == env511) = true)

def leafEnv511 : List Nat := [2,4,4,2,0,0,1,2,7,1,4,2,2,7,2,1,7,0,0,2,2,0,2,6,4,7,1,0,5,5,0,1,5,5,3,5,5,5,6,6,1,3,0]

def active511 : List Nat := [0,1]

def tree511 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood511 : H12WitnessSearch.Good tree511 := H12GlobalWitnessIndex.good

theorem leafIdentity511 : H12AffineFastState.composeSystem env511 rootObs = leafEnv511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env511 rootObs == leafEnv511) = true)

theorem terminalChecked511 : H12PackedTerminal.terminalCheckFast leafEnv511 active511 tree511 = true := by decide +kernel

def env512 : List Nat := [2,4,8,14,1,0,12,14,10,1,4,14,3,10,15,13,10,1,0,15,14,1,14,7,7,0,5,4,0,0,5,5,15,5,11,11]

theorem envBound512 : H12AffineFastState.Bounded env512 := by
  intro p hp
  have h : env512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans509_512 : H12AffineEnvironment.transform 4 1 env509 = env512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env509 == env512) = true)

theorem identity512 : scanCanonicalize (H12AffineFastState.compose env512 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound512 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env513 : List Nat := [2,4,0,6,1,0,4,6,2,1,4,6,3,2,7,5,2,1,0,7,6,1,6,7,7,0,5,4,0,0,5,5,7,5,3,3]

theorem envBound513 : H12AffineFastState.Bounded env513 := by
  intro p hp
  have h : env513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans512_513 : H12AffineEnvironment.transform 2 0 env512 = env513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env512 == env513) = true)

def leafEnv513 : List Nat := [2,4,0,6,1,0,4,6,2,1,4,6,3,2,7,5,2,1,0,7,6,1,6,7,4,7,1,0,5,4,0,0,5,5,7,5,5,0,3,3,1,7,0]

def active513 : List Nat := [0,1]

def tree513 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood513 : H12WitnessSearch.Good tree513 := H12GlobalWitnessIndex.good

theorem leafIdentity513 : H12AffineFastState.composeSystem env513 rootObs = leafEnv513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env513 rootObs == leafEnv513) = true)

theorem terminalChecked513 : H12PackedTerminal.terminalCheckFast leafEnv513 active513 tree513 = true := by decide +kernel

def env514 : List Nat := [2,4,8,14,32,1,45,15,42,1,4,15,35,43,47,12,43,32,1,47,14,32,15,38,6,0,5,37,1,33,5,5,15,5,42,43]

theorem envBound514 : H12AffineFastState.Bounded env514 := by
  intro p hp
  have h : env514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans508_514 : H12AffineEnvironment.transform 5 1 env508 = env514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env508 == env514) = true)

def env515 : List Nat := [2,4,8,14,0,1,13,15,10,1,4,15,3,11,15,12,11,0,1,15,14,0,15,6,6,0,5,5,1,1,5,5,15,5,10,11]

theorem envBound515 : H12AffineFastState.Bounded env515 := by
  intro p hp
  have h : env515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans514_515 : H12AffineEnvironment.transform 4 0 env514 = env515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env514 == env515) = true)

theorem identity515 : scanCanonicalize (H12AffineFastState.compose env515 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound515 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env516 : List Nat := [1,4,8,13,0,1,13,12,9,1,4,12,0,8,12,12,8,0,1,12,13,0,12,5,5,0,5,5,1,1,5,5,12,5,9,8]

theorem envBound516 : H12AffineFastState.Bounded env516 := by
  intro p hp
  have h : env516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans515_516 : H12AffineEnvironment.transform 0 1 env515 = env516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env515 == env516) = true)

def leafEnv516 : List Nat := [1,4,8,13,0,1,13,12,9,1,4,12,0,8,12,12,8,0,1,12,13,0,12,5,5,5,1,0,5,5,1,1,5,5,12,5,4,8,9,8,1,12,0]

def active516 : List Nat := [1,2]

def tree516 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood516 : H12WitnessSearch.Good tree516 := H12GlobalWitnessIndex.good

theorem leafIdentity516 : H12AffineFastState.composeSystem env516 rootObs = leafEnv516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env516 rootObs == leafEnv516) = true)

theorem terminalChecked516 : H12PackedTerminal.terminalCheckFast leafEnv516 active516 tree516 = true := by decide +kernel

def env517 : List Nat := [2,4,8,14,1,1,12,15,11,1,4,15,2,10,14,12,10,1,1,14,14,1,15,7,6,0,5,4,1,0,5,5,15,5,11,10]

theorem envBound517 : H12AffineFastState.Bounded env517 := by
  intro p hp
  have h : env517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans514_517 : H12AffineEnvironment.transform 4 1 env514 = env517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env514 == env517) = true)

theorem identity517 : scanCanonicalize (H12AffineFastState.compose env517 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound517 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env518 : List Nat := [2,2,8,8,1,1,10,9,11,1,2,9,2,10,8,10,10,1,1,8,8,1,9,1,0,0,3,2,1,0,3,3,9,3,11,10]

theorem envBound518 : H12AffineFastState.Bounded env518 := by
  intro p hp
  have h : env518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans517_518 : H12AffineEnvironment.transform 1 2 env517 = env518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env517 == env518) = true)

def leafEnv518 : List Nat := [2,2,8,8,1,1,10,9,11,1,2,9,2,10,8,10,10,1,1,8,8,1,9,1,3,0,1,0,3,2,1,0,3,3,9,3,2,9,11,10,1,9,0]

def active518 : List Nat := [0,2]

def tree518 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood518 : H12WitnessSearch.Good tree518 := H12GlobalWitnessIndex.good

theorem leafIdentity518 : H12AffineFastState.composeSystem env518 rootObs = leafEnv518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env518 rootObs == leafEnv518) = true)

theorem terminalChecked518 : H12PackedTerminal.terminalCheckFast leafEnv518 active518 tree518 = true := by decide +kernel

def env519 : List Nat := [2,4,8,16,32,64,128,253,512,173,707,4096,208,4296,113,4712,755,586,237,113,634,32,81,4785,88,1,706,738,4113,4209,4,4754,189,4754,4297,4155]

theorem envBound519 : H12AffineFastState.Bounded env519 := by
  intro p hp
  have h : env519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans451_519 : H12AffineEnvironment.transform 9 173 env451 = env519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env451 == env519) = true)

theorem identity519 : scanCanonicalize (H12AffineFastState.compose env519 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 571) := by decide +kernel

theorem selectedBound519 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env520 : List Nat := [2,4,8,16,32,64,128,253,512,173,707,571,208,755,113,83,755,586,237,113,634,32,81,138,88,1,706,738,554,586,4,169,189,169,754,512]

theorem envBound520 : H12AffineFastState.Bounded env520 := by
  intro p hp
  have h : env520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans519_520 : H12AffineEnvironment.transform 11 571 env519 = env520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 571 env519 == env520) = true)

theorem identity520 : scanCanonicalize (H12AffineFastState.compose env520 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound520 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env521 : List Nat := [2,4,8,16,32,64,128,253,31,173,220,36,208,236,113,83,236,85,237,113,101,32,81,138,88,1,221,253,53,85,4,169,189,169,237,31]

theorem envBound521 : H12AffineFastState.Bounded env521 := by
  intro p hp
  have h : env521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans520_521 : H12AffineEnvironment.transform 8 31 env520 = env521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env520 == env521) = true)

theorem identity521 : scanCanonicalize (H12AffineFastState.compose env521 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound521 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env522 : List Nat := [2,4,8,16,32,64,50,79,31,31,110,36,98,94,113,83,94,85,95,113,101,32,81,56,88,1,111,79,53,85,4,27,15,27,95,31]

theorem envBound522 : H12AffineFastState.Bounded env522 := by
  intro p hp
  have h : env522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans521_522 : H12AffineEnvironment.transform 6 50 env521 = env522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env521 == env522) = true)

theorem identity522 : scanCanonicalize (H12AffineFastState.compose env522 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound522 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env523 : List Nat := [2,4,8,16,1,64,19,79,31,31,79,5,67,94,80,83,94,85,95,80,68,1,81,25,88,1,78,79,20,85,4,27,15,27,95,31]

theorem envBound523 : H12AffineFastState.Bounded env523 := by
  intro p hp
  have h : env523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans522_523 : H12AffineEnvironment.transform 4 1 env522 = env523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env522 == env523) = true)

theorem identity523 : scanCanonicalize (H12AffineFastState.compose env523 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound523 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env524 : List Nat := [2,4,8,16,1,11,19,4,31,31,4,5,8,21,27,24,21,30,20,27,15,1,26,25,19,1,5,4,20,30,4,27,15,27,20,31]

theorem envBound524 : H12AffineFastState.Bounded env524 := by
  intro p hp
  have h : env524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans523_524 : H12AffineEnvironment.transform 5 11 env523 = env524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env523 == env524) = true)

theorem identity524 : scanCanonicalize (H12AffineFastState.compose env524 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound524 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env525 : List Nat := [2,4,8,11,1,11,8,4,4,4,4,5,8,14,0,3,14,5,15,0,15,1,1,2,8,1,5,4,15,5,4,0,15,0,15,4]

theorem envBound525 : H12AffineFastState.Bounded env525 := by
  intro p hp
  have h : env525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans524_525 : H12AffineEnvironment.transform 3 11 env524 = env525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env524 == env525) = true)

theorem identity525 : scanCanonicalize (H12AffineFastState.compose env525 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound525 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env526 : List Nat := [2,4,1,2,1,2,1,4,4,4,4,5,1,7,0,3,7,5,6,0,6,1,1,2,1,1,5,4,6,5,4,0,6,0,6,4]

theorem envBound526 : H12AffineFastState.Bounded env526 := by
  intro p hp
  have h : env526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans525_526 : H12AffineEnvironment.transform 2 1 env525 = env526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env525 == env526) = true)

theorem identity526 : scanCanonicalize (H12AffineFastState.compose env526 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound526 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env527 : List Nat := [1,4,1,1,1,1,1,4,4,4,4,5,1,4,0,0,4,5,5,0,5,1,1,1,1,1,5,4,5,5,4,0,5,0,5,4]

theorem envBound527 : H12AffineFastState.Bounded env527 := by
  intro p hp
  have h : env527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans526_527 : H12AffineEnvironment.transform 0 1 env526 = env527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env526 == env527) = true)

def leafEnv527 : List Nat := [1,4,1,1,1,1,1,4,4,4,4,5,1,4,0,0,4,5,5,0,5,1,1,1,5,1,1,1,5,4,5,5,4,0,5,0,5,0,5,4,1,5,0]

def active527 : List Nat := [1]

def tree527 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood527 : H12WitnessSearch.Good tree527 := H12GlobalWitnessIndex.good

theorem leafIdentity527 : H12AffineFastState.composeSystem env527 rootObs = leafEnv527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env527 rootObs == leafEnv527) = true)

theorem terminalChecked527 : H12PackedTerminal.terminalCheckFast leafEnv527 active527 tree527 = true := by decide +kernel

def env528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8353,65536,131072,262144,524288,8353,656584,32,525329,74228,8328,525377,262280,656465,529489,76279,1364,73770,525568,74199,268353,74371]

theorem envBound528 : H12AffineFastState.Bounded env528 := by
  intro p hp
  have h : env528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans351_528 : H12AffineEnvironment.transform 13 4297 env351 = env528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4297 env351 == env528) = true)

theorem identity528 : scanCanonicalize (H12AffineFastState.compose env528 (packedSelected [0,1,3,5,6,7,8,13] rootPS)) = affineNative (2^(18+1) ^^^ 236) := by decide +kernel

theorem selectedBound528 : packedSelected [0,1,3,5,6,7,8,13] rootPS < 2^1333 := by decide +kernel

def env529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8353,65536,131072,262144,236,8353,132132,32,1277,74228,8328,1197,262280,132285,5309,76279,1364,73770,1516,74199,268353,74371]

theorem envBound529 : H12AffineFastState.Bounded env529 := by
  intro p hp
  have h : env529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans528_529 : H12AffineEnvironment.transform 18 236 env528 = env529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 236 env528 == env529) = true)

def env530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8353,65536,131072,138512,236,8353,132132,32,1277,74228,8328,1197,138648,132285,5309,76279,1364,73770,1516,74199,132433,74371]

theorem envBound530 : H12AffineFastState.Bounded env530 := by
  intro p hp
  have h : env530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans529_530 : H12AffineEnvironment.transform 17 138512 env529 = env530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138512 env529 == env530) = true)

def env531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8353,65536,5220,2420,236,8353,4160,32,1277,74228,8328,1197,2556,4313,5309,76279,1364,73770,1516,74199,4405,74371]

theorem envBound531 : H12AffineFastState.Bounded env531 := by
  intro p hp
  have h : env531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans530_531 : H12AffineEnvironment.transform 16 5220 env530 = env531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env530 == env531) = true)

theorem identity531 : scanCanonicalize (H12AffineFastState.compose env531 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound531 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env532 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4297,8353,65536,5220,2185,236,8353,4160,32,1277,73737,8328,1197,2049,4313,5309,75786,1193,73770,1041,73770,4296,74371]

theorem envBound532 : H12AffineFastState.Bounded env532 := by
  intro p hp
  have h : env532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans531_532 : H12AffineEnvironment.transform 7 253 env531 = env532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env531 == env532) = true)

theorem identity532 : scanCanonicalize (H12AffineFastState.compose env532 (packedSelected [0,6,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 7301) := by decide +kernel

theorem selectedBound532 : packedSelected [0,6,7,10] rootPS < 2^1333 := by decide +kernel

def env533 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,7301,4297,7204,65536,5220,2185,236,7204,4160,32,1277,72844,7181,1197,2049,4313,5309,70799,1193,72879,1041,72879,4296,73222]

theorem envBound533 : H12AffineFastState.Bounded env533 := by
  intro p hp
  have h : env533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans532_533 : H12AffineEnvironment.transform 12 7301 env532 = env533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7301 env532 == env533) = true)

theorem identity533 : scanCanonicalize (H12AffineFastState.compose env533 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(15+1) ^^^ 4713) := by decide +kernel

theorem selectedBound533 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env534 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,7301,4297,7204,4713,5220,2185,236,7204,4160,32,1277,3813,7181,1197,2049,4313,5309,1766,1193,3782,1041,3782,4296,3183]

theorem envBound534 : H12AffineFastState.Bounded env534 := by
  intro p hp
  have h : env534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans533_534 : H12AffineEnvironment.transform 15 4713 env533 = env534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4713 env533 == env534) = true)

theorem identity534 : scanCanonicalize (H12AffineFastState.compose env534 (packedSelected [0,3,5,6,7,15] rootPS)) = affineNative (2^(10+1) ^^^ 1647) := by decide +kernel

theorem selectedBound534 : packedSelected [0,3,5,6,7,15] rootPS < 2^1333 := by decide +kernel

def env535 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1647,4096,4842,4297,4683,4713,5220,1766,236,4683,4160,32,1277,138,4706,1197,1646,4313,5309,1766,1193,169,1041,169,4296,512]

theorem envBound535 : H12AffineFastState.Bounded env535 := by
  intro p hp
  have h : env535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans534_535 : H12AffineEnvironment.transform 10 1647 env534 = env535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1647 env534 == env535) = true)

theorem identity535 : scanCanonicalize (H12AffineFastState.compose env535 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1687) := by decide +kernel

theorem selectedBound535 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env536 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1647,1687,1149,1630,1244,1278,755,1766,236,1244,1751,32,1277,138,1269,1197,1646,1614,554,1766,1193,169,1041,169,1631,512]

theorem envBound536 : H12AffineFastState.Bounded env536 := by
  intro p hp
  have h : env536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans535_536 : H12AffineEnvironment.transform 11 1687 env535 = env536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1687 env535 == env536) = true)

theorem identity536 : scanCanonicalize (H12AffineFastState.compose env536 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound536 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env537 : List Nat := [2,4,8,16,32,64,128,253,512,30,625,649,99,576,194,224,755,760,236,194,713,32,227,138,235,179,624,592,554,760,183,169,15,169,577,512]

theorem envBound537 : H12AffineFastState.Bounded env537 := by
  intro p hp
  have h : env537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans536_537 : H12AffineEnvironment.transform 9 30 env536 = env537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env536 == env537) = true)

theorem identity537 : scanCanonicalize (H12AffineFastState.compose env537 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound537 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env538 : List Nat := [2,4,8,16,32,64,19,110,512,30,625,538,99,576,81,115,608,619,127,81,602,32,112,25,120,32,624,592,554,619,36,58,15,58,577,512]

theorem envBound538 : H12AffineFastState.Bounded env538 := by
  intro p hp
  have h : env538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans537_538 : H12AffineEnvironment.transform 6 19 env537 = env538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env537 == env538) = true)

theorem identity538 : scanCanonicalize (H12AffineFastState.compose env538 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound538 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env539 : List Nat := [2,4,8,16,32,11,19,37,512,30,570,538,40,523,26,56,555,544,52,26,529,32,59,25,51,32,571,539,554,544,36,58,15,58,522,512]

theorem envBound539 : H12AffineFastState.Bounded env539 := by
  intro p hp
  have h : env539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans538_539 : H12AffineEnvironment.transform 5 11 env538 = env539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env538 == env539) = true)

theorem identity539 : scanCanonicalize (H12AffineFastState.compose env539 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 37) := by decide +kernel

theorem selectedBound539 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env540 : List Nat := [2,4,8,16,32,11,19,37,37,30,31,63,40,46,26,56,14,5,52,26,52,32,59,25,51,32,30,62,15,5,36,58,15,58,47,37]

theorem envBound540 : H12AffineFastState.Bounded env540 := by
  intro p hp
  have h : env540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans539_540 : H12AffineEnvironment.transform 8 37 env539 = env540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 37 env539 == env540) = true)

theorem identity540 : scanCanonicalize (H12AffineFastState.compose env540 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound540 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env541 : List Nat := [2,4,8,10,32,11,9,37,37,4,5,37,40,46,0,34,14,5,46,0,46,32,33,3,41,32,4,36,15,5,36,32,15,32,47,37]

theorem envBound541 : H12AffineFastState.Bounded env541 := by
  intro p hp
  have h : env541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans540_541 : H12AffineEnvironment.transform 3 10 env540 = env541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env540 == env541) = true)

theorem identity541 : scanCanonicalize (H12AffineFastState.compose env541 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound541 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env542 : List Nat := [2,4,8,10,10,11,9,15,15,4,5,15,2,4,0,8,14,5,4,0,4,10,11,3,3,10,4,14,15,5,14,10,15,10,5,15]

theorem envBound542 : H12AffineFastState.Bounded env542 := by
  intro p hp
  have h : env542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans541_542 : H12AffineEnvironment.transform 4 10 env541 = env542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env541 == env542) = true)

theorem identity542 : scanCanonicalize (H12AffineFastState.compose env542 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env543 : List Nat := [0,4,8,8,8,9,9,13,13,4,5,13,0,4,0,8,12,5,4,0,4,8,9,1,1,8,4,12,13,5,12,8,13,8,5,13]

theorem envBound543 : H12AffineFastState.Bounded env543 := by
  intro p hp
  have h : env543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans542_543 : H12AffineEnvironment.transform 0 0 env542 = env543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env542 == env543) = true)

def leafEnv543 : List Nat := [0,4,8,8,8,9,9,13,13,4,5,13,0,4,0,8,12,5,4,0,4,8,9,1,12,1,1,8,4,12,13,5,12,8,13,8,4,9,5,13,1,4,0]

def active543 : List Nat := [1,2]

def tree543 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood543 : H12WitnessSearch.Good tree543 := H12GlobalWitnessIndex.good

theorem leafIdentity543 : H12AffineFastState.composeSystem env543 rootObs = leafEnv543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env543 rootObs == leafEnv543) = true)

theorem terminalChecked543 : H12PackedTerminal.terminalCheckFast leafEnv543 active543 tree543 = true := by decide +kernel

def env544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8353,65536,5221,2421,236,8353,4161,32,1277,74228,8328,1197,2557,4312,5309,76279,1364,73770,1516,74199,4404,74371]

theorem envBound544 : H12AffineFastState.Bounded env544 := by
  intro p hp
  have h : env544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans530_544 : H12AffineEnvironment.transform 16 5221 env530 = env544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env530 == env544) = true)

theorem identity544 : scanCanonicalize (H12AffineFastState.compose env544 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound544 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8353,8574,5221,2421,236,8353,4161,32,1277,138,8328,1197,2557,4312,5309,2185,1364,340,1516,169,4404,1021]

theorem envBound545 : H12AffineFastState.Bounded env545 := by
  intro p hp
  have h : env545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans544_545 : H12AffineEnvironment.transform 15 8574 env544 = env545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env544 == env545) = true)

theorem identity545 : scanCanonicalize (H12AffineFastState.compose env545 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 2981) := by decide +kernel

theorem selectedBound545 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,2981,4297,2820,2779,5221,2421,236,2820,4161,32,1277,138,2861,1197,2557,4312,5309,2185,1364,340,1516,169,4404,1021]

theorem envBound546 : H12AffineFastState.Bounded env546 := by
  intro p hp
  have h : env546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans545_546 : H12AffineEnvironment.transform 12 2981 env545 = env546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2981 env545 == env546) = true)

theorem identity546 : scanCanonicalize (H12AffineFastState.compose env546 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound546 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env547 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,2981,4297,2820,2779,4605,2421,236,2820,4161,32,357,138,2861,309,2557,4312,4389,2185,204,340,116,169,4404,1021]

theorem envBound547 : H12AffineFastState.Bounded env547 := by
  intro p hp
  have h : env547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans546_547 : H12AffineEnvironment.transform 9 408 env546 = env547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env546 == env547) = true)

theorem identity547 : scanCanonicalize (H12AffineFastState.compose env547 (packedSelected [1,2,5,6,10] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound547 : packedSelected [1,2,5,6,10] rootPS < 2^1333 := by decide +kernel

def env548 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,2356,2981,2557,2820,2779,2249,2421,236,2820,2421,32,357,138,2861,309,2557,2540,2065,2185,204,340,116,169,2048,1021]

theorem envBound548 : H12AffineFastState.Bounded env548 := by
  intro p hp
  have h : env548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans547_548 : H12AffineEnvironment.transform 11 2356 env547 = env548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env547 == env548) = true)

theorem identity548 : scanCanonicalize (H12AffineFastState.compose env548 (packedSelected [2,3,5,6,11] rootPS)) = affineNative (2^(10+1) ^^^ 852) := by decide +kernel

theorem selectedBound548 : packedSelected [2,3,5,6,11] rootPS < 2^1333 := by decide +kernel

def env549 : List Nat := [2,4,8,16,32,64,128,256,512,408,852,608,241,681,80,399,925,545,236,80,545,32,357,138,121,309,681,696,837,989,204,340,116,169,852,1021]

theorem envBound549 : H12AffineFastState.Bounded env549 := by
  intro p hp
  have h : env549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans548_549 : H12AffineEnvironment.transform 10 852 env548 = env549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 852 env548 == env549) = true)

theorem identity549 : scanCanonicalize (H12AffineFastState.compose env549 (packedSelected [3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 388) := by decide +kernel

theorem selectedBound549 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env550 : List Nat := [2,4,8,16,32,64,128,256,388,408,208,484,241,301,80,399,25,421,236,80,421,32,357,138,121,309,301,316,193,89,204,340,116,169,208,121]

theorem envBound550 : H12AffineFastState.Bounded env550 := by
  intro p hp
  have h : env550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans549_550 : H12AffineEnvironment.transform 8 388 env549 = env550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 388 env549 == env550) = true)

theorem identity550 : scanCanonicalize (H12AffineFastState.compose env550 (packedSelected [0,1,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound550 : packedSelected [0,1,3,6] rootPS < 2^1333 := by decide +kernel

def env551 : List Nat := [2,4,8,16,32,64,18,256,278,266,66,374,99,301,80,285,25,311,126,80,311,32,357,24,121,309,301,316,83,89,94,340,116,59,66,121]

theorem envBound551 : H12AffineFastState.Bounded env551 := by
  intro p hp
  have h : env551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans550_551 : H12AffineEnvironment.transform 6 18 env550 = env551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env550 == env551) = true)

theorem identity551 : scanCanonicalize (H12AffineFastState.compose env551 (packedSelected [0,1,3,4,12] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound551 : packedSelected [0,1,3,4,12] rootPS < 2^1333 := by decide +kernel

def env552 : List Nat := [2,4,8,16,32,64,18,69,83,79,66,51,99,104,80,88,25,114,126,80,114,32,32,24,121,112,104,121,83,89,94,17,116,59,66,121]

theorem envBound552 : H12AffineFastState.Bounded env552 := by
  intro p hp
  have h : env552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans551_552 : H12AffineEnvironment.transform 7 69 env551 = env552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env551 == env552) = true)

theorem identity552 : scanCanonicalize (H12AffineFastState.compose env552 (packedSelected [0,14] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound552 : packedSelected [0,14] rootPS < 2^1333 := by decide +kernel

def env553 : List Nat := [2,4,8,16,32,32,18,37,51,47,34,51,3,8,48,56,25,18,30,48,18,32,32,24,25,16,8,25,51,57,62,17,20,59,34,25]

theorem envBound553 : H12AffineFastState.Bounded env553 := by
  intro p hp
  have h : env553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans552_553 : H12AffineEnvironment.transform 5 32 env552 = env553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env552 == env553) = true)

theorem identity553 : scanCanonicalize (H12AffineFastState.compose env553 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound553 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env554 : List Nat := [2,4,8,16,16,16,18,21,3,31,18,3,3,8,0,8,25,18,30,0,18,16,16,24,25,16,8,25,3,9,14,17,20,11,18,25]

theorem envBound554 : H12AffineFastState.Bounded env554 := by
  intro p hp
  have h : env554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans553_554 : H12AffineEnvironment.transform 4 16 env553 = env554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env553 == env554) = true)

theorem identity554 : scanCanonicalize (H12AffineFastState.compose env554 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound554 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env555 : List Nat := [2,4,8,10,10,10,8,15,3,5,8,3,3,8,0,8,3,8,4,0,8,10,10,2,3,10,8,3,3,9,14,11,14,11,8,3]

theorem envBound555 : H12AffineFastState.Bounded env555 := by
  intro p hp
  have h : env555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans554_555 : H12AffineEnvironment.transform 3 10 env554 = env555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env554 == env555) = true)

theorem identity555 : scanCanonicalize (H12AffineFastState.compose env555 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound555 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env556 : List Nat := [2,0,8,10,10,10,8,11,3,1,8,3,3,8,0,8,3,8,0,0,8,10,10,2,3,10,8,3,3,9,10,11,10,11,8,3]

theorem envBound556 : H12AffineFastState.Bounded env556 := by
  intro p hp
  have h : env556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans555_556 : H12AffineEnvironment.transform 1 0 env555 = env556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env555 == env556) = true)

def leafEnv556 : List Nat := [2,0,8,10,10,10,8,11,3,1,8,3,3,8,0,8,3,8,0,0,8,10,10,2,11,3,1,10,8,3,3,9,10,11,10,11,1,8,8,3,1,9,0]

def active556 : List Nat := [0,2]

def tree556 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood556 : H12WitnessSearch.Good tree556 := H12GlobalWitnessIndex.good

theorem leafIdentity556 : H12AffineFastState.composeSystem env556 rootObs = leafEnv556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env556 rootObs == leafEnv556) = true)

theorem terminalChecked556 : H12PackedTerminal.terminalCheckFast leafEnv556 active556 tree556 = true := by decide +kernel

def env557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4297,8353,65536,131072,138513,236,8353,132132,32,1277,74228,8328,1197,138649,132285,5309,76279,1364,73770,1516,74199,132432,74371]

theorem envBound557 : H12AffineFastState.Bounded env557 := by
  intro p hp
  have h : env557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans529_557 : H12AffineEnvironment.transform 17 138513 env529 = env557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138513 env529 == env557) = true)

theorem identity557 : scanCanonicalize (H12AffineFastState.compose env557 (packedSelected [21] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound557 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env558 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4297,8353,65536,131072,138476,236,8353,132132,32,1277,73737,8328,1197,138340,132285,5309,75786,1193,73770,1041,73770,132269,74371]

theorem envBound558 : H12AffineFastState.Bounded env558 := by
  intro p hp
  have h : env558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans557_558 : H12AffineEnvironment.transform 7 253 env557 = env558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env557 == env558) = true)

def env559 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4297,8353,65536,2112,5292,236,8353,3172,32,1277,73737,8328,1197,5156,3325,5309,75786,1193,73770,1041,73770,3309,74371]

theorem envBound559 : H12AffineFastState.Bounded env559 := by
  intro p hp
  have h : env559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans558_559 : H12AffineEnvironment.transform 16 2112 env558 = env559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2112 env558 == env559) = true)

theorem identity559 : scanCanonicalize (H12AffineFastState.compose env559 (packedSelected [10] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound559 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env560 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4297,8353,34,2112,5292,236,8353,3172,32,1277,8235,8328,1197,5156,3325,5309,10280,1193,8200,1041,8200,3309,8865]

theorem envBound560 : H12AffineFastState.Bounded env560 := by
  intro p hp
  have h : env560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans559_560 : H12AffineEnvironment.transform 15 34 env559 = env560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env559 == env560) = true)

def env561 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,4161,8233,34,2112,5156,100,8233,3172,32,1141,8235,8192,1061,5156,3189,5173,10280,1057,8200,1041,8200,3173,8745]

theorem envBound561 : H12AffineFastState.Bounded env561 := by
  intro p hp
  have h : env561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans560_561 : H12AffineEnvironment.transform 6 8 env560 = env561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env560 == env561) = true)

theorem identity561 : scanCanonicalize (H12AffineFastState.compose env561 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound561 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env562 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3109,8192,3172,8233,34,2112,2049,100,8233,3172,32,1141,8235,8192,1061,2049,3189,2064,10280,1057,8200,1041,8200,3173,8745]

theorem envBound562 : H12AffineFastState.Bounded env562 := by
  intro p hp
  have h : env562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans561_562 : H12AffineEnvironment.transform 11 3109 env561 = env562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env561 == env562) = true)

theorem identity562 : scanCanonicalize (H12AffineFastState.compose env562 (packedSelected [0,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 1647) := by decide +kernel

theorem selectedBound562 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env563 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1647,586,8192,523,8233,34,1583,1646,100,8233,523,32,1141,8235,8192,1061,1646,538,1663,9799,1057,8200,1041,8200,522,8745]

theorem envBound563 : H12AffineFastState.Bounded env563 := by
  intro p hp
  have h : env563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans562_563 : H12AffineEnvironment.transform 10 1647 env562 = env563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1647 env562 == env563) = true)

def env564 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1647,586,40,523,1,34,1583,1646,100,1,523,32,1141,3,40,1061,1646,538,1663,1647,1057,32,1041,32,522,513]

theorem envBound564 : H12AffineFastState.Bounded env564 := by
  intro p hp
  have h : env564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans563_564 : H12AffineEnvironment.transform 12 40 env563 = env564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env563 == env564) = true)

theorem identity564 : scanCanonicalize (H12AffineFastState.compose env564 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound564 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env565 : List Nat := [2,4,8,16,32,49,8,4,512,1024,1566,571,40,523,1,34,1583,1567,21,1,523,32,1028,3,40,1061,1567,538,1550,1566,1057,32,1041,32,522,513]

theorem envBound565 : H12AffineFastState.Bounded env565 := by
  intro p hp
  have h : env565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans564_565 : H12AffineEnvironment.transform 5 49 env564 = env565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env564 == env565) = true)

theorem identity565 : scanCanonicalize (H12AffineFastState.compose env565 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound565 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env566 : List Nat := [0,4,8,16,32,49,8,4,512,1024,1564,569,40,521,1,32,1581,1565,21,1,521,32,1028,1,40,1061,1565,536,1548,1564,1057,32,1041,32,520,513]

theorem envBound566 : H12AffineFastState.Bounded env566 := by
  intro p hp
  have h : env566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans565_566 : H12AffineEnvironment.transform 0 0 env565 = env566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env565 == env566) = true)

theorem identity566 : scanCanonicalize (H12AffineFastState.compose env566 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound566 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env567 : List Nat := [0,4,8,16,32,49,8,4,32,1024,1084,25,40,41,1,32,1037,1085,21,1,41,32,1028,1,40,1061,1085,56,1068,1084,1057,32,1041,32,40,33]

theorem envBound567 : H12AffineFastState.Bounded env567 := by
  intro p hp
  have h : env567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans566_567 : H12AffineEnvironment.transform 8 32 env566 = env567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env566 == env567) = true)

def leafEnv567 : List Nat := [0,4,8,16,32,49,8,4,32,1024,1084,25,40,41,1,32,1037,1085,21,1,41,32,1028,1,52,40,1,1061,1085,56,1068,1084,1057,32,1041,32,1041,33,40,33,1,40,0]

def active567 : List Nat := [1,2,3,4,9]

def tree567 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood567 : H12WitnessSearch.Good tree567 := H12GlobalWitnessIndex.good

theorem leafIdentity567 : H12AffineFastState.composeSystem env567 rootObs = leafEnv567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env567 rootObs == leafEnv567) = true)

theorem terminalChecked567 : H12PackedTerminal.terminalCheckFast leafEnv567 active567 tree567 = true := by decide +kernel

def env568 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1647,586,41,523,0,34,1583,1646,100,0,523,32,1141,2,41,1061,1646,538,1663,1646,1057,33,1041,33,522,512]

theorem envBound568 : H12AffineFastState.Bounded env568 := by
  intro p hp
  have h : env568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans563_568 : H12AffineEnvironment.transform 12 41 env563 = env568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env563 == env568) = true)

theorem identity568 : scanCanonicalize (H12AffineFastState.compose env568 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound568 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env569 : List Nat := [2,4,8,16,32,64,8,117,512,85,570,586,41,523,0,34,634,571,100,0,523,32,32,2,41,112,571,538,554,571,116,33,68,33,522,512]

theorem envBound569 : H12AffineFastState.Bounded env569 := by
  intro p hp
  have h : env569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans568_569 : H12AffineEnvironment.transform 9 85 env568 = env569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env568 == env569) = true)

theorem identity569 : scanCanonicalize (H12AffineFastState.compose env569 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound569 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env570 : List Nat := [2,4,8,16,32,10,8,63,512,31,570,512,41,523,0,34,560,571,46,0,523,32,32,2,41,58,571,538,554,571,62,33,14,33,522,512]

theorem envBound570 : H12AffineFastState.Bounded env570 := by
  intro p hp
  have h : env570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans569_570 : H12AffineEnvironment.transform 5 10 env569 = env570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env569 == env570) = true)

theorem identity570 : scanCanonicalize (H12AffineFastState.compose env570 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound570 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env571 : List Nat := [2,4,8,10,32,10,8,37,512,5,544,512,41,523,0,34,554,545,46,0,523,32,32,2,41,32,545,512,554,545,36,33,14,33,522,512]

theorem envBound571 : H12AffineFastState.Bounded env571 := by
  intro p hp
  have h : env571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans570_571 : H12AffineEnvironment.transform 3 10 env570 = env571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env570 == env571) = true)

theorem identity571 : scanCanonicalize (H12AffineFastState.compose env571 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound571 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env572 : List Nat := [2,4,7,5,32,5,7,37,512,5,544,512,38,516,0,34,549,545,33,0,516,32,32,2,38,32,545,512,549,545,36,33,1,33,517,512]

theorem envBound572 : H12AffineFastState.Bounded env572 := by
  intro p hp
  have h : env572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans571_572 : H12AffineEnvironment.transform 2 7 env571 = env572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env571 == env572) = true)

theorem identity572 : scanCanonicalize (H12AffineFastState.compose env572 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound572 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env573 : List Nat := [2,4,7,5,5,5,7,0,512,5,517,512,3,516,0,7,512,516,4,0,516,5,5,2,3,5,516,512,512,516,1,4,1,4,517,512]

theorem envBound573 : H12AffineFastState.Bounded env573 := by
  intro p hp
  have h : env573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans572_573 : H12AffineEnvironment.transform 4 5 env572 = env573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env572 == env573) = true)

theorem identity573 : scanCanonicalize (H12AffineFastState.compose env573 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound573 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env574 : List Nat := [2,4,7,5,5,5,7,0,3,5,6,3,3,7,0,7,3,7,4,0,7,5,5,2,3,5,7,3,3,7,1,4,1,4,6,3]

theorem envBound574 : H12AffineFastState.Bounded env574 := by
  intro p hp
  have h : env574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans573_574 : H12AffineEnvironment.transform 8 3 env573 = env574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env573 == env574) = true)

def leafEnv574 : List Nat := [2,4,7,5,5,5,7,0,3,5,6,3,3,7,0,7,3,7,4,0,7,5,5,2,0,3,1,5,7,3,3,7,1,4,1,4,5,7,6,3,1,7,0]

def active574 : List Nat := [0,1]

def tree574 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood574 : H12WitnessSearch.Good tree574 := H12GlobalWitnessIndex.good

theorem leafIdentity574 : H12AffineFastState.composeSystem env574 rootObs = leafEnv574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env574 rootObs == leafEnv574) = true)

theorem terminalChecked574 : H12PackedTerminal.terminalCheckFast leafEnv574 active574 tree574 = true := by decide +kernel

def env575 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,4160,8232,34,2112,5157,101,8232,3172,32,1140,8235,8193,1060,5156,3188,5172,10280,1056,8200,1041,8200,3172,8744]

theorem envBound575 : H12AffineFastState.Bounded env575 := by
  intro p hp
  have h : env575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans560_575 : H12AffineEnvironment.transform 6 9 env560 = env575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env560 == env575) = true)

theorem identity575 : scanCanonicalize (H12AffineFastState.compose env575 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound575 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env576 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,7180,4160,7204,34,2112,5157,101,7204,3172,32,1140,7207,7181,1060,5156,3188,5172,5156,1056,7172,1041,7172,3172,7716]

theorem envBound576 : H12AffineFastState.Bounded env576 := by
  intro p hp
  have h : env576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans575_576 : H12AffineEnvironment.transform 12 7180 env575 = env576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env575 == env576) = true)

theorem identity576 : scanCanonicalize (H12AffineFastState.compose env576 (packedSelected [0,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 586) := by decide +kernel

theorem selectedBound576 : packedSelected [0,9,11] rootPS < 2^1333 := by decide +kernel

def env577 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,586,3654,522,3694,34,2112,1647,101,3694,3172,32,1140,3693,3655,1060,1646,3188,1662,1646,1056,3662,1041,3662,3172,3182]

theorem envBound577 : H12AffineFastState.Bounded env577 := by
  intro p hp
  have h : env577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans576_577 : H12AffineEnvironment.transform 11 586 env576 = env577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 586 env576 == env577) = true)

def env578 : List Nat := [2,4,8,16,32,64,9,116,512,20,2048,586,2642,522,2682,34,2112,635,101,2682,2160,32,96,2681,2643,48,634,2144,618,634,52,2650,5,2650,2160,2170]

theorem envBound578 : H12AffineFastState.Bounded env578 := by
  intro p hp
  have h : env578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans577_578 : H12AffineEnvironment.transform 9 20 env577 = env578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env577 == env578) = true)

theorem identity578 : scanCanonicalize (H12AffineFastState.compose env578 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 553) := by decide +kernel

theorem selectedBound578 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env579 : List Nat := [2,4,8,16,32,64,9,116,512,20,553,586,123,522,83,34,617,635,101,83,601,32,96,80,122,48,634,585,618,634,52,115,5,115,601,595]

theorem envBound579 : H12AffineFastState.Bounded env579 := by
  intro p hp
  have h : env579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans578_579 : H12AffineEnvironment.transform 10 553 env578 = env579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 553 env578 == env579) = true)

theorem identity579 : scanCanonicalize (H12AffineFastState.compose env579 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound579 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env580 : List Nat := [2,4,8,16,32,49,9,5,512,20,553,571,10,522,34,34,536,522,20,34,552,32,17,33,11,48,523,568,539,523,52,2,5,2,552,546]

theorem envBound580 : H12AffineFastState.Bounded env580 := by
  intro p hp
  have h : env580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans579_580 : H12AffineEnvironment.transform 5 49 env579 = env580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env579 == env580) = true)

def env581 : List Nat := [2,0,8,16,32,49,9,1,512,16,553,571,10,522,34,34,536,522,16,34,552,32,17,33,11,48,523,568,539,523,48,2,1,2,552,546]

theorem envBound581 : H12AffineFastState.Bounded env581 := by
  intro p hp
  have h : env581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans580_581 : H12AffineEnvironment.transform 1 0 env580 = env581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env580 == env581) = true)

theorem identity581 : scanCanonicalize (H12AffineFastState.compose env581 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound581 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env582 : List Nat := [2,0,8,16,32,49,9,1,2,16,43,57,10,8,34,34,26,8,16,34,42,32,17,33,11,48,9,58,25,9,48,2,1,2,42,32]

theorem envBound582 : H12AffineFastState.Bounded env582 := by
  intro p hp
  have h : env582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans581_582 : H12AffineEnvironment.transform 8 2 env581 = env582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env581 == env582) = true)

def env583 : List Nat := [2,0,8,0,32,33,9,1,2,0,43,41,10,8,34,34,10,8,0,34,42,32,1,33,11,32,9,42,9,9,32,2,1,2,42,32]

theorem envBound583 : H12AffineFastState.Bounded env583 := by
  intro p hp
  have h : env583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans582_583 : H12AffineEnvironment.transform 3 0 env582 = env583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env582 == env583) = true)

theorem identity583 : scanCanonicalize (H12AffineFastState.compose env583 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound583 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env584 : List Nat := [2,0,8,0,3,2,9,1,2,0,8,10,10,8,1,1,10,8,0,1,9,3,1,2,11,3,9,9,9,9,3,2,1,2,9,3]

theorem envBound584 : H12AffineFastState.Bounded env584 := by
  intro p hp
  have h : env584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans583_584 : H12AffineEnvironment.transform 4 3 env583 = env584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env583 == env584) = true)

def leafEnv584 : List Nat := [2,0,8,0,3,2,9,1,2,0,8,10,10,8,1,1,10,8,0,1,9,3,1,2,3,11,1,3,9,9,9,9,3,2,1,2,0,1,9,3,1,8,0]

def active584 : List Nat := [0,2]

def tree584 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood584 : H12WitnessSearch.Good tree584 := H12GlobalWitnessIndex.good

theorem leafIdentity584 : H12AffineFastState.composeSystem env584 rootObs = leafEnv584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env584 rootObs == leafEnv584) = true)

theorem terminalChecked584 : H12PackedTerminal.terminalCheckFast leafEnv584 active584 tree584 = true := by decide +kernel

def env585 : List Nat := [2,0,8,1,32,32,9,1,2,1,43,40,10,8,34,34,11,8,1,34,42,32,0,33,11,33,9,43,8,9,33,2,1,2,42,32]

theorem envBound585 : H12AffineFastState.Bounded env585 := by
  intro p hp
  have h : env585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans582_585 : H12AffineEnvironment.transform 3 1 env582 = env585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env582 == env585) = true)

def env586 : List Nat := [2,0,8,1,8,8,9,1,2,1,3,0,10,8,10,10,11,8,1,10,2,8,0,9,11,9,9,3,8,9,9,2,1,2,2,8]

theorem envBound586 : H12AffineFastState.Bounded env586 := by
  intro p hp
  have h : env586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans585_586 : H12AffineEnvironment.transform 4 8 env585 = env586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env585 == env586) = true)

theorem identity586 : scanCanonicalize (H12AffineFastState.compose env586 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound586 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env587 : List Nat := [2,0,3,1,3,3,2,1,2,1,3,0,1,3,1,1,0,3,1,1,2,3,0,2,0,2,2,3,3,2,2,2,1,2,2,3]

theorem envBound587 : H12AffineFastState.Bounded env587 := by
  intro p hp
  have h : env587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans586_587 : H12AffineEnvironment.transform 2 3 env586 = env587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env586 == env587) = true)

def leafEnv587 : List Nat := [2,0,3,1,3,3,2,1,2,1,3,0,1,3,1,1,0,3,1,1,2,3,0,2,2,0,1,2,2,3,3,2,2,2,1,2,0,1,2,3,1,3,0]

def active587 : List Nat := [0]

def tree587 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood587 : H12WitnessSearch.Good tree587 := H12GlobalWitnessIndex.good

theorem leafIdentity587 : H12AffineFastState.composeSystem env587 rootObs = leafEnv587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env587 rootObs == leafEnv587) = true)

theorem terminalChecked587 : H12PackedTerminal.terminalCheckFast leafEnv587 active587 tree587 = true := by decide +kernel

def env588 : List Nat := [2,0,8,1,9,9,9,1,2,1,2,1,10,8,11,11,11,8,1,11,3,9,0,8,11,8,9,2,8,9,8,2,1,2,3,9]

theorem envBound588 : H12AffineFastState.Bounded env588 := by
  intro p hp
  have h : env588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans585_588 : H12AffineEnvironment.transform 4 9 env585 = env588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env585 == env588) = true)

def env589 : List Nat := [2,0,0,1,1,1,1,1,2,1,2,1,2,0,3,3,3,0,1,3,3,1,0,0,3,0,1,2,0,1,0,2,1,2,3,1]

theorem envBound589 : H12AffineFastState.Bounded env589 := by
  intro p hp
  have h : env589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans588_589 : H12AffineEnvironment.transform 2 0 env588 = env589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env588 == env589) = true)

theorem identity589 : scanCanonicalize (H12AffineFastState.compose env589 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound589 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env590 : List Nat := [0,0,0,1,1,1,1,1,0,1,0,1,0,0,1,1,1,0,1,1,1,1,0,0,1,0,1,0,0,1,0,0,1,0,1,1]

theorem envBound590 : H12AffineFastState.Bounded env590 := by
  intro p hp
  have h : env590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans589_590 : H12AffineEnvironment.transform 0 0 env589 = env590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env589 == env590) = true)

def leafEnv590 : List Nat := [0,0,0,1,1,1,1,1,0,1,0,1,0,0,1,1,1,0,1,1,1,1,0,0,0,1,1,0,1,0,0,1,0,0,1,0,0,1,1,1,1,0,0]

def active590 : List Nat := []

def tree590 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood590 : H12WitnessSearch.Good tree590 := H12GlobalWitnessIndex.good

theorem leafIdentity590 : H12AffineFastState.composeSystem env590 rootObs = leafEnv590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env590 rootObs == leafEnv590) = true)

theorem terminalChecked590 : H12PackedTerminal.terminalCheckFast leafEnv590 active590 tree590 = true := by decide +kernel

def env591 : List Nat := [2,0,1,1,0,0,0,1,2,1,2,1,3,1,2,2,2,1,1,2,3,0,0,1,2,1,0,2,1,0,1,2,1,2,3,0]

theorem envBound591 : H12AffineFastState.Bounded env591 := by
  intro p hp
  have h : env591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans588_591 : H12AffineEnvironment.transform 2 1 env588 = env591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env588 == env591) = true)

def leafEnv591 : List Nat := [2,0,1,1,0,0,0,1,2,1,2,1,3,1,2,2,2,1,1,2,3,0,0,1,1,2,1,1,0,2,1,0,1,2,1,2,0,1,3,0,1,2,0]

def active591 : List Nat := [0]

def tree591 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood591 : H12WitnessSearch.Good tree591 := H12GlobalWitnessIndex.good

theorem leafIdentity591 : H12AffineFastState.composeSystem env591 rootObs = leafEnv591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env591 rootObs == leafEnv591) = true)

theorem terminalChecked591 : H12PackedTerminal.terminalCheckFast leafEnv591 active591 tree591 = true := by decide +kernel

def env592 : List Nat := [2,1,8,16,32,49,9,0,512,17,553,571,10,522,34,34,536,522,17,34,552,32,17,33,11,48,523,568,539,523,49,2,0,2,552,546]

theorem envBound592 : H12AffineFastState.Bounded env592 := by
  intro p hp
  have h : env592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans580_592 : H12AffineEnvironment.transform 1 1 env580 = env592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env580 == env592) = true)

theorem identity592 : scanCanonicalize (H12AffineFastState.compose env592 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound592 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env593 : List Nat := [2,1,8,16,32,49,9,0,33,17,8,26,10,43,34,34,57,43,17,34,9,32,17,33,11,48,42,25,58,42,49,2,0,2,9,3]

theorem envBound593 : H12AffineFastState.Bounded env593 := by
  intro p hp
  have h : env593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans592_593 : H12AffineEnvironment.transform 8 33 env592 = env593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env592 == env593) = true)

def env594 : List Nat := [2,1,8,0,32,33,9,0,33,1,8,10,10,43,34,34,41,43,1,34,9,32,1,33,11,32,42,9,42,42,33,2,0,2,9,3]

theorem envBound594 : H12AffineFastState.Bounded env594 := by
  intro p hp
  have h : env594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans593_594 : H12AffineEnvironment.transform 3 0 env593 = env594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env593 == env594) = true)

theorem identity594 : scanCanonicalize (H12AffineFastState.compose env594 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound594 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env595 : List Nat := [2,1,8,0,3,2,9,0,2,1,8,10,10,8,1,1,10,8,1,1,9,3,1,2,11,3,9,9,9,9,2,2,0,2,9,3]

theorem envBound595 : H12AffineFastState.Bounded env595 := by
  intro p hp
  have h : env595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans594_595 : H12AffineEnvironment.transform 4 3 env594 = env595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env594 == env595) = true)

def leafEnv595 : List Nat := [2,1,8,0,3,2,9,0,2,1,8,10,10,8,1,1,10,8,1,1,9,3,1,2,2,11,1,3,9,9,9,9,2,2,0,2,1,1,9,3,1,8,0]

def active595 : List Nat := [0,2]

def tree595 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood595 : H12WitnessSearch.Good tree595 := H12GlobalWitnessIndex.good

theorem leafIdentity595 : H12AffineFastState.composeSystem env595 rootObs = leafEnv595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env595 rootObs == leafEnv595) = true)

theorem terminalChecked595 : H12PackedTerminal.terminalCheckFast leafEnv595 active595 tree595 = true := by decide +kernel

def env596 : List Nat := [2,1,8,1,32,32,9,0,33,0,8,11,10,43,34,34,40,43,0,34,9,32,0,33,11,33,42,8,43,42,32,2,0,2,9,3]

theorem envBound596 : H12AffineFastState.Bounded env596 := by
  intro p hp
  have h : env596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans593_596 : H12AffineEnvironment.transform 3 1 env593 = env596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env593 == env596) = true)

def env597 : List Nat := [2,1,8,1,8,8,9,0,9,0,8,11,10,3,10,10,0,3,0,10,9,8,0,9,11,9,2,8,3,2,8,2,0,2,9,3]

theorem envBound597 : H12AffineFastState.Bounded env597 := by
  intro p hp
  have h : env597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans596_597 : H12AffineEnvironment.transform 4 8 env596 = env597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env596 == env597) = true)

theorem identity597 : scanCanonicalize (H12AffineFastState.compose env597 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound597 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env598 : List Nat := [2,1,3,1,3,3,2,0,2,0,3,0,1,3,1,1,0,3,0,1,2,3,0,2,0,2,2,3,3,2,3,2,0,2,2,3]

theorem envBound598 : H12AffineFastState.Bounded env598 := by
  intro p hp
  have h : env598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans597_598 : H12AffineEnvironment.transform 2 3 env597 = env598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env597 == env598) = true)

def leafEnv598 : List Nat := [2,1,3,1,3,3,2,0,2,0,3,0,1,3,1,1,0,3,0,1,2,3,0,2,3,0,1,2,2,3,3,2,3,2,0,2,1,1,2,3,1,3,0]

def active598 : List Nat := [0]

def tree598 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood598 : H12WitnessSearch.Good tree598 := H12GlobalWitnessIndex.good

theorem leafIdentity598 : H12AffineFastState.composeSystem env598 rootObs = leafEnv598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env598 rootObs == leafEnv598) = true)

theorem terminalChecked598 : H12PackedTerminal.terminalCheckFast leafEnv598 active598 tree598 = true := by decide +kernel

def env599 : List Nat := [2,1,8,1,9,9,9,0,8,0,8,11,10,2,11,11,1,2,0,11,9,9,0,8,11,8,3,8,2,3,9,2,0,2,9,3]

theorem envBound599 : H12AffineFastState.Bounded env599 := by
  intro p hp
  have h : env599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans596_599 : H12AffineEnvironment.transform 4 9 env596 = env599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env596 == env599) = true)

def env600 : List Nat := [2,1,0,1,1,1,1,0,0,0,0,3,2,2,3,3,1,2,0,3,1,1,0,0,3,0,3,0,2,3,1,2,0,2,1,3]

theorem envBound600 : H12AffineFastState.Bounded env600 := by
  intro p hp
  have h : env600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans599_600 : H12AffineEnvironment.transform 2 0 env599 = env600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env599 == env600) = true)

theorem identity600 : scanCanonicalize (H12AffineFastState.compose env600 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound600 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env601 : List Nat := [0,1,0,1,1,1,1,0,0,0,0,1,0,0,1,1,1,0,0,1,1,1,0,0,1,0,1,0,0,1,1,0,0,0,1,1]

theorem envBound601 : H12AffineFastState.Bounded env601 := by
  intro p hp
  have h : env601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans600_601 : H12AffineEnvironment.transform 0 0 env600 = env601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env600 == env601) = true)

def leafEnv601 : List Nat := [0,1,0,1,1,1,1,0,0,0,0,1,0,0,1,1,1,0,0,1,1,1,0,0,1,1,1,0,1,0,0,1,1,0,0,0,1,1,1,1,1,0,0]

def active601 : List Nat := []

def tree601 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood601 : H12WitnessSearch.Good tree601 := H12GlobalWitnessIndex.good

theorem leafIdentity601 : H12AffineFastState.composeSystem env601 rootObs = leafEnv601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env601 rootObs == leafEnv601) = true)

theorem terminalChecked601 : H12PackedTerminal.terminalCheckFast leafEnv601 active601 tree601 = true := by decide +kernel

def env602 : List Nat := [2,1,1,1,0,0,0,0,1,0,1,2,3,2,2,2,1,2,0,2,0,0,0,1,2,1,3,1,2,3,0,2,0,2,0,3]

theorem envBound602 : H12AffineFastState.Bounded env602 := by
  intro p hp
  have h : env602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans599_602 : H12AffineEnvironment.transform 2 1 env599 = env602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env599 == env602) = true)

def leafEnv602 : List Nat := [2,1,1,1,0,0,0,0,1,0,1,2,3,2,2,2,1,2,0,2,0,0,0,1,0,2,1,1,3,1,2,3,0,2,0,2,1,1,0,3,1,1,0]

def active602 : List Nat := [0]

def tree602 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood602 : H12WitnessSearch.Good tree602 := H12GlobalWitnessIndex.good

theorem leafIdentity602 : H12AffineFastState.composeSystem env602 rootObs = leafEnv602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env602 rootObs == leafEnv602) = true)

theorem terminalChecked602 : H12PackedTerminal.terminalCheckFast leafEnv602 active602 tree602 = true := by decide +kernel

def env603 : List Nat := [2,4,8,16,32,64,9,116,512,21,2048,586,2643,522,2683,34,2112,634,101,2683,2161,32,97,2680,2642,49,635,2145,619,635,53,2651,4,2651,2161,2171]

theorem envBound603 : H12AffineFastState.Bounded env603 := by
  intro p hp
  have h : env603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans577_603 : H12AffineEnvironment.transform 9 21 env577 = env603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env577 == env603) = true)

theorem identity603 : scanCanonicalize (H12AffineFastState.compose env603 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound603 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env604 : List Nat := [2,4,8,16,3,64,9,87,512,21,2048,586,2643,522,2648,1,2112,601,70,2648,2130,3,66,2651,2642,18,600,2114,584,600,22,2651,4,2651,2130,2136]

theorem envBound604 : H12AffineFastState.Bounded env604 := by
  intro p hp
  have h : env604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans603_604 : H12AffineEnvironment.transform 4 3 env603 = env604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env603 == env604) = true)

theorem identity604 : scanCanonicalize (H12AffineFastState.compose env604 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound604 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env605 : List Nat := [2,4,8,16,3,64,9,87,512,21,523,586,88,522,83,1,587,601,70,83,601,3,66,80,89,18,600,585,584,600,22,80,4,80,601,595]

theorem envBound605 : H12AffineFastState.Bounded env605 := by
  intro p hp
  have h : env605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans604_605 : H12AffineEnvironment.transform 10 523 env604 = env605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env604 == env605) = true)

def env606 : List Nat := [2,4,8,16,3,20,9,3,512,21,523,542,12,522,7,1,543,525,18,7,525,3,22,4,13,18,524,541,540,524,22,4,4,4,525,519]

theorem envBound606 : H12AffineFastState.Bounded env606 := by
  intro p hp
  have h : env606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans605_606 : H12AffineEnvironment.transform 5 20 env605 = env606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 20 env605 == env606) = true)

theorem identity606 : scanCanonicalize (H12AffineFastState.compose env606 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound606 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env607 : List Nat := [2,4,8,16,3,20,9,3,4,21,15,26,12,14,7,1,27,9,18,7,9,3,22,4,13,18,8,25,24,8,22,4,4,4,9,3]

theorem envBound607 : H12AffineFastState.Bounded env607 := by
  intro p hp
  have h : env607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans606_607 : H12AffineEnvironment.transform 8 4 env606 = env607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env606 == env607) = true)

def env608 : List Nat := [2,4,8,0,3,4,9,3,4,5,15,10,12,14,7,1,11,9,2,7,9,3,6,4,13,2,8,9,8,8,6,4,4,4,9,3]

theorem envBound608 : H12AffineFastState.Bounded env608 := by
  intro p hp
  have h : env608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans607_608 : H12AffineEnvironment.transform 3 0 env607 = env608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env607 == env608) = true)

def env609 : List Nat := [2,4,4,0,3,4,5,3,4,5,3,6,0,2,7,1,7,5,2,7,5,3,6,4,1,2,4,5,4,4,6,4,4,4,5,3]

theorem envBound609 : H12AffineFastState.Bounded env609 := by
  intro p hp
  have h : env609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans608_609 : H12AffineEnvironment.transform 2 4 env608 = env609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env608 == env609) = true)

theorem identity609 : scanCanonicalize (H12AffineFastState.compose env609 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound609 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env610 : List Nat := [2,2,2,0,3,2,3,3,2,3,3,0,0,2,1,1,1,3,2,1,3,3,0,2,1,2,2,3,2,2,0,2,2,2,3,3]

theorem envBound610 : H12AffineFastState.Bounded env610 := by
  intro p hp
  have h : env610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans609_610 : H12AffineEnvironment.transform 1 2 env609 = env610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env609 == env610) = true)

def leafEnv610 : List Nat := [2,2,2,0,3,2,3,3,2,3,3,0,0,2,1,1,1,3,2,1,3,3,0,2,1,1,1,2,2,3,2,2,0,2,2,2,3,1,3,3,1,2,0]

def active610 : List Nat := [0]

def tree610 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood610 : H12WitnessSearch.Good tree610 := H12GlobalWitnessIndex.good

theorem leafIdentity610 : H12AffineFastState.composeSystem env610 rootObs = leafEnv610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env610 rootObs == leafEnv610) = true)

theorem terminalChecked610 : H12PackedTerminal.terminalCheckFast leafEnv610 active610 tree610 = true := by decide +kernel

def env611 : List Nat := [2,4,5,0,3,4,4,3,4,5,2,7,1,3,7,1,6,4,2,7,4,3,6,4,0,2,5,4,5,5,6,4,4,4,4,3]

theorem envBound611 : H12AffineFastState.Bounded env611 := by
  intro p hp
  have h : env611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans608_611 : H12AffineEnvironment.transform 2 5 env608 = env611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env608 == env611) = true)

def env612 : List Nat := [2,0,1,0,3,0,0,3,0,1,2,3,1,3,3,1,2,0,2,3,0,3,2,0,0,2,1,0,1,1,2,0,0,0,0,3]

theorem envBound612 : H12AffineFastState.Bounded env612 := by
  intro p hp
  have h : env612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans611_612 : H12AffineEnvironment.transform 1 0 env611 = env612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env611 == env612) = true)

theorem identity612 : scanCanonicalize (H12AffineFastState.compose env612 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound612 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env613 : List Nat := [0,0,1,0,1,0,0,1,0,1,0,1,1,1,1,1,0,0,0,1,0,1,0,0,0,0,1,0,1,1,0,0,0,0,0,1]

theorem envBound613 : H12AffineFastState.Bounded env613 := by
  intro p hp
  have h : env613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans612_613 : H12AffineEnvironment.transform 0 0 env612 = env613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env612 == env613) = true)

def leafEnv613 : List Nat := [0,0,1,0,1,0,0,1,0,1,0,1,1,1,1,1,0,0,0,1,0,1,0,0,1,0,1,0,1,0,1,1,0,0,0,0,1,1,0,1,1,1,0]

def active613 : List Nat := []

def tree613 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood613 : H12WitnessSearch.Good tree613 := H12GlobalWitnessIndex.good

theorem leafIdentity613 : H12AffineFastState.composeSystem env613 rootObs = leafEnv613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env613 rootObs == leafEnv613) = true)

theorem terminalChecked613 : H12PackedTerminal.terminalCheckFast leafEnv613 active613 tree613 = true := by decide +kernel

def env614 : List Nat := [2,1,0,0,3,1,1,3,1,0,2,2,1,3,2,1,3,1,2,2,1,3,3,1,0,2,0,1,0,0,3,1,1,1,1,3]

theorem envBound614 : H12AffineFastState.Bounded env614 := by
  intro p hp
  have h : env614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans611_614 : H12AffineEnvironment.transform 1 1 env611 = env614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env611 == env614) = true)

def leafEnv614 : List Nat := [2,1,0,0,3,1,1,3,1,0,2,2,1,3,2,1,3,1,2,2,1,3,3,1,1,0,1,2,0,1,0,0,3,1,1,1,3,2,1,3,1,0,0]

def active614 : List Nat := [0]

def tree614 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood614 : H12WitnessSearch.Good tree614 := H12GlobalWitnessIndex.good

theorem leafIdentity614 : H12AffineFastState.composeSystem env614 rootObs = leafEnv614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env614 rootObs == leafEnv614) = true)

theorem terminalChecked614 : H12PackedTerminal.terminalCheckFast leafEnv614 active614 tree614 = true := by decide +kernel

def env615 : List Nat := [2,4,8,1,3,5,9,3,4,4,15,11,12,14,7,1,10,9,3,7,9,3,7,4,13,3,8,8,9,8,7,4,4,4,9,3]

theorem envBound615 : H12AffineFastState.Bounded env615 := by
  intro p hp
  have h : env615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans607_615 : H12AffineEnvironment.transform 3 1 env607 = env615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env607 == env615) = true)

theorem identity615 : scanCanonicalize (H12AffineFastState.compose env615 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound615 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env616 : List Nat := [2,2,8,1,3,3,9,3,2,2,9,11,10,8,1,1,10,9,3,1,9,3,1,2,11,3,8,8,9,8,1,2,2,2,9,3]

theorem envBound616 : H12AffineFastState.Bounded env616 := by
  intro p hp
  have h : env616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans615_616 : H12AffineEnvironment.transform 1 2 env615 = env616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env615 == env616) = true)

def leafEnv616 : List Nat := [2,2,8,1,3,3,9,3,2,2,9,11,10,8,1,1,10,9,3,1,9,3,1,2,0,11,1,3,8,8,9,8,1,2,2,2,3,1,9,3,1,8,0]

def active616 : List Nat := [0,2]

def tree616 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood616 : H12WitnessSearch.Good tree616 := H12GlobalWitnessIndex.good

theorem leafIdentity616 : H12AffineFastState.composeSystem env616 rootObs = leafEnv616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env616 rootObs == leafEnv616) = true)

theorem terminalChecked616 : H12PackedTerminal.terminalCheckFast leafEnv616 active616 tree616 = true := by decide +kernel

def env617 : List Nat := [2,4,8,16,3,21,9,2,512,21,523,543,13,522,6,1,542,524,19,6,524,3,23,5,12,18,525,540,541,525,22,5,4,5,524,518]

theorem envBound617 : H12AffineFastState.Bounded env617 := by
  intro p hp
  have h : env617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans605_617 : H12AffineEnvironment.transform 5 21 env605 = env617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 21 env605 == env617) = true)

theorem identity617 : scanCanonicalize (H12AffineFastState.compose env617 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound617 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env618 : List Nat := [2,4,8,16,3,21,9,2,2,21,9,29,13,8,6,1,28,14,19,6,14,3,23,5,12,18,15,30,31,15,22,5,4,5,14,4]

theorem envBound618 : H12AffineFastState.Bounded env618 := by
  intro p hp
  have h : env618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans617_618 : H12AffineEnvironment.transform 8 2 env617 = env618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env617 == env618) = true)

def env619 : List Nat := [2,4,8,0,3,5,9,2,2,5,9,13,13,8,6,1,12,14,3,6,14,3,7,5,12,2,15,14,15,15,6,5,4,5,14,4]

theorem envBound619 : H12AffineFastState.Bounded env619 := by
  intro p hp
  have h : env619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans618_619 : H12AffineEnvironment.transform 3 0 env618 = env619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env618 == env619) = true)

def env620 : List Nat := [2,4,4,0,3,5,5,2,2,5,5,1,1,4,6,1,0,2,3,6,2,3,7,5,0,2,3,2,3,3,6,5,4,5,2,4]

theorem envBound620 : H12AffineFastState.Bounded env620 := by
  intro p hp
  have h : env620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans619_620 : H12AffineEnvironment.transform 2 4 env619 = env620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env619 == env620) = true)

def env621 : List Nat := [2,0,0,0,3,1,1,2,2,1,1,1,1,0,2,1,0,2,3,2,2,3,3,1,0,2,3,2,3,3,2,1,0,1,2,0]

theorem envBound621 : H12AffineFastState.Bounded env621 := by
  intro p hp
  have h : env621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans620_621 : H12AffineEnvironment.transform 1 0 env620 = env621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env620 == env621) = true)

def leafEnv621 : List Nat := [2,0,0,0,3,1,1,2,2,1,1,1,1,0,2,1,0,2,3,2,2,3,3,1,0,0,1,2,3,2,3,3,2,1,0,1,2,2,2,0,1,3,0]

def active621 : List Nat := [0]

def tree621 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood621 : H12WitnessSearch.Good tree621 := H12GlobalWitnessIndex.good

theorem leafIdentity621 : H12AffineFastState.composeSystem env621 rootObs = leafEnv621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env621 rootObs == leafEnv621) = true)

theorem terminalChecked621 : H12PackedTerminal.terminalCheckFast leafEnv621 active621 tree621 = true := by decide +kernel

def env622 : List Nat := [2,1,1,0,3,0,0,2,2,0,0,1,1,1,3,1,0,2,3,3,2,3,2,0,0,2,3,2,3,3,3,0,1,0,2,1]

theorem envBound622 : H12AffineFastState.Bounded env622 := by
  intro p hp
  have h : env622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans620_622 : H12AffineEnvironment.transform 1 1 env620 = env622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env620 == env622) = true)

theorem identity622 : scanCanonicalize (H12AffineFastState.compose env622 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound622 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env623 : List Nat := [0,1,1,0,1,0,0,0,0,0,0,1,1,1,1,1,0,0,1,1,0,1,0,0,0,0,1,0,1,1,1,0,1,0,0,1]

theorem envBound623 : H12AffineFastState.Bounded env623 := by
  intro p hp
  have h : env623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans622_623 : H12AffineEnvironment.transform 0 0 env622 = env623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env622 == env623) = true)

def leafEnv623 : List Nat := [0,1,1,0,1,0,0,0,0,0,0,1,1,1,1,1,0,0,1,1,0,1,0,0,0,0,1,0,1,0,1,1,1,0,1,0,0,1,0,1,1,1,0]

def active623 : List Nat := []

def tree623 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood623 : H12WitnessSearch.Good tree623 := H12GlobalWitnessIndex.good

theorem leafIdentity623 : H12AffineFastState.composeSystem env623 rootObs = leafEnv623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env623 rootObs == leafEnv623) = true)

theorem terminalChecked623 : H12PackedTerminal.terminalCheckFast leafEnv623 active623 tree623 = true := by decide +kernel

def env624 : List Nat := [2,4,5,0,3,5,4,2,2,5,4,0,0,5,6,1,1,3,3,6,3,3,7,5,1,2,2,3,2,2,6,5,4,5,3,4]

theorem envBound624 : H12AffineFastState.Bounded env624 := by
  intro p hp
  have h : env624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans619_624 : H12AffineEnvironment.transform 2 5 env619 = env624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env619 == env624) = true)

theorem identity624 : scanCanonicalize (H12AffineFastState.compose env624 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound624 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env625 : List Nat := [2,3,2,0,3,2,3,2,2,2,3,0,0,2,1,1,1,3,3,1,3,3,0,2,1,2,2,3,2,2,1,2,3,2,3,3]

theorem envBound625 : H12AffineFastState.Bounded env625 := by
  intro p hp
  have h : env625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans624_625 : H12AffineEnvironment.transform 1 3 env624 = env625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env624 == env625) = true)

def leafEnv625 : List Nat := [2,3,2,0,3,2,3,2,2,2,3,0,0,2,1,1,1,3,3,1,3,3,0,2,0,1,1,2,2,3,2,2,1,2,3,2,2,1,3,3,1,2,0]

def active625 : List Nat := [0]

def tree625 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood625 : H12WitnessSearch.Good tree625 := H12GlobalWitnessIndex.good

theorem leafIdentity625 : H12AffineFastState.composeSystem env625 rootObs = leafEnv625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env625 rootObs == leafEnv625) = true)

theorem terminalChecked625 : H12PackedTerminal.terminalCheckFast leafEnv625 active625 tree625 = true := by decide +kernel

def env626 : List Nat := [2,4,8,1,3,4,9,2,2,4,9,12,13,8,6,1,13,14,2,6,14,3,6,5,12,3,15,15,14,15,7,5,4,5,14,4]

theorem envBound626 : H12AffineFastState.Bounded env626 := by
  intro p hp
  have h : env626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans618_626 : H12AffineEnvironment.transform 3 1 env618 = env626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env618 == env626) = true)

theorem identity626 : scanCanonicalize (H12AffineFastState.compose env626 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound626 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env627 : List Nat := [2,3,8,1,3,3,9,2,2,3,9,11,10,8,1,1,10,9,2,1,9,3,1,2,11,3,8,8,9,8,0,2,3,2,9,3]

theorem envBound627 : H12AffineFastState.Bounded env627 := by
  intro p hp
  have h : env627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans626_627 : H12AffineEnvironment.transform 1 3 env626 = env627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env626 == env627) = true)

def leafEnv627 : List Nat := [2,3,8,1,3,3,9,2,2,3,9,11,10,8,1,1,10,9,2,1,9,3,1,2,1,11,1,3,8,8,9,8,0,2,3,2,2,1,9,3,1,8,0]

def active627 : List Nat := [0,2]

def tree627 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood627 : H12WitnessSearch.Good tree627 := H12GlobalWitnessIndex.good

theorem leafIdentity627 : H12AffineFastState.composeSystem env627 rootObs = leafEnv627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env627 rootObs == leafEnv627) = true)

theorem terminalChecked627 : H12PackedTerminal.terminalCheckFast leafEnv627 active627 tree627 = true := by decide +kernel

def env628 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4297,8353,65536,2113,5293,236,8353,3173,32,1277,73737,8328,1197,5157,3324,5309,75786,1193,73770,1041,73770,3308,74371]

theorem envBound628 : H12AffineFastState.Bounded env628 := by
  intro p hp
  have h : env628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans558_628 : H12AffineEnvironment.transform 16 2113 env558 = env628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2113 env558 == env628) = true)

theorem identity628 : scanCanonicalize (H12AffineFastState.compose env628 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound628 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env629 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4297,8353,8322,2113,5293,236,8353,3173,32,1277,139,8328,1197,5157,3324,5309,2184,1193,168,1041,168,3308,513]

theorem envBound629 : H12AffineFastState.Bounded env629 := by
  intro p hp
  have h : env629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans628_629 : H12AffineEnvironment.transform 15 8322 env628 = env629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env628 == env629) = true)

theorem identity629 : scanCanonicalize (H12AffineFastState.compose env629 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound629 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env630 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,4297,0,35,2113,5293,236,0,3173,32,1277,139,41,1197,5157,3324,5309,2184,1193,168,1041,168,3308,513]

theorem envBound630 : H12AffineFastState.Bounded env630 := by
  intro p hp
  have h : env630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans629_630 : H12AffineEnvironment.transform 12 161 env629 = env630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env629 == env630) = true)

theorem identity630 : scanCanonicalize (H12AffineFastState.compose env630 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound630 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env631 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,161,4281,0,35,2097,5293,156,0,3093,32,1165,139,41,1197,5157,3212,5309,2184,1193,168,1041,168,3228,513]

theorem envBound631 : H12AffineFastState.Bounded env631 := by
  intro p hp
  have h : env631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans630_631 : H12AffineEnvironment.transform 5 48 env630 = env631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env630 == env631) = true)

theorem identity631 : scanCanonicalize (H12AffineFastState.compose env631 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound631 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env632 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,3108,161,3229,0,35,2097,2185,156,0,3093,32,1165,139,41,1197,2049,3212,2201,2184,1193,168,1041,168,3228,513]

theorem envBound632 : H12AffineFastState.Bounded env632 := by
  intro p hp
  have h : env632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans631_632 : H12AffineEnvironment.transform 11 3108 env631 = env632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env631 == env632) = true)

theorem identity632 : scanCanonicalize (H12AffineFastState.compose env632 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound632 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env633 : List Nat := [2,4,8,16,32,48,128,141,512,1024,1567,571,161,642,0,35,1582,1686,156,0,522,32,1165,139,41,1197,1566,659,1670,1687,1193,168,1041,168,643,513]

theorem envBound633 : H12AffineFastState.Bounded env633 := by
  intro p hp
  have h : env633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans632_633 : H12AffineEnvironment.transform 10 1567 env632 = env633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env632 == env633) = true)

theorem identity633 : scanCanonicalize (H12AffineFastState.compose env633 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound633 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env634 : List Nat := [2,4,8,16,32,48,128,141,169,1024,1206,146,161,43,0,35,1159,1087,156,0,163,32,1165,139,41,1197,1207,58,1071,1086,1193,168,1041,168,42,168]

theorem envBound634 : H12AffineFastState.Bounded env634 := by
  intro p hp
  have h : env634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans633_634 : H12AffineEnvironment.transform 8 169 env633 = env634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env633 == env634) = true)

def env635 : List Nat := [2,4,8,16,0,16,128,141,137,1024,1174,146,129,11,0,3,1159,1055,156,0,131,0,1165,139,9,1165,1175,26,1039,1054,1161,136,1041,136,10,136]

theorem envBound635 : H12AffineFastState.Bounded env635 := by
  intro p hp
  have h : env635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans634_635 : H12AffineEnvironment.transform 4 0 env634 = env635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env634 == env635) = true)

theorem identity635 : scanCanonicalize (H12AffineFastState.compose env635 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 23) := by decide +kernel

theorem selectedBound635 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env636 : List Nat := [2,4,8,16,0,16,128,141,137,23,129,146,129,11,0,3,144,8,156,0,131,0,154,139,9,154,128,26,24,9,158,136,6,136,10,136]

theorem envBound636 : H12AffineFastState.Bounded env636 := by
  intro p hp
  have h : env636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans635_636 : H12AffineEnvironment.transform 9 23 env635 = env636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 23 env635 == env636) = true)

def leafEnv636 : List Nat := [2,4,8,16,0,16,128,141,137,23,129,146,129,11,0,3,144,8,156,0,131,0,154,139,21,9,1,154,128,26,24,9,158,136,6,136,143,138,10,136,1,130,0]

def active636 : List Nat := [0,1,2,3,6]

def tree636 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood636 : H12WitnessSearch.Good tree636 := H12GlobalWitnessIndex.good

theorem leafIdentity636 : H12AffineFastState.composeSystem env636 rootObs = leafEnv636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env636 rootObs == leafEnv636) = true)

theorem terminalChecked636 : H12PackedTerminal.terminalCheckFast leafEnv636 active636 tree636 = true := by decide +kernel

def env637 : List Nat := [2,4,8,16,1,17,128,141,136,1024,1175,146,128,10,0,2,1159,1054,156,0,130,1,1165,139,8,1164,1174,27,1038,1055,1160,137,1041,137,11,137]

theorem envBound637 : H12AffineFastState.Bounded env637 := by
  intro p hp
  have h : env637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans634_637 : H12AffineEnvironment.transform 4 1 env634 = env637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env634 == env637) = true)

theorem identity637 : scanCanonicalize (H12AffineFastState.compose env637 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 159) := by decide +kernel

theorem selectedBound637 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env638 : List Nat := [2,4,8,16,1,17,128,141,136,159,8,146,128,10,0,2,24,129,156,0,130,1,18,139,8,19,9,27,145,128,23,137,142,137,11,137]

theorem envBound638 : H12AffineFastState.Bounded env638 := by
  intro p hp
  have h : env638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans637_638 : H12AffineEnvironment.transform 9 159 env637 = env638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 159 env637 == env638) = true)

def leafEnv638 : List Nat := [2,4,8,16,1,17,128,141,136,159,8,146,128,10,0,2,24,129,156,0,130,1,18,139,20,8,1,19,9,27,145,128,23,137,142,137,7,139,11,137,1,131,0]

def active638 : List Nat := [0,1,2,3,6]

def tree638 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood638 : H12WitnessSearch.Good tree638 := H12GlobalWitnessIndex.good

theorem leafIdentity638 : H12AffineFastState.composeSystem env638 rootObs = leafEnv638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env638 rootObs == leafEnv638) = true)

theorem terminalChecked638 : H12PackedTerminal.terminalCheckFast leafEnv638 active638 tree638 = true := by decide +kernel

def env639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,33,8388608,8988133,8328,525377,262280,11031617,11158593,8990183,1364,73770,525568,8988103,34359738368,74371]

theorem envBound639 : H12AffineFastState.Bounded env639 := by
  intro p hp
  have h : env639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans332_639 : H12AffineEnvironment.transform 21 33 env332 = env639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env332 == env639) = true)

theorem identity639 : scanCanonicalize (H12AffineFastState.compose env639 (packedSelected [0,3,7,9,10,13,14,20,21,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound639 : packedSelected [0,3,7,9,10,13,14,20,21,22,24,26] rootPS < 2^1333 := by decide +kernel

def env640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,8575,131072,262144,524288,8353,2097152,33,8388608,8914074,8328,525377,262280,11031617,11158593,8916120,1364,341,525568,8914104,34359738368,1020]

theorem envBound640 : H12AffineFastState.Bounded env640 := by
  intro p hp
  have h : env640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans639_640 : H12AffineEnvironment.transform 15 8575 env639 = env640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env639 == env640) = true)

theorem identity640 : scanCanonicalize (H12AffineFastState.compose env640 (packedSelected [0,7,9,13,14,17,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound640 : packedSelected [0,7,9,13,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env641 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8323,131072,262144,524288,8353,2097152,33,8388608,8914074,8328,525377,262280,11031617,11158593,8916120,1192,169,525564,8914104,34359738368,512]

theorem envBound641 : H12AffineFastState.Bounded env641 := by
  intro p hp
  have h : env641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans640_641 : H12AffineEnvironment.transform 7 252 env640 = env641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env640 == env641) = true)

theorem identity641 : scanCanonicalize (H12AffineFastState.compose env641 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17596) := by decide +kernel

theorem selectedBound641 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env642 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8323,131072,262144,524288,8353,17596,33,8388608,8914074,8328,525377,262280,8917245,9044221,8916120,1192,169,525564,8914104,34359738368,512]

theorem envBound642 : H12AffineFastState.Bounded env642 := by
  intro p hp
  have h : env642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans641_642 : H12AffineEnvironment.transform 20 17596 env641 = env642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17596 env641 == env642) = true)

theorem identity642 : scanCanonicalize (H12AffineFastState.compose env642 (packedSelected [11,12,13,15,18] rootPS)) = affineNative (2^(34+1) ^^^ 940084) := by decide +kernel

theorem selectedBound642 : packedSelected [11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env643 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8323,131072,262144,524288,8353,17596,33,8388608,8914074,8328,525377,262280,8917245,9044221,8916120,1192,169,525564,8914104,940084,512]

theorem envBound643 : H12AffineFastState.Bounded env643 := by
  intro p hp
  have h : env643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans642_643 : H12AffineEnvironment.transform 34 940084 env642 = env643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 940084 env642 == env643) = true)

theorem identity643 : scanCanonicalize (H12AffineFastState.compose env643 (packedSelected [0,4,7,9,11,12,13,14,15,23] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound643 : packedSelected [0,4,7,9,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env644 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,1,35,131072,262144,524288,1,17596,33,8388608,8914074,40,525377,262280,8917245,9044221,8916120,1192,169,525564,8914104,940084,512]

theorem envBound644 : H12AffineFastState.Bounded env644 := by
  intro p hp
  have h : env644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans643_644 : H12AffineEnvironment.transform 12 160 env643 = env644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env643 == env644) = true)

theorem identity644 : scanCanonicalize (H12AffineFastState.compose env644 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5356) := by decide +kernel

theorem selectedBound644 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env645 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,1,35,5356,262144,524288,1,17596,33,8388608,8914074,40,525377,262280,8917245,8918033,8916120,1192,169,525564,8914104,806104,512]

theorem envBound645 : H12AffineFastState.Bounded env645 := by
  intro p hp
  have h : env645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans644_645 : H12AffineEnvironment.transform 16 5356 env644 = env645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5356 env644 == env645) = true)

theorem identity645 : scanCanonicalize (H12AffineFastState.compose env645 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(22+1) ^^^ 789657) := by decide +kernel

theorem selectedBound645 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env646 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,1,35,5356,262144,524288,1,17596,33,789657,264195,40,525377,262280,269412,268424,262145,1192,169,525564,264225,806104,512]

theorem envBound646 : H12AffineFastState.Bounded env646 := by
  intro p hp
  have h : env646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans645_646 : H12AffineEnvironment.transform 22 789657 env645 = env646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 789657 env645 == env646) = true)

theorem identity646 : scanCanonicalize (H12AffineFastState.compose env646 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound646 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env647 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,1,35,5356,2185,524288,1,17596,33,525328,138,40,525377,2049,5357,4097,2184,1192,169,525564,168,541777,512]

theorem envBound647 : H12AffineFastState.Bounded env647 := by
  intro p hp
  have h : env647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans646_647 : H12AffineEnvironment.transform 17 2185 env646 = env647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env646 == env647) = true)

theorem identity647 : scanCanonicalize (H12AffineFastState.compose env647 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound647 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env648 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,9,16384,1,35,5189,2080,524288,1,17429,33,525328,35,40,525377,2049,5188,4097,2081,1025,0,525397,1,541777,512]

theorem envBound648 : H12AffineFastState.Bounded env648 := by
  intro p hp
  have h : env648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans647_648 : H12AffineEnvironment.transform 6 41 env647 = env648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env647 == env648) = true)

def env649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,262280,77615105,77742081,13208935,67674548,73770,525568,13206855,34359738368,98850]

theorem envBound649 : H12AffineFastState.Bounded env649 := by
  intro p hp
  have h : env649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans252_649 : H12AffineEnvironment.transform 27 77615105 env252 = env649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 77615105 env252 == env649) = true)

theorem identity649 : scanCanonicalize (H12AffineFastState.compose env649 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(25+1) ^^^ 599234) := by decide +kernel

theorem selectedBound649 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,599234,262280,11105475,11232451,13208935,99702,73770,525568,13206855,34359738368,98850]

theorem envBound650 : H12AffineFastState.Bounded env650 := by
  intro p hp
  have h : env650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans649_650 : H12AffineEnvironment.transform 25 599234 env649 = env650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 599234 env649 == env650) = true)

def env651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,4194304,8388608,8988133,8328,599234,262280,11105475,11232451,13184455,75222,73770,525568,13182439,34359738368,74370]

theorem envBound651 : H12AffineFastState.Bounded env651 := by
  intro p hp
  have h : env651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans650_651 : H12AffineEnvironment.transform 14 8352 env650 = env651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env650 == env651) = true)

theorem identity651 : scanCanonicalize (H12AffineFastState.compose env651 (packedSelected [0,7,9,11,14,18,20,22,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 74078) := by decide +kernel

theorem selectedBound651 : packedSelected [0,7,9,11,14,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,74078,8388608,8988133,8328,599234,262280,11105475,11232451,8916121,75222,73770,525568,8914105,34359738368,74370]

theorem envBound652 : H12AffineFastState.Bounded env652 := by
  intro p hp
  have h : env652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans651_652 : H12AffineEnvironment.transform 21 74078 env651 = env652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74078 env651 == env652) = true)

def env653 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,73890,8388608,8987673,8328,599234,262280,11105475,11232451,8916121,74794,73770,525564,8914105,34359738368,74370]

theorem envBound653 : H12AffineFastState.Bounded env653 := by
  intro p hp
  have h : env653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans652_653 : H12AffineEnvironment.transform 7 252 env652 = env653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env652 == env653) = true)

theorem identity653 : scanCanonicalize (H12AffineFastState.compose env653 (packedSelected [1,2,5,6,7,9,10,18,20,21,22,23,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound653 : packedSelected [1,2,5,6,7,9,10,18,20,21,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env654 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8323,131072,262144,524288,8352,2097152,33,8388608,8914074,8328,525377,262280,11031616,11158592,8916121,1193,169,525564,8914105,34359738368,513]

theorem envBound654 : H12AffineFastState.Bounded env654 := by
  intro p hp
  have h : env654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans653_654 : H12AffineEnvironment.transform 15 8323 env653 = env654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env653 == env654) = true)

theorem identity654 : scanCanonicalize (H12AffineFastState.compose env654 (packedSelected [3,5,10] rootPS)) = affineNative (2^(22+1) ^^^ 2102460) := by decide +kernel

theorem selectedBound654 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env655 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8323,131072,262144,524288,8352,2097152,33,2102460,2625574,8328,525377,262280,540924,676092,2627621,1193,169,525564,2625541,34359738368,513]

theorem envBound655 : H12AffineFastState.Bounded env655 := by
  intro p hp
  have h : env655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans654_655 : H12AffineEnvironment.transform 22 2102460 env654 = env655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2102460 env654 == env655) = true)

theorem identity655 : scanCanonicalize (H12AffineFastState.compose env655 (packedSelected [11,12,13,15,18] rootPS)) = affineNative (2^(34+1) ^^^ 2241733) := by decide +kernel

theorem selectedBound655 : packedSelected [11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env656 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8323,131072,262144,524288,8352,2097152,33,2102460,2625574,8328,525377,262280,540924,676092,2627621,1193,169,525564,2625541,2241733,513]

theorem envBound656 : H12AffineFastState.Bounded env656 := by
  intro p hp
  have h : env656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans655_656 : H12AffineEnvironment.transform 34 2241733 env655 = env656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 2241733 env655 == env656) = true)

theorem identity656 : scanCanonicalize (H12AffineFastState.compose env656 (packedSelected [13,21] rootPS)) = affineNative (2^(20+1) ^^^ 12392) := by decide +kernel

theorem selectedBound656 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env657 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8323,131072,262144,524288,8352,12392,33,9428,532558,8328,525377,262280,540924,676092,534605,1193,169,525564,532589,132269,513]

theorem envBound657 : H12AffineFastState.Bounded env657 := by
  intro p hp
  have h : env657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans656_657 : H12AffineEnvironment.transform 20 12392 env656 = env657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12392 env656 == env657) = true)

theorem identity657 : scanCanonicalize (H12AffineFastState.compose env657 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 8388) := by decide +kernel

theorem selectedBound657 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env658 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8323,131072,262144,8388,8352,12392,33,9428,138,8328,9349,262280,24632,159800,2185,1193,169,9272,169,132269,513]

theorem envBound658 : H12AffineFastState.Bounded env658 := by
  intro p hp
  have h : env658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans657_658 : H12AffineEnvironment.transform 18 8388 env657 = env658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 8388 env657 == env658) = true)

theorem identity658 : scanCanonicalize (H12AffineFastState.compose env658 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 12297) := by decide +kernel

theorem selectedBound658 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env659 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8323,12297,262144,8388,8352,12392,33,9428,138,8328,9349,262280,24632,16433,2185,1193,169,9272,169,13476,513]

theorem envBound659 : H12AffineFastState.Bounded env659 := by
  intro p hp
  have h : env659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans658_659 : H12AffineEnvironment.transform 16 12297 env658 = env659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12297 env658 == env659) = true)

def env660 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,73891,8388608,8987672,8328,599234,262280,11105475,11232451,8916121,74795,73770,525565,8914105,34359738368,74370]

theorem envBound660 : H12AffineFastState.Bounded env660 := by
  intro p hp
  have h : env660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans652_660 : H12AffineEnvironment.transform 7 253 env652 = env660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env652 == env660) = true)

theorem identity660 : scanCanonicalize (H12AffineFastState.compose env660 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound660 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env661 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,8322,131072,262144,524288,8352,2097152,33,8388608,8914074,8328,525376,262280,11031617,11158593,8916121,1193,168,525565,8914105,34359738368,512]

theorem envBound661 : H12AffineFastState.Bounded env661 := by
  intro p hp
  have h : env661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans660_661 : H12AffineEnvironment.transform 15 8322 env660 = env661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env660 == env661) = true)

theorem identity661 : scanCanonicalize (H12AffineFastState.compose env661 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5356) := by decide +kernel

theorem selectedBound661 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env662 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,8322,5356,262144,524288,8352,2097152,33,8388608,8914074,8328,525376,262280,11031617,11030701,8916121,1193,168,525565,8914105,34359738368,512]

theorem envBound662 : H12AffineFastState.Bounded env662 := by
  intro p hp
  have h : env662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans661_662 : H12AffineEnvironment.transform 16 5356 env661 = env662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5356 env661 == env662) = true)

theorem identity662 : scanCanonicalize (H12AffineFastState.compose env662 (packedSelected [11,12,13,15,18] rootPS)) = affineNative (2^(34+1) ^^^ 24737) := by decide +kernel

theorem selectedBound662 : packedSelected [11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env663 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,8322,5356,262144,524288,8352,2097152,33,8388608,8914074,8328,525376,262280,11031617,11030701,8916121,1193,168,525565,8914105,24737,512]

theorem envBound663 : H12AffineFastState.Bounded env663 := by
  intro p hp
  have h : env663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans662_663 : H12AffineEnvironment.transform 34 24737 env662 = env663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 24737 env662 == env663) = true)

theorem identity663 : scanCanonicalize (H12AffineFastState.compose env663 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound663 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env664 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,1,35,5356,262144,524288,1,2097152,33,8388608,8914074,41,525376,262280,11031617,11030701,8916121,1193,168,525565,8914105,16384,512]

theorem envBound664 : H12AffineFastState.Bounded env664 := by
  intro p hp
  have h : env664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans663_664 : H12AffineEnvironment.transform 12 161 env663 = env664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env663 == env664) = true)

def env665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,4194304,8388608,8988133,8328,599234,262280,11105475,11232451,13184454,75223,73770,525568,13182438,34359738368,74371]

theorem envBound665 : H12AffineFastState.Bounded env665 := by
  intro p hp
  have h : env665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans650_665 : H12AffineEnvironment.transform 14 8353 env650 = env665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env650 == env665) = true)

def env666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,32,8388608,8988133,8328,599234,262280,11105475,11232451,8990182,75223,73770,525568,8988102,34359738368,74371]

theorem envBound666 : H12AffineFastState.Bounded env666 := by
  intro p hp
  have h : env666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans665_666 : H12AffineEnvironment.transform 21 32 env665 = env666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env665 == env666) = true)

def env667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,32,525328,74229,8328,599234,262280,2191571,2318547,76278,75223,73770,525568,74198,34359738368,74371]

theorem envBound667 : H12AffineFastState.Bounded env667 := by
  intro p hp
  have h : env667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans666_667 : H12AffineEnvironment.transform 22 525328 env666 = env667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525328 env666 == env667) = true)

theorem identity667 : scanCanonicalize (H12AffineFastState.compose env667 (packedSelected [0,7,9,13,14,17,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound667 : packedSelected [0,7,9,13,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,8574,131072,262144,524288,8353,2097152,32,525328,139,8328,525756,262280,2118061,2245037,2184,1193,340,525568,168,34359738368,1021]

theorem envBound668 : H12AffineFastState.Bounded env668 := by
  intro p hp
  have h : env668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans667_668 : H12AffineEnvironment.transform 15 8574 env667 = env668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env667 == env668) = true)

def env669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,32,525329,74228,8328,599234,262280,2191570,2318546,76279,75223,73770,525568,74199,34359738368,74371]

theorem envBound669 : H12AffineFastState.Bounded env669 := by
  intro p hp
  have h : env669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans666_669 : H12AffineEnvironment.transform 22 525329 env666 = env669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525329 env666 == env669) = true)

theorem identity669 : scanCanonicalize (H12AffineFastState.compose env669 (packedSelected [0,7,9,13,14,17,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound669 : packedSelected [0,7,9,13,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,8323,131072,262144,524288,8353,2097152,32,525329,375,8328,525377,262280,2117713,2244689,2420,1364,169,525568,340,34359738368,512]

theorem envBound670 : H12AffineFastState.Bounded env670 := by
  intro p hp
  have h : env670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans669_670 : H12AffineEnvironment.transform 15 8323 env669 = env670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env669 == env670) = true)

theorem identity670 : scanCanonicalize (H12AffineFastState.compose env670 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound670 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,8323,5393,262144,524288,8353,2097152,32,525329,375,8328,525377,262280,2117713,2118976,2420,1364,169,525568,340,34359738368,512]

theorem envBound671 : H12AffineFastState.Bounded env671 := by
  intro p hp
  have h : env671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans670_671 : H12AffineEnvironment.transform 16 5393 env670 = env671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env670 == env671) = true)

theorem identity671 : scanCanonicalize (H12AffineFastState.compose env671 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound671 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env672 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,8323,5356,262144,524288,8353,2097152,32,525329,138,8328,525377,262280,2117713,2118845,2185,1193,169,525565,169,34359738368,512]

theorem envBound672 : H12AffineFastState.Bounded env672 := by
  intro p hp
  have h : env672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans671_672 : H12AffineEnvironment.transform 7 253 env671 = env672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env671 == env672) = true)

theorem identity672 : scanCanonicalize (H12AffineFastState.compose env672 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 540908) := by decide +kernel

theorem selectedBound672 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env673 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,8323,5356,262144,524288,8353,540908,32,525329,138,8328,525377,262280,528573,529489,2185,1193,169,525565,169,34359738368,512]

theorem envBound673 : H12AffineFastState.Bounded env673 := by
  intro p hp
  have h : env673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans672_673 : H12AffineEnvironment.transform 20 540908 env672 = env673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 540908 env672 == env673) = true)

theorem identity673 : scanCanonicalize (H12AffineFastState.compose env673 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(34+1) ^^^ 5293) := by decide +kernel

theorem selectedBound673 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env674 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,8323,5356,262144,524288,8353,540908,32,525329,138,8328,525377,262280,528573,529489,2185,1193,169,525565,169,5293,512]

theorem envBound674 : H12AffineFastState.Bounded env674 := by
  intro p hp
  have h : env674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans673_674 : H12AffineEnvironment.transform 34 5293 env673 = env674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 5293 env673 == env674) = true)

theorem identity674 : scanCanonicalize (H12AffineFastState.compose env674 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound674 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env675 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,8323,5356,23589,524288,8353,540908,32,525329,138,8328,525377,23725,528573,529489,2185,1193,169,525565,169,5293,512]

theorem envBound675 : H12AffineFastState.Bounded env675 := by
  intro p hp
  have h : env675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans674_675 : H12AffineEnvironment.transform 17 23589 env674 = env675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env674 == env675) = true)

theorem identity675 : scanCanonicalize (H12AffineFastState.compose env675 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(18+1) ^^^ 1161) := by decide +kernel

theorem selectedBound675 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env676 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,8323,5356,23589,1161,8353,17509,32,152,138,8328,200,23725,5172,4312,2185,1193,169,116,169,5293,512]

theorem envBound676 : H12AffineFastState.Bounded env676 := by
  intro p hp
  have h : env676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans675_676 : H12AffineEnvironment.transform 18 1161 env675 = env676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1161 env675 == env676) = true)

theorem identity676 : scanCanonicalize (H12AffineFastState.compose env676 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 15878) := by decide +kernel

theorem selectedBound676 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env677 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,15878,8353,8323,5356,8739,1161,8353,14947,32,152,138,8328,200,8875,5172,4312,2185,1193,169,116,169,5293,512]

theorem envBound677 : H12AffineFastState.Bounded env677 := by
  intro p hp
  have h : env677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans676_677 : H12AffineEnvironment.transform 13 15878 env676 = env677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15878 env676 == env677) = true)

theorem identity677 : scanCanonicalize (H12AffineFastState.compose env677 (packedSelected [11,12] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound677 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env678 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,121,7807,216,250,5356,602,1161,216,6682,32,152,138,241,200,722,5172,4312,2185,1193,169,116,169,5293,512]

theorem envBound678 : H12AffineFastState.Bounded env678 := by
  intro p hp
  have h : env678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans677_678 : H12AffineEnvironment.transform 12 121 env677 = env678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env677 == env678) = true)

theorem identity678 : scanCanonicalize (H12AffineFastState.compose env678 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound678 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env679 : List Nat := [2,4,8,16,32,64,128,253,512,167,2048,4096,121,6872,216,250,4171,602,46,216,6682,32,152,138,241,200,722,4243,4312,2185,14,169,116,169,4106,512]

theorem envBound679 : H12AffineFastState.Bounded env679 := by
  intro p hp
  have h : env679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans678_679 : H12AffineEnvironment.transform 9 167 env678 = env679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env678 == env679) = true)

theorem identity679 : scanCanonicalize (H12AffineFastState.compose env679 (packedSelected [2,14] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound679 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env680 : List Nat := [2,4,8,16,32,64,88,37,512,127,2048,4096,121,6656,0,34,4171,602,46,0,6682,32,64,82,41,16,522,4171,4096,2129,14,113,116,113,4106,512]

theorem envBound680 : H12AffineFastState.Bounded env680 := by
  intro p hp
  have h : env680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans679_680 : H12AffineEnvironment.transform 6 88 env679 = env680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env679 == env680) = true)

def env681 : List Nat := [2,4,8,16,32,16,8,37,512,47,2048,4096,41,6656,0,34,4123,522,46,0,6682,32,16,2,41,16,522,4123,4096,2049,14,33,36,33,4106,512]

theorem envBound681 : H12AffineFastState.Bounded env681 := by
  intro p hp
  have h : env681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans680_681 : H12AffineEnvironment.transform 5 16 env680 = env681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env680 == env681) = true)

theorem identity681 : scanCanonicalize (H12AffineFastState.compose env681 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound681 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env682 : List Nat := [2,4,8,16,16,16,8,21,512,31,2048,4096,25,6656,0,18,4123,522,30,0,6682,16,16,2,25,16,522,4123,4096,2049,14,17,20,17,4106,512]

theorem envBound682 : H12AffineFastState.Bounded env682 := by
  intro p hp
  have h : env682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans681_682 : H12AffineEnvironment.transform 4 16 env681 = env682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env681 == env682) = true)

def env683 : List Nat := [2,4,8,16,16,16,8,21,512,31,2048,0,25,2560,0,18,27,522,30,0,2586,16,16,2,25,16,522,27,0,2049,14,17,20,17,10,512]

theorem envBound683 : H12AffineFastState.Bounded env683 := by
  intro p hp
  have h : env683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans682_683 : H12AffineEnvironment.transform 11 0 env682 = env683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env682 == env683) = true)

theorem identity683 : scanCanonicalize (H12AffineFastState.compose env683 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound683 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env684 : List Nat := [2,4,8,3,3,3,8,6,512,12,2048,0,10,2560,0,1,8,522,13,0,2569,3,3,2,10,3,522,8,0,2049,14,2,7,2,10,512]

theorem envBound684 : H12AffineFastState.Bounded env684 := by
  intro p hp
  have h : env684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans683_684 : H12AffineEnvironment.transform 3 3 env683 = env684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env683 == env684) = true)

def env685 : List Nat := [2,4,8,3,3,3,8,6,8,12,2048,0,10,2056,0,1,8,2,13,0,2049,3,3,2,10,3,2,8,0,2049,14,2,7,2,10,8]

theorem envBound685 : H12AffineFastState.Bounded env685 := by
  intro p hp
  have h : env685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans684_685 : H12AffineEnvironment.transform 8 8 env684 = env685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env684 == env685) = true)

def env686 : List Nat := [2,4,8,3,3,3,8,6,8,12,0,0,10,8,0,1,8,2,13,0,1,3,3,2,10,3,2,8,0,1,14,2,7,2,10,8]

theorem envBound686 : H12AffineFastState.Bounded env686 := by
  intro p hp
  have h : env686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans685_686 : H12AffineEnvironment.transform 10 0 env685 = env686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env685 == env686) = true)

theorem identity686 : scanCanonicalize (H12AffineFastState.compose env686 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound686 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env687 : List Nat := [2,4,5,3,3,3,5,6,5,1,0,0,7,5,0,1,5,2,0,0,1,3,3,2,7,3,2,5,0,1,3,2,7,2,7,5]

theorem envBound687 : H12AffineFastState.Bounded env687 := by
  intro p hp
  have h : env687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans686_687 : H12AffineEnvironment.transform 2 5 env686 = env687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env686 == env687) = true)

def env688 : List Nat := [2,0,1,3,3,3,1,2,1,1,0,0,3,1,0,1,1,2,0,0,1,3,3,2,3,3,2,1,0,1,3,2,3,2,3,1]

theorem envBound688 : H12AffineFastState.Bounded env688 := by
  intro p hp
  have h : env688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans687_688 : H12AffineEnvironment.transform 1 0 env687 = env688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env687 == env688) = true)

theorem identity688 : scanCanonicalize (H12AffineFastState.compose env688 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound688 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env689 : List Nat := [1,0,1,0,0,0,1,1,1,1,0,0,0,1,0,1,1,1,0,0,1,0,0,1,0,0,1,1,0,1,0,1,0,1,0,1]

theorem envBound689 : H12AffineFastState.Bounded env689 := by
  intro p hp
  have h : env689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans688_689 : H12AffineEnvironment.transform 0 1 env688 = env689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env688 == env689) = true)

def leafEnv689 : List Nat := [1,0,1,0,0,0,1,1,1,1,0,0,0,1,0,1,1,1,0,0,1,0,0,1,1,0,1,0,1,1,0,1,0,1,0,1,1,1,0,1,1,1,0]

def active689 : List Nat := []

def tree689 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood689 : H12WitnessSearch.Good tree689 := H12GlobalWitnessIndex.good

theorem leafIdentity689 : H12AffineFastState.composeSystem env689 rootObs = leafEnv689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env689 rootObs == leafEnv689) = true)

theorem terminalChecked689 : H12PackedTerminal.terminalCheckFast leafEnv689 active689 tree689 = true := by decide +kernel

def env690 : List Nat := [2,1,0,3,3,3,0,3,0,1,0,0,2,0,0,1,0,2,0,0,1,3,3,2,2,3,2,0,0,1,3,2,2,2,2,0]

theorem envBound690 : H12AffineFastState.Bounded env690 := by
  intro p hp
  have h : env690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans687_690 : H12AffineEnvironment.transform 1 1 env687 = env690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env687 == env690) = true)

def leafEnv690 : List Nat := [2,1,0,3,3,3,0,3,0,1,0,0,2,0,0,1,0,2,0,0,1,3,3,2,2,2,1,3,2,0,0,1,3,2,2,2,0,1,2,0,1,2,0]

def active690 : List Nat := [0]

def tree690 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood690 : H12WitnessSearch.Good tree690 := H12GlobalWitnessIndex.good

theorem leafIdentity690 : H12AffineFastState.composeSystem env690 rootObs = leafEnv690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env690 rootObs == leafEnv690) = true)

theorem terminalChecked690 : H12PackedTerminal.terminalCheckFast leafEnv690 active690 tree690 = true := by decide +kernel

def env691 : List Nat := [2,4,8,3,3,3,8,6,8,12,1,0,10,9,0,1,8,2,13,0,0,3,3,2,10,3,2,8,0,0,14,2,7,2,10,8]

theorem envBound691 : H12AffineFastState.Bounded env691 := by
  intro p hp
  have h : env691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans685_691 : H12AffineEnvironment.transform 10 1 env685 = env691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env685 == env691) = true)

theorem identity691 : scanCanonicalize (H12AffineFastState.compose env691 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound691 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env692 : List Nat := [2,4,7,3,3,3,7,6,7,3,1,0,5,6,0,1,7,2,2,0,0,3,3,2,5,3,2,7,0,0,1,2,7,2,5,7]

theorem envBound692 : H12AffineFastState.Bounded env692 := by
  intro p hp
  have h : env692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans691_692 : H12AffineEnvironment.transform 2 7 env691 = env692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env691 == env692) = true)

def env693 : List Nat := [2,0,3,3,3,3,3,2,3,3,1,0,1,2,0,1,3,2,2,0,0,3,3,2,1,3,2,3,0,0,1,2,3,2,1,3]

theorem envBound693 : H12AffineFastState.Bounded env693 := by
  intro p hp
  have h : env693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans692_693 : H12AffineEnvironment.transform 1 0 env692 = env693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env692 == env693) = true)

def leafEnv693 : List Nat := [2,0,3,3,3,3,3,2,3,3,1,0,1,2,0,1,3,2,2,0,0,3,3,2,0,1,1,3,2,3,0,0,1,2,3,2,1,1,1,3,1,2,0]

def active693 : List Nat := [0]

def tree693 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood693 : H12WitnessSearch.Good tree693 := H12GlobalWitnessIndex.good

theorem leafIdentity693 : H12AffineFastState.composeSystem env693 rootObs = leafEnv693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env693 rootObs == leafEnv693) = true)

theorem terminalChecked693 : H12PackedTerminal.terminalCheckFast leafEnv693 active693 tree693 = true := by decide +kernel

def env694 : List Nat := [2,1,2,3,3,3,2,3,2,3,1,0,0,3,0,1,2,2,2,0,0,3,3,2,0,3,2,2,0,0,1,2,2,2,0,2]

theorem envBound694 : H12AffineFastState.Bounded env694 := by
  intro p hp
  have h : env694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans692_694 : H12AffineEnvironment.transform 1 1 env692 = env694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env692 == env694) = true)

theorem identity694 : scanCanonicalize (H12AffineFastState.compose env694 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound694 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env695 : List Nat := [0,1,0,1,1,1,0,1,0,1,1,0,0,1,0,1,0,0,0,0,0,1,1,0,0,1,0,0,0,0,1,0,0,0,0,0]

theorem envBound695 : H12AffineFastState.Bounded env695 := by
  intro p hp
  have h : env695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans694_695 : H12AffineEnvironment.transform 0 0 env694 = env695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env694 == env695) = true)

def leafEnv695 : List Nat := [0,1,0,1,1,1,0,1,0,1,1,0,0,1,0,1,0,0,0,0,0,1,1,0,0,0,1,1,0,0,0,0,1,0,0,0,0,1,0,0,1,0,0]

def active695 : List Nat := []

def tree695 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood695 : H12WitnessSearch.Good tree695 := H12GlobalWitnessIndex.good

theorem leafIdentity695 : H12AffineFastState.composeSystem env695 rootObs = leafEnv695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env695 rootObs == leafEnv695) = true)

theorem terminalChecked695 : H12PackedTerminal.terminalCheckFast leafEnv695 active695 tree695 = true := by decide +kernel

def env696 : List Nat := [2,4,8,3,3,3,8,6,9,12,2048,0,10,2057,0,1,8,3,13,0,2048,3,3,2,10,3,3,8,0,2049,14,2,7,2,10,9]

theorem envBound696 : H12AffineFastState.Bounded env696 := by
  intro p hp
  have h : env696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans684_696 : H12AffineEnvironment.transform 8 9 env684 = env696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env684 == env696) = true)

theorem identity696 : scanCanonicalize (H12AffineFastState.compose env696 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 3) := by decide +kernel

theorem selectedBound696 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env697 : List Nat := [2,4,8,3,3,3,8,6,9,12,3,0,10,10,0,1,8,3,13,0,3,3,3,2,10,3,3,8,0,2,14,2,7,2,10,9]

theorem envBound697 : H12AffineFastState.Bounded env697 := by
  intro p hp
  have h : env697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans696_697 : H12AffineEnvironment.transform 10 3 env696 = env697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 3 env696 == env697) = true)

theorem identity697 : scanCanonicalize (H12AffineFastState.compose env697 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound697 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env698 : List Nat := [2,3,8,3,3,3,8,1,9,11,3,0,10,10,0,1,8,3,10,0,3,3,3,2,10,3,3,8,0,2,9,2,0,2,10,9]

theorem envBound698 : H12AffineFastState.Bounded env698 := by
  intro p hp
  have h : env698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans697_698 : H12AffineEnvironment.transform 1 3 env697 = env698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env697 == env698) = true)

theorem identity698 : scanCanonicalize (H12AffineFastState.compose env698 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound698 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env699 : List Nat := [2,3,1,3,3,3,1,1,0,2,3,0,3,3,0,1,1,3,3,0,3,3,3,2,3,3,3,1,0,2,0,2,0,2,3,0]

theorem envBound699 : H12AffineFastState.Bounded env699 := by
  intro p hp
  have h : env699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans698_699 : H12AffineEnvironment.transform 2 1 env698 = env699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env698 == env699) = true)

def leafEnv699 : List Nat := [2,3,1,3,3,3,1,1,0,2,3,0,3,3,0,1,1,3,3,0,3,3,3,2,1,3,1,3,3,1,0,2,0,2,0,2,2,1,3,0,1,2,0]

def active699 : List Nat := [0]

def tree699 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood699 : H12WitnessSearch.Good tree699 := H12GlobalWitnessIndex.good

theorem leafIdentity699 : H12AffineFastState.composeSystem env699 rootObs = leafEnv699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env699 rootObs == leafEnv699) = true)

theorem terminalChecked699 : H12PackedTerminal.terminalCheckFast leafEnv699 active699 tree699 = true := by decide +kernel

def env700 : List Nat := [2,4,8,16,16,16,8,21,512,31,2048,1,25,2561,0,18,26,522,30,0,2587,16,16,2,25,16,522,26,1,2049,14,17,20,17,11,512]

theorem envBound700 : H12AffineFastState.Bounded env700 := by
  intro p hp
  have h : env700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans682_700 : H12AffineEnvironment.transform 11 1 env682 = env700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env682 == env700) = true)

theorem identity700 : scanCanonicalize (H12AffineFastState.compose env700 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound700 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env701 : List Nat := [2,4,1,16,16,16,1,21,512,22,2048,1,16,2561,0,18,19,515,23,0,2578,16,16,2,16,16,515,19,1,2049,7,17,20,17,2,512]

theorem envBound701 : H12AffineFastState.Bounded env701 := by
  intro p hp
  have h : env701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans700_701 : H12AffineEnvironment.transform 2 1 env700 = env701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env700 == env701) = true)

def env702 : List Nat := [2,4,1,16,16,16,1,21,512,22,16,1,16,529,0,18,19,515,23,0,514,16,16,2,16,16,515,19,1,17,7,17,20,17,2,512]

theorem envBound702 : H12AffineFastState.Bounded env702 := by
  intro p hp
  have h : env702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans701_702 : H12AffineEnvironment.transform 10 16 env701 = env702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env701 == env702) = true)

theorem identity702 : scanCanonicalize (H12AffineFastState.compose env702 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 19) := by decide +kernel

theorem selectedBound702 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env703 : List Nat := [2,4,1,16,16,16,1,21,19,22,16,1,16,2,0,18,19,16,23,0,17,16,16,2,16,16,16,19,1,17,7,17,20,17,2,19]

theorem envBound703 : H12AffineFastState.Bounded env703 := by
  intro p hp
  have h : env703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans702_703 : H12AffineEnvironment.transform 8 19 env702 = env703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 19 env702 == env703) = true)

theorem identity703 : scanCanonicalize (H12AffineFastState.compose env703 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound703 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env704 : List Nat := [2,4,1,4,4,4,1,1,7,2,4,1,4,2,0,6,7,4,3,0,5,4,4,2,4,4,4,7,1,5,7,5,0,5,2,7]

theorem envBound704 : H12AffineFastState.Bounded env704 := by
  intro p hp
  have h : env704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans703_704 : H12AffineEnvironment.transform 3 4 env703 = env704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env703 == env704) = true)

theorem identity704 : scanCanonicalize (H12AffineFastState.compose env704 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound704 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env705 : List Nat := [2,2,1,2,2,2,1,1,1,2,2,1,2,2,0,0,1,2,3,0,3,2,2,2,2,2,2,1,1,3,1,3,0,3,2,1]

theorem envBound705 : H12AffineFastState.Bounded env705 := by
  intro p hp
  have h : env705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans704_705 : H12AffineEnvironment.transform 1 2 env704 = env705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env704 == env705) = true)

def leafEnv705 : List Nat := [2,2,1,2,2,2,1,1,1,2,2,1,2,2,0,0,1,2,3,0,3,2,2,2,0,2,1,2,2,1,1,3,1,3,0,3,3,0,2,1,1,2,0]

def active705 : List Nat := [0]

def tree705 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood705 : H12WitnessSearch.Good tree705 := H12GlobalWitnessIndex.good

theorem leafIdentity705 : H12AffineFastState.composeSystem env705 rootObs = leafEnv705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env705 rootObs == leafEnv705) = true)

theorem terminalChecked705 : H12PackedTerminal.terminalCheckFast leafEnv705 active705 tree705 = true := by decide +kernel

def env706 : List Nat := [2,4,1,16,16,16,1,21,512,22,17,1,16,528,0,18,19,515,23,0,515,16,16,2,16,16,515,19,1,16,7,17,20,17,2,512]

theorem envBound706 : H12AffineFastState.Bounded env706 := by
  intro p hp
  have h : env706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans701_706 : H12AffineEnvironment.transform 10 17 env701 = env706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env701 == env706) = true)

def env707 : List Nat := [2,4,1,16,16,16,1,21,16,22,17,1,16,0,0,18,19,19,23,0,19,16,16,2,16,16,19,19,1,16,7,17,20,17,2,16]

theorem envBound707 : H12AffineFastState.Bounded env707 := by
  intro p hp
  have h : env707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans706_707 : H12AffineEnvironment.transform 8 16 env706 = env707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env706 == env707) = true)

theorem identity707 : scanCanonicalize (H12AffineFastState.compose env707 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound707 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env708 : List Nat := [2,2,1,16,16,16,1,19,16,16,17,1,16,0,0,18,19,19,17,0,19,16,16,2,16,16,19,19,1,16,1,17,18,17,2,16]

theorem envBound708 : H12AffineFastState.Bounded env708 := by
  intro p hp
  have h : env708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans707_708 : H12AffineEnvironment.transform 1 2 env707 = env708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env707 == env708) = true)

def env709 : List Nat := [2,2,1,0,0,0,1,3,0,0,1,1,0,0,0,2,3,3,1,0,3,0,0,2,0,0,3,3,1,0,1,1,2,1,2,0]

theorem envBound709 : H12AffineFastState.Bounded env709 := by
  intro p hp
  have h : env709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans708_709 : H12AffineEnvironment.transform 3 0 env708 = env709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env708 == env709) = true)

theorem identity709 : scanCanonicalize (H12AffineFastState.compose env709 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound709 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env710 : List Nat := [1,1,1,0,0,0,1,0,0,0,1,1,0,0,0,1,0,0,1,0,0,0,0,1,0,0,0,0,1,0,1,1,1,1,1,0]

theorem envBound710 : H12AffineFastState.Bounded env710 := by
  intro p hp
  have h : env710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans709_710 : H12AffineEnvironment.transform 0 1 env709 = env710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env709 == env710) = true)

def leafEnv710 : List Nat := [1,1,1,0,0,0,1,0,0,0,1,1,0,0,0,1,0,0,1,0,0,0,0,1,0,0,1,0,0,0,1,0,1,1,1,1,0,1,1,0,1,0,0]

def active710 : List Nat := []

def tree710 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood710 : H12WitnessSearch.Good tree710 := H12GlobalWitnessIndex.good

theorem leafIdentity710 : H12AffineFastState.composeSystem env710 rootObs = leafEnv710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env710 rootObs == leafEnv710) = true)

theorem terminalChecked710 : H12PackedTerminal.terminalCheckFast leafEnv710 active710 tree710 = true := by decide +kernel

def env711 : List Nat := [2,2,1,1,1,1,1,2,1,1,0,1,1,0,0,3,2,2,0,0,2,1,1,2,1,1,2,2,1,1,1,0,3,0,2,1]

theorem envBound711 : H12AffineFastState.Bounded env711 := by
  intro p hp
  have h : env711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans708_711 : H12AffineEnvironment.transform 3 1 env708 = env711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env708 == env711) = true)

def leafEnv711 : List Nat := [2,2,1,1,1,1,1,2,1,1,0,1,1,0,0,3,2,2,0,0,2,1,1,2,0,1,1,1,2,2,1,1,1,0,3,0,3,3,2,1,1,1,0]

def active711 : List Nat := [0]

def tree711 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood711 : H12WitnessSearch.Good tree711 := H12GlobalWitnessIndex.good

theorem leafIdentity711 : H12AffineFastState.composeSystem env711 rootObs = leafEnv711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env711 rootObs == leafEnv711) = true)

theorem terminalChecked711 : H12PackedTerminal.terminalCheckFast leafEnv711 active711 tree711 = true := by decide +kernel

def env712 : List Nat := [2,4,1,16,16,16,1,21,17,22,17,1,16,1,0,18,19,18,23,0,18,16,16,2,16,16,18,19,1,16,7,17,20,17,2,17]

theorem envBound712 : H12AffineFastState.Bounded env712 := by
  intro p hp
  have h : env712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans706_712 : H12AffineEnvironment.transform 8 17 env706 = env712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env706 == env712) = true)

theorem identity712 : scanCanonicalize (H12AffineFastState.compose env712 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound712 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env713 : List Nat := [2,1,1,16,16,16,1,16,17,19,17,1,16,1,0,18,19,18,18,0,18,16,16,2,16,16,18,19,1,16,2,17,17,17,2,17]

theorem envBound713 : H12AffineFastState.Bounded env713 := by
  intro p hp
  have h : env713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans712_713 : H12AffineEnvironment.transform 1 1 env712 = env713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env712 == env713) = true)

def env714 : List Nat := [2,1,1,0,0,0,1,0,1,3,1,1,0,1,0,2,3,2,2,0,2,0,0,2,0,0,2,3,1,0,2,1,1,1,2,1]

theorem envBound714 : H12AffineFastState.Bounded env714 := by
  intro p hp
  have h : env714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans713_714 : H12AffineEnvironment.transform 3 0 env713 = env714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env713 == env714) = true)

def leafEnv714 : List Nat := [2,1,1,0,0,0,1,0,1,3,1,1,0,1,0,2,3,2,2,0,2,0,0,2,3,0,1,0,2,3,1,0,2,1,1,1,0,2,2,1,1,0,0]

def active714 : List Nat := [0]

def tree714 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

end H12CloudChart1