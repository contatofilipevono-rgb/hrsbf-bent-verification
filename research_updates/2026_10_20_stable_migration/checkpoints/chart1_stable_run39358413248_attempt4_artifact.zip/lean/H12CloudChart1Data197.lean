import H12CloudChart1Data196

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity49901 : scanCanonicalize (H12AffineFastState.compose env49901 (packedSelected [4,9,10,11,12,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound49901 : packedSelected [4,9,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env49902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8323,16400,10401,1024,8661,25797,169,153,3,8328,64,10708,24860,12556,2556,1501,8492,256,8613,25045,648]

theorem envBound49902 : H12AffineFastState.Bounded env49902 := by
  intro p hp
  have h : env49902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49901_49902 : H12AffineEnvironment.transform 14 8660 env49901 = env49902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env49901 == env49902) = true)

theorem identity49902 : scanCanonicalize (H12AffineFastState.compose env49902 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound49902 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env49903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,81,262,16400,2340,1024,80,17728,169,153,3,269,64,2129,16537,4233,2556,1501,169,256,32,16464,648]

theorem envBound49903 : H12AffineFastState.Bounded env49903 := by
  intro p hp
  have h : env49903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49902_49903 : H12AffineEnvironment.transform 12 389 env49902 = env49903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env49902 == env49903) = true)

theorem identity49903 : scanCanonicalize (H12AffineFastState.compose env49903 (packedSelected [0,4,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound49903 : packedSelected [0,4,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5372,81,262,5356,2340,1024,80,4540,169,153,3,269,64,2129,5221,4233,2556,1501,169,256,32,5292,648]

theorem envBound49904 : H12AffineFastState.Bounded env49904 := by
  intro p hp
  have h : env49904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49903_49904 : H12AffineEnvironment.transform 13 5372 env49903 = env49904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env49903 == env49904) = true)

theorem identity49904 : scanCanonicalize (H12AffineFastState.compose env49904 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49904 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env49905 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,241,5372,81,114,5356,2128,1024,80,4296,169,153,3,121,64,2129,5221,4233,2184,1193,169,116,32,5292,648]

theorem envBound49905 : H12AffineFastState.Bounded env49905 := by
  intro p hp
  have h : env49905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49904_49905 : H12AffineEnvironment.transform 7 116 env49904 = env49905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49904 == env49905) = true)

theorem identity49905 : scanCanonicalize (H12AffineFastState.compose env49905 (packedSelected [2,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound49905 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env49906 : List Nat := [2,4,8,16,32,64,128,116,512,1024,1,4096,241,5372,81,114,5356,81,1024,80,4296,169,153,3,121,64,80,5221,4233,137,1193,169,116,32,5292,648]

theorem envBound49906 : H12AffineFastState.Bounded env49906 := by
  intro p hp
  have h : env49906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49905_49906 : H12AffineEnvironment.transform 10 1 env49905 = env49906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env49905 == env49906) = true)

theorem identity49906 : scanCanonicalize (H12AffineFastState.compose env49906 (packedSelected [0,1,2,5,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound49906 : packedSelected [0,1,2,5,7,10] rootPS < 2^1333 := by decide +kernel

def env49907 : List Nat := [2,4,8,16,32,64,88,116,512,1024,1,4096,41,5156,81,114,5172,81,1024,80,4112,113,65,3,121,64,80,5221,4177,81,1137,113,116,32,5236,592]

theorem envBound49907 : H12AffineFastState.Bounded env49907 := by
  intro p hp
  have h : env49907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49906_49907 : H12AffineEnvironment.transform 6 88 env49906 = env49907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env49906 == env49907) = true)

theorem identity49907 : scanCanonicalize (H12AffineFastState.compose env49907 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound49907 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env49908 : List Nat := [2,4,8,16,32,64,88,116,512,1024,1,1141,41,81,81,114,65,81,1024,80,1125,113,65,3,121,64,80,16,1060,81,1137,113,116,32,1,592]

theorem envBound49908 : H12AffineFastState.Bounded env49908 := by
  intro p hp
  have h : env49908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49907_49908 : H12AffineEnvironment.transform 11 1141 env49907 = env49908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env49907 == env49908) = true)

theorem identity49908 : scanCanonicalize (H12AffineFastState.compose env49908 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49908 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env49909 : List Nat := [2,4,8,16,32,64,88,116,512,53,1,64,41,81,81,114,65,81,53,80,80,113,65,3,121,64,80,16,17,81,68,113,116,32,1,592]

theorem envBound49909 : H12AffineFastState.Bounded env49909 := by
  intro p hp
  have h : env49909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49908_49909 : H12AffineEnvironment.transform 9 53 env49908 = env49909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49908 == env49909) = true)

def env49910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound49910 : H12AffineFastState.Bounded env49910 := by
  intro p hp
  have h : env49910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49805_49910 : H12AffineEnvironment.transform 18 1025 env49805 = env49910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env49805 == env49910) = true)

theorem identity49910 : scanCanonicalize (H12AffineFastState.compose env49910 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound49910 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env49911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29630491,18973836,10507600,8724506,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound49911 : H12AffineFastState.Bounded env49911 := by
  intro p hp
  have h : env49911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49910_49911 : H12AffineEnvironment.transform 16 122907 env49910 = env49911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env49910 == env49911) = true)

def env49912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6664599,8393984,10507600,8724506,2102684,12645452,257,21792,46213,2175563]

theorem envBound49912 : H12AffineFastState.Bounded env49912 := by
  intro p hp
  have h : env49912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49911_49912 : H12AffineEnvironment.transform 23 10588556 env49911 = env49912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env49911 == env49912) = true)

def env49913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6664599,2098512,17664,2437194,2102684,6349852,257,21792,46213,2175563]

theorem envBound49913 : H12AffineFastState.Bounded env49913 := by
  intro p hp
  have h : env49913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49912_49913 : H12AffineEnvironment.transform 22 2101328 env49912 = env49913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env49912 == env49913) = true)

def env49914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2201879,2098512,17664,2437194,2102684,2411676,257,21792,46213,2175563]

theorem envBound49914 : H12AffineFastState.Bounded env49914 := by
  intro p hp
  have h : env49914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49913_49914 : H12AffineEnvironment.transform 21 272512 env49913 = env49914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49913 == env49914) = true)

theorem identity49914 : scanCanonicalize (H12AffineFastState.compose env49914 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound49914 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,70862,262144,1025,29908,2097152,272512,2101328,95497,8328,64,2190786,2098512,17664,2437194,2102684,2373705,257,21792,16464,2175563]

theorem envBound49915 : H12AffineFastState.Bounded env49915 := by
  intro p hp
  have h : env49915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49914_49915 : H12AffineEnvironment.transform 14 29909 env49914 = env49915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env49914 == env49915) = true)

def env49916 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,70814,262144,1025,29828,2097152,272512,2101248,95497,8328,16,2190738,2098432,17664,2437146,2102684,2373657,257,21792,16384,2175515]

theorem envBound49916 : H12AffineFastState.Bounded env49916 := by
  intro p hp
  have h : env49916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49915_49916 : H12AffineEnvironment.transform 5 16 env49915 = env49916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49915 == env49916) = true)

theorem identity49916 : scanCanonicalize (H12AffineFastState.compose env49916 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound49916 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env49917 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,70814,76198,1025,29828,2097152,65830,2101248,95497,8328,16,2190738,2098432,17664,2103740,2102684,2167231,257,21792,16384,2175515]

theorem envBound49917 : H12AffineFastState.Bounded env49917 := by
  intro p hp
  have h : env49917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49916_49917 : H12AffineEnvironment.transform 17 76198 env49916 = env49917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env49916 == env49917) = true)

theorem identity49917 : scanCanonicalize (H12AffineFastState.compose env49917 (packedSelected [0,1,3,4,7,10,16,20,22,24,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 12572) := by decide +kernel

theorem selectedBound49917 : packedSelected [0,1,3,4,7,10,16,20,22,24,28,31] rootPS < 2^1333 := by decide +kernel

def env49918 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,70814,76198,1025,29828,12572,65830,8476,95497,8328,16,89230,13340,17664,10400,9344,73891,257,21792,16384,66311]

theorem envBound49918 : H12AffineFastState.Bounded env49918 := by
  intro p hp
  have h : env49918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49917_49918 : H12AffineEnvironment.transform 20 12572 env49917 = env49918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12572 env49917 == env49918) = true)

theorem identity49918 : scanCanonicalize (H12AffineFastState.compose env49918 (packedSelected [1,8,9,10,11,15,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 2201) := by decide +kernel

theorem selectedBound49918 : packedSelected [1,8,9,10,11,15,20,22] rootPS < 2^1333 := by decide +kernel

def env49919 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2201,8192,16384,27676,65536,68615,76198,1025,27677,10629,65830,8476,93584,8328,16,82967,11397,17664,10400,9344,73891,257,19897,16384,66311]

theorem envBound49919 : H12AffineFastState.Bounded env49919 := by
  intro p hp
  have h : env49919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49918_49919 : H12AffineEnvironment.transform 11 2201 env49918 = env49919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2201 env49918 == env49919) = true)

theorem identity49919 : scanCanonicalize (H12AffineFastState.compose env49919 (packedSelected [0,1,2,3,5,6,7,8,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 3101) := by decide +kernel

theorem selectedBound49919 : packedSelected [0,1,2,3,5,6,7,8,15,16,17] rootPS < 2^1333 := by decide +kernel

def env49920 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2201,3101,16384,16385,65536,68615,67003,1025,16384,1432,65830,3329,82317,3221,16,82967,152,17664,1213,2205,68798,257,19897,16384,66311]

theorem envBound49920 : H12AffineFastState.Bounded env49920 := by
  intro p hp
  have h : env49920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49919_49920 : H12AffineEnvironment.transform 12 3101 env49919 = env49920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3101 env49919 == env49920) = true)

theorem identity49920 : scanCanonicalize (H12AffineFastState.compose env49920 (packedSelected [0,4,7,9,10,11,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 1183) := by decide +kernel

theorem selectedBound49920 : packedSelected [0,4,7,9,10,11,16,19] rootPS < 2^1333 := by decide +kernel

def env49921 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2201,3101,16384,16385,1183,2200,292,1025,16384,1432,1465,3329,17682,3221,16,16520,152,17664,1213,2205,2081,257,19897,16384,1944]

theorem envBound49921 : H12AffineFastState.Bounded env49921 := by
  intro p hp
  have h : env49921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49920_49921 : H12AffineEnvironment.transform 15 1183 env49920 = env49921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1183 env49920 == env49921) = true)

theorem identity49921 : scanCanonicalize (H12AffineFastState.compose env49921 (packedSelected [0,1,3,4,5,7,8,9,12,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 2476) := by decide +kernel

theorem selectedBound49921 : packedSelected [0,1,3,4,5,7,8,9,12,18,20] rootPS < 2^1333 := by decide +kernel

def env49922 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2201,3101,2476,2477,1183,2200,292,1025,2476,1432,1465,3329,3262,3221,16,2340,152,3244,1213,2205,2081,257,1045,2476,1944]

theorem envBound49922 : H12AffineFastState.Bounded env49922 := by
  intro p hp
  have h : env49922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49921_49922 : H12AffineEnvironment.transform 13 2476 env49921 = env49922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2476 env49921 == env49922) = true)

theorem identity49922 : scanCanonicalize (H12AffineFastState.compose env49922 (packedSelected [0,2,4,6,7,9,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound49922 : packedSelected [0,2,4,6,7,9,12,14] rootPS < 2^1333 := by decide +kernel

def env49923 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1076,1197,41,1432,1433,1183,1196,292,1025,1432,1432,1465,309,138,161,16,1296,152,152,1213,1193,1045,257,1045,1432,1944]

theorem envBound49923 : H12AffineFastState.Bounded env49923 := by
  intro p hp
  have h : env49923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49922_49923 : H12AffineEnvironment.transform 10 1076 env49922 = env49923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env49922 == env49923) = true)

theorem identity49923 : scanCanonicalize (H12AffineFastState.compose env49923 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound49923 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env49924 : List Nat := [2,4,8,16,32,16,128,256,512,272,292,445,41,136,137,399,444,292,273,136,136,169,309,138,161,16,0,152,152,429,441,261,257,261,136,648]

theorem envBound49924 : H12AffineFastState.Bounded env49924 := by
  intro p hp
  have h : env49924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49923_49924 : H12AffineEnvironment.transform 9 272 env49923 = env49924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env49923 == env49924) = true)

theorem identity49924 : scanCanonicalize (H12AffineFastState.compose env49924 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound49924 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env49925 : List Nat := [2,4,8,16,32,16,128,172,512,188,136,17,41,136,137,35,16,136,189,136,136,169,153,138,161,16,0,152,152,1,21,169,173,169,136,648]

theorem envBound49925 : H12AffineFastState.Bounded env49925 := by
  intro p hp
  have h : env49925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49924_49925 : H12AffineEnvironment.transform 7 172 env49924 = env49925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env49924 == env49925) = true)

theorem identity49925 : scanCanonicalize (H12AffineFastState.compose env49925 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 157) := by decide +kernel

theorem selectedBound49925 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49926 : List Nat := [2,4,8,16,32,16,128,172,157,188,136,17,41,136,137,35,16,136,189,136,136,169,153,138,161,16,0,152,152,1,21,169,173,169,136,21]

theorem envBound49926 : H12AffineFastState.Bounded env49926 := by
  intro p hp
  have h : env49926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49925_49926 : H12AffineEnvironment.transform 8 157 env49925 = env49926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 157 env49925 == env49926) = true)

theorem identity49926 : scanCanonicalize (H12AffineFastState.compose env49926 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound49926 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env49927 : List Nat := [2,4,8,16,16,16,128,156,157,140,136,17,25,136,137,19,16,136,141,136,136,153,153,138,145,16,0,152,152,1,21,153,157,153,136,21]

theorem envBound49927 : H12AffineFastState.Bounded env49927 := by
  intro p hp
  have h : env49927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49926_49927 : H12AffineEnvironment.transform 4 16 env49926 = env49927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env49926 == env49927) = true)

theorem identity49927 : scanCanonicalize (H12AffineFastState.compose env49927 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49927 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49928 : List Nat := [2,4,8,0,0,0,128,140,141,140,136,1,9,136,137,3,0,136,141,136,136,137,137,138,129,0,0,136,136,1,5,137,141,137,136,5]

theorem envBound49928 : H12AffineFastState.Bounded env49928 := by
  intro p hp
  have h : env49928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49927_49928 : H12AffineEnvironment.transform 3 0 env49927 = env49928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49927 == env49928) = true)

theorem identity49928 : scanCanonicalize (H12AffineFastState.compose env49928 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound49928 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49929 : List Nat := [2,1,8,0,0,0,128,137,136,137,136,1,9,136,137,3,0,136,136,136,136,137,137,138,129,0,0,136,136,1,0,137,136,137,136,0]

theorem envBound49929 : H12AffineFastState.Bounded env49929 := by
  intro p hp
  have h : env49929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49928_49929 : H12AffineEnvironment.transform 1 1 env49928 = env49929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env49928 == env49929) = true)

theorem identity49929 : scanCanonicalize (H12AffineFastState.compose env49929 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound49929 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49930 : List Nat := [2,1,8,0,0,0,3,10,11,10,11,1,9,11,10,3,0,11,11,11,11,10,10,9,2,0,0,11,11,1,0,10,11,10,11,0]

theorem envBound49930 : H12AffineFastState.Bounded env49930 := by
  intro p hp
  have h : env49930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49929_49930 : H12AffineEnvironment.transform 6 3 env49929 = env49930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env49929 == env49930) = true)

theorem identity49930 : scanCanonicalize (H12AffineFastState.compose env49930 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound49930 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49931 : List Nat := [2,1,1,0,0,0,3,3,2,3,2,1,0,2,3,3,0,2,2,2,2,3,3,0,2,0,0,2,2,1,0,3,2,3,2,0]

theorem envBound49931 : H12AffineFastState.Bounded env49931 := by
  intro p hp
  have h : env49931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49930_49931 : H12AffineEnvironment.transform 2 1 env49930 = env49931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env49930 == env49931) = true)

theorem identity49931 : scanCanonicalize (H12AffineFastState.compose env49931 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49931 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49932 : List Nat := [0,1,1,0,0,0,1,1,0,1,0,1,0,0,1,1,0,0,0,0,0,1,1,0,0,0,0,0,0,1,0,1,0,1,0,0]

theorem envBound49932 : H12AffineFastState.Bounded env49932 := by
  intro p hp
  have h : env49932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49931_49932 : H12AffineEnvironment.transform 0 0 env49931 = env49932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49931 == env49932) = true)

def env49933 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,70815,262144,1025,29829,2097152,272512,2101249,95497,8328,17,2190739,2098433,17664,2437147,2102684,2373656,257,21792,16385,2175514]

theorem envBound49933 : H12AffineFastState.Bounded env49933 := by
  intro p hp
  have h : env49933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49915_49933 : H12AffineEnvironment.transform 5 17 env49915 = env49933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49915 == env49933) = true)

theorem identity49933 : scanCanonicalize (H12AffineFastState.compose env49933 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2477) := by decide +kernel

theorem selectedBound49933 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env49934 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,70815,2477,1025,29829,2097152,8493,2101249,95497,8328,17,2190739,2098433,17664,2177462,2102684,2109877,257,21792,16385,2175514]

theorem envBound49934 : H12AffineFastState.Bounded env49934 := by
  intro p hp
  have h : env49934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49933_49934 : H12AffineEnvironment.transform 17 2477 env49933 = env49934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2477 env49933 == env49934) = true)

theorem identity49934 : scanCanonicalize (H12AffineFastState.compose env49934 (packedSelected [1,10,11,17,26,28,32] rootPS)) = affineNative (2^(20+1) ^^^ 17816) := by decide +kernel

theorem selectedBound49934 : packedSelected [1,10,11,17,26,28,32] rootPS < 2^1333 := by decide +kernel

def env49935 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,70815,2477,1025,29829,17816,8493,21913,95497,8328,17,75787,16537,17664,97326,20484,29741,257,21792,16385,96130]

theorem envBound49935 : H12AffineFastState.Bounded env49935 := by
  intro p hp
  have h : env49935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49934_49935 : H12AffineEnvironment.transform 20 17816 env49934 = env49935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17816 env49934 == env49935) = true)

theorem identity49935 : scanCanonicalize (H12AffineFastState.compose env49935 (packedSelected [0,3,4,7,10,19,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound49935 : packedSelected [0,3,4,7,10,19,22,24] rootPS < 2^1333 := by decide +kernel

def env49936 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,30083,24860,2477,1025,29829,17816,8493,21913,138,8328,17,23944,16537,17664,2477,20484,29741,257,21792,16385,513]

theorem envBound49936 : H12AffineFastState.Bounded env49936 := by
  intro p hp
  have h : env49936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49935_49936 : H12AffineEnvironment.transform 15 30083 env49935 = env49936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env49935 == env49936) = true)

theorem identity49936 : scanCanonicalize (H12AffineFastState.compose env49936 (packedSelected [2,4,6,9,14,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49936 : packedSelected [2,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env49937 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,29963,24860,2341,1025,29709,17680,8493,21777,2,8192,17,23808,16401,17664,2341,20484,29741,257,21792,16385,513]

theorem envBound49937 : H12AffineFastState.Bounded env49937 := by
  intro p hp
  have h : env49937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49936_49937 : H12AffineEnvironment.transform 6 8 env49936 = env49937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49936 == env49937) = true)

theorem identity49937 : scanCanonicalize (H12AffineFastState.compose env49937 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound49937 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49938 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,21760,21511,16400,2341,1025,21761,17680,33,21777,2,268,17,23808,16401,17664,2341,20484,21793,257,21792,16385,513]

theorem envBound49938 : H12AffineFastState.Bounded env49938 := by
  intro p hp
  have h : env49938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49937_49938 : H12AffineEnvironment.transform 12 268 env49937 = env49938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env49937 == env49938) = true)

theorem identity49938 : scanCanonicalize (H12AffineFastState.compose env49938 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound49938 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env49939 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,263,5392,2341,1025,1,4112,33,17,2,268,17,2048,5393,4096,2341,1284,33,257,32,5377,513]

theorem envBound49939 : H12AffineFastState.Bounded env49939 := by
  intro p hp
  have h : env49939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49938_49939 : H12AffineEnvironment.transform 13 5376 env49938 = env49939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49938 == env49939) = true)

theorem identity49939 : scanCanonicalize (H12AffineFastState.compose env49939 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49939 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49940 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5156,0,35,5172,2049,1025,1,4112,33,17,2,40,17,2048,5173,4096,2049,1056,33,37,32,5157,513]

theorem envBound49940 : H12AffineFastState.Bounded env49940 := by
  intro p hp
  have h : env49940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49939_49940 : H12AffineEnvironment.transform 7 36 env49939 = env49940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49939 == env49940) = true)

theorem identity49940 : scanCanonicalize (H12AffineFastState.compose env49940 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound49940 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49941 : List Nat := [2,4,8,16,32,17,8,36,512,1024,523,4096,40,5156,0,35,5172,522,1025,1,4112,33,17,2,40,17,523,5173,4096,522,1056,33,37,32,5157,513]

theorem envBound49941 : H12AffineFastState.Bounded env49941 := by
  intro p hp
  have h : env49941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49940_49941 : H12AffineEnvironment.transform 10 523 env49940 = env49941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env49940 == env49941) = true)

theorem identity49941 : scanCanonicalize (H12AffineFastState.compose env49941 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49941 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49942 : List Nat := [2,4,8,16,0,17,8,4,512,1024,523,4096,8,5124,0,3,5140,522,1025,1,4112,1,17,2,8,17,523,5141,4096,522,1024,1,5,0,5125,513]

theorem envBound49942 : H12AffineFastState.Bounded env49942 := by
  intro p hp
  have h : env49942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49941_49942 : H12AffineEnvironment.transform 4 0 env49941 = env49942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49941 == env49942) = true)

def env49943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2201878,2098512,17664,2437194,2102684,2411677,257,21792,46213,2175563]

theorem envBound49943 : H12AffineFastState.Bounded env49943 := by
  intro p hp
  have h : env49943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49913_49943 : H12AffineEnvironment.transform 21 272513 env49913 = env49943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49913 == env49943) = true)

theorem identity49943 : scanCanonicalize (H12AffineFastState.compose env49943 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound49943 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,58516,272513,62660,98780,8328,64,97666,57796,17664,382174,61704,272393,257,21792,46213,120543]

theorem envBound49944 : H12AffineFastState.Bounded env49944 := by
  intro p hp
  have h : env49944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49943_49944 : H12AffineEnvironment.transform 20 58516 env49943 = env49944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env49943 == env49944) = true)

def env49945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10280,1025,32769,58516,169,62660,98780,8328,64,97666,57796,17664,130294,61704,33,257,21792,46213,120543]

theorem envBound49945 : H12AffineFastState.Bounded env49945 := by
  intro p hp
  have h : env49945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49944_49945 : H12AffineEnvironment.transform 17 10280 env49944 = env49945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env49944 == env49945) = true)

theorem identity49945 : scanCanonicalize (H12AffineFastState.compose env49945 (packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound49945 : packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS < 2^1333 := by decide +kernel

def env49946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1100,16384,32768,65536,115799,3172,1025,32769,49368,169,53384,98780,1220,64,88526,50568,17664,121018,54596,33,257,21792,37065,120543]

theorem envBound49946 : H12AffineFastState.Bounded env49946 := by
  intro p hp
  have h : env49946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49945_49946 : H12AffineEnvironment.transform 12 1100 env49945 = env49946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env49945 == env49946) = true)

theorem identity49946 : scanCanonicalize (H12AffineFastState.compose env49946 (packedSelected [1,3,8,15,16,19,20,24,26,31,38] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound49946 : packedSelected [1,3,8,15,16,19,20,24,26,31,38] rootPS < 2^1333 := by decide +kernel

def env49947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1100,16384,32768,20759,38208,3172,1025,32769,49368,169,53384,53451,1220,64,2265,50568,17664,35245,54596,33,257,21792,37065,34760]

theorem envBound49947 : H12AffineFastState.Bounded env49947 := by
  intro p hp
  have h : env49947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49946_49947 : H12AffineEnvironment.transform 15 20759 env49946 = env49947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env49946 == env49947) = true)

theorem identity49947 : scanCanonicalize (H12AffineFastState.compose env49947 (packedSelected [0,1,4,5,7,8,11,17,18,19,22,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound49947 : packedSelected [0,1,4,5,7,8,11,17,18,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env49948 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,161,16384,32768,20759,37293,2185,236,32769,49368,169,53384,53451,41,64,2265,49509,16877,35245,53673,33,257,20941,37065,33573]

theorem envBound49948 : H12AffineFastState.Bounded env49948 := by
  intro p hp
  have h : env49948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49947_49948 : H12AffineEnvironment.transform 9 237 env49947 = env49948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env49947 == env49948) = true)

theorem identity49948 : scanCanonicalize (H12AffineFastState.compose env49948 (packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound49948 : packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env49949 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,161,16384,216,20759,4469,2185,236,217,16384,169,20560,20499,41,64,2265,16829,16877,2421,20849,33,257,20941,4113,1021]

theorem envBound49949 : H12AffineFastState.Bounded env49949 := by
  intro p hp
  have h : env49949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49948_49949 : H12AffineEnvironment.transform 14 216 env49948 = env49949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env49948 == env49949) = true)

theorem identity49949 : scanCanonicalize (H12AffineFastState.compose env49949 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49949 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env49950 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,41,16384,80,20759,4469,2049,100,81,16384,33,20560,20499,41,64,2129,16693,16741,2421,20849,33,257,20805,4113,885]

theorem envBound49950 : H12AffineFastState.Bounded env49950 := by
  intro p hp
  have h : env49950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49949_49950 : H12AffineEnvironment.transform 6 8 env49949 = env49950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49949 == env49950) = true)

theorem identity49950 : scanCanonicalize (H12AffineFastState.compose env49950 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49950 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49951 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,41,16384,0,20759,4389,2049,52,1,16384,33,20480,20499,41,16,2049,16693,16693,2341,20769,33,257,20757,4113,805]

theorem envBound49951 : H12AffineFastState.Bounded env49951 := by
  intro p hp
  have h : env49951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49950_49951 : H12AffineEnvironment.transform 5 16 env49950 = env49951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49950 == env49951) = true)

theorem identity49951 : scanCanonicalize (H12AffineFastState.compose env49951 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound49951 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49952 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,41,4112,0,263,4389,2049,52,1,4112,33,16,3,41,16,2049,4389,4389,2341,305,33,257,261,4113,805]

theorem envBound49952 : H12AffineFastState.Bounded env49952 := by
  intro p hp
  have h : env49952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49951_49952 : H12AffineEnvironment.transform 13 4112 env49951 = env49952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env49951 == env49952) = true)

def env49953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1025,32769,58516,168,62660,98780,8328,64,97666,57796,17664,130295,61704,32,257,21792,46213,120543]

theorem envBound49953 : H12AffineFastState.Bounded env49953 := by
  intro p hp
  have h : env49953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49944_49953 : H12AffineEnvironment.transform 17 10281 env49944 = env49953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env49944 == env49953) = true)

theorem identity49953 : scanCanonicalize (H12AffineFastState.compose env49953 (packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS)) = affineNative (2^(15+1) ^^^ 62851) := by decide +kernel

theorem selectedBound49953 : packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS < 2^1333 := by decide +kernel

def env49954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62851,5528,10281,1025,32769,58516,168,62660,29791,8328,64,34817,57796,17664,2420,61704,32,257,21792,46213,9052]

theorem envBound49954 : H12AffineFastState.Bounded env49954 := by
  intro p hp
  have h : env49954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49953_49954 : H12AffineEnvironment.transform 15 62851 env49953 = env49954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62851 env49953 == env49954) = true)

theorem identity49954 : scanCanonicalize (H12AffineFastState.compose env49954 (packedSelected [0,1,3,4,7,8,10,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound49954 : packedSelected [0,1,3,4,7,8,10,22,24] rootPS < 2^1333 := by decide +kernel

def env49955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,54358,5528,2556,1025,32769,50497,168,54545,21898,349,64,34817,49169,17664,2420,53469,32,257,21792,38224,649]

theorem envBound49955 : H12AffineFastState.Bounded env49955 := by
  intro p hp
  have h : env49955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49954_49955 : H12AffineEnvironment.transform 12 469 env49954 = env49955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env49954 == env49955) = true)

theorem identity49955 : scanCanonicalize (H12AffineFastState.compose env49955 (packedSelected [0,1,2,6,7,8,10,12,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound49955 : packedSelected [0,1,2,6,7,8,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env49956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,32768,33111,5528,2556,1025,32769,36928,168,32784,139,349,64,34817,38160,4097,2420,34268,32,257,33,38224,649]

theorem envBound49956 : H12AffineFastState.Bounded env49956 := by
  intro p hp
  have h : env49956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49955_49956 : H12AffineEnvironment.transform 13 5377 env49955 = env49956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49955 == env49956) = true)

theorem identity49956 : scanCanonicalize (H12AffineFastState.compose env49956 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49956 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,33111,5393,2421,1025,32769,36928,33,32784,2,349,64,34817,38160,4097,2420,34133,32,257,33,38224,512]

theorem envBound49957 : H12AffineFastState.Bounded env49957 := by
  intro p hp
  have h : env49957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49956_49957 : H12AffineEnvironment.transform 6 9 env49956 = env49957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49956 == env49957) = true)

theorem identity49957 : scanCanonicalize (H12AffineFastState.compose env49957 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound49957 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49958 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32,375,5393,2421,1025,33,4192,33,48,2,349,64,2081,5424,4097,2420,1397,32,257,33,5488,512]

theorem envBound49958 : H12AffineFastState.Bounded env49958 := by
  intro p hp
  have h : env49958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49957_49958 : H12AffineEnvironment.transform 14 32 env49957 = env49958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env49957 == env49958) = true)

def env49959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6664599,2098513,17665,2437195,2102684,6349853,257,21792,46213,2175563]

theorem envBound49959 : H12AffineFastState.Bounded env49959 := by
  intro p hp
  have h : env49959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49912_49959 : H12AffineEnvironment.transform 22 2101329 env49912 = env49959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env49912 == env49959) = true)

def env49960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2201879,2098513,17665,2437195,2102684,2411677,257,21792,46213,2175563]

theorem envBound49960 : H12AffineFastState.Bounded env49960 := by
  intro p hp
  have h : env49960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49959_49960 : H12AffineEnvironment.transform 21 272512 env49959 = env49960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49959 == env49960) = true)

def env49961 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272392,2101329,98645,8192,64,2201879,2098513,17665,2437195,2102548,2411541,257,21792,46093,2175563]

theorem envBound49961 : H12AffineFastState.Bounded env49961 := by
  intro p hp
  have h : env49961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49960_49961 : H12AffineEnvironment.transform 6 8 env49960 = env49961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49960 == env49961) = true)

def env49962 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4160,272392,17,98645,8192,64,100695,5393,17665,335883,1364,318549,257,21792,46093,74251]

theorem envBound49962 : H12AffineFastState.Bounded env49962 := by
  intro p hp
  have h : env49962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49961_49962 : H12AffineEnvironment.transform 20 4160 env49961 = env49962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49961 == env49962) = true)

theorem identity49962 : scanCanonicalize (H12AffineFastState.compose env49962 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound49962 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49963 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1025,32769,4160,33,17,98645,8192,64,100695,5393,17665,67618,1364,62588,257,21792,46093,74251]

theorem envBound49963 : H12AffineFastState.Bounded env49963 := by
  intro p hp
  have h : env49963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49962_49963 : H12AffineEnvironment.transform 17 10281 env49962 = env49963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env49962 == env49963) = true)

theorem identity49963 : scanCanonicalize (H12AffineFastState.compose env49963 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound49963 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env49964 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,90138,10281,1025,0,4160,33,17,65876,8192,64,67926,5393,17665,67618,1364,29821,257,21792,13324,74251]

theorem envBound49964 : H12AffineFastState.Bounded env49964 := by
  intro p hp
  have h : env49964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49963_49964 : H12AffineEnvironment.transform 14 1 env49963 = env49964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env49963 == env49964) = true)

theorem identity49964 : scanCanonicalize (H12AffineFastState.compose env49964 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49964 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env49965 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8202,16400,10281,1025,0,4160,33,17,8542,8192,64,10588,5393,17665,10280,1364,29821,257,21792,13324,513]

theorem envBound49965 : H12AffineFastState.Bounded env49965 := by
  intro p hp
  have h : env49965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49964_49965 : H12AffineEnvironment.transform 15 8202 env49964 = env49965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49964 == env49965) = true)

theorem identity49965 : scanCanonicalize (H12AffineFastState.compose env49965 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49965 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env49966 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,343,16400,2420,1025,0,4160,33,17,3,349,64,2049,5393,17665,2421,1364,21792,257,21792,5457,513]

theorem envBound49966 : H12AffineFastState.Bounded env49966 := by
  intro p hp
  have h : env49966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49965_49966 : H12AffineEnvironment.transform 12 349 env49965 = env49966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49965 == env49966) = true)

theorem identity49966 : scanCanonicalize (H12AffineFastState.compose env49966 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound49966 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49967 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4112,1,343,4096,2420,1025,0,4160,33,17,3,349,64,2049,5393,5393,2421,1364,1328,257,1328,5457,513]

theorem envBound49967 : H12AffineFastState.Bounded env49967 := by
  intro p hp
  have h : env49967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49966_49967 : H12AffineEnvironment.transform 13 4112 env49966 = env49967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env49966 == env49967) = true)

theorem identity49967 : scanCanonicalize (H12AffineFastState.compose env49967 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound49967 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env49968 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,8,4112,1,2,4096,2081,1025,0,4160,33,17,3,8,64,2049,5188,5188,2080,1025,1125,84,1125,5124,513]

theorem envBound49968 : H12AffineFastState.Bounded env49968 := by
  intro p hp
  have h : env49968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49967_49968 : H12AffineEnvironment.transform 7 85 env49967 = env49968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env49967 == env49968) = true)

theorem identity49968 : scanCanonicalize (H12AffineFastState.compose env49968 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49968 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env49969 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,8,4112,1,2,4096,2081,1025,0,4113,33,17,3,8,17,2049,5141,5141,2080,1025,1076,5,1076,5124,513]

theorem envBound49969 : H12AffineFastState.Bounded env49969 := by
  intro p hp
  have h : env49969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49968_49969 : H12AffineEnvironment.transform 5 17 env49968 = env49969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49968 == env49969) = true)

theorem identity49969 : scanCanonicalize (H12AffineFastState.compose env49969 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound49969 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49970 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,1061,8,1077,1,2,1061,2081,1025,0,1076,33,17,3,8,17,2049,48,48,2080,1025,1076,5,1076,33,513]

theorem envBound49970 : H12AffineFastState.Bounded env49970 := by
  intro p hp
  have h : env49970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49969_49970 : H12AffineEnvironment.transform 11 1061 env49969 = env49970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env49969 == env49970) = true)

theorem identity49970 : scanCanonicalize (H12AffineFastState.compose env49970 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound49970 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env49971 : List Nat := [2,4,8,16,32,17,8,4,512,1024,544,1061,8,1077,1,2,1061,513,1025,0,1076,33,17,3,8,17,545,48,48,512,1025,1076,5,1076,33,513]

theorem envBound49971 : H12AffineFastState.Bounded env49971 := by
  intro p hp
  have h : env49971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49970_49971 : H12AffineEnvironment.transform 10 544 env49970 = env49971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env49970 == env49971) = true)

theorem identity49971 : scanCanonicalize (H12AffineFastState.compose env49971 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound49971 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env49972 : List Nat := [2,4,8,16,32,17,8,4,512,564,544,529,8,513,1,2,529,513,565,0,512,33,17,3,8,17,545,48,48,512,565,512,5,512,33,513]

theorem envBound49972 : H12AffineFastState.Bounded env49972 := by
  intro p hp
  have h : env49972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49971_49972 : H12AffineEnvironment.transform 9 564 env49971 = env49972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env49971 == env49972) = true)

theorem identity49972 : scanCanonicalize (H12AffineFastState.compose env49972 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound49972 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49973 : List Nat := [2,4,8,16,16,17,8,4,512,516,528,529,8,513,1,2,529,513,517,0,512,17,17,3,8,17,529,0,0,512,517,512,5,512,17,513]

theorem envBound49973 : H12AffineFastState.Bounded env49973 := by
  intro p hp
  have h : env49973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49972_49973 : H12AffineEnvironment.transform 4 16 env49972 = env49973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env49972 == env49973) = true)

def env49974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4161,272392,16,98645,8192,64,100694,5392,17665,335882,1365,318548,257,21792,46093,74250]

theorem envBound49974 : H12AffineFastState.Bounded env49974 := by
  intro p hp
  have h : env49974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49961_49974 : H12AffineEnvironment.transform 20 4161 env49961 = env49974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49961 == env49974) = true)

theorem identity49974 : scanCanonicalize (H12AffineFastState.compose env49974 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 130094) := by decide +kernel

theorem selectedBound49974 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env49975 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,130094,1025,32769,4161,119846,16,98645,8192,64,100694,5392,17665,56356,1365,73850,257,21792,46093,74250]

theorem envBound49975 : H12AffineFastState.Bounded env49975 := by
  intro p hp
  have h : env49975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49974_49975 : H12AffineEnvironment.transform 17 130094 env49974 = env49975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130094 env49974 == env49975) = true)

theorem identity49975 : scanCanonicalize (H12AffineFastState.compose env49975 (packedSelected [0,3,9,10,18,22,23,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound49975 : packedSelected [0,3,9,10,18,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env49976 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,65536,103447,100386,1025,32769,4161,106538,16,98645,8192,64,100694,5392,12557,43048,1365,73850,257,8492,46093,74250]

theorem envBound49976 : H12AffineFastState.Bounded env49976 := by
  intro p hp
  have h : env49976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49975_49976 : H12AffineEnvironment.transform 13 13324 env49975 = env49976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env49975 == env49976) = true)

theorem identity49976 : scanCanonicalize (H12AffineFastState.compose env49976 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49976 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env49977 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,8203,46108,43049,1025,32769,4161,32801,16,41310,8192,64,43357,5392,12557,43048,1365,113,257,8492,46093,513]

theorem envBound49977 : H12AffineFastState.Bounded env49977 := by
  intro p hp
  have h : env49977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49976_49977 : H12AffineEnvironment.transform 15 8203 env49976 = env49977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49976 == env49977) = true)

theorem identity49977 : scanCanonicalize (H12AffineFastState.compose env49977 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49977 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49978 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,32768,342,38209,35188,1025,32769,4161,32801,16,32771,349,64,34816,5392,4176,35189,1365,113,257,113,38224,513]

theorem envBound49978 : H12AffineFastState.Bounded env49978 := by
  intro p hp
  have h : env49978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49977_49978 : H12AffineEnvironment.transform 12 349 env49977 = env49978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49977 == env49978) = true)

theorem identity49978 : scanCanonicalize (H12AffineFastState.compose env49978 (packedSelected [0,2,3,4,5,7,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 3125) := by decide +kernel

theorem selectedBound49978 : packedSelected [0,2,3,4,5,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env49979 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,3125,342,6516,1345,1025,3124,4161,3092,16,3126,349,64,1077,5392,4176,1344,1365,113,257,113,6501,513]

theorem envBound49979 : H12AffineFastState.Bounded env49979 := by
  intro p hp
  have h : env49979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49978_49979 : H12AffineEnvironment.transform 14 3125 env49978 = env49979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3125 env49978 == env49979) = true)

theorem identity49979 : scanCanonicalize (H12AffineFastState.compose env49979 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound49979 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env49980 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,349,5457,292,342,5221,1345,1025,293,4161,261,16,295,349,64,1077,5392,4176,1344,1365,113,257,113,5236,513]

theorem envBound49980 : H12AffineFastState.Bounded env49980 := by
  intro p hp
  have h : env49980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49979_49980 : H12AffineEnvironment.transform 10 1297 env49979 = env49980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env49979 == env49980) = true)

theorem identity49980 : scanCanonicalize (H12AffineFastState.compose env49980 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49980 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env49981 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1125,4096,41,5157,80,34,5221,1077,1025,81,4161,113,16,83,41,64,1077,5220,4176,1076,1057,113,117,113,5236,513]

theorem envBound49981 : H12AffineFastState.Bounded env49981 := by
  intro p hp
  have h : env49981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49980_49981 : H12AffineEnvironment.transform 7 116 env49980 = env49981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49980 == env49981) = true)

theorem identity49981 : scanCanonicalize (H12AffineFastState.compose env49981 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49981 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49982 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1076,4096,41,5157,1,34,5172,1077,1025,0,4112,32,16,2,41,17,1077,5173,4097,1076,1057,32,36,32,5157,513]

theorem envBound49982 : H12AffineFastState.Bounded env49982 := by
  intro p hp
  have h : env49982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49981_49982 : H12AffineEnvironment.transform 5 17 env49981 = env49982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49981 == env49982) = true)

def env49983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272393,2101329,98644,8193,64,2201879,2098513,17665,2437195,2102549,2411540,257,21792,46092,2175563]

theorem envBound49983 : H12AffineFastState.Bounded env49983 := by
  intro p hp
  have h : env49983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49960_49983 : H12AffineEnvironment.transform 6 9 env49960 = env49983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49960 == env49983) = true)

theorem identity49983 : scanCanonicalize (H12AffineFastState.compose env49983 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 36928) := by decide +kernel

theorem selectedBound49983 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env49984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,36928,272393,32785,98644,8193,64,67927,38161,17665,368651,34133,285780,257,21792,46092,107019]

theorem envBound49984 : H12AffineFastState.Bounded env49984 := by
  intro p hp
  have h : env49984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49983_49984 : H12AffineEnvironment.transform 20 36928 env49983 = env49984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 36928 env49983 == env49984) = true)

theorem identity49984 : scanCanonicalize (H12AffineFastState.compose env49984 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound49984 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env49985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,57677,262144,1025,32769,36928,272393,32785,32770,8193,64,2049,38161,17665,303453,34133,285780,257,21792,46092,41821]

theorem envBound49985 : H12AffineFastState.Bounded env49985 := by
  intro p hp
  have h : env49985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49984_49985 : H12AffineEnvironment.transform 15 342 env49984 = env49985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env49984 == env49985) = true)

theorem identity49985 : scanCanonicalize (H12AffineFastState.compose env49985 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound49985 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env49986 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,57677,43049,1025,32769,36928,32800,32785,32770,8193,64,2049,38161,17665,2420,34133,62589,257,21792,46092,41821]

theorem envBound49986 : H12AffineFastState.Bounded env49986 := by
  intro p hp
  have h : env49986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49985_49986 : H12AffineEnvironment.transform 17 43049 env49985 = env49986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env49985 == env49986) = true)

theorem identity49986 : scanCanonicalize (H12AffineFastState.compose env49986 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49986 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49987 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,342,49168,35188,1025,32769,36928,32800,32785,32770,348,64,2049,38161,17665,2420,34133,54560,257,21792,38225,33280]

theorem envBound49987 : H12AffineFastState.Bounded env49987 := by
  intro p hp
  have h : env49987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49986_49987 : H12AffineEnvironment.transform 12 349 env49986 = env49987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49986 == env49987) = true)

theorem identity49987 : scanCanonicalize (H12AffineFastState.compose env49987 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound49987 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env49988 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,293,342,16693,2129,1025,292,4453,261,308,295,348,64,2049,5172,17665,2420,1136,21509,257,21792,5236,805]

theorem envBound49988 : H12AffineFastState.Bounded env49988 := by
  intro p hp
  have h : env49988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49987_49988 : H12AffineEnvironment.transform 14 293 env49987 = env49988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env49987 == env49988) = true)

theorem identity49988 : scanCanonicalize (H12AffineFastState.compose env49988 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49988 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env49989 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,16384,1,114,16401,2129,1025,0,4161,33,16,3,120,64,2049,5172,17445,2128,1136,21509,37,21508,5236,513]

theorem envBound49989 : H12AffineFastState.Bounded env49989 := by
  intro p hp
  have h : env49989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49988_49989 : H12AffineEnvironment.transform 7 36 env49988 = env49989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49988 == env49989) = true)

theorem identity49989 : scanCanonicalize (H12AffineFastState.compose env49989 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound49989 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49990 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,5236,1,114,5221,2129,1025,0,4161,33,16,3,120,64,2049,5172,4177,2128,1136,113,37,112,5236,513]

theorem envBound49990 : H12AffineFastState.Bounded env49990 := by
  intro p hp
  have h : env49990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49989_49990 : H12AffineEnvironment.transform 13 5236 env49989 = env49990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env49989 == env49990) = true)

theorem identity49990 : scanCanonicalize (H12AffineFastState.compose env49990 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49990 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49991 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,1,34,5173,2049,1025,0,4113,33,16,3,40,16,2049,5172,4097,2048,1056,33,37,32,5156,513]

theorem envBound49991 : H12AffineFastState.Bounded env49991 := by
  intro p hp
  have h : env49991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49990_49991 : H12AffineEnvironment.transform 5 16 env49990 = env49991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49990 == env49991) = true)

theorem identity49991 : scanCanonicalize (H12AffineFastState.compose env49991 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound49991 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49992 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1077,4096,41,5156,1,34,5173,1076,1025,0,4113,33,16,3,40,16,1076,5172,4097,1077,1056,33,37,32,5156,513]

theorem envBound49992 : H12AffineFastState.Bounded env49992 := by
  intro p hp
  have h : env49992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49991_49992 : H12AffineEnvironment.transform 10 1077 env49991 = env49992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env49991 == env49992) = true)

theorem identity49992 : scanCanonicalize (H12AffineFastState.compose env49992 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound49992 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49993 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1077,1061,41,1,1,34,16,1076,1025,0,1076,33,16,3,40,16,1076,17,1060,1077,1056,33,37,32,1,513]

theorem envBound49993 : H12AffineFastState.Bounded env49993 := by
  intro p hp
  have h : env49993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49992_49993 : H12AffineEnvironment.transform 11 1061 env49992 = env49993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env49992 == env49993) = true)

theorem identity49993 : scanCanonicalize (H12AffineFastState.compose env49993 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49993 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env49994 : List Nat := [2,4,8,16,32,16,9,36,512,53,0,16,41,1,1,34,16,1,52,0,1,33,16,3,40,16,1,17,17,0,21,33,37,32,1,513]

theorem envBound49994 : H12AffineFastState.Bounded env49994 := by
  intro p hp
  have h : env49994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49993_49994 : H12AffineEnvironment.transform 9 53 env49993 = env49994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49993 == env49994) = true)

theorem identity49994 : scanCanonicalize (H12AffineFastState.compose env49994 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound49994 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49995 : List Nat := [2,4,8,16,32,16,9,36,17,53,0,16,41,1,1,34,16,1,52,0,1,33,16,3,40,16,1,17,17,0,21,33,37,32,1,16]

theorem envBound49995 : H12AffineFastState.Bounded env49995 := by
  intro p hp
  have h : env49995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49994_49995 : H12AffineEnvironment.transform 8 17 env49994 = env49995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env49994 == env49995) = true)

theorem identity49995 : scanCanonicalize (H12AffineFastState.compose env49995 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound49995 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49996 : List Nat := [2,4,8,16,27,16,9,31,17,14,0,16,18,1,1,25,16,1,15,0,1,26,16,3,19,16,1,17,17,0,21,26,30,27,1,16]

theorem envBound49996 : H12AffineFastState.Bounded env49996 := by
  intro p hp
  have h : env49996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49995_49996 : H12AffineEnvironment.transform 4 27 env49995 = env49996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env49995 == env49996) = true)

def env49997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2201878,2098513,17665,2437195,2102684,2411676,257,21792,46213,2175563]

theorem envBound49997 : H12AffineFastState.Bounded env49997 := by
  intro p hp
  have h : env49997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49959_49997 : H12AffineEnvironment.transform 21 272513 env49959 = env49997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49959 == env49997) = true)

theorem identity49997 : scanCanonicalize (H12AffineFastState.compose env49997 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound49997 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4160,272513,17,98781,8328,64,100694,5393,17665,335883,1500,318684,257,21792,46213,74251]

theorem envBound49998 : H12AffineFastState.Bounded env49998 := by
  intro p hp
  have h : env49998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49997_49998 : H12AffineEnvironment.transform 20 4160 env49997 = env49998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49997 == env49998) = true)

theorem identity49998 : scanCanonicalize (H12AffineFastState.compose env49998 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49998 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env49999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,4160,272513,17,41431,8328,64,43356,5393,17665,262145,1500,318684,257,21792,46213,513]

theorem envBound49999 : H12AffineFastState.Bounded env49999 := by
  intro p hp
  have h : env49999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49998_49999 : H12AffineEnvironment.transform 15 8202 env49998 = env49999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49998 == env49999) = true)

theorem identity49999 : scanCanonicalize (H12AffineFastState.compose env49999 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound49999 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env50000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10400,1025,32769,4160,33,17,41431,8328,64,43356,5393,17665,10401,1500,62588,257,21792,46213,513]

theorem envBound50000 : H12AffineFastState.Bounded env50000 := by
  intro p hp
  have h : env50000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49999_50000 : H12AffineEnvironment.transform 17 10400 env49999 = env50000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env49999 == env50000) = true)

theorem identity50000 : scanCanonicalize (H12AffineFastState.compose env50000 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound50000 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env50001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8202,16400,10400,1025,0,4160,33,17,8662,8328,64,10589,5393,17665,10401,1500,29821,257,21792,13444,513]

theorem envBound50001 : H12AffineFastState.Bounded env50001 := by
  intro p hp
  have h : env50001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50000_50001 : H12AffineEnvironment.transform 14 1 env50000 = env50001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env50000 == env50001) = true)

theorem identity50001 : scanCanonicalize (H12AffineFastState.compose env50001 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(12+1) ^^^ 1220) := by decide +kernel

theorem selectedBound50001 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env50002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1220,16384,1,1230,16400,3172,1025,0,4160,33,17,1298,1100,64,3481,5393,17665,3173,1500,20665,257,21792,4160,513]

theorem envBound50002 : H12AffineFastState.Bounded env50002 := by
  intro p hp
  have h : env50002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50001_50002 : H12AffineEnvironment.transform 12 1220 env50001 = env50002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env50001 == env50002) = true)

theorem identity50002 : scanCanonicalize (H12AffineFastState.compose env50002 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound50002 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env50003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1220,1212,1,1230,1196,3172,1025,0,4160,33,17,1298,1100,64,3481,5393,445,3173,1500,5125,257,4508,4160,513]

theorem envBound50003 : H12AffineFastState.Bounded env50003 := by
  intro p hp
  have h : env50003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50002_50003 : H12AffineEnvironment.transform 13 1212 env50002 = env50003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env50002 == env50003) = true)

theorem identity50003 : scanCanonicalize (H12AffineFastState.compose env50003 (packedSelected [0,1,3,4,5,8,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound50003 : packedSelected [0,1,3,4,5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env50004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,64,1220,1212,1,1230,1196,3172,1025,0,0,33,17,1298,1100,64,3481,1361,445,3173,1500,1093,257,476,0,513]

theorem envBound50004 : H12AffineFastState.Bounded env50004 := by
  intro p hp
  have h : env50004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50003_50004 : H12AffineEnvironment.transform 11 64 env50003 = env50004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env50003 == env50004) = true)

theorem identity50004 : scanCanonicalize (H12AffineFastState.compose env50004 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound50004 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env50005 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,64,388,508,1,398,492,2340,321,0,0,33,17,82,268,64,2265,17,445,2341,156,261,257,476,0,513]

theorem envBound50005 : H12AffineFastState.Bounded env50005 := by
  intro p hp
  have h : env50005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50004_50005 : H12AffineEnvironment.transform 9 320 env50004 = env50005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50004 == env50005) = true)

theorem identity50005 : scanCanonicalize (H12AffineFastState.compose env50005 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound50005 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env50006 : List Nat := [2,4,8,16,32,64,128,256,512,320,81,64,388,508,1,398,492,373,321,0,0,33,17,82,268,64,136,17,445,372,156,261,257,476,0,513]

theorem envBound50006 : H12AffineFastState.Bounded env50006 := by
  intro p hp
  have h : env50006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50005_50006 : H12AffineEnvironment.transform 10 81 env50005 = env50006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env50005 == env50006) = true)

def env50007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6664598,8393985,10507600,8724506,2102685,12645453,257,21793,46212,2175562]

theorem envBound50007 : H12AffineFastState.Bounded env50007 := by
  intro p hp
  have h : env50007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49911_50007 : H12AffineEnvironment.transform 23 10588557 env49911 = env50007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env49911 == env50007) = true)

def env50008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6664598,2098513,17664,2437194,2102685,6349853,257,21793,46212,2175562]

theorem envBound50008 : H12AffineFastState.Bounded env50008 := by
  intro p hp
  have h : env50008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50007_50008 : H12AffineEnvironment.transform 22 2101328 env50007 = env50008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env50007 == env50008) = true)

def env50009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2201878,2098513,17664,2437194,2102685,2411677,257,21793,46212,2175562]

theorem envBound50009 : H12AffineFastState.Bounded env50009 := by
  intro p hp
  have h : env50009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50008_50009 : H12AffineEnvironment.transform 21 272512 env50008 = env50009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env50008 == env50009) = true)

theorem identity50009 : scanCanonicalize (H12AffineFastState.compose env50009 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound50009 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,77899,272512,73755,98781,8328,64,43357,79130,17664,262145,75222,392406,257,21793,46212,513]

theorem envBound50010 : H12AffineFastState.Bounded env50010 := by
  intro p hp
  have h : env50010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50009_50010 : H12AffineEnvironment.transform 20 77899 env50009 = env50010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env50009 == env50010) = true)

theorem identity50010 : scanCanonicalize (H12AffineFastState.compose env50010 (packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound50010 : packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env50011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,67619,1025,32769,77899,73891,73755,98781,8328,64,43357,79130,17664,67618,75222,62709,257,21793,46212,513]

theorem envBound50011 : H12AffineFastState.Bounded env50011 := by
  intro p hp
  have h : env50011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50010_50011 : H12AffineEnvironment.transform 17 67619 env50010 = env50011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env50010 == env50011) = true)

theorem identity50011 : scanCanonicalize (H12AffineFastState.compose env50011 (packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound50011 : packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env50012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,65536,90138,67619,1025,0,77899,73891,73755,66012,8328,64,10588,79130,17664,67618,75222,29940,257,21793,13445,513]

theorem envBound50012 : H12AffineFastState.Bounded env50012 := by
  intro p hp
  have h : env50012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50011_50012 : H12AffineEnvironment.transform 14 1 env50011 = env50012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env50011 == env50012) = true)

def env50013 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,90138,67619,1025,0,77899,73771,73755,65876,8192,64,10588,79130,17664,67618,75102,29820,257,21793,13325,513]

theorem envBound50013 : H12AffineFastState.Bounded env50013 := by
  intro p hp
  have h : env50013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50012_50013 : H12AffineEnvironment.transform 6 8 env50012 = env50013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50012 == env50013) = true)

theorem identity50013 : scanCanonicalize (H12AffineFastState.compose env50013 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50013 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env50014 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,16401,10280,1025,0,4160,32,16,8543,8192,64,10588,5393,17664,10281,1365,29820,257,21793,13325,513]

theorem envBound50014 : H12AffineFastState.Bounded env50014 := by
  intro p hp
  have h : env50014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50013_50014 : H12AffineEnvironment.transform 15 8203 env50013 = env50014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50013 == env50014) = true)

theorem identity50014 : scanCanonicalize (H12AffineFastState.compose env50014 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound50014 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env50015 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,1,1094,16401,3173,1025,0,4160,32,16,1298,1101,64,3345,5393,17664,3172,1365,20529,257,21793,4160,513]

theorem envBound50015 : H12AffineFastState.Bounded env50015 := by
  intro p hp
  have h : env50015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50014_50015 : H12AffineEnvironment.transform 12 1101 env50014 = env50015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env50014 == env50015) = true)

theorem identity50015 : scanCanonicalize (H12AffineFastState.compose env50015 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound50015 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50016 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,41,16384,1,34,16401,2049,101,0,4160,32,16,374,41,64,2421,4469,16740,2048,305,20529,257,20805,4160,513]

theorem envBound50016 : H12AffineFastState.Bounded env50016 := by
  intro p hp
  have h : env50016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50015_50016 : H12AffineEnvironment.transform 9 100 env50015 = env50016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env50015 == env50016) = true)

theorem identity50016 : scanCanonicalize (H12AffineFastState.compose env50016 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound50016 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50017 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,41,4404,1,34,4389,2049,101,0,4160,32,16,374,41,64,2421,4469,4176,2048,305,261,257,113,4160,513]

theorem envBound50017 : H12AffineFastState.Bounded env50017 := by
  intro p hp
  have h : env50017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50016_50017 : H12AffineEnvironment.transform 13 4404 env50016 = env50017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env50016 == env50017) = true)

theorem identity50017 : scanCanonicalize (H12AffineFastState.compose env50017 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound50017 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env50018 : List Nat := [2,4,8,16,32,64,8,256,512,100,293,4096,41,4404,1,34,4389,292,101,0,4160,32,16,374,41,64,80,4469,4176,293,305,261,257,113,4160,513]

theorem envBound50018 : H12AffineFastState.Bounded env50018 := by
  intro p hp
  have h : env50018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50017_50018 : H12AffineEnvironment.transform 10 293 env50017 = env50018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env50017 == env50018) = true)

theorem identity50018 : scanCanonicalize (H12AffineFastState.compose env50018 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound50018 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env50019 : List Nat := [2,4,8,16,32,64,8,256,512,100,293,65,41,373,1,34,356,292,101,0,1,32,16,374,41,64,80,308,17,293,305,261,257,113,1,513]

theorem envBound50019 : H12AffineFastState.Bounded env50019 := by
  intro p hp
  have h : env50019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50018_50019 : H12AffineEnvironment.transform 11 65 env50018 = env50019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env50018 == env50019) = true)

theorem identity50019 : scanCanonicalize (H12AffineFastState.compose env50019 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50019 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50020 : List Nat := [2,4,8,16,32,16,8,256,512,52,293,17,41,293,1,34,308,292,53,0,1,32,16,294,41,16,0,308,17,293,305,261,257,33,1,513]

theorem envBound50020 : H12AffineFastState.Bounded env50020 := by
  intro p hp
  have h : env50020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50019_50020 : H12AffineEnvironment.transform 5 16 env50019 = env50020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50019 == env50020) = true)

theorem identity50020 : scanCanonicalize (H12AffineFastState.compose env50020 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50020 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50021 : List Nat := [2,4,8,16,32,16,8,37,512,52,0,17,41,0,1,34,17,1,53,0,1,32,16,3,41,16,0,17,17,0,20,32,36,33,1,513]

theorem envBound50021 : H12AffineFastState.Bounded env50021 := by
  intro p hp
  have h : env50021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50020_50021 : H12AffineEnvironment.transform 7 37 env50020 = env50021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50020 == env50021) = true)

theorem identity50021 : scanCanonicalize (H12AffineFastState.compose env50021 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound50021 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50022 : List Nat := [2,4,8,16,32,16,8,37,17,52,0,17,41,0,1,34,17,1,53,0,1,32,16,3,41,16,0,17,17,0,20,32,36,33,1,16]

theorem envBound50022 : H12AffineFastState.Bounded env50022 := by
  intro p hp
  have h : env50022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50021_50022 : H12AffineEnvironment.transform 8 17 env50021 = env50022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env50021 == env50022) = true)

theorem identity50022 : scanCanonicalize (H12AffineFastState.compose env50022 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound50022 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50023 : List Nat := [2,4,8,16,27,16,8,30,17,15,0,17,18,0,1,25,17,1,14,0,1,27,16,3,18,16,0,17,17,0,20,27,31,26,1,16]

theorem envBound50023 : H12AffineFastState.Bounded env50023 := by
  intro p hp
  have h : env50023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50022_50023 : H12AffineEnvironment.transform 4 27 env50022 = env50023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env50022 == env50023) = true)

def env50024 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,90138,67619,1025,0,77899,73770,73755,65877,8193,64,10588,79130,17664,67618,75103,29821,257,21793,13324,513]

theorem envBound50024 : H12AffineFastState.Bounded env50024 := by
  intro p hp
  have h : env50024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50012_50024 : H12AffineEnvironment.transform 6 9 env50012 = env50024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50012 == env50024) = true)

theorem identity50024 : scanCanonicalize (H12AffineFastState.compose env50024 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound50024 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50025 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,342,24908,2421,1025,0,12573,8572,8525,3,8193,64,10588,13388,17664,2420,9225,29821,257,21793,13324,513]

theorem envBound50025 : H12AffineFastState.Bounded env50025 := by
  intro p hp
  have h : env50025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50024_50025 : H12AffineEnvironment.transform 15 342 env50024 = env50025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env50024 == env50025) = true)

theorem identity50025 : scanCanonicalize (H12AffineFastState.compose env50025 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 12393) := by decide +kernel

theorem selectedBound50025 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env50026 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12393,1,342,4389,2421,1025,0,12573,8572,8525,3,8193,64,10588,13388,13673,2420,9225,1044,257,9544,13324,513]

theorem envBound50026 : H12AffineFastState.Bounded env50026 := by
  intro p hp
  have h : env50026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50025_50026 : H12AffineEnvironment.transform 13 12393 env50025 = env50026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12393 env50025 == env50026) = true)

theorem identity50026 : scanCanonicalize (H12AffineFastState.compose env50026 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound50026 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env50027 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,8192,11625,1,342,3109,2421,1025,0,11293,8572,8525,3,8193,64,10588,10572,10345,2420,9225,1044,257,9544,10508,513]

theorem envBound50027 : H12AffineFastState.Bounded env50027 := by
  intro p hp
  have h : env50027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50026_50027 : H12AffineEnvironment.transform 11 3328 env50026 = env50027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env50026 == env50027) = true)

theorem identity50027 : scanCanonicalize (H12AffineFastState.compose env50027 (packedSelected [0,1,7,8,10,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50027 : packedSelected [0,1,7,8,10,18] rootPS < 2^1333 := by decide +kernel

def env50028 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,3109,8192,11340,1,115,3109,2128,1025,0,11293,8281,8296,3,8193,64,10361,10345,10345,2129,9225,1044,36,9325,10281,513]

theorem envBound50028 : H12AffineFastState.Bounded env50028 := by
  intro p hp
  have h : env50028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50027_50028 : H12AffineEnvironment.transform 7 37 env50027 = env50028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50027 == env50028) = true)

theorem identity50028 : scanCanonicalize (H12AffineFastState.compose env50028 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound50028 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env50029 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,3109,120,3124,1,115,3109,2128,1025,0,3173,33,16,3,121,64,2049,2065,2065,2129,1137,1044,36,1045,2129,513]

theorem envBound50029 : H12AffineFastState.Bounded env50029 := by
  intro p hp
  have h : env50029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50028_50029 : H12AffineEnvironment.transform 12 120 env50028 = env50029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env50028 == env50029) = true)

theorem identity50029 : scanCanonicalize (H12AffineFastState.compose env50029 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound50029 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env50030 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,2064,120,2049,1,115,2064,2128,52,0,2128,33,16,3,121,64,2049,2065,2065,2129,68,33,36,32,2129,513]

theorem envBound50030 : H12AffineFastState.Bounded env50030 := by
  intro p hp
  have h : env50030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50029_50030 : H12AffineEnvironment.transform 9 53 env50029 = env50030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50029 == env50030) = true)

def env50031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2201879,2098513,17664,2437194,2102685,2411676,257,21793,46212,2175562]

theorem envBound50031 : H12AffineFastState.Bounded env50031 := by
  intro p hp
  have h : env50031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50008_50031 : H12AffineEnvironment.transform 21 272513 env50008 = env50031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env50008 == env50031) = true)

theorem identity50031 : scanCanonicalize (H12AffineFastState.compose env50031 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50031 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,2097152,272513,2101328,41431,8328,64,2144541,2098513,17664,2363456,2102685,2411676,257,21793,46212,2101824]

theorem envBound50032 : H12AffineFastState.Bounded env50032 := by
  intro p hp
  have h : env50032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50031_50032 : H12AffineEnvironment.transform 15 8202 env50031 = env50032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50031 == env50032) = true)

theorem identity50032 : scanCanonicalize (H12AffineFastState.compose env50032 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 309473) := by decide +kernel

theorem selectedBound50032 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env50033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,309473,272513,305329,41431,8328,64,262652,310704,17664,43169,306556,29821,257,21793,46212,305825]

theorem envBound50033 : H12AffineFastState.Bounded env50033 := by
  intro p hp
  have h : env50033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50032_50033 : H12AffineEnvironment.transform 20 309473 env50032 = env50033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 309473 env50032 == env50033) = true)

theorem identity50033 : scanCanonicalize (H12AffineFastState.compose env50033 (packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound50033 : packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8202,16401,262144,1025,1,276705,272513,272561,8663,8328,64,262652,277936,17664,10401,273788,29821,257,21793,13444,273057]

theorem envBound50034 : H12AffineFastState.Bounded env50034 := by
  intro p hp
  have h : env50034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50033_50034 : H12AffineEnvironment.transform 14 0 env50033 = env50034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env50033 == env50034) = true)

theorem identity50034 : scanCanonicalize (H12AffineFastState.compose env50034 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound50034 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env50035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,0,8202,13509,262144,1025,1,276705,272513,272561,8663,8328,64,262652,277936,12756,10401,273788,169,257,8693,13444,273057]

theorem envBound50035 : H12AffineFastState.Bounded env50035 := by
  intro p hp
  have h : env50035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50034_50035 : H12AffineEnvironment.transform 13 13524 env50034 = env50035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env50034 == env50035) = true)

theorem identity50035 : scanCanonicalize (H12AffineFastState.compose env50035 (packedSelected [1,8,9,10,11,15,16,22] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound50035 : packedSelected [1,8,9,10,11,15,16,22] rootPS < 2^1333 := by decide +kernel

def env50036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2113,8192,11413,0,8202,11396,262144,1025,1,270496,272513,272561,8663,8328,64,262652,271857,10645,10401,273788,169,257,8693,11461,273057]

theorem envBound50036 : H12AffineFastState.Bounded env50036 := by
  intro p hp
  have h : env50036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50035_50036 : H12AffineEnvironment.transform 11 2113 env50035 = env50036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env50035 == env50036) = true)

theorem identity50036 : scanCanonicalize (H12AffineFastState.compose env50036 (packedSelected [2,3,4,5,6,9,10,12,15,17,23] rootPS)) = affineNative (2^(17+1) ^^^ 80) := by decide +kernel

theorem selectedBound50036 : packedSelected [2,3,4,5,6,9,10,12,15,17,23] rootPS < 2^1333 := by decide +kernel

def env50037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2113,8192,11413,0,8202,11396,80,1025,1,8432,10449,10465,8663,8328,64,428,9633,10645,10401,11564,169,257,8693,11461,10993]

theorem envBound50037 : H12AffineFastState.Bounded env50037 := by
  intro p hp
  have h : env50037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50036_50037 : H12AffineEnvironment.transform 17 80 env50036 = env50037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 80 env50036 == env50037) = true)

theorem identity50037 : scanCanonicalize (H12AffineFastState.compose env50037 (packedSelected [0,2,4,7,9,11,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 3400) := by decide +kernel

theorem selectedBound50037 : packedSelected [0,2,4,7,9,11,17,18,19] rootPS < 2^1333 := by decide +kernel

def env50038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2113,3400,477,0,3394,460,80,1025,1,3512,1433,1449,3231,3520,64,428,2281,1245,1513,100,169,257,3261,397,1977]

theorem envBound50038 : H12AffineFastState.Bounded env50038 := by
  intro p hp
  have h : env50038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50037_50038 : H12AffineEnvironment.transform 12 3400 env50037 = env50038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3400 env50037 == env50038) = true)

theorem identity50038 : scanCanonicalize (H12AffineFastState.compose env50038 (packedSelected [2,3,5,7,9,12,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound50038 : packedSelected [2,3,5,7,9,12,15,18] rootPS < 2^1333 := by decide +kernel

def env50039 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,2113,3301,112,0,3311,97,80,1025,1,3093,1076,1028,3231,3181,64,1,2281,1245,1092,100,169,172,3261,32,1556]

theorem envBound50039 : H12AffineFastState.Bounded env50039 := by
  intro p hp
  have h : env50039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50038_50039 : H12AffineEnvironment.transform 7 173 env50038 = env50039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env50038 == env50039) = true)

theorem identity50039 : scanCanonicalize (H12AffineFastState.compose env50039 (packedSelected [1,4,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound50039 : packedSelected [1,4,7,8,11] rootPS < 2^1333 := by decide +kernel

def env50040 : List Nat := [2,4,8,16,32,64,128,173,512,221,2048,2113,2104,112,0,2098,97,80,220,1,2248,233,217,2114,2224,64,1,2281,0,153,100,169,172,2144,32,713]

theorem envBound50040 : H12AffineFastState.Bounded env50040 := by
  intro p hp
  have h : env50040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50039_50040 : H12AffineEnvironment.transform 9 221 env50039 = env50040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env50039 == env50040) = true)

theorem identity50040 : scanCanonicalize (H12AffineFastState.compose env50040 (packedSelected [1,2,4,6,8,9,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 249) := by decide +kernel

theorem selectedBound50040 : packedSelected [1,2,4,6,8,9,14,15] rootPS < 2^1333 := by decide +kernel

def env50041 : List Nat := [2,4,8,16,32,64,128,173,512,221,249,184,193,112,0,203,97,80,220,1,49,233,217,187,73,64,1,16,0,153,100,169,172,153,32,713]

theorem envBound50041 : H12AffineFastState.Bounded env50041 := by
  intro p hp
  have h : env50041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50040_50041 : H12AffineEnvironment.transform 10 249 env50040 = env50041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 249 env50040 == env50041) = true)

theorem identity50041 : scanCanonicalize (H12AffineFastState.compose env50041 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50041 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env50042 : List Nat := [2,4,8,16,32,64,9,36,512,84,112,49,72,112,0,66,97,80,85,1,49,96,80,50,73,64,1,16,0,16,100,32,37,16,32,576]

theorem envBound50042 : H12AffineFastState.Bounded env50042 := by
  intro p hp
  have h : env50042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50041_50042 : H12AffineEnvironment.transform 6 9 env50041 = env50042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50041 == env50042) = true)

theorem identity50042 : scanCanonicalize (H12AffineFastState.compose env50042 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound50042 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50043 : List Nat := [2,4,8,16,32,1,9,36,512,21,49,49,9,49,0,3,32,17,20,1,49,33,17,50,8,1,1,16,0,16,37,32,37,16,32,513]

theorem envBound50043 : H12AffineFastState.Bounded env50043 := by
  intro p hp
  have h : env50043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50042_50043 : H12AffineEnvironment.transform 5 1 env50042 = env50043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env50042 == env50043) = true)

theorem identity50043 : scanCanonicalize (H12AffineFastState.compose env50043 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50043 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env50044 : List Nat := [2,4,8,11,32,1,9,36,512,14,42,42,9,42,0,3,32,10,15,1,42,33,10,41,8,1,1,11,0,11,37,32,37,11,32,513]

theorem envBound50044 : H12AffineFastState.Bounded env50044 := by
  intro p hp
  have h : env50044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50043_50044 : H12AffineEnvironment.transform 3 11 env50043 = env50044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50043 == env50044) = true)

theorem identity50044 : scanCanonicalize (H12AffineFastState.compose env50044 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound50044 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50045 : List Nat := [2,4,8,11,7,1,9,3,512,14,13,13,9,13,0,3,7,10,15,1,13,6,10,14,8,1,1,11,0,11,2,7,2,11,7,513]

theorem envBound50045 : H12AffineFastState.Bounded env50045 := by
  intro p hp
  have h : env50045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50044_50045 : H12AffineEnvironment.transform 4 7 env50044 = env50045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env50044 == env50045) = true)

theorem identity50045 : scanCanonicalize (H12AffineFastState.compose env50045 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound50045 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env50046 : List Nat := [2,4,2,1,7,1,3,3,512,4,7,7,3,7,0,3,7,0,5,1,7,6,0,4,2,1,1,1,0,1,2,7,2,1,7,513]

theorem envBound50046 : H12AffineFastState.Bounded env50046 := by
  intro p hp
  have h : env50046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50045_50046 : H12AffineEnvironment.transform 2 2 env50045 = env50046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env50045 == env50046) = true)

theorem identity50046 : scanCanonicalize (H12AffineFastState.compose env50046 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound50046 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50047 : List Nat := [0,4,0,1,5,1,1,1,512,4,5,5,1,5,0,1,5,0,5,1,5,4,0,4,0,1,1,1,0,1,0,5,0,1,5,513]

theorem envBound50047 : H12AffineFastState.Bounded env50047 := by
  intro p hp
  have h : env50047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50046_50047 : H12AffineEnvironment.transform 0 0 env50046 = env50047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env50046 == env50047) = true)

theorem identity50047 : scanCanonicalize (H12AffineFastState.compose env50047 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound50047 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50048 : List Nat := [0,1,0,1,0,1,1,1,512,1,0,0,1,0,0,1,0,0,0,1,0,1,0,1,0,1,1,1,0,1,0,0,0,1,0,513]

theorem envBound50048 : H12AffineFastState.Bounded env50048 := by
  intro p hp
  have h : env50048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50047_50048 : H12AffineEnvironment.transform 1 1 env50047 = env50048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env50047 == env50048) = true)

def env50049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6664598,2098512,17665,2437195,2102685,6349852,257,21793,46212,2175562]

theorem envBound50049 : H12AffineFastState.Bounded env50049 := by
  intro p hp
  have h : env50049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50007_50049 : H12AffineEnvironment.transform 22 2101329 env50007 = env50049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env50007 == env50049) = true)

def env50050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2201878,2098512,17665,2437195,2102685,2411676,257,21793,46212,2175562]

theorem envBound50050 : H12AffineFastState.Bounded env50050 := by
  intro p hp
  have h : env50050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50049_50050 : H12AffineEnvironment.transform 21 272512 env50049 = env50050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env50049 == env50050) = true)

theorem identity50050 : scanCanonicalize (H12AffineFastState.compose env50050 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound50050 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,115871,272512,120014,98780,8328,64,23945,115151,17665,324820,119042,329731,257,21793,46212,63189]

theorem envBound50051 : H12AffineFastState.Bounded env50051 := by
  intro p hp
  have h : env50051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50050_50051 : H12AffineEnvironment.transform 20 115871 env50050 = env50051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env50050 == env50051) = true)

def env50052 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,115871,272512,119966,98700,8328,16,23945,115103,17665,324740,119042,329731,257,21793,46212,63109]

theorem envBound50052 : H12AffineFastState.Bounded env50052 := by
  intro p hp
  have h : env50052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50051_50052 : H12AffineEnvironment.transform 5 16 env50051 = env50052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50051 == env50052) = true)

theorem identity50052 : scanCanonicalize (H12AffineFastState.compose env50052 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 122146) := by decide +kernel

theorem selectedBound50052 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env50053 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,122146,1025,32769,115871,128418,119966,98700,8328,16,23945,115103,17665,76198,119042,54561,257,21793,46212,63109]

theorem envBound50053 : H12AffineFastState.Bounded env50053 := by
  intro p hp
  have h : env50053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50052_50053 : H12AffineEnvironment.transform 17 122146 env50052 = env50053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122146 env50052 == env50053) = true)

theorem identity50053 : scanCanonicalize (H12AffineFastState.compose env50053 (packedSelected [0,3,5,8,9,10,11,16,17,20,22,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound50053 : packedSelected [0,3,5,8,9,10,11,16,17,20,22,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env50054 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,62731,5392,10281,1025,32769,12692,169,8597,29831,8328,16,23945,13460,17665,56493,9225,54561,257,21793,46212,63109]

theorem envBound50054 : H12AffineFastState.Bounded env50054 := by
  intro p hp
  have h : env50054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50053_50054 : H12AffineEnvironment.transform 15 62731 env50053 = env50054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env50053 == env50054) = true)

def env50055 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,115871,272512,119967,98701,8328,17,23945,115102,17665,324741,119042,329731,257,21793,46212,63108]

theorem envBound50055 : H12AffineFastState.Bounded env50055 := by
  intro p hp
  have h : env50055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50051_50055 : H12AffineEnvironment.transform 5 17 env50051 = env50055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50051 == env50055) = true)

theorem identity50055 : scanCanonicalize (H12AffineFastState.compose env50055 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound50055 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env50056 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,64808,1025,32769,115871,54696,119967,98701,8328,17,23945,115102,17665,2477,119042,128299,257,21793,46212,63108]

theorem envBound50056 : H12AffineFastState.Bounded env50056 := by
  intro p hp
  have h : env50056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50055_50056 : H12AffineEnvironment.transform 17 64808 env50055 = env50056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env50055 == env50056) = true)

theorem identity50056 : scanCanonicalize (H12AffineFastState.compose env50056 (packedSelected [0,1,9,16,18,20,22,23,26,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound50056 : packedSelected [0,1,9,16,18,20,22,23,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env50057 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,32768,65536,103582,35245,1025,32769,110618,41261,106522,98701,8328,17,10508,111899,12676,2477,107911,98734,257,8612,46212,33281]

theorem envBound50057 : H12AffineFastState.Bounded env50057 := by
  intro p hp
  have h : env50057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50056_50057 : H12AffineEnvironment.transform 13 13445 env50056 = env50057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env50056 == env50057) = true)

theorem identity50057 : scanCanonicalize (H12AffineFastState.compose env50057 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound50057 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env50058 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,8580,65536,79130,10281,1025,8581,70046,169,65950,73737,8328,17,10508,70815,12676,2477,66563,73770,257,8612,5376,9093]

theorem envBound50058 : H12AffineFastState.Bounded env50058 := by
  intro p hp
  have h : env50058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50057_50058 : H12AffineEnvironment.transform 14 8580 env50057 = env50058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env50057 == env50058) = true)

theorem identity50058 : scanCanonicalize (H12AffineFastState.compose env50058 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50058 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env50059 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13325,8460,65536,79130,10281,1025,8461,69910,33,65814,73737,8192,17,10508,70679,12556,2341,66563,73770,257,8492,5376,8973]

theorem envBound50059 : H12AffineFastState.Bounded env50059 := by
  intro p hp
  have h : env50059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50058_50059 : H12AffineEnvironment.transform 6 8 env50058 = env50059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50058 == env50059) = true)

theorem identity50059 : scanCanonicalize (H12AffineFastState.compose env50059 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound50059 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env50060 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13325,8460,263,13341,10281,1025,8461,4113,33,17,8462,8192,17,10508,5392,12556,2341,1284,8493,257,8492,5376,8973]

theorem envBound50060 : H12AffineFastState.Bounded env50060 := by
  intro p hp
  have h : env50060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50059_50060 : H12AffineEnvironment.transform 15 263 env50059 = env50060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env50059 == env50060) = true)

theorem identity50060 : scanCanonicalize (H12AffineFastState.compose env50060 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 2823) := by decide +kernel

theorem selectedBound50060 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env50061 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,2823,7946,2571,263,7962,814,1025,2570,4113,33,17,2569,2823,17,523,5392,6667,2341,1284,2602,257,2603,5376,2058]

theorem envBound50061 : H12AffineFastState.Bounded env50061 := by
  intro p hp
  have h : env50061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50060_50061 : H12AffineEnvironment.transform 12 2823 env50060 = env50061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2823 env50060 == env50061) = true)

theorem identity50061 : scanCanonicalize (H12AffineFastState.compose env50061 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound50061 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env50062 : List Nat := [2,4,8,16,32,17,8,256,512,1024,523,4096,268,5377,0,263,5393,814,1025,1,4113,33,17,2,268,17,523,5392,4096,814,1284,33,257,32,5376,513]

theorem envBound50062 : H12AffineFastState.Bounded env50062 := by
  intro p hp
  have h : env50062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50061_50062 : H12AffineEnvironment.transform 10 523 env50061 = env50062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env50061 == env50062) = true)

theorem identity50062 : scanCanonicalize (H12AffineFastState.compose env50062 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50062 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50063 : List Nat := [2,4,8,16,32,17,8,37,512,1024,523,4096,41,5156,0,34,5172,523,1025,1,4113,33,17,2,41,17,523,5173,4096,523,1057,33,36,32,5157,513]

theorem envBound50063 : H12AffineFastState.Bounded env50063 := by
  intro p hp
  have h : env50063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50062_50063 : H12AffineEnvironment.transform 7 37 env50062 = env50063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50062 == env50063) = true)

theorem identity50063 : scanCanonicalize (H12AffineFastState.compose env50063 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50063 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50064 : List Nat := [2,4,8,16,0,17,8,5,512,1024,523,4096,9,5124,0,2,5140,523,1025,1,4113,1,17,2,9,17,523,5141,4096,523,1025,1,4,0,5125,513]

theorem envBound50064 : H12AffineFastState.Bounded env50064 := by
  intro p hp
  have h : env50064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50063_50064 : H12AffineEnvironment.transform 4 0 env50063 = env50064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50063 == env50064) = true)

def env50065 : List Nat := [2,4,8,16,0,17,8,5,512,1024,523,16,9,1044,0,2,1028,523,1025,1,1,1,17,2,9,17,523,1029,16,523,1025,1,4,0,1045,513]

theorem envBound50065 : H12AffineFastState.Bounded env50065 := by
  intro p hp
  have h : env50065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50064_50065 : H12AffineEnvironment.transform 11 16 env50064 = env50065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env50064 == env50065) = true)

theorem identity50065 : scanCanonicalize (H12AffineFastState.compose env50065 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 522) := by decide +kernel

theorem selectedBound50065 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50066 : List Nat := [2,4,8,16,0,17,8,5,512,522,523,16,9,542,0,2,526,523,523,1,1,1,17,2,9,17,523,527,16,523,523,1,4,0,543,513]

theorem envBound50066 : H12AffineFastState.Bounded env50066 := by
  intro p hp
  have h : env50066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50065_50066 : H12AffineEnvironment.transform 9 522 env50065 = env50066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 522 env50065 == env50066) = true)

def env50067 : List Nat := [2,4,8,4,0,5,8,5,512,522,523,4,9,522,0,2,526,523,523,1,1,1,5,2,9,5,523,527,4,523,523,1,4,0,523,513]

theorem envBound50067 : H12AffineFastState.Bounded env50067 := by
  intro p hp
  have h : env50067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50066_50067 : H12AffineEnvironment.transform 3 4 env50066 = env50067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env50066 == env50067) = true)

theorem identity50067 : scanCanonicalize (H12AffineFastState.compose env50067 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound50067 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50068 : List Nat := [2,4,8,4,0,5,8,5,9,3,2,4,9,3,0,2,7,2,2,1,1,1,5,2,9,5,2,6,4,2,2,1,4,0,2,8]

theorem envBound50068 : H12AffineFastState.Bounded env50068 := by
  intro p hp
  have h : env50068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50067_50068 : H12AffineEnvironment.transform 8 9 env50067 = env50068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env50067 == env50068) = true)

def leafEnv50068 : List Nat := [2,4,8,4,0,5,8,5,9,3,2,4,9,3,0,2,7,2,2,1,1,1,5,2,2,9,1,5,2,6,4,2,2,1,4,0,4,2,2,8,1,0,0]

def active50068 : List Nat := [0,1,2]

def tree50068 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50068 : H12WitnessSearch.Good tree50068 := H12GlobalWitnessIndex.good

theorem leafIdentity50068 : H12AffineFastState.composeSystem env50068 rootObs = leafEnv50068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50068 rootObs == leafEnv50068) = true)

theorem terminalChecked50068 : H12PackedTerminal.terminalCheckFast leafEnv50068 active50068 tree50068 = true := by decide +kernel

def env50069 : List Nat := [2,4,8,5,0,4,8,5,512,522,523,5,9,523,0,2,526,523,523,1,1,1,4,2,9,4,523,527,5,523,523,1,4,0,522,513]

theorem envBound50069 : H12AffineFastState.Bounded env50069 := by
  intro p hp
  have h : env50069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50066_50069 : H12AffineEnvironment.transform 3 5 env50066 = env50069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env50066 == env50069) = true)

theorem identity50069 : scanCanonicalize (H12AffineFastState.compose env50069 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50069 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50070 : List Nat := [1,4,8,5,0,4,8,5,512,521,520,5,9,520,0,1,525,520,520,1,1,1,4,1,9,4,520,524,5,520,520,1,4,0,521,513]

theorem envBound50070 : H12AffineFastState.Bounded env50070 := by
  intro p hp
  have h : env50070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50069_50070 : H12AffineEnvironment.transform 0 1 env50069 = env50070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50069 == env50070) = true)

def leafEnv50070 : List Nat := [1,4,8,5,0,4,8,5,512,521,520,5,9,520,0,1,525,520,520,1,1,1,4,1,520,9,1,4,520,524,5,520,520,1,4,0,4,1,521,513,1,0,0]

def active50070 : List Nat := [1,2,8]

def tree50070 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50070 : H12WitnessSearch.Good tree50070 := H12GlobalWitnessIndex.good

theorem leafIdentity50070 : H12AffineFastState.composeSystem env50070 rootObs = leafEnv50070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50070 rootObs == leafEnv50070) = true)

theorem terminalChecked50070 : H12PackedTerminal.terminalCheckFast leafEnv50070 active50070 tree50070 = true := by decide +kernel

def env50071 : List Nat := [2,4,8,16,0,17,8,5,512,1024,523,17,9,1045,0,2,1029,523,1025,1,0,1,17,2,9,17,523,1028,17,523,1025,1,4,0,1044,513]

theorem envBound50071 : H12AffineFastState.Bounded env50071 := by
  intro p hp
  have h : env50071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50064_50071 : H12AffineEnvironment.transform 11 17 env50064 = env50071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env50064 == env50071) = true)

theorem identity50071 : scanCanonicalize (H12AffineFastState.compose env50071 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound50071 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50072 : List Nat := [2,4,8,16,0,17,8,5,31,1024,20,17,9,1045,0,2,1029,20,1025,1,0,1,17,2,9,17,20,1028,17,20,1025,1,4,0,1044,30]

theorem envBound50072 : H12AffineFastState.Bounded env50072 := by
  intro p hp
  have h : env50072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50071_50072 : H12AffineEnvironment.transform 8 31 env50071 = env50072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env50071 == env50072) = true)

def env50073 : List Nat := [2,4,8,16,0,17,8,5,31,0,20,17,9,21,0,2,5,20,1,1,0,1,17,2,9,17,20,4,17,20,1,1,4,0,20,30]

theorem envBound50073 : H12AffineFastState.Bounded env50073 := by
  intro p hp
  have h : env50073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50072_50073 : H12AffineEnvironment.transform 9 0 env50072 = env50073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env50072 == env50073) = true)

theorem identity50073 : scanCanonicalize (H12AffineFastState.compose env50073 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50073 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50074 : List Nat := [1,4,8,16,0,17,8,5,28,0,20,17,9,21,0,1,5,20,1,1,0,1,17,1,9,17,20,4,17,20,1,1,4,0,20,29]

theorem envBound50074 : H12AffineFastState.Bounded env50074 := by
  intro p hp
  have h : env50074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50073_50074 : H12AffineEnvironment.transform 0 1 env50073 = env50074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50073 == env50074) = true)

def leafEnv50074 : List Nat := [1,4,8,16,0,17,8,5,28,0,20,17,9,21,0,1,5,20,1,1,0,1,17,1,1,9,1,17,20,4,17,20,1,1,4,0,4,1,20,29,1,1,0]

def active50074 : List Nat := [1,2,3]

def tree50074 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50074 : H12WitnessSearch.Good tree50074 := H12GlobalWitnessIndex.good

theorem leafIdentity50074 : H12AffineFastState.composeSystem env50074 rootObs = leafEnv50074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50074 rootObs == leafEnv50074) = true)

theorem terminalChecked50074 : H12PackedTerminal.terminalCheckFast leafEnv50074 active50074 tree50074 = true := by decide +kernel

def env50075 : List Nat := [2,4,8,16,0,17,8,5,31,1,20,17,9,20,0,2,4,20,0,1,0,1,17,2,9,17,20,5,17,20,0,1,4,0,21,30]

theorem envBound50075 : H12AffineFastState.Bounded env50075 := by
  intro p hp
  have h : env50075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50072_50075 : H12AffineEnvironment.transform 9 1 env50072 = env50075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env50072 == env50075) = true)

theorem identity50075 : scanCanonicalize (H12AffineFastState.compose env50075 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound50075 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50076 : List Nat := [2,4,8,6,0,7,8,5,9,1,2,7,9,2,0,2,4,2,0,1,0,1,7,2,9,7,2,5,7,2,0,1,4,0,3,8]

theorem envBound50076 : H12AffineFastState.Bounded env50076 := by
  intro p hp
  have h : env50076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50075_50076 : H12AffineEnvironment.transform 3 6 env50075 = env50076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env50075 == env50076) = true)

def leafEnv50076 : List Nat := [2,4,8,6,0,7,8,5,9,1,2,7,9,2,0,2,4,2,0,1,0,1,7,2,0,9,1,7,2,5,7,2,0,1,4,0,4,2,3,8,1,1,0]

def active50076 : List Nat := [0,1,2]

def tree50076 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50076 : H12WitnessSearch.Good tree50076 := H12GlobalWitnessIndex.good

theorem leafIdentity50076 : H12AffineFastState.composeSystem env50076 rootObs = leafEnv50076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50076 rootObs == leafEnv50076) = true)

theorem terminalChecked50076 : H12PackedTerminal.terminalCheckFast leafEnv50076 active50076 tree50076 = true := by decide +kernel

def env50077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2201879,2098512,17665,2437195,2102685,2411677,257,21793,46212,2175562]

theorem envBound50077 : H12AffineFastState.Bounded env50077 := by
  intro p hp
  have h : env50077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50049_50077 : H12AffineEnvironment.transform 21 272513 env50049 = env50077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env50049 == env50077) = true)

theorem identity50077 : scanCanonicalize (H12AffineFastState.compose env50077 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound50077 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,13508,262144,1025,32769,2097152,272513,2101329,21763,8328,64,2117064,2098512,17665,2417812,2102685,2411677,257,21793,46212,2156181]

theorem envBound50078 : H12AffineFastState.Bounded env50078 := by
  intro p hp
  have h : env50078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50077_50078 : H12AffineEnvironment.transform 15 54495 env50077 = env50078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env50077 == env50078) = true)

def env50079 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13388,262144,1025,32769,2097152,272393,2101329,21763,8192,64,2116928,2098512,17665,2417692,2102549,2411541,257,21793,46092,2156061]

theorem envBound50079 : H12AffineFastState.Bounded env50079 := by
  intro p hp
  have h : env50079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50078_50079 : H12AffineEnvironment.transform 6 8 env50078 = env50079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50078 == env50079) = true)

theorem identity50079 : scanCanonicalize (H12AffineFastState.compose env50079 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound50079 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env50080 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13388,10281,1025,32769,2097152,32,2101329,21763,8192,64,2116928,2098512,17665,2149429,2102549,2155580,257,21793,46092,2156061]

theorem envBound50080 : H12AffineFastState.Bounded env50080 := by
  intro p hp
  have h : env50080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50079_50080 : H12AffineEnvironment.transform 17 10281 env50079 = env50080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env50079 == env50080) = true)

theorem identity50080 : scanCanonicalize (H12AffineFastState.compose env50080 (packedSelected [0,1,3,7,9,12,14,15,16,22,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound50080 : packedSelected [0,1,3,7,9,12,14,15,16,22,24,28] rootPS < 2^1333 := by decide +kernel

def env50081 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13388,10281,1025,32769,25628,32,29773,21763,8192,64,10588,24908,17665,43049,28937,32800,257,21793,46092,33281]

theorem envBound50081 : H12AffineFastState.Bounded env50081 := by
  intro p hp
  have h : env50081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50080_50081 : H12AffineEnvironment.transform 20 25628 env50080 = env50081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env50080 == env50081) = true)

theorem identity50081 : scanCanonicalize (H12AffineFastState.compose env50081 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50081 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50082 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,13388,10281,1025,32769,12573,32,8524,2,8192,64,10588,13389,4096,43049,9224,32800,257,32,46092,33281]

theorem envBound50082 : H12AffineFastState.Bounded env50082 := by
  intro p hp
  have h : env50082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50081_50082 : H12AffineEnvironment.transform 13 5377 env50081 = env50082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50081 == env50082) = true)

theorem identity50082 : scanCanonicalize (H12AffineFastState.compose env50082 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50082 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env50083 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,13388,10281,1025,8541,12573,32,8524,2,8192,64,10588,13389,4096,2421,9224,8572,257,32,5456,9053]

theorem envBound50083 : H12AffineFastState.Bounded env50083 := by
  intro p hp
  have h : env50083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50082_50083 : H12AffineEnvironment.transform 14 8540 env50082 = env50083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50082 == env50083) = true)

theorem identity50083 : scanCanonicalize (H12AffineFastState.compose env50083 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound50083 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env50084 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,8233,8202,13388,10281,1025,8232,12392,32,8249,2,8192,64,10281,13389,4096,2048,9224,8201,116,32,5157,8744]

theorem envBound50084 : H12AffineFastState.Bounded env50084 := by
  intro p hp
  have h : env50084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50083_50084 : H12AffineEnvironment.transform 7 117 env50083 = env50084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50083 == env50084) = true)

theorem identity50084 : scanCanonicalize (H12AffineFastState.compose env50084 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50084 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env50085 : List Nat := [2,4,8,16,32,64,8,117,512,1024,0,4096,8192,5236,8233,8202,13388,8233,1025,8232,12392,32,8249,2,8192,64,8233,13389,4096,0,9224,8201,116,32,5157,8744]

theorem envBound50085 : H12AffineFastState.Bounded env50085 := by
  intro p hp
  have h : env50085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50084_50085 : H12AffineEnvironment.transform 10 0 env50084 = env50085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50084 == env50085) = true)

def env50086 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13389,262144,1025,32769,2097152,272392,2101329,21763,8193,64,2116929,2098512,17665,2417693,2102548,2411540,257,21793,46093,2156060]

theorem envBound50086 : H12AffineFastState.Bounded env50086 := by
  intro p hp
  have h : env50086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50078_50086 : H12AffineEnvironment.transform 6 9 env50078 = env50086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50078 == env50086) = true)

theorem identity50086 : scanCanonicalize (H12AffineFastState.compose env50086 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 309353) := by decide +kernel

theorem selectedBound50086 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env50087 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13389,262144,1025,32769,309353,272392,305208,21763,8193,64,324904,310585,17665,23668,306557,29821,257,21793,46093,286325]

theorem envBound50087 : H12AffineFastState.Bounded env50087 := by
  intro p hp
  have h : env50087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50086_50087 : H12AffineEnvironment.transform 20 309353 env50086 = env50087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 309353 env50086 == env50087) = true)

theorem identity50087 : scanCanonicalize (H12AffineFastState.compose env50087 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound50087 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env50088 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13389,10280,1025,32769,36929,32,32784,21763,8193,64,56576,38161,17665,23668,34133,29821,257,21793,46093,30301]

theorem envBound50088 : H12AffineFastState.Bounded env50088 := by
  intro p hp
  have h : env50088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50087_50088 : H12AffineEnvironment.transform 17 10280 env50087 = env50088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50087 == env50088) = true)

theorem identity50088 : scanCanonicalize (H12AffineFastState.compose env50088 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50088 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50089 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,13389,10280,1025,8541,12573,32,8524,21763,8193,64,31836,13389,17665,23668,9225,29821,257,21793,5457,30301]

theorem envBound50089 : H12AffineFastState.Bounded env50089 := by
  intro p hp
  have h : env50089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50088_50089 : H12AffineEnvironment.transform 14 8540 env50088 = env50089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50088 == env50089) = true)

theorem identity50089 : scanCanonicalize (H12AffineFastState.compose env50089 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound50089 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env50090 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,8192,16384,8540,28990,12409,10280,53,8541,12573,32,8524,20791,8193,64,30824,12409,16693,22592,8253,28745,257,20757,4453,29289]

theorem envBound50090 : H12AffineFastState.Bounded env50090 := by
  intro p hp
  have h : env50090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50089_50090 : H12AffineEnvironment.transform 9 52 env50089 = env50090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50089 == env50090) = true)

theorem identity50090 : scanCanonicalize (H12AffineFastState.compose env50090 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound50090 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50091 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,40,16384,372,20758,4177,2048,53,373,4405,32,356,20791,41,64,22592,4177,16693,22592,21,20577,257,20757,4453,21057]

theorem envBound50091 : H12AffineFastState.Bounded env50091 := by
  intro p hp
  have h : env50091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50090_50091 : H12AffineEnvironment.transform 12 40 env50090 = env50091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env50090 == env50091) = true)

theorem identity50091 : scanCanonicalize (H12AffineFastState.compose env50091 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound50091 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env50092 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,4096,40,16384,1,20579,4177,2048,53,0,4160,32,17,20546,41,64,22592,4177,16448,22592,21,20577,116,20576,4112,21057]

theorem envBound50092 : H12AffineFastState.Bounded env50092 := by
  intro p hp
  have h : env50092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50091_50092 : H12AffineEnvironment.transform 7 117 env50091 = env50092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50091 == env50092) = true)

theorem identity50092 : scanCanonicalize (H12AffineFastState.compose env50092 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound50092 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50093 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,4096,40,17,1,4210,4177,2048,53,0,4160,32,17,4179,41,64,6225,4177,81,6225,21,4208,116,4209,4112,4688]

theorem envBound50093 : H12AffineFastState.Bounded env50093 := by
  intro p hp
  have h : env50093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50092_50093 : H12AffineEnvironment.transform 13 17 env50092 = env50093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env50092 == env50093) = true)

theorem identity50093 : scanCanonicalize (H12AffineFastState.compose env50093 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 113) := by decide +kernel

theorem selectedBound50093 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env50094 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,113,40,17,1,3,32,2048,53,0,49,32,17,34,41,64,2080,32,81,2080,21,1,116,0,97,545]

theorem envBound50094 : H12AffineFastState.Bounded env50094 := by
  intro p hp
  have h : env50094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50093_50094 : H12AffineEnvironment.transform 11 113 env50093 = env50094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 113 env50093 == env50094) = true)

theorem identity50094 : scanCanonicalize (H12AffineFastState.compose env50094 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50094 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50095 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,32,40,17,1,3,32,2048,53,0,49,32,17,34,41,17,2080,32,0,2080,21,1,37,0,48,545]

theorem envBound50095 : H12AffineFastState.Bounded env50095 := by
  intro p hp
  have h : env50095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50094_50095 : H12AffineEnvironment.transform 5 17 env50094 = env50095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50094 == env50095) = true)

theorem identity50095 : scanCanonicalize (H12AffineFastState.compose env50095 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50095 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50096 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,0,8,17,1,3,0,2048,21,0,17,0,17,2,9,17,2048,0,0,2048,21,1,5,0,16,513]

theorem envBound50096 : H12AffineFastState.Bounded env50096 := by
  intro p hp
  have h : env50096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50095_50096 : H12AffineEnvironment.transform 4 0 env50095 = env50096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50095 == env50096) = true)

theorem identity50096 : scanCanonicalize (H12AffineFastState.compose env50096 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound50096 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50097 : List Nat := [2,4,8,16,0,17,9,4,512,20,512,0,8,17,1,3,0,512,21,0,17,0,17,2,9,17,512,0,0,512,21,1,5,0,16,513]

theorem envBound50097 : H12AffineFastState.Bounded env50097 := by
  intro p hp
  have h : env50097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50096_50097 : H12AffineEnvironment.transform 10 512 env50096 = env50097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env50096 == env50097) = true)

def env50098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254785,25265169,145662401,525568,140903596,27337993,25733062]

theorem envBound50098 : H12AffineFastState.Bounded env50098 := by
  intro p hp
  have h : env50098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49352_50098 : H12AffineEnvironment.transform 25 65 env49352 = env50098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env49352 == env50098) = true)

def env50099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356289,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound50099 : H12AffineFastState.Bounded env50099 := by
  intro p hp
  have h : env50099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50098_50099 : H12AffineEnvironment.transform 26 30393344 env50098 = env50099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env50098 == env50099) = true)

def env50100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound50100 : H12AffineFastState.Bounded env50100 := by
  intro p hp
  have h : env50100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50099_50100 : H12AffineEnvironment.transform 18 1024 env50099 = env50100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env50099 == env50100) = true)

theorem identity50100 : scanCanonicalize (H12AffineFastState.compose env50100 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2534778) := by decide +kernel

theorem selectedBound50100 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env50101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2534778,8328,65,14773626,469495,10507601,8830977,10955115,4704443,256,8874454,8882291,10882748]

theorem envBound50101 : H12AffineFastState.Bounded env50101 := by
  intro p hp
  have h : env50101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50100_50101 : H12AffineEnvironment.transform 23 2534778 env50100 = env50101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2534778 env50100 == env50101) = true)

def env50102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,8388608,2114882,8328,65,14773626,115151,10507601,8398905,10600787,4268163,256,8487406,8478795,10544772]

theorem envBound50102 : H12AffineFastState.Bounded env50102 := by
  intro p hp
  have h : env50102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50101_50102 : H12AffineEnvironment.transform 17 190520 env50101 = env50102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env50101 == env50102) = true)

def env50103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,2101328,2114882,8328,65,4291882,115151,17665,2111593,119043,4268163,256,2199998,2191387,63188]

theorem envBound50103 : H12AffineFastState.Bounded env50103 := by
  intro p hp
  have h : env50103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50102_50103 : H12AffineEnvironment.transform 22 2101328 env50102 = env50103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env50102 == env50103) = true)

def env50104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,21762,8328,65,4291882,115151,17665,10281,119043,4268163,256,98814,90203,63188]

theorem envBound50104 : H12AffineFastState.Bounded env50104 := by
  intro p hp
  have h : env50104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50103_50104 : H12AffineEnvironment.transform 20 4160 env50103 = env50104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50103 == env50104) = true)

def env50105 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,21762,8192,65,4291882,115015,17665,10281,119043,4268043,256,98678,90203,63068]

theorem envBound50105 : H12AffineFastState.Bounded env50105 := by
  intro p hp
  have h : env50105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50104_50105 : H12AffineEnvironment.transform 6 8 env50104 = env50105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50104 == env50105) = true)

theorem identity50105 : scanCanonicalize (H12AffineFastState.compose env50105 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound50105 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50106 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4160,4194304,16,21762,8192,65,4291882,115015,17665,10281,119043,4268043,256,98678,90203,63068]

theorem envBound50106 : H12AffineFastState.Bounded env50106 := by
  intro p hp
  have h : env50106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50105_50106 : H12AffineEnvironment.transform 16 49169 env50105 = env50106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env50105 == env50106) = true)

theorem identity50106 : scanCanonicalize (H12AffineFastState.compose env50106 (packedSelected [0,1,4,5,7,8,10,15,16,20,22,24,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound50106 : packedSelected [0,1,4,5,7,8,10,15,16,20,22,24,31,38] rootPS < 2^1333 := by decide +kernel

def env50107 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13388,10281,1024,29788,4160,4194304,16,21762,8192,65,4291882,79130,17665,10281,75102,4268043,256,95531,90203,513]

theorem envBound50107 : H12AffineFastState.Bounded env50107 := by
  intro p hp
  have h : env50107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50106_50107 : H12AffineEnvironment.transform 14 29789 env50106 = env50107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env50106 == env50107) = true)

theorem identity50107 : scanCanonicalize (H12AffineFastState.compose env50107 (packedSelected [0,1,4,7,8,9,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50107 : packedSelected [0,1,4,7,8,9,14,19] rootPS < 2^1333 := by decide +kernel

def env50108 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,13388,10281,1024,29788,4160,4194304,16,21762,8192,65,4218145,5393,17665,10281,1365,4194304,256,21792,16464,513]

theorem envBound50108 : H12AffineFastState.Bounded env50108 := by
  intro p hp
  have h : env50108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50107_50108 : H12AffineEnvironment.transform 15 8203 env50107 = env50108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50107 == env50108) = true)

theorem identity50108 : scanCanonicalize (H12AffineFastState.compose env50108 (packedSelected [2,3,5,6,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50108 : packedSelected [2,3,5,6,10,11,18] rootPS < 2^1333 := by decide +kernel

def env50109 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,21841,263,5440,2341,1024,21840,4160,4194304,16,21762,268,65,4218145,5393,17665,2341,1365,4194304,256,21792,16464,513]

theorem envBound50109 : H12AffineFastState.Bounded env50109 := by
  intro p hp
  have h : env50109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50108_50109 : H12AffineEnvironment.transform 12 268 env50108 = env50109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50108 == env50109) = true)

theorem identity50109 : scanCanonicalize (H12AffineFastState.compose env50109 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 21793) := by decide +kernel

theorem selectedBound50109 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env50110 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,21841,263,5440,2341,1024,21840,4160,21793,16,21762,268,65,2048,5393,17665,2341,1365,21793,256,21792,16464,513]

theorem envBound50110 : H12AffineFastState.Bounded env50110 := by
  intro p hp
  have h : env50110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50109_50110 : H12AffineEnvironment.transform 21 21793 env50109 = env50110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env50109 == env50110) = true)

theorem identity50110 : scanCanonicalize (H12AffineFastState.compose env50110 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound50110 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env50111 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5457,0,263,5440,2341,1024,1,4160,112,16,83,268,65,2048,5393,4176,2341,1365,112,256,113,5377,513]

theorem envBound50111 : H12AffineFastState.Bounded env50111 := by
  intro p hp
  have h : env50111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50110_50111 : H12AffineEnvironment.transform 13 5457 env50110 = env50111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env50110 == env50111) = true)

theorem identity50111 : scanCanonicalize (H12AffineFastState.compose env50111 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50111 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50112 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,263,5393,2341,1024,1,4113,33,16,2,268,16,2048,5393,4097,2341,1284,33,256,32,5377,513]

theorem envBound50112 : H12AffineFastState.Bounded env50112 := by
  intro p hp
  have h : env50112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50111_50112 : H12AffineEnvironment.transform 5 17 env50111 = env50112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50111 == env50112) = true)

theorem identity50112 : scanCanonicalize (H12AffineFastState.compose env50112 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50112 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50113 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5156,0,35,5173,2049,1024,1,4113,33,16,2,40,16,2048,5173,4097,2049,1056,33,36,32,5157,513]

theorem envBound50113 : H12AffineFastState.Bounded env50113 := by
  intro p hp
  have h : env50113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50112_50113 : H12AffineEnvironment.transform 7 36 env50112 = env50113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50112 == env50113) = true)

theorem identity50113 : scanCanonicalize (H12AffineFastState.compose env50113 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound50113 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50114 : List Nat := [2,4,8,16,32,17,8,36,512,1024,523,4096,40,5156,0,35,5173,522,1024,1,4113,33,16,2,40,16,523,5173,4097,522,1056,33,36,32,5157,513]

theorem envBound50114 : H12AffineFastState.Bounded env50114 := by
  intro p hp
  have h : env50114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50113_50114 : H12AffineEnvironment.transform 10 523 env50113 = env50114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env50113 == env50114) = true)

theorem identity50114 : scanCanonicalize (H12AffineFastState.compose env50114 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50114 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50115 : List Nat := [2,4,8,16,0,17,8,4,512,1024,523,4096,8,5124,0,3,5141,522,1024,1,4113,1,16,2,8,16,523,5141,4097,522,1024,1,4,0,5125,513]

theorem envBound50115 : H12AffineFastState.Bounded env50115 := by
  intro p hp
  have h : env50115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50114_50115 : H12AffineEnvironment.transform 4 0 env50114 = env50115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50114 == env50115) = true)

def env50116 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,21762,8193,65,4291882,115014,17665,10281,119043,4268042,256,98679,90203,63069]

theorem envBound50116 : H12AffineFastState.Bounded env50116 := by
  intro p hp
  have h : env50116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50104_50116 : H12AffineEnvironment.transform 6 9 env50104 = env50116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50104 == env50116) = true)

theorem identity50116 : scanCanonicalize (H12AffineFastState.compose env50116 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound50116 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35188,1024,32769,4160,4194304,16,21762,8193,65,4291882,115014,17665,10281,119043,4268042,256,98679,90203,63069]

theorem envBound50117 : H12AffineFastState.Bounded env50117 := by
  intro p hp
  have h : env50117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50116_50117 : H12AffineEnvironment.transform 16 24908 env50116 = env50117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env50116 == env50117) = true)

theorem identity50117 : scanCanonicalize (H12AffineFastState.compose env50117 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound50117 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env50118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,24908,35188,1024,32769,4160,4194304,16,21762,8193,65,4229153,13389,17665,10281,9224,4248833,256,29820,38224,63069]

theorem envBound50118 : H12AffineFastState.Bounded env50118 := by
  intro p hp
  have h : env50118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50117_50118 : H12AffineEnvironment.transform 15 62731 env50117 = env50118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env50117 == env50118) = true)

theorem identity50118 : scanCanonicalize (H12AffineFastState.compose env50118 (packedSelected [1,4,8,9,12,14,19,20,38] rootPS)) = affineNative (2^(21+1) ^^^ 341) := by decide +kernel

theorem selectedBound50118 : packedSelected [1,4,8,9,12,14,19,20,38] rootPS < 2^1333 := by decide +kernel

def env50119 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,24908,35188,1024,32769,4160,341,16,21762,8193,65,35188,13389,17665,10281,9224,54356,256,29820,38224,63069]

theorem envBound50119 : H12AffineFastState.Bounded env50119 := by
  intro p hp
  have h : env50119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50118_50119 : H12AffineEnvironment.transform 21 341 env50118 = env50119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 341 env50118 == env50119) = true)

theorem identity50119 : scanCanonicalize (H12AffineFastState.compose env50119 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound50119 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env50120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,343,24908,32040,1024,29789,4160,341,16,21762,8193,65,32040,13389,17665,10281,9224,8200,256,29820,24844,513]

theorem envBound50120 : H12AffineFastState.Bounded env50120 := by
  intro p hp
  have h : env50120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50119_50120 : H12AffineEnvironment.transform 14 29788 env50119 = env50120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env50119 == env50120) = true)

theorem identity50120 : scanCanonicalize (H12AffineFastState.compose env50120 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound50120 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,9292,343,12636,11576,1024,9293,4160,341,16,1298,8193,65,11576,13389,5393,10281,9224,8200,256,9324,12572,513]

theorem envBound50121 : H12AffineFastState.Bounded env50121 := by
  intro p hp
  have h : env50121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50120_50121 : H12AffineEnvironment.transform 13 4112 env50120 = env50121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env50120 == env50121) = true)

theorem identity50121 : scanCanonicalize (H12AffineFastState.compose env50121 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50121 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env50122 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,4112,9245,262,12557,11576,1024,9244,4113,260,16,1298,8193,16,11576,13340,5393,10281,9224,8200,256,9277,12572,513]

theorem envBound50122 : H12AffineFastState.Bounded env50122 := by
  intro p hp
  have h : env50122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50121_50122 : H12AffineEnvironment.transform 5 17 env50121 = env50122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50121 == env50122) = true)

theorem identity50122 : scanCanonicalize (H12AffineFastState.compose env50122 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound50122 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50123 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,4112,1077,262,4389,3344,1024,1076,4113,260,16,1298,41,16,3344,5172,5393,2049,1056,32,256,1045,4404,513]

theorem envBound50123 : H12AffineFastState.Bounded env50123 := by
  intro p hp
  have h : env50123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50122_50123 : H12AffineEnvironment.transform 12 40 env50122 = env50123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env50122 == env50123) = true)

theorem identity50123 : scanCanonicalize (H12AffineFastState.compose env50123 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50123 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env50124 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,4112,1077,34,4097,3124,1024,1076,4113,32,16,1078,41,16,3124,5172,5173,2049,1056,32,36,1045,4112,513]

theorem envBound50124 : H12AffineFastState.Bounded env50124 := by
  intro p hp
  have h : env50124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50123_50124 : H12AffineEnvironment.transform 7 36 env50123 = env50124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50123 == env50124) = true)

theorem identity50124 : scanCanonicalize (H12AffineFastState.compose env50124 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound50124 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50125 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,17,40,1,1077,34,16,3124,1024,1076,0,32,16,1078,41,16,3124,1061,1060,2049,1056,32,36,1045,1,513]

theorem envBound50125 : H12AffineFastState.Bounded env50125 := by
  intro p hp
  have h : env50125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50124_50125 : H12AffineEnvironment.transform 11 17 env50124 = env50125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env50124 == env50125) = true)

theorem identity50125 : scanCanonicalize (H12AffineFastState.compose env50125 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound50125 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env50126 : List Nat := [2,4,2,16,32,17,3,36,512,1024,2048,17,34,1,1077,34,16,3124,1024,1076,0,32,16,1078,35,16,3124,1061,1060,2049,1056,32,36,1045,1,513]

theorem envBound50126 : H12AffineFastState.Bounded env50126 := by
  intro p hp
  have h : env50126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50125_50126 : H12AffineEnvironment.transform 2 2 env50125 = env50126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env50125 == env50126) = true)

theorem identity50126 : scanCanonicalize (H12AffineFastState.compose env50126 (packedSelected [0,1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound50126 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env50127 : List Nat := [2,4,2,16,32,17,3,36,512,1024,1573,17,34,1,1077,34,16,529,1024,1076,0,32,16,1078,35,16,529,1061,1060,1572,1056,32,36,1045,1,513]

theorem envBound50127 : H12AffineFastState.Bounded env50127 := by
  intro p hp
  have h : env50127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50126_50127 : H12AffineEnvironment.transform 10 1573 env50126 = env50127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env50126 == env50127) = true)

theorem identity50127 : scanCanonicalize (H12AffineFastState.compose env50127 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound50127 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50128 : List Nat := [2,4,2,16,32,17,3,36,512,52,529,17,34,1,1,34,16,529,52,0,0,32,16,2,35,16,529,17,16,528,20,32,36,33,1,513]

theorem envBound50128 : H12AffineFastState.Bounded env50128 := by
  intro p hp
  have h : env50128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50127_50128 : H12AffineEnvironment.transform 9 52 env50127 = env50128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50127 == env50128) = true)

theorem identity50128 : scanCanonicalize (H12AffineFastState.compose env50128 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound50128 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50129 : List Nat := [2,4,2,16,32,17,3,36,16,52,1,17,34,1,1,34,16,1,52,0,0,32,16,2,35,16,1,17,16,0,20,32,36,33,1,17]

theorem envBound50129 : H12AffineFastState.Bounded env50129 := by
  intro p hp
  have h : env50129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50128_50129 : H12AffineEnvironment.transform 8 16 env50128 = env50129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env50128 == env50129) = true)

def env50130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,17,21763,8328,65,4291882,115151,17665,10280,119043,4268163,256,98815,90202,63188]

theorem envBound50130 : H12AffineFastState.Bounded env50130 := by
  intro p hp
  have h : env50130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50103_50130 : H12AffineEnvironment.transform 20 4161 env50103 = env50130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50103 == env50130) = true)

theorem identity50130 : scanCanonicalize (H12AffineFastState.compose env50130 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180408) := by decide +kernel

theorem selectedBound50130 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,180408,17,21763,8328,65,245138,115151,17665,10280,119043,254011,256,98815,90202,63188]

theorem envBound50131 : H12AffineFastState.Bounded env50131 := by
  intro p hp
  have h : env50131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50130_50131 : H12AffineEnvironment.transform 21 180408 env50130 = env50131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env50130 == env50131) = true)

def env50132 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,180272,17,21763,8192,65,245018,115015,17665,10280,119043,254011,256,98679,90202,63068]

theorem envBound50132 : H12AffineFastState.Bounded env50132 := by
  intro p hp
  have h : env50132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50131_50132 : H12AffineEnvironment.transform 6 8 env50131 = env50132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50131 == env50132) = true)

theorem identity50132 : scanCanonicalize (H12AffineFastState.compose env50132 (packedSelected [7,8,10,11,12,14,15,20,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 82198) := by decide +kernel

theorem selectedBound50132 : packedSelected [7,8,10,11,12,14,15,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env50133 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82198,108846,1024,32769,4161,98598,17,21763,8192,65,64524,115015,17665,10280,119043,41261,256,98679,90202,63068]

theorem envBound50133 : H12AffineFastState.Bounded env50133 := by
  intro p hp
  have h : env50133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50132_50133 : H12AffineEnvironment.transform 16 82198 env50132 = env50133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82198 env50132 == env50133) = true)

theorem identity50133 : scanCanonicalize (H12AffineFastState.compose env50133 (packedSelected [0,1,3,9,14,16,18,19,20,22,23,24,26,27,28,35] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound50133 : packedSelected [0,1,3,9,14,16,18,19,20,22,23,24,26,27,28,35] rootPS < 2^1333 := by decide +kernel

def env50134 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,30042,13388,56436,1024,32769,4161,62588,17,21763,8192,65,64524,46109,17665,10280,42073,41261,256,62509,5376,63068]

theorem envBound50134 : H12AffineFastState.Bounded env50134 := by
  intro p hp
  have h : env50134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50133_50134 : H12AffineEnvironment.transform 15 30042 env50133 = env50134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env50133 == env50134) = true)

theorem identity50134 : scanCanonicalize (H12AffineFastState.compose env50134 (packedSelected [4,10,14,15,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound50134 : packedSelected [4,10,14,15,18,19,22] rootPS < 2^1333 := by decide +kernel

def env50135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,30042,13388,2420,1024,21761,4161,8572,17,21763,8192,65,10508,24861,17665,10280,29017,29741,256,8493,5376,9052]

theorem envBound50135 : H12AffineFastState.Bounded env50135 := by
  intro p hp
  have h : env50135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50134_50135 : H12AffineEnvironment.transform 14 21760 env50134 = env50135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env50134 == env50135) = true)

def env50136 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,180273,17,21763,8193,65,245019,115014,17665,10280,119043,254011,256,98678,90202,63069]

theorem envBound50136 : H12AffineFastState.Bounded env50136 := by
  intro p hp
  have h : env50136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50131_50136 : H12AffineEnvironment.transform 6 9 env50131 = env50136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50131 == env50136) = true)

theorem identity50136 : scanCanonicalize (H12AffineFastState.compose env50136 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50136 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50137 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,149860,1024,8541,4161,156013,17,21763,8193,65,203847,90138,17665,10280,94303,213351,256,73770,90202,22273]

theorem envBound50137 : H12AffineFastState.Bounded env50137 := by
  intro p hp
  have h : env50137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50136_50137 : H12AffineEnvironment.transform 14 8540 env50136 = env50137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50136 == env50137) = true)

theorem identity50137 : scanCanonicalize (H12AffineFastState.compose env50137 (packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound50137 : packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env50138 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,21591,131072,149860,1024,8541,4161,156013,17,21763,8193,65,149520,13389,17665,10280,9224,136496,256,29821,13325,22273]

theorem envBound50138 : H12AffineFastState.Bounded env50138 := by
  intro p hp
  have h : env50138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50137_50138 : H12AffineEnvironment.transform 15 21591 env50137 = env50138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env50137 == env50138) = true)

theorem identity50138 : scanCanonicalize (H12AffineFastState.compose env50138 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound50138 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env50139 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,21591,24908,10280,1024,8541,4161,33,17,21763,8193,65,10588,13389,17665,10280,9224,29820,256,29821,13325,22273]

theorem envBound50139 : H12AffineFastState.Bounded env50139 := by
  intro p hp
  have h : env50139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50138_50139 : H12AffineEnvironment.transform 16 24908 env50138 = env50139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env50138 == env50139) = true)

theorem identity50139 : scanCanonicalize (H12AffineFastState.compose env50139 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound50139 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env50140 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,8540,9499,4096,10280,1024,8541,4161,33,17,9295,8193,65,10588,13389,13389,10280,9224,1328,256,1329,13325,9805]

theorem envBound50140 : H12AffineFastState.Bounded env50140 := by
  intro p hp
  have h : env50140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50139_50140 : H12AffineEnvironment.transform 13 12620 env50139 = env50140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env50139 == env50140) = true)

theorem identity50140 : scanCanonicalize (H12AffineFastState.compose env50140 (packedSelected [11,18] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound50140 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env50141 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,5157,1077,114,4096,3393,1024,1076,4161,33,17,294,1384,65,3125,4388,4388,3393,353,1328,256,1329,4452,804]

theorem envBound50141 : H12AffineFastState.Bounded env50141 := by
  intro p hp
  have h : env50141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50140_50141 : H12AffineEnvironment.transform 12 1385 env50140 = env50141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env50140 == env50141) = true)

theorem identity50141 : scanCanonicalize (H12AffineFastState.compose env50141 (packedSelected [0,4,7,9,11,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound50141 : packedSelected [0,4,7,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env50142 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,348,4112,0,114,4096,2420,53,1,4161,33,17,294,349,65,2048,4388,4388,2420,353,261,256,260,4452,804]

theorem envBound50142 : H12AffineFastState.Bounded env50142 := by
  intro p hp
  have h : env50142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50141_50142 : H12AffineEnvironment.transform 9 53 env50141 = env50142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50141 == env50142) = true)

theorem identity50142 : scanCanonicalize (H12AffineFastState.compose env50142 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50142 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50143 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,121,4112,0,114,4096,2129,53,1,4161,33,17,3,120,65,2048,4097,4097,2129,68,32,37,33,4161,513]

theorem envBound50143 : H12AffineFastState.Bounded env50143 := by
  intro p hp
  have h : env50143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50142_50143 : H12AffineEnvironment.transform 7 37 env50142 = env50143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50142 == env50143) = true)

theorem identity50143 : scanCanonicalize (H12AffineFastState.compose env50143 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50143 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50144 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,41,4112,0,34,4096,2049,53,1,4113,33,17,3,40,17,2048,4097,4097,2049,20,32,37,33,4113,513]

theorem envBound50144 : H12AffineFastState.Bounded env50144 := by
  intro p hp
  have h : env50144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50143_50144 : H12AffineEnvironment.transform 5 16 env50143 = env50144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50143 == env50144) = true)

def env50145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,2101329,2114882,8328,65,4291883,115151,17664,2111592,119042,4268163,256,2199999,2191386,63189]

theorem envBound50145 : H12AffineFastState.Bounded env50145 := by
  intro p hp
  have h : env50145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50102_50145 : H12AffineEnvironment.transform 22 2101329 env50102 = env50145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env50102 == env50145) = true)

def env50146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,17,21762,8328,65,4291883,115151,17664,10280,119042,4268163,256,98815,90202,63189]

theorem envBound50146 : H12AffineFastState.Bounded env50146 := by
  intro p hp
  have h : env50146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50145_50146 : H12AffineEnvironment.transform 20 4160 env50145 = env50146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50145 == env50146) = true)

theorem identity50146 : scanCanonicalize (H12AffineFastState.compose env50146 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144492) := by decide +kernel

theorem selectedBound50146 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,144492,17,21762,8328,65,215367,115151,17664,10280,119042,201967,256,98815,90202,63189]

theorem envBound50147 : H12AffineFastState.Bounded env50147 := by
  intro p hp
  have h : env50147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50146_50147 : H12AffineEnvironment.transform 21 144492 env50146 = env50147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144492 env50146 == env50147) = true)

def env50148 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,144492,17,21762,8192,65,215367,115015,17664,10280,119042,201831,256,98679,90202,63069]

theorem envBound50148 : H12AffineFastState.Bounded env50148 := by
  intro p hp
  have h : env50148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50147_50148 : H12AffineEnvironment.transform 6 8 env50147 = env50148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50147 == env50148) = true)

theorem identity50148 : scanCanonicalize (H12AffineFastState.compose env50148 (packedSelected [1,3,7,8,11,12,14,15,19,20,24,26,27,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound50148 : packedSelected [1,3,7,8,11,12,14,15,19,20,24,26,27,31,32] rootPS < 2^1333 := by decide +kernel

def env50149 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33031,131072,190520,1024,32769,4160,144492,17,21762,8192,65,182336,16448,17664,10280,20485,169312,256,112,57693,63069]

theorem envBound50149 : H12AffineFastState.Bounded env50149 := by
  intro p hp
  have h : env50149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50148_50149 : H12AffineEnvironment.transform 15 33031 env50148 = env50149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env50148 == env50149) = true)

theorem identity50149 : scanCanonicalize (H12AffineFastState.compose env50149 (packedSelected [0,1,3,4,7,10,18,19,22,23,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 49216) := by decide +kernel

theorem selectedBound50149 : packedSelected [0,1,3,4,7,10,18,19,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env50150 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33031,49216,10360,1024,32769,4160,62508,17,21762,8192,65,2048,16448,17664,10280,20485,21792,256,112,57693,63069]

theorem envBound50150 : H12AffineFastState.Bounded env50150 := by
  intro p hp
  have h : env50150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50149_50150 : H12AffineEnvironment.transform 16 49216 env50149 = env50150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49216 env50149 == env50150) = true)

theorem identity50150 : scanCanonicalize (H12AffineFastState.compose env50150 (packedSelected [0,5,7,9,12,14,15,19,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound50150 : packedSelected [0,5,7,9,12,14,15,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env50151 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,21591,5392,10360,1024,21841,4160,8572,17,21762,8192,65,2048,16448,17664,10280,20485,21792,256,112,13325,8973]

theorem envBound50151 : H12AffineFastState.Bounded env50151 := by
  intro p hp
  have h : env50151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50150_50151 : H12AffineEnvironment.transform 14 21840 env50150 = env50151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env50150 == env50151) = true)

theorem identity50151 : scanCanonicalize (H12AffineFastState.compose env50151 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50151 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env50152 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21840,21591,5392,2421,1024,21841,4160,113,17,21762,269,65,2048,16448,17664,2341,20485,21792,256,112,5376,512]

theorem envBound50152 : H12AffineFastState.Bounded env50152 := by
  intro p hp
  have h : env50152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50151_50152 : H12AffineEnvironment.transform 12 269 env50151 = env50152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50151 == env50152) = true)

theorem identity50152 : scanCanonicalize (H12AffineFastState.compose env50152 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4421) := by decide +kernel

theorem selectedBound50152 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50153 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,4421,1045,1298,5392,2421,1024,1044,4160,113,17,1095,269,65,2048,4357,5189,2341,320,1125,256,112,5376,512]

theorem envBound50153 : H12AffineFastState.Bounded env50153 := by
  intro p hp
  have h : env50153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50152_50153 : H12AffineEnvironment.transform 13 4421 env50152 = env50153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4421 env50152 == env50153) = true)

theorem identity50153 : scanCanonicalize (H12AffineFastState.compose env50153 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound50153 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env50154 : List Nat := [2,4,8,16,32,64,8,256,512,304,2048,4096,269,4421,293,34,4128,2421,304,292,4160,113,17,375,269,65,2048,4357,4469,2341,320,341,256,112,4144,512]

theorem envBound50154 : H12AffineFastState.Bounded env50154 := by
  intro p hp
  have h : env50154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50153_50154 : H12AffineEnvironment.transform 9 304 env50153 = env50154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env50153 == env50154) = true)

theorem identity50154 : scanCanonicalize (H12AffineFastState.compose env50154 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50154 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env50155 : List Nat := [2,4,8,16,32,64,8,37,512,21,2048,4096,40,4192,0,34,4128,2128,21,1,4160,113,17,82,40,65,2048,4128,4176,2048,101,112,37,112,4144,512]

theorem envBound50155 : H12AffineFastState.Bounded env50155 := by
  intro p hp
  have h : env50155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50154_50155 : H12AffineEnvironment.transform 7 37 env50154 = env50155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50154 == env50155) = true)

theorem identity50155 : scanCanonicalize (H12AffineFastState.compose env50155 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound50155 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env50156 : List Nat := [2,4,8,16,32,64,8,37,512,21,2048,2065,40,2161,0,34,2097,2128,21,1,2129,113,17,82,40,65,2048,2097,2113,2048,101,112,37,112,2081,512]

theorem envBound50156 : H12AffineFastState.Bounded env50156 := by
  intro p hp
  have h : env50156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1