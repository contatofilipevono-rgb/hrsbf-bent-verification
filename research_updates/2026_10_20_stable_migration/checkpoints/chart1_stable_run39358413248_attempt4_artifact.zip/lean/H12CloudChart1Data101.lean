import H12CloudChart1Data100

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env25586 : List Nat := [1,4,8,16,32,16,8,37,512,20,552,537,40,552,1,32,568,552,20,0,520,32,16,1,40,17,552,569,537,552,53,33,37,32,552,512]

theorem envBound25586 : H12AffineFastState.Bounded env25586 := by
  intro p hp
  have h : env25586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25585_25586 : H12AffineEnvironment.transform 0 1 env25585 = env25586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env25585 == env25586) = true)

theorem identity25586 : scanCanonicalize (H12AffineFastState.compose env25586 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25586 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25587 : List Nat := [1,4,8,16,1,16,8,4,512,20,521,537,9,521,1,1,537,521,20,0,520,1,16,1,9,17,521,536,537,521,20,0,4,1,521,512]

theorem envBound25587 : H12AffineFastState.Bounded env25587 := by
  intro p hp
  have h : env25587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25586_25587 : H12AffineEnvironment.transform 4 1 env25586 = env25587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25586 == env25587) = true)

theorem identity25587 : scanCanonicalize (H12AffineFastState.compose env25587 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25587 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25588 : List Nat := [1,0,8,16,1,16,8,0,512,16,521,537,9,521,1,1,537,521,16,0,520,1,16,1,9,17,521,536,537,521,16,0,0,1,521,512]

theorem envBound25588 : H12AffineFastState.Bounded env25588 := by
  intro p hp
  have h : env25588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25587_25588 : H12AffineEnvironment.transform 1 0 env25587 = env25588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25587 == env25588) = true)

def env25589 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,115735,156012,16,95497,8193,65,245019,79130,102742,108927,61704,243002,256,95531,103430,120406]

theorem envBound25589 : H12AffineFastState.Bounded env25589 := by
  intro p hp
  have h : env25589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25574_25589 : H12AffineEnvironment.transform 6 9 env25574 = env25589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25574 == env25589) = true)

theorem identity25589 : scanCanonicalize (H12AffineFastState.compose env25589 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound25589 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25590 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,89379,1024,32769,115735,21793,16,95497,8193,65,100694,79130,102742,108927,61704,98679,256,95531,103430,120406]

theorem envBound25590 : H12AffineFastState.Bounded env25590 := by
  intro p hp
  have h : env25590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25589_25590 : H12AffineEnvironment.transform 16 13389 env25589 = env25590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env25589 == env25590) = true)

theorem identity25590 : scanCanonicalize (H12AffineFastState.compose env25590 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound25590 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env25591 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,13389,2421,1024,32769,36929,21793,16,8543,8193,65,56576,24908,50432,64809,61704,54561,256,8573,49232,33280]

theorem envBound25591 : H12AffineFastState.Bounded env25591 := by
  intro p hp
  have h : env25591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25590_25591 : H12AffineEnvironment.transform 15 21590 env25590 = env25591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env25590 == env25591) = true)

theorem identity25591 : scanCanonicalize (H12AffineFastState.compose env25591 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound25591 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env25592 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,21590,5393,2421,1024,32769,36929,21793,16,3,349,65,56576,16400,50432,56437,53332,54561,256,33,49232,33280]

theorem envBound25592 : H12AffineFastState.Bounded env25592 := by
  intro p hp
  have h : env25592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25591_25592 : H12AffineEnvironment.transform 12 348 env25591 = env25592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env25591 == env25592) = true)

theorem identity25592 : scanCanonicalize (H12AffineFastState.compose env25592 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound25592 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env25593 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,32768,21590,5220,2048,1024,32769,36929,21588,16,3,40,65,56437,16400,50293,56437,53332,54356,117,33,49232,33280]

theorem envBound25593 : H12AffineFastState.Bounded env25593 := by
  intro p hp
  have h : env25593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25592_25593 : H12AffineEnvironment.transform 7 117 env25592 = env25593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env25592 == env25593) = true)

theorem identity25593 : scanCanonicalize (H12AffineFastState.compose env25593 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound25593 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env25594 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,21620,21590,5220,2048,1024,21621,17461,21588,16,3,40,65,2049,16400,4097,2049,1056,32,117,33,5156,22132]

theorem envBound25594 : H12AffineFastState.Bounded env25594 := by
  intro p hp
  have h : env25594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25593_25594 : H12AffineEnvironment.transform 14 21620 env25593 = env25594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env25593 == env25594) = true)

theorem identity25594 : scanCanonicalize (H12AffineFastState.compose env25594 (packedSelected [4,6,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound25594 : packedSelected [4,6,9,12] rootPS < 2^1333 := by decide +kernel

def env25595 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,0,34,5220,2048,1024,1,4161,32,16,3,40,65,2049,5220,4097,2049,1056,32,117,33,5156,512]

theorem envBound25595 : H12AffineFastState.Bounded env25595 := by
  intro p hp
  have h : env25595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25594_25595 : H12AffineEnvironment.transform 13 5236 env25594 = env25595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env25594 == env25595) = true)

theorem identity25595 : scanCanonicalize (H12AffineFastState.compose env25595 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound25595 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25596 : List Nat := [2,4,8,16,32,64,9,117,512,1024,555,4096,41,5236,0,34,5220,555,1024,1,4161,32,16,3,40,65,554,5220,4097,554,1056,32,117,33,5156,512]

theorem envBound25596 : H12AffineFastState.Bounded env25596 := by
  intro p hp
  have h : env25596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25595_25596 : H12AffineEnvironment.transform 10 555 env25595 = env25596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env25595 == env25596) = true)

theorem identity25596 : scanCanonicalize (H12AffineFastState.compose env25596 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound25596 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25597 : List Nat := [2,4,8,16,32,48,9,5,512,1024,555,4096,41,5124,0,34,5140,555,1024,1,4145,32,16,3,40,49,554,5140,4097,554,1056,32,5,33,5156,512]

theorem envBound25597 : H12AffineFastState.Bounded env25597 := by
  intro p hp
  have h : env25597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25596_25597 : H12AffineEnvironment.transform 5 48 env25596 = env25597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env25596 == env25597) = true)

theorem identity25597 : scanCanonicalize (H12AffineFastState.compose env25597 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25597 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25598 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,4096,8,5124,0,3,5140,522,1024,1,4112,1,16,3,9,16,523,5140,4097,523,1025,1,5,0,5125,512]

theorem envBound25598 : H12AffineFastState.Bounded env25598 := by
  intro p hp
  have h : env25598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25597_25598 : H12AffineEnvironment.transform 4 1 env25597 = env25598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25597 == env25598) = true)

def env25599 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,16,8,1044,0,3,1028,522,1024,1,0,1,16,3,9,16,523,1028,17,523,1025,1,5,0,1045,512]

theorem envBound25599 : H12AffineFastState.Bounded env25599 := by
  intro p hp
  have h : env25599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25598_25599 : H12AffineEnvironment.transform 11 16 env25598 = env25599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env25598 == env25599) = true)

theorem identity25599 : scanCanonicalize (H12AffineFastState.compose env25599 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound25599 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25600 : List Nat := [2,4,8,16,1,17,9,5,512,0,522,16,8,20,0,3,4,522,0,1,0,1,16,3,9,16,523,4,17,523,1,1,5,0,21,512]

theorem envBound25600 : H12AffineFastState.Bounded env25600 := by
  intro p hp
  have h : env25600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25599_25600 : H12AffineEnvironment.transform 9 0 env25599 = env25600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env25599 == env25600) = true)

def env25601 : List Nat := [2,4,8,4,1,5,9,5,512,0,522,4,8,0,0,3,4,522,0,1,0,1,4,3,9,4,523,4,5,523,1,1,5,0,1,512]

theorem envBound25601 : H12AffineFastState.Bounded env25601 := by
  intro p hp
  have h : env25601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25600_25601 : H12AffineEnvironment.transform 3 4 env25600 = env25601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env25600 == env25601) = true)

theorem identity25601 : scanCanonicalize (H12AffineFastState.compose env25601 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound25601 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25602 : List Nat := [2,4,8,4,1,5,9,5,8,0,2,4,8,0,0,3,4,2,0,1,0,1,4,3,9,4,3,4,5,3,1,1,5,0,1,8]

theorem envBound25602 : H12AffineFastState.Bounded env25602 := by
  intro p hp
  have h : env25602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25601_25602 : H12AffineEnvironment.transform 8 8 env25601 = env25602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env25601 == env25602) = true)

def leafEnv25602 : List Nat := [2,4,8,4,1,5,9,5,8,0,2,4,8,0,0,3,4,2,0,1,0,1,4,3,0,9,1,4,3,4,5,3,1,1,5,0,5,2,1,8,1,1,0]

def active25602 : List Nat := [0,1,2]

def tree25602 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25602 : H12WitnessSearch.Good tree25602 := H12GlobalWitnessIndex.good

theorem leafIdentity25602 : H12AffineFastState.composeSystem env25602 rootObs = leafEnv25602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25602 rootObs == leafEnv25602) = true)

theorem terminalChecked25602 : H12PackedTerminal.terminalCheckFast leafEnv25602 active25602 tree25602 = true := by decide +kernel

def env25603 : List Nat := [2,4,8,5,1,4,9,5,512,0,522,5,8,1,0,3,4,522,0,1,0,1,5,3,9,5,523,4,4,523,1,1,5,0,0,512]

theorem envBound25603 : H12AffineFastState.Bounded env25603 := by
  intro p hp
  have h : env25603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25600_25603 : H12AffineEnvironment.transform 3 5 env25600 = env25603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env25600 == env25603) = true)

theorem identity25603 : scanCanonicalize (H12AffineFastState.compose env25603 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound25603 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25604 : List Nat := [1,4,8,5,1,4,9,5,512,0,521,5,8,1,0,0,4,521,0,1,0,1,5,0,9,5,520,4,4,520,1,1,5,0,0,512]

theorem envBound25604 : H12AffineFastState.Bounded env25604 := by
  intro p hp
  have h : env25604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25603_25604 : H12AffineEnvironment.transform 0 1 env25603 = env25604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env25603 == env25604) = true)

def leafEnv25604 : List Nat := [1,4,8,5,1,4,9,5,512,0,521,5,8,1,0,0,4,521,0,1,0,1,5,0,0,9,1,5,520,4,4,520,1,1,5,0,5,1,0,512,1,1,0]

def active25604 : List Nat := [1,2,8]

def tree25604 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25604 : H12WitnessSearch.Good tree25604 := H12GlobalWitnessIndex.good

theorem leafIdentity25604 : H12AffineFastState.composeSystem env25604 rootObs = leafEnv25604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25604 rootObs == leafEnv25604) = true)

theorem terminalChecked25604 : H12PackedTerminal.terminalCheckFast leafEnv25604 active25604 tree25604 = true := by decide +kernel

def env25605 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,17,8,1045,0,3,1029,522,1024,1,1,1,16,3,9,16,523,1029,16,523,1025,1,5,0,1044,512]

theorem envBound25605 : H12AffineFastState.Bounded env25605 := by
  intro p hp
  have h : env25605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25598_25605 : H12AffineEnvironment.transform 11 17 env25598 = env25605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env25598 == env25605) = true)

theorem identity25605 : scanCanonicalize (H12AffineFastState.compose env25605 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound25605 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25606 : List Nat := [2,4,8,4,1,5,9,5,512,1024,522,5,8,1025,0,3,1029,522,1024,1,1,1,4,3,9,4,523,1029,4,523,1025,1,5,0,1024,512]

theorem envBound25606 : H12AffineFastState.Bounded env25606 := by
  intro p hp
  have h : env25606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25605_25606 : H12AffineEnvironment.transform 3 4 env25605 = env25606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env25605 == env25606) = true)

def env25607 : List Nat := [2,4,8,4,1,5,9,5,512,0,522,5,8,1,0,3,5,522,0,1,1,1,4,3,9,4,523,5,4,523,1,1,5,0,0,512]

theorem envBound25607 : H12AffineFastState.Bounded env25607 := by
  intro p hp
  have h : env25607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25606_25607 : H12AffineEnvironment.transform 9 0 env25606 = env25607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env25606 == env25607) = true)

theorem identity25607 : scanCanonicalize (H12AffineFastState.compose env25607 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound25607 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25608 : List Nat := [2,4,8,4,1,5,9,5,9,0,3,5,8,1,0,3,5,3,0,1,1,1,4,3,9,4,2,5,4,2,1,1,5,0,0,9]

theorem envBound25608 : H12AffineFastState.Bounded env25608 := by
  intro p hp
  have h : env25608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25607_25608 : H12AffineEnvironment.transform 8 9 env25607 = env25608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env25607 == env25608) = true)

def leafEnv25608 : List Nat := [2,4,8,4,1,5,9,5,9,0,3,5,8,1,0,3,5,3,0,1,1,1,4,3,0,9,1,4,2,5,4,2,1,1,5,0,5,2,0,9,1,0,0]

def active25608 : List Nat := [0,1,2]

def tree25608 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25608 : H12WitnessSearch.Good tree25608 := H12GlobalWitnessIndex.good

theorem leafIdentity25608 : H12AffineFastState.composeSystem env25608 rootObs = leafEnv25608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25608 rootObs == leafEnv25608) = true)

theorem terminalChecked25608 : H12PackedTerminal.terminalCheckFast leafEnv25608 active25608 tree25608 = true := by decide +kernel

def env25609 : List Nat := [2,4,8,4,1,5,9,5,512,1,522,5,8,0,0,3,4,522,1,1,1,1,4,3,9,4,523,4,4,523,0,1,5,0,1,512]

theorem envBound25609 : H12AffineFastState.Bounded env25609 := by
  intro p hp
  have h : env25609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25606_25609 : H12AffineEnvironment.transform 9 1 env25606 = env25609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env25606 == env25609) = true)

theorem identity25609 : scanCanonicalize (H12AffineFastState.compose env25609 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound25609 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25610 : List Nat := [1,4,8,4,1,5,9,5,512,1,521,5,8,0,0,0,4,521,1,1,1,1,4,0,9,4,520,4,4,520,0,1,5,0,1,512]

theorem envBound25610 : H12AffineFastState.Bounded env25610 := by
  intro p hp
  have h : env25610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25609_25610 : H12AffineEnvironment.transform 0 1 env25609 = env25610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env25609 == env25610) = true)

def leafEnv25610 : List Nat := [1,4,8,4,1,5,9,5,512,1,521,5,8,0,0,0,4,521,1,1,1,1,4,0,1,9,1,4,520,4,4,520,0,1,5,0,5,1,1,512,1,0,0]

def active25610 : List Nat := [1,2,8]

def tree25610 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25610 : H12WitnessSearch.Good tree25610 := H12GlobalWitnessIndex.good

theorem leafIdentity25610 : H12AffineFastState.composeSystem env25610 rootObs = leafEnv25610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25610 rootObs == leafEnv25610) = true)

theorem terminalChecked25610 : H12PackedTerminal.terminalCheckFast leafEnv25610 active25610 tree25610 = true := by decide +kernel

def env25611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,156133,485758,16777216,8328,65,16959643,17246588,102878,108927,17231215,17148373,256,16777251,16834951,17287864]

theorem envBound25611 : H12AffineFastState.Bounded env25611 := by
  intro p hp
  have h : env25611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25541_25611 : H12AffineEnvironment.transform 20 437745 env25541 = env25611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437745 env25541 == env25611) = true)

theorem identity25611 : scanCanonicalize (H12AffineFastState.compose env25611 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 362664) := by decide +kernel

theorem selectedBound25611 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env25612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,156133,485758,362664,8328,65,475187,172500,102878,108927,222663,8573,256,362635,354607,147984]

theorem envBound25612 : H12AffineFastState.Bounded env25612 := by
  intro p hp
  have h : env25612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25611_25612 : H12AffineEnvironment.transform 23 362664 env25611 = env25612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 362664 env25611 == env25612) = true)

def env25613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,64928,1024,32769,151633,156133,234718,95496,8328,65,245139,172500,102878,108927,222663,8573,256,95531,103567,147984]

theorem envBound25613 : H12AffineFastState.Bounded env25613 := by
  intro p hp
  have h : env25613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25612_25613 : H12AffineEnvironment.transform 17 64928 env25612 = env25613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64928 env25612 == env25613) = true)

theorem identity25613 : scanCanonicalize (H12AffineFastState.compose env25613 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound25613 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,64928,1024,32769,77898,66046,62661,95496,8328,65,56712,115151,102878,108927,1500,8573,256,95531,103567,74251]

theorem envBound25614 : H12AffineFastState.Bounded env25614 := by
  intro p hp
  have h : env25614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25613_25614 : H12AffineEnvironment.transform 16 90139 env25613 = env25614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env25613 == env25614) = true)

theorem identity25614 : scanCanonicalize (H12AffineFastState.compose env25614 (packedSelected [1,3,4,5,7,8,9,10,15,16,17,20,26,27,38] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound25614 : packedSelected [1,3,4,5,7,8,9,10,15,16,17,20,26,27,38] rootPS < 2^1333 := by decide +kernel

def env25615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,32768,65536,79179,43248,1024,32769,77898,66046,41365,73816,8328,65,35032,103583,102878,108927,1500,8573,256,73851,103567,74251]

theorem envBound25615 : H12AffineFastState.Bounded env25615 := by
  intro p hp
  have h : env25615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25614_25615 : H12AffineEnvironment.transform 13 5456 env25614 = env25615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env25614 == env25615) = true)

theorem identity25615 : scanCanonicalize (H12AffineFastState.compose env25615 (packedSelected [0,4,7,17,18,19,22,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound25615 : packedSelected [0,4,7,17,18,19,22,23,26] rootPS < 2^1333 := by decide +kernel

def env25616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8540,65536,79179,2476,1024,8541,77898,66046,201,73816,8328,65,10628,79299,77954,67619,1500,8573,256,73851,79315,74251]

theorem envBound25616 : H12AffineFastState.Bounded env25616 := by
  intro p hp
  have h : env25616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25615_25616 : H12AffineEnvironment.transform 14 8540 env25615 = env25616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env25615 == env25616) = true)

theorem identity25616 : scanCanonicalize (H12AffineFastState.compose env25616 (packedSelected [10,11,12,14,15,16,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8403) := by decide +kernel

theorem selectedBound25616 : packedSelected [10,11,12,14,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env25617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8540,8403,5528,2476,1024,8541,4249,8493,201,139,8328,65,10628,5392,4177,10480,1500,8573,256,168,5376,728]

theorem envBound25617 : H12AffineFastState.Bounded env25617 := by
  intro p hp
  have h : env25617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25616_25617 : H12AffineEnvironment.transform 15 8403 env25616 = env25617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8403 env25616 == env25617) = true)

theorem identity25617 : scanCanonicalize (H12AffineFastState.compose env25617 (packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound25617 : packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env25618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5456,136,263,5528,2476,1024,137,4249,249,201,139,348,65,2128,5392,4177,2340,1500,169,256,168,5376,728]

theorem envBound25618 : H12AffineFastState.Bounded env25618 := by
  intro p hp
  have h : env25618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25617_25618 : H12AffineEnvironment.transform 12 468 env25617 = env25618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env25617 == env25618) = true)

theorem identity25618 : scanCanonicalize (H12AffineFastState.compose env25618 (packedSelected [0,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound25618 : packedSelected [0,7,10,11] rootPS < 2^1333 := by decide +kernel

def env25619 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,468,4541,136,263,4469,2476,237,137,4249,249,201,139,348,65,2128,4605,4177,2340,305,169,256,168,4589,728]

theorem envBound25619 : H12AffineFastState.Bounded env25619 := by
  intro p hp
  have h : env25619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25618_25619 : H12AffineEnvironment.transform 9 237 env25618 = env25619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env25618 == env25619) = true)

theorem identity25619 : scanCanonicalize (H12AffineFastState.compose env25619 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25619 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env25620 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,349,4404,1,263,4469,2341,100,0,4112,112,64,2,348,65,2128,4468,4177,2340,305,32,256,33,4452,593]

theorem envBound25620 : H12AffineFastState.Bounded env25620 := by
  intro p hp
  have h : env25620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25619_25620 : H12AffineEnvironment.transform 6 9 env25619 = env25620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25619 == env25620) = true)

theorem identity25620 : scanCanonicalize (H12AffineFastState.compose env25620 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25620 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25621 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,4096,121,4112,1,35,4177,2049,100,0,4112,112,64,2,120,65,2128,4176,4177,2048,21,32,36,33,4160,593]

theorem envBound25621 : H12AffineFastState.Bounded env25621 := by
  intro p hp
  have h : env25621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25620_25621 : H12AffineEnvironment.transform 7 36 env25620 = env25621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25620 == env25621) = true)

theorem identity25621 : scanCanonicalize (H12AffineFastState.compose env25621 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25621 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env25622 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,4096,41,4112,1,35,4097,2049,52,0,4112,32,16,2,40,17,2048,4096,4097,2048,21,32,36,33,4112,513]

theorem envBound25622 : H12AffineFastState.Bounded env25622 := by
  intro p hp
  have h : env25622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25621_25622 : H12AffineEnvironment.transform 5 16 env25621 = env25622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25621 == env25622) = true)

theorem identity25622 : scanCanonicalize (H12AffineFastState.compose env25622 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound25622 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25623 : List Nat := [2,4,8,16,32,16,9,36,512,52,17,4096,41,4112,1,35,4097,16,52,0,4112,32,16,2,40,17,17,4096,4097,17,21,32,36,33,4112,513]

theorem envBound25623 : H12AffineFastState.Bounded env25623 := by
  intro p hp
  have h : env25623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25622_25623 : H12AffineEnvironment.transform 10 17 env25622 = env25623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env25622 == env25623) = true)

theorem identity25623 : scanCanonicalize (H12AffineFastState.compose env25623 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound25623 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25624 : List Nat := [2,4,8,16,32,16,9,36,11,52,17,4096,41,4112,1,35,4097,16,52,0,4112,32,16,2,40,17,17,4096,4097,17,21,32,36,33,4112,10]

theorem envBound25624 : H12AffineFastState.Bounded env25624 := by
  intro p hp
  have h : env25624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25623_25624 : H12AffineEnvironment.transform 8 11 env25623 = env25624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env25623 == env25624) = true)

theorem identity25624 : scanCanonicalize (H12AffineFastState.compose env25624 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound25624 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25625 : List Nat := [2,4,8,16,32,16,9,36,11,52,17,16,41,0,1,35,17,16,52,0,0,32,16,2,40,17,17,16,17,17,21,32,36,33,0,10]

theorem envBound25625 : H12AffineFastState.Bounded env25625 := by
  intro p hp
  have h : env25625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25624_25625 : H12AffineEnvironment.transform 11 16 env25624 = env25625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env25624 == env25625) = true)

def env25626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,64929,1024,32769,151632,156133,234719,95497,8328,65,245138,172500,102878,108927,222663,8573,256,95530,103566,147984]

theorem envBound25626 : H12AffineFastState.Bounded env25626 := by
  intro p hp
  have h : env25626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25612_25626 : H12AffineEnvironment.transform 17 64929 env25612 = env25626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64929 env25612 == env25626) = true)

theorem identity25626 : scanCanonicalize (H12AffineFastState.compose env25626 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound25626 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,64929,1024,32769,151632,156133,177365,21763,8328,65,171416,172500,45524,35189,148941,8573,256,21792,46212,147984]

theorem envBound25627 : H12AffineFastState.Bounded env25627 := by
  intro p hp
  have h : env25627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25626_25627 : H12AffineEnvironment.transform 15 8202 env25626 = env25627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env25626 == env25627) = true)

theorem identity25627 : scanCanonicalize (H12AffineFastState.compose env25627 (packedSelected [0,1,5,8,9,15,17,22,24,27,38] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound25627 : packedSelected [0,1,5,8,9,15,17,22,24,27,38] rootPS < 2^1333 := by decide +kernel

def env25628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,32768,8202,131072,43248,1024,32769,132353,144564,177365,82,8328,65,171416,172500,45524,35189,135324,8573,256,113,46212,137025]

theorem envBound25628 : H12AffineFastState.Bounded env25628 := by
  intro p hp
  have h : env25628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25627_25628 : H12AffineEnvironment.transform 13 5457 env25627 = env25628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env25627 == env25628) = true)

theorem identity25628 : scanCanonicalize (H12AffineFastState.compose env25628 (packedSelected [16,17,18,19,20,23,26] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound25628 : packedSelected [16,17,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env25629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,32768,8202,46108,43248,1024,32769,45341,32936,201,82,8328,65,10628,5576,45524,35189,42112,8573,256,113,46212,41821]

theorem envBound25629 : H12AffineFastState.Bounded env25629 := by
  intro p hp
  have h : env25629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25628_25629 : H12AffineEnvironment.transform 16 46108 env25628 = env25629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env25628 == env25629) = true)

theorem identity25629 : scanCanonicalize (H12AffineFastState.compose env25629 (packedSelected [0,1,3,5,7,8,9,11,12,15,17,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound25629 : packedSelected [0,1,3,5,7,8,9,11,12,15,17,18,22] rootPS < 2^1333 := by decide +kernel

def env25630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5457,32768,262,38160,35324,1024,32769,36881,32936,201,82,388,65,2184,5576,37080,35189,34188,113,256,113,38280,33361]

theorem envBound25630 : H12AffineFastState.Bounded env25630 := by
  intro p hp
  have h : env25630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25629_25630 : H12AffineEnvironment.transform 12 268 env25629 = env25630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env25629 == env25630) = true)

theorem identity25630 : scanCanonicalize (H12AffineFastState.compose env25630 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound25630 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env25631 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,4096,268,4453,32768,262,37156,35324,52,32769,36881,32936,201,82,388,65,2184,4604,37080,35189,33208,113,256,113,37308,33361]

theorem envBound25631 : H12AffineFastState.Bounded env25631 := by
  intro p hp
  have h : env25631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25630_25631 : H12AffineEnvironment.transform 9 52 env25630 = env25631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env25630 == env25631) = true)

theorem identity25631 : scanCanonicalize (H12AffineFastState.compose env25631 (packedSelected [0,2,6,7,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 6453) := by decide +kernel

theorem selectedBound25631 : packedSelected [0,2,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env25632 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,4096,268,4453,6453,262,2065,4297,52,6452,2340,6557,201,82,388,65,2184,4604,2541,4160,6285,113,256,113,2185,7012]

theorem envBound25632 : H12AffineFastState.Bounded env25632 := by
  intro p hp
  have h : env25632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25631_25632 : H12AffineEnvironment.transform 14 6453 env25631 = env25632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6453 env25631 == env25632) = true)

theorem identity25632 : scanCanonicalize (H12AffineFastState.compose env25632 (packedSelected [1,4,5,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound25632 : packedSelected [1,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env25633 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,493,268,136,2264,262,2065,292,52,2265,2340,2160,201,82,388,65,2184,17,2541,429,2400,113,256,113,2185,2697]

theorem envBound25633 : H12AffineFastState.Bounded env25633 := by
  intro p hp
  have h : env25633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25632_25633 : H12AffineEnvironment.transform 11 493 env25632 = env25633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env25632 == env25633) = true)

theorem identity25633 : scanCanonicalize (H12AffineFastState.compose env25633 (packedSelected [0,3,4,8,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound25633 : packedSelected [0,3,4,8,10,15] rootPS < 2^1333 := by decide +kernel

def env25634 : List Nat := [2,4,8,16,32,64,128,256,512,52,292,493,268,136,508,262,309,292,52,509,0,340,201,82,388,65,428,17,201,429,68,113,256,113,429,941]

theorem envBound25634 : H12AffineFastState.Bounded env25634 := by
  intro p hp
  have h : env25634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25633_25634 : H12AffineEnvironment.transform 10 292 env25633 = env25634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env25633 == env25634) = true)

theorem identity25634 : scanCanonicalize (H12AffineFastState.compose env25634 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25634 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25635 : List Nat := [2,4,8,16,32,64,8,256,512,52,292,357,268,0,372,262,309,292,52,373,0,340,65,82,268,65,292,17,65,293,68,113,256,113,293,805]

theorem envBound25635 : H12AffineFastState.Bounded env25635 := by
  intro p hp
  have h : env25635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25634_25635 : H12AffineEnvironment.transform 6 8 env25634 = env25635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25634 == env25635) = true)

theorem identity25635 : scanCanonicalize (H12AffineFastState.compose env25635 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound25635 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env25636 : List Nat := [2,4,8,16,32,64,8,116,512,52,80,17,120,0,0,114,65,80,52,1,0,32,65,82,120,65,80,17,65,81,68,113,116,113,81,593]

theorem envBound25636 : H12AffineFastState.Bounded env25636 := by
  intro p hp
  have h : env25636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25635_25636 : H12AffineEnvironment.transform 7 116 env25635 = env25636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env25635 == env25636) = true)

def env25637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound25637 : H12AffineFastState.Bounded env25637 := by
  intro p hp
  have h : env25637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25458_25637 : H12AffineEnvironment.transform 18 1025 env25458 = env25637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env25458 == env25637) = true)

theorem identity25637 : scanCanonicalize (H12AffineFastState.compose env25637 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 297470) := by decide +kernel

theorem selectedBound25637 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env25638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297470,8328,65,12798463,2428274,10507601,8830976,8719855,6679615,257,10833235,10857718,8661561]

theorem envBound25638 : H12AffineFastState.Bounded env25638 := by
  intro p hp
  have h : env25638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25637_25638 : H12AffineEnvironment.transform 23 297470 env25637 = env25638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 297470 env25637 == env25638) = true)

def env25639 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297334,8192,65,12798327,2428274,10507601,8830976,8719719,6679615,257,10833235,10857598,8661561]

theorem envBound25639 : H12AffineFastState.Bounded env25639 := by
  intro p hp
  have h : env25639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25638_25639 : H12AffineEnvironment.transform 6 8 env25638 = env25639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25638 == env25639) = true)

def env25640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297334,8192,65,12650855,2428274,10507601,8683536,8719719,6679615,257,10833235,10857598,8661561]

theorem envBound25640 : H12AffineFastState.Bounded env25640 := by
  intro p hp
  have h : env25640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25639_25640 : H12AffineEnvironment.transform 16 16400 env25639 = env25640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env25639 == env25640) = true)

theorem identity25640 : scanCanonicalize (H12AffineFastState.compose env25640 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 297317) := by decide +kernel

theorem selectedBound25640 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env25641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,297317,297334,8192,65,4554754,2428274,2415668,2421,99330,6679615,257,2212918,2172187,41820]

theorem envBound25641 : H12AffineFastState.Bounded env25641 := by
  intro p hp
  have h : env25641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25640_25641 : H12AffineEnvironment.transform 22 297317 env25640 = env25641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297317 env25640 == env25641) = true)

theorem identity25641 : scanCanonicalize (H12AffineFastState.compose env25641 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25641 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env25642 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,2097152,4194304,297317,297334,8192,65,4497417,2370937,2415668,2421,41993,6605876,257,2155581,2098448,41820]

theorem envBound25642 : H12AffineFastState.Bounded env25642 := by
  intro p hp
  have h : env25642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25641_25642 : H12AffineEnvironment.transform 15 8203 env25641 = env25642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25641 == env25642) = true)

theorem identity25642 : scanCanonicalize (H12AffineFastState.compose env25642 (packedSelected [1,5,8,17,19,21,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound25642 : packedSelected [1,5,8,17,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env25643 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16400,262144,1025,8540,2097152,4194304,272440,272427,8192,65,4456788,2370937,2391401,2421,1364,6581609,257,2114912,2098448,513]

theorem envBound25643 : H12AffineFastState.Bounded env25643 := by
  intro p hp
  have h : env25643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25642_25643 : H12AffineEnvironment.transform 14 8541 env25642 = env25643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env25642 == env25643) = true)

theorem identity25643 : scanCanonicalize (H12AffineFastState.compose env25643 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 292888) := by decide +kernel

theorem selectedBound25643 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env25644 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16400,262144,1025,8540,2097152,292888,272440,272427,8192,65,31052,2370937,2391401,2421,1364,2102641,257,2114912,2098448,513]

theorem envBound25644 : H12AffineFastState.Bounded env25644 := by
  intro p hp
  have h : env25644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25643_25644 : H12AffineEnvironment.transform 21 292888 env25643 = env25644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 292888 env25643 == env25644) = true)

theorem identity25644 : scanCanonicalize (H12AffineFastState.compose env25644 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 290153) := by decide +kernel

theorem selectedBound25644 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25645 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16400,262144,1025,8540,290153,292888,272440,272427,8192,65,31052,16400,4096,2421,1364,292888,257,272393,288889,513]

theorem envBound25645 : H12AffineFastState.Bounded env25645 := by
  intro p hp
  have h : env25645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25644_25645 : H12AffineEnvironment.transform 20 290153 env25644 = env25645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290153 env25644 == env25645) = true)

theorem identity25645 : scanCanonicalize (H12AffineFastState.compose env25645 (packedSelected [0,7,20] rootPS)) = affineNative (2^(17+1) ^^^ 30777) := by decide +kernel

theorem selectedBound25645 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env25646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16400,30777,1025,8540,5456,33,20481,20498,8192,65,31052,16400,4096,2421,1364,33,257,20528,4160,513]

theorem envBound25646 : H12AffineFastState.Bounded env25646 := by
  intro p hp
  have h : env25646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25645_25646 : H12AffineEnvironment.transform 17 30777 env25645 = env25646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30777 env25645 == env25646) = true)

theorem identity25646 : scanCanonicalize (H12AffineFastState.compose env25646 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound25646 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25647 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,343,16400,22885,1025,0,5456,33,20481,20498,348,65,22544,16400,4096,2421,1364,33,257,20528,4160,513]

theorem envBound25647 : H12AffineFastState.Bounded env25647 := by
  intro p hp
  have h : env25647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25646_25647 : H12AffineEnvironment.transform 12 348 env25646 = env25647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env25646 == env25647) = true)

theorem identity25647 : scanCanonicalize (H12AffineFastState.compose env25647 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound25647 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,4112,1,343,4096,2421,1025,0,5456,33,17,2,348,65,2048,4096,4096,2421,1364,33,257,32,4160,513]

theorem envBound25648 : H12AffineFastState.Bounded env25648 := by
  intro p hp
  have h : env25648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25647_25648 : H12AffineEnvironment.transform 13 4112 env25647 = env25648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env25647 == env25648) = true)

theorem identity25648 : scanCanonicalize (H12AffineFastState.compose env25648 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound25648 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25649 : List Nat := [2,4,8,16,32,64,8,256,512,785,2048,4096,348,4112,1,343,4096,2421,784,0,4673,33,17,2,348,65,2048,4096,4096,2421,581,33,257,32,4160,513]

theorem envBound25649 : H12AffineFastState.Bounded env25649 := by
  intro p hp
  have h : env25649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25648_25649 : H12AffineEnvironment.transform 9 785 env25648 = env25649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env25648 == env25649) = true)

def env25650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297334,8192,65,12650854,2428274,10507601,8683537,8719719,6679615,257,10833235,10857598,8661561]

theorem envBound25650 : H12AffineFastState.Bounded env25650 := by
  intro p hp
  have h : env25650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25639_25650 : H12AffineEnvironment.transform 16 16401 env25639 = env25650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env25639 == env25650) = true)

theorem identity25650 : scanCanonicalize (H12AffineFastState.compose env25650 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound25650 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env25651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,262144,1025,8540,2097152,4194304,8388608,272427,8192,65,12650854,2428274,10507601,8659276,8719719,6638946,257,10833235,10816803,8661561]

theorem envBound25651 : H12AffineFastState.Bounded env25651 := by
  intro p hp
  have h : env25651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25650_25651 : H12AffineEnvironment.transform 14 8541 env25650 = env25651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env25650 == env25651) = true)

theorem identity25651 : scanCanonicalize (H12AffineFastState.compose env25651 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound25651 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env25652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,262144,1025,8540,2097152,4194304,8388608,272427,8192,65,12593516,2370936,10507601,8659276,8662381,6581608,257,10775897,10759465,8661561]

theorem envBound25652 : H12AffineFastState.Bounded env25652 := by
  intro p hp
  have h : env25652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25651_25652 : H12AffineEnvironment.transform 15 8202 env25651 = env25652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env25651 == env25652) = true)

theorem identity25652 : scanCanonicalize (H12AffineFastState.compose env25652 (packedSelected [0,1,3,5,8,9,10,11,18,19,21,22,23,27,32] rootPS)) = affineNative (2^(22+1) ^^^ 6309153) := by decide +kernel

theorem selectedBound25652 : packedSelected [0,1,3,5,8,9,10,11,18,19,21,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env25653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,262144,1025,8540,2097152,4194304,6309153,272427,8192,65,2124877,2370936,4198512,6579309,6580300,6581608,257,4466808,4483080,6582040]

theorem envBound25653 : H12AffineFastState.Bounded env25653 := by
  intro p hp
  have h : env25653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25652_25653 : H12AffineEnvironment.transform 22 6309153 env25652 = env25653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6309153 env25652 == env25653) = true)

theorem identity25653 : scanCanonicalize (H12AffineFastState.compose env25653 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound25653 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env25654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,262144,1025,8540,2097152,32,2114817,272427,8192,65,2124877,2370936,4176,2384973,2386028,2387272,257,272472,288808,2387768]

theorem envBound25654 : H12AffineFastState.Bounded env25654 := by
  intro p hp
  have h : env25654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25653_25654 : H12AffineEnvironment.transform 21 32 env25653 = env25654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env25653 == env25654) = true)

theorem identity25654 : scanCanonicalize (H12AffineFastState.compose env25654 (packedSelected [1,3,5,8,10,16,19,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound25654 : packedSelected [1,3,5,8,10,16,19,20,21] rootPS < 2^1333 := by decide +kernel

def env25655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,2420,1025,8540,2097152,32,2114817,8543,8192,65,2124877,2106380,4176,2125113,2122008,2122812,257,8492,24924,2123340]

theorem envBound25655 : H12AffineFastState.Bounded env25655 := by
  intro p hp
  have h : env25655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25654_25655 : H12AffineEnvironment.transform 17 2420 env25654 = env25655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env25654 == env25655) = true)

theorem identity25655 : scanCanonicalize (H12AffineFastState.compose env25655 (packedSelected [0,1,2,6,7,8,10,11,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound25655 : packedSelected [0,1,2,6,7,8,10,11,18,20] rootPS < 2^1333 := by decide +kernel

def env25656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8541,8202,5220,2420,1025,8540,2097152,32,2101620,8543,8192,65,2111544,2106380,4176,2111820,2110829,2109513,257,8492,13609,2110009]

theorem envBound25656 : H12AffineFastState.Bounded env25656 := by
  intro p hp
  have h : env25656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25655_25656 : H12AffineEnvironment.transform 13 5237 env25655 = env25656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env25655 == env25656) = true)

theorem identity25656 : scanCanonicalize (H12AffineFastState.compose env25656 (packedSelected [0,1,2,4,6,7,8,9,10,11,14,17,18] rootPS)) = affineNative (2^(20+1) ^^^ 12344) := by decide +kernel

theorem selectedBound25656 : packedSelected [0,1,2,4,6,7,8,9,10,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env25657 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8541,8202,5220,2420,1025,8540,12344,32,8524,8543,8192,65,2048,5172,4176,2420,1365,113,257,8492,13609,513]

theorem envBound25657 : H12AffineFastState.Bounded env25657 := by
  intro p hp
  have h : env25657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25656_25657 : H12AffineEnvironment.transform 20 12344 env25656 = env25657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12344 env25656 == env25657) = true)

theorem identity25657 : scanCanonicalize (H12AffineFastState.compose env25657 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound25657 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env25658 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1385,5237,1076,1379,5220,2420,1025,1077,5457,32,1061,1078,1385,65,2048,5172,4176,2420,1365,113,257,1093,4160,513]

theorem envBound25658 : H12AffineFastState.Bounded env25658 := by
  intro p hp
  have h : env25658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25657_25658 : H12AffineEnvironment.transform 12 1385 env25657 = env25658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env25657 == env25658) = true)

theorem identity25658 : scanCanonicalize (H12AffineFastState.compose env25658 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25658 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env25659 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1337,5157,1076,1331,5172,2340,1025,1077,5377,32,1061,1078,1337,17,2048,5172,4096,2340,1285,33,257,1045,4112,513]

theorem envBound25659 : H12AffineFastState.Bounded env25659 := by
  intro p hp
  have h : env25659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25658_25659 : H12AffineEnvironment.transform 5 16 env25658 = env25659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25658 == env25659) = true)

def env25660 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297335,8193,65,12798326,2428274,10507601,8830976,8719718,6679615,257,10833235,10857599,8661561]

theorem envBound25660 : H12AffineFastState.Bounded env25660 := by
  intro p hp
  have h : env25660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25638_25660 : H12AffineEnvironment.transform 6 9 env25638 = env25660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25638 == env25660) = true)

def env25661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297335,8193,65,12650854,2428274,10507601,8683536,8719718,6679615,257,10833235,10857599,8661561]

theorem envBound25661 : H12AffineFastState.Bounded env25661 := by
  intro p hp
  have h : env25661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25660_25661 : H12AffineEnvironment.transform 16 16400 env25660 = env25661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env25660 == env25661) = true)

theorem identity25661 : scanCanonicalize (H12AffineFastState.compose env25661 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound25661 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env25662 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,8388608,41310,8193,65,12650854,2172251,10507601,8431673,8463695,6407190,257,10577274,10585174,8389136]

theorem envBound25662 : H12AffineFastState.Bounded env25662 := by
  intro p hp
  have h : env25662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25661_25662 : H12AffineEnvironment.transform 17 10281 env25661 = env25662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25661 == env25662) = true)

theorem identity25662 : scanCanonicalize (H12AffineFastState.compose env25662 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound25662 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env25663 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,17,41310,8193,65,4262263,2172251,2118976,43048,75102,6407190,257,2188651,2196551,513]

theorem envBound25663 : H12AffineFastState.Bounded env25663 := by
  intro p hp
  have h : env25663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25662_25663 : H12AffineEnvironment.transform 22 17 env25662 = env25663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env25662 == env25663) = true)

theorem identity25663 : scanCanonicalize (H12AffineFastState.compose env25663 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound25663 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env25664 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,115735,4194304,17,41310,8193,65,4262263,57676,102743,43048,75102,4194305,257,41340,16464,513]

theorem envBound25664 : H12AffineFastState.Bounded env25664 := by
  intro p hp
  have h : env25664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25663_25664 : H12AffineEnvironment.transform 20 115735 env25663 = env25664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env25663 == env25664) = true)

theorem identity25664 : scanCanonicalize (H12AffineFastState.compose env25664 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound25664 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env25665 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,16400,10281,1025,32769,50497,4194304,17,41310,8193,65,4196385,57676,36865,43048,9224,4194305,257,41340,16464,513]

theorem envBound25665 : H12AffineFastState.Bounded env25665 := by
  intro p hp
  have h : env25665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25664_25665 : H12AffineEnvironment.transform 15 342 env25664 = env25665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env25664 == env25665) = true)

theorem identity25665 : scanCanonicalize (H12AffineFastState.compose env25665 (packedSelected [0,7,11,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound25665 : packedSelected [0,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env25666 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,342,16400,10281,1025,8541,25629,4194304,17,2,8193,65,4196385,16400,12637,2420,9224,4194305,257,32,16464,513]

theorem envBound25666 : H12AffineFastState.Bounded env25666 := by
  intro p hp
  have h : env25666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25665_25666 : H12AffineEnvironment.transform 14 8540 env25665 = env25666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env25665 == env25666) = true)

theorem identity25666 : scanCanonicalize (H12AffineFastState.compose env25666 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound25666 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env25667 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,342,16400,10281,1025,8541,25629,8572,17,2,8193,65,10589,16400,12637,2420,9224,8573,257,32,16464,513]

theorem envBound25667 : H12AffineFastState.Bounded env25667 := by
  intro p hp
  have h : env25667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25666_25667 : H12AffineEnvironment.transform 21 8572 env25666 = env25667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env25666 == env25667) = true)

theorem identity25667 : scanCanonicalize (H12AffineFastState.compose env25667 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 1312) := by decide +kernel

theorem selectedBound25667 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env25668 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,1312,8540,342,1328,10281,1025,8541,8509,8572,17,2,8193,65,10589,1328,12637,2420,9224,8573,257,32,1392,513]

theorem envBound25668 : H12AffineFastState.Bounded env25668 := by
  intro p hp
  have h : env25668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25667_25668 : H12AffineEnvironment.transform 13 1312 env25667 = env25668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1312 env25667 == env25668) = true)

theorem identity25668 : scanCanonicalize (H12AffineFastState.compose env25668 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound25668 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env25669 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,1312,1,342,1328,2420,1025,0,96,33,17,2,348,65,2048,1328,4096,2420,1365,32,257,32,1392,513]

theorem envBound25669 : H12AffineFastState.Bounded env25669 := by
  intro p hp
  have h : env25669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25668_25669 : H12AffineEnvironment.transform 12 349 env25668 = env25669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env25668 == env25669) = true)

theorem identity25669 : scanCanonicalize (H12AffineFastState.compose env25669 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound25669 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25670 : List Nat := [2,4,8,16,32,64,9,256,512,784,2048,4096,349,560,1,342,544,2420,785,0,96,33,17,2,348,65,2048,544,4096,2420,581,32,257,32,608,513]

theorem envBound25670 : H12AffineFastState.Bounded env25670 := by
  intro p hp
  have h : env25670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25669_25670 : H12AffineEnvironment.transform 9 784 env25669 = env25670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env25669 == env25670) = true)

def env25671 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297335,8193,65,12650855,2428274,10507601,8683537,8719718,6679615,257,10833235,10857599,8661561]

theorem envBound25671 : H12AffineFastState.Bounded env25671 := by
  intro p hp
  have h : env25671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25660_25671 : H12AffineEnvironment.transform 16 16401 env25660 = env25671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env25660 == env25671) = true)

theorem identity25671 : scanCanonicalize (H12AffineFastState.compose env25671 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound25671 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env25672 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,17,297335,8193,65,4262262,2428274,2118976,294912,331127,6679615,257,2444610,2468974,272936]

theorem envBound25672 : H12AffineFastState.Bounded env25672 := by
  intro p hp
  have h : env25672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25671_25672 : H12AffineEnvironment.transform 22 17 env25671 = env25672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env25671 == env25672) = true)

theorem identity25672 : scanCanonicalize (H12AffineFastState.compose env25672 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound25672 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env25673 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,17,41310,8193,65,4262262,2172251,2118976,43049,75102,6407190,257,2188651,2196551,513]

theorem envBound25673 : H12AffineFastState.Bounded env25673 := by
  intro p hp
  have h : env25673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25672_25673 : H12AffineEnvironment.transform 17 10281 env25672 = env25673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25672 == env25673) = true)

def env25674 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58396,4194304,17,41310,8193,65,4262262,115015,45404,43049,75102,4268042,257,98679,90203,513]

theorem envBound25674 : H12AffineFastState.Bounded env25674 := by
  intro p hp
  have h : env25674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25673_25674 : H12AffineEnvironment.transform 20 58396 env25673 = env25674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env25673 == env25674) = true)

theorem identity25674 : scanCanonicalize (H12AffineFastState.compose env25674 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound25674 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env25675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1025,8540,17729,4194304,17,3,8193,65,4262262,90138,4097,2420,75102,4268042,257,73770,90203,513]

theorem envBound25675 : H12AffineFastState.Bounded env25675 := by
  intro p hp
  have h : env25675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25674_25675 : H12AffineEnvironment.transform 14 8541 env25674 = env25675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env25674 == env25675) = true)

theorem identity25675 : scanCanonicalize (H12AffineFastState.compose env25675 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound25675 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env25676 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,262,16401,10281,1025,8540,17729,4194304,17,3,8193,65,4196464,24860,4097,2420,9304,4202764,257,8492,24925,513]

theorem envBound25676 : H12AffineFastState.Bounded env25676 := by
  intro p hp
  have h : env25676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25675_25676 : H12AffineEnvironment.transform 15 262 env25675 = env25676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env25675 == env25676) = true)

theorem identity25676 : scanCanonicalize (H12AffineFastState.compose env25676 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound25676 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env25677 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,262,16401,10281,1025,8540,17729,113,17,3,8193,65,2049,24860,4097,2420,9304,8573,257,8492,24925,513]

theorem envBound25677 : H12AffineFastState.Bounded env25677 := by
  intro p hp
  have h : env25677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25676_25677 : H12AffineEnvironment.transform 21 113 env25676 = env25677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env25676 == env25677) = true)

theorem identity25677 : scanCanonicalize (H12AffineFastState.compose env25677 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25677 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env25678 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,262,16401,10281,1025,8460,17681,33,17,3,8193,17,2049,24860,4097,2340,9224,8493,257,8492,24845,513]

theorem envBound25678 : H12AffineFastState.Bounded env25678 := by
  intro p hp
  have h : env25678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25677_25678 : H12AffineEnvironment.transform 5 16 env25677 = env25678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25677 == env25678) = true)

def env25679 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58397,4194304,17,41310,8193,65,4262262,115014,45405,43049,75102,4268043,257,98678,90202,513]

theorem envBound25679 : H12AffineFastState.Bounded env25679 := by
  intro p hp
  have h : env25679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25673_25679 : H12AffineEnvironment.transform 20 58397 env25673 = env25679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env25673 == env25679) = true)

theorem identity25679 : scanCanonicalize (H12AffineFastState.compose env25679 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound25679 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25680 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10281,1025,32769,58397,4194304,17,41310,8193,65,4204924,57676,45405,43049,1364,4194305,257,41340,16464,513]

theorem envBound25680 : H12AffineFastState.Bounded env25680 := by
  intro p hp
  have h : env25680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25679_25680 : H12AffineEnvironment.transform 15 8202 env25679 = env25680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env25679 == env25680) = true)

theorem identity25680 : scanCanonicalize (H12AffineFastState.compose env25680 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound25680 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env25681 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10281,1025,32769,58397,113,17,41310,8193,65,10509,57676,45405,43049,1364,112,257,41340,16464,513]

theorem envBound25681 : H12AffineFastState.Bounded env25681 := by
  intro p hp
  have h : env25681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25680_25681 : H12AffineEnvironment.transform 21 113 env25680 = env25681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env25680 == env25681) = true)

theorem identity25681 : scanCanonicalize (H12AffineFastState.compose env25681 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound25681 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env25682 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,342,16401,2421,1025,32769,50497,113,17,32770,349,65,2129,49168,36865,35189,1364,112,257,32800,16464,513]

theorem envBound25682 : H12AffineFastState.Bounded env25682 := by
  intro p hp
  have h : env25682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25681_25682 : H12AffineEnvironment.transform 12 348 env25681 = env25682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env25681 == env25682) = true)

theorem identity25682 : scanCanonicalize (H12AffineFastState.compose env25682 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25682 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env25683 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,262,16401,2341,1025,32769,50449,33,17,32770,269,17,2049,49168,36865,35109,1284,32,257,32800,16384,513]

theorem envBound25683 : H12AffineFastState.Bounded env25683 := by
  intro p hp
  have h : env25683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25682_25683 : H12AffineEnvironment.transform 5 16 env25682 = env25683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25682 == env25683) = true)

theorem identity25683 : scanCanonicalize (H12AffineFastState.compose env25683 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound25683 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25684 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,262,16401,2341,1025,1,17681,33,17,2,269,17,2049,16400,4097,2341,1284,32,257,32,16384,513]

theorem envBound25684 : H12AffineFastState.Bounded env25684 := by
  intro p hp
  have h : env25684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25683_25684 : H12AffineEnvironment.transform 14 0 env25683 = env25684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env25683 == env25684) = true)

theorem identity25684 : scanCanonicalize (H12AffineFastState.compose env25684 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound25684 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25685 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,262,5393,2341,1025,1,4113,33,17,2,269,17,2049,5392,4097,2341,1284,32,257,32,5376,513]

theorem envBound25685 : H12AffineFastState.Bounded env25685 := by
  intro p hp
  have h : env25685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25684_25685 : H12AffineEnvironment.transform 13 5376 env25684 = env25685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25684 == env25685) = true)

theorem identity25685 : scanCanonicalize (H12AffineFastState.compose env25685 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound25685 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25686 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,308,268,1076,0,262,1061,2341,1025,1,293,33,17,2,269,17,2049,1060,309,2341,1284,32,257,32,1076,513]

theorem envBound25686 : H12AffineFastState.Bounded env25686 := by
  intro p hp
  have h : env25686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25685_25686 : H12AffineEnvironment.transform 11 308 env25685 = env25686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env25685 == env25686) = true)

theorem identity25686 : scanCanonicalize (H12AffineFastState.compose env25686 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound25686 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25687 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,308,268,292,0,262,309,2341,273,1,293,33,17,2,269,17,2049,308,309,2341,20,32,257,32,292,513]

theorem envBound25687 : H12AffineFastState.Bounded env25687 := by
  intro p hp
  have h : env25687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25686_25687 : H12AffineEnvironment.transform 9 272 env25686 = env25687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env25686 == env25687) = true)

theorem identity25687 : scanCanonicalize (H12AffineFastState.compose env25687 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound25687 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25688 : List Nat := [2,4,8,16,32,16,9,256,512,272,1,308,268,292,0,262,309,292,273,1,293,33,17,2,269,17,0,308,309,292,20,32,257,32,292,513]

theorem envBound25688 : H12AffineFastState.Bounded env25688 := by
  intro p hp
  have h : env25688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25687_25688 : H12AffineEnvironment.transform 10 1 env25687 = env25688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25687 == env25688) = true)

theorem identity25688 : scanCanonicalize (H12AffineFastState.compose env25688 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25688 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env25689 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,16,40,0,0,34,17,0,53,1,1,33,17,2,41,17,0,16,17,0,20,32,37,32,0,513]

theorem envBound25689 : H12AffineFastState.Bounded env25689 := by
  intro p hp
  have h : env25689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25688_25689 : H12AffineEnvironment.transform 7 36 env25688 = env25689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25688 == env25689) = true)

theorem identity25689 : scanCanonicalize (H12AffineFastState.compose env25689 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound25689 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25690 : List Nat := [2,4,8,16,32,16,9,36,17,52,1,16,40,0,0,34,17,0,53,1,1,33,17,2,41,17,0,16,17,0,20,32,37,32,0,16]

theorem envBound25690 : H12AffineFastState.Bounded env25690 := by
  intro p hp
  have h : env25690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25689_25690 : H12AffineEnvironment.transform 8 17 env25689 = env25690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env25689 == env25690) = true)

theorem identity25690 : scanCanonicalize (H12AffineFastState.compose env25690 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound25690 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25691 : List Nat := [2,4,3,16,32,16,2,36,17,52,1,16,35,0,0,34,17,0,53,1,1,33,17,2,34,17,0,16,17,0,20,32,37,32,0,16]

theorem envBound25691 : H12AffineFastState.Bounded env25691 := by
  intro p hp
  have h : env25691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25690_25691 : H12AffineEnvironment.transform 2 3 env25690 = env25691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env25690 == env25691) = true)

def env25692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356288,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound25692 : H12AffineFastState.Bounded env25692 := by
  intro p hp
  have h : env25692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25457_25692 : H12AffineEnvironment.transform 26 30393345 env25457 = env25692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env25457 == env25692) = true)

def env25693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound25693 : H12AffineFastState.Bounded env25693 := by
  intro p hp
  have h : env25693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25692_25693 : H12AffineEnvironment.transform 18 1024 env25692 = env25693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env25692 == env25693) = true)

theorem identity25693 : scanCanonicalize (H12AffineFastState.compose env25693 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10882239) := by decide +kernel

theorem selectedBound25693 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env25694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10882239,8328,65,6409406,8882226,10507601,8830976,2590894,13068671,256,509970,469431,2535289]

theorem envBound25694 : H12AffineFastState.Bounded env25694 := by
  intro p hp
  have h : env25694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25693_25694 : H12AffineEnvironment.transform 23 10882239 env25693 = env25694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10882239 env25693 == env25694) = true)

def env25695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412156,2114883,8328,65,6409406,115150,2497709,35324,2590894,4268163,256,509970,469431,2535289]

theorem envBound25695 : H12AffineFastState.Bounded env25695 := by
  intro p hp
  have h : env25695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25694_25695 : H12AffineEnvironment.transform 22 412156 env25694 = env25695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412156 env25694 == env25695) = true)

def env25696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262520,412156,2114883,8328,65,215366,115150,2497709,35324,2590894,2336123,256,509970,469431,2535289]

theorem envBound25696 : H12AffineFastState.Bounded env25696 := by
  intro p hp
  have h : env25696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25695_25696 : H12AffineEnvironment.transform 21 2262520 env25695 = env25696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262520 env25695 == env25696) = true)

def env25697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412156,21763,8328,65,215366,115150,396525,35324,497902,243003,256,509970,469431,442169]

theorem envBound25697 : H12AffineFastState.Bounded env25697 := by
  intro p hp
  have h : env25697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25696_25697 : H12AffineEnvironment.transform 20 4160 env25696 = env25697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25696 == env25697) = true)

theorem identity25697 : scanCanonicalize (H12AffineFastState.compose env25697 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25697 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4160,169400,412156,21763,8328,65,158029,57797,396525,35324,440549,169264,256,452633,395708,442169]

theorem envBound25698 : H12AffineFastState.Bounded env25698 := by
  intro p hp
  have h : env25698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25697_25698 : H12AffineEnvironment.transform 15 8203 env25697 = env25698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25697 == env25698) = true)

theorem identity25698 : scanCanonicalize (H12AffineFastState.compose env25698 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound25698 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env25699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4160,169400,62660,21763,8328,65,158029,57797,45525,35324,1501,169264,256,21793,46212,513]

theorem envBound25699 : H12AffineFastState.Bounded env25699 := by
  intro p hp
  have h : env25699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25698_25699 : H12AffineEnvironment.transform 17 179512 env25698 = env25699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env25698 == env25699) = true)

theorem identity25699 : scanCanonicalize (H12AffineFastState.compose env25699 (packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound25699 : packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env25700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,342,131072,171109,1024,32769,4160,169400,54681,21763,469,65,149520,49304,37000,35324,1501,169264,256,21793,38361,513]

theorem envBound25700 : H12AffineFastState.Bounded env25700 := by
  intro p hp
  have h : env25700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25699_25700 : H12AffineEnvironment.transform 12 349 env25699 = env25700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env25699 == env25700) = true)

theorem identity25700 : scanCanonicalize (H12AffineFastState.compose env25700 (packedSelected [1,2,4,5,6,7,8,9,15,17,18,23,24,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 16585) := by decide +kernel

theorem selectedBound25700 : packedSelected [1,2,4,5,6,7,8,9,15,17,18,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env25701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,342,16585,56492,1024,32769,4160,54641,54681,21763,469,65,2265,49304,37000,35324,1501,54777,256,21793,38361,513]

theorem envBound25701 : H12AffineFastState.Bounded env25701 := by
  intro p hp
  have h : env25701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25700_25701 : H12AffineEnvironment.transform 16 16585 env25700 = env25701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16585 env25700 == env25701) = true)

theorem identity25701 : scanCanonicalize (H12AffineFastState.compose env25701 (packedSelected [3,4,9,10,14,19,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound25701 : packedSelected [3,4,9,10,14,19,20,24] rootPS < 2^1333 := by decide +kernel

def env25702 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,16384,32768,342,16401,56436,1024,32769,4160,54641,54593,21763,269,65,2049,49216,36944,35108,1285,54561,256,21793,38145,513]

theorem envBound25702 : H12AffineFastState.Bounded env25702 := by
  intro p hp
  have h : env25702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25701_25702 : H12AffineEnvironment.transform 6 88 env25701 = env25702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env25701 == env25702) = true)

theorem identity25702 : scanCanonicalize (H12AffineFastState.compose env25702 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound25702 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env25703 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,16384,21841,342,16401,2341,1024,21840,4160,32,16,21763,269,65,2049,5393,17665,23669,1285,112,256,21793,16464,513]

theorem envBound25703 : H12AffineFastState.Bounded env25703 := by
  intro p hp
  have h : env25703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25702_25703 : H12AffineEnvironment.transform 14 21841 env25702 = env25703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env25702 == env25703) = true)

theorem identity25703 : scanCanonicalize (H12AffineFastState.compose env25703 (packedSelected [2,5,7,8,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5167) := by decide +kernel

theorem selectedBound25703 : packedSelected [2,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env25704 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,5167,382,342,5182,2341,1024,383,4160,32,16,300,269,65,2049,5393,4398,2138,1285,112,256,270,5247,513]

theorem envBound25704 : H12AffineFastState.Bounded env25704 := by
  intro p hp
  have h : env25704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25703_25704 : H12AffineEnvironment.transform 13 5167 env25703 = env25704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5167 env25703 == env25704) = true)

theorem identity25704 : scanCanonicalize (H12AffineFastState.compose env25704 (packedSelected [1,2,4,6,7,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound25704 : packedSelected [1,2,4,6,7,8,12] rootPS < 2^1333 := by decide +kernel

def env25705 : List Nat := [2,4,8,16,32,64,88,256,512,47,2048,4096,349,4096,382,342,4113,2341,47,383,4160,32,16,300,269,65,2049,4414,4398,2138,298,112,256,270,4176,513]

theorem envBound25705 : H12AffineFastState.Bounded env25705 := by
  intro p hp
  have h : env25705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25704_25705 : H12AffineEnvironment.transform 9 47 env25704 = env25705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env25704 == env25705) = true)

theorem identity25705 : scanCanonicalize (H12AffineFastState.compose env25705 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 127) := by decide +kernel

theorem selectedBound25705 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env25706 : List Nat := [2,4,8,16,32,64,88,127,512,47,2048,4096,34,4096,1,41,4113,2138,47,0,4160,32,16,83,114,65,2049,4161,4177,2138,85,112,127,113,4176,513]

theorem envBound25706 : H12AffineFastState.Bounded env25706 := by
  intro p hp
  have h : env25706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25705_25706 : H12AffineEnvironment.transform 7 127 env25705 = env25706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 127 env25705 == env25706) = true)

theorem identity25706 : scanCanonicalize (H12AffineFastState.compose env25706 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound25706 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25707 : List Nat := [2,4,8,16,32,64,88,127,512,47,2048,2059,34,2059,1,41,2074,2138,47,0,2123,32,16,83,114,65,2049,2122,2138,2138,85,112,127,113,2139,513]

theorem envBound25707 : H12AffineFastState.Bounded env25707 := by
  intro p hp
  have h : env25707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25706_25707 : H12AffineEnvironment.transform 11 2059 env25706 = env25707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env25706 == env25707) = true)

def env25708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412156,21762,8328,65,215366,115150,396524,35324,497903,243002,256,509970,469431,442168]

theorem envBound25708 : H12AffineFastState.Bounded env25708 := by
  intro p hp
  have h : env25708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25696_25708 : H12AffineEnvironment.transform 20 4161 env25696 = env25708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25696 == env25708) = true)

theorem identity25708 : scanCanonicalize (H12AffineFastState.compose env25708 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236850) := by decide +kernel

theorem selectedBound25708 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,4161,169401,120014,21762,8328,65,215366,115150,102878,35324,1501,243002,256,21792,46213,74250]

theorem envBound25709 : H12AffineFastState.Bounded env25709 := by
  intro p hp
  have h : env25709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25708_25709 : H12AffineEnvironment.transform 17 236850 env25708 = env25709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236850 env25708 == env25709) = true)

def env25710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130174,1024,32769,4161,62709,120014,21762,8328,65,75786,115150,102878,35324,1501,119926,256,21792,46213,74250]

theorem envBound25710 : H12AffineFastState.Bounded env25710 := by
  intro p hp
  have h : env25710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25709_25710 : H12AffineEnvironment.transform 16 24908 env25709 = env25710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env25709 == env25710) = true)

def env25711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130174,1024,32769,4161,62589,119878,21762,8192,65,75786,115014,102742,35188,1365,119926,256,21792,46093,74250]

theorem envBound25711 : H12AffineFastState.Bounded env25711 := by
  intro p hp
  have h : env25711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25710_25711 : H12AffineEnvironment.transform 6 8 env25710 = env25711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25710 == env25711) = true)

theorem identity25711 : scanCanonicalize (H12AffineFastState.compose env25711 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound25711 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,24908,32041,1024,32769,4161,62589,21777,21762,8192,65,43357,16401,4097,35188,1365,21793,256,21792,46093,41821]

theorem envBound25712 : H12AffineFastState.Bounded env25712 := by
  intro p hp
  have h : env25712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25711_25712 : H12AffineEnvironment.transform 15 33111 env25711 = env25712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env25711 == env25712) = true)

theorem identity25712 : scanCanonicalize (H12AffineFastState.compose env25712 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound25712 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env25713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,13389,10280,1024,32769,4161,41340,16,3,8192,65,43357,5392,4097,35188,1365,32,256,33,46093,41821]

theorem envBound25713 : H12AffineFastState.Bounded env25713 := by
  intro p hp
  have h : env25713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25712_25713 : H12AffineEnvironment.transform 13 5377 env25712 = env25713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25712 == env25713) = true)

theorem identity25713 : scanCanonicalize (H12AffineFastState.compose env25713 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound25713 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5377,32768,33111,4096,3173,1024,32769,4161,34097,16,3,1101,65,36112,5392,4097,35188,1365,32,256,33,36928,34576]

theorem envBound25714 : H12AffineFastState.Bounded env25714 := by
  intro p hp
  have h : env25714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25713_25714 : H12AffineEnvironment.transform 12 1101 env25713 = env25714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env25713 == env25714) = true)

theorem identity25714 : scanCanonicalize (H12AffineFastState.compose env25714 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound25714 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env25715 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4113,32768,33111,4096,2421,272,32769,4161,32801,16,3,349,65,34816,4096,4097,35188,69,32,256,33,36928,33280]

theorem envBound25715 : H12AffineFastState.Bounded env25715 := by
  intro p hp
  have h : env25715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25714_25715 : H12AffineEnvironment.transform 9 272 env25714 = env25715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env25714 == env25715) = true)

theorem identity25715 : scanCanonicalize (H12AffineFastState.compose env25715 (packedSelected [2,4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound25715 : packedSelected [2,4,9,16] rootPS < 2^1333 := by decide +kernel

def env25716 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4113,373,34,4096,2421,272,372,4161,340,16,3,349,65,2421,4096,4097,2049,69,32,256,33,4405,885]

theorem envBound25716 : H12AffineFastState.Bounded env25716 := by
  intro p hp
  have h : env25716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25715_25716 : H12AffineEnvironment.transform 14 373 env25715 = env25716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env25715 == env25716) = true)

theorem identity25716 : scanCanonicalize (H12AffineFastState.compose env25716 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 2400) := by decide +kernel

theorem selectedBound25716 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env25717 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2400,349,2417,373,34,2400,2421,272,372,2337,340,16,3,349,65,2421,2400,2401,2049,69,32,256,33,2133,885]

theorem envBound25717 : H12AffineFastState.Bounded env25717 := by
  intro p hp
  have h : env25717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25716_25717 : H12AffineEnvironment.transform 11 2400 env25716 = env25717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2400 env25716 == env25717) = true)

theorem identity25717 : scanCanonicalize (H12AffineFastState.compose env25717 (packedSelected [4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 808) := by decide +kernel

theorem selectedBound25717 : packedSelected [4,6,8] rootPS < 2^1333 := by decide +kernel

def env25718 : List Nat := [2,4,8,16,32,64,8,256,512,272,808,584,349,601,373,34,584,605,272,372,521,340,16,3,349,65,605,584,585,809,69,32,256,33,893,885]

theorem envBound25718 : H12AffineFastState.Bounded env25718 := by
  intro p hp
  have h : env25718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25717_25718 : H12AffineEnvironment.transform 10 808 env25717 = env25718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 808 env25717 == env25718) = true)

theorem identity25718 : scanCanonicalize (H12AffineFastState.compose env25718 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25718 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env25719 : List Nat := [2,4,8,16,32,64,8,37,512,53,525,584,120,601,80,34,584,605,53,81,521,113,16,3,120,65,605,584,585,524,69,32,37,33,600,592]

theorem envBound25719 : H12AffineFastState.Bounded env25719 := by
  intro p hp
  have h : env25719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25718_25719 : H12AffineEnvironment.transform 7 37 env25718 = env25719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25718 == env25719) = true)

theorem identity25719 : scanCanonicalize (H12AffineFastState.compose env25719 (packedSelected [1,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound25719 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env25720 : List Nat := [2,4,8,16,32,48,8,37,512,53,525,568,8,553,32,34,568,557,53,33,521,1,16,3,8,49,557,568,569,524,53,32,37,33,552,544]

theorem envBound25720 : H12AffineFastState.Bounded env25720 := by
  intro p hp
  have h : env25720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25719_25720 : H12AffineEnvironment.transform 5 48 env25719 = env25720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env25719 == env25720) = true)

def env25721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130174,1024,32769,4161,62588,119879,21762,8193,65,75786,115015,102743,35189,1364,119926,256,21792,46092,74250]

theorem envBound25721 : H12AffineFastState.Bounded env25721 := by
  intro p hp
  have h : env25721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25710_25721 : H12AffineEnvironment.transform 6 9 env25710 = env25721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25710 == env25721) = true)

theorem identity25721 : scanCanonicalize (H12AffineFastState.compose env25721 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25721 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24908,56437,1024,32769,4161,62588,62540,21762,8193,65,2049,57676,45404,35189,1364,62589,256,21792,46092,513]

theorem envBound25722 : H12AffineFastState.Bounded env25722 := by
  intro p hp
  have h : env25722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25721_25722 : H12AffineEnvironment.transform 15 8203 env25721 = env25722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25721 == env25722) = true)

def env25723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130175,1024,32769,4161,62708,120014,21762,8328,65,75787,115150,102878,35324,1501,119927,256,21792,46213,74250]

theorem envBound25723 : H12AffineFastState.Bounded env25723 := by
  intro p hp
  have h : env25723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25709_25723 : H12AffineEnvironment.transform 16 24909 env25709 = env25723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env25709 == env25723) = true)

def env25724 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130175,1024,32769,4161,62588,119878,21762,8192,65,75787,115014,102742,35188,1365,119927,256,21792,46093,74250]

theorem envBound25724 : H12AffineFastState.Bounded env25724 := by
  intro p hp
  have h : env25724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25723_25724 : H12AffineEnvironment.transform 6 8 env25723 = env25724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25723 == env25724) = true)

theorem identity25724 : scanCanonicalize (H12AffineFastState.compose env25724 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound25724 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25725 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,13389,108927,1024,32769,4161,41340,98630,2,8192,65,75787,103494,102742,35188,1365,98679,256,32,46093,74250]

theorem envBound25725 : H12AffineFastState.Bounded env25725 := by
  intro p hp
  have h : env25725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25724_25725 : H12AffineEnvironment.transform 13 5376 env25724 = env25725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25724 == env25725) = true)

theorem identity25725 : scanCanonicalize (H12AffineFastState.compose env25725 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound25725 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env25726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,40970,13389,2421,1024,32769,4161,41340,8524,2,8192,65,34817,13388,12636,35188,1365,8573,256,32,46093,33280]

theorem envBound25726 : H12AffineFastState.Bounded env25726 := by
  intro p hp
  have h : env25726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25725_25726 : H12AffineEnvironment.transform 15 40970 env25725 = env25726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env25725 == env25726) = true)

theorem identity25726 : scanCanonicalize (H12AffineFastState.compose env25726 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound25726 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env25727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,342,13389,2421,1024,8541,4161,32,8524,2,8192,65,10589,13388,12636,10280,1365,8573,256,32,5457,9052]

theorem envBound25727 : H12AffineFastState.Bounded env25727 := by
  intro p hp
  have h : env25727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25726_25727 : H12AffineEnvironment.transform 14 8540 env25726 = env25727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env25726 == env25727) = true)

theorem identity25727 : scanCanonicalize (H12AffineFastState.compose env25727 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound25727 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env25728 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,372,342,5221,2421,1024,373,4161,32,356,2,40,65,2421,5220,4468,2048,1365,341,256,32,5457,884]

theorem envBound25728 : H12AffineFastState.Bounded env25728 := by
  intro p hp
  have h : env25728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25727_25728 : H12AffineEnvironment.transform 12 40 env25727 = env25728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env25727 == env25728) = true)

theorem identity25728 : scanCanonicalize (H12AffineFastState.compose env25728 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25728 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env25729 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5376,292,262,5173,2341,1024,293,4113,32,308,2,40,17,2341,5172,4388,2048,1285,261,256,32,5377,804]

theorem envBound25729 : H12AffineFastState.Bounded env25729 := by
  intro p hp
  have h : env25729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25728_25729 : H12AffineEnvironment.transform 5 16 env25728 = env25729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25728 == env25729) = true)

theorem identity25729 : scanCanonicalize (H12AffineFastState.compose env25729 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25729 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env25730 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5156,0,34,5173,2049,1024,1,4113,32,16,2,40,17,2049,5172,4096,2048,1057,33,36,32,5157,512]

theorem envBound25730 : H12AffineFastState.Bounded env25730 := by
  intro p hp
  have h : env25730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25729_25730 : H12AffineEnvironment.transform 7 36 env25729 = env25730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25729 == env25730) = true)

theorem identity25730 : scanCanonicalize (H12AffineFastState.compose env25730 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25730 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25731 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,8,5124,0,2,5141,2049,1024,1,4113,0,16,2,8,17,2049,5140,4096,2048,1025,1,4,0,5125,512]

theorem envBound25731 : H12AffineFastState.Bounded env25731 := by
  intro p hp
  have h : env25731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25730_25731 : H12AffineEnvironment.transform 4 0 env25730 = env25731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25730 == env25731) = true)

theorem identity25731 : scanCanonicalize (H12AffineFastState.compose env25731 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound25731 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25732 : List Nat := [2,4,8,16,0,16,8,4,512,1024,522,4096,8,5124,0,2,5141,523,1024,1,4113,0,16,2,8,17,523,5140,4096,522,1025,1,4,0,5125,512]

theorem envBound25732 : H12AffineFastState.Bounded env25732 := by
  intro p hp
  have h : env25732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25731_25732 : H12AffineEnvironment.transform 10 522 env25731 = env25732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env25731 == env25732) = true)

def env25733 : List Nat := [2,4,8,16,0,16,8,4,512,1024,522,16,8,1044,0,2,1029,523,1024,1,1,0,16,2,8,17,523,1028,16,522,1025,1,4,0,1045,512]

theorem envBound25733 : H12AffineFastState.Bounded env25733 := by
  intro p hp
  have h : env25733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25732_25733 : H12AffineEnvironment.transform 11 16 env25732 = env25733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env25732 == env25733) = true)

theorem identity25733 : scanCanonicalize (H12AffineFastState.compose env25733 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound25733 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25734 : List Nat := [2,4,8,16,0,16,8,4,31,1024,21,16,8,1044,0,2,1029,20,1024,1,1,0,16,2,8,17,20,1028,16,21,1025,1,4,0,1045,31]

theorem envBound25734 : H12AffineFastState.Bounded env25734 := by
  intro p hp
  have h : env25734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25733_25734 : H12AffineEnvironment.transform 8 31 env25733 = env25734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env25733 == env25734) = true)

def env25735 : List Nat := [2,4,8,16,0,16,8,4,31,0,21,16,8,20,0,2,5,20,0,1,1,0,16,2,8,17,20,4,16,21,1,1,4,0,21,31]

theorem envBound25735 : H12AffineFastState.Bounded env25735 := by
  intro p hp
  have h : env25735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25734_25735 : H12AffineEnvironment.transform 9 0 env25734 = env25735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env25734 == env25735) = true)

theorem identity25735 : scanCanonicalize (H12AffineFastState.compose env25735 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound25735 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25736 : List Nat := [2,4,8,7,0,7,8,4,8,0,2,7,8,3,0,2,5,3,0,1,1,0,7,2,8,6,3,4,7,2,1,1,4,0,2,8]

theorem envBound25736 : H12AffineFastState.Bounded env25736 := by
  intro p hp
  have h : env25736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25735_25736 : H12AffineEnvironment.transform 3 7 env25735 = env25736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env25735 == env25736) = true)

def leafEnv25736 : List Nat := [2,4,8,7,0,7,8,4,8,0,2,7,8,3,0,2,5,3,0,1,1,0,7,2,0,8,1,6,3,4,7,2,1,1,4,0,5,2,2,8,1,0,0]

def active25736 : List Nat := [0,1,2]

def tree25736 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25736 : H12WitnessSearch.Good tree25736 := H12GlobalWitnessIndex.good

theorem leafIdentity25736 : H12AffineFastState.composeSystem env25736 rootObs = leafEnv25736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25736 rootObs == leafEnv25736) = true)

theorem terminalChecked25736 : H12PackedTerminal.terminalCheckFast leafEnv25736 active25736 tree25736 = true := by decide +kernel

def env25737 : List Nat := [2,4,8,16,0,16,8,4,31,1,21,16,8,21,0,2,4,20,1,1,1,0,16,2,8,17,20,5,16,21,0,1,4,0,20,31]

theorem envBound25737 : H12AffineFastState.Bounded env25737 := by
  intro p hp
  have h : env25737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25734_25737 : H12AffineEnvironment.transform 9 1 env25734 = env25737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env25734 == env25737) = true)

theorem identity25737 : scanCanonicalize (H12AffineFastState.compose env25737 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound25737 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25738 : List Nat := [0,4,8,16,0,16,8,4,29,1,21,16,8,21,0,0,4,20,1,1,1,0,16,0,8,17,20,5,16,21,0,1,4,0,20,29]

theorem envBound25738 : H12AffineFastState.Bounded env25738 := by
  intro p hp
  have h : env25738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25737_25738 : H12AffineEnvironment.transform 0 0 env25737 = env25738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env25737 == env25738) = true)

def leafEnv25738 : List Nat := [0,4,8,16,0,16,8,4,29,1,21,16,8,21,0,0,4,20,1,1,1,0,16,0,1,8,1,17,20,5,16,21,0,1,4,0,5,0,20,29,1,0,0]

def active25738 : List Nat := [1,2,3]

def tree25738 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25738 : H12WitnessSearch.Good tree25738 := H12GlobalWitnessIndex.good

theorem leafIdentity25738 : H12AffineFastState.composeSystem env25738 rootObs = leafEnv25738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25738 rootObs == leafEnv25738) = true)

theorem terminalChecked25738 : H12PackedTerminal.terminalCheckFast leafEnv25738 active25738 tree25738 = true := by decide +kernel

def env25739 : List Nat := [2,4,8,16,0,16,8,4,512,1024,522,17,8,1045,0,2,1028,523,1024,1,0,0,16,2,8,17,523,1029,17,522,1025,1,4,0,1044,512]

theorem envBound25739 : H12AffineFastState.Bounded env25739 := by
  intro p hp
  have h : env25739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25732_25739 : H12AffineEnvironment.transform 11 17 env25732 = env25739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env25732 == env25739) = true)

theorem identity25739 : scanCanonicalize (H12AffineFastState.compose env25739 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 522) := by decide +kernel

theorem selectedBound25739 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25740 : List Nat := [2,4,8,16,0,16,8,4,512,522,522,17,8,543,0,2,526,523,522,1,0,0,16,2,8,17,523,527,17,522,523,1,4,0,542,512]

theorem envBound25740 : H12AffineFastState.Bounded env25740 := by
  intro p hp
  have h : env25740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25739_25740 : H12AffineEnvironment.transform 9 522 env25739 = env25740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 522 env25739 == env25740) = true)

def env25741 : List Nat := [2,4,8,4,0,4,8,4,512,522,522,5,8,523,0,2,526,523,522,1,0,0,4,2,8,5,523,527,5,522,523,1,4,0,522,512]

theorem envBound25741 : H12AffineFastState.Bounded env25741 := by
  intro p hp
  have h : env25741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25740_25741 : H12AffineEnvironment.transform 3 4 env25740 = env25741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env25740 == env25741) = true)

theorem identity25741 : scanCanonicalize (H12AffineFastState.compose env25741 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound25741 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25742 : List Nat := [2,4,8,4,0,4,8,4,9,3,3,5,8,2,0,2,7,2,3,1,0,0,4,2,8,5,2,6,5,3,2,1,4,0,3,9]

theorem envBound25742 : H12AffineFastState.Bounded env25742 := by
  intro p hp
  have h : env25742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25741_25742 : H12AffineEnvironment.transform 8 9 env25741 = env25742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env25741 == env25742) = true)

def leafEnv25742 : List Nat := [2,4,8,4,0,4,8,4,9,3,3,5,8,2,0,2,7,2,3,1,0,0,4,2,3,8,1,5,2,6,5,3,2,1,4,0,5,2,3,9,1,1,0]

def active25742 : List Nat := [0,1,2]

def tree25742 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25742 : H12WitnessSearch.Good tree25742 := H12GlobalWitnessIndex.good

theorem leafIdentity25742 : H12AffineFastState.composeSystem env25742 rootObs = leafEnv25742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25742 rootObs == leafEnv25742) = true)

theorem terminalChecked25742 : H12PackedTerminal.terminalCheckFast leafEnv25742 active25742 tree25742 = true := by decide +kernel

def env25743 : List Nat := [2,4,8,5,0,5,8,4,512,522,522,4,8,522,0,2,526,523,522,1,0,0,5,2,8,4,523,527,4,522,523,1,4,0,523,512]

theorem envBound25743 : H12AffineFastState.Bounded env25743 := by
  intro p hp
  have h : env25743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25740_25743 : H12AffineEnvironment.transform 3 5 env25740 = env25743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env25740 == env25743) = true)

theorem identity25743 : scanCanonicalize (H12AffineFastState.compose env25743 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound25743 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25744 : List Nat := [0,4,8,5,0,5,8,4,512,520,520,4,8,520,0,0,524,521,520,1,0,0,5,0,8,4,521,525,4,520,521,1,4,0,521,512]

theorem envBound25744 : H12AffineFastState.Bounded env25744 := by
  intro p hp
  have h : env25744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25743_25744 : H12AffineEnvironment.transform 0 0 env25743 = env25744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env25743 == env25744) = true)

def leafEnv25744 : List Nat := [0,4,8,5,0,5,8,4,512,520,520,4,8,520,0,0,524,521,520,1,0,0,5,0,520,8,1,4,521,525,4,520,521,1,4,0,5,0,521,512,1,1,0]

def active25744 : List Nat := [1,2,8]

def tree25744 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25744 : H12WitnessSearch.Good tree25744 := H12GlobalWitnessIndex.good

theorem leafIdentity25744 : H12AffineFastState.composeSystem env25744 rootObs = leafEnv25744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25744 rootObs == leafEnv25744) = true)

theorem terminalChecked25744 : H12PackedTerminal.terminalCheckFast leafEnv25744 active25744 tree25744 = true := by decide +kernel

def env25745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130175,1024,32769,4161,62589,119879,21762,8193,65,75787,115015,102743,35189,1364,119927,256,21792,46092,74250]

theorem envBound25745 : H12AffineFastState.Bounded env25745 := by
  intro p hp
  have h : env25745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25723_25745 : H12AffineEnvironment.transform 6 9 env25723 = env25745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25723 == env25745) = true)

theorem identity25745 : scanCanonicalize (H12AffineFastState.compose env25745 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound25745 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,24909,67618,1024,29788,4161,32,73754,21762,8193,65,75787,79130,91402,32040,1364,73770,256,21792,16465,74250]

theorem envBound25746 : H12AffineFastState.Bounded env25746 := by
  intro p hp
  have h : env25746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25745_25746 : H12AffineEnvironment.transform 14 29789 env25745 = env25746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env25745 == env25746) = true)

theorem identity25746 : scanCanonicalize (H12AffineFastState.compose env25746 (packedSelected [0,1,2,6,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound25746 : packedSelected [0,1,2,6,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env25747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8283,24909,10361,1024,29788,4161,32,65,21762,8193,65,2128,5441,17745,32040,1364,113,256,21792,16465,593]

theorem envBound25747 : H12AffineFastState.Bounded env25747 := by
  intro p hp
  have h : env25747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25746_25747 : H12AffineEnvironment.transform 15 8283 env25746 = env25747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env25746 == env25747) = true)

theorem identity25747 : scanCanonicalize (H12AffineFastState.compose env25747 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound25747 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env25748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,81,8283,5441,10361,1024,80,4161,32,65,8462,8193,65,2128,5441,12637,2340,1364,113,256,8492,13405,593]

theorem envBound25748 : H12AffineFastState.Bounded env25748 := by
  intro p hp
  have h : env25748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25747_25748 : H12AffineEnvironment.transform 13 13324 env25747 = env25748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env25747 == env25748) = true)

theorem identity25748 : scanCanonicalize (H12AffineFastState.compose env25748 (packedSelected [2,3,4,5,6,7,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound25748 : packedSelected [2,3,4,5,6,7,11,12,14] rootPS < 2^1333 := by decide +kernel

def env25749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,8192,11576,81,8283,3189,10361,1024,80,2421,32,65,8462,8193,65,2128,3189,10345,2340,1364,113,256,8492,11625,593]

theorem envBound25749 : H12AffineFastState.Bounded env25749 := by
  intro p hp
  have h : env25749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25748_25749 : H12AffineEnvironment.transform 11 2356 env25748 = env25749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env25748 == env25749) = true)

theorem identity25749 : scanCanonicalize (H12AffineFastState.compose env25749 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound25749 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env25750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,41,3345,81,114,3189,2128,1024,80,2421,32,65,295,40,65,2128,3189,2112,2340,1364,113,256,261,3392,593]

theorem envBound25750 : H12AffineFastState.Bounded env25750 := by
  intro p hp
  have h : env25750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25749_25750 : H12AffineEnvironment.transform 12 41 env25749 = env25750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env25749 == env25750) = true)

theorem identity25750 : scanCanonicalize (H12AffineFastState.compose env25750 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25750 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env25751 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2356,41,3345,1,34,3109,2048,1024,0,2341,32,17,295,40,17,2048,3109,2064,2340,1284,33,256,261,3344,513]

theorem envBound25751 : H12AffineFastState.Bounded env25751 := by
  intro p hp
  have h : env25751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25750_25751 : H12AffineEnvironment.transform 5 16 env25750 = env25751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25750 == env25751) = true)

def env25752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262521,412156,2114883,8328,65,215367,115150,2497709,35324,2590894,2336122,256,509970,469431,2535289]

theorem envBound25752 : H12AffineFastState.Bounded env25752 := by
  intro p hp
  have h : env25752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25695_25752 : H12AffineEnvironment.transform 21 2262521 env25695 = env25752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262521 env25695 == env25752) = true)

def env25753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412156,21763,8328,65,215367,115150,396525,35324,497902,243002,256,509970,469431,442169]

theorem envBound25753 : H12AffineFastState.Bounded env25753 := by
  intro p hp
  have h : env25753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25752_25753 : H12AffineEnvironment.transform 20 4160 env25752 = env25753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25752 == env25753) = true)

theorem identity25753 : scanCanonicalize (H12AffineFastState.compose env25753 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223719) := by decide +kernel

theorem selectedBound25753 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4160,169401,73755,21763,8328,65,215367,115150,91402,35324,61705,243002,256,41461,16464,120542]

theorem envBound25754 : H12AffineFastState.Bounded env25754 := by
  intro p hp
  have h : env25754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25753_25754 : H12AffineEnvironment.transform 17 223719 env25753 = env25754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223719 env25753 == env25754) = true)

def env25755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,67755,1024,32769,4160,62709,73755,21763,8328,65,75787,115150,91402,35324,61705,119926,256,41461,16464,120542]

theorem envBound25755 : H12AffineFastState.Bounded env25755 := by
  intro p hp
  have h : env25755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25754_25755 : H12AffineEnvironment.transform 16 24908 env25754 = env25755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env25754 == env25755) = true)

theorem identity25755 : scanCanonicalize (H12AffineFastState.compose env25755 (packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound25755 : packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env25756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,65536,24908,67755,1024,137,4160,29821,73755,21763,8328,65,75787,82246,91402,2420,29057,87294,256,8573,16464,87638]

theorem envBound25756 : H12AffineFastState.Bounded env25756 := by
  intro p hp
  have h : env25756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25755_25756 : H12AffineEnvironment.transform 14 136 env25755 = env25756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env25755 == env25756) = true)

theorem identity25756 : scanCanonicalize (H12AffineFastState.compose env25756 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25756 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env25757 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,24908,67618,1024,0,4160,29821,73755,21763,8193,65,75787,82246,91402,2420,28936,87159,256,8573,16464,87638]

theorem envBound25757 : H12AffineFastState.Bounded env25757 := by
  intro p hp
  have h : env25757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25756_25757 : H12AffineEnvironment.transform 6 9 env25756 = env25757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25756 == env25757) = true)

theorem identity25757 : scanCanonicalize (H12AffineFastState.compose env25757 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound25757 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25758 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,21591,24908,23669,1024,0,4160,29821,29772,21763,8193,65,31836,5393,12637,2420,28936,32,256,8573,16464,513]

theorem envBound25758 : H12AffineFastState.Bounded env25758 := by
  intro p hp
  have h : env25758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25757_25758 : H12AffineEnvironment.transform 15 21591 env25757 = env25758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env25757 == env25758) = true)

def env25759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67754,1024,32769,4160,62708,73755,21763,8328,65,75786,115150,91402,35324,61705,119927,256,41461,16464,120542]

theorem envBound25759 : H12AffineFastState.Bounded env25759 := by
  intro p hp
  have h : env25759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25754_25759 : H12AffineEnvironment.transform 16 24909 env25754 = env25759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env25754 == env25759) = true)

theorem identity25759 : scanCanonicalize (H12AffineFastState.compose env25759 (packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound25759 : packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env25760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,65536,5393,67754,1024,32769,4160,32936,73755,8543,8328,65,75786,112018,69974,35324,34133,106539,256,41461,13324,107138]

theorem envBound25760 : H12AffineFastState.Bounded env25760 := by
  intro p hp
  have h : env25760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25759_25760 : H12AffineEnvironment.transform 13 13404 env25759 = env25760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env25759 == env25760) = true)

theorem identity25760 : scanCanonicalize (H12AffineFastState.compose env25760 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound25760 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env25761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,33110,5393,35324,1024,32769,4160,32936,41293,8543,8328,65,43356,13508,36864,35324,34133,8573,256,41461,13324,9172]

theorem envBound25761 : H12AffineFastState.Bounded env25761 := by
  intro p hp
  have h : env25761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25760_25761 : H12AffineEnvironment.transform 15 33110 env25760 = env25761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env25760 == env25761) = true)

theorem identity25761 : scanCanonicalize (H12AffineFastState.compose env25761 (packedSelected [16,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound25761 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env25762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,479,5393,2421,1024,136,4160,33,8644,8543,8328,65,10709,13508,4233,2421,1500,8573,256,8572,13324,9172]

theorem envBound25762 : H12AffineFastState.Bounded env25762 := by
  intro p hp
  have h : env25762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25761_25762 : H12AffineEnvironment.transform 14 137 env25761 = env25762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env25761 == env25762) = true)

theorem identity25762 : scanCanonicalize (H12AffineFastState.compose env25762 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound25762 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env25763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,137,479,5393,2421,1024,136,4160,33,16,139,348,65,2049,5392,4233,2421,1500,169,256,168,5592,512]

theorem envBound25763 : H12AffineFastState.Bounded env25763 := by
  intro p hp
  have h : env25763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25762_25763 : H12AffineEnvironment.transform 12 468 env25762 = env25763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env25762 == env25763) = true)

theorem identity25763 : scanCanonicalize (H12AffineFastState.compose env25763 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound25763 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25764 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,380,5408,33,375,5393,2421,1024,32,4160,33,16,35,348,65,2049,5392,4129,2421,1396,1,256,0,5488,512]

theorem envBound25764 : H12AffineFastState.Bounded env25764 := by
  intro p hp
  have h : env25764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25763_25764 : H12AffineEnvironment.transform 6 40 env25763 = env25764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env25763 == env25764) = true)

theorem identity25764 : scanCanonicalize (H12AffineFastState.compose env25764 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound25764 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env25765 : List Nat := [2,4,8,16,32,64,40,117,512,1024,2048,4096,9,5205,33,2,5220,2048,1024,32,4160,33,16,35,41,65,2049,5221,4129,2048,1025,1,117,0,5125,512]

theorem envBound25765 : H12AffineFastState.Bounded env25765 := by
  intro p hp
  have h : env25765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25764_25765 : H12AffineEnvironment.transform 7 117 env25764 = env25765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env25764 == env25765) = true)

theorem identity25765 : scanCanonicalize (H12AffineFastState.compose env25765 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound25765 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env25766 : List Nat := [2,4,8,16,32,64,40,117,512,1024,2048,2064,9,3141,33,2,3188,2048,1024,32,2128,33,16,35,41,65,2049,3189,2097,2048,1025,1,117,0,3093,512]

theorem envBound25766 : H12AffineFastState.Bounded env25766 := by
  intro p hp
  have h : env25766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25765_25766 : H12AffineEnvironment.transform 11 2064 env25765 = env25766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env25765 == env25766) = true)

def env25767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412156,21762,8328,65,215367,115150,396524,35324,497903,243003,256,509970,469431,442168]

theorem envBound25767 : H12AffineFastState.Bounded env25767 := by
  intro p hp
  have h : env25767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25752_25767 : H12AffineEnvironment.transform 20 4161 env25752 = env25767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25752 == env25767) = true)

theorem identity25767 : scanCanonicalize (H12AffineFastState.compose env25767 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound25767 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4161,169400,412156,21762,8328,65,171417,5392,396524,35324,412721,156133,256,400588,458089,442168]

theorem envBound25768 : H12AffineFastState.Bounded env25768 := by
  intro p hp
  have h : env25768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25767_25768 : H12AffineEnvironment.transform 15 54494 env25767 = env25768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env25767 == env25768) = true)

def env25769 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1024,32769,4113,169400,412076,21762,8328,17,171417,5392,396476,35244,412721,156085,256,400540,458041,442168]

theorem envBound25769 : H12AffineFastState.Bounded env25769 := by
  intro p hp
  have h : env25769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25768_25769 : H12AffineEnvironment.transform 5 16 env25768 = env25769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25768 == env25769) = true)

theorem identity25769 : scanCanonicalize (H12AffineFastState.compose env25769 (packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 43168) := by decide +kernel

theorem selectedBound25769 : packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env25770 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,43168,1024,32769,4113,169400,188684,21762,8328,17,171417,5392,173084,35244,189585,156085,256,177212,152985,137112]

theorem envBound25770 : H12AffineFastState.Bounded env25770 := by
  intro p hp
  have h : env25770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25769_25770 : H12AffineEnvironment.transform 17 43168 env25769 = env25770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43168 env25769 == env25770) = true)

theorem identity25770 : scanCanonicalize (H12AffineFastState.compose env25770 (packedSelected [3,4,5,7,8,9,17,18,23,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 57748) := by decide +kernel

theorem selectedBound25770 : packedSelected [3,4,5,7,8,9,17,18,23,27,28] rootPS < 2^1333 := by decide +kernel

def env25771 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,57748,43168,1024,32769,4113,29740,152,21762,8328,17,31757,5392,17800,35244,1285,32801,256,21928,46093,62988]

theorem envBound25771 : H12AffineFastState.Bounded env25771 := by
  intro p hp
  have h : env25771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25770_25771 : H12AffineEnvironment.transform 16 57748 env25770 = env25771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57748 env25770 == env25771) = true)

theorem identity25771 : scanCanonicalize (H12AffineFastState.compose env25771 (packedSelected [0,1,3,4,5,7,8,10,17,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound25771 : packedSelected [0,1,3,4,5,7,8,10,17,22,26] rootPS < 2^1333 := by decide +kernel

def env25772 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29709,8323,5529,23725,1024,29708,4113,29740,152,21762,8328,17,31757,5392,17800,32161,1285,29740,256,21928,16384,513]

theorem envBound25772 : H12AffineFastState.Bounded env25772 := by
  intro p hp
  have h : env25772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25771_25772 : H12AffineEnvironment.transform 14 29709 env25771 = env25772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env25771 == env25772) = true)

theorem identity25772 : scanCanonicalize (H12AffineFastState.compose env25772 (packedSelected [1,2,3,5,6,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound25772 : packedSelected [1,2,3,5,6,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env25773 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21760,398,5529,23725,1024,21761,4113,21793,152,21762,389,17,23808,5392,17800,23724,1285,21793,256,21928,16384,513]

theorem envBound25773 : H12AffineFastState.Bounded env25773 := by
  intro p hp
  have h : env25773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25772_25773 : H12AffineEnvironment.transform 12 269 env25772 = env25773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env25772 == env25773) = true)

theorem identity25773 : scanCanonicalize (H12AffineFastState.compose env25773 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound25773 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25774 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5512,136,398,5529,2341,1024,137,4113,169,152,138,389,17,2184,5392,4096,2340,1285,169,256,32,5512,513]

theorem envBound25774 : H12AffineFastState.Bounded env25774 := by
  intro p hp
  have h : env25774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25773_25774 : H12AffineEnvironment.transform 13 5512 env25773 = env25774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env25773 == env25774) = true)

theorem identity25774 : scanCanonicalize (H12AffineFastState.compose env25774 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound25774 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env25775 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,17,269,1433,136,398,1416,2341,1024,137,0,169,152,138,389,17,2184,1281,17,2340,1285,169,256,32,1433,513]

theorem envBound25775 : H12AffineFastState.Bounded env25775 := by
  intro p hp
  have h : env25775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25774_25775 : H12AffineEnvironment.transform 11 17 env25774 = env25775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env25774 == env25775) = true)

theorem identity25775 : scanCanonicalize (H12AffineFastState.compose env25775 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound25775 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25776 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,17,269,0,136,398,17,2341,409,137,0,169,152,138,389,17,2184,152,17,2340,156,169,256,32,0,513]

theorem envBound25776 : H12AffineFastState.Bounded env25776 := by
  intro p hp
  have h : env25776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25775_25776 : H12AffineEnvironment.transform 9 409 env25775 = env25776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env25775 == env25776) = true)

theorem identity25776 : scanCanonicalize (H12AffineFastState.compose env25776 (packedSelected [1,2,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound25776 : packedSelected [1,2,8,11] rootPS < 2^1333 := by decide +kernel

def env25777 : List Nat := [2,4,8,16,32,16,128,256,512,409,137,17,269,0,136,398,17,428,409,137,0,169,152,138,389,17,1,152,17,429,156,169,256,32,0,513]

theorem envBound25777 : H12AffineFastState.Bounded env25777 := by
  intro p hp
  have h : env25777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25776_25777 : H12AffineEnvironment.transform 10 137 env25776 = env25777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env25776 == env25777) = true)

def env25778 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1024,32769,4112,169400,412077,21762,8328,16,171417,5392,396477,35245,412721,156084,256,400541,458040,442168]

theorem envBound25778 : H12AffineFastState.Bounded env25778 := by
  intro p hp
  have h : env25778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25768_25778 : H12AffineEnvironment.transform 5 17 env25768 = env25778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25768 == env25778) = true)

theorem identity25778 : scanCanonicalize (H12AffineFastState.compose env25778 (packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound25778 : packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env25779 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,32768,54415,131072,262144,1024,32769,4112,169400,412077,21762,268,16,171417,5392,396477,35245,412721,147504,256,400541,449724,433852]

theorem envBound25779 : H12AffineFastState.Bounded env25779 := by
  intro p hp
  have h : env25779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25778_25779 : H12AffineEnvironment.transform 12 388 env25778 = env25779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env25778 == env25779) = true)

theorem identity25779 : scanCanonicalize (H12AffineFastState.compose env25779 (packedSelected [0,1,5,8,9,10,16,18,20,22,23,24,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound25779 : packedSelected [0,1,5,8,9,10,16,18,20,22,23,24,27,31] rootPS < 2^1333 := by decide +kernel

def env25780 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,32768,54415,131072,35108,1024,32769,4112,169400,180361,21762,268,16,171417,5392,165273,35245,181525,147504,256,169401,152984,137112]

theorem envBound25780 : H12AffineFastState.Bounded env25780 := by
  intro p hp
  have h : env25780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25779_25780 : H12AffineEnvironment.transform 17 35108 env25779 = env25780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env25779 == env25780) = true)

theorem identity25780 : scanCanonicalize (H12AffineFastState.compose env25780 (packedSelected [0,1,3,4,5,7,8,10,22,26] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound25780 : packedSelected [0,1,3,4,5,7,8,10,22,26] rootPS < 2^1333 := by decide +kernel

def env25781 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,32768,54415,5529,35108,1024,32769,4112,32801,54544,21762,268,16,34816,5392,36864,35245,53388,21929,256,32800,16385,513]

theorem envBound25781 : H12AffineFastState.Bounded env25781 := by
  intro p hp
  have h : env25781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25780_25781 : H12AffineEnvironment.transform 16 5529 env25780 = env25781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env25780 == env25781) = true)

theorem identity25781 : scanCanonicalize (H12AffineFastState.compose env25781 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound25781 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env25782 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,137,21510,5529,2477,1024,136,4112,168,21913,21762,268,16,2185,5392,4233,2340,20485,21929,256,169,16385,513]

theorem envBound25782 : H12AffineFastState.Bounded env25782 := by
  intro p hp
  have h : env25782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25781_25782 : H12AffineEnvironment.transform 14 137 env25781 = env25782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env25781 == env25782) = true)

theorem identity25782 : scanCanonicalize (H12AffineFastState.compose env25782 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound25782 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25783 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5513,137,399,5529,2477,1024,136,4112,168,16,139,268,16,2185,5392,4233,2340,1420,32,256,169,5512,513]

theorem envBound25783 : H12AffineFastState.Bounded env25783 := by
  intro p hp
  have h : env25783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25782_25783 : H12AffineEnvironment.transform 13 5513 env25782 = env25783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env25782 == env25783) = true)

theorem identity25783 : scanCanonicalize (H12AffineFastState.compose env25783 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 412) := by decide +kernel

theorem selectedBound25783 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25784 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,412,388,1045,137,399,1029,2477,1024,136,396,168,16,139,268,16,2185,1164,277,2340,1420,32,256,169,1044,513]

theorem envBound25784 : H12AffineFastState.Bounded env25784 := by
  intro p hp
  have h : env25784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25783_25784 : H12AffineEnvironment.transform 11 412 env25783 = env25784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 412 env25783 == env25784) = true)

def env25785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412157,2114882,8328,65,6409406,115151,2497708,35325,2590894,4268162,256,509970,469431,2535289]

theorem envBound25785 : H12AffineFastState.Bounded env25785 := by
  intro p hp
  have h : env25785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25694_25785 : H12AffineEnvironment.transform 22 412157 env25694 = env25785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412157 env25694 == env25785) = true)

def env25786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262520,412157,2114882,8328,65,215366,115151,2497708,35325,2590894,2336122,256,509970,469431,2535289]

theorem envBound25786 : H12AffineFastState.Bounded env25786 := by
  intro p hp
  have h : env25786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25785_25786 : H12AffineEnvironment.transform 21 2262520 env25785 = env25786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262520 env25785 == env25786) = true)

def env25787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412157,21762,8328,65,215366,115151,396524,35325,497902,243002,256,509970,469431,442169]

theorem envBound25787 : H12AffineFastState.Bounded env25787 := by
  intro p hp
  have h : env25787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25786_25787 : H12AffineEnvironment.transform 20 4160 env25786 = env25787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25786 == env25787) = true)

theorem identity25787 : scanCanonicalize (H12AffineFastState.compose env25787 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound25787 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4160,156013,412157,21762,8328,65,215366,79130,396524,32040,486459,213487,256,474311,469431,412652]

theorem envBound25788 : H12AffineFastState.Bounded env25788 := by
  intro p hp
  have h : env25788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25787_25788 : H12AffineEnvironment.transform 14 29909 env25787 = env25788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env25787 == env25788) = true)

def env25789 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,4112,155965,412077,21762,8328,17,215318,79130,396476,32040,486459,213439,256,474263,469431,412604]

theorem envBound25789 : H12AffineFastState.Bounded env25789 := by
  intro p hp
  have h : env25789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25788_25789 : H12AffineEnvironment.transform 5 16 env25788 = env25789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25788 == env25789) = true)

theorem identity25789 : scanCanonicalize (H12AffineFastState.compose env25789 (packedSelected [10,12,14,31,35,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound25789 : packedSelected [10,12,14,31,35,41] rootPS < 2^1333 := by decide +kernel

def env25790 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,157752,1024,29828,4112,155965,8597,21762,8328,17,215318,79130,25732,32040,66563,213439,256,87215,82319,9092]

theorem envBound25790 : H12AffineFastState.Bounded env25790 := by
  intro p hp
  have h : env25790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25789_25790 : H12AffineEnvironment.transform 17 157752 env25789 = env25790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env25789 == env25790) = true)

theorem identity25790 : scanCanonicalize (H12AffineFastState.compose env25790 (packedSelected [0,1,9,10,16,18,20,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound25790 : packedSelected [0,1,9,10,16,18,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env25791 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,262,131072,157752,1024,29828,4112,155965,8597,21762,8328,17,149520,13340,25732,32040,1285,147641,256,21929,16521,9092]

theorem envBound25791 : H12AffineFastState.Bounded env25791 := by
  intro p hp
  have h : env25791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25790_25791 : H12AffineEnvironment.transform 15 262 env25790 = env25791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env25790 == env25791) = true)

theorem identity25791 : scanCanonicalize (H12AffineFastState.compose env25791 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound25791 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env25792 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,262,131072,146745,1024,8581,4112,144444,8597,3,8328,17,138513,13340,12677,10281,1285,136632,256,168,5512,9092]

theorem envBound25792 : H12AffineFastState.Bounded env25792 := by
  intro p hp
  have h : env25792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25791_25792 : H12AffineEnvironment.transform 13 5377 env25791 = env25792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25791 == env25792) = true)

theorem identity25792 : scanCanonicalize (H12AffineFastState.compose env25792 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound25792 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env25793 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,262,13341,2340,1024,8581,4112,33,8597,3,8328,17,10508,13340,12677,10281,1285,8613,256,168,5512,9092]

theorem envBound25793 : H12AffineFastState.Bounded env25793 := by
  intro p hp
  have h : env25793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25792_25793 : H12AffineEnvironment.transform 16 13341 env25792 = env25793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env25792 == env25793) = true)

theorem identity25793 : scanCanonicalize (H12AffineFastState.compose env25793 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 5253) := by decide +kernel

theorem selectedBound25793 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env25794 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5253,5377,5377,262,152,2340,1024,5376,4112,33,5392,3,5133,17,7561,153,1280,7340,1285,5408,256,168,5512,5889]

theorem envBound25794 : H12AffineFastState.Bounded env25794 := by
  intro p hp
  have h : env25794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25793_25794 : H12AffineEnvironment.transform 12 5253 env25793 = env25794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5253 env25793 == env25794) = true)

theorem identity25794 : scanCanonicalize (H12AffineFastState.compose env25794 (packedSelected [0,2,4,6,7,9,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound25794 : packedSelected [0,2,4,6,7,9,12,14] rootPS < 2^1333 := by decide +kernel

def env25795 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,16,1173,1297,1297,262,152,2340,1024,1296,0,33,1280,3,1053,17,3481,153,1280,3260,1285,1328,256,168,1432,1809]

theorem envBound25795 : H12AffineFastState.Bounded env25795 := by
  intro p hp
  have h : env25795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25794_25795 : H12AffineEnvironment.transform 11 16 env25794 = env25795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env25794 == env25795) = true)

theorem identity25795 : scanCanonicalize (H12AffineFastState.compose env25795 (packedSelected [4,9,15] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound25795 : packedSelected [4,9,15] rootPS < 2^1333 := by decide +kernel

def env25796 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,16,1173,1297,1297,262,152,293,1024,1296,0,33,1280,3,1053,17,1432,153,1280,1213,1285,1328,256,168,1432,1809]

theorem envBound25796 : H12AffineFastState.Bounded env25796 := by
  intro p hp
  have h : env25796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25795_25796 : H12AffineEnvironment.transform 10 1 env25795 = env25796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25795 == env25796) = true)

theorem identity25796 : scanCanonicalize (H12AffineFastState.compose env25796 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25796 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env25797 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,16,1053,1297,1297,262,16,293,1024,1296,0,33,1280,3,1053,17,1296,17,1280,1077,1285,1328,256,32,1296,1809]

theorem envBound25797 : H12AffineFastState.Bounded env25797 := by
  intro p hp
  have h : env25797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25796_25797 : H12AffineEnvironment.transform 6 8 env25796 = env25797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25796 == env25797) = true)

theorem identity25797 : scanCanonicalize (H12AffineFastState.compose env25797 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound25797 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25798 : List Nat := [2,4,8,16,32,16,8,256,512,20,1,16,9,261,261,262,16,293,20,260,0,33,276,3,9,17,260,17,276,33,273,292,256,32,260,773]

theorem envBound25798 : H12AffineFastState.Bounded env25798 := by
  intro p hp
  have h : env25798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25797_25798 : H12AffineEnvironment.transform 9 20 env25797 = env25798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env25797 == env25798) = true)

theorem identity25798 : scanCanonicalize (H12AffineFastState.compose env25798 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25798 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env25799 : List Nat := [2,4,8,16,0,16,8,256,512,20,1,16,9,261,261,262,16,261,20,260,0,1,276,3,9,17,260,17,276,1,273,260,256,0,260,773]

theorem envBound25799 : H12AffineFastState.Bounded env25799 := by
  intro p hp
  have h : env25799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25798_25799 : H12AffineEnvironment.transform 4 0 env25798 = env25799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25798 == env25799) = true)

theorem identity25799 : scanCanonicalize (H12AffineFastState.compose env25799 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound25799 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25800 : List Nat := [2,4,8,16,0,16,8,5,512,20,1,16,9,0,0,3,16,0,20,1,0,1,17,3,9,17,1,17,17,1,20,1,5,0,1,512]

theorem envBound25800 : H12AffineFastState.Bounded env25800 := by
  intro p hp
  have h : env25800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25799_25800 : H12AffineEnvironment.transform 7 5 env25799 = env25800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env25799 == env25800) = true)

theorem identity25800 : scanCanonicalize (H12AffineFastState.compose env25800 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound25800 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25801 : List Nat := [2,4,8,16,0,16,8,5,17,20,1,16,9,0,0,3,16,0,20,1,0,1,17,3,9,17,1,17,17,1,20,1,5,0,1,17]

theorem envBound25801 : H12AffineFastState.Bounded env25801 := by
  intro p hp
  have h : env25801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25800_25801 : H12AffineEnvironment.transform 8 17 env25800 = env25801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env25800 == env25801) = true)

theorem identity25801 : scanCanonicalize (H12AffineFastState.compose env25801 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound25801 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25802 : List Nat := [2,4,6,16,0,16,6,5,17,20,1,16,7,0,0,3,16,0,20,1,0,1,17,3,7,17,1,17,17,1,20,1,5,0,1,17]

theorem envBound25802 : H12AffineFastState.Bounded env25802 := by
  intro p hp
  have h : env25802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25801_25802 : H12AffineEnvironment.transform 2 6 env25801 = env25802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env25801 == env25802) = true)

def env25803 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,4113,155964,412076,21762,8328,16,215319,79130,396477,32040,486459,213438,256,474262,469431,412605]

theorem envBound25803 : H12AffineFastState.Bounded env25803 := by
  intro p hp
  have h : env25803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25788_25803 : H12AffineEnvironment.transform 5 17 env25788 = env25803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25788 == env25803) = true)

theorem identity25803 : scanCanonicalize (H12AffineFastState.compose env25803 (packedSelected [10,12,14,31,35,41] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound25803 : packedSelected [10,12,14,31,35,41] rootPS < 2^1333 := by decide +kernel

def env25804 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,21646,131072,262144,1024,29829,4113,155964,412076,21762,8328,16,138649,24980,396477,32040,407733,136496,256,419864,425273,412605]

theorem envBound25804 : H12AffineFastState.Bounded env25804 := by
  intro p hp
  have h : env25804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25803_25804 : H12AffineEnvironment.transform 15 21646 env25803 = env25804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env25803 == env25804) = true)

theorem identity25804 : scanCanonicalize (H12AffineFastState.compose env25804 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 138293) := by decide +kernel

theorem selectedBound25804 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env25805 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,21646,131072,138293,1024,29829,4113,155964,21913,21762,8328,16,138649,24980,4232,32040,9344,136496,256,29741,24844,22408]

theorem envBound25805 : H12AffineFastState.Bounded env25805 := by
  intro p hp
  have h : env25805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25804_25805 : H12AffineEnvironment.transform 17 138293 env25804 = env25805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138293 env25804 == env25805) = true)

theorem identity25805 : scanCanonicalize (H12AffineFastState.compose env25805 (packedSelected [0,7,9,10,11,12,15,16,18,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound25805 : packedSelected [0,7,9,10,11,12,15,16,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env25806 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21896,21646,131072,138293,1024,21897,4113,147504,21913,21762,388,16,138649,16536,4232,23588,1420,136496,256,21793,16384,22408]

theorem envBound25806 : H12AffineFastState.Bounded env25806 := by
  intro p hp
  have h : env25806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25805_25806 : H12AffineEnvironment.transform 12 268 env25805 = env25806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env25805 == env25806) = true)

theorem identity25806 : scanCanonicalize (H12AffineFastState.compose env25806 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound25806 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env25807 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21896,21646,5528,2477,1024,21897,4113,21928,21913,21762,388,16,2049,16536,4232,23588,1420,168,256,21793,16384,22408]

theorem envBound25807 : H12AffineFastState.Bounded env25807 := by
  intro p hp
  have h : env25807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25806_25807 : H12AffineEnvironment.transform 16 5528 env25806 = env25807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env25806 == env25807) = true)

theorem identity25807 : scanCanonicalize (H12AffineFastState.compose env25807 (packedSelected [1,3,5,6,8,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound25807 : packedSelected [1,3,5,6,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env25808 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,161,16384,21541,21646,5173,2048,1024,21540,4113,21509,21556,21679,41,16,2049,16536,4232,23588,1057,168,173,21644,16384,22053]

theorem envBound25808 : H12AffineFastState.Bounded env25808 := by
  intro p hp
  have h : env25808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25807_25808 : H12AffineEnvironment.transform 7 173 env25807 = env25808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env25807 == env25808) = true)

theorem identity25808 : scanCanonicalize (H12AffineFastState.compose env25808 (packedSelected [0,2,4,6,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25808 : packedSelected [0,2,4,6,10] rootPS < 2^1333 := by decide +kernel

def env25809 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,21541,21510,5173,2048,1024,21540,4113,21509,21556,21543,41,16,2049,16400,4096,23588,1057,32,37,21508,16384,22053]

theorem envBound25809 : H12AffineFastState.Bounded env25809 := by
  intro p hp
  have h : env25809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25808_25809 : H12AffineEnvironment.transform 6 8 env25808 = env25809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25808 == env25809) = true)

theorem identity25809 : scanCanonicalize (H12AffineFastState.compose env25809 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound25809 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env25810 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,0,35,5173,2048,1024,1,4113,32,17,2,41,16,2049,5173,4096,2049,1057,32,37,33,5157,512]

theorem envBound25810 : H12AffineFastState.Bounded env25810 := by
  intro p hp
  have h : env25810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25809_25810 : H12AffineEnvironment.transform 13 5157 env25809 = env25810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env25809 == env25810) = true)

theorem identity25810 : scanCanonicalize (H12AffineFastState.compose env25810 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25810 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25811 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,4096,8,5124,0,2,5140,2048,1024,1,4113,1,17,2,8,16,2049,5140,4096,2049,1024,1,4,0,5124,512]

theorem envBound25811 : H12AffineFastState.Bounded env25811 := by
  intro p hp
  have h : env25811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25810_25811 : H12AffineEnvironment.transform 4 1 env25810 = env25811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25810 == env25811) = true)

def env25812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412157,21763,8328,65,215366,115151,396525,35325,497903,243003,256,509970,469431,442168]

theorem envBound25812 : H12AffineFastState.Bounded env25812 := by
  intro p hp
  have h : env25812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25786_25812 : H12AffineEnvironment.transform 20 4161 env25786 = env25812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25786 == env25812) = true)

theorem identity25812 : scanCanonicalize (H12AffineFastState.compose env25812 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149997) := by decide +kernel

theorem selectedBound25812 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,169401,16,21763,8328,65,215366,115151,17664,35325,119042,243003,256,98815,90202,63189]

theorem envBound25813 : H12AffineFastState.Bounded env25813 := by
  intro p hp
  have h : env25813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25812_25813 : H12AffineEnvironment.transform 17 149997 env25812 = env25813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149997 env25812 == env25813) = true)

def env25814 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169265,16,21763,8192,65,215366,115015,17664,35189,119042,243003,256,98679,90202,63069]

theorem envBound25814 : H12AffineFastState.Bounded env25814 := by
  intro p hp
  have h : env25814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25813_25814 : H12AffineEnvironment.transform 6 8 env25813 = env25814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25813 == env25814) = true)

theorem identity25814 : scanCanonicalize (H12AffineFastState.compose env25814 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound25814 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25815 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13389,32040,1024,32769,4161,41340,16,21763,8192,65,97547,115015,17664,35189,119042,98678,256,98679,90202,63069]

theorem envBound25815 : H12AffineFastState.Bounded env25815 := by
  intro p hp
  have h : env25815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25814_25815 : H12AffineEnvironment.transform 16 13389 env25814 = env25815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env25814 == env25815) = true)

theorem identity25815 : scanCanonicalize (H12AffineFastState.compose env25815 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound25815 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env25816 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,292,65536,13389,32040,1024,293,4161,8280,16,21763,8192,65,97547,82019,17664,2129,86054,65618,256,65619,90202,30585]

theorem envBound25816 : H12AffineFastState.Bounded env25816 := by
  intro p hp
  have h : env25816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25815_25816 : H12AffineEnvironment.transform 14 292 env25815 = env25816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env25815 == env25816) = true)

theorem identity25816 : scanCanonicalize (H12AffineFastState.compose env25816 (packedSelected [0,4,7,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound25816 : packedSelected [0,4,7,19,22,26] rootPS < 2^1333 := by decide +kernel

def env25817 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,292,8575,13389,32040,1024,293,4161,8280,16,21763,8192,65,23668,24860,17664,2129,29017,8493,256,8492,16677,30585]

theorem envBound25817 : H12AffineFastState.Bounded env25817 := by
  intro p hp
  have h : env25817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25816_25817 : H12AffineEnvironment.transform 15 8575 env25816 = env25817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env25816 == env25817) = true)

theorem identity25817 : scanCanonicalize (H12AffineFastState.compose env25817 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound25817 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env25818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,292,8575,13389,2340,1024,293,4161,8280,16,8463,8192,65,10360,5392,12556,2129,1365,8493,256,8492,13609,885]

theorem envBound25818 : H12AffineFastState.Bounded env25818 := by
  intro p hp
  have h : env25818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25817_25818 : H12AffineEnvironment.transform 13 13324 env25817 = env25818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env25817 == env25818) = true)

theorem identity25818 : scanCanonicalize (H12AffineFastState.compose env25818 (packedSelected [15] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound25818 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env25819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,4112,292,1379,4177,2340,1024,293,4161,1092,16,1299,1052,65,3172,5392,5392,2129,1365,1329,256,1328,4405,885]

theorem envBound25819 : H12AffineFastState.Bounded env25819 := by
  intro p hp
  have h : env25819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25818_25819 : H12AffineEnvironment.transform 12 1052 env25818 = env25819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env25818 == env25819) = true)

theorem identity25819 : scanCanonicalize (H12AffineFastState.compose env25819 (packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound25819 : packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env25820 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,41,4112,292,342,4177,2340,53,293,4161,113,16,294,41,65,2129,4389,4389,2129,352,260,256,261,4405,885]

theorem envBound25820 : H12AffineFastState.Bounded env25820 := by
  intro p hp
  have h : env25820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25819_25820 : H12AffineEnvironment.transform 9 53 env25819 = env25820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env25819 == env25820) = true)

theorem identity25820 : scanCanonicalize (H12AffineFastState.compose env25820 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound25820 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env25821 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,4096,41,4112,80,34,4177,2128,53,81,4161,113,16,82,41,65,2129,4177,4177,2129,20,112,116,113,4161,513]

theorem envBound25821 : H12AffineFastState.Bounded env25821 := by
  intro p hp
  have h : env25821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25820_25821 : H12AffineEnvironment.transform 7 116 env25820 = env25821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env25820 == env25821) = true)

theorem identity25821 : scanCanonicalize (H12AffineFastState.compose env25821 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25821 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25822 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,41,4112,1,34,4096,2049,53,0,4112,32,16,3,41,16,2048,4096,4096,2048,20,33,37,32,4112,513]

theorem envBound25822 : H12AffineFastState.Bounded env25822 := by
  intro p hp
  have h : env25822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25821_25822 : H12AffineEnvironment.transform 5 17 env25821 = env25822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25821 == env25822) = true)

theorem identity25822 : scanCanonicalize (H12AffineFastState.compose env25822 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound25822 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25823 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,2608,41,2592,1,34,2608,2049,53,0,2592,32,16,3,41,16,2048,2608,2608,2048,20,33,37,32,2592,513]

theorem envBound25823 : H12AffineFastState.Bounded env25823 := by
  intro p hp
  have h : env25823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25822_25823 : H12AffineEnvironment.transform 11 2608 env25822 = env25823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env25822 == env25823) = true)

theorem identity25823 : scanCanonicalize (H12AffineFastState.compose env25823 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound25823 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25824 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,529,41,513,1,34,529,32,53,0,513,32,16,3,41,16,33,529,529,33,20,33,37,32,513,513]

theorem envBound25824 : H12AffineFastState.Bounded env25824 := by
  intro p hp
  have h : env25824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25823_25824 : H12AffineEnvironment.transform 10 33 env25823 = env25824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env25823 == env25824) = true)

theorem identity25824 : scanCanonicalize (H12AffineFastState.compose env25824 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25824 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25825 : List Nat := [2,4,8,16,32,17,8,37,0,53,33,17,41,1,1,34,17,32,53,0,1,32,16,3,41,16,33,17,17,33,20,33,37,32,1,1]

theorem envBound25825 : H12AffineFastState.Bounded env25825 := by
  intro p hp
  have h : env25825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25824_25825 : H12AffineEnvironment.transform 8 0 env25824 = env25825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25824 == env25825) = true)

theorem identity25825 : scanCanonicalize (H12AffineFastState.compose env25825 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25825 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25826 : List Nat := [2,4,8,16,1,17,8,4,0,20,0,17,8,1,1,3,17,1,20,0,1,1,16,3,8,16,0,17,17,0,20,0,4,1,1,1]

theorem envBound25826 : H12AffineFastState.Bounded env25826 := by
  intro p hp
  have h : env25826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25825_25826 : H12AffineEnvironment.transform 4 1 env25825 = env25826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25825 == env25826) = true)

def env25827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169264,16,21763,8193,65,215366,115014,17664,35188,119042,243003,256,98678,90202,63068]

theorem envBound25827 : H12AffineFastState.Bounded env25827 := by
  intro p hp
  have h : env25827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25813_25827 : H12AffineEnvironment.transform 6 9 env25813 = env25827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25813 == env25827) = true)

theorem identity25827 : scanCanonicalize (H12AffineFastState.compose env25827 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound25827 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,56436,1024,32769,4161,32,16,21763,8193,65,121942,115014,17664,35188,119042,73771,256,98678,90202,63068]

theorem envBound25828 : H12AffineFastState.Bounded env25828 := by
  intro p hp
  have h : env25828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25827_25828 : H12AffineEnvironment.transform 16 38160 env25827 = env25828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env25827 == env25828) = true)

theorem identity25828 : scanCanonicalize (H12AffineFastState.compose env25828 (packedSelected [1,2,3,4,5,6,8,9,12,16,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound25828 : packedSelected [1,2,3,4,5,6,8,9,12,16,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env25829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30043,38160,56436,1024,32769,4161,32,16,21763,8193,65,43277,46109,17664,35188,42073,21872,256,62509,5377,63068]

theorem envBound25829 : H12AffineFastState.Bounded env25829 := by
  intro p hp
  have h : env25829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25828_25829 : H12AffineEnvironment.transform 15 30043 env25828 = env25829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env25828 == env25829) = true)

theorem identity25829 : scanCanonicalize (H12AffineFastState.compose env25829 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound25829 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env25830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,30043,5392,23668,1024,1,4161,32,16,21763,8193,65,10509,13341,17664,2420,9305,21872,256,29741,5377,30300]

theorem envBound25830 : H12AffineFastState.Bounded env25830 := by
  intro p hp
  have h : env25830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25829_25830 : H12AffineEnvironment.transform 14 0 env25829 = env25830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env25829 == env25830) = true)

theorem identity25830 : scanCanonicalize (H12AffineFastState.compose env25830 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound25830 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env25831 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,262,5392,10281,1024,1,4161,32,16,8542,8193,65,10509,13341,12637,2420,9305,8493,256,112,5377,513]

theorem envBound25831 : H12AffineFastState.Bounded env25831 := by
  intro p hp
  have h : env25831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25830_25831 : H12AffineEnvironment.transform 13 13405 env25830 = env25831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env25830 == env25831) = true)

theorem identity25831 : scanCanonicalize (H12AffineFastState.compose env25831 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound25831 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25832 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5457,0,262,5392,2341,1024,1,4161,32,16,82,269,65,2049,5393,4177,2420,1365,33,256,112,5377,513]

theorem envBound25832 : H12AffineFastState.Bounded env25832 := by
  intro p hp
  have h : env25832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25831_25832 : H12AffineEnvironment.transform 12 268 env25831 = env25832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env25831 == env25832) = true)

theorem identity25832 : scanCanonicalize (H12AffineFastState.compose env25832 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25832 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25833 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5392,2341,1024,1,4113,32,16,2,269,17,2049,5393,4097,2340,1285,33,256,32,5377,513]

theorem envBound25833 : H12AffineFastState.Bounded env25833 := by
  intro p hp
  have h : env25833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25832_25833 : H12AffineEnvironment.transform 5 16 env25832 = env25833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25832 == env25833) = true)

theorem identity25833 : scanCanonicalize (H12AffineFastState.compose env25833 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound25833 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25834 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1045,268,276,0,262,261,2341,1024,1,1028,32,16,2,269,17,2049,260,1044,2340,1285,33,256,32,276,513]

theorem envBound25834 : H12AffineFastState.Bounded env25834 := by
  intro p hp
  have h : env25834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25833_25834 : H12AffineEnvironment.transform 11 1045 env25833 = env25834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env25833 == env25834) = true)

theorem identity25834 : scanCanonicalize (H12AffineFastState.compose env25834 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound25834 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25835 : List Nat := [2,4,8,16,32,16,9,256,512,784,2048,773,268,276,0,262,261,2341,784,1,788,32,16,2,269,17,2049,260,772,2340,533,33,256,32,276,513]

theorem envBound25835 : H12AffineFastState.Bounded env25835 := by
  intro p hp
  have h : env25835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25834_25835 : H12AffineEnvironment.transform 9 784 env25834 = env25835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env25834 == env25835) = true)

theorem identity25835 : scanCanonicalize (H12AffineFastState.compose env25835 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound25835 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25836 : List Nat := [2,4,8,16,32,16,9,256,512,784,805,773,268,276,0,262,261,512,784,1,788,32,16,2,269,17,804,260,772,513,533,33,256,32,276,513]

theorem envBound25836 : H12AffineFastState.Bounded env25836 := by
  intro p hp
  have h : env25836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25835_25836 : H12AffineEnvironment.transform 10 805 env25835 = env25836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env25835 == env25836) = true)

theorem identity25836 : scanCanonicalize (H12AffineFastState.compose env25836 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25836 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25837 : List Nat := [2,4,8,0,32,0,9,256,512,768,805,773,268,260,0,262,261,512,768,1,772,32,0,2,269,1,804,260,772,513,517,33,256,32,260,513]

end H12CloudChart1