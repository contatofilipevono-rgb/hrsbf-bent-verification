import H12CloudChart1Data236

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env60128 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3158,1288,9617,2365812,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound60128 : H12AffineFastState.Bounded env60128 := by
  intro p hp
  have h : env60128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60127_60128 : H12AffineEnvironment.transform 8 0 env60127 = env60128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60127 == env60128) = true)

theorem identity60128 : scanCanonicalize (H12AffineFastState.compose env60128 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 74030) := by decide +kernel

theorem selectedBound60128 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60129 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,74030,1417,9664,3158,1288,9617,342106,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound60129 : H12AffineFastState.Bounded env60129 := by
  intro p hp
  have h : env60129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60128_60129 : H12AffineEnvironment.transform 20 74030 env60128 = env60129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 74030 env60128 == env60129) = true)

def env60130 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,66734,1417,64,3158,1288,17,335322,4177,70914,66898,65542,68094,256,65674,70994,1]

theorem envBound60130 : H12AffineFastState.Bounded env60130 := by
  intro p hp
  have h : env60130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60129_60130 : H12AffineEnvironment.transform 12 1408 env60129 = env60130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60129 == env60130) = true)

theorem identity60130 : scanCanonicalize (H12AffineFastState.compose env60130 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7507) := by decide +kernel

theorem selectedBound60130 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60131 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,7507,2049,262144,1025,2129,6653,1417,64,3158,1288,17,262281,4177,2129,6145,7509,5293,256,7641,2049,1]

theorem envBound60131 : H12AffineFastState.Bounded env60131 := by
  intro p hp
  have h : env60131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60130_60131 : H12AffineEnvironment.transform 15 7507 env60130 = env60131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7507 env60130 == env60131) = true)

theorem identity60131 : scanCanonicalize (H12AffineFastState.compose env60131 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60131 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60132 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1449,4267,1529,262144,1025,1449,5125,1417,64,430,1288,17,262281,4177,1449,5625,4269,5293,256,4129,1529,1]

theorem envBound60132 : H12AffineFastState.Bounded env60132 := by
  intro p hp
  have h : env60132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60131_60132 : H12AffineEnvironment.transform 10 1528 env60131 = env60132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60131 == env60132) = true)

theorem identity60132 : scanCanonicalize (H12AffineFastState.compose env60132 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1093) := by decide +kernel

theorem selectedBound60132 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60133 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1449,4267,1529,1093,1025,1449,5125,1417,64,430,1288,17,1228,4177,1449,5625,4269,5293,256,4129,1529,1]

theorem envBound60133 : H12AffineFastState.Bounded env60133 := by
  intro p hp
  have h : env60133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60132_60133 : H12AffineEnvironment.transform 17 1093 env60132 = env60133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1093 env60132 == env60133) = true)

theorem identity60133 : scanCanonicalize (H12AffineFastState.compose env60133 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1164) := by decide +kernel

theorem selectedBound60133 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60134 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1164,1408,1244,1449,1063,1529,1093,1025,1449,137,1417,64,430,1288,17,1228,1245,1449,373,1057,33,256,1197,1529,1]

theorem envBound60134 : H12AffineFastState.Bounded env60134 := by
  intro p hp
  have h : env60134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60133_60134 : H12AffineEnvironment.transform 11 1164 env60133 = env60134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1164 env60133 == env60134) = true)

theorem identity60134 : scanCanonicalize (H12AffineFastState.compose env60134 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound60134 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60135 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1029,1164,1149,1244,1108,1063,1028,1093,1025,1108,137,1140,64,83,1269,17,1228,1245,1108,136,1057,33,253,1197,1028,1]

theorem envBound60135 : H12AffineFastState.Bounded env60135 := by
  intro p hp
  have h : env60135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60134_60135 : H12AffineEnvironment.transform 7 253 env60134 = env60135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env60134 == env60135) = true)

theorem identity60135 : scanCanonicalize (H12AffineFastState.compose env60135 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60135 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60136 : List Nat := [2,4,8,16,32,16,128,173,0,1024,1029,1164,1069,1164,1028,1063,1028,1045,1025,1028,137,1060,16,3,1189,17,1180,1165,1028,136,1057,33,173,1197,1028,1]

theorem envBound60136 : H12AffineFastState.Bounded env60136 := by
  intro p hp
  have h : env60136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60135_60136 : H12AffineEnvironment.transform 5 16 env60135 = env60136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60135 == env60136) = true)

theorem identity60136 : scanCanonicalize (H12AffineFastState.compose env60136 (packedSelected [0,6] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60136 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env60137 : List Nat := [0,4,8,16,32,16,128,173,0,1024,1029,1164,1069,1164,1028,1061,1028,1045,1025,1028,137,1060,16,1,1189,17,1180,1165,1028,136,1057,33,173,1197,1028,1]

theorem envBound60137 : H12AffineFastState.Bounded env60137 := by
  intro p hp
  have h : env60137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60136_60137 : H12AffineEnvironment.transform 0 0 env60136 = env60137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60136 == env60137) = true)

theorem identity60137 : scanCanonicalize (H12AffineFastState.compose env60137 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound60137 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60138 : List Nat := [0,4,8,16,32,16,128,173,0,20,17,152,57,152,16,49,16,1,21,16,137,48,16,1,177,17,136,153,16,136,53,33,173,185,16,1]

theorem envBound60138 : H12AffineFastState.Bounded env60138 := by
  intro p hp
  have h : env60138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60137_60138 : H12AffineEnvironment.transform 9 20 env60137 = env60138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env60137 == env60138) = true)

theorem identity60138 : scanCanonicalize (H12AffineFastState.compose env60138 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound60138 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env60139 : List Nat := [0,4,8,16,32,16,57,20,0,20,17,33,57,33,16,49,16,1,21,16,48,48,16,1,8,17,49,32,16,49,53,33,20,0,16,1]

theorem envBound60139 : H12AffineFastState.Bounded env60139 := by
  intro p hp
  have h : env60139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60138_60139 : H12AffineEnvironment.transform 6 57 env60138 = env60139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env60138 == env60139) = true)

theorem identity60139 : scanCanonicalize (H12AffineFastState.compose env60139 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60139 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60140 : List Nat := [0,4,0,16,32,16,49,20,0,20,17,33,49,33,16,49,16,1,21,16,48,48,16,1,0,17,49,32,16,49,53,33,20,0,16,1]

theorem envBound60140 : H12AffineFastState.Bounded env60140 := by
  intro p hp
  have h : env60140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60139_60140 : H12AffineEnvironment.transform 2 0 env60139 = env60140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60139 == env60140) = true)

theorem identity60140 : scanCanonicalize (H12AffineFastState.compose env60140 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60140 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60141 : List Nat := [0,4,0,16,0,16,17,20,0,20,17,1,17,1,16,17,16,1,21,16,16,16,16,1,0,17,17,0,16,17,21,1,20,0,16,1]

theorem envBound60141 : H12AffineFastState.Bounded env60141 := by
  intro p hp
  have h : env60141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60140_60141 : H12AffineEnvironment.transform 4 0 env60140 = env60141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60140 == env60141) = true)

def env60142 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,66735,1417,65,3158,1288,16,335323,4177,70915,66898,65542,68094,256,65674,70995,0]

theorem envBound60142 : H12AffineFastState.Bounded env60142 := by
  intro p hp
  have h : env60142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60129_60142 : H12AffineEnvironment.transform 12 1409 env60129 = env60142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60129 == env60142) = true)

theorem identity60142 : scanCanonicalize (H12AffineFastState.compose env60142 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound60142 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60143 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2129,65536,67847,262144,1025,2129,66735,1417,65,3158,1288,16,328079,3077,67927,66898,65542,68094,256,65674,67847,0]

theorem envBound60143 : H12AffineFastState.Bounded env60143 := by
  intro p hp
  have h : env60143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60142_60143 : H12AffineEnvironment.transform 11 3156 env60142 = env60143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env60142 == env60143) = true)

theorem identity60143 : scanCanonicalize (H12AffineFastState.compose env60143 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68962) := by decide +kernel

theorem selectedBound60143 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60144 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2129,65536,67847,68962,1025,2129,66735,1417,65,3158,1288,16,3309,3077,67927,66898,65542,68094,256,65674,67847,0]

theorem envBound60144 : H12AffineFastState.Bounded env60144 := by
  intro p hp
  have h : env60144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60143_60144 : H12AffineEnvironment.transform 17 68962 env60143 = env60144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68962 env60143 == env60144) = true)

theorem identity60144 : scanCanonicalize (H12AffineFastState.compose env60144 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2203) := by decide +kernel

theorem selectedBound60144 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60145 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1409,3076,2129,2203,412,1529,1025,2129,3124,1417,65,3158,1288,16,3309,3077,460,3529,2205,357,256,2065,412,0]

theorem envBound60145 : H12AffineFastState.Bounded env60145 := by
  intro p hp
  have h : env60145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60144_60145 : H12AffineEnvironment.transform 15 2203 env60144 = env60145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2203 env60144 == env60145) = true)

theorem identity60145 : scanCanonicalize (H12AffineFastState.compose env60145 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1432) := by decide +kernel

theorem selectedBound60145 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env60146 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1432,460,1409,412,1481,1283,412,1529,1025,1481,428,1417,65,462,1288,16,373,413,460,81,1285,357,256,1417,412,0]

theorem envBound60146 : H12AffineFastState.Bounded env60146 := by
  intro p hp
  have h : env60146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60145_60146 : H12AffineEnvironment.transform 10 1432 env60145 = env60146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1432 env60145 == env60146) = true)

theorem identity60146 : scanCanonicalize (H12AffineFastState.compose env60146 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound60146 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env60147 : List Nat := [2,4,8,16,32,64,114,256,0,1024,1386,318,1395,366,1339,1283,366,1291,1025,1339,350,1403,65,316,1288,16,373,367,318,81,1285,357,256,1403,366,0]

theorem envBound60147 : H12AffineFastState.Bounded env60147 := by
  intro p hp
  have h : env60147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60146_60147 : H12AffineEnvironment.transform 6 114 env60146 = env60147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env60146 == env60147) = true)

theorem identity60147 : scanCanonicalize (H12AffineFastState.compose env60147 (packedSelected [0,3,10] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound60147 : packedSelected [0,3,10] rootPS < 2^1333 := by decide +kernel

def env60148 : List Nat := [2,4,8,16,32,64,114,68,0,1024,1070,122,1079,42,1151,1095,42,1103,1025,1151,26,1087,65,120,1100,16,49,43,122,81,1089,33,68,1087,42,0]

theorem envBound60148 : H12AffineFastState.Bounded env60148 := by
  intro p hp
  have h : env60148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60147_60148 : H12AffineEnvironment.transform 7 68 env60147 = env60148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env60147 == env60148) = true)

theorem identity60148 : scanCanonicalize (H12AffineFastState.compose env60148 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound60148 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60149 : List Nat := [2,4,8,16,32,64,114,68,0,31,49,122,40,42,96,88,42,80,30,96,26,32,65,120,83,16,49,43,122,81,94,33,68,32,42,0]

theorem envBound60149 : H12AffineFastState.Bounded env60149 := by
  intro p hp
  have h : env60149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60148_60149 : H12AffineEnvironment.transform 9 31 env60148 = env60149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env60148 == env60149) = true)

def env60150 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3159,1288,9617,2365813,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound60150 : H12AffineFastState.Bounded env60150 := by
  intro p hp
  have h : env60150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60127_60150 : H12AffineEnvironment.transform 8 1 env60127 = env60150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60127 == env60150) = true)

theorem identity60150 : scanCanonicalize (H12AffineFastState.compose env60150 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 66734) := by decide +kernel

theorem selectedBound60150 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60151 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,66734,1417,9664,3159,1288,9617,335323,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound60151 : H12AffineFastState.Bounded env60151 := by
  intro p hp
  have h : env60151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60150_60151 : H12AffineEnvironment.transform 20 66734 env60150 = env60151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66734 env60150 == env60151) = true)

def env60152 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,66734,1417,64,3159,1288,17,335323,4177,70914,66899,65542,68095,256,65674,70994,0]

theorem envBound60152 : H12AffineFastState.Bounded env60152 := by
  intro p hp
  have h : env60152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60151_60152 : H12AffineEnvironment.transform 12 1408 env60151 = env60152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60151 == env60152) = true)

theorem identity60152 : scanCanonicalize (H12AffineFastState.compose env60152 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7506) := by decide +kernel

theorem selectedBound60152 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60153 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,7506,2048,262144,1025,2128,6652,1417,64,3159,1288,17,262281,4177,2128,6145,7508,5293,256,7640,2048,0]

theorem envBound60153 : H12AffineFastState.Bounded env60153 := by
  intro p hp
  have h : env60153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60152_60153 : H12AffineEnvironment.transform 15 7506 env60152 = env60153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7506 env60152 == env60153) = true)

theorem identity60153 : scanCanonicalize (H12AffineFastState.compose env60153 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60153 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60154 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1449,4267,1529,262144,1025,1449,5125,1417,64,430,1288,17,262281,4177,1449,5624,4269,5293,256,4129,1529,0]

theorem envBound60154 : H12AffineFastState.Bounded env60154 := by
  intro p hp
  have h : env60154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60153_60154 : H12AffineEnvironment.transform 10 1529 env60153 = env60154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60153 == env60154) = true)

theorem identity60154 : scanCanonicalize (H12AffineFastState.compose env60154 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1093) := by decide +kernel

theorem selectedBound60154 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60155 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1449,4267,1529,1093,1025,1449,5125,1417,64,430,1288,17,1228,4177,1449,5624,4269,5293,256,4129,1529,0]

theorem envBound60155 : H12AffineFastState.Bounded env60155 := by
  intro p hp
  have h : env60155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60154_60155 : H12AffineEnvironment.transform 17 1093 env60154 = env60155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1093 env60154 == env60155) = true)

theorem identity60155 : scanCanonicalize (H12AffineFastState.compose env60155 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1164) := by decide +kernel

theorem selectedBound60155 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60156 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1164,1408,1244,1449,1063,1529,1093,1025,1449,137,1417,64,430,1288,17,1228,1245,1449,372,1057,33,256,1197,1529,0]

theorem envBound60156 : H12AffineFastState.Bounded env60156 := by
  intro p hp
  have h : env60156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60155_60156 : H12AffineEnvironment.transform 11 1164 env60155 = env60156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1164 env60155 == env60156) = true)

theorem identity60156 : scanCanonicalize (H12AffineFastState.compose env60156 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound60156 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60157 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1029,1164,1148,1244,1109,1063,1029,1093,1025,1109,137,1141,64,82,1268,17,1228,1245,1109,136,1057,33,252,1197,1029,0]

theorem envBound60157 : H12AffineFastState.Bounded env60157 := by
  intro p hp
  have h : env60157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60156_60157 : H12AffineEnvironment.transform 7 252 env60156 = env60157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env60156 == env60157) = true)

theorem identity60157 : scanCanonicalize (H12AffineFastState.compose env60157 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound60157 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60158 : List Nat := [2,4,8,16,32,64,128,252,1,140,137,0,240,80,217,171,137,201,141,217,137,249,64,82,120,17,64,81,217,136,173,33,252,33,137,0]

theorem envBound60158 : H12AffineFastState.Bounded env60158 := by
  intro p hp
  have h : env60158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60157_60158 : H12AffineEnvironment.transform 9 140 env60157 = env60158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env60157 == env60158) = true)

theorem identity60158 : scanCanonicalize (H12AffineFastState.compose env60158 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound60158 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env60159 : List Nat := [2,4,8,16,32,64,25,101,1,21,16,0,105,80,64,50,16,80,20,64,16,96,64,82,120,17,64,81,64,17,52,33,101,33,16,0]

theorem envBound60159 : H12AffineFastState.Bounded env60159 := by
  intro p hp
  have h : env60159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60158_60159 : H12AffineEnvironment.transform 6 25 env60158 = env60159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env60158 == env60159) = true)

theorem identity60159 : scanCanonicalize (H12AffineFastState.compose env60159 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound60159 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env60160 : List Nat := [2,4,8,16,32,49,25,20,1,21,16,0,24,33,49,50,16,33,20,49,16,17,49,35,9,17,49,32,49,17,52,33,20,33,16,0]

theorem envBound60160 : H12AffineFastState.Bounded env60160 := by
  intro p hp
  have h : env60160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60159_60160 : H12AffineEnvironment.transform 5 49 env60159 = env60160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env60159 == env60160) = true)

theorem identity60160 : scanCanonicalize (H12AffineFastState.compose env60160 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound60160 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60161 : List Nat := [2,4,8,16,2,19,25,20,1,21,16,0,24,3,19,16,16,3,20,19,16,17,19,1,9,17,19,2,19,17,22,3,20,3,16,0]

theorem envBound60161 : H12AffineFastState.Bounded env60161 := by
  intro p hp
  have h : env60161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60160_60161 : H12AffineEnvironment.transform 4 2 env60160 = env60161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env60160 == env60161) = true)

theorem identity60161 : scanCanonicalize (H12AffineFastState.compose env60161 (packedSelected [1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound60161 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env60162 : List Nat := [2,4,8,9,2,10,0,13,1,12,9,0,1,3,10,9,9,3,13,10,9,8,10,1,9,8,10,2,10,8,15,3,13,3,9,0]

theorem envBound60162 : H12AffineFastState.Bounded env60162 := by
  intro p hp
  have h : env60162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60161_60162 : H12AffineEnvironment.transform 3 9 env60161 = env60162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env60161 == env60162) = true)

theorem identity60162 : scanCanonicalize (H12AffineFastState.compose env60162 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60162 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60163 : List Nat := [2,4,1,0,2,3,0,4,1,5,0,0,1,3,3,0,0,3,4,3,0,1,3,1,0,1,3,2,3,1,6,3,4,3,0,0]

theorem envBound60163 : H12AffineFastState.Bounded env60163 := by
  intro p hp
  have h : env60163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60162_60163 : H12AffineEnvironment.transform 2 1 env60162 = env60163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60162 == env60163) = true)

theorem identity60163 : scanCanonicalize (H12AffineFastState.compose env60163 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60163 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60164 : List Nat := [1,4,1,0,1,0,0,4,1,5,0,0,1,0,0,0,0,0,4,0,0,1,0,1,0,1,0,1,0,1,5,0,4,0,0,0]

theorem envBound60164 : H12AffineFastState.Bounded env60164 := by
  intro p hp
  have h : env60164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60163_60164 : H12AffineEnvironment.transform 0 1 env60163 = env60164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60163 == env60164) = true)

def env60165 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,66734,1417,65,3159,1288,16,335323,4177,70915,66899,65542,68095,256,65674,70995,1]

theorem envBound60165 : H12AffineFastState.Bounded env60165 := by
  intro p hp
  have h : env60165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60151_60165 : H12AffineEnvironment.transform 12 1409 env60151 = env60165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60151 == env60165) = true)

theorem identity60165 : scanCanonicalize (H12AffineFastState.compose env60165 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound60165 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60166 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2128,65536,67847,262144,1025,2128,66734,1417,65,3159,1288,16,328079,3077,67927,66899,65542,68095,256,65674,67847,1]

theorem envBound60166 : H12AffineFastState.Bounded env60166 := by
  intro p hp
  have h : env60166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60165_60166 : H12AffineEnvironment.transform 11 3156 env60165 = env60166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env60165 == env60166) = true)

theorem identity60166 : scanCanonicalize (H12AffineFastState.compose env60166 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68962) := by decide +kernel

theorem selectedBound60166 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60167 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2128,65536,67847,68962,1025,2128,66734,1417,65,3159,1288,16,3309,3077,67927,66899,65542,68095,256,65674,67847,1]

theorem envBound60167 : H12AffineFastState.Bounded env60167 := by
  intro p hp
  have h : env60167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60166_60167 : H12AffineEnvironment.transform 17 68962 env60166 = env60167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68962 env60166 == env60167) = true)

theorem identity60167 : scanCanonicalize (H12AffineFastState.compose env60167 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2202) := by decide +kernel

theorem selectedBound60167 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60168 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2128,2202,413,1528,1025,2128,3124,1417,65,3159,1288,16,3309,3077,461,3529,2204,357,256,2064,413,1]

theorem envBound60168 : H12AffineFastState.Bounded env60168 := by
  intro p hp
  have h : env60168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60167_60168 : H12AffineEnvironment.transform 15 2202 env60167 = env60168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2202 env60167 == env60168) = true)

theorem identity60168 : scanCanonicalize (H12AffineFastState.compose env60168 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound60168 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env60169 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1245,137,1409,217,1165,1095,413,1528,1025,1165,233,1417,65,138,1288,16,48,216,461,276,1089,357,256,1229,413,1]

theorem envBound60169 : H12AffineFastState.Bounded env60169 := by
  intro p hp
  have h : env60169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60168_60169 : H12AffineEnvironment.transform 10 1245 env60168 = env60169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env60168 == env60169) = true)

theorem identity60169 : scanCanonicalize (H12AffineFastState.compose env60169 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound60169 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env60170 : List Nat := [2,4,8,16,32,64,128,256,1,425,372,137,40,217,292,494,413,81,424,292,233,32,65,138,161,16,48,216,461,276,488,357,256,356,413,1]

theorem envBound60170 : H12AffineFastState.Bounded env60170 := by
  intro p hp
  have h : env60170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60169_60170 : H12AffineEnvironment.transform 9 425 env60169 = env60170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env60169 == env60170) = true)

theorem identity60170 : scanCanonicalize (H12AffineFastState.compose env60170 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound60170 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60171 : List Nat := [2,4,8,16,32,64,128,69,1,236,49,137,40,217,97,171,216,81,237,97,233,32,65,138,161,16,48,216,136,81,173,32,69,33,216,1]

theorem envBound60171 : H12AffineFastState.Bounded env60171 := by
  intro p hp
  have h : env60171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60170_60171 : H12AffineEnvironment.transform 7 69 env60170 = env60171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env60170 == env60171) = true)

theorem identity60171 : scanCanonicalize (H12AffineFastState.compose env60171 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound60171 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60172 : List Nat := [2,4,8,16,32,58,128,63,1,150,49,137,40,163,27,171,162,43,151,27,147,32,59,138,161,16,48,162,136,43,173,32,63,33,162,1]

theorem envBound60172 : H12AffineFastState.Bounded env60172 := by
  intro p hp
  have h : env60172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60171_60172 : H12AffineEnvironment.transform 5 58 env60171 = env60172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env60171 == env60172) = true)

def env60173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9665,3671,1289,9616,2366324,4177,77954,67410,65543,68607,256,65674,78034,10112]

theorem envBound60173 : H12AffineFastState.Bounded env60173 := by
  intro p hp
  have h : env60173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60126_60173 : H12AffineEnvironment.transform 22 9665 env60126 = env60173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env60126 == env60173) = true)

def env60174 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3159,1289,9616,2365812,4177,77954,66898,65543,68095,256,65674,78034,9600]

theorem envBound60174 : H12AffineFastState.Bounded env60174 := by
  intro p hp
  have h : env60174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60173_60174 : H12AffineEnvironment.transform 8 0 env60173 = env60174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60173 == env60174) = true)

theorem identity60174 : scanCanonicalize (H12AffineFastState.compose env60174 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 7422) := by decide +kernel

theorem selectedBound60174 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60175 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,7422,11308,262144,1025,2129,2097152,1417,9665,3159,1289,9616,2365812,4177,11388,6572,7417,5377,256,7284,11308,9600]

theorem envBound60175 : H12AffineFastState.Bounded env60175 := by
  intro p hp
  have h : env60175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60174_60175 : H12AffineEnvironment.transform 15 7422 env60174 = env60175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7422 env60174 == env60175) = true)

def env60176 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,7422,2476,262144,1025,2129,2097152,1417,65,3159,1289,16,2365812,4177,2556,6572,7417,5377,256,7284,2476,0]

theorem envBound60176 : H12AffineFastState.Bounded env60176 := by
  intro p hp
  have h : env60176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60175_60176 : H12AffineEnvironment.transform 12 1408 env60175 = env60176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60175 == env60176) = true)

theorem identity60176 : scanCanonicalize (H12AffineFastState.compose env60176 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1028) := by decide +kernel

theorem selectedBound60176 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60177 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,7422,2476,262144,1025,2129,1028,1417,65,3159,1289,16,269680,4177,2556,6572,7417,5377,256,7284,2476,0]

theorem envBound60177 : H12AffineFastState.Bounded env60177 := by
  intro p hp
  have h : env60177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60176_60177 : H12AffineEnvironment.transform 20 1028 env60176 = env60177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1028 env60176 == env60177) = true)

theorem identity60177 : scanCanonicalize (H12AffineFastState.compose env60177 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3528) := by decide +kernel

theorem selectedBound60177 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60178 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,7422,2476,3528,1025,2129,1028,1417,65,3159,1289,16,4280,4177,2556,6572,7417,5377,256,7284,2476,0]

theorem envBound60178 : H12AffineFastState.Bounded env60178 := by
  intro p hp
  have h : env60178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60177_60178 : H12AffineEnvironment.transform 17 3528 env60177 = env60178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3528 env60177 == env60178) = true)

theorem identity60178 : scanCanonicalize (H12AffineFastState.compose env60178 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound60178 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60179 : List Nat := [2,4,8,16,32,64,128,256,0,1024,48,4096,1408,4176,97,5326,412,1528,1025,97,1028,1417,65,1127,1289,16,4280,4177,460,4508,5321,5377,256,5188,412,0]

theorem envBound60179 : H12AffineFastState.Bounded env60179 := by
  intro p hp
  have h : env60179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60178_60179 : H12AffineEnvironment.transform 10 48 env60178 = env60179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env60178 == env60179) = true)

theorem identity60179 : scanCanonicalize (H12AffineFastState.compose env60179 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound60179 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env60180 : List Nat := [2,4,8,16,32,64,128,256,0,237,48,4096,365,4176,97,4131,412,277,236,97,233,356,65,138,484,16,4280,4177,460,4508,4132,4588,256,4265,412,0]

theorem envBound60180 : H12AffineFastState.Bounded env60180 := by
  intro p hp
  have h : env60180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60179_60180 : H12AffineEnvironment.transform 9 237 env60179 = env60180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env60179 == env60180) = true)

theorem identity60180 : scanCanonicalize (H12AffineFastState.compose env60180 (packedSelected [0,4,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound60180 : packedSelected [0,4,6,11] rootPS < 2^1333 := by decide +kernel

def env60181 : List Nat := [2,4,8,16,32,64,128,256,0,237,48,460,365,412,97,495,412,277,236,97,233,356,65,138,484,16,372,413,460,80,488,32,256,357,412,0]

theorem envBound60181 : H12AffineFastState.Bounded env60181 := by
  intro p hp
  have h : env60181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60180_60181 : H12AffineEnvironment.transform 11 460 env60180 = env60181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env60180 == env60181) = true)

theorem identity60181 : scanCanonicalize (H12AffineFastState.compose env60181 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound60181 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60182 : List Nat := [2,4,8,16,32,64,128,182,0,237,48,122,219,42,97,89,42,163,236,97,233,210,65,138,82,16,194,43,122,80,94,32,182,211,42,0]

theorem envBound60182 : H12AffineFastState.Bounded env60182 := by
  intro p hp
  have h : env60182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60181_60182 : H12AffineEnvironment.transform 7 182 env60181 = env60182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env60181 == env60182) = true)

theorem identity60182 : scanCanonicalize (H12AffineFastState.compose env60182 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound60182 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env60183 : List Nat := [2,4,8,16,32,64,114,68,0,31,48,122,41,42,97,89,42,81,30,97,27,32,65,120,82,16,48,43,122,80,94,32,68,33,42,0]

theorem envBound60183 : H12AffineFastState.Bounded env60183 := by
  intro p hp
  have h : env60183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60182_60183 : H12AffineEnvironment.transform 6 114 env60182 = env60183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env60182 == env60183) = true)

def env60184 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,7422,2477,262144,1025,2129,2097152,1417,64,3159,1289,17,2365812,4177,2557,6572,7417,5377,256,7284,2477,1]

theorem envBound60184 : H12AffineFastState.Bounded env60184 := by
  intro p hp
  have h : env60184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60175_60184 : H12AffineEnvironment.transform 12 1409 env60175 = env60184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60175 == env60184) = true)

theorem identity60184 : scanCanonicalize (H12AffineFastState.compose env60184 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound60184 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60185 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,7422,2477,262144,1025,2129,6653,1417,64,3159,1289,17,262281,4177,2557,6572,7417,5377,256,7284,2477,1]

theorem envBound60185 : H12AffineFastState.Bounded env60185 := by
  intro p hp
  have h : env60185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60184_60185 : H12AffineEnvironment.transform 20 6653 env60184 = env60185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env60184 == env60185) = true)

theorem identity60185 : scanCanonicalize (H12AffineFastState.compose env60185 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60185 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60186 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1449,4358,1109,262144,1025,1449,5125,1417,64,431,1289,17,262281,4177,1029,5204,4353,5377,256,4492,1109,1]

theorem envBound60186 : H12AffineFastState.Bounded env60186 := by
  intro p hp
  have h : env60186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60185_60186 : H12AffineEnvironment.transform 10 1528 env60185 = env60186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60185 == env60186) = true)

theorem identity60186 : scanCanonicalize (H12AffineFastState.compose env60186 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1513) := by decide +kernel

theorem selectedBound60186 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60187 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1449,4358,1109,1513,1025,1449,5125,1417,64,431,1289,17,1376,4177,1029,5204,4353,5377,256,4492,1109,1]

theorem envBound60187 : H12AffineFastState.Bounded env60187 := by
  intro p hp
  have h : env60187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60186_60187 : H12AffineEnvironment.transform 17 1513 env60186 = env60187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1513 env60186 == env60187) = true)

theorem identity60187 : scanCanonicalize (H12AffineFastState.compose env60187 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound60187 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60188 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1313,1409,1393,1449,1063,1109,1513,1025,1449,292,1417,64,431,1289,17,1376,1392,1029,373,1056,32,256,1197,1109,1]

theorem envBound60188 : H12AffineFastState.Bounded env60188 := by
  intro p hp
  have h : env60188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60187_60188 : H12AffineEnvironment.transform 11 1313 env60187 = env60188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env60187 == env60188) = true)

theorem identity60188 : scanCanonicalize (H12AffineFastState.compose env60188 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound60188 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60189 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1028,1245,1149,1165,1109,1063,1109,1045,1025,1109,216,1141,64,83,1269,17,1180,1164,1029,137,1056,32,252,1197,1109,1]

theorem envBound60189 : H12AffineFastState.Bounded env60189 := by
  intro p hp
  have h : env60189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60188_60189 : H12AffineEnvironment.transform 7 252 env60188 = env60189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env60188 == env60189) = true)

theorem identity60189 : scanCanonicalize (H12AffineFastState.compose env60189 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound60189 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60190 : List Nat := [2,4,8,16,32,64,128,252,0,141,137,80,240,0,216,170,216,152,140,216,216,248,64,83,120,17,17,1,136,137,173,32,252,32,216,1]

theorem envBound60190 : H12AffineFastState.Bounded env60190 := by
  intro p hp
  have h : env60190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60189_60190 : H12AffineEnvironment.transform 9 141 env60189 = env60190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env60189 == env60190) = true)

theorem identity60190 : scanCanonicalize (H12AffineFastState.compose env60190 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound60190 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60191 : List Nat := [2,4,8,16,32,49,128,141,0,141,137,33,129,0,169,170,169,152,140,169,169,137,49,34,9,17,17,1,136,137,173,32,141,32,169,1]

theorem envBound60191 : H12AffineFastState.Bounded env60191 := by
  intro p hp
  have h : env60191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60190_60191 : H12AffineEnvironment.transform 5 49 env60190 = env60191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env60190 == env60191) = true)

theorem identity60191 : scanCanonicalize (H12AffineFastState.compose env60191 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound60191 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60192 : List Nat := [2,4,8,8,32,41,128,141,0,141,137,33,129,0,169,170,169,128,140,169,169,137,41,34,9,9,9,1,136,137,173,32,141,32,169,1]

theorem envBound60192 : H12AffineFastState.Bounded env60192 := by
  intro p hp
  have h : env60192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60191_60192 : H12AffineEnvironment.transform 3 8 env60191 = env60192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env60191 == env60192) = true)

theorem identity60192 : scanCanonicalize (H12AffineFastState.compose env60192 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound60192 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env60193 : List Nat := [2,4,8,8,32,41,11,6,0,6,2,33,10,0,34,33,34,11,7,34,34,2,41,34,9,9,9,1,3,2,38,32,6,32,34,1]

theorem envBound60193 : H12AffineFastState.Bounded env60193 := by
  intro p hp
  have h : env60193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60192_60193 : H12AffineEnvironment.transform 6 11 env60192 = env60193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env60192 == env60193) = true)

theorem identity60193 : scanCanonicalize (H12AffineFastState.compose env60193 (packedSelected [1,3,5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60193 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env60194 : List Nat := [0,4,8,8,32,41,9,4,0,4,0,33,8,0,32,33,32,9,5,32,32,0,41,32,9,9,9,1,1,0,36,32,4,32,32,1]

theorem envBound60194 : H12AffineFastState.Bounded env60194 := by
  intro p hp
  have h : env60194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60193_60194 : H12AffineEnvironment.transform 0 0 env60193 = env60194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60193 == env60194) = true)

theorem identity60194 : scanCanonicalize (H12AffineFastState.compose env60194 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60194 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60195 : List Nat := [0,4,0,0,32,33,1,4,0,4,0,33,0,0,32,33,32,1,5,32,32,0,33,32,1,1,1,1,1,0,36,32,4,32,32,1]

theorem envBound60195 : H12AffineFastState.Bounded env60195 := by
  intro p hp
  have h : env60195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60194_60195 : H12AffineEnvironment.transform 2 0 env60194 = env60195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60194 == env60195) = true)

theorem identity60195 : scanCanonicalize (H12AffineFastState.compose env60195 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60195 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60196 : List Nat := [0,4,0,0,0,1,1,4,0,4,0,1,0,0,0,1,0,1,5,0,0,0,1,0,1,1,1,1,1,0,4,0,4,0,0,1]

theorem envBound60196 : H12AffineFastState.Bounded env60196 := by
  intro p hp
  have h : env60196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60195_60196 : H12AffineEnvironment.transform 4 0 env60195 = env60196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60195 == env60196) = true)

def env60197 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3158,1289,9616,2365813,4177,77954,66899,65543,68094,256,65674,78034,9601]

theorem envBound60197 : H12AffineFastState.Bounded env60197 := by
  intro p hp
  have h : env60197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60173_60197 : H12AffineEnvironment.transform 8 1 env60173 = env60197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60173 == env60197) = true)

theorem identity60197 : scanCanonicalize (H12AffineFastState.compose env60197 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 14718) := by decide +kernel

theorem selectedBound60197 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60198 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,14718,2476,262144,1025,2128,2097152,1417,9665,3158,1289,9616,2365813,4177,2556,15405,14713,12416,256,14836,2476,9601]

theorem envBound60198 : H12AffineFastState.Bounded env60198 := by
  intro p hp
  have h : env60198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60197_60198 : H12AffineEnvironment.transform 15 14718 env60197 = env60198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14718 env60197 == env60198) = true)

def env60199 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,7422,2476,262144,1025,2128,2097152,1417,65,3158,1289,16,2365813,4177,2556,6573,7417,5376,256,7284,2476,1]

theorem envBound60199 : H12AffineFastState.Bounded env60199 := by
  intro p hp
  have h : env60199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60198_60199 : H12AffineEnvironment.transform 12 1408 env60198 = env60199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60198 == env60199) = true)

theorem identity60199 : scanCanonicalize (H12AffineFastState.compose env60199 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1029) := by decide +kernel

theorem selectedBound60199 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60200 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,7422,2476,262144,1025,2128,1029,1417,65,3158,1289,16,269680,4177,2556,6573,7417,5376,256,7284,2476,1]

theorem envBound60200 : H12AffineFastState.Bounded env60200 := by
  intro p hp
  have h : env60200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60199_60200 : H12AffineEnvironment.transform 20 1029 env60199 = env60200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1029 env60199 == env60200) = true)

theorem identity60200 : scanCanonicalize (H12AffineFastState.compose env60200 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3528) := by decide +kernel

theorem selectedBound60200 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60201 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,7422,2476,3528,1025,2128,1029,1417,65,3158,1289,16,4280,4177,2556,6573,7417,5376,256,7284,2476,1]

theorem envBound60201 : H12AffineFastState.Bounded env60201 := by
  intro p hp
  have h : env60201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60200_60201 : H12AffineEnvironment.transform 17 3528 env60200 = env60201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3528 env60200 == env60201) = true)

theorem identity60201 : scanCanonicalize (H12AffineFastState.compose env60201 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound60201 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60202 : List Nat := [2,4,8,16,32,64,128,256,1,1024,49,4096,1408,4176,97,5327,413,1529,1025,97,1029,1417,65,1127,1289,16,4280,4177,461,4508,5320,5376,256,5189,413,1]

theorem envBound60202 : H12AffineFastState.Bounded env60202 := by
  intro p hp
  have h : env60202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60201_60202 : H12AffineEnvironment.transform 10 49 env60201 = env60202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env60201 == env60202) = true)

theorem identity60202 : scanCanonicalize (H12AffineFastState.compose env60202 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound60202 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env60203 : List Nat := [2,4,8,16,32,64,128,256,1,1024,49,1312,1408,1392,97,495,413,1529,1025,97,1029,1417,65,1127,1289,16,1432,1393,461,1212,488,32,256,357,413,1]

theorem envBound60203 : H12AffineFastState.Bounded env60203 := by
  intro p hp
  have h : env60203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60202_60203 : H12AffineEnvironment.transform 11 1312 env60202 = env60203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env60202 == env60203) = true)

theorem identity60203 : scanCanonicalize (H12AffineFastState.compose env60203 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound60203 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60204 : List Nat := [2,4,8,16,32,64,128,256,1,237,49,461,365,413,97,495,413,276,236,97,232,356,65,138,484,16,373,412,461,81,488,32,256,357,413,1]

theorem envBound60204 : H12AffineFastState.Bounded env60204 := by
  intro p hp
  have h : env60204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60203_60204 : H12AffineEnvironment.transform 9 237 env60203 = env60204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env60203 == env60204) = true)

theorem identity60204 : scanCanonicalize (H12AffineFastState.compose env60204 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound60204 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60205 : List Nat := [2,4,8,16,32,64,128,182,1,237,49,123,219,43,97,89,43,162,236,97,232,210,65,138,82,16,195,42,123,81,94,32,182,211,43,1]

theorem envBound60205 : H12AffineFastState.Bounded env60205 := by
  intro p hp
  have h : env60205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60204_60205 : H12AffineEnvironment.transform 7 182 env60204 = env60205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env60204 == env60205) = true)

theorem identity60205 : scanCanonicalize (H12AffineFastState.compose env60205 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound60205 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env60206 : List Nat := [2,4,8,16,32,64,114,68,1,31,49,123,41,43,97,89,43,80,30,97,26,32,65,120,82,16,49,42,123,81,94,32,68,33,43,1]

theorem envBound60206 : H12AffineFastState.Bounded env60206 := by
  intro p hp
  have h : env60206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60205_60206 : H12AffineEnvironment.transform 6 114 env60205 = env60206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env60205 == env60206) = true)

def env60207 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,7423,2476,262144,1025,2128,2097152,1417,64,3158,1289,17,2365813,4177,2556,6572,7416,5377,256,7285,2476,0]

theorem envBound60207 : H12AffineFastState.Bounded env60207 := by
  intro p hp
  have h : env60207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60198_60207 : H12AffineEnvironment.transform 12 1409 env60198 = env60207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60198 == env60207) = true)

theorem identity60207 : scanCanonicalize (H12AffineFastState.compose env60207 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound60207 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60208 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,7423,2476,262144,1025,2128,6652,1417,64,3158,1289,17,262281,4177,2556,6572,7416,5377,256,7285,2476,0]

theorem envBound60208 : H12AffineFastState.Bounded env60208 := by
  intro p hp
  have h : env60208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60207_60208 : H12AffineEnvironment.transform 20 6652 env60207 = env60208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env60207 == env60208) = true)

theorem identity60208 : scanCanonicalize (H12AffineFastState.compose env60208 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60208 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60209 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1449,4358,1109,262144,1025,1449,5125,1417,64,431,1289,17,262281,4177,1029,5205,4353,5377,256,4492,1109,0]

theorem envBound60209 : H12AffineFastState.Bounded env60209 := by
  intro p hp
  have h : env60209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60208_60209 : H12AffineEnvironment.transform 10 1529 env60208 = env60209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60208 == env60209) = true)

theorem identity60209 : scanCanonicalize (H12AffineFastState.compose env60209 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1513) := by decide +kernel

theorem selectedBound60209 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60210 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1449,4358,1109,1513,1025,1449,5125,1417,64,431,1289,17,1376,4177,1029,5205,4353,5377,256,4492,1109,0]

theorem envBound60210 : H12AffineFastState.Bounded env60210 := by
  intro p hp
  have h : env60210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60209_60210 : H12AffineEnvironment.transform 17 1513 env60209 = env60210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1513 env60209 == env60210) = true)

theorem identity60210 : scanCanonicalize (H12AffineFastState.compose env60210 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound60210 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60211 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1313,1409,1393,1449,1063,1109,1513,1025,1449,292,1417,64,431,1289,17,1376,1392,1029,372,1056,32,256,1197,1109,0]

theorem envBound60211 : H12AffineFastState.Bounded env60211 := by
  intro p hp
  have h : env60211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60210_60211 : H12AffineEnvironment.transform 11 1313 env60210 = env60211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env60210 == env60211) = true)

theorem identity60211 : scanCanonicalize (H12AffineFastState.compose env60211 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound60211 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60212 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1028,1244,1148,1164,1108,1063,1109,1044,1025,1108,217,1140,64,82,1268,17,1181,1165,1029,137,1056,32,253,1197,1109,0]

theorem envBound60212 : H12AffineFastState.Bounded env60212 := by
  intro p hp
  have h : env60212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60211_60212 : H12AffineEnvironment.transform 7 253 env60211 = env60212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env60211 == env60212) = true)

theorem identity60212 : scanCanonicalize (H12AffineFastState.compose env60212 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60212 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60213 : List Nat := [2,4,8,16,32,16,128,173,1,1024,1028,1164,1068,1164,1028,1063,1029,1044,1025,1028,137,1060,16,2,1188,17,1181,1165,1029,137,1056,32,173,1197,1029,0]

theorem envBound60213 : H12AffineFastState.Bounded env60213 := by
  intro p hp
  have h : env60213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60212_60213 : H12AffineEnvironment.transform 5 16 env60212 = env60213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60212 == env60213) = true)

theorem identity60213 : scanCanonicalize (H12AffineFastState.compose env60213 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 10) := by decide +kernel

theorem selectedBound60213 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env60214 : List Nat := [2,4,8,16,32,16,10,39,1,1024,1028,1030,1068,1030,1028,1063,1029,1044,1025,1028,3,1060,16,2,1070,17,1047,1031,1029,3,1056,32,39,1063,1029,0]

theorem envBound60214 : H12AffineFastState.Bounded env60214 := by
  intro p hp
  have h : env60214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60213_60214 : H12AffineEnvironment.transform 6 10 env60213 = env60214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 10 env60213 == env60214) = true)

theorem identity60214 : scanCanonicalize (H12AffineFastState.compose env60214 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound60214 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60215 : List Nat := [2,4,8,16,32,16,10,39,1,21,17,19,57,19,17,50,16,1,20,17,3,49,16,2,59,17,2,18,16,3,53,32,39,50,16,0]

theorem envBound60215 : H12AffineFastState.Bounded env60215 := by
  intro p hp
  have h : env60215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60214_60215 : H12AffineEnvironment.transform 9 21 env60214 = env60215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env60214 == env60215) = true)

theorem identity60215 : scanCanonicalize (H12AffineFastState.compose env60215 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound60215 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env60216 : List Nat := [2,4,8,16,2,16,10,5,1,21,17,19,27,19,17,16,16,1,20,17,3,19,16,2,25,17,2,18,16,3,23,2,5,16,16,0]

theorem envBound60216 : H12AffineFastState.Bounded env60216 := by
  intro p hp
  have h : env60216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60215_60216 : H12AffineEnvironment.transform 4 2 env60215 = env60216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env60215 == env60216) = true)

theorem identity60216 : scanCanonicalize (H12AffineFastState.compose env60216 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60216 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60217 : List Nat := [2,4,1,16,2,16,3,5,1,21,17,19,18,19,17,16,16,1,20,17,3,19,16,2,16,17,2,18,16,3,23,2,5,16,16,0]

theorem envBound60217 : H12AffineFastState.Bounded env60217 := by
  intro p hp
  have h : env60217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60216_60217 : H12AffineEnvironment.transform 2 1 env60216 = env60217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60216 == env60217) = true)

theorem identity60217 : scanCanonicalize (H12AffineFastState.compose env60217 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound60217 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60218 : List Nat := [2,4,1,2,2,2,3,5,1,7,3,1,0,1,3,2,2,1,6,3,3,1,2,2,2,3,2,0,2,3,5,2,5,2,2,0]

theorem envBound60218 : H12AffineFastState.Bounded env60218 := by
  intro p hp
  have h : env60218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60217_60218 : H12AffineEnvironment.transform 3 2 env60217 = env60218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env60217 == env60218) = true)

theorem identity60218 : scanCanonicalize (H12AffineFastState.compose env60218 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60218 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60219 : List Nat := [1,4,1,1,1,1,0,5,1,4,0,1,0,1,0,1,1,1,5,0,0,1,1,1,1,0,1,0,1,0,5,1,5,1,1,0]

theorem envBound60219 : H12AffineFastState.Bounded env60219 := by
  intro p hp
  have h : env60219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60218_60219 : H12AffineEnvironment.transform 0 1 env60218 = env60219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60218 == env60219) = true)

def env60220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,4194304,8388608,8399766,8397001,8388689,134217728,4177,77954,4260571,8463814,149237955,256,136649726,78034,8389184]

theorem envBound60220 : H12AffineFastState.Bounded env60220 := by
  intro p hp
  have h : env60220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59844_60220 : H12AffineEnvironment.transform 24 8397001 env59844 = env60220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8397001 env59844 == env60220) = true)

def env60221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,4194304,8388608,8399766,8397001,8388689,6561532,4177,77954,4260571,8463814,8465983,256,4261122,78034,8389184]

theorem envBound60221 : H12AffineFastState.Bounded env60221 := by
  intro p hp
  have h : env60221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60220_60221 : H12AffineEnvironment.transform 26 6561532 env60220 = env60221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561532 env60220 == env60221) = true)

def env60222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,8388608,8399766,8397001,8388689,2366324,4177,77954,67411,8463814,8465983,256,65674,78034,8389184]

theorem envBound60222 : H12AffineFastState.Bounded env60222 := by
  intro p hp
  have h : env60222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60221_60222 : H12AffineEnvironment.transform 21 1416 env60221 = env60222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env60221 == env60222) = true)

def env60223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9664,3670,1289,9617,2366324,4177,77954,67411,65542,68607,256,65674,78034,10112]

theorem envBound60223 : H12AffineFastState.Bounded env60223 := by
  intro p hp
  have h : env60223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60222_60223 : H12AffineEnvironment.transform 22 9664 env60222 = env60223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env60222 == env60223) = true)

def env60224 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3158,1289,9617,2365812,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound60224 : H12AffineFastState.Bounded env60224 := by
  intro p hp
  have h : env60224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60223_60224 : H12AffineEnvironment.transform 8 0 env60223 = env60224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60223 == env60224) = true)

theorem identity60224 : scanCanonicalize (H12AffineFastState.compose env60224 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 3076) := by decide +kernel

theorem selectedBound60224 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60225 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,3076,1416,9664,3158,1289,9617,267632,4177,77954,66899,65542,68095,256,65674,78034,9600]

theorem envBound60225 : H12AffineFastState.Bounded env60225 := by
  intro p hp
  have h : env60225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60224_60225 : H12AffineEnvironment.transform 20 3076 env60224 = env60225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3076 env60224 == env60225) = true)

def env60226 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,3076,1416,64,3158,1289,17,267632,4177,70914,66899,65542,68095,256,65674,70994,0]

theorem envBound60226 : H12AffineFastState.Bounded env60226 := by
  intro p hp
  have h : env60226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60225_60226 : H12AffineEnvironment.transform 12 1408 env60225 = env60226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60225 == env60226) = true)

theorem identity60226 : scanCanonicalize (H12AffineFastState.compose env60226 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5374) := by decide +kernel

theorem selectedBound60226 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60227 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,5374,428,262144,1025,2129,3076,1416,64,3158,1289,17,267632,4177,508,4525,5368,7425,256,5236,428,0]

theorem envBound60227 : H12AffineFastState.Bounded env60227 := by
  intro p hp
  have h : env60227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60226_60227 : H12AffineEnvironment.transform 15 5374 env60226 = env60227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5374 env60226 == env60227) = true)

theorem identity60227 : scanCanonicalize (H12AffineFastState.compose env60227 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound60227 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60228 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,5374,428,6377,1025,2129,3076,1416,64,3158,1289,17,3481,4177,508,4525,5368,7425,256,5236,428,0]

theorem envBound60228 : H12AffineFastState.Bounded env60228 := by
  intro p hp
  have h : env60228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60227_60228 : H12AffineEnvironment.transform 17 6377 env60227 = env60228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env60227 == env60228) = true)

theorem identity60228 : scanCanonicalize (H12AffineFastState.compose env60228 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound60228 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60229 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,461,1408,413,2129,1331,428,2340,1025,2129,3076,1416,64,3158,1289,17,3481,412,508,96,1333,3276,256,1465,428,0]

theorem envBound60229 : H12AffineFastState.Bounded env60229 := by
  intro p hp
  have h : env60229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60228_60229 : H12AffineEnvironment.transform 11 461 env60228 = env60229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env60228 == env60229) = true)

theorem identity60229 : scanCanonicalize (H12AffineFastState.compose env60229 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound60229 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60230 : List Nat := [2,4,8,16,32,64,128,256,0,1024,324,461,1408,413,277,1331,428,96,1025,277,1344,1416,64,1298,1289,17,1245,412,508,96,1333,1416,256,1465,428,0]

theorem envBound60230 : H12AffineFastState.Bounded env60230 := by
  intro p hp
  have h : env60230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60229_60230 : H12AffineEnvironment.transform 10 324 env60229 = env60230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env60229 == env60230) = true)

theorem identity60230 : scanCanonicalize (H12AffineFastState.compose env60230 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound60230 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60231 : List Nat := [2,4,8,16,32,64,128,256,0,408,324,461,24,413,277,171,428,96,409,277,216,16,64,138,145,17,325,412,508,96,173,16,256,33,428,0]

theorem envBound60231 : H12AffineFastState.Bounded env60231 := by
  intro p hp
  have h : env60231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60230_60231 : H12AffineEnvironment.transform 9 408 env60230 = env60231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env60230 == env60231) = true)

theorem identity60231 : scanCanonicalize (H12AffineFastState.compose env60231 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60231 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60232 : List Nat := [2,4,8,16,32,64,128,94,0,198,26,147,24,195,75,171,242,96,199,75,216,16,64,138,145,17,27,194,162,96,173,16,94,33,242,0]

theorem envBound60232 : H12AffineFastState.Bounded env60232 := by
  intro p hp
  have h : env60232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60231_60232 : H12AffineEnvironment.transform 7 94 env60231 = env60232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60231 == env60232) = true)

theorem identity60232 : scanCanonicalize (H12AffineFastState.compose env60232 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60232 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60233 : List Nat := [2,4,8,16,16,64,128,94,0,198,26,147,24,195,75,155,194,80,199,75,216,16,64,138,145,17,27,194,146,80,157,16,94,17,194,0]

theorem envBound60233 : H12AffineFastState.Bounded env60233 := by
  intro p hp
  have h : env60233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60232_60233 : H12AffineEnvironment.transform 4 16 env60232 = env60233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60232 == env60233) = true)

def env60234 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,3076,1416,65,3158,1289,16,267632,4177,70915,66899,65542,68095,256,65674,70995,1]

theorem envBound60234 : H12AffineFastState.Bounded env60234 := by
  intro p hp
  have h : env60234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60225_60234 : H12AffineEnvironment.transform 12 1409 env60225 = env60234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60225 == env60234) = true)

theorem identity60234 : scanCanonicalize (H12AffineFastState.compose env60234 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60234 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60235 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1529,1409,1449,2129,65536,65706,262144,1025,2129,3076,1416,65,3158,1289,16,262281,1448,65786,66899,65542,68095,256,65674,65706,1]

theorem envBound60235 : H12AffineFastState.Bounded env60235 := by
  intro p hp
  have h : env60235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60234_60235 : H12AffineEnvironment.transform 11 1529 env60234 = env60235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1529 env60234 == env60235) = true)

theorem identity60235 : scanCanonicalize (H12AffineFastState.compose env60235 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60235 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60236 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1529,1409,1449,1448,65536,65706,262144,1025,1448,509,1416,65,431,1289,16,262281,1448,65786,66899,65542,66566,256,65674,65706,1]

theorem envBound60236 : H12AffineFastState.Bounded env60236 := by
  intro p hp
  have h : env60236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60235_60236 : H12AffineEnvironment.transform 10 1529 env60235 = env60236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60235 == env60236) = true)

theorem identity60236 : scanCanonicalize (H12AffineFastState.compose env60236 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65586) := by decide +kernel

theorem selectedBound60236 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60237 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1529,1409,1449,1448,65536,65706,65586,1025,1448,509,1416,65,431,1289,16,65723,1448,65786,66899,65542,66566,256,65674,65706,1]

theorem envBound60237 : H12AffineFastState.Bounded env60237 := by
  intro p hp
  have h : env60237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60236_60237 : H12AffineEnvironment.transform 17 65586 env60236 = env60237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65586 env60236 == env60237) = true)

theorem identity60237 : scanCanonicalize (H12AffineFastState.compose env60237 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60237 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60238 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1529,1409,1449,1448,1063,1165,1045,1025,1448,509,1416,65,431,1289,16,1180,1448,1245,372,1057,33,256,1197,1165,1]

theorem envBound60238 : H12AffineFastState.Bounded env60238 := by
  intro p hp
  have h : env60238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60237_60238 : H12AffineEnvironment.transform 15 1063 env60237 = env60238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60237 == env60238) = true)

theorem identity60238 : scanCanonicalize (H12AffineFastState.compose env60238 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60238 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60239 : List Nat := [2,4,8,16,32,64,128,256,0,221,292,292,348,372,373,250,80,200,220,373,509,341,65,431,468,16,65,373,0,372,252,33,256,112,80,1]

theorem envBound60239 : H12AffineFastState.Bounded env60239 := by
  intro p hp
  have h : env60239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60238_60239 : H12AffineEnvironment.transform 9 221 env60238 = env60239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60238 == env60239) = true)

theorem identity60239 : scanCanonicalize (H12AffineFastState.compose env60239 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60239 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60240 : List Nat := [2,4,8,16,32,17,128,256,0,140,292,292,269,293,292,171,1,153,141,292,428,260,16,431,389,16,16,292,0,293,173,33,256,33,1,1]

theorem envBound60240 : H12AffineFastState.Bounded env60240 := by
  intro p hp
  have h : env60240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60239_60240 : H12AffineEnvironment.transform 5 17 env60239 = env60240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60239 == env60240) = true)

theorem identity60240 : scanCanonicalize (H12AffineFastState.compose env60240 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 22) := by decide +kernel

theorem selectedBound60240 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env60241 : List Nat := [2,4,8,16,32,17,128,22,0,140,50,50,27,51,50,171,1,153,141,50,186,18,16,185,147,16,16,50,0,51,173,33,22,33,1,1]

theorem envBound60241 : H12AffineFastState.Bounded env60241 := by
  intro p hp
  have h : env60241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60240_60241 : H12AffineEnvironment.transform 7 22 env60240 = env60241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 22 env60240 == env60241) = true)

theorem identity60241 : scanCanonicalize (H12AffineFastState.compose env60241 (packedSelected [1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound60241 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60242 : List Nat := [2,4,8,2,32,3,128,4,0,140,32,32,9,33,32,171,1,139,141,32,168,0,2,171,129,2,2,32,0,33,173,33,4,33,1,1]

theorem envBound60242 : H12AffineFastState.Bounded env60242 := by
  intro p hp
  have h : env60242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60241_60242 : H12AffineEnvironment.transform 3 2 env60241 = env60242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env60241 == env60242) = true)

theorem identity60242 : scanCanonicalize (H12AffineFastState.compose env60242 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound60242 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60243 : List Nat := [2,4,8,2,32,3,3,4,0,15,32,32,9,33,32,40,1,8,14,32,43,0,2,40,2,2,2,32,0,33,46,33,4,33,1,1]

theorem envBound60243 : H12AffineFastState.Bounded env60243 := by
  intro p hp
  have h : env60243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60242_60243 : H12AffineEnvironment.transform 6 3 env60242 = env60243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env60242 == env60243) = true)

theorem identity60243 : scanCanonicalize (H12AffineFastState.compose env60243 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound60243 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60244 : List Nat := [2,4,3,2,32,3,3,4,0,4,32,32,2,33,32,35,1,3,5,32,32,0,2,35,2,2,2,32,0,33,37,33,4,33,1,1]

theorem envBound60244 : H12AffineFastState.Bounded env60244 := by
  intro p hp
  have h : env60244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60243_60244 : H12AffineEnvironment.transform 2 3 env60243 = env60244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env60243 == env60244) = true)

theorem identity60244 : scanCanonicalize (H12AffineFastState.compose env60244 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60244 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60245 : List Nat := [1,4,0,1,32,0,0,4,0,4,32,32,1,33,32,32,1,0,5,32,32,0,1,32,1,1,1,32,0,33,37,33,4,33,1,1]

theorem envBound60245 : H12AffineFastState.Bounded env60245 := by
  intro p hp
  have h : env60245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60244_60245 : H12AffineEnvironment.transform 0 1 env60244 = env60245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60244 == env60245) = true)

theorem identity60245 : scanCanonicalize (H12AffineFastState.compose env60245 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound60245 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60246 : List Nat := [1,4,0,1,1,0,0,4,0,4,1,1,1,0,1,1,1,0,5,1,1,0,1,1,1,1,1,1,0,0,4,0,4,0,1,1]

theorem envBound60246 : H12AffineFastState.Bounded env60246 := by
  intro p hp
  have h : env60246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60245_60246 : H12AffineEnvironment.transform 4 1 env60245 = env60246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env60245 == env60246) = true)

def env60247 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3159,1289,9617,2365813,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound60247 : H12AffineFastState.Bounded env60247 := by
  intro p hp
  have h : env60247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60223_60247 : H12AffineEnvironment.transform 8 1 env60223 = env60247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60223 == env60247) = true)

theorem identity60247 : scanCanonicalize (H12AffineFastState.compose env60247 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 10628) := by decide +kernel

theorem selectedBound60247 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60248 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,10628,1416,9664,3159,1289,9617,274673,4177,77954,66898,65542,68094,256,65674,78034,9601]

theorem envBound60248 : H12AffineFastState.Bounded env60248 := by
  intro p hp
  have h : env60248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60247_60248 : H12AffineEnvironment.transform 20 10628 env60247 = env60248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 10628 env60247 == env60248) = true)

def env60249 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,3076,1416,64,3159,1289,17,267633,4177,70914,66898,65542,68094,256,65674,70994,1]

theorem envBound60249 : H12AffineFastState.Bounded env60249 := by
  intro p hp
  have h : env60249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60248_60249 : H12AffineEnvironment.transform 12 1408 env60248 = env60249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60248 == env60249) = true)

theorem identity60249 : scanCanonicalize (H12AffineFastState.compose env60249 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5375) := by decide +kernel

theorem selectedBound60249 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60250 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,5375,429,262144,1025,2128,3076,1416,64,3159,1289,17,267633,4177,509,4525,5369,7425,256,5237,429,1]

theorem envBound60250 : H12AffineFastState.Bounded env60250 := by
  intro p hp
  have h : env60250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60249_60250 : H12AffineEnvironment.transform 15 5375 env60249 = env60250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5375 env60249 == env60250) = true)

theorem identity60250 : scanCanonicalize (H12AffineFastState.compose env60250 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound60250 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60251 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,5375,429,6376,1025,2128,3076,1416,64,3159,1289,17,3481,4177,509,4525,5369,7425,256,5237,429,1]

theorem envBound60251 : H12AffineFastState.Bounded env60251 := by
  intro p hp
  have h : env60251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60250_60251 : H12AffineEnvironment.transform 17 6376 env60250 = env60251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env60250 == env60251) = true)

theorem identity60251 : scanCanonicalize (H12AffineFastState.compose env60251 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound60251 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60252 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,460,1408,412,2128,1331,429,2340,1025,2128,3076,1416,64,3159,1289,17,3481,413,509,97,1333,3277,256,1465,429,1]

theorem envBound60252 : H12AffineFastState.Bounded env60252 := by
  intro p hp
  have h : env60252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60251_60252 : H12AffineEnvironment.transform 11 460 env60251 = env60252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env60251 == env60252) = true)

theorem identity60252 : scanCanonicalize (H12AffineFastState.compose env60252 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound60252 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60253 : List Nat := [2,4,8,16,32,64,128,256,1,408,2048,460,24,412,2128,171,429,2340,409,2128,2460,16,64,2511,145,17,2049,413,509,97,173,2389,256,33,429,1]

theorem envBound60253 : H12AffineFastState.Bounded env60253 := by
  intro p hp
  have h : env60253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60252_60253 : H12AffineEnvironment.transform 9 408 env60252 = env60253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env60252 == env60253) = true)

theorem identity60253 : scanCanonicalize (H12AffineFastState.compose env60253 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60253 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60254 : List Nat := [2,4,8,16,32,64,128,256,1,408,325,460,24,412,277,171,429,97,409,277,217,16,64,138,145,17,324,413,509,97,173,16,256,33,429,1]

theorem envBound60254 : H12AffineFastState.Bounded env60254 := by
  intro p hp
  have h : env60254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60253_60254 : H12AffineEnvironment.transform 10 325 env60253 = env60254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60253 == env60254) = true)

theorem identity60254 : scanCanonicalize (H12AffineFastState.compose env60254 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound60254 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60255 : List Nat := [2,4,8,16,32,64,128,110,1,246,43,162,24,242,123,171,195,97,247,123,217,16,64,138,145,17,42,243,147,97,173,16,110,33,195,1]

theorem envBound60255 : H12AffineFastState.Bounded env60255 := by
  intro p hp
  have h : env60255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60254_60255 : H12AffineEnvironment.transform 7 110 env60254 = env60255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env60254 == env60255) = true)

theorem identity60255 : scanCanonicalize (H12AffineFastState.compose env60255 (packedSelected [0,1,6,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60255 : packedSelected [0,1,6,11] rootPS < 2^1333 := by decide +kernel

def env60256 : List Nat := [2,4,8,16,16,64,128,94,1,198,27,146,24,194,75,155,195,81,199,75,217,16,64,138,145,17,26,195,147,81,157,16,94,17,195,1]

theorem envBound60256 : H12AffineFastState.Bounded env60256 := by
  intro p hp
  have h : env60256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60255_60256 : H12AffineEnvironment.transform 4 16 env60255 = env60256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60255 == env60256) = true)

def env60257 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,3077,1416,65,3159,1289,16,267632,4177,70915,66898,65542,68094,256,65674,70995,0]

theorem envBound60257 : H12AffineFastState.Bounded env60257 := by
  intro p hp
  have h : env60257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60248_60257 : H12AffineEnvironment.transform 12 1409 env60248 = env60257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60248 == env60257) = true)

theorem identity60257 : scanCanonicalize (H12AffineFastState.compose env60257 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60257 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60258 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1529,1409,1449,2128,65536,65706,262144,1025,2128,3077,1416,65,3159,1289,16,262281,1448,65786,66898,65542,68094,256,65674,65706,0]

theorem envBound60258 : H12AffineFastState.Bounded env60258 := by
  intro p hp
  have h : env60258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60257_60258 : H12AffineEnvironment.transform 11 1529 env60257 = env60258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1529 env60257 == env60258) = true)

theorem identity60258 : scanCanonicalize (H12AffineFastState.compose env60258 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60258 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60259 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1529,1409,1449,1448,65536,65706,262144,1025,1448,509,1416,65,431,1289,16,262281,1448,65786,66898,65542,66566,256,65674,65706,0]

theorem envBound60259 : H12AffineFastState.Bounded env60259 := by
  intro p hp
  have h : env60259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60258_60259 : H12AffineEnvironment.transform 10 1528 env60258 = env60259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60258 == env60259) = true)

theorem identity60259 : scanCanonicalize (H12AffineFastState.compose env60259 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65586) := by decide +kernel

theorem selectedBound60259 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60260 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1529,1409,1449,1448,65536,65706,65586,1025,1448,509,1416,65,431,1289,16,65723,1448,65786,66898,65542,66566,256,65674,65706,0]

theorem envBound60260 : H12AffineFastState.Bounded env60260 := by
  intro p hp
  have h : env60260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60259_60260 : H12AffineEnvironment.transform 17 65586 env60259 = env60260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65586 env60259 == env60260) = true)

theorem identity60260 : scanCanonicalize (H12AffineFastState.compose env60260 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60260 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60261 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1529,1409,1449,1448,1063,1165,1045,1025,1448,509,1416,65,431,1289,16,1180,1448,1245,373,1057,33,256,1197,1165,0]

theorem envBound60261 : H12AffineFastState.Bounded env60261 := by
  intro p hp
  have h : env60261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60260_60261 : H12AffineEnvironment.transform 15 1063 env60260 = env60261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60260 == env60261) = true)

theorem identity60261 : scanCanonicalize (H12AffineFastState.compose env60261 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60261 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60262 : List Nat := [2,4,8,16,32,64,128,256,1,220,292,293,349,373,372,251,81,201,221,372,509,340,65,431,469,16,64,372,1,373,253,33,256,113,81,0]

theorem envBound60262 : H12AffineFastState.Bounded env60262 := by
  intro p hp
  have h : env60262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60261_60262 : H12AffineEnvironment.transform 9 220 env60261 = env60262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60261 == env60262) = true)

theorem identity60262 : scanCanonicalize (H12AffineFastState.compose env60262 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound60262 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60263 : List Nat := [2,4,8,16,32,64,128,172,1,220,136,137,241,217,216,251,81,201,221,216,81,248,65,3,121,16,64,216,1,217,253,33,172,113,81,0]

theorem envBound60263 : H12AffineFastState.Bounded env60263 := by
  intro p hp
  have h : env60263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60262_60263 : H12AffineEnvironment.transform 7 172 env60262 = env60263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60262 == env60263) = true)

theorem identity60263 : scanCanonicalize (H12AffineFastState.compose env60263 (packedSelected [3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound60263 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env60264 : List Nat := [2,4,8,16,3,64,128,143,1,220,136,137,210,217,216,216,81,201,221,216,81,219,65,3,90,16,64,216,1,217,222,2,143,82,81,0]

theorem envBound60264 : H12AffineFastState.Bounded env60264 := by
  intro p hp
  have h : env60264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60263_60264 : H12AffineEnvironment.transform 4 3 env60263 = env60264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env60263 == env60264) = true)

theorem identity60264 : scanCanonicalize (H12AffineFastState.compose env60264 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound60264 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env60265 : List Nat := [2,4,8,16,3,18,128,143,1,142,136,137,128,139,138,138,3,155,143,138,3,137,19,3,8,16,18,138,1,139,140,2,143,0,3,0]

theorem envBound60265 : H12AffineFastState.Bounded env60265 := by
  intro p hp
  have h : env60265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60264_60265 : H12AffineEnvironment.transform 5 18 env60264 = env60265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env60264 == env60265) = true)

theorem identity60265 : scanCanonicalize (H12AffineFastState.compose env60265 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60265 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60266 : List Nat := [2,4,8,10,3,8,128,143,1,142,136,137,128,139,138,138,3,129,143,138,3,137,9,3,8,10,8,138,1,139,140,2,143,0,3,0]

theorem envBound60266 : H12AffineFastState.Bounded env60266 := by
  intro p hp
  have h : env60266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60265_60266 : H12AffineEnvironment.transform 3 10 env60265 = env60266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60265 == env60266) = true)

theorem identity60266 : scanCanonicalize (H12AffineFastState.compose env60266 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound60266 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60267 : List Nat := [2,4,8,10,3,8,9,6,1,7,1,0,9,2,3,3,3,8,6,3,3,0,9,3,8,10,8,3,1,2,5,2,6,0,3,0]

theorem envBound60267 : H12AffineFastState.Bounded env60267 := by
  intro p hp
  have h : env60267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60266_60267 : H12AffineEnvironment.transform 6 9 env60266 = env60267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env60266 == env60267) = true)

theorem identity60267 : scanCanonicalize (H12AffineFastState.compose env60267 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60267 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60268 : List Nat := [2,4,1,3,3,1,0,6,1,7,1,0,0,2,3,3,3,1,6,3,3,0,0,3,1,3,1,3,1,2,5,2,6,0,3,0]

theorem envBound60268 : H12AffineFastState.Bounded env60268 := by
  intro p hp
  have h : env60268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60267_60268 : H12AffineEnvironment.transform 2 1 env60267 = env60268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60267 == env60268) = true)

theorem identity60268 : scanCanonicalize (H12AffineFastState.compose env60268 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60269 : List Nat := [1,4,1,0,0,1,0,5,1,4,1,0,0,1,0,0,0,1,5,0,0,0,0,0,1,0,1,0,1,1,5,1,5,0,0,0]

theorem envBound60269 : H12AffineFastState.Bounded env60269 := by
  intro p hp
  have h : env60269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60268_60269 : H12AffineEnvironment.transform 0 1 env60268 = env60269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60268 == env60269) = true)

def env60270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9665,3671,1288,9616,2366324,4177,77954,67411,65543,68606,256,65674,78034,10113]

theorem envBound60270 : H12AffineFastState.Bounded env60270 := by
  intro p hp
  have h : env60270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60222_60270 : H12AffineEnvironment.transform 22 9665 env60222 = env60270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env60222 == env60270) = true)

def env60271 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3159,1288,9616,2365812,4177,77954,66899,65543,68094,256,65674,78034,9601]

theorem envBound60271 : H12AffineFastState.Bounded env60271 := by
  intro p hp
  have h : env60271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60270_60271 : H12AffineEnvironment.transform 8 0 env60270 = env60271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60270 == env60271) = true)

theorem identity60271 : scanCanonicalize (H12AffineFastState.compose env60271 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 4564) := by decide +kernel

theorem selectedBound60271 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60272 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,4564,4176,2129,65536,65798,262144,1025,2129,2097152,1416,5141,3159,1288,5188,2365812,4177,65878,66899,65543,68094,256,65674,65798,5205]

theorem envBound60272 : H12AffineFastState.Bounded env60272 := by
  intro p hp
  have h : env60272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60271_60272 : H12AffineEnvironment.transform 12 4564 env60271 = env60272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4564 env60271 == env60272) = true)

def env60273 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1408,1028,2129,65536,65798,262144,1025,2129,2097152,1416,65,3159,1288,16,2362656,1029,65878,66899,65543,68094,256,65674,65798,1]

theorem envBound60273 : H12AffineFastState.Bounded env60273 := by
  intro p hp
  have h : env60273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60272_60273 : H12AffineEnvironment.transform 11 1108 env60272 = env60273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env60272 == env60273) = true)

theorem identity60273 : scanCanonicalize (H12AffineFastState.compose env60273 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3497) := by decide +kernel

theorem selectedBound60273 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60274 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1408,1028,2129,65536,65798,262144,1025,2129,3497,1416,65,3159,1288,16,262281,1029,65878,66899,65543,68094,256,65674,65798,1]

theorem envBound60274 : H12AffineFastState.Bounded env60274 := by
  intro p hp
  have h : env60274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60273_60274 : H12AffineEnvironment.transform 20 3497 env60273 = env60274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3497 env60273 == env60274) = true)

theorem identity60274 : scanCanonicalize (H12AffineFastState.compose env60274 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60274 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60275 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1108,1408,1028,1448,65536,65798,262144,1025,1448,80,1416,65,430,1288,16,262281,1029,65878,66899,65543,66567,256,65674,65798,1]

theorem envBound60275 : H12AffineFastState.Bounded env60275 := by
  intro p hp
  have h : env60275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60274_60275 : H12AffineEnvironment.transform 10 1529 env60274 = env60275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60274 == env60275) = true)

theorem identity60275 : scanCanonicalize (H12AffineFastState.compose env60275 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65951) := by decide +kernel

theorem selectedBound60275 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60276 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1108,1408,1028,1448,65536,65798,65951,1025,1448,80,1416,65,430,1288,16,65814,1029,65878,66899,65543,66567,256,65674,65798,1]

theorem envBound60276 : H12AffineFastState.Bounded env60276 := by
  intro p hp
  have h : env60276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60275_60276 : H12AffineEnvironment.transform 17 65951 env60275 = env60276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65951 env60275 == env60276) = true)

theorem identity60276 : scanCanonicalize (H12AffineFastState.compose env60276 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60276 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60277 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1108,1408,1028,1448,1063,1313,1464,1025,1448,80,1416,65,430,1288,16,1329,1029,1393,372,1056,32,256,1197,1313,1]

theorem envBound60277 : H12AffineFastState.Bounded env60277 := by
  intro p hp
  have h : env60277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60276_60277 : H12AffineEnvironment.transform 15 1063 env60276 = env60277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60276 == env60277) = true)

theorem identity60277 : scanCanonicalize (H12AffineFastState.compose env60277 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60277 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60278 : List Nat := [2,4,8,16,32,64,128,256,0,221,292,137,349,217,373,250,508,357,220,373,80,341,65,430,469,16,492,216,428,372,253,32,256,112,508,1]

theorem envBound60278 : H12AffineFastState.Bounded env60278 := by
  intro p hp
  have h : env60278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60277_60278 : H12AffineEnvironment.transform 9 221 env60277 = env60278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60277 == env60278) = true)

theorem identity60278 : scanCanonicalize (H12AffineFastState.compose env60278 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound60278 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env60279 : List Nat := [2,4,8,16,17,64,128,256,0,221,277,137,349,217,324,203,461,340,220,324,80,341,65,415,469,16,477,216,413,325,204,17,256,65,461,1]

theorem envBound60279 : H12AffineFastState.Bounded env60279 := by
  intro p hp
  have h : env60279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60278_60279 : H12AffineEnvironment.transform 4 17 env60278 = env60279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env60278 == env60279) = true)

theorem identity60279 : scanCanonicalize (H12AffineFastState.compose env60279 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound60279 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60280 : List Nat := [2,4,8,16,17,0,128,256,0,157,277,137,285,153,260,139,397,276,156,260,16,277,1,415,405,16,413,152,413,261,140,17,256,1,397,1]

theorem envBound60280 : H12AffineFastState.Bounded env60280 := by
  intro p hp
  have h : env60280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60279_60280 : H12AffineEnvironment.transform 5 0 env60279 = env60280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env60279 == env60280) = true)

theorem identity60280 : scanCanonicalize (H12AffineFastState.compose env60280 (packedSelected [1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound60280 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env60281 : List Nat := [2,4,8,16,17,0,16,256,0,13,277,25,285,9,260,27,285,276,12,260,16,277,1,271,261,16,269,8,269,261,28,17,256,1,285,1]

theorem envBound60281 : H12AffineFastState.Bounded env60281 := by
  intro p hp
  have h : env60281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60280_60281 : H12AffineEnvironment.transform 6 16 env60280 = env60281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env60280 == env60281) = true)

theorem identity60281 : scanCanonicalize (H12AffineFastState.compose env60281 (packedSelected [0,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60281 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env60282 : List Nat := [2,4,0,16,17,0,16,256,0,5,277,17,277,1,260,19,277,276,4,260,16,277,1,263,261,16,261,0,261,261,20,17,256,1,277,1]

theorem envBound60282 : H12AffineFastState.Bounded env60282 := by
  intro p hp
  have h : env60282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60281_60282 : H12AffineEnvironment.transform 2 0 env60281 = env60282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60281 == env60282) = true)

theorem identity60282 : scanCanonicalize (H12AffineFastState.compose env60282 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound60282 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env60283 : List Nat := [2,4,0,3,2,0,3,256,0,5,262,2,262,1,260,0,262,263,4,260,3,262,1,263,261,3,261,0,261,261,7,2,256,1,262,1]

theorem envBound60283 : H12AffineFastState.Bounded env60283 := by
  intro p hp
  have h : env60283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60282_60283 : H12AffineEnvironment.transform 3 3 env60282 = env60283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env60282 == env60283) = true)

theorem identity60283 : scanCanonicalize (H12AffineFastState.compose env60283 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60283 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60284 : List Nat := [1,4,0,0,1,0,0,256,0,5,261,1,261,1,260,0,261,260,4,260,0,261,1,260,261,0,261,0,261,261,4,1,256,1,261,1]

theorem envBound60284 : H12AffineFastState.Bounded env60284 := by
  intro p hp
  have h : env60284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60283_60284 : H12AffineEnvironment.transform 0 1 env60283 = env60284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60283 == env60284) = true)

theorem identity60284 : scanCanonicalize (H12AffineFastState.compose env60284 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound60284 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env60285 : List Nat := [1,4,0,0,1,0,0,5,0,5,0,1,0,1,1,0,0,1,4,1,0,0,1,1,0,0,0,0,0,0,4,1,5,1,0,1]

theorem envBound60285 : H12AffineFastState.Bounded env60285 := by
  intro p hp
  have h : env60285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60284_60285 : H12AffineEnvironment.transform 7 5 env60284 = env60285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env60284 == env60285) = true)

def env60286 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1109,1409,1029,2129,65536,65798,262144,1025,2129,2097152,1416,64,3159,1288,17,2362657,1028,65878,66899,65543,68094,256,65674,65798,0]

theorem envBound60286 : H12AffineFastState.Bounded env60286 := by
  intro p hp
  have h : env60286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60272_60286 : H12AffineEnvironment.transform 11 1109 env60272 = env60286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env60272 == env60286) = true)

theorem identity60286 : scanCanonicalize (H12AffineFastState.compose env60286 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 68782) := by decide +kernel

theorem selectedBound60286 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60287 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1109,1409,1029,2129,65536,65798,262144,1025,2129,68782,1416,64,3159,1288,17,328079,1028,65878,66899,65543,68094,256,65674,65798,0]

theorem envBound60287 : H12AffineFastState.Bounded env60287 := by
  intro p hp
  have h : env60287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60286_60287 : H12AffineEnvironment.transform 20 68782 env60286 = env60287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 68782 env60286 == env60287) = true)

theorem identity60287 : scanCanonicalize (H12AffineFastState.compose env60287 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3260) := by decide +kernel

theorem selectedBound60287 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60288 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1109,1409,1029,2129,65536,65798,3260,1025,2129,68782,1416,64,3159,1288,17,68915,1028,65878,66899,65543,68094,256,65674,65798,0]

theorem envBound60288 : H12AffineFastState.Bounded env60288 := by
  intro p hp
  have h : env60288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60287_60288 : H12AffineEnvironment.transform 17 3260 env60287 = env60288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3260 env60287 == env60288) = true)

theorem identity60288 : scanCanonicalize (H12AffineFastState.compose env60288 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60288 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60289 : List Nat := [2,4,8,16,32,64,128,256,0,1024,325,1109,1409,1029,276,65536,65798,1529,1025,276,67051,1416,64,1298,1288,17,66678,1028,65878,66899,65543,65723,256,65674,65798,0]

theorem envBound60289 : H12AffineFastState.Bounded env60289 := by
  intro p hp
  have h : env60289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60288_60289 : H12AffineEnvironment.transform 10 325 env60288 = env60289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60288 == env60289) = true)

theorem identity60289 : scanCanonicalize (H12AffineFastState.compose env60289 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60289 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60290 : List Nat := [2,4,8,16,16,64,128,256,0,1024,325,1109,1409,1029,276,65536,65798,1481,1025,276,67035,1416,64,1298,1288,17,66630,1028,65878,66899,65543,65675,256,65674,65798,0]

theorem envBound60290 : H12AffineFastState.Bounded env60290 := by
  intro p hp
  have h : env60290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60289_60290 : H12AffineEnvironment.transform 4 16 env60289 = env60290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60289 == env60290) = true)

theorem identity60290 : scanCanonicalize (H12AffineFastState.compose env60290 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound60290 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60291 : List Nat := [2,4,8,16,16,64,128,256,0,1024,325,1109,1409,1029,276,154,412,1481,1025,276,1345,1416,64,1298,1288,17,1244,1028,460,1481,157,17,256,16,412,0]

theorem envBound60291 : H12AffineFastState.Bounded env60291 := by
  intro p hp
  have h : env60291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60290_60291 : H12AffineEnvironment.transform 15 154 env60290 = env60291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env60290 == env60291) = true)

theorem identity60291 : scanCanonicalize (H12AffineFastState.compose env60291 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60291 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60292 : List Nat := [2,4,8,16,16,64,128,94,0,1024,27,1109,1247,1029,74,154,194,1175,1025,74,1055,1238,64,1100,1110,17,1244,1028,146,1175,157,17,94,16,194,0]

theorem envBound60292 : H12AffineFastState.Bounded env60292 := by
  intro p hp
  have h : env60292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60291_60292 : H12AffineEnvironment.transform 7 94 env60291 = env60292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60291 == env60292) = true)

def env60293 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3158,1288,9616,2365813,4177,77954,66898,65543,68095,256,65674,78034,9600]

theorem envBound60293 : H12AffineFastState.Bounded env60293 := by
  intro p hp
  have h : env60293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60270_60293 : H12AffineEnvironment.transform 8 1 env60270 = env60293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60270 == env60293) = true)

theorem identity60293 : scanCanonicalize (H12AffineFastState.compose env60293 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound60293 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60294 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,8192,1028,2128,65536,74886,262144,1025,2128,2097152,1416,9665,3158,1288,9616,2362657,1029,74966,66898,65543,68095,256,65674,74886,9600]

theorem envBound60294 : H12AffineFastState.Bounded env60294 := by
  intro p hp
  have h : env60294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60293_60294 : H12AffineEnvironment.transform 11 1108 env60293 = env60294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env60293 == env60294) = true)

def env60295 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1408,1028,2128,65536,65798,262144,1025,2128,2097152,1416,65,3158,1288,16,2362657,1029,65878,66898,65543,68095,256,65674,65798,0]

theorem envBound60295 : H12AffineFastState.Bounded env60295 := by
  intro p hp
  have h : env60295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60294_60295 : H12AffineEnvironment.transform 12 1408 env60294 = env60295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60294 == env60295) = true)

theorem identity60295 : scanCanonicalize (H12AffineFastState.compose env60295 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3496) := by decide +kernel

theorem selectedBound60295 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60296 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1408,1028,2128,65536,65798,262144,1025,2128,3496,1416,65,3158,1288,16,262281,1029,65878,66898,65543,68095,256,65674,65798,0]

theorem envBound60296 : H12AffineFastState.Bounded env60296 := by
  intro p hp
  have h : env60296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60295_60296 : H12AffineEnvironment.transform 20 3496 env60295 = env60296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3496 env60295 == env60296) = true)

theorem identity60296 : scanCanonicalize (H12AffineFastState.compose env60296 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60296 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60297 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1108,1408,1028,1448,65536,65798,262144,1025,1448,80,1416,65,430,1288,16,262281,1029,65878,66898,65543,66567,256,65674,65798,0]

theorem envBound60297 : H12AffineFastState.Bounded env60297 := by
  intro p hp
  have h : env60297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60296_60297 : H12AffineEnvironment.transform 10 1528 env60296 = env60297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60296 == env60297) = true)

theorem identity60297 : scanCanonicalize (H12AffineFastState.compose env60297 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65951) := by decide +kernel

theorem selectedBound60297 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60298 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1108,1408,1028,1448,65536,65798,65951,1025,1448,80,1416,65,430,1288,16,65814,1029,65878,66898,65543,66567,256,65674,65798,0]

theorem envBound60298 : H12AffineFastState.Bounded env60298 := by
  intro p hp
  have h : env60298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60297_60298 : H12AffineEnvironment.transform 17 65951 env60297 = env60298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65951 env60297 == env60298) = true)

theorem identity60298 : scanCanonicalize (H12AffineFastState.compose env60298 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60298 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60299 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1108,1408,1028,1448,1063,1313,1464,1025,1448,80,1416,65,430,1288,16,1329,1029,1393,373,1056,32,256,1197,1313,0]

theorem envBound60299 : H12AffineFastState.Bounded env60299 := by
  intro p hp
  have h : env60299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60298_60299 : H12AffineEnvironment.transform 15 1063 env60298 = env60299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60298 == env60299) = true)

theorem identity60299 : scanCanonicalize (H12AffineFastState.compose env60299 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60299 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60300 : List Nat := [2,4,8,16,32,64,128,256,1,220,292,136,348,216,372,251,509,356,221,372,80,340,65,430,468,16,493,217,429,373,252,32,256,113,509,0]

theorem envBound60300 : H12AffineFastState.Bounded env60300 := by
  intro p hp
  have h : env60300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60299_60300 : H12AffineEnvironment.transform 9 220 env60299 = env60300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60299 == env60300) = true)

theorem identity60300 : scanCanonicalize (H12AffineFastState.compose env60300 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound60300 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env60301 : List Nat := [2,4,8,16,32,64,41,256,1,117,292,33,348,113,372,82,340,356,116,372,80,340,65,263,381,16,324,112,260,373,85,32,256,113,340,0]

theorem envBound60301 : H12AffineFastState.Bounded env60301 := by
  intro p hp
  have h : env60301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60300_60301 : H12AffineEnvironment.transform 6 41 env60300 = env60301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env60300 == env60301) = true)

theorem identity60301 : scanCanonicalize (H12AffineFastState.compose env60301 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60301 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60302 : List Nat := [2,4,8,16,32,17,41,256,1,36,292,33,269,32,293,3,261,309,37,293,1,261,16,263,300,16,277,33,260,292,4,32,256,32,261,0]

theorem envBound60302 : H12AffineFastState.Bounded env60302 := by
  intro p hp
  have h : env60302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60301_60302 : H12AffineEnvironment.transform 5 17 env60301 = env60302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60301 == env60302) = true)

theorem identity60302 : scanCanonicalize (H12AffineFastState.compose env60302 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 38) := by decide +kernel

theorem selectedBound60302 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60303 : List Nat := [2,4,8,16,32,17,41,38,1,36,2,33,43,32,3,3,35,19,37,3,1,35,16,33,10,16,51,33,34,2,4,32,38,32,35,0]

theorem envBound60303 : H12AffineFastState.Bounded env60303 := by
  intro p hp
  have h : env60303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60302_60303 : H12AffineEnvironment.transform 7 38 env60302 = env60303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 38 env60302 == env60303) = true)

theorem identity60303 : scanCanonicalize (H12AffineFastState.compose env60303 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound60303 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60304 : List Nat := [2,4,8,16,11,17,2,13,1,15,2,10,0,11,3,3,8,19,14,3,1,8,16,10,10,16,24,10,9,2,4,11,13,11,8,0]

theorem envBound60304 : H12AffineFastState.Bounded env60304 := by
  intro p hp
  have h : env60304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60303_60304 : H12AffineEnvironment.transform 4 11 env60303 = env60304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env60303 == env60304) = true)

theorem identity60304 : scanCanonicalize (H12AffineFastState.compose env60304 (packedSelected [3,5,6] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60304 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env60305 : List Nat := [2,4,1,16,2,17,2,4,1,6,2,3,0,2,3,3,1,19,7,3,1,1,16,3,3,16,17,3,0,2,4,2,4,2,1,0]

theorem envBound60305 : H12AffineFastState.Bounded env60305 := by
  intro p hp
  have h : env60305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60304_60305 : H12AffineEnvironment.transform 2 1 env60304 = env60305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60304 == env60305) = true)

theorem identity60305 : scanCanonicalize (H12AffineFastState.compose env60305 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound60305 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60306 : List Nat := [2,4,1,3,2,2,2,4,1,6,2,3,0,2,3,3,1,0,7,3,1,1,3,3,3,3,2,3,0,2,4,2,4,2,1,0]

theorem envBound60306 : H12AffineFastState.Bounded env60306 := by
  intro p hp
  have h : env60306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60305_60306 : H12AffineEnvironment.transform 3 3 env60305 = env60306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env60305 == env60306) = true)

def env60307 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1409,1028,2128,65536,65799,262144,1025,2128,2097152,1416,64,3158,1288,17,2362657,1029,65879,66898,65543,68095,256,65674,65799,1]

theorem envBound60307 : H12AffineFastState.Bounded env60307 := by
  intro p hp
  have h : env60307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60294_60307 : H12AffineEnvironment.transform 12 1409 env60294 = env60307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60294 == env60307) = true)

theorem identity60307 : scanCanonicalize (H12AffineFastState.compose env60307 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 68782) := by decide +kernel

theorem selectedBound60307 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60308 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1409,1028,2128,65536,65799,262144,1025,2128,68782,1416,64,3158,1288,17,328079,1029,65879,66898,65543,68095,256,65674,65799,1]

theorem envBound60308 : H12AffineFastState.Bounded env60308 := by
  intro p hp
  have h : env60308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60307_60308 : H12AffineEnvironment.transform 20 68782 env60307 = env60308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 68782 env60307 == env60308) = true)

theorem identity60308 : scanCanonicalize (H12AffineFastState.compose env60308 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3260) := by decide +kernel

theorem selectedBound60308 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60309 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1409,1028,2128,65536,65799,3260,1025,2128,68782,1416,64,3158,1288,17,68915,1029,65879,66898,65543,68095,256,65674,65799,1]

theorem envBound60309 : H12AffineFastState.Bounded env60309 := by
  intro p hp
  have h : env60309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60308_60309 : H12AffineEnvironment.transform 17 3260 env60308 = env60309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3260 env60308 == env60309) = true)

theorem identity60309 : scanCanonicalize (H12AffineFastState.compose env60309 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound60309 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60310 : List Nat := [2,4,8,16,32,64,128,256,1,1024,324,1108,1409,1028,276,65536,65799,1528,1025,276,67050,1416,64,1298,1288,17,66679,1029,65879,66898,65543,65723,256,65674,65799,1]

theorem envBound60310 : H12AffineFastState.Bounded env60310 := by
  intro p hp
  have h : env60310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60309_60310 : H12AffineEnvironment.transform 10 324 env60309 = env60310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env60309 == env60310) = true)

theorem identity60310 : scanCanonicalize (H12AffineFastState.compose env60310 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound60310 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60311 : List Nat := [2,4,8,16,32,64,128,256,1,424,324,508,41,428,276,65536,65799,80,425,276,65602,32,64,186,160,17,66015,429,65879,65786,65543,65723,256,65674,65799,1]

theorem envBound60311 : H12AffineFastState.Bounded env60311 := by
  intro p hp
  have h : env60311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60310_60311 : H12AffineEnvironment.transform 9 424 env60310 = env60311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env60310 == env60311) = true)

theorem identity60311 : scanCanonicalize (H12AffineFastState.compose env60311 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound60311 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60312 : List Nat := [2,4,8,16,32,64,128,256,1,424,324,508,41,428,276,170,429,80,425,276,232,32,64,186,160,17,373,429,509,80,173,17,256,32,429,1]

theorem envBound60312 : H12AffineFastState.Bounded env60312 := by
  intro p hp
  have h : env60312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60311_60312 : H12AffineEnvironment.transform 15 170 env60311 = env60312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env60311 == env60312) = true)

theorem identity60312 : scanCanonicalize (H12AffineFastState.compose env60312 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60312 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env60313 : List Nat := [2,4,8,16,16,64,128,256,1,408,324,460,25,412,276,154,413,80,409,276,216,16,64,138,144,17,325,413,461,80,157,17,256,16,413,1]

theorem envBound60313 : H12AffineFastState.Bounded env60313 := by
  intro p hp
  have h : env60313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60312_60313 : H12AffineEnvironment.transform 4 16 env60312 = env60313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60312 == env60313) = true)

def env60314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,8388608,8399766,8397001,8388689,2366325,4177,77954,67410,8463814,8465983,256,65675,78034,8389184]

theorem envBound60314 : H12AffineFastState.Bounded env60314 := by
  intro p hp
  have h : env60314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60221_60314 : H12AffineEnvironment.transform 21 1417 env60221 = env60314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env60221 == env60314) = true)

def env60315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9664,3670,1289,9617,2366325,4177,77954,67410,65542,68607,256,65675,78034,10112]

theorem envBound60315 : H12AffineFastState.Bounded env60315 := by
  intro p hp
  have h : env60315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60314_60315 : H12AffineEnvironment.transform 22 9664 env60314 = env60315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env60314 == env60315) = true)

def env60316 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3158,1289,9617,2365813,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound60316 : H12AffineFastState.Bounded env60316 := by
  intro p hp
  have h : env60316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60315_60316 : H12AffineEnvironment.transform 8 0 env60315 = env60316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60315 == env60316) = true)

theorem identity60316 : scanCanonicalize (H12AffineFastState.compose env60316 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 9561) := by decide +kernel

theorem selectedBound60316 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60317 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,9561,1417,9664,3158,1289,9617,277548,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound60317 : H12AffineFastState.Bounded env60317 := by
  intro p hp
  have h : env60317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60316_60317 : H12AffineEnvironment.transform 20 9561 env60316 = env60317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 9561 env60316 == env60317) = true)

def env60318 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,217,1417,64,3158,1289,17,268716,4177,70914,66898,65542,68095,256,65675,70994,0]

theorem envBound60318 : H12AffineFastState.Bounded env60318 := by
  intro p hp
  have h : env60318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60317_60318 : H12AffineEnvironment.transform 12 1408 env60317 = env60318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60317 == env60318) = true)

theorem identity60318 : scanCanonicalize (H12AffineFastState.compose env60318 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6179) := by decide +kernel

theorem selectedBound60318 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60319 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,6179,3441,262144,1025,2129,217,1417,64,3158,1289,17,268716,4177,3361,7537,6181,4572,256,6312,3441,0]

theorem envBound60319 : H12AffineFastState.Bounded env60319 := by
  intro p hp
  have h : env60319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60318_60319 : H12AffineEnvironment.transform 15 6179 env60318 = env60319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6179 env60318 == env60319) = true)

theorem identity60319 : scanCanonicalize (H12AffineFastState.compose env60319 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound60319 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60320 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,6179,3441,6376,1025,2129,217,1417,64,3158,1289,17,324,4177,3361,7537,6181,4572,256,6312,3441,0]

theorem envBound60320 : H12AffineFastState.Bounded env60320 := by
  intro p hp
  have h : env60320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60319_60320 : H12AffineEnvironment.transform 17 6376 env60319 = env60320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env60319 == env60320) = true)

theorem identity60320 : scanCanonicalize (H12AffineFastState.compose env60320 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound60320 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60321 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,460,1408,412,2129,2543,3441,2340,1025,2129,217,1417,64,3158,1289,17,324,413,3361,3261,2537,16,256,2404,3441,0]

theorem envBound60321 : H12AffineFastState.Bounded env60321 := by
  intro p hp
  have h : env60321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60320_60321 : H12AffineEnvironment.transform 11 460 env60320 = env60321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env60320 == env60321) = true)

theorem identity60321 : scanCanonicalize (H12AffineFastState.compose env60321 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound60321 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60322 : List Nat := [2,4,8,16,32,64,128,256,0,409,2048,460,25,412,2129,2543,2280,2340,408,2129,217,16,64,2511,144,17,324,413,2232,2340,2537,16,256,2404,2280,0]

theorem envBound60322 : H12AffineFastState.Bounded env60322 := by
  intro p hp
  have h : env60322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60321_60322 : H12AffineEnvironment.transform 9 409 env60321 = env60322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env60321 == env60322) = true)

theorem identity60322 : scanCanonicalize (H12AffineFastState.compose env60322 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60322 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60323 : List Nat := [2,4,8,16,32,64,128,256,0,409,325,460,25,412,276,170,429,97,408,276,217,16,64,138,144,17,324,413,509,97,172,16,256,33,429,0]

theorem envBound60323 : H12AffineFastState.Bounded env60323 := by
  intro p hp
  have h : env60323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60322_60323 : H12AffineEnvironment.transform 10 325 env60322 = env60323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60322 == env60323) = true)

theorem identity60323 : scanCanonicalize (H12AffineFastState.compose env60323 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60323 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60324 : List Nat := [2,4,8,16,32,64,128,94,0,199,27,146,25,194,74,170,243,97,198,74,217,16,64,138,144,17,26,195,163,97,172,16,94,33,243,0]

theorem envBound60324 : H12AffineFastState.Bounded env60324 := by
  intro p hp
  have h : env60324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60323_60324 : H12AffineEnvironment.transform 7 94 env60323 = env60324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60323 == env60324) = true)

theorem identity60324 : scanCanonicalize (H12AffineFastState.compose env60324 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60324 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60325 : List Nat := [2,4,8,16,16,64,128,94,0,199,27,146,25,194,74,154,195,81,198,74,217,16,64,138,144,17,26,195,147,81,156,16,94,17,195,0]

theorem envBound60325 : H12AffineFastState.Bounded env60325 := by
  intro p hp
  have h : env60325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60324_60325 : H12AffineEnvironment.transform 4 16 env60324 = env60325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60324 == env60325) = true)

def env60326 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,216,1417,65,3158,1289,16,268717,4177,70915,66898,65542,68095,256,65675,70995,1]

theorem envBound60326 : H12AffineFastState.Bounded env60326 := by
  intro p hp
  have h : env60326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60317_60326 : H12AffineEnvironment.transform 12 1409 env60317 = env60326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60317 == env60326) = true)

theorem identity60326 : scanCanonicalize (H12AffineFastState.compose env60326 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2340) := by decide +kernel

theorem selectedBound60326 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60327 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2340,1409,2420,2129,65536,68727,262144,1025,2129,216,1417,65,3158,1289,16,262281,2421,68647,66898,65542,68095,256,65675,68727,1]

theorem envBound60327 : H12AffineFastState.Bounded env60327 := by
  intro p hp
  have h : env60327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60326_60327 : H12AffineEnvironment.transform 11 2340 env60326 = env60327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2340 env60326 == env60327) = true)

theorem identity60327 : scanCanonicalize (H12AffineFastState.compose env60327 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60327 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60328 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1245,1409,1165,1448,65536,65934,262144,1025,1448,216,1417,65,431,1289,16,262281,1164,66014,66898,65542,66566,256,65675,65934,1]

theorem envBound60328 : H12AffineFastState.Bounded env60328 := by
  intro p hp
  have h : env60328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60327_60328 : H12AffineEnvironment.transform 10 1529 env60327 = env60328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60327 == env60328) = true)

theorem identity60328 : scanCanonicalize (H12AffineFastState.compose env60328 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65815) := by decide +kernel

theorem selectedBound60328 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60329 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1245,1409,1165,1448,65536,65934,65815,1025,1448,216,1417,65,431,1289,16,65950,1164,66014,66898,65542,66566,256,65675,65934,1]

theorem envBound60329 : H12AffineFastState.Bounded env60329 := by
  intro p hp
  have h : env60329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60328_60329 : H12AffineEnvironment.transform 17 65815 env60328 = env60329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65815 env60328 == env60329) = true)

theorem identity60329 : scanCanonicalize (H12AffineFastState.compose env60329 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60329 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60330 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1245,1409,1165,1448,1063,1449,1328,1025,1448,216,1417,65,431,1289,16,1465,1164,1529,373,1057,33,256,1196,1449,1]

theorem envBound60330 : H12AffineFastState.Bounded env60330 := by
  intro p hp
  have h : env60330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60329_60330 : H12AffineEnvironment.transform 15 1063 env60329 = env60330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60329 == env60330) = true)

theorem identity60330 : scanCanonicalize (H12AffineFastState.compose env60330 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60330 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60331 : List Nat := [2,4,8,16,32,64,128,256,0,220,293,1,349,81,372,251,373,492,221,372,216,341,65,431,469,16,357,80,293,373,253,33,256,112,373,1]

theorem envBound60331 : H12AffineFastState.Bounded env60331 := by
  intro p hp
  have h : env60331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60330_60331 : H12AffineEnvironment.transform 9 220 env60330 = env60331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60330 == env60331) = true)

theorem identity60331 : scanCanonicalize (H12AffineFastState.compose env60331 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60331 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60332 : List Nat := [2,4,8,16,32,17,128,256,0,141,293,1,268,0,293,170,292,445,140,293,137,260,16,431,388,16,308,1,293,292,172,33,256,33,292,1]

theorem envBound60332 : H12AffineFastState.Bounded env60332 := by
  intro p hp
  have h : env60332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60331_60332 : H12AffineEnvironment.transform 5 17 env60331 = env60332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60331 == env60332) = true)

theorem identity60332 : scanCanonicalize (H12AffineFastState.compose env60332 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound60332 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env60333 : List Nat := [2,4,8,16,32,17,128,141,0,141,168,1,129,0,168,170,169,48,140,168,137,137,16,34,9,16,185,1,168,169,172,33,141,33,169,1]

theorem envBound60333 : H12AffineFastState.Bounded env60333 := by
  intro p hp
  have h : env60333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60332_60333 : H12AffineEnvironment.transform 7 141 env60332 = env60333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env60332 == env60333) = true)

theorem identity60333 : scanCanonicalize (H12AffineFastState.compose env60333 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60333 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60334 : List Nat := [2,4,2,16,32,17,128,135,0,135,162,1,129,0,162,160,163,48,134,162,131,131,16,34,3,16,179,1,162,163,166,33,135,33,163,1]

theorem envBound60334 : H12AffineFastState.Bounded env60334 := by
  intro p hp
  have h : env60334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60333_60334 : H12AffineEnvironment.transform 2 2 env60333 = env60334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60333 == env60334) = true)

theorem identity60334 : scanCanonicalize (H12AffineFastState.compose env60334 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 17) := by decide +kernel

theorem selectedBound60334 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env60335 : List Nat := [2,4,2,16,32,17,17,22,0,22,51,1,16,0,51,49,50,48,23,51,18,18,16,34,3,16,34,1,51,50,55,33,22,33,50,1]

theorem envBound60335 : H12AffineFastState.Bounded env60335 := by
  intro p hp
  have h : env60335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60334_60335 : H12AffineEnvironment.transform 6 17 env60334 = env60335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 17 env60334 == env60335) = true)

theorem identity60335 : scanCanonicalize (H12AffineFastState.compose env60335 (packedSelected [1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound60335 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60336 : List Nat := [2,4,2,16,1,17,17,22,0,22,18,1,16,0,18,16,19,17,23,18,18,18,16,3,3,16,3,1,18,19,22,0,22,0,19,1]

theorem envBound60336 : H12AffineFastState.Bounded env60336 := by
  intro p hp
  have h : env60336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60335_60336 : H12AffineEnvironment.transform 4 1 env60335 = env60336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env60335 == env60336) = true)

theorem identity60336 : scanCanonicalize (H12AffineFastState.compose env60336 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60336 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60337 : List Nat := [1,4,1,16,1,17,17,21,0,21,17,1,16,0,17,16,16,17,20,17,17,17,16,0,0,16,0,1,17,16,21,0,21,0,16,1]

theorem envBound60337 : H12AffineFastState.Bounded env60337 := by
  intro p hp
  have h : env60337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60336_60337 : H12AffineEnvironment.transform 0 1 env60336 = env60337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60336 == env60337) = true)

theorem identity60337 : scanCanonicalize (H12AffineFastState.compose env60337 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60337 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60338 : List Nat := [1,4,1,0,1,1,1,5,0,5,1,1,0,0,1,0,0,1,4,1,1,1,0,0,0,0,0,1,1,0,5,0,5,0,0,1]

theorem envBound60338 : H12AffineFastState.Bounded env60338 := by
  intro p hp
  have h : env60338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60337_60338 : H12AffineEnvironment.transform 3 0 env60337 = env60338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60337 == env60338) = true)

def env60339 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3159,1289,9617,2365812,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound60339 : H12AffineFastState.Bounded env60339 := by
  intro p hp
  have h : env60339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60315_60339 : H12AffineEnvironment.transform 8 1 env60315 = env60339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60315 == env60339) = true)

theorem identity60339 : scanCanonicalize (H12AffineFastState.compose env60339 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 216) := by decide +kernel

theorem selectedBound60339 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60340 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,216,1417,9664,3159,1289,9617,268716,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound60340 : H12AffineFastState.Bounded env60340 := by
  intro p hp
  have h : env60340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60339_60340 : H12AffineEnvironment.transform 20 216 env60339 = env60340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 216 env60339 == env60340) = true)

def env60341 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,216,1417,64,3159,1289,17,268716,4177,70914,66899,65542,68094,256,65675,70994,1]

theorem envBound60341 : H12AffineFastState.Bounded env60341 := by
  intro p hp
  have h : env60341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60340_60341 : H12AffineEnvironment.transform 12 1408 env60340 = env60341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60340 == env60341) = true)

theorem identity60341 : scanCanonicalize (H12AffineFastState.compose env60341 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6179) := by decide +kernel

theorem selectedBound60341 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60342 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,6179,3441,262144,1025,2128,216,1417,64,3159,1289,17,268716,4177,3361,7536,6181,4573,256,6312,3441,1]

theorem envBound60342 : H12AffineFastState.Bounded env60342 := by
  intro p hp
  have h : env60342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60341_60342 : H12AffineEnvironment.transform 15 6179 env60341 = env60342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6179 env60341 == env60342) = true)

theorem identity60342 : scanCanonicalize (H12AffineFastState.compose env60342 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound60342 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60343 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,6179,3441,6377,1025,2128,216,1417,64,3159,1289,17,325,4177,3361,7536,6181,4573,256,6312,3441,1]

theorem envBound60343 : H12AffineFastState.Bounded env60343 := by
  intro p hp
  have h : env60343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60342_60343 : H12AffineEnvironment.transform 17 6377 env60342 = env60343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env60342 == env60343) = true)

theorem identity60343 : scanCanonicalize (H12AffineFastState.compose env60343 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound60343 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60344 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,461,1408,413,2128,2542,3441,2340,1025,2128,216,1417,64,3159,1289,17,325,412,3361,3261,2536,16,256,2405,3441,1]

theorem envBound60344 : H12AffineFastState.Bounded env60344 := by
  intro p hp
  have h : env60344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60343_60344 : H12AffineEnvironment.transform 11 461 env60343 = env60344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env60343 == env60344) = true)

theorem identity60344 : scanCanonicalize (H12AffineFastState.compose env60344 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound60344 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60345 : List Nat := [2,4,8,16,32,64,128,256,1,1024,324,461,1408,413,276,170,1077,96,1025,276,216,1417,64,1299,1289,17,325,412,1125,1529,172,16,256,33,1077,1]

theorem envBound60345 : H12AffineFastState.Bounded env60345 := by
  intro p hp
  have h : env60345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60344_60345 : H12AffineEnvironment.transform 10 324 env60344 = env60345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env60344 == env60345) = true)

theorem identity60345 : scanCanonicalize (H12AffineFastState.compose env60345 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound60345 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60346 : List Nat := [2,4,8,16,32,64,128,256,1,409,324,461,25,413,276,170,428,96,408,276,216,16,64,138,144,17,325,412,508,96,172,16,256,33,428,1]

theorem envBound60346 : H12AffineFastState.Bounded env60346 := by
  intro p hp
  have h : env60346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60345_60346 : H12AffineEnvironment.transform 9 409 env60345 = env60346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env60345 == env60346) = true)

theorem identity60346 : scanCanonicalize (H12AffineFastState.compose env60346 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound60346 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60347 : List Nat := [2,4,8,16,32,64,128,110,1,247,42,163,25,243,122,170,194,96,246,122,216,16,64,138,144,17,43,242,146,96,172,16,110,33,194,1]

theorem envBound60347 : H12AffineFastState.Bounded env60347 := by
  intro p hp
  have h : env60347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60346_60347 : H12AffineEnvironment.transform 7 110 env60346 = env60347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env60346 == env60347) = true)

theorem identity60347 : scanCanonicalize (H12AffineFastState.compose env60347 (packedSelected [0,1,6,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60347 : packedSelected [0,1,6,11] rootPS < 2^1333 := by decide +kernel

def env60348 : List Nat := [2,4,8,16,16,64,128,94,1,199,26,147,25,195,74,154,194,80,198,74,216,16,64,138,144,17,27,194,146,80,156,16,94,17,194,1]

theorem envBound60348 : H12AffineFastState.Bounded env60348 := by
  intro p hp
  have h : env60348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60347_60348 : H12AffineEnvironment.transform 4 16 env60347 = env60348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60347 == env60348) = true)

def env60349 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,216,1417,65,3159,1289,16,268716,4177,70915,66899,65542,68094,256,65675,70995,0]

theorem envBound60349 : H12AffineFastState.Bounded env60349 := by
  intro p hp
  have h : env60349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60340_60349 : H12AffineEnvironment.transform 12 1409 env60340 = env60349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60340 == env60349) = true)

theorem identity60349 : scanCanonicalize (H12AffineFastState.compose env60349 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2341) := by decide +kernel

theorem selectedBound60349 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60350 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2341,1409,2421,2128,65536,68726,262144,1025,2128,216,1417,65,3159,1289,16,262281,2420,68646,66899,65542,68094,256,65675,68726,0]

theorem envBound60350 : H12AffineFastState.Bounded env60350 := by
  intro p hp
  have h : env60350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60349_60350 : H12AffineEnvironment.transform 11 2341 env60349 = env60350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2341 env60349 == env60350) = true)

theorem identity60350 : scanCanonicalize (H12AffineFastState.compose env60350 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60350 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60351 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1245,1409,1165,1448,65536,65934,262144,1025,1448,216,1417,65,431,1289,16,262281,1164,66014,66899,65542,66566,256,65675,65934,0]

theorem envBound60351 : H12AffineFastState.Bounded env60351 := by
  intro p hp
  have h : env60351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60350_60351 : H12AffineEnvironment.transform 10 1528 env60350 = env60351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60350 == env60351) = true)

theorem identity60351 : scanCanonicalize (H12AffineFastState.compose env60351 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65815) := by decide +kernel

theorem selectedBound60351 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60352 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1245,1409,1165,1448,65536,65934,65815,1025,1448,216,1417,65,431,1289,16,65950,1164,66014,66899,65542,66566,256,65675,65934,0]

theorem envBound60352 : H12AffineFastState.Bounded env60352 := by
  intro p hp
  have h : env60352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60351_60352 : H12AffineEnvironment.transform 17 65815 env60351 = env60352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65815 env60351 == env60352) = true)

theorem identity60352 : scanCanonicalize (H12AffineFastState.compose env60352 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60352 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60353 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1245,1409,1165,1448,1063,1449,1328,1025,1448,216,1417,65,431,1289,16,1465,1164,1529,372,1057,33,256,1196,1449,0]

theorem envBound60353 : H12AffineFastState.Bounded env60353 := by
  intro p hp
  have h : env60353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60352_60353 : H12AffineEnvironment.transform 15 1063 env60352 = env60353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60352 == env60353) = true)

theorem identity60353 : scanCanonicalize (H12AffineFastState.compose env60353 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60353 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60354 : List Nat := [2,4,8,16,32,64,128,256,1,221,293,0,348,80,373,250,372,493,220,373,216,340,65,431,468,16,356,81,292,372,252,33,256,113,372,0]

theorem envBound60354 : H12AffineFastState.Bounded env60354 := by
  intro p hp
  have h : env60354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60353_60354 : H12AffineEnvironment.transform 9 221 env60353 = env60354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60353 == env60354) = true)

theorem identity60354 : scanCanonicalize (H12AffineFastState.compose env60354 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound60354 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60355 : List Nat := [2,4,8,16,32,64,128,172,1,221,137,0,240,80,217,250,216,65,220,217,216,248,65,3,120,16,200,81,136,216,252,33,172,113,216,0]

theorem envBound60355 : H12AffineFastState.Bounded env60355 := by
  intro p hp
  have h : env60355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60354_60355 : H12AffineEnvironment.transform 7 172 env60354 = env60355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60354 == env60355) = true)

theorem identity60355 : scanCanonicalize (H12AffineFastState.compose env60355 (packedSelected [1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 51) := by decide +kernel

theorem selectedBound60355 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env60356 : List Nat := [2,4,8,16,32,51,128,172,1,174,137,0,131,35,170,137,171,50,175,170,171,139,50,3,11,16,187,34,136,171,143,33,172,2,171,0]

theorem envBound60356 : H12AffineFastState.Bounded env60356 := by
  intro p hp
  have h : env60356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60355_60356 : H12AffineEnvironment.transform 5 51 env60355 = env60356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 51 env60355 == env60356) = true)

theorem identity60356 : scanCanonicalize (H12AffineFastState.compose env60356 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound60356 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env60357 : List Nat := [2,4,8,16,32,51,11,39,1,37,2,0,8,35,33,2,32,50,36,33,32,0,50,3,11,16,48,34,3,32,4,33,39,2,32,0]

theorem envBound60357 : H12AffineFastState.Bounded env60357 := by
  intro p hp
  have h : env60357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60356_60357 : H12AffineEnvironment.transform 6 11 env60356 = env60357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env60356 == env60357) = true)

theorem identity60357 : scanCanonicalize (H12AffineFastState.compose env60357 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60357 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60358 : List Nat := [2,4,1,16,32,51,2,39,1,37,2,0,1,35,33,2,32,50,36,33,32,0,50,3,2,16,48,34,3,32,4,33,39,2,32,0]

theorem envBound60358 : H12AffineFastState.Bounded env60358 := by
  intro p hp
  have h : env60358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60357_60358 : H12AffineEnvironment.transform 2 1 env60357 = env60358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60357 == env60358) = true)

theorem identity60358 : scanCanonicalize (H12AffineFastState.compose env60358 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60358 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60359 : List Nat := [2,4,1,16,0,19,2,7,1,5,2,0,1,3,1,2,0,18,4,1,0,0,18,3,2,16,16,2,3,0,4,1,7,2,0,0]

theorem envBound60359 : H12AffineFastState.Bounded env60359 := by
  intro p hp
  have h : env60359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60358_60359 : H12AffineEnvironment.transform 4 0 env60358 = env60359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60358 == env60359) = true)

theorem identity60359 : scanCanonicalize (H12AffineFastState.compose env60359 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60359 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env60360 : List Nat := [2,4,1,0,0,3,2,7,1,5,2,0,1,3,1,2,0,2,4,1,0,0,2,3,2,0,0,2,3,0,4,1,7,2,0,0]

theorem envBound60360 : H12AffineFastState.Bounded env60360 := by
  intro p hp
  have h : env60360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60359_60360 : H12AffineEnvironment.transform 3 0 env60359 = env60360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60359 == env60360) = true)

def env60361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9665,3671,1288,9616,2366325,4177,77954,67410,65543,68606,256,65675,78034,10113]

theorem envBound60361 : H12AffineFastState.Bounded env60361 := by
  intro p hp
  have h : env60361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60314_60361 : H12AffineEnvironment.transform 22 9665 env60314 = env60361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env60314 == env60361) = true)

def env60362 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3159,1288,9616,2365813,4177,77954,66898,65543,68094,256,65675,78034,9601]

theorem envBound60362 : H12AffineFastState.Bounded env60362 := by
  intro p hp
  have h : env60362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60361_60362 : H12AffineEnvironment.transform 8 0 env60361 = env60362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60361 == env60362) = true)

theorem identity60362 : scanCanonicalize (H12AffineFastState.compose env60362 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2184) := by decide +kernel

theorem selectedBound60362 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60363 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,8192,2264,2129,65536,75866,262144,1025,2129,2097152,1417,9665,3159,1288,9616,2359805,2265,75786,66898,65543,68094,256,65675,75866,9601]

theorem envBound60363 : H12AffineFastState.Bounded env60363 := by
  intro p hp
  have h : env60363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60362_60363 : H12AffineEnvironment.transform 11 2184 env60362 = env60363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env60362 == env60363) = true)

def env60364 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1408,2264,2129,65536,69082,262144,1025,2129,2097152,1417,65,3159,1288,16,2359805,2265,69002,66898,65543,68094,256,65675,69082,1]

theorem envBound60364 : H12AffineFastState.Bounded env60364 := by
  intro p hp
  have h : env60364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60363_60364 : H12AffineEnvironment.transform 12 1408 env60363 = env60364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60363 == env60364) = true)

theorem identity60364 : scanCanonicalize (H12AffineFastState.compose env60364 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 372) := by decide +kernel

theorem selectedBound60364 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60365 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1408,2264,2129,65536,69082,262144,1025,2129,372,1417,65,3159,1288,16,262281,2265,69002,66898,65543,68094,256,65675,69082,1]

theorem envBound60365 : H12AffineFastState.Bounded env60365 := by
  intro p hp
  have h : env60365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60364_60365 : H12AffineEnvironment.transform 20 372 env60364 = env60365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 372 env60364 == env60365) = true)

theorem identity60365 : scanCanonicalize (H12AffineFastState.compose env60365 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60365 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60366 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1393,1408,1313,1448,65536,65571,262144,1025,1448,372,1417,65,430,1288,16,262281,1312,65651,66898,65543,66567,256,65675,65571,1]

theorem envBound60366 : H12AffineFastState.Bounded env60366 := by
  intro p hp
  have h : env60366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60365_60366 : H12AffineEnvironment.transform 10 1529 env60365 = env60366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60365 == env60366) = true)

theorem identity60366 : scanCanonicalize (H12AffineFastState.compose env60366 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65723) := by decide +kernel

theorem selectedBound60366 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60367 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1393,1408,1313,1448,65536,65571,65723,1025,1448,372,1417,65,430,1288,16,65586,1312,65651,66898,65543,66567,256,65675,65571,1]

theorem envBound60367 : H12AffineFastState.Bounded env60367 := by
  intro p hp
  have h : env60367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60366_60367 : H12AffineEnvironment.transform 17 65723 env60366 = env60367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65723 env60366 == env60367) = true)

theorem identity60367 : scanCanonicalize (H12AffineFastState.compose env60367 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60367 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60368 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,1393,1408,1313,1448,1063,1028,1180,1025,1448,372,1417,65,430,1288,16,1045,1312,1108,373,1056,32,256,1196,1028,1]

theorem envBound60368 : H12AffineFastState.Bounded env60368 := by
  intro p hp
  have h : env60368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60367_60368 : H12AffineEnvironment.transform 15 1063 env60367 = env60368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60367 == env60368) = true)

theorem identity60368 : scanCanonicalize (H12AffineFastState.compose env60368 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60368 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60369 : List Nat := [2,4,8,16,32,64,128,256,0,220,293,429,348,509,372,251,216,64,221,372,372,341,65,430,468,16,201,508,136,373,252,32,256,112,216,1]

theorem envBound60369 : H12AffineFastState.Bounded env60369 := by
  intro p hp
  have h : env60369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60368_60369 : H12AffineEnvironment.transform 9 220 env60368 = env60369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60368 == env60369) = true)

theorem identity60369 : scanCanonicalize (H12AffineFastState.compose env60369 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound60369 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env60370 : List Nat := [2,4,8,16,17,64,128,256,0,220,276,412,348,460,325,202,216,64,221,325,325,341,65,415,468,16,201,461,136,324,205,17,256,65,216,1]

theorem envBound60370 : H12AffineFastState.Bounded env60370 := by
  intro p hp
  have h : env60370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60369_60370 : H12AffineEnvironment.transform 4 17 env60369 = env60370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env60369 == env60370) = true)

theorem identity60370 : scanCanonicalize (H12AffineFastState.compose env60370 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound60370 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60371 : List Nat := [2,4,8,2,3,64,128,256,0,206,262,398,334,460,325,202,202,64,207,325,325,327,65,397,454,2,201,461,136,324,205,3,256,65,202,1]

theorem envBound60371 : H12AffineFastState.Bounded env60371 := by
  intro p hp
  have h : env60371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60370_60371 : H12AffineEnvironment.transform 3 2 env60370 = env60371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env60370 == env60371) = true)

theorem identity60371 : scanCanonicalize (H12AffineFastState.compose env60371 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound60371 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60372 : List Nat := [2,4,8,2,3,64,66,256,0,12,262,332,334,270,325,8,8,64,13,325,325,327,65,335,260,2,11,271,74,324,15,3,256,65,8,1]

theorem envBound60372 : H12AffineFastState.Bounded env60372 := by
  intro p hp
  have h : env60372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60371_60372 : H12AffineEnvironment.transform 6 66 env60371 = env60372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env60371 == env60372) = true)

theorem identity60372 : scanCanonicalize (H12AffineFastState.compose env60372 (packedSelected [3,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 77) := by decide +kernel

theorem selectedBound60372 : packedSelected [3,6,8] rootPS < 2^1333 := by decide +kernel

def env60373 : List Nat := [2,4,8,2,3,64,66,77,0,12,75,1,3,67,8,8,8,64,13,8,8,10,65,2,73,2,11,66,74,9,15,3,77,65,8,1]

theorem envBound60373 : H12AffineFastState.Bounded env60373 := by
  intro p hp
  have h : env60373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60372_60373 : H12AffineEnvironment.transform 7 77 env60372 = env60373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 77 env60372 == env60373) = true)

theorem identity60373 : scanCanonicalize (H12AffineFastState.compose env60373 (packedSelected [1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound60373 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env60374 : List Nat := [2,4,8,2,3,3,1,14,0,12,8,1,3,0,8,8,8,3,13,8,8,10,2,2,10,2,11,1,9,9,15,3,14,2,8,1]

theorem envBound60374 : H12AffineFastState.Bounded env60374 := by
  intro p hp
  have h : env60374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60373_60374 : H12AffineEnvironment.transform 5 3 env60373 = env60374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env60373 == env60374) = true)

theorem identity60374 : scanCanonicalize (H12AffineFastState.compose env60374 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60374 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60375 : List Nat := [1,4,8,1,0,0,1,13,0,12,8,1,0,0,8,8,8,0,13,8,8,9,1,1,9,1,8,1,9,9,12,0,13,1,8,1]

theorem envBound60375 : H12AffineFastState.Bounded env60375 := by
  intro p hp
  have h : env60375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60374_60375 : H12AffineEnvironment.transform 0 1 env60374 = env60375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60374 == env60375) = true)

theorem identity60375 : scanCanonicalize (H12AffineFastState.compose env60375 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60375 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60376 : List Nat := [1,4,0,1,0,0,1,5,0,4,0,1,0,0,0,0,0,0,5,0,0,1,1,1,1,1,0,1,1,1,4,0,5,1,0,1]

theorem envBound60376 : H12AffineFastState.Bounded env60376 := by
  intro p hp
  have h : env60376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60375_60376 : H12AffineEnvironment.transform 2 0 env60375 = env60376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60375 == env60376) = true)

def env60377 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1409,2264,2129,65536,69083,262144,1025,2129,2097152,1417,64,3159,1288,17,2359805,2265,69003,66898,65543,68094,256,65675,69083,0]

theorem envBound60377 : H12AffineFastState.Bounded env60377 := by
  intro p hp
  have h : env60377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60363_60377 : H12AffineEnvironment.transform 12 1409 env60363 = env60377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60363 == env60377) = true)

theorem identity60377 : scanCanonicalize (H12AffineFastState.compose env60377 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 65651) := by decide +kernel

theorem selectedBound60377 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60378 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1409,2264,2129,65536,69083,262144,1025,2129,65651,1417,64,3159,1288,17,328078,2265,69003,66898,65543,68094,256,65675,69083,0]

theorem envBound60378 : H12AffineFastState.Bounded env60378 := by
  intro p hp
  have h : env60378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60377_60378 : H12AffineEnvironment.transform 20 65651 env60377 = env60378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65651 env60377 == env60378) = true)

theorem identity60378 : scanCanonicalize (H12AffineFastState.compose env60378 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 96) := by decide +kernel

theorem selectedBound60378 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60379 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1409,2264,2129,65536,69083,96,1025,2129,65651,1417,64,3159,1288,17,66030,2265,69003,66898,65543,68094,256,65675,69083,0]

theorem envBound60379 : H12AffineFastState.Bounded env60379 := by
  intro p hp
  have h : env60379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60378_60379 : H12AffineEnvironment.transform 17 96 env60378 = env60379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96 env60378 == env60379) = true)

theorem identity60379 : scanCanonicalize (H12AffineFastState.compose env60379 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound60379 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60380 : List Nat := [2,4,8,16,32,64,128,256,0,409,2048,2184,24,2264,2129,65536,67650,96,408,2129,65651,16,64,2510,145,17,66030,2265,67602,65739,65543,68094,256,65675,67650,0]

theorem envBound60380 : H12AffineFastState.Bounded env60380 := by
  intro p hp
  have h : env60380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60379_60380 : H12AffineEnvironment.transform 9 409 env60379 = env60380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env60379 == env60380) = true)

theorem identity60380 : scanCanonicalize (H12AffineFastState.compose env60380 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound60380 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60381 : List Nat := [2,4,8,16,32,64,128,256,0,409,372,508,24,428,293,65536,65846,96,408,293,65651,16,64,186,145,17,66030,429,65894,65739,65543,65674,256,65675,65846,0]

theorem envBound60381 : H12AffineFastState.Bounded env60381 := by
  intro p hp
  have h : env60381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60380_60381 : H12AffineEnvironment.transform 10 372 env60380 = env60381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env60380 == env60381) = true)

theorem identity60381 : scanCanonicalize (H12AffineFastState.compose env60381 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound60381 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60382 : List Nat := [2,4,8,16,32,64,128,256,0,409,372,508,24,428,293,171,413,96,408,293,216,16,64,186,145,17,325,429,461,96,172,33,256,32,413,0]

theorem envBound60382 : H12AffineFastState.Bounded env60382 := by
  intro p hp
  have h : env60382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60381_60382 : H12AffineEnvironment.transform 15 171 env60381 = env60382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env60381 == env60382) = true)

theorem identity60382 : scanCanonicalize (H12AffineFastState.compose env60382 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound60382 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60383 : List Nat := [2,4,8,16,32,64,128,110,0,247,26,146,24,194,75,171,243,96,246,75,216,16,64,186,145,17,43,195,163,96,172,33,110,32,243,0]

theorem envBound60383 : H12AffineFastState.Bounded env60383 := by
  intro p hp
  have h : env60383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60382_60383 : H12AffineEnvironment.transform 7 110 env60382 = env60383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env60382 == env60383) = true)

theorem identity60383 : scanCanonicalize (H12AffineFastState.compose env60383 (packedSelected [4,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound60383 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env60384 : List Nat := [2,4,8,16,17,64,128,95,0,198,26,146,24,194,75,154,194,81,199,75,216,16,64,139,145,17,26,195,146,81,157,16,95,17,194,0]

theorem envBound60384 : H12AffineFastState.Bounded env60384 := by
  intro p hp
  have h : env60384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1