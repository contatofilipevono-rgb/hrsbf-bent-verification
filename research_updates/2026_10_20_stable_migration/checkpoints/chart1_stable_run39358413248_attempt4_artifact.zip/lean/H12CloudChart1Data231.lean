import H12CloudChart1Data230

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound58582 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58583 : List Nat := [2,4,8,16,32,64,89,256,512,84,863,554,349,634,293,115,782,262144,84,293,863,32,262688,262983,269,262769,560,634,863,634,262724,113,257,263012,783,512]

theorem envBound58583 : H12AffineFastState.Bounded env58583 := by
  intro p hp
  have h : env58583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58582_58583 : H12AffineEnvironment.transform 11 554 env58582 = env58583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env58582 == env58583) = true)

theorem identity58583 : scanCanonicalize (H12AffineFastState.compose env58583 (packedSelected [0,4,5,10,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound58583 : packedSelected [0,4,5,10,11,13] rootPS < 2^1333 := by decide +kernel

def env58584 : List Nat := [2,4,8,16,32,64,89,256,270,84,81,292,349,372,293,115,0,262144,84,293,81,32,262446,262217,269,262527,318,372,81,372,262474,113,257,262250,1,270]

theorem envBound58584 : H12AffineFastState.Bounded env58584 := by
  intro p hp
  have h : env58584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58583_58584 : H12AffineEnvironment.transform 8 270 env58583 = env58584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env58583 == env58584) = true)

theorem identity58584 : scanCanonicalize (H12AffineFastState.compose env58584 (packedSelected [0,4,5,7,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 26) := by decide +kernel

theorem selectedBound58584 : packedSelected [0,4,5,7,9,18] rootPS < 2^1333 := by decide +kernel

def env58585 : List Nat := [2,4,8,16,32,64,89,256,270,84,81,292,349,372,293,115,0,26,84,293,81,32,308,83,269,357,318,372,81,372,336,113,257,112,1,270]

theorem envBound58585 : H12AffineFastState.Bounded env58585 := by
  intro p hp
  have h : env58585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58584_58585 : H12AffineEnvironment.transform 17 26 env58584 = env58585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26 env58584 == env58585) = true)

theorem identity58585 : scanCanonicalize (H12AffineFastState.compose env58585 (packedSelected [1,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58585 : packedSelected [1,4,9] rootPS < 2^1333 := by decide +kernel

def env58586 : List Nat := [2,4,8,10,32,64,67,256,270,78,75,292,327,366,293,105,0,0,78,293,75,32,302,73,269,357,292,366,75,366,330,107,257,106,1,270]

theorem envBound58586 : H12AffineFastState.Bounded env58586 := by
  intro p hp
  have h : env58586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58585_58586 : H12AffineEnvironment.transform 3 10 env58585 = env58586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58585 == env58586) = true)

def env58587 : List Nat := [2,4,8,10,32,64,67,36,42,78,75,0,99,74,1,105,0,0,78,1,75,32,10,73,41,65,0,74,75,74,110,107,37,106,1,42]

theorem envBound58587 : H12AffineFastState.Bounded env58587 := by
  intro p hp
  have h : env58587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58586_58587 : H12AffineEnvironment.transform 7 36 env58586 = env58587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58586 == env58587) = true)

theorem identity58587 : scanCanonicalize (H12AffineFastState.compose env58587 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58587 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58588 : List Nat := [2,4,8,10,11,64,67,15,1,78,75,0,72,74,1,66,0,0,78,1,75,11,10,73,2,65,0,74,75,74,69,64,14,65,1,1]

theorem envBound58588 : H12AffineFastState.Bounded env58588 := by
  intro p hp
  have h : env58588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58587_58588 : H12AffineEnvironment.transform 4 11 env58587 = env58588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58587 == env58588) = true)

def env58589 : List Nat := [2,4,8,10,32,64,67,37,43,78,75,1,98,75,0,105,0,0,78,0,75,32,11,73,40,64,1,75,75,75,111,107,36,106,1,43]

theorem envBound58589 : H12AffineFastState.Bounded env58589 := by
  intro p hp
  have h : env58589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58586_58589 : H12AffineEnvironment.transform 7 37 env58586 = env58589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58586 == env58589) = true)

def env58590 : List Nat := [2,4,8,16,32,64,128,256,512,85,862,4096,348,4176,509,114,4605,262144,85,509,4524,32,266250,266605,469,266331,4291,4176,4524,635,266422,168,257,266574,4604,512]

theorem envBound58590 : H12AffineFastState.Bounded env58590 := by
  intro p hp
  have h : env58590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58572_58590 : H12AffineEnvironment.transform 9 85 env58572 = env58590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env58572 == env58590) = true)

def env58591 : List Nat := [2,4,8,16,32,64,88,256,512,85,862,4096,348,4176,293,114,4389,262144,85,293,4468,32,266250,266605,269,266331,4123,4176,4468,635,266350,112,257,266574,4388,512]

theorem envBound58591 : H12AffineFastState.Bounded env58591 := by
  intro p hp
  have h : env58591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58590_58591 : H12AffineEnvironment.transform 6 88 env58590 = env58591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58590 == env58591) = true)

theorem identity58591 : scanCanonicalize (H12AffineFastState.compose env58591 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 608) := by decide +kernel

theorem selectedBound58591 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58592 : List Nat := [2,4,8,16,32,64,88,256,512,85,862,4096,348,4176,293,114,4389,608,85,293,4468,32,4714,4877,269,4667,4123,4176,4468,635,4622,112,257,4910,4388,512]

theorem envBound58592 : H12AffineFastState.Bounded env58592 := by
  intro p hp
  have h : env58592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58591_58592 : H12AffineEnvironment.transform 17 608 env58591 = env58592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 608 env58591 == env58592) = true)

theorem identity58592 : scanCanonicalize (H12AffineFastState.compose env58592 (packedSelected [3,7,9,12,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 587) := by decide +kernel

theorem selectedBound58592 : packedSelected [3,7,9,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58593 : List Nat := [2,4,8,16,32,64,88,256,512,85,862,587,348,539,293,114,878,608,85,293,831,32,33,326,269,112,592,539,831,635,69,112,257,357,879,512]

theorem envBound58593 : H12AffineFastState.Bounded env58593 := by
  intro p hp
  have h : env58593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58592_58593 : H12AffineEnvironment.transform 11 587 env58592 = env58593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 587 env58592 == env58593) = true)

theorem identity58593 : scanCanonicalize (H12AffineFastState.compose env58593 (packedSelected [0,1,4] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound58593 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58594 : List Nat := [2,4,8,16,32,64,88,62,512,85,608,587,98,539,27,114,592,608,85,27,513,32,33,120,51,112,592,539,513,635,69,112,63,91,593,512]

theorem envBound58594 : H12AffineFastState.Bounded env58594 := by
  intro p hp
  have h : env58594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58593_58594 : H12AffineEnvironment.transform 7 62 env58593 = env58594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env58593 == env58594) = true)

theorem identity58594 : scanCanonicalize (H12AffineFastState.compose env58594 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58594 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58595 : List Nat := [2,4,8,16,32,10,18,62,512,31,554,513,40,539,27,56,538,554,31,27,513,32,33,50,51,58,538,539,513,561,15,58,63,17,539,512]

theorem envBound58595 : H12AffineFastState.Bounded env58595 := by
  intro p hp
  have h : env58595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58594_58595 : H12AffineEnvironment.transform 5 10 env58594 = env58595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58594 == env58595) = true)

theorem identity58595 : scanCanonicalize (H12AffineFastState.compose env58595 (packedSelected [1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58595 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env58596 : List Nat := [2,4,8,10,32,10,8,36,512,5,554,513,40,513,1,34,512,554,5,1,513,32,33,40,41,32,512,513,513,555,15,32,37,11,513,512]

theorem envBound58596 : H12AffineFastState.Bounded env58596 := by
  intro p hp
  have h : env58596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58595_58596 : H12AffineEnvironment.transform 3 10 env58595 = env58596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58595 == env58596) = true)

theorem identity58596 : scanCanonicalize (H12AffineFastState.compose env58596 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58596 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58597 : List Nat := [2,4,8,10,11,10,8,15,512,5,513,513,3,513,1,9,512,513,5,1,513,11,10,3,2,11,512,513,513,512,15,11,14,11,513,512]

theorem envBound58597 : H12AffineFastState.Bounded env58597 := by
  intro p hp
  have h : env58597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58596_58597 : H12AffineEnvironment.transform 4 11 env58596 = env58597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58596 == env58597) = true)

theorem identity58597 : scanCanonicalize (H12AffineFastState.compose env58597 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58597 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58598 : List Nat := [2,4,8,10,11,10,8,15,1,5,0,0,3,0,1,9,1,0,5,1,0,11,10,3,2,11,1,0,0,1,15,11,14,11,0,1]

theorem envBound58598 : H12AffineFastState.Bounded env58598 := by
  intro p hp
  have h : env58598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58597_58598 : H12AffineEnvironment.transform 8 1 env58597 = env58598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58597 == env58598) = true)

def env58599 : List Nat := [2,4,8,16,32,64,89,256,512,85,862,4096,348,4176,292,114,4388,262144,85,292,4469,32,266250,266605,268,266331,4122,4176,4469,635,266351,113,257,266574,4389,512]

theorem envBound58599 : H12AffineFastState.Bounded env58599 := by
  intro p hp
  have h : env58599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58590_58599 : H12AffineEnvironment.transform 6 89 env58590 = env58599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58590 == env58599) = true)

theorem identity58599 : scanCanonicalize (H12AffineFastState.compose env58599 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 789) := by decide +kernel

theorem selectedBound58599 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58600 : List Nat := [2,4,8,16,32,64,89,256,512,85,862,4096,348,4176,292,114,4388,789,85,292,4469,32,4895,4728,268,4942,4122,4176,4469,635,4986,113,257,4699,4389,512]

theorem envBound58600 : H12AffineFastState.Bounded env58600 := by
  intro p hp
  have h : env58600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58599_58600 : H12AffineEnvironment.transform 17 789 env58599 = env58600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 789 env58599 == env58600) = true)

theorem identity58600 : scanCanonicalize (H12AffineFastState.compose env58600 (packedSelected [5,7,9,10,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound58600 : packedSelected [5,7,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env58601 : List Nat := [2,4,8,16,32,64,89,256,271,85,81,4096,348,4176,292,114,4388,26,85,292,4469,32,4112,4471,268,4161,4122,4176,4469,372,4213,113,257,4436,4389,271]

theorem envBound58601 : H12AffineFastState.Bounded env58601 := by
  intro p hp
  have h : env58601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58600_58601 : H12AffineEnvironment.transform 8 271 env58600 = env58601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env58600 == env58601) = true)

theorem identity58601 : scanCanonicalize (H12AffineFastState.compose env58601 (packedSelected [0,4,5,7,9,18] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58601 : packedSelected [0,4,5,7,9,18] rootPS < 2^1333 := by decide +kernel

def env58602 : List Nat := [2,4,8,10,32,64,67,256,271,79,75,4096,326,4170,292,104,4388,0,79,292,4463,32,4106,4461,268,4161,4096,4170,4463,366,4207,107,257,4430,4389,271]

theorem envBound58602 : H12AffineFastState.Bounded env58602 := by
  intro p hp
  have h : env58602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58601_58602 : H12AffineEnvironment.transform 3 10 env58601 = env58602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58601 == env58602) = true)

theorem identity58602 : scanCanonicalize (H12AffineFastState.compose env58602 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound58602 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58603 : List Nat := [2,4,8,10,32,64,67,256,271,79,75,292,326,366,292,104,0,0,79,292,75,32,302,73,268,357,292,366,75,366,331,107,257,106,1,271]

theorem envBound58603 : H12AffineFastState.Bounded env58603 := by
  intro p hp
  have h : env58603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58602_58603 : H12AffineEnvironment.transform 11 292 env58602 = env58603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env58602 == env58603) = true)

def env58604 : List Nat := [2,4,8,10,32,64,67,36,43,79,75,0,98,74,0,104,0,0,79,0,75,32,10,73,40,65,0,74,75,74,111,107,37,106,1,43]

theorem envBound58604 : H12AffineFastState.Bounded env58604 := by
  intro p hp
  have h : env58604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58603_58604 : H12AffineEnvironment.transform 7 36 env58603 = env58604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58603 == env58604) = true)

theorem identity58604 : scanCanonicalize (H12AffineFastState.compose env58604 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58604 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58605 : List Nat := [2,4,8,10,11,64,67,15,0,79,75,0,73,74,0,67,0,0,79,0,75,11,10,73,3,65,0,74,75,74,68,64,14,65,1,0]

theorem envBound58605 : H12AffineFastState.Bounded env58605 := by
  intro p hp
  have h : env58605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58604_58605 : H12AffineEnvironment.transform 4 11 env58604 = env58605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58604 == env58605) = true)

def env58606 : List Nat := [2,4,8,10,32,64,67,37,42,79,75,1,99,75,1,104,0,0,79,1,75,32,11,73,41,64,1,75,75,75,110,107,36,106,1,42]

theorem envBound58606 : H12AffineFastState.Bounded env58606 := by
  intro p hp
  have h : env58606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58603_58606 : H12AffineEnvironment.transform 7 37 env58603 = env58606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58603 == env58606) = true)

def env58607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430022,4227081,8388689,10785997,4176,77954,4294794,8463815,2101508,257,14725225,78034,4235904]

theorem envBound58607 : H12AffineFastState.Bounded env58607 := by
  intro p hp
  have h : env58607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58526_58607 : H12AffineEnvironment.transform 24 4227081 env58526 = env58607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227081 env58526 == env58607) = true)

theorem identity58607 : scanCanonicalize (H12AffineFastState.compose env58607 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 2209034) := by decide +kernel

theorem selectedBound58607 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,2209034,8388608,8430022,2176259,8388689,10785997,4176,77954,2112896,8463815,2101508,257,8455523,78034,2168714]

theorem envBound58608 : H12AffineFastState.Bounded env58608 := by
  intro p hp
  have h : env58608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58607_58608 : H12AffineEnvironment.transform 21 2209034 env58607 = env58608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2209034 env58607 == env58608) = true)

theorem identity58608 : scanCanonicalize (H12AffineFastState.compose env58608 (packedSelected [15,17,19,21,26,38] rootPS)) = affineNative (2^(20+1) ^^^ 71050) := by decide +kernel

theorem selectedBound58608 : packedSelected [15,17,19,21,26,38] rootPS < 2^1333 := by decide +kernel

def env58609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,71050,41088,8388608,8430022,8329,8388689,8749383,4176,77954,75786,8463815,66702,257,8455523,78034,512]

theorem envBound58609 : H12AffineFastState.Bounded env58609 := by
  intro p hp
  have h : env58609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58608_58609 : H12AffineEnvironment.transform 20 71050 env58608 = env58609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 71050 env58608 == env58609) = true)

theorem identity58609 : scanCanonicalize (H12AffineFastState.compose env58609 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound58609 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33167,45404,262144,1024,32768,37893,41088,8388608,8430022,8329,8388689,8650952,4176,45325,43397,8430664,34049,257,8422636,45405,512]

theorem envBound58610 : H12AffineFastState.Bounded env58610 := by
  intro p hp
  have h : env58610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58609_58610 : H12AffineEnvironment.transform 15 33167 env58609 = env58610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env58609 == env58610) = true)

theorem identity58610 : scanCanonicalize (H12AffineFastState.compose env58610 (packedSelected [5,8] rootPS)) = affineNative (2^(22+1) ^^^ 311201) := by decide +kernel

theorem selectedBound58610 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,33167,45404,262144,1024,32768,37893,41088,311201,269927,8329,311280,49001,4176,45325,43397,269289,34049,257,277325,45405,512]

theorem envBound58611 : H12AffineFastState.Bounded env58611 := by
  intro p hp
  have h : env58611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58610_58611 : H12AffineEnvironment.transform 22 311201 env58610 = env58611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 311201 env58610 == env58611) = true)

theorem identity58611 : scanCanonicalize (H12AffineFastState.compose env58611 (packedSelected [1,2,3,5,6,10,11,12,15,17,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound58611 : packedSelected [1,2,3,5,6,10,11,12,15,17,18,24] rootPS < 2^1333 := by decide +kernel

def env58612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8352,8495,4604,262144,1024,8352,13477,32,270081,269927,8329,270160,8137,4176,4525,2341,269289,9633,257,277325,4605,512]

theorem envBound58612 : H12AffineFastState.Bounded env58612 := by
  intro p hp
  have h : env58612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58611_58612 : H12AffineEnvironment.transform 14 8352 env58611 = env58612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env58611 == env58612) = true)

def env58613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4176,1448,1063,4604,262144,1024,1448,4525,32,270081,269927,1409,270160,8137,4176,4525,2341,269289,169,257,269893,4605,512]

theorem envBound58613 : H12AffineFastState.Bounded env58613 := by
  intro p hp
  have h : env58613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58612_58613 : H12AffineEnvironment.transform 12 1288 env58612 = env58613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env58612 == env58613) = true)

theorem identity58613 : scanCanonicalize (H12AffineFastState.compose env58613 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4171) := by decide +kernel

theorem selectedBound58613 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1288,4176,1448,1063,4604,4171,1024,1448,4525,32,3914,3628,1409,3867,8137,4176,4525,2341,2978,169,257,3598,4605,512]

theorem envBound58614 : H12AffineFastState.Bounded env58614 := by
  intro p hp
  have h : env58614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58613_58614 : H12AffineEnvironment.transform 17 4171 env58613 = env58614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4171 env58613 == env58614) = true)

def env58615 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,4096,348,4176,508,115,4604,4171,84,508,4525,32,2846,2680,469,2895,7069,4176,4525,2341,2978,169,257,2650,4605,512]

theorem envBound58615 : H12AffineFastState.Bounded env58615 := by
  intro p hp
  have h : env58615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58614_58615 : H12AffineEnvironment.transform 9 84 env58614 = env58615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env58614 == env58615) = true)

def env58616 : List Nat := [2,4,8,16,32,64,88,256,512,84,2048,4096,348,4176,292,115,4388,4171,84,292,4469,32,2846,2680,269,2895,6981,4176,4469,2341,2938,113,257,2650,4389,512]

theorem envBound58616 : H12AffineFastState.Bounded env58616 := by
  intro p hp
  have h : env58616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58615_58616 : H12AffineEnvironment.transform 6 88 env58615 = env58616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58615 == env58616) = true)

theorem identity58616 : scanCanonicalize (H12AffineFastState.compose env58616 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 862) := by decide +kernel

theorem selectedBound58616 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58617 : List Nat := [2,4,8,16,32,64,88,256,512,84,2048,862,348,782,292,115,634,789,84,292,555,32,2846,2680,269,2895,2075,782,555,2341,2938,113,257,2650,635,512]

theorem envBound58617 : H12AffineFastState.Bounded env58617 := by
  intro p hp
  have h : env58617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58616_58617 : H12AffineEnvironment.transform 11 862 env58616 = env58617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 862 env58616 == env58617) = true)

theorem identity58617 : scanCanonicalize (H12AffineFastState.compose env58617 (packedSelected [3,7,9,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound58617 : packedSelected [3,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env58618 : List Nat := [2,4,8,16,32,64,88,256,512,84,538,862,348,782,292,115,634,789,84,292,555,32,260,98,269,341,513,782,555,831,352,113,257,64,635,512]

theorem envBound58618 : H12AffineFastState.Bounded env58618 := by
  intro p hp
  have h : env58618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58617_58618 : H12AffineEnvironment.transform 10 538 env58617 = env58618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env58617 == env58618) = true)

theorem identity58618 : scanCanonicalize (H12AffineFastState.compose env58618 (packedSelected [1,3,5,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound58618 : packedSelected [1,3,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env58619 : List Nat := [2,4,8,16,32,64,88,62,512,84,538,608,98,560,26,115,634,555,84,26,555,32,58,98,51,107,513,560,555,513,94,113,63,64,635,512]

theorem envBound58619 : H12AffineFastState.Bounded env58619 := by
  intro p hp
  have h : env58619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58618_58619 : H12AffineEnvironment.transform 7 62 env58618 = env58619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env58618 == env58619) = true)

theorem identity58619 : scanCanonicalize (H12AffineFastState.compose env58619 (packedSelected [0,3,9] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound58619 : packedSelected [0,3,9] rootPS < 2^1333 := by decide +kernel

def env58620 : List Nat := [2,4,8,16,32,33,57,62,512,53,538,513,3,560,26,18,539,555,53,26,555,32,58,3,51,10,513,560,555,513,63,16,63,33,538,512]

theorem envBound58620 : H12AffineFastState.Bounded env58620 := by
  intro p hp
  have h : env58620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58619_58620 : H12AffineEnvironment.transform 5 33 env58619 = env58620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58619 == env58620) = true)

theorem identity58620 : scanCanonicalize (H12AffineFastState.compose env58620 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound58620 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58621 : List Nat := [2,4,8,16,32,33,57,62,43,53,49,42,3,27,26,18,48,0,53,26,0,32,58,3,51,10,42,27,0,42,63,16,63,33,49,43]

theorem envBound58621 : H12AffineFastState.Bounded env58621 := by
  intro p hp
  have h : env58621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58620_58621 : H12AffineEnvironment.transform 8 43 env58620 = env58621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env58620 == env58621) = true)

theorem identity58621 : scanCanonicalize (H12AffineFastState.compose env58621 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58621 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58622 : List Nat := [2,4,8,11,32,33,34,37,43,46,42,42,3,0,1,9,43,0,46,1,0,32,33,3,40,10,42,0,0,42,36,11,36,33,42,43]

theorem envBound58622 : H12AffineFastState.Bounded env58622 := by
  intro p hp
  have h : env58622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58621_58622 : H12AffineEnvironment.transform 3 11 env58621 = env58622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58621 == env58622) = true)

def env58623 : List Nat := [2,4,8,16,32,64,89,256,512,84,2048,4096,348,4176,293,115,4389,4171,84,293,4468,32,2846,2680,268,2895,6980,4176,4468,2341,2939,112,257,2650,4388,512]

theorem envBound58623 : H12AffineFastState.Bounded env58623 := by
  intro p hp
  have h : env58623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58615_58623 : H12AffineEnvironment.transform 6 89 env58615 = env58623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58615 == env58623) = true)

theorem identity58623 : scanCanonicalize (H12AffineFastState.compose env58623 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound58623 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58624 : List Nat := [2,4,8,16,32,64,89,256,512,84,2048,555,348,635,293,115,782,608,84,293,863,32,2846,2680,268,2895,2415,635,863,2341,2939,112,257,2650,783,512]

theorem envBound58624 : H12AffineFastState.Bounded env58624 := by
  intro p hp
  have h : env58624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58623_58624 : H12AffineEnvironment.transform 11 555 env58623 = env58624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env58623 == env58624) = true)

theorem identity58624 : scanCanonicalize (H12AffineFastState.compose env58624 (packedSelected [5,7,9,10,12,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound58624 : packedSelected [5,7,9,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58625 : List Nat := [2,4,8,16,32,64,89,256,512,84,1,555,348,635,293,115,782,608,84,293,863,32,799,633,268,846,366,635,863,292,890,112,257,603,783,512]

theorem envBound58625 : H12AffineFastState.Bounded env58625 := by
  intro p hp
  have h : env58625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58624_58625 : H12AffineEnvironment.transform 10 1 env58624 = env58625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env58624 == env58625) = true)

theorem identity58625 : scanCanonicalize (H12AffineFastState.compose env58625 (packedSelected [0,1,5,9,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound58625 : packedSelected [0,1,5,9,12,15] rootPS < 2^1333 := by decide +kernel

def env58626 : List Nat := [2,4,8,16,32,64,89,256,49,84,1,26,348,74,293,115,319,81,84,293,366,32,302,72,268,383,366,74,366,292,331,112,257,106,318,49]

theorem envBound58626 : H12AffineFastState.Bounded env58626 := by
  intro p hp
  have h : env58626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58625_58626 : H12AffineEnvironment.transform 8 49 env58625 = env58626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env58625 == env58626) = true)

theorem identity58626 : scanCanonicalize (H12AffineFastState.compose env58626 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58626 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58627 : List Nat := [2,4,8,11,32,64,66,256,42,79,1,1,327,74,293,104,292,74,79,293,366,32,302,72,268,356,366,74,366,292,331,107,257,106,293,42]

theorem envBound58627 : H12AffineFastState.Bounded env58627 := by
  intro p hp
  have h : env58627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58626_58627 : H12AffineEnvironment.transform 3 11 env58626 = env58627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58626 == env58627) = true)

def env58628 : List Nat := [2,4,8,11,32,32,34,256,42,47,1,1,295,42,293,8,292,42,47,293,270,32,302,40,268,260,270,42,270,292,299,11,257,10,293,42]

theorem envBound58628 : H12AffineFastState.Bounded env58628 := by
  intro p hp
  have h : env58628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58627_58628 : H12AffineEnvironment.transform 5 32 env58627 = env58628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58627 == env58628) = true)

theorem identity58628 : scanCanonicalize (H12AffineFastState.compose env58628 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound58628 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58629 : List Nat := [2,4,8,11,32,32,34,36,42,47,1,1,3,42,1,8,0,42,47,1,42,32,10,40,40,32,42,42,42,0,15,11,37,10,1,42]

theorem envBound58629 : H12AffineFastState.Bounded env58629 := by
  intro p hp
  have h : env58629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58628_58629 : H12AffineEnvironment.transform 7 36 env58628 = env58629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58628 == env58629) = true)

def env58630 : List Nat := [2,4,8,11,32,33,35,256,42,46,1,1,294,43,293,9,292,43,46,293,271,32,302,41,268,261,271,43,271,292,298,10,257,11,293,42]

theorem envBound58630 : H12AffineFastState.Bounded env58630 := by
  intro p hp
  have h : env58630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58627_58630 : H12AffineEnvironment.transform 5 33 env58627 = env58630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58627 == env58630) = true)

def env58631 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,4096,349,4176,509,114,4604,4171,85,509,4525,32,2847,2681,468,2894,7068,4176,4525,2341,2978,169,257,2651,4605,512]

theorem envBound58631 : H12AffineFastState.Bounded env58631 := by
  intro p hp
  have h : env58631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58614_58631 : H12AffineEnvironment.transform 9 85 env58614 = env58631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env58614 == env58631) = true)

def env58632 : List Nat := [2,4,8,16,32,64,88,256,512,85,2048,4096,349,4176,293,114,4388,4171,85,293,4469,32,2847,2681,268,2894,6980,4176,4469,2341,2938,113,257,2651,4389,512]

theorem envBound58632 : H12AffineFastState.Bounded env58632 := by
  intro p hp
  have h : env58632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58631_58632 : H12AffineEnvironment.transform 6 88 env58631 = env58632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58631 == env58632) = true)

theorem identity58632 : scanCanonicalize (H12AffineFastState.compose env58632 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2420) := by decide +kernel

theorem selectedBound58632 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58633 : List Nat := [2,4,8,16,32,64,88,256,512,85,2048,2420,349,2340,293,114,2128,2367,85,293,2049,32,2847,2681,268,2894,560,2340,2049,2341,2938,113,257,2651,2129,512]

theorem envBound58633 : H12AffineFastState.Bounded env58633 := by
  intro p hp
  have h : env58633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58632_58633 : H12AffineEnvironment.transform 11 2420 env58632 = env58633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2420 env58632 == env58633) = true)

theorem identity58633 : scanCanonicalize (H12AffineFastState.compose env58633 (packedSelected [0,3,4,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58633 : packedSelected [0,3,4,11,13] rootPS < 2^1333 := by decide +kernel

def env58634 : List Nat := [2,4,8,16,17,64,88,256,512,85,2048,2373,349,2325,276,67,2128,2318,85,276,2049,17,2847,2632,268,2894,513,2325,2049,2324,2891,64,257,2651,2129,512]

theorem envBound58634 : H12AffineFastState.Bounded env58634 := by
  intro p hp
  have h : env58634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58633_58634 : H12AffineEnvironment.transform 4 17 env58633 = env58634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58633 == env58634) = true)

theorem identity58634 : scanCanonicalize (H12AffineFastState.compose env58634 (packedSelected [0,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound58634 : packedSelected [0,9,10] rootPS < 2^1333 := by decide +kernel

def env58635 : List Nat := [2,4,8,16,17,64,88,95,512,85,2048,2074,2,2122,75,67,2128,2129,85,75,2049,17,2624,2632,83,2577,513,2122,2049,2123,2580,64,94,2651,2129,512]

theorem envBound58635 : H12AffineFastState.Bounded env58635 := by
  intro p hp
  have h : env58635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58634_58635 : H12AffineEnvironment.transform 7 95 env58634 = env58635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env58634 == env58635) = true)

def env58636 : List Nat := [2,4,8,16,32,64,89,256,512,85,2048,4096,349,4176,292,114,4389,4171,85,292,4468,32,2847,2681,269,2894,6981,4176,4468,2341,2939,112,257,2651,4388,512]

theorem envBound58636 : H12AffineFastState.Bounded env58636 := by
  intro p hp
  have h : env58636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58631_58636 : H12AffineEnvironment.transform 6 89 env58631 = env58636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58631 == env58636) = true)

theorem identity58636 : scanCanonicalize (H12AffineFastState.compose env58636 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound58636 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58637 : List Nat := [2,4,8,16,32,64,89,256,512,85,2048,2048,349,2128,292,114,2341,2123,85,292,2420,32,2847,2681,269,2894,837,2128,2420,2341,2939,112,257,2651,2340,512]

theorem envBound58637 : H12AffineFastState.Bounded env58637 := by
  intro p hp
  have h : env58637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58636_58637 : H12AffineEnvironment.transform 11 2048 env58636 = env58637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env58636 == env58637) = true)

theorem identity58637 : scanCanonicalize (H12AffineFastState.compose env58637 (packedSelected [0,4,5,10,12,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound58637 : packedSelected [0,4,5,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58638 : List Nat := [2,4,8,16,32,64,89,256,512,85,1,1,349,81,292,114,292,74,85,292,373,32,798,632,269,847,837,81,373,292,890,112,257,602,293,512]

theorem envBound58638 : H12AffineFastState.Bounded env58638 := by
  intro p hp
  have h : env58638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58637_58638 : H12AffineEnvironment.transform 10 1 env58637 = env58638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env58637 == env58638) = true)

theorem identity58638 : scanCanonicalize (H12AffineFastState.compose env58638 (packedSelected [1,3,4,5,9,10,13] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58638 : packedSelected [1,3,4,5,9,10,13] rootPS < 2^1333 := by decide +kernel

def env58639 : List Nat := [2,4,8,11,32,64,66,256,512,78,1,1,326,74,292,105,292,74,78,292,366,32,773,611,269,847,837,74,366,292,865,107,257,577,293,512]

theorem envBound58639 : H12AffineFastState.Bounded env58639 := by
  intro p hp
  have h : env58639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58638_58639 : H12AffineEnvironment.transform 3 11 env58638 = env58639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58638 == env58639) = true)

theorem identity58639 : scanCanonicalize (H12AffineFastState.compose env58639 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound58639 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58640 : List Nat := [2,4,8,11,32,64,66,256,43,78,1,1,326,74,292,105,292,74,78,292,366,32,302,72,269,356,366,74,366,292,330,107,257,106,293,43]

theorem envBound58640 : H12AffineFastState.Bounded env58640 := by
  intro p hp
  have h : env58640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58639_58640 : H12AffineEnvironment.transform 8 43 env58639 = env58640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env58639 == env58640) = true)

def env58641 : List Nat := [2,4,8,11,32,32,34,256,43,46,1,1,294,42,292,9,292,42,46,292,270,32,302,40,269,260,270,42,270,292,298,11,257,10,293,43]

theorem envBound58641 : H12AffineFastState.Bounded env58641 := by
  intro p hp
  have h : env58641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58640_58641 : H12AffineEnvironment.transform 5 32 env58640 = env58641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58640 == env58641) = true)

theorem identity58641 : scanCanonicalize (H12AffineFastState.compose env58641 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound58641 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58642 : List Nat := [2,4,8,11,32,32,34,36,43,46,1,1,2,42,0,9,0,42,46,0,42,32,10,40,41,32,42,42,42,0,14,11,37,10,1,43]

theorem envBound58642 : H12AffineFastState.Bounded env58642 := by
  intro p hp
  have h : env58642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58641_58642 : H12AffineEnvironment.transform 7 36 env58641 = env58642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58641 == env58642) = true)

def env58643 : List Nat := [2,4,8,11,32,33,35,256,43,47,1,1,295,43,292,8,292,43,47,292,271,32,302,41,269,261,271,43,271,292,299,10,257,11,293,43]

theorem envBound58643 : H12AffineFastState.Bounded env58643 := by
  intro p hp
  have h : env58643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58640_58643 : H12AffineEnvironment.transform 5 33 env58640 = env58643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58640 == env58643) = true)

def env58644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1289,4176,1449,1062,4604,262144,1024,1449,4524,32,270081,269927,1408,270160,8137,4176,4525,2341,269289,168,257,269892,4605,512]

theorem envBound58644 : H12AffineFastState.Bounded env58644 := by
  intro p hp
  have h : env58644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58612_58644 : H12AffineEnvironment.transform 12 1289 env58612 = env58644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env58612 == env58644) = true)

theorem identity58644 : scanCanonicalize (H12AffineFastState.compose env58644 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound58644 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1703,4096,1289,4176,1449,1062,4604,262144,1024,1449,4524,32,266662,266432,1408,266743,4462,4176,4525,1922,267598,168,257,266467,4605,512]

theorem envBound58645 : H12AffineFastState.Bounded env58645 := by
  intro p hp
  have h : env58645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58644_58645 : H12AffineEnvironment.transform 10 1703 env58644 = env58645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env58644 == env58645) = true)

def env58646 : List Nat := [2,4,8,16,32,64,128,256,512,84,755,4096,349,4176,509,114,4604,262144,84,509,4524,32,266662,266432,468,266743,4462,4176,4525,982,266522,168,257,266467,4605,512]

theorem envBound58646 : H12AffineFastState.Bounded env58646 := by
  intro p hp
  have h : env58646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58645_58646 : H12AffineEnvironment.transform 9 84 env58645 = env58646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env58645 == env58646) = true)

def env58647 : List Nat := [2,4,8,16,32,64,88,256,512,84,555,4096,349,4176,293,114,4388,262144,84,293,4468,32,266622,266264,268,266543,4462,4176,4469,782,266522,112,257,266299,4389,512]

theorem envBound58647 : H12AffineFastState.Bounded env58647 := by
  intro p hp
  have h : env58647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58646_58647 : H12AffineEnvironment.transform 6 88 env58646 = env58647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58646 == env58647) = true)

theorem identity58647 : scanCanonicalize (H12AffineFastState.compose env58647 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 862) := by decide +kernel

theorem selectedBound58647 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58648 : List Nat := [2,4,8,16,32,64,88,256,512,84,555,862,349,782,293,114,634,262144,84,293,554,32,262688,262982,268,262769,560,782,555,782,262724,112,257,263013,635,512]

theorem envBound58648 : H12AffineFastState.Bounded env58648 := by
  intro p hp
  have h : env58648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58647_58648 : H12AffineEnvironment.transform 11 862 env58647 = env58648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 862 env58647 == env58648) = true)

theorem identity58648 : scanCanonicalize (H12AffineFastState.compose env58648 (packedSelected [0,3,4,11,13] rootPS)) = affineNative (2^(17+1) ^^^ 863) := by decide +kernel

theorem selectedBound58648 : packedSelected [0,3,4,11,13] rootPS < 2^1333 := by decide +kernel

def env58649 : List Nat := [2,4,8,16,32,64,88,256,512,84,555,862,349,782,293,114,634,863,84,293,554,32,383,25,268,302,560,782,555,782,283,112,257,58,635,512]

theorem envBound58649 : H12AffineFastState.Bounded env58649 := by
  intro p hp
  have h : env58649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58648_58649 : H12AffineEnvironment.transform 17 863 env58648 = env58649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 863 env58648 == env58649) = true)

theorem identity58649 : scanCanonicalize (H12AffineFastState.compose env58649 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound58649 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env58650 : List Nat := [2,4,8,16,32,11,19,256,512,31,555,789,278,782,293,57,561,788,31,293,554,32,308,25,268,302,560,782,555,782,283,59,257,58,560,512]

theorem envBound58650 : H12AffineFastState.Bounded env58650 := by
  intro p hp
  have h : env58650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58649_58650 : H12AffineEnvironment.transform 5 11 env58649 = env58650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env58649 == env58650) = true)

theorem identity58650 : scanCanonicalize (H12AffineFastState.compose env58650 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound58650 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env58651 : List Nat := [2,4,8,16,32,11,19,37,512,31,555,560,51,555,0,57,561,561,31,0,554,32,17,25,41,11,560,555,555,555,62,59,36,58,560,512]

theorem envBound58651 : H12AffineFastState.Bounded env58651 := by
  intro p hp
  have h : env58651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58650_58651 : H12AffineEnvironment.transform 7 37 env58650 = env58651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58650 == env58651) = true)

theorem identity58651 : scanCanonicalize (H12AffineFastState.compose env58651 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58651 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58652 : List Nat := [2,4,8,16,17,11,19,20,512,31,538,513,2,538,0,8,512,512,31,0,539,17,17,25,24,11,513,538,538,538,15,10,21,11,513,512]

theorem envBound58652 : H12AffineFastState.Bounded env58652 := by
  intro p hp
  have h : env58652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58651_58652 : H12AffineEnvironment.transform 4 17 env58651 = env58652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58651 == env58652) = true)

def env58653 : List Nat := [2,4,8,16,32,64,89,256,512,84,554,4096,349,4176,292,114,4389,262144,84,292,4469,32,266623,266265,269,266542,4462,4176,4468,783,266522,113,257,266298,4388,512]

theorem envBound58653 : H12AffineFastState.Bounded env58653 := by
  intro p hp
  have h : env58653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58646_58653 : H12AffineEnvironment.transform 6 89 env58646 = env58653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58646 == env58653) = true)

theorem identity58653 : scanCanonicalize (H12AffineFastState.compose env58653 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound58653 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58654 : List Nat := [2,4,8,16,32,64,89,256,512,84,554,555,349,635,292,114,782,262144,84,292,862,32,262996,262706,269,262917,837,635,863,783,262961,113,257,262673,783,512]

theorem envBound58654 : H12AffineFastState.Bounded env58654 := by
  intro p hp
  have h : env58654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58653_58654 : H12AffineEnvironment.transform 11 555 env58653 = env58654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env58653 == env58654) = true)

theorem identity58654 : scanCanonicalize (H12AffineFastState.compose env58654 (packedSelected [0,4,5,10,12,15,18] rootPS)) = affineNative (2^(17+1) ^^^ 49) := by decide +kernel

theorem selectedBound58654 : packedSelected [0,4,5,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58655 : List Nat := [2,4,8,16,32,64,89,256,512,84,554,555,349,635,292,114,782,49,84,292,862,32,869,515,269,820,837,635,863,783,768,113,257,544,783,512]

theorem envBound58655 : H12AffineFastState.Bounded env58655 := by
  intro p hp
  have h : env58655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58654_58655 : H12AffineEnvironment.transform 17 49 env58654 = env58655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 49 env58654 == env58655) = true)

theorem identity58655 : scanCanonicalize (H12AffineFastState.compose env58655 (packedSelected [0,1,4,5,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound58655 : packedSelected [0,1,4,5,10,12] rootPS < 2^1333 := by decide +kernel

def env58656 : List Nat := [2,4,8,16,32,64,89,256,80,84,122,123,349,43,292,114,350,49,84,292,270,32,309,83,269,356,277,43,271,351,336,113,257,112,351,80]

theorem envBound58656 : H12AffineFastState.Bounded env58656 := by
  intro p hp
  have h : env58656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58655_58656 : H12AffineEnvironment.transform 8 80 env58655 = env58656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env58655 == env58656) = true)

theorem identity58656 : scanCanonicalize (H12AffineFastState.compose env58656 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58656 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env58657 : List Nat := [2,4,8,11,32,64,66,256,75,79,97,96,326,43,292,105,325,42,79,292,270,32,302,72,269,356,270,43,271,324,331,106,257,107,324,75]

theorem envBound58657 : H12AffineFastState.Bounded env58657 := by
  intro p hp
  have h : env58657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58656_58657 : H12AffineEnvironment.transform 3 11 env58656 = env58657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58656 == env58657) = true)

def env58658 : List Nat := [2,4,8,11,32,32,34,256,43,47,1,0,294,43,292,9,293,42,47,292,270,32,302,40,269,260,270,43,271,292,299,10,257,11,292,43]

theorem envBound58658 : H12AffineFastState.Bounded env58658 := by
  intro p hp
  have h : env58658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58657_58658 : H12AffineEnvironment.transform 5 32 env58657 = env58658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58657 == env58658) = true)

def env58659 : List Nat := [2,4,8,11,32,33,35,256,42,46,0,1,295,43,292,8,292,42,46,292,270,32,302,41,269,261,270,43,271,293,298,11,257,10,293,42]

theorem envBound58659 : H12AffineFastState.Bounded env58659 := by
  intro p hp
  have h : env58659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58657_58659 : H12AffineEnvironment.transform 5 33 env58657 = env58659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58657 == env58659) = true)

theorem identity58659 : scanCanonicalize (H12AffineFastState.compose env58659 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound58659 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58660 : List Nat := [2,4,8,11,32,33,35,37,42,46,0,1,2,43,1,8,1,42,46,1,43,32,11,41,40,32,43,43,42,0,15,11,36,10,0,42]

theorem envBound58660 : H12AffineFastState.Bounded env58660 := by
  intro p hp
  have h : env58660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58659_58660 : H12AffineEnvironment.transform 7 37 env58659 = env58660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58659 == env58660) = true)

def env58661 : List Nat := [2,4,8,16,32,64,128,256,512,85,754,4096,348,4176,508,115,4604,262144,85,508,4524,32,266662,266432,469,266743,4462,4176,4525,983,266523,168,257,266467,4605,512]

theorem envBound58661 : H12AffineFastState.Bounded env58661 := by
  intro p hp
  have h : env58661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58645_58661 : H12AffineEnvironment.transform 9 85 env58645 = env58661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env58645 == env58661) = true)

def env58662 : List Nat := [2,4,8,16,32,64,88,256,512,85,554,4096,348,4176,292,115,4388,262144,85,292,4468,32,266622,266264,269,266543,4462,4176,4469,783,266523,112,257,266299,4389,512]

theorem envBound58662 : H12AffineFastState.Bounded env58662 := by
  intro p hp
  have h : env58662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58661_58662 : H12AffineEnvironment.transform 6 88 env58661 = env58662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58661 == env58662) = true)

theorem identity58662 : scanCanonicalize (H12AffineFastState.compose env58662 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 789) := by decide +kernel

theorem selectedBound58662 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58663 : List Nat := [2,4,8,16,32,64,88,256,512,85,554,4096,348,4176,292,115,4388,789,85,292,4468,32,4715,4877,269,4666,4462,4176,4469,783,4622,112,257,4910,4389,512]

theorem envBound58663 : H12AffineFastState.Bounded env58663 := by
  intro p hp
  have h : env58663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58662_58663 : H12AffineEnvironment.transform 17 789 env58662 = env58663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 789 env58662 == env58663) = true)

theorem identity58663 : scanCanonicalize (H12AffineFastState.compose env58663 (packedSelected [3,7,9,11,13] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58663 : packedSelected [3,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env58664 : List Nat := [2,4,8,16,32,10,18,256,512,31,554,4096,278,4122,292,57,4388,789,31,292,4414,32,4641,4877,269,4666,4388,4122,4415,783,4622,58,257,4910,4389,512]

theorem envBound58664 : H12AffineFastState.Bounded env58664 := by
  intro p hp
  have h : env58664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58663_58664 : H12AffineEnvironment.transform 5 10 env58663 = env58664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58663 == env58664) = true)

theorem identity58664 : scanCanonicalize (H12AffineFastState.compose env58664 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 789) := by decide +kernel

theorem selectedBound58664 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env58665 : List Nat := [2,4,8,16,32,10,18,256,512,31,554,789,278,783,292,57,561,789,31,292,555,32,308,24,269,303,561,783,554,783,283,58,257,59,560,512]

theorem envBound58665 : H12AffineFastState.Bounded env58665 := by
  intro p hp
  have h : env58665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58664_58665 : H12AffineEnvironment.transform 11 789 env58664 = env58665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 789 env58664 == env58665) = true)

theorem identity58665 : scanCanonicalize (H12AffineFastState.compose env58665 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound58665 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env58666 : List Nat := [2,4,8,16,32,10,18,36,512,31,554,561,50,555,0,57,561,561,31,0,555,32,16,24,41,11,561,555,554,555,63,58,37,59,560,512]

theorem envBound58666 : H12AffineFastState.Bounded env58666 := by
  intro p hp
  have h : env58666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58665_58666 : H12AffineEnvironment.transform 7 36 env58665 = env58666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58665 == env58666) = true)

def env58667 : List Nat := [2,4,8,16,32,64,89,256,512,85,555,4096,348,4176,293,115,4389,262144,85,293,4469,32,266623,266265,268,266542,4462,4176,4468,782,266523,113,257,266298,4388,512]

theorem envBound58667 : H12AffineFastState.Bounded env58667 := by
  intro p hp
  have h : env58667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58661_58667 : H12AffineEnvironment.transform 6 89 env58661 = env58667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58661 == env58667) = true)

theorem identity58667 : scanCanonicalize (H12AffineFastState.compose env58667 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 608) := by decide +kernel

theorem selectedBound58667 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58668 : List Nat := [2,4,8,16,32,64,89,256,512,85,555,4096,348,4176,293,115,4389,608,85,293,4469,32,4895,4729,268,4942,4462,4176,4468,782,4987,113,257,4698,4388,512]

theorem envBound58668 : H12AffineFastState.Bounded env58668 := by
  intro p hp
  have h : env58668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58667_58668 : H12AffineEnvironment.transform 17 608 env58667 = env58668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 608 env58667 == env58668) = true)

theorem identity58668 : scanCanonicalize (H12AffineFastState.compose env58668 (packedSelected [5,7,9,10,12,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 123) := by decide +kernel

theorem selectedBound58668 : packedSelected [5,7,9,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env58669 : List Nat := [2,4,8,16,32,64,89,256,512,85,555,123,348,43,293,115,350,608,85,293,270,32,868,514,268,821,277,43,271,782,768,113,257,545,351,512]

theorem envBound58669 : H12AffineFastState.Bounded env58669 := by
  intro p hp
  have h : env58669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58668_58669 : H12AffineEnvironment.transform 11 123 env58668 = env58669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 123 env58668 == env58669) = true)

def env58670 : List Nat := [2,4,8,16,32,64,89,256,276,85,319,123,348,43,293,115,350,372,85,293,270,32,112,278,268,33,277,43,271,26,20,113,257,309,351,276]

theorem envBound58670 : H12AffineFastState.Bounded env58670 := by
  intro p hp
  have h : env58670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58669_58670 : H12AffineEnvironment.transform 8 276 env58669 = env58670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env58669 == env58670) = true)

theorem identity58670 : scanCanonicalize (H12AffineFastState.compose env58670 (packedSelected [9,10] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound58670 : packedSelected [9,10] rootPS < 2^1333 := by decide +kernel

def env58671 : List Nat := [2,4,8,16,32,64,89,68,80,85,123,123,24,43,97,115,26,48,85,97,74,32,112,82,72,33,81,43,75,26,20,113,69,113,27,80]

theorem envBound58671 : H12AffineFastState.Bounded env58671 := by
  intro p hp
  have h : env58671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58670_58671 : H12AffineEnvironment.transform 7 68 env58670 = env58671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env58670 == env58671) = true)

theorem identity58671 : scanCanonicalize (H12AffineFastState.compose env58671 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound58671 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58672 : List Nat := [2,4,8,16,32,58,35,62,42,47,1,1,24,43,27,9,26,48,47,27,48,32,10,40,50,33,43,43,49,26,20,11,63,11,27,42]

theorem envBound58672 : H12AffineFastState.Bounded env58672 := by
  intro p hp
  have h : env58672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58671_58672 : H12AffineEnvironment.transform 5 58 env58671 = env58672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env58671 == env58672) = true)

theorem identity58672 : scanCanonicalize (H12AffineFastState.compose env58672 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58672 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58673 : List Nat := [2,4,8,16,16,10,19,14,26,31,1,1,24,27,27,9,26,0,31,27,0,16,10,24,2,17,27,27,1,26,20,11,15,11,27,26]

theorem envBound58673 : H12AffineFastState.Bounded env58673 := by
  intro p hp
  have h : env58673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58672_58673 : H12AffineEnvironment.transform 4 16 env58672 = env58673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58672 == env58673) = true)

def env58674 : List Nat := [2,4,8,16,32,64,89,256,277,85,318,123,348,43,293,115,350,373,85,293,270,32,113,279,268,32,277,43,271,27,21,113,257,308,351,277]

theorem envBound58674 : H12AffineFastState.Bounded env58674 := by
  intro p hp
  have h : env58674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58669_58674 : H12AffineEnvironment.transform 8 277 env58669 = env58674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env58669 == env58674) = true)

theorem identity58674 : scanCanonicalize (H12AffineFastState.compose env58674 (packedSelected [0,1,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58674 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env58675 : List Nat := [2,4,8,11,32,64,66,256,270,78,293,96,327,43,293,104,325,366,78,293,270,32,106,268,268,32,270,43,271,0,14,106,257,303,324,270]

theorem envBound58675 : H12AffineFastState.Bounded env58675 := by
  intro p hp
  have h : env58675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58674_58675 : H12AffineEnvironment.transform 3 11 env58674 = env58675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58674 == env58675) = true)

theorem identity58675 : scanCanonicalize (H12AffineFastState.compose env58675 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound58675 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58676 : List Nat := [2,4,8,11,32,33,35,256,270,47,293,1,294,43,293,9,292,271,47,293,270,32,11,268,268,32,270,43,271,0,14,11,257,303,293,270]

theorem envBound58676 : H12AffineFastState.Bounded env58676 := by
  intro p hp
  have h : env58676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58675_58676 : H12AffineEnvironment.transform 5 33 env58675 = env58676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58675 == env58676) = true)

def env58677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8388688,134217728,4177,77954,4294795,8463815,2101509,257,14725225,78034,33563273]

theorem envBound58677 : H12AffineFastState.Bounded env58677 := by
  intro p hp
  have h : env58677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58380_58677 : H12AffineEnvironment.transform 13 4177 env58380 = env58677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58380 == env58677) = true)

theorem identity58677 : scanCanonicalize (H12AffineFastState.compose env58677 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound58677 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env58678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430022,8328,8388688,134217728,4177,77954,4294795,8463815,2101509,257,14725225,78034,513]

theorem envBound58678 : H12AffineFastState.Bounded env58678 := by
  intro p hp
  have h : env58678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58677_58678 : H12AffineEnvironment.transform 24 8328 env58677 = env58678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env58677 == env58678) = true)

theorem identity58678 : scanCanonicalize (H12AffineFastState.compose env58678 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 8724554) := by decide +kernel

theorem selectedBound58678 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430022,8328,8388688,8724554,4177,77954,4294795,8463815,2101509,257,14725225,78034,513]

theorem envBound58679 : H12AffineFastState.Bounded env58679 := by
  intro p hp
  have h : env58679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58678_58679 : H12AffineEnvironment.transform 26 8724554 env58678 = env58679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8724554 env58678 == env58679) = true)

theorem identity58679 : scanCanonicalize (H12AffineFastState.compose env58679 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound58679 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1024,32768,4097,4194304,8388608,8430022,8328,8388688,8724554,4177,77954,4294795,8463815,260,257,12623976,78034,513]

theorem envBound58680 : H12AffineFastState.Bounded env58680 := by
  intro p hp
  have h : env58680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58679_58680 : H12AffineEnvironment.transform 20 4097 env58679 = env58680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env58679 == env58680) = true)

theorem identity58680 : scanCanonicalize (H12AffineFastState.compose env58680 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4292674) := by decide +kernel

theorem selectedBound58680 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1024,32768,4097,4194304,4292674,4268420,8328,4292626,4497416,4177,77954,4294795,4236677,260,257,73770,78034,513]

theorem envBound58681 : H12AffineFastState.Bounded env58681 := by
  intro p hp
  have h : env58681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58680_58681 : H12AffineEnvironment.transform 22 4292674 env58680 = env58681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292674 env58680 == env58681) = true)

theorem identity58681 : scanCanonicalize (H12AffineFastState.compose env58681 (packedSelected [6,25] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound58681 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1024,32768,4097,396,98766,73736,8328,98718,303492,4177,77954,100615,41993,260,257,73770,78034,513]

theorem envBound58682 : H12AffineFastState.Bounded env58682 := by
  intro p hp
  have h : env58682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58681_58682 : H12AffineEnvironment.transform 21 396 env58681 = env58682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env58681 == env58682) = true)

theorem identity58682 : scanCanonicalize (H12AffineFastState.compose env58682 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound58682 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,8282,4233,262144,1024,32768,4097,396,41364,82,8328,41412,303492,4177,4312,43357,41993,260,257,112,4232,513]

theorem envBound58683 : H12AffineFastState.Bounded env58683 := by
  intro p hp
  have h : env58683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58682_58683 : H12AffineEnvironment.transform 15 8282 env58682 = env58683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env58682 == env58683) = true)

theorem identity58683 : scanCanonicalize (H12AffineFastState.compose env58683 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8432) := by decide +kernel

theorem selectedBound58683 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env58684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8432,8282,4233,262144,1024,8432,4097,396,356,82,8328,308,262516,4177,4312,2477,1273,260,257,112,4232,513]

theorem envBound58684 : H12AffineFastState.Bounded env58684 := by
  intro p hp
  have h : env58684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58683_58684 : H12AffineEnvironment.transform 14 8432 env58683 = env58684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8432 env58683 == env58684) = true)

theorem identity58684 : scanCanonicalize (H12AffineFastState.compose env58684 (packedSelected [2,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound58684 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env58685 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,4177,8432,8282,4233,262144,1024,8432,4097,112,152,82,8328,200,262280,4177,4312,2129,1273,248,253,112,4232,513]

theorem envBound58685 : H12AffineFastState.Bounded env58685 := by
  intro p hp
  have h : env58685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58684_58685 : H12AffineEnvironment.transform 7 252 env58684 = env58685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env58684 == env58685) = true)

theorem identity58685 : scanCanonicalize (H12AffineFastState.compose env58685 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound58685 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58686 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8,4177,248,82,4233,262144,1024,248,4097,112,152,82,128,200,262280,4177,4312,2129,1273,248,253,112,4232,513]

theorem envBound58686 : H12AffineFastState.Bounded env58686 := by
  intro p hp
  have h : env58686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58685_58686 : H12AffineEnvironment.transform 12 8 env58685 = env58686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env58685 == env58686) = true)

theorem identity58686 : scanCanonicalize (H12AffineFastState.compose env58686 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 576) := by decide +kernel

theorem selectedBound58686 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58687 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,576,8,529,248,82,713,262144,1024,248,577,112,152,82,128,200,262280,529,664,2129,1273,248,253,112,712,513]

theorem envBound58687 : H12AffineFastState.Bounded env58687 := by
  intro p hp
  have h : env58687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58686_58687 : H12AffineEnvironment.transform 11 576 env58686 = env58687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 576 env58686 == env58687) = true)

theorem identity58687 : scanCanonicalize (H12AffineFastState.compose env58687 (packedSelected [1,12,13,15,24] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound58687 : packedSelected [1,12,13,15,24] rootPS < 2^1333 := by decide +kernel

def env58688 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1703,576,8,529,248,82,713,262144,1024,248,577,112,152,82,128,200,262280,529,664,1782,1273,248,253,112,712,513]

theorem envBound58688 : H12AffineFastState.Bounded env58688 := by
  intro p hp
  have h : env58688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58687_58688 : H12AffineEnvironment.transform 10 1703 env58687 = env58688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env58687 == env58688) = true)

theorem identity58688 : scanCanonicalize (H12AffineFastState.compose env58688 (packedSelected [3,12,13,15,28] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound58688 : packedSelected [3,12,13,15,28] rootPS < 2^1333 := by decide +kernel

def env58689 : List Nat := [2,4,8,16,32,64,89,37,512,1024,1662,576,8,529,33,82,528,262144,1024,33,577,112,65,82,89,17,262225,529,577,1583,1056,33,36,112,529,513]

theorem envBound58689 : H12AffineFastState.Bounded env58689 := by
  intro p hp
  have h : env58689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58688_58689 : H12AffineEnvironment.transform 6 89 env58688 = env58689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58688 == env58689) = true)

theorem identity58689 : scanCanonicalize (H12AffineFastState.compose env58689 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58689 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58690 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1582,528,8,529,33,2,528,262144,1024,33,529,32,17,2,9,17,262145,529,529,1583,1056,33,36,32,529,513]

theorem envBound58690 : H12AffineFastState.Bounded env58690 := by
  intro p hp
  have h : env58690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58689_58690 : H12AffineEnvironment.transform 5 16 env58689 = env58690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58689 == env58690) = true)

theorem identity58690 : scanCanonicalize (H12AffineFastState.compose env58690 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 518) := by decide +kernel

theorem selectedBound58690 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58691 : List Nat := [2,4,8,16,32,16,9,37,512,518,40,528,8,529,33,2,528,262144,518,33,529,32,17,2,9,17,262145,529,529,41,550,33,36,32,529,513]

theorem envBound58691 : H12AffineFastState.Bounded env58691 := by
  intro p hp
  have h : env58691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58690_58691 : H12AffineEnvironment.transform 9 518 env58690 = env58691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 518 env58690 == env58691) = true)

theorem identity58691 : scanCanonicalize (H12AffineFastState.compose env58691 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound58691 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env58692 : List Nat := [2,4,8,16,32,16,9,37,48,54,40,32,8,33,33,2,32,262144,54,33,33,32,17,2,9,17,262145,33,33,41,22,33,36,32,33,49]

theorem envBound58692 : H12AffineFastState.Bounded env58692 := by
  intro p hp
  have h : env58692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58691_58692 : H12AffineEnvironment.transform 8 48 env58691 = env58692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env58691 == env58692) = true)

theorem identity58692 : scanCanonicalize (H12AffineFastState.compose env58692 (packedSelected [4,9] rootPS)) = affineNative (2^(17+1) ^^^ 40) := by decide +kernel

theorem selectedBound58692 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env58693 : List Nat := [2,4,8,16,32,16,9,37,48,54,40,32,8,33,33,2,32,40,54,33,33,32,17,2,9,17,41,33,33,41,22,33,36,32,33,49]

theorem envBound58693 : H12AffineFastState.Bounded env58693 := by
  intro p hp
  have h : env58693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58692_58693 : H12AffineEnvironment.transform 17 40 env58692 = env58693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 40 env58692 == env58693) = true)

theorem identity58693 : scanCanonicalize (H12AffineFastState.compose env58693 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58693 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58694 : List Nat := [2,4,8,11,32,11,9,37,43,45,40,32,8,33,33,2,32,40,45,33,33,32,10,2,9,10,41,33,33,41,13,33,36,32,33,42]

theorem envBound58694 : H12AffineFastState.Bounded env58694 := by
  intro p hp
  have h : env58694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58693_58694 : H12AffineEnvironment.transform 3 11 env58693 = env58694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58693 == env58694) = true)

def leafEnv58694 : List Nat := [2,4,8,11,32,11,9,37,43,45,40,32,8,33,33,2,32,40,45,33,33,32,10,2,13,9,1,10,41,33,33,41,13,33,36,32,5,2,33,42,1,33,0]

def active58694 : List Nat := [0,1,2,4]

def tree58694 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58694 : H12WitnessSearch.Good tree58694 := H12GlobalWitnessIndex.good

theorem leafIdentity58694 : H12AffineFastState.composeSystem env58694 rootObs = leafEnv58694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58694 rootObs == leafEnv58694) = true)

theorem terminalChecked58694 : H12PackedTerminal.terminalCheckFast leafEnv58694 active58694 tree58694 = true := by decide +kernel

def env58695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16384,131152,4315355,8463815,4294967296,256,4307611965,34359738368,33563273]

theorem envBound58695 : H12AffineFastState.Bounded env58695 := by
  intro p hp
  have h : env58695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57779_58695 : H12AffineEnvironment.transform 18 1025 env57779 = env58695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env57779 == env58695) = true)

def env58696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16384,131152,4315355,8463815,4294967296,256,4307611965,131072,33563273]

theorem envBound58696 : H12AffineFastState.Bounded env58696 := by
  intro p hp
  have h : env58696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58695_58696 : H12AffineEnvironment.transform 34 131072 env58695 = env58696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env58695 == env58696) = true)

theorem identity58696 : scanCanonicalize (H12AffineFastState.compose env58696 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 8594567) := by decide +kernel

theorem selectedBound58696 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16384,131152,4315355,8463815,8594567,256,4445626,131072,33563273]

theorem envBound58697 : H12AffineFastState.Bounded env58697 := by
  intro p hp
  have h : env58697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58696_58697 : H12AffineEnvironment.transform 31 8594567 env58696 = env58697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8594567 env58696 == env58697) = true)

theorem identity58697 : scanCanonicalize (H12AffineFastState.compose env58697 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12919239) := by decide +kernel

theorem selectedBound58697 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409089,12919239,16384,131152,4315355,8463815,8594567,256,4445626,131072,33563273]

theorem envBound58698 : H12AffineFastState.Bounded env58698 := by
  intro p hp
  have h : env58698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58697_58698 : H12AffineEnvironment.transform 26 12919239 env58697 = env58698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12919239 env58697 == env58698) = true)

theorem identity58698 : scanCanonicalize (H12AffineFastState.compose env58698 (packedSelected [6,13,17,21,25,33] rootPS)) = affineNative (2^(24+1) ^^^ 28888) := by decide +kernel

theorem selectedBound58698 : packedSelected [6,13,17,21,25,33] rootPS < 2^1333 := by decide +kernel

def env58699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,28888,8409089,12919239,16384,131152,4315355,8463815,8594567,256,4445626,131072,21073]

theorem envBound58699 : H12AffineFastState.Bounded env58699 := by
  intro p hp
  have h : env58699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58698_58699 : H12AffineEnvironment.transform 24 28888 env58698 = env58699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 28888 env58698 == env58699) = true)

def env58700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,8328,8388689,12919239,4176,131152,4294795,8463815,8594567,256,4425194,131072,513]

theorem envBound58700 : H12AffineFastState.Bounded env58700 := by
  intro p hp
  have h : env58700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58699_58700 : H12AffineEnvironment.transform 13 4176 env58699 = env58700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env58699 == env58700) = true)

theorem identity58700 : scanCanonicalize (H12AffineFastState.compose env58700 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound58700 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,397,8388608,8430023,8328,8388689,8724554,4176,131152,100614,8463815,8594567,256,230503,131072,513]

theorem envBound58701 : H12AffineFastState.Bounded env58701 := by
  intro p hp
  have h : env58701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58700_58701 : H12AffineEnvironment.transform 21 397 env58700 = env58701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env58700 == env58701) = true)

theorem identity58701 : scanCanonicalize (H12AffineFastState.compose env58701 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound58701 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4096,397,8388608,8430023,8328,8388689,8724554,4176,131152,100614,8463815,8594567,256,230503,131072,513]

theorem envBound58702 : H12AffineFastState.Bounded env58702 := by
  intro p hp
  have h : env58702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58701_58702 : H12AffineEnvironment.transform 20 4096 env58701 = env58702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env58701 == env58702) = true)

theorem identity58702 : scanCanonicalize (H12AffineFastState.compose env58702 (packedSelected [13,21] rootPS)) = affineNative (2^(22+1) ^^^ 176413) := by decide +kernel

theorem selectedBound58702 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4096,397,176413,135386,8328,176460,495959,4176,131152,100614,234714,103834,256,230503,131072,513]

theorem envBound58703 : H12AffineFastState.Bounded env58703 := by
  intro p hp
  have h : env58703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58702_58703 : H12AffineEnvironment.transform 22 176413 env58702 = env58703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 176413 env58702 == env58703) = true)

theorem identity58703 : scanCanonicalize (H12AffineFastState.compose env58703 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound58703 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env58704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8461,65536,131072,262144,1025,8461,4096,397,135184,135386,8328,135233,471130,4176,131152,75787,210391,78999,256,206186,131072,513]

theorem envBound58704 : H12AffineFastState.Bounded env58704 := by
  intro p hp
  have h : env58704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58703_58704 : H12AffineEnvironment.transform 14 8461 env58703 = env58704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env58703 == env58704) = true)

theorem identity58704 : scanCanonicalize (H12AffineFastState.compose env58704 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 1212) := by decide +kernel

theorem selectedBound58704 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env58705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8461,65536,1212,262144,1025,8461,4096,397,5292,5222,8328,5373,341222,4176,1260,75787,78187,78999,256,74198,1212,513]

theorem envBound58705 : H12AffineFastState.Bounded env58705 := by
  intro p hp
  have h : env58705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58704_58705 : H12AffineEnvironment.transform 16 1212 env58704 = env58705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1212 env58704 == env58705) = true)

theorem identity58705 : scanCanonicalize (H12AffineFastState.compose env58705 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 81127) := by decide +kernel

theorem selectedBound58705 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env58706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8461,65536,1212,81127,1025,8461,4096,397,5292,5222,8328,5373,2049,4176,1260,75787,78187,78999,256,74198,1212,513]

theorem envBound58706 : H12AffineFastState.Bounded env58706 := by
  intro p hp
  have h : env58706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58705_58706 : H12AffineEnvironment.transform 17 81127 env58705 = env58706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 81127 env58705 == env58706) = true)

theorem identity58706 : scanCanonicalize (H12AffineFastState.compose env58706 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58706 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env58707 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4176,8353,65536,1212,81127,1025,8353,4096,33,5292,5222,8328,5373,2049,4176,1260,75787,78023,78999,172,73850,1212,513]

theorem envBound58707 : H12AffineFastState.Bounded env58707 := by
  intro p hp
  have h : env58707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58706_58707 : H12AffineEnvironment.transform 7 172 env58706 = env58707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58706 == env58707) = true)

theorem identity58707 : scanCanonicalize (H12AffineFastState.compose env58707 (packedSelected [0,2,5,7,8,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 1783) := by decide +kernel

theorem selectedBound58707 : packedSelected [0,2,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env58708 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1783,4096,8192,4176,8353,65536,1212,78352,1025,8353,4096,33,5292,5222,8328,5373,1782,4176,1260,75516,78023,78999,172,73850,1212,513]

theorem envBound58708 : H12AffineFastState.Bounded env58708 := by
  intro p hp
  have h : env58708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58707_58708 : H12AffineEnvironment.transform 10 1783 env58707 = env58708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1783 env58707 == env58708) = true)

theorem identity58708 : scanCanonicalize (H12AffineFastState.compose env58708 (packedSelected [0,2,5,6,7,8,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 1790) := by decide +kernel

theorem selectedBound58708 : packedSelected [0,2,5,6,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env58709 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1783,4096,8192,4176,8353,1790,1212,13550,1025,8353,4096,33,5292,5222,8328,5373,1782,4176,1260,8194,13881,12905,172,9860,1212,513]

theorem envBound58709 : H12AffineFastState.Bounded env58709 := by
  intro p hp
  have h : env58709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58708_58709 : H12AffineEnvironment.transform 15 1790 env58708 = env58709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1790 env58708 == env58709) = true)

theorem identity58709 : scanCanonicalize (H12AffineFastState.compose env58709 (packedSelected [0,2,3,6,7,8,10,11,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound58709 : packedSelected [0,2,3,6,7,8,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env58710 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1783,1212,8192,1260,8353,1790,1212,8274,1025,8353,1212,33,16,218,8328,65,1782,1260,1260,8194,8837,9941,172,9860,1212,513]

theorem envBound58710 : H12AffineFastState.Bounded env58710 := by
  intro p hp
  have h : env58710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58709_58710 : H12AffineEnvironment.transform 11 1212 env58709 = env58710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env58709 == env58710) = true)

theorem identity58710 : scanCanonicalize (H12AffineFastState.compose env58710 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound58710 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58711 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1783,1212,88,1260,249,1790,1212,10,1025,249,1212,33,16,218,208,65,1782,1260,1260,90,733,1677,172,1756,1212,513]

theorem envBound58711 : H12AffineFastState.Bounded env58711 := by
  intro p hp
  have h : env58711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58710_58711 : H12AffineEnvironment.transform 12 88 env58710 = env58711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env58710 == env58711) = true)

theorem identity58711 : scanCanonicalize (H12AffineFastState.compose env58711 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 182) := by decide +kernel

theorem selectedBound58711 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env58712 : List Nat := [2,4,8,16,32,64,128,172,512,182,577,10,88,90,249,584,10,10,183,249,10,33,16,218,208,65,576,90,90,90,733,571,172,618,10,513]

theorem envBound58712 : H12AffineFastState.Bounded env58712 := by
  intro p hp
  have h : env58712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58711_58712 : H12AffineEnvironment.transform 9 182 env58711 = env58712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 182 env58711 == env58712) = true)

theorem identity58712 : scanCanonicalize (H12AffineFastState.compose env58712 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound58712 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env58713 : List Nat := [2,4,8,16,32,64,128,172,146,182,211,10,88,90,249,218,10,10,183,249,10,33,16,218,208,65,210,90,90,90,79,169,172,248,10,147]

theorem envBound58713 : H12AffineFastState.Bounded env58713 := by
  intro p hp
  have h : env58713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58712_58713 : H12AffineEnvironment.transform 8 146 env58712 = env58713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env58712 == env58713) = true)

theorem identity58713 : scanCanonicalize (H12AffineFastState.compose env58713 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58713 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58714 : List Nat := [2,4,8,16,32,64,19,63,1,37,64,10,88,90,106,73,10,10,36,106,10,33,16,73,67,65,65,90,90,90,79,58,63,107,10,0]

theorem envBound58714 : H12AffineFastState.Bounded env58714 := by
  intro p hp
  have h : env58714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58713_58714 : H12AffineEnvironment.transform 6 19 env58713 = env58714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58713 == env58714) = true)

theorem identity58714 : scanCanonicalize (H12AffineFastState.compose env58714 (packedSelected [0,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound58714 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env58715 : List Nat := [2,4,8,16,32,32,19,63,1,37,32,10,56,58,10,41,10,10,36,10,10,33,16,41,35,33,33,58,58,58,47,58,63,11,10,0]

theorem envBound58715 : H12AffineFastState.Bounded env58715 := by
  intro p hp
  have h : env58715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58714_58715 : H12AffineEnvironment.transform 5 32 env58714 = env58715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58714 == env58715) = true)

theorem identity58715 : scanCanonicalize (H12AffineFastState.compose env58715 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound58715 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58716 : List Nat := [2,4,8,3,32,32,0,44,1,37,32,10,43,41,10,41,10,10,36,10,10,33,3,41,35,33,33,41,41,41,47,41,44,11,10,0]

theorem envBound58716 : H12AffineFastState.Bounded env58716 := by
  intro p hp
  have h : env58716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58715_58716 : H12AffineEnvironment.transform 3 3 env58715 = env58716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env58715 == env58716) = true)

theorem identity58716 : scanCanonicalize (H12AffineFastState.compose env58716 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound58716 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env58717 : List Nat := [2,4,8,3,3,3,0,15,1,6,3,10,8,10,10,10,10,10,7,10,10,2,3,10,0,2,2,10,10,10,12,10,15,11,10,0]

theorem envBound58717 : H12AffineFastState.Bounded env58717 := by
  intro p hp
  have h : env58717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58716_58717 : H12AffineEnvironment.transform 4 3 env58716 = env58717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env58716 == env58717) = true)

def leafEnv58717 : List Nat := [2,4,8,3,3,3,0,15,1,6,3,10,8,10,10,10,10,10,7,10,10,2,3,10,12,0,1,2,2,10,10,10,12,10,15,11,5,2,10,0,1,11,0]

def active58717 : List Nat := [0,1,2]

def tree58717 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58717 : H12WitnessSearch.Good tree58717 := H12GlobalWitnessIndex.good

theorem leafIdentity58717 : H12AffineFastState.composeSystem env58717 rootObs = leafEnv58717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58717 rootObs == leafEnv58717) = true)

theorem terminalChecked58717 : H12PackedTerminal.terminalCheckFast leafEnv58717 active58717 tree58717 = true := by decide +kernel

def env58718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,8329,8388688,12919239,4177,131152,4294794,8463815,8594567,256,4425195,131072,512]

theorem envBound58718 : H12AffineFastState.Bounded env58718 := by
  intro p hp
  have h : env58718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58699_58718 : H12AffineEnvironment.transform 13 4177 env58699 = env58718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58699 == env58718) = true)

theorem identity58718 : scanCanonicalize (H12AffineFastState.compose env58718 (packedSelected [4,9,16] rootPS)) = affineNative (2^(16+1) ^^^ 78035) := by decide +kernel

theorem selectedBound58718 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1025,32768,2097152,4194304,8388608,8430023,8329,8388688,12919239,4177,77955,4294794,8463815,8393812,256,4240696,78035,512]

theorem envBound58719 : H12AffineFastState.Bounded env58719 := by
  intro p hp
  have h : env58719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58718_58719 : H12AffineEnvironment.transform 16 78035 env58718 = env58719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78035 env58718 == env58719) = true)

theorem identity58719 : scanCanonicalize (H12AffineFastState.compose env58719 (packedSelected [13,21] rootPS)) = affineNative (2^(21+1) ^^^ 103746) := by decide +kernel

theorem selectedBound58719 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78035,262144,1025,32768,2097152,103746,8388608,8430023,8329,8388688,8696965,4177,77955,7624,8463815,8393812,256,73850,78035,512]

theorem envBound58720 : H12AffineFastState.Bounded env58720 := by
  intro p hp
  have h : env58720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58719_58720 : H12AffineEnvironment.transform 21 103746 env58719 = env58720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 103746 env58719 == env58720) = true)

theorem identity58720 : scanCanonicalize (H12AffineFastState.compose env58720 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 38243) := by decide +kernel

theorem selectedBound58720 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env58721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38243,42416,262144,1025,32768,2097152,33,8388608,8430023,8329,8388688,8696965,4177,42464,7624,8433828,8393812,256,46361,42416,512]

theorem envBound58721 : H12AffineFastState.Bounded env58721 := by
  intro p hp
  have h : env58721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58720_58721 : H12AffineEnvironment.transform 15 38243 env58720 = env58721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38243 env58720 == env58721) = true)

def env58722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38243,42416,262144,1025,32768,2097152,33,64,41351,8329,16,308421,4177,42464,7624,45284,5140,256,46361,42416,512]

theorem envBound58722 : H12AffineFastState.Bounded env58722 := by
  intro p hp
  have h : env58722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58721_58722 : H12AffineEnvironment.transform 22 64 env58721 = env58722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 64 env58721 == env58722) = true)

theorem identity58722 : scanCanonicalize (H12AffineFastState.compose env58722 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 48325) := by decide +kernel

theorem selectedBound58722 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38243,42416,48325,1025,32768,2097152,33,64,41351,8329,16,2048,4177,42464,7624,45284,5140,256,46361,42416,512]

theorem envBound58723 : H12AffineFastState.Bounded env58723 := by
  intro p hp
  have h : env58723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58722_58723 : H12AffineEnvironment.transform 17 48325 env58722 = env58723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48325 env58722 == env58723) = true)

theorem identity58723 : scanCanonicalize (H12AffineFastState.compose env58723 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(20+1) ^^^ 1945) := by decide +kernel

theorem selectedBound58723 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38243,42416,48325,1025,32768,1945,33,64,41351,8329,16,2048,4177,42464,7624,45284,5140,256,46361,42416,512]

theorem envBound58724 : H12AffineFastState.Bounded env58724 := by
  intro p hp
  have h : env58724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58723_58724 : H12AffineEnvironment.transform 20 1945 env58723 = env58724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1945 env58723 == env58724) = true)

theorem identity58724 : scanCanonicalize (H12AffineFastState.compose env58724 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound58724 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,13423,1212,7625,1025,8460,1945,33,64,139,8329,16,2048,4177,1260,7624,4584,5140,256,5141,1212,512]

theorem envBound58725 : H12AffineFastState.Bounded env58725 := by
  intro p hp
  have h : env58725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58724_58725 : H12AffineEnvironment.transform 14 8460 env58724 = env58725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env58724 == env58725) = true)

theorem identity58725 : scanCanonicalize (H12AffineFastState.compose env58725 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(11+1) ^^^ 2634) := by decide +kernel

theorem selectedBound58725 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env58726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2634,8192,2587,8460,11813,1212,1923,1025,8460,1945,33,64,139,8329,16,2048,2587,1260,1922,2978,3678,256,3679,1212,512]

theorem envBound58726 : H12AffineFastState.Bounded env58726 := by
  intro p hp
  have h : env58726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58725_58726 : H12AffineEnvironment.transform 11 2634 env58725 = env58726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2634 env58725 == env58726) = true)

theorem identity58726 : scanCanonicalize (H12AffineFastState.compose env58726 (packedSelected [0,1,3,6,7,13] rootPS)) = affineNative (2^(12+1) ^^^ 1111) := by decide +kernel

theorem selectedBound58726 : packedSelected [0,1,3,6,7,13] rootPS < 2^1333 := by decide +kernel

def env58727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2634,1111,2587,1371,2674,1212,1923,1025,1371,1945,33,64,139,1246,16,2048,2587,1260,1922,2978,3678,256,3679,1212,512]

theorem envBound58727 : H12AffineFastState.Bounded env58727 := by
  intro p hp
  have h : env58727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58726_58727 : H12AffineEnvironment.transform 12 1111 env58726 = env58727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1111 env58726 == env58727) = true)

theorem identity58727 : scanCanonicalize (H12AffineFastState.compose env58727 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound58727 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env58728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1703,1261,1111,1212,1371,1237,1212,1923,1025,1371,1945,33,64,139,1246,16,1703,1212,1260,1922,1285,249,256,248,1212,512]

theorem envBound58728 : H12AffineFastState.Bounded env58728 := by
  intro p hp
  have h : env58728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58727_58728 : H12AffineEnvironment.transform 10 1703 env58727 = env58728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env58727 == env58728) = true)

theorem identity58728 : scanCanonicalize (H12AffineFastState.compose env58728 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound58728 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58729 : List Nat := [2,4,8,16,32,64,128,256,293,1024,1410,1261,1111,1212,1371,1237,1212,1190,1025,1371,1212,33,64,139,1246,16,1410,1212,1260,1191,1285,249,256,248,1212,293]

theorem envBound58729 : H12AffineFastState.Bounded env58729 := by
  intro p hp
  have h : env58729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58728_58729 : H12AffineEnvironment.transform 8 293 env58728 = env58729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env58728 == env58729) = true)

def env58730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38243,42416,262144,1025,32768,2097152,33,65,41350,8329,17,308420,4177,42464,7624,45285,5141,256,46361,42416,512]

theorem envBound58730 : H12AffineFastState.Bounded env58730 := by
  intro p hp
  have h : env58730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58721_58730 : H12AffineEnvironment.transform 22 65 env58721 = env58730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 65 env58721 == env58730) = true)

theorem identity58730 : scanCanonicalize (H12AffineFastState.compose env58730 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound58730 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38243,42416,43048,1025,32768,2097152,33,65,41350,8329,17,7404,4177,42464,7624,45285,5141,256,46361,42416,512]

theorem envBound58731 : H12AffineFastState.Bounded env58731 := by
  intro p hp
  have h : env58731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58730_58731 : H12AffineEnvironment.transform 17 43048 env58730 = env58731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env58730 == env58731) = true)

theorem identity58731 : scanCanonicalize (H12AffineFastState.compose env58731 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 4981) := by decide +kernel

theorem selectedBound58731 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38243,42416,43048,1025,32768,4981,33,65,41350,8329,17,7404,4177,42464,7624,45285,5141,256,46361,42416,512]

theorem envBound58732 : H12AffineFastState.Bounded env58732 := by
  intro p hp
  have h : env58732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58731_58732 : H12AffineEnvironment.transform 20 4981 env58731 = env58732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4981 env58731 == env58732) = true)

theorem identity58732 : scanCanonicalize (H12AffineFastState.compose env58732 (packedSelected [1,3,6,13] rootPS)) = affineNative (2^(14+1) ^^^ 13792) := by decide +kernel

theorem selectedBound58732 : packedSelected [1,3,6,13] rootPS < 2^1333 := by decide +kernel

def env58733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,13792,8323,4176,7624,1025,13792,4981,33,65,5222,8329,17,7404,4177,4096,7624,1285,5141,256,249,4176,512]

theorem envBound58733 : H12AffineFastState.Bounded env58733 := by
  intro p hp
  have h : env58733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58732_58733 : H12AffineEnvironment.transform 14 13792 env58732 = env58733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13792 env58732 == env58733) = true)

theorem identity58733 : scanCanonicalize (H12AffineFastState.compose env58733 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1261) := by decide +kernel

theorem selectedBound58733 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1212,8461,8323,1213,2341,1025,8461,1944,33,65,139,8329,17,2049,1212,1261,2341,1285,248,256,249,1213,512]

theorem envBound58734 : H12AffineFastState.Bounded env58734 := by
  intro p hp
  have h : env58734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58733_58734 : H12AffineEnvironment.transform 11 1261 env58733 = env58734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1261 env58733 == env58734) = true)

theorem identity58734 : scanCanonicalize (H12AffineFastState.compose env58734 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2949) := by decide +kernel

theorem selectedBound58734 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,2949,1212,2696,2822,1213,2341,1025,2696,1944,33,65,139,2828,17,2049,1212,1261,2341,1285,248,256,249,1213,512]

theorem envBound58735 : H12AffineFastState.Bounded env58735 := by
  intro p hp
  have h : env58735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58734_58735 : H12AffineEnvironment.transform 12 2949 env58734 = env58735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2949 env58734 == env58735) = true)

def env58736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16384,131152,4315355,8463815,4294967296,256,4307611965,131073,33563273]

theorem envBound58736 : H12AffineFastState.Bounded env58736 := by
  intro p hp
  have h : env58736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58695_58736 : H12AffineEnvironment.transform 34 131073 env58695 = env58736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env58695 == env58736) = true)

theorem identity58736 : scanCanonicalize (H12AffineFastState.compose env58736 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 10695815) := by decide +kernel

theorem selectedBound58736 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16384,131152,4315355,8463815,10695815,256,6538682,131073,33563273]

theorem envBound58737 : H12AffineFastState.Bounded env58737 := by
  intro p hp
  have h : env58737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58736_58737 : H12AffineEnvironment.transform 31 10695815 env58736 = env58737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10695815 env58736 == env58737) = true)

theorem identity58737 : scanCanonicalize (H12AffineFastState.compose env58737 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound58737 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8388689,134217728,4176,131152,4294795,8463815,10695815,256,6526442,131073,33563273]

theorem envBound58738 : H12AffineFastState.Bounded env58738 := by
  intro p hp
  have h : env58738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58737_58738 : H12AffineEnvironment.transform 13 4176 env58737 = env58738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env58737 == env58738) = true)

theorem identity58738 : scanCanonicalize (H12AffineFastState.compose env58738 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound58738 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env58739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,8328,8388689,134217728,4176,131152,4294795,8463815,10695815,256,6526442,131073,513]

theorem envBound58739 : H12AffineFastState.Bounded env58739 := by
  intro p hp
  have h : env58739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58738_58739 : H12AffineEnvironment.transform 24 8328 env58738 = env58739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env58738 == env58739) = true)

theorem identity58739 : scanCanonicalize (H12AffineFastState.compose env58739 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 8724554) := by decide +kernel

theorem selectedBound58739 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,8328,8388689,8724554,4176,131152,4294795,8463815,10695815,256,6526442,131073,513]

theorem envBound58740 : H12AffineFastState.Bounded env58740 := by
  intro p hp
  have h : env58740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58739_58740 : H12AffineEnvironment.transform 26 8724554 env58739 = env58740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8724554 env58739 == env58740) = true)

theorem identity58740 : scanCanonicalize (H12AffineFastState.compose env58740 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound58740 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4096,4194304,8388608,8430023,8328,8388689,8724554,4176,131152,4294795,8463815,8594567,256,4425194,131073,513]

theorem envBound58741 : H12AffineFastState.Bounded env58741 := by
  intro p hp
  have h : env58741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58740_58741 : H12AffineEnvironment.transform 20 4096 env58740 = env58741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env58740 == env58741) = true)

theorem identity58741 : scanCanonicalize (H12AffineFastState.compose env58741 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4370576) := by decide +kernel

theorem selectedBound58741 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4096,4194304,4370576,4329815,8328,4370625,4690138,4176,131152,4294795,4429143,4297751,256,4425194,131073,513]

theorem envBound58742 : H12AffineFastState.Bounded env58742 := by
  intro p hp
  have h : env58742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58741_58742 : H12AffineEnvironment.transform 22 4370576 env58741 = env58742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4370576 env58741 == env58742) = true)

theorem identity58742 : scanCanonicalize (H12AffineFastState.compose env58742 (packedSelected [6,25] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound58742 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4096,397,176413,135386,8328,176460,495959,4176,131152,100614,234714,103834,256,230503,131073,513]

theorem envBound58743 : H12AffineFastState.Bounded env58743 := by
  intro p hp
  have h : env58743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58742_58743 : H12AffineEnvironment.transform 21 397 env58742 = env58743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env58742 == env58743) = true)

theorem identity58743 : scanCanonicalize (H12AffineFastState.compose env58743 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound58743 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env58744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8460,65536,131072,262144,1025,8460,4096,397,135185,135386,8328,135232,471131,4176,131152,75786,210390,78998,256,206187,131073,513]

theorem envBound58744 : H12AffineFastState.Bounded env58744 := by
  intro p hp
  have h : env58744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58743_58744 : H12AffineEnvironment.transform 14 8460 env58743 = env58744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env58743 == env58744) = true)

theorem identity58744 : scanCanonicalize (H12AffineFastState.compose env58744 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 1212) := by decide +kernel

theorem selectedBound58744 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env58745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8460,65536,1212,262144,1025,8460,4096,397,5293,5222,8328,5372,341223,4176,1260,75786,78186,78998,256,74199,1213,513]

theorem envBound58745 : H12AffineFastState.Bounded env58745 := by
  intro p hp
  have h : env58745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58744_58745 : H12AffineEnvironment.transform 16 1212 env58744 = env58745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1212 env58744 == env58745) = true)

theorem identity58745 : scanCanonicalize (H12AffineFastState.compose env58745 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 75787) := by decide +kernel

theorem selectedBound58745 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env58746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8460,65536,1212,75787,1025,8460,4096,397,5293,5222,8328,5372,7404,4176,1260,75786,78186,78998,256,74199,1213,513]

theorem envBound58746 : H12AffineFastState.Bounded env58746 := by
  intro p hp
  have h : env58746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58745_58746 : H12AffineEnvironment.transform 17 75787 env58745 = env58746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75787 env58745 == env58746) = true)

theorem identity58746 : scanCanonicalize (H12AffineFastState.compose env58746 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58746 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env58747 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4176,8352,65536,1212,75787,1025,8352,4096,33,5293,5222,8328,5372,7404,4176,1260,75786,78022,78998,172,73851,1213,513]

theorem envBound58747 : H12AffineFastState.Bounded env58747 := by
  intro p hp
  have h : env58747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58746_58747 : H12AffineEnvironment.transform 7 172 env58746 = env58747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58746 == env58747) = true)

theorem identity58747 : scanCanonicalize (H12AffineFastState.compose env58747 (packedSelected [0,5,6,7,8,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1710) := by decide +kernel

theorem selectedBound58747 : packedSelected [0,5,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env58748 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4176,8352,1710,1212,11941,1025,8352,4096,33,5293,5222,8328,5372,7404,4176,1260,11940,13928,12856,172,9941,1213,513]

theorem envBound58748 : H12AffineFastState.Bounded env58748 := by
  intro p hp
  have h : env58748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58747_58748 : H12AffineEnvironment.transform 15 1710 env58747 = env58748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1710 env58747 == env58748) = true)

theorem identity58748 : scanCanonicalize (H12AffineFastState.compose env58748 (packedSelected [0,3,6,7,8,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound58748 : packedSelected [0,3,6,7,8,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env58749 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1702,4096,8192,4176,8352,1710,1212,8195,1025,8352,4096,33,5293,5222,8328,5372,4682,4176,1260,8194,13928,12856,172,9941,1213,513]

theorem envBound58749 : H12AffineFastState.Bounded env58749 := by
  intro p hp
  have h : env58749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58748_58749 : H12AffineEnvironment.transform 10 1702 env58748 = env58749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env58748 == env58749) = true)

theorem identity58749 : scanCanonicalize (H12AffineFastState.compose env58749 (packedSelected [3,5,6,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1260) := by decide +kernel

theorem selectedBound58749 : packedSelected [3,5,6,10,13,17] rootPS < 2^1333 := by decide +kernel

def env58750 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1702,1260,8192,1212,8352,1710,1212,8195,1025,8352,1260,33,65,138,8328,16,1702,1212,1260,8194,8836,9940,172,9941,1213,513]

theorem envBound58750 : H12AffineFastState.Bounded env58750 := by
  intro p hp
  have h : env58750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58749_58750 : H12AffineEnvironment.transform 11 1260 env58749 = env58750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env58749 == env58750) = true)

theorem identity58750 : scanCanonicalize (H12AffineFastState.compose env58750 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58750 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58751 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1702,1212,8192,1212,8352,1710,1212,8195,1025,8352,1212,33,17,138,8328,16,1702,1212,1212,8194,8836,9860,172,9861,1213,513]

theorem envBound58751 : H12AffineFastState.Bounded env58751 := by
  intro p hp
  have h : env58751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58750_58751 : H12AffineEnvironment.transform 5 16 env58750 = env58751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58750 == env58751) = true)

theorem identity58751 : scanCanonicalize (H12AffineFastState.compose env58751 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound58751 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env58752 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1702,1212,8,1212,168,1710,1212,11,1025,168,1212,33,17,138,128,16,1702,1212,1212,10,652,1676,172,1677,1213,513]

theorem envBound58752 : H12AffineFastState.Bounded env58752 := by
  intro p hp
  have h : env58752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58751_58752 : H12AffineEnvironment.transform 12 8 env58751 = env58752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env58751 == env58752) = true)

theorem identity58752 : scanCanonicalize (H12AffineFastState.compose env58752 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 574) := by decide +kernel

theorem selectedBound58752 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env58753 : List Nat := [2,4,8,16,32,16,128,172,512,574,152,642,8,642,168,144,642,11,575,168,642,33,17,138,128,16,152,642,642,10,652,178,172,179,643,513]

theorem envBound58753 : H12AffineFastState.Bounded env58753 := by
  intro p hp
  have h : env58753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58752_58753 : H12AffineEnvironment.transform 9 574 env58752 = env58753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 574 env58752 == env58753) = true)

theorem identity58753 : scanCanonicalize (H12AffineFastState.compose env58753 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound58753 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env58754 : List Nat := [2,4,8,16,32,16,128,172,27,37,152,153,8,153,168,144,153,11,36,168,153,33,17,138,128,16,152,153,153,10,151,178,172,179,152,26]

theorem envBound58754 : H12AffineFastState.Bounded env58754 := by
  intro p hp
  have h : env58754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58753_58754 : H12AffineEnvironment.transform 8 27 env58753 = env58754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env58753 == env58754) = true)

def env58755 : List Nat := [2,4,8,16,32,16,56,20,27,37,32,33,8,33,16,40,33,11,36,16,33,33,17,50,56,16,32,33,33,10,47,10,20,11,32,26]

theorem envBound58755 : H12AffineFastState.Bounded env58755 := by
  intro p hp
  have h : env58755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58754_58755 : H12AffineEnvironment.transform 6 56 env58754 = env58755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env58754 == env58755) = true)

def env58756 : List Nat := [2,4,8,16,0,16,24,20,27,5,0,1,8,1,16,8,1,11,4,16,1,1,17,18,24,16,0,1,1,10,15,10,20,11,0,26]

theorem envBound58756 : H12AffineFastState.Bounded env58756 := by
  intro p hp
  have h : env58756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58755_58756 : H12AffineEnvironment.transform 4 0 env58755 = env58756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env58755 == env58756) = true)

theorem identity58756 : scanCanonicalize (H12AffineFastState.compose env58756 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound58756 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58757 : List Nat := [2,4,8,8,0,8,0,12,3,5,0,1,8,1,8,8,1,11,4,8,1,1,9,10,0,8,0,1,1,10,15,10,12,11,0,2]

theorem envBound58757 : H12AffineFastState.Bounded env58757 := by
  intro p hp
  have h : env58757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58756_58757 : H12AffineEnvironment.transform 3 8 env58756 = env58757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env58756 == env58757) = true)

def env58758 : List Nat := [2,4,0,0,0,0,0,4,3,5,0,1,0,1,0,0,1,3,4,0,1,1,1,2,0,0,0,1,1,2,7,2,4,3,0,2]

theorem envBound58758 : H12AffineFastState.Bounded env58758 := by
  intro p hp
  have h : env58758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58757_58758 : H12AffineEnvironment.transform 2 0 env58757 = env58758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58757 == env58758) = true)

def env58759 : List Nat := [2,4,1,1,0,1,0,5,3,5,0,1,1,1,1,1,1,2,4,1,1,1,0,3,0,1,0,1,1,3,6,3,5,2,0,2]

theorem envBound58759 : H12AffineFastState.Bounded env58759 := by
  intro p hp
  have h : env58759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58757_58759 : H12AffineEnvironment.transform 2 1 env58757 = env58759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env58757 == env58759) = true)

theorem identity58759 : scanCanonicalize (H12AffineFastState.compose env58759 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58759 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58760 : List Nat := [0,4,1,1,0,1,0,5,1,5,0,1,1,1,1,1,1,0,4,1,1,1,0,1,0,1,0,1,1,1,4,1,5,0,0,0]

theorem envBound58760 : H12AffineFastState.Bounded env58760 := by
  intro p hp
  have h : env58760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58759_58760 : H12AffineEnvironment.transform 0 0 env58759 = env58760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58759 == env58760) = true)

def leafEnv58760 : List Nat := [0,4,1,1,0,1,0,5,1,5,0,1,1,1,1,1,1,0,4,1,1,1,0,1,4,0,1,1,0,1,1,1,4,1,5,0,5,0,0,0,1,1,0]

def active58760 : List Nat := [1]

def tree58760 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58760 : H12WitnessSearch.Good tree58760 := H12GlobalWitnessIndex.good

theorem leafIdentity58760 : H12AffineFastState.composeSystem env58760 rootObs = leafEnv58760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58760 rootObs == leafEnv58760) = true)

theorem terminalChecked58760 : H12PackedTerminal.terminalCheckFast leafEnv58760 active58760 tree58760 = true := by decide +kernel

def env58761 : List Nat := [2,4,8,16,1,16,25,20,27,4,1,0,8,0,16,9,0,11,5,16,0,0,17,19,25,16,1,0,0,10,14,10,20,11,1,26]

theorem envBound58761 : H12AffineFastState.Bounded env58761 := by
  intro p hp
  have h : env58761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58755_58761 : H12AffineEnvironment.transform 4 1 env58755 = env58761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env58755 == env58761) = true)

theorem identity58761 : scanCanonicalize (H12AffineFastState.compose env58761 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58761 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58762 : List Nat := [1,4,8,16,1,16,25,20,24,4,1,0,8,0,16,9,0,8,5,16,0,0,17,16,25,16,1,0,0,9,13,9,20,8,1,25]

theorem envBound58762 : H12AffineFastState.Bounded env58762 := by
  intro p hp
  have h : env58762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58761_58762 : H12AffineEnvironment.transform 0 1 env58761 = env58762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58761 == env58762) = true)

def env58763 : List Nat := [1,4,8,0,1,0,9,4,8,4,1,0,8,0,0,9,0,8,5,0,0,0,1,0,9,0,1,0,0,9,13,9,4,8,1,9]

theorem envBound58763 : H12AffineFastState.Bounded env58763 := by
  intro p hp
  have h : env58763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58762_58763 : H12AffineEnvironment.transform 3 0 env58762 = env58763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env58762 == env58763) = true)

theorem identity58763 : scanCanonicalize (H12AffineFastState.compose env58763 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound58763 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58764 : List Nat := [1,4,1,0,1,0,0,4,1,4,1,0,1,0,0,0,0,1,5,0,0,0,1,0,0,0,1,0,0,0,4,0,4,1,1,0]

theorem envBound58764 : H12AffineFastState.Bounded env58764 := by
  intro p hp
  have h : env58764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58763_58764 : H12AffineEnvironment.transform 2 1 env58763 = env58764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env58763 == env58764) = true)

def leafEnv58764 : List Nat := [1,4,1,0,1,0,0,4,1,4,1,0,1,0,0,0,0,1,5,0,0,0,1,0,4,0,1,0,1,0,0,0,4,0,4,1,5,1,1,0,1,0,0]

def active58764 : List Nat := [1]

def tree58764 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58764 : H12WitnessSearch.Good tree58764 := H12GlobalWitnessIndex.good

theorem leafIdentity58764 : H12AffineFastState.composeSystem env58764 rootObs = leafEnv58764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58764 rootObs == leafEnv58764) = true)

theorem terminalChecked58764 : H12PackedTerminal.terminalCheckFast leafEnv58764 active58764 tree58764 = true := by decide +kernel

def env58765 : List Nat := [1,4,8,1,1,1,8,5,9,4,1,0,8,0,1,9,0,8,5,1,0,0,0,1,8,1,1,0,0,9,13,9,5,8,1,8]

theorem envBound58765 : H12AffineFastState.Bounded env58765 := by
  intro p hp
  have h : env58765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58762_58765 : H12AffineEnvironment.transform 3 1 env58762 = env58765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env58762 == env58765) = true)

def env58766 : List Nat := [2,4,8,16,32,16,57,21,27,37,33,32,8,32,17,41,32,11,36,17,32,33,17,51,57,16,33,32,32,10,46,11,21,10,33,26]

theorem envBound58766 : H12AffineFastState.Bounded env58766 := by
  intro p hp
  have h : env58766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58754_58766 : H12AffineEnvironment.transform 6 57 env58754 = env58766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env58754 == env58766) = true)

theorem identity58766 : scanCanonicalize (H12AffineFastState.compose env58766 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58766 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58767 : List Nat := [2,4,8,10,32,10,35,15,1,37,33,32,8,32,11,41,32,11,36,11,32,33,11,41,35,10,33,32,32,10,46,11,15,10,33,0]

theorem envBound58767 : H12AffineFastState.Bounded env58767 := by
  intro p hp
  have h : env58767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58766_58767 : H12AffineEnvironment.transform 3 10 env58766 = env58767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58766 == env58767) = true)

theorem identity58767 : scanCanonicalize (H12AffineFastState.compose env58767 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58767 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58768 : List Nat := [2,4,0,2,32,2,35,7,1,37,33,32,0,32,3,33,32,3,36,3,32,33,3,33,35,2,33,32,32,2,38,3,7,2,33,0]

theorem envBound58768 : H12AffineFastState.Bounded env58768 := by
  intro p hp
  have h : env58768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58767_58768 : H12AffineEnvironment.transform 2 0 env58767 = env58768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58767 == env58768) = true)

theorem identity58768 : scanCanonicalize (H12AffineFastState.compose env58768 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound58768 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58769 : List Nat := [2,4,0,2,3,2,0,7,1,6,2,3,0,3,3,2,3,3,7,3,3,2,3,2,0,2,2,3,3,2,5,3,7,2,2,0]

theorem envBound58769 : H12AffineFastState.Bounded env58769 := by
  intro p hp
  have h : env58769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58768_58769 : H12AffineEnvironment.transform 4 3 env58768 = env58769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env58768 == env58769) = true)

def leafEnv58769 : List Nat := [2,4,0,2,3,2,0,7,1,6,2,3,0,3,3,2,3,3,7,3,3,2,3,2,5,0,1,2,2,3,3,2,5,3,7,2,5,2,2,0,1,3,0]

def active58769 : List Nat := [0,1]

def tree58769 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58769 : H12WitnessSearch.Good tree58769 := H12GlobalWitnessIndex.good

theorem leafIdentity58769 : H12AffineFastState.composeSystem env58769 rootObs = leafEnv58769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58769 rootObs == leafEnv58769) = true)

theorem terminalChecked58769 : H12PackedTerminal.terminalCheckFast leafEnv58769 active58769 tree58769 = true := by decide +kernel

def env58770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955334,33554432,67108864,134217728,16385,76174416,80317658,8463814,4294967296,525569,4366311741,34359738368,33563273]

theorem envBound58770 : H12AffineFastState.Bounded env58770 := by
  intro p hp
  have h : env58770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56761_58770 : H12AffineEnvironment.transform 27 16385 env56761 = env58770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env56761 == env58770) = true)

def env58771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955334,33554432,8409088,134217728,16385,656464,4840666,8463814,4294967296,525569,4307611965,34359738368,33563273]

theorem envBound58771 : H12AffineFastState.Bounded env58771 := by
  intro p hp
  have h : env58771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58770_58771 : H12AffineEnvironment.transform 25 8409088 env58770 = env58771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8409088 env58770 == env58771) = true)

def env58772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16385,131152,4315354,8463814,4294967296,257,4307611965,34359738368,33563273]

theorem envBound58772 : H12AffineFastState.Bounded env58772 := by
  intro p hp
  have h : env58772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58771_58772 : H12AffineEnvironment.transform 18 1024 env58771 = env58772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env58771 == env58772) = true)

def env58773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16385,131152,4315354,8463814,4294967296,257,4307611965,131072,33563273]

theorem envBound58773 : H12AffineFastState.Bounded env58773 := by
  intro p hp
  have h : env58773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58772_58773 : H12AffineEnvironment.transform 34 131072 env58772 = env58773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env58772 == env58773) = true)

theorem identity58773 : scanCanonicalize (H12AffineFastState.compose env58773 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 149382611) := by decide +kernel

theorem selectedBound58773 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16385,131152,4315354,8463814,149382611,257,136811758,131072,33563273]

theorem envBound58774 : H12AffineFastState.Bounded env58774 := by
  intro p hp
  have h : env58774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58773_58774 : H12AffineEnvironment.transform 31 149382611 env58773 = env58774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 149382611 env58773 == env58774) = true)

theorem identity58774 : scanCanonicalize (H12AffineFastState.compose env58774 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound58774 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8388689,134217728,4176,131152,4294795,8463814,149370242,257,136811758,131072,33563273]

theorem envBound58775 : H12AffineFastState.Bounded env58775 := by
  intro p hp
  have h : env58775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58774_58775 : H12AffineEnvironment.transform 13 4177 env58774 = env58775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58774 == env58775) = true)

theorem identity58775 : scanCanonicalize (H12AffineFastState.compose env58775 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound58775 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env58776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,8328,8388689,134217728,4176,131152,4294795,8463814,149370242,257,136811758,131072,513]

theorem envBound58776 : H12AffineFastState.Bounded env58776 := by
  intro p hp
  have h : env58776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58775_58776 : H12AffineEnvironment.transform 24 8328 env58775 = env58776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env58775 == env58776) = true)

theorem identity58776 : scanCanonicalize (H12AffineFastState.compose env58776 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 8724555) := by decide +kernel

theorem selectedBound58776 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,8328,8388689,8724555,4176,131152,4294795,8463814,6428105,257,10663077,131072,513]

theorem envBound58777 : H12AffineFastState.Bounded env58777 := by
  intro p hp
  have h : env58777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58776_58777 : H12AffineEnvironment.transform 26 8724555 env58776 = env58777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8724555 env58776 == env58777) = true)

theorem identity58777 : scanCanonicalize (H12AffineFastState.compose env58777 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound58777 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,4194304,8388608,8430022,8328,8388689,8724555,4176,131152,4294795,8463814,4326856,257,8561828,131072,513]

theorem envBound58778 : H12AffineFastState.Bounded env58778 := by
  intro p hp
  have h : env58778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58777_58778 : H12AffineEnvironment.transform 20 4097 env58777 = env58778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env58777 == env58778) = true)

theorem identity58778 : scanCanonicalize (H12AffineFastState.compose env58778 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4370577) := by decide +kernel

theorem selectedBound58778 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,4194304,4370577,4329815,8328,4370624,4690138,4176,131152,4294795,4429143,4326856,257,4199477,131072,513]

theorem envBound58779 : H12AffineFastState.Bounded env58779 := by
  intro p hp
  have h : env58779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58778_58779 : H12AffineEnvironment.transform 22 4370577 env58778 = env58779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4370577 env58778 == env58779) = true)

theorem identity58779 : scanCanonicalize (H12AffineFastState.compose env58779 (packedSelected [6,25] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound58779 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,397,176412,135386,8328,176461,495959,4176,131152,100614,234714,132165,257,5560,131072,513]

theorem envBound58780 : H12AffineFastState.Bounded env58780 := by
  intro p hp
  have h : env58780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58779_58780 : H12AffineEnvironment.transform 21 397 env58779 = env58780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env58779 == env58780) = true)

theorem identity58780 : scanCanonicalize (H12AffineFastState.compose env58780 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound58780 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env58781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,65536,131072,262144,1024,8461,4097,397,135185,135386,8328,135232,471130,4176,131152,75787,210391,132165,257,5560,131072,513]

theorem envBound58781 : H12AffineFastState.Bounded env58781 := by
  intro p hp
  have h : env58781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58780_58781 : H12AffineEnvironment.transform 14 8461 env58780 = env58781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env58780 == env58781) = true)

theorem identity58781 : scanCanonicalize (H12AffineFastState.compose env58781 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 13422) := by decide +kernel

theorem selectedBound58781 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env58782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,13422,131072,262144,1024,8461,4097,397,135185,135386,8328,135232,394292,4176,131152,7269,131513,132165,257,5560,131072,513]

theorem envBound58782 : H12AffineFastState.Bounded env58782 := by
  intro p hp
  have h : env58782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58781_58782 : H12AffineEnvironment.transform 15 13422 env58781 = env58782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13422 env58781 == env58782) = true)

theorem identity58782 : scanCanonicalize (H12AffineFastState.compose env58782 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 7268) := by decide +kernel

theorem selectedBound58782 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env58783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,13422,131072,7268,1024,8461,4097,397,135185,135386,8328,135232,137296,4176,131152,7269,131513,132165,257,5560,131072,513]

theorem envBound58783 : H12AffineFastState.Bounded env58783 := by
  intro p hp
  have h : env58783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58782_58783 : H12AffineEnvironment.transform 17 7268 env58782 = env58783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7268 env58782 == env58783) = true)

theorem identity58783 : scanCanonicalize (H12AffineFastState.compose env58783 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58783 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env58784 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4177,8353,13422,131072,7268,1024,8353,4097,33,135185,135386,8328,135232,137296,4176,131152,7269,131093,132165,173,5140,131072,513]

theorem envBound58784 : H12AffineFastState.Bounded env58784 := by
  intro p hp
  have h : env58784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58783_58784 : H12AffineEnvironment.transform 7 172 env58783 = env58784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58783 == env58784) = true)

theorem identity58784 : scanCanonicalize (H12AffineFastState.compose env58784 (packedSelected [0,3,7,8,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 4176) := by decide +kernel

theorem selectedBound58784 : packedSelected [0,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env58785 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4177,8353,13422,4176,7268,1024,8353,4097,33,65,138,8328,16,2048,4176,4096,7269,4165,5141,173,5140,4176,513]

theorem envBound58785 : H12AffineFastState.Bounded env58785 := by
  intro p hp
  have h : env58785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58784_58785 : H12AffineEnvironment.transform 16 4176 env58784 = env58785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4176 env58784 == env58785) = true)

theorem identity58785 : scanCanonicalize (H12AffineFastState.compose env58785 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58785 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58786 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,4097,8353,13374,4096,7220,1024,8353,4097,33,17,138,8328,16,2048,4096,4096,7221,4117,5141,173,5140,4096,513]

theorem envBound58786 : H12AffineFastState.Bounded env58786 := by
  intro p hp
  have h : env58786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58785_58786 : H12AffineEnvironment.transform 5 16 env58785 = env58786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58785 == env58786) = true)

theorem identity58786 : scanCanonicalize (H12AffineFastState.compose env58786 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound58786 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env58787 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8,4097,169,5174,4096,7220,1024,169,4097,33,17,138,128,16,2048,4096,4096,7221,4117,5141,173,5140,4096,513]

theorem envBound58787 : H12AffineFastState.Bounded env58787 := by
  intro p hp
  have h : env58787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58786_58787 : H12AffineEnvironment.transform 12 8 env58786 = env58787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env58786 == env58787) = true)

theorem identity58787 : scanCanonicalize (H12AffineFastState.compose env58787 (packedSelected [0,1,4] rootPS)) = affineNative (2^(11+1) ^^^ 665) := by decide +kernel

theorem selectedBound58787 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58788 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,665,8,664,169,1711,665,3757,1024,169,664,33,17,138,128,16,2048,665,665,3756,652,1676,173,1677,665,513]

theorem envBound58788 : H12AffineFastState.Bounded env58788 := by
  intro p hp
  have h : env58788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58787_58788 : H12AffineEnvironment.transform 11 665 env58787 = env58788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 665 env58787 == env58788) = true)

theorem identity58788 : scanCanonicalize (H12AffineFastState.compose env58788 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound58788 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env58789 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1213,665,8,664,169,1711,665,528,1024,169,664,33,17,138,128,16,1213,665,665,529,652,1676,173,1677,665,513]

theorem envBound58789 : H12AffineFastState.Bounded env58789 := by
  intro p hp
  have h : env58789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58788_58789 : H12AffineEnvironment.transform 10 1213 env58788 = env58789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env58788 == env58789) = true)

theorem identity58789 : scanCanonicalize (H12AffineFastState.compose env58789 (packedSelected [1,2,10] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound58789 : packedSelected [1,2,10] rootPS < 2^1333 := by decide +kernel

def env58790 : List Nat := [2,4,8,16,32,16,128,172,512,549,664,665,8,664,169,138,665,528,549,169,664,33,17,138,128,16,664,665,665,529,652,169,173,168,665,513]

theorem envBound58790 : H12AffineFastState.Bounded env58790 := by
  intro p hp
  have h : env58790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58789_58790 : H12AffineEnvironment.transform 9 549 env58789 = env58790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env58789 == env58790) = true)

theorem identity58790 : scanCanonicalize (H12AffineFastState.compose env58790 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound58790 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58791 : List Nat := [2,4,8,16,32,16,128,172,43,14,179,178,8,179,169,138,178,59,14,169,179,33,17,138,128,16,179,178,178,58,167,169,173,168,178,42]

theorem envBound58791 : H12AffineFastState.Bounded env58791 := by
  intro p hp
  have h : env58791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58790_58791 : H12AffineEnvironment.transform 8 43 env58790 = env58791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env58790 == env58791) = true)

theorem identity58791 : scanCanonicalize (H12AffineFastState.compose env58791 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58791 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58792 : List Nat := [2,4,8,10,32,10,128,172,43,14,169,168,8,169,169,138,168,33,14,169,169,33,11,138,128,10,169,168,168,32,167,169,173,168,168,42]

theorem envBound58792 : H12AffineFastState.Bounded env58792 := by
  intro p hp
  have h : env58792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58791_58792 : H12AffineEnvironment.transform 3 10 env58791 = env58792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58791 == env58792) = true)

theorem identity58792 : scanCanonicalize (H12AffineFastState.compose env58792 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound58792 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58793 : List Nat := [2,4,8,10,2,10,128,142,9,14,139,138,8,139,139,138,138,3,14,139,139,3,11,138,128,10,139,138,138,2,133,139,143,138,138,8]

theorem envBound58793 : H12AffineFastState.Bounded env58793 := by
  intro p hp
  have h : env58793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58792_58793 : H12AffineEnvironment.transform 4 2 env58792 = env58793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env58792 == env58793) = true)

theorem identity58793 : scanCanonicalize (H12AffineFastState.compose env58793 (packedSelected [13] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58793 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env58794 : List Nat := [2,4,0,2,2,2,128,134,1,6,131,130,0,131,131,130,130,3,6,131,131,3,3,130,128,2,131,130,130,2,133,131,135,130,130,0]

theorem envBound58794 : H12AffineFastState.Bounded env58794 := by
  intro p hp
  have h : env58794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58793_58794 : H12AffineEnvironment.transform 2 0 env58793 = env58794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58793 == env58794) = true)

def leafEnv58794 : List Nat := [2,4,0,2,2,2,128,134,1,6,131,130,0,131,131,130,130,3,6,131,131,3,3,130,132,128,1,2,131,130,130,2,133,131,135,130,4,2,130,0,1,131,0]

def active58794 : List Nat := [0,1,6]

def tree58794 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58794 : H12WitnessSearch.Good tree58794 := H12GlobalWitnessIndex.good

theorem leafIdentity58794 : H12AffineFastState.composeSystem env58794 rootObs = leafEnv58794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58794 rootObs == leafEnv58794) = true)

theorem terminalChecked58794 : H12PackedTerminal.terminalCheckFast leafEnv58794 active58794 tree58794 = true := by decide +kernel

def env58795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16385,131152,4315354,8463814,4294967296,257,4307611965,131073,33563273]

theorem envBound58795 : H12AffineFastState.Bounded env58795 := by
  intro p hp
  have h : env58795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58772_58795 : H12AffineEnvironment.transform 34 131073 env58772 = env58795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env58772 == env58795) = true)

theorem identity58795 : scanCanonicalize (H12AffineFastState.compose env58795 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 147289554) := by decide +kernel

theorem selectedBound58795 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16385,131152,4315354,8463814,147289554,257,134710511,131073,33563273]

theorem envBound58796 : H12AffineFastState.Bounded env58796 := by
  intro p hp
  have h : env58796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58795_58796 : H12AffineEnvironment.transform 31 147289554 env58795 = env58796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 147289554 env58795 == env58796) = true)

theorem identity58796 : scanCanonicalize (H12AffineFastState.compose env58796 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12919238) := by decide +kernel

theorem selectedBound58796 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,33554432,8409088,12919238,16385,131152,4315354,8463814,152596,257,12756265,131073,33563273]

theorem envBound58797 : H12AffineFastState.Bounded env58797 := by
  intro p hp
  have h : env58797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58796_58797 : H12AffineEnvironment.transform 26 12919238 env58796 = env58797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12919238 env58796 == env58797) = true)

theorem identity58797 : scanCanonicalize (H12AffineFastState.compose env58797 (packedSelected [6,13,17,21,25,33] rootPS)) = affineNative (2^(24+1) ^^^ 28889) := by decide +kernel

theorem selectedBound58797 : packedSelected [6,13,17,21,25,33] rootPS < 2^1333 := by decide +kernel

def env58798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,28889,8409088,12919238,16385,131152,4315354,8463814,152596,257,12756265,131073,21072]

theorem envBound58798 : H12AffineFastState.Bounded env58798 := by
  intro p hp
  have h : env58798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58797_58798 : H12AffineEnvironment.transform 24 28889 env58797 = env58798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 28889 env58797 == env58798) = true)

def env58799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,8329,8388688,12919238,4177,131152,4294794,8463814,132164,257,12756265,131073,512]

theorem envBound58799 : H12AffineFastState.Bounded env58799 := by
  intro p hp
  have h : env58799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58798_58799 : H12AffineEnvironment.transform 13 4176 env58798 = env58799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env58798 == env58799) = true)

theorem identity58799 : scanCanonicalize (H12AffineFastState.compose env58799 (packedSelected [4,9,16] rootPS)) = affineNative (2^(16+1) ^^^ 78035) := by decide +kernel

theorem selectedBound58799 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,4194304,8388608,8430022,8329,8388688,12919238,4177,77955,4294794,8463814,78999,257,12686842,78034,512]

theorem envBound58800 : H12AffineFastState.Bounded env58800 := by
  intro p hp
  have h : env58800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58799_58800 : H12AffineEnvironment.transform 16 78035 env58799 = env58800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78035 env58799 == env58800) = true)

theorem identity58800 : scanCanonicalize (H12AffineFastState.compose env58800 (packedSelected [13,21] rootPS)) = affineNative (2^(22+1) ^^^ 4240769) := by decide +kernel

theorem selectedBound58800 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,4194304,4240769,4199495,8329,4240849,365639,4177,77955,4294794,4296775,78999,257,73851,78034,512]

theorem envBound58801 : H12AffineFastState.Bounded env58801 := by
  intro p hp
  have h : env58801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58800_58801 : H12AffineEnvironment.transform 22 4240769 env58800 = env58801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240769 env58800 == env58801) = true)

theorem identity58801 : scanCanonicalize (H12AffineFastState.compose env58801 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound58801 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env58802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78035,262144,1024,32768,2097152,33,46496,5222,8329,46576,365639,4177,77955,100523,102502,78999,257,73851,78034,512]

theorem envBound58802 : H12AffineFastState.Bounded env58802 := by
  intro p hp
  have h : env58802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58801_58802 : H12AffineEnvironment.transform 21 33 env58801 = env58802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env58801 == env58802) = true)

def env58803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,32768,65536,74815,262144,1024,32768,2097152,33,41292,138,8329,41244,360619,1213,74863,100523,99466,73851,257,73851,74814,512]

theorem envBound58803 : H12AffineFastState.Bounded env58803 := by
  intro p hp
  have h : env58803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58802_58803 : H12AffineEnvironment.transform 11 1260 env58802 = env58803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env58802 == env58803) = true)

theorem identity58803 : scanCanonicalize (H12AffineFastState.compose env58803 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 75547) := by decide +kernel

theorem selectedBound58803 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env58804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,32768,65536,74815,262144,1024,32768,75547,33,41292,138,8329,41244,360619,1213,74863,100523,99466,73851,257,73851,74814,512]

theorem envBound58804 : H12AffineFastState.Bounded env58804 := by
  intro p hp
  have h : env58804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58803_58804 : H12AffineEnvironment.transform 20 75547 env58803 = env58804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 75547 env58803 == env58804) = true)

theorem identity58804 : scanCanonicalize (H12AffineFastState.compose env58804 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 100522) := by decide +kernel

theorem selectedBound58804 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env58805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,32768,65536,74815,100522,1024,32768,75547,33,41292,138,8329,41244,2049,1213,74863,100523,99466,73851,257,73851,74814,512]

theorem envBound58805 : H12AffineFastState.Bounded env58805 := by
  intro p hp
  have h : env58805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58804_58805 : H12AffineEnvironment.transform 17 100522 env58804 = env58805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100522 env58804 == env58805) = true)

theorem identity58805 : scanCanonicalize (H12AffineFastState.compose env58805 (packedSelected [0,1,3,7,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound58805 : packedSelected [0,1,3,7,12,15] rootPS < 2^1333 := by decide +kernel

def env58806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1212,1,65536,74815,67755,1024,1,75547,33,8525,138,8329,8477,2049,1213,74863,67754,66699,73851,257,73851,74814,512]

theorem envBound58806 : H12AffineFastState.Bounded env58806 := by
  intro p hp
  have h : env58806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58805_58806 : H12AffineEnvironment.transform 14 1 env58805 = env58806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env58805 == env58806) = true)

def env58807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,32768,65536,74814,262144,1024,32768,2097152,33,41293,139,8329,41245,360618,1212,74862,100523,99467,73850,257,73851,74815,512]

theorem envBound58807 : H12AffineFastState.Bounded env58807 := by
  intro p hp
  have h : env58807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58802_58807 : H12AffineEnvironment.transform 11 1261 env58802 = env58807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1261 env58802 == env58807) = true)

theorem identity58807 : scanCanonicalize (H12AffineFastState.compose env58807 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 265917) := by decide +kernel

theorem selectedBound58807 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env58808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,32768,65536,74814,262144,1024,32768,265917,33,41293,139,8329,41245,360618,1212,74862,100523,99467,73850,257,73851,74815,512]

theorem envBound58808 : H12AffineFastState.Bounded env58808 := by
  intro p hp
  have h : env58808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58807_58808 : H12AffineEnvironment.transform 20 265917 env58807 = env58808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 265917 env58807 == env58808) = true)

theorem identity58808 : scanCanonicalize (H12AffineFastState.compose env58808 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound58808 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env58809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,32768,65536,74814,43048,1024,32768,42645,33,41293,139,8329,41245,75906,1212,74862,100523,99467,73850,257,73851,74815,512]

theorem envBound58809 : H12AffineFastState.Bounded env58809 := by
  intro p hp
  have h : env58809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58808_58809 : H12AffineEnvironment.transform 17 43048 env58808 = env58809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env58808 == env58809) = true)

theorem identity58809 : scanCanonicalize (H12AffineFastState.compose env58809 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound58809 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env58810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,32768,33166,42416,43048,1024,32768,42645,33,41293,139,8329,41245,43276,1212,42464,2341,1285,41460,257,41461,42417,512]

theorem envBound58810 : H12AffineFastState.Bounded env58810 := by
  intro p hp
  have h : env58810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58809_58810 : H12AffineEnvironment.transform 15 33166 env58809 = env58810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env58809 == env58810) = true)

def env58811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,8312,8694,1480,2128,1024,8312,1773,33,309,139,8329,357,2420,1212,1432,2341,1285,396,257,397,1481,512]

theorem envBound58811 : H12AffineFastState.Bounded env58811 := by
  intro p hp
  have h : env58811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58810_58811 : H12AffineEnvironment.transform 14 8312 env58810 = env58811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env58810 == env58811) = true)

theorem identity58811 : scanCanonicalize (H12AffineFastState.compose env58811 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound58811 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,2209,1213,2265,2391,1480,2128,1024,2265,1773,33,309,139,2088,357,2420,1212,1432,2341,1285,396,257,397,1481,512]

theorem envBound58812 : H12AffineFastState.Bounded env58812 := by
  intro p hp
  have h : env58812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58811_58812 : H12AffineEnvironment.transform 12 2209 env58811 = env58812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env58811 == env58812) = true)

def env58813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,8192,1213,8313,8695,1481,2129,1024,8313,1772,33,308,139,8329,356,2421,1212,1433,2341,1285,397,257,396,1480,512]

theorem envBound58813 : H12AffineFastState.Bounded env58813 := by
  intro p hp
  have h : env58813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58810_58813 : H12AffineEnvironment.transform 14 8313 env58810 = env58813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env58810 == env58813) = true)

theorem identity58813 : scanCanonicalize (H12AffineFastState.compose env58813 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2517) := by decide +kernel

theorem selectedBound58813 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1261,2517,1213,2476,2082,1481,2129,1024,2476,1772,33,308,139,2396,356,2421,1212,1433,2341,1285,397,257,396,1480,512]

theorem envBound58814 : H12AffineFastState.Bounded env58814 := by
  intro p hp
  have h : env58814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58813_58814 : H12AffineEnvironment.transform 12 2517 env58813 = env58814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2517 env58813 == env58814) = true)

def env58815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430022,8328,8388689,12919238,4176,131152,4294795,8463814,132165,257,12756265,131073,513]

theorem envBound58815 : H12AffineFastState.Bounded env58815 := by
  intro p hp
  have h : env58815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58798_58815 : H12AffineEnvironment.transform 13 4177 env58798 = env58815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58798 == env58815) = true)

theorem identity58815 : scanCanonicalize (H12AffineFastState.compose env58815 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound58815 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,397,8388608,8430022,8328,8388689,8724555,4176,131152,100614,8463814,132165,257,8561828,131073,513]

theorem envBound58816 : H12AffineFastState.Bounded env58816 := by
  intro p hp
  have h : env58816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58815_58816 : H12AffineEnvironment.transform 21 397 env58815 = env58816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env58815 == env58816) = true)

theorem identity58816 : scanCanonicalize (H12AffineFastState.compose env58816 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound58816 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,397,8388608,8430022,8328,8388689,8724555,4176,131152,100614,8463814,132165,257,8561828,131073,513]

theorem envBound58817 : H12AffineFastState.Bounded env58817 := by
  intro p hp
  have h : env58817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58816_58817 : H12AffineEnvironment.transform 20 4097 env58816 = env58817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env58816 == env58817) = true)

theorem identity58817 : scanCanonicalize (H12AffineFastState.compose env58817 (packedSelected [13,21] rootPS)) = affineNative (2^(22+1) ^^^ 176412) := by decide +kernel

theorem selectedBound58817 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,397,176412,135386,8328,176461,495959,4176,131152,100614,234714,132165,257,5560,131073,513]

theorem envBound58818 : H12AffineFastState.Bounded env58818 := by
  intro p hp
  have h : env58818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58817_58818 : H12AffineEnvironment.transform 22 176412 env58817 = env58818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 176412 env58817 == env58818) = true)

theorem identity58818 : scanCanonicalize (H12AffineFastState.compose env58818 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound58818 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env58819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,65536,131072,262144,1024,8460,4097,397,135184,135386,8328,135233,471131,4176,131152,75786,210390,132165,257,5560,131073,513]

theorem envBound58819 : H12AffineFastState.Bounded env58819 := by
  intro p hp
  have h : env58819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58818_58819 : H12AffineEnvironment.transform 14 8460 env58818 = env58819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env58818 == env58819) = true)

theorem identity58819 : scanCanonicalize (H12AffineFastState.compose env58819 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 13423) := by decide +kernel

theorem selectedBound58819 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env58820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,13423,131072,262144,1024,8460,4097,397,135184,135386,8328,135233,394292,4176,131152,7269,131513,132165,257,5560,131073,513]

theorem envBound58820 : H12AffineFastState.Bounded env58820 := by
  intro p hp
  have h : env58820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58819_58820 : H12AffineEnvironment.transform 15 13423 env58819 = env58820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13423 env58819 == env58820) = true)

theorem identity58820 : scanCanonicalize (H12AffineFastState.compose env58820 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 134197) := by decide +kernel

theorem selectedBound58820 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env58821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,13423,131072,134197,1024,8460,4097,397,135184,135386,8328,135233,2049,4176,131152,7269,131513,132165,257,5560,131073,513]

theorem envBound58821 : H12AffineFastState.Bounded env58821 := by
  intro p hp
  have h : env58821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58820_58821 : H12AffineEnvironment.transform 17 134197 env58820 = env58821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 134197 env58820 == env58821) = true)

theorem identity58821 : scanCanonicalize (H12AffineFastState.compose env58821 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58821 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env58822 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4177,8352,13423,131072,134197,1024,8352,4097,33,135184,135386,8328,135233,2049,4176,131152,7269,131093,132165,173,5140,131073,513]

theorem envBound58822 : H12AffineFastState.Bounded env58822 := by
  intro p hp
  have h : env58822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58821_58822 : H12AffineEnvironment.transform 7 172 env58821 = env58822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58821 == env58822) = true)

theorem identity58822 : scanCanonicalize (H12AffineFastState.compose env58822 (packedSelected [0,2,3,6,7,8,10,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2267) := by decide +kernel

theorem selectedBound58822 : packedSelected [0,2,3,6,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env58823 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,2267,4177,2171,7348,131072,134197,1024,2171,4097,33,135184,135386,2131,135233,2049,4176,131152,7269,131093,132165,173,5140,131073,513]

theorem envBound58823 : H12AffineFastState.Bounded env58823 := by
  intro p hp
  have h : env58823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58822_58823 : H12AffineEnvironment.transform 12 2267 env58822 = env58823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2267 env58822 == env58823) = true)

theorem identity58823 : scanCanonicalize (H12AffineFastState.compose env58823 (packedSelected [0,2,3,7,8,10,11,15] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound58823 : packedSelected [0,2,3,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env58824 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,2267,4177,2171,7348,4096,7221,1024,2171,4097,33,16,218,2131,65,2049,4176,4176,7269,4117,5189,173,5140,4097,513]

theorem envBound58824 : H12AffineFastState.Bounded env58824 := by
  intro p hp
  have h : env58824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58823_58824 : H12AffineEnvironment.transform 16 4096 env58823 = env58824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env58823 == env58824) = true)

theorem identity58824 : scanCanonicalize (H12AffineFastState.compose env58824 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 211) := by decide +kernel

theorem selectedBound58824 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58825 : List Nat := [2,4,8,16,32,64,128,172,512,1024,211,4096,8,4177,168,5223,4096,5350,1024,168,4097,33,16,218,128,65,210,4176,4176,5302,4117,5189,173,5140,4097,513]

theorem envBound58825 : H12AffineFastState.Bounded env58825 := by
  intro p hp
  have h : env58825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58824_58825 : H12AffineEnvironment.transform 10 211 env58824 = env58825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 211 env58824 == env58825) = true)

theorem identity58825 : scanCanonicalize (H12AffineFastState.compose env58825 (packedSelected [0,1,2,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1070) := by decide +kernel

theorem selectedBound58825 : packedSelected [0,1,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env58826 : List Nat := [2,4,8,16,32,64,128,172,512,1024,211,1070,8,1151,168,73,1070,200,1024,168,1071,33,16,218,128,65,210,1150,1150,152,1083,107,173,58,1071,513]

theorem envBound58826 : H12AffineFastState.Bounded env58826 := by
  intro p hp
  have h : env58826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58825_58826 : H12AffineEnvironment.transform 11 1070 env58825 = env58826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1070 env58825 == env58826) = true)

theorem identity58826 : scanCanonicalize (H12AffineFastState.compose env58826 (packedSelected [4,5,7,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58826 : packedSelected [4,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env58827 : List Nat := [2,4,8,16,32,16,128,172,512,1024,131,1070,8,1071,168,25,1070,152,1024,168,1071,33,16,138,128,17,130,1070,1070,152,1083,59,173,58,1071,513]

theorem envBound58827 : H12AffineFastState.Bounded env58827 := by
  intro p hp
  have h : env58827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58826_58827 : H12AffineEnvironment.transform 5 16 env58826 = env58827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58826 == env58827) = true)

theorem identity58827 : scanCanonicalize (H12AffineFastState.compose env58827 (packedSelected [0,1,4] rootPS)) = affineNative (2^(9+1) ^^^ 182) := by decide +kernel

theorem selectedBound58827 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58828 : List Nat := [2,4,8,16,32,16,128,172,512,182,131,152,8,153,168,25,152,152,182,168,153,33,16,138,128,17,130,152,152,152,141,59,173,58,153,513]

theorem envBound58828 : H12AffineFastState.Bounded env58828 := by
  intro p hp
  have h : env58828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58827_58828 : H12AffineEnvironment.transform 9 182 env58827 = env58828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 182 env58827 == env58828) = true)

theorem identity58828 : scanCanonicalize (H12AffineFastState.compose env58828 (packedSelected [1,2,10] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound58828 : packedSelected [1,2,10] rootPS < 2^1333 := by decide +kernel

def env58829 : List Nat := [2,4,8,16,32,16,128,172,146,182,131,152,8,153,168,25,152,152,182,168,153,33,16,138,128,17,130,152,152,152,141,59,173,58,153,147]

theorem envBound58829 : H12AffineFastState.Bounded env58829 := by
  intro p hp
  have h : env58829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58828_58829 : H12AffineEnvironment.transform 8 146 env58828 = env58829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env58828 == env58829) = true)

def env58830 : List Nat := [2,4,8,16,16,16,128,156,146,134,131,152,8,153,152,25,152,152,134,152,153,17,16,138,128,17,130,152,152,152,141,11,157,10,153,147]

theorem envBound58830 : H12AffineFastState.Bounded env58830 := by
  intro p hp
  have h : env58830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58829_58830 : H12AffineEnvironment.transform 4 16 env58829 = env58830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58829 == env58830) = true)

def env58831 : List Nat := [2,4,8,16,17,16,128,157,146,135,131,152,8,153,153,25,152,152,135,153,153,16,16,138,128,17,130,152,152,152,141,10,156,11,153,147]

theorem envBound58831 : H12AffineFastState.Bounded env58831 := by
  intro p hp
  have h : env58831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58829_58831 : H12AffineEnvironment.transform 4 17 env58829 = env58831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58829 == env58831) = true)

theorem identity58831 : scanCanonicalize (H12AffineFastState.compose env58831 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58831 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58832 : List Nat := [2,4,8,16,17,16,19,14,1,20,16,11,8,10,10,25,11,11,20,10,10,16,16,25,19,17,17,11,11,11,30,10,15,11,10,0]

theorem envBound58832 : H12AffineFastState.Bounded env58832 := by
  intro p hp
  have h : env58832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58831_58832 : H12AffineEnvironment.transform 6 19 env58831 = env58832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58831 == env58832) = true)

theorem identity58832 : scanCanonicalize (H12AffineFastState.compose env58832 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound58832 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58833 : List Nat := [2,4,1,16,17,16,19,7,1,20,16,2,1,3,3,16,2,2,20,3,3,16,16,16,19,17,17,2,2,2,23,3,6,2,3,0]

theorem envBound58833 : H12AffineFastState.Bounded env58833 := by
  intro p hp
  have h : env58833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58832_58833 : H12AffineEnvironment.transform 2 1 env58832 = env58833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env58832 == env58833) = true)

def leafEnv58833 : List Nat := [2,4,1,16,17,16,19,7,1,20,16,2,1,3,3,16,2,2,20,3,3,16,16,16,22,19,1,17,17,2,2,2,23,3,6,2,4,2,3,0,1,2,0]

def active58833 : List Nat := [0,1,3]

def tree58833 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58833 : H12WitnessSearch.Good tree58833 := H12GlobalWitnessIndex.good

theorem leafIdentity58833 : H12AffineFastState.composeSystem env58833 rootObs = leafEnv58833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58833 rootObs == leafEnv58833) = true)

theorem terminalChecked58833 : H12PackedTerminal.terminalCheckFast leafEnv58833 active58833 tree58833 = true := by decide +kernel

def env58834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16385,131153,4315355,8463814,4294967296,256,4307611965,34359738368,33563273]

theorem envBound58834 : H12AffineFastState.Bounded env58834 := by
  intro p hp
  have h : env58834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58771_58834 : H12AffineEnvironment.transform 18 1025 env58771 = env58834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env58771 == env58834) = true)

def env58835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16385,131153,4315355,8463814,4294967296,256,4307611965,131072,33563273]

theorem envBound58835 : H12AffineFastState.Bounded env58835 := by
  intro p hp
  have h : env58835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58834_58835 : H12AffineEnvironment.transform 34 131072 env58834 = env58835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env58834 == env58835) = true)

theorem identity58835 : scanCanonicalize (H12AffineFastState.compose env58835 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 140976339) := by decide +kernel

theorem selectedBound58835 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16385,131153,4315355,8463814,140976339,256,145215982,131072,33563273]

theorem envBound58836 : H12AffineFastState.Bounded env58836 := by
  intro p hp
  have h : env58836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58835_58836 : H12AffineEnvironment.transform 31 140976339 env58835 = env58836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 140976339 env58835 == env58836) = true)

theorem identity58836 : scanCanonicalize (H12AffineFastState.compose env58836 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(16+1) ^^^ 78035) := by decide +kernel

theorem selectedBound58836 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78035,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409088,134217728,16385,77954,4315355,8463814,140775424,256,145023293,78035,33563273]

theorem envBound58837 : H12AffineFastState.Bounded env58837 := by
  intro p hp
  have h : env58837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58836_58837 : H12AffineEnvironment.transform 16 78035 env58836 = env58837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78035 env58836 == env58837) = true)

def env58838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2640,65536,78035,262144,1025,2640,2097152,4194304,8388608,8399767,33554432,8409088,134217728,16385,77954,4280971,8463814,140775424,256,144993133,78035,33563273]

theorem envBound58838 : H12AffineFastState.Bounded env58838 := by
  intro p hp
  have h : env58838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58837_58838 : H12AffineEnvironment.transform 14 2640 env58837 = env58838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2640 env58837 == env58838) = true)

def env58839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2640,65536,78035,262144,1025,2640,2097152,4194304,8388608,8399767,8328,8409088,134217728,16385,77954,4280971,8463814,140775424,256,144993133,78035,513]

theorem envBound58839 : H12AffineFastState.Bounded env58839 := by
  intro p hp
  have h : env58839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58838_58839 : H12AffineEnvironment.transform 24 8328 env58838 = env58839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env58838 == env58839) = true)

end H12CloudChart1