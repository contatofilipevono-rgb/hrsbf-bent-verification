import H12CloudChart1Data031

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity7931 : scanCanonicalize (H12AffineFastState.compose env7931 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound7931 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7932 : List Nat := [2,4,8,16,26,11,128,31,512,151,522,665,154,513,1,139,523,642,30,1,648,26,11,24,19,17,523,664,523,529,4,0,150,1,512,659]

theorem envBound7932 : H12AffineFastState.Bounded env7932 := by
  intro p hp
  have h : env7932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7931_7932 : H12AffineEnvironment.transform 10 522 env7931 = env7932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env7931 == env7932) = true)

theorem identity7932 : scanCanonicalize (H12AffineFastState.compose env7932 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound7932 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env7933 : List Nat := [2,4,8,16,26,11,19,31,512,4,522,522,9,513,1,24,523,529,30,1,539,26,11,24,19,17,523,523,523,529,4,0,5,1,512,512]

theorem envBound7933 : H12AffineFastState.Bounded env7933 := by
  intro p hp
  have h : env7933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7932_7933 : H12AffineEnvironment.transform 6 19 env7932 = env7933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env7932 == env7933) = true)

theorem identity7933 : scanCanonicalize (H12AffineFastState.compose env7933 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound7933 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7934 : List Nat := [2,4,8,16,26,11,19,31,26,4,16,16,9,27,1,24,17,11,30,1,1,26,11,24,19,17,17,17,17,11,4,0,5,1,26,26]

theorem envBound7934 : H12AffineFastState.Bounded env7934 := by
  intro p hp
  have h : env7934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7933_7934 : H12AffineEnvironment.transform 8 26 env7933 = env7934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env7933 == env7934) = true)

def leafEnv7934 : List Nat := [2,4,8,16,26,11,19,31,26,4,16,16,9,27,1,24,17,11,30,1,1,26,11,24,30,19,1,17,17,17,17,11,4,0,5,1,30,3,26,26,1,1,0]

def active7934 : List Nat := [0,1,2,3]

def tree7934 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7934 : H12WitnessSearch.Good tree7934 := H12GlobalWitnessIndex.good

theorem leafIdentity7934 : H12AffineFastState.composeSystem env7934 rootObs = leafEnv7934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7934 rootObs == leafEnv7934) = true)

theorem terminalChecked7934 : H12PackedTerminal.terminalCheckFast leafEnv7934 active7934 tree7934 = true := by decide +kernel

def env7935 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,65536,4265,262144,4813,8352,360046,32,5748,16777216,8329,16855680,17114157,16856229,16856077,76967,4,74887,5784,74887,17058822,16777866]

theorem envBound7935 : H12AffineFastState.Bounded env7935 := by
  intro p hp
  have h : env7935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7921_7935 : H12AffineEnvironment.transform 7 85 env7921 = env7935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7921 == env7935) = true)

theorem identity7935 : scanCanonicalize (H12AffineFastState.compose env7935 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound7935 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7936 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4709,8200,360046,32,5748,16777216,8225,16855592,17114157,16856077,16856077,76815,4,74799,5680,74799,17058822,16777762]

theorem envBound7936 : H12AffineFastState.Bounded env7936 := by
  intro p hp
  have h : env7936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7935_7936 : H12AffineEnvironment.transform 6 40 env7935 = env7936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7935 == env7936) = true)

theorem identity7936 : scanCanonicalize (H12AffineFastState.compose env7936 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(23+1) ^^^ 73736) := by decide +kernel

theorem selectedBound7936 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7937 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4709,8200,360046,32,5748,73736,8225,4640,263205,5125,5125,76815,4,74799,5680,74799,355342,74282]

theorem envBound7937 : H12AffineFastState.Bounded env7937 := by
  intro p hp
  have h : env7937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7936_7937 : H12AffineEnvironment.transform 23 73736 env7936 = env7937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73736 env7936 == env7937) = true)

theorem identity7937 : scanCanonicalize (H12AffineFastState.compose env7937 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound7937 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7938 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,8234,4097,262144,4709,8200,286276,32,5748,34,8225,4640,263205,5125,5125,3109,4,1029,5680,1029,281636,512]

theorem envBound7938 : H12AffineFastState.Bounded env7938 := by
  intro p hp
  have h : env7938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7937_7938 : H12AffineEnvironment.transform 15 8234 env7937 = env7938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env7937 == env7938) = true)

theorem identity7938 : scanCanonicalize (H12AffineFastState.compose env7938 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 7781) := by decide +kernel

theorem selectedBound7938 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7939 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,7781,8200,8234,4097,262144,4709,8200,262177,32,5748,34,8225,4640,263205,5125,5125,3109,4,1029,5680,1029,266817,512]

theorem envBound7939 : H12AffineFastState.Bounded env7939 := by
  intro p hp
  have h : env7939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7938_7939 : H12AffineEnvironment.transform 13 7781 env7938 = env7939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7781 env7938 == env7939) = true)

theorem identity7939 : scanCanonicalize (H12AffineFastState.compose env7939 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound7939 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7940 : List Nat := [2,4,8,16,32,64,40,85,512,5,2048,4096,8192,6752,8200,8234,4097,262144,4709,8200,262177,32,4721,34,8225,4640,262176,4096,4096,2080,4,0,4661,0,266817,512]

theorem envBound7940 : H12AffineFastState.Bounded env7940 := by
  intro p hp
  have h : env7940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7939_7940 : H12AffineEnvironment.transform 9 5 env7939 = env7940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env7939 == env7940) = true)

theorem identity7940 : scanCanonicalize (H12AffineFastState.compose env7940 (packedSelected [0,4] rootPS)) = affineNative (2^(17+1) ^^^ 6778) := by decide +kernel

theorem selectedBound7940 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7941 : List Nat := [2,4,8,16,32,64,40,85,512,5,2048,4096,8192,6752,8200,8234,4097,6778,4709,8200,6747,32,4721,34,8225,4640,6746,4096,4096,2080,4,0,4661,0,2107,512]

theorem envBound7941 : H12AffineFastState.Bounded env7941 := by
  intro p hp
  have h : env7941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7940_7941 : H12AffineEnvironment.transform 17 6778 env7940 = env7941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6778 env7940 == env7941) = true)

theorem identity7941 : scanCanonicalize (H12AffineFastState.compose env7941 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound7941 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env7942 : List Nat := [2,4,8,16,32,43,40,62,512,5,2048,4096,8192,6667,8200,8234,4097,6673,4622,8200,6704,32,4634,34,8225,4640,6705,4096,4096,2080,4,0,4661,0,2107,512]

theorem envBound7942 : H12AffineFastState.Bounded env7942 := by
  intro p hp
  have h : env7942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7941_7942 : H12AffineEnvironment.transform 5 43 env7941 = env7942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env7941 == env7942) = true)

def env7943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5016,8693,2097152,33,5748,16777216,8329,16856021,17114156,16856229,16856408,76966,4,75218,5784,74886,18953020,16778207]

theorem envBound7943 : H12AffineFastState.Bounded env7943 := by
  intro p hp
  have h : env7943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7919_7943 : H12AffineEnvironment.transform 21 33 env7919 = env7943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7919 == env7943) = true)

theorem identity7943 : scanCanonicalize (H12AffineFastState.compose env7943 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 360046) := by decide +kernel

theorem selectedBound7943 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5016,8693,360046,33,5748,16777216,8329,16856021,17114156,16856229,16856408,76966,4,75218,5784,74886,17059154,16778207]

theorem envBound7944 : H12AffineFastState.Bounded env7944 := by
  intro p hp
  have h : env7944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7943_7944 : H12AffineEnvironment.transform 20 360046 env7943 = env7944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 360046 env7943 == env7944) = true)

def env7945 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,65536,4264,262144,4812,8353,360046,33,5748,16777216,8329,16855681,17114156,16856229,16856076,76966,4,74886,5784,74886,17058822,16777867]

theorem envBound7945 : H12AffineFastState.Bounded env7945 := by
  intro p hp
  have h : env7945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7944_7945 : H12AffineEnvironment.transform 7 84 env7944 = env7945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7944 == env7945) = true)

theorem identity7945 : scanCanonicalize (H12AffineFastState.compose env7945 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound7945 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7946 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4709,8200,360046,33,5748,16777216,8224,16855592,17114156,16856076,16856076,76815,4,74799,5681,74799,17058822,16777762]

theorem envBound7946 : H12AffineFastState.Bounded env7946 := by
  intro p hp
  have h : env7946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7945_7946 : H12AffineEnvironment.transform 6 41 env7945 = env7946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7945 == env7946) = true)

theorem identity7946 : scanCanonicalize (H12AffineFastState.compose env7946 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(23+1) ^^^ 73737) := by decide +kernel

theorem selectedBound7946 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7947 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4709,8200,360046,33,5748,73737,8224,4641,263205,5125,5125,76815,4,74799,5681,74799,355343,74283]

theorem envBound7947 : H12AffineFastState.Bounded env7947 := by
  intro p hp
  have h : env7947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7946_7947 : H12AffineEnvironment.transform 23 73737 env7946 = env7947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73737 env7946 == env7947) = true)

theorem identity7947 : scanCanonicalize (H12AffineFastState.compose env7947 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7947 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7948 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,8235,4097,262144,4709,8200,286277,33,5748,34,8224,4641,263205,5125,5125,3108,4,1028,5681,1028,281636,512]

theorem envBound7948 : H12AffineFastState.Bounded env7948 := by
  intro p hp
  have h : env7948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7947_7948 : H12AffineEnvironment.transform 15 8235 env7947 = env7948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7947 == env7948) = true)

theorem identity7948 : scanCanonicalize (H12AffineFastState.compose env7948 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(17+1) ^^^ 24648) := by decide +kernel

theorem selectedBound7948 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7949 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,8235,4097,24648,4709,8200,15885,33,5748,34,8224,4641,25709,5125,5125,3108,4,1028,5681,1028,11372,512]

theorem envBound7949 : H12AffineFastState.Bounded env7949 := by
  intro p hp
  have h : env7949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7948_7949 : H12AffineEnvironment.transform 17 24648 env7948 = env7949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 24648 env7948 == env7949) = true)

theorem identity7949 : scanCanonicalize (H12AffineFastState.compose env7949 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 14937) := by decide +kernel

theorem selectedBound7949 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7950 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,14937,8200,8235,4097,6673,4709,8200,15885,33,5748,34,8224,4641,7732,5125,5125,3108,4,1028,5681,1028,11372,512]

theorem envBound7950 : H12AffineFastState.Bounded env7950 := by
  intro p hp
  have h : env7950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7949_7950 : H12AffineEnvironment.transform 13 14937 env7949 = env7950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14937 env7949 == env7950) = true)

theorem identity7950 : scanCanonicalize (H12AffineFastState.compose env7950 (packedSelected [3,5,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound7950 : packedSelected [3,5,11,13] rootPS < 2^1333 := by decide +kernel

def env7951 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1588,8192,11373,8200,8235,1589,3109,1105,8200,10297,33,64,34,8224,1045,2048,561,561,3108,4,1028,5,1028,11372,512]

theorem envBound7951 : H12AffineFastState.Bounded env7951 := by
  intro p hp
  have h : env7951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7950_7951 : H12AffineEnvironment.transform 11 1588 env7950 = env7951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env7950 == env7951) = true)

theorem identity7951 : scanCanonicalize (H12AffineFastState.compose env7951 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 3164) := by decide +kernel

theorem selectedBound7951 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env7952 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1588,3164,49,3156,3191,1589,3109,1105,3156,1125,33,64,34,3196,1045,2048,561,561,3108,4,1028,5,1028,48,512]

theorem envBound7952 : H12AffineFastState.Bounded env7952 := by
  intro p hp
  have h : env7952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7951_7952 : H12AffineEnvironment.transform 12 3164 env7951 = env7952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3164 env7951 == env7952) = true)

theorem identity7952 : scanCanonicalize (H12AffineFastState.compose env7952 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound7952 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env7953 : List Nat := [2,4,8,16,32,58,41,46,512,1024,2048,1588,3110,49,3118,3085,1589,3109,1067,3118,1055,33,58,34,3078,1045,2048,561,561,3108,4,1028,5,1028,48,512]

theorem envBound7953 : H12AffineFastState.Bounded env7953 := by
  intro p hp
  have h : env7953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7952_7953 : H12AffineEnvironment.transform 5 58 env7952 = env7953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env7952 == env7953) = true)

theorem identity7953 : scanCanonicalize (H12AffineFastState.compose env7953 (packedSelected [0,14] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound7953 : packedSelected [0,14] rootPS < 2^1333 := by decide +kernel

def env7954 : List Nat := [2,4,8,16,32,58,41,46,512,4,2048,560,2082,49,2090,2057,561,2081,47,2090,27,33,58,34,2050,17,2048,561,561,2080,4,0,5,0,48,512]

theorem envBound7954 : H12AffineFastState.Bounded env7954 := by
  intro p hp
  have h : env7954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7953_7954 : H12AffineEnvironment.transform 9 4 env7953 = env7954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env7953 == env7954) = true)

def env7955 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,65536,4265,262144,4813,8352,360046,33,5748,16777216,8329,16855680,17114156,16856229,16856077,76966,4,74887,5784,74886,17058823,16777866]

theorem envBound7955 : H12AffineFastState.Bounded env7955 := by
  intro p hp
  have h : env7955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7944_7955 : H12AffineEnvironment.transform 7 85 env7944 = env7955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7944 == env7955) = true)

theorem identity7955 : scanCanonicalize (H12AffineFastState.compose env7955 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound7955 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7956 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,8234,4265,262144,4813,8352,286276,33,5748,16777216,8329,16781994,17040390,16782479,16782375,3212,4,1197,5784,1196,17058823,16777866]

theorem envBound7956 : H12AffineFastState.Bounded env7956 := by
  intro p hp
  have h : env7956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7955_7956 : H12AffineEnvironment.transform 15 8234 env7955 = env7956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env7955 == env7956) = true)

theorem identity7956 : scanCanonicalize (H12AffineFastState.compose env7956 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 34) := by decide +kernel

theorem selectedBound7956 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7957 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,8234,4265,262144,4813,8352,286276,33,5748,34,8329,4744,263204,5293,5125,3212,4,1197,5784,1196,281637,680]

theorem envBound7957 : H12AffineFastState.Bounded env7957 := by
  intro p hp
  have h : env7957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7956_7957 : H12AffineEnvironment.transform 23 34 env7956 = env7957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 34 env7956 == env7957) = true)

theorem identity7957 : scanCanonicalize (H12AffineFastState.compose env7957 (packedSelected [11,12,13,15,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 7780) := by decide +kernel

theorem selectedBound7957 : packedSelected [11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env7958 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,8234,4265,7780,4813,8352,16416,33,5748,34,8329,4744,6720,5293,5125,3212,4,1197,5784,1196,21057,680]

theorem envBound7958 : H12AffineFastState.Bounded env7958 := by
  intro p hp
  have h : env7958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7957_7958 : H12AffineEnvironment.transform 17 7780 env7957 = env7958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7780 env7957 == env7958) = true)

theorem identity7958 : scanCanonicalize (H12AffineFastState.compose env7958 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound7958 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env7959 : List Nat := [2,4,8,16,32,64,128,85,512,5,2048,4096,8192,16384,8352,8234,4265,6753,4813,8352,16416,33,4721,34,8329,4744,6720,4264,4096,2185,4,168,4765,169,21057,680]

theorem envBound7959 : H12AffineFastState.Bounded env7959 := by
  intro p hp
  have h : env7959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7958_7959 : H12AffineEnvironment.transform 9 5 env7958 = env7959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env7958 == env7959) = true)

theorem identity7959 : scanCanonicalize (H12AffineFastState.compose env7959 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 2275) := by decide +kernel

theorem selectedBound7959 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env7960 : List Nat := [2,4,8,16,32,64,128,85,512,5,2048,4096,8192,2275,8352,8234,4265,6753,4813,8352,2243,33,4721,34,8329,4744,6720,4264,4096,2185,4,168,4765,169,6818,680]

theorem envBound7960 : H12AffineFastState.Bounded env7960 := by
  intro p hp
  have h : env7960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7959_7960 : H12AffineEnvironment.transform 13 2275 env7959 = env7960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2275 env7959 == env7960) = true)

theorem identity7960 : scanCanonicalize (H12AffineFastState.compose env7960 (packedSelected [3,5,6,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 576) := by decide +kernel

theorem selectedBound7960 : packedSelected [3,5,6,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env7961 : List Nat := [2,4,8,16,32,64,128,85,512,5,2048,576,8192,2275,8352,8234,745,2081,141,8352,2243,33,49,34,8329,200,2048,744,576,2185,4,168,221,169,2274,680]

theorem envBound7961 : H12AffineFastState.Bounded env7961 := by
  intro p hp
  have h : env7961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7960_7961 : H12AffineEnvironment.transform 11 576 env7960 = env7961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 576 env7960 == env7961) = true)

theorem identity7961 : scanCanonicalize (H12AffineFastState.compose env7961 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound7961 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env7962 : List Nat := [2,4,8,16,32,64,41,85,512,5,2048,576,8192,2122,8201,8234,576,2081,36,8201,2154,33,49,34,8224,97,2048,577,576,2080,4,1,116,0,2123,513]

theorem envBound7962 : H12AffineFastState.Bounded env7962 := by
  intro p hp
  have h : env7962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7961_7962 : H12AffineEnvironment.transform 6 41 env7961 = env7962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7961 == env7962) = true)

theorem identity7962 : scanCanonicalize (H12AffineFastState.compose env7962 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 546) := by decide +kernel

theorem selectedBound7962 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7963 : List Nat := [2,4,8,16,32,64,41,85,512,5,2048,576,546,2122,555,520,576,2081,36,555,2154,33,49,34,514,97,2048,577,576,2080,4,1,116,0,2123,513]

theorem envBound7963 : H12AffineFastState.Bounded env7963 := by
  intro p hp
  have h : env7963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7962_7963 : H12AffineEnvironment.transform 12 546 env7962 = env7963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 546 env7962 == env7963) = true)

theorem identity7963 : scanCanonicalize (H12AffineFastState.compose env7963 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound7963 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7964 : List Nat := [2,4,8,16,32,64,41,85,32,5,2048,96,2,2122,11,40,96,2081,36,11,2154,33,49,34,34,97,2048,97,96,2080,4,1,116,0,2123,33]

theorem envBound7964 : H12AffineFastState.Bounded env7964 := by
  intro p hp
  have h : env7964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7963_7964 : H12AffineEnvironment.transform 8 32 env7963 = env7964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env7963 == env7964) = true)

theorem identity7964 : scanCanonicalize (H12AffineFastState.compose env7964 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound7964 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7965 : List Nat := [2,4,8,16,32,58,41,47,32,5,2048,26,2,2096,11,40,26,2081,36,11,2064,33,49,34,34,27,2048,27,26,2080,4,1,14,0,2097,33]

theorem envBound7965 : H12AffineFastState.Bounded env7965 := by
  intro p hp
  have h : env7965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7964_7965 : H12AffineEnvironment.transform 5 58 env7964 = env7965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env7964 == env7965) = true)

theorem identity7965 : scanCanonicalize (H12AffineFastState.compose env7965 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 14) := by decide +kernel

theorem selectedBound7965 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7966 : List Nat := [2,4,8,16,32,58,41,47,32,5,14,26,2,62,11,40,26,47,36,11,30,33,49,34,34,27,14,27,26,46,4,1,14,0,63,33]

theorem envBound7966 : H12AffineFastState.Bounded env7966 := by
  intro p hp
  have h : env7966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7965_7966 : H12AffineEnvironment.transform 10 14 env7965 = env7966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 14 env7965 == env7966) = true)

theorem identity7966 : scanCanonicalize (H12AffineFastState.compose env7966 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound7966 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env7967 : List Nat := [2,4,3,16,32,49,34,36,32,5,5,17,2,53,0,35,17,36,36,0,21,33,49,34,34,16,5,16,17,37,4,1,5,0,52,33]

theorem envBound7967 : H12AffineFastState.Bounded env7967 := by
  intro p hp
  have h : env7967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7966_7967 : H12AffineEnvironment.transform 2 3 env7966 = env7967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env7966 == env7967) = true)

def env7968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5017,8693,2097152,4194304,5749,16777216,8329,16856020,21308428,16856228,16856409,4271238,4,75219,5785,4269222,23147292,16778207]

theorem envBound7968 : H12AffineFastState.Bounded env7968 := by
  intro p hp
  have h : env7968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7918_7968 : H12AffineEnvironment.transform 18 5017 env7918 = env7968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5017 env7918 == env7968) = true)

def env7969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5017,8693,2097152,32,5749,16777216,8329,16856020,17114156,16856228,16856409,76966,4,75219,5785,74886,18953020,16778207]

theorem envBound7969 : H12AffineFastState.Bounded env7969 := by
  intro p hp
  have h : env7969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7968_7969 : H12AffineEnvironment.transform 21 32 env7968 = env7969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env7968 == env7969) = true)

theorem identity7969 : scanCanonicalize (H12AffineFastState.compose env7969 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(23+1) ^^^ 2383462) := by decide +kernel

theorem selectedBound7969 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5017,8693,2097152,32,5749,2383462,8329,2452914,2193994,2452162,2452287,76966,4,75219,5785,74886,355674,2383289]

theorem envBound7970 : H12AffineFastState.Bounded env7970 := by
  intro p hp
  have h : env7970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7969_7970 : H12AffineEnvironment.transform 23 2383462 env7969 = env7970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2383462 env7969 == env7970) = true)

def env7971 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,65536,4264,262144,4813,8353,2097152,32,5749,2383462,8329,2452710,2193994,2452162,2452075,76966,4,74887,5785,74886,355342,2383085]

theorem envBound7971 : H12AffineFastState.Bounded env7971 := by
  intro p hp
  have h : env7971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7970_7971 : H12AffineEnvironment.transform 7 84 env7970 = env7971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7970 == env7971) = true)

theorem identity7971 : scanCanonicalize (H12AffineFastState.compose env7971 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound7971 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7972 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,8234,4264,262144,4813,8353,2097152,32,5749,2383462,8329,2378956,2120288,2378472,2378305,3212,4,1197,5785,1196,281636,2383085]

theorem envBound7972 : H12AffineFastState.Bounded env7972 := by
  intro p hp
  have h : env7972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7971_7972 : H12AffineEnvironment.transform 15 8234 env7971 = env7972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env7971 == env7972) = true)

theorem identity7972 : scanCanonicalize (H12AffineFastState.compose env7972 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 286276) := by decide +kernel

theorem selectedBound7972 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7973 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,8234,4264,262144,4813,8353,286276,32,5749,34,8329,4744,263204,5292,5125,3212,4,1197,5785,1196,281636,681]

theorem envBound7973 : H12AffineFastState.Bounded env7973 := by
  intro p hp
  have h : env7973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7972_7973 : H12AffineEnvironment.transform 20 286276 env7972 = env7973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 286276 env7972 == env7973) = true)

theorem identity7973 : scanCanonicalize (H12AffineFastState.compose env7973 (packedSelected [11,12,13,15,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 6856) := by decide +kernel

theorem selectedBound7973 : packedSelected [11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env7974 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,8234,4264,6856,4813,8353,17548,32,5749,34,8329,4744,7916,5292,5125,3212,4,1197,5785,1196,22252,681]

theorem envBound7974 : H12AffineFastState.Bounded env7974 := by
  intro p hp
  have h : env7974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7973_7974 : H12AffineEnvironment.transform 17 6856 env7973 = env7974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6856 env7973 == env7974) = true)

theorem identity7974 : scanCanonicalize (H12AffineFastState.compose env7974 (packedSelected [0,2,3,5,6,9,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 664) := by decide +kernel

theorem selectedBound7974 : packedSelected [0,2,3,5,6,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env7975 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,664,8192,16384,8353,8234,560,2128,85,8353,17548,32,1261,34,8329,16,3188,1588,1693,3212,4,1197,1025,1196,17524,681]

theorem envBound7975 : H12AffineFastState.Bounded env7975 := by
  intro p hp
  have h : env7975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7974_7975 : H12AffineEnvironment.transform 11 664 env7974 = env7975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 664 env7974 == env7975) = true)

theorem identity7975 : scanCanonicalize (H12AffineFastState.compose env7975 (packedSelected [2,3,4,5,6,7,11,13,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound7975 : packedSelected [2,3,4,5,6,7,11,13,14,15] rootPS < 2^1333 := by decide +kernel

def env7976 : List Nat := [2,4,8,16,32,49,128,37,512,1024,2048,664,8192,16384,8353,8234,560,2081,36,8353,17548,32,1180,34,8329,16,3077,1588,1693,3212,4,1197,1025,1196,17413,681]

theorem envBound7976 : H12AffineFastState.Bounded env7976 := by
  intro p hp
  have h : env7976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7975_7976 : H12AffineEnvironment.transform 5 49 env7975 = env7976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7975 == env7976) = true)

theorem identity7976 : scanCanonicalize (H12AffineFastState.compose env7976 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound7976 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env7977 : List Nat := [2,4,8,16,32,49,128,37,512,5,2048,664,8192,16384,8353,8234,560,2081,36,8353,16521,32,153,34,8329,16,2048,561,664,2185,4,168,4,169,16384,681]

theorem envBound7977 : H12AffineFastState.Bounded env7977 := by
  intro p hp
  have h : env7977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7976_7977 : H12AffineEnvironment.transform 9 5 env7976 = env7977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env7976 == env7977) = true)

theorem identity7977 : scanCanonicalize (H12AffineFastState.compose env7977 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 2731) := by decide +kernel

theorem selectedBound7977 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env7978 : List Nat := [2,4,8,16,32,49,128,37,512,5,2048,664,2731,16384,2570,2689,560,2081,36,2570,16521,32,153,34,2594,16,2048,561,664,2185,4,168,4,169,16384,681]

theorem envBound7978 : H12AffineFastState.Bounded env7978 := by
  intro p hp
  have h : env7978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7977_7978 : H12AffineEnvironment.transform 12 2731 env7977 = env7978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2731 env7977 == env7978) = true)

theorem identity7978 : scanCanonicalize (H12AffineFastState.compose env7978 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound7978 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env7979 : List Nat := [2,4,8,16,32,49,128,37,512,5,523,664,160,16384,1,138,560,554,36,1,16521,32,153,34,41,16,523,561,664,642,4,168,4,169,16384,681]

theorem envBound7979 : H12AffineFastState.Bounded env7979 := by
  intro p hp
  have h : env7979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7978_7979 : H12AffineEnvironment.transform 10 523 env7978 = env7979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env7978 == env7979) = true)

theorem identity7979 : scanCanonicalize (H12AffineFastState.compose env7979 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound7979 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env7980 : List Nat := [2,4,8,16,26,11,128,31,512,5,523,664,154,16384,1,138,522,528,30,1,16521,26,153,24,19,16,523,523,664,642,4,146,4,147,16384,659]

theorem envBound7980 : H12AffineFastState.Bounded env7980 := by
  intro p hp
  have h : env7980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7979_7980 : H12AffineEnvironment.transform 4 26 env7979 = env7980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env7979 == env7980) = true)

theorem identity7980 : scanCanonicalize (H12AffineFastState.compose env7980 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound7980 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env7981 : List Nat := [2,4,8,16,26,11,19,31,512,5,523,523,9,16384,1,25,522,528,30,1,16410,26,10,24,19,16,523,523,523,529,4,1,4,0,16384,512]

theorem envBound7981 : H12AffineFastState.Bounded env7981 := by
  intro p hp
  have h : env7981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7980_7981 : H12AffineEnvironment.transform 6 19 env7980 = env7981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env7980 == env7981) = true)

theorem identity7981 : scanCanonicalize (H12AffineFastState.compose env7981 (packedSelected [0,1] rootPS)) = affineNative (2^(13+1) ^^^ 513) := by decide +kernel

theorem selectedBound7981 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7982 : List Nat := [2,4,8,16,26,11,19,31,512,5,523,523,9,513,1,25,522,528,30,1,539,26,10,24,19,16,523,523,523,529,4,1,4,0,513,512]

theorem envBound7982 : H12AffineFastState.Bounded env7982 := by
  intro p hp
  have h : env7982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7981_7982 : H12AffineEnvironment.transform 13 513 env7981 = env7982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 513 env7981 == env7982) = true)

theorem identity7982 : scanCanonicalize (H12AffineFastState.compose env7982 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound7982 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7983 : List Nat := [2,4,8,16,26,11,19,31,26,5,17,17,9,27,1,25,16,10,30,1,1,26,10,24,19,16,17,17,17,11,4,1,4,0,27,26]

theorem envBound7983 : H12AffineFastState.Bounded env7983 := by
  intro p hp
  have h : env7983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7982_7983 : H12AffineEnvironment.transform 8 26 env7982 = env7983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env7982 == env7983) = true)

def leafEnv7983 : List Nat := [2,4,8,16,26,11,19,31,26,5,17,17,9,27,1,25,16,10,30,1,1,26,10,24,31,19,1,16,17,17,17,11,4,1,4,0,31,2,27,26,1,0,0]

def active7983 : List Nat := [0,1,2,3]

def tree7983 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7983 : H12WitnessSearch.Good tree7983 := H12GlobalWitnessIndex.good

theorem leafIdentity7983 : H12AffineFastState.composeSystem env7983 rootObs = leafEnv7983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7983 rootObs == leafEnv7983) = true)

theorem terminalChecked7983 : H12PackedTerminal.terminalCheckFast leafEnv7983 active7983 tree7983 = true := by decide +kernel

def env7984 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,65536,4265,262144,4812,8352,2097152,32,5749,2383462,8329,2452711,2193994,2452162,2452074,76966,4,74886,5785,74886,355343,2383084]

theorem envBound7984 : H12AffineFastState.Bounded env7984 := by
  intro p hp
  have h : env7984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7970_7984 : H12AffineEnvironment.transform 7 85 env7970 = env7984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7970 == env7984) = true)

theorem identity7984 : scanCanonicalize (H12AffineFastState.compose env7984 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound7984 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7985 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4708,8200,2097152,32,5749,2383462,8225,2452559,2193994,2452074,2452074,76814,4,74798,5681,74798,355343,2382916]

theorem envBound7985 : H12AffineFastState.Bounded env7985 := by
  intro p hp
  have h : env7985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7984_7985 : H12AffineEnvironment.transform 6 40 env7984 = env7985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7984 == env7985) = true)

theorem identity7985 : scanCanonicalize (H12AffineFastState.compose env7985 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 360047) := by decide +kernel

theorem selectedBound7985 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7986 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4708,8200,360047,32,5749,73737,8225,4640,263205,5125,5125,76814,4,74798,5681,74798,355343,74283]

theorem envBound7986 : H12AffineFastState.Bounded env7986 := by
  intro p hp
  have h : env7986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7985_7986 : H12AffineEnvironment.transform 20 360047 env7985 = env7986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 360047 env7985 == env7986) = true)

theorem identity7986 : scanCanonicalize (H12AffineFastState.compose env7986 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7986 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7987 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,8235,4097,262144,4708,8200,286276,32,5749,34,8225,4640,263205,5125,5125,3109,4,1029,5681,1029,281636,512]

theorem envBound7987 : H12AffineFastState.Bounded env7987 := by
  intro p hp
  have h : env7987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7986_7987 : H12AffineEnvironment.transform 15 8235 env7986 = env7987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7986 == env7987) = true)

theorem identity7987 : scanCanonicalize (H12AffineFastState.compose env7987 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 2081) := by decide +kernel

theorem selectedBound7987 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7988 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,2081,8200,8235,4097,262144,4708,8200,267877,32,5749,34,8225,4640,263205,5125,5125,3109,4,1029,5681,1029,263173,512]

theorem envBound7988 : H12AffineFastState.Bounded env7988 := by
  intro p hp
  have h : env7988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7987_7988 : H12AffineEnvironment.transform 13 2081 env7987 = env7988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2081 env7987 == env7988) = true)

theorem identity7988 : scanCanonicalize (H12AffineFastState.compose env7988 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound7988 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7989 : List Nat := [2,4,8,16,32,64,40,85,512,4,2048,4096,8192,2081,8200,8235,4097,262144,4708,8200,266849,32,4721,34,8225,4640,262177,4097,4097,2081,4,1,4661,1,262145,512]

theorem envBound7989 : H12AffineFastState.Bounded env7989 := by
  intro p hp
  have h : env7989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7988_7989 : H12AffineEnvironment.transform 9 4 env7988 = env7989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env7988 == env7989) = true)

theorem identity7989 : scanCanonicalize (H12AffineFastState.compose env7989 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(17+1) ^^^ 2107) := by decide +kernel

theorem selectedBound7989 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7990 : List Nat := [2,4,8,16,32,64,40,85,512,4,2048,4096,8192,2081,8200,8235,4097,2107,4708,8200,6746,32,4721,34,8225,4640,2074,4097,4097,2081,4,1,4661,1,2106,512]

theorem envBound7990 : H12AffineFastState.Bounded env7990 := by
  intro p hp
  have h : env7990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7989_7990 : H12AffineEnvironment.transform 17 2107 env7989 = env7990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2107 env7989 == env7990) = true)

def env7991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5017,8693,2097152,33,5749,16777216,8329,16856020,17114157,16856228,16856409,76967,4,75219,5785,74887,18953021,16778207]

theorem envBound7991 : H12AffineFastState.Bounded env7991 := by
  intro p hp
  have h : env7991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7968_7991 : H12AffineEnvironment.transform 21 33 env7968 = env7991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7968 == env7991) = true)

theorem identity7991 : scanCanonicalize (H12AffineFastState.compose env7991 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(23+1) ^^^ 2383667) := by decide +kernel

theorem selectedBound7991 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,5017,8693,2097152,33,5749,2383667,8329,2452711,2194206,2452375,2452074,76967,4,75219,5785,74887,355342,2383084]

theorem envBound7992 : H12AffineFastState.Bounded env7992 := by
  intro p hp
  have h : env7992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7991_7992 : H12AffineEnvironment.transform 23 2383667 env7991 = env7992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2383667 env7991 == env7992) = true)

def env7993 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8353,65536,4264,262144,4813,8353,2097152,33,5749,2383463,8329,2452711,2193994,2452163,2452074,76967,4,74887,5785,74887,355342,2383084]

theorem envBound7993 : H12AffineFastState.Bounded env7993 := by
  intro p hp
  have h : env7993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7992_7993 : H12AffineEnvironment.transform 7 84 env7992 = env7993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7992 == env7993) = true)

theorem identity7993 : scanCanonicalize (H12AffineFastState.compose env7993 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound7993 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7994 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4708,8200,2097152,33,5749,2383463,8224,2452558,2193994,2452074,2452074,76814,4,74798,5680,74798,355342,2382917]

theorem envBound7994 : H12AffineFastState.Bounded env7994 := by
  intro p hp
  have h : env7994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7993_7994 : H12AffineEnvironment.transform 6 41 env7993 = env7994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7993 == env7994) = true)

theorem identity7994 : scanCanonicalize (H12AffineFastState.compose env7994 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 360047) := by decide +kernel

theorem selectedBound7994 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7995 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,4708,8200,360047,33,5749,73736,8224,4641,263205,5125,5125,76814,4,74798,5680,74798,355342,74282]

theorem envBound7995 : H12AffineFastState.Bounded env7995 := by
  intro p hp
  have h : env7995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7994_7995 : H12AffineEnvironment.transform 20 360047 env7994 = env7995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 360047 env7994 == env7995) = true)

theorem identity7995 : scanCanonicalize (H12AffineFastState.compose env7995 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound7995 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7996 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,8234,4097,262144,4708,8200,286277,33,5749,34,8224,4641,263205,5125,5125,3108,4,1028,5680,1028,281636,512]

theorem envBound7996 : H12AffineFastState.Bounded env7996 := by
  intro p hp
  have h : env7996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7995_7996 : H12AffineEnvironment.transform 15 8234 env7995 = env7996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env7995 == env7996) = true)

theorem identity7996 : scanCanonicalize (H12AffineFastState.compose env7996 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(17+1) ^^^ 30221) := by decide +kernel

theorem selectedBound7996 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7997 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,8234,4097,30221,4708,8200,10312,33,5749,34,8224,4641,29224,5125,5125,3108,4,1028,5680,1028,14889,512]

theorem envBound7997 : H12AffineFastState.Bounded env7997 := by
  intro p hp
  have h : env7997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7996_7997 : H12AffineEnvironment.transform 17 30221 env7996 = env7997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30221 env7996 == env7997) = true)

theorem identity7997 : scanCanonicalize (H12AffineFastState.compose env7997 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 10264) := by decide +kernel

theorem selectedBound7997 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7998 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,10264,8200,8234,4097,7701,4708,8200,10312,33,5749,34,8224,4641,6704,5125,5125,3108,4,1028,5680,1028,14889,512]

theorem envBound7998 : H12AffineFastState.Bounded env7998 := by
  intro p hp
  have h : env7998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7997_7998 : H12AffineEnvironment.transform 13 10264 env7997 = env7998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10264 env7997 == env7998) = true)

theorem identity7998 : scanCanonicalize (H12AffineFastState.compose env7998 (packedSelected [0,1,5,7,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound7998 : packedSelected [0,1,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env7999 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,561,8192,10264,8200,8234,560,3108,85,8200,10312,33,1092,34,8224,16,2049,1588,1588,3108,4,1028,1025,1028,10264,512]

theorem envBound7999 : H12AffineFastState.Bounded env7999 := by
  intro p hp
  have h : env7999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7998_7999 : H12AffineEnvironment.transform 11 561 env7998 = env7999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env7998 == env7999) = true)

theorem identity7999 : scanCanonicalize (H12AffineFastState.compose env7999 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 2168) := by decide +kernel

theorem selectedBound7999 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env8000 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,561,2168,96,2160,2130,560,3108,85,2160,48,33,1092,34,2136,16,2049,1588,1588,3108,4,1028,1025,1028,96,512]

theorem envBound8000 : H12AffineFastState.Bounded env8000 := by
  intro p hp
  have h : env8000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7999_8000 : H12AffineEnvironment.transform 12 2168 env7999 = env8000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2168 env7999 == env8000) = true)

theorem identity8000 : scanCanonicalize (H12AffineFastState.compose env8000 (packedSelected [1,3,14] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound8000 : packedSelected [1,3,14] rootPS < 2^1333 := by decide +kernel

def env8001 : List Nat := [2,4,8,16,32,64,41,84,512,5,2048,561,2168,96,2160,2130,560,2081,85,2160,48,33,65,34,2136,16,2049,561,561,2081,4,1,4,1,96,512]

theorem envBound8001 : H12AffineFastState.Bounded env8001 := by
  intro p hp
  have h : env8001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8000_8001 : H12AffineEnvironment.transform 9 5 env8000 = env8001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env8000 == env8001) = true)

theorem identity8001 : scanCanonicalize (H12AffineFastState.compose env8001 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound8001 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8002 : List Nat := [2,4,8,16,32,26,41,14,512,5,2048,561,2082,58,2090,2056,560,2081,15,2090,48,33,27,34,2050,16,2049,561,561,2081,4,1,4,1,58,512]

theorem envBound8002 : H12AffineFastState.Bounded env8002 := by
  intro p hp
  have h : env8002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8001_8002 : H12AffineEnvironment.transform 5 26 env8001 = env8002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env8001 == env8002) = true)

theorem identity8002 : scanCanonicalize (H12AffineFastState.compose env8002 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound8002 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8003 : List Nat := [2,4,8,16,32,26,41,14,16,5,2048,33,2082,58,2090,2056,32,2081,15,2090,48,33,27,34,2050,16,2049,33,33,2081,4,1,4,1,58,16]

theorem envBound8003 : H12AffineFastState.Bounded env8003 := by
  intro p hp
  have h : env8003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8002_8003 : H12AffineEnvironment.transform 8 16 env8002 = env8003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env8002 == env8003) = true)

def env8004 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,65536,4265,262144,4812,8352,2097152,33,5749,2383462,8329,2452711,2193995,2452162,2452074,76967,4,74886,5785,74887,355342,2383084]

theorem envBound8004 : H12AffineFastState.Bounded env8004 := by
  intro p hp
  have h : env8004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7992_8004 : H12AffineEnvironment.transform 7 85 env7992 = env8004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7992 == env8004) = true)

theorem identity8004 : scanCanonicalize (H12AffineFastState.compose env8004 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound8004 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env8005 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,8235,4265,262144,4812,8352,2097152,33,5749,2383462,8329,2378956,2120288,2378473,2378305,3212,4,1197,5785,1196,281637,2383084]

theorem envBound8005 : H12AffineFastState.Bounded env8005 := by
  intro p hp
  have h : env8005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8004_8005 : H12AffineEnvironment.transform 15 8235 env8004 = env8005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env8004 == env8005) = true)

theorem identity8005 : scanCanonicalize (H12AffineFastState.compose env8005 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 286276) := by decide +kernel

theorem selectedBound8005 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8006 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,8235,4265,262144,4812,8352,286276,33,5749,34,8329,4744,263204,5293,5125,3212,4,1197,5785,1196,281637,680]

theorem envBound8006 : H12AffineFastState.Bounded env8006 := by
  intro p hp
  have h : env8006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8005_8006 : H12AffineEnvironment.transform 20 286276 env8005 = env8006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 286276 env8005 == env8006) = true)

theorem identity8006 : scanCanonicalize (H12AffineFastState.compose env8006 (packedSelected [11,12,13,15,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 7885) := by decide +kernel

theorem selectedBound8006 : packedSelected [11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env8007 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8352,8235,4265,7885,4812,8352,16521,33,5749,34,8329,4744,6889,5293,5125,3212,4,1197,5785,1196,21224,680]

theorem envBound8007 : H12AffineFastState.Bounded env8007 := by
  intro p hp
  have h : env8007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8006_8007 : H12AffineEnvironment.transform 17 7885 env8006 = env8007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7885 env8006 == env8007) = true)

theorem identity8007 : scanCanonicalize (H12AffineFastState.compose env8007 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound8007 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8008 : List Nat := [2,4,8,16,32,64,128,85,512,173,2048,4096,8192,16384,8352,8235,4265,6752,4812,8352,16521,33,4824,34,8329,4744,6889,4096,4264,2081,4,0,4660,1,21224,680]

theorem envBound8008 : H12AffineFastState.Bounded env8008 := by
  intro p hp
  have h : env8008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8007_8008 : H12AffineEnvironment.transform 9 173 env8007 = env8008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env8007 == env8008) = true)

theorem identity8008 : scanCanonicalize (H12AffineFastState.compose env8008 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 170) := by decide +kernel

theorem selectedBound8008 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env8009 : List Nat := [2,4,8,16,32,64,128,85,512,173,2048,4096,170,16384,10,129,4265,6752,4812,10,16521,33,4824,34,35,4744,6889,4096,4264,2081,4,0,4660,1,21224,680]

theorem envBound8009 : H12AffineFastState.Bounded env8009 := by
  intro p hp
  have h : env8009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8008_8009 : H12AffineEnvironment.transform 12 170 env8008 = env8009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 170 env8008 == env8009) = true)

theorem identity8009 : scanCanonicalize (H12AffineFastState.compose env8009 (packedSelected [3,4,5,6,7,13] rootPS)) = affineNative (2^(13+1) ^^^ 512) := by decide +kernel

theorem selectedBound8009 : packedSelected [3,4,5,6,7,13] rootPS < 2^1333 := by decide +kernel

def env8010 : List Nat := [2,4,8,16,32,64,128,85,512,173,2048,4096,170,512,10,129,4265,6752,4812,10,649,33,4824,34,35,4744,6889,4096,4264,2081,4,0,4660,1,4328,680]

theorem envBound8010 : H12AffineFastState.Bounded env8010 := by
  intro p hp
  have h : env8010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8009_8010 : H12AffineEnvironment.transform 13 512 env8009 = env8010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 512 env8009 == env8010) = true)

theorem identity8010 : scanCanonicalize (H12AffineFastState.compose env8010 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound8010 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8011 : List Nat := [2,4,8,16,32,64,88,85,512,117,2048,4096,114,512,10,89,4209,6752,4628,10,593,33,4608,34,35,4688,6705,4096,4208,2081,4,0,4660,1,4144,624]

theorem envBound8011 : H12AffineFastState.Bounded env8011 := by
  intro p hp
  have h : env8011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8010_8011 : H12AffineEnvironment.transform 6 88 env8010 = env8011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env8010 == env8011) = true)

theorem identity8011 : scanCanonicalize (H12AffineFastState.compose env8011 (packedSelected [11,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound8011 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env8012 : List Nat := [2,4,8,16,32,49,41,36,512,4,2048,4096,3,512,10,40,4096,6673,4628,10,544,33,4608,34,35,4641,6705,4096,4097,2081,4,0,4660,1,4144,513]

theorem envBound8012 : H12AffineFastState.Bounded env8012 := by
  intro p hp
  have h : env8012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8011_8012 : H12AffineEnvironment.transform 5 49 env8011 = env8012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env8011 == env8012) = true)

theorem identity8012 : scanCanonicalize (H12AffineFastState.compose env8012 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 570) := by decide +kernel

theorem selectedBound8012 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env8013 : List Nat := [2,4,8,16,32,49,41,36,512,4,570,4096,3,512,10,40,4096,4139,4628,10,544,33,4608,34,35,4641,4107,4096,4097,539,4,0,4660,1,4144,513]

theorem envBound8013 : H12AffineFastState.Bounded env8013 := by
  intro p hp
  have h : env8013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8012_8013 : H12AffineEnvironment.transform 10 570 env8012 = env8013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 570 env8012 == env8013) = true)

theorem identity8013 : scanCanonicalize (H12AffineFastState.compose env8013 (packedSelected [0,2] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound8013 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8014 : List Nat := [2,4,8,16,32,49,41,36,512,4,570,539,3,512,10,40,539,560,15,10,544,33,27,34,35,58,528,539,538,539,4,0,47,1,555,513]

theorem envBound8014 : H12AffineFastState.Bounded env8014 := by
  intro p hp
  have h : env8014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8013_8014 : H12AffineEnvironment.transform 11 539 env8013 = env8014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env8013 == env8014) = true)

theorem identity8014 : scanCanonicalize (H12AffineFastState.compose env8014 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8014 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8015 : List Nat := [2,4,8,16,10,27,3,14,512,4,528,539,3,512,10,2,539,538,15,10,522,11,27,8,9,16,528,539,538,539,4,0,5,1,513,513]

theorem envBound8015 : H12AffineFastState.Bounded env8015 := by
  intro p hp
  have h : env8015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8014_8015 : H12AffineEnvironment.transform 4 10 env8014 = env8015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8014 == env8015) = true)

theorem identity8015 : scanCanonicalize (H12AffineFastState.compose env8015 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound8015 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8016 : List Nat := [2,4,8,16,10,27,3,14,0,4,16,27,3,0,10,2,27,26,15,10,10,11,27,8,9,16,16,27,26,27,4,0,5,1,1,1]

theorem envBound8016 : H12AffineFastState.Bounded env8016 := by
  intro p hp
  have h : env8016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8015_8016 : H12AffineEnvironment.transform 8 0 env8015 = env8016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env8015 == env8016) = true)

theorem identity8016 : scanCanonicalize (H12AffineFastState.compose env8016 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound8016 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8017 : List Nat := [2,4,8,15,10,4,3,14,0,4,15,4,3,0,10,2,4,5,15,10,10,11,4,8,9,15,15,4,5,4,4,0,5,1,1,1]

theorem envBound8017 : H12AffineFastState.Bounded env8017 := by
  intro p hp
  have h : env8017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8016_8017 : H12AffineEnvironment.transform 3 15 env8016 = env8017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env8016 == env8017) = true)

theorem identity8017 : scanCanonicalize (H12AffineFastState.compose env8017 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8017 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8018 : List Nat := [2,0,8,11,10,0,3,10,0,0,11,0,3,0,10,2,0,1,11,10,10,11,0,8,9,11,11,0,1,0,0,0,1,1,1,1]

theorem envBound8018 : H12AffineFastState.Bounded env8018 := by
  intro p hp
  have h : env8018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8017_8018 : H12AffineEnvironment.transform 1 0 env8017 = env8018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8017 == env8018) = true)

theorem identity8018 : scanCanonicalize (H12AffineFastState.compose env8018 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8018 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env8019 : List Nat := [2,0,3,0,1,0,3,1,0,0,0,0,3,0,1,2,0,1,0,1,1,0,0,3,2,0,0,0,1,0,0,0,1,1,1,1]

theorem envBound8019 : H12AffineFastState.Bounded env8019 := by
  intro p hp
  have h : env8019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8018_8019 : H12AffineEnvironment.transform 2 3 env8018 = env8019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8018 == env8019) = true)

def env8020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,16777216,8329,67108864,134217728,138678441,138678612,151259274,84484169,155451871,525568,151257258,73400520,16778207]

theorem envBound8020 : H12AffineFastState.Bounded env8020 := by
  intro p hp
  have h : env8020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7813_8020 : H12AffineEnvironment.transform 27 138678441 env7813 = env8020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 138678441 env7813 == env8020) = true)

theorem identity8020 : scanCanonicalize (H12AffineFastState.compose env8020 (packedSelected [9,14,22] rootPS)) = affineNative (2^(26+1) ^^^ 71570980) := by decide +kernel

theorem selectedBound8020 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env8021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,16777216,8329,67108864,71570980,67110541,67110768,88088238,84484169,83892219,525568,88086158,73400520,16778207]

theorem envBound8021 : H12AffineFastState.Bounded env8021 := by
  intro p hp
  have h : env8021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8020_8021 : H12AffineEnvironment.transform 26 71570980 env8020 = env8021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 71570980 env8020 == env8021) = true)

def env8022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,16777216,8329,17375308,21837416,17376961,17377084,4800226,5,604087,525568,4798146,23666820,16778207]

theorem envBound8022 : H12AffineFastState.Bounded env8022 := by
  intro p hp
  have h : env8022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8021_8022 : H12AffineEnvironment.transform 25 17375308 env8021 = env8022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 17375308 env8021 == env8022) = true)

def env8023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,603024,8329,5084,4457976,5457,5292,4800226,5,604087,525568,4798146,6296340,602191]

theorem envBound8023 : H12AffineFastState.Bounded env8023 := by
  intro p hp
  have h : env8023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8022_8023 : H12AffineEnvironment.transform 23 603024 env8022 = env8023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 603024 env8022 == env8023) = true)

def env8024 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,4194304,525636,602936,8225,4980,4457808,5457,5124,4800074,5,603935,525568,4798058,6296340,602191]

theorem envBound8024 : H12AffineFastState.Bounded env8024 := by
  intro p hp
  have h : env8024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8023_8024 : H12AffineEnvironment.transform 6 40 env8023 = env8024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8023 == env8024) = true)

theorem identity8024 : scanCanonicalize (H12AffineFastState.compose env8024 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound8024 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8025 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,372,525636,602936,8225,4980,263204,5457,5124,606014,5,603935,525568,603934,2101856,602191]

theorem envBound8025 : H12AffineFastState.Bounded env8025 := by
  intro p hp
  have h : env8025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8024_8025 : H12AffineEnvironment.transform 21 372 env8024 = env8025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env8024 == env8025) = true)

theorem identity8025 : scanCanonicalize (H12AffineFastState.compose env8025 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 806260) := by decide +kernel

theorem selectedBound8025 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env8026 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,806260,372,525636,602936,8225,4980,263204,5457,5124,606014,5,603935,525568,603934,810772,602191]

theorem envBound8026 : H12AffineFastState.Bounded env8026 := by
  intro p hp
  have h : env8026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8025_8026 : H12AffineEnvironment.transform 20 806260 env8025 = env8026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 806260 env8025 == env8026) = true)

theorem identity8026 : scanCanonicalize (H12AffineFastState.compose env8026 (packedSelected [0,7,20] rootPS)) = affineNative (2^(18+1) ^^^ 78619) := by decide +kernel

theorem selectedBound8026 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8027 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,78619,8541,360047,372,79455,35,8225,4980,263204,5457,5124,3109,5,1028,79387,1029,355343,852]

theorem envBound8027 : H12AffineFastState.Bounded env8027 := by
  intro p hp
  have h : env8027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8026_8027 : H12AffineEnvironment.transform 18 78619 env8026 = env8027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78619 env8026 == env8027) = true)

theorem identity8027 : scanCanonicalize (H12AffineFastState.compose env8027 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound8027 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env8028 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,2421,78619,8541,96026,372,79455,35,8225,4980,3409,5457,5124,3109,5,1028,79387,1029,91514,852]

theorem envBound8028 : H12AffineFastState.Bounded env8028 := by
  intro p hp
  have h : env8028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8027_8028 : H12AffineEnvironment.transform 17 2421 env8027 = env8028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env8027 == env8028) = true)

theorem identity8028 : scanCanonicalize (H12AffineFastState.compose env8028 (packedSelected [1,3,4,5,8,9,11,13,18,21] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound8028 : packedSelected [1,3,4,5,8,9,11,13,18,21] rootPS < 2^1333 := by decide +kernel

def env8029 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,1289,16384,1108,65536,4436,2421,71186,1108,86547,372,70486,35,1320,4980,3409,5457,5124,3109,5,1028,70418,1029,82035,852]

theorem envBound8029 : H12AffineFastState.Bounded env8029 := by
  intro p hp
  have h : env8029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8028_8029 : H12AffineEnvironment.transform 12 1289 env8028 = env8029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env8028 == env8029) = true)

theorem identity8029 : scanCanonicalize (H12AffineFastState.compose env8029 (packedSelected [0,3,5,9,13,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 2091) := by decide +kernel

theorem selectedBound8029 : packedSelected [0,3,5,9,13,17,18] rootPS < 2^1333 := by decide +kernel

def env8030 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,1289,2091,1108,65536,4436,2421,71186,1108,72248,372,70486,35,1320,4980,3409,5457,5124,3109,5,1028,70418,1029,67672,852]

theorem envBound8030 : H12AffineFastState.Bounded env8030 := by
  intro p hp
  have h : env8030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8029_8030 : H12AffineEnvironment.transform 13 2091 env8029 = env8030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2091 env8029 == env8030) = true)

theorem identity8030 : scanCanonicalize (H12AffineFastState.compose env8030 (packedSelected [0,3,5,9,13,17,23] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound8030 : packedSelected [0,3,5,9,13,17,23] rootPS < 2^1333 := by decide +kernel

def env8031 : List Nat := [2,4,8,16,32,64,40,256,512,4,2048,4096,269,2091,80,65536,4436,2421,70166,80,72248,372,70486,35,300,4980,2389,4437,4096,2081,5,0,70418,1,67672,852]

theorem envBound8031 : H12AffineFastState.Bounded env8031 := by
  intro p hp
  have h : env8031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8030_8031 : H12AffineEnvironment.transform 9 4 env8030 = env8031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env8030 == env8031) = true)

theorem identity8031 : scanCanonicalize (H12AffineFastState.compose env8031 (packedSelected [1,5,7,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 863) := by decide +kernel

theorem selectedBound8031 : packedSelected [1,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env8032 : List Nat := [2,4,8,16,32,64,40,256,512,4,2048,863,269,2091,80,65536,523,2421,65865,80,67943,372,65545,35,300,43,2389,522,863,2081,5,0,65613,1,67672,852]

theorem envBound8032 : H12AffineFastState.Bounded env8032 := by
  intro p hp
  have h : env8032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8031_8032 : H12AffineEnvironment.transform 11 863 env8031 = env8032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 863 env8031 == env8032) = true)

theorem identity8032 : scanCanonicalize (H12AffineFastState.compose env8032 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound8032 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env8033 : List Nat := [2,4,8,16,32,64,40,256,512,4,372,863,269,351,80,65536,523,1,65865,80,65555,372,65545,35,300,43,33,522,863,341,5,0,65613,1,65836,852]

theorem envBound8033 : H12AffineFastState.Bounded env8033 := by
  intro p hp
  have h : env8033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8032_8033 : H12AffineEnvironment.transform 10 372 env8032 = env8033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env8032 == env8033) = true)

theorem identity8033 : scanCanonicalize (H12AffineFastState.compose env8033 (packedSelected [0,1,3,4,6,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound8033 : packedSelected [0,1,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env8034 : List Nat := [2,4,8,16,32,64,40,256,11,4,372,340,269,351,80,65536,0,1,65865,80,65555,372,65545,35,300,43,33,1,340,341,5,0,65613,1,65836,351]

theorem envBound8034 : H12AffineFastState.Bounded env8034 := by
  intro p hp
  have h : env8034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8033_8034 : H12AffineEnvironment.transform 8 11 env8033 = env8034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env8033 == env8034) = true)

theorem identity8034 : scanCanonicalize (H12AffineFastState.compose env8034 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(15+1) ^^^ 374) := by decide +kernel

theorem selectedBound8034 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env8035 : List Nat := [2,4,8,16,32,64,40,256,11,4,372,340,269,351,80,374,0,1,63,80,357,372,383,35,300,43,33,1,340,341,5,0,315,1,90,351]

theorem envBound8035 : H12AffineFastState.Bounded env8035 := by
  intro p hp
  have h : env8035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8034_8035 : H12AffineEnvironment.transform 15 374 env8034 = env8035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 374 env8034 == env8035) = true)

theorem identity8035 : scanCanonicalize (H12AffineFastState.compose env8035 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8035 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env8036 : List Nat := [2,4,8,16,0,64,8,256,11,4,340,340,269,351,80,342,0,1,31,80,325,340,351,3,268,11,1,1,340,341,5,0,283,1,90,351]

theorem envBound8036 : H12AffineFastState.Bounded env8036 := by
  intro p hp
  have h : env8036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8035_8036 : H12AffineEnvironment.transform 4 0 env8035 = env8036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8035 == env8036) = true)

theorem identity8036 : scanCanonicalize (H12AffineFastState.compose env8036 (packedSelected [0,1,4,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8036 : packedSelected [0,1,4,6,8] rootPS < 2^1333 := by decide +kernel

def env8037 : List Nat := [2,4,8,16,0,1,8,256,11,4,277,277,269,286,17,279,0,1,31,17,260,277,286,3,268,11,1,1,277,276,5,0,283,1,27,286]

theorem envBound8037 : H12AffineFastState.Bounded env8037 := by
  intro p hp
  have h : env8037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8036_8037 : H12AffineEnvironment.transform 5 1 env8036 = env8037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8036 == env8037) = true)

theorem identity8037 : scanCanonicalize (H12AffineFastState.compose env8037 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8037 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8038 : List Nat := [2,4,8,1,0,1,8,256,11,4,260,260,269,271,0,262,0,1,14,0,260,260,271,3,268,11,1,1,260,261,5,0,266,1,10,271]

theorem envBound8038 : H12AffineFastState.Bounded env8038 := by
  intro p hp
  have h : env8038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8037_8038 : H12AffineEnvironment.transform 3 1 env8037 = env8038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8037 == env8038) = true)

theorem identity8038 : scanCanonicalize (H12AffineFastState.compose env8038 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound8038 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8039 : List Nat := [2,4,8,1,0,1,8,5,11,4,1,1,8,10,0,3,0,1,14,0,1,1,10,3,9,11,1,1,1,0,5,0,15,1,10,10]

theorem envBound8039 : H12AffineFastState.Bounded env8039 := by
  intro p hp
  have h : env8039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8038_8039 : H12AffineEnvironment.transform 7 5 env8038 = env8039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env8038 == env8039) = true)

theorem identity8039 : scanCanonicalize (H12AffineFastState.compose env8039 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8039 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8040 : List Nat := [2,0,8,1,0,1,8,1,11,0,1,1,8,10,0,3,0,1,10,0,1,1,10,3,9,11,1,1,1,0,1,0,11,1,10,10]

theorem envBound8040 : H12AffineFastState.Bounded env8040 := by
  intro p hp
  have h : env8040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8039_8040 : H12AffineEnvironment.transform 1 0 env8039 = env8040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8039 == env8040) = true)

theorem identity8040 : scanCanonicalize (H12AffineFastState.compose env8040 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8040 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8041 : List Nat := [2,0,2,1,0,1,2,1,1,0,1,1,2,0,0,3,0,1,0,0,1,1,0,3,3,1,1,1,1,0,1,0,1,1,0,0]

theorem envBound8041 : H12AffineFastState.Bounded env8041 := by
  intro p hp
  have h : env8041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8040_8041 : H12AffineEnvironment.transform 2 2 env8040 = env8041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8040 == env8041) = true)

def env8042 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,4194304,525637,602937,8224,4981,4457809,5457,5125,4800075,5,603934,525568,4798059,6296340,602191]

theorem envBound8042 : H12AffineFastState.Bounded env8042 := by
  intro p hp
  have h : env8042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8023_8042 : H12AffineEnvironment.transform 6 41 env8023 = env8042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8023 == env8042) = true)

theorem identity8042 : scanCanonicalize (H12AffineFastState.compose env8042 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 2977150) := by decide +kernel

theorem selectedBound8042 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8043 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,2977150,525637,602937,8224,4981,2713647,5457,5125,2380597,5,603934,525568,2382613,884330,602191]

theorem envBound8043 : H12AffineFastState.Bounded env8043 := by
  intro p hp
  have h : env8043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8042_8043 : H12AffineEnvironment.transform 21 2977150 env8042 = env8043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2977150 env8042 == env8043) = true)

def env8044 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,2976810,525329,602733,8224,4641,2713647,5125,5125,2380385,5,603722,525396,2382401,884330,602191]

theorem envBound8044 : H12AffineFastState.Bounded env8044 := by
  intro p hp
  have h : env8044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8043_8044 : H12AffineEnvironment.transform 7 84 env8043 = env8044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8043 == env8044) = true)

def env8045 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,2976811,525328,602732,8224,4640,2713647,5124,5125,2380384,5,603723,525397,2382400,884330,602191]

theorem envBound8045 : H12AffineFastState.Bounded env8045 := by
  intro p hp
  have h : env8045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8043_8045 : H12AffineEnvironment.transform 7 85 env8043 = env8045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8043 == env8045) = true)

theorem identity8045 : scanCanonicalize (H12AffineFastState.compose env8045 (packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 879627) := by decide +kernel

theorem selectedBound8045 : packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env8046 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,879627,32,525328,602732,8224,4640,263204,5124,5125,605803,5,603723,525397,603723,884330,602191]

theorem envBound8046 : H12AffineFastState.Bounded env8046 := by
  intro p hp
  have h : env8046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8045_8046 : H12AffineEnvironment.transform 20 879627 env8045 = env8046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 879627 env8045 == env8046) = true)

theorem identity8046 : scanCanonicalize (H12AffineFastState.compose env8046 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 9263) := by decide +kernel

theorem selectedBound8046 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8047 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,9263,4096,262144,524288,8201,804900,32,525328,529987,8224,4640,263204,5124,5125,531012,5,528996,525397,528996,809541,529504]

theorem envBound8047 : H12AffineFastState.Bounded env8047 := by
  intro p hp
  have h : env8047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8046_8047 : H12AffineEnvironment.transform 15 9263 env8046 = env8047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9263 env8046 == env8047) = true)

theorem identity8047 : scanCanonicalize (H12AffineFastState.compose env8047 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(18+1) ^^^ 267338) := by decide +kernel

theorem selectedBound8047 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env8048 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,9263,4096,262144,267338,8201,23662,32,266330,262665,8224,4640,263204,5124,5125,265742,5,263726,266271,263726,19983,262186]

theorem envBound8048 : H12AffineFastState.Bounded env8048 := by
  intro p hp
  have h : env8048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8047_8048 : H12AffineEnvironment.transform 18 267338 env8047 = env8048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 267338 env8047 == env8048) = true)

theorem identity8048 : scanCanonicalize (H12AffineFastState.compose env8048 (packedSelected [1,5,6,10,11,12] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound8048 : packedSelected [1,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env8049 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,9263,4096,554,5728,8201,23662,32,4720,35,8224,4640,1550,5124,5125,3108,5,1028,4661,1028,19983,512]

theorem envBound8049 : H12AffineFastState.Bounded env8049 := by
  intro p hp
  have h : env8049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8048_8049 : H12AffineEnvironment.transform 17 554 env8048 = env8049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env8048 == env8049) = true)

theorem identity8049 : scanCanonicalize (H12AffineFastState.compose env8049 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 1652) := by decide +kernel

theorem selectedBound8049 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8050 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,1652,8201,9263,4096,554,5728,8201,6682,32,4720,35,8224,4640,1550,5124,5125,3108,5,1028,4661,1028,2171,512]

theorem envBound8050 : H12AffineFastState.Bounded env8050 := by
  intro p hp
  have h : env8050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8049_8050 : H12AffineEnvironment.transform 13 1652 env8049 = env8050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1652 env8049 == env8050) = true)

theorem identity8050 : scanCanonicalize (H12AffineFastState.compose env8050 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 3134) := by decide +kernel

theorem selectedBound8050 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env8051 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,3134,8192,1652,8201,9263,3134,554,2654,8201,1572,32,3662,35,8224,3614,1550,2106,2107,3108,5,1028,3595,1028,2171,512]

theorem envBound8051 : H12AffineFastState.Bounded env8051 := by
  intro p hp
  have h : env8051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8050_8051 : H12AffineEnvironment.transform 11 3134 env8050 = env8051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3134 env8050 == env8051) = true)

theorem identity8051 : scanCanonicalize (H12AffineFastState.compose env8051 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 1037) := by decide +kernel

theorem selectedBound8051 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env8052 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,3134,1037,1652,1028,34,3134,554,2654,1028,1572,32,3662,35,1069,3614,1550,2106,2107,3108,5,1028,3595,1028,2171,512]

theorem envBound8052 : H12AffineFastState.Bounded env8052 := by
  intro p hp
  have h : env8052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8051_8052 : H12AffineEnvironment.transform 12 1037 env8051 = env8052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1037 env8051 == env8052) = true)

def env8053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,603025,8329,5085,4457977,5456,5293,4800226,5,604087,525568,4798146,6296341,602190]

theorem envBound8053 : H12AffineFastState.Bounded env8053 := by
  intro p hp
  have h : env8053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8022_8053 : H12AffineEnvironment.transform 23 603025 env8022 = env8053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 603025 env8022 == env8053) = true)

def env8054 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,4194304,525636,602937,8225,4981,4457809,5456,5125,4800074,5,603935,525568,4798058,6296341,602190]

theorem envBound8054 : H12AffineFastState.Bounded env8054 := by
  intro p hp
  have h : env8054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8053_8054 : H12AffineEnvironment.transform 6 40 env8053 = env8054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8053 == env8054) = true)

theorem identity8054 : scanCanonicalize (H12AffineFastState.compose env8054 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 2977150) := by decide +kernel

theorem selectedBound8054 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8055 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,2977150,525636,602937,8225,4981,2713647,5456,5125,2380596,5,603935,525568,2382612,884331,602190]

theorem envBound8055 : H12AffineFastState.Bounded env8055 := by
  intro p hp
  have h : env8055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8054_8055 : H12AffineEnvironment.transform 21 2977150 env8054 = env8055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2977150 env8054 == env8055) = true)

def env8056 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,2976810,525328,602733,8225,4641,2713647,5124,5125,2380384,5,603723,525396,2382400,884331,602190]

theorem envBound8056 : H12AffineFastState.Bounded env8056 := by
  intro p hp
  have h : env8056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8055_8056 : H12AffineEnvironment.transform 7 84 env8055 = env8056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8055 == env8056) = true)

def env8057 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,2976811,525329,602732,8225,4640,2713647,5125,5125,2380385,5,603722,525397,2382401,884331,602190]

theorem envBound8057 : H12AffineFastState.Bounded env8057 := by
  intro p hp
  have h : env8057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8055_8057 : H12AffineEnvironment.transform 7 85 env8055 = env8057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8055 == env8057) = true)

theorem identity8057 : scanCanonicalize (H12AffineFastState.compose env8057 (packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 879626) := by decide +kernel

theorem selectedBound8057 : packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env8058 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,879626,33,525329,602732,8225,4640,263205,5125,5125,605803,5,603722,525397,603723,884331,602190]

theorem envBound8058 : H12AffineFastState.Bounded env8058 := by
  intro p hp
  have h : env8058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8057_8058 : H12AffineEnvironment.transform 20 879626 env8057 = env8058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 879626 env8057 == env8058) = true)

theorem identity8058 : scanCanonicalize (H12AffineFastState.compose env8058 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(18+1) ^^^ 78414) := by decide +kernel

theorem selectedBound8058 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8059 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,78414,8200,286276,33,79455,34,8225,4640,263205,5125,5125,3109,5,1028,79387,1029,281637,512]

theorem envBound8059 : H12AffineFastState.Bounded env8059 := by
  intro p hp
  have h : env8059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8058_8059 : H12AffineEnvironment.transform 18 78414 env8058 = env8059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78414 env8058 == env8059) = true)

theorem identity8059 : scanCanonicalize (H12AffineFastState.compose env8059 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 7780) := by decide +kernel

theorem selectedBound8059 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8060 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,7780,78414,8200,16416,33,79455,34,8225,4640,6721,5125,5125,3109,5,1028,79387,1029,21057,512]

theorem envBound8060 : H12AffineFastState.Bounded env8060 := by
  intro p hp
  have h : env8060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8059_8060 : H12AffineEnvironment.transform 17 7780 env8059 = env8060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7780 env8059 == env8060) = true)

theorem identity8060 : scanCanonicalize (H12AffineFastState.compose env8060 (packedSelected [1,8,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 12906) := by decide +kernel

theorem selectedBound8060 : packedSelected [1,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env8061 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,12906,4097,7780,36,8200,16416,33,1077,34,8225,4640,6721,5125,5125,3109,5,1028,1137,1029,21057,512]

theorem envBound8061 : H12AffineFastState.Bounded env8061 := by
  intro p hp
  have h : env8061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8060_8061 : H12AffineEnvironment.transform 15 12906 env8060 = env8061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12906 env8060 == env8061) = true)

theorem identity8061 : scanCanonicalize (H12AffineFastState.compose env8061 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(13+1) ^^^ 11340) := by decide +kernel

theorem selectedBound8061 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env8062 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,11340,8200,12906,4097,7780,36,8200,11372,33,1077,34,8225,4640,6721,5125,5125,3109,5,1028,1137,1029,15885,512]

theorem envBound8062 : H12AffineFastState.Bounded env8062 := by
  intro p hp
  have h : env8062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8061_8062 : H12AffineEnvironment.transform 13 11340 env8061 = env8062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11340 env8061 == env8062) = true)

theorem identity8062 : scanCanonicalize (H12AffineFastState.compose env8062 (packedSelected [0,1,2,3,4,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound8062 : packedSelected [0,1,2,3,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env8063 : List Nat := [2,4,8,16,32,64,40,85,512,1024,16,4096,8192,9308,8200,12906,4097,5748,36,8200,9340,33,1077,34,8225,4640,4689,5125,5125,1077,5,1028,1137,1029,13853,512]

theorem envBound8063 : H12AffineFastState.Bounded env8063 := by
  intro p hp
  have h : env8063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8062_8063 : H12AffineEnvironment.transform 10 16 env8062 = env8063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env8062 == env8063) = true)

theorem identity8063 : scanCanonicalize (H12AffineFastState.compose env8063 (packedSelected [0,2,3,4,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 4729) := by decide +kernel

theorem selectedBound8063 : packedSelected [0,2,3,4,5,6,10] rootPS < 2^1333 := by decide +kernel

def env8064 : List Nat := [2,4,8,16,32,64,40,85,512,1024,16,4096,4729,5669,4721,19,4097,5748,36,4721,5637,33,1077,34,4696,4640,4689,5125,5125,1077,5,1028,1137,1029,1124,512]

theorem envBound8064 : H12AffineFastState.Bounded env8064 := by
  intro p hp
  have h : env8064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8063_8064 : H12AffineEnvironment.transform 12 4729 env8063 = env8064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4729 env8063 == env8064) = true)

theorem identity8064 : scanCanonicalize (H12AffineFastState.compose env8064 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound8064 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env8065 : List Nat := [2,4,8,16,32,64,40,85,27,1024,16,4096,4194,5182,4202,19,4097,5231,36,4202,5150,33,1077,34,4163,4155,4170,5125,5125,1077,5,1028,1137,1029,1124,27]

theorem envBound8065 : H12AffineFastState.Bounded env8065 := by
  intro p hp
  have h : env8065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8064_8065 : H12AffineEnvironment.transform 8 27 env8064 = env8065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env8064 == env8065) = true)

theorem identity8065 : scanCanonicalize (H12AffineFastState.compose env8065 (packedSelected [6,11] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound8065 : packedSelected [6,11] rootPS < 2^1333 := by decide +kernel

def env8066 : List Nat := [2,4,8,16,32,64,40,85,27,1024,16,43,73,1045,65,19,42,1092,36,65,1077,33,1077,34,104,16,97,1070,1070,1077,5,1028,1137,1029,1124,27]

theorem envBound8066 : H12AffineFastState.Bounded env8066 := by
  intro p hp
  have h : env8066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8065_8066 : H12AffineEnvironment.transform 11 43 env8065 = env8066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env8065 == env8066) = true)

theorem identity8066 : scanCanonicalize (H12AffineFastState.compose env8066 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound8066 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env8067 : List Nat := [2,4,8,16,32,10,40,31,27,1024,16,43,3,1045,11,19,42,1038,36,11,1077,33,1077,34,34,16,43,1070,1070,1077,5,1028,1083,1029,1070,27]

theorem envBound8067 : H12AffineFastState.Bounded env8067 := by
  intro p hp
  have h : env8067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8066_8067 : H12AffineEnvironment.transform 5 10 env8066 = env8067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env8066 == env8067) = true)

theorem identity8067 : scanCanonicalize (H12AffineFastState.compose env8067 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8067 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8068 : List Nat := [2,4,8,16,27,10,19,31,27,1024,16,16,3,1045,11,19,17,1038,31,11,1038,26,1038,25,25,16,16,1045,1045,1038,5,1028,1024,1029,1045,27]

theorem envBound8068 : H12AffineFastState.Bounded env8068 := by
  intro p hp
  have h : env8068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8067_8068 : H12AffineEnvironment.transform 4 27 env8067 = env8068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8067 == env8068) = true)

theorem identity8068 : scanCanonicalize (H12AffineFastState.compose env8068 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound8068 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env8069 : List Nat := [2,4,8,11,0,10,8,4,0,1024,11,11,3,1038,11,8,10,1038,4,11,1038,1,1038,2,2,11,11,1038,1038,1038,5,1028,1024,1029,1038,0]

theorem envBound8069 : H12AffineFastState.Bounded env8069 := by
  intro p hp
  have h : env8069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8068_8069 : H12AffineEnvironment.transform 3 11 env8068 = env8069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env8068 == env8069) = true)

theorem identity8069 : scanCanonicalize (H12AffineFastState.compose env8069 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound8069 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8070 : List Nat := [2,4,8,11,0,10,8,4,0,4,11,11,3,10,11,8,10,10,4,11,10,1,10,2,2,11,11,10,10,10,5,0,4,1,10,0]

theorem envBound8070 : H12AffineFastState.Bounded env8070 := by
  intro p hp
  have h : env8070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8069_8070 : H12AffineEnvironment.transform 9 4 env8069 = env8070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env8069 == env8070) = true)

theorem identity8070 : scanCanonicalize (H12AffineFastState.compose env8070 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8070 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8071 : List Nat := [2,4,2,1,0,0,2,4,0,4,1,1,3,0,1,2,0,0,4,1,0,1,0,2,2,1,1,0,0,0,5,0,4,1,0,0]

theorem envBound8071 : H12AffineFastState.Bounded env8071 := by
  intro p hp
  have h : env8071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8070_8071 : H12AffineEnvironment.transform 2 2 env8070 = env8071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8070 == env8071) = true)

def env8072 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,4194304,525637,602936,8224,4980,4457808,5456,5124,4800075,5,603934,525568,4798059,6296341,602190]

theorem envBound8072 : H12AffineFastState.Bounded env8072 := by
  intro p hp
  have h : env8072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8053_8072 : H12AffineEnvironment.transform 6 41 env8053 = env8072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8053 == env8072) = true)

theorem identity8072 : scanCanonicalize (H12AffineFastState.compose env8072 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound8072 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8073 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,372,525637,602936,8224,4980,263204,5456,5124,606015,5,603934,525568,603935,2101857,602190]

theorem envBound8073 : H12AffineFastState.Bounded env8073 := by
  intro p hp
  have h : env8073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8072_8073 : H12AffineEnvironment.transform 21 372 env8072 = env8073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env8072 == env8073) = true)

theorem identity8073 : scanCanonicalize (H12AffineFastState.compose env8073 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 806261) := by decide +kernel

theorem selectedBound8073 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env8074 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,806261,372,525637,602936,8224,4980,263204,5456,5124,606015,5,603934,525568,603935,810772,602190]

theorem envBound8074 : H12AffineFastState.Bounded env8074 := by
  intro p hp
  have h : env8074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8073_8074 : H12AffineEnvironment.transform 20 806261 env8073 = env8074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 806261 env8073 == env8074) = true)

theorem identity8074 : scanCanonicalize (H12AffineFastState.compose env8074 (packedSelected [0,7,20] rootPS)) = affineNative (2^(18+1) ^^^ 78619) := by decide +kernel

theorem selectedBound8074 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8075 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,78619,8540,360046,372,79454,35,8224,4980,263204,5456,5124,3108,5,1029,79387,1028,355343,853]

theorem envBound8075 : H12AffineFastState.Bounded env8075 := by
  intro p hp
  have h : env8075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8074_8075 : H12AffineEnvironment.transform 18 78619 env8074 = env8075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78619 env8074 == env8075) = true)

theorem identity8075 : scanCanonicalize (H12AffineFastState.compose env8075 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 9595) := by decide +kernel

theorem selectedBound8075 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env8076 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,9595,4437,262144,5728,8540,285461,372,4901,35,8224,4980,263204,5456,5124,3108,5,1029,4960,1028,280948,853]

theorem envBound8076 : H12AffineFastState.Bounded env8076 := by
  intro p hp
  have h : env8076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8075_8076 : H12AffineEnvironment.transform 15 9595 env8075 = env8076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9595 env8075 == env8076) = true)

theorem identity8076 : scanCanonicalize (H12AffineFastState.compose env8076 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 24902) := by decide +kernel

theorem selectedBound8076 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env8077 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,9595,4437,24902,5728,8540,14931,372,4901,35,8224,4980,25954,5456,5124,3108,5,1029,4960,1028,10290,853]

theorem envBound8077 : H12AffineFastState.Bounded env8077 := by
  intro p hp
  have h : env8077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8076_8077 : H12AffineEnvironment.transform 17 24902 env8076 = env8077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 24902 env8076 == env8077) = true)

theorem identity8077 : scanCanonicalize (H12AffineFastState.compose env8077 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 6259) := by decide +kernel

theorem selectedBound8077 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env8078 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,6259,16384,6447,7432,4437,22837,5728,6447,544,372,4901,35,6227,4980,23825,5456,5124,3108,5,1029,4960,1028,4161,853]

theorem envBound8078 : H12AffineFastState.Bounded env8078 := by
  intro p hp
  have h : env8078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8077_8078 : H12AffineEnvironment.transform 12 6259 env8077 = env8078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6259 env8077 == env8078) = true)

theorem identity8078 : scanCanonicalize (H12AffineFastState.compose env8078 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 624) := by decide +kernel

theorem selectedBound8078 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8079 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,6259,624,6447,7432,4437,6981,5728,6447,544,372,4901,35,6227,4980,8033,5456,5124,3108,5,1029,4960,1028,4161,853]

theorem envBound8079 : H12AffineFastState.Bounded env8079 := by
  intro p hp
  have h : env8079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8078_8079 : H12AffineEnvironment.transform 13 624 env8078 = env8079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 624 env8078 == env8079) = true)

theorem identity8079 : scanCanonicalize (H12AffineFastState.compose env8079 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound8079 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env8080 : List Nat := [2,4,8,16,32,64,41,256,512,1024,522,4096,4729,624,4901,5890,4437,4431,5728,4901,544,372,4901,35,4697,4980,5483,5456,5124,1582,5,1029,4960,1028,4161,853]

theorem envBound8080 : H12AffineFastState.Bounded env8080 := by
  intro p hp
  have h : env8080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8079_8080 : H12AffineEnvironment.transform 10 522 env8079 = env8080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env8079 == env8080) = true)

theorem identity8080 : scanCanonicalize (H12AffineFastState.compose env8080 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound8080 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env8081 : List Nat := [2,4,8,16,32,0,41,256,512,1024,522,4096,4665,560,4901,5890,4373,4367,5664,4901,544,308,4901,35,4633,4916,5419,5392,5124,1582,5,1029,4896,1028,4097,789]

theorem envBound8081 : H12AffineFastState.Bounded env8081 := by
  intro p hp
  have h : env8081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8080_8081 : H12AffineEnvironment.transform 5 0 env8080 = env8081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8080 == env8081) = true)

theorem identity8081 : scanCanonicalize (H12AffineFastState.compose env8081 (packedSelected [0,3,4,6,8,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound8081 : packedSelected [0,3,4,6,8,11,13] rootPS < 2^1333 := by decide +kernel

def env8082 : List Nat := [2,4,8,16,32,0,41,256,512,1024,522,1045,1580,560,1840,791,1280,1306,565,1840,544,308,1840,35,1548,1825,318,261,17,1582,5,1029,1845,1028,1044,789]

theorem envBound8082 : H12AffineFastState.Bounded env8082 := by
  intro p hp
  have h : env8082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8081_8082 : H12AffineEnvironment.transform 11 1045 env8081 = env8082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env8081 == env8082) = true)

def env8083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,16777216,8329,17375309,21837417,17376960,17377085,4800227,4,604086,525568,4798147,23666821,16778207]

theorem envBound8083 : H12AffineFastState.Bounded env8083 := by
  intro p hp
  have h : env8083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8021_8083 : H12AffineEnvironment.transform 25 17375309 env8021 = env8083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 17375309 env8021 == env8083) = true)

def env8084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,603024,8329,5085,4457977,5456,5293,4800227,4,604086,525568,4798147,6296341,602191]

theorem envBound8084 : H12AffineFastState.Bounded env8084 := by
  intro p hp
  have h : env8084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8083_8084 : H12AffineEnvironment.transform 23 603024 env8083 = env8084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 603024 env8083 == env8084) = true)

def env8085 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,4194304,525636,602936,8225,4981,4457809,5456,5125,4800075,4,603934,525568,4798059,6296341,602191]

theorem envBound8085 : H12AffineFastState.Bounded env8085 := by
  intro p hp
  have h : env8085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8084_8085 : H12AffineEnvironment.transform 6 40 env8084 = env8085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8084 == env8085) = true)

theorem identity8085 : scanCanonicalize (H12AffineFastState.compose env8085 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound8085 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8086 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,372,525636,602936,8225,4981,263205,5456,5125,606015,4,603934,525568,603935,2101857,602191]

theorem envBound8086 : H12AffineFastState.Bounded env8086 := by
  intro p hp
  have h : env8086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8085_8086 : H12AffineEnvironment.transform 21 372 env8085 = env8086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env8085 == env8086) = true)

theorem identity8086 : scanCanonicalize (H12AffineFastState.compose env8086 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 806260) := by decide +kernel

theorem selectedBound8086 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env8087 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,806260,372,525636,602936,8225,4981,263205,5456,5125,606015,4,603934,525568,603935,810773,602191]

theorem envBound8087 : H12AffineFastState.Bounded env8087 := by
  intro p hp
  have h : env8087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8086_8087 : H12AffineEnvironment.transform 20 806260 env8086 = env8087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 806260 env8086 == env8087) = true)

theorem identity8087 : scanCanonicalize (H12AffineFastState.compose env8087 (packedSelected [0,7,20] rootPS)) = affineNative (2^(18+1) ^^^ 78619) := by decide +kernel

theorem selectedBound8087 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8088 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,78619,8541,360047,372,79455,35,8225,4981,263205,5456,5125,3108,4,1029,79387,1028,355342,852]

theorem envBound8088 : H12AffineFastState.Bounded env8088 := by
  intro p hp
  have h : env8088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8087_8088 : H12AffineEnvironment.transform 18 78619 env8087 = env8088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78619 env8087 == env8088) = true)

theorem identity8088 : scanCanonicalize (H12AffineFastState.compose env8088 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound8088 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env8089 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,2421,78619,8541,96026,372,79455,35,8225,4981,3408,5456,5125,3108,4,1029,79387,1028,91515,852]

theorem envBound8089 : H12AffineFastState.Bounded env8089 := by
  intro p hp
  have h : env8089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8088_8089 : H12AffineEnvironment.transform 17 2421 env8088 = env8089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env8088 == env8089) = true)

theorem identity8089 : scanCanonicalize (H12AffineFastState.compose env8089 (packedSelected [1,3,4,5,8,9,11,13,18,21] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound8089 : packedSelected [1,3,4,5,8,9,11,13,18,21] rootPS < 2^1333 := by decide +kernel

def env8090 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,1288,16384,1109,65536,4436,2421,71187,1109,86546,372,70487,35,1321,4981,3408,5456,5125,3108,4,1029,70419,1028,82035,852]

theorem envBound8090 : H12AffineFastState.Bounded env8090 := by
  intro p hp
  have h : env8090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8089_8090 : H12AffineEnvironment.transform 12 1288 env8089 = env8090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env8089 == env8090) = true)

theorem identity8090 : scanCanonicalize (H12AffineFastState.compose env8090 (packedSelected [0,3,5,9,13,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 2090) := by decide +kernel

theorem selectedBound8090 : packedSelected [0,3,5,9,13,17,18] rootPS < 2^1333 := by decide +kernel

def env8091 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,1288,2090,1109,65536,4436,2421,71187,1109,72248,372,70487,35,1321,4981,3408,5456,5125,3108,4,1029,70419,1028,67673,852]

theorem envBound8091 : H12AffineFastState.Bounded env8091 := by
  intro p hp
  have h : env8091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8090_8091 : H12AffineEnvironment.transform 13 2090 env8090 = env8091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2090 env8090 == env8091) = true)

theorem identity8091 : scanCanonicalize (H12AffineFastState.compose env8091 (packedSelected [0,3,5,9,13,17,23] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound8091 : packedSelected [0,3,5,9,13,17,23] rootPS < 2^1333 := by decide +kernel

def env8092 : List Nat := [2,4,8,16,32,64,40,256,512,5,2048,4096,269,2090,80,65536,4436,2421,70166,80,72248,372,70487,35,300,4981,2389,4437,4096,2081,4,0,70419,1,67673,852]

theorem envBound8092 : H12AffineFastState.Bounded env8092 := by
  intro p hp
  have h : env8092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8091_8092 : H12AffineEnvironment.transform 9 5 env8091 = env8092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env8091 == env8092) = true)

theorem identity8092 : scanCanonicalize (H12AffineFastState.compose env8092 (packedSelected [1,5,7,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 862) := by decide +kernel

theorem selectedBound8092 : packedSelected [1,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env8093 : List Nat := [2,4,8,16,32,64,40,256,512,5,2048,862,269,2090,80,65536,522,2421,65864,80,67942,372,65545,35,300,43,2389,523,862,2081,4,0,65613,1,67673,852]

theorem envBound8093 : H12AffineFastState.Bounded env8093 := by
  intro p hp
  have h : env8093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8092_8093 : H12AffineEnvironment.transform 11 862 env8092 = env8093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 862 env8092 == env8093) = true)

theorem identity8093 : scanCanonicalize (H12AffineFastState.compose env8093 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound8093 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env8094 : List Nat := [2,4,8,16,32,64,40,256,512,5,372,862,269,350,80,65536,522,1,65864,80,65554,372,65545,35,300,43,33,523,862,341,4,0,65613,1,65837,852]

theorem envBound8094 : H12AffineFastState.Bounded env8094 := by
  intro p hp
  have h : env8094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8093_8094 : H12AffineEnvironment.transform 10 372 env8093 = env8094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env8093 == env8094) = true)

theorem identity8094 : scanCanonicalize (H12AffineFastState.compose env8094 (packedSelected [0,1,3,4,6,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 633) := by decide +kernel

theorem selectedBound8094 : packedSelected [0,1,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env8095 : List Nat := [2,4,8,16,32,64,40,256,512,5,372,862,269,350,80,633,522,1,817,80,619,372,624,35,300,43,33,523,862,341,4,0,564,1,852,852]

theorem envBound8095 : H12AffineFastState.Bounded env8095 := by
  intro p hp
  have h : env8095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8094_8095 : H12AffineEnvironment.transform 15 633 env8094 = env8095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 633 env8094 == env8095) = true)

theorem identity8095 : scanCanonicalize (H12AffineFastState.compose env8095 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound8095 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env8096 : List Nat := [2,4,8,16,32,64,40,256,271,5,372,81,269,350,80,374,261,1,62,80,356,372,383,35,300,43,33,260,81,341,4,0,315,1,91,91]

theorem envBound8096 : H12AffineFastState.Bounded env8096 := by
  intro p hp
  have h : env8096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8095_8096 : H12AffineEnvironment.transform 8 271 env8095 = env8096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env8095 == env8096) = true)

theorem identity8096 : scanCanonicalize (H12AffineFastState.compose env8096 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8096 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env8097 : List Nat := [2,4,8,16,0,64,8,256,271,5,340,81,269,350,80,342,261,1,30,80,324,340,351,3,268,11,1,260,81,341,4,0,283,1,91,91]

theorem envBound8097 : H12AffineFastState.Bounded env8097 := by
  intro p hp
  have h : env8097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8096_8097 : H12AffineEnvironment.transform 4 0 env8096 = env8097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8096 == env8097) = true)

theorem identity8097 : scanCanonicalize (H12AffineFastState.compose env8097 (packedSelected [0,1,4,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound8097 : packedSelected [0,1,4,6,8] rootPS < 2^1333 := by decide +kernel

def env8098 : List Nat := [2,4,8,16,0,0,8,256,271,5,276,17,269,286,16,278,261,1,30,16,260,276,287,3,268,11,1,260,17,277,4,0,283,1,27,27]

theorem envBound8098 : H12AffineFastState.Bounded env8098 := by
  intro p hp
  have h : env8098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8097_8098 : H12AffineEnvironment.transform 5 0 env8097 = env8098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8097 == env8098) = true)

theorem identity8098 : scanCanonicalize (H12AffineFastState.compose env8098 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8098 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8099 : List Nat := [2,4,8,0,0,0,8,256,271,5,260,1,269,270,0,262,261,1,14,0,260,260,271,3,268,11,1,260,1,261,4,0,267,1,11,11]

theorem envBound8099 : H12AffineFastState.Bounded env8099 := by
  intro p hp
  have h : env8099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8098_8099 : H12AffineEnvironment.transform 3 0 env8098 = env8099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8098 == env8099) = true)

theorem identity8099 : scanCanonicalize (H12AffineFastState.compose env8099 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8099 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8100 : List Nat := [2,4,3,0,0,0,3,256,260,5,260,1,262,261,0,262,261,1,5,0,260,260,260,3,263,0,1,260,1,261,4,0,256,1,0,0]

theorem envBound8100 : H12AffineFastState.Bounded env8100 := by
  intro p hp
  have h : env8100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8099_8100 : H12AffineEnvironment.transform 2 3 env8099 = env8100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8099 == env8100) = true)

theorem identity8100 : scanCanonicalize (H12AffineFastState.compose env8100 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8100 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8101 : List Nat := [2,4,3,0,0,0,3,4,0,5,0,1,2,1,0,2,1,1,5,0,0,0,0,3,3,0,1,0,1,1,4,0,4,1,0,0]

theorem envBound8101 : H12AffineFastState.Bounded env8101 := by
  intro p hp
  have h : env8101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8100_8101 : H12AffineEnvironment.transform 7 4 env8100 = env8101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8100 == env8101) = true)

def env8102 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,4194304,525637,602937,8224,4980,4457808,5456,5124,4800074,4,603935,525568,4798058,6296341,602191]

theorem envBound8102 : H12AffineFastState.Bounded env8102 := by
  intro p hp
  have h : env8102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8084_8102 : H12AffineEnvironment.transform 6 41 env8084 = env8102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8084 == env8102) = true)

theorem identity8102 : scanCanonicalize (H12AffineFastState.compose env8102 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 2977150) := by decide +kernel

theorem selectedBound8102 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8103 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,2977150,525637,602937,8224,4980,2713646,5456,5124,2380596,4,603935,525568,2382612,884331,602191]

theorem envBound8103 : H12AffineFastState.Bounded env8103 := by
  intro p hp
  have h : env8103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8102_8103 : H12AffineEnvironment.transform 21 2977150 env8102 = env8103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2977150 env8102 == env8103) = true)

def env8104 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,2976810,525329,602733,8224,4640,2713646,5124,5124,2380384,4,603723,525396,2382400,884331,602191]

theorem envBound8104 : H12AffineFastState.Bounded env8104 := by
  intro p hp
  have h : env8104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8103_8104 : H12AffineEnvironment.transform 7 84 env8103 = env8104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8103 == env8104) = true)

def env8105 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,2976811,525328,602732,8224,4641,2713646,5125,5124,2380385,4,603722,525397,2382401,884331,602191]

theorem envBound8105 : H12AffineFastState.Bounded env8105 := by
  intro p hp
  have h : env8105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8103_8105 : H12AffineEnvironment.transform 7 85 env8103 = env8105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8103 == env8105) = true)

theorem identity8105 : scanCanonicalize (H12AffineFastState.compose env8105 (packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 879627) := by decide +kernel

theorem selectedBound8105 : packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env8106 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,879627,32,525328,602732,8224,4641,263205,5125,5124,605802,4,603722,525397,603722,884331,602191]

theorem envBound8106 : H12AffineFastState.Bounded env8106 := by
  intro p hp
  have h : env8106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8105_8106 : H12AffineEnvironment.transform 20 879627 env8105 = env8106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 879627 env8105 == env8106) = true)

theorem identity8106 : scanCanonicalize (H12AffineFastState.compose env8106 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 9262) := by decide +kernel

theorem selectedBound8106 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8107 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,9262,4096,262144,524288,8201,804901,32,525328,529986,8224,4641,263205,5125,5124,531012,4,528996,525397,528996,809541,529505]

theorem envBound8107 : H12AffineFastState.Bounded env8107 := by
  intro p hp
  have h : env8107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8106_8107 : H12AffineEnvironment.transform 15 9262 env8106 = env8107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9262 env8106 == env8107) = true)

theorem identity8107 : scanCanonicalize (H12AffineFastState.compose env8107 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(18+1) ^^^ 267339) := by decide +kernel

theorem selectedBound8107 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env8108 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,9262,4096,262144,267339,8201,23662,32,266331,262665,8224,4641,263205,5125,5124,265743,4,263727,266270,263727,19982,262186]

theorem envBound8108 : H12AffineFastState.Bounded env8108 := by
  intro p hp
  have h : env8108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8107_8108 : H12AffineEnvironment.transform 18 267339 env8107 = env8108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 267339 env8107 == env8108) = true)

theorem identity8108 : scanCanonicalize (H12AffineFastState.compose env8108 (packedSelected [1,5,6,10,11,12] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound8108 : packedSelected [1,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env8109 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,9262,4096,554,5729,8201,23662,32,4721,35,8224,4641,1551,5125,5124,3109,4,1029,4660,1029,19982,512]

theorem envBound8109 : H12AffineFastState.Bounded env8109 := by
  intro p hp
  have h : env8109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8108_8109 : H12AffineEnvironment.transform 17 554 env8108 = env8109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env8108 == env8109) = true)

theorem identity8109 : scanCanonicalize (H12AffineFastState.compose env8109 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 1652) := by decide +kernel

theorem selectedBound8109 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8110 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,1652,8201,9262,4096,554,5729,8201,6682,32,4721,35,8224,4641,1551,5125,5124,3109,4,1029,4660,1029,2170,512]

theorem envBound8110 : H12AffineFastState.Bounded env8110 := by
  intro p hp
  have h : env8110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8109_8110 : H12AffineEnvironment.transform 13 1652 env8109 = env8110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1652 env8109 == env8110) = true)

theorem identity8110 : scanCanonicalize (H12AffineFastState.compose env8110 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 3134) := by decide +kernel

theorem selectedBound8110 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env8111 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,3134,8192,1652,8201,9262,3134,554,2655,8201,1572,32,3663,35,8224,3615,1551,2107,2106,3109,4,1029,3594,1029,2170,512]

theorem envBound8111 : H12AffineFastState.Bounded env8111 := by
  intro p hp
  have h : env8111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8110_8111 : H12AffineEnvironment.transform 11 3134 env8110 = env8111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3134 env8110 == env8111) = true)

theorem identity8111 : scanCanonicalize (H12AffineFastState.compose env8111 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 1036) := by decide +kernel

theorem selectedBound8111 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env8112 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,3134,1036,1652,1029,34,3134,554,2655,1029,1572,32,3663,35,1068,3615,1551,2107,2106,3109,4,1029,3594,1029,2170,512]

theorem envBound8112 : H12AffineFastState.Bounded env8112 := by
  intro p hp
  have h : env8112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8111_8112 : H12AffineEnvironment.transform 12 1036 env8111 = env8112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1036 env8111 == env8112) = true)

def env8113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,4604,262144,524288,8693,2097152,4194304,525804,603025,8329,5084,4457976,5457,5292,4800227,4,604086,525568,4798147,6296340,602190]

theorem envBound8113 : H12AffineFastState.Bounded env8113 := by
  intro p hp
  have h : env8113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8083_8113 : H12AffineEnvironment.transform 23 603025 env8083 = env8113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 603025 env8083 == env8113) = true)

def env8114 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,4194304,525636,602937,8225,4980,4457808,5457,5124,4800075,4,603934,525568,4798059,6296340,602190]

theorem envBound8114 : H12AffineFastState.Bounded env8114 := by
  intro p hp
  have h : env8114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8113_8114 : H12AffineEnvironment.transform 6 40 env8113 = env8114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8113 == env8114) = true)

theorem identity8114 : scanCanonicalize (H12AffineFastState.compose env8114 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 2977150) := by decide +kernel

theorem selectedBound8114 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8115 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,4436,262144,524288,8541,2097152,2977150,525636,602937,8225,4980,2713646,5457,5124,2380597,4,603934,525568,2382613,884330,602190]

theorem envBound8115 : H12AffineFastState.Bounded env8115 := by
  intro p hp
  have h : env8115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8114_8115 : H12AffineEnvironment.transform 21 2977150 env8114 = env8115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2977150 env8114 == env8115) = true)

def env8116 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8201,65536,4096,262144,524288,8201,2097152,2976810,525328,602733,8225,4640,2713646,5125,5124,2380385,4,603722,525396,2382401,884330,602190]

theorem envBound8116 : H12AffineFastState.Bounded env8116 := by
  intro p hp
  have h : env8116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8115_8116 : H12AffineEnvironment.transform 7 84 env8115 = env8116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8115 == env8116) = true)

def env8117 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,2097152,2976811,525329,602732,8225,4641,2713646,5124,5124,2380384,4,603723,525397,2382400,884330,602190]

theorem envBound8117 : H12AffineFastState.Bounded env8117 := by
  intro p hp
  have h : env8117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8115_8117 : H12AffineEnvironment.transform 7 85 env8115 = env8117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8115 == env8117) = true)

theorem identity8117 : scanCanonicalize (H12AffineFastState.compose env8117 (packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 879626) := by decide +kernel

theorem selectedBound8117 : packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env8118 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,524288,8200,879626,33,525329,602732,8225,4641,263204,5124,5124,605802,4,603723,525397,603722,884330,602190]

theorem envBound8118 : H12AffineFastState.Bounded env8118 := by
  intro p hp
  have h : env8118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8117_8118 : H12AffineEnvironment.transform 20 879626 env8117 = env8118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 879626 env8117 == env8118) = true)

theorem identity8118 : scanCanonicalize (H12AffineFastState.compose env8118 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(18+1) ^^^ 78414) := by decide +kernel

theorem selectedBound8118 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8119 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,78414,8200,286276,33,79455,34,8225,4641,263204,5124,5124,3108,4,1029,79387,1028,281636,512]

theorem envBound8119 : H12AffineFastState.Bounded env8119 := by
  intro p hp
  have h : env8119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8118_8119 : H12AffineEnvironment.transform 18 78414 env8118 = env8119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78414 env8118 == env8119) = true)

theorem identity8119 : scanCanonicalize (H12AffineFastState.compose env8119 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 7780) := by decide +kernel

theorem selectedBound8119 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8120 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,65536,4097,7780,78414,8200,16416,33,79455,34,8225,4641,6720,5124,5124,3108,4,1029,79387,1028,21056,512]

theorem envBound8120 : H12AffineFastState.Bounded env8120 := by
  intro p hp
  have h : env8120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8119_8120 : H12AffineEnvironment.transform 17 7780 env8119 = env8120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7780 env8119 == env8120) = true)

theorem identity8120 : scanCanonicalize (H12AffineFastState.compose env8120 (packedSelected [1,8,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 12907) := by decide +kernel

theorem selectedBound8120 : packedSelected [1,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env8121 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8200,12907,4097,7780,37,8200,16416,33,1076,34,8225,4641,6720,5124,5124,3108,4,1029,1136,1028,21056,512]

theorem envBound8121 : H12AffineFastState.Bounded env8121 := by
  intro p hp
  have h : env8121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8120_8121 : H12AffineEnvironment.transform 15 12907 env8120 = env8121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12907 env8120 == env8121) = true)

theorem identity8121 : scanCanonicalize (H12AffineFastState.compose env8121 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(13+1) ^^^ 11340) := by decide +kernel

theorem selectedBound8121 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env8122 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,11340,8200,12907,4097,7780,37,8200,11372,33,1076,34,8225,4641,6720,5124,5124,3108,4,1029,1136,1028,15884,512]

theorem envBound8122 : H12AffineFastState.Bounded env8122 := by
  intro p hp
  have h : env8122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8121_8122 : H12AffineEnvironment.transform 13 11340 env8121 = env8122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11340 env8121 == env8122) = true)

theorem identity8122 : scanCanonicalize (H12AffineFastState.compose env8122 (packedSelected [0,1,2,3,4,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound8122 : packedSelected [0,1,2,3,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env8123 : List Nat := [2,4,8,16,32,64,40,85,512,1024,17,4096,8192,9309,8200,12907,4097,5749,37,8200,9341,33,1076,34,8225,4641,4689,5124,5124,1077,4,1029,1136,1028,13853,512]

theorem envBound8123 : H12AffineFastState.Bounded env8123 := by
  intro p hp
  have h : env8123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8122_8123 : H12AffineEnvironment.transform 10 17 env8122 = env8123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env8122 == env8123) = true)

theorem identity8123 : scanCanonicalize (H12AffineFastState.compose env8123 (packedSelected [0,2,3,4,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 4729) := by decide +kernel

theorem selectedBound8123 : packedSelected [0,2,3,4,5,6,10] rootPS < 2^1333 := by decide +kernel

def env8124 : List Nat := [2,4,8,16,32,64,40,85,512,1024,17,4096,4729,5668,4721,18,4097,5749,37,4721,5636,33,1076,34,4696,4641,4689,5124,5124,1077,4,1029,1136,1028,1124,512]

theorem envBound8124 : H12AffineFastState.Bounded env8124 := by
  intro p hp
  have h : env8124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8123_8124 : H12AffineEnvironment.transform 12 4729 env8123 = env8124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4729 env8123 == env8124) = true)

theorem identity8124 : scanCanonicalize (H12AffineFastState.compose env8124 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1119) := by decide +kernel

theorem selectedBound8124 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env8125 : List Nat := [2,4,8,16,32,64,40,85,512,1024,17,1119,1574,635,1582,18,1118,554,37,1582,603,33,1076,34,1543,1662,1550,91,91,1077,4,1029,1136,1028,1124,512]

theorem envBound8125 : H12AffineFastState.Bounded env8125 := by
  intro p hp
  have h : env8125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8124_8125 : H12AffineEnvironment.transform 11 1119 env8124 = env8125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1119 env8124 == env8125) = true)

theorem identity8125 : scanCanonicalize (H12AffineFastState.compose env8125 (packedSelected [6,11] rootPS)) = affineNative (2^(9+1) ^^^ 622) := by decide +kernel

theorem selectedBound8125 : packedSelected [6,11] rootPS < 2^1333 := by decide +kernel

def env8126 : List Nat := [2,4,8,16,32,64,40,85,512,622,17,561,72,635,64,18,560,554,37,64,603,33,602,34,105,16,96,91,91,603,4,619,542,618,522,512]

theorem envBound8126 : H12AffineFastState.Bounded env8126 := by
  intro p hp
  have h : env8126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8125_8126 : H12AffineEnvironment.transform 9 622 env8125 = env8126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 622 env8125 == env8126) = true)

theorem identity8126 : scanCanonicalize (H12AffineFastState.compose env8126 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound8126 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env8127 : List Nat := [2,4,8,16,32,10,40,31,512,548,17,561,2,561,10,18,560,554,37,10,529,33,528,34,35,16,42,17,17,529,4,545,542,544,522,512]

theorem envBound8127 : H12AffineFastState.Bounded env8127 := by
  intro p hp
  have h : env8127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8126_8127 : H12AffineEnvironment.transform 5 10 env8126 = env8127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env8126 == env8127) = true)

theorem identity8127 : scanCanonicalize (H12AffineFastState.compose env8127 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8127 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env8128 : List Nat := [2,4,8,10,32,10,40,5,512,548,11,555,2,555,10,8,554,554,37,10,523,33,522,34,35,10,42,11,11,523,4,545,516,544,522,512]

theorem envBound8128 : H12AffineFastState.Bounded env8128 := by
  intro p hp
  have h : env8128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8127_8128 : H12AffineEnvironment.transform 3 10 env8127 = env8128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8127 == env8128) = true)

theorem identity8128 : scanCanonicalize (H12AffineFastState.compose env8128 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound8128 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8129 : List Nat := [2,4,8,10,32,10,40,5,1,37,11,42,2,42,10,8,43,43,37,10,10,33,11,34,35,10,42,11,11,10,4,32,5,33,11,1]

theorem envBound8129 : H12AffineFastState.Bounded env8129 := by
  intro p hp
  have h : env8129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8128_8129 : H12AffineEnvironment.transform 8 1 env8128 = env8129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env8128 == env8129) = true)

theorem identity8129 : scanCanonicalize (H12AffineFastState.compose env8129 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8129 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8130 : List Nat := [2,4,8,10,0,10,8,5,1,5,11,10,2,10,10,8,11,11,5,10,10,1,11,2,3,10,10,11,11,10,4,0,5,1,11,1]

theorem envBound8130 : H12AffineFastState.Bounded env8130 := by
  intro p hp
  have h : env8130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8129_8130 : H12AffineEnvironment.transform 4 0 env8129 = env8130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8129 == env8130) = true)

def env8131 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,4194304,525637,602936,8224,4981,4457809,5457,5125,4800074,4,603935,525568,4798058,6296340,602190]

theorem envBound8131 : H12AffineFastState.Bounded env8131 := by
  intro p hp
  have h : env8131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8113_8131 : H12AffineEnvironment.transform 6 41 env8113 = env8131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8113 == env8131) = true)

theorem identity8131 : scanCanonicalize (H12AffineFastState.compose env8131 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound8131 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env8132 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,2097152,372,525637,602936,8224,4981,263205,5457,5125,606014,4,603935,525568,603934,2101856,602190]

theorem envBound8132 : H12AffineFastState.Bounded env8132 := by
  intro p hp
  have h : env8132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8131_8132 : H12AffineEnvironment.transform 21 372 env8131 = env8132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env8131 == env8132) = true)

theorem identity8132 : scanCanonicalize (H12AffineFastState.compose env8132 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 806261) := by decide +kernel

theorem selectedBound8132 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env8133 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,524288,8540,806261,372,525637,602936,8224,4981,263205,5457,5125,606014,4,603935,525568,603934,810773,602190]

theorem envBound8133 : H12AffineFastState.Bounded env8133 := by
  intro p hp
  have h : env8133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8132_8133 : H12AffineEnvironment.transform 20 806261 env8132 = env8133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 806261 env8132 == env8133) = true)

theorem identity8133 : scanCanonicalize (H12AffineFastState.compose env8133 (packedSelected [0,7,20] rootPS)) = affineNative (2^(18+1) ^^^ 78619) := by decide +kernel

theorem selectedBound8133 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8134 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,4437,262144,78619,8540,360046,372,79454,35,8224,4981,263205,5457,5125,3109,4,1028,79387,1029,355342,853]

theorem envBound8134 : H12AffineFastState.Bounded env8134 := by
  intro p hp
  have h : env8134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8133_8134 : H12AffineEnvironment.transform 18 78619 env8133 = env8134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78619 env8133 == env8134) = true)

theorem identity8134 : scanCanonicalize (H12AffineFastState.compose env8134 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 9594) := by decide +kernel

theorem selectedBound8134 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env8135 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,9594,4437,262144,5729,8540,285460,372,4900,35,8224,4981,263205,5457,5125,3109,4,1028,4961,1029,280948,853]

theorem envBound8135 : H12AffineFastState.Bounded env8135 := by
  intro p hp
  have h : env8135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8134_8135 : H12AffineEnvironment.transform 15 9594 env8134 = env8135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9594 env8134 == env8135) = true)

theorem identity8135 : scanCanonicalize (H12AffineFastState.compose env8135 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 24902) := by decide +kernel

theorem selectedBound8135 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env8136 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,9594,4437,24902,5729,8540,14930,372,4900,35,8224,4981,25955,5457,5125,3109,4,1028,4961,1029,10290,853]

theorem envBound8136 : H12AffineFastState.Bounded env8136 := by
  intro p hp
  have h : env8136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8135_8136 : H12AffineEnvironment.transform 17 24902 env8135 = env8136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 24902 env8135 == env8136) = true)

theorem identity8136 : scanCanonicalize (H12AffineFastState.compose env8136 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 6259) := by decide +kernel

theorem selectedBound8136 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env8137 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,6259,16384,6447,7433,4437,22837,5729,6447,545,372,4900,35,6227,4981,23824,5457,5125,3109,4,1028,4961,1029,4161,853]

theorem envBound8137 : H12AffineFastState.Bounded env8137 := by
  intro p hp
  have h : env8137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8136_8137 : H12AffineEnvironment.transform 12 6259 env8136 = env8137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6259 env8136 == env8137) = true)

theorem identity8137 : scanCanonicalize (H12AffineFastState.compose env8137 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 625) := by decide +kernel

theorem selectedBound8137 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8138 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,6259,625,6447,7433,4437,6980,5729,6447,545,372,4900,35,6227,4981,8033,5457,5125,3109,4,1028,4961,1029,4161,853]

theorem envBound8138 : H12AffineFastState.Bounded env8138 := by
  intro p hp
  have h : env8138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8137_8138 : H12AffineEnvironment.transform 13 625 env8137 = env8138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 625 env8137 == env8138) = true)

theorem identity8138 : scanCanonicalize (H12AffineFastState.compose env8138 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound8138 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env8139 : List Nat := [2,4,8,16,32,64,41,256,512,1024,522,4096,4729,625,4901,5891,4437,4430,5729,4901,545,372,4900,35,4697,4981,5483,5457,5125,1583,4,1028,4961,1029,4161,853]

theorem envBound8139 : H12AffineFastState.Bounded env8139 := by
  intro p hp
  have h : env8139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8138_8139 : H12AffineEnvironment.transform 10 522 env8138 = env8139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env8138 == env8139) = true)

theorem identity8139 : scanCanonicalize (H12AffineFastState.compose env8139 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8139 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env8140 : List Nat := [2,4,8,16,32,1,41,256,512,1024,522,4096,4664,560,4901,5891,4372,4367,5664,4901,545,309,4900,35,4632,4916,5418,5392,5125,1583,4,1028,4896,1029,4096,788]

theorem envBound8140 : H12AffineFastState.Bounded env8140 := by
  intro p hp
  have h : env8140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8139_8140 : H12AffineEnvironment.transform 5 1 env8139 = env8140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8139 == env8140) = true)

theorem identity8140 : scanCanonicalize (H12AffineFastState.compose env8140 (packedSelected [0,3,4,6,8,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound8140 : packedSelected [0,3,4,6,8,11,13] rootPS < 2^1333 := by decide +kernel

def env8141 : List Nat := [2,4,8,16,32,1,41,256,512,1024,522,1044,1580,560,1841,791,1280,1307,564,1841,545,309,1840,35,1548,1824,318,260,17,1583,4,1028,1844,1029,1044,788]

theorem envBound8141 : H12AffineFastState.Bounded env8141 := by
  intro p hp
  have h : env8141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8140_8141 : H12AffineEnvironment.transform 11 1044 env8140 = env8141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env8140 == env8141) = true)

def env8142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,525805,16777216,8329,67108864,134217728,268435456,268435964,151259274,84509117,155492395,525568,151257258,34359738368,16818731]

theorem envBound8142 : H12AffineFastState.Bounded env8142 := by
  intro p hp
  have h : env8142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7631_8142 : H12AffineEnvironment.transform 16 4605 env7631 = env8142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4605 env7631 == env8142) = true)

theorem identity8142 : scanCanonicalize (H12AffineFastState.compose env8142 (packedSelected [5,8,12,13,15,17,24,26,28,31,38,41] rootPS)) = affineNative (2^(34+1) ^^^ 203784470) := by decide +kernel

theorem selectedBound8142 : packedSelected [5,8,12,13,15,17,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env8143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,525805,16777216,8329,67108864,134217728,268435456,268435964,151259274,84509117,155492395,525568,151257258,203784470,16818731]

theorem envBound8143 : H12AffineFastState.Bounded env8143 := by
  intro p hp
  have h : env8143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8142_8143 : H12AffineEnvironment.transform 34 203784470 env8142 = env8143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 203784470 env8142 == env8143) = true)

def env8144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,525805,16777216,8329,67108864,134217728,268435456,268435964,151259274,84484169,155451871,525568,151257258,203759842,16778207]

theorem envBound8144 : H12AffineFastState.Bounded env8144 := by
  intro p hp
  have h : env8144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8143_8144 : H12AffineEnvironment.transform 14 8692 env8143 = env8144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env8143 == env8144) = true)

def env8145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,525805,16777216,8329,67108864,134217728,138678440,138678612,151259274,84484169,155451871,525568,151257258,203759842,16778207]

theorem envBound8145 : H12AffineFastState.Bounded env8145 := by
  intro p hp
  have h : env8145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8144_8145 : H12AffineEnvironment.transform 27 138678440 env8144 = env8145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 138678440 env8144 == env8145) = true)

theorem identity8145 : scanCanonicalize (H12AffineFastState.compose env8145 (packedSelected [9,14,22] rootPS)) = affineNative (2^(25+1) ^^^ 16857040) := by decide +kernel

theorem selectedBound8145 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env8146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,525805,16777216,8329,16857040,134217728,138678440,138678612,151259274,530329,155451871,525568,151257258,153360178,16778207]

theorem envBound8146 : H12AffineFastState.Bounded env8146 := by
  intro p hp
  have h : env8146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8145_8146 : H12AffineEnvironment.transform 25 16857040 env8145 = env8146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 16857040 env8145 == env8146) = true)

def env8147 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524525,16777216,8329,16855760,134217728,138678440,138678612,151259274,529049,155451871,524288,151257258,153358898,16778207]

theorem envBound8147 : H12AffineFastState.Bounded env8147 := by
  intro p hp
  have h : env8147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8146_8147 : H12AffineEnvironment.transform 9 256 env8146 = env8147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env8146 == env8147) = true)

def env8148 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524525,16777216,8329,16855760,807680,4735912,4735572,17324938,529049,21517023,524288,17322922,19415346,16778207]

theorem envBound8148 : H12AffineFastState.Bounded env8148 := by
  intro p hp
  have h : env8148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8147_8148 : H12AffineEnvironment.transform 26 807680 env8147 = env8148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 807680 env8147 == env8148) = true)

def env8149 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524525,90336,8329,21040,807680,4735912,4735572,605034,529049,4796991,524288,602954,2695634,90943]

theorem envBound8149 : H12AffineFastState.Bounded env8149 := by
  intro p hp
  have h : env8149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8148_8149 : H12AffineEnvironment.transform 23 90336 env8148 = env8149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env8148 == env8149) = true)

def env8150 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,4960,8692,2097152,4194304,5005,90336,8329,21040,278624,4214984,4215092,75786,505,4268383,4960,73770,2175666,90943]

theorem envBound8150 : H12AffineFastState.Bounded env8150 := by
  intro p hp
  have h : env8150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8149_8150 : H12AffineEnvironment.transform 18 4960 env8149 = env8150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env8149 == env8150) = true)

theorem identity8150 : scanCanonicalize (H12AffineFastState.compose env8150 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8150 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8151 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,2097152,4194304,4720,90336,8329,21040,278624,4214984,4214985,75786,4,4268194,4765,73770,2175666,90818]

theorem envBound8151 : H12AffineFastState.Bounded env8151 := by
  intro p hp
  have h : env8151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8150_8151 : H12AffineEnvironment.transform 7 253 env8150 = env8151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8150 == env8151) = true)

def env8152 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,64,4194304,4720,90336,8329,21040,278624,4214984,4214985,75786,4,4268194,4765,73770,78578,90818]

theorem envBound8152 : H12AffineFastState.Bounded env8152 := by
  intro p hp
  have h : env8152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8151_8152 : H12AffineEnvironment.transform 20 64 env8151 = env8152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8151 == env8152) = true)

theorem identity8152 : scanCanonicalize (H12AffineFastState.compose env8152 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 356600) := by decide +kernel

theorem selectedBound8152 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8153 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,64,356600,4720,90336,8329,21040,278624,335920,335921,75786,4,282714,4765,73770,78578,90818]

theorem envBound8153 : H12AffineFastState.Bounded env8153 := by
  intro p hp
  have h : env8153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8152_8153 : H12AffineEnvironment.transform 21 356600 env8152 = env8153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 356600 env8152 == env8153) = true)

def env8154 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8201,65536,4096,262144,4645,8201,64,356416,4720,90200,8241,21040,278624,335920,335921,75786,4,282714,4645,73770,78410,90746]

theorem envBound8154 : H12AffineFastState.Bounded env8154 := by
  intro p hp
  have h : env8154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8153_8154 : H12AffineEnvironment.transform 6 56 env8153 = env8154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env8153 == env8154) = true)

theorem identity8154 : scanCanonicalize (H12AffineFastState.compose env8154 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 90209) := by decide +kernel

theorem selectedBound8154 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8155 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8201,65536,4096,90209,4645,8201,64,4129,4720,90200,8241,21040,73729,16465,16464,75786,4,77883,4645,73770,78410,90746]

theorem envBound8155 : H12AffineFastState.Bounded env8155 := by
  intro p hp
  have h : env8155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8154_8155 : H12AffineEnvironment.transform 17 90209 env8154 = env8155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90209 env8154 == env8155) = true)

def env8156 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,4704,8201,65536,4096,78337,4645,8201,64,4129,4720,78392,8241,80,73729,4657,4656,75786,4,77883,4645,73770,78410,77850]

theorem envBound8156 : H12AffineFastState.Bounded env8156 := by
  intro p hp
  have h : env8156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8155_8156 : H12AffineEnvironment.transform 13 4704 env8155 = env8156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4704 env8155 == env8156) = true)

theorem identity8156 : scanCanonicalize (H12AffineFastState.compose env8156 (packedSelected [1,3,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound8156 : packedSelected [1,3,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env8157 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,4704,8201,8314,4096,4731,4645,8201,64,4129,4720,4674,8241,80,123,4657,4656,2160,4,4161,4645,80,4656,4192]

theorem envBound8157 : H12AffineFastState.Bounded env8157 := by
  intro p hp
  have h : env8157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8156_8157 : H12AffineEnvironment.transform 15 8314 env8156 = env8157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env8156 == env8157) = true)

theorem identity8157 : scanCanonicalize (H12AffineFastState.compose env8157 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 587) := by decide +kernel

theorem selectedBound8157 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env8158 : List Nat := [2,4,8,16,32,64,56,69,512,69,587,4096,8192,4704,8201,8314,4096,4731,4645,8201,64,4129,4720,4674,8241,80,123,4657,4656,571,4,4161,4645,80,4656,4192]

theorem envBound8158 : H12AffineFastState.Bounded env8158 := by
  intro p hp
  have h : env8158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8157_8158 : H12AffineEnvironment.transform 10 587 env8157 = env8158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 587 env8157 == env8158) = true)

theorem identity8158 : scanCanonicalize (H12AffineFastState.compose env8158 (packedSelected [1,3,4,5,8,9,10,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound8158 : packedSelected [1,3,4,5,8,9,10,19,20] rootPS < 2^1333 := by decide +kernel

def env8159 : List Nat := [2,4,8,16,32,64,56,69,512,69,587,17,8192,625,8201,8314,17,618,564,8201,64,48,609,595,8241,80,123,544,545,571,4,80,564,80,545,113]

theorem envBound8159 : H12AffineFastState.Bounded env8159 := by
  intro p hp
  have h : env8159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8158_8159 : H12AffineEnvironment.transform 11 17 env8158 = env8159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env8158 == env8159) = true)

theorem identity8159 : scanCanonicalize (H12AffineFastState.compose env8159 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8159 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8160 : List Nat := [2,4,8,0,32,64,40,69,512,69,587,1,8192,609,8201,8298,1,618,548,8201,64,32,609,579,8225,64,107,544,545,555,4,64,548,64,545,97]

theorem envBound8160 : H12AffineFastState.Bounded env8160 := by
  intro p hp
  have h : env8160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8159_8160 : H12AffineEnvironment.transform 3 0 env8159 = env8160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8159 == env8160) = true)

theorem identity8160 : scanCanonicalize (H12AffineFastState.compose env8160 (packedSelected [0,1,2,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 616) := by decide +kernel

theorem selectedBound8160 : packedSelected [0,1,2,8,9] rootPS < 2^1333 := by decide +kernel

def env8161 : List Nat := [2,4,8,0,32,64,40,69,512,69,587,1,616,609,609,514,1,618,548,609,64,32,609,579,585,64,107,544,545,555,4,64,548,64,545,97]

theorem envBound8161 : H12AffineFastState.Bounded env8161 := by
  intro p hp
  have h : env8161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8160_8161 : H12AffineEnvironment.transform 12 616 env8160 = env8161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 616 env8160 == env8161) = true)

theorem identity8161 : scanCanonicalize (H12AffineFastState.compose env8161 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8161 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env8162 : List Nat := [2,4,8,0,11,64,3,69,512,69,587,1,579,586,586,514,1,577,527,586,64,11,586,579,585,64,64,523,522,512,4,64,527,64,522,74]

theorem envBound8162 : H12AffineFastState.Bounded env8162 := by
  intro p hp
  have h : env8162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8161_8162 : H12AffineEnvironment.transform 4 11 env8161 = env8162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8161 == env8162) = true)

theorem identity8162 : scanCanonicalize (H12AffineFastState.compose env8162 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound8162 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8163 : List Nat := [2,4,8,0,11,64,3,69,0,69,75,1,67,74,74,2,1,65,15,74,64,11,74,67,73,64,64,11,10,0,4,64,15,64,10,74]

theorem envBound8163 : H12AffineFastState.Bounded env8163 := by
  intro p hp
  have h : env8163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8162_8163 : H12AffineEnvironment.transform 8 0 env8162 = env8163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env8162 == env8163) = true)

def env8164 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,4705,8201,65536,4096,78336,4645,8201,64,4129,4720,78393,8241,81,73729,4656,4657,75786,4,77883,4645,73770,78410,77851]

theorem envBound8164 : H12AffineFastState.Bounded env8164 := by
  intro p hp
  have h : env8164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8155_8164 : H12AffineEnvironment.transform 13 4705 env8155 = env8164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4705 env8155 == env8164) = true)

theorem identity8164 : scanCanonicalize (H12AffineFastState.compose env8164 (packedSelected [1,3,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound8164 : packedSelected [1,3,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env8165 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,4705,8201,8714,4096,4106,4645,8201,64,4129,4720,4147,8241,81,523,4656,4657,2560,4,4657,4645,544,4160,4625]

theorem envBound8165 : H12AffineFastState.Bounded env8165 := by
  intro p hp
  have h : env8165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8164_8165 : H12AffineEnvironment.transform 15 8714 env8164 = env8165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env8164 == env8165) = true)

theorem identity8165 : scanCanonicalize (H12AffineFastState.compose env8165 (packedSelected [2,5,8,10,11,12,15,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound8165 : packedSelected [2,5,8,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env8166 : List Nat := [2,4,8,16,32,64,56,69,113,69,2048,4096,8192,4112,8201,8315,4096,4106,4180,8201,64,4129,4097,4147,8241,81,122,4161,4160,2161,4,4160,4180,81,4160,4192]

theorem envBound8166 : H12AffineFastState.Bounded env8166 := by
  intro p hp
  have h : env8166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8165_8166 : H12AffineEnvironment.transform 8 113 env8165 = env8166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env8165 == env8166) = true)

theorem identity8166 : scanCanonicalize (H12AffineFastState.compose env8166 (packedSelected [1,5,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2171) := by decide +kernel

theorem selectedBound8166 : packedSelected [1,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env8167 : List Nat := [2,4,8,16,32,64,56,69,113,69,2048,2171,8192,2155,8201,8315,2171,2161,2095,8201,64,2138,2170,2120,8241,81,122,2106,2107,2161,4,2107,2095,81,2107,2075]

theorem envBound8167 : H12AffineFastState.Bounded env8167 := by
  intro p hp
  have h : env8167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8166_8167 : H12AffineEnvironment.transform 11 2171 env8166 = env8167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2171 env8166 == env8167) = true)

theorem identity8167 : scanCanonicalize (H12AffineFastState.compose env8167 (packedSelected [0,1,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound8167 : packedSelected [0,1,8,9,11] rootPS < 2^1333 := by decide +kernel

def env8168 : List Nat := [2,4,8,16,32,64,56,69,113,69,2048,2171,9,2155,0,114,2171,2161,2095,0,64,2138,2170,2120,56,81,122,2106,2107,2161,4,2107,2095,81,2107,2075]

theorem envBound8168 : H12AffineFastState.Bounded env8168 := by
  intro p hp
  have h : env8168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8167_8168 : H12AffineEnvironment.transform 12 9 env8167 = env8168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env8167 == env8168) = true)

theorem identity8168 : scanCanonicalize (H12AffineFastState.compose env8168 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8168 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env8169 : List Nat := [2,4,8,0,32,64,40,69,97,69,2048,2155,9,2155,0,98,2155,2145,2095,0,64,2122,2154,2120,40,65,106,2090,2091,2145,4,2091,2095,65,2091,2059]

theorem envBound8169 : H12AffineFastState.Bounded env8169 := by
  intro p hp
  have h : env8169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8168_8169 : H12AffineEnvironment.transform 3 0 env8168 = env8169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8168 == env8169) = true)

theorem identity8169 : scanCanonicalize (H12AffineFastState.compose env8169 (packedSelected [0,1,2,3,4,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound8169 : packedSelected [0,1,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env8170 : List Nat := [2,4,8,0,32,10,40,15,43,15,2048,2081,9,2081,0,40,2081,2091,2095,0,10,2048,2080,2050,40,11,32,2090,2091,2091,4,2091,2095,11,2091,2059]

theorem envBound8170 : H12AffineFastState.Bounded env8170 := by
  intro p hp
  have h : env8170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8169_8170 : H12AffineEnvironment.transform 5 10 env8169 = env8170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env8169 == env8170) = true)

theorem identity8170 : scanCanonicalize (H12AffineFastState.compose env8170 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8170 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env8171 : List Nat := [2,4,8,0,0,10,8,15,11,15,2048,2049,9,2049,0,8,2049,2059,2063,0,10,2048,2048,2050,8,11,0,2058,2059,2059,4,2059,2063,11,2059,2059]

theorem envBound8171 : H12AffineFastState.Bounded env8171 := by
  intro p hp
  have h : env8171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8170_8171 : H12AffineEnvironment.transform 4 0 env8170 = env8171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8170 == env8171) = true)

theorem identity8171 : scanCanonicalize (H12AffineFastState.compose env8171 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound8171 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8172 : List Nat := [2,4,8,0,0,10,8,15,11,15,0,1,9,1,0,8,1,11,15,0,10,0,0,2,8,11,0,10,11,11,4,11,15,11,11,11]

theorem envBound8172 : H12AffineFastState.Bounded env8172 := by
  intro p hp
  have h : env8172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8171_8172 : H12AffineEnvironment.transform 10 0 env8171 = env8172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8171 == env8172) = true)

theorem identity8172 : scanCanonicalize (H12AffineFastState.compose env8172 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8172 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8173 : List Nat := [2,4,3,0,0,1,3,4,0,4,0,1,2,1,0,3,1,0,4,0,1,0,0,2,3,0,0,1,0,0,4,0,4,0,0,0]

theorem envBound8173 : H12AffineFastState.Bounded env8173 := by
  intro p hp
  have h : env8173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8172_8173 : H12AffineEnvironment.transform 2 3 env8172 = env8173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8172 == env8173) = true)

def env8174 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8201,65536,4096,262144,4644,8201,64,356417,4720,90201,8240,21040,278624,335920,335921,75786,4,282714,4644,73770,78411,90747]

theorem envBound8174 : H12AffineFastState.Bounded env8174 := by
  intro p hp
  have h : env8174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8153_8174 : H12AffineEnvironment.transform 6 57 env8153 = env8174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env8153 == env8174) = true)

theorem identity8174 : scanCanonicalize (H12AffineFastState.compose env8174 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 28779) := by decide +kernel

theorem selectedBound8174 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8175 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8201,28779,4096,262144,4644,8201,64,262186,4720,4146,8240,21040,278624,282715,282714,22625,4,282714,4644,20545,16928,4624]

theorem envBound8175 : H12AffineFastState.Bounded env8175 := by
  intro p hp
  have h : env8175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8174_8175 : H12AffineEnvironment.transform 15 28779 env8174 = env8175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28779 env8174 == env8175) = true)

def env8176 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,4640,8201,8779,4096,262144,4644,8201,64,262186,4720,4146,8240,16,266816,262779,262778,2625,4,262778,4644,609,4096,4624]

theorem envBound8176 : H12AffineFastState.Bounded env8176 := by
  intro p hp
  have h : env8176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8175_8176 : H12AffineEnvironment.transform 13 4640 env8175 = env8176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4640 env8175 == env8176) = true)

def env8177 : List Nat := [2,4,8,16,32,0,57,4,512,4,2048,4096,8192,4640,8201,8715,4096,262144,4644,8201,0,262186,4656,4146,8240,16,266752,262715,262714,2561,4,262714,4644,545,4096,4624]

theorem envBound8177 : H12AffineFastState.Bounded env8177 := by
  intro p hp
  have h : env8177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8176_8177 : H12AffineEnvironment.transform 5 0 env8176 = env8177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8176 == env8177) = true)

theorem identity8177 : scanCanonicalize (H12AffineFastState.compose env8177 (packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound8177 : packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8178 : List Nat := [2,4,8,16,32,0,57,4,512,4,2048,2587,8192,2107,8201,8715,2587,262144,2111,8201,0,262186,2091,2601,8240,16,264219,262715,262714,2561,4,262714,2111,545,2587,2059]

theorem envBound8178 : H12AffineFastState.Bounded env8178 := by
  intro p hp
  have h : env8178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8177_8178 : H12AffineEnvironment.transform 11 2587 env8177 = env8178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env8177 == env8178) = true)

theorem identity8178 : scanCanonicalize (H12AffineFastState.compose env8178 (packedSelected [0,1,5,7,10,12,14,15,20] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound8178 : packedSelected [0,1,5,7,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env8179 : List Nat := [2,4,8,16,32,0,57,4,48,4,2048,2091,8192,2107,8201,8251,2091,262144,2111,8201,0,262186,2091,2073,8240,16,264219,262155,262154,2097,4,262154,2111,17,2091,2059]

theorem envBound8179 : H12AffineFastState.Bounded env8179 := by
  intro p hp
  have h : env8179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8178_8179 : H12AffineEnvironment.transform 8 48 env8178 = env8179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env8178 == env8179) = true)

theorem identity8179 : scanCanonicalize (H12AffineFastState.compose env8179 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(17+1) ^^^ 10) := by decide +kernel

theorem selectedBound8179 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env8180 : List Nat := [2,4,8,16,32,0,57,4,48,4,2048,2091,8192,2107,8201,8251,2091,10,2111,8201,0,32,2091,2073,8240,16,2065,1,0,2097,4,0,2111,17,2091,2059]

theorem envBound8180 : H12AffineFastState.Bounded env8180 := by
  intro p hp
  have h : env8180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8179_8180 : H12AffineEnvironment.transform 17 10 env8179 = env8180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10 env8179 == env8180) = true)

theorem identity8180 : scanCanonicalize (H12AffineFastState.compose env8180 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound8180 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env8181 : List Nat := [2,4,8,16,32,0,57,4,48,4,43,0,8192,16,8201,8251,0,10,20,8201,0,32,0,50,8240,16,58,1,0,26,4,0,20,17,0,32]

theorem envBound8181 : H12AffineFastState.Bounded env8181 := by
  intro p hp
  have h : env8181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8180_8181 : H12AffineEnvironment.transform 10 43 env8180 = env8181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env8180 == env8181) = true)

theorem identity8181 : scanCanonicalize (H12AffineFastState.compose env8181 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound8181 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8182 : List Nat := [2,4,8,16,32,0,57,4,48,4,43,0,50,16,59,9,0,10,20,59,0,32,0,50,2,16,58,1,0,26,4,0,20,17,0,32]

theorem envBound8182 : H12AffineFastState.Bounded env8182 := by
  intro p hp
  have h : env8182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8181_8182 : H12AffineEnvironment.transform 12 50 env8181 = env8182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env8181 == env8182) = true)

theorem identity8182 : scanCanonicalize (H12AffineFastState.compose env8182 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8182 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8183 : List Nat := [2,4,8,16,11,0,18,4,27,4,0,0,25,16,16,9,0,10,20,16,0,11,0,25,2,16,17,1,0,26,4,0,20,17,0,11]

theorem envBound8183 : H12AffineFastState.Bounded env8183 := by
  intro p hp
  have h : env8183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8182_8183 : H12AffineEnvironment.transform 4 11 env8182 = env8183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8182 == env8183) = true)

theorem identity8183 : scanCanonicalize (H12AffineFastState.compose env8183 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8183 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8184 : List Nat := [2,4,3,16,0,0,18,4,16,4,0,0,18,16,16,2,0,1,20,16,0,0,0,18,2,16,17,1,0,17,4,0,20,17,0,0]

theorem envBound8184 : H12AffineFastState.Bounded env8184 := by
  intro p hp
  have h : env8184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8183_8184 : H12AffineEnvironment.transform 2 3 env8183 = env8184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8183 == env8184) = true)

theorem identity8184 : scanCanonicalize (H12AffineFastState.compose env8184 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8184 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8185 : List Nat := [2,4,3,0,0,0,2,4,0,4,0,0,2,0,0,2,0,1,4,0,0,0,0,2,2,0,1,1,0,1,4,0,4,1,0,0]

theorem envBound8185 : H12AffineFastState.Bounded env8185 := by
  intro p hp
  have h : env8185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8184_8185 : H12AffineEnvironment.transform 3 0 env8184 = env8185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8184 == env8185) = true)

def env8186 : List Nat := [2,4,8,16,32,1,57,5,512,5,2048,4096,8192,4640,8201,8714,4096,262144,4644,8201,1,262186,4657,4146,8240,16,266753,262714,262715,2560,4,262715,4644,544,4096,4624]

theorem envBound8186 : H12AffineFastState.Bounded env8186 := by
  intro p hp
  have h : env8186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8176_8186 : H12AffineEnvironment.transform 5 1 env8176 = env8186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8176 == env8186) = true)

theorem identity8186 : scanCanonicalize (H12AffineFastState.compose env8186 (packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS)) = affineNative (2^(17+1) ^^^ 6656) := by decide +kernel

theorem selectedBound8186 : packedSelected [2,3,8,11,12,13,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8187 : List Nat := [2,4,8,16,32,1,57,5,512,5,2048,4096,8192,4640,8201,8714,4096,6656,4644,8201,1,6698,4657,4146,8240,16,2049,6202,6203,2560,4,6203,4644,544,4096,4624]

theorem envBound8187 : H12AffineFastState.Bounded env8187 := by
  intro p hp
  have h : env8187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8186_8187 : H12AffineEnvironment.transform 17 6656 env8186 = env8187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6656 env8186 == env8187) = true)

theorem identity8187 : scanCanonicalize (H12AffineFastState.compose env8187 (packedSelected [0,1,5,7,10,12,14,15,20] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound8187 : packedSelected [0,1,5,7,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env8188 : List Nat := [2,4,8,16,32,1,57,5,512,5,2048,545,8192,1,8201,8714,545,2081,5,8201,1,2059,16,531,8240,16,2049,2587,2586,2560,4,2586,5,544,545,49]

theorem envBound8188 : H12AffineFastState.Bounded env8188 := by
  intro p hp
  have h : env8188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8187_8188 : H12AffineEnvironment.transform 11 545 env8187 = env8188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env8187 == env8188) = true)

theorem identity8188 : scanCanonicalize (H12AffineFastState.compose env8188 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

end H12CloudChart1