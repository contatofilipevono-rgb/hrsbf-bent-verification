import H12CloudChart1Data159

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans40575_40576 : H12AffineEnvironment.transform 21 272512 env40575 = env40576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env40575 == env40576) = true)

def env40577 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272392,441641,98645,8192,65,316532,436264,17664,32040,440429,156012,256,21792,46093,499506]

theorem envBound40577 : H12AffineFastState.Bounded env40577 := by
  intro p hp
  have h : env40577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40576_40577 : H12AffineEnvironment.transform 6 8 env40576 = env40577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40576 == env40577) = true)

def env40578 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,276585,272392,272441,98645,8192,65,316532,277816,17664,32040,273789,62588,256,21792,46093,330274]

theorem envBound40578 : H12AffineFastState.Bounded env40578 := by
  intro p hp
  have h : env40578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40577_40578 : H12AffineEnvironment.transform 16 38160 env40577 = env40578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env40577 == env40578) = true)

def env40579 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,64808,1024,32769,50497,54560,54545,98645,8192,65,10588,49168,17664,32040,53333,62588,256,21792,46093,128778]

theorem envBound40579 : H12AffineFastState.Bounded env40579 := by
  intro p hp
  have h : env40579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40578_40579 : H12AffineEnvironment.transform 17 64808 env40578 = env40579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env40578 == env40579) = true)

theorem identity40579 : scanCanonicalize (H12AffineFastState.compose env40579 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound40579 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env40580 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,38160,64808,1024,32769,50497,54560,54545,29790,8192,65,10588,49168,17664,32040,53333,62588,256,21792,46093,513]

theorem envBound40580 : H12AffineFastState.Bounded env40580 := by
  intro p hp
  have h : env40580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40579_40580 : H12AffineEnvironment.transform 15 62731 env40579 = env40580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env40579 == env40580) = true)

theorem identity40580 : scanCanonicalize (H12AffineFastState.compose env40580 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound40580 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,342,24909,2421,1024,29788,12572,8573,8524,29790,8192,65,10588,13389,17664,32040,9224,33,256,21792,16464,513]

theorem envBound40581 : H12AffineFastState.Bounded env40581 := by
  intro p hp
  have h : env40581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40580_40581 : H12AffineEnvironment.transform 14 29789 env40580 = env40581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env40580 == env40581) = true)

theorem identity40581 : scanCanonicalize (H12AffineFastState.compose env40581 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound40581 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,342,5393,2421,1024,0,12572,8573,8524,2,8192,65,10588,13389,12636,2420,9224,33,256,8572,13324,513]

theorem envBound40582 : H12AffineFastState.Bounded env40582 := by
  intro p hp
  have h : env40582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40581_40582 : H12AffineEnvironment.transform 13 13404 env40581 = env40582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env40581 == env40582) = true)

theorem identity40582 : scanCanonicalize (H12AffineFastState.compose env40582 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40582 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40583 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13325,1,263,5393,2340,1024,0,12572,8492,8477,2,8192,16,10509,13340,12557,2341,9224,33,256,8493,13324,513]

theorem envBound40583 : H12AffineFastState.Bounded env40583 := by
  intro p hp
  have h : env40583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40582_40583 : H12AffineEnvironment.transform 5 17 env40582 = env40583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40582 == env40583) = true)

theorem identity40583 : scanCanonicalize (H12AffineFastState.compose env40583 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound40583 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env40584 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1052,4113,1,263,5393,2340,1024,0,5376,1328,1281,2,1052,16,3345,4096,5393,2341,20,33,256,1329,4112,513]

theorem envBound40584 : H12AffineFastState.Bounded env40584 := by
  intro p hp
  have h : env40584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40583_40584 : H12AffineEnvironment.transform 12 1052 env40583 = env40584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env40583 == env40584) = true)

theorem identity40584 : scanCanonicalize (H12AffineFastState.compose env40584 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound40584 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env40585 : List Nat := [2,4,8,16,32,17,8,256,512,1024,0,4096,1052,4113,1,263,5393,292,1024,0,5376,1328,1281,2,1052,16,1297,4096,5393,293,20,33,256,1329,4112,513]

theorem envBound40585 : H12AffineFastState.Bounded env40585 := by
  intro p hp
  have h : env40585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40584_40585 : H12AffineEnvironment.transform 10 0 env40584 = env40585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env40584 == env40585) = true)

theorem identity40585 : scanCanonicalize (H12AffineFastState.compose env40585 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40585 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40586 : List Nat := [2,4,8,16,32,17,8,256,512,272,0,4096,268,4113,1,263,4097,292,272,0,4112,32,17,2,268,16,1,4096,4097,293,20,33,256,33,4112,513]

theorem envBound40586 : H12AffineFastState.Bounded env40586 := by
  intro p hp
  have h : env40586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40585_40586 : H12AffineEnvironment.transform 9 272 env40585 = env40586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40585 == env40586) = true)

theorem identity40586 : scanCanonicalize (H12AffineFastState.compose env40586 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40586 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40587 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,4096,41,4113,1,34,4097,1,53,0,4112,32,17,2,41,16,1,4096,4097,0,20,33,37,33,4112,513]

theorem envBound40587 : H12AffineFastState.Bounded env40587 := by
  intro p hp
  have h : env40587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40586_40587 : H12AffineEnvironment.transform 7 37 env40586 = env40587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40586 == env40587) = true)

theorem identity40587 : scanCanonicalize (H12AffineFastState.compose env40587 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound40587 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40588 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,48,41,33,1,34,49,1,53,0,32,32,17,2,41,16,1,48,49,0,20,33,37,33,32,513]

theorem envBound40588 : H12AffineFastState.Bounded env40588 := by
  intro p hp
  have h : env40588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40587_40588 : H12AffineEnvironment.transform 11 48 env40587 = env40588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env40587 == env40588) = true)

theorem identity40588 : scanCanonicalize (H12AffineFastState.compose env40588 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40588 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40589 : List Nat := [2,4,8,16,1,17,8,4,512,20,0,17,8,0,1,3,16,1,20,0,1,1,17,2,8,16,1,17,16,0,20,0,4,0,1,513]

theorem envBound40589 : H12AffineFastState.Bounded env40589 := by
  intro p hp
  have h : env40589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40588_40589 : H12AffineEnvironment.transform 4 1 env40588 = env40589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40588 == env40589) = true)

def env40590 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,64809,1024,32769,50496,54561,54544,98645,8192,65,10589,49169,17664,32040,53332,62588,256,21792,46093,128779]

theorem envBound40590 : H12AffineFastState.Bounded env40590 := by
  intro p hp
  have h : env40590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40578_40590 : H12AffineEnvironment.transform 17 64809 env40578 = env40590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env40578 == env40590) = true)

theorem identity40590 : scanCanonicalize (H12AffineFastState.compose env40590 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound40590 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env40591 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,16400,10281,1024,21761,4160,33,16,87125,8192,65,10589,5393,17664,32040,1364,8572,256,21792,24845,74251]

theorem envBound40591 : H12AffineFastState.Bounded env40591 := by
  intro p hp
  have h : env40591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40590_40591 : H12AffineEnvironment.transform 14 21760 env40590 = env40591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env40590 == env40591) = true)

theorem identity40591 : scanCanonicalize (H12AffineFastState.compose env40591 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound40591 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env40592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8540,65536,13388,10281,1024,8541,4160,33,16,73737,8192,65,10589,5393,12636,2420,1364,8572,256,8572,5457,74251]

theorem envBound40592 : H12AffineFastState.Bounded env40592 := by
  intro p hp
  have h : env40592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40591_40592 : H12AffineEnvironment.transform 13 13404 env40591 = env40592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env40591 == env40592) = true)

theorem identity40592 : scanCanonicalize (H12AffineFastState.compose env40592 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 8542) := by decide +kernel

theorem selectedBound40592 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env40593 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8540,8542,13388,10281,1024,8541,4160,33,16,343,8192,65,10589,5393,12636,2420,1364,8572,256,8572,5457,853]

theorem envBound40593 : H12AffineFastState.Bounded env40593 := by
  intro p hp
  have h : env40593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40592_40593 : H12AffineEnvironment.transform 15 8542 env40592 = env40593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8542 env40592 == env40593) = true)

theorem identity40593 : scanCanonicalize (H12AffineFastState.compose env40593 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound40593 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env40594 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,8192,13404,8201,8203,13388,10281,1024,8200,4160,33,16,2,8192,65,10248,5188,12297,2081,1025,8233,85,8233,5124,512]

theorem envBound40594 : H12AffineFastState.Bounded env40594 := by
  intro p hp
  have h : env40594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40593_40594 : H12AffineEnvironment.transform 7 85 env40593 = env40594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env40593 == env40594) = true)

theorem identity40594 : scanCanonicalize (H12AffineFastState.compose env40594 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound40594 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40595 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,120,5156,113,115,5172,2129,1024,112,4160,33,16,2,120,65,2160,5188,4209,2081,1025,81,85,81,5124,512]

theorem envBound40595 : H12AffineFastState.Bounded env40595 := by
  intro p hp
  have h : env40595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40594_40595 : H12AffineEnvironment.transform 12 120 env40594 = env40595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env40594 == env40595) = true)

theorem identity40595 : scanCanonicalize (H12AffineFastState.compose env40595 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound40595 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env40596 : List Nat := [2,4,8,16,32,64,8,85,512,1024,603,4096,120,5156,113,115,5172,522,1024,112,4160,33,16,2,120,65,555,5188,4209,634,1025,81,85,81,5124,512]

theorem envBound40596 : H12AffineFastState.Bounded env40596 := by
  intro p hp
  have h : env40596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40595_40596 : H12AffineEnvironment.transform 10 603 env40595 = env40596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env40595 == env40596) = true)

theorem identity40596 : scanCanonicalize (H12AffineFastState.compose env40596 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound40596 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40597 : List Nat := [2,4,8,16,32,49,8,36,512,1024,554,4096,9,5156,0,2,5172,522,1024,1,4145,33,16,2,9,48,555,5173,4096,523,1025,32,36,32,5124,512]

theorem envBound40597 : H12AffineFastState.Bounded env40597 := by
  intro p hp
  have h : env40597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40596_40597 : H12AffineEnvironment.transform 5 49 env40596 = env40597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env40596 == env40597) = true)

theorem identity40597 : scanCanonicalize (H12AffineFastState.compose env40597 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40597 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40598 : List Nat := [2,4,8,16,32,49,8,36,512,53,554,4096,9,4113,0,2,4097,522,53,1,4145,33,16,2,9,48,555,4096,4096,523,52,32,36,32,4145,512]

theorem envBound40598 : H12AffineFastState.Bounded env40598 := by
  intro p hp
  have h : env40598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40597_40598 : H12AffineEnvironment.transform 9 53 env40597 = env40598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40597 == env40598) = true)

theorem identity40598 : scanCanonicalize (H12AffineFastState.compose env40598 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40598 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40599 : List Nat := [2,4,8,16,1,16,8,5,512,20,523,4096,9,4113,0,2,4097,522,20,1,4112,0,16,2,9,17,522,4096,4096,523,21,1,5,1,4112,512]

theorem envBound40599 : H12AffineFastState.Bounded env40599 := by
  intro p hp
  have h : env40599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40598_40599 : H12AffineEnvironment.transform 4 1 env40598 = env40599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40598 == env40599) = true)

theorem identity40599 : scanCanonicalize (H12AffineFastState.compose env40599 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound40599 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40600 : List Nat := [2,4,8,16,1,16,8,5,31,20,20,4096,9,4113,0,2,4097,21,20,1,4112,0,16,2,9,17,21,4096,4096,20,21,1,5,1,4112,31]

theorem envBound40600 : H12AffineFastState.Bounded env40600 := by
  intro p hp
  have h : env40600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40599_40600 : H12AffineEnvironment.transform 8 31 env40599 = env40600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env40599 == env40600) = true)

theorem identity40600 : scanCanonicalize (H12AffineFastState.compose env40600 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 22) := by decide +kernel

theorem selectedBound40600 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40601 : List Nat := [2,4,8,16,1,16,8,5,31,20,20,22,9,7,0,2,23,21,20,1,6,0,16,2,9,17,21,22,22,20,21,1,5,1,6,31]

theorem envBound40601 : H12AffineFastState.Bounded env40601 := by
  intro p hp
  have h : env40601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40600_40601 : H12AffineEnvironment.transform 11 22 env40600 = env40601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 22 env40600 == env40601) = true)

def env40602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,276584,272392,272440,98645,8192,65,316532,277817,17664,32040,273788,62589,256,21792,46093,330275]

theorem envBound40602 : H12AffineFastState.Bounded env40602 := by
  intro p hp
  have h : env40602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40577_40602 : H12AffineEnvironment.transform 16 38161 env40577 = env40602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env40577 == env40602) = true)

theorem identity40602 : scanCanonicalize (H12AffineFastState.compose env40602 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound40602 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4161,33,17,98645,8192,65,64605,5392,17664,32040,1365,62589,256,21792,46093,74250]

theorem envBound40603 : H12AffineFastState.Bounded env40603 := by
  intro p hp
  have h : env40603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40602_40603 : H12AffineEnvironment.transform 17 10281 env40602 = env40603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40602 == env40603) = true)

theorem identity40603 : scanCanonicalize (H12AffineFastState.compose env40603 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound40603 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env40604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54278,38161,10281,1024,32769,4161,33,17,21843,8192,65,64605,5392,17664,32040,1365,62589,256,21792,46093,62988]

theorem envBound40604 : H12AffineFastState.Bounded env40604 := by
  intro p hp
  have h : env40604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40603_40604 : H12AffineEnvironment.transform 15 54278 env40603 = env40604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env40603 == env40604) = true)

theorem identity40604 : scanCanonicalize (H12AffineFastState.compose env40604 (packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound40604 : packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env40605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,21510,5393,10281,1024,1,4161,33,17,21843,8192,65,31837,5392,17664,32040,1365,29821,256,21792,13325,30220]

theorem envBound40605 : H12AffineFastState.Bounded env40605 := by
  intro p hp
  have h : env40605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40604_40605 : H12AffineEnvironment.transform 14 0 env40604 = env40605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env40604 == env40605) = true)

theorem identity40605 : scanCanonicalize (H12AffineFastState.compose env40605 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound40605 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env40606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,0,343,5393,10281,1024,1,4161,33,17,2,8192,65,10508,5392,4177,10361,1365,8492,256,113,13325,9053]

theorem envBound40606 : H12AffineFastState.Bounded env40606 := by
  intro p hp
  have h : env40606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40605_40606 : H12AffineEnvironment.transform 13 5457 env40605 = env40606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env40605 == env40606) = true)

theorem identity40606 : scanCanonicalize (H12AffineFastState.compose env40606 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40606 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40607 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,0,263,5393,10281,1024,1,4113,33,17,2,8192,17,10508,5392,4097,10281,1285,8492,256,33,13325,8973]

theorem envBound40607 : H12AffineFastState.Bounded env40607 := by
  intro p hp
  have h : env40607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40606_40607 : H12AffineEnvironment.transform 5 16 env40606 = env40607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40606 == env40607) = true)

theorem identity40607 : scanCanonicalize (H12AffineFastState.compose env40607 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40607 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40608 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,263,5393,2341,1024,1,4113,33,17,2,268,17,2048,5392,4097,2341,1285,32,256,33,5377,513]

theorem envBound40608 : H12AffineFastState.Bounded env40608 := by
  intro p hp
  have h : env40608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40607_40608 : H12AffineEnvironment.transform 12 268 env40607 = env40608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40607 == env40608) = true)

theorem identity40608 : scanCanonicalize (H12AffineFastState.compose env40608 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40608 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40609 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5156,0,34,5172,2048,1024,1,4113,33,17,2,41,17,2048,5173,4097,2048,1056,32,37,33,5156,513]

theorem envBound40609 : H12AffineFastState.Bounded env40609 := by
  intro p hp
  have h : env40609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40608_40609 : H12AffineEnvironment.transform 7 37 env40608 = env40609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40608 == env40609) = true)

def env40610 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,41,1044,0,34,1028,2048,1024,1,33,33,17,2,41,17,2048,1029,49,2048,1056,32,37,33,1044,513]

theorem envBound40610 : H12AffineFastState.Bounded env40610 := by
  intro p hp
  have h : env40610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40609_40610 : H12AffineEnvironment.transform 11 48 env40609 = env40610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env40609 == env40610) = true)

theorem identity40610 : scanCanonicalize (H12AffineFastState.compose env40610 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound40610 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40611 : List Nat := [2,4,8,16,32,16,8,37,512,1024,32,48,41,1044,0,34,1028,32,1024,1,33,33,17,2,41,17,32,1029,49,32,1056,32,37,33,1044,513]

theorem envBound40611 : H12AffineFastState.Bounded env40611 := by
  intro p hp
  have h : env40611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40610_40611 : H12AffineEnvironment.transform 10 32 env40610 = env40611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env40610 == env40611) = true)

def env40612 : List Nat := [2,4,8,16,32,16,8,37,512,52,32,48,41,32,0,34,48,32,52,1,33,33,17,2,41,17,32,49,49,32,20,32,37,33,32,513]

theorem envBound40612 : H12AffineFastState.Bounded env40612 := by
  intro p hp
  have h : env40612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40611_40612 : H12AffineEnvironment.transform 9 52 env40611 = env40612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40611 == env40612) = true)

theorem identity40612 : scanCanonicalize (H12AffineFastState.compose env40612 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound40612 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40613 : List Nat := [2,4,8,16,32,16,8,37,43,52,32,48,41,32,0,34,48,32,52,1,33,33,17,2,41,17,32,49,49,32,20,32,37,33,32,42]

theorem envBound40613 : H12AffineFastState.Bounded env40613 := by
  intro p hp
  have h : env40613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40612_40613 : H12AffineEnvironment.transform 8 43 env40612 = env40613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env40612 == env40613) = true)

def leafEnv40613 : List Nat := [2,4,8,16,32,16,8,37,43,52,32,48,41,32,0,34,48,32,52,1,33,33,17,2,20,41,1,17,32,49,49,32,20,32,37,33,4,34,32,42,1,33,0]

def active40613 : List Nat := [0,1,2,3,4]

def tree40613 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40613 : H12WitnessSearch.Good tree40613 := H12GlobalWitnessIndex.good

theorem leafIdentity40613 : H12AffineFastState.composeSystem env40613 rootObs = leafEnv40613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40613 rootObs == leafEnv40613) = true)

theorem terminalChecked40613 : H12PackedTerminal.terminalCheckFast leafEnv40613 active40613 tree40613 = true := by decide +kernel

def env40614 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,48,41,33,0,34,49,32,53,1,33,33,17,2,41,17,32,48,49,32,21,32,37,33,33,513]

theorem envBound40614 : H12AffineFastState.Bounded env40614 := by
  intro p hp
  have h : env40614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40611_40614 : H12AffineEnvironment.transform 9 53 env40611 = env40614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40611 == env40614) = true)

def env40615 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,41,1045,0,34,1029,2048,1024,1,32,33,17,2,41,17,2048,1028,48,2048,1056,32,37,33,1045,513]

theorem envBound40615 : H12AffineFastState.Bounded env40615 := by
  intro p hp
  have h : env40615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40609_40615 : H12AffineEnvironment.transform 11 49 env40609 = env40615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env40609 == env40615) = true)

theorem identity40615 : scanCanonicalize (H12AffineFastState.compose env40615 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound40615 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40616 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1045,49,41,1045,0,34,1029,1045,1024,1,32,33,17,2,41,17,1045,1028,48,1045,1056,32,37,33,1045,513]

theorem envBound40616 : H12AffineFastState.Bounded env40616 := by
  intro p hp
  have h : env40616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40615_40616 : H12AffineEnvironment.transform 10 1045 env40615 = env40616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env40615 == env40616) = true)

def env40617 : List Nat := [2,4,8,16,32,16,8,37,512,52,33,49,41,33,0,34,49,33,52,1,32,33,17,2,41,17,33,48,48,33,20,32,37,33,33,513]

theorem envBound40617 : H12AffineFastState.Bounded env40617 := by
  intro p hp
  have h : env40617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40616_40617 : H12AffineEnvironment.transform 9 52 env40616 = env40617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40616 == env40617) = true)

theorem identity40617 : scanCanonicalize (H12AffineFastState.compose env40617 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound40617 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40618 : List Nat := [2,4,8,16,32,16,8,37,42,52,33,49,41,33,0,34,49,33,52,1,32,33,17,2,41,17,33,48,48,33,20,32,37,33,33,43]

theorem envBound40618 : H12AffineFastState.Bounded env40618 := by
  intro p hp
  have h : env40618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40617_40618 : H12AffineEnvironment.transform 8 42 env40617 = env40618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env40617 == env40618) = true)

def leafEnv40618 : List Nat := [2,4,8,16,32,16,8,37,42,52,33,49,41,33,0,34,49,33,52,1,32,33,17,2,20,41,1,17,33,48,48,33,20,32,37,33,4,34,33,43,1,32,0]

def active40618 : List Nat := [0,1,2,3,4]

def tree40618 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40618 : H12WitnessSearch.Good tree40618 := H12GlobalWitnessIndex.good

theorem leafIdentity40618 : H12AffineFastState.composeSystem env40618 rootObs = leafEnv40618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40618 rootObs == leafEnv40618) = true)

theorem terminalChecked40618 : H12PackedTerminal.terminalCheckFast leafEnv40618 active40618 tree40618 = true := by decide +kernel

def env40619 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,49,41,32,0,34,48,32,53,1,32,33,17,2,41,17,32,49,48,32,21,32,37,33,32,513]

theorem envBound40619 : H12AffineFastState.Bounded env40619 := by
  intro p hp
  have h : env40619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40616_40619 : H12AffineEnvironment.transform 9 53 env40616 = env40619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40616 == env40619) = true)

def env40620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272393,441640,98644,8193,65,316533,436265,17664,32041,440429,156012,256,21792,46092,499507]

theorem envBound40620 : H12AffineFastState.Bounded env40620 := by
  intro p hp
  have h : env40620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40576_40620 : H12AffineEnvironment.transform 6 9 env40576 = env40620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40576 == env40620) = true)

theorem identity40620 : scanCanonicalize (H12AffineFastState.compose env40620 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 122146) := by decide +kernel

theorem selectedBound40620 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env40621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,122146,1024,32769,225370,128299,221194,98644,8193,65,67927,226571,17664,32041,222543,156012,256,21792,46092,147985]

theorem envBound40621 : H12AffineFastState.Bounded env40621 := by
  intro p hp
  have h : env40621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40620_40621 : H12AffineEnvironment.transform 17 122146 env40620 = env40621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122146 env40620 == env40621) = true)

theorem identity40621 : scanCanonicalize (H12AffineFastState.compose env40621 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound40621 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env40622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,122146,1024,32769,102678,128299,98630,98644,8193,65,67927,103495,17664,32041,99331,32800,256,21792,46092,41821]

theorem envBound40622 : H12AffineFastState.Bounded env40622 := by
  intro p hp
  have h : env40622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40621_40622 : H12AffineEnvironment.transform 16 57676 env40621 = env40622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env40621 == env40622) = true)

theorem identity40622 : scanCanonicalize (H12AffineFastState.compose env40622 (packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound40622 : packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env40623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,97406,1024,8541,77898,87159,73754,73736,8193,65,67927,79131,17664,32041,75103,8572,256,21792,5456,513]

theorem envBound40623 : H12AffineFastState.Bounded env40623 := by
  intro p hp
  have h : env40623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40622_40623 : H12AffineEnvironment.transform 14 8540 env40622 = env40623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env40622 == env40623) = true)

theorem identity40623 : scanCanonicalize (H12AffineFastState.compose env40623 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound40623 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40624 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,16384,8540,65536,16400,96623,273,8541,77898,86374,73754,73736,8193,65,67927,77834,16401,30776,73806,8572,256,20529,4161,513]

theorem envBound40624 : H12AffineFastState.Bounded env40624 := by
  intro p hp
  have h : env40624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40623_40624 : H12AffineEnvironment.transform 9 273 env40623 = env40624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env40623 == env40624) = true)

theorem identity40624 : scanCanonicalize (H12AffineFastState.compose env40624 (packedSelected [1,2,6,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound40624 : packedSelected [1,2,6,8,19] rootPS < 2^1333 := by decide +kernel

def env40625 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,12620,8540,65536,12636,67619,273,8541,77898,73770,73754,73736,8193,65,67927,77834,12637,2420,73806,8572,256,8573,4161,513]

theorem envBound40625 : H12AffineFastState.Bounded env40625 := by
  intro p hp
  have h : env40625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40624_40625 : H12AffineEnvironment.transform 13 12620 env40624 = env40625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env40624 == env40625) = true)

theorem identity40625 : scanCanonicalize (H12AffineFastState.compose env40625 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound40625 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40626 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,12620,8540,8203,12636,10280,273,8541,4161,33,17,3,8193,65,10588,4097,12637,2420,69,8572,256,8573,4161,513]

theorem envBound40626 : H12AffineFastState.Bounded env40626 := by
  intro p hp
  have h : env40626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40625_40626 : H12AffineEnvironment.transform 15 8203 env40625 = env40626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env40625 == env40626) = true)

theorem identity40626 : scanCanonicalize (H12AffineFastState.compose env40626 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40626 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40627 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,268,4160,80,263,4176,2340,273,81,4161,33,17,3,269,65,2128,4097,4177,2420,69,112,256,113,4161,513]

theorem envBound40627 : H12AffineFastState.Bounded env40627 := by
  intro p hp
  have h : env40627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40626_40627 : H12AffineEnvironment.transform 12 268 env40626 = env40627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40626 == env40627) = true)

theorem identity40627 : scanCanonicalize (H12AffineFastState.compose env40627 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40627 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env40628 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,268,4113,1,263,4097,2340,273,0,4112,33,17,3,269,16,2049,4097,4096,2341,20,33,256,32,4112,513]

theorem envBound40628 : H12AffineFastState.Bounded env40628 := by
  intro p hp
  have h : env40628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40627_40628 : H12AffineEnvironment.transform 5 17 env40627 = env40628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40627 == env40628) = true)

theorem identity40628 : scanCanonicalize (H12AffineFastState.compose env40628 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound40628 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40629 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2064,268,2049,1,263,2065,2340,273,0,2048,33,17,3,269,16,2049,2065,2064,2341,20,33,256,32,2048,513]

theorem envBound40629 : H12AffineFastState.Bounded env40629 := by
  intro p hp
  have h : env40629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40628_40629 : H12AffineEnvironment.transform 11 2064 env40628 = env40629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env40628 == env40629) = true)

theorem identity40629 : scanCanonicalize (H12AffineFastState.compose env40629 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40629 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40630 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2064,40,2049,1,35,2065,2048,53,0,2048,33,17,3,41,16,2049,2065,2064,2049,20,33,36,32,2048,513]

theorem envBound40630 : H12AffineFastState.Bounded env40630 := by
  intro p hp
  have h : env40630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40629_40630 : H12AffineEnvironment.transform 7 36 env40629 = env40630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40629 == env40630) = true)

theorem identity40630 : scanCanonicalize (H12AffineFastState.compose env40630 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound40630 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40631 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,33,40,48,1,35,32,49,53,0,49,33,17,3,41,16,48,32,33,48,20,33,36,32,49,513]

theorem envBound40631 : H12AffineFastState.Bounded env40631 := by
  intro p hp
  have h : env40631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40630_40631 : H12AffineEnvironment.transform 10 49 env40630 = env40631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env40630 == env40631) = true)

def leafEnv40631 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,33,40,48,1,35,32,49,53,0,49,33,17,3,20,41,1,16,48,32,33,48,20,33,36,32,4,34,49,513,1,48,0]

def active40631 : List Nat := [0,1,2,3,4,8]

def tree40631 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40631 : H12WitnessSearch.Good tree40631 := H12GlobalWitnessIndex.good

theorem leafIdentity40631 : H12AffineFastState.composeSystem env40631 rootObs = leafEnv40631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40631 rootObs == leafEnv40631) = true)

theorem terminalChecked40631 : H12PackedTerminal.terminalCheckFast leafEnv40631 active40631 tree40631 = true := by decide +kernel

def env40632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272513,441761,98781,8328,65,316669,436384,17664,32160,440429,156013,256,21792,46213,499642]

theorem envBound40632 : H12AffineFastState.Bounded env40632 := by
  intro p hp
  have h : env40632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40575_40632 : H12AffineEnvironment.transform 21 272513 env40575 = env40632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env40575 == env40632) = true)

theorem identity40632 : scanCanonicalize (H12AffineFastState.compose env40632 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179633) := by decide +kernel

theorem selectedBound40632 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,169264,16,98781,8328,65,158028,5393,17664,32160,1500,156013,256,21792,46213,74251]

theorem envBound40633 : H12AffineFastState.Bounded env40633 := by
  intro p hp
  have h : env40633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40632_40633 : H12AffineEnvironment.transform 17 179633 env40632 = env40633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env40632 == env40633) = true)

theorem identity40633 : scanCanonicalize (H12AffineFastState.compose env40633 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40633 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env40634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179633,1024,32769,4160,169264,16,41431,8328,65,158028,5393,17664,32160,1500,156013,256,21792,46213,513]

theorem envBound40634 : H12AffineFastState.Bounded env40634 := by
  intro p hp
  have h : env40634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40633_40634 : H12AffineEnvironment.transform 15 8202 env40633 = env40634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40633 == env40634) = true)

def env40635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,4194304,8388608,8862845,8328,65,4258941,8393984,8845473,8830977,440428,12645452,256,21793,46212,499643]

theorem envBound40635 : H12AffineFastState.Bounded env40635 := by
  intro p hp
  have h : env40635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40499_40635 : H12AffineEnvironment.transform 23 8862845 env40499 = env40635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862845 env40499 == env40635) = true)

def env40636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,4194304,441760,98781,8328,65,4258941,436384,17665,32161,440428,4606444,256,21793,46212,499643]

theorem envBound40636 : H12AffineFastState.Bounded env40636 := by
  intro p hp
  have h : env40636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40635_40636 : H12AffineEnvironment.transform 22 441760 env40635 = env40636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env40635 == env40636) = true)

def env40637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272512,441760,98781,8328,65,316669,436384,17665,32161,440428,156012,256,21793,46212,499643]

theorem envBound40637 : H12AffineFastState.Bounded env40637 := by
  intro p hp
  have h : env40637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40636_40637 : H12AffineEnvironment.transform 21 272512 env40636 = env40637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env40636 == env40637) = true)

theorem identity40637 : scanCanonicalize (H12AffineFastState.compose env40637 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236986) := by decide +kernel

theorem selectedBound40637 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236986,1024,32769,77899,243002,73754,98781,8328,65,215367,79130,17665,32161,75222,156012,256,21793,46212,513]

theorem envBound40638 : H12AffineFastState.Bounded env40638 := by
  intro p hp
  have h : env40638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40637_40638 : H12AffineEnvironment.transform 17 236986 env40637 = env40638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236986 env40637 == env40638) = true)

def env40639 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,77899,243002,73754,98645,8192,65,215367,79130,17665,32041,75102,156012,256,21793,46092,513]

theorem envBound40639 : H12AffineFastState.Bounded env40639 := by
  intro p hp
  have h : env40639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40638_40639 : H12AffineEnvironment.transform 6 8 env40638 = env40639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40638 == env40639) = true)

theorem identity40639 : scanCanonicalize (H12AffineFastState.compose env40639 (packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound40639 : packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env40640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,64809,1024,32769,77899,54561,73754,98645,8192,65,10588,79130,17665,32041,75102,65911,256,21793,46092,513]

theorem envBound40640 : H12AffineFastState.Bounded env40640 := by
  intro p hp
  have h : env40640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40639_40640 : H12AffineEnvironment.transform 16 90139 env40639 = env40640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env40639 == env40640) = true)

theorem identity40640 : scanCanonicalize (H12AffineFastState.compose env40640 (packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound40640 : packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS < 2^1333 := by decide +kernel

def env40641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,46156,64809,1024,32769,58396,54561,62541,21762,8192,65,10588,57677,17665,32041,61705,54560,256,21793,46092,513]

theorem envBound40641 : H12AffineFastState.Bounded env40641 := by
  intro p hp
  have h : env40641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40640_40641 : H12AffineEnvironment.transform 15 54359 env40640 = env40641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env40640 == env40641) = true)

theorem identity40641 : scanCanonicalize (H12AffineFastState.compose env40641 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound40641 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env40642 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,16400,2421,1024,29789,4160,8573,17,21762,8192,65,10588,5393,17665,32041,1365,8572,256,21793,16464,513]

theorem envBound40642 : H12AffineFastState.Bounded env40642 := by
  intro p hp
  have h : env40642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40641_40642 : H12AffineEnvironment.transform 14 29788 env40641 = env40642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env40641 == env40642) = true)

theorem identity40642 : scanCanonicalize (H12AffineFastState.compose env40642 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40642 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40643 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5392,2421,1024,8541,4160,8573,17,2,8192,65,10588,5393,4097,10281,1365,8572,256,33,5456,513]

theorem envBound40643 : H12AffineFastState.Bounded env40643 := by
  intro p hp
  have h : env40643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40642_40643 : H12AffineEnvironment.transform 13 5376 env40642 = env40643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40642 == env40643) = true)

theorem identity40643 : scanCanonicalize (H12AffineFastState.compose env40643 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40643 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40644 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,263,5392,2421,1024,81,4160,113,17,2,268,65,2128,5393,4097,2341,1365,112,256,33,5456,513]

theorem envBound40644 : H12AffineFastState.Bounded env40644 := by
  intro p hp
  have h : env40644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40643_40644 : H12AffineEnvironment.transform 12 268 env40643 = env40644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40643 == env40644) = true)

theorem identity40644 : scanCanonicalize (H12AffineFastState.compose env40644 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40644 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env40645 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,263,5392,2341,1024,1,4112,33,17,2,268,17,2048,5393,4097,2341,1285,32,256,33,5376,513]

theorem envBound40645 : H12AffineFastState.Bounded env40645 := by
  intro p hp
  have h : env40645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40644_40645 : H12AffineEnvironment.transform 5 16 env40644 = env40645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40644 == env40645) = true)

theorem identity40645 : scanCanonicalize (H12AffineFastState.compose env40645 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40645 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40646 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5156,0,35,5172,2049,1024,1,4112,33,17,2,40,17,2048,5173,4097,2049,1057,32,36,33,5156,513]

theorem envBound40646 : H12AffineFastState.Bounded env40646 := by
  intro p hp
  have h : env40646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40645_40646 : H12AffineEnvironment.transform 7 36 env40645 = env40646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40645 == env40646) = true)

def env40647 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1044,0,35,1028,2049,1024,1,32,33,17,2,40,17,2048,1029,49,2049,1057,32,36,33,1044,513]

theorem envBound40647 : H12AffineFastState.Bounded env40647 := by
  intro p hp
  have h : env40647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40646_40647 : H12AffineEnvironment.transform 11 48 env40646 = env40647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env40646 == env40647) = true)

theorem identity40647 : scanCanonicalize (H12AffineFastState.compose env40647 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound40647 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40648 : List Nat := [2,4,8,16,32,16,8,36,512,517,2048,48,40,529,0,35,513,2049,517,1,32,33,17,2,40,17,2048,512,49,2049,548,32,36,33,529,513]

theorem envBound40648 : H12AffineFastState.Bounded env40648 := by
  intro p hp
  have h : env40648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40647_40648 : H12AffineEnvironment.transform 9 517 env40647 = env40648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env40647 == env40648) = true)

def env40649 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,48,40,33,0,35,49,2049,53,1,32,33,17,2,40,17,2048,48,49,2049,20,32,36,33,33,49]

theorem envBound40649 : H12AffineFastState.Bounded env40649 := by
  intro p hp
  have h : env40649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40648_40649 : H12AffineEnvironment.transform 8 48 env40648 = env40649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env40648 == env40649) = true)

def env40650 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,48,40,32,0,35,48,2049,52,1,32,33,17,2,40,17,2048,49,49,2049,21,32,36,33,32,48]

theorem envBound40650 : H12AffineFastState.Bounded env40650 := by
  intro p hp
  have h : env40650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40648_40650 : H12AffineEnvironment.transform 8 49 env40648 = env40650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env40648 == env40650) = true)

theorem identity40650 : scanCanonicalize (H12AffineFastState.compose env40650 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40650 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40651 : List Nat := [2,4,8,11,32,11,8,36,42,47,2048,43,40,32,0,35,43,2049,47,1,32,33,10,2,40,10,2048,42,42,2049,14,32,36,33,32,43]

theorem envBound40651 : H12AffineFastState.Bounded env40651 := by
  intro p hp
  have h : env40651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40650_40651 : H12AffineEnvironment.transform 3 11 env40650 = env40651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40650 == env40651) = true)

def leafEnv40651 : List Nat := [2,4,8,11,32,11,8,36,42,47,2048,43,40,32,0,35,43,2049,47,1,32,33,10,2,14,40,1,10,2048,42,42,2049,14,32,36,33,4,35,32,43,1,32,0]

def active40651 : List Nat := [0,1,2,4,10]

def tree40651 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40651 : H12WitnessSearch.Good tree40651 := H12GlobalWitnessIndex.good

theorem leafIdentity40651 : H12AffineFastState.composeSystem env40651 rootObs = leafEnv40651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40651 rootObs == leafEnv40651) = true)

theorem terminalChecked40651 : H12PackedTerminal.terminalCheckFast leafEnv40651 active40651 tree40651 = true := by decide +kernel

def env40652 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1045,0,35,1029,2049,1024,1,33,33,17,2,40,17,2048,1028,48,2049,1057,32,36,33,1045,513]

theorem envBound40652 : H12AffineFastState.Bounded env40652 := by
  intro p hp
  have h : env40652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40646_40652 : H12AffineEnvironment.transform 11 49 env40646 = env40652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env40646 == env40652) = true)

theorem identity40652 : scanCanonicalize (H12AffineFastState.compose env40652 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound40652 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40653 : List Nat := [2,4,8,16,32,16,8,36,48,1024,2048,49,40,1045,0,35,1029,2049,1024,1,33,33,17,2,40,17,2048,1028,48,2049,1057,32,36,33,1045,49]

theorem envBound40653 : H12AffineFastState.Bounded env40653 := by
  intro p hp
  have h : env40653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40652_40653 : H12AffineEnvironment.transform 8 48 env40652 = env40653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env40652 == env40653) = true)

def env40654 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,49,40,33,0,35,49,2049,52,1,33,33,17,2,40,17,2048,48,48,2049,21,32,36,33,33,49]

theorem envBound40654 : H12AffineFastState.Bounded env40654 := by
  intro p hp
  have h : env40654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40653_40654 : H12AffineEnvironment.transform 9 52 env40653 = env40654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40653 == env40654) = true)

theorem identity40654 : scanCanonicalize (H12AffineFastState.compose env40654 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40654 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40655 : List Nat := [2,4,8,11,32,11,8,36,43,47,2048,42,40,33,0,35,42,2049,47,1,33,33,10,2,40,10,2048,43,43,2049,14,32,36,33,33,42]

theorem envBound40655 : H12AffineFastState.Bounded env40655 := by
  intro p hp
  have h : env40655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40654_40655 : H12AffineEnvironment.transform 3 11 env40654 = env40655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40654 == env40655) = true)

def leafEnv40655 : List Nat := [2,4,8,11,32,11,8,36,43,47,2048,42,40,33,0,35,42,2049,47,1,33,33,10,2,14,40,1,10,2048,43,43,2049,14,32,36,33,4,35,33,42,1,33,0]

def active40655 : List Nat := [0,1,2,4,10]

def tree40655 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40655 : H12WitnessSearch.Good tree40655 := H12GlobalWitnessIndex.good

theorem leafIdentity40655 : H12AffineFastState.composeSystem env40655 rootObs = leafEnv40655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40655 rootObs == leafEnv40655) = true)

theorem terminalChecked40655 : H12PackedTerminal.terminalCheckFast leafEnv40655 active40655 tree40655 = true := by decide +kernel

def env40656 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,49,40,32,0,35,48,2049,53,1,33,33,17,2,40,17,2048,49,48,2049,20,32,36,33,32,49]

theorem envBound40656 : H12AffineFastState.Bounded env40656 := by
  intro p hp
  have h : env40656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40653_40656 : H12AffineEnvironment.transform 9 53 env40653 = env40656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40653 == env40656) = true)

def env40657 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,77899,243002,73754,98644,8193,65,215367,79130,17665,32040,75103,156012,256,21793,46093,513]

theorem envBound40657 : H12AffineFastState.Bounded env40657 := by
  intro p hp
  have h : env40657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40638_40657 : H12AffineEnvironment.transform 6 9 env40638 = env40657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40638 == env40657) = true)

theorem identity40657 : scanCanonicalize (H12AffineFastState.compose env40657 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound40657 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env40658 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,64808,1024,32769,77899,54561,73754,98644,8193,65,10588,79130,17665,32040,75103,65911,256,21793,46093,513]

theorem envBound40658 : H12AffineFastState.Bounded env40658 := by
  intro p hp
  have h : env40658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40657_40658 : H12AffineEnvironment.transform 16 90139 env40657 = env40658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env40657 == env40658) = true)

theorem identity40658 : scanCanonicalize (H12AffineFastState.compose env40658 (packedSelected [0,2,4,6,9,18,20,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound40658 : packedSelected [0,2,4,6,9,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env40659 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,1047,25612,64808,1024,32769,13404,54561,9229,34115,8193,65,10588,12557,17665,32040,8520,1376,256,21793,46093,513]

theorem envBound40659 : H12AffineFastState.Bounded env40659 := by
  intro p hp
  have h : env40659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40658_40659 : H12AffineEnvironment.transform 15 1047 env40658 = env40659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env40658 == env40659) = true)

theorem identity40659 : scanCanonicalize (H12AffineFastState.compose env40659 (packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound40659 : packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS < 2^1333 := by decide +kernel

def env40660 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,1047,25612,64604,1024,32769,13404,54357,9229,33847,8193,65,10280,12409,17525,31836,8252,1044,116,21589,46093,513]

theorem envBound40660 : H12AffineFastState.Bounded env40660 := by
  intro p hp
  have h : env40660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40659_40660 : H12AffineEnvironment.transform 7 116 env40659 = env40660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env40659 == env40660) = true)

theorem identity40660 : scanCanonicalize (H12AffineFastState.compose env40660 (packedSelected [1,2,3,6,11,12,15,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 28776) := by decide +kernel

theorem selectedBound40660 : packedSelected [1,2,3,6,11,12,15,23,24,28] rootPS < 2^1333 := by decide +kernel

def env40661 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,28776,1047,25612,3124,1024,28777,13404,9277,9229,29791,8193,65,10280,12409,17525,31836,8252,1044,116,21589,17509,513]

theorem envBound40661 : H12AffineFastState.Bounded env40661 := by
  intro p hp
  have h : env40661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40660_40661 : H12AffineEnvironment.transform 14 28776 env40660 = env40661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28776 env40660 == env40661) = true)

theorem identity40661 : scanCanonicalize (H12AffineFastState.compose env40661 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound40661 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40662 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,13404,1076,1047,4176,3124,1024,1077,13404,9277,9229,3,8193,65,10280,12409,12329,2048,8252,1044,116,8201,12345,513]

theorem envBound40662 : H12AffineFastState.Bounded env40662 := by
  intro p hp
  have h : env40662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40661_40662 : H12AffineEnvironment.transform 13 13404 env40661 = env40662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env40661 == env40662) = true)

theorem identity40662 : scanCanonicalize (H12AffineFastState.compose env40662 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40662 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env40663 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,13325,1076,1047,4097,3124,1024,1077,13325,9277,9229,3,8193,16,10280,12328,12329,2048,8252,1044,37,8201,12345,513]

theorem envBound40663 : H12AffineFastState.Bounded env40663 := by
  intro p hp
  have h : env40663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40662_40663 : H12AffineEnvironment.transform 5 17 env40662 = env40663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40662 == env40663) = true)

theorem identity40663 : scanCanonicalize (H12AffineFastState.compose env40663 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound40663 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env40664 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,1052,4113,1076,1047,4097,3124,1024,1077,4113,33,17,3,1053,16,3124,5172,5173,2048,1056,1044,37,1045,5157,513]

theorem envBound40664 : H12AffineFastState.Bounded env40664 := by
  intro p hp
  have h : env40664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40663_40664 : H12AffineEnvironment.transform 12 1052 env40663 = env40664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env40663 == env40664) = true)

theorem identity40664 : scanCanonicalize (H12AffineFastState.compose env40664 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40664 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40665 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,4113,0,35,4097,2048,52,1,4113,33,17,3,41,16,2048,4096,4097,2048,20,32,37,33,4113,513]

theorem envBound40665 : H12AffineFastState.Bounded env40665 := by
  intro p hp
  have h : env40665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40664_40665 : H12AffineEnvironment.transform 9 52 env40664 = env40665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40664 == env40665) = true)

theorem identity40665 : scanCanonicalize (H12AffineFastState.compose env40665 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound40665 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40666 : List Nat := [2,4,8,16,32,17,9,37,512,52,560,4096,40,4113,0,35,4097,560,52,1,4113,33,17,3,41,16,560,4096,4097,560,20,32,37,33,4113,513]

theorem envBound40666 : H12AffineFastState.Bounded env40666 := by
  intro p hp
  have h : env40666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40665_40666 : H12AffineEnvironment.transform 10 560 env40665 = env40666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env40665 == env40666) = true)

theorem identity40666 : scanCanonicalize (H12AffineFastState.compose env40666 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound40666 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40667 : List Nat := [2,4,8,16,32,17,9,37,49,52,1,4096,40,4113,0,35,4097,1,52,1,4113,33,17,3,41,16,1,4096,4097,1,20,32,37,33,4113,48]

theorem envBound40667 : H12AffineFastState.Bounded env40667 := by
  intro p hp
  have h : env40667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40666_40667 : H12AffineEnvironment.transform 8 49 env40666 = env40667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env40666 == env40667) = true)

def env40668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272513,441760,98781,8328,65,316668,436384,17665,32161,440428,156013,256,21793,46212,499643]

theorem envBound40668 : H12AffineFastState.Bounded env40668 := by
  intro p hp
  have h : env40668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40636_40668 : H12AffineEnvironment.transform 21 272513 env40636 = env40668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env40636 == env40668) = true)

theorem identity40668 : scanCanonicalize (H12AffineFastState.compose env40668 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40668 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,437745,272513,441760,41431,8328,65,316668,436384,17665,32161,440428,156013,256,21793,46212,442289]

theorem envBound40669 : H12AffineFastState.Bounded env40669 := by
  intro p hp
  have h : env40669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40668_40669 : H12AffineEnvironment.transform 15 8202 env40668 = env40669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40668 == env40669) = true)

def env40670 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,437625,272393,441640,41311,8192,65,316532,436264,17665,32041,440428,156013,256,21793,46092,442169]

theorem envBound40670 : H12AffineFastState.Bounded env40670 := by
  intro p hp
  have h : env40670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40669_40670 : H12AffineEnvironment.transform 6 8 env40669 = env40670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40669 == env40670) = true)

theorem identity40670 : scanCanonicalize (H12AffineFastState.compose env40670 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound40670 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env40671 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38160,262144,1024,32769,276585,272393,272440,41311,8192,65,316532,277816,17665,32041,273788,62589,256,21793,46092,272937]

theorem envBound40671 : H12AffineFastState.Bounded env40671 := by
  intro p hp
  have h : env40671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40670_40671 : H12AffineEnvironment.transform 16 38160 env40670 = env40671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env40670 == env40671) = true)

theorem identity40671 : scanCanonicalize (H12AffineFastState.compose env40671 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound40671 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40672 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38160,10281,1024,32769,4160,32,17,41311,8192,65,64605,5393,17665,32041,1365,62589,256,21793,46092,512]

theorem envBound40672 : H12AffineFastState.Bounded env40672 := by
  intro p hp
  have h : env40672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40671_40672 : H12AffineEnvironment.transform 17 10281 env40671 = env40672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40671 == env40672) = true)

theorem identity40672 : scanCanonicalize (H12AffineFastState.compose env40672 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound40672 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env40673 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,1296,32768,8202,38160,10281,1024,32769,4160,32,17,41311,8192,65,47437,5393,17,14393,1365,45421,256,4145,46092,512]

theorem envBound40673 : H12AffineFastState.Bounded env40673 := by
  intro p hp
  have h : env40673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40672_40673 : H12AffineEnvironment.transform 13 1296 env40672 = env40673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env40672 == env40673) = true)

theorem identity40673 : scanCanonicalize (H12AffineFastState.compose env40673 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 12344) := by decide +kernel

theorem selectedBound40673 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,1296,12344,8202,9512,10281,1024,12345,4160,32,17,4455,8192,65,2421,5393,17,14393,1365,341,256,4145,1076,512]

theorem envBound40674 : H12AffineFastState.Bounded env40674 := by
  intro p hp
  have h : env40674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40673_40674 : H12AffineEnvironment.transform 14 12344 env40673 = env40674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12344 env40673 == env40674) = true)

theorem identity40674 : scanCanonicalize (H12AffineFastState.compose env40674 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound40674 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env40675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,88,1296,4192,82,1392,2161,1024,4193,4160,32,17,4455,88,65,2421,5393,17,6241,1365,341,256,4145,1076,512]

theorem envBound40675 : H12AffineFastState.Bounded env40675 := by
  intro p hp
  have h : env40675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40674_40675 : H12AffineEnvironment.transform 12 88 env40674 = env40675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env40674 == env40675) = true)

def env40676 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,437624,272392,441641,41310,8193,65,316533,436265,17665,32040,440428,156013,256,21793,46093,442168]

theorem envBound40676 : H12AffineFastState.Bounded env40676 := by
  intro p hp
  have h : env40676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40669_40676 : H12AffineEnvironment.transform 6 9 env40669 = env40676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40669 == env40676) = true)

theorem identity40676 : scanCanonicalize (H12AffineFastState.compose env40676 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound40676 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env40677 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,13388,262144,1024,32769,301364,272392,297317,41310,8193,65,316533,302181,17665,32040,298016,21793,256,21793,46093,297844]

theorem envBound40677 : H12AffineFastState.Bounded env40677 := by
  intro p hp
  have h : env40677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40676_40677 : H12AffineEnvironment.transform 16 13388 env40676 = env40677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env40676 == env40677) = true)

theorem identity40677 : scanCanonicalize (H12AffineFastState.compose env40677 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 23808) := by decide +kernel

theorem selectedBound40677 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env40678 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,13388,23808,1024,32769,50228,29960,54373,41310,8193,65,35189,49509,17665,32040,53536,21793,256,21793,46093,54900]

theorem envBound40678 : H12AffineFastState.Bounded env40678 := by
  intro p hp
  have h : env40678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40677_40678 : H12AffineEnvironment.transform 17 23808 env40677 = env40678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env40677 == env40678) = true)

theorem identity40678 : scanCanonicalize (H12AffineFastState.compose env40678 (packedSelected [0,6,7,14,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound40678 : packedSelected [0,6,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env40679 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21620,8202,13388,23808,1024,21621,4160,29960,17,29994,8193,65,23809,5393,17665,32040,1364,21793,256,21793,24697,512]

theorem envBound40679 : H12AffineFastState.Bounded env40679 := by
  intro p hp
  have h : env40679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40678_40679 : H12AffineEnvironment.transform 14 21620 env40678 = env40679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env40678 == env40679) = true)

theorem identity40679 : scanCanonicalize (H12AffineFastState.compose env40679 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40679 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env40680 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21620,343,5393,23808,1024,21621,4160,21589,17,21623,348,65,23809,5393,17665,23669,1364,21793,256,21793,16676,512]

theorem envBound40680 : H12AffineFastState.Bounded env40680 := by
  intro p hp
  have h : env40680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40679_40680 : H12AffineEnvironment.transform 12 349 env40679 = env40680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40679 == env40680) = true)

theorem identity40680 : scanCanonicalize (H12AffineFastState.compose env40680 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40680 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env40681 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21540,263,5393,23808,1024,21541,4112,21509,17,21543,268,17,23809,5393,17665,23589,1284,21793,256,21793,16676,512]

theorem envBound40681 : H12AffineFastState.Bounded env40681 := by
  intro p hp
  have h : env40681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40680_40681 : H12AffineEnvironment.transform 5 16 env40680 = env40681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40680 == env40681) = true)

theorem identity40681 : scanCanonicalize (H12AffineFastState.compose env40681 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2081) := by decide +kernel

theorem selectedBound40681 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env40682 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,2081,7173,263,5393,5409,1024,7172,4112,7204,17,7174,268,17,5408,5393,3360,5124,1284,7424,256,7424,2309,512]

theorem envBound40682 : H12AffineFastState.Bounded env40682 := by
  intro p hp
  have h : env40682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40681_40682 : H12AffineEnvironment.transform 13 2081 env40681 = env40682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2081 env40681 == env40682) = true)

theorem identity40682 : scanCanonicalize (H12AffineFastState.compose env40682 (packedSelected [11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound40682 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env40683 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3076,269,2081,1,263,2325,2341,1024,0,3092,32,17,2,268,17,2340,2325,3360,2048,1284,260,256,260,2309,512]

theorem envBound40683 : H12AffineFastState.Bounded env40683 := by
  intro p hp
  have h : env40683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40682_40683 : H12AffineEnvironment.transform 11 3076 env40682 = env40683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env40682 == env40683) = true)

theorem identity40683 : scanCanonicalize (H12AffineFastState.compose env40683 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40683 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40684 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,3076,9,2081,1,3,2065,2081,1024,0,3092,32,17,2,8,17,2080,2065,3108,2048,1024,0,4,0,2049,512]

theorem envBound40684 : H12AffineFastState.Bounded env40684 := by
  intro p hp
  have h : env40684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40683_40684 : H12AffineEnvironment.transform 7 4 env40683 = env40684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40683 == env40684) = true)

theorem identity40684 : scanCanonicalize (H12AffineFastState.compose env40684 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound40684 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env40685 : List Nat := [2,4,8,16,32,16,9,4,512,21,2048,2065,9,2081,1,3,2065,2081,21,0,2049,32,17,2,8,17,2080,2065,2097,2048,21,0,4,0,2049,512]

theorem envBound40685 : H12AffineFastState.Bounded env40685 := by
  intro p hp
  have h : env40685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40684_40685 : H12AffineEnvironment.transform 9 21 env40684 = env40685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env40684 == env40685) = true)

theorem identity40685 : scanCanonicalize (H12AffineFastState.compose env40685 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40685 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env40686 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,2065,9,2048,1,3,2065,2048,21,0,2049,1,17,2,8,17,2049,2065,2064,2048,21,0,4,0,2049,512]

theorem envBound40686 : H12AffineFastState.Bounded env40686 := by
  intro p hp
  have h : env40686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40685_40686 : H12AffineEnvironment.transform 4 1 env40685 = env40686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40685 == env40686) = true)

theorem identity40686 : scanCanonicalize (H12AffineFastState.compose env40686 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound40686 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40687 : List Nat := [2,4,8,16,1,16,9,4,512,21,5,20,9,5,1,3,20,5,21,0,4,1,17,2,8,17,4,20,21,5,21,0,4,0,4,512]

theorem envBound40687 : H12AffineFastState.Bounded env40687 := by
  intro p hp
  have h : env40687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40686_40687 : H12AffineEnvironment.transform 10 5 env40686 = env40687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env40686 == env40687) = true)

theorem identity40687 : scanCanonicalize (H12AffineFastState.compose env40687 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound40687 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40688 : List Nat := [2,4,8,16,1,16,9,4,22,21,5,20,9,5,1,3,20,5,21,0,4,1,17,2,8,17,4,20,21,5,21,0,4,0,4,22]

theorem envBound40688 : H12AffineFastState.Bounded env40688 := by
  intro p hp
  have h : env40688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40687_40688 : H12AffineEnvironment.transform 8 22 env40687 = env40688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env40687 == env40688) = true)

theorem identity40688 : scanCanonicalize (H12AffineFastState.compose env40688 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound40688 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40689 : List Nat := [2,1,8,16,1,16,9,1,19,16,0,17,9,0,1,3,17,0,16,0,1,1,17,2,8,17,1,17,16,0,16,0,1,0,1,19]

theorem envBound40689 : H12AffineFastState.Bounded env40689 := by
  intro p hp
  have h : env40689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40688_40689 : H12AffineEnvironment.transform 1 1 env40688 = env40689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env40688 == env40689) = true)

theorem identity40689 : scanCanonicalize (H12AffineFastState.compose env40689 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound40689 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40690 : List Nat := [2,1,8,8,1,8,9,1,11,8,0,9,9,0,1,3,9,0,8,0,1,1,9,2,8,9,1,9,8,0,8,0,1,0,1,11]

theorem envBound40690 : H12AffineFastState.Bounded env40690 := by
  intro p hp
  have h : env40690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40689_40690 : H12AffineEnvironment.transform 3 8 env40689 = env40690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env40689 == env40690) = true)

def env40691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,4194304,441761,98780,8328,65,4258941,436385,17664,32160,440428,4606445,256,21793,46212,499643]

theorem envBound40691 : H12AffineFastState.Bounded env40691 := by
  intro p hp
  have h : env40691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40635_40691 : H12AffineEnvironment.transform 22 441761 env40635 = env40691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env40635 == env40691) = true)

def env40692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272512,441761,98780,8328,65,316669,436385,17664,32160,440428,156013,256,21793,46212,499643]

theorem envBound40692 : H12AffineFastState.Bounded env40692 := by
  intro p hp
  have h : env40692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40691_40692 : H12AffineEnvironment.transform 21 272512 env40691 = env40692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env40691 == env40692) = true)

theorem identity40692 : scanCanonicalize (H12AffineFastState.compose env40692 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223598) := by decide +kernel

theorem selectedBound40692 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,115871,213486,120015,98780,8328,65,245139,115151,17664,32160,119042,156013,256,21793,46212,63189]

theorem envBound40693 : H12AffineFastState.Bounded env40693 := by
  intro p hp
  have h : env40693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40692_40693 : H12AffineEnvironment.transform 17 223598 env40692 = env40693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223598 env40692 == env40693) = true)

def env40694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,130174,1024,32769,115871,120062,120015,98780,8328,65,75907,115151,17664,32160,119042,62589,256,21793,46212,63189]

theorem envBound40694 : H12AffineFastState.Bounded env40694 := by
  intro p hp
  have h : env40694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40693_40694 : H12AffineEnvironment.transform 16 38160 env40693 = env40694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env40693 == env40694) = true)

theorem identity40694 : scanCanonicalize (H12AffineFastState.compose env40694 (packedSelected [0,1,4,5,7,8,10,15,16,18,20,22,23,24,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound40694 : packedSelected [0,1,4,5,7,8,10,15,16,18,20,22,23,24,31,38] rootPS < 2^1333 := by decide +kernel

def env40695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,81,65536,5441,97327,1024,80,83150,87215,87198,65933,8328,65,75907,82334,17664,32160,86355,29740,256,21793,13525,30340]

theorem envBound40695 : H12AffineFastState.Bounded env40695 := by
  intro p hp
  have h : env40695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40694_40695 : H12AffineEnvironment.transform 14 81 env40694 = env40695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env40694 == env40695) = true)

theorem identity40695 : scanCanonicalize (H12AffineFastState.compose env40695 (packedSelected [1,10,16,20,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound40695 : packedSelected [1,10,16,20,26,28] rootPS < 2^1333 := by decide +kernel

def env40696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,81,263,5441,32040,1024,80,17865,21928,21913,138,8328,65,10628,16537,17664,32160,20564,29740,256,21793,13525,30340]

theorem envBound40696 : H12AffineFastState.Bounded env40696 := by
  intro p hp
  have h : env40696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40695_40696 : H12AffineEnvironment.transform 15 263 env40695 = env40696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env40695 == env40696) = true)

theorem identity40696 : scanCanonicalize (H12AffineFastState.compose env40696 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40696 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env40697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,81,263,5441,23588,1024,80,17865,21928,21913,138,388,65,2184,16537,17664,23724,20564,21792,256,21793,5593,22408]

theorem envBound40697 : H12AffineFastState.Bounded env40697 := by
  intro p hp
  have h : env40697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40696_40697 : H12AffineEnvironment.transform 12 268 env40696 = env40697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40696 == env40697) = true)

theorem identity40697 : scanCanonicalize (H12AffineFastState.compose env40697 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40697 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env40698 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,0,263,5392,23588,1024,1,17816,21928,21913,138,388,16,2184,16537,17664,23724,20485,21792,256,21793,5512,22408]

theorem envBound40698 : H12AffineFastState.Bounded env40698 := by
  intro p hp
  have h : env40698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40697_40698 : H12AffineEnvironment.transform 5 17 env40697 = env40698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40697 == env40698) = true)

theorem identity40698 : scanCanonicalize (H12AffineFastState.compose env40698 (packedSelected [0,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40698 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env40699 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,263,5392,23588,1024,1,17680,21792,21777,2,268,16,2048,16401,17664,23588,20485,21792,256,21793,5376,22272]

theorem envBound40699 : H12AffineFastState.Bounded env40699 := by
  intro p hp
  have h : env40699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40698_40699 : H12AffineEnvironment.transform 6 8 env40698 = env40699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40698 == env40699) = true)

theorem identity40699 : scanCanonicalize (H12AffineFastState.compose env40699 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound40699 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env40700 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5156,0,263,5392,2048,1024,1,4404,260,309,2,268,16,2048,5173,4388,2048,1057,260,256,261,5376,804]

theorem envBound40700 : H12AffineFastState.Bounded env40700 := by
  intro p hp
  have h : env40700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40699_40700 : H12AffineEnvironment.transform 13 5156 env40699 = env40700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env40699 == env40700) = true)

theorem identity40700 : scanCanonicalize (H12AffineFastState.compose env40700 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40700 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env40701 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,0,34,5173,2048,1024,1,4113,33,16,2,41,16,2048,5173,4097,2048,1057,33,37,32,5157,513]

theorem envBound40701 : H12AffineFastState.Bounded env40701 := by
  intro p hp
  have h : env40701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40700_40701 : H12AffineEnvironment.transform 7 37 env40700 = env40701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40700 == env40701) = true)

theorem identity40701 : scanCanonicalize (H12AffineFastState.compose env40701 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound40701 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40702 : List Nat := [2,4,8,16,32,17,8,37,512,1024,523,4096,41,5156,0,34,5173,523,1024,1,4113,33,16,2,41,16,523,5173,4097,523,1057,33,37,32,5157,513]

theorem envBound40702 : H12AffineFastState.Bounded env40702 := by
  intro p hp
  have h : env40702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40701_40702 : H12AffineEnvironment.transform 10 523 env40701 = env40702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env40701 == env40702) = true)

theorem identity40702 : scanCanonicalize (H12AffineFastState.compose env40702 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40702 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40703 : List Nat := [2,4,8,16,1,17,8,4,512,1024,523,4096,8,5125,0,3,5140,523,1024,1,4113,0,16,2,8,16,523,5140,4097,523,1024,0,4,1,5124,513]

theorem envBound40703 : H12AffineFastState.Bounded env40703 := by
  intro p hp
  have h : env40703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40702_40703 : H12AffineEnvironment.transform 4 1 env40702 = env40703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40702 == env40703) = true)

def env40704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,130175,1024,32769,115871,120063,120015,98780,8328,65,75906,115151,17664,32160,119042,62588,256,21793,46212,63189]

theorem envBound40704 : H12AffineFastState.Bounded env40704 := by
  intro p hp
  have h : env40704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40693_40704 : H12AffineEnvironment.transform 16 38161 env40693 = env40704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env40693 == env40704) = true)

theorem identity40704 : scanCanonicalize (H12AffineFastState.compose env40704 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound40704 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env40705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,25029,67755,1024,29909,77899,73771,73755,95496,8328,65,75906,79131,17664,32160,75222,168,256,21793,16464,513]

theorem envBound40705 : H12AffineFastState.Bounded env40705 := by
  intro p hp
  have h : env40705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40704_40705 : H12AffineEnvironment.transform 14 29908 env40704 = env40705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env40704 == env40705) = true)

theorem identity40705 : scanCanonicalize (H12AffineFastState.compose env40705 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound40705 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env40706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,478,25029,2421,1024,29909,12693,8693,8645,29910,8328,65,10588,13509,17664,32160,9224,168,256,21793,16464,513]

theorem envBound40706 : H12AffineFastState.Bounded env40706 := by
  intro p hp
  have h : env40706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40705_40706 : H12AffineEnvironment.transform 15 478 env40705 = env40706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env40705 == env40706) = true)

theorem identity40706 : scanCanonicalize (H12AffineFastState.compose env40706 (packedSelected [3,5,8,17,18,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound40706 : packedSelected [3,5,8,17,18,23,28] rootPS < 2^1333 := by decide +kernel

def env40707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,478,13389,2421,1024,8541,12693,8693,8645,8542,8328,65,10588,13509,4232,10280,9224,168,256,169,5592,513]

theorem envBound40707 : H12AffineFastState.Bounded env40707 := by
  intro p hp
  have h : env40707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40706_40707 : H12AffineEnvironment.transform 13 5512 env40706 = env40707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env40706 == env40707) = true)

theorem identity40707 : scanCanonicalize (H12AffineFastState.compose env40707 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound40707 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,136,478,5529,2421,1024,137,4161,33,17,138,348,65,2184,5393,4232,2556,1500,168,256,169,5592,513]

theorem envBound40708 : H12AffineFastState.Bounded env40708 := by
  intro p hp
  have h : env40708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40707_40708 : H12AffineEnvironment.transform 12 468 env40707 = env40708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env40707 == env40708) = true)

theorem identity40708 : scanCanonicalize (H12AffineFastState.compose env40708 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40708 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40709 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5512,136,399,5529,2340,1024,137,4112,33,17,138,269,16,2184,5393,4232,2477,1421,168,256,169,5513,513]

theorem envBound40709 : H12AffineFastState.Bounded env40709 := by
  intro p hp
  have h : env40709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40708_40709 : H12AffineEnvironment.transform 5 17 env40708 = env40709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40708 == env40709) = true)

theorem identity40709 : scanCanonicalize (H12AffineFastState.compose env40709 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 772) := by decide +kernel

theorem selectedBound40709 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env40710 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,772,389,1676,136,399,1693,2340,1024,137,788,33,17,138,269,16,2184,1557,908,2477,1421,168,256,169,1677,513]

theorem envBound40710 : H12AffineFastState.Bounded env40710 := by
  intro p hp
  have h : env40710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40709_40710 : H12AffineEnvironment.transform 11 772 env40709 = env40710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env40709 == env40710) = true)

theorem identity40710 : scanCanonicalize (H12AffineFastState.compose env40710 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound40710 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env40711 : List Nat := [2,4,8,16,32,17,128,256,512,1024,820,772,389,1676,136,399,1693,528,1024,137,788,33,17,138,269,16,956,1557,908,665,1421,168,256,169,1677,513]

theorem envBound40711 : H12AffineFastState.Bounded env40711 := by
  intro p hp
  have h : env40711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40710_40711 : H12AffineEnvironment.transform 10 820 env40710 = env40711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env40710 == env40711) = true)

theorem identity40711 : scanCanonicalize (H12AffineFastState.compose env40711 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound40711 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env40712 : List Nat := [2,4,8,16,32,17,128,52,512,1024,512,560,177,1676,136,187,1693,528,1024,137,544,33,17,138,57,16,648,1557,696,665,1209,168,52,169,1677,513]

theorem envBound40712 : H12AffineFastState.Bounded env40712 := by
  intro p hp
  have h : env40712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40711_40712 : H12AffineEnvironment.transform 7 52 env40711 = env40712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env40711 == env40712) = true)

theorem identity40712 : scanCanonicalize (H12AffineFastState.compose env40712 (packedSelected [1,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound40712 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env40713 : List Nat := [2,4,8,16,32,17,128,52,512,156,512,560,177,528,136,187,513,528,156,137,544,33,17,138,57,16,648,649,696,665,37,168,52,169,529,513]

theorem envBound40713 : H12AffineFastState.Bounded env40713 := by
  intro p hp
  have h : env40713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40712_40713 : H12AffineEnvironment.transform 9 156 env40712 = env40713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env40712 == env40713) = true)

def env40714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437745,272513,441761,98780,8328,65,316668,436385,17664,32160,440428,156012,256,21793,46212,499643]

theorem envBound40714 : H12AffineFastState.Bounded env40714 := by
  intro p hp
  have h : env40714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40691_40714 : H12AffineEnvironment.transform 21 272513 env40691 = env40714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env40691 == env40714) = true)

theorem identity40714 : scanCanonicalize (H12AffineFastState.compose env40714 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound40714 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,437745,272513,441761,21763,8328,65,316668,436385,17664,32160,440428,156012,256,21793,46212,412516]

theorem envBound40715 : H12AffineFastState.Bounded env40715 := by
  intro p hp
  have h : env40715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40714_40715 : H12AffineEnvironment.transform 15 54495 env40714 = env40715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env40714 == env40715) = true)

def env40716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,437625,272393,441641,21763,8192,65,316532,436265,17664,32040,440428,156012,256,21793,46092,412516]

theorem envBound40716 : H12AffineFastState.Bounded env40716 := by
  intro p hp
  have h : env40716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40715_40716 : H12AffineEnvironment.transform 6 8 env40715 = env40716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40715 == env40716) = true)

theorem identity40716 : scanCanonicalize (H12AffineFastState.compose env40716 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound40716 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env40717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1024,32769,165200,32,169216,21763,8192,65,64605,163840,17664,32040,168005,156012,256,21793,46092,156493]

theorem envBound40717 : H12AffineFastState.Bounded env40717 := by
  intro p hp
  have h : env40717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40716_40717 : H12AffineEnvironment.transform 17 10281 env40716 = env40717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40716 == env40717) = true)

theorem identity40717 : scanCanonicalize (H12AffineFastState.compose env40717 (packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound40717 : packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS < 2^1333 := by decide +kernel

def env40718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,10281,1024,32769,17728,32,21776,21763,8192,65,64605,16400,17664,32040,20565,41340,256,21793,46092,41821]

theorem envBound40718 : H12AffineFastState.Bounded env40718 := by
  intro p hp
  have h : env40718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40717_40718 : H12AffineEnvironment.transform 16 49168 env40717 = env40718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env40717 == env40718) = true)

theorem identity40718 : scanCanonicalize (H12AffineFastState.compose env40718 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound40718 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29963,24908,10281,1024,8541,17728,32,21776,21763,8192,65,23809,16400,17664,32040,20565,32,256,21793,5456,513]

theorem envBound40719 : H12AffineFastState.Bounded env40719 := by
  intro p hp
  have h : env40719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40718_40719 : H12AffineEnvironment.transform 14 8540 env40718 = env40719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env40718 == env40719) = true)

theorem identity40719 : scanCanonicalize (H12AffineFastState.compose env40719 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40719 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env40720 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,29963,24861,10281,1024,8460,17681,32,21776,21763,8192,16,23809,16400,17664,32040,20484,32,256,21793,5377,513]

theorem envBound40720 : H12AffineFastState.Bounded env40720 := by
  intro p hp
  have h : env40720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40719_40720 : H12AffineEnvironment.transform 5 17 env40719 = env40720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40719 == env40720) = true)

theorem identity40720 : scanCanonicalize (H12AffineFastState.compose env40720 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40720 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env40721 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,21510,16400,2340,1024,1,17681,32,21776,21763,269,16,23809,16400,17664,23589,20484,32,256,21793,5377,513]

theorem envBound40721 : H12AffineFastState.Bounded env40721 := by
  intro p hp
  have h : env40721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40720_40721 : H12AffineEnvironment.transform 12 269 env40720 = env40721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40720 == env40721) = true)

def env40722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,437624,272392,441640,21763,8193,65,316533,436264,17664,32041,440428,156012,256,21793,46093,412516]

theorem envBound40722 : H12AffineFastState.Bounded env40722 := by
  intro p hp
  have h : env40722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40715_40722 : H12AffineEnvironment.transform 6 9 env40715 = env40722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40715 == env40722) = true)

theorem identity40722 : scanCanonicalize (H12AffineFastState.compose env40722 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40722 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env40723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54358,131072,262144,1024,32769,429093,264533,433269,21763,348,65,316533,428405,17664,23668,432433,147505,256,21793,38224,412516]

theorem envBound40723 : H12AffineFastState.Bounded env40723 := by
  intro p hp
  have h : env40723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40722_40723 : H12AffineEnvironment.transform 12 349 env40722 = env40723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40722 == env40723) = true)

theorem identity40723 : scanCanonicalize (H12AffineFastState.compose env40723 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 182628) := by decide +kernel

theorem selectedBound40723 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env40724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54358,131072,182628,1024,32769,17729,180273,21777,21763,348,65,138513,16401,17664,23668,20565,147505,256,21793,38224,33280]

theorem envBound40724 : H12AffineFastState.Bounded env40724 := by
  intro p hp
  have h : env40724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40723_40724 : H12AffineEnvironment.transform 17 182628 env40723 = env40724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182628 env40723 == env40724) = true)

theorem identity40724 : scanCanonicalize (H12AffineFastState.compose env40724 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound40724 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env40725 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54358,5393,56437,1024,32769,17729,54560,21777,21763,348,65,2048,16401,17664,23668,20565,21792,256,21793,38224,33280]

theorem envBound40725 : H12AffineFastState.Bounded env40725 := by
  intro p hp
  have h : env40725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40724_40725 : H12AffineEnvironment.transform 16 5393 env40724 = env40725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env40724 == env40725) = true)

theorem identity40725 : scanCanonicalize (H12AffineFastState.compose env40725 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40725 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env40726 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32768,33110,5393,35189,1024,32769,4161,32800,17,3,348,65,2048,5393,4096,2420,1365,32,256,33,38224,33280]

theorem envBound40726 : H12AffineFastState.Bounded env40726 := by
  intro p hp
  have h : env40726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40725_40726 : H12AffineEnvironment.transform 13 5376 env40725 = env40726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40725 == env40726) = true)

theorem identity40726 : scanCanonicalize (H12AffineFastState.compose env40726 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound40726 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env40727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3108,349,2340,32768,33110,2357,35189,1024,32769,3173,32800,17,3,348,65,2048,2357,3108,2420,1365,32,256,33,35188,33280]

theorem envBound40727 : H12AffineFastState.Bounded env40727 := by
  intro p hp
  have h : env40727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40726_40727 : H12AffineEnvironment.transform 11 3108 env40726 = env40727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env40726 == env40727) = true)

theorem identity40727 : scanCanonicalize (H12AffineFastState.compose env40727 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 3700) := by decide +kernel

theorem selectedBound40727 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env40728 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3108,349,2340,3700,3874,2357,1793,1024,3701,3173,3668,17,3,348,65,2048,2357,3108,2420,1365,32,256,33,1792,3188]

theorem envBound40728 : H12AffineFastState.Bounded env40728 := by
  intro p hp
  have h : env40728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40727_40728 : H12AffineEnvironment.transform 14 3700 env40727 = env40728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3700 env40727 == env40728) = true)

theorem identity40728 : scanCanonicalize (H12AffineFastState.compose env40728 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40728 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env40729 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,3108,120,2049,3700,3591,2064,1572,1024,3701,3173,3668,17,3,121,65,2048,2064,3108,2129,1136,32,37,33,1573,3188]

theorem envBound40729 : H12AffineFastState.Bounded env40729 := by
  intro p hp
  have h : env40729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40728_40729 : H12AffineEnvironment.transform 7 37 env40728 = env40729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40728 == env40729) = true)

theorem identity40729 : scanCanonicalize (H12AffineFastState.compose env40729 (packedSelected [0,2,4,6,10] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound40729 : packedSelected [0,2,4,6,10] rootPS < 2^1333 := by decide +kernel

def env40730 : List Nat := [2,4,8,16,32,64,9,37,512,1024,80,1140,120,81,1572,1623,64,1572,1024,1573,1077,1540,17,3,121,65,80,64,1140,1,1136,32,37,33,1573,1060]

theorem envBound40730 : H12AffineFastState.Bounded env40730 := by
  intro p hp
  have h : env40730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40729_40730 : H12AffineEnvironment.transform 10 80 env40729 = env40730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env40729 == env40730) = true)

theorem identity40730 : scanCanonicalize (H12AffineFastState.compose env40730 (packedSelected [0,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound40730 : packedSelected [0,6,9] rootPS < 2^1333 := by decide +kernel

def env40731 : List Nat := [2,4,8,16,32,64,9,37,512,36,80,80,120,81,512,627,64,512,36,513,17,544,17,3,121,65,80,64,80,1,84,32,37,33,513,0]

theorem envBound40731 : H12AffineFastState.Bounded env40731 := by
  intro p hp
  have h : env40731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40730_40731 : H12AffineEnvironment.transform 9 36 env40730 = env40731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env40730 == env40731) = true)

theorem identity40731 : scanCanonicalize (H12AffineFastState.compose env40731 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40731 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env40732 : List Nat := [2,4,8,16,32,16,9,37,512,36,0,0,40,1,512,547,16,512,36,513,17,544,17,3,41,17,0,16,0,1,4,32,37,33,513,0]

theorem envBound40732 : H12AffineFastState.Bounded env40732 := by
  intro p hp
  have h : env40732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40731_40732 : H12AffineEnvironment.transform 5 16 env40731 = env40732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40731 == env40732) = true)

theorem identity40732 : scanCanonicalize (H12AffineFastState.compose env40732 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40732 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40733 : List Nat := [2,4,8,0,32,0,9,37,512,36,0,0,40,1,512,547,0,512,36,513,1,544,1,3,41,1,0,0,0,1,4,32,37,33,513,0]

theorem envBound40733 : H12AffineFastState.Bounded env40733 := by
  intro p hp
  have h : env40733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40732_40733 : H12AffineEnvironment.transform 3 0 env40732 = env40733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40732 == env40733) = true)

theorem identity40733 : scanCanonicalize (H12AffineFastState.compose env40733 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound40733 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40734 : List Nat := [2,4,8,0,32,0,9,37,1,36,0,0,40,1,1,34,0,1,36,0,1,33,1,3,41,1,0,0,0,1,4,32,37,33,0,0]

theorem envBound40734 : H12AffineFastState.Bounded env40734 := by
  intro p hp
  have h : env40734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40733_40734 : H12AffineEnvironment.transform 8 1 env40733 = env40734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env40733 == env40734) = true)

theorem identity40734 : scanCanonicalize (H12AffineFastState.compose env40734 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound40734 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40735 : List Nat := [2,4,8,0,11,0,9,14,1,15,0,0,3,1,1,9,0,1,15,0,1,10,1,3,2,1,0,0,0,1,4,11,14,10,0,0]

theorem envBound40735 : H12AffineFastState.Bounded env40735 := by
  intro p hp
  have h : env40735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40734_40735 : H12AffineEnvironment.transform 4 11 env40734 = env40735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env40734 == env40735) = true)

def env40736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound40736 : H12AffineFastState.Bounded env40736 := by
  intro p hp
  have h : env40736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40497_40736 : H12AffineEnvironment.transform 18 1025 env40497 = env40736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env40497 == env40736) = true)

theorem identity40736 : scanCanonicalize (H12AffineFastState.compose env40736 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10833264) := by decide +kernel

theorem selectedBound40736 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env40737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10833264,8328,65,6458737,8702461,10507600,8830976,2410849,12855472,257,297436,288888,2485943]

theorem envBound40737 : H12AffineFastState.Bounded env40737 := by
  intro p hp
  have h : env40737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40736_40737 : H12AffineEnvironment.transform 23 10833264 env40736 = env40737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10833264 env40736 == env40737) = true)

def env40738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,2097152,4194304,8388608,10588556,8328,65,6458737,8393985,10507600,8527100,2102685,12645452,257,21792,46212,2175563]

theorem envBound40738 : H12AffineFastState.Bounded env40738 := by
  intro p hp
  have h : env40738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40737_40738 : H12AffineEnvironment.transform 17 56572 env40737 = env40738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56572 env40737 == env40738) = true)

def env40739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,4194304,8388608,8487372,8328,65,4365617,8393985,8406288,8527100,1501,12645452,257,21792,46212,74251]

theorem envBound40739 : H12AffineFastState.Bounded env40739 := by
  intro p hp
  have h : env40739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40738_40739 : H12AffineEnvironment.transform 20 4160 env40738 = env40739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env40738 == env40739) = true)

def env40740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,4194304,16,98780,8328,65,4365617,5393,17664,138476,1501,4256860,257,21792,46212,74251]

theorem envBound40740 : H12AffineFastState.Bounded env40740 := by
  intro p hp
  have h : env40740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40739_40740 : H12AffineEnvironment.transform 22 16 env40739 = env40740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env40739 == env40740) = true)

theorem identity40740 : scanCanonicalize (H12AffineFastState.compose env40740 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound40740 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,73891,16,98780,8328,65,245138,5393,17664,138476,1501,120063,257,21792,46212,74251]

theorem envBound40741 : H12AffineFastState.Bounded env40741 := by
  intro p hp
  have h : env40741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40740_40741 : H12AffineEnvironment.transform 21 73891 env40740 = env40741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env40740 == env40741) = true)

def env40742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,73771,16,98644,8192,65,245018,5393,17664,138340,1365,119927,257,21792,46092,74251]

theorem envBound40742 : H12AffineFastState.Bounded env40742 := by
  intro p hp
  have h : env40742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40741_40742 : H12AffineEnvironment.transform 6 8 env40741 = env40742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40741 == env40742) = true)

theorem identity40742 : scanCanonicalize (H12AffineFastState.compose env40742 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40742 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40743 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35189,1025,32769,4160,73771,16,98644,8192,65,245018,5393,4097,138340,1365,98678,257,33,46092,74251]

theorem envBound40743 : H12AffineFastState.Bounded env40743 := by
  intro p hp
  have h : env40743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40742_40743 : H12AffineEnvironment.transform 13 5377 env40742 = env40743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40742 == env40743) = true)

theorem identity40743 : scanCanonicalize (H12AffineFastState.compose env40743 (packedSelected [0,1,9,10,16,20,22,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound40743 : packedSelected [0,1,9,10,16,20,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env40744 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,103494,35189,1025,32769,4160,73771,16,98644,8192,65,10588,5393,4097,100386,1365,98678,257,33,46092,74251]

theorem envBound40744 : H12AffineFastState.Bounded env40744 := by
  intro p hp
  have h : env40744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40743_40744 : H12AffineEnvironment.transform 16 103494 env40743 = env40744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env40743 == env40744) = true)

theorem identity40744 : scanCanonicalize (H12AffineFastState.compose env40744 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound40744 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env40745 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,5392,35189,1025,32769,4160,41341,16,2,8192,65,10588,5393,4097,2420,1365,32,257,33,46092,41821]

theorem envBound40745 : H12AffineFastState.Bounded env40745 := by
  intro p hp
  have h : env40745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40744_40745 : H12AffineEnvironment.transform 15 33110 env40744 = env40745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env40744 == env40745) = true)

theorem identity40745 : scanCanonicalize (H12AffineFastState.compose env40745 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7433) := by decide +kernel

theorem selectedBound40745 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env40746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7433,5377,32768,33110,5392,35189,1025,32769,4160,40052,16,2,7433,65,5205,5393,4097,2420,1365,32,257,33,35077,40532]

theorem envBound40746 : H12AffineFastState.Bounded env40746 := by
  intro p hp
  have h : env40746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40745_40746 : H12AffineEnvironment.transform 12 7433 env40745 = env40746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7433 env40745 == env40746) = true)

theorem identity40746 : scanCanonicalize (H12AffineFastState.compose env40746 (packedSelected [0,2,3,5,6,7,10,11,14] rootPS)) = affineNative (2^(14+1) ^^^ 4112) := by decide +kernel

theorem selectedBound40746 : packedSelected [0,2,3,5,6,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env40747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7433,5377,4112,4422,5392,6501,1025,4113,4160,3172,16,2,7433,65,5205,5393,4097,2420,1365,32,257,33,6421,3652]

theorem envBound40747 : H12AffineFastState.Bounded env40747 := by
  intro p hp
  have h : env40747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40746_40747 : H12AffineEnvironment.transform 14 4112 env40746 = env40747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4112 env40746 == env40747) = true)

theorem identity40747 : scanCanonicalize (H12AffineFastState.compose env40747 (packedSelected [3,5,6,10,11,16] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound40747 : packedSelected [3,5,6,10,11,16] rootPS < 2^1333 := by decide +kernel

def env40748 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,96,3433,1377,112,294,1392,2309,1025,113,32,3172,16,2,3433,65,1077,1393,97,2420,1365,32,257,33,2421,3652]

theorem envBound40748 : H12AffineFastState.Bounded env40748 := by
  intro p hp
  have h : env40748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40747_40748 : H12AffineEnvironment.transform 11 96 env40747 = env40748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env40747 == env40748) = true)

theorem identity40748 : scanCanonicalize (H12AffineFastState.compose env40748 (packedSelected [0,3,4,6,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40748 : packedSelected [0,3,4,6,8,11] rootPS < 2^1333 := by decide +kernel

def env40749 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,96,2169,113,112,294,96,2309,273,113,32,2420,16,2,2169,65,293,97,97,2420,69,32,257,33,2421,2900]

theorem envBound40749 : H12AffineFastState.Bounded env40749 := by
  intro p hp
  have h : env40749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40748_40749 : H12AffineEnvironment.transform 9 272 env40748 = env40749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40748 == env40749) = true)

theorem identity40749 : scanCanonicalize (H12AffineFastState.compose env40749 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 341) := by decide +kernel

theorem selectedBound40749 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40750 : List Nat := [2,4,8,16,32,64,8,256,512,272,341,96,300,113,112,294,96,80,273,113,32,33,16,2,300,65,293,97,97,33,69,32,257,33,32,513]

theorem envBound40750 : H12AffineFastState.Bounded env40750 := by
  intro p hp
  have h : env40750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40749_40750 : H12AffineEnvironment.transform 10 341 env40749 = env40750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 341 env40749 == env40750) = true)

theorem identity40750 : scanCanonicalize (H12AffineFastState.compose env40750 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound40750 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40751 : List Nat := [2,4,8,16,32,64,8,20,512,4,65,96,56,113,112,50,96,80,5,113,32,33,16,2,56,65,49,97,97,33,69,32,21,33,32,513]

theorem envBound40751 : H12AffineFastState.Bounded env40751 := by
  intro p hp
  have h : env40751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40750_40751 : H12AffineEnvironment.transform 7 20 env40750 = env40751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env40750 == env40751) = true)

theorem identity40751 : scanCanonicalize (H12AffineFastState.compose env40751 (packedSelected [0,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound40751 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env40752 : List Nat := [2,4,8,16,32,64,8,20,26,4,65,96,56,113,112,50,96,80,5,113,32,33,16,2,56,65,49,97,97,33,69,32,21,33,32,27]

theorem envBound40752 : H12AffineFastState.Bounded env40752 := by
  intro p hp
  have h : env40752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40751_40752 : H12AffineEnvironment.transform 8 26 env40751 = env40752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env40751 == env40752) = true)

def env40753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,73770,16,98645,8193,65,245019,5393,17664,138341,1364,119926,257,21792,46093,74251]

theorem envBound40753 : H12AffineFastState.Bounded env40753 := by
  intro p hp
  have h : env40753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40741_40753 : H12AffineEnvironment.transform 6 9 env40741 = env40753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40741 == env40753) = true)

theorem identity40753 : scanCanonicalize (H12AffineFastState.compose env40753 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound40753 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1025,29789,4160,73770,16,95497,8193,65,215367,5393,17664,138341,1364,73770,257,21792,16465,74251]

theorem envBound40754 : H12AffineFastState.Bounded env40754 := by
  intro p hp
  have h : env40754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40753_40754 : H12AffineEnvironment.transform 14 29788 env40753 = env40754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env40753 == env40754) = true)

theorem identity40754 : scanCanonicalize (H12AffineFastState.compose env40754 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound40754 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env40755 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,16401,10281,1025,29789,4160,73770,16,95497,8193,65,67926,5393,17664,23668,1364,73770,257,21792,16465,74251]

theorem envBound40755 : H12AffineFastState.Bounded env40755 := by
  intro p hp
  have h : env40755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40754_40755 : H12AffineEnvironment.transform 16 16401 env40754 = env40755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env40754 == env40755) = true)

theorem identity40755 : scanCanonicalize (H12AffineFastState.compose env40755 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound40755 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env40756 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,16401,10281,1025,29789,4160,21792,16,3,8193,65,31836,5393,17664,23668,1364,21792,257,21792,16465,22273]

theorem envBound40756 : H12AffineFastState.Bounded env40756 := by
  intro p hp
  have h : env40756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40755_40756 : H12AffineEnvironment.transform 15 29962 env40755 = env40756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env40755 == env40756) = true)

theorem identity40756 : scanCanonicalize (H12AffineFastState.compose env40756 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40756 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40757 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,5393,10281,1025,8541,4160,32,16,3,8193,65,10588,5393,4096,2420,1364,32,257,32,5457,513]

theorem envBound40757 : H12AffineFastState.Bounded env40757 := by
  intro p hp
  have h : env40757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40756_40757 : H12AffineEnvironment.transform 13 5376 env40756 = env40757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40756 == env40757) = true)

theorem identity40757 : scanCanonicalize (H12AffineFastState.compose env40757 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound40757 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40758 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,89,5376,261,83,5393,2160,1025,260,4160,32,16,3,88,65,2309,5393,4096,2420,1364,32,257,32,5457,513]

theorem envBound40758 : H12AffineFastState.Bounded env40758 := by
  intro p hp
  have h : env40758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40757_40758 : H12AffineEnvironment.transform 12 89 env40757 = env40758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env40757 == env40758) = true)

theorem identity40758 : scanCanonicalize (H12AffineFastState.compose env40758 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40758 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env40759 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,9,5376,261,3,5393,2080,1025,260,4112,32,16,3,8,17,2309,5393,4096,2340,1284,32,257,32,5377,513]

theorem envBound40759 : H12AffineFastState.Bounded env40759 := by
  intro p hp
  have h : env40759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40758_40759 : H12AffineEnvironment.transform 5 16 env40758 = env40759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40758 == env40759) = true)

theorem identity40759 : scanCanonicalize (H12AffineFastState.compose env40759 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound40759 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40760 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,292,9,1060,261,3,1077,2080,1025,260,308,32,16,3,8,17,2309,1077,292,2340,1284,32,257,32,1061,513]

theorem envBound40760 : H12AffineFastState.Bounded env40760 := by
  intro p hp
  have h : env40760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40759_40760 : H12AffineEnvironment.transform 11 292 env40759 = env40760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env40759 == env40760) = true)

theorem identity40760 : scanCanonicalize (H12AffineFastState.compose env40760 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound40760 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40761 : List Nat := [2,4,8,16,32,16,9,256,1,1024,2048,292,9,1060,261,3,1077,2080,1025,260,308,32,16,3,8,17,2309,1077,292,2340,1284,32,257,32,1061,0]

theorem envBound40761 : H12AffineFastState.Bounded env40761 := by
  intro p hp
  have h : env40761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40760_40761 : H12AffineEnvironment.transform 8 1 env40760 = env40761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env40760 == env40761) = true)

def env40762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,4194304,17,98781,8328,65,4365617,5392,17665,138477,1501,4256861,257,21792,46212,74251]

theorem envBound40762 : H12AffineFastState.Bounded env40762 := by
  intro p hp
  have h : env40762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40739_40762 : H12AffineEnvironment.transform 22 17 env40739 = env40762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env40739 == env40762) = true)

theorem identity40762 : scanCanonicalize (H12AffineFastState.compose env40762 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40762 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56572,1025,32769,4160,4194304,17,41431,8328,65,4365617,5392,17665,138477,1501,4256861,257,21792,46212,513]

theorem envBound40763 : H12AffineFastState.Bounded env40763 := by
  intro p hp
  have h : env40763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40762_40763 : H12AffineEnvironment.transform 15 8202 env40762 = env40763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40762 == env40763) = true)

theorem identity40763 : scanCanonicalize (H12AffineFastState.compose env40763 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound40763 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env40764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56572,1025,32769,4160,112,17,41431,8328,65,171329,5392,17665,138477,1501,62509,257,21792,46212,513]

theorem envBound40764 : H12AffineFastState.Bounded env40764 := by
  intro p hp
  have h : env40764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40763_40764 : H12AffineEnvironment.transform 21 112 env40763 = env40764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env40763 == env40764) = true)

def env40765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56436,1025,32769,4160,112,17,41311,8192,65,171329,5392,17665,138341,1365,62509,257,21792,46092,513]

theorem envBound40765 : H12AffineFastState.Bounded env40765 := by
  intro p hp
  have h : env40765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40764_40765 : H12AffineEnvironment.transform 6 8 env40764 = env40765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40764 == env40765) = true)

theorem identity40765 : scanCanonicalize (H12AffineFastState.compose env40765 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound40765 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,32041,1025,8540,4160,112,17,2,8192,65,146460,5392,17665,138341,1365,21872,257,21792,5457,513]

theorem envBound40766 : H12AffineFastState.Bounded env40766 := by
  intro p hp
  have h : env40766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40765_40766 : H12AffineEnvironment.transform 14 8541 env40765 = env40766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env40765 == env40766) = true)

theorem identity40766 : scanCanonicalize (H12AffineFastState.compose env40766 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound40766 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env40767 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,8541,8202,131072,30776,272,8540,4160,112,17,2,8192,65,145677,4097,16400,137588,68,20577,257,20529,4160,513]

theorem envBound40767 : H12AffineFastState.Bounded env40767 := by
  intro p hp
  have h : env40767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40766_40767 : H12AffineEnvironment.transform 9 273 env40766 = env40767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env40766 == env40767) = true)

theorem identity40767 : scanCanonicalize (H12AffineFastState.compose env40767 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 12409) := by decide +kernel

theorem selectedBound40767 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env40768 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,8541,8202,12409,30776,272,8540,4160,112,17,2,8192,65,2420,4097,16400,10509,68,20577,257,20529,4160,513]

theorem envBound40768 : H12AffineFastState.Bounded env40768 := by
  intro p hp
  have h : env40768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40767_40768 : H12AffineEnvironment.transform 16 12409 env40767 = env40768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12409 env40767 == env40768) = true)

theorem identity40768 : scanCanonicalize (H12AffineFastState.compose env40768 (packedSelected [9,14,22] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound40768 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env40769 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,12392,8541,8202,12409,2128,272,8540,4160,112,17,2,8192,65,2420,4097,12408,10509,68,8201,257,8281,4160,513]

theorem envBound40769 : H12AffineFastState.Bounded env40769 := by
  intro p hp
  have h : env40769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40768_40769 : H12AffineEnvironment.transform 13 12392 env40768 = env40769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env40768 == env40769) = true)

theorem identity40769 : scanCanonicalize (H12AffineFastState.compose env40769 (packedSelected [14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40769 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env40770 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,349,4405,0,343,4388,2128,272,1,4160,112,17,2,349,65,2420,4097,4389,2128,68,340,257,260,4160,513]

theorem envBound40770 : H12AffineFastState.Bounded env40770 := by
  intro p hp
  have h : env40770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40769_40770 : H12AffineEnvironment.transform 12 349 env40769 = env40770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40769 == env40770) = true)

theorem identity40770 : scanCanonicalize (H12AffineFastState.compose env40770 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40770 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40771 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,4096,121,4113,0,115,4096,2128,52,1,4160,112,17,2,121,65,2128,4097,4097,2128,68,112,37,32,4160,513]

theorem envBound40771 : H12AffineFastState.Bounded env40771 := by
  intro p hp
  have h : env40771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40770_40771 : H12AffineEnvironment.transform 7 36 env40770 = env40771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40770 == env40771) = true)

theorem identity40771 : scanCanonicalize (H12AffineFastState.compose env40771 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound40771 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env40772 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,512,121,529,0,115,512,2128,52,1,576,112,17,2,121,65,2128,513,513,2128,68,112,37,32,576,513]

theorem envBound40772 : H12AffineFastState.Bounded env40772 := by
  intro p hp
  have h : env40772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40771_40772 : H12AffineEnvironment.transform 11 512 env40771 = env40772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env40771 == env40772) = true)

theorem identity40772 : scanCanonicalize (H12AffineFastState.compose env40772 (packedSelected [3,4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound40772 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env40773 : List Nat := [2,4,8,16,32,48,8,36,512,53,2048,512,9,529,0,3,512,2080,52,1,560,0,17,2,9,49,2080,513,513,2080,52,0,37,32,560,513]

theorem envBound40773 : H12AffineFastState.Bounded env40773 := by
  intro p hp
  have h : env40773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40772_40773 : H12AffineEnvironment.transform 5 48 env40772 = env40773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env40772 == env40773) = true)

def env40774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56437,1025,32769,4160,112,17,41310,8193,65,171329,5392,17665,138340,1364,62509,257,21792,46093,513]

theorem envBound40774 : H12AffineFastState.Bounded env40774 := by
  intro p hp
  have h : env40774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40764_40774 : H12AffineEnvironment.transform 6 9 env40764 = env40774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40764 == env40774) = true)

def env40775 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56357,1025,32769,4112,32,17,41230,8193,17,171281,5392,17665,138292,1284,62509,257,21792,46093,513]

theorem envBound40775 : H12AffineFastState.Bounded env40775 := by
  intro p hp
  have h : env40775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40774_40775 : H12AffineEnvironment.transform 5 16 env40774 = env40775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40774 == env40775) = true)

theorem identity40775 : scanCanonicalize (H12AffineFastState.compose env40775 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound40775 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env40776 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,56357,1025,32769,4112,32,17,41230,8193,17,23809,5392,17665,56356,1284,62509,257,21792,46093,513]

theorem envBound40776 : H12AffineFastState.Bounded env40776 := by
  intro p hp
  have h : env40776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40775_40776 : H12AffineEnvironment.transform 16 49168 env40775 = env40776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env40775 == env40776) = true)

theorem identity40776 : scanCanonicalize (H12AffineFastState.compose env40776 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40776 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40777 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,32768,263,49168,56357,1025,32769,4112,32,17,32771,268,17,23809,5392,17665,56356,1284,54560,257,21792,38144,513]

theorem envBound40777 : H12AffineFastState.Bounded env40777 := by
  intro p hp
  have h : env40777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40776_40777 : H12AffineEnvironment.transform 12 269 env40776 = env40777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40776 == env40777) = true)

theorem identity40777 : scanCanonicalize (H12AffineFastState.compose env40777 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40777 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40778 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,32768,263,38160,35109,1025,32769,4112,32,17,32771,268,17,2049,5392,4097,35108,1284,32800,257,32,38144,513]

theorem envBound40778 : H12AffineFastState.Bounded env40778 := by
  intro p hp
  have h : env40778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40777_40778 : H12AffineEnvironment.transform 13 5376 env40777 = env40778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40777 == env40778) = true)

theorem identity40778 : scanCanonicalize (H12AffineFastState.compose env40778 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound40778 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40779 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,1,263,5393,2340,1025,0,4112,32,17,2,268,17,2049,5392,4097,2341,1284,33,257,32,5377,513]

theorem envBound40779 : H12AffineFastState.Bounded env40779 := by
  intro p hp
  have h : env40779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40778_40779 : H12AffineEnvironment.transform 14 1 env40778 = env40779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env40778 == env40779) = true)

theorem identity40779 : scanCanonicalize (H12AffineFastState.compose env40779 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound40779 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40780 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8,5125,1,2,5140,2081,1025,0,4112,32,17,2,9,17,2049,5141,4097,2080,1025,33,4,32,5124,513]

theorem envBound40780 : H12AffineFastState.Bounded env40780 := by
  intro p hp
  have h : env40780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40779_40780 : H12AffineEnvironment.transform 7 5 env40779 = env40780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env40779 == env40780) = true)

theorem identity40780 : scanCanonicalize (H12AffineFastState.compose env40780 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40780 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40781 : List Nat := [2,4,8,16,32,16,9,5,512,52,2048,4096,8,4145,1,2,4128,2081,53,0,4112,32,17,2,9,17,2049,4129,4097,2080,53,33,4,32,4144,513]

theorem envBound40781 : H12AffineFastState.Bounded env40781 := by
  intro p hp
  have h : env40781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40780_40781 : H12AffineEnvironment.transform 9 52 env40780 = env40781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40780 == env40781) = true)

theorem identity40781 : scanCanonicalize (H12AffineFastState.compose env40781 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound40781 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40782 : List Nat := [2,4,8,16,32,16,9,5,512,52,2048,2608,8,2561,1,2,2576,2081,53,0,2592,32,17,2,9,17,2049,2577,2609,2080,53,33,4,32,2560,513]

theorem envBound40782 : H12AffineFastState.Bounded env40782 := by
  intro p hp
  have h : env40782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40781_40782 : H12AffineEnvironment.transform 11 2608 env40781 = env40782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env40781 == env40782) = true)

theorem identity40782 : scanCanonicalize (H12AffineFastState.compose env40782 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound40782 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40783 : List Nat := [2,4,8,16,32,16,9,5,512,52,544,16,8,33,1,2,48,513,53,0,0,32,17,2,9,17,545,49,17,512,53,33,4,32,32,513]

theorem envBound40783 : H12AffineFastState.Bounded env40783 := by
  intro p hp
  have h : env40783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40782_40783 : H12AffineEnvironment.transform 10 544 env40782 = env40783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env40782 == env40783) = true)

theorem identity40783 : scanCanonicalize (H12AffineFastState.compose env40783 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound40783 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40784 : List Nat := [2,4,8,16,32,16,9,5,17,52,49,16,8,33,1,2,48,16,53,0,0,32,17,2,9,17,48,49,17,17,53,33,4,32,32,16]

theorem envBound40784 : H12AffineFastState.Bounded env40784 := by
  intro p hp
  have h : env40784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40783_40784 : H12AffineEnvironment.transform 8 17 env40783 = env40784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env40783 == env40784) = true)

theorem identity40784 : scanCanonicalize (H12AffineFastState.compose env40784 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40784 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env40785 : List Nat := [2,4,8,16,1,16,9,5,17,21,16,16,8,0,1,2,17,16,20,0,0,1,17,2,9,17,17,16,17,17,20,0,4,1,1,16]

theorem envBound40785 : H12AffineFastState.Bounded env40785 := by
  intro p hp
  have h : env40785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40784_40785 : H12AffineEnvironment.transform 4 1 env40784 = env40785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40784 == env40785) = true)

theorem identity40785 : scanCanonicalize (H12AffineFastState.compose env40785 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40785 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40786 : List Nat := [2,4,8,10,1,10,9,5,11,15,10,10,8,0,1,2,11,10,14,0,0,1,11,2,9,11,11,10,11,11,14,0,4,1,1,10]

theorem envBound40786 : H12AffineFastState.Bounded env40786 := by
  intro p hp
  have h : env40786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40785_40786 : H12AffineEnvironment.transform 3 10 env40785 = env40786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40785 == env40786) = true)

def env40787 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56356,1025,32769,4113,33,17,41231,8193,16,171280,5392,17665,138293,1285,62509,257,21792,46093,513]

theorem envBound40787 : H12AffineFastState.Bounded env40787 := by
  intro p hp
  have h : env40787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40774_40787 : H12AffineEnvironment.transform 5 17 env40774 = env40787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40774 == env40787) = true)

theorem identity40787 : scanCanonicalize (H12AffineFastState.compose env40787 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound40787 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env40788 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,32768,8202,131072,43049,1025,32769,4113,33,17,41231,8193,16,171280,5392,12556,138293,1285,32800,257,8493,46093,513]

theorem envBound40788 : H12AffineFastState.Bounded env40788 := by
  intro p hp
  have h : env40788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40787_40788 : H12AffineEnvironment.transform 13 13325 env40787 = env40788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env40787 == env40788) = true)

theorem identity40788 : scanCanonicalize (H12AffineFastState.compose env40788 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound40788 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env40789 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,32768,8202,5392,43049,1025,32769,4113,33,17,41231,8193,16,34816,5392,12556,2341,1285,32800,257,8493,46093,513]

theorem envBound40789 : H12AffineFastState.Bounded env40789 := by
  intro p hp
  have h : env40789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40788_40789 : H12AffineEnvironment.transform 16 5392 env40788 = env40789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env40788 == env40789) = true)

theorem identity40789 : scanCanonicalize (H12AffineFastState.compose env40789 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40789 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40790 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,32768,262,5392,35109,1025,32769,4113,33,17,32771,269,16,34816,5392,4096,2341,1285,32800,257,33,38145,513]

theorem envBound40790 : H12AffineFastState.Bounded env40790 := by
  intro p hp
  have h : env40790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40789_40790 : H12AffineEnvironment.transform 12 268 env40789 = env40790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40789 == env40790) = true)

theorem identity40790 : scanCanonicalize (H12AffineFastState.compose env40790 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40790 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env40791 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5156,32768,35,5173,34816,1025,32769,4113,33,17,32771,40,16,34816,5173,4096,2048,1056,32800,36,33,37924,513]

theorem envBound40791 : H12AffineFastState.Bounded env40791 := by
  intro p hp
  have h : env40791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40790_40791 : H12AffineEnvironment.transform 7 37 env40790 = env40791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40790 == env40791) = true)

def env40792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,4194304,8388608,8487373,8328,65,4365616,8393985,8406289,8527100,1500,12645452,257,21792,46212,74250]

theorem envBound40792 : H12AffineFastState.Bounded env40792 := by
  intro p hp
  have h : env40792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40738_40792 : H12AffineEnvironment.transform 20 4161 env40738 = env40792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env40738 == env40792) = true)

def env40793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,4194304,16,98781,8328,65,4365616,5393,17665,138476,1500,4256860,257,21792,46212,74250]

theorem envBound40793 : H12AffineFastState.Bounded env40793 := by
  intro p hp
  have h : env40793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40792_40793 : H12AffineEnvironment.transform 22 16 env40792 = env40793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env40792 == env40793) = true)

theorem identity40793 : scanCanonicalize (H12AffineFastState.compose env40793 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 119927) := by decide +kernel

theorem selectedBound40793 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,119927,16,98781,8328,65,215367,5393,17665,138476,1500,73771,257,21792,46212,74250]

theorem envBound40794 : H12AffineFastState.Bounded env40794 := by
  intro p hp
  have h : env40794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40793_40794 : H12AffineEnvironment.transform 21 119927 env40793 = env40794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119927 env40793 == env40794) = true)

theorem identity40794 : scanCanonicalize (H12AffineFastState.compose env40794 (packedSelected [1,3,5,8,10,12,15,17,19,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound40794 : packedSelected [1,3,5,8,10,12,15,17,19,38,41] rootPS < 2^1333 := by decide +kernel

def env40795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,56572,1025,32769,4161,119927,16,98781,8328,65,10588,5393,17665,97527,1500,73771,257,21792,46212,74250]

theorem envBound40795 : H12AffineFastState.Bounded env40795 := by
  intro p hp
  have h : env40795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40794_40795 : H12AffineEnvironment.transform 16 90139 env40794 = env40795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env40794 == env40795) = true)

def env40796 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,56436,1025,32769,4161,119927,16,98645,8192,65,10588,5393,17665,97407,1364,73771,257,21792,46092,74250]

theorem envBound40796 : H12AffineFastState.Bounded env40796 := by
  intro p hp
  have h : env40796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40795_40796 : H12AffineEnvironment.transform 6 8 env40795 = env40796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40795 == env40796) = true)

theorem identity40796 : scanCanonicalize (H12AffineFastState.compose env40796 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40796 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40797 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79130,35189,1025,32769,4161,98678,16,98645,8192,65,10588,5393,4096,76158,1364,73771,257,33,46092,74250]

theorem envBound40797 : H12AffineFastState.Bounded env40797 := by
  intro p hp
  have h : env40797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40796_40797 : H12AffineEnvironment.transform 13 5377 env40796 = env40797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40796 == env40797) = true)

theorem identity40797 : scanCanonicalize (H12AffineFastState.compose env40797 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound40797 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env40798 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,5393,35189,1025,32769,4161,41341,16,41310,8192,65,10588,5393,4096,2421,1364,32,257,33,46092,513]

theorem envBound40798 : H12AffineFastState.Bounded env40798 := by
  intro p hp
  have h : env40798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40797_40798 : H12AffineEnvironment.transform 15 8203 env40797 = env40798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env40797 == env40798) = true)

theorem identity40798 : scanCanonicalize (H12AffineFastState.compose env40798 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound40798 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40799 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,5377,32768,1046,5393,35189,1025,32769,4161,34144,16,34115,1053,65,3393,5393,4096,2421,1364,32,257,33,36881,513]

theorem envBound40799 : H12AffineFastState.Bounded env40799 := by
  intro p hp
  have h : env40799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40798_40799 : H12AffineEnvironment.transform 12 1053 env40798 = env40799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env40798 == env40799) = true)

theorem identity40799 : scanCanonicalize (H12AffineFastState.compose env40799 (packedSelected [2,3,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 3393) := by decide +kernel

theorem selectedBound40799 : packedSelected [2,3,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env40800 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,5377,3393,1046,5393,1076,1025,3392,4161,2081,16,2050,1053,65,3393,5393,4096,2421,1364,32,257,33,7504,513]

theorem envBound40800 : H12AffineFastState.Bounded env40800 := by
  intro p hp
  have h : env40800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40799_40800 : H12AffineEnvironment.transform 14 3393 env40799 = env40800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3393 env40799 == env40800) = true)

theorem identity40800 : scanCanonicalize (H12AffineFastState.compose env40800 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound40800 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1361,1053,80,3393,1046,64,1076,1025,3392,1296,2081,16,2050,1053,65,3393,64,1361,2421,1364,32,257,33,2049,513]

theorem envBound40801 : H12AffineFastState.Bounded env40801 := by
  intro p hp
  have h : env40801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40800_40801 : H12AffineEnvironment.transform 11 1361 env40800 = env40801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env40800 == env40801) = true)

def env40802 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,56437,1025,32769,4161,119927,16,98644,8193,65,10588,5393,17665,97406,1365,73771,257,21792,46093,74250]

theorem envBound40802 : H12AffineFastState.Bounded env40802 := by
  intro p hp
  have h : env40802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40795_40802 : H12AffineEnvironment.transform 6 9 env40795 = env40802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40795 == env40802) = true)

theorem identity40802 : scanCanonicalize (H12AffineFastState.compose env40802 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound40802 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40803 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10281,1025,29789,4161,73771,16,95496,8193,65,10588,5393,17665,97406,1365,73771,257,21792,16465,74250]

theorem envBound40803 : H12AffineFastState.Bounded env40803 := by
  intro p hp
  have h : env40803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40802_40803 : H12AffineEnvironment.transform 14 29788 env40802 = env40803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env40802 == env40803) = true)

theorem identity40803 : scanCanonicalize (H12AffineFastState.compose env40803 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40803 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env40804 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,16401,10281,1025,29789,4161,33,16,21762,8193,65,10588,5393,17665,23668,1365,33,257,21792,16465,512]

theorem envBound40804 : H12AffineFastState.Bounded env40804 := by
  intro p hp
  have h : env40804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40803_40804 : H12AffineEnvironment.transform 15 8202 env40803 = env40804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40803 == env40804) = true)

theorem identity40804 : scanCanonicalize (H12AffineFastState.compose env40804 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40804 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40805 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,343,16401,2420,1025,21760,4161,33,16,21762,348,65,2049,5393,17665,23668,1365,33,257,21792,16465,512]

theorem envBound40805 : H12AffineFastState.Bounded env40805 := by
  intro p hp
  have h : env40805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40804_40805 : H12AffineEnvironment.transform 12 349 env40804 = env40805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40804 == env40805) = true)

theorem identity40805 : scanCanonicalize (H12AffineFastState.compose env40805 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40805 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40806 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,349,16384,21761,343,16401,2388,1025,21760,4161,1,16,21762,348,65,2049,5393,17665,23636,1365,1,257,21760,16465,512]

theorem envBound40806 : H12AffineFastState.Bounded env40806 := by
  intro p hp
  have h : env40806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40805_40806 : H12AffineEnvironment.transform 4 0 env40805 = env40806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40805 == env40806) = true)

theorem identity40806 : scanCanonicalize (H12AffineFastState.compose env40806 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound40806 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env40807 : List Nat := [2,4,8,16,0,64,9,256,512,1024,261,4096,349,16384,21761,343,16401,81,1025,21760,4161,1,16,21762,348,65,260,5393,17665,21841,1365,1,257,21760,16465,512]

theorem envBound40807 : H12AffineFastState.Bounded env40807 := by
  intro p hp
  have h : env40807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40806_40807 : H12AffineEnvironment.transform 10 261 env40806 = env40807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env40806 == env40807) = true)

theorem identity40807 : scanCanonicalize (H12AffineFastState.compose env40807 (packedSelected [2,3,4,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 843) := by decide +kernel

theorem selectedBound40807 : packedSelected [2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env40808 : List Nat := [2,4,8,16,0,64,9,256,512,843,261,4096,349,16384,21066,343,16401,81,842,21067,4161,1,16,21065,348,65,260,4698,16970,21018,542,1,257,21067,16465,512]

theorem envBound40808 : H12AffineFastState.Bounded env40808 := by
  intro p hp
  have h : env40808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40807_40808 : H12AffineEnvironment.transform 9 843 env40807 = env40808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 843 env40807 == env40808) = true)

theorem identity40808 : scanCanonicalize (H12AffineFastState.compose env40808 (packedSelected [0,2,3,7,8,14] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound40808 : packedSelected [0,2,3,7,8,14] rootPS < 2^1333 := by decide +kernel

def env40809 : List Nat := [2,4,8,16,0,64,9,256,271,68,261,4096,349,16384,20805,343,16401,81,69,20804,4161,1,16,20806,348,65,260,4437,16709,20757,273,1,257,20804,16465,271]

theorem envBound40809 : H12AffineFastState.Bounded env40809 := by
  intro p hp
  have h : env40809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40808_40809 : H12AffineEnvironment.transform 8 271 env40808 = env40809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env40808 == env40809) = true)

theorem identity40809 : scanCanonicalize (H12AffineFastState.compose env40809 (packedSelected [2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40809 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env40810 : List Nat := [2,4,8,16,0,16,9,256,271,20,261,4096,269,16384,20757,263,16401,1,21,20756,4113,1,16,20758,268,17,260,4357,16661,20757,273,1,257,20756,16385,271]

theorem envBound40810 : H12AffineFastState.Bounded env40810 := by
  intro p hp
  have h : env40810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40809_40810 : H12AffineEnvironment.transform 5 16 env40809 = env40810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40809 == env40810) = true)

theorem identity40810 : scanCanonicalize (H12AffineFastState.compose env40810 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4372) := by decide +kernel

theorem selectedBound40810 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40811 : List Nat := [2,4,8,16,0,16,9,256,271,20,261,4096,269,4372,1,263,4357,1,21,0,4113,1,16,2,268,17,260,4357,4097,1,273,1,257,0,4373,271]

theorem envBound40811 : H12AffineFastState.Bounded env40811 := by
  intro p hp
  have h : env40811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40810_40811 : H12AffineEnvironment.transform 13 4372 env40810 = env40811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4372 env40810 == env40811) = true)

theorem identity40811 : scanCanonicalize (H12AffineFastState.compose env40811 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound40811 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40812 : List Nat := [2,4,8,16,0,16,9,256,271,20,261,276,269,0,1,263,17,1,21,0,261,1,16,2,268,17,260,17,277,1,273,1,257,0,1,271]

theorem envBound40812 : H12AffineFastState.Bounded env40812 := by
  intro p hp
  have h : env40812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40811_40812 : H12AffineEnvironment.transform 11 276 env40811 = env40812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env40811 == env40812) = true)

theorem identity40812 : scanCanonicalize (H12AffineFastState.compose env40812 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40812 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40813 : List Nat := [2,4,8,16,0,16,9,4,11,20,1,16,9,0,1,3,17,1,21,0,1,1,16,2,8,17,0,17,17,1,21,1,5,0,1,11]

theorem envBound40813 : H12AffineFastState.Bounded env40813 := by
  intro p hp
  have h : env40813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40812_40813 : H12AffineEnvironment.transform 7 4 env40812 = env40813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40812 == env40813) = true)

theorem identity40813 : scanCanonicalize (H12AffineFastState.compose env40813 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound40813 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40814 : List Nat := [2,0,8,16,0,16,9,0,11,16,1,16,9,0,1,3,17,1,17,0,1,1,16,2,8,17,0,17,17,1,17,1,1,0,1,11]

theorem envBound40814 : H12AffineFastState.Bounded env40814 := by
  intro p hp
  have h : env40814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40813_40814 : H12AffineEnvironment.transform 1 0 env40813 = env40814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env40813 == env40814) = true)

theorem identity40814 : scanCanonicalize (H12AffineFastState.compose env40814 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound40814 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40815 : List Nat := [2,0,8,3,0,3,9,0,11,3,1,3,9,0,1,3,2,1,2,0,1,1,3,2,8,2,0,2,2,1,2,1,1,0,1,11]

theorem envBound40815 : H12AffineFastState.Bounded env40815 := by
  intro p hp
  have h : env40815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40814_40815 : H12AffineEnvironment.transform 3 3 env40814 = env40815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env40814 == env40815) = true)

def env40816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,4194304,17,98780,8328,65,4365616,5392,17664,138477,1500,4256861,257,21792,46212,74250]

theorem envBound40816 : H12AffineFastState.Bounded env40816 := by
  intro p hp
  have h : env40816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40792_40816 : H12AffineEnvironment.transform 22 17 env40792 = env40816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env40792 == env40816) = true)

theorem identity40816 : scanCanonicalize (H12AffineFastState.compose env40816 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound40816 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,56572,1025,32769,4161,4194304,17,21762,8328,65,4365616,5392,17664,138477,1500,4256861,257,21792,46212,63188]

theorem envBound40817 : H12AffineFastState.Bounded env40817 := by
  intro p hp
  have h : env40817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40816_40817 : H12AffineEnvironment.transform 15 54494 env40816 = env40817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env40816 == env40817) = true)

theorem identity40817 : scanCanonicalize (H12AffineFastState.compose env40817 (packedSelected [1,4,5,7,8,9,11,14,16,18,19,20,23,24,26,27,32,35] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40817 : packedSelected [1,4,5,7,8,9,11,14,16,18,19,20,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env40818 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,56437,1025,32769,4161,4194304,17,21762,8193,65,4365616,5392,17664,138340,1365,4256861,257,21792,46093,63069]

theorem envBound40818 : H12AffineFastState.Bounded env40818 := by
  intro p hp
  have h : env40818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40817_40818 : H12AffineEnvironment.transform 6 9 env40817 = env40818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40817 == env40818) = true)

theorem identity40818 : scanCanonicalize (H12AffineFastState.compose env40818 (packedSelected [0,3,5,8,9,11,12,15,16,18,19,20,22,26,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound40818 : packedSelected [0,3,5,8,9,11,12,15,16,18,19,20,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env40819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,56437,1025,32769,4161,41340,17,21762,8193,65,146508,5392,17664,138340,1365,21793,257,21792,46093,63069]

theorem envBound40819 : H12AffineFastState.Bounded env40819 := by
  intro p hp
  have h : env40819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40818_40819 : H12AffineEnvironment.transform 21 41340 env40818 = env40819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env40818 == env40819) = true)

theorem identity40819 : scanCanonicalize (H12AffineFastState.compose env40819 (packedSelected [3,4,5,7,11,15,16,19,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound40819 : packedSelected [3,4,5,7,11,15,16,19,22,27] rootPS < 2^1333 := by decide +kernel

def env40820 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,57676,56437,1025,32769,4161,41340,17,21762,8193,65,56576,5392,17664,64808,1365,21793,257,21792,46093,63069]

theorem envBound40820 : H12AffineFastState.Bounded env40820 := by
  intro p hp
  have h : env40820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40819_40820 : H12AffineEnvironment.transform 16 57676 env40819 = env40820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env40819 == env40820) = true)

theorem identity40820 : scanCanonicalize (H12AffineFastState.compose env40820 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound40820 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env40821 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54359,49168,56437,1025,32769,4161,32800,17,21762,349,65,56576,5392,17664,56436,1365,21793,257,21792,38225,55041]

theorem envBound40821 : H12AffineFastState.Bounded env40821 := by
  intro p hp
  have h : env40821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40820_40821 : H12AffineEnvironment.transform 12 348 env40820 = env40821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env40820 == env40821) = true)

theorem identity40821 : scanCanonicalize (H12AffineFastState.compose env40821 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40821 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env40822 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,54279,49168,56357,1025,32769,4113,32800,17,21762,269,17,56576,5392,17664,56356,1285,21793,257,21792,38145,55041]

theorem envBound40822 : H12AffineFastState.Bounded env40822 := by
  intro p hp
  have h : env40822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40821_40822 : H12AffineEnvironment.transform 5 16 env40821 = env40822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40821 == env40822) = true)

theorem identity40822 : scanCanonicalize (H12AffineFastState.compose env40822 (packedSelected [0,1,2,6,7,8,10,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound40822 : packedSelected [0,1,2,6,7,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env40823 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2064,268,16384,32768,52247,49168,50229,1025,32769,2049,32800,17,19730,269,17,50448,3328,17664,50228,1285,19761,257,19760,36113,53009]

theorem envBound40823 : H12AffineFastState.Bounded env40823 := by
  intro p hp
  have h : env40823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40822_40823 : H12AffineEnvironment.transform 11 2064 env40822 = env40823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env40822 == env40823) = true)

theorem identity40823 : scanCanonicalize (H12AffineFastState.compose env40823 (packedSelected [4,9] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound40823 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env40824 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2064,268,16384,1,19478,16401,17460,1025,0,2049,33,17,19730,269,17,17681,3328,17664,17461,1285,19761,257,19760,3344,20240]

theorem envBound40824 : H12AffineFastState.Bounded env40824 := by
  intro p hp
  have h : env40824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40823_40824 : H12AffineEnvironment.transform 14 1 env40823 = env40824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env40823 == env40824) = true)

theorem identity40824 : scanCanonicalize (H12AffineFastState.compose env40824 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 560) := by decide +kernel

theorem selectedBound40824 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env40825 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2064,268,560,1,3622,545,1540,1025,0,2049,33,17,3874,269,17,1825,3328,1840,1541,1285,3841,257,3840,3344,3360]

theorem envBound40825 : H12AffineFastState.Bounded env40825 := by
  intro p hp
  have h : env40825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40824_40825 : H12AffineEnvironment.transform 13 560 env40824 = env40825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env40824 == env40825) = true)

theorem identity40825 : scanCanonicalize (H12AffineFastState.compose env40825 (packedSelected [1,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound40825 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env40826 : List Nat := [2,4,8,16,32,16,9,256,512,1024,554,570,268,560,1,1036,545,1540,1025,0,555,33,17,1288,269,17,1825,1834,1840,1541,1285,1323,257,1322,1850,1802]

theorem envBound40826 : H12AffineFastState.Bounded env40826 := by
  intro p hp
  have h : env40826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40825_40826 : H12AffineEnvironment.transform 10 554 env40825 = env40826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env40825 == env40826) = true)

theorem identity40826 : scanCanonicalize (H12AffineFastState.compose env40826 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound40826 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env40827 : List Nat := [2,4,8,16,32,16,9,31,512,1024,554,570,19,560,1,1036,545,1540,1025,0,555,33,17,1047,18,17,1598,1589,1583,1541,1050,1076,30,1077,1573,1557]

theorem envBound40827 : H12AffineFastState.Bounded env40827 := by
  intro p hp
  have h : env40827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40826_40827 : H12AffineEnvironment.transform 7 31 env40826 = env40827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env40826 == env40827) = true)

theorem identity40827 : scanCanonicalize (H12AffineFastState.compose env40827 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound40827 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env40828 : List Nat := [2,4,8,16,32,16,9,31,512,31,554,570,19,560,1,19,545,539,30,0,555,33,17,8,18,17,545,554,560,538,5,43,30,42,570,522]

theorem envBound40828 : H12AffineFastState.Bounded env40828 := by
  intro p hp
  have h : env40828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40827_40828 : H12AffineEnvironment.transform 9 31 env40827 = env40828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env40827 == env40828) = true)

theorem identity40828 : scanCanonicalize (H12AffineFastState.compose env40828 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound40828 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env40829 : List Nat := [2,4,8,16,32,16,9,31,17,31,59,43,19,33,1,19,48,10,30,0,58,33,17,8,18,17,48,59,33,11,5,43,30,42,43,27]

theorem envBound40829 : H12AffineFastState.Bounded env40829 := by
  intro p hp
  have h : env40829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40828_40829 : H12AffineEnvironment.transform 8 17 env40828 = env40829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env40828 == env40829) = true)

theorem identity40829 : scanCanonicalize (H12AffineFastState.compose env40829 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound40829 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env40830 : List Nat := [2,4,8,16,20,16,9,31,17,31,15,31,19,21,1,19,4,10,30,0,14,21,17,8,18,17,4,15,21,11,5,31,30,30,31,27]

theorem envBound40830 : H12AffineFastState.Bounded env40830 := by
  intro p hp
  have h : env40830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1