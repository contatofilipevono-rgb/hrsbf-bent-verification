import H12CloudChart1Data060

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound15344 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15345 : List Nat := [2,4,5,6,6,7,2,4,2,3,6,1,2,6,1,2,7,1,3,0,1,7,1,5,5,6,1,7,0,0,3,7,4,7,7,2]

theorem envBound15345 : H12AffineFastState.Bounded env15345 := by
  intro p hp
  have h : env15345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15344_15345 : H12AffineEnvironment.transform 8 2 env15344 = env15345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env15344 == env15345) = true)

def env15346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272513,441760,98780,8328,65,316668,436384,17665,32160,440429,156013,256,21793,46212,499642]

theorem envBound15346 : H12AffineFastState.Bounded env15346 := by
  intro p hp
  have h : env15346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15311_15346 : H12AffineEnvironment.transform 21 272513 env15311 = env15346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env15311 == env15346) = true)

theorem identity15346 : scanCanonicalize (H12AffineFastState.compose env15346 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149860) := by decide +kernel

theorem selectedBound15346 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,58516,156133,62660,98780,8328,65,171416,57796,17665,32160,61705,156013,256,21793,46212,120542]

theorem envBound15347 : H12AffineFastState.Bounded env15347 := by
  intro p hp
  have h : env15347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15346_15347 : H12AffineEnvironment.transform 17 149860 env15346 = env15347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env15346 == env15347) = true)

def env15348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,56572,1024,32769,58516,62589,62660,98780,8328,65,2048,57796,17665,32160,61705,62709,256,21793,46212,120542]

theorem envBound15348 : H12AffineFastState.Bounded env15348 := by
  intro p hp
  have h : env15348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15347_15348 : H12AffineEnvironment.transform 16 38296 env15347 = env15348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env15347 == env15348) = true)

def env15349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38296,35324,1024,32769,45460,41341,41412,98780,8328,65,2048,46276,4097,10400,41993,41461,256,33,46212,99294]

theorem envBound15349 : H12AffineFastState.Bounded env15349 := by
  intro p hp
  have h : env15349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15348_15349 : H12AffineEnvironment.transform 13 5376 env15348 = env15349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15348 == env15349) = true)

theorem identity15349 : scanCanonicalize (H12AffineFastState.compose env15349 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15349 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8202,38296,35324,1024,32769,45460,41341,41412,41430,8328,65,2048,46276,4097,10400,41993,41461,256,33,46212,41940]

theorem envBound15350 : H12AffineFastState.Bounded env15350 := by
  intro p hp
  have h : env15350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15349_15350 : H12AffineEnvironment.transform 15 8202 env15349 = env15350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15349 == env15350) = true)

theorem identity15350 : scanCanonicalize (H12AffineFastState.compose env15350 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound15350 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env15351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8202,13389,10281,1024,8660,4161,168,17,3,8328,65,2048,5393,4097,10400,1500,32,256,33,5457,513]

theorem envBound15351 : H12AffineFastState.Bounded env15351 := by
  intro p hp
  have h : env15351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15350_15351 : H12AffineEnvironment.transform 14 8661 env15350 = env15351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env15350 == env15351) = true)

theorem identity15351 : scanCanonicalize (H12AffineFastState.compose env15351 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15351 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,216,263,5440,2340,1024,217,4161,168,17,3,389,65,2048,5393,4097,2477,1500,32,256,33,5457,513]

theorem envBound15352 : H12AffineFastState.Bounded env15352 := by
  intro p hp
  have h : env15352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15351_15352 : H12AffineEnvironment.transform 12 269 env15351 = env15352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15351 == env15352) = true)

theorem identity15352 : scanCanonicalize (H12AffineFastState.compose env15352 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound15352 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15353 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5376,0,263,5440,2340,1024,1,4161,112,17,3,349,65,2048,5393,4097,2421,1284,32,256,33,5457,513]

theorem envBound15353 : H12AffineFastState.Bounded env15353 := by
  intro p hp
  have h : env15353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15352_15353 : H12AffineEnvironment.transform 6 88 env15352 = env15353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env15352 == env15353) = true)

theorem identity15353 : scanCanonicalize (H12AffineFastState.compose env15353 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound15353 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env15354 : List Nat := [2,4,8,16,32,64,88,256,512,273,2048,4096,269,4113,0,263,4177,2340,273,1,4161,112,17,3,349,65,2048,4096,4097,2421,21,32,256,33,4160,513]

theorem envBound15354 : H12AffineFastState.Bounded env15354 := by
  intro p hp
  have h : env15354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15353_15354 : H12AffineEnvironment.transform 9 273 env15353 = env15354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15353 == env15354) = true)

def env15355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38296,35325,1024,32769,45461,41340,41413,98780,8328,65,2048,46277,4096,10401,41992,41460,256,32,46212,99295]

theorem envBound15355 : H12AffineFastState.Bounded env15355 := by
  intro p hp
  have h : env15355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15348_15355 : H12AffineEnvironment.transform 13 5377 env15348 = env15355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15348 == env15355) = true)

theorem identity15355 : scanCanonicalize (H12AffineFastState.compose env15355 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound15355 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8322,38296,35325,1024,32769,45461,41340,41413,41310,8328,65,2048,46277,4096,10401,41992,41460,256,32,46212,41821]

theorem envBound15356 : H12AffineFastState.Bounded env15356 := by
  intro p hp
  have h : env15356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15355_15356 : H12AffineEnvironment.transform 15 8322 env15355 = env15356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env15355 == env15356) = true)

theorem identity15356 : scanCanonicalize (H12AffineFastState.compose env15356 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15356 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env15357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,1,8322,5529,2556,1024,0,12692,8573,8644,8543,8328,65,2048,13508,4096,10401,9225,8693,256,32,13445,9052]

theorem envBound15357 : H12AffineFastState.Bounded env15357 := by
  intro p hp
  have h : env15357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15356_15357 : H12AffineEnvironment.transform 14 1 env15356 = env15357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15356 == env15357) = true)

def env15358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,56573,1024,32769,58516,62588,62660,98780,8328,65,2049,57796,17665,32160,61705,62708,256,21793,46212,120542]

theorem envBound15358 : H12AffineFastState.Bounded env15358 := by
  intro p hp
  have h : env15358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15347_15358 : H12AffineEnvironment.transform 16 38297 env15347 = env15358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env15347 == env15358) = true)

def env15359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38297,35325,1024,32769,45460,41340,41412,98780,8328,65,2049,46276,4097,10400,41993,41460,256,33,46212,99294]

theorem envBound15359 : H12AffineFastState.Bounded env15359 := by
  intro p hp
  have h : env15359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15358_15359 : H12AffineEnvironment.transform 13 5376 env15358 = env15359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15358 == env15359) = true)

theorem identity15359 : scanCanonicalize (H12AffineFastState.compose env15359 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound15359 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33247,38297,35325,1024,32769,45460,41340,41412,3,8328,65,2049,46276,4097,10400,41993,41460,256,33,46212,513]

theorem envBound15360 : H12AffineFastState.Bounded env15360 := by
  intro p hp
  have h : env15360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15359_15360 : H12AffineEnvironment.transform 15 33247 env15359 = env15360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env15359 == env15360) = true)

theorem identity15360 : scanCanonicalize (H12AffineFastState.compose env15360 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound15360 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env15361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,216,263,5441,2341,1024,217,12620,8612,8476,3,8328,65,2049,13340,4097,10400,9425,8492,256,33,13404,513]

theorem envBound15361 : H12AffineFastState.Bounded env15361 := by
  intro p hp
  have h : env15361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15360_15361 : H12AffineEnvironment.transform 14 216 env15360 = env15361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env15360 == env15361) = true)

theorem identity15361 : scanCanonicalize (H12AffineFastState.compose env15361 (packedSelected [0,2,6,7,9,14,16,18,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15361 : packedSelected [0,2,6,7,9,14,16,18,22,23] rootPS < 2^1333 := by decide +kernel

def env15362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,216,263,5441,2341,1024,217,4161,169,17,3,389,65,2049,5393,4097,2477,1500,33,256,33,5457,513]

theorem envBound15362 : H12AffineFastState.Bounded env15362 := by
  intro p hp
  have h : env15362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15361_15362 : H12AffineEnvironment.transform 12 269 env15361 = env15362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15361 == env15362) = true)

def env15363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38297,35324,1024,32769,45461,41341,41413,98780,8328,65,2049,46277,4096,10401,41992,41461,256,32,46212,99295]

theorem envBound15363 : H12AffineFastState.Bounded env15363 := by
  intro p hp
  have h : env15363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15358_15363 : H12AffineEnvironment.transform 13 5377 env15358 = env15363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15358 == env15363) = true)

theorem identity15363 : scanCanonicalize (H12AffineFastState.compose env15363 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound15363 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,38297,35324,1024,32769,45461,41341,41413,138,8328,65,2049,46277,4096,10401,41992,41461,256,32,46212,649]

theorem envBound15364 : H12AffineFastState.Bounded env15364 := by
  intro p hp
  have h : env15364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15363_15364 : H12AffineEnvironment.transform 15 33110 env15363 = env15364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env15363 == env15364) = true)

theorem identity15364 : scanCanonicalize (H12AffineFastState.compose env15364 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound15364 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env15365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,32768,33110,38297,35324,1024,32769,36928,32936,32784,138,349,65,2049,38160,4096,2420,34269,32800,256,32,38225,649]

theorem envBound15365 : H12AffineFastState.Bounded env15365 := by
  intro p hp
  have h : env15365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15364_15365 : H12AffineEnvironment.transform 12 469 env15364 = env15365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env15364 == env15365) = true)

theorem identity15365 : scanCanonicalize (H12AffineFastState.compose env15365 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound15365 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env15366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,0,342,5529,2556,1024,1,4160,168,16,138,349,65,2049,5392,4096,2420,1501,32,256,32,5457,649]

theorem envBound15366 : H12AffineFastState.Bounded env15366 := by
  intro p hp
  have h : env15366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15365_15366 : H12AffineEnvironment.transform 14 0 env15365 = env15366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env15365 == env15366) = true)

theorem identity15366 : scanCanonicalize (H12AffineFastState.compose env15366 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound15366 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15367 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,9,5341,0,138,5189,2080,1024,1,4160,168,16,138,129,65,2049,5324,4096,2216,1025,32,220,32,5261,649]

theorem envBound15367 : H12AffineFastState.Bounded env15367 := by
  intro p hp
  have h : env15367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15366_15367 : H12AffineEnvironment.transform 7 220 env15366 = env15367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env15366 == env15367) = true)

theorem identity15367 : scanCanonicalize (H12AffineFastState.compose env15367 (packedSelected [0,1,3,5,6,7,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15367 : packedSelected [0,1,3,5,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env15368 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,9,5205,0,2,5189,2080,1024,1,4160,32,16,2,9,65,2049,5188,4096,2080,1025,32,84,32,5125,513]

theorem envBound15368 : H12AffineFastState.Bounded env15368 := by
  intro p hp
  have h : env15368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15367_15368 : H12AffineEnvironment.transform 6 8 env15367 = env15368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15367 == env15368) = true)

theorem identity15368 : scanCanonicalize (H12AffineFastState.compose env15368 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2667) := by decide +kernel

theorem selectedBound15368 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15369 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,2667,9,3646,0,2,3630,2080,1024,1,2603,32,16,2,9,65,2049,3631,2667,2080,1025,32,84,32,3694,513]

theorem envBound15369 : H12AffineFastState.Bounded env15369 := by
  intro p hp
  have h : env15369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15368_15369 : H12AffineEnvironment.transform 11 2667 env15368 = env15369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2667 env15368 == env15369) = true)

theorem identity15369 : scanCanonicalize (H12AffineFastState.compose env15369 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15369 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15370 : List Nat := [2,4,8,16,32,16,8,4,512,1024,2048,2619,9,3646,0,2,3630,2080,1024,1,2603,32,16,2,9,17,2049,3631,2619,2080,1025,32,4,32,3646,513]

theorem envBound15370 : H12AffineFastState.Bounded env15370 := by
  intro p hp
  have h : env15370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15369_15370 : H12AffineEnvironment.transform 5 16 env15369 = env15370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15369 == env15370) = true)

theorem identity15370 : scanCanonicalize (H12AffineFastState.compose env15370 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15370 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15371 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,2587,9,3614,0,2,3598,2048,1024,1,2571,0,16,2,9,17,2049,3599,2587,2048,1025,0,4,0,3614,513]

theorem envBound15371 : H12AffineFastState.Bounded env15371 := by
  intro p hp
  have h : env15371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15370_15371 : H12AffineEnvironment.transform 4 0 env15370 = env15371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15370 == env15371) = true)

theorem identity15371 : scanCanonicalize (H12AffineFastState.compose env15371 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound15371 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15372 : List Nat := [2,4,8,16,0,16,8,4,512,1024,10,529,9,1556,0,2,1540,10,1024,1,513,0,16,2,9,17,11,1541,529,10,1025,0,4,0,1556,513]

theorem envBound15372 : H12AffineFastState.Bounded env15372 := by
  intro p hp
  have h : env15372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15371_15372 : H12AffineEnvironment.transform 10 10 env15371 = env15372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env15371 == env15372) = true)

theorem identity15372 : scanCanonicalize (H12AffineFastState.compose env15372 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound15372 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15373 : List Nat := [2,4,8,10,0,10,8,4,512,1024,10,523,9,1550,0,2,1540,10,1024,1,513,0,10,2,9,11,11,1541,523,10,1025,0,4,0,1550,513]

theorem envBound15373 : H12AffineFastState.Bounded env15373 := by
  intro p hp
  have h : env15373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15372_15373 : H12AffineEnvironment.transform 3 10 env15372 = env15373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env15372 == env15373) = true)

theorem identity15373 : scanCanonicalize (H12AffineFastState.compose env15373 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound15373 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15374 : List Nat := [2,4,8,10,0,10,8,4,512,4,10,523,9,522,0,2,512,10,4,1,513,0,10,2,9,11,11,513,523,10,5,0,4,0,522,513]

theorem envBound15374 : H12AffineFastState.Bounded env15374 := by
  intro p hp
  have h : env15374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15373_15374 : H12AffineEnvironment.transform 9 4 env15373 = env15374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env15373 == env15374) = true)

theorem identity15374 : scanCanonicalize (H12AffineFastState.compose env15374 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound15374 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env15375 : List Nat := [2,4,8,10,0,10,8,4,12,4,10,7,9,6,0,2,12,10,4,1,13,0,10,2,9,11,11,13,7,10,5,0,4,0,6,13]

theorem envBound15375 : H12AffineFastState.Bounded env15375 := by
  intro p hp
  have h : env15375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15374_15375 : H12AffineEnvironment.transform 8 12 env15374 = env15375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env15374 == env15375) = true)

theorem identity15375 : scanCanonicalize (H12AffineFastState.compose env15375 (packedSelected [0,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound15375 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env15376 : List Nat := [2,4,5,7,0,7,5,4,1,4,7,7,4,6,0,2,1,7,4,1,0,0,7,2,4,6,6,0,7,7,5,0,4,0,6,0]

theorem envBound15376 : H12AffineFastState.Bounded env15376 := by
  intro p hp
  have h : env15376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15375_15376 : H12AffineEnvironment.transform 2 5 env15375 = env15376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env15375 == env15376) = true)

theorem identity15376 : scanCanonicalize (H12AffineFastState.compose env15376 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound15376 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15377 : List Nat := [2,0,1,3,0,3,1,0,1,0,3,3,0,2,0,2,1,3,0,1,0,0,3,2,0,2,2,0,3,3,1,0,0,0,2,0]

theorem envBound15377 : H12AffineFastState.Bounded env15377 := by
  intro p hp
  have h : env15377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15376_15377 : H12AffineEnvironment.transform 1 0 env15376 = env15377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env15376 == env15377) = true)

def env15378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,4194304,441761,98781,8328,65,4258941,436385,17664,32161,440429,4606445,256,21793,46212,499642]

theorem envBound15378 : H12AffineFastState.Bounded env15378 := by
  intro p hp
  have h : env15378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15310_15378 : H12AffineEnvironment.transform 22 441761 env15310 = env15378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env15310 == env15378) = true)

def env15379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272512,441761,98781,8328,65,316669,436385,17664,32161,440429,156013,256,21793,46212,499642]

theorem envBound15379 : H12AffineFastState.Bounded env15379 := by
  intro p hp
  have h : env15379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15378_15379 : H12AffineEnvironment.transform 21 272512 env15378 = env15379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env15378 == env15379) = true)

def env15380 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272392,441641,98645,8192,65,316533,436265,17664,32041,440429,156013,256,21793,46092,499506]

theorem envBound15380 : H12AffineFastState.Bounded env15380 := by
  intro p hp
  have h : env15380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15379_15380 : H12AffineEnvironment.transform 6 8 env15379 = env15380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15379 == env15380) = true)

theorem identity15380 : scanCanonicalize (H12AffineFastState.compose env15380 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 236851) := by decide +kernel

theorem selectedBound15380 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env15381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,77899,243003,73754,98645,8192,65,215366,79130,17664,32041,75102,156013,256,21793,46092,513]

theorem envBound15381 : H12AffineFastState.Bounded env15381 := by
  intro p hp
  have h : env15381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15380_15381 : H12AffineEnvironment.transform 17 236851 env15380 = env15381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236851 env15380 == env15381) = true)

theorem identity15381 : scanCanonicalize (H12AffineFastState.compose env15381 (packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15381 : packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env15382 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4160,169264,17,41310,8192,65,158029,5393,17664,32041,1365,156013,256,21793,46092,513]

theorem envBound15382 : H12AffineFastState.Bounded env15382 := by
  intro p hp
  have h : env15382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15381_15382 : H12AffineEnvironment.transform 15 8203 env15381 = env15382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15381 == env15382) = true)

theorem identity15382 : scanCanonicalize (H12AffineFastState.compose env15382 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound15382 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15383 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,64809,1024,32769,4160,54561,17,41310,8192,65,10588,5393,17664,32041,1365,8572,256,21793,46092,513]

theorem envBound15383 : H12AffineFastState.Bounded env15383 := by
  intro p hp
  have h : env15383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15382_15383 : H12AffineEnvironment.transform 16 16401 env15382 = env15383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env15382 == env15383) = true)

theorem identity15383 : scanCanonicalize (H12AffineFastState.compose env15383 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15383 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15384 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16401,23668,1024,8540,4160,29820,17,3,8192,65,10588,5393,17664,32041,1365,8572,256,21793,5457,513]

theorem envBound15384 : H12AffineFastState.Bounded env15384 := by
  intro p hp
  have h : env15384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15383_15384 : H12AffineEnvironment.transform 14 8541 env15383 = env15384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15383 == env15384) = true)

theorem identity15384 : scanCanonicalize (H12AffineFastState.compose env15384 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound15384 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8541,8203,13673,10508,1024,8540,4160,260,17,3,8192,65,10588,5393,12408,2129,1365,8572,256,8281,5457,513]

theorem envBound15385 : H12AffineFastState.Bounded env15385 := by
  intro p hp
  have h : env15385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15384_15385 : H12AffineEnvironment.transform 13 13688 env15384 = env15385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env15384 == env15385) = true)

theorem identity15385 : scanCanonicalize (H12AffineFastState.compose env15385 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound15385 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env15386 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,12344,8541,8203,12329,10508,320,8540,4160,260,17,3,8192,65,10588,4177,12408,2129,21,8572,256,8281,4113,513]

theorem envBound15386 : H12AffineFastState.Bounded env15386 := by
  intro p hp
  have h : env15386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15385_15386 : H12AffineEnvironment.transform 9 320 env15385 = env15386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env15385 == env15386) = true)

theorem identity15386 : scanCanonicalize (H12AffineFastState.compose env15386 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound15386 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env15387 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,65,8192,8313,8541,8203,8296,10508,320,8540,1,260,17,3,8192,65,10588,16,8249,2129,21,8572,256,8281,80,513]

theorem envBound15387 : H12AffineFastState.Bounded env15387 := by
  intro p hp
  have h : env15387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15386_15387 : H12AffineEnvironment.transform 11 65 env15386 = env15387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env15386 == env15387) = true)

theorem identity15387 : scanCanonicalize (H12AffineFastState.compose env15387 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound15387 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env15388 : List Nat := [2,4,8,16,32,64,8,256,512,320,372,65,8192,8313,8541,8203,8296,8312,320,8540,1,260,17,3,8192,65,8232,16,8249,293,21,8572,256,8281,80,513]

theorem envBound15388 : H12AffineFastState.Bounded env15388 := by
  intro p hp
  have h : env15388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15387_15388 : H12AffineEnvironment.transform 10 372 env15387 = env15388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env15387 == env15388) = true)

theorem identity15388 : scanCanonicalize (H12AffineFastState.compose env15388 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound15388 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env15389 : List Nat := [2,4,8,16,32,64,8,116,512,52,0,65,8192,8313,8233,8203,8296,8312,52,8232,1,112,17,3,8192,65,8232,16,8249,81,21,8200,116,8281,80,513]

theorem envBound15389 : H12AffineFastState.Bounded env15389 := by
  intro p hp
  have h : env15389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15388_15389 : H12AffineEnvironment.transform 7 116 env15388 = env15389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env15388 == env15389) = true)

theorem identity15389 : scanCanonicalize (H12AffineFastState.compose env15389 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15389 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15390 : List Nat := [2,4,8,16,32,17,8,37,512,52,0,16,8192,8232,8233,8203,8249,8233,52,8232,1,33,17,3,8192,16,8232,16,8249,0,21,8200,37,8200,1,513]

theorem envBound15390 : H12AffineFastState.Bounded env15390 := by
  intro p hp
  have h : env15390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15389_15390 : H12AffineEnvironment.transform 5 17 env15389 = env15390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15389 == env15390) = true)

theorem identity15390 : scanCanonicalize (H12AffineFastState.compose env15390 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound15390 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15391 : List Nat := [2,4,8,16,32,17,8,37,512,52,0,16,41,1,0,34,16,0,52,1,1,33,17,3,41,16,1,16,16,0,21,33,37,33,1,513]

theorem envBound15391 : H12AffineFastState.Bounded env15391 := by
  intro p hp
  have h : env15391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15390_15391 : H12AffineEnvironment.transform 12 41 env15390 = env15391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env15390 == env15391) = true)

theorem identity15391 : scanCanonicalize (H12AffineFastState.compose env15391 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound15391 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15392 : List Nat := [2,4,8,16,32,17,8,37,16,52,0,16,41,1,0,34,16,0,52,1,1,33,17,3,41,16,1,16,16,0,21,33,37,33,1,17]

theorem envBound15392 : H12AffineFastState.Bounded env15392 := by
  intro p hp
  have h : env15392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15391_15392 : H12AffineEnvironment.transform 8 16 env15391 = env15392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env15391 == env15392) = true)

theorem identity15392 : scanCanonicalize (H12AffineFastState.compose env15392 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound15392 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15393 : List Nat := [2,4,8,16,11,17,8,14,16,31,0,16,2,1,0,9,16,0,31,1,1,10,17,3,2,16,1,16,16,0,21,10,14,10,1,17]

theorem envBound15393 : H12AffineFastState.Bounded env15393 := by
  intro p hp
  have h : env15393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15392_15393 : H12AffineEnvironment.transform 4 11 env15392 = env15393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env15392 == env15393) = true)

def env15394 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272393,441640,98644,8193,65,316532,436264,17664,32040,440429,156013,256,21793,46093,499507]

theorem envBound15394 : H12AffineFastState.Bounded env15394 := by
  intro p hp
  have h : env15394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15379_15394 : H12AffineEnvironment.transform 6 9 env15379 = env15394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15379 == env15394) = true)

theorem identity15394 : scanCanonicalize (H12AffineFastState.compose env15394 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound15394 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env15395 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,322920,272393,326969,98644,8193,65,316532,321593,17664,32040,325756,8572,256,21793,46093,384802]

theorem envBound15395 : H12AffineFastState.Bounded env15395 := by
  intro p hp
  have h : env15395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15394_15395 : H12AffineEnvironment.transform 16 16401 env15394 = env15395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env15394 == env15395) = true)

def env15396 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16401,262144,1024,21761,276584,272393,272441,87124,8193,65,262516,277817,17664,32040,273788,8572,256,21793,24845,330274]

theorem envBound15396 : H12AffineFastState.Bounded env15396 := by
  intro p hp
  have h : env15396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15395_15396 : H12AffineEnvironment.transform 14 21760 env15395 = env15396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env15395 == env15396) = true)

theorem identity15396 : scanCanonicalize (H12AffineFastState.compose env15396 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound15396 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15397 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,21591,16401,262144,1024,21761,276584,272393,272441,3,8193,65,262516,277817,17664,32040,273788,8572,256,21793,24845,286325]

theorem envBound15397 : H12AffineFastState.Bounded env15397 := by
  intro p hp
  have h : env15397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15396_15397 : H12AffineEnvironment.transform 15 21591 env15396 = env15397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env15396 == env15397) = true)

theorem identity15397 : scanCanonicalize (H12AffineFastState.compose env15397 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound15397 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env15398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,21591,16401,32041,1024,21761,17729,21792,21776,3,8193,65,31837,16400,17664,32040,20565,8572,256,21793,24845,9052]

theorem envBound15398 : H12AffineFastState.Bounded env15398 := by
  intro p hp
  have h : env15398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15397_15398 : H12AffineEnvironment.transform 17 32041 env15397 = env15398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env15397 == env15398) = true)

theorem identity15398 : scanCanonicalize (H12AffineFastState.compose env15398 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound15398 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env15399 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,8203,13389,2421,1024,8541,12573,8572,8524,3,8193,65,2049,13388,12636,2420,9225,8572,256,8573,5457,9052]

theorem envBound15399 : H12AffineFastState.Bounded env15399 := by
  intro p hp
  have h : env15399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15398_15399 : H12AffineEnvironment.transform 13 13404 env15398 = env15399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env15398 == env15399) = true)

theorem identity15399 : scanCanonicalize (H12AffineFastState.compose env15399 (packedSelected [1,2,3,5,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound15399 : packedSelected [1,2,3,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env15400 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,80,263,5441,2421,1024,81,4113,112,64,3,269,65,2049,5440,4176,2420,1285,112,256,113,5457,592]

theorem envBound15400 : H12AffineFastState.Bounded env15400 := by
  intro p hp
  have h : env15400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15399_15400 : H12AffineEnvironment.transform 12 268 env15399 = env15400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env15399 == env15400) = true)

theorem identity15400 : scanCanonicalize (H12AffineFastState.compose env15400 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15400 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15401 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,263,5393,2341,1024,1,4113,32,16,3,269,17,2049,5392,4096,2340,1285,32,256,33,5377,512]

theorem envBound15401 : H12AffineFastState.Bounded env15401 := by
  intro p hp
  have h : env15401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15400_15401 : H12AffineEnvironment.transform 5 16 env15400 = env15401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15400 == env15401) = true)

theorem identity15401 : scanCanonicalize (H12AffineFastState.compose env15401 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15401 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15402 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,268,5376,0,263,5393,2308,1024,1,4113,1,16,3,269,17,2049,5392,4096,2309,1285,1,256,0,5377,512]

theorem envBound15402 : H12AffineFastState.Bounded env15402 := by
  intro p hp
  have h : env15402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15401_15402 : H12AffineEnvironment.transform 4 1 env15401 = env15402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15401 == env15402) = true)

theorem identity15402 : scanCanonicalize (H12AffineFastState.compose env15402 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound15402 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15403 : List Nat := [2,4,8,16,1,16,9,256,512,1024,522,4096,268,5376,0,263,5393,782,1024,1,4113,1,16,3,269,17,523,5392,4096,783,1285,1,256,0,5377,512]

theorem envBound15403 : H12AffineFastState.Bounded env15403 := by
  intro p hp
  have h : env15403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15402_15403 : H12AffineEnvironment.transform 10 522 env15402 = env15403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env15402 == env15403) = true)

theorem identity15403 : scanCanonicalize (H12AffineFastState.compose env15403 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15403 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env15404 : List Nat := [2,4,8,16,1,16,9,4,512,1024,522,4096,8,5124,0,3,5141,522,1024,1,4113,1,16,3,9,17,523,5140,4096,523,1025,1,4,0,5125,512]

theorem envBound15404 : H12AffineFastState.Bounded env15404 := by
  intro p hp
  have h : env15404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15403_15404 : H12AffineEnvironment.transform 7 4 env15403 = env15404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15403 == env15404) = true)

def env15405 : List Nat := [2,4,8,16,1,16,9,4,512,1024,522,16,8,1044,0,3,1029,522,1024,1,1,1,16,3,9,17,523,1028,16,523,1025,1,4,0,1045,512]

theorem envBound15405 : H12AffineFastState.Bounded env15405 := by
  intro p hp
  have h : env15405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15404_15405 : H12AffineEnvironment.transform 11 16 env15404 = env15405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env15404 == env15405) = true)

theorem identity15405 : scanCanonicalize (H12AffineFastState.compose env15405 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound15405 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15406 : List Nat := [2,4,8,5,1,5,9,4,512,1024,522,5,8,1025,0,3,1029,522,1024,1,1,1,5,3,9,4,523,1028,5,523,1025,1,4,0,1024,512]

theorem envBound15406 : H12AffineFastState.Bounded env15406 := by
  intro p hp
  have h : env15406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15405_15406 : H12AffineEnvironment.transform 3 5 env15405 = env15406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env15405 == env15406) = true)

def env15407 : List Nat := [2,4,8,5,1,5,9,4,512,0,522,5,8,1,0,3,5,522,0,1,1,1,5,3,9,4,523,4,5,523,1,1,4,0,0,512]

theorem envBound15407 : H12AffineFastState.Bounded env15407 := by
  intro p hp
  have h : env15407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15406_15407 : H12AffineEnvironment.transform 9 0 env15406 = env15407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env15406 == env15407) = true)

theorem identity15407 : scanCanonicalize (H12AffineFastState.compose env15407 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound15407 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15408 : List Nat := [2,4,8,5,1,5,9,4,9,0,3,5,8,1,0,3,5,3,0,1,1,1,5,3,9,4,2,4,5,2,1,1,4,0,0,9]

theorem envBound15408 : H12AffineFastState.Bounded env15408 := by
  intro p hp
  have h : env15408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15407_15408 : H12AffineEnvironment.transform 8 9 env15407 = env15408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env15407 == env15408) = true)

def leafEnv15408 : List Nat := [2,4,8,5,1,5,9,4,9,0,3,5,8,1,0,3,5,3,0,1,1,1,5,3,0,9,1,4,2,4,5,2,1,1,4,0,5,2,0,9,1,0,0]

def active15408 : List Nat := [0,1,2]

def tree15408 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15408 : H12WitnessSearch.Good tree15408 := H12GlobalWitnessIndex.good

theorem leafIdentity15408 : H12AffineFastState.composeSystem env15408 rootObs = leafEnv15408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15408 rootObs == leafEnv15408) = true)

theorem terminalChecked15408 : H12PackedTerminal.terminalCheckFast leafEnv15408 active15408 tree15408 = true := by decide +kernel

def env15409 : List Nat := [2,4,8,5,1,5,9,4,512,1,522,5,8,0,0,3,4,522,1,1,1,1,5,3,9,4,523,5,5,523,0,1,4,0,1,512]

theorem envBound15409 : H12AffineFastState.Bounded env15409 := by
  intro p hp
  have h : env15409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15406_15409 : H12AffineEnvironment.transform 9 1 env15406 = env15409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env15406 == env15409) = true)

theorem identity15409 : scanCanonicalize (H12AffineFastState.compose env15409 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound15409 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15410 : List Nat := [1,4,8,5,1,5,9,4,512,1,521,5,8,0,0,0,4,521,1,1,1,1,5,0,9,4,520,5,5,520,0,1,4,0,1,512]

theorem envBound15410 : H12AffineFastState.Bounded env15410 := by
  intro p hp
  have h : env15410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15409_15410 : H12AffineEnvironment.transform 0 1 env15409 = env15410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env15409 == env15410) = true)

def leafEnv15410 : List Nat := [1,4,8,5,1,5,9,4,512,1,521,5,8,0,0,0,4,521,1,1,1,1,5,0,1,9,1,4,520,5,5,520,0,1,4,0,5,1,1,512,1,0,0]

def active15410 : List Nat := [1,2,8]

def tree15410 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15410 : H12WitnessSearch.Good tree15410 := H12GlobalWitnessIndex.good

theorem leafIdentity15410 : H12AffineFastState.composeSystem env15410 rootObs = leafEnv15410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15410 rootObs == leafEnv15410) = true)

theorem terminalChecked15410 : H12PackedTerminal.terminalCheckFast leafEnv15410 active15410 tree15410 = true := by decide +kernel

def env15411 : List Nat := [2,4,8,16,1,16,9,4,512,1024,522,17,8,1045,0,3,1028,522,1024,1,0,1,16,3,9,17,523,1029,17,523,1025,1,4,0,1044,512]

theorem envBound15411 : H12AffineFastState.Bounded env15411 := by
  intro p hp
  have h : env15411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15404_15411 : H12AffineEnvironment.transform 11 17 env15404 = env15411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env15404 == env15411) = true)

theorem identity15411 : scanCanonicalize (H12AffineFastState.compose env15411 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound15411 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15412 : List Nat := [2,4,8,16,1,16,9,4,512,0,522,17,8,21,0,3,4,522,0,1,0,1,16,3,9,17,523,5,17,523,1,1,4,0,20,512]

theorem envBound15412 : H12AffineFastState.Bounded env15412 := by
  intro p hp
  have h : env15412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15411_15412 : H12AffineEnvironment.transform 9 0 env15411 = env15412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env15411 == env15412) = true)

def env15413 : List Nat := [2,4,8,4,1,4,9,4,512,0,522,5,8,1,0,3,4,522,0,1,0,1,4,3,9,5,523,5,5,523,1,1,4,0,0,512]

theorem envBound15413 : H12AffineFastState.Bounded env15413 := by
  intro p hp
  have h : env15413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15412_15413 : H12AffineEnvironment.transform 3 4 env15412 = env15413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env15412 == env15413) = true)

theorem identity15413 : scanCanonicalize (H12AffineFastState.compose env15413 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound15413 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15414 : List Nat := [1,4,8,4,1,4,9,4,512,0,521,5,8,1,0,0,4,521,0,1,0,1,4,0,9,5,520,5,5,520,1,1,4,0,0,512]

theorem envBound15414 : H12AffineFastState.Bounded env15414 := by
  intro p hp
  have h : env15414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15413_15414 : H12AffineEnvironment.transform 0 1 env15413 = env15414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env15413 == env15414) = true)

def leafEnv15414 : List Nat := [1,4,8,4,1,4,9,4,512,0,521,5,8,1,0,0,4,521,0,1,0,1,4,0,0,9,1,5,520,5,5,520,1,1,4,0,5,1,0,512,1,1,0]

def active15414 : List Nat := [1,2,8]

def tree15414 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15414 : H12WitnessSearch.Good tree15414 := H12GlobalWitnessIndex.good

theorem leafIdentity15414 : H12AffineFastState.composeSystem env15414 rootObs = leafEnv15414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15414 rootObs == leafEnv15414) = true)

theorem terminalChecked15414 : H12PackedTerminal.terminalCheckFast leafEnv15414 active15414 tree15414 = true := by decide +kernel

def env15415 : List Nat := [2,4,8,5,1,5,9,4,512,0,522,4,8,0,0,3,4,522,0,1,0,1,5,3,9,4,523,5,4,523,1,1,4,0,1,512]

theorem envBound15415 : H12AffineFastState.Bounded env15415 := by
  intro p hp
  have h : env15415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15412_15415 : H12AffineEnvironment.transform 3 5 env15412 = env15415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env15412 == env15415) = true)

theorem identity15415 : scanCanonicalize (H12AffineFastState.compose env15415 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound15415 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15416 : List Nat := [2,4,8,5,1,5,9,4,8,0,2,4,8,0,0,3,4,2,0,1,0,1,5,3,9,4,3,5,4,3,1,1,4,0,1,8]

theorem envBound15416 : H12AffineFastState.Bounded env15416 := by
  intro p hp
  have h : env15416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15415_15416 : H12AffineEnvironment.transform 8 8 env15415 = env15416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env15415 == env15416) = true)

def leafEnv15416 : List Nat := [2,4,8,5,1,5,9,4,8,0,2,4,8,0,0,3,4,2,0,1,0,1,5,3,0,9,1,4,3,5,4,3,1,1,4,0,5,2,1,8,1,1,0]

def active15416 : List Nat := [0,1,2]

def tree15416 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15416 : H12WitnessSearch.Good tree15416 := H12GlobalWitnessIndex.good

theorem leafIdentity15416 : H12AffineFastState.composeSystem env15416 rootObs = leafEnv15416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15416 rootObs == leafEnv15416) = true)

theorem terminalChecked15416 : H12PackedTerminal.terminalCheckFast leafEnv15416 active15416 tree15416 = true := by decide +kernel

def env15417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16401,262144,1024,21760,276585,272393,272440,87125,8193,65,262517,277816,17664,32040,273789,8572,256,21793,24844,330275]

theorem envBound15417 : H12AffineFastState.Bounded env15417 := by
  intro p hp
  have h : env15417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15395_15417 : H12AffineEnvironment.transform 14 21761 env15395 = env15417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env15395 == env15417) = true)

theorem identity15417 : scanCanonicalize (H12AffineFastState.compose env15417 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 97407) := by decide +kernel

theorem selectedBound15417 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15418 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16401,97407,1024,21760,82966,87158,87111,87125,8193,65,97546,82247,17664,32040,86274,8572,256,21793,24844,30300]

theorem envBound15418 : H12AffineFastState.Bounded env15418 := by
  intro p hp
  have h : env15418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15417_15418 : H12AffineEnvironment.transform 17 97407 env15417 = env15418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97407 env15417 == env15418) = true)

theorem identity15418 : scanCanonicalize (H12AffineFastState.compose env15418 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15418 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env15419 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8203,16401,23668,1024,21760,25629,29821,29772,29790,8193,65,23809,24908,17664,32040,28937,8572,256,21793,24844,30300]

theorem envBound15419 : H12AffineFastState.Bounded env15419 := by
  intro p hp
  have h : env15419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15418_15419 : H12AffineEnvironment.transform 15 8203 env15418 = env15419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15418 == env15419) = true)

theorem identity15419 : scanCanonicalize (H12AffineFastState.compose env15419 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound15419 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env15420 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8461,8203,13341,10360,1024,8460,4113,113,64,82,8193,65,10509,5440,12556,2340,1285,8572,256,8493,5376,592]

theorem envBound15420 : H12AffineFastState.Bounded env15420 := by
  intro p hp
  have h : env15420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15419_15420 : H12AffineEnvironment.transform 13 13324 env15419 = env15420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env15419 == env15420) = true)

theorem identity15420 : scanCanonicalize (H12AffineFastState.compose env15420 (packedSelected [0,2,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound15420 : packedSelected [0,2,9,10] rootPS < 2^1333 := by decide +kernel

def env15421 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,8192,10360,8461,8203,10345,10360,1024,8460,3173,113,64,82,8193,65,10509,2356,11640,2340,1285,8572,256,8493,2420,592]

theorem envBound15421 : H12AffineFastState.Bounded env15421 := by
  intro p hp
  have h : env15421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15420_15421 : H12AffineEnvironment.transform 11 3188 env15420 = env15421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env15420 == env15421) = true)

theorem identity15421 : scanCanonicalize (H12AffineFastState.compose env15421 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound15421 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env15422 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,357,8192,9577,8461,8203,9592,9577,1024,8460,372,113,64,82,8193,65,9244,1061,8297,1077,1285,8572,256,8493,1125,592]

theorem envBound15422 : H12AffineFastState.Bounded env15422 := by
  intro p hp
  have h : env15422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15421_15422 : H12AffineEnvironment.transform 10 1297 env15421 = env15422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env15421 == env15422) = true)

theorem identity15422 : scanCanonicalize (H12AffineFastState.compose env15422 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound15422 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env15423 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1297,357,1385,0,1124,1378,17,0,1024,1125,372,113,64,82,1384,65,373,1061,1280,1077,1285,1045,256,1092,1125,592]

theorem envBound15423 : H12AffineFastState.Bounded env15423 := by
  intro p hp
  have h : env15423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15422_15423 : H12AffineEnvironment.transform 12 1385 env15422 = env15423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env15422 == env15423) = true)

theorem identity15423 : scanCanonicalize (H12AffineFastState.compose env15423 (packedSelected [7,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound15423 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env15424 : List Nat := [2,4,8,16,32,64,9,256,512,52,293,357,349,0,80,342,17,0,52,81,372,113,64,82,348,65,373,17,308,1,305,33,256,112,81,592]

theorem envBound15424 : H12AffineFastState.Bounded env15424 := by
  intro p hp
  have h : env15424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15423_15424 : H12AffineEnvironment.transform 9 52 env15423 = env15424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15423 == env15424) = true)

theorem identity15424 : scanCanonicalize (H12AffineFastState.compose env15424 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound15424 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env15425 : List Nat := [2,4,8,16,32,64,9,116,512,52,81,17,41,0,80,34,17,0,52,81,0,113,64,82,40,65,1,17,64,1,69,33,116,112,81,592]

theorem envBound15425 : H12AffineFastState.Bounded env15425 := by
  intro p hp
  have h : env15425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15424_15425 : H12AffineEnvironment.transform 7 116 env15424 = env15425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env15424 == env15425) = true)

theorem identity15425 : scanCanonicalize (H12AffineFastState.compose env15425 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15425 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15426 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,17,41,0,0,34,17,0,52,1,0,33,16,2,40,17,1,17,16,1,21,33,36,32,1,512]

theorem envBound15426 : H12AffineFastState.Bounded env15426 := by
  intro p hp
  have h : env15426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15425_15426 : H12AffineEnvironment.transform 5 16 env15425 = env15426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15425 == env15426) = true)

theorem identity15426 : scanCanonicalize (H12AffineFastState.compose env15426 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound15426 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15427 : List Nat := [2,4,8,16,5,16,9,1,512,17,1,17,12,0,0,7,17,0,17,1,0,4,16,2,13,17,1,17,16,1,21,4,1,5,1,512]

theorem envBound15427 : H12AffineFastState.Bounded env15427 := by
  intro p hp
  have h : env15427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15426_15427 : H12AffineEnvironment.transform 4 5 env15426 = env15427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env15426 == env15427) = true)

theorem identity15427 : scanCanonicalize (H12AffineFastState.compose env15427 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound15427 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15428 : List Nat := [2,4,8,16,5,16,9,1,13,17,1,17,12,0,0,7,17,0,17,1,0,4,16,2,13,17,1,17,16,1,21,4,1,5,1,13]

theorem envBound15428 : H12AffineFastState.Bounded env15428 := by
  intro p hp
  have h : env15428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15427_15428 : H12AffineEnvironment.transform 8 13 env15427 = env15428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env15427 == env15428) = true)

theorem identity15428 : scanCanonicalize (H12AffineFastState.compose env15428 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound15428 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15429 : List Nat := [2,0,8,16,1,16,9,1,9,17,1,17,8,0,0,3,17,0,17,1,0,0,16,2,9,17,1,17,16,1,17,0,1,1,1,9]

theorem envBound15429 : H12AffineFastState.Bounded env15429 := by
  intro p hp
  have h : env15429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15428_15429 : H12AffineEnvironment.transform 1 0 env15428 = env15429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env15428 == env15429) = true)

theorem identity15429 : scanCanonicalize (H12AffineFastState.compose env15429 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound15429 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15430 : List Nat := [0,0,8,16,1,16,9,1,9,17,1,17,8,0,0,1,17,0,17,1,0,0,16,0,9,17,1,17,16,1,17,0,1,1,1,9]

theorem envBound15430 : H12AffineFastState.Bounded env15430 := by
  intro p hp
  have h : env15430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15429_15430 : H12AffineEnvironment.transform 0 0 env15429 = env15430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env15429 == env15430) = true)

def env15431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272513,441761,98781,8328,65,316668,436385,17664,32161,440429,156012,256,21793,46212,499642]

theorem envBound15431 : H12AffineFastState.Bounded env15431 := by
  intro p hp
  have h : env15431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15378_15431 : H12AffineEnvironment.transform 21 272513 env15378 = env15431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env15378 == env15431) = true)

theorem identity15431 : scanCanonicalize (H12AffineFastState.compose env15431 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179633) := by decide +kernel

theorem selectedBound15431 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,169264,16,98781,8328,65,158029,5392,17664,32161,1500,156012,256,21793,46212,74251]

theorem envBound15432 : H12AffineFastState.Bounded env15432 := by
  intro p hp
  have h : env15432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15431_15432 : H12AffineEnvironment.transform 17 179633 env15431 = env15432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env15431 == env15432) = true)

theorem identity15432 : scanCanonicalize (H12AffineFastState.compose env15432 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15432 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env15433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179633,1024,32769,4161,169264,16,41431,8328,65,158029,5392,17664,32161,1500,156012,256,21793,46212,513]

theorem envBound15433 : H12AffineFastState.Bounded env15433 := by
  intro p hp
  have h : env15433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15432_15433 : H12AffineEnvironment.transform 15 8202 env15432 = env15433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15432 == env15433) = true)

def env15434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,4194304,8388608,8862845,8328,65,4258940,8393985,8845473,8830976,440428,12645453,256,21792,46213,499643]

theorem envBound15434 : H12AffineFastState.Bounded env15434 := by
  intro p hp
  have h : env15434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15309_15434 : H12AffineEnvironment.transform 23 8862845 env15309 = env15434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862845 env15309 == env15434) = true)

def env15435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,4194304,441760,98781,8328,65,4258940,436385,17665,32160,440428,4606445,256,21792,46213,499643]

theorem envBound15435 : H12AffineFastState.Bounded env15435 := by
  intro p hp
  have h : env15435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15434_15435 : H12AffineEnvironment.transform 22 441760 env15434 = env15435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env15434 == env15435) = true)

def env15436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272512,441760,98781,8328,65,316668,436385,17665,32160,440428,156013,256,21792,46213,499643]

theorem envBound15436 : H12AffineFastState.Bounded env15436 := by
  intro p hp
  have h : env15436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15435_15436 : H12AffineEnvironment.transform 21 272512 env15435 = env15436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env15435 == env15436) = true)

theorem identity15436 : scanCanonicalize (H12AffineFastState.compose env15436 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236986) := by decide +kernel

theorem selectedBound15436 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236986,1024,32769,77898,243002,73754,98781,8328,65,215366,79131,17665,32160,75222,156013,256,21792,46213,513]

theorem envBound15437 : H12AffineFastState.Bounded env15437 := by
  intro p hp
  have h : env15437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15436_15437 : H12AffineEnvironment.transform 17 236986 env15436 = env15437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236986 env15436 == env15437) = true)

def env15438 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,77898,243002,73754,98645,8192,65,215366,79131,17665,32040,75102,156013,256,21792,46093,513]

theorem envBound15438 : H12AffineFastState.Bounded env15438 := by
  intro p hp
  have h : env15438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15437_15438 : H12AffineEnvironment.transform 6 8 env15437 = env15438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15437 == env15438) = true)

theorem identity15438 : scanCanonicalize (H12AffineFastState.compose env15438 (packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15438 : packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env15439 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1024,32769,4161,169265,17,41310,8192,65,158029,5392,17665,32040,1365,156013,256,21792,46093,513]

theorem envBound15439 : H12AffineFastState.Bounded env15439 := by
  intro p hp
  have h : env15439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15438_15439 : H12AffineEnvironment.transform 15 8203 env15438 = env15439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15438 == env15439) = true)

theorem identity15439 : scanCanonicalize (H12AffineFastState.compose env15439 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound15439 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15440 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,64808,1024,32769,4161,54560,17,41310,8192,65,10588,5392,17665,32040,1365,8572,256,21792,46093,513]

theorem envBound15440 : H12AffineFastState.Bounded env15440 := by
  intro p hp
  have h : env15440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15439_15440 : H12AffineEnvironment.transform 16 16401 env15439 = env15440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env15439 == env15440) = true)

theorem identity15440 : scanCanonicalize (H12AffineFastState.compose env15440 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15440 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15441 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16401,23669,1024,8540,4161,29821,17,3,8192,65,10588,5392,17665,32040,1365,8572,256,21792,5456,513]

theorem envBound15441 : H12AffineFastState.Bounded env15441 := by
  intro p hp
  have h : env15441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15440_15441 : H12AffineEnvironment.transform 14 8541 env15440 = env15441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15440 == env15441) = true)

theorem identity15441 : scanCanonicalize (H12AffineFastState.compose env15441 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound15441 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15442 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8541,8203,13672,10508,1024,8540,4161,260,17,3,8192,65,10588,5392,12408,2129,1365,8572,256,8281,5456,513]

theorem envBound15442 : H12AffineFastState.Bounded env15442 := by
  intro p hp
  have h : env15442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15441_15442 : H12AffineEnvironment.transform 13 13689 env15441 = env15442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env15441 == env15442) = true)

theorem identity15442 : scanCanonicalize (H12AffineFastState.compose env15442 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound15442 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env15443 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,12345,8541,8203,12328,10508,320,8540,4161,260,17,3,8192,65,10588,4176,12408,2129,21,8572,256,8281,4112,513]

theorem envBound15443 : H12AffineFastState.Bounded env15443 := by
  intro p hp
  have h : env15443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15442_15443 : H12AffineEnvironment.transform 9 320 env15442 = env15443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env15442 == env15443) = true)

theorem identity15443 : scanCanonicalize (H12AffineFastState.compose env15443 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound15443 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env15444 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,4153,0,4452,4146,17,6453,320,4453,4161,260,17,3,4153,65,6501,4176,65,2129,21,4421,256,4192,4112,513]

theorem envBound15444 : H12AffineFastState.Bounded env15444 := by
  intro p hp
  have h : env15444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15443_15444 : H12AffineEnvironment.transform 12 4153 env15443 = env15444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env15443 == env15444) = true)

theorem identity15444 : scanCanonicalize (H12AffineFastState.compose env15444 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound15444 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env15445 : List Nat := [2,4,8,16,32,64,8,256,512,320,81,4096,4153,0,4452,4146,17,4452,320,4453,4161,260,17,3,4153,65,4404,4176,65,0,21,4421,256,4192,4112,513]

theorem envBound15445 : H12AffineFastState.Bounded env15445 := by
  intro p hp
  have h : env15445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15444_15445 : H12AffineEnvironment.transform 10 81 env15444 = env15445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env15444 == env15445) = true)

theorem identity15445 : scanCanonicalize (H12AffineFastState.compose env15445 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound15445 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15446 : List Nat := [2,4,8,16,32,64,8,116,512,52,81,4096,4153,0,4112,4146,17,4112,52,4113,4161,112,17,3,4153,65,4160,4176,65,0,21,4145,116,4192,4112,513]

theorem envBound15446 : H12AffineFastState.Bounded env15446 := by
  intro p hp
  have h : env15446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15445_15446 : H12AffineEnvironment.transform 7 116 env15445 = env15446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env15445 == env15446) = true)

theorem identity15446 : scanCanonicalize (H12AffineFastState.compose env15446 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound15446 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15447 : List Nat := [2,4,8,16,32,64,8,116,512,52,81,16,41,0,0,34,17,0,52,1,81,112,17,3,41,65,80,64,65,0,21,33,116,112,0,513]

theorem envBound15447 : H12AffineFastState.Bounded env15447 := by
  intro p hp
  have h : env15447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15446_15447 : H12AffineEnvironment.transform 11 16 env15446 = env15447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env15446 == env15447) = true)

theorem identity15447 : scanCanonicalize (H12AffineFastState.compose env15447 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15447 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15448 : List Nat := [2,4,8,16,32,17,8,37,512,52,0,16,41,0,0,34,17,0,52,1,0,33,17,3,41,16,1,17,16,0,21,33,37,33,0,513]

theorem envBound15448 : H12AffineFastState.Bounded env15448 := by
  intro p hp
  have h : env15448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15447_15448 : H12AffineEnvironment.transform 5 17 env15447 = env15448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15447 == env15448) = true)

theorem identity15448 : scanCanonicalize (H12AffineFastState.compose env15448 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound15448 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15449 : List Nat := [2,4,8,16,32,17,8,37,33,52,0,16,41,0,0,34,17,0,52,1,0,33,17,3,41,16,1,17,16,0,21,33,37,33,0,32]

theorem envBound15449 : H12AffineFastState.Bounded env15449 := by
  intro p hp
  have h : env15449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15448_15449 : H12AffineEnvironment.transform 8 33 env15448 = env15449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env15448 == env15449) = true)

def env15450 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,77898,243002,73754,98644,8193,65,215366,79131,17665,32041,75103,156013,256,21792,46092,513]

theorem envBound15450 : H12AffineFastState.Bounded env15450 := by
  intro p hp
  have h : env15450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15437_15450 : H12AffineEnvironment.transform 6 9 env15437 = env15450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15437 == env15450) = true)

theorem identity15450 : scanCanonicalize (H12AffineFastState.compose env15450 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound15450 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15451 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,64809,1024,32769,77898,54560,73754,98644,8193,65,10588,79131,17665,32041,75103,65911,256,21792,46092,513]

theorem envBound15451 : H12AffineFastState.Bounded env15451 := by
  intro p hp
  have h : env15451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15450_15451 : H12AffineEnvironment.transform 16 90138 env15450 = env15451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env15450 == env15451) = true)

theorem identity15451 : scanCanonicalize (H12AffineFastState.compose env15451 (packedSelected [0,2,4,6,9,18,20,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound15451 : packedSelected [0,2,4,6,9,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env15452 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1052,16384,32768,65536,82950,55605,1024,32769,70742,54560,66566,98644,1053,65,3392,69895,17665,22837,65859,65911,256,21792,36880,513]

theorem envBound15452 : H12AffineFastState.Bounded env15452 := by
  intro p hp
  have h : env15452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15451_15452 : H12AffineEnvironment.transform 12 1052 env15451 = env15452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env15451 == env15452) = true)

theorem identity15452 : scanCanonicalize (H12AffineFastState.compose env15452 (packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS)) = affineNative (2^(15+1) ^^^ 54563) := by decide +kernel

theorem selectedBound15452 : packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS < 2^1333 := by decide +kernel

def env15453 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1052,16384,32768,54563,37157,55605,1024,32769,49525,54560,53541,21623,1053,65,3392,50212,17665,22837,54368,54356,256,21792,36880,513]

theorem envBound15453 : H12AffineFastState.Bounded env15453 := by
  intro p hp
  have h : env15453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15452_15453 : H12AffineEnvironment.transform 15 54563 env15452 = env15453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54563 env15452 == env15453) = true)

theorem identity15453 : scanCanonicalize (H12AffineFastState.compose env15453 (packedSelected [0,1,3,7,12,15,18,20,24,28,32] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound15453 : packedSelected [0,1,3,7,12,15,18,20,24,28,32] rootPS < 2^1333 := by decide +kernel

def env15454 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,121,16384,32768,53574,37157,55605,101,32769,49525,53573,53541,20498,120,65,2341,49217,16740,22837,53253,53297,256,20805,36880,513]

theorem envBound15454 : H12AffineFastState.Bounded env15454 := by
  intro p hp
  have h : env15454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15453_15454 : H12AffineEnvironment.transform 9 101 env15453 = env15454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env15453 == env15454) = true)

theorem identity15454 : scanCanonicalize (H12AffineFastState.compose env15454 (packedSelected [2,4,6,9,11,14,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound15454 : packedSelected [2,4,6,9,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env15455 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,121,4112,32768,33110,37157,35109,101,32769,37221,33109,33077,2,120,65,2341,36945,4468,2341,32789,32801,256,341,36880,513]

theorem envBound15455 : H12AffineFastState.Bounded env15455 := by
  intro p hp
  have h : env15455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15454_15455 : H12AffineEnvironment.transform 13 4112 env15454 = env15455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env15454 == env15455) = true)

theorem identity15455 : scanCanonicalize (H12AffineFastState.compose env15455 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound15455 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15456 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,356,121,372,32768,33110,32833,35109,101,32769,32769,33109,33077,2,120,65,2341,33077,16,2341,32789,32801,256,341,33140,513]

theorem envBound15456 : H12AffineFastState.Bounded env15456 := by
  intro p hp
  have h : env15456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15455_15456 : H12AffineEnvironment.transform 11 356 env15455 = env15456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env15455 == env15456) = true)

theorem identity15456 : scanCanonicalize (H12AffineFastState.compose env15456 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15456 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15457 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,356,121,372,1,343,64,2340,101,0,0,340,308,2,120,65,2341,308,16,2341,20,32,256,341,373,513]

theorem envBound15457 : H12AffineFastState.Bounded env15457 := by
  intro p hp
  have h : env15457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15456_15457 : H12AffineEnvironment.transform 14 1 env15456 = env15457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15456 == env15457) = true)

theorem identity15457 : scanCanonicalize (H12AffineFastState.compose env15457 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound15457 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env15458 : List Nat := [2,4,8,16,32,64,9,256,512,101,293,356,121,372,1,343,64,1,101,0,0,340,308,2,120,65,0,308,16,0,20,32,256,341,373,513]

theorem envBound15458 : H12AffineFastState.Bounded env15458 := by
  intro p hp
  have h : env15458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15457_15458 : H12AffineEnvironment.transform 10 293 env15457 = env15458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env15457 == env15458) = true)

theorem identity15458 : scanCanonicalize (H12AffineFastState.compose env15458 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15458 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15459 : List Nat := [2,4,8,16,32,64,9,117,512,101,80,17,121,1,1,34,64,1,101,0,0,33,65,2,120,65,0,65,16,0,20,32,117,32,0,513]

theorem envBound15459 : H12AffineFastState.Bounded env15459 := by
  intro p hp
  have h : env15459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15458_15459 : H12AffineEnvironment.transform 7 117 env15458 = env15459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15458 == env15459) = true)

def env15460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272513,441760,98781,8328,65,316669,436385,17665,32160,440428,156012,256,21792,46213,499643]

theorem envBound15460 : H12AffineFastState.Bounded env15460 := by
  intro p hp
  have h : env15460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15435_15460 : H12AffineEnvironment.transform 21 272513 env15435 = env15460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env15435 == env15460) = true)

theorem identity15460 : scanCanonicalize (H12AffineFastState.compose env15460 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15460 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,437744,272513,441760,41431,8328,65,316669,436385,17665,32160,440428,156012,256,21792,46213,442289]

theorem envBound15461 : H12AffineFastState.Bounded env15461 := by
  intro p hp
  have h : env15461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15460_15461 : H12AffineEnvironment.transform 15 8202 env15460 = env15461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15460 == env15461) = true)

def env15462 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,437624,272393,441640,41311,8192,65,316533,436265,17665,32040,440428,156012,256,21792,46093,442169]

theorem envBound15462 : H12AffineFastState.Bounded env15462 := by
  intro p hp
  have h : env15462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15461_15462 : H12AffineEnvironment.transform 6 8 env15461 = env15462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15461 == env15462) = true)

theorem identity15462 : scanCanonicalize (H12AffineFastState.compose env15462 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound15462 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env15463 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38160,262144,1024,32769,276584,272393,272440,41311,8192,65,316533,277817,17665,32040,273788,62588,256,21792,46093,272937]

theorem envBound15463 : H12AffineFastState.Bounded env15463 := by
  intro p hp
  have h : env15463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15462_15463 : H12AffineEnvironment.transform 16 38160 env15462 = env15463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env15462 == env15463) = true)

def env15464 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,437625,272392,441641,41310,8193,65,316532,436264,17665,32041,440428,156012,256,21792,46092,442168]

theorem envBound15464 : H12AffineFastState.Bounded env15464 := by
  intro p hp
  have h : env15464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15461_15464 : H12AffineEnvironment.transform 6 9 env15461 = env15464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15461 == env15464) = true)

theorem identity15464 : scanCanonicalize (H12AffineFastState.compose env15464 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound15464 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env15465 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,13388,262144,1024,32769,301365,272392,297317,41310,8193,65,316532,302180,17665,32041,298016,21792,256,21792,46092,297844]

theorem envBound15465 : H12AffineFastState.Bounded env15465 := by
  intro p hp
  have h : env15465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15464_15465 : H12AffineEnvironment.transform 16 13388 env15464 = env15465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env15464 == env15465) = true)

theorem identity15465 : scanCanonicalize (H12AffineFastState.compose env15465 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound15465 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env15466 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,8202,13388,262144,1024,32769,301365,272392,297317,41310,8193,65,294912,302180,4469,10589,298016,340,256,340,46092,297844]

theorem envBound15466 : H12AffineFastState.Bounded env15466 := by
  intro p hp
  have h : env15466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15465_15466 : H12AffineEnvironment.transform 13 5236 env15465 = env15466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env15465 == env15466) = true)

theorem identity15466 : scanCanonicalize (H12AffineFastState.compose env15466 (packedSelected [0,1,3,5,6,7,8,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound15466 : packedSelected [0,1,3,5,6,7,8,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env15467 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,8202,13388,35189,1024,32769,4160,41341,16,41310,8193,65,2421,5393,4469,10589,1365,340,256,340,46092,513]

theorem envBound15467 : H12AffineFastState.Bounded env15467 := by
  intro p hp
  have h : env15467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15466_15467 : H12AffineEnvironment.transform 17 35189 env15466 = env15467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env15466 == env15467) = true)

theorem identity15467 : scanCanonicalize (H12AffineFastState.compose env15467 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound15467 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15468 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,5236,32768,1095,4097,35189,1024,32769,4160,34096,16,34067,1100,65,2421,5393,4469,3344,1365,340,256,340,36929,513]

theorem envBound15468 : H12AffineFastState.Bounded env15468 := by
  intro p hp
  have h : env15468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15467_15468 : H12AffineEnvironment.transform 12 1101 env15467 = env15468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env15467 == env15468) = true)

theorem identity15468 : scanCanonicalize (H12AffineFastState.compose env15468 (packedSelected [0,4,6,7,9,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 6452) := by decide +kernel

theorem selectedBound15468 : packedSelected [0,4,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env15469 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,5236,6452,1095,4097,4161,1024,6453,4160,7172,16,7207,1100,65,2421,5393,4469,3344,1365,340,256,340,2421,513]

theorem envBound15469 : H12AffineFastState.Bounded env15469 := by
  intro p hp
  have h : env15469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15468_15469 : H12AffineEnvironment.transform 14 6452 env15468 = env15469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6452 env15468 == env15469) = true)

theorem identity15469 : scanCanonicalize (H12AffineFastState.compose env15469 (packedSelected [0,3,4,5,6,7,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound15469 : packedSelected [0,3,4,5,6,7,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env15470 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,1101,3173,293,1095,2064,2128,1024,292,2129,1045,16,1078,1100,65,2421,3328,2404,3344,1365,340,256,340,2421,513]

theorem envBound15470 : H12AffineFastState.Bounded env15470 := by
  intro p hp
  have h : env15470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15469_15470 : H12AffineEnvironment.transform 11 2065 env15469 = env15470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env15469 == env15470) = true)

theorem identity15470 : scanCanonicalize (H12AffineFastState.compose env15470 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound15470 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env15471 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,2065,348,2420,293,342,2064,2128,273,292,2129,260,16,295,349,65,2421,2065,2404,2049,68,340,256,340,2421,513]

theorem envBound15471 : H12AffineFastState.Bounded env15471 := by
  intro p hp
  have h : env15471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15470_15471 : H12AffineEnvironment.transform 9 273 env15470 = env15471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15470 == env15471) = true)

theorem identity15471 : scanCanonicalize (H12AffineFastState.compose env15471 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15471 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env15472 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2065,269,2341,293,263,2064,2049,273,292,2048,260,16,295,268,16,2340,2065,2357,2049,21,261,256,261,2340,513]

theorem envBound15472 : H12AffineFastState.Bounded env15472 := by
  intro p hp
  have h : env15472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15471_15472 : H12AffineEnvironment.transform 5 17 env15471 = env15472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15471 == env15472) = true)

def env15473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,4194304,441761,98780,8328,65,4258940,436384,17664,32161,440428,4606444,256,21792,46213,499643]

theorem envBound15473 : H12AffineFastState.Bounded env15473 := by
  intro p hp
  have h : env15473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15434_15473 : H12AffineEnvironment.transform 22 441761 env15434 = env15473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env15434 == env15473) = true)

def env15474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272512,441761,98780,8328,65,316668,436384,17664,32161,440428,156012,256,21792,46213,499643]

theorem envBound15474 : H12AffineFastState.Bounded env15474 := by
  intro p hp
  have h : env15474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15473_15474 : H12AffineEnvironment.transform 21 272512 env15473 = env15474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env15473 == env15474) = true)

theorem identity15474 : scanCanonicalize (H12AffineFastState.compose env15474 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound15474 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,115871,213487,120014,98780,8328,65,245139,115151,17664,32161,119043,156012,256,21792,46213,63188]

theorem envBound15475 : H12AffineFastState.Bounded env15475 := by
  intro p hp
  have h : env15475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15474_15475 : H12AffineEnvironment.transform 17 223599 env15474 = env15475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env15474 == env15475) = true)

def env15476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,130175,1024,32769,115871,120063,120014,98780,8328,65,75907,115151,17664,32161,119043,62588,256,21792,46213,63188]

theorem envBound15476 : H12AffineFastState.Bounded env15476 := by
  intro p hp
  have h : env15476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15475_15476 : H12AffineEnvironment.transform 16 38160 env15475 = env15476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env15475 == env15476) = true)

theorem identity15476 : scanCanonicalize (H12AffineFastState.compose env15476 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound15476 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env15477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,25028,67755,1024,29909,77899,73771,73754,95496,8328,65,75907,79131,17664,32161,75223,168,256,21792,16465,512]

theorem envBound15477 : H12AffineFastState.Bounded env15477 := by
  intro p hp
  have h : env15477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15476_15477 : H12AffineEnvironment.transform 14 29908 env15476 = env15477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env15476 == env15477) = true)

theorem identity15477 : scanCanonicalize (H12AffineFastState.compose env15477 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15477 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env15478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21897,65536,16537,67755,1024,21896,69910,65910,65863,87125,469,65,68062,70726,17664,23804,66698,168,256,21792,16465,512]

theorem envBound15478 : H12AffineFastState.Bounded env15478 := by
  intro p hp
  have h : env15478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15477_15478 : H12AffineEnvironment.transform 12 349 env15477 = env15478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15477 == env15478) = true)

theorem identity15478 : scanCanonicalize (H12AffineFastState.compose env15478 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound15478 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env15479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5237,508,65536,5356,67755,1024,509,69910,65910,65863,65568,469,65,68062,70726,4469,2185,66698,168,256,341,5156,512]

theorem envBound15479 : H12AffineFastState.Bounded env15479 := by
  intro p hp
  have h : env15479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15478_15479 : H12AffineEnvironment.transform 13 5237 env15478 = env15479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env15478 == env15479) = true)

theorem identity15479 : scanCanonicalize (H12AffineFastState.compose env15479 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound15479 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env15480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5237,508,138,5356,2081,1024,509,4508,508,461,170,469,65,2388,5324,4469,2185,1024,168,256,341,5156,512]

theorem envBound15480 : H12AffineFastState.Bounded env15480 := by
  intro p hp
  have h : env15480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15479_15480 : H12AffineEnvironment.transform 15 138 env15479 = env15480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env15479 == env15480) = true)

theorem identity15480 : scanCanonicalize (H12AffineFastState.compose env15480 (packedSelected [6,11,14,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15480 : packedSelected [6,11,14,18] rootPS < 2^1333 := by decide +kernel

def env15481 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5237,373,3,5221,2081,1024,372,4373,373,324,35,348,65,2388,5189,4469,2048,1024,33,256,341,5156,512]

theorem envBound15481 : H12AffineFastState.Bounded env15481 := by
  intro p hp
  have h : env15481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15480_15481 : H12AffineEnvironment.transform 6 9 env15480 = env15481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15480 == env15481) = true)

theorem identity15481 : scanCanonicalize (H12AffineFastState.compose env15481 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15481 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env15482 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5237,0,3,5221,2081,1024,1,4192,0,49,35,41,65,2081,5189,4096,2048,1024,33,117,32,5156,512]

theorem envBound15482 : H12AffineFastState.Bounded env15482 := by
  intro p hp
  have h : env15482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15481_15482 : H12AffineEnvironment.transform 7 117 env15481 = env15482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15481 == env15482) = true)

theorem identity15482 : scanCanonicalize (H12AffineFastState.compose env15482 (packedSelected [1,3,4,5,8,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15482 : packedSelected [1,3,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env15483 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8,5205,0,3,5189,2049,1024,1,4160,0,17,3,9,65,2049,5189,4096,2048,1024,1,85,0,5124,512]

theorem envBound15483 : H12AffineFastState.Bounded env15483 := by
  intro p hp
  have h : env15483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15482_15483 : H12AffineEnvironment.transform 4 0 env15482 = env15483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15482 == env15483) = true)

theorem identity15483 : scanCanonicalize (H12AffineFastState.compose env15483 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15483 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15484 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,8,5124,0,3,5140,2049,1024,1,4113,0,17,3,9,16,2049,5140,4096,2048,1024,1,4,0,5124,512]

theorem envBound15484 : H12AffineFastState.Bounded env15484 := by
  intro p hp
  have h : env15484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15483_15484 : H12AffineEnvironment.transform 5 17 env15483 = env15484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15483 == env15484) = true)

def env15485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,130174,1024,32769,115871,120062,120014,98780,8328,65,75906,115151,17664,32161,119043,62589,256,21792,46213,63188]

theorem envBound15485 : H12AffineFastState.Bounded env15485 := by
  intro p hp
  have h : env15485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15475_15485 : H12AffineEnvironment.transform 16 38161 env15475 = env15485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env15475 == env15485) = true)

def env15486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272513,441761,98780,8328,65,316669,436384,17664,32161,440428,156013,256,21792,46213,499643]

theorem envBound15486 : H12AffineFastState.Bounded env15486 := by
  intro p hp
  have h : env15486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15473_15486 : H12AffineEnvironment.transform 21 272513 env15473 = env15486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env15473 == env15486) = true)

theorem identity15486 : scanCanonicalize (H12AffineFastState.compose env15486 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound15486 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,437744,272513,441761,21762,8328,65,316669,436384,17664,32161,440428,156013,256,21792,46213,412517]

theorem envBound15487 : H12AffineFastState.Bounded env15487 := by
  intro p hp
  have h : env15487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15486_15487 : H12AffineEnvironment.transform 15 54494 env15486 = env15487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env15486 == env15487) = true)

def env15488 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,437624,272393,441641,21762,8192,65,316533,436264,17664,32041,440428,156013,256,21792,46093,412517]

theorem envBound15488 : H12AffineFastState.Bounded env15488 := by
  intro p hp
  have h : env15488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15487_15488 : H12AffineEnvironment.transform 6 8 env15487 = env15488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15487 == env15488) = true)

theorem identity15488 : scanCanonicalize (H12AffineFastState.compose env15488 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound15488 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env15489 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,24909,262144,1024,32769,314421,272393,318564,21762,8192,65,316533,313701,17664,32041,317729,32,256,21792,46093,272936]

theorem envBound15489 : H12AffineFastState.Bounded env15489 := by
  intro p hp
  have h : env15489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15488_15489 : H12AffineEnvironment.transform 16 24909 env15488 = env15489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env15488 == env15489) = true)

theorem identity15489 : scanCanonicalize (H12AffineFastState.compose env15489 (packedSelected [2,3,4,6,9,12,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound15489 : packedSelected [2,3,4,6,9,12,23,24] rootPS < 2^1333 := by decide +kernel

def env15490 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,24909,56356,1024,32769,4113,62509,64,21762,8192,65,2129,5441,17664,32041,1285,32,256,21792,46093,62988]

theorem envBound15490 : H12AffineFastState.Bounded env15490 := by
  intro p hp
  have h : env15490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15489_15490 : H12AffineEnvironment.transform 17 56356 env15489 = env15490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env15489 == env15490) = true)

theorem identity15490 : scanCanonicalize (H12AffineFastState.compose env15490 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15490 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env15491 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54358,16401,56356,1024,32769,4113,54641,64,21762,348,65,2129,5441,17664,23669,1285,32,256,21792,38225,55120]

theorem envBound15491 : H12AffineFastState.Bounded env15491 := by
  intro p hp
  have h : env15491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15490_15491 : H12AffineEnvironment.transform 12 348 env15490 = env15491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15490 == env15491) = true)

theorem identity15491 : scanCanonicalize (H12AffineFastState.compose env15491 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15491 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env15492 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,54278,16401,56356,1024,32769,4113,54561,16,21762,268,17,2049,5393,17664,23589,1285,32,256,21792,38145,55040]

theorem envBound15492 : H12AffineFastState.Bounded env15492 := by
  intro p hp
  have h : env15492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15491_15492 : H12AffineEnvironment.transform 5 16 env15491 = env15492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15491 == env15492) = true)

theorem identity15492 : scanCanonicalize (H12AffineFastState.compose env15492 (packedSelected [0,3,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound15492 : packedSelected [0,3,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15493 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,2049,23559,16401,21541,1024,2048,4113,23840,16,21762,268,17,2049,5393,17664,23589,1285,32,256,21792,7424,24321]

theorem envBound15493 : H12AffineFastState.Bounded env15493 := by
  intro p hp
  have h : env15493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15492_15493 : H12AffineEnvironment.transform 14 2049 env15492 = env15493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env15492 == env15493) = true)

theorem identity15493 : scanCanonicalize (H12AffineFastState.compose env15493 (packedSelected [0,2,3,6,8,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound15493 : packedSelected [0,2,3,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env15494 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,268,16384,2049,22578,16401,20496,53,2048,4113,22805,16,20791,268,17,2049,4388,16693,22544,304,32,256,20757,6453,23348]

theorem envBound15494 : H12AffineFastState.Bounded env15494 := by
  intro p hp
  have h : env15494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15493_15494 : H12AffineEnvironment.transform 9 53 env15493 = env15494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15493 == env15494) = true)

theorem identity15494 : scanCanonicalize (H12AffineFastState.compose env15494 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound15494 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env15495 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,17,268,16384,2049,18467,16401,16385,53,2048,0,18692,16,16678,268,17,2049,309,16693,18433,304,32,256,16644,2340,19237]

theorem envBound15495 : H12AffineFastState.Bounded env15495 := by
  intro p hp
  have h : env15495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15494_15495 : H12AffineEnvironment.transform 11 17 env15494 = env15495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env15494 == env15495) = true)

theorem identity15495 : scanCanonicalize (H12AffineFastState.compose env15495 (packedSelected [1,3,4,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 292) := by decide +kernel

theorem selectedBound15495 : packedSelected [1,3,4,7,10] rootPS < 2^1333 := by decide +kernel

def env15496 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,17,268,292,2049,2311,309,293,53,2048,0,2080,16,2,268,17,2049,309,17,2341,304,32,256,32,2340,2561]

theorem envBound15496 : H12AffineFastState.Bounded env15496 := by
  intro p hp
  have h : env15496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15495_15496 : H12AffineEnvironment.transform 13 292 env15495 = env15496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 292 env15495 == env15496) = true)

theorem identity15496 : scanCanonicalize (H12AffineFastState.compose env15496 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15496 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env15497 : List Nat := [2,4,8,16,32,16,8,4,512,53,2048,17,8,32,2049,2051,49,33,53,2048,0,2080,16,2,8,17,2049,49,17,2081,52,32,4,32,2080,2561]

theorem envBound15497 : H12AffineFastState.Bounded env15497 := by
  intro p hp
  have h : env15497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15496_15497 : H12AffineEnvironment.transform 7 4 env15496 = env15497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15496 == env15497) = true)

theorem identity15497 : scanCanonicalize (H12AffineFastState.compose env15497 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound15497 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env15498 : List Nat := [2,4,8,16,32,16,8,4,512,53,1,17,8,32,0,2,49,33,53,1,0,33,16,2,8,17,0,49,17,32,52,32,4,32,33,512]

theorem envBound15498 : H12AffineFastState.Bounded env15498 := by
  intro p hp
  have h : env15498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15497_15498 : H12AffineEnvironment.transform 10 1 env15497 = env15498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env15497 == env15498) = true)

theorem identity15498 : scanCanonicalize (H12AffineFastState.compose env15498 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15498 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15499 : List Nat := [2,4,8,16,0,16,8,4,512,21,1,17,8,0,0,2,17,1,21,1,0,1,16,2,8,17,0,17,17,0,20,0,4,0,1,512]

theorem envBound15499 : H12AffineFastState.Bounded env15499 := by
  intro p hp
  have h : env15499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15498_15499 : H12AffineEnvironment.transform 4 0 env15498 = env15499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15498 == env15499) = true)

theorem identity15499 : scanCanonicalize (H12AffineFastState.compose env15499 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound15499 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15500 : List Nat := [2,4,8,16,0,16,8,4,16,21,1,17,8,0,0,2,17,1,21,1,0,1,16,2,8,17,0,17,17,0,20,0,4,0,1,16]

theorem envBound15500 : H12AffineFastState.Bounded env15500 := by
  intro p hp
  have h : env15500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15499_15500 : H12AffineEnvironment.transform 8 16 env15499 = env15500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env15499 == env15500) = true)

theorem identity15500 : scanCanonicalize (H12AffineFastState.compose env15500 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound15500 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15501 : List Nat := [2,1,8,16,0,16,8,1,16,16,1,17,8,0,0,2,17,1,16,1,0,1,16,2,8,17,0,17,17,0,17,0,1,0,1,16]

theorem envBound15501 : H12AffineFastState.Bounded env15501 := by
  intro p hp
  have h : env15501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15500_15501 : H12AffineEnvironment.transform 1 1 env15500 = env15501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env15500 == env15501) = true)

def env15502 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,437625,272392,441640,21762,8193,65,316532,436265,17664,32040,440428,156013,256,21792,46092,412517]

theorem envBound15502 : H12AffineFastState.Bounded env15502 := by
  intro p hp
  have h : env15502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15487_15502 : H12AffineEnvironment.transform 6 9 env15487 = env15502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15487 == env15502) = true)

theorem identity15502 : scanCanonicalize (H12AffineFastState.compose env15502 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound15502 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env15503 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,157753,1024,32769,50496,147505,54545,21762,8193,65,179277,49168,17664,32040,53333,156013,256,21792,46092,9052]

theorem envBound15503 : H12AffineFastState.Bounded env15503 := by
  intro p hp
  have h : env15503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15502_15503 : H12AffineEnvironment.transform 17 157753 env15502 = env15503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env15502 == env15503) = true)

theorem identity15503 : scanCanonicalize (H12AffineFastState.compose env15503 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15503 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env15504 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,21590,131072,157753,1024,0,17729,147505,21776,21762,8193,65,146508,16401,17664,32040,20564,156013,256,21792,13325,9052]

theorem envBound15504 : H12AffineFastState.Bounded env15504 := by
  intro p hp
  have h : env15504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15503_15504 : H12AffineEnvironment.transform 14 1 env15503 = env15504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15503 == env15504) = true)

theorem identity15504 : scanCanonicalize (H12AffineFastState.compose env15504 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound15504 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env15505 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,21590,13388,23669,1024,0,17729,29821,21776,21762,8193,65,2048,16401,17664,32040,20564,21793,256,21792,13325,9052]

theorem envBound15505 : H12AffineFastState.Bounded env15505 := by
  intro p hp
  have h : env15505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15504_15505 : H12AffineEnvironment.transform 16 13388 env15504 = env15505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env15504 == env15505) = true)

theorem identity15505 : scanCanonicalize (H12AffineFastState.compose env15505 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15505 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env15506 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,342,13388,2421,1024,0,4161,8573,16,2,8193,65,2048,5393,4096,10280,1364,33,256,32,13325,9052]

theorem envBound15506 : H12AffineFastState.Bounded env15506 := by
  intro p hp
  have h : env15506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15505_15506 : H12AffineEnvironment.transform 13 5376 env15505 = env15506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15505 == env15506) = true)

theorem identity15506 : scanCanonicalize (H12AffineFastState.compose env15506 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound15506 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env15507 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,381,5376,1,342,5425,2421,1024,0,4161,0,16,2,380,65,2048,5393,4096,2389,1364,33,256,32,5488,545]

theorem envBound15507 : H12AffineFastState.Bounded env15507 := by
  intro p hp
  have h : env15507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15506_15507 : H12AffineEnvironment.transform 12 381 env15506 = env15507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env15506 == env15507) = true)

theorem identity15507 : scanCanonicalize (H12AffineFastState.compose env15507 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound15507 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env15508 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,40,5205,1,3,5220,2080,1024,0,4161,0,16,2,41,65,2048,5188,4096,2048,1025,33,85,32,5157,545]

theorem envBound15508 : H12AffineFastState.Bounded env15508 := by
  intro p hp
  have h : env15508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15507_15508 : H12AffineEnvironment.transform 7 85 env15507 = env15508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env15507 == env15508) = true)

theorem identity15508 : scanCanonicalize (H12AffineFastState.compose env15508 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15508 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15509 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8,5205,1,3,5188,2048,1024,0,4161,0,16,2,9,65,2048,5188,4096,2048,1025,1,85,0,5125,513]

theorem envBound15509 : H12AffineFastState.Bounded env15509 := by
  intro p hp
  have h : env15509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15508_15509 : H12AffineEnvironment.transform 4 0 env15508 = env15509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15508 == env15509) = true)

theorem identity15509 : scanCanonicalize (H12AffineFastState.compose env15509 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 580) := by decide +kernel

theorem selectedBound15509 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15510 : List Nat := [2,4,8,16,0,64,9,85,512,580,2048,4096,8,4625,1,3,4608,2048,580,0,4161,0,16,2,9,65,2048,4608,4096,2048,581,1,85,0,4673,513]

theorem envBound15510 : H12AffineFastState.Bounded env15510 := by
  intro p hp
  have h : env15510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15509_15510 : H12AffineEnvironment.transform 9 580 env15509 = env15510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 580 env15509 == env15510) = true)

theorem identity15510 : scanCanonicalize (H12AffineFastState.compose env15510 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15510 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15511 : List Nat := [2,4,8,16,0,17,9,4,512,533,2048,4096,8,4625,1,3,4608,2048,533,0,4112,0,16,2,9,16,2048,4608,4096,2048,532,1,4,0,4624,513]

theorem envBound15511 : H12AffineFastState.Bounded env15511 := by
  intro p hp
  have h : env15511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15510_15511 : H12AffineEnvironment.transform 5 17 env15510 = env15511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15510 == env15511) = true)

theorem identity15511 : scanCanonicalize (H12AffineFastState.compose env15511 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound15511 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15512 : List Nat := [2,4,8,16,0,17,9,4,512,533,2048,1,8,528,1,3,513,2048,533,0,17,0,16,2,9,16,2048,513,1,2048,532,1,4,0,529,513]

theorem envBound15512 : H12AffineFastState.Bounded env15512 := by
  intro p hp
  have h : env15512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15511_15512 : H12AffineEnvironment.transform 11 1 env15511 = env15512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env15511 == env15512) = true)

theorem identity15512 : scanCanonicalize (H12AffineFastState.compose env15512 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound15512 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15513 : List Nat := [2,4,8,16,0,17,9,4,17,4,2048,1,8,1,1,3,16,2048,4,0,17,0,16,2,9,16,2048,16,1,2048,5,1,4,0,0,16]

theorem envBound15513 : H12AffineFastState.Bounded env15513 := by
  intro p hp
  have h : env15513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15512_15513 : H12AffineEnvironment.transform 8 17 env15512 = env15513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env15512 == env15513) = true)

theorem identity15513 : scanCanonicalize (H12AffineFastState.compose env15513 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound15513 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15514 : List Nat := [2,4,8,16,0,17,9,4,17,4,0,1,8,1,1,3,16,0,4,0,17,0,16,2,9,16,0,16,1,0,5,1,4,0,0,16]

theorem envBound15514 : H12AffineFastState.Bounded env15514 := by
  intro p hp
  have h : env15514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15513_15514 : H12AffineEnvironment.transform 10 0 env15513 = env15514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env15513 == env15514) = true)

theorem identity15514 : scanCanonicalize (H12AffineFastState.compose env15514 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15514 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15515 : List Nat := [2,4,8,1,0,0,9,4,0,4,0,1,8,1,1,3,1,0,4,0,0,0,1,2,9,1,0,1,1,0,5,1,4,0,0,1]

theorem envBound15515 : H12AffineFastState.Bounded env15515 := by
  intro p hp
  have h : env15515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15514_15515 : H12AffineEnvironment.transform 3 1 env15514 = env15515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15514 == env15515) = true)

def env15516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound15516 : H12AffineFastState.Bounded env15516 := by
  intro p hp
  have h : env15516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15307_15516 : H12AffineEnvironment.transform 18 1025 env15307 = env15516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env15307 == env15516) = true)

theorem identity15516 : scanCanonicalize (H12AffineFastState.compose env15516 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10833264) := by decide +kernel

theorem selectedBound15516 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env15517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10833264,8328,65,6458736,8702461,10507601,8830977,2410849,12855472,257,297436,288888,2485943]

theorem envBound15517 : H12AffineFastState.Bounded env15517 := by
  intro p hp
  have h : env15517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15516_15517 : H12AffineEnvironment.transform 23 10833264 env15516 = env15517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10833264 env15516 == env15517) = true)

def env15518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,2097152,4194304,8388608,10588556,8328,65,6458736,8393985,10507601,8527101,2102685,12645452,257,21792,46212,2175563]

theorem envBound15518 : H12AffineFastState.Bounded env15518 := by
  intro p hp
  have h : env15518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15517_15518 : H12AffineEnvironment.transform 17 56572 env15517 = env15518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56572 env15517 == env15518) = true)

def env15519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,4194304,8388608,8487372,8328,65,4365616,8393985,8406289,8527101,1501,12645452,257,21792,46212,74251]

theorem envBound15519 : H12AffineFastState.Bounded env15519 := by
  intro p hp
  have h : env15519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15518_15519 : H12AffineEnvironment.transform 20 4160 env15518 = env15519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15518 == env15519) = true)

def env15520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,4194304,16,98780,8328,65,4365616,5393,17665,138477,1501,4256860,257,21792,46212,74251]

theorem envBound15520 : H12AffineFastState.Bounded env15520 := by
  intro p hp
  have h : env15520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15519_15520 : H12AffineEnvironment.transform 22 16 env15519 = env15520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env15519 == env15520) = true)

theorem identity15520 : scanCanonicalize (H12AffineFastState.compose env15520 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound15520 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,169,16,98780,8328,65,171417,5393,17665,138477,1501,62709,257,21792,46212,74251]

theorem envBound15521 : H12AffineFastState.Bounded env15521 := by
  intro p hp
  have h : env15521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15520_15521 : H12AffineEnvironment.transform 21 169 env15520 = env15521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env15520 == env15521) = true)

def env15522 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,33,16,98644,8192,65,171281,5393,17665,138341,1365,62589,257,21792,46092,74251]

theorem envBound15522 : H12AffineFastState.Bounded env15522 := by
  intro p hp
  have h : env15522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15521_15522 : H12AffineEnvironment.transform 6 8 env15521 = env15522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15521 == env15522) = true)

theorem identity15522 : scanCanonicalize (H12AffineFastState.compose env15522 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound15522 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15523 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,56436,1025,32769,4160,33,16,62559,8192,65,171281,5393,17665,138341,1365,62589,257,21792,46092,22272]

theorem envBound15523 : H12AffineFastState.Bounded env15523 := by
  intro p hp
  have h : env15523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15522_15523 : H12AffineEnvironment.transform 15 29963 env15522 = env15523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env15522 == env15523) = true)

theorem identity15523 : scanCanonicalize (H12AffineFastState.compose env15523 (packedSelected [0,3,5,8,9,16,19,20,22,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound15523 : packedSelected [0,3,5,8,9,16,19,20,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env15524 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29963,131072,10281,1025,29788,4160,33,16,2,8192,65,158028,5393,17665,138341,1365,32,257,21792,16465,22272]

theorem envBound15524 : H12AffineFastState.Bounded env15524 := by
  intro p hp
  have h : env15524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15523_15524 : H12AffineEnvironment.transform 14 29789 env15523 = env15524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env15523 == env15524) = true)

theorem identity15524 : scanCanonicalize (H12AffineFastState.compose env15524 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13357) := by decide +kernel

theorem selectedBound15524 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env15525 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13357,112,294,131072,10281,1025,113,4160,33,16,2,8192,65,138593,5393,12588,138341,1365,32,257,8461,13436,9005]

theorem envBound15525 : H12AffineFastState.Bounded env15525 := by
  intro p hp
  have h : env15525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15524_15525 : H12AffineEnvironment.transform 13 13357 env15524 = env15525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13357 env15524 == env15525) = true)

theorem identity15525 : scanCanonicalize (H12AffineFastState.compose env15525 (packedSelected [0,4,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound15525 : packedSelected [0,4,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env15526 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5125,112,294,131072,2049,1025,113,4160,33,16,2,40,65,138593,5393,4356,138341,1365,32,257,293,5204,773]

theorem envBound15526 : H12AffineFastState.Bounded env15526 := by
  intro p hp
  have h : env15526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15525_15526 : H12AffineEnvironment.transform 12 40 env15525 = env15526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env15525 == env15526) = true)

theorem identity15526 : scanCanonicalize (H12AffineFastState.compose env15526 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound15526 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15527 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5125,112,294,5393,2049,1025,113,4160,33,16,2,40,65,2160,5393,4356,2420,1365,32,257,293,5204,773]

theorem envBound15527 : H12AffineFastState.Bounded env15527 := by
  intro p hp
  have h : env15527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15526_15527 : H12AffineEnvironment.transform 16 5393 env15526 = env15527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env15526 == env15527) = true)

theorem identity15527 : scanCanonicalize (H12AffineFastState.compose env15527 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15527 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env15528 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,40,5125,112,35,5140,2049,1025,113,4160,33,16,2,40,65,2160,5140,4097,2161,1104,32,4,32,5204,512]

theorem envBound15528 : H12AffineFastState.Bounded env15528 := by
  intro p hp
  have h : env15528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15527_15528 : H12AffineEnvironment.transform 7 5 env15527 = env15528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15527 == env15528) = true)

theorem identity15528 : scanCanonicalize (H12AffineFastState.compose env15528 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound15528 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15529 : List Nat := [2,4,8,16,32,48,8,5,512,1024,2048,4096,40,5125,0,35,5140,2049,1025,1,4144,33,16,2,40,49,2048,5140,4097,2049,1056,32,4,32,5156,512]

theorem envBound15529 : H12AffineFastState.Bounded env15529 := by
  intro p hp
  have h : env15529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15528_15529 : H12AffineEnvironment.transform 5 48 env15528 = env15529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env15528 == env15529) = true)

theorem identity15529 : scanCanonicalize (H12AffineFastState.compose env15529 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound15529 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15530 : List Nat := [2,4,8,16,32,48,8,5,512,1024,11,4096,40,5125,0,35,5140,10,1025,1,4144,33,16,2,40,49,11,5140,4097,10,1056,32,4,32,5156,512]

theorem envBound15530 : H12AffineFastState.Bounded env15530 := by
  intro p hp
  have h : env15530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15529_15530 : H12AffineEnvironment.transform 10 11 env15529 = env15530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env15529 == env15530) = true)

theorem identity15530 : scanCanonicalize (H12AffineFastState.compose env15530 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound15530 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15531 : List Nat := [2,4,8,16,32,48,8,5,512,1024,11,33,40,1060,0,35,1077,10,1025,1,17,33,16,2,40,49,11,1077,32,10,1056,32,4,32,1029,512]

theorem envBound15531 : H12AffineFastState.Bounded env15531 := by
  intro p hp
  have h : env15531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15530_15531 : H12AffineEnvironment.transform 11 33 env15530 = env15531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env15530 == env15531) = true)

theorem identity15531 : scanCanonicalize (H12AffineFastState.compose env15531 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound15531 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env15532 : List Nat := [2,4,8,16,32,48,8,5,512,31,11,33,40,59,0,35,42,10,30,1,17,33,16,2,40,49,11,42,32,10,63,32,4,32,26,512]

theorem envBound15532 : H12AffineFastState.Bounded env15532 := by
  intro p hp
  have h : env15532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15531_15532 : H12AffineEnvironment.transform 9 31 env15531 = env15532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env15531 == env15532) = true)

def env15533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,32,16,98645,8193,65,171280,5393,17665,138340,1364,62588,257,21792,46093,74251]

theorem envBound15533 : H12AffineFastState.Bounded env15533 := by
  intro p hp
  have h : env15533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15521_15533 : H12AffineEnvironment.transform 6 9 env15521 = env15533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15521 == env15533) = true)

theorem identity15533 : scanCanonicalize (H12AffineFastState.compose env15533 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound15533 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,56437,1025,32769,4160,32,16,21763,8193,65,171280,5393,17665,138340,1364,62588,257,21792,46093,63069]

theorem envBound15534 : H12AffineFastState.Bounded env15534 := by
  intro p hp
  have h : env15534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15533_15534 : H12AffineEnvironment.transform 15 54358 env15533 = env15534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env15533 == env15534) = true)

theorem identity15534 : scanCanonicalize (H12AffineFastState.compose env15534 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound15534 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env15535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,16400,56437,1025,32769,4160,32,16,21763,8193,65,56576,5393,17665,23668,1364,62588,257,21792,46093,63069]

theorem envBound15535 : H12AffineFastState.Bounded env15535 := by
  intro p hp
  have h : env15535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15534_15535 : H12AffineEnvironment.transform 16 16400 env15534 = env15535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env15534 == env15535) = true)

theorem identity15535 : scanCanonicalize (H12AffineFastState.compose env15535 (packedSelected [3,4,5,9,10,11,14,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15535 : packedSelected [3,4,5,9,10,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env15536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,54358,16400,56437,1025,32769,4160,32,16,21763,268,65,56576,5393,17665,23668,1364,54641,257,21792,38144,55120]

theorem envBound15536 : H12AffineFastState.Bounded env15536 := by
  intro p hp
  have h : env15536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15535_15536 : H12AffineEnvironment.transform 12 269 env15535 = env15536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15535 == env15536) = true)

theorem identity15536 : scanCanonicalize (H12AffineFastState.compose env15536 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound15536 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env15537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,32768,33030,5440,35109,1025,32769,4160,32,16,83,268,65,34896,5393,4177,2340,1364,32801,257,112,38144,33280]

theorem envBound15537 : H12AffineFastState.Bounded env15537 := by
  intro p hp
  have h : env15537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15536_15537 : H12AffineEnvironment.transform 13 5456 env15536 = env15537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env15536 == env15537) = true)

theorem identity15537 : scanCanonicalize (H12AffineFastState.compose env15537 (packedSelected [0,3,5,6,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 625) := by decide +kernel

theorem selectedBound15537 : packedSelected [0,3,5,6,9,14] rootPS < 2^1333 := by decide +kernel

def env15538 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,625,269,1825,32768,33030,1841,35109,1025,32769,561,32,16,83,268,65,34896,1888,544,2340,1364,32801,257,112,34673,33280]

theorem envBound15538 : H12AffineFastState.Bounded env15538 := by
  intro p hp
  have h : env15538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15537_15538 : H12AffineEnvironment.transform 11 625 env15537 = env15538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 625 env15537 == env15538) = true)

theorem identity15538 : scanCanonicalize (H12AffineFastState.compose env15538 (packedSelected [4,5,7,8,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 1604) := by decide +kernel

theorem selectedBound15538 : packedSelected [4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env15539 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,625,269,1825,1604,1858,1841,3937,1025,1605,561,32,16,83,268,65,3604,1888,544,2340,1364,1637,257,112,309,1092]

theorem envBound15539 : H12AffineFastState.Bounded env15539 := by
  intro p hp
  have h : env15539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15538_15539 : H12AffineEnvironment.transform 14 1604 env15538 = env15539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1604 env15538 == env15539) = true)

def env15540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,4194304,17,98781,8328,65,4365616,5392,17664,138476,1501,4256861,257,21792,46212,74251]

theorem envBound15540 : H12AffineFastState.Bounded env15540 := by
  intro p hp
  have h : env15540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15519_15540 : H12AffineEnvironment.transform 22 17 env15519 = env15540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env15519 == env15540) = true)

def env15541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,4194304,17,98645,8192,65,4365616,5392,17664,138340,1365,4256861,257,21792,46092,74251]

theorem envBound15541 : H12AffineFastState.Bounded env15541 := by
  intro p hp
  have h : env15541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15540_15541 : H12AffineEnvironment.transform 6 8 env15540 = env15541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15540 == env15541) = true)

theorem identity15541 : scanCanonicalize (H12AffineFastState.compose env15541 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound15541 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15542 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,56436,1025,32769,4160,4194304,17,2,8192,65,4365616,5392,17664,138340,1365,4256861,257,21792,46092,41820]

theorem envBound15542 : H12AffineFastState.Bounded env15542 := by
  intro p hp
  have h : env15542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15541_15542 : H12AffineEnvironment.transform 15 33111 env15541 = env15542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env15541 == env15542) = true)

theorem identity15542 : scanCanonicalize (H12AffineFastState.compose env15542 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound15542 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env15543 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,16400,56436,1025,32769,4160,4194304,17,2,8192,65,4250912,5392,17664,23668,1365,4256861,257,21792,46092,41820]

theorem envBound15543 : H12AffineFastState.Bounded env15543 := by
  intro p hp
  have h : env15543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15542_15543 : H12AffineEnvironment.transform 16 16400 env15542 = env15543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env15542 == env15543) = true)

theorem identity15543 : scanCanonicalize (H12AffineFastState.compose env15543 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15543 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env15544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,32041,1025,8540,4160,4194304,17,2,8192,65,4226173,5392,17664,23668,1365,4216064,257,21792,5457,513]

theorem envBound15544 : H12AffineFastState.Bounded env15544 := by
  intro p hp
  have h : env15544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15543_15544 : H12AffineEnvironment.transform 14 8541 env15543 = env15544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15543 == env15544) = true)

theorem identity15544 : scanCanonicalize (H12AffineFastState.compose env15544 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound15544 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15545 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,8202,16400,30777,273,8540,4160,4194304,17,2,8192,65,4225389,4096,16400,22884,69,4214800,257,20528,4161,513]

theorem envBound15545 : H12AffineFastState.Bounded env15545 := by
  intro p hp
  have h : env15545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15544_15545 : H12AffineEnvironment.transform 9 272 env15544 = env15545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env15544 == env15545) = true)

theorem identity15545 : scanCanonicalize (H12AffineFastState.compose env15545 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound15545 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15546 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8541,8202,4096,10281,273,8540,4160,4194304,17,2,8192,65,4204925,4096,4096,2420,69,4194304,257,32,4161,513]

theorem envBound15546 : H12AffineFastState.Bounded env15546 := by
  intro p hp
  have h : env15546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15545_15546 : H12AffineEnvironment.transform 13 4112 env15545 = env15546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env15545 == env15546) = true)

theorem identity15546 : scanCanonicalize (H12AffineFastState.compose env15546 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound15546 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15547 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8541,8202,4096,10281,273,8540,4160,113,17,2,8192,65,10508,4096,4096,2420,69,113,257,32,4161,513]

theorem envBound15547 : H12AffineFastState.Bounded env15547 := by
  intro p hp
  have h : env15547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15546_15547 : H12AffineEnvironment.transform 21 113 env15546 = env15547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env15546 == env15547) = true)

theorem identity15547 : scanCanonicalize (H12AffineFastState.compose env15547 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 4381) := by decide +kernel

theorem selectedBound15547 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env15548 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,4381,4112,4160,4375,4096,6452,273,4161,4160,113,17,2,4381,65,6161,4096,4096,2420,69,113,257,32,4161,513]

theorem envBound15548 : H12AffineFastState.Bounded env15548 := by
  intro p hp
  have h : env15548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15547_15548 : H12AffineEnvironment.transform 12 4381 env15547 = env15548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4381 env15547 == env15548) = true)

theorem identity15548 : scanCanonicalize (H12AffineFastState.compose env15548 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound15548 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15549 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,16,269,0,80,263,16,2340,273,81,80,113,17,2,269,65,2049,16,16,2420,69,113,257,32,81,513]

theorem envBound15549 : H12AffineFastState.Bounded env15549 := by
  intro p hp
  have h : env15549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15548_15549 : H12AffineEnvironment.transform 11 16 env15548 = env15549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env15548 == env15549) = true)

theorem identity15549 : scanCanonicalize (H12AffineFastState.compose env15549 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15549 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15550 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,16,41,0,80,35,16,2048,53,81,80,113,17,2,41,65,2049,16,16,2128,69,113,37,32,81,513]

theorem envBound15550 : H12AffineFastState.Bounded env15550 := by
  intro p hp
  have h : env15550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15549_15550 : H12AffineEnvironment.transform 7 36 env15549 = env15550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15549 == env15550) = true)

theorem identity15550 : scanCanonicalize (H12AffineFastState.compose env15550 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound15550 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15551 : List Nat := [2,4,8,16,32,64,8,36,512,52,113,16,41,0,80,35,16,113,53,81,80,113,17,2,41,65,112,16,16,33,69,113,37,32,81,513]

theorem envBound15551 : H12AffineFastState.Bounded env15551 := by
  intro p hp
  have h : env15551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15550_15551 : H12AffineEnvironment.transform 10 113 env15550 = env15551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env15550 == env15551) = true)

theorem identity15551 : scanCanonicalize (H12AffineFastState.compose env15551 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 112) := by decide +kernel

theorem selectedBound15551 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env15552 : List Nat := [2,4,8,16,32,64,8,36,112,52,113,16,41,0,80,35,16,113,53,81,80,113,17,2,41,65,112,16,16,33,69,113,37,32,81,113]

theorem envBound15552 : H12AffineFastState.Bounded env15552 := by
  intro p hp
  have h : env15552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15551_15552 : H12AffineEnvironment.transform 8 112 env15551 = env15552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 112 env15551 == env15552) = true)

theorem identity15552 : scanCanonicalize (H12AffineFastState.compose env15552 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15552 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15553 : List Nat := [2,4,8,16,1,64,8,5,81,21,80,16,8,0,80,2,16,80,20,81,80,80,17,2,8,65,81,16,16,0,69,80,4,1,81,80]

theorem envBound15553 : H12AffineFastState.Bounded env15553 := by
  intro p hp
  have h : env15553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15552_15553 : H12AffineEnvironment.transform 4 1 env15552 = env15553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15552 == env15553) = true)

def env15554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,4194304,17,98644,8193,65,4365616,5392,17664,138341,1364,4256861,257,21792,46093,74251]

theorem envBound15554 : H12AffineFastState.Bounded env15554 := by
  intro p hp
  have h : env15554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15540_15554 : H12AffineEnvironment.transform 6 9 env15540 = env15554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15540 == env15554) = true)

theorem identity15554 : scanCanonicalize (H12AffineFastState.compose env15554 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15554 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56437,1025,32769,4160,4194304,17,41310,8193,65,4365616,5392,17664,138341,1364,4256861,257,21792,46093,513]

theorem envBound15555 : H12AffineFastState.Bounded env15555 := by
  intro p hp
  have h : env15555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15554_15555 : H12AffineEnvironment.transform 15 8202 env15554 = env15555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15554 == env15555) = true)

theorem identity15555 : scanCanonicalize (H12AffineFastState.compose env15555 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound15555 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env15556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56437,1025,32769,4160,112,17,41310,8193,65,171328,5392,17664,138341,1364,62509,257,21792,46093,513]

theorem envBound15556 : H12AffineFastState.Bounded env15556 := by
  intro p hp
  have h : env15556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15555_15556 : H12AffineEnvironment.transform 21 112 env15555 = env15556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env15555 == env15556) = true)

def env15557 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56357,1025,32769,4112,32,17,41230,8193,17,171280,5392,17664,138293,1284,62509,257,21792,46093,513]

theorem envBound15557 : H12AffineFastState.Bounded env15557 := by
  intro p hp
  have h : env15557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15556_15557 : H12AffineEnvironment.transform 5 16 env15556 = env15557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15556 == env15557) = true)

theorem identity15557 : scanCanonicalize (H12AffineFastState.compose env15557 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound15557 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env15558 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,32768,8202,131072,43048,1025,32769,4112,32,17,41230,8193,17,171280,5392,12557,138293,1284,32800,257,8493,46093,513]

theorem envBound15558 : H12AffineFastState.Bounded env15558 := by
  intro p hp
  have h : env15558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15557_15558 : H12AffineEnvironment.transform 13 13325 env15557 = env15558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env15557 == env15558) = true)

theorem identity15558 : scanCanonicalize (H12AffineFastState.compose env15558 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound15558 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env15559 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,32768,8202,13341,43048,1025,32769,4112,32,17,41230,8193,17,43277,5392,12557,10280,1284,32800,257,8493,46093,513]

theorem envBound15559 : H12AffineFastState.Bounded env15559 := by
  intro p hp
  have h : env15559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15558_15559 : H12AffineEnvironment.transform 16 13341 env15558 = env15559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env15558 == env15559) = true)

theorem identity15559 : scanCanonicalize (H12AffineFastState.compose env15559 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound15559 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15560 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,32768,262,5393,35108,1025,32769,4112,32,17,32770,269,17,34817,5392,4097,2340,1284,32800,257,33,38145,513]

theorem envBound15560 : H12AffineFastState.Bounded env15560 := by
  intro p hp
  have h : env15560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15559_15560 : H12AffineEnvironment.transform 12 268 env15559 = env15560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env15559 == env15560) = true)

theorem identity15560 : scanCanonicalize (H12AffineFastState.compose env15560 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15560 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15561 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5393,2341,1025,0,4112,32,17,3,269,17,2048,5392,4097,2340,1284,33,257,33,5376,513]

theorem envBound15561 : H12AffineFastState.Bounded env15561 := by
  intro p hp
  have h : env15561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15560_15561 : H12AffineEnvironment.transform 14 1 env15560 = env15561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15560 == env15561) = true)

theorem identity15561 : scanCanonicalize (H12AffineFastState.compose env15561 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15561 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15562 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,268,5377,1,262,5393,2308,1025,0,4112,1,17,3,269,17,2048,5392,4097,2309,1284,0,257,0,5376,513]

theorem envBound15562 : H12AffineFastState.Bounded env15562 := by
  intro p hp
  have h : env15562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15561_15562 : H12AffineEnvironment.transform 4 1 env15561 = env15562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15561 == env15562) = true)

theorem identity15562 : scanCanonicalize (H12AffineFastState.compose env15562 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound15562 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15563 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,1028,268,261,1,262,277,2308,1025,0,1044,1,17,3,269,17,2048,276,1029,2309,1284,0,257,0,260,513]

theorem envBound15563 : H12AffineFastState.Bounded env15563 := by
  intro p hp
  have h : env15563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15562_15563 : H12AffineEnvironment.transform 11 1028 env15562 = env15563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env15562 == env15563) = true)

theorem identity15563 : scanCanonicalize (H12AffineFastState.compose env15563 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound15563 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15564 : List Nat := [2,4,8,16,1,16,9,256,512,1024,1557,1028,268,261,1,262,277,1809,1025,0,1044,1,17,3,269,17,1557,276,1029,1808,1284,0,257,0,260,513]

theorem envBound15564 : H12AffineFastState.Bounded env15564 := by
  intro p hp
  have h : env15564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15563_15564 : H12AffineEnvironment.transform 10 1557 env15563 = env15564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env15563 == env15564) = true)

theorem identity15564 : scanCanonicalize (H12AffineFastState.compose env15564 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound15564 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15565 : List Nat := [2,4,8,16,1,16,9,256,512,516,17,512,268,261,1,262,277,277,517,0,528,1,17,3,269,17,17,276,513,276,768,0,257,0,260,513]

theorem envBound15565 : H12AffineFastState.Bounded env15565 := by
  intro p hp
  have h : env15565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15564_15565 : H12AffineEnvironment.transform 9 516 env15564 = env15565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env15564 == env15565) = true)

theorem identity15565 : scanCanonicalize (H12AffineFastState.compose env15565 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15565 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15566 : List Nat := [2,4,8,16,1,16,9,256,1,5,17,1,268,261,1,262,277,277,4,0,17,1,17,3,269,17,17,276,0,276,257,0,257,0,260,0]

theorem envBound15566 : H12AffineFastState.Bounded env15566 := by
  intro p hp
  have h : env15566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15565_15566 : H12AffineEnvironment.transform 8 1 env15565 = env15566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15565 == env15566) = true)

def env15567 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,56356,1025,32769,4113,33,17,41231,8193,16,171281,5392,17664,138292,1285,62509,257,21792,46093,513]

theorem envBound15567 : H12AffineFastState.Bounded env15567 := by
  intro p hp
  have h : env15567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15556_15567 : H12AffineEnvironment.transform 5 17 env15556 = env15567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15556 == env15567) = true)

theorem identity15567 : scanCanonicalize (H12AffineFastState.compose env15567 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound15567 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env15568 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,56356,1025,32769,4113,33,17,41231,8193,16,23808,5392,17664,56357,1285,62509,257,21792,46093,513]

theorem envBound15568 : H12AffineFastState.Bounded env15568 := by
  intro p hp
  have h : env15568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15567_15568 : H12AffineEnvironment.transform 16 49169 env15567 = env15568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env15567 == env15568) = true)

theorem identity15568 : scanCanonicalize (H12AffineFastState.compose env15568 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound15568 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15569 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,8202,13340,10281,1025,29708,4113,33,17,21762,8193,16,23808,5392,17664,10280,1285,32,257,21792,16384,513]

theorem envBound15569 : H12AffineFastState.Bounded env15569 := by
  intro p hp
  have h : env15569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15568_15569 : H12AffineEnvironment.transform 14 29709 env15568 = env15569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env15568 == env15569) = true)

def env15570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,4194304,8388608,8487373,8328,65,4365617,8393985,8406288,8527101,1500,12645452,257,21792,46212,74250]

theorem envBound15570 : H12AffineFastState.Bounded env15570 := by
  intro p hp
  have h : env15570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15518_15570 : H12AffineEnvironment.transform 20 4161 env15518 = env15570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15518 == env15570) = true)

def env15571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,4194304,16,98781,8328,65,4365617,5393,17664,138477,1500,4256860,257,21792,46212,74250]

theorem envBound15571 : H12AffineFastState.Bounded env15571 := by
  intro p hp
  have h : env15571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15570_15571 : H12AffineEnvironment.transform 22 16 env15570 = env15571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env15570 == env15571) = true)

theorem identity15571 : scanCanonicalize (H12AffineFastState.compose env15571 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 62588) := by decide +kernel

theorem selectedBound15571 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,62588,16,98781,8328,65,158029,5393,17664,138477,1500,32,257,21792,46212,74250]

theorem envBound15572 : H12AffineFastState.Bounded env15572 := by
  intro p hp
  have h : env15572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15571_15572 : H12AffineEnvironment.transform 21 62588 env15571 = env15572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62588 env15571 == env15572) = true)

theorem identity15572 : scanCanonicalize (H12AffineFastState.compose env15572 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15572 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env15573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56572,1025,32769,4161,62588,16,41430,8328,65,158029,5393,17664,138477,1500,32,257,21792,46212,513]

theorem envBound15573 : H12AffineFastState.Bounded env15573 := by
  intro p hp
  have h : env15573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15572_15573 : H12AffineEnvironment.transform 15 8203 env15572 = env15573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15572 == env15573) = true)

theorem identity15573 : scanCanonicalize (H12AffineFastState.compose env15573 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound15573 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56572,1025,32769,4161,62588,16,41430,8328,65,10588,5393,17664,23804,1500,32,257,21792,46212,513]

theorem envBound15574 : H12AffineFastState.Bounded env15574 := by
  intro p hp
  have h : env15574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15573_15574 : H12AffineEnvironment.transform 16 16401 env15573 = env15574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env15573 == env15574) = true)

def env15575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4161,4194304,17,98780,8328,65,4365617,5392,17665,138476,1500,4256861,257,21792,46212,74250]

theorem envBound15575 : H12AffineFastState.Bounded env15575 := by
  intro p hp
  have h : env15575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15570_15575 : H12AffineEnvironment.transform 22 17 env15570 = env15575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env15570 == env15575) = true)

theorem identity15575 : scanCanonicalize (H12AffineFastState.compose env15575 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound15575 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10281,1025,29908,4161,4194304,17,95497,8328,65,4352484,5392,17665,138476,1500,4194440,257,21792,16465,74250]

theorem envBound15576 : H12AffineFastState.Bounded env15576 := by
  intro p hp
  have h : env15576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15575_15576 : H12AffineEnvironment.transform 14 29909 env15575 = env15576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env15575 == env15576) = true)

def env15577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10281,1025,8660,4161,4194304,17,73737,8328,65,4340964,5392,4097,138476,1500,4194440,257,32,5457,74250]

theorem envBound15577 : H12AffineFastState.Bounded env15577 := by
  intro p hp
  have h : env15577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15576_15577 : H12AffineEnvironment.transform 13 5376 env15576 = env15577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15576 == env15577) = true)

theorem identity15577 : scanCanonicalize (H12AffineFastState.compose env15577 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15577 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,131072,10281,1025,8660,4161,4194304,17,2,8328,65,4340964,5392,4097,138476,1500,4194440,257,32,5457,513]

theorem envBound15578 : H12AffineFastState.Bounded env15578 := by
  intro p hp
  have h : env15578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15577_15578 : H12AffineEnvironment.transform 15 8203 env15577 = env15578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15577 == env15578) = true)

theorem identity15578 : scanCanonicalize (H12AffineFastState.compose env15578 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15578 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env15579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,342,131072,2420,1025,137,4161,4194304,17,2,469,65,4332985,5392,4097,138476,1500,4194440,257,32,5457,513]

theorem envBound15579 : H12AffineFastState.Bounded env15579 := by
  intro p hp
  have h : env15579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15578_15579 : H12AffineEnvironment.transform 12 349 env15578 = env15579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15578 == env15579) = true)

theorem identity15579 : scanCanonicalize (H12AffineFastState.compose env15579 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound15579 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env15580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,342,5393,2420,1025,137,4161,4194304,17,2,469,65,4196520,5392,4097,2557,1500,4194440,257,32,5457,513]

theorem envBound15580 : H12AffineFastState.Bounded env15580 := by
  intro p hp
  have h : env15580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15579_15580 : H12AffineEnvironment.transform 16 5393 env15579 = env15580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env15579 == env15580) = true)

theorem identity15580 : scanCanonicalize (H12AffineFastState.compose env15580 (packedSelected [0,1,4,5,7,8,9,11,14,23,24] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound15580 : packedSelected [0,1,4,5,7,8,9,11,14,23,24] rootPS < 2^1333 := by decide +kernel

def env15581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,342,5393,2420,1025,137,4161,169,17,2,469,65,2049,5392,4097,2557,1500,33,257,32,5457,513]

theorem envBound15581 : H12AffineFastState.Bounded env15581 := by
  intro p hp
  have h : env15581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15580_15581 : H12AffineEnvironment.transform 21 169 env15580 = env15581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env15580 == env15581) = true)

theorem identity15581 : scanCanonicalize (H12AffineFastState.compose env15581 (packedSelected [0,1,3,7,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound15581 : packedSelected [0,1,3,7,11,14] rootPS < 2^1333 := by decide +kernel

def env15582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1572,349,804,136,342,821,2420,1025,137,1637,169,17,2,469,65,2049,820,1573,2557,1500,33,257,32,885,513]

theorem envBound15582 : H12AffineFastState.Bounded env15582 := by
  intro p hp
  have h : env15582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15581_15582 : H12AffineEnvironment.transform 11 1572 env15581 = env15582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env15581 == env15582) = true)

theorem identity15582 : scanCanonicalize (H12AffineFastState.compose env15582 (packedSelected [2,5,8,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 1708) := by decide +kernel

theorem selectedBound15582 : packedSelected [2,5,8,11,15] rootPS < 2^1333 := by decide +kernel

def env15583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1708,1572,349,804,136,342,821,2008,1025,137,1637,169,17,2,469,65,1709,820,1573,1873,1500,33,257,32,885,513]

theorem envBound15583 : H12AffineFastState.Bounded env15583 := by
  intro p hp
  have h : env15583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15582_15583 : H12AffineEnvironment.transform 10 1708 env15582 = env15583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1708 env15582 == env15583) = true)

theorem identity15583 : scanCanonicalize (H12AffineFastState.compose env15583 (packedSelected [0,2,27] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15583 : packedSelected [0,2,27] rootPS < 2^1333 := by decide +kernel

def env15584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1573,1572,349,804,1,342,821,1873,1025,0,1637,32,17,2,348,65,1572,820,1573,1873,1365,33,257,32,885,513]

theorem envBound15584 : H12AffineFastState.Bounded env15584 := by
  intro p hp
  have h : env15584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15583_15584 : H12AffineEnvironment.transform 6 9 env15583 = env15584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15583 == env15584) = true)

theorem identity15584 : scanCanonicalize (H12AffineFastState.compose env15584 (packedSelected [5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15584 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env15585 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1573,1572,269,804,1,262,821,1793,1025,0,1589,32,17,2,268,17,1572,820,1573,1793,1285,33,257,32,805,513]

theorem envBound15585 : H12AffineFastState.Bounded env15585 := by
  intro p hp
  have h : env15585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15584_15585 : H12AffineEnvironment.transform 5 16 env15584 = env15585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15584 == env15585) = true)

theorem identity15585 : scanCanonicalize (H12AffineFastState.compose env15585 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound15585 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15586 : List Nat := [2,4,8,16,32,16,9,52,512,1024,1573,1572,57,528,1,50,513,1589,1025,0,1589,32,17,2,56,17,1572,512,1573,1589,1073,33,53,32,529,513]

theorem envBound15586 : H12AffineFastState.Bounded env15586 := by
  intro p hp
  have h : env15586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15585_15586 : H12AffineEnvironment.transform 7 52 env15585 = env15586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env15585 == env15586) = true)

theorem identity15586 : scanCanonicalize (H12AffineFastState.compose env15586 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound15586 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15587 : List Nat := [2,4,8,16,32,16,9,52,512,564,17,16,57,528,1,50,513,1,565,0,1,32,17,2,56,17,16,512,17,1,517,33,53,32,529,513]

theorem envBound15587 : H12AffineFastState.Bounded env15587 := by
  intro p hp
  have h : env15587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15586_15587 : H12AffineEnvironment.transform 9 564 env15586 = env15587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env15586 == env15587) = true)

def env15588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10281,1025,8661,4161,4194304,17,73736,8328,65,4340965,5392,4096,138476,1500,4194440,257,33,5456,74250]

theorem envBound15588 : H12AffineFastState.Bounded env15588 := by
  intro p hp
  have h : env15588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15576_15588 : H12AffineEnvironment.transform 13 5377 env15576 = env15588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15576 == env15588) = true)

theorem identity15588 : scanCanonicalize (H12AffineFastState.compose env15588 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound15588 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8322,131072,10281,1025,8661,4161,4194304,17,138,8328,65,4340965,5392,4096,138476,1500,4194440,257,33,5456,648]

theorem envBound15589 : H12AffineFastState.Bounded env15589 := by
  intro p hp
  have h : env15589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15588_15589 : H12AffineEnvironment.transform 15 8322 env15588 = env15589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env15588 == env15589) = true)

theorem identity15589 : scanCanonicalize (H12AffineFastState.compose env15589 (packedSelected [0,1,3,4,5,7,8,10,11,18,19,22] rootPS)) = affineNative (2^(21+1) ^^^ 8692) := by decide +kernel

theorem selectedBound15589 : packedSelected [0,1,3,4,5,7,8,10,11,18,19,22] rootPS < 2^1333 := by decide +kernel

def env15590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8322,131072,10281,1025,8661,4161,8692,17,138,8328,65,138513,5392,4096,138476,1500,8572,257,33,5456,648]

theorem envBound15590 : H12AffineFastState.Bounded env15590 := by
  intro p hp
  have h : env15590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15589_15590 : H12AffineEnvironment.transform 21 8692 env15589 = env15590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8692 env15589 == env15590) = true)

theorem identity15590 : scanCanonicalize (H12AffineFastState.compose env15590 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15590 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env15591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,136,478,131072,2421,1025,137,4161,168,17,138,468,65,138513,5392,4096,138476,1500,32,257,33,5456,648]

theorem envBound15591 : H12AffineFastState.Bounded env15591 := by
  intro p hp
  have h : env15591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15590_15591 : H12AffineEnvironment.transform 12 348 env15590 = env15591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15590 == env15591) = true)

theorem identity15591 : scanCanonicalize (H12AffineFastState.compose env15591 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 5560) := by decide +kernel

theorem selectedBound15591 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,136,478,5560,2421,1025,137,4161,168,17,138,468,65,2217,5392,4096,2388,1500,32,257,33,5456,648]

theorem envBound15592 : H12AffineFastState.Bounded env15592 := by
  intro p hp
  have h : env15592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15591_15592 : H12AffineEnvironment.transform 16 5560 env15591 = env15592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5560 env15591 == env15592) = true)

theorem identity15592 : scanCanonicalize (H12AffineFastState.compose env15592 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound15592 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env15593 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,348,5377,112,294,5440,2421,1025,113,4161,80,17,114,300,65,2129,5392,4096,2388,1316,32,257,33,5456,624]

theorem envBound15593 : H12AffineFastState.Bounded env15593 := by
  intro p hp
  have h : env15593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15592_15593 : H12AffineEnvironment.transform 6 120 env15592 = env15593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env15592 == env15593) = true)

theorem identity15593 : scanCanonicalize (H12AffineFastState.compose env15593 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound15593 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15594 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,300,5377,0,294,5424,2309,1025,1,4145,32,17,2,300,49,2081,5392,4096,2340,1316,32,257,33,5408,512]

theorem envBound15594 : H12AffineFastState.Bounded env15594 := by
  intro p hp
  have h : env15594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15593_15594 : H12AffineEnvironment.transform 5 48 env15593 = env15594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env15593 == env15594) = true)

theorem identity15594 : scanCanonicalize (H12AffineFastState.compose env15594 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound15594 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env15595 : List Nat := [2,4,8,16,32,48,8,256,512,52,2048,4096,300,4405,0,294,4356,2309,53,1,4145,32,17,2,300,49,2081,4388,4096,2340,272,32,257,33,4372,512]

theorem envBound15595 : H12AffineFastState.Bounded env15595 := by
  intro p hp
  have h : env15595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15594_15595 : H12AffineEnvironment.transform 9 52 env15594 = env15595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15594 == env15595) = true)

theorem identity15595 : scanCanonicalize (H12AffineFastState.compose env15595 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15595 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env15596 : List Nat := [2,4,8,16,32,48,8,4,512,52,2048,4096,40,4145,0,34,4096,2049,53,1,4145,32,17,2,40,49,2081,4128,4096,2080,20,32,5,33,4112,512]

theorem envBound15596 : H12AffineFastState.Bounded env15596 := by
  intro p hp
  have h : env15596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15595_15596 : H12AffineEnvironment.transform 7 4 env15595 = env15596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15595 == env15596) = true)

theorem identity15596 : scanCanonicalize (H12AffineFastState.compose env15596 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15596 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15597 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,4096,8,4113,0,2,4096,2049,21,1,4113,0,17,2,8,17,2049,4096,4096,2048,20,0,5,1,4112,512]

theorem envBound15597 : H12AffineFastState.Bounded env15597 := by
  intro p hp
  have h : env15597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15596_15597 : H12AffineEnvironment.transform 4 0 env15596 = env15597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15596 == env15597) = true)

theorem identity15597 : scanCanonicalize (H12AffineFastState.compose env15597 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound15597 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15598 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,2065,8,2048,0,2,2065,2049,21,1,2048,0,17,2,8,17,2049,2065,2065,2048,20,0,5,1,2049,512]

theorem envBound15598 : H12AffineFastState.Bounded env15598 := by
  intro p hp
  have h : env15598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15597_15598 : H12AffineEnvironment.transform 11 2065 env15597 = env15598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env15597 == env15598) = true)

theorem identity15598 : scanCanonicalize (H12AffineFastState.compose env15598 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound15598 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15599 : List Nat := [2,4,8,4,0,4,8,4,512,0,2048,2053,8,2048,0,2,2053,2049,1,1,2048,0,5,2,8,5,2049,2053,2053,2048,0,0,5,1,2049,512]

theorem envBound15599 : H12AffineFastState.Bounded env15599 := by
  intro p hp
  have h : env15599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15598_15599 : H12AffineEnvironment.transform 3 4 env15598 = env15599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env15598 == env15599) = true)

theorem identity15599 : scanCanonicalize (H12AffineFastState.compose env15599 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound15599 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15600 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,8,0,0,2,5,1,1,1,0,0,5,2,8,5,1,5,5,0,0,0,5,1,1,512]

theorem envBound15600 : H12AffineFastState.Bounded env15600 := by
  intro p hp
  have h : env15600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1