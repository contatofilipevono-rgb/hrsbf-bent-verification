import H12CloudChart1Data203

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound51668 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51669 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24909,10280,1024,32769,4161,4194304,16,21762,8193,65,4258940,57676,17665,35189,61704,4194305,256,41340,16464,63069]

theorem envBound51669 : H12AffineFastState.Bounded env51669 := by
  intro p hp
  have h : env51669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51668_51669 : H12AffineEnvironment.transform 16 24909 env51668 = env51669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env51668 == env51669) = true)

theorem identity51669 : scanCanonicalize (H12AffineFastState.compose env51669 (packedSelected [2,3,5,6,7,9,10,11,16,18,22,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound51669 : packedSelected [2,3,5,6,7,9,10,11,16,18,22,27] rootPS < 2^1333 := by decide +kernel

def env51670 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,13389,10280,1024,32769,4161,4194304,16,2,8193,65,4237692,46156,4097,35189,41992,4194305,256,41340,5456,41821]

theorem envBound51670 : H12AffineFastState.Bounded env51670 := by
  intro p hp
  have h : env51670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51669_51670 : H12AffineEnvironment.transform 13 5376 env51669 = env51670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51669 == env51670) = true)

theorem identity51670 : scanCanonicalize (H12AffineFastState.compose env51670 (packedSelected [16,20] rootPS)) = affineNative (2^(21+1) ^^^ 32801) := by decide +kernel

theorem selectedBound51670 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env51671 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,13389,10280,1024,32769,4161,32801,16,2,8193,65,10589,46156,4097,35189,41992,32800,256,41340,5456,41821]

theorem envBound51671 : H12AffineFastState.Bounded env51671 := by
  intro p hp
  have h : env51671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51670_51671 : H12AffineEnvironment.transform 21 32801 env51670 = env51671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32801 env51670 == env51671) = true)

theorem identity51671 : scanCanonicalize (H12AffineFastState.compose env51671 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51671 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env51672 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,343,5393,2420,1024,32769,4161,32801,16,2,349,65,2049,38160,4097,35189,34132,32800,256,32800,5456,33281]

theorem envBound51672 : H12AffineFastState.Bounded env51672 := by
  intro p hp
  have h : env51672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51671_51672 : H12AffineEnvironment.transform 12 348 env51671 = env51672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51671 == env51672) = true)

theorem identity51672 : scanCanonicalize (H12AffineFastState.compose env51672 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 341) := by decide +kernel

theorem selectedBound51672 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51673 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,341,343,5393,2420,1024,340,4161,372,16,2,349,65,2049,5189,4097,2080,1025,373,256,373,5456,852]

theorem envBound51673 : H12AffineFastState.Bounded env51673 := by
  intro p hp
  have h : env51673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51672_51673 : H12AffineEnvironment.transform 14 341 env51672 = env51673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 341 env51672 == env51673) = true)

theorem identity51673 : scanCanonicalize (H12AffineFastState.compose env51673 (packedSelected [6,11,12,14,15,23] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound51673 : packedSelected [6,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env51674 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5204,1,3,5189,2080,1024,0,4161,32,16,2,9,65,2049,5189,4097,2080,1025,33,84,33,5124,512]

theorem envBound51674 : H12AffineFastState.Bounded env51674 := by
  intro p hp
  have h : env51674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51673_51674 : H12AffineEnvironment.transform 7 84 env51673 = env51674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env51673 == env51674) = true)

theorem identity51674 : scanCanonicalize (H12AffineFastState.compose env51674 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3167) := by decide +kernel

theorem selectedBound51674 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51675 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,3167,8,2059,1,3,2074,2080,1024,0,3102,32,16,2,9,65,2049,2074,3166,2080,1025,33,84,33,2139,512]

theorem envBound51675 : H12AffineFastState.Bounded env51675 := by
  intro p hp
  have h : env51675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51674_51675 : H12AffineEnvironment.transform 11 3167 env51674 = env51675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3167 env51674 == env51675) = true)

theorem identity51675 : scanCanonicalize (H12AffineFastState.compose env51675 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51675 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51676 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,3167,8,2059,1,3,2074,2049,1024,0,3102,1,16,2,9,65,2049,2074,3166,2049,1025,0,84,0,2139,512]

theorem envBound51676 : H12AffineFastState.Bounded env51676 := by
  intro p hp
  have h : env51676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51675_51676 : H12AffineEnvironment.transform 4 1 env51675 = env51676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51675 == env51676) = true)

theorem identity51676 : scanCanonicalize (H12AffineFastState.compose env51676 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 95) := by decide +kernel

theorem selectedBound51676 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51677 : List Nat := [2,4,8,16,1,64,9,84,512,95,2048,2048,8,2059,1,3,2074,2049,95,0,2113,1,16,2,9,65,2049,2074,2049,2049,94,0,84,0,2139,512]

theorem envBound51677 : H12AffineFastState.Bounded env51677 := by
  intro p hp
  have h : env51677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51676_51677 : H12AffineEnvironment.transform 9 95 env51676 = env51677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 95 env51676 == env51677) = true)

theorem identity51677 : scanCanonicalize (H12AffineFastState.compose env51677 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound51677 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env51678 : List Nat := [2,4,8,16,1,0,9,20,512,31,2048,2048,8,2059,1,3,2074,2049,31,0,2049,1,16,2,9,1,2049,2074,2049,2049,30,0,20,0,2075,512]

theorem envBound51678 : H12AffineFastState.Bounded env51678 := by
  intro p hp
  have h : env51678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51677_51678 : H12AffineEnvironment.transform 5 0 env51677 = env51678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env51677 == env51678) = true)

theorem identity51678 : scanCanonicalize (H12AffineFastState.compose env51678 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51678 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env51679 : List Nat := [2,4,8,11,1,0,9,15,512,4,2048,2048,8,2059,1,3,2049,2049,4,0,2049,1,11,2,9,1,2049,2049,2049,2049,5,0,15,0,2048,512]

theorem envBound51679 : H12AffineFastState.Bounded env51679 := by
  intro p hp
  have h : env51679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51678_51679 : H12AffineEnvironment.transform 3 11 env51678 = env51679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51678 == env51679) = true)

theorem identity51679 : scanCanonicalize (H12AffineFastState.compose env51679 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound51679 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51680 : List Nat := [2,4,8,11,1,0,9,15,2,4,2048,2048,8,2059,1,3,2049,2049,4,0,2049,1,11,2,9,1,2049,2049,2049,2049,5,0,15,0,2048,2]

theorem envBound51680 : H12AffineFastState.Bounded env51680 := by
  intro p hp
  have h : env51680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51679_51680 : H12AffineEnvironment.transform 8 2 env51679 = env51680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env51679 == env51680) = true)

theorem identity51680 : scanCanonicalize (H12AffineFastState.compose env51680 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51680 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51681 : List Nat := [2,4,3,0,1,0,2,4,2,4,2048,2048,3,2048,1,3,2049,2049,4,0,2049,1,0,2,2,1,2049,2049,2049,2049,5,0,4,0,2048,2]

theorem envBound51681 : H12AffineFastState.Bounded env51681 := by
  intro p hp
  have h : env51681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51680_51681 : H12AffineEnvironment.transform 2 3 env51680 = env51681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51680 == env51681) = true)

theorem identity51681 : scanCanonicalize (H12AffineFastState.compose env51681 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51681 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51682 : List Nat := [2,3,3,0,1,0,2,3,2,3,2048,2048,3,2048,1,3,2049,2049,3,0,2049,1,0,2,2,1,2049,2049,2049,2049,2,0,3,0,2048,2]

theorem envBound51682 : H12AffineFastState.Bounded env51682 := by
  intro p hp
  have h : env51682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51681_51682 : H12AffineEnvironment.transform 1 3 env51681 = env51682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51681 == env51682) = true)

theorem identity51682 : scanCanonicalize (H12AffineFastState.compose env51682 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound51682 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env51683 : List Nat := [2,3,3,0,1,0,2,3,2,3,1,1,3,1,1,3,0,0,3,0,0,1,0,2,2,1,0,0,0,0,2,0,3,0,1,2]

theorem envBound51683 : H12AffineFastState.Bounded env51683 := by
  intro p hp
  have h : env51683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51682_51683 : H12AffineEnvironment.transform 10 1 env51682 = env51683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env51682 == env51683) = true)

def env51684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,4194304,17,21762,8328,65,4316415,115150,17664,35325,119042,4268163,256,98815,90202,63189]

theorem envBound51684 : H12AffineFastState.Bounded env51684 := by
  intro p hp
  have h : env51684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51650_51684 : H12AffineEnvironment.transform 22 17 env51650 = env51684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env51650 == env51684) = true)

theorem identity51684 : scanCanonicalize (H12AffineFastState.compose env51684 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243122) := by decide +kernel

theorem selectedBound51684 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149996,1024,32769,4161,243122,17,21762,8328,65,158029,115150,17664,35325,119042,169265,256,98815,90202,63189]

theorem envBound51685 : H12AffineFastState.Bounded env51685 := by
  intro p hp
  have h : env51685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51684_51685 : H12AffineEnvironment.transform 21 243122 env51684 = env51685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243122 env51684 == env51685) = true)

theorem identity51685 : scanCanonicalize (H12AffineFastState.compose env51685 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound51685 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env51686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149996,1024,29909,4161,213350,17,21762,8328,65,158029,79130,17664,32041,75222,156133,256,95531,90202,513]

theorem envBound51686 : H12AffineFastState.Bounded env51686 := by
  intro p hp
  have h : env51686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51685_51686 : H12AffineEnvironment.transform 14 29908 env51685 = env51686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env51685 == env51686) = true)

theorem identity51686 : scanCanonicalize (H12AffineFastState.compose env51686 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound51686 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env51687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,76278,1024,29909,4161,8572,17,21762,8328,65,67927,79130,17664,32041,75222,66047,256,95531,90202,513]

theorem envBound51687 : H12AffineFastState.Bounded env51687 := by
  intro p hp
  have h : env51687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51686_51687 : H12AffineEnvironment.transform 16 90138 env51686 = env51687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env51686 == env51687) = true)

def env51688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,79130,76278,1024,8661,4161,8572,17,2,8328,65,67927,79130,4096,10281,75222,66047,256,73771,79194,513]

theorem envBound51688 : H12AffineFastState.Bounded env51688 := by
  intro p hp
  have h : env51688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51687_51688 : H12AffineEnvironment.transform 13 5376 env51687 = env51688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51687 == env51688) = true)

theorem identity51688 : scanCanonicalize (H12AffineFastState.compose env51688 (packedSelected [1,2,3,4,6,9,14,18,20,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound51688 : packedSelected [1,2,3,4,6,9,14,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env51689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,343,13389,10401,1024,8661,4161,8572,17,2,8328,65,2048,13389,4096,10281,9345,168,256,8572,13325,513]

theorem envBound51689 : H12AffineFastState.Bounded env51689 := by
  intro p hp
  have h : env51689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51688_51689 : H12AffineEnvironment.transform 15 343 env51688 = env51689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env51688 == env51689) = true)

theorem identity51689 : scanCanonicalize (H12AffineFastState.compose env51689 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound51689 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env51690 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5376,8460,343,13389,10361,1024,8461,4161,8572,17,2,8272,65,2048,13389,4096,10281,9305,112,256,8572,13325,513]

theorem envBound51690 : H12AffineFastState.Bounded env51690 := by
  intro p hp
  have h : env51690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51689_51690 : H12AffineEnvironment.transform 6 88 env51689 = env51690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env51689 == env51690) = true)

theorem identity51690 : scanCanonicalize (H12AffineFastState.compose env51690 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51690 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51691 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,5376,0,343,5441,2421,1024,1,4161,112,17,2,348,65,2048,5441,4096,2341,1365,112,256,112,5377,513]

theorem envBound51691 : H12AffineFastState.Bounded env51691 := by
  intro p hp
  have h : env51691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51690_51691 : H12AffineEnvironment.transform 12 268 env51690 = env51691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51690 == env51691) = true)

theorem identity51691 : scanCanonicalize (H12AffineFastState.compose env51691 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound51691 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51692 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,65,268,1345,0,343,1280,2421,1024,1,0,112,17,2,348,65,2048,1280,65,2341,1365,112,256,112,1344,513]

theorem envBound51692 : H12AffineFastState.Bounded env51692 := by
  intro p hp
  have h : env51692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51691_51692 : H12AffineEnvironment.transform 11 65 env51691 = env51692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env51691 == env51692) = true)

theorem identity51692 : scanCanonicalize (H12AffineFastState.compose env51692 (packedSelected [0,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound51692 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env51693 : List Nat := [2,4,8,16,32,64,88,256,512,273,2048,65,268,80,0,343,17,2421,273,1,0,112,17,2,348,65,2048,17,65,2341,68,112,256,112,81,513]

theorem envBound51693 : H12AffineFastState.Bounded env51693 := by
  intro p hp
  have h : env51693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51692_51693 : H12AffineEnvironment.transform 9 273 env51692 = env51693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51692 == env51693) = true)

theorem identity51693 : scanCanonicalize (H12AffineFastState.compose env51693 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound51693 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env51694 : List Nat := [2,4,8,16,32,64,88,256,512,273,292,65,268,80,0,343,17,81,273,1,0,112,17,2,348,65,292,17,65,1,68,112,256,112,81,513]

theorem envBound51694 : H12AffineFastState.Bounded env51694 := by
  intro p hp
  have h : env51694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51693_51694 : H12AffineEnvironment.transform 10 292 env51693 = env51694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env51693 == env51694) = true)

def env51695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,79131,76278,1024,8660,4161,8572,17,3,8328,65,67927,79130,4097,10280,75222,66047,256,73770,79195,513]

theorem envBound51695 : H12AffineFastState.Bounded env51695 := by
  intro p hp
  have h : env51695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51687_51695 : H12AffineEnvironment.transform 13 5377 env51687 = env51695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51687 == env51695) = true)

theorem identity51695 : scanCanonicalize (H12AffineFastState.compose env51695 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51695 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51696 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,79131,76159,1024,8541,4161,8572,17,3,8193,65,67927,79130,4097,10280,75103,65910,256,73770,79195,513]

theorem envBound51696 : H12AffineFastState.Bounded env51696 := by
  intro p hp
  have h : env51696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51695_51696 : H12AffineEnvironment.transform 6 9 env51695 = env51696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51695 == env51696) = true)

theorem identity51696 : scanCanonicalize (H12AffineFastState.compose env51696 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51696 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env51697 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5393,2421,1024,8541,4161,8572,17,3,8193,65,10589,5392,4097,10280,1365,8572,256,32,5457,513]

theorem envBound51697 : H12AffineFastState.Bounded env51697 := by
  intro p hp
  have h : env51697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51696_51697 : H12AffineEnvironment.transform 15 8202 env51696 = env51697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51696 == env51697) = true)

theorem identity51697 : scanCanonicalize (H12AffineFastState.compose env51697 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51697 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51698 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,343,5393,2421,1024,0,4161,33,17,3,348,65,2048,5392,4097,2421,1365,33,256,32,5457,513]

theorem envBound51698 : H12AffineFastState.Bounded env51698 := by
  intro p hp
  have h : env51698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51697_51698 : H12AffineEnvironment.transform 12 349 env51697 = env51698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51697 == env51698) = true)

theorem identity51698 : scanCanonicalize (H12AffineFastState.compose env51698 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound51698 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51699 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5237,1,35,5221,2049,1024,0,4161,33,17,3,40,65,2048,5220,4097,2049,1057,33,116,32,5157,513]

theorem envBound51699 : H12AffineFastState.Bounded env51699 := by
  intro p hp
  have h : env51699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51698_51699 : H12AffineEnvironment.transform 7 116 env51698 = env51699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env51698 == env51699) = true)

theorem identity51699 : scanCanonicalize (H12AffineFastState.compose env51699 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51699 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51700 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,1,35,5173,2049,1024,0,4113,33,17,3,40,17,2048,5172,4097,2049,1057,33,36,32,5157,513]

theorem envBound51700 : H12AffineFastState.Bounded env51700 := by
  intro p hp
  have h : env51700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51699_51700 : H12AffineEnvironment.transform 5 16 env51699 = env51700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51699 == env51700) = true)

def env51701 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,41,1045,1,35,1029,2049,1024,0,33,33,17,3,40,17,2048,1028,49,2049,1057,33,36,32,1045,513]

theorem envBound51701 : H12AffineFastState.Bounded env51701 := by
  intro p hp
  have h : env51701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51700_51701 : H12AffineEnvironment.transform 11 48 env51700 = env51701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env51700 == env51701) = true)

theorem identity51701 : scanCanonicalize (H12AffineFastState.compose env51701 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound51701 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51702 : List Nat := [2,4,8,16,32,16,9,36,512,20,2048,48,41,1,1,35,17,2049,20,0,33,33,17,3,40,17,2048,16,49,2049,53,33,36,32,1,513]

theorem envBound51702 : H12AffineFastState.Bounded env51702 := by
  intro p hp
  have h : env51702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51701_51702 : H12AffineEnvironment.transform 9 20 env51701 = env51702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51701 == env51702) = true)

def env51703 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,16,9,1,1,3,17,2049,20,0,1,1,17,3,8,17,2048,16,17,2049,21,1,4,0,1,513]

theorem envBound51703 : H12AffineFastState.Bounded env51703 := by
  intro p hp
  have h : env51703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51702_51703 : H12AffineEnvironment.transform 4 0 env51702 = env51703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51702 == env51703) = true)

theorem identity51703 : scanCanonicalize (H12AffineFastState.compose env51703 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound51703 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51704 : List Nat := [2,4,8,16,0,16,9,4,512,20,1,16,9,1,1,3,17,0,20,0,1,1,17,3,8,17,1,16,17,0,21,1,4,0,1,513]

theorem envBound51704 : H12AffineFastState.Bounded env51704 := by
  intro p hp
  have h : env51704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51703_51704 : H12AffineEnvironment.transform 10 1 env51703 = env51704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env51703 == env51704) = true)

def leafEnv51704 : List Nat := [2,4,8,16,0,16,9,4,512,20,1,16,9,1,1,3,17,0,20,0,1,1,17,3,21,8,1,17,1,16,17,0,21,1,4,0,4,2,1,513,1,1,0]

def active51704 : List Nat := [0,1,2,3,8]

def tree51704 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51704 : H12WitnessSearch.Good tree51704 := H12GlobalWitnessIndex.good

theorem leafIdentity51704 : H12AffineFastState.composeSystem env51704 rootObs = leafEnv51704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51704 rootObs == leafEnv51704) = true)

theorem terminalChecked51704 : H12PackedTerminal.terminalCheckFast leafEnv51704 active51704 tree51704 = true := by decide +kernel

def env51705 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,17,8,1,1,2,17,2049,20,0,0,0,17,3,9,17,2048,16,16,2049,20,0,5,1,1,513]

theorem envBound51705 : H12AffineFastState.Bounded env51705 := by
  intro p hp
  have h : env51705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51702_51705 : H12AffineEnvironment.transform 4 1 env51702 = env51705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51702 == env51705) = true)

theorem identity51705 : scanCanonicalize (H12AffineFastState.compose env51705 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound51705 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51706 : List Nat := [2,4,8,16,1,16,9,5,512,20,523,17,8,1,1,2,17,522,20,0,0,0,17,3,9,17,523,16,16,522,20,0,5,1,1,513]

theorem envBound51706 : H12AffineFastState.Bounded env51706 := by
  intro p hp
  have h : env51706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51705_51706 : H12AffineEnvironment.transform 10 523 env51705 = env51706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env51705 == env51706) = true)

def leafEnv51706 : List Nat := [2,4,8,16,1,16,9,5,512,20,523,17,8,1,1,2,17,522,20,0,0,0,17,3,20,9,1,17,523,16,16,522,20,0,5,1,4,3,1,513,1,0,0]

def active51706 : List Nat := [0,1,2,3,8]

def tree51706 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51706 : H12WitnessSearch.Good tree51706 := H12GlobalWitnessIndex.good

theorem leafIdentity51706 : H12AffineFastState.composeSystem env51706 rootObs = leafEnv51706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51706 rootObs == leafEnv51706) = true)

theorem terminalChecked51706 : H12PackedTerminal.terminalCheckFast leafEnv51706 active51706 tree51706 = true := by decide +kernel

def env51707 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,41,1044,1,35,1028,2049,1024,0,32,33,17,3,40,17,2048,1029,48,2049,1057,33,36,32,1044,513]

theorem envBound51707 : H12AffineFastState.Bounded env51707 := by
  intro p hp
  have h : env51707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51700_51707 : H12AffineEnvironment.transform 11 49 env51700 = env51707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env51700 == env51707) = true)

theorem identity51707 : scanCanonicalize (H12AffineFastState.compose env51707 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51707 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51708 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,17,9,1044,1,3,1028,2049,1024,0,0,1,17,3,8,17,2048,1029,16,2049,1025,1,4,0,1044,513]

theorem envBound51708 : H12AffineFastState.Bounded env51708 := by
  intro p hp
  have h : env51708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51707_51708 : H12AffineEnvironment.transform 4 0 env51707 = env51708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51707 == env51708) = true)

def env51709 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,17,9,0,1,3,16,2049,20,0,0,1,17,3,8,17,2048,17,16,2049,21,1,4,0,0,513]

theorem envBound51709 : H12AffineFastState.Bounded env51709 := by
  intro p hp
  have h : env51709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51708_51709 : H12AffineEnvironment.transform 9 20 env51708 = env51709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51708 == env51709) = true)

theorem identity51709 : scanCanonicalize (H12AffineFastState.compose env51709 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51709 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51710 : List Nat := [2,4,8,16,0,16,9,4,512,20,0,17,9,0,1,3,16,1,20,0,0,1,17,3,8,17,0,17,16,1,21,1,4,0,0,513]

theorem envBound51710 : H12AffineFastState.Bounded env51710 := by
  intro p hp
  have h : env51710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51709_51710 : H12AffineEnvironment.transform 10 0 env51709 = env51710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51709 == env51710) = true)

def leafEnv51710 : List Nat := [2,4,8,16,0,16,9,4,512,20,0,17,9,0,1,3,16,1,20,0,0,1,17,3,21,8,1,17,0,17,16,1,21,1,4,0,4,2,0,513,1,0,0]

def active51710 : List Nat := [0,1,2,3,8]

def tree51710 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51710 : H12WitnessSearch.Good tree51710 := H12GlobalWitnessIndex.good

theorem leafIdentity51710 : H12AffineFastState.composeSystem env51710 rootObs = leafEnv51710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51710 rootObs == leafEnv51710) = true)

theorem terminalChecked51710 : H12PackedTerminal.terminalCheckFast leafEnv51710 active51710 tree51710 = true := by decide +kernel

def env51711 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,17,9,1,1,3,17,2049,21,0,0,1,17,3,8,17,2048,16,16,2049,20,1,4,0,1,513]

theorem envBound51711 : H12AffineFastState.Bounded env51711 := by
  intro p hp
  have h : env51711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51708_51711 : H12AffineEnvironment.transform 9 21 env51708 = env51711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env51708 == env51711) = true)

theorem identity51711 : scanCanonicalize (H12AffineFastState.compose env51711 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound51711 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51712 : List Nat := [2,4,8,16,0,16,9,4,512,21,523,17,9,1,1,3,17,522,21,0,0,1,17,3,8,17,523,16,16,522,20,1,4,0,1,513]

theorem envBound51712 : H12AffineFastState.Bounded env51712 := by
  intro p hp
  have h : env51712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51711_51712 : H12AffineEnvironment.transform 10 523 env51711 = env51712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env51711 == env51712) = true)

def leafEnv51712 : List Nat := [2,4,8,16,0,16,9,4,512,21,523,17,9,1,1,3,17,522,21,0,0,1,17,3,20,8,1,17,523,16,16,522,20,1,4,0,4,2,1,513,1,0,0]

def active51712 : List Nat := [0,1,2,3,8]

def tree51712 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51712 : H12WitnessSearch.Good tree51712 := H12GlobalWitnessIndex.good

theorem leafIdentity51712 : H12AffineFastState.composeSystem env51712 rootObs = leafEnv51712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51712 rootObs == leafEnv51712) = true)

theorem terminalChecked51712 : H12PackedTerminal.terminalCheckFast leafEnv51712 active51712 tree51712 = true := by decide +kernel

def env51713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,2097152,4194304,8388608,2114882,8328,65,14797999,115151,10507600,8423917,10600787,4268162,256,8487407,8478794,10544772]

theorem envBound51713 : H12AffineFastState.Bounded env51713 := by
  intro p hp
  have h : env51713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51578_51713 : H12AffineEnvironment.transform 17 149997 env51578 = env51713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149997 env51578 == env51713) = true)

def env51714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,4194304,8388608,21762,8328,65,12705007,115151,8406288,8423917,8507667,4268162,256,8487407,8478794,8451780]

theorem envBound51714 : H12AffineFastState.Bounded env51714 := by
  intro p hp
  have h : env51714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51713_51714 : H12AffineEnvironment.transform 20 4160 env51713 = env51714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env51713 == env51714) = true)

def env51715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,4194304,16,21762,8328,65,4316415,115151,17664,35325,119043,4268162,256,98815,90202,63188]

theorem envBound51715 : H12AffineFastState.Bounded env51715 := by
  intro p hp
  have h : env51715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51714_51715 : H12AffineEnvironment.transform 22 16 env51714 = env51715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env51714 == env51715) = true)

def env51716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,4194304,16,21762,8192,65,4316279,115015,17664,35189,119043,4268042,256,98679,90202,63068]

theorem envBound51716 : H12AffineFastState.Bounded env51716 := by
  intro p hp
  have h : env51716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51715_51716 : H12AffineEnvironment.transform 6 8 env51715 = env51716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51715 == env51716) = true)

theorem identity51716 : scanCanonicalize (H12AffineFastState.compose env51716 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound51716 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1024,32769,4160,4194304,16,21762,8192,65,4316279,115015,17664,35189,119043,4268042,256,98679,90202,63068]

theorem envBound51717 : H12AffineFastState.Bounded env51717 := by
  intro p hp
  have h : env51717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51716_51717 : H12AffineEnvironment.transform 16 49168 env51716 = env51717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env51716 == env51717) = true)

theorem identity51717 : scanCanonicalize (H12AffineFastState.compose env51717 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound51717 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env51718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21591,49168,35189,1024,32769,4160,4194304,16,21762,8192,65,4229152,38160,17664,35189,34132,4224093,256,54560,13325,63068]

theorem envBound51718 : H12AffineFastState.Bounded env51718 := by
  intro p hp
  have h : env51718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51717_51718 : H12AffineEnvironment.transform 15 21591 env51717 = env51718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env51717 == env51718) = true)

theorem identity51718 : scanCanonicalize (H12AffineFastState.compose env51718 (packedSelected [0,1,3,5,7,9,10,11,12,14,18,19,20,22,23,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound51718 : packedSelected [0,1,3,5,7,9,10,11,12,14,18,19,20,22,23,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env51719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,21591,13624,31837,1024,29993,4160,4194304,16,21762,8192,65,4226312,24632,17664,31837,28796,4224093,256,8200,13325,884]

theorem envBound51719 : H12AffineFastState.Bounded env51719 := by
  intro p hp
  have h : env51719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51718_51719 : H12AffineEnvironment.transform 14 29992 env51718 = env51719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env51718 == env51719) = true)

theorem identity51719 : scanCanonicalize (H12AffineFastState.compose env51719 (packedSelected [0,2,3,6,7,10,18,19,20,24,32] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound51719 : packedSelected [0,2,3,6,7,10,18,19,20,24,32] rootPS < 2^1333 := by decide +kernel

def env51720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21840,21591,5440,23589,1024,21841,4160,4194304,16,21762,120,65,4218224,16448,17664,23589,20484,4215845,256,112,5237,884]

theorem envBound51720 : H12AffineFastState.Bounded env51720 := by
  intro p hp
  have h : env51720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51719_51720 : H12AffineEnvironment.transform 12 120 env51719 = env51720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env51719 == env51720) = true)

theorem identity51720 : scanCanonicalize (H12AffineFastState.compose env51720 (packedSelected [0,1,2,6,7,8,11,12,15,18,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51720 : packedSelected [0,1,2,6,7,8,11,12,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env51721 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,16384,21620,21591,5220,23589,1024,21621,4160,4194304,16,21542,120,65,4217940,16448,17444,23589,20484,4215845,36,112,5237,592]

theorem envBound51721 : H12AffineFastState.Bounded env51721 := by
  intro p hp
  have h : env51721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51720_51721 : H12AffineEnvironment.transform 7 36 env51720 = env51721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51720 == env51721) = true)

theorem identity51721 : scanCanonicalize (H12AffineFastState.compose env51721 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51721 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51722 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,16384,21541,21510,5173,23589,1024,21540,4113,4194304,16,21542,41,16,4217861,16401,17444,23589,20484,4215845,36,33,5156,513]

theorem envBound51722 : H12AffineFastState.Bounded env51722 := by
  intro p hp
  have h : env51722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51721_51722 : H12AffineEnvironment.transform 5 17 env51721 = env51722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51721 == env51722) = true)

theorem identity51722 : scanCanonicalize (H12AffineFastState.compose env51722 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound51722 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51723 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,4113,1076,1047,5173,3124,1024,1077,4113,4194304,16,1079,41,16,4197396,4096,5173,3124,21,4195380,36,33,5156,513]

theorem envBound51723 : H12AffineFastState.Bounded env51723 := by
  intro p hp
  have h : env51723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51722_51723 : H12AffineEnvironment.transform 13 4113 env51722 = env51723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env51722 == env51723) = true)

theorem identity51723 : scanCanonicalize (H12AffineFastState.compose env51723 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51723 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51724 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,41,4113,1,34,4096,2049,53,0,4113,4194304,16,2,41,16,4196385,4096,4096,2049,21,4194305,36,33,4113,513]

theorem envBound51724 : H12AffineFastState.Bounded env51724 := by
  intro p hp
  have h : env51724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51723_51724 : H12AffineEnvironment.transform 9 53 env51723 = env51724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51723 == env51724) = true)

theorem identity51724 : scanCanonicalize (H12AffineFastState.compose env51724 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 560) := by decide +kernel

theorem selectedBound51724 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51725 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,41,4113,1,34,4096,2049,53,0,4113,560,16,2,41,16,2577,4096,4096,2049,21,561,36,33,4113,513]

theorem envBound51725 : H12AffineFastState.Bounded env51725 := by
  intro p hp
  have h : env51725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51724_51725 : H12AffineEnvironment.transform 21 560 env51724 = env51725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 560 env51724 == env51725) = true)

theorem identity51725 : scanCanonicalize (H12AffineFastState.compose env51725 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound51725 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51726 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,561,41,544,1,34,561,2049,53,0,544,560,16,2,41,16,2577,561,561,2049,21,561,36,33,544,513]

theorem envBound51726 : H12AffineFastState.Bounded env51726 := by
  intro p hp
  have h : env51726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51725_51726 : H12AffineEnvironment.transform 11 561 env51725 = env51726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env51725 == env51726) = true)

theorem identity51726 : scanCanonicalize (H12AffineFastState.compose env51726 (packedSelected [0,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound51726 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env51727 : List Nat := [2,4,8,16,32,17,8,36,32,53,2048,17,41,0,1,34,17,2049,53,0,0,16,16,2,41,16,2097,17,17,2049,21,17,36,33,0,33]

theorem envBound51727 : H12AffineFastState.Bounded env51727 := by
  intro p hp
  have h : env51727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51726_51727 : H12AffineEnvironment.transform 8 32 env51726 = env51727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env51726 == env51727) = true)

def env51728 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,4194304,16,21762,8193,65,4316278,115014,17664,35188,119043,4268043,256,98678,90202,63069]

theorem envBound51728 : H12AffineFastState.Bounded env51728 := by
  intro p hp
  have h : env51728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51715_51728 : H12AffineEnvironment.transform 6 9 env51715 = env51728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51715 == env51728) = true)

theorem identity51728 : scanCanonicalize (H12AffineFastState.compose env51728 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound51728 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51729 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10280,1024,32769,4160,4194304,16,21762,8193,65,4316278,115014,17664,35188,119043,4268043,256,98678,90202,63069]

theorem envBound51729 : H12AffineFastState.Bounded env51729 := by
  intro p hp
  have h : env51729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51728_51729 : H12AffineEnvironment.transform 16 24908 env51728 = env51729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env51728 == env51729) = true)

theorem identity51729 : scanCanonicalize (H12AffineFastState.compose env51729 (packedSelected [0,1,3,7,8,9,11,12,14,15,16,18,22,23,24,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound51729 : packedSelected [0,1,3,7,8,9,11,12,14,15,16,18,22,23,24,31,32] rootPS < 2^1333 := by decide +kernel

def env51730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24908,10280,1024,8541,4160,4194304,16,21762,8193,65,4291882,90138,17664,10280,94303,4268043,256,73770,90202,22273]

theorem envBound51730 : H12AffineFastState.Bounded env51730 := by
  intro p hp
  have h : env51730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51729_51730 : H12AffineEnvironment.transform 14 8540 env51729 = env51730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env51729 == env51730) = true)

theorem identity51730 : scanCanonicalize (H12AffineFastState.compose env51730 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51730 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env51731 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,24908,10280,1024,8541,4160,4194304,16,21762,8193,65,4218144,16400,17664,10280,20565,4194305,256,32,16464,22273]

theorem envBound51731 : H12AffineFastState.Bounded env51731 := by
  intro p hp
  have h : env51731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51730_51731 : H12AffineEnvironment.transform 15 8202 env51730 = env51731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51730 == env51731) = true)

theorem identity51731 : scanCanonicalize (H12AffineFastState.compose env51731 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound51731 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env51732 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,24908,10280,1024,8541,4160,113,16,21762,8193,65,23889,16400,17664,10280,20565,112,256,32,16464,22273]

theorem envBound51732 : H12AffineFastState.Bounded env51732 := by
  intro p hp
  have h : env51732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51731_51732 : H12AffineEnvironment.transform 21 113 env51731 = env51732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env51731 == env51732) = true)

theorem identity51732 : scanCanonicalize (H12AffineFastState.compose env51732 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51732 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env51733 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,342,16400,2420,1024,1,4160,113,16,21762,349,65,23889,16400,17664,2420,20565,112,256,32,16464,22273]

theorem envBound51733 : H12AffineFastState.Bounded env51733 := by
  intro p hp
  have h : env51733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51732_51733 : H12AffineEnvironment.transform 12 348 env51732 = env51733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51732 == env51733) = true)

theorem identity51733 : scanCanonicalize (H12AffineFastState.compose env51733 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound51733 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env51734 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,342,5392,2420,1024,1,4160,113,16,2,349,65,2129,5392,4096,2420,1365,112,256,32,5456,513]

theorem envBound51734 : H12AffineFastState.Bounded env51734 := by
  intro p hp
  have h : env51734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51733_51734 : H12AffineEnvironment.transform 13 5376 env51733 = env51734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51733 == env51734) = true)

def env51735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,4194304,17,21762,8328,65,4316414,115151,17665,35324,119042,4268162,256,98814,90203,63189]

theorem envBound51735 : H12AffineFastState.Bounded env51735 := by
  intro p hp
  have h : env51735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51714_51735 : H12AffineEnvironment.transform 22 17 env51714 = env51735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env51714 == env51735) = true)

theorem identity51735 : scanCanonicalize (H12AffineFastState.compose env51735 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169401) := by decide +kernel

theorem selectedBound51735 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4160,169401,17,21762,8328,65,215367,115151,17665,35324,119042,243003,256,98814,90203,63189]

theorem envBound51736 : H12AffineFastState.Bounded env51736 := by
  intro p hp
  have h : env51736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51735_51736 : H12AffineEnvironment.transform 21 169401 env51735 = env51736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env51735 == env51736) = true)

def env51737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169265,17,21762,8192,65,215367,115015,17665,35188,119042,243003,256,98678,90203,63069]

theorem envBound51737 : H12AffineFastState.Bounded env51737 := by
  intro p hp
  have h : env51737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51736_51737 : H12AffineEnvironment.transform 6 8 env51736 = env51737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51736 == env51737) = true)

theorem identity51737 : scanCanonicalize (H12AffineFastState.compose env51737 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound51737 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,149861,1024,8541,4160,144493,17,21762,8192,65,215367,90139,17665,10280,94302,201831,256,73770,90203,22273]

theorem envBound51738 : H12AffineFastState.Bounded env51738 := by
  intro p hp
  have h : env51738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51737_51738 : H12AffineEnvironment.transform 14 8540 env51737 = env51738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env51737 == env51738) = true)

theorem identity51738 : scanCanonicalize (H12AffineFastState.compose env51738 (packedSelected [0,7,8,9,12,14,15,18,19,20,22,23,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 78958) := by decide +kernel

theorem selectedBound51738 : packedSelected [0,7,8,9,12,14,15,18,19,20,22,23,26,28,31] rootPS < 2^1333 := by decide +kernel

def env51739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,78958,97547,1024,8541,4160,65539,17,21762,8192,65,32041,90139,17665,10280,94302,8201,256,73770,90203,22273]

theorem envBound51739 : H12AffineFastState.Bounded env51739 := by
  intro p hp
  have h : env51739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51738_51739 : H12AffineEnvironment.transform 16 78958 env51738 = env51739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78958 env51738 == env51739) = true)

theorem identity51739 : scanCanonicalize (H12AffineFastState.compose env51739 (packedSelected [0,1,2,3,4,6,8,9,10,11,12,15,20,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound51739 : packedSelected [0,1,2,3,4,6,8,9,10,11,12,15,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env51740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8540,65536,78958,67619,1024,8541,4160,65539,17,8234,8192,65,2049,70963,12329,10280,66934,8201,256,73770,71027,8745]

theorem envBound51740 : H12AffineFastState.Bounded env51740 := by
  intro p hp
  have h : env51740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51739_51740 : H12AffineEnvironment.transform 13 13608 env51739 = env51740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env51739 == env51740) = true)

theorem identity51740 : scanCanonicalize (H12AffineFastState.compose env51740 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51740 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env51741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8540,8202,5220,10281,1024,8541,4160,8201,17,8234,8192,65,2049,13625,12329,10280,9596,8201,256,32,13689,8745]

theorem envBound51741 : H12AffineFastState.Bounded env51741 := by
  intro p hp
  have h : env51741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51740_51741 : H12AffineEnvironment.transform 15 8202 env51740 = env51741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51740 == env51741) = true)

theorem identity51741 : scanCanonicalize (H12AffineFastState.compose env51741 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound51741 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env51742 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,8192,12572,8540,8202,4176,10281,52,8541,4160,8201,17,8234,8192,65,2049,12557,12329,10280,8520,8201,256,32,12621,8745]

theorem envBound51742 : H12AffineFastState.Bounded env51742 := by
  intro p hp
  have h : env51742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51741_51742 : H12AffineEnvironment.transform 9 52 env51741 = env51742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51741 == env51742) = true)

theorem identity51742 : scanCanonicalize (H12AffineFastState.compose env51742 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound51742 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env51743 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,40,4404,372,34,4176,2049,52,373,4160,33,17,2,40,65,2049,4389,4097,2048,352,33,256,32,4453,513]

theorem envBound51743 : H12AffineFastState.Bounded env51743 := by
  intro p hp
  have h : env51743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51742_51743 : H12AffineEnvironment.transform 12 40 env51742 = env51743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env51742 == env51743) = true)

theorem identity51743 : scanCanonicalize (H12AffineFastState.compose env51743 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound51743 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51744 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,40,4161,1,34,4176,2049,52,0,4160,33,17,2,40,65,2049,4176,4097,2048,21,33,117,32,4112,513]

theorem envBound51744 : H12AffineFastState.Bounded env51744 := by
  intro p hp
  have h : env51744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51743_51744 : H12AffineEnvironment.transform 7 117 env51743 = env51744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env51743 == env51744) = true)

theorem identity51744 : scanCanonicalize (H12AffineFastState.compose env51744 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound51744 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51745 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,80,40,17,1,34,0,2049,52,0,16,33,17,2,40,65,2049,0,81,2048,21,33,117,32,64,513]

theorem envBound51745 : H12AffineFastState.Bounded env51745 := by
  intro p hp
  have h : env51745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51744_51745 : H12AffineEnvironment.transform 11 80 env51744 = env51745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env51744 == env51745) = true)

theorem identity51745 : scanCanonicalize (H12AffineFastState.compose env51745 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound51745 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51746 : List Nat := [2,4,8,16,32,64,8,117,512,52,90,80,40,17,1,34,0,91,52,0,16,33,17,2,40,65,91,0,81,90,21,33,117,32,64,513]

theorem envBound51746 : H12AffineFastState.Bounded env51746 := by
  intro p hp
  have h : env51746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51745_51746 : H12AffineEnvironment.transform 10 90 env51745 = env51746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env51745 == env51746) = true)

def env51747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169264,17,21762,8193,65,215367,115014,17665,35189,119042,243003,256,98679,90203,63068]

theorem envBound51747 : H12AffineFastState.Bounded env51747 := by
  intro p hp
  have h : env51747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51736_51747 : H12AffineEnvironment.transform 6 9 env51736 = env51747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51736 == env51747) = true)

theorem identity51747 : scanCanonicalize (H12AffineFastState.compose env51747 (packedSelected [0,7,8,9,14,15,20,22,28,31,41] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound51747 : packedSelected [0,7,8,9,14,15,20,22,28,31,41] rootPS < 2^1333 := by decide +kernel

def env51748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,131072,149860,1024,1,4160,136496,17,21762,8193,65,215367,82246,17665,2421,86274,210235,256,65911,90203,30300]

theorem envBound51748 : H12AffineFastState.Bounded env51748 := by
  intro p hp
  have h : env51748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51747_51748 : H12AffineEnvironment.transform 14 0 env51747 = env51748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env51747 == env51748) = true)

theorem identity51748 : scanCanonicalize (H12AffineFastState.compose env51748 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound51748 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env51749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,24908,10280,1024,1,4160,29820,17,21762,8193,65,75787,82246,17665,2421,86274,87159,256,65911,90203,30300]

theorem envBound51749 : H12AffineFastState.Bounded env51749 := by
  intro p hp
  have h : env51749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51748_51749 : H12AffineEnvironment.transform 16 24908 env51748 = env51749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env51748 == env51749) = true)

theorem identity51749 : scanCanonicalize (H12AffineFastState.compose env51749 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound51749 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env51750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,65536,5393,10280,1024,1,4160,33,17,8543,8193,65,75787,79131,12636,2421,75103,73770,256,65911,70662,513]

theorem envBound51750 : H12AffineFastState.Bounded env51750 := by
  intro p hp
  have h : env51750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51749_51750 : H12AffineEnvironment.transform 13 13405 env51749 = env51750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env51749 == env51750) = true)

theorem identity51750 : scanCanonicalize (H12AffineFastState.compose env51750 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51750 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,8203,5393,10280,1024,1,4160,33,17,8543,8193,65,2048,5392,12636,2421,1364,33,256,8572,13325,513]

theorem envBound51751 : H12AffineFastState.Bounded env51751 := by
  intro p hp
  have h : env51751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51750_51751 : H12AffineEnvironment.transform 15 8203 env51750 = env51751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51750 == env51751) = true)

theorem identity51751 : scanCanonicalize (H12AffineFastState.compose env51751 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51751 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,0,262,5393,2341,1024,1,4160,33,17,82,268,65,2048,5392,4177,2421,1364,33,256,113,5376,513]

theorem envBound51752 : H12AffineFastState.Bounded env51752 := by
  intro p hp
  have h : env51752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51751_51752 : H12AffineEnvironment.transform 12 269 env51751 = env51752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51751 == env51752) = true)

theorem identity51752 : scanCanonicalize (H12AffineFastState.compose env51752 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound51752 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env51753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1572,4096,269,5456,0,262,5393,1793,1024,1,4160,33,17,82,268,65,1572,5392,4177,1873,1364,33,256,113,5376,513]

theorem envBound51753 : H12AffineFastState.Bounded env51753 := by
  intro p hp
  have h : env51753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51752_51753 : H12AffineEnvironment.transform 10 1572 env51752 = env51753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env51752 == env51753) = true)

theorem identity51753 : scanCanonicalize (H12AffineFastState.compose env51753 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51753 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env51754 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1572,4096,269,5376,0,262,5393,1793,1024,1,4112,33,17,2,268,17,1572,5392,4097,1793,1284,33,256,33,5376,513]

theorem envBound51754 : H12AffineFastState.Bounded env51754 := by
  intro p hp
  have h : env51754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51753_51754 : H12AffineEnvironment.transform 5 16 env51753 = env51754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51753 == env51754) = true)

theorem identity51754 : scanCanonicalize (H12AffineFastState.compose env51754 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound51754 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51755 : List Nat := [2,4,8,16,17,16,9,256,512,1024,1557,4096,269,5376,0,262,5393,1793,1024,1,4112,16,17,2,268,17,1557,5392,4097,1793,1284,16,256,16,5376,513]

theorem envBound51755 : H12AffineFastState.Bounded env51755 := by
  intro p hp
  have h : env51755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51754_51755 : H12AffineEnvironment.transform 4 17 env51754 = env51755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env51754 == env51755) = true)

theorem identity51755 : scanCanonicalize (H12AffineFastState.compose env51755 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound51755 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51756 : List Nat := [2,4,8,16,17,16,9,256,512,516,17,4096,269,4868,0,262,4885,261,516,1,4112,16,17,2,268,17,17,4884,4097,261,768,16,256,16,4868,513]

theorem envBound51756 : H12AffineFastState.Bounded env51756 := by
  intro p hp
  have h : env51756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51755_51756 : H12AffineEnvironment.transform 9 516 env51755 = env51756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env51755 == env51756) = true)

theorem identity51756 : scanCanonicalize (H12AffineFastState.compose env51756 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound51756 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51757 : List Nat := [2,4,8,16,17,16,9,256,276,272,17,4096,269,4112,0,262,4097,261,272,1,4112,16,17,2,268,17,17,4096,4097,261,20,16,256,16,4112,277]

theorem envBound51757 : H12AffineFastState.Bounded env51757 := by
  intro p hp
  have h : env51757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51756_51757 : H12AffineEnvironment.transform 8 276 env51756 = env51757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env51756 == env51757) = true)

theorem identity51757 : scanCanonicalize (H12AffineFastState.compose env51757 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound51757 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51758 : List Nat := [2,4,8,16,17,16,9,256,276,272,17,277,269,261,0,262,276,261,272,1,261,16,17,2,268,17,17,277,276,261,20,16,256,16,261,277]

theorem envBound51758 : H12AffineFastState.Bounded env51758 := by
  intro p hp
  have h : env51758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51757_51758 : H12AffineEnvironment.transform 11 277 env51757 = env51758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env51757 == env51758) = true)

theorem identity51758 : scanCanonicalize (H12AffineFastState.compose env51758 (packedSelected [0,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51758 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env51759 : List Nat := [2,4,8,16,17,16,9,5,17,21,17,16,8,0,0,3,17,0,21,1,0,16,17,2,9,17,17,16,17,0,20,16,5,16,0,16]

theorem envBound51759 : H12AffineFastState.Bounded env51759 := by
  intro p hp
  have h : env51759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51758_51759 : H12AffineEnvironment.transform 7 5 env51758 = env51759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51758 == env51759) = true)

def env51760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,4194304,8388608,21763,8328,65,12705006,115151,8406289,8423917,8507666,4268162,256,8487407,8478794,8451781]

theorem envBound51760 : H12AffineFastState.Bounded env51760 := by
  intro p hp
  have h : env51760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51713_51760 : H12AffineEnvironment.transform 20 4161 env51713 = env51760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env51713 == env51760) = true)

def env51761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,4194304,16,21763,8328,65,4316414,115151,17665,35325,119042,4268162,256,98815,90202,63189]

theorem envBound51761 : H12AffineFastState.Bounded env51761 := by
  intro p hp
  have h : env51761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51760_51761 : H12AffineEnvironment.transform 22 16 env51760 = env51761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env51760 == env51761) = true)

theorem identity51761 : scanCanonicalize (H12AffineFastState.compose env51761 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound51761 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149997,1024,29909,4161,4194304,16,21763,8328,65,4270122,79131,17665,32041,75222,4268162,256,95531,90202,513]

theorem envBound51762 : H12AffineFastState.Bounded env51762 := by
  intro p hp
  have h : env51762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51761_51762 : H12AffineEnvironment.transform 14 29908 env51761 = env51762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env51761 == env51762) = true)

def env51763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,138477,1024,8661,4161,4194304,16,3,8328,65,4270122,79131,4097,10281,75222,4268162,256,73771,79194,513]

theorem envBound51763 : H12AffineFastState.Bounded env51763 := by
  intro p hp
  have h : env51763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51762_51763 : H12AffineEnvironment.transform 13 5376 env51762 = env51763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51762 == env51763) = true)

theorem identity51763 : scanCanonicalize (H12AffineFastState.compose env51763 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound51763 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13388,10401,1024,8661,4161,4194304,16,3,8328,65,4270122,79131,4097,10281,75222,4268162,256,73771,79194,513]

theorem envBound51764 : H12AffineFastState.Bounded env51764 := by
  intro p hp
  have h : env51764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51763_51764 : H12AffineEnvironment.transform 16 13388 env51763 = env51764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env51763 == env51764) = true)

theorem identity51764 : scanCanonicalize (H12AffineFastState.compose env51764 (packedSelected [0,1,2,6,8,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 8693) := by decide +kernel

theorem selectedBound51764 : packedSelected [0,1,2,6,8,14,19,27] rootPS < 2^1333 := by decide +kernel

def env51765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13388,10401,1024,8661,4161,8693,16,3,8328,65,68063,79131,4097,10281,75222,65911,256,73771,79194,513]

theorem envBound51765 : H12AffineFastState.Bounded env51765 := by
  intro p hp
  have h : env51765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51764_51765 : H12AffineEnvironment.transform 21 8693 env51764 = env51765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8693 env51764 == env51765) = true)

theorem identity51765 : scanCanonicalize (H12AffineFastState.compose env51765 (packedSelected [0,2,3,4,5,6,7,9,11,15,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51765 : packedSelected [0,2,3,4,5,6,7,9,11,15,19,20] rootPS < 2^1333 := by decide +kernel

def env51766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,13388,10401,1024,8661,4161,8693,16,3,8328,65,10708,5392,4097,10281,1501,8572,256,32,5457,513]

theorem envBound51766 : H12AffineFastState.Bounded env51766 := by
  intro p hp
  have h : env51766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51765_51766 : H12AffineEnvironment.transform 15 8203 env51765 = env51766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51765 == env51766) = true)

theorem identity51766 : scanCanonicalize (H12AffineFastState.compose env51766 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51766 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,136,343,5392,2557,1024,137,4161,169,16,3,468,65,2184,5392,4097,2421,1501,32,256,32,5457,513]

theorem envBound51767 : H12AffineFastState.Bounded env51767 := by
  intro p hp
  have h : env51767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51766_51767 : H12AffineEnvironment.transform 12 348 env51766 = env51767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51766 == env51767) = true)

theorem identity51767 : scanCanonicalize (H12AffineFastState.compose env51767 (packedSelected [0,4,5,7,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2138) := by decide +kernel

theorem selectedBound51767 : packedSelected [0,4,5,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env51768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2138,348,3418,136,343,3402,2557,1024,137,2075,169,16,3,468,65,2184,3402,2139,2421,1501,32,256,32,3339,513]

theorem envBound51768 : H12AffineFastState.Bounded env51768 := by
  intro p hp
  have h : env51768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51767_51768 : H12AffineEnvironment.transform 11 2138 env51767 = env51768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2138 env51767 == env51768) = true)

theorem identity51768 : scanCanonicalize (H12AffineFastState.compose env51768 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51768 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env51769 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2138,348,3418,1,343,3402,2420,1024,0,2075,32,16,3,349,65,2049,3402,2139,2421,1364,32,256,32,3339,513]

theorem envBound51769 : H12AffineFastState.Bounded env51769 := by
  intro p hp
  have h : env51769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51768_51769 : H12AffineEnvironment.transform 6 9 env51768 = env51769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51768 == env51769) = true)

theorem identity51769 : scanCanonicalize (H12AffineFastState.compose env51769 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound51769 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51770 : List Nat := [2,4,8,16,32,64,9,256,512,1024,91,1,348,1281,1,343,1297,303,1024,0,64,32,16,3,349,65,90,1297,0,302,1364,32,256,32,1360,513]

theorem envBound51770 : H12AffineFastState.Bounded env51770 := by
  intro p hp
  have h : env51770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51769_51770 : H12AffineEnvironment.transform 10 91 env51769 = env51770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env51769 == env51770) = true)

theorem identity51770 : scanCanonicalize (H12AffineFastState.compose env51770 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound51770 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env51771 : List Nat := [2,4,8,16,32,64,9,116,512,1024,91,1,40,1141,1,35,1125,91,1024,0,64,32,16,3,41,65,90,1125,0,90,1056,32,116,32,1060,513]

theorem envBound51771 : H12AffineFastState.Bounded env51771 := by
  intro p hp
  have h : env51771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51770_51771 : H12AffineEnvironment.transform 7 116 env51770 = env51771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env51770 == env51771) = true)

theorem identity51771 : scanCanonicalize (H12AffineFastState.compose env51771 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound51771 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env51772 : List Nat := [2,4,8,16,32,64,9,116,512,63,91,1,40,74,1,35,90,91,63,0,64,32,16,3,41,65,90,90,0,90,31,32,116,32,27,513]

theorem envBound51772 : H12AffineFastState.Bounded env51772 := by
  intro p hp
  have h : env51772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51771_51772 : H12AffineEnvironment.transform 9 63 env51771 = env51772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env51771 == env51772) = true)

theorem identity51772 : scanCanonicalize (H12AffineFastState.compose env51772 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51772 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env51773 : List Nat := [2,4,8,16,0,64,9,84,512,31,91,1,8,74,1,3,90,91,31,0,64,0,16,3,9,65,90,90,0,90,31,0,84,0,27,513]

theorem envBound51773 : H12AffineFastState.Bounded env51773 := by
  intro p hp
  have h : env51773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51772_51773 : H12AffineEnvironment.transform 4 0 env51772 = env51773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51772 == env51773) = true)

def env51774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,138476,1024,8660,4161,4194304,16,2,8328,65,4270122,79131,4096,10280,75222,4268162,256,73770,79195,513]

theorem envBound51774 : H12AffineFastState.Bounded env51774 := by
  intro p hp
  have h : env51774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51762_51774 : H12AffineEnvironment.transform 13 5377 env51762 = env51774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51762 == env51774) = true)

theorem identity51774 : scanCanonicalize (H12AffineFastState.compose env51774 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound51774 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13508,10280,1024,8660,4161,4194304,16,2,8328,65,4270122,79131,4096,10280,75222,4268162,256,73770,79195,513]

theorem envBound51775 : H12AffineFastState.Bounded env51775 := by
  intro p hp
  have h : env51775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51774_51775 : H12AffineEnvironment.transform 16 13508 env51774 = env51775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env51774 == env51775) = true)

theorem identity51775 : scanCanonicalize (H12AffineFastState.compose env51775 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51775 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env51776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,13508,10280,1024,8660,4161,4194304,16,2,8328,65,4196384,5393,4096,10280,1500,4194440,256,32,5457,513]

theorem envBound51776 : H12AffineFastState.Bounded env51776 := by
  intro p hp
  have h : env51776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51775_51776 : H12AffineEnvironment.transform 15 8202 env51775 = env51776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51775 == env51776) = true)

theorem identity51776 : scanCanonicalize (H12AffineFastState.compose env51776 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound51776 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,13508,10280,1024,8660,4161,113,16,2,8328,65,2129,5393,4096,10280,1500,249,256,32,5457,513]

theorem envBound51777 : H12AffineFastState.Bounded env51777 := by
  intro p hp
  have h : env51777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51776_51777 : H12AffineEnvironment.transform 21 113 env51776 = env51777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env51776 == env51777) = true)

theorem identity51777 : scanCanonicalize (H12AffineFastState.compose env51777 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51777 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env51778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,13389,10280,1024,8541,4161,113,16,2,8193,65,2129,5393,4096,10280,1365,112,256,32,5457,513]

theorem envBound51778 : H12AffineFastState.Bounded env51778 := by
  intro p hp
  have h : env51778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51777_51778 : H12AffineEnvironment.transform 6 9 env51777 = env51778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51777 == env51778) = true)

theorem identity51778 : scanCanonicalize (H12AffineFastState.compose env51778 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51778 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env51779 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,343,5392,2421,1024,0,4161,113,16,2,348,65,2129,5393,4096,2421,1365,112,256,32,5457,513]

theorem envBound51779 : H12AffineFastState.Bounded env51779 := by
  intro p hp
  have h : env51779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51778_51779 : H12AffineEnvironment.transform 12 349 env51778 = env51779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51778 == env51779) = true)

def env51780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,4194304,17,21763,8328,65,4316415,115151,17664,35324,119043,4268162,256,98814,90203,63188]

theorem envBound51780 : H12AffineFastState.Bounded env51780 := by
  intro p hp
  have h : env51780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51760_51780 : H12AffineEnvironment.transform 22 17 env51760 = env51780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env51760 == env51780) = true)

theorem identity51780 : scanCanonicalize (H12AffineFastState.compose env51780 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156013) := by decide +kernel

theorem selectedBound51780 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,156013,17,21763,8328,65,245138,115151,17664,35324,119043,213487,256,98814,90203,63188]

theorem envBound51781 : H12AffineFastState.Bounded env51781 := by
  intro p hp
  have h : env51781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51780_51781 : H12AffineEnvironment.transform 21 156013 env51780 = env51781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156013 env51780 == env51781) = true)

def env51782 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,156013,17,21763,8192,65,245018,115015,17664,35188,119043,213351,256,98678,90203,63068]

theorem envBound51782 : H12AffineFastState.Bounded env51782 := by
  intro p hp
  have h : env51782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51781_51782 : H12AffineEnvironment.transform 6 8 env51781 = env51782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51781 == env51782) = true)

theorem identity51782 : scanCanonicalize (H12AffineFastState.compose env51782 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound51782 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51783 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,149861,1024,8541,4161,156013,17,21763,8192,65,203846,90139,17664,10280,94303,213351,256,73770,90203,22272]

theorem envBound51783 : H12AffineFastState.Bounded env51783 := by
  intro p hp
  have h : env51783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51782_51783 : H12AffineEnvironment.transform 14 8540 env51782 = env51783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env51782 == env51783) = true)

theorem identity51783 : scanCanonicalize (H12AffineFastState.compose env51783 (packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound51783 : packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env51784 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,76159,1024,8541,4161,65911,17,21763,8192,65,31836,90139,17664,10280,94303,8573,256,73770,90203,22272]

theorem envBound51784 : H12AffineFastState.Bounded env51784 := by
  intro p hp
  have h : env51784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51783_51784 : H12AffineEnvironment.transform 16 90138 env51783 = env51784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env51783 == env51784) = true)

theorem identity51784 : scanCanonicalize (H12AffineFastState.compose env51784 (packedSelected [1,3,7,8,10,12,14,15,16,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound51784 : packedSelected [1,3,7,8,10,12,14,15,16,24,27] rootPS < 2^1333 := by decide +kernel

def env51785 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,115,24681,10508,1024,8541,4161,260,17,21763,8192,65,31836,24680,17664,10280,28716,8573,256,8281,24616,22272]

theorem envBound51785 : H12AffineFastState.Bounded env51785 := by
  intro p hp
  have h : env51785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51784_51785 : H12AffineEnvironment.transform 15 115 env51784 = env51785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env51784 == env51785) = true)

theorem identity51785 : scanCanonicalize (H12AffineFastState.compose env51785 (packedSelected [0,1,2,6,7,8,11,12,15,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound51785 : packedSelected [0,1,2,6,7,8,11,12,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env51786 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8540,115,5393,10508,1024,8541,4161,260,17,8315,8192,65,2340,5392,12408,10280,1364,8573,256,8281,5456,8824]

theorem envBound51786 : H12AffineFastState.Bounded env51786 := by
  intro p hp
  have h : env51786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51785_51786 : H12AffineEnvironment.transform 13 13688 env51785 = env51786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env51785 == env51786) = true)

theorem identity51786 : scanCanonicalize (H12AffineFastState.compose env51786 (packedSelected [2,3,5,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51786 : packedSelected [2,3,5,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env51787 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5237,81,115,5393,2049,1024,80,4161,260,17,374,269,65,2340,5392,4469,2341,1364,112,256,340,5456,885]

theorem envBound51787 : H12AffineFastState.Bounded env51787 := by
  intro p hp
  have h : env51787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51786_51787 : H12AffineEnvironment.transform 12 269 env51786 = env51787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51786 == env51787) = true)

def env51788 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,156013,17,21763,8193,65,245019,115014,17664,35189,119043,213350,256,98679,90203,63069]

theorem envBound51788 : H12AffineFastState.Bounded env51788 := by
  intro p hp
  have h : env51788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51781_51788 : H12AffineEnvironment.transform 6 9 env51781 = env51788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51781 == env51788) = true)

theorem identity51788 : scanCanonicalize (H12AffineFastState.compose env51788 (packedSelected [0,1,3,9,10,11,14,16,18,19,20,22,23,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51788 : packedSelected [0,1,3,9,10,11,14,16,18,19,20,22,23,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env51789 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149860,1024,32769,4161,156013,17,21763,8193,65,171280,57677,17664,35189,61704,156013,256,41340,16464,63069]

theorem envBound51789 : H12AffineFastState.Bounded env51789 := by
  intro p hp
  have h : env51789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51788_51789 : H12AffineEnvironment.transform 15 8203 env51788 = env51789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51788 == env51789) = true)

theorem identity51789 : scanCanonicalize (H12AffineFastState.compose env51789 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound51789 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env51790 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,46157,64809,1024,32769,4161,54560,17,21763,8193,65,10589,57677,17664,35189,61704,54560,256,41340,16464,63069]

theorem envBound51790 : H12AffineFastState.Bounded env51790 := by
  intro p hp
  have h : env51790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51789_51790 : H12AffineEnvironment.transform 16 46157 env51789 = env51790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env51789 == env51790) = true)

theorem identity51790 : scanCanonicalize (H12AffineFastState.compose env51790 (packedSelected [0,5,7,9,12,14,15,19,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound51790 : packedSelected [0,5,7,9,12,14,15,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env51791 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,8203,46157,35189,1024,32769,4161,41340,17,8543,8193,65,10589,38161,12636,35189,34132,41340,256,41340,13324,33281]

theorem envBound51791 : H12AffineFastState.Bounded env51791 := by
  intro p hp
  have h : env51791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51790_51791 : H12AffineEnvironment.transform 13 13404 env51790 = env51791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env51790 == env51791) = true)

theorem identity51791 : scanCanonicalize (H12AffineFastState.compose env51791 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound51791 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env51792 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8192,13404,32768,8203,46157,34848,1024,32769,4161,41001,17,8202,8193,65,10248,37956,12297,34848,33793,41001,85,41001,13324,33281]

theorem envBound51792 : H12AffineFastState.Bounded env51792 := by
  intro p hp
  have h : env51792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51791_51792 : H12AffineEnvironment.transform 7 85 env51791 = env51792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env51791 == env51792) = true)

theorem identity51792 : scanCanonicalize (H12AffineFastState.compose env51792 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound51792 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env51793 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8192,13404,80,8203,13341,2160,1024,81,4161,8313,17,8202,8193,65,10248,5140,12297,2160,1105,8313,85,8313,13324,593]

theorem envBound51793 : H12AffineFastState.Bounded env51793 := by
  intro p hp
  have h : env51793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51792_51793 : H12AffineEnvironment.transform 14 80 env51792 = env51793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env51792 == env51793) = true)

theorem identity51793 : scanCanonicalize (H12AffineFastState.compose env51793 (packedSelected [0,1,3,4,5,6,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 5724) := by decide +kernel

theorem selectedBound51793 : packedSelected [0,1,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env51794 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,5724,512,80,5719,577,2160,1024,81,4161,5669,17,5718,5725,65,7764,5140,1621,2160,1105,5669,85,5669,592,593]

theorem envBound51794 : H12AffineFastState.Bounded env51794 := by
  intro p hp
  have h : env51794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51793_51794 : H12AffineEnvironment.transform 12 5724 env51793 = env51794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5724 env51793 == env51794) = true)

theorem identity51794 : scanCanonicalize (H12AffineFastState.compose env51794 (packedSelected [0,2,4,5,6,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 593) := by decide +kernel

theorem selectedBound51794 : packedSelected [0,2,4,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env51795 : List Nat := [2,4,8,16,32,64,9,85,512,1024,593,4096,5724,512,80,5719,577,545,1024,81,4161,5669,17,5718,5725,65,5125,5140,1621,545,1105,5669,85,5669,592,593]

theorem envBound51795 : H12AffineFastState.Bounded env51795 := by
  intro p hp
  have h : env51795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51794_51795 : H12AffineEnvironment.transform 10 593 env51794 = env51795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 593 env51794 == env51795) = true)

theorem identity51795 : scanCanonicalize (H12AffineFastState.compose env51795 (packedSelected [0,3,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 113) := by decide +kernel

theorem selectedBound51795 : packedSelected [0,3,6,7,8] rootPS < 2^1333 := by decide +kernel

def env51796 : List Nat := [2,4,8,16,32,64,9,85,512,1024,593,113,1581,512,80,1574,577,545,1024,81,48,1620,17,1575,1580,65,1140,1125,1621,545,1105,1620,85,1620,592,593]

theorem envBound51796 : H12AffineFastState.Bounded env51796 := by
  intro p hp
  have h : env51796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51795_51796 : H12AffineEnvironment.transform 11 113 env51795 = env51796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 113 env51795 == env51796) = true)

theorem identity51796 : scanCanonicalize (H12AffineFastState.compose env51796 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51796 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51797 : List Nat := [2,4,8,16,32,64,9,85,512,53,593,113,536,512,80,531,577,545,53,81,48,609,17,530,537,65,65,80,608,545,100,609,85,609,592,593]

theorem envBound51797 : H12AffineFastState.Bounded env51797 := by
  intro p hp
  have h : env51797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51796_51797 : H12AffineEnvironment.transform 9 53 env51796 = env51797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51796 == env51797) = true)

theorem identity51797 : scanCanonicalize (H12AffineFastState.compose env51797 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51797 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env51798 : List Nat := [2,4,8,0,32,64,9,69,512,37,577,97,520,512,64,515,577,545,37,65,32,609,1,514,521,65,65,64,608,545,100,609,69,609,576,577]

theorem envBound51798 : H12AffineFastState.Bounded env51798 := by
  intro p hp
  have h : env51798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51797_51798 : H12AffineEnvironment.transform 3 0 env51797 = env51798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51797 == env51798) = true)

theorem identity51798 : scanCanonicalize (H12AffineFastState.compose env51798 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound51798 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51799 : List Nat := [2,4,8,0,32,64,9,69,64,37,1,97,72,64,64,67,1,97,37,65,32,33,1,66,73,65,65,64,32,97,100,33,69,33,0,1]

theorem envBound51799 : H12AffineFastState.Bounded env51799 := by
  intro p hp
  have h : env51799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51798_51799 : H12AffineEnvironment.transform 8 64 env51798 = env51799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env51798 == env51799) = true)

theorem identity51799 : scanCanonicalize (H12AffineFastState.compose env51799 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound51799 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env51800 : List Nat := [2,4,8,0,32,33,9,36,33,37,1,0,41,33,33,34,1,0,37,32,32,33,1,35,40,32,32,33,32,0,5,33,36,33,0,1]

theorem envBound51800 : H12AffineFastState.Bounded env51800 := by
  intro p hp
  have h : env51800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51799_51800 : H12AffineEnvironment.transform 5 33 env51799 = env51800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env51799 == env51800) = true)

theorem identity51800 : scanCanonicalize (H12AffineFastState.compose env51800 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51800 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51801 : List Nat := [2,4,8,0,0,1,9,4,1,5,1,0,9,1,1,2,1,0,5,0,0,1,1,3,8,0,0,1,0,0,5,1,4,1,0,1]

theorem envBound51801 : H12AffineFastState.Bounded env51801 := by
  intro p hp
  have h : env51801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51800_51801 : H12AffineEnvironment.transform 4 0 env51800 = env51801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51800 == env51801) = true)

theorem identity51801 : scanCanonicalize (H12AffineFastState.compose env51801 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound51801 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51802 : List Nat := [2,1,8,0,0,1,9,1,1,0,1,0,9,1,1,2,1,0,0,0,0,1,1,3,8,0,0,1,0,0,0,1,1,1,0,1]

theorem envBound51802 : H12AffineFastState.Bounded env51802 := by
  intro p hp
  have h : env51802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51801_51802 : H12AffineEnvironment.transform 1 1 env51801 = env51802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env51801 == env51802) = true)

def env51803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound51803 : H12AffineFastState.Bounded env51803 := by
  intro p hp
  have h : env51803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51576_51803 : H12AffineEnvironment.transform 18 1025 env51576 = env51803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env51576 == env51803) = true)

theorem identity51803 : scanCanonicalize (H12AffineFastState.compose env51803 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2485294) := by decide +kernel

theorem selectedBound51803 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env51804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2485294,16777216,8328,65,23211055,18973836,375166,2305071,19163199,23160256,257,17049730,17090854,19222505]

theorem envBound51804 : H12AffineFastState.Bounded env51804 := by
  intro p hp
  have h : env51804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51803_51804 : H12AffineEnvironment.transform 22 2485294 env51803 = env51804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2485294 env51803 == env51804) = true)

def env51805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155700,2485294,16777216,8328,65,16959643,18973836,375166,2305071,19163199,16875892,257,17049730,17090854,19222505]

theorem envBound51805 : H12AffineFastState.Bounded env51805 := by
  intro p hp
  have h : env51805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51804_51805 : H12AffineEnvironment.transform 21 2155700 env51804 = env51805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155700 env51804 == env51805) = true)

def env51806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155700,2485294,2559344,8328,65,2475499,428540,375166,2305071,222543,2526212,257,2303474,2344022,148121]

theorem envBound51806 : H12AffineFastState.Bounded env51806 := by
  intro p hp
  have h : env51806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51805_51806 : H12AffineEnvironment.transform 23 2559344 env51805 = env51806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559344 env51805 == env51806) = true)

theorem identity51806 : scanCanonicalize (H12AffineFastState.compose env51806 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51806 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env51807 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485294,2559344,8192,65,2475363,428404,375166,2305071,222543,2526212,257,2303354,2344022,147985]

theorem envBound51807 : H12AffineFastState.Bounded env51807 := by
  intro p hp
  have h : env51807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51806_51807 : H12AffineEnvironment.transform 6 8 env51806 = env51807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51806 == env51807) = true)

theorem identity51807 : scanCanonicalize (H12AffineFastState.compose env51807 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound51807 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env51808 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2155580,2212870,2303320,8192,65,2223435,172380,102742,2305071,222543,2270252,257,2303354,2344022,147985]

theorem envBound51808 : H12AffineFastState.Bounded env51808 := by
  intro p hp
  have h : env51808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51807_51808 : H12AffineEnvironment.transform 17 10280 env51807 = env51808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51807 == env51808) = true)

def env51809 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,62588,119878,210200,8192,65,130315,172380,102742,212079,222543,177260,257,210234,250902,147985]

theorem envBound51809 : H12AffineFastState.Bounded env51809 := by
  intro p hp
  have h : env51809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51808_51809 : H12AffineEnvironment.transform 20 4160 env51808 = env51809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env51808 == env51809) = true)

theorem identity51809 : scanCanonicalize (H12AffineFastState.compose env51809 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound51809 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51810 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,4160,62588,119878,95496,8192,65,130315,57676,102742,97407,75103,62588,257,95530,103430,513]

theorem envBound51810 : H12AffineFastState.Bounded env51810 := by
  intro p hp
  have h : env51810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51809_51810 : H12AffineEnvironment.transform 16 16400 env51809 = env51810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env51809 == env51810) = true)

theorem identity51810 : scanCanonicalize (H12AffineFastState.compose env51810 (packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound51810 : packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env51811 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,16400,10280,1025,32769,4160,62588,41292,2,8192,65,34817,57676,58460,2421,20565,62588,257,32,57612,513]

theorem envBound51811 : H12AffineFastState.Bounded env51811 := by
  intro p hp
  have h : env51811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51810_51811 : H12AffineEnvironment.transform 15 29962 env51810 = env51811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env51810 == env51811) = true)

theorem identity51811 : scanCanonicalize (H12AffineFastState.compose env51811 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound51811 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env51812 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,29962,16400,10280,1025,29709,4160,112,21824,2,8192,65,31757,5440,4176,2421,20565,112,257,32,5376,513]

theorem envBound51812 : H12AffineFastState.Bounded env51812 := by
  intro p hp
  have h : env51812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51811_51812 : H12AffineEnvironment.transform 14 29708 env51811 = env51812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env51811 == env51812) = true)

theorem identity51812 : scanCanonicalize (H12AffineFastState.compose env51812 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound51812 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51813 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8460,8202,5392,10280,1025,8461,4160,112,64,2,8192,65,10509,5440,4176,2421,1365,112,257,32,5376,513]

theorem envBound51813 : H12AffineFastState.Bounded env51813 := by
  intro p hp
  have h : env51813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51812_51813 : H12AffineEnvironment.transform 13 5376 env51812 = env51813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51812 == env51813) = true)

theorem identity51813 : scanCanonicalize (H12AffineFastState.compose env51813 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51813 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51814 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,8202,5392,10280,1025,8461,4113,33,17,2,8192,16,10509,5393,4097,2340,1284,33,257,32,5376,513]

theorem envBound51814 : H12AffineFastState.Bounded env51814 := by
  intro p hp
  have h : env51814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51813_51814 : H12AffineEnvironment.transform 5 17 env51813 = env51814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51813 == env51814) = true)

theorem identity51814 : scanCanonicalize (H12AffineFastState.compose env51814 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound51814 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51815 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1289,5376,1029,1283,5392,3361,1025,1028,4113,33,17,2,1289,16,3076,5393,4097,2340,1284,33,257,32,5376,513]

theorem envBound51815 : H12AffineFastState.Bounded env51815 := by
  intro p hp
  have h : env51815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51814_51815 : H12AffineEnvironment.transform 12 1289 env51814 = env51815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env51814 == env51815) = true)

theorem identity51815 : scanCanonicalize (H12AffineFastState.compose env51815 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound51815 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env51816 : List Nat := [2,4,8,16,32,17,8,256,512,1024,561,4096,1289,5376,1029,1283,5392,1808,1025,1028,4113,33,17,2,1289,16,1589,5393,4097,789,1284,33,257,32,5376,513]

theorem envBound51816 : H12AffineFastState.Bounded env51816 := by
  intro p hp
  have h : env51816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51815_51816 : H12AffineEnvironment.transform 10 561 env51815 = env51816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env51815 == env51816) = true)

theorem identity51816 : scanCanonicalize (H12AffineFastState.compose env51816 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound51816 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51817 : List Nat := [2,4,8,16,32,17,8,256,512,36,561,4096,301,4388,33,295,4404,820,37,32,4113,33,17,2,301,16,529,4405,4097,789,288,33,257,32,4388,513]

theorem envBound51817 : H12AffineFastState.Bounded env51817 := by
  intro p hp
  have h : env51817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51816_51817 : H12AffineEnvironment.transform 9 36 env51816 = env51817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env51816 == env51817) = true)

theorem identity51817 : scanCanonicalize (H12AffineFastState.compose env51817 (packedSelected [1,3,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51817 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env51818 : List Nat := [2,4,8,16,1,17,8,256,512,5,528,4096,268,4357,0,262,4373,789,4,1,4113,0,17,2,268,16,529,4372,4097,789,257,0,257,1,4357,513]

theorem envBound51818 : H12AffineFastState.Bounded env51818 := by
  intro p hp
  have h : env51818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51817_51818 : H12AffineEnvironment.transform 4 1 env51817 = env51818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51817 == env51818) = true)

theorem identity51818 : scanCanonicalize (H12AffineFastState.compose env51818 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound51818 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51819 : List Nat := [2,4,8,16,1,17,8,256,512,5,528,513,268,772,0,262,788,789,4,1,528,0,17,2,268,16,529,789,512,789,257,0,257,1,772,513]

theorem envBound51819 : H12AffineFastState.Bounded env51819 := by
  intro p hp
  have h : env51819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51818_51819 : H12AffineEnvironment.transform 11 513 env51818 = env51819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env51818 == env51819) = true)

theorem identity51819 : scanCanonicalize (H12AffineFastState.compose env51819 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound51819 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51820 : List Nat := [2,4,8,16,1,17,8,256,276,5,260,277,268,16,0,262,0,1,4,1,260,0,17,2,268,16,261,1,276,1,257,0,257,1,16,277]

theorem envBound51820 : H12AffineFastState.Bounded env51820 := by
  intro p hp
  have h : env51820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51819_51820 : H12AffineEnvironment.transform 8 276 env51819 = env51820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env51819 == env51820) = true)

def env51821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,62589,119879,210201,8192,65,130314,172380,102742,212078,222543,177261,257,210235,250903,147985]

theorem envBound51821 : H12AffineFastState.Bounded env51821 := by
  intro p hp
  have h : env51821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51808_51821 : H12AffineEnvironment.transform 20 4161 env51808 = env51821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env51808 == env51821) = true)

def env51822 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,4161,62589,119879,95497,8192,65,130314,57676,102742,97406,75103,62589,257,95531,103431,513]

theorem envBound51822 : H12AffineFastState.Bounded env51822 := by
  intro p hp
  have h : env51822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51821_51822 : H12AffineEnvironment.transform 16 16400 env51821 = env51822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env51821 == env51822) = true)

theorem identity51822 : scanCanonicalize (H12AffineFastState.compose env51822 (packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound51822 : packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env51823 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,16400,10280,1025,32769,4161,62589,41292,2,8192,65,34817,57676,58461,2421,20564,62589,257,32,57612,513]

theorem envBound51823 : H12AffineFastState.Bounded env51823 := by
  intro p hp
  have h : env51823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51822_51823 : H12AffineEnvironment.transform 15 29963 env51822 = env51823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env51822 == env51823) = true)

theorem identity51823 : scanCanonicalize (H12AffineFastState.compose env51823 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound51823 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env51824 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,29963,16400,10280,1025,29708,4161,112,21825,2,8192,65,31756,5441,4176,2421,20564,112,257,32,5377,513]

theorem envBound51824 : H12AffineFastState.Bounded env51824 := by
  intro p hp
  have h : env51824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51823_51824 : H12AffineEnvironment.transform 14 29709 env51823 = env51824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env51823 == env51824) = true)

theorem identity51824 : scanCanonicalize (H12AffineFastState.compose env51824 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51824 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51825 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8460,8202,5393,10280,1025,8461,4161,112,64,2,8192,65,10509,5441,4176,2421,1365,112,257,32,5377,513]

theorem envBound51825 : H12AffineFastState.Bounded env51825 := by
  intro p hp
  have h : env51825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51824_51825 : H12AffineEnvironment.transform 13 5377 env51824 = env51825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51824 == env51825) = true)

theorem identity51825 : scanCanonicalize (H12AffineFastState.compose env51825 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51825 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51826 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8202,5393,10280,1025,8461,4112,33,17,2,8192,16,10509,5392,4097,2340,1284,33,257,32,5377,513]

theorem envBound51826 : H12AffineFastState.Bounded env51826 := by
  intro p hp
  have h : env51826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51825_51826 : H12AffineEnvironment.transform 5 17 env51825 = env51826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51825 == env51826) = true)

theorem identity51826 : scanCanonicalize (H12AffineFastState.compose env51826 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1288) := by decide +kernel

theorem selectedBound51826 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51827 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1288,5377,1028,1282,5393,3360,1025,1029,4112,33,17,2,1288,16,3077,5392,4097,2340,1284,33,257,32,5377,513]

theorem envBound51827 : H12AffineFastState.Bounded env51827 := by
  intro p hp
  have h : env51827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51826_51827 : H12AffineEnvironment.transform 12 1288 env51826 = env51827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env51826 == env51827) = true)

theorem identity51827 : scanCanonicalize (H12AffineFastState.compose env51827 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound51827 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env51828 : List Nat := [2,4,8,16,32,17,8,256,512,1024,560,4096,1288,5377,1028,1282,5393,1808,1025,1029,4112,33,17,2,1288,16,1589,5392,4097,788,1284,33,257,32,5377,513]

theorem envBound51828 : H12AffineFastState.Bounded env51828 := by
  intro p hp
  have h : env51828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51827_51828 : H12AffineEnvironment.transform 10 560 env51827 = env51828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env51827 == env51828) = true)

theorem identity51828 : scanCanonicalize (H12AffineFastState.compose env51828 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound51828 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51829 : List Nat := [2,4,8,16,32,17,8,256,512,36,560,4096,300,4389,32,294,4405,820,37,33,4112,33,17,2,300,16,529,4404,4097,788,288,33,257,32,4389,513]

theorem envBound51829 : H12AffineFastState.Bounded env51829 := by
  intro p hp
  have h : env51829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51828_51829 : H12AffineEnvironment.transform 9 36 env51828 = env51829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env51828 == env51829) = true)

theorem identity51829 : scanCanonicalize (H12AffineFastState.compose env51829 (packedSelected [1,3,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51829 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env51830 : List Nat := [2,4,8,16,0,17,8,256,512,4,528,4096,268,4357,0,262,4373,788,5,1,4112,1,17,2,268,16,529,4372,4097,788,256,1,257,0,4357,513]

theorem envBound51830 : H12AffineFastState.Bounded env51830 := by
  intro p hp
  have h : env51830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51829_51830 : H12AffineEnvironment.transform 4 0 env51829 = env51830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51829 == env51830) = true)

theorem identity51830 : scanCanonicalize (H12AffineFastState.compose env51830 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound51830 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51831 : List Nat := [2,4,8,16,0,17,8,256,512,4,528,512,268,773,0,262,789,788,5,1,528,1,17,2,268,16,529,788,513,788,256,1,257,0,773,513]

theorem envBound51831 : H12AffineFastState.Bounded env51831 := by
  intro p hp
  have h : env51831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51830_51831 : H12AffineEnvironment.transform 11 512 env51830 = env51831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env51830 == env51831) = true)

theorem identity51831 : scanCanonicalize (H12AffineFastState.compose env51831 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound51831 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51832 : List Nat := [2,4,8,16,0,17,8,256,276,4,260,276,268,17,0,262,1,0,5,1,260,1,17,2,268,16,261,0,277,0,256,1,257,0,17,277]

theorem envBound51832 : H12AffineFastState.Bounded env51832 := by
  intro p hp
  have h : env51832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51831_51832 : H12AffineEnvironment.transform 8 276 env51831 = env51832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env51831 == env51832) = true)

theorem identity51832 : scanCanonicalize (H12AffineFastState.compose env51832 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51832 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51833 : List Nat := [2,4,8,1,0,0,8,256,261,4,260,261,268,0,0,262,1,0,5,1,260,1,0,2,268,1,261,0,260,0,256,1,257,0,0,260]

theorem envBound51833 : H12AffineFastState.Bounded env51833 := by
  intro p hp
  have h : env51833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51832_51833 : H12AffineEnvironment.transform 3 1 env51832 = env51833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51832 == env51833) = true)

def env51834 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,4161,62589,119879,95496,8192,65,130314,57677,102742,97407,75102,62588,257,95530,103430,512]

theorem envBound51834 : H12AffineFastState.Bounded env51834 := by
  intro p hp
  have h : env51834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51821_51834 : H12AffineEnvironment.transform 16 16401 env51821 = env51834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env51821 == env51834) = true)

theorem identity51834 : scanCanonicalize (H12AffineFastState.compose env51834 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound51834 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51835 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,16401,10280,1025,32769,4161,62589,41293,2,8192,65,34816,57677,58460,2421,20564,62588,257,32,57612,512]

theorem envBound51835 : H12AffineFastState.Bounded env51835 := by
  intro p hp
  have h : env51835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51834_51835 : H12AffineEnvironment.transform 15 29962 env51834 = env51835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env51834 == env51835) = true)

theorem identity51835 : scanCanonicalize (H12AffineFastState.compose env51835 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 8461) := by decide +kernel

theorem selectedBound51835 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env51836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,8461,32768,5127,8476,10280,1025,32769,4161,38256,41293,2,8192,65,34816,32832,34129,2421,12633,38257,257,32,32769,512]

theorem envBound51836 : H12AffineFastState.Bounded env51836 := by
  intro p hp
  have h : env51836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51835_51836 : H12AffineEnvironment.transform 13 8461 env51835 = env51836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8461 env51835 == env51836) = true)

theorem identity51836 : scanCanonicalize (H12AffineFastState.compose env51836 (packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 14621) := by decide +kernel

theorem selectedBound51836 : packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env51837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,8461,14621,5127,8476,10280,1025,14620,4161,11373,6224,2,8192,65,12573,14685,15436,2421,12633,11372,257,32,14620,512]

theorem envBound51837 : H12AffineFastState.Bounded env51837 := by
  intro p hp
  have h : env51837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51836_51837 : H12AffineEnvironment.transform 14 14621 env51836 = env51837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14621 env51836 == env51837) = true)

theorem identity51837 : scanCanonicalize (H12AffineFastState.compose env51837 (packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound51837 : packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS < 2^1333 := by decide +kernel

def env51838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3328,8192,8461,9245,2311,8476,10280,1025,9244,3393,11373,1360,2,8192,65,11293,9309,8524,2421,11353,11372,257,32,9244,512]

theorem envBound51838 : H12AffineFastState.Bounded env51838 := by
  intro p hp
  have h : env51838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51837_51838 : H12AffineEnvironment.transform 11 3328 env51837 = env51838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env51837 == env51838) = true)

theorem identity51838 : scanCanonicalize (H12AffineFastState.compose env51838 (packedSelected [1,2,6,8,10,12,16,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound51838 : packedSelected [1,2,6,8,10,12,16,20] rootPS < 2^1333 := by decide +kernel

def env51839 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,3076,8192,8201,9245,2051,8216,10280,1025,9244,3141,11373,1108,2,8192,65,11293,9309,8264,2161,11353,11372,5,32,9244,512]

theorem envBound51839 : H12AffineFastState.Bounded env51839 := by
  intro p hp
  have h : env51839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51838_51839 : H12AffineEnvironment.transform 7 4 env51838 = env51839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env51838 == env51839) = true)

theorem identity51839 : scanCanonicalize (H12AffineFastState.compose env51839 (packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound51839 : packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS < 2^1333 := by decide +kernel

def env51840 : List Nat := [2,4,8,16,32,64,8,4,512,68,2048,2112,8192,8201,8281,2051,8216,10280,69,8280,2049,10281,16,2,8192,65,10329,8217,8264,2161,10269,10280,5,32,8280,512]

theorem envBound51840 : H12AffineFastState.Bounded env51840 := by
  intro p hp
  have h : env51840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51839_51840 : H12AffineEnvironment.transform 9 68 env51839 = env51840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env51839 == env51840) = true)

theorem identity51840 : scanCanonicalize (H12AffineFastState.compose env51840 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound51840 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env51841 : List Nat := [2,4,8,16,32,49,8,4,512,53,2048,2097,8192,8201,8232,2051,8216,10280,52,8233,2049,10281,16,2,8192,48,10280,8217,8249,2048,10269,10280,5,32,8233,512]

theorem envBound51841 : H12AffineFastState.Bounded env51841 := by
  intro p hp
  have h : env51841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51840_51841 : H12AffineEnvironment.transform 5 49 env51840 = env51841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env51840 == env51841) = true)

theorem identity51841 : scanCanonicalize (H12AffineFastState.compose env51841 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound51841 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51842 : List Nat := [2,4,8,16,32,49,8,4,512,53,2048,2097,40,33,0,2051,48,2048,52,1,2049,2049,16,2,40,48,2048,49,17,2048,2101,2048,5,32,1,512]

theorem envBound51842 : H12AffineFastState.Bounded env51842 := by
  intro p hp
  have h : env51842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51841_51842 : H12AffineEnvironment.transform 12 40 env51841 = env51842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env51841 == env51842) = true)

theorem identity51842 : scanCanonicalize (H12AffineFastState.compose env51842 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51842 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51843 : List Nat := [2,4,8,16,0,17,8,4,512,21,2048,2065,8,1,0,2051,16,2048,20,1,2049,2049,16,2,8,16,2048,17,17,2048,2069,2048,5,0,1,512]

theorem envBound51843 : H12AffineFastState.Bounded env51843 := by
  intro p hp
  have h : env51843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51842_51843 : H12AffineEnvironment.transform 4 0 env51842 = env51843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51842 == env51843) = true)

def env51844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155700,2485294,2559345,8328,65,2475498,428541,375166,2305071,222542,2526213,257,2303475,2344023,148120]

theorem envBound51844 : H12AffineFastState.Bounded env51844 := by
  intro p hp
  have h : env51844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51805_51844 : H12AffineEnvironment.transform 23 2559345 env51805 = env51844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559345 env51805 == env51844) = true)

def env51845 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485294,2559345,8192,65,2475362,428405,375166,2305071,222542,2526213,257,2303355,2344023,147984]

theorem envBound51845 : H12AffineFastState.Bounded env51845 := by
  intro p hp
  have h : env51845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51844_51845 : H12AffineEnvironment.transform 6 8 env51844 = env51845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51844 == env51845) = true)

theorem identity51845 : scanCanonicalize (H12AffineFastState.compose env51845 (packedSelected [3,4,7,9,10,14,16,17,20,24,26,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound51845 : packedSelected [3,4,7,9,10,14,16,17,20,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env51846 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,2155580,2485294,2444640,8192,65,2475362,313700,375166,2190398,75103,2411540,257,2188650,2196550,513]

theorem envBound51846 : H12AffineFastState.Bounded env51846 := by
  intro p hp
  have h : env51846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51845_51846 : H12AffineEnvironment.transform 16 16401 env51845 = env51846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env51845 == env51846) = true)

def env51847 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,2155580,2212870,2188616,8192,65,2223434,57676,102742,2190398,75103,2155580,257,2188650,2196550,513]

theorem envBound51847 : H12AffineFastState.Bounded env51847 := by
  intro p hp
  have h : env51847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51846_51847 : H12AffineEnvironment.transform 17 10280 env51846 = env51847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51846 == env51847) = true)

theorem identity51847 : scanCanonicalize (H12AffineFastState.compose env51847 (packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound51847 : packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env51848 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10280,1025,32769,2097152,2155580,2122764,2147650,8192,65,2116928,57676,12636,2149428,34133,2155580,257,2147680,2106444,513]

theorem envBound51848 : H12AffineFastState.Bounded env51848 := by
  intro p hp
  have h : env51848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51847_51848 : H12AffineEnvironment.transform 15 40970 env51847 = env51848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env51847 == env51848) = true)

theorem identity51848 : scanCanonicalize (H12AffineFastState.compose env51848 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound51848 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env51849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,8282,16401,10280,1025,81,2097152,2122860,2122764,2114834,8192,65,2116928,24860,12636,2116708,1285,2122860,257,2114864,2106444,513]

theorem envBound51849 : H12AffineFastState.Bounded env51849 := by
  intro p hp
  have h : env51849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51848_51849 : H12AffineEnvironment.transform 14 80 env51848 = env51849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env51848 == env51849) = true)

theorem identity51849 : scanCanonicalize (H12AffineFastState.compose env51849 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51849 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env51850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,80,342,16401,2340,1025,81,2097152,2114912,2114816,2114834,268,65,2116928,16400,4176,2116708,1285,2114912,257,2114864,2098496,513]

theorem envBound51850 : H12AffineFastState.Bounded env51850 := by
  intro p hp
  have h : env51850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51849_51850 : H12AffineEnvironment.transform 12 268 env51849 = env51850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51849 == env51850) = true)

theorem identity51850 : scanCanonicalize (H12AffineFastState.compose env51850 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound51850 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,80,342,16401,2340,1025,81,17680,112,16,2,268,65,2128,16400,4176,2420,1285,112,257,32,16464,513]

theorem envBound51851 : H12AffineFastState.Bounded env51851 := by
  intro p hp
  have h : env51851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51850_51851 : H12AffineEnvironment.transform 20 17680 env51850 = env51851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env51850 == env51851) = true)

theorem identity51851 : scanCanonicalize (H12AffineFastState.compose env51851 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 1361) := by decide +kernel

theorem selectedBound51851 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env51852 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,1361,80,342,1344,2340,1025,81,65,112,16,2,268,65,2128,1345,4176,2420,1285,112,257,32,1281,513]

theorem envBound51852 : H12AffineFastState.Bounded env51852 := by
  intro p hp
  have h : env51852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51851_51852 : H12AffineEnvironment.transform 13 1361 env51851 = env51852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1361 env51851 == env51852) = true)

def env51853 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,2155580,2212871,2188617,8192,65,2223435,57677,102743,2190398,75103,2155581,257,2188650,2196550,513]

theorem envBound51853 : H12AffineFastState.Bounded env51853 := by
  intro p hp
  have h : env51853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51846_51853 : H12AffineEnvironment.transform 17 10281 env51846 = env51853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env51846 == env51853) = true)

theorem identity51853 : scanCanonicalize (H12AffineFastState.compose env51853 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51853 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51854 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10281,1025,32769,2097152,2155580,2155532,2114882,8192,65,2149696,57677,45404,2116661,1364,2155581,257,2114913,2139213,513]

theorem envBound51854 : H12AffineFastState.Bounded env51854 := by
  intro p hp
  have h : env51854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51853_51854 : H12AffineEnvironment.transform 15 8203 env51853 = env51854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51853 == env51854) = true)

theorem identity51854 : scanCanonicalize (H12AffineFastState.compose env51854 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound51854 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51855 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8203,16401,10281,1025,29004,2097152,2102641,2102593,2114882,8192,65,2112525,4096,16401,2116661,1364,2102640,257,2114913,2118912,513]

theorem envBound51855 : H12AffineFastState.Bounded env51855 := by
  intro p hp
  have h : env51855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51854_51855 : H12AffineEnvironment.transform 14 29005 env51854 = env51855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env51854 == env51855) = true)

theorem identity51855 : scanCanonicalize (H12AffineFastState.compose env51855 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(20+1) ^^^ 11625) := by decide +kernel

theorem selectedBound51855 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env51856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8203,16401,10281,1025,29004,11625,14360,14376,26667,8192,65,4452,4096,16401,24924,1364,14361,257,26632,30825,513]

theorem envBound51856 : H12AffineFastState.Bounded env51856 := by
  intro p hp
  have h : env51856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51855_51856 : H12AffineEnvironment.transform 20 11625 env51855 = env51856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11625 env51855 == env51856) = true)

theorem identity51856 : scanCanonicalize (H12AffineFastState.compose env51856 (packedSelected [11,12,14,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound51856 : packedSelected [11,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env51857 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3148,16384,23809,3143,16401,1125,1025,23808,293,5204,5220,17511,3148,65,4452,4096,16401,19728,1364,5205,257,17476,21541,513]

theorem envBound51857 : H12AffineFastState.Bounded env51857 := by
  intro p hp
  have h : env51857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51856_51857 : H12AffineEnvironment.transform 12 3148 env51856 = env51857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env51856 == env51857) = true)

theorem identity51857 : scanCanonicalize (H12AffineFastState.compose env51857 (packedSelected [21] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound51857 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,3148,16384,18804,3143,16401,1125,1025,18805,293,33,17,17511,3148,65,1297,1141,16401,19728,1364,32,257,17476,16464,513]

theorem envBound51858 : H12AffineFastState.Bounded env51858 := by
  intro p hp
  have h : env51858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51857_51858 : H12AffineEnvironment.transform 11 1141 env51857 = env51858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env51857 == env51858) = true)

theorem identity51858 : scanCanonicalize (H12AffineFastState.compose env51858 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 2128) := by decide +kernel

theorem selectedBound51858 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env51859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,3148,2128,292,3143,2113,1125,1025,293,293,33,17,3127,3148,65,1297,1141,2113,1344,1364,32,257,3092,2048,513]

theorem envBound51859 : H12AffineFastState.Bounded env51859 := by
  intro p hp
  have h : env51859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51858_51859 : H12AffineEnvironment.transform 13 2128 env51858 = env51859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2128 env51858 == env51859) = true)

theorem identity51859 : scanCanonicalize (H12AffineFastState.compose env51859 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound51859 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env51860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,789,1141,1881,837,292,1874,852,1125,1025,293,293,33,17,1826,1881,65,1297,1141,852,1344,1364,32,257,1793,789,513]

theorem envBound51860 : H12AffineFastState.Bounded env51860 := by
  intro p hp
  have h : env51860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51859_51860 : H12AffineEnvironment.transform 10 789 env51859 = env51860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env51859 == env51860) = true)

theorem identity51860 : scanCanonicalize (H12AffineFastState.compose env51860 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound51860 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env51861 : List Nat := [2,4,8,16,32,64,8,256,33,1024,308,1141,1400,356,292,1395,373,1125,1025,293,293,33,17,1283,1400,65,1297,1141,373,1344,1364,32,257,1312,308,32]

theorem envBound51861 : H12AffineFastState.Bounded env51861 := by
  intro p hp
  have h : env51861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51860_51861 : H12AffineEnvironment.transform 8 33 env51860 = env51861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env51860 == env51861) = true)

theorem identity51861 : scanCanonicalize (H12AffineFastState.compose env51861 (packedSelected [0,1,3,4,5,6,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound51861 : packedSelected [0,1,3,4,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env51862 : List Nat := [2,4,8,16,32,64,8,256,33,37,308,80,349,356,292,342,373,64,36,293,293,33,17,294,349,65,308,80,373,357,369,32,257,261,308,32]

theorem envBound51862 : H12AffineFastState.Bounded env51862 := by
  intro p hp
  have h : env51862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51861_51862 : H12AffineEnvironment.transform 9 37 env51861 = env51862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env51861 == env51862) = true)

theorem identity51862 : scanCanonicalize (H12AffineFastState.compose env51862 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51862 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51863 : List Nat := [2,4,8,16,32,16,8,256,33,37,308,0,269,308,292,262,293,16,36,293,293,33,17,294,269,17,308,0,293,309,289,32,257,261,308,32]

theorem envBound51863 : H12AffineFastState.Bounded env51863 := by
  intro p hp
  have h : env51863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51862_51863 : H12AffineEnvironment.transform 5 16 env51862 = env51863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51862 == env51863) = true)

theorem identity51863 : scanCanonicalize (H12AffineFastState.compose env51863 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound51863 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51864 : List Nat := [2,4,8,16,32,16,8,52,33,37,0,0,57,0,16,50,17,16,36,17,17,33,17,18,57,17,0,0,17,1,21,32,53,49,0,32]

theorem envBound51864 : H12AffineFastState.Bounded env51864 := by
  intro p hp
  have h : env51864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51863_51864 : H12AffineEnvironment.transform 7 52 env51863 = env51864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env51863 == env51864) = true)

theorem identity51864 : scanCanonicalize (H12AffineFastState.compose env51864 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound51864 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51865 : List Nat := [2,4,8,16,16,16,8,4,17,21,0,0,9,0,16,2,17,16,20,17,17,17,17,18,9,17,0,0,17,1,21,16,5,1,0,16]

theorem envBound51865 : H12AffineFastState.Bounded env51865 := by
  intro p hp
  have h : env51865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51864_51865 : H12AffineEnvironment.transform 4 16 env51864 = env51865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env51864 == env51865) = true)

theorem identity51865 : scanCanonicalize (H12AffineFastState.compose env51865 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51865 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51866 : List Nat := [2,4,8,1,1,1,8,4,0,4,0,0,9,0,1,2,0,1,5,0,0,0,0,3,9,0,0,0,0,1,4,1,5,1,0,1]

theorem envBound51866 : H12AffineFastState.Bounded env51866 := by
  intro p hp
  have h : env51866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51865_51866 : H12AffineEnvironment.transform 3 1 env51865 = env51866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51865 == env51866) = true)

def env51867 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485294,2559345,8193,65,2475363,428404,375166,2305071,222542,2526213,257,2303354,2344023,147985]

theorem envBound51867 : H12AffineFastState.Bounded env51867 := by
  intro p hp
  have h : env51867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51844_51867 : H12AffineEnvironment.transform 6 9 env51844 = env51867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51844 == env51867) = true)

theorem identity51867 : scanCanonicalize (H12AffineFastState.compose env51867 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound51867 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env51868 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,2155581,2188634,2327557,8193,65,2182167,131072,77834,2305071,222542,2229617,257,2303354,2344023,147985]

theorem envBound51868 : H12AffineFastState.Bounded env51868 := by
  intro p hp
  have h : env51868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51867_51868 : H12AffineEnvironment.transform 17 35188 env51867 = env51868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env51867 == env51868) = true)

theorem identity51868 : scanCanonicalize (H12AffineFastState.compose env51868 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51868 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env51869 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,35188,1025,32769,2097152,2155581,2114896,2270223,8193,65,2124829,131072,4096,2231333,148804,2229617,257,2229616,2286685,147985]

theorem envBound51869 : H12AffineFastState.Bounded env51869 := by
  intro p hp
  have h : env51869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51868_51869 : H12AffineEnvironment.transform 15 8202 env51868 = env51869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51868 == env51869) = true)

def env51870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155701,2485294,16777216,8328,65,16959642,18973836,375166,2305071,19163199,16875893,257,17049730,17090854,19222505]

theorem envBound51870 : H12AffineFastState.Bounded env51870 := by
  intro p hp
  have h : env51870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51804_51870 : H12AffineEnvironment.transform 21 2155701 env51804 = env51870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155701 env51804 == env51870) = true)

def env51871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155701,2485294,2559344,8328,65,2475498,428540,375166,2305071,222543,2526213,257,2303474,2344022,148121]

theorem envBound51871 : H12AffineFastState.Bounded env51871 := by
  intro p hp
  have h : env51871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51870_51871 : H12AffineEnvironment.transform 23 2559344 env51870 = env51871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559344 env51870 == env51871) = true)

theorem identity51871 : scanCanonicalize (H12AffineFastState.compose env51871 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388159) := by decide +kernel

theorem selectedBound51871 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env51872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,329866,17,188751,8328,65,10709,428540,375166,442384,222543,221242,257,444877,403561,148121]

theorem envBound51872 : H12AffineFastState.Bounded env51872 := by
  intro p hp
  have h : env51872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51871_51872 : H12AffineEnvironment.transform 20 388159 env51871 = env51872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388159 env51871 == env51872) = true)

def env51873 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,329730,17,188751,8192,65,10589,428404,375166,442384,222543,221242,257,444741,403561,147985]

theorem envBound51873 : H12AffineFastState.Bounded env51873 := by
  intro p hp
  have h : env51873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51872_51873 : H12AffineEnvironment.transform 6 8 env51872 = env51873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51872 == env51873) = true)

theorem identity51873 : scanCanonicalize (H12AffineFastState.compose env51873 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound51873 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env51874 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1025,32769,230407,221242,17,188751,8192,65,10589,57676,250182,43048,222543,221242,257,41341,16465,147985]

theorem envBound51874 : H12AffineFastState.Bounded env51874 := by
  intro p hp
  have h : env51874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51873_51874 : H12AffineEnvironment.transform 17 157752 env51873 = env51874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env51873 == env51874) = true)

theorem identity51874 : scanCanonicalize (H12AffineFastState.compose env51874 (packedSelected [1,2,3,4,5,6,7,8,10,11,14,16,18,19,20,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound51874 : packedSelected [1,2,3,4,5,6,7,8,10,11,14,16,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env51875 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,67618,1025,32769,58397,32,17,98645,8192,65,10589,57676,45404,43048,1365,32,257,41341,16465,74251]

theorem envBound51875 : H12AffineFastState.Bounded env51875 := by
  intro p hp
  have h : env51875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51874_51875 : H12AffineEnvironment.transform 16 90138 env51874 = env51875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env51874 == env51875) = true)

theorem identity51875 : scanCanonicalize (H12AffineFastState.compose env51875 (packedSelected [0,1,3,5,7,8,14,15,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound51875 : packedSelected [0,1,3,5,7,8,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env51876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,65536,90138,67618,1025,8461,17681,32,17,73817,8192,65,10589,16448,4176,2340,1365,32,257,113,16465,74251]

theorem envBound51876 : H12AffineFastState.Bounded env51876 := by
  intro p hp
  have h : env51876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51875_51876 : H12AffineEnvironment.transform 14 8460 env51875 = env51876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env51875 == env51876) = true)

theorem identity51876 : scanCanonicalize (H12AffineFastState.compose env51876 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51876 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env51877 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,90138,67618,1025,8461,17681,32,17,73736,8192,16,10508,16401,4097,2340,1284,32,257,32,16384,74251]

theorem envBound51877 : H12AffineFastState.Bounded env51877 := by
  intro p hp
  have h : env51877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51876_51877 : H12AffineEnvironment.transform 5 17 env51876 = env51877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51876 == env51877) = true)

theorem identity51877 : scanCanonicalize (H12AffineFastState.compose env51877 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51877 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env51878 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,8203,16401,10281,1025,8461,17681,32,17,3,8192,16,10508,16401,4097,2340,1284,32,257,32,16384,512]

theorem envBound51878 : H12AffineFastState.Bounded env51878 := by
  intro p hp
  have h : env51878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51877_51878 : H12AffineEnvironment.transform 15 8203 env51877 = env51878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51877 == env51878) = true)

theorem identity51878 : scanCanonicalize (H12AffineFastState.compose env51878 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 9260) := by decide +kernel

theorem selectedBound51878 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51879 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,9260,8460,8203,9277,10281,1025,8461,8509,32,17,3,8192,16,10508,9277,4097,2340,1284,32,257,32,9260,512]

theorem envBound51879 : H12AffineFastState.Bounded env51879 := by
  intro p hp
  have h : env51879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51878_51879 : H12AffineEnvironment.transform 13 9260 env51878 = env51879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9260 env51878 == env51879) = true)

theorem identity51879 : scanCanonicalize (H12AffineFastState.compose env51879 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound51879 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51880 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,300,1280,32,295,1297,2309,1025,33,17,32,17,3,300,16,2080,1297,4097,2340,1284,32,257,32,1280,512]

theorem envBound51880 : H12AffineFastState.Bounded env51880 := by
  intro p hp
  have h : env51880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51879_51880 : H12AffineEnvironment.transform 12 300 env51879 = env51880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env51879 == env51880) = true)

theorem identity51880 : scanCanonicalize (H12AffineFastState.compose env51880 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound51880 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env51881 : List Nat := [2,4,8,16,32,17,8,256,512,1024,11,4096,300,1280,32,295,1297,270,1025,33,17,32,17,3,300,16,43,1297,4097,303,1284,32,257,32,1280,512]

theorem envBound51881 : H12AffineFastState.Bounded env51881 := by
  intro p hp
  have h : env51881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51880_51881 : H12AffineEnvironment.transform 10 11 env51880 = env51881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env51880 == env51881) = true)

theorem identity51881 : scanCanonicalize (H12AffineFastState.compose env51881 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound51881 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51882 : List Nat := [2,4,8,16,32,17,8,256,512,1024,11,1,300,1280,32,295,1297,270,1025,33,17,32,17,3,300,16,43,1297,0,303,1284,32,257,32,1280,512]

theorem envBound51882 : H12AffineFastState.Bounded env51882 := by
  intro p hp
  have h : env51882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51881_51882 : H12AffineEnvironment.transform 11 1 env51881 = env51882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env51881 == env51882) = true)

theorem identity51882 : scanCanonicalize (H12AffineFastState.compose env51882 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound51882 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51883 : List Nat := [2,4,8,16,32,17,8,256,512,304,11,1,300,48,32,295,33,270,305,33,17,32,17,3,300,16,43,33,0,303,52,32,257,32,48,512]

theorem envBound51883 : H12AffineFastState.Bounded env51883 := by
  intro p hp
  have h : env51883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51882_51883 : H12AffineEnvironment.transform 9 304 env51882 = env51883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env51882 == env51883) = true)

theorem identity51883 : scanCanonicalize (H12AffineFastState.compose env51883 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51883 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51884 : List Nat := [2,4,8,1,32,0,8,256,512,289,11,1,300,33,32,295,33,270,288,33,0,32,0,3,300,1,43,33,0,303,37,32,257,32,33,512]

theorem envBound51884 : H12AffineFastState.Bounded env51884 := by
  intro p hp
  have h : env51884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51883_51884 : H12AffineEnvironment.transform 3 1 env51883 = env51884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51883 == env51884) = true)

theorem identity51884 : scanCanonicalize (H12AffineFastState.compose env51884 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound51884 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51885 : List Nat := [2,4,8,1,32,0,8,14,512,47,11,1,34,33,32,41,33,0,46,33,0,32,0,3,34,1,43,33,0,33,37,32,15,32,33,512]

theorem envBound51885 : H12AffineFastState.Bounded env51885 := by
  intro p hp
  have h : env51885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51884_51885 : H12AffineEnvironment.transform 7 14 env51884 = env51885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env51884 == env51885) = true)

theorem identity51885 : scanCanonicalize (H12AffineFastState.compose env51885 (packedSelected [0,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51885 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env51886 : List Nat := [2,4,8,1,11,0,8,14,512,4,11,1,9,10,11,2,10,0,5,10,0,11,0,3,9,1,0,10,0,10,14,11,15,11,10,512]

theorem envBound51886 : H12AffineFastState.Bounded env51886 := by
  intro p hp
  have h : env51886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51885_51886 : H12AffineEnvironment.transform 4 11 env51885 = env51886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51885 == env51886) = true)

theorem identity51886 : scanCanonicalize (H12AffineFastState.compose env51886 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound51886 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51887 : List Nat := [2,1,8,1,11,0,8,11,512,1,11,1,9,10,11,2,10,0,0,10,0,11,0,3,9,1,0,10,0,10,11,11,10,11,10,512]

theorem envBound51887 : H12AffineFastState.Bounded env51887 := by
  intro p hp
  have h : env51887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51886_51887 : H12AffineEnvironment.transform 1 1 env51886 = env51887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env51886 == env51887) = true)

def env51888 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,329731,17,188751,8193,65,10588,428405,375166,442384,222543,221242,257,444740,403561,147984]

theorem envBound51888 : H12AffineFastState.Bounded env51888 := by
  intro p hp
  have h : env51888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51872_51888 : H12AffineEnvironment.transform 6 9 env51872 = env51888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51872 == env51888) = true)

theorem identity51888 : scanCanonicalize (H12AffineFastState.compose env51888 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound51888 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env51889 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1025,8540,347490,329731,17,147474,8193,65,10588,403496,333859,418125,222543,221242,257,419865,403561,147984]

theorem envBound51889 : H12AffineFastState.Bounded env51889 := by
  intro p hp
  have h : env51889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51888_51889 : H12AffineEnvironment.transform 14 8541 env51888 = env51889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env51888 == env51889) = true)

def env51890 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,262144,1025,8540,347490,329731,17,2,8193,65,10588,288824,333859,270685,75103,73770,257,272393,288889,512]

theorem envBound51890 : H12AffineFastState.Bounded env51890 := by
  intro p hp
  have h : env51890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51889_51890 : H12AffineEnvironment.transform 16 16400 env51889 = env51890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env51889 == env51890) = true)

theorem identity51890 : scanCanonicalize (H12AffineFastState.compose env51890 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8543) := by decide +kernel

theorem selectedBound51890 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51891 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8543,16400,262144,1025,8540,289853,272732,17,2,8193,65,10588,288824,276860,270685,1024,373,257,272393,288889,512]

theorem envBound51891 : H12AffineFastState.Bounded env51891 := by
  intro p hp
  have h : env51891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51890_51891 : H12AffineEnvironment.transform 15 8543 env51890 = env51891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8543 env51890 == env51891) = true)

theorem identity51891 : scanCanonicalize (H12AffineFastState.compose env51891 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound51891 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env51892 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8233,8235,16400,262144,1025,8232,289853,272424,17,2,8193,65,10280,288824,276488,270377,1024,1,117,272393,288889,512]

theorem envBound51892 : H12AffineFastState.Bounded env51892 := by
  intro p hp
  have h : env51892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51891_51892 : H12AffineEnvironment.transform 7 116 env51891 = env51892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env51891 == env51892) = true)

theorem identity51892 : scanCanonicalize (H12AffineFastState.compose env51892 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound51892 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51893 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,16384,0,2,16400,262144,1025,1,281620,264193,17,2,40,65,2049,280593,268321,262144,1024,1,117,264224,280656,512]

theorem envBound51893 : H12AffineFastState.Bounded env51893 := by
  intro p hp
  have h : env51893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51892_51893 : H12AffineEnvironment.transform 12 41 env51892 = env51893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env51892 == env51893) = true)

def env51894 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,262144,1025,8540,347490,329731,17,3,8193,65,10588,288825,333859,270684,75102,73771,257,272392,288888,513]

theorem envBound51894 : H12AffineFastState.Bounded env51894 := by
  intro p hp
  have h : env51894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51889_51894 : H12AffineEnvironment.transform 16 16401 env51889 = env51894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env51889 == env51894) = true)

theorem identity51894 : scanCanonicalize (H12AffineFastState.compose env51894 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound51894 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,8541,65536,12637,262144,1025,8540,343086,329731,17,3,8193,65,10588,268661,333859,270684,75102,73771,257,272392,268596,513]

theorem envBound51895 : H12AffineFastState.Bounded env51895 := by
  intro p hp
  have h : env51895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51894_51895 : H12AffineEnvironment.transform 13 12620 env51894 = env51895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env51894 == env51895) = true)

theorem identity51895 : scanCanonicalize (H12AffineFastState.compose env51895 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51895 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,8541,8203,12637,262144,1025,8540,269349,272392,17,3,8193,65,10588,268661,276520,270684,1365,32,257,272392,268596,513]

theorem envBound51896 : H12AffineFastState.Bounded env51896 := by
  intro p hp
  have h : env51896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51895_51896 : H12AffineEnvironment.transform 15 8203 env51895 = env51896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51895 == env51896) = true)

theorem identity51896 : scanCanonicalize (H12AffineFastState.compose env51896 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound51896 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,8541,8203,12637,10361,1025,8540,13404,113,17,3,8193,65,10588,12556,4177,2341,1365,32,257,113,12621,513]

theorem envBound51897 : H12AffineFastState.Bounded env51897 := by
  intro p hp
  have h : env51897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51896_51897 : H12AffineEnvironment.transform 17 10361 env51896 = env51897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env51896 == env51897) = true)

theorem identity51897 : scanCanonicalize (H12AffineFastState.compose env51897 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound51897 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,4453,372,34,4468,2128,1025,373,5237,113,17,3,40,65,2421,4389,4177,2341,1365,32,257,113,4452,513]

theorem envBound51898 : H12AffineFastState.Bounded env51898 := by
  intro p hp
  have h : env51898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51897_51898 : H12AffineEnvironment.transform 12 41 env51897 = env51898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env51897 == env51898) = true)

theorem identity51898 : scanCanonicalize (H12AffineFastState.compose env51898 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51898 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env51899 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,41,4160,81,34,4177,2128,1025,80,5237,113,17,3,40,65,2128,4096,4177,2048,1136,32,36,113,4161,513]

theorem envBound51899 : H12AffineFastState.Bounded env51899 := by
  intro p hp
  have h : env51899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51898_51899 : H12AffineEnvironment.transform 7 37 env51898 = env51899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51898 == env51899) = true)

theorem identity51899 : scanCanonicalize (H12AffineFastState.compose env51899 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound51899 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51900 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,4096,41,4160,81,34,4177,2128,53,80,4161,113,17,3,40,65,2128,4096,4177,2048,68,32,36,113,4161,513]

theorem envBound51900 : H12AffineFastState.Bounded env51900 := by
  intro p hp
  have h : env51900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51899_51900 : H12AffineEnvironment.transform 9 52 env51899 = env51900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51899 == env51900) = true)

def env51901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155701,2485294,2559345,8328,65,2475499,428541,375166,2305071,222542,2526212,257,2303475,2344023,148120]

theorem envBound51901 : H12AffineFastState.Bounded env51901 := by
  intro p hp
  have h : env51901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51870_51901 : H12AffineEnvironment.transform 23 2559345 env51870 = env51901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559345 env51870 == env51901) = true)

theorem identity51901 : scanCanonicalize (H12AffineFastState.compose env51901 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388279) := by decide +kernel

theorem selectedBound51901 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env51902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388279,329730,153,188870,8328,65,10588,428541,375166,442520,222542,221363,257,444740,403680,148120]

theorem envBound51902 : H12AffineFastState.Bounded env51902 := by
  intro p hp
  have h : env51902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51901_51902 : H12AffineEnvironment.transform 20 388279 env51901 = env51902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388279 env51901 == env51902) = true)

theorem identity51902 : scanCanonicalize (H12AffineFastState.compose env51902 (packedSelected [3,10,21,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51902 : packedSelected [3,10,21,24,26] rootPS < 2^1333 := by decide +kernel

def env51903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,329730,17,188750,8192,65,10588,428405,375166,442384,222542,221243,257,444740,403560,147984]

theorem envBound51903 : H12AffineFastState.Bounded env51903 := by
  intro p hp
  have h : env51903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51902_51903 : H12AffineEnvironment.transform 6 8 env51902 = env51903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51902 == env51903) = true)

def env51904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,388159,329730,17,41310,8192,65,10588,313701,375166,294912,75102,73771,257,297300,288888,512]

theorem envBound51904 : H12AffineFastState.Bounded env51904 := by
  intro p hp
  have h : env51904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51903_51904 : H12AffineEnvironment.transform 16 16400 env51903 = env51904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env51903 == env51904) = true)

theorem identity51904 : scanCanonicalize (H12AffineFastState.compose env51904 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound51904 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env51905 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,388159,329730,17,41002,8192,65,10280,313361,374794,294912,74794,73771,117,296992,288888,512]

theorem envBound51905 : H12AffineFastState.Bounded env51905 := by
  intro p hp
  have h : env51905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51904_51905 : H12AffineEnvironment.transform 7 116 env51904 = env51905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env51904 == env51905) = true)

theorem identity51905 : scanCanonicalize (H12AffineFastState.compose env51905 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound51905 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51906 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,29822,16400,262144,1025,32769,301121,294012,17,41002,8192,65,10280,313361,314484,294912,20564,21589,117,296992,288888,512]

theorem envBound51906 : H12AffineFastState.Bounded env51906 := by
  intro p hp
  have h : env51906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51905_51906 : H12AffineEnvironment.transform 15 29822 env51905 = env51906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env51905 == env51906) = true)

theorem identity51906 : scanCanonicalize (H12AffineFastState.compose env51906 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 21588) := by decide +kernel

theorem selectedBound51906 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51907 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,21588,29822,16400,262144,1025,21589,281621,294012,17,29822,8192,65,10280,269381,268320,283732,20564,21589,117,285812,288888,512]

theorem envBound51907 : H12AffineFastState.Bounded env51907 := by
  intro p hp
  have h : env51907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51906_51907 : H12AffineEnvironment.transform 14 21588 env51906 = env51907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21588 env51906 == env51907) = true)

theorem identity51907 : scanCanonicalize (H12AffineFastState.compose env51907 (packedSelected [2,4,14,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 23637) := by decide +kernel

theorem selectedBound51907 : packedSelected [2,4,14,20,22] rootPS < 2^1333 := by decide +kernel

def env51908 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,21588,29822,16400,23637,1025,21589,4160,8233,17,29822,8192,65,10280,16400,17525,2049,20564,21589,117,33,13357,512]

theorem envBound51908 : H12AffineFastState.Bounded env51908 := by
  intro p hp
  have h : env51908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51907_51908 : H12AffineEnvironment.transform 17 23637 env51907 = env51908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23637 env51907 == env51908) = true)

theorem identity51908 : scanCanonicalize (H12AffineFastState.compose env51908 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound51908 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env51909 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,9,16384,21588,21623,16400,23637,1025,21589,4160,32,17,21623,9,65,2081,16400,17525,2049,20564,21589,117,33,5156,512]

theorem envBound51909 : H12AffineFastState.Bounded env51909 := by
  intro p hp
  have h : env51909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51908_51909 : H12AffineEnvironment.transform 12 9 env51908 = env51909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env51908 == env51909) = true)

theorem identity51909 : scanCanonicalize (H12AffineFastState.compose env51909 (packedSelected [2,3,5,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 2081) := by decide +kernel

theorem selectedBound51909 : packedSelected [2,3,5,10,11] rootPS < 2^1333 := by decide +kernel

def env51910 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,9,2081,7285,7254,2097,5236,1025,7284,4160,32,17,7254,9,65,2081,2097,3156,2049,6261,7284,117,33,5156,512]

theorem envBound51910 : H12AffineFastState.Bounded env51910 := by
  intro p hp
  have h : env51910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51909_51910 : H12AffineEnvironment.transform 13 2081 env51909 = env51910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2081 env51909 == env51910) = true)

theorem identity51910 : scanCanonicalize (H12AffineFastState.compose env51910 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound51910 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51911 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3109,9,2081,80,115,2097,2129,1025,81,3173,32,17,115,9,65,2081,2097,3156,2049,1104,81,117,33,2049,512]

theorem envBound51911 : H12AffineFastState.Bounded env51911 := by
  intro p hp
  have h : env51911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51910_51911 : H12AffineEnvironment.transform 11 3109 env51910 = env51911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env51910 == env51911) = true)

theorem identity51911 : scanCanonicalize (H12AffineFastState.compose env51911 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound51911 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env51912 : List Nat := [2,4,8,16,32,64,8,116,512,20,2048,2097,9,2081,80,115,2097,2129,21,81,2161,32,17,115,9,65,2081,2097,2112,2049,68,81,117,33,2049,512]

theorem envBound51912 : H12AffineFastState.Bounded env51912 := by
  intro p hp
  have h : env51912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51911_51912 : H12AffineEnvironment.transform 9 20 env51911 = env51912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51911 == env51912) = true)

theorem identity51912 : scanCanonicalize (H12AffineFastState.compose env51912 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51912 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env51913 : List Nat := [2,4,8,16,1,64,8,85,512,20,2048,2064,9,2048,80,82,2064,2129,21,81,2128,1,17,82,9,65,2048,2064,2112,2049,68,81,84,0,2049,512]

theorem envBound51913 : H12AffineFastState.Bounded env51913 := by
  intro p hp
  have h : env51913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51912_51913 : H12AffineEnvironment.transform 4 1 env51912 = env51913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51912 == env51913) = true)

theorem identity51913 : scanCanonicalize (H12AffineFastState.compose env51913 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51913 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env51914 : List Nat := [2,4,8,16,1,16,8,5,512,20,2048,2064,9,2048,0,2,2064,2049,21,1,2048,1,17,2,9,17,2048,2064,2064,2049,20,1,4,0,2049,512]

theorem envBound51914 : H12AffineFastState.Bounded env51914 := by
  intro p hp
  have h : env51914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51913_51914 : H12AffineEnvironment.transform 5 16 env51913 = env51914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51913 == env51914) = true)

theorem identity51914 : scanCanonicalize (H12AffineFastState.compose env51914 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound51914 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51915 : List Nat := [2,4,8,16,1,16,8,5,0,20,2048,2064,9,2048,0,2,2064,2049,21,1,2048,1,17,2,9,17,2048,2064,2064,2049,20,1,4,0,2049,0]

theorem envBound51915 : H12AffineFastState.Bounded env51915 := by
  intro p hp
  have h : env51915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51914_51915 : H12AffineEnvironment.transform 8 0 env51914 = env51915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env51914 == env51915) = true)

theorem identity51915 : scanCanonicalize (H12AffineFastState.compose env51915 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound51915 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51916 : List Nat := [2,4,8,5,1,5,8,5,0,1,2048,2053,9,2048,0,2,2053,2049,0,1,2048,1,4,2,9,4,2048,2053,2053,2049,1,1,4,0,2049,0]

theorem envBound51916 : H12AffineFastState.Bounded env51916 := by
  intro p hp
  have h : env51916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51915_51916 : H12AffineEnvironment.transform 3 5 env51915 = env51916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env51915 == env51916) = true)

def leafEnv51916 : List Nat := [2,4,8,5,1,5,8,5,0,1,2048,2053,9,2048,0,2,2053,2049,0,1,2048,1,4,2,0,9,1,4,2048,2053,2053,2049,1,1,4,0,5,2,2049,0,1,2049,0]

def active51916 : List Nat := [0,1,2,10]

def tree51916 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51916 : H12WitnessSearch.Good tree51916 := H12GlobalWitnessIndex.good

theorem leafIdentity51916 : H12AffineFastState.composeSystem env51916 rootObs = leafEnv51916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51916 rootObs == leafEnv51916) = true)

theorem terminalChecked51916 : H12PackedTerminal.terminalCheckFast leafEnv51916 active51916 tree51916 = true := by decide +kernel

def env51917 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388159,329730,17,41311,8192,65,10588,313700,375166,294913,75103,73770,257,297301,288889,513]

theorem envBound51917 : H12AffineFastState.Bounded env51917 := by
  intro p hp
  have h : env51917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51903_51917 : H12AffineEnvironment.transform 16 16401 env51903 = env51917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env51903 == env51917) = true)

theorem identity51917 : scanCanonicalize (H12AffineFastState.compose env51917 (packedSelected [2,4,6,7,9,11,17,18,23,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound51917 : packedSelected [2,4,6,7,9,11,17,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env51918 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,16401,262144,1025,32769,322920,264533,17,41311,8192,65,10588,313700,309289,294913,9224,8573,257,297301,288889,513]

theorem envBound51918 : H12AffineFastState.Bounded env51918 := by
  intro p hp
  have h : env51918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51917_51918 : H12AffineEnvironment.transform 15 343 env51917 = env51918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env51917 == env51918) = true)

theorem identity51918 : scanCanonicalize (H12AffineFastState.compose env51918 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound51918 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env51919 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,16401,43049,1025,32769,17729,41340,17,41311,8192,65,10588,24909,4096,10280,9224,8573,257,8572,49232,513]

theorem envBound51919 : H12AffineFastState.Bounded env51919 := by
  intro p hp
  have h : env51919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51918_51919 : H12AffineEnvironment.transform 17 43049 env51918 = env51919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env51918 == env51919) = true)

theorem identity51919 : scanCanonicalize (H12AffineFastState.compose env51919 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound51919 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env51920 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,343,16401,10280,1025,0,17729,8573,17,8542,8192,65,10588,24909,4096,10280,9224,8573,257,8572,16465,513]

theorem envBound51920 : H12AffineFastState.Bounded env51920 := by
  intro p hp
  have h : env51920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51919_51920 : H12AffineEnvironment.transform 14 1 env51919 = env51920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env51919 == env51920) = true)

theorem identity51920 : scanCanonicalize (H12AffineFastState.compose env51920 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

end H12CloudChart1