import H12CloudChart1Data044

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env11248 : List Nat := [2,4,8,16,32,64,8,117,512,21,635,17,40,1,1,34,16,635,20,0,32,32,16,2,40,65,635,17,17,635,53,32,116,32,80,513]

theorem envBound11248 : H12AffineFastState.Bounded env11248 := by
  intro p hp
  have h : env11248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11247_11248 : H12AffineEnvironment.transform 9 21 env11247 = env11248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env11247 == env11248) = true)

theorem identity11248 : scanCanonicalize (H12AffineFastState.compose env11248 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11248 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11249 : List Nat := [2,4,8,16,32,16,8,37,512,21,555,17,40,1,1,34,16,555,20,0,32,32,16,2,40,17,555,17,17,555,53,32,36,32,0,513]

theorem envBound11249 : H12AffineFastState.Bounded env11249 := by
  intro p hp
  have h : env11249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11248_11249 : H12AffineEnvironment.transform 5 16 env11248 = env11249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11248 == env11249) = true)

def env11250 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8193,65,29616168,18973700,10507601,8579112,25265169,23160136,257,27378724,27337992,25207630]

theorem envBound11250 : H12AffineFastState.Bounded env11250 := by
  intro p hp
  have h : env11250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11212_11250 : H12AffineEnvironment.transform 6 9 env11212 = env11250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11212 == env11250) = true)

theorem identity11250 : scanCanonicalize (H12AffineFastState.compose env11250 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 8429903) := by decide +kernel

theorem selectedBound11250 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env11251 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,8429903,8193,65,4409703,10560843,10507601,8579112,75102,14795783,257,2188651,2196551,513]

theorem envBound11251 : H12AffineFastState.Bounded env11251 := by
  intro p hp
  have h : env11251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11250_11251 : H12AffineEnvironment.transform 23 8429903 env11250 = env11251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8429903 env11250 == env11251) = true)

def env11252 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,2155532,2114883,8193,65,4409703,115015,45405,2231332,75102,4268043,257,2188651,2196551,513]

theorem envBound11252 : H12AffineFastState.Bounded env11252 := by
  intro p hp
  have h : env11252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11251_11252 : H12AffineEnvironment.transform 22 2155532 env11251 = env11252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2155532 env11251 == env11252) = true)

def env11253 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155532,2114883,8193,65,215367,115015,45405,2231332,75102,73771,257,2188651,2196551,513]

theorem envBound11253 : H12AffineFastState.Bounded env11253 := by
  intro p hp
  have h : env11253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11252_11253 : H12AffineEnvironment.transform 21 32 env11252 = env11253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env11252 == env11253) = true)

theorem identity11253 : scanCanonicalize (H12AffineFastState.compose env11253 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound11253 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11254 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,32,73755,98644,8193,65,215367,115015,45405,247859,75102,73771,257,41340,16464,513]

theorem envBound11254 : H12AffineFastState.Bounded env11254 := by
  intro p hp
  have h : env11254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11253_11254 : H12AffineEnvironment.transform 20 115735 env11253 = env11254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env11253 == env11254) = true)

theorem identity11254 : scanCanonicalize (H12AffineFastState.compose env11254 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound11254 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env11255 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,115735,32,73755,98644,8193,65,67927,115015,45405,100387,75102,73771,257,41340,16464,513]

theorem envBound11255 : H12AffineFastState.Bounded env11255 := by
  intro p hp
  have h : env11255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11254_11255 : H12AffineEnvironment.transform 16 16400 env11254 = env11255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env11254 == env11255) = true)

theorem identity11255 : scanCanonicalize (H12AffineFastState.compose env11255 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11255 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env11256 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1025,32769,58397,32,17,41310,8193,65,10589,57677,45405,43049,1364,33,257,41340,16464,513]

theorem envBound11256 : H12AffineFastState.Bounded env11256 := by
  intro p hp
  have h : env11256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11255_11256 : H12AffineEnvironment.transform 15 8202 env11255 = env11256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11255 == env11256) = true)

theorem identity11256 : scanCanonicalize (H12AffineFastState.compose env11256 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound11256 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env11257 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,8202,16400,10280,1025,81,25677,32,17,8462,8193,65,10589,24861,12557,10361,1364,33,257,8492,16464,513]

theorem envBound11257 : H12AffineFastState.Bounded env11257 := by
  intro p hp
  have h : env11257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11256_11257 : H12AffineEnvironment.transform 14 80 env11256 = env11257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env11256 == env11257) = true)

theorem identity11257 : scanCanonicalize (H12AffineFastState.compose env11257 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound11257 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env11258 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,80,342,16400,2420,1025,81,17681,32,17,82,349,65,2049,16449,4177,2341,1364,33,257,112,16464,513]

theorem envBound11258 : H12AffineFastState.Bounded env11258 := by
  intro p hp
  have h : env11258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11257_11258 : H12AffineEnvironment.transform 12 348 env11257 = env11258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env11257 == env11258) = true)

theorem identity11258 : scanCanonicalize (H12AffineFastState.compose env11258 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11258 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11259 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,263,16400,2341,1025,0,17681,32,17,3,268,16,2049,16400,4096,2341,1285,33,257,33,16385,513]

theorem envBound11259 : H12AffineFastState.Bounded env11259 := by
  intro p hp
  have h : env11259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11258_11259 : H12AffineEnvironment.transform 5 17 env11258 = env11259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11258 == env11259) = true)

theorem identity11259 : scanCanonicalize (H12AffineFastState.compose env11259 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11259 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11260 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,269,16384,1,263,16400,2308,1025,0,17681,1,17,3,268,16,2049,16400,4096,2308,1285,0,257,0,16385,513]

theorem envBound11260 : H12AffineFastState.Bounded env11260 := by
  intro p hp
  have h : env11260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11259_11260 : H12AffineEnvironment.transform 4 1 env11259 = env11260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11259 == env11260) = true)

theorem identity11260 : scanCanonicalize (H12AffineFastState.compose env11260 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound11260 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11261 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,17,269,16384,1,263,16400,2308,1025,0,17681,1,17,3,268,16,2049,16400,17,2308,1285,0,257,0,16385,513]

theorem envBound11261 : H12AffineFastState.Bounded env11261 := by
  intro p hp
  have h : env11261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11260_11261 : H12AffineEnvironment.transform 11 17 env11260 = env11261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env11260 == env11261) = true)

theorem identity11261 : scanCanonicalize (H12AffineFastState.compose env11261 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 1808) := by decide +kernel

theorem selectedBound11261 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11262 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,17,269,1808,1,263,1792,2308,1025,0,513,1,17,3,268,16,2049,1792,17,2308,1285,0,257,0,1809,513]

theorem envBound11262 : H12AffineFastState.Bounded env11262 := by
  intro p hp
  have h : env11262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11261_11262 : H12AffineEnvironment.transform 13 1808 env11261 = env11262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1808 env11261 == env11262) = true)

theorem identity11262 : scanCanonicalize (H12AffineFastState.compose env11262 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound11262 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11263 : List Nat := [2,4,8,16,1,17,9,256,512,1024,528,17,269,1808,1,263,1792,788,1025,0,513,1,17,3,268,16,529,1792,17,788,1285,0,257,0,1809,513]

theorem envBound11263 : H12AffineFastState.Bounded env11263 := by
  intro p hp
  have h : env11263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11262_11263 : H12AffineEnvironment.transform 10 528 env11262 = env11263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env11262 == env11263) = true)

theorem identity11263 : scanCanonicalize (H12AffineFastState.compose env11263 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound11263 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11264 : List Nat := [2,4,8,16,1,17,9,256,512,257,528,17,269,529,1,263,513,788,256,0,513,1,17,3,268,16,529,513,17,788,4,0,257,0,528,513]

theorem envBound11264 : H12AffineFastState.Bounded env11264 := by
  intro p hp
  have h : env11264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11263_11264 : H12AffineEnvironment.transform 9 257 env11263 = env11264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env11263 == env11264) = true)

theorem identity11264 : scanCanonicalize (H12AffineFastState.compose env11264 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound11264 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env11265 : List Nat := [2,4,8,16,1,17,9,256,261,257,277,17,269,276,1,263,260,17,256,0,260,1,17,3,268,16,276,260,17,17,4,0,257,0,277,260]

theorem envBound11265 : H12AffineFastState.Bounded env11265 := by
  intro p hp
  have h : env11265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11264_11265 : H12AffineEnvironment.transform 8 261 env11264 = env11265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env11264 == env11265) = true)

def env11266 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,33,2155532,2114883,8193,65,215366,115015,45405,2231332,75102,73770,257,2188651,2196551,513]

theorem envBound11266 : H12AffineFastState.Bounded env11266 := by
  intro p hp
  have h : env11266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11252_11266 : H12AffineEnvironment.transform 21 33 env11252 = env11266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env11252 == env11266) = true)

theorem identity11266 : scanCanonicalize (H12AffineFastState.compose env11266 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11266 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11267 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10280,1025,32769,2097152,33,2155532,2114883,8193,65,158028,57677,45405,2231332,1364,32,257,2114913,2139213,513]

theorem envBound11267 : H12AffineFastState.Bounded env11267 := by
  intro p hp
  have h : env11267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11266_11267 : H12AffineEnvironment.transform 15 8202 env11266 = env11267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11266 == env11267) = true)

theorem identity11267 : scanCanonicalize (H12AffineFastState.compose env11267 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(20+1) ^^^ 173148) := by decide +kernel

theorem selectedBound11267 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env11268 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10280,1025,32769,173148,33,147536,188703,8193,65,158028,57677,45405,43128,1364,32,257,188733,131089,513]

theorem envBound11268 : H12AffineFastState.Bounded env11268 := by
  intro p hp
  have h : env11268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11267_11268 : H12AffineEnvironment.transform 20 173148 env11267 = env11268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 173148 env11267 == env11268) = true)

theorem identity11268 : scanCanonicalize (H12AffineFastState.compose env11268 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound11268 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env11269 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,24909,10280,1025,32769,50449,33,8477,32850,8193,65,2049,57677,45405,43128,1364,32,257,32880,24924,513]

theorem envBound11269 : H12AffineFastState.Bounded env11269 := by
  intro p hp
  have h : env11269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11268_11269 : H12AffineEnvironment.transform 16 24909 env11268 = env11269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env11268 == env11269) = true)

theorem identity11269 : scanCanonicalize (H12AffineFastState.compose env11269 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound11269 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11270 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,32768,262,16449,2340,1025,32769,50449,33,17,32850,269,65,2049,49217,36945,35188,1364,32,257,32880,16464,513]

theorem envBound11270 : H12AffineFastState.Bounded env11270 := by
  intro p hp
  have h : env11270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11269_11270 : H12AffineEnvironment.transform 12 268 env11269 = env11270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env11269 == env11270) = true)

theorem identity11270 : scanCanonicalize (H12AffineFastState.compose env11270 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound11270 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env11271 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,1,262,16449,2340,1025,0,17680,33,17,83,269,65,2049,16448,4176,2421,1364,32,257,113,16464,513]

theorem envBound11271 : H12AffineFastState.Bounded env11271 := by
  intro p hp
  have h : env11271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11270_11271 : H12AffineEnvironment.transform 14 1 env11270 = env11271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env11270 == env11271) = true)

theorem identity11271 : scanCanonicalize (H12AffineFastState.compose env11271 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11271 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11272 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,1,262,16400,2340,1025,0,17680,33,17,2,269,16,2049,16401,4097,2340,1285,32,257,32,16385,513]

theorem envBound11272 : H12AffineFastState.Bounded env11272 := by
  intro p hp
  have h : env11272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11271_11272 : H12AffineEnvironment.transform 5 17 env11271 = env11272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11271 == env11272) = true)

theorem identity11272 : scanCanonicalize (H12AffineFastState.compose env11272 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound11272 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11273 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,4112,1,262,4096,2340,1025,0,5376,33,17,2,269,16,2049,4097,4097,2340,1285,32,257,32,4113,513]

theorem envBound11273 : H12AffineFastState.Bounded env11273 := by
  intro p hp
  have h : env11273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11272_11273 : H12AffineEnvironment.transform 13 4112 env11272 = env11273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env11272 == env11273) = true)

theorem identity11273 : scanCanonicalize (H12AffineFastState.compose env11273 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound11273 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11274 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,309,268,293,1,262,309,2340,1025,0,1077,33,17,2,269,16,2049,308,308,2340,1285,32,257,32,292,513]

theorem envBound11274 : H12AffineFastState.Bounded env11274 := by
  intro p hp
  have h : env11274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11273_11274 : H12AffineEnvironment.transform 11 309 env11273 = env11274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env11273 == env11274) = true)

theorem identity11274 : scanCanonicalize (H12AffineFastState.compose env11274 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11274 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11275 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,17,40,1,1,34,17,2048,1025,0,1077,33,17,2,41,16,2049,16,16,2048,1057,32,37,32,0,513]

theorem envBound11275 : H12AffineFastState.Bounded env11275 := by
  intro p hp
  have h : env11275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11274_11275 : H12AffineEnvironment.transform 7 36 env11274 = env11275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11274 == env11275) = true)

theorem identity11275 : scanCanonicalize (H12AffineFastState.compose env11275 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound11275 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11276 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1077,17,40,1,1,34,17,1077,1025,0,1077,33,17,2,41,16,1076,16,16,1077,1057,32,37,32,0,513]

theorem envBound11276 : H12AffineFastState.Bounded env11276 := by
  intro p hp
  have h : env11276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11275_11276 : H12AffineEnvironment.transform 10 1077 env11275 = env11276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env11275 == env11276) = true)

def env11277 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,2155533,2114882,8193,65,4409703,115014,45404,2231333,75102,4268042,257,2188651,2196551,513]

theorem envBound11277 : H12AffineFastState.Bounded env11277 := by
  intro p hp
  have h : env11277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11251_11277 : H12AffineEnvironment.transform 22 2155533 env11251 = env11277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2155533 env11251 == env11277) = true)

def env11278 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155533,2114882,8193,65,215367,115014,45404,2231333,75102,73770,257,2188651,2196551,513]

theorem envBound11278 : H12AffineFastState.Bounded env11278 := by
  intro p hp
  have h : env11278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11277_11278 : H12AffineEnvironment.transform 21 32 env11277 = env11278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env11277 == env11278) = true)

def env11279 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155533,2114834,8193,17,215319,114966,45324,2231333,75022,73770,257,2188603,2196503,513]

theorem envBound11279 : H12AffineFastState.Bounded env11279 := by
  intro p hp
  have h : env11279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11278_11279 : H12AffineEnvironment.transform 5 16 env11278 = env11279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11278 == env11279) = true)

theorem identity11279 : scanCanonicalize (H12AffineFastState.compose env11279 (packedSelected [14,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 58396) := by decide +kernel

theorem selectedBound11279 : packedSelected [14,16,18] rootPS < 2^1333 := by decide +kernel

def env11280 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,58396,32,17,41230,8193,17,215319,114966,45324,190521,75022,73770,257,98599,90123,513]

theorem envBound11280 : H12AffineFastState.Bounded env11280 := by
  intro p hp
  have h : env11280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11279_11280 : H12AffineEnvironment.transform 20 58396 env11279 = env11280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env11279 == env11280) = true)

theorem identity11280 : scanCanonicalize (H12AffineFastState.compose env11280 (packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound11280 : packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env11281 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10280,1025,32769,58396,32,17,41230,8193,17,190748,24861,45324,190521,34053,32801,257,8492,49152,513]

theorem envBound11281 : H12AffineFastState.Bounded env11281 := by
  intro p hp
  have h : env11281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11280_11281 : H12AffineEnvironment.transform 15 40971 env11280 = env11281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env11280 == env11281) = true)

theorem identity11281 : scanCanonicalize (H12AffineFastState.compose env11281 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound11281 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env11282 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40971,16400,10280,1025,32769,58396,32,17,41230,8193,17,43276,24861,45324,43049,34053,32801,257,8492,49152,513]

theorem envBound11282 : H12AffineFastState.Bounded env11282 := by
  intro p hp
  have h : env11282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11281_11282 : H12AffineEnvironment.transform 16 16400 env11281 = env11282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env11281 == env11282) = true)

theorem identity11282 : scanCanonicalize (H12AffineFastState.compose env11282 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound11282 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11283 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,263,16400,10280,1025,8461,17680,32,17,2,8193,17,2048,24861,4096,2341,9225,8493,257,8492,24844,513]

theorem envBound11283 : H12AffineFastState.Bounded env11283 := by
  intro p hp
  have h : env11283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11282_11283 : H12AffineEnvironment.transform 14 8460 env11282 = env11283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env11282 == env11283) = true)

theorem identity11283 : scanCanonicalize (H12AffineFastState.compose env11283 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11283 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11284 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,263,16400,2341,1025,0,17680,32,17,2,268,17,2048,16400,4096,2341,1284,32,257,33,16385,513]

theorem envBound11284 : H12AffineFastState.Bounded env11284 := by
  intro p hp
  have h : env11284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11283_11284 : H12AffineEnvironment.transform 12 269 env11283 = env11284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11283 == env11284) = true)

theorem identity11284 : scanCanonicalize (H12AffineFastState.compose env11284 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound11284 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11285 : List Nat := [2,4,8,16,32,16,9,256,512,21,2048,4096,269,16384,1,263,16400,2341,20,0,16645,32,17,2,268,17,2048,16400,4096,2341,273,32,257,33,16385,513]

theorem envBound11285 : H12AffineFastState.Bounded env11285 := by
  intro p hp
  have h : env11285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11284_11285 : H12AffineEnvironment.transform 9 21 env11284 = env11285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env11284 == env11285) = true)

theorem identity11285 : scanCanonicalize (H12AffineFastState.compose env11285 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound11285 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11286 : List Nat := [2,4,8,16,32,16,9,256,512,21,2048,4096,269,4373,1,263,4357,2341,20,0,4112,32,17,2,268,17,2048,4357,4096,2341,273,32,257,33,4372,513]

theorem envBound11286 : H12AffineFastState.Bounded env11286 := by
  intro p hp
  have h : env11286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11285_11286 : H12AffineEnvironment.transform 13 4373 env11285 = env11286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env11285 == env11286) = true)

theorem identity11286 : scanCanonicalize (H12AffineFastState.compose env11286 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound11286 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11287 : List Nat := [2,4,8,16,32,16,9,256,512,21,2048,561,269,804,1,263,820,2341,20,0,545,32,17,2,268,17,2048,820,561,2341,273,32,257,33,805,513]

theorem envBound11287 : H12AffineFastState.Bounded env11287 := by
  intro p hp
  have h : env11287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11286_11287 : H12AffineEnvironment.transform 11 561 env11286 = env11287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env11286 == env11287) = true)

theorem identity11287 : scanCanonicalize (H12AffineFastState.compose env11287 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound11287 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11288 : List Nat := [2,4,8,16,32,16,9,256,512,21,821,561,269,804,1,263,820,528,20,0,545,32,17,2,268,17,821,820,561,528,273,32,257,33,805,513]

theorem envBound11288 : H12AffineFastState.Bounded env11288 := by
  intro p hp
  have h : env11288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11287_11288 : H12AffineEnvironment.transform 10 821 env11287 = env11288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env11287 == env11288) = true)

theorem identity11288 : scanCanonicalize (H12AffineFastState.compose env11288 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11288 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11289 : List Nat := [2,4,8,16,32,16,9,36,512,21,529,561,41,512,1,35,528,528,20,0,545,32,17,2,40,17,529,528,561,528,53,32,37,33,513,513]

theorem envBound11289 : H12AffineFastState.Bounded env11289 := by
  intro p hp
  have h : env11289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11288_11289 : H12AffineEnvironment.transform 7 36 env11288 = env11289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11288 == env11289) = true)

theorem identity11289 : scanCanonicalize (H12AffineFastState.compose env11289 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11289 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env11290 : List Nat := [2,4,8,16,0,16,9,4,512,21,529,529,9,512,1,3,528,528,20,0,513,0,17,2,8,17,529,528,529,528,21,0,5,1,513,513]

theorem envBound11290 : H12AffineFastState.Bounded env11290 := by
  intro p hp
  have h : env11290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11289_11290 : H12AffineEnvironment.transform 4 0 env11289 = env11290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11289 == env11290) = true)

theorem identity11290 : scanCanonicalize (H12AffineFastState.compose env11290 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11290 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11291 : List Nat := [2,4,3,16,0,16,2,4,512,21,529,529,2,512,1,3,528,528,20,0,513,0,17,2,3,17,529,528,529,528,21,0,5,1,513,513]

theorem envBound11291 : H12AffineFastState.Bounded env11291 := by
  intro p hp
  have h : env11291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11290_11291 : H12AffineEnvironment.transform 2 3 env11290 = env11291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11290 == env11291) = true)

def env11292 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,32,2155533,2114835,8193,16,215318,114967,45325,2231333,75023,73770,257,2188602,2196502,513]

theorem envBound11292 : H12AffineFastState.Bounded env11292 := by
  intro p hp
  have h : env11292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11278_11292 : H12AffineEnvironment.transform 5 17 env11278 = env11292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11278 == env11292) = true)

theorem identity11292 : scanCanonicalize (H12AffineFastState.compose env11292 (packedSelected [14,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound11292 : packedSelected [14,16,18] rootPS < 2^1333 := by decide +kernel

def env11293 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,33030,131072,10280,1025,32769,2097152,32,2155533,2114835,8193,16,182288,16401,45325,2231333,41993,41260,257,2155580,2098448,513]

theorem envBound11293 : H12AffineFastState.Bounded env11293 := by
  intro p hp
  have h : env11293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11292_11293 : H12AffineEnvironment.transform 15 33030 env11292 = env11293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env11292 == env11293) = true)

theorem identity11293 : scanCanonicalize (H12AffineFastState.compose env11293 (packedSelected [11,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11293 : packedSelected [11,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env11294 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,33030,131072,2341,1025,32769,2097152,32,2147584,2114835,268,16,182288,16401,36864,2231333,34052,32801,257,2147633,2098448,513]

theorem envBound11294 : H12AffineFastState.Bounded env11294 := by
  intro p hp
  have h : env11294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11293_11294 : H12AffineEnvironment.transform 12 269 env11293 = env11294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11293 == env11294) = true)

theorem identity11294 : scanCanonicalize (H12AffineFastState.compose env11294 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound11294 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env11295 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,263,131072,2341,1025,0,2097152,32,2114817,2114835,268,16,149521,16401,4097,2231333,1285,32,257,2114864,2098448,513]

theorem envBound11295 : H12AffineFastState.Bounded env11295 := by
  intro p hp
  have h : env11295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11294_11295 : H12AffineEnvironment.transform 14 1 env11294 = env11295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env11294 == env11295) = true)

def env11296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,33,2155533,2114882,8193,65,215366,115014,45404,2231333,75102,73771,257,2188651,2196551,513]

theorem envBound11296 : H12AffineFastState.Bounded env11296 := by
  intro p hp
  have h : env11296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11277_11296 : H12AffineEnvironment.transform 21 33 env11277 = env11296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env11277 == env11296) = true)

theorem identity11296 : scanCanonicalize (H12AffineFastState.compose env11296 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 58396) := by decide +kernel

theorem selectedBound11296 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11297 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,58396,33,17,41310,8193,65,215366,115014,45404,190521,75102,73771,257,98679,90203,513]

theorem envBound11297 : H12AffineFastState.Bounded env11297 := by
  intro p hp
  have h : env11297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11296_11297 : H12AffineEnvironment.transform 20 58396 env11296 = env11297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env11296 == env11297) = true)

theorem identity11297 : scanCanonicalize (H12AffineFastState.compose env11297 (packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound11297 : packedSelected [0,1,3,5,7,8,10,11,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env11298 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,58396,33,17,41310,8193,65,67926,115014,45404,43049,75102,73771,257,98679,90203,513]

theorem envBound11298 : H12AffineFastState.Bounded env11298 := by
  intro p hp
  have h : env11298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11297_11298 : H12AffineEnvironment.transform 16 16400 env11297 = env11298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env11297 == env11298) = true)

theorem identity11298 : scanCanonicalize (H12AffineFastState.compose env11298 (packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound11298 : packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env11299 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8282,16400,10280,1025,32769,58396,33,17,41310,8193,65,10508,57628,45404,43049,1284,113,257,41261,16385,513]

theorem envBound11299 : H12AffineFastState.Bounded env11299 := by
  intro p hp
  have h : env11299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11298_11299 : H12AffineEnvironment.transform 15 8282 env11298 = env11299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env11298 == env11299) = true)

theorem identity11299 : scanCanonicalize (H12AffineFastState.compose env11299 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound11299 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env11300 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,8282,16400,10280,1025,81,25676,33,17,8462,8193,65,10508,24908,12556,10361,1284,113,257,8573,16385,513]

theorem envBound11300 : H12AffineFastState.Bounded env11300 := by
  intro p hp
  have h : env11300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11299_11300 : H12AffineEnvironment.transform 14 80 env11299 = env11300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env11299 == env11300) = true)

theorem identity11300 : scanCanonicalize (H12AffineFastState.compose env11300 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound11300 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11301 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,80,262,16400,2420,1025,81,17680,33,17,82,349,65,2128,16400,4176,2341,1284,113,257,33,16385,513]

theorem envBound11301 : H12AffineFastState.Bounded env11301 := by
  intro p hp
  have h : env11301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11300_11301 : H12AffineEnvironment.transform 12 348 env11300 = env11301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env11300 == env11301) = true)

def env11302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254785,92374096,145662400,525568,140903597,27337992,25733062]

theorem envBound11302 : H12AffineFastState.Bounded env11302 := by
  intro p hp
  have h : env11302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9918_11302 : H12AffineEnvironment.transform 29 155254785 env9918 = env11302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env9918 == env11302) = true)

def env11303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254785,25265168,145662400,525568,140903597,27337992,25733062]

theorem envBound11303 : H12AffineFastState.Bounded env11303 := by
  intro p hp
  have h : env11303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11302_11303 : H12AffineEnvironment.transform 25 64 env11302 = env11303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env11302 == env11303) = true)

def env11304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356289,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound11304 : H12AffineFastState.Bounded env11304 := by
  intro p hp
  have h : env11304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11303_11304 : H12AffineEnvironment.transform 26 30393344 env11303 = env11304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env11303 == env11304) = true)

def env11305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound11305 : H12AffineFastState.Bounded env11305 := by
  intro p hp
  have h : env11305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11304_11305 : H12AffineEnvironment.transform 18 1024 env11304 = env11305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env11304 == env11305) = true)

theorem identity11305 : scanCanonicalize (H12AffineFastState.compose env11305 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10577240) := by decide +kernel

theorem selectedBound11305 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env11306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10577240,8328,64,6727000,8446420,10507600,8830977,2154824,12583064,256,41461,16464,2213534]

theorem envBound11306 : H12AffineFastState.Bounded env11306 := by
  intro p hp
  have h : env11306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11305_11306 : H12AffineEnvironment.transform 23 10577240 env11305 = env11306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10577240 env11305 == env11306) = true)

def env11307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,4194304,8388608,10577240,8328,64,6705548,8393984,10507600,8795349,2102684,12583064,256,21793,16464,2175562]

theorem envBound11307 : H12AffineFastState.Bounded env11307 := by
  intro p hp
  have h : env11307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11306_11307 : H12AffineEnvironment.transform 14 29908 env11306 = env11307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env11306 == env11307) = true)

def env11308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,272512,8388608,10577240,8328,64,2259212,8393984,10507600,8795349,2102684,8661016,256,21793,16464,2175562]

theorem envBound11308 : H12AffineFastState.Bounded env11308 := by
  intro p hp
  have h : env11308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11307_11308 : H12AffineEnvironment.transform 21 272512 env11307 = env11308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env11307 == env11308) = true)

def env11309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1024,8661,2097152,272512,8388608,10563672,8328,64,2239500,8393984,10485840,8795349,2102684,8661016,256,33,5456,2175562]

theorem envBound11309 : H12AffineFastState.Bounded env11309 := by
  intro p hp
  have h : env11309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11308_11309 : H12AffineEnvironment.transform 13 5376 env11308 = env11309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11308 == env11309) = true)

def env11310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1024,8661,2097152,32,8388608,10563672,8328,64,2239500,8393984,10485840,8526965,2102684,8388792,256,33,5456,2175562]

theorem envBound11310 : H12AffineFastState.Bounded env11310 := by
  intro p hp
  have h : env11310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11309_11310 : H12AffineEnvironment.transform 17 10400 env11309 = env11310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env11309 == env11310) = true)

theorem identity11310 : scanCanonicalize (H12AffineFastState.compose env11310 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 78018) := by decide +kernel

theorem selectedBound11310 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1024,8661,78018,32,8388608,8388762,8328,64,203982,8393984,8466578,8526965,75102,8388792,256,33,5456,648]

theorem envBound11311 : H12AffineFastState.Bounded env11311 := by
  intro p hp
  have h : env11311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11310_11311 : H12AffineEnvironment.transform 20 78018 env11310 = env11311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78018 env11310 == env11311) = true)

theorem identity11311 : scanCanonicalize (H12AffineFastState.compose env11311 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11311 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env11312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1024,8540,77899,32,8388608,8388627,8193,64,203847,8393984,8466459,8526965,75102,8388657,256,33,5456,513]

theorem envBound11312 : H12AffineFastState.Bounded env11312 := by
  intro p hp
  have h : env11312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11311_11312 : H12AffineEnvironment.transform 6 9 env11311 = env11312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11311 == env11312) = true)

theorem identity11312 : scanCanonicalize (H12AffineFastState.compose env11312 (packedSelected [0,1,7,8,10,11,12,16,18] rootPS)) = affineNative (2^(22+1) ^^^ 210266) := by decide +kernel

theorem selectedBound11312 : packedSelected [0,1,7,8,10,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env11313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1024,8540,77899,32,210266,210249,8193,64,203847,204890,132417,76079,75102,210283,256,33,5456,513]

theorem envBound11313 : H12AffineFastState.Bounded env11313 := by
  intro p hp
  have h : env11313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11312_11313 : H12AffineEnvironment.transform 22 210266 env11312 = env11313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 210266 env11312 == env11313) = true)

theorem identity11313 : scanCanonicalize (H12AffineFastState.compose env11313 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound11313 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env11314 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,70678,10281,1024,8540,77899,32,8524,8543,8193,64,2129,13388,69975,76079,75102,8573,256,33,5456,513]

theorem envBound11314 : H12AffineFastState.Bounded env11314 := by
  intro p hp
  have h : env11314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11313_11314 : H12AffineEnvironment.transform 16 70678 env11313 = env11314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env11313 == env11314) = true)

theorem identity11314 : scanCanonicalize (H12AffineFastState.compose env11314 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11314 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env11315 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8203,13341,10281,1024,8540,4160,32,8524,8543,8193,64,2129,13388,12636,2340,1365,8573,256,33,5456,513]

theorem envBound11315 : H12AffineFastState.Bounded env11315 := by
  intro p hp
  have h : env11315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11314_11315 : H12AffineEnvironment.transform 15 8203 env11314 = env11315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11314 == env11315) = true)

theorem identity11315 : scanCanonicalize (H12AffineFastState.compose env11315 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound11315 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env11316 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,343,5441,2421,1024,0,4160,32,16,3,349,64,2129,5392,4096,2340,1365,33,256,33,5456,513]

theorem envBound11316 : H12AffineFastState.Bounded env11316 := by
  intro p hp
  have h : env11316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11315_11316 : H12AffineEnvironment.transform 12 348 env11315 = env11316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env11315 == env11316) = true)

theorem identity11316 : scanCanonicalize (H12AffineFastState.compose env11316 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound11316 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env11317 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,348,3344,1,343,3409,2421,1024,0,2128,32,16,3,349,64,2129,3328,2064,2340,1365,33,256,33,3392,513]

theorem envBound11317 : H12AffineFastState.Bounded env11317 := by
  intro p hp
  have h : env11317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11316_11317 : H12AffineEnvironment.transform 11 2064 env11316 = env11317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env11316 == env11317) = true)

theorem identity11317 : scanCanonicalize (H12AffineFastState.compose env11317 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound11317 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11318 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2064,41,3173,1,34,3108,2048,1024,0,2128,32,16,3,40,64,2129,3189,2064,2129,1056,33,117,33,3125,513]

theorem envBound11318 : H12AffineFastState.Bounded env11318 := by
  intro p hp
  have h : env11318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11317_11318 : H12AffineEnvironment.transform 7 117 env11317 = env11318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env11317 == env11318) = true)

theorem identity11318 : scanCanonicalize (H12AffineFastState.compose env11318 (packedSelected [0,3,4,5,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11318 : packedSelected [0,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env11319 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,2064,41,3125,1,34,3108,2048,1024,0,2048,32,16,3,40,16,2049,3109,2064,2049,1056,33,37,33,3125,513]

theorem envBound11319 : H12AffineFastState.Bounded env11319 := by
  intro p hp
  have h : env11319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11318_11319 : H12AffineEnvironment.transform 5 16 env11318 = env11319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11318 == env11319) = true)

theorem identity11319 : scanCanonicalize (H12AffineFastState.compose env11319 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound11319 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11320 : List Nat := [2,4,8,16,32,16,9,37,512,1024,0,16,41,1077,1,34,1060,0,1024,0,0,32,16,3,40,16,1,1061,16,1,1056,33,37,33,1077,513]

theorem envBound11320 : H12AffineFastState.Bounded env11320 := by
  intro p hp
  have h : env11320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11319_11320 : H12AffineEnvironment.transform 10 0 env11319 = env11320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11319 == env11320) = true)

theorem identity11320 : scanCanonicalize (H12AffineFastState.compose env11320 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound11320 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11321 : List Nat := [2,4,8,16,32,16,9,37,10,1024,0,16,41,1077,1,34,1060,0,1024,0,0,32,16,3,40,16,1,1061,16,1,1056,33,37,33,1077,11]

theorem envBound11321 : H12AffineFastState.Bounded env11321 := by
  intro p hp
  have h : env11321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11320_11321 : H12AffineEnvironment.transform 8 10 env11320 = env11321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env11320 == env11321) = true)

theorem identity11321 : scanCanonicalize (H12AffineFastState.compose env11321 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 57) := by decide +kernel

theorem selectedBound11321 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env11322 : List Nat := [2,4,8,16,32,16,9,37,10,57,0,16,41,12,1,34,29,0,57,0,0,32,16,3,40,16,1,28,16,1,25,33,37,33,12,11]

theorem envBound11322 : H12AffineFastState.Bounded env11322 := by
  intro p hp
  have h : env11322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11321_11322 : H12AffineEnvironment.transform 9 57 env11321 = env11322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 57 env11321 == env11322) = true)

theorem identity11322 : scanCanonicalize (H12AffineFastState.compose env11322 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound11322 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11323 : List Nat := [2,4,8,16,13,16,9,8,10,20,0,16,4,12,1,15,29,0,20,0,0,13,16,3,5,16,1,28,16,1,25,12,8,12,12,11]

theorem envBound11323 : H12AffineFastState.Bounded env11323 := by
  intro p hp
  have h : env11323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11322_11323 : H12AffineEnvironment.transform 4 13 env11322 = env11323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env11322 == env11323) = true)

theorem identity11323 : scanCanonicalize (H12AffineFastState.compose env11323 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound11323 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11324 : List Nat := [2,4,8,8,13,8,9,8,10,12,0,8,4,12,1,15,5,0,12,0,0,13,8,3,5,8,1,4,8,1,1,12,8,12,12,11]

theorem envBound11324 : H12AffineFastState.Bounded env11324 := by
  intro p hp
  have h : env11324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11323_11324 : H12AffineEnvironment.transform 3 8 env11323 = env11324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env11323 == env11324) = true)

theorem identity11324 : scanCanonicalize (H12AffineFastState.compose env11324 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound11324 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11325 : List Nat := [2,4,4,4,1,4,5,4,6,0,0,4,4,0,1,3,5,0,0,0,0,1,4,3,5,4,1,4,4,1,1,0,4,0,0,7]

theorem envBound11325 : H12AffineFastState.Bounded env11325 := by
  intro p hp
  have h : env11325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11324_11325 : H12AffineEnvironment.transform 2 4 env11324 = env11325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env11324 == env11325) = true)

def env11326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10401,1024,8661,2097152,33,8388608,10563672,8328,64,2239500,8393984,10485840,8526964,2102684,8388793,256,33,5456,2175562]

theorem envBound11326 : H12AffineFastState.Bounded env11326 := by
  intro p hp
  have h : env11326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11309_11326 : H12AffineEnvironment.transform 17 10401 env11309 = env11326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env11309 == env11326) = true)

theorem identity11326 : scanCanonicalize (H12AffineFastState.compose env11326 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 2175186) := by decide +kernel

theorem selectedBound11326 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10401,1024,8661,2097152,33,2175186,138,8328,64,2239500,2172370,77954,2305190,2102684,2175083,256,33,5456,2175562]

theorem envBound11327 : H12AffineFastState.Bounded env11327 := by
  intro p hp
  have h : env11327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11326_11327 : H12AffineEnvironment.transform 22 2175186 env11326 = env11327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2175186 env11326 == env11327) = true)

theorem identity11327 : scanCanonicalize (H12AffineFastState.compose env11327 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound11327 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env11328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10401,1024,8661,77899,33,153,138,8328,64,203847,5529,77954,138477,75223,32,256,33,5456,513]

theorem envBound11328 : H12AffineFastState.Bounded env11328 := by
  intro p hp
  have h : env11328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11327_11328 : H12AffineEnvironment.transform 20 77899 env11327 = env11328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env11327 == env11328) = true)

theorem identity11328 : scanCanonicalize (H12AffineFastState.compose env11328 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound11328 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,79131,10401,1024,8661,77899,33,153,138,8328,64,10588,5529,77954,76278,75223,32,256,33,5456,513]

theorem envBound11329 : H12AffineFastState.Bounded env11329 := by
  intro p hp
  have h : env11329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11328_11329 : H12AffineEnvironment.transform 16 79131 env11328 = env11329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env11328 == env11329) = true)

theorem identity11329 : scanCanonicalize (H12AffineFastState.compose env11329 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 9618) := by decide +kernel

theorem selectedBound11329 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env11330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,9618,4233,10401,1024,8661,5593,33,153,138,8328,64,10588,5529,5392,3172,69,32,256,33,5456,513]

theorem envBound11330 : H12AffineFastState.Bounded env11330 := by
  intro p hp
  have h : env11330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11329_11330 : H12AffineEnvironment.transform 15 9618 env11329 = env11330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9618 env11329 == env11330) = true)

theorem identity11330 : scanCanonicalize (H12AffineFastState.compose env11330 (packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound11330 : packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS < 2^1333 := by decide +kernel

def env11331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2200,8192,3480,8660,9618,2065,10401,1024,8661,3393,33,153,138,8328,64,10588,3329,3464,3172,69,32,256,33,3528,513]

theorem envBound11331 : H12AffineFastState.Bounded env11331 := by
  intro p hp
  have h : env11331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11330_11331 : H12AffineEnvironment.transform 11 2200 env11330 = env11331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env11330 == env11331) = true)

theorem identity11331 : scanCanonicalize (H12AffineFastState.compose env11331 (packedSelected [0,1,3,4,5,7,8,9,11,12,14,18] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound11331 : packedSelected [0,1,3,4,5,7,8,9,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env11332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1124,1276,8192,508,8660,9618,1141,9413,1024,8661,293,33,153,138,8328,64,9528,357,492,0,69,32,256,33,428,513]

theorem envBound11332 : H12AffineFastState.Bounded env11332 := by
  intro p hp
  have h : env11332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11331_11332 : H12AffineEnvironment.transform 10 1124 env11331 = env11332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env11331 == env11332) = true)

theorem identity11332 : scanCanonicalize (H12AffineFastState.compose env11332 (packedSelected [0,1,8,10,14,15,27] rootPS)) = affineNative (2^(12+1) ^^^ 1505) := by decide +kernel

theorem selectedBound11332 : packedSelected [0,1,8,10,14,15,27] rootPS < 2^1333 := by decide +kernel

def env11333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1124,1276,1505,508,1077,115,1141,292,1024,1076,293,33,153,138,1385,64,217,357,492,0,69,32,256,33,428,513]

theorem envBound11333 : H12AffineFastState.Bounded env11333 := by
  intro p hp
  have h : env11333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11332_11333 : H12AffineEnvironment.transform 12 1505 env11332 = env11333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1505 env11332 == env11333) = true)

theorem identity11333 : scanCanonicalize (H12AffineFastState.compose env11333 (packedSelected [0,1,2,3,5,6,7,8,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound11333 : packedSelected [0,1,2,3,5,6,7,8,11,14] rootPS < 2^1333 := by decide +kernel

def env11334 : List Nat := [2,4,8,16,32,64,128,256,512,272,372,492,241,508,293,115,357,292,272,292,293,33,153,138,121,64,217,357,492,0,69,32,256,33,428,513]

theorem envBound11334 : H12AffineFastState.Bounded env11334 := by
  intro p hp
  have h : env11334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11333_11334 : H12AffineEnvironment.transform 9 272 env11333 = env11334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env11333 == env11334) = true)

theorem identity11334 : scanCanonicalize (H12AffineFastState.compose env11334 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11334 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11335 : List Nat := [2,4,8,16,32,64,9,256,512,272,372,357,120,373,293,115,357,292,272,292,293,33,16,3,121,64,80,357,357,0,69,32,256,33,293,513]

theorem envBound11335 : H12AffineFastState.Bounded env11335 := by
  intro p hp
  have h : env11335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11334_11335 : H12AffineEnvironment.transform 6 9 env11334 = env11335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11334 == env11335) = true)

theorem identity11335 : scanCanonicalize (H12AffineFastState.compose env11335 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound11335 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11336 : List Nat := [2,4,8,16,32,1,9,256,512,272,309,292,57,308,293,50,292,292,272,292,293,33,16,3,56,1,17,292,292,0,4,32,256,33,293,513]

theorem envBound11336 : H12AffineFastState.Bounded env11336 := by
  intro p hp
  have h : env11336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11335_11336 : H12AffineEnvironment.transform 5 1 env11335 = env11336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env11335 == env11336) = true)

theorem identity11336 : scanCanonicalize (H12AffineFastState.compose env11336 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11336 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11337 : List Nat := [2,4,8,16,0,1,9,256,512,272,277,260,25,276,261,18,260,260,272,260,261,1,16,3,24,1,17,260,260,0,4,0,256,1,261,513]

theorem envBound11337 : H12AffineFastState.Bounded env11337 := by
  intro p hp
  have h : env11337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11336_11337 : H12AffineEnvironment.transform 4 0 env11336 = env11337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11336 == env11337) = true)

theorem identity11337 : scanCanonicalize (H12AffineFastState.compose env11337 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound11337 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11338 : List Nat := [2,4,8,16,0,1,9,20,512,4,1,16,25,0,17,18,16,16,4,16,17,1,16,3,24,1,17,16,16,0,4,0,20,1,17,513]

theorem envBound11338 : H12AffineFastState.Bounded env11338 := by
  intro p hp
  have h : env11338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11337_11338 : H12AffineEnvironment.transform 7 20 env11337 = env11338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env11337 == env11338) = true)

theorem identity11338 : scanCanonicalize (H12AffineFastState.compose env11338 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11338 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11339 : List Nat := [2,4,8,1,0,1,9,5,512,4,1,1,8,0,0,3,1,1,4,1,0,1,1,3,9,1,0,1,1,0,4,0,5,1,0,513]

theorem envBound11339 : H12AffineFastState.Bounded env11339 := by
  intro p hp
  have h : env11339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11338_11339 : H12AffineEnvironment.transform 3 1 env11338 = env11339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11338 == env11339) = true)

theorem identity11339 : scanCanonicalize (H12AffineFastState.compose env11339 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound11339 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11340 : List Nat := [2,4,8,1,0,1,9,5,1,4,1,1,8,0,0,3,1,1,4,1,0,1,1,3,9,1,0,1,1,0,4,0,5,1,0,0]

theorem envBound11340 : H12AffineFastState.Bounded env11340 := by
  intro p hp
  have h : env11340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11339_11340 : H12AffineEnvironment.transform 8 1 env11339 = env11340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env11339 == env11340) = true)

def env11341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1024,8660,2097152,272512,8388608,10563673,8328,64,2239501,8393984,10485841,8795349,2102684,8661016,256,32,5457,2175562]

theorem envBound11341 : H12AffineFastState.Bounded env11341 := by
  intro p hp
  have h : env11341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11308_11341 : H12AffineEnvironment.transform 13 5377 env11308 = env11341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env11308 == env11341) = true)

def env11342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10400,1024,8660,2097152,32,8388608,10563673,8328,64,2239501,8393984,10485841,8526965,2102684,8388792,256,32,5457,2175562]

theorem envBound11342 : H12AffineFastState.Bounded env11342 := by
  intro p hp
  have h : env11342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11341_11342 : H12AffineEnvironment.transform 17 10400 env11341 = env11342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env11341 == env11342) = true)

theorem identity11342 : scanCanonicalize (H12AffineFastState.compose env11342 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound11342 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10400,1024,8660,77899,32,8388608,8388626,8328,64,203846,8393984,8466458,8526965,75223,8388792,256,32,5457,513]

theorem envBound11343 : H12AffineFastState.Bounded env11343 := by
  intro p hp
  have h : env11343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11342_11343 : H12AffineEnvironment.transform 20 77899 env11342 = env11343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env11342 == env11343) = true)

def env11344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,2049,8661,65536,131072,10400,1024,8660,77131,32,8388608,8388626,8328,64,196934,8390656,8465690,8520053,75223,8388792,256,32,2129,513]

theorem envBound11344 : H12AffineFastState.Bounded env11344 := by
  intro p hp
  have h : env11344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11343_11344 : H12AffineEnvironment.transform 11 3328 env11343 = env11344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env11343 == env11344) = true)

theorem identity11344 : scanCanonicalize (H12AffineFastState.compose env11344 (packedSelected [0,3,4,5,7,9,11,12,14,18,19] rootPS)) = affineNative (2^(22+1) ^^^ 65815) := by decide +kernel

theorem selectedBound11344 : packedSelected [0,3,4,5,7,9,11,12,14,18,19] rootPS < 2^1333 := by decide +kernel

def env11345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,2049,8661,65536,131072,10400,1024,8660,77131,32,65815,65797,8328,64,196934,67863,11277,196706,75223,65967,256,32,2129,513]

theorem envBound11345 : H12AffineFastState.Bounded env11345 := by
  intro p hp
  have h : env11345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11344_11345 : H12AffineEnvironment.transform 22 65815 env11344 = env11345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 65815 env11344 == env11345) = true)

theorem identity11345 : scanCanonicalize (H12AffineFastState.compose env11345 (packedSelected [1,2,3,6,7,11,16,20,24,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 2112) := by decide +kernel

theorem selectedBound11345 : packedSelected [1,2,3,6,7,11,16,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env11346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,2049,8661,65536,2112,10400,1024,8660,77131,32,65815,65797,8328,64,67846,67863,11277,67618,75223,65967,256,32,2129,513]

theorem envBound11346 : H12AffineFastState.Bounded env11346 := by
  intro p hp
  have h : env11346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11345_11346 : H12AffineEnvironment.transform 16 2112 env11345 = env11346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2112 env11345 == env11346) = true)

theorem identity11346 : scanCanonicalize (H12AffineFastState.compose env11346 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound11346 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env11347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,2049,8661,479,2112,10400,1024,8660,11412,32,200,218,8328,64,2265,2248,11277,2557,9224,112,256,32,2129,513]

theorem envBound11347 : H12AffineFastState.Bounded env11347 := by
  intro p hp
  have h : env11347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11346_11347 : H12AffineEnvironment.transform 15 479 env11346 = env11347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env11346 == env11347) = true)

theorem identity11347 : scanCanonicalize (H12AffineFastState.compose env11347 (packedSelected [0,7,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 1173) := by decide +kernel

theorem selectedBound11347 : packedSelected [0,7,12,14] rootPS < 2^1333 := by decide +kernel

def env11348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,1173,2049,1344,479,2112,3125,1024,1345,2049,32,200,218,1053,64,2265,2248,2200,2557,157,112,256,32,2129,513]

theorem envBound11348 : H12AffineFastState.Bounded env11348 := by
  intro p hp
  have h : env11348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11347_11348 : H12AffineEnvironment.transform 12 1173 env11347 = env11348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1173 env11347 == env11348) = true)

theorem identity11348 : scanCanonicalize (H12AffineFastState.compose env11348 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11348 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env11349 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3328,1173,2049,1297,398,2065,3125,1024,1296,2049,32,153,139,1053,17,2184,2201,2200,2476,157,33,256,32,2048,513]

theorem envBound11349 : H12AffineFastState.Bounded env11349 := by
  intro p hp
  have h : env11349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11348_11349 : H12AffineEnvironment.transform 5 17 env11348 = env11349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11348 == env11349) = true)

theorem identity11349 : scanCanonicalize (H12AffineFastState.compose env11349 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound11349 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env11350 : List Nat := [2,4,8,16,32,17,128,256,512,189,2048,2493,40,2049,428,398,2065,2184,189,429,2049,32,153,139,160,17,2184,2201,2200,2476,157,33,256,32,2048,513]

theorem envBound11350 : H12AffineFastState.Bounded env11350 := by
  intro p hp
  have h : env11350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11349_11350 : H12AffineEnvironment.transform 9 189 env11349 = env11350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env11349 == env11350) = true)

theorem identity11350 : scanCanonicalize (H12AffineFastState.compose env11350 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11350 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env11351 : List Nat := [2,4,8,16,32,17,128,36,512,189,2048,2201,40,2049,136,170,2065,2184,189,137,2049,32,153,139,160,17,2184,2201,2200,2184,157,33,36,32,2048,513]

theorem envBound11351 : H12AffineFastState.Bounded env11351 := by
  intro p hp
  have h : env11351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11350_11351 : H12AffineEnvironment.transform 7 36 env11350 = env11351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11350 == env11351) = true)

theorem identity11351 : scanCanonicalize (H12AffineFastState.compose env11351 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound11351 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env11352 : List Nat := [2,4,8,16,32,17,128,36,512,189,16,137,40,17,136,170,1,152,189,137,17,32,153,139,160,17,152,137,136,152,157,33,36,32,16,513]

theorem envBound11352 : H12AffineFastState.Bounded env11352 := by
  intro p hp
  have h : env11352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11351_11352 : H12AffineEnvironment.transform 10 16 env11351 = env11352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env11351 == env11352) = true)

theorem identity11352 : scanCanonicalize (H12AffineFastState.compose env11352 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11352 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11353 : List Nat := [2,4,8,16,32,17,9,36,512,52,16,0,40,17,1,35,1,17,52,0,17,32,16,2,41,17,17,0,1,17,20,33,36,32,16,513]

theorem envBound11353 : H12AffineFastState.Bounded env11353 := by
  intro p hp
  have h : env11353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11352_11353 : H12AffineEnvironment.transform 6 9 env11352 = env11353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11352 == env11353) = true)

theorem identity11353 : scanCanonicalize (H12AffineFastState.compose env11353 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound11353 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11354 : List Nat := [2,4,8,16,32,17,9,36,0,52,16,0,40,17,1,35,1,17,52,0,17,32,16,2,41,17,17,0,1,17,20,33,36,32,16,1]

theorem envBound11354 : H12AffineFastState.Bounded env11354 := by
  intro p hp
  have h : env11354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11353_11354 : H12AffineEnvironment.transform 8 0 env11353 = env11354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env11353 == env11354) = true)

theorem identity11354 : scanCanonicalize (H12AffineFastState.compose env11354 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound11354 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11355 : List Nat := [2,4,8,16,11,17,9,15,0,31,16,0,3,17,1,8,1,17,31,0,17,11,16,2,2,17,17,0,1,17,20,10,15,11,16,1]

theorem envBound11355 : H12AffineFastState.Bounded env11355 := by
  intro p hp
  have h : env11355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11354_11355 : H12AffineEnvironment.transform 4 11 env11354 = env11355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env11354 == env11355) = true)

theorem identity11355 : scanCanonicalize (H12AffineFastState.compose env11355 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11355 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11356 : List Nat := [2,4,8,0,11,1,9,15,0,15,0,0,3,1,1,8,1,1,15,0,1,11,0,2,2,1,1,0,1,1,4,10,15,11,0,1]

theorem envBound11356 : H12AffineFastState.Bounded env11356 := by
  intro p hp
  have h : env11356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11355_11356 : H12AffineEnvironment.transform 3 0 env11355 = env11356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11355 == env11356) = true)

def env11357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3329,8192,2048,8661,65536,131072,10400,1024,8660,77130,32,8388608,8388626,8328,64,196935,8390657,8465691,8520052,75223,8388792,256,32,2128,513]

theorem envBound11357 : H12AffineFastState.Bounded env11357 := by
  intro p hp
  have h : env11357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11343_11357 : H12AffineEnvironment.transform 11 3329 env11343 = env11357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env11343 == env11357) = true)

theorem identity11357 : scanCanonicalize (H12AffineFastState.compose env11357 (packedSelected [0,3,4,5,7,9,11,12,14,18,19] rootPS)) = affineNative (2^(22+1) ^^^ 65950) := by decide +kernel

theorem selectedBound11357 : packedSelected [0,3,4,5,7,9,11,12,14,18,19] rootPS < 2^1333 := by decide +kernel

def env11358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3329,8192,2048,8661,65536,131072,10400,1024,8660,77130,32,65950,65932,8328,64,196935,67999,11397,196842,75223,65830,256,32,2128,513]

theorem envBound11358 : H12AffineFastState.Bounded env11358 := by
  intro p hp
  have h : env11358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11357_11358 : H12AffineEnvironment.transform 22 65950 env11357 = env11358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 65950 env11357 == env11358) = true)

theorem identity11358 : scanCanonicalize (H12AffineFastState.compose env11358 (packedSelected [1,2,4,5,6,8,9,11,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound11358 : packedSelected [1,2,4,5,6,8,9,11,16,20,24] rootPS < 2^1333 := by decide +kernel

def env11359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3329,8192,2048,8661,479,131072,10400,1024,8660,11413,32,65,83,8328,64,131224,2112,11397,131381,9224,249,256,32,2128,513]

theorem envBound11359 : H12AffineFastState.Bounded env11359 := by
  intro p hp
  have h : env11359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11358_11359 : H12AffineEnvironment.transform 15 479 env11358 = env11359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env11358 == env11359) = true)

theorem identity11359 : scanCanonicalize (H12AffineFastState.compose env11359 (packedSelected [0,1,7,8,10,11,12,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 2113) := by decide +kernel

theorem selectedBound11359 : packedSelected [0,1,7,8,10,11,12,18,20] rootPS < 2^1333 := by decide +kernel

def env11360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3329,8192,2048,8661,479,2113,10400,1024,8660,11413,32,65,83,8328,64,2265,2112,11397,2420,9224,249,256,32,2128,513]

theorem envBound11360 : H12AffineFastState.Bounded env11360 := by
  intro p hp
  have h : env11360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11359_11360 : H12AffineEnvironment.transform 16 2113 env11359 = env11360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2113 env11359 == env11360) = true)

theorem identity11360 : scanCanonicalize (H12AffineFastState.compose env11360 (packedSelected [0,2,4,6,7,9,11,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound11360 : packedSelected [0,2,4,6,7,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env11361 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,2065,8192,2048,8661,479,2113,10400,272,8660,10629,32,65,83,8328,64,2265,2112,10645,2420,8472,249,256,32,2128,513]

theorem envBound11361 : H12AffineFastState.Bounded env11361 := by
  intro p hp
  have h : env11361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11360_11361 : H12AffineEnvironment.transform 9 272 env11360 = env11361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env11360 == env11361) = true)

theorem identity11361 : scanCanonicalize (H12AffineFastState.compose env11361 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11361 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env11362 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,2065,8192,2048,8580,398,2064,10400,272,8581,10629,32,16,2,8328,17,2184,2065,10645,2341,8472,168,256,32,2049,513]

theorem envBound11362 : H12AffineFastState.Bounded env11362 := by
  intro p hp
  have h : env11362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11361_11362 : H12AffineEnvironment.transform 5 17 env11361 = env11362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11361 == env11362) = true)

theorem identity11362 : scanCanonicalize (H12AffineFastState.compose env11362 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound11362 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env11363 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,2065,268,2048,136,398,2064,2476,272,137,2185,32,16,2,388,17,2184,2065,2201,2341,20,168,256,32,2049,513]

theorem envBound11363 : H12AffineFastState.Bounded env11363 := by
  intro p hp
  have h : env11363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11362_11363 : H12AffineEnvironment.transform 12 268 env11362 = env11363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env11362 == env11363) = true)

theorem identity11363 : scanCanonicalize (H12AffineFastState.compose env11363 (packedSelected [0,1,3,4,5,7,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11363 : packedSelected [0,1,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env11364 : List Nat := [2,4,8,1,32,0,128,256,512,257,2048,2048,268,2048,136,398,2049,2476,257,137,2185,32,1,2,388,0,2184,2048,2184,2341,5,168,256,32,2049,513]

theorem envBound11364 : H12AffineFastState.Bounded env11364 := by
  intro p hp
  have h : env11364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11363_11364 : H12AffineEnvironment.transform 3 1 env11363 = env11364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11363 == env11364) = true)

theorem identity11364 : scanCanonicalize (H12AffineFastState.compose env11364 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound11364 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env11365 : List Nat := [2,4,8,1,32,0,128,256,512,257,1,1,268,1,136,398,0,429,257,137,136,32,1,2,388,0,137,1,137,292,5,168,256,32,0,513]

theorem envBound11365 : H12AffineFastState.Bounded env11365 := by
  intro p hp
  have h : env11365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11364_11365 : H12AffineEnvironment.transform 10 1 env11364 = env11365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11364 == env11365) = true)

theorem identity11365 : scanCanonicalize (H12AffineFastState.compose env11365 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound11365 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env11366 : List Nat := [2,4,8,1,32,0,128,172,512,173,1,1,160,1,136,34,0,1,173,137,136,32,1,2,40,0,137,1,137,136,5,168,172,32,0,513]

theorem envBound11366 : H12AffineFastState.Bounded env11366 := by
  intro p hp
  have h : env11366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11365_11366 : H12AffineEnvironment.transform 7 172 env11365 = env11366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env11365 == env11366) = true)

theorem identity11366 : scanCanonicalize (H12AffineFastState.compose env11366 (packedSelected [12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11366 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env11367 : List Nat := [2,4,8,1,32,0,9,37,512,36,1,1,41,1,1,34,0,1,36,0,1,32,1,2,40,0,0,1,0,1,5,33,37,32,0,513]

theorem envBound11367 : H12AffineFastState.Bounded env11367 := by
  intro p hp
  have h : env11367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11366_11367 : H12AffineEnvironment.transform 6 9 env11366 = env11367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11366 == env11367) = true)

def env11368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10401,1024,8660,2097152,33,8388608,10563673,8328,64,2239501,8393984,10485841,8526964,2102684,8388793,256,32,5457,2175562]

theorem envBound11368 : H12AffineFastState.Bounded env11368 := by
  intro p hp
  have h : env11368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11341_11368 : H12AffineEnvironment.transform 17 10401 env11341 = env11368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env11341 == env11368) = true)

theorem identity11368 : scanCanonicalize (H12AffineFastState.compose env11368 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 2175067) := by decide +kernel

theorem selectedBound11368 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10401,1024,8660,2097152,33,2175067,2,8328,64,2239501,2172251,77834,2305071,2102684,2175202,256,32,5457,2175562]

theorem envBound11369 : H12AffineFastState.Bounded env11369 := by
  intro p hp
  have h : env11369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11368_11369 : H12AffineEnvironment.transform 22 2175067 env11368 = env11369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2175067 env11368 == env11369) = true)

theorem identity11369 : scanCanonicalize (H12AffineFastState.compose env11369 (packedSelected [1,11,18,19,23,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound11369 : packedSelected [1,11,18,19,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env11370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10401,1024,8660,4161,33,73754,2,8328,64,146508,79130,77834,212078,1501,73891,256,32,5457,74251]

theorem envBound11370 : H12AffineFastState.Bounded env11370 := by
  intro p hp
  have h : env11370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11369_11370 : H12AffineEnvironment.transform 20 4161 env11369 = env11370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env11369 == env11370) = true)

theorem identity11370 : scanCanonicalize (H12AffineFastState.compose env11370 (packedSelected [0,2,3,4,9,10,14,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 295) := by decide +kernel

theorem selectedBound11370 : packedSelected [0,2,3,4,9,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env11371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,295,131072,10401,1024,8660,4161,33,8509,2,8328,64,146508,13373,12589,146761,1501,8580,256,32,5457,9004]

theorem envBound11371 : H12AffineFastState.Bounded env11371 := by
  intro p hp
  have h : env11371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11370_11371 : H12AffineEnvironment.transform 15 295 env11370 = env11371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 295 env11370 == env11371) = true)

theorem identity11371 : scanCanonicalize (H12AffineFastState.compose env11371 (packedSelected [1,4,5,6,8,14,16,19,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 13373) := by decide +kernel

theorem selectedBound11371 : packedSelected [1,4,5,6,8,14,16,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env11372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,295,13373,10401,1024,8660,4161,33,8509,2,8328,64,2161,13373,12589,2420,1501,8580,256,32,5457,9004]

theorem envBound11372 : H12AffineFastState.Bounded env11372 := by
  intro p hp
  have h : env11372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11371_11372 : H12AffineEnvironment.transform 16 13373 env11371 = env11372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13373 env11371 == env11372) = true)

theorem identity11372 : scanCanonicalize (H12AffineFastState.compose env11372 (packedSelected [1,3,4,5,6,8,10,14,16,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound11372 : packedSelected [1,3,4,5,6,8,10,14,16,19,22] rootPS < 2^1333 := by decide +kernel

def env11373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,301,5377,248,295,5392,2444,1024,249,4161,33,16,2,421,64,2161,5392,4096,2420,1501,169,256,32,5457,513]

theorem envBound11373 : H12AffineFastState.Bounded env11373 := by
  intro p hp
  have h : env11373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11372_11373 : H12AffineEnvironment.transform 12 301 env11372 = env11373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env11372 == env11373) = true)

theorem identity11373 : scanCanonicalize (H12AffineFastState.compose env11373 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound11373 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11374 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,301,5377,32,295,5392,2388,1024,33,4161,33,16,2,381,64,2161,5392,4096,2420,1285,113,256,32,5457,513]

theorem envBound11374 : H12AffineFastState.Bounded env11374 := by
  intro p hp
  have h : env11374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11373_11374 : H12AffineEnvironment.transform 6 88 env11373 = env11374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env11373 == env11374) = true)

theorem identity11374 : scanCanonicalize (H12AffineFastState.compose env11374 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound11374 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11375 : List Nat := [2,4,8,16,32,64,88,256,512,101,2048,4096,301,4452,32,295,4469,2388,101,33,4161,33,16,2,381,64,2161,4469,4096,2420,352,113,256,32,4404,513]

theorem envBound11375 : H12AffineFastState.Bounded env11375 := by
  intro p hp
  have h : env11375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11374_11375 : H12AffineEnvironment.transform 9 101 env11374 = env11375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env11374 == env11375) = true)

theorem identity11375 : scanCanonicalize (H12AffineFastState.compose env11375 (packedSelected [3,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound11375 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env11376 : List Nat := [2,4,8,16,32,64,88,116,512,101,2048,4096,89,4112,32,83,4097,2080,101,33,4161,33,16,2,9,64,2161,4097,4096,2048,20,113,116,32,4160,513]

theorem envBound11376 : H12AffineFastState.Bounded env11376 := by
  intro p hp
  have h : env11376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11375_11376 : H12AffineEnvironment.transform 7 116 env11375 = env11376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env11375 == env11376) = true)

theorem identity11376 : scanCanonicalize (H12AffineFastState.compose env11376 (packedSelected [0,2] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound11376 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env11377 : List Nat := [2,4,8,16,32,64,88,116,512,101,2048,2576,89,2560,32,83,2577,2080,101,33,2641,33,16,2,9,64,2161,2577,2576,2048,20,113,116,32,2640,513]

theorem envBound11377 : H12AffineFastState.Bounded env11377 := by
  intro p hp
  have h : env11377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11376_11377 : H12AffineEnvironment.transform 11 2576 env11376 = env11377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env11376 == env11377) = true)

theorem identity11377 : scanCanonicalize (H12AffineFastState.compose env11377 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound11377 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11378 : List Nat := [2,4,8,16,32,64,88,116,90,101,2048,2122,89,2138,32,83,2123,2080,101,33,2059,33,16,2,9,64,2161,2123,2122,2048,20,113,116,32,2058,91]

theorem envBound11378 : H12AffineFastState.Bounded env11378 := by
  intro p hp
  have h : env11378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11377_11378 : H12AffineEnvironment.transform 8 90 env11377 = env11378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env11377 == env11378) = true)

theorem identity11378 : scanCanonicalize (H12AffineFastState.compose env11378 (packedSelected [8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11378 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env11379 : List Nat := [2,4,8,16,32,16,8,36,10,53,2048,2074,9,2058,32,3,2075,2080,53,33,2059,33,16,2,9,16,2081,2075,2074,2048,20,33,36,32,2058,11]

theorem envBound11379 : H12AffineFastState.Bounded env11379 := by
  intro p hp
  have h : env11379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11378_11379 : H12AffineEnvironment.transform 5 16 env11378 = env11379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11378 == env11379) = true)

theorem identity11379 : scanCanonicalize (H12AffineFastState.compose env11379 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound11379 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11380 : List Nat := [2,4,8,16,32,16,8,36,10,53,42,48,9,32,32,3,49,10,53,33,33,33,16,2,9,16,11,49,48,42,20,33,36,32,32,11]

theorem envBound11380 : H12AffineFastState.Bounded env11380 := by
  intro p hp
  have h : env11380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11379_11380 : H12AffineEnvironment.transform 10 42 env11379 = env11380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env11379 == env11380) = true)

theorem identity11380 : scanCanonicalize (H12AffineFastState.compose env11380 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11380 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11381 : List Nat := [2,4,8,0,32,0,8,36,10,37,42,32,9,32,32,3,33,10,37,33,33,33,0,2,9,0,11,33,32,42,4,33,36,32,32,11]

theorem envBound11381 : H12AffineFastState.Bounded env11381 := by
  intro p hp
  have h : env11381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11380_11381 : H12AffineEnvironment.transform 3 0 env11380 = env11381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11380 == env11381) = true)

theorem identity11381 : scanCanonicalize (H12AffineFastState.compose env11381 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11381 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env11382 : List Nat := [2,4,8,0,10,0,8,14,10,15,0,10,9,10,10,3,11,10,15,11,11,11,0,2,9,0,11,11,10,0,4,11,14,10,10,11]

theorem envBound11382 : H12AffineFastState.Bounded env11382 := by
  intro p hp
  have h : env11382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11381_11382 : H12AffineEnvironment.transform 4 10 env11381 = env11382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11381 == env11382) = true)

def env11383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,272513,8388608,10577240,8328,64,2259213,8393984,10507600,8795349,2102684,8661017,256,21793,16464,2175562]

theorem envBound11383 : H12AffineFastState.Bounded env11383 := by
  intro p hp
  have h : env11383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11307_11383 : H12AffineEnvironment.transform 21 272513 env11307 = env11383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env11307 == env11383) = true)

theorem identity11383 : scanCanonicalize (H12AffineFastState.compose env11383 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound11383 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,272513,16,2188616,8328,64,2259213,5392,2118976,406725,2102684,272393,256,21793,16464,2175562]

theorem envBound11384 : H12AffineFastState.Bounded env11384 := by
  intro p hp
  have h : env11384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11383_11384 : H12AffineEnvironment.transform 22 16 env11383 = env11384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env11383 == env11384) = true)

def env11385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1024,8661,2097152,272513,16,2175048,8328,64,2239501,5392,2097216,406725,2102684,272393,256,33,5456,2175562]

theorem envBound11385 : H12AffineFastState.Bounded env11385 := by
  intro p hp
  have h : env11385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11384_11385 : H12AffineEnvironment.transform 13 5376 env11384 = env11385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11384 == env11385) = true)

theorem identity11385 : scanCanonicalize (H12AffineFastState.compose env11385 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 78018) := by decide +kernel

theorem selectedBound11385 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1024,8661,78018,272513,16,138,8328,64,203983,5392,77954,406725,75102,272393,256,33,5456,648]

theorem envBound11386 : H12AffineFastState.Bounded env11386 := by
  intro p hp
  have h : env11386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11385_11386 : H12AffineEnvironment.transform 20 78018 env11385 = env11386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78018 env11385 == env11386) = true)

theorem identity11386 : scanCanonicalize (H12AffineFastState.compose env11386 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 212031) := by decide +kernel

theorem selectedBound11386 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env11387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,212031,1024,8661,78018,201918,16,138,8328,64,203983,5392,77954,67834,75102,201782,256,33,5456,648]

theorem envBound11387 : H12AffineFastState.Bounded env11387 := by
  intro p hp
  have h : env11387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11386_11387 : H12AffineEnvironment.transform 17 212031 env11386 = env11387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212031 env11386 == env11387) = true)

theorem identity11387 : scanCanonicalize (H12AffineFastState.compose env11387 (packedSelected [1,3,4,8,9,10,11,16,19,20,23,24,31] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11387 : packedSelected [1,3,4,8,9,10,11,16,19,20,23,24,31] rootPS < 2^1333 := by decide +kernel

def env11388 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,65536,131072,212031,1024,8581,77970,201918,16,138,8328,16,203935,5392,77954,67754,75022,201782,256,33,5376,648]

theorem envBound11388 : H12AffineFastState.Bounded env11388 := by
  intro p hp
  have h : env11388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11387_11388 : H12AffineEnvironment.transform 5 16 env11387 = env11388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11387 == env11388) = true)

theorem identity11388 : scanCanonicalize (H12AffineFastState.compose env11388 (packedSelected [2,6,9,10,11,12,15,16,18,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound11388 : packedSelected [2,6,9,10,11,12,15,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env11389 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,8322,131072,138429,1024,8581,4112,144444,16,138,8328,16,146461,5392,4096,10280,1420,144564,256,33,5376,648]

theorem envBound11389 : H12AffineFastState.Bounded env11389 := by
  intro p hp
  have h : env11389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11388_11389 : H12AffineEnvironment.transform 15 8322 env11388 = env11389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env11388 == env11389) = true)

theorem identity11389 : scanCanonicalize (H12AffineFastState.compose env11389 (packedSelected [4,6,9,16] rootPS)) = affineNative (2^(16+1) ^^^ 13372) := by decide +kernel

theorem selectedBound11389 : packedSelected [4,6,9,16] rootPS < 2^1333 := by decide +kernel

def env11390 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,8322,13372,10369,1024,8581,4112,0,16,138,8328,16,2081,5392,4096,10280,1420,136,256,33,5376,648]

theorem envBound11390 : H12AffineFastState.Bounded env11390 := by
  intro p hp
  have h : env11390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11389_11390 : H12AffineEnvironment.transform 16 13372 env11389 = env11390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13372 env11389 == env11390) = true)

theorem identity11390 : scanCanonicalize (H12AffineFastState.compose env11390 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11390 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env11391 : List Nat := [2,4,8,16,1,16,128,256,512,1024,2048,4096,8192,5376,8580,8322,13341,10369,1024,8581,4112,0,16,138,8328,16,2048,5392,4096,10249,1420,136,256,0,5376,648]

theorem envBound11391 : H12AffineFastState.Bounded env11391 := by
  intro p hp
  have h : env11391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11390_11391 : H12AffineEnvironment.transform 4 1 env11390 = env11391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11390 == env11391) = true)

theorem identity11391 : scanCanonicalize (H12AffineFastState.compose env11391 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11391 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11392 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,8192,5376,8460,8202,13341,10249,1024,8461,4112,0,16,2,8192,16,2048,5392,4096,10249,1284,0,256,0,5376,512]

theorem envBound11392 : H12AffineFastState.Bounded env11392 := by
  intro p hp
  have h : env11392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11391_11392 : H12AffineEnvironment.transform 6 8 env11391 = env11392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11391 == env11392) = true)

theorem identity11392 : scanCanonicalize (H12AffineFastState.compose env11392 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound11392 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env11393 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,9,5376,261,3,5140,2048,1024,260,4112,0,16,2,9,16,2048,5392,4096,2048,1284,0,256,0,5376,512]

theorem envBound11393 : H12AffineFastState.Bounded env11393 := by
  intro p hp
  have h : env11393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11392_11393 : H12AffineEnvironment.transform 12 9 env11392 = env11393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env11392 == env11393) = true)

theorem identity11393 : scanCanonicalize (H12AffineFastState.compose env11393 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound11393 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env11394 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,4096,9,4112,261,3,4356,2048,272,260,4112,0,16,2,9,16,2048,4096,4096,2048,20,0,256,0,4112,512]

theorem envBound11394 : H12AffineFastState.Bounded env11394 := by
  intro p hp
  have h : env11394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11393_11394 : H12AffineEnvironment.transform 9 272 env11393 = env11394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env11393 == env11394) = true)

theorem identity11394 : scanCanonicalize (H12AffineFastState.compose env11394 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound11394 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11395 : List Nat := [2,4,8,16,1,16,8,4,512,20,2048,4096,9,4112,1,3,4096,2048,20,0,4112,0,16,2,9,16,2048,4096,4096,2048,20,0,4,0,4112,512]

theorem envBound11395 : H12AffineFastState.Bounded env11395 := by
  intro p hp
  have h : env11395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11394_11395 : H12AffineEnvironment.transform 7 4 env11394 = env11395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env11394 == env11395) = true)

theorem identity11395 : scanCanonicalize (H12AffineFastState.compose env11395 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound11395 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11396 : List Nat := [2,4,8,16,1,16,8,4,512,20,2048,2064,9,2048,1,3,2064,2048,20,0,2048,0,16,2,9,16,2048,2064,2064,2048,20,0,4,0,2048,512]

theorem envBound11396 : H12AffineFastState.Bounded env11396 := by
  intro p hp
  have h : env11396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11395_11396 : H12AffineEnvironment.transform 11 2064 env11395 = env11396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env11395 == env11396) = true)

theorem identity11396 : scanCanonicalize (H12AffineFastState.compose env11396 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound11396 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11397 : List Nat := [2,4,8,16,1,16,8,4,512,20,20,4,9,20,1,3,4,20,20,0,20,0,16,2,9,16,20,4,4,20,20,0,4,0,20,512]

theorem envBound11397 : H12AffineFastState.Bounded env11397 := by
  intro p hp
  have h : env11397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11396_11397 : H12AffineEnvironment.transform 10 20 env11396 = env11397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env11396 == env11397) = true)

theorem identity11397 : scanCanonicalize (H12AffineFastState.compose env11397 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound11397 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11398 : List Nat := [2,4,8,5,1,5,8,4,512,1,1,4,9,1,1,3,4,1,1,0,1,0,5,2,9,5,1,4,4,1,1,0,4,0,1,512]

theorem envBound11398 : H12AffineFastState.Bounded env11398 := by
  intro p hp
  have h : env11398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11397_11398 : H12AffineEnvironment.transform 3 5 env11397 = env11398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env11397 == env11398) = true)

def env11399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1024,8660,2097152,272513,16,2175049,8328,64,2239500,5392,2097217,406725,2102684,272393,256,32,5457,2175562]

theorem envBound11399 : H12AffineFastState.Bounded env11399 := by
  intro p hp
  have h : env11399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11384_11399 : H12AffineEnvironment.transform 13 5377 env11384 = env11399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env11384 == env11399) = true)

theorem identity11399 : scanCanonicalize (H12AffineFastState.compose env11399 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound11399 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1024,8660,77899,272513,16,2,8328,64,203847,5392,77834,406725,75223,272393,256,32,5457,513]

theorem envBound11400 : H12AffineFastState.Bounded env11400 := by
  intro p hp
  have h : env11400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11399_11400 : H12AffineEnvironment.transform 20 77899 env11399 = env11400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env11399 == env11400) = true)

def env11401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77899,272393,16,2,8192,64,203847,5392,77834,406605,75103,272393,256,32,5457,513]

theorem envBound11401 : H12AffineFastState.Bounded env11401 := by
  intro p hp
  have h : env11401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11400_11401 : H12AffineEnvironment.transform 6 8 env11400 = env11401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11400 == env11401) = true)

theorem identity11401 : scanCanonicalize (H12AffineFastState.compose env11401 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound11401 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env11402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,9498,131072,262144,1024,8540,5457,272393,16,2,8192,64,145757,5392,5392,406605,69,272393,256,32,5457,513]

theorem envBound11402 : H12AffineFastState.Bounded env11402 := by
  intro p hp
  have h : env11402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11401_11402 : H12AffineEnvironment.transform 15 9498 env11401 = env11402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env11401 == env11402) = true)

theorem identity11402 : scanCanonicalize (H12AffineFastState.compose env11402 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound11402 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env11403 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,9498,4096,262144,1024,8540,5457,272393,16,2,8192,64,10589,5392,5392,271437,69,272393,256,32,5457,513]

theorem envBound11403 : H12AffineFastState.Bounded env11403 := by
  intro p hp
  have h : env11403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11402_11403 : H12AffineEnvironment.transform 16 4096 env11402 = env11403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env11402 == env11403) = true)

theorem identity11403 : scanCanonicalize (H12AffineFastState.compose env11403 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 11577) := by decide +kernel

theorem selectedBound11403 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env11404 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,9498,4096,11577,1024,8540,5457,1328,16,2,8192,64,10589,5392,5392,2420,69,1328,256,32,5457,513]

theorem envBound11404 : H12AffineFastState.Bounded env11404 := by
  intro p hp
  have h : env11404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11403_11404 : H12AffineEnvironment.transform 17 11577 env11403 = env11404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11577 env11403 == env11404) = true)

theorem identity11404 : scanCanonicalize (H12AffineFastState.compose env11404 (packedSelected [12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound11404 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env11405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,5377,1124,35,4096,2048,1024,1125,5457,1328,16,2,1337,64,3172,5392,5392,2420,69,1328,256,32,5457,513]

theorem envBound11405 : H12AffineFastState.Bounded env11405 := by
  intro p hp
  have h : env11405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11404_11405 : H12AffineEnvironment.transform 12 1337 env11404 = env11405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env11404 == env11405) = true)

theorem identity11405 : scanCanonicalize (H12AffineFastState.compose env11405 (packedSelected [1,3,5,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound11405 : packedSelected [1,3,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env11406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,1337,2341,1124,35,3108,2048,1024,1125,2421,1328,16,2,1337,64,3172,2356,2356,2420,69,1328,256,32,2421,513]

theorem envBound11406 : H12AffineFastState.Bounded env11406 := by
  intro p hp
  have h : env11406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11405_11406 : H12AffineEnvironment.transform 11 3108 env11405 = env11406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env11405 == env11406) = true)

theorem identity11406 : scanCanonicalize (H12AffineFastState.compose env11406 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11406 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env11407 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3108,1052,2048,1124,35,3108,2048,1024,1125,2128,1045,16,2,1052,64,3172,2065,2065,2129,69,1045,37,32,2128,513]

theorem envBound11407 : H12AffineFastState.Bounded env11407 := by
  intro p hp
  have h : env11407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11406_11407 : H12AffineEnvironment.transform 7 37 env11406 = env11407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11406 == env11407) = true)

theorem identity11407 : scanCanonicalize (H12AffineFastState.compose env11407 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11407 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env11408 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3108,1052,2048,1077,35,3108,2048,1024,1076,2049,1045,16,2,1052,17,3125,2065,2065,2048,20,1045,37,32,2049,513]

theorem envBound11408 : H12AffineFastState.Bounded env11408 := by
  intro p hp
  have h : env11408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11407_11408 : H12AffineEnvironment.transform 5 17 env11407 = env11408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11407 == env11408) = true)

theorem identity11408 : scanCanonicalize (H12AffineFastState.compose env11408 (packedSelected [3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound11408 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env11409 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1061,1,1052,1061,1077,35,1,1061,1024,1076,1060,1045,16,2,1052,17,16,1076,1076,1061,20,1045,37,32,1060,513]

theorem envBound11409 : H12AffineFastState.Bounded env11409 := by
  intro p hp
  have h : env11409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11408_11409 : H12AffineEnvironment.transform 10 1061 env11408 = env11409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env11408 == env11409) = true)

theorem identity11409 : scanCanonicalize (H12AffineFastState.compose env11409 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11409 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env11410 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1029,1,1052,1029,1045,3,1,1029,1024,1044,1028,1045,16,2,1052,17,16,1044,1044,1029,20,1045,5,0,1028,513]

theorem envBound11410 : H12AffineFastState.Bounded env11410 := by
  intro p hp
  have h : env11410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11409_11410 : H12AffineEnvironment.transform 4 0 env11409 = env11410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11409 == env11410) = true)

theorem identity11410 : scanCanonicalize (H12AffineFastState.compose env11410 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound11410 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env11411 : List Nat := [2,4,8,16,0,17,8,5,512,4,1,1,24,1,17,3,1,1,4,16,0,17,16,2,24,17,16,16,16,1,20,17,5,0,0,513]

theorem envBound11411 : H12AffineFastState.Bounded env11411 := by
  intro p hp
  have h : env11411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11410_11411 : H12AffineEnvironment.transform 9 4 env11410 = env11411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env11410 == env11411) = true)

theorem identity11411 : scanCanonicalize (H12AffineFastState.compose env11411 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11411 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env11412 : List Nat := [2,4,8,0,0,1,8,5,512,4,1,1,8,1,1,3,1,1,4,0,0,1,0,2,8,1,0,0,0,1,4,1,5,0,0,513]

theorem envBound11412 : H12AffineFastState.Bounded env11412 := by
  intro p hp
  have h : env11412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11411_11412 : H12AffineEnvironment.transform 3 0 env11411 = env11412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11411 == env11412) = true)

theorem identity11412 : scanCanonicalize (H12AffineFastState.compose env11412 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound11412 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11413 : List Nat := [2,4,8,0,0,1,8,5,0,4,1,1,8,1,1,3,1,1,4,0,0,1,0,2,8,1,0,0,0,1,4,1,5,0,0,1]

theorem envBound11413 : H12AffineFastState.Bounded env11413 := by
  intro p hp
  have h : env11413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11412_11413 : H12AffineEnvironment.transform 8 0 env11412 = env11413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env11412 == env11413) = true)

def env11414 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77899,272392,16,2,8193,64,203847,5392,77834,406604,75102,272393,256,32,5457,513]

theorem envBound11414 : H12AffineFastState.Bounded env11414 := by
  intro p hp
  have h : env11414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11400_11414 : H12AffineEnvironment.transform 6 9 env11400 = env11414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11400 == env11414) = true)

theorem identity11414 : scanCanonicalize (H12AffineFastState.compose env11414 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound11414 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env11415 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,70726,262144,1024,8541,77899,272392,16,2,8193,64,2049,5392,77834,335882,75102,272393,256,32,5457,513]

theorem envBound11415 : H12AffineFastState.Bounded env11415 := by
  intro p hp
  have h : env11415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11414_11415 : H12AffineEnvironment.transform 16 70726 env11414 = env11415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env11414 == env11415) = true)

theorem identity11415 : scanCanonicalize (H12AffineFastState.compose env11415 (packedSelected [0,1,4,5,7,8,9,14,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 67699) := by decide +kernel

theorem selectedBound11415 : packedSelected [0,1,4,5,7,8,9,14,18,23,24] rootPS < 2^1333 := by decide +kernel

def env11416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,70726,67699,1024,8541,77899,73851,16,2,8193,64,2049,5392,77834,10361,75102,73850,256,32,5457,513]

theorem envBound11416 : H12AffineFastState.Bounded env11416 := by
  intro p hp
  have h : env11416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11415_11416 : H12AffineEnvironment.transform 17 67699 env11415 = env11416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67699 env11415 == env11416) = true)

theorem identity11416 : scanCanonicalize (H12AffineFastState.compose env11416 (packedSelected [18,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11416 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env11417 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,65536,70679,67618,1024,8460,77850,73770,16,2,8193,17,2049,5392,77834,10280,75023,73771,256,32,5376,513]

theorem envBound11417 : H12AffineFastState.Bounded env11417 := by
  intro p hp
  have h : env11417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11416_11417 : H12AffineEnvironment.transform 5 17 env11416 = env11417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11416 == env11417) = true)

theorem identity11417 : scanCanonicalize (H12AffineFastState.compose env11417 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 6428) := by decide +kernel

theorem selectedBound11417 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env11418 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,6428,5377,6161,65536,70679,67618,1024,6160,67846,71990,16,2,6429,17,2049,5392,67862,4404,72723,71991,256,32,5376,513]

theorem envBound11418 : H12AffineFastState.Bounded env11418 := by
  intro p hp
  have h : env11418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11417_11418 : H12AffineEnvironment.transform 12 6428 env11417 = env11418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6428 env11417 == env11418) = true)

theorem identity11418 : scanCanonicalize (H12AffineFastState.compose env11418 (packedSelected [1,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 4146) := by decide +kernel

theorem selectedBound11418 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env11419 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,6428,5377,6161,4146,1061,6160,1024,6160,6452,2308,16,2,6429,17,2049,5392,6436,4404,3105,2309,256,32,5376,513]

theorem envBound11419 : H12AffineFastState.Bounded env11419 := by
  intro p hp
  have h : env11419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11418_11419 : H12AffineEnvironment.transform 15 4146 env11418 = env11419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4146 env11418 == env11419) = true)

def env11420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,4194304,8388608,10577240,8328,64,6705549,8393985,10507600,8795348,2102685,12583064,256,21792,16464,2175563]

theorem envBound11420 : H12AffineFastState.Bounded env11420 := by
  intro p hp
  have h : env11420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11306_11420 : H12AffineEnvironment.transform 14 29909 env11306 = env11420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env11306 == env11420) = true)

def env11421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,272512,8388608,10577240,8328,64,2259213,8393985,10507600,8795348,2102685,8661016,256,21792,16464,2175563]

theorem envBound11421 : H12AffineFastState.Bounded env11421 := by
  intro p hp
  have h : env11421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11420_11421 : H12AffineEnvironment.transform 21 272512 env11420 = env11421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env11420 == env11421) = true)

theorem identity11421 : scanCanonicalize (H12AffineFastState.compose env11421 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound11421 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,77898,272512,8388608,8410386,8328,64,215367,8393985,8480026,8795348,75223,8661016,256,21792,16464,513]

theorem envBound11422 : H12AffineFastState.Bounded env11422 := by
  intro p hp
  have h : env11422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11421_11422 : H12AffineEnvironment.transform 20 77898 env11421 = env11422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env11421 == env11422) = true)

def env11423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,77898,272392,8388608,8410386,8192,64,215367,8393985,8480026,8795228,75103,8661016,256,21792,16464,513]

theorem envBound11423 : H12AffineFastState.Bounded env11423 := by
  intro p hp
  have h : env11423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11422_11423 : H12AffineEnvironment.transform 6 8 env11422 = env11423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11422 == env11423) = true)

theorem identity11423 : scanCanonicalize (H12AffineFastState.compose env11423 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound11423 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env11424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1024,29788,77898,272392,8388608,8410386,8192,64,10588,8393985,8480026,8737863,75103,8661016,256,21792,16464,513]

theorem envBound11424 : H12AffineFastState.Bounded env11424 := by
  intro p hp
  have h : env11424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11423_11424 : H12AffineEnvironment.transform 16 90139 env11423 = env11424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env11423 == env11424) = true)

def env11425 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1024,29788,77898,272392,16,21762,8192,64,10588,5393,91402,349271,75103,272392,256,21792,16464,513]

theorem envBound11425 : H12AffineFastState.Bounded env11425 := by
  intro p hp
  have h : env11425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11424_11425 : H12AffineEnvironment.transform 22 16 env11424 = env11425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env11424 == env11425) = true)

theorem identity11425 : scanCanonicalize (H12AffineFastState.compose env11425 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound11425 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11426 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,79131,262144,1024,8540,77898,272392,16,2,8192,64,10588,5393,77834,328023,75103,272392,256,32,5456,513]

theorem envBound11426 : H12AffineFastState.Bounded env11426 := by
  intro p hp
  have h : env11426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11425_11426 : H12AffineEnvironment.transform 13 5376 env11425 = env11426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11425 == env11426) = true)

theorem identity11426 : scanCanonicalize (H12AffineFastState.compose env11426 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound11426 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env11427 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,9499,4096,262144,1024,8540,5457,272392,16,2,8192,64,10588,5393,5393,271436,68,272392,256,32,5456,513]

theorem envBound11427 : H12AffineFastState.Bounded env11427 := by
  intro p hp
  have h : env11427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11426_11427 : H12AffineEnvironment.transform 15 9499 env11426 = env11427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env11426 == env11427) = true)

theorem identity11427 : scanCanonicalize (H12AffineFastState.compose env11427 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound11427 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env11428 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,9499,4096,10281,1024,8540,5457,33,16,2,8192,64,10588,5393,5393,3173,68,33,256,32,5456,513]

theorem envBound11428 : H12AffineFastState.Bounded env11428 := by
  intro p hp
  have h : env11428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11427_11428 : H12AffineEnvironment.transform 17 10281 env11427 = env11428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11427 == env11428) = true)

theorem identity11428 : scanCanonicalize (H12AffineFastState.compose env11428 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound11428 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env11429 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,4096,8192,5376,8541,9499,4096,9292,1024,8540,5457,33,16,2,8192,64,9529,5393,5393,0,68,33,256,32,5456,513]

theorem envBound11429 : H12AffineFastState.Bounded env11429 := by
  intro p hp
  have h : env11429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11428_11429 : H12AffineEnvironment.transform 10 1125 env11428 = env11429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env11428 == env11429) = true)

theorem identity11429 : scanCanonicalize (H12AffineFastState.compose env11429 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 5212) := by decide +kernel

theorem selectedBound11429 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env11430 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,4096,5212,5376,5377,4423,4096,4112,1024,5376,5457,33,16,2,5212,64,4453,5393,5393,0,68,33,256,32,5456,513]

theorem envBound11430 : H12AffineFastState.Bounded env11430 := by
  intro p hp
  have h : env11430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11429_11430 : H12AffineEnvironment.transform 12 5212 env11429 = env11430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5212 env11429 == env11430) = true)

theorem identity11430 : scanCanonicalize (H12AffineFastState.compose env11430 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound11430 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env11431 : List Nat := [2,4,8,16,32,0,8,256,512,1024,1061,4096,5148,5376,5377,4359,4096,4112,1024,5376,5393,33,16,2,5148,0,4389,5393,5393,0,4,33,256,32,5392,513]

theorem envBound11431 : H12AffineFastState.Bounded env11431 := by
  intro p hp
  have h : env11431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11430_11431 : H12AffineEnvironment.transform 5 0 env11430 = env11431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env11430 == env11431) = true)

theorem identity11431 : scanCanonicalize (H12AffineFastState.compose env11431 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound11431 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env11432 : List Nat := [2,4,8,16,32,0,8,256,512,1024,1061,1588,552,820,821,1843,1588,1572,1024,820,805,33,16,2,552,0,1809,805,805,0,4,33,256,32,804,513]

theorem envBound11432 : H12AffineFastState.Bounded env11432 := by
  intro p hp
  have h : env11432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11431_11432 : H12AffineEnvironment.transform 11 1588 env11431 = env11432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env11431 == env11432) = true)

theorem identity11432 : scanCanonicalize (H12AffineFastState.compose env11432 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 817) := by decide +kernel

theorem selectedBound11432 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env11433 : List Nat := [2,4,8,16,32,0,8,256,512,817,788,261,552,820,821,2,261,277,817,820,805,33,16,2,552,0,32,805,805,0,4,33,256,32,804,513]

theorem envBound11433 : H12AffineFastState.Bounded env11433 := by
  intro p hp
  have h : env11433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11432_11433 : H12AffineEnvironment.transform 9 817 env11432 = env11433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 817 env11432 == env11433) = true)

theorem identity11433 : scanCanonicalize (H12AffineFastState.compose env11433 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound11433 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env11434 : List Nat := [2,4,8,16,32,0,8,256,33,272,309,261,9,277,276,2,261,277,272,277,260,33,16,2,9,0,32,260,260,0,4,33,256,32,261,32]

theorem envBound11434 : H12AffineFastState.Bounded env11434 := by
  intro p hp
  have h : env11434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11433_11434 : H12AffineEnvironment.transform 8 33 env11433 = env11434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env11433 == env11434) = true)

theorem identity11434 : scanCanonicalize (H12AffineFastState.compose env11434 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11434 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11435 : List Nat := [2,4,8,16,32,0,8,36,33,52,17,33,9,49,48,2,33,49,52,49,32,33,16,2,9,0,32,32,32,0,4,33,36,32,33,32]

theorem envBound11435 : H12AffineFastState.Bounded env11435 := by
  intro p hp
  have h : env11435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11434_11435 : H12AffineEnvironment.transform 7 36 env11434 = env11435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11434 == env11435) = true)

theorem identity11435 : scanCanonicalize (H12AffineFastState.compose env11435 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11435 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11436 : List Nat := [2,4,8,16,0,0,8,4,1,20,17,1,9,17,16,2,1,17,20,17,0,1,16,2,9,0,0,0,0,0,4,1,4,0,1,0]

theorem envBound11436 : H12AffineFastState.Bounded env11436 := by
  intro p hp
  have h : env11436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11435_11436 : H12AffineEnvironment.transform 4 0 env11435 = env11436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11435 == env11436) = true)

theorem identity11436 : scanCanonicalize (H12AffineFastState.compose env11436 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11436 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11437 : List Nat := [2,4,8,1,0,0,8,4,1,5,0,1,9,0,1,2,1,0,5,0,0,1,1,2,9,0,0,0,0,0,4,1,4,0,1,0]

theorem envBound11437 : H12AffineFastState.Bounded env11437 := by
  intro p hp
  have h : env11437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11436_11437 : H12AffineEnvironment.transform 3 1 env11436 = env11437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11436 == env11437) = true)

def env11438 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1024,29788,77898,272392,17,21763,8192,64,10588,5392,91403,349270,75103,272393,256,21792,16464,513]

theorem envBound11438 : H12AffineFastState.Bounded env11438 := by
  intro p hp
  have h : env11438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11424_11438 : H12AffineEnvironment.transform 22 17 env11424 = env11438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env11424 == env11438) = true)

theorem identity11438 : scanCanonicalize (H12AffineFastState.compose env11438 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound11438 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11439 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,32040,1024,29788,77898,21792,17,21763,8192,64,10588,5392,91403,76158,75103,21793,256,21792,16464,513]

theorem envBound11439 : H12AffineFastState.Bounded env11439 := by
  intro p hp
  have h : env11439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11438_11439 : H12AffineEnvironment.transform 17 32040 env11438 = env11439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env11438 == env11439) = true)

theorem identity11439 : scanCanonicalize (H12AffineFastState.compose env11439 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound11439 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env11440 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,29005,65536,90139,30776,272,29004,77898,20528,17,20499,8192,64,10588,4096,90139,76158,73807,20529,256,20528,16464,513]

theorem envBound11440 : H12AffineFastState.Bounded env11440 := by
  intro p hp
  have h : env11440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11439_11440 : H12AffineEnvironment.transform 9 272 env11439 = env11440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env11439 == env11440) = true)

def env11441 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,77898,272393,8388608,8410386,8193,64,215367,8393985,8480026,8795229,75102,8661016,256,21792,16464,513]

theorem envBound11441 : H12AffineFastState.Bounded env11441 := by
  intro p hp
  have h : env11441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11422_11441 : H12AffineEnvironment.transform 6 9 env11422 = env11441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11422 == env11441) = true)

def env11442 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,77898,272393,16,21762,8193,64,215367,5393,91402,406605,75102,272392,256,21792,16464,513]

theorem envBound11442 : H12AffineFastState.Bounded env11442 := by
  intro p hp
  have h : env11442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11441_11442 : H12AffineEnvironment.transform 22 16 env11441 = env11442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env11441 == env11442) = true)

def env11443 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,77898,272393,16,2,8193,64,203847,5393,77834,406605,75102,272392,256,32,5456,513]

theorem envBound11443 : H12AffineFastState.Bounded env11443 := by
  intro p hp
  have h : env11443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11442_11443 : H12AffineEnvironment.transform 13 5376 env11442 = env11443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11442 == env11443) = true)

theorem identity11443 : scanCanonicalize (H12AffineFastState.compose env11443 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound11443 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env11444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,13389,262144,1024,8541,77898,272393,16,2,8193,64,75786,5393,77834,262144,75102,272392,256,32,5456,513]

theorem envBound11444 : H12AffineFastState.Bounded env11444 := by
  intro p hp
  have h : env11444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11443_11444 : H12AffineEnvironment.transform 16 13389 env11443 = env11444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env11443 == env11444) = true)

theorem identity11444 : scanCanonicalize (H12AffineFastState.compose env11444 (packedSelected [0,2,4,6,7,9,14,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound11444 : packedSelected [0,2,4,6,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env11445 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,13389,10281,1024,8541,77898,32,16,2,8193,64,75786,5393,77834,10281,75102,33,256,32,5456,513]

theorem envBound11445 : H12AffineFastState.Bounded env11445 := by
  intro p hp
  have h : env11445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11444_11445 : H12AffineEnvironment.transform 17 10281 env11444 = env11445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11444 == env11445) = true)

theorem identity11445 : scanCanonicalize (H12AffineFastState.compose env11445 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11445 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env11446 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,65536,5392,2420,1024,0,69911,32,16,2,348,64,67927,5393,69975,2420,66563,33,256,32,5456,513]

theorem envBound11446 : H12AffineFastState.Bounded env11446 := by
  intro p hp
  have h : env11446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11445_11446 : H12AffineEnvironment.transform 12 349 env11445 = env11446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11445 == env11446) = true)

theorem identity11446 : scanCanonicalize (H12AffineFastState.compose env11446 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound11446 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11447 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5392,2420,1024,0,4161,32,16,2,348,64,2049,5393,4097,2420,1365,33,256,32,5456,513]

theorem envBound11447 : H12AffineFastState.Bounded env11447 := by
  intro p hp
  have h : env11447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11446_11447 : H12AffineEnvironment.transform 15 342 env11446 = env11447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env11446 == env11447) = true)

theorem identity11447 : scanCanonicalize (H12AffineFastState.compose env11447 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound11447 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11448 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1572,349,804,1,342,820,2420,1024,0,1637,32,16,2,348,64,2049,821,1573,2420,1365,33,256,32,884,513]

theorem envBound11448 : H12AffineFastState.Bounded env11448 := by
  intro p hp
  have h : env11448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11447_11448 : H12AffineEnvironment.transform 11 1572 env11447 = env11448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env11447 == env11448) = true)

theorem identity11448 : scanCanonicalize (H12AffineFastState.compose env11448 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound11448 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1573,1572,349,804,1,342,820,1873,1024,0,1637,32,16,2,348,64,1572,821,1573,1873,1365,33,256,32,884,513]

theorem envBound11449 : H12AffineFastState.Bounded env11449 := by
  intro p hp
  have h : env11449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11448_11449 : H12AffineEnvironment.transform 10 1573 env11448 = env11449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env11448 == env11449) = true)

def env11450 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77898,272393,16,3,8193,64,203846,5393,77835,406605,75102,272392,256,33,5457,513]

theorem envBound11450 : H12AffineFastState.Bounded env11450 := by
  intro p hp
  have h : env11450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11442_11450 : H12AffineEnvironment.transform 13 5377 env11442 = env11450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env11442 == env11450) = true)

theorem identity11450 : scanCanonicalize (H12AffineFastState.compose env11450 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound11450 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env11451 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,79130,262144,1024,8540,77898,272393,16,3,8193,64,10588,5393,77835,328023,75102,272392,256,33,5457,513]

theorem envBound11451 : H12AffineFastState.Bounded env11451 := by
  intro p hp
  have h : env11451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11450_11451 : H12AffineEnvironment.transform 16 79130 env11450 = env11451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env11450 == env11451) = true)

theorem identity11451 : scanCanonicalize (H12AffineFastState.compose env11451 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11451 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env11452 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5392,262144,1024,8540,4160,272393,16,3,8193,64,10588,5393,4097,270685,1364,272392,256,33,5457,513]

theorem envBound11452 : H12AffineFastState.Bounded env11452 := by
  intro p hp
  have h : env11452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11451_11452 : H12AffineEnvironment.transform 15 8202 env11451 = env11452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11451 == env11452) = true)

theorem identity11452 : scanCanonicalize (H12AffineFastState.compose env11452 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11452 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11453 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,8202,5392,262144,1024,8461,4113,272393,16,3,8193,17,10509,5393,4097,270604,1285,272392,256,33,5376,513]

theorem envBound11453 : H12AffineFastState.Bounded env11453 := by
  intro p hp
  have h : env11453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11452_11453 : H12AffineEnvironment.transform 5 17 env11452 = env11453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11452 == env11453) = true)

theorem identity11453 : scanCanonicalize (H12AffineFastState.compose env11453 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound11453 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11454 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,300,5377,32,294,5392,262144,1024,33,4113,264485,16,3,301,17,2081,5393,4097,262176,1285,264484,256,33,5376,513]

theorem envBound11454 : H12AffineFastState.Bounded env11454 := by
  intro p hp
  have h : env11454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11453_11454 : H12AffineEnvironment.transform 12 300 env11453 = env11454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env11453 == env11454) = true)

theorem identity11454 : scanCanonicalize (H12AffineFastState.compose env11454 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11454 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11455 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,9,5156,32,3,5173,262144,1024,33,4113,264192,16,3,8,17,2081,5172,4097,262176,1056,264193,37,33,5157,513]

theorem envBound11455 : H12AffineFastState.Bounded env11455 := by
  intro p hp
  have h : env11455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11454_11455 : H12AffineEnvironment.transform 7 37 env11454 = env11455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11454 == env11455) = true)

theorem identity11455 : scanCanonicalize (H12AffineFastState.compose env11455 (packedSelected [14] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound11455 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env11456 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,9,5156,32,3,5173,2080,1024,33,4113,32,16,3,8,17,2081,5172,4097,2048,1056,33,37,33,5157,513]

theorem envBound11456 : H12AffineFastState.Bounded env11456 := by
  intro p hp
  have h : env11456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11455_11456 : H12AffineEnvironment.transform 17 2080 env11455 = env11456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env11455 == env11456) = true)

theorem identity11456 : scanCanonicalize (H12AffineFastState.compose env11456 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound11456 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11457 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1076,4096,9,5156,32,3,5173,1044,1024,33,4113,32,16,3,8,17,1045,5172,4097,1076,1056,33,37,33,5157,513]

theorem envBound11457 : H12AffineFastState.Bounded env11457 := by
  intro p hp
  have h : env11457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11456_11457 : H12AffineEnvironment.transform 10 1076 env11456 = env11457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env11456 == env11457) = true)

theorem identity11457 : scanCanonicalize (H12AffineFastState.compose env11457 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound11457 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env11458 : List Nat := [2,4,8,16,32,17,9,37,0,1024,1076,4096,9,5156,32,3,5173,1044,1024,33,4113,32,16,3,8,17,1045,5172,4097,1076,1056,33,37,33,5157,1]

theorem envBound11458 : H12AffineFastState.Bounded env11458 := by
  intro p hp
  have h : env11458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11457_11458 : H12AffineEnvironment.transform 8 0 env11457 = env11458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env11457 == env11458) = true)

def env11459 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,77898,272393,17,21763,8193,64,215367,5392,91403,406604,75102,272393,256,21792,16464,513]

theorem envBound11459 : H12AffineFastState.Bounded env11459 := by
  intro p hp
  have h : env11459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11441_11459 : H12AffineEnvironment.transform 22 17 env11441 = env11459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env11441 == env11459) = true)

theorem identity11459 : scanCanonicalize (H12AffineFastState.compose env11459 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound11459 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env11460 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1024,29789,77898,272393,17,21763,8193,64,10588,5392,91403,349271,75102,272393,256,21792,16464,513]

theorem envBound11460 : H12AffineFastState.Bounded env11460 := by
  intro p hp
  have h : env11460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11459_11460 : H12AffineEnvironment.transform 16 90139 env11459 = env11460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env11459 == env11460) = true)

theorem identity11460 : scanCanonicalize (H12AffineFastState.compose env11460 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound11460 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11461 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10281,1024,29789,77898,32,17,21763,8193,64,10588,5392,91403,97406,75102,32,256,21792,16464,513]

theorem envBound11461 : H12AffineFastState.Bounded env11461 := by
  intro p hp
  have h : env11461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11460_11461 : H12AffineEnvironment.transform 17 10281 env11460 = env11461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11460 == env11461) = true)

theorem identity11461 : scanCanonicalize (H12AffineFastState.compose env11461 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound11461 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11462 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,5392,10281,1024,29789,17729,32,17,21763,8193,64,10588,5392,4096,2421,20565,32,256,21792,16464,513]

theorem envBound11462 : H12AffineFastState.Bounded env11462 := by
  intro p hp
  have h : env11462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11461_11462 : H12AffineEnvironment.transform 15 29963 env11461 = env11462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env11461 == env11462) = true)

theorem identity11462 : scanCanonicalize (H12AffineFastState.compose env11462 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound11462 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env11463 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,21591,5392,2421,1024,21761,17729,32,17,21763,349,64,2048,5392,4096,2421,20565,32,256,21792,16464,513]

theorem envBound11463 : H12AffineFastState.Bounded env11463 := by
  intro p hp
  have h : env11463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11462_11463 : H12AffineEnvironment.transform 12 348 env11462 = env11463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env11462 == env11463) = true)

theorem identity11463 : scanCanonicalize (H12AffineFastState.compose env11463 (packedSelected [4,9,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound11463 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env11464 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5457,81,262,5392,2421,1024,80,4112,32,17,82,349,64,2048,5392,4096,2421,1284,32,256,113,5377,513]

theorem envBound11464 : H12AffineFastState.Bounded env11464 := by
  intro p hp
  have h : env11464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11463_11464 : H12AffineEnvironment.transform 13 5457 env11463 = env11464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env11463 == env11464) = true)

def env11465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,272513,8388608,10577240,8328,64,2259212,8393985,10507600,8795348,2102685,8661017,256,21792,16464,2175563]

theorem envBound11465 : H12AffineFastState.Bounded env11465 := by
  intro p hp
  have h : env11465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11420_11465 : H12AffineEnvironment.transform 21 272513 env11420 = env11465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env11420 == env11465) = true)

theorem identity11465 : scanCanonicalize (H12AffineFastState.compose env11465 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 2175066) := by decide +kernel

theorem selectedBound11465 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,272513,2175066,21762,8328,64,2259212,2172251,91402,2557070,2102685,2431043,256,21792,16464,2175563]

theorem envBound11466 : H12AffineFastState.Bounded env11466 := by
  intro p hp
  have h : env11466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11465_11466 : H12AffineEnvironment.transform 22 2175066 env11465 = env11466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2175066 env11465 == env11466) = true)

def env11467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,2097152,33,2175066,21762,8328,64,2259212,2172251,91402,2305070,2102685,2175203,256,21792,16464,2175563]

theorem envBound11467 : H12AffineFastState.Bounded env11467 := by
  intro p hp
  have h : env11467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11466_11467 : H12AffineEnvironment.transform 17 10400 env11466 = env11467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env11466 == env11467) = true)

theorem identity11467 : scanCanonicalize (H12AffineFastState.compose env11467 (packedSelected [1,11,17,18,19,23,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound11467 : packedSelected [1,11,17,18,19,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env11468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,77898,33,16,21762,8328,64,215366,5393,91402,138340,75223,169,256,21792,16464,513]

theorem envBound11468 : H12AffineFastState.Bounded env11468 := by
  intro p hp
  have h : env11468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11467_11468 : H12AffineEnvironment.transform 20 77898 env11467 = env11468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env11467 == env11468) = true)

def env11469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10400,1024,8660,77898,33,16,2,8328,64,203846,5393,77834,138340,75223,169,256,32,5456,513]

theorem envBound11469 : H12AffineFastState.Bounded env11469 := by
  intro p hp
  have h : env11469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11468_11469 : H12AffineEnvironment.transform 13 5376 env11468 = env11469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11468 == env11469) = true)

theorem identity11469 : scanCanonicalize (H12AffineFastState.compose env11469 (packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,18,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound11469 : packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env11470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,79250,10400,1024,8660,77898,33,16,2,8328,64,10708,5393,77834,76278,75223,169,256,32,5456,513]

theorem envBound11470 : H12AffineFastState.Bounded env11470 := by
  intro p hp
  have h : env11470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11469_11470 : H12AffineEnvironment.transform 16 79250 env11469 = env11470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env11469 == env11470) = true)

theorem identity11470 : scanCanonicalize (H12AffineFastState.compose env11470 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11470 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11471 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,79131,10281,1024,8541,77898,33,16,2,8193,64,10589,5393,77834,76159,75102,32,256,32,5456,513]

theorem envBound11471 : H12AffineFastState.Bounded env11471 := by
  intro p hp
  have h : env11471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11470_11471 : H12AffineEnvironment.transform 6 9 env11470 = env11471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11470 == env11471) = true)

def env11472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10400,1024,8661,77898,33,16,3,8328,64,203847,5393,77835,138340,75223,169,256,33,5457,513]

theorem envBound11472 : H12AffineFastState.Bounded env11472 := by
  intro p hp
  have h : env11472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11468_11472 : H12AffineEnvironment.transform 13 5377 env11468 = env11472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env11468 == env11472) = true)

theorem identity11472 : scanCanonicalize (H12AffineFastState.compose env11472 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11472 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11473 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1024,8540,77898,33,16,3,8193,64,203847,5393,77835,138340,75102,32,256,33,5457,513]

theorem envBound11473 : H12AffineFastState.Bounded env11473 := by
  intro p hp
  have h : env11473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11472_11473 : H12AffineEnvironment.transform 6 9 env11472 = env11473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11472 == env11473) = true)

theorem identity11473 : scanCanonicalize (H12AffineFastState.compose env11473 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound11473 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env11474 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,70678,10281,1024,8540,77898,33,16,3,8193,64,2129,5393,77835,67698,75102,32,256,33,5457,513]

theorem envBound11474 : H12AffineFastState.Bounded env11474 := by
  intro p hp
  have h : env11474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11473_11474 : H12AffineEnvironment.transform 16 70678 env11473 = env11474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env11473 == env11474) = true)

theorem identity11474 : scanCanonicalize (H12AffineFastState.compose env11474 (packedSelected [4,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11474 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env11475 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,13340,10281,1024,8540,4160,33,16,3,8193,64,2129,5393,4097,10360,1364,32,256,33,5457,513]

theorem envBound11475 : H12AffineFastState.Bounded env11475 := by
  intro p hp
  have h : env11475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11474_11475 : H12AffineEnvironment.transform 15 8202 env11474 = env11475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11474 == env11475) = true)

theorem identity11475 : scanCanonicalize (H12AffineFastState.compose env11475 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11475 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11476 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,343,5441,2420,1024,1,4160,33,16,3,348,64,2129,5393,4097,2341,1364,32,256,33,5457,513]

theorem envBound11476 : H12AffineFastState.Bounded env11476 := by
  intro p hp
  have h : env11476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11475_11476 : H12AffineEnvironment.transform 12 349 env11475 = env11476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11475 == env11476) = true)

theorem identity11476 : scanCanonicalize (H12AffineFastState.compose env11476 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound11476 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env11477 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,349,4404,0,343,4468,2420,53,1,4160,33,16,3,348,64,2129,4388,4097,2341,353,32,256,33,4452,513]

theorem envBound11477 : H12AffineFastState.Bounded env11477 := by
  intro p hp
  have h : env11477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11476_11477 : H12AffineEnvironment.transform 9 53 env11476 = env11477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env11476 == env11477) = true)

theorem identity11477 : scanCanonicalize (H12AffineFastState.compose env11477 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11477 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env11478 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,120,4113,0,114,4177,2129,53,1,4160,33,16,3,121,64,2129,4097,4097,2048,68,32,37,33,4161,513]

theorem envBound11478 : H12AffineFastState.Bounded env11478 := by
  intro p hp
  have h : env11478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11477_11478 : H12AffineEnvironment.transform 7 37 env11477 = env11478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11477 == env11478) = true)

theorem identity11478 : scanCanonicalize (H12AffineFastState.compose env11478 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11478 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11479 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,41,4113,0,35,4096,2048,53,1,4113,33,16,3,40,17,2048,4097,4097,2048,21,32,37,33,4112,513]

theorem envBound11479 : H12AffineFastState.Bounded env11479 := by
  intro p hp
  have h : env11479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11478_11479 : H12AffineEnvironment.transform 5 17 env11478 = env11479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11478 == env11479) = true)

theorem identity11479 : scanCanonicalize (H12AffineFastState.compose env11479 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound11479 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11480 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,2608,41,2593,0,35,2608,2048,53,1,2593,33,16,3,40,17,2048,2609,2609,2048,21,32,37,33,2592,513]

theorem envBound11480 : H12AffineFastState.Bounded env11480 := by
  intro p hp
  have h : env11480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11479_11480 : H12AffineEnvironment.transform 11 2608 env11479 = env11480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env11479 == env11480) = true)

theorem identity11480 : scanCanonicalize (H12AffineFastState.compose env11480 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound11480 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11481 : List Nat := [2,4,8,16,32,17,9,37,512,53,16,544,41,561,0,35,544,16,53,1,561,33,16,3,40,17,16,545,545,16,21,32,37,33,560,513]

theorem envBound11481 : H12AffineFastState.Bounded env11481 := by
  intro p hp
  have h : env11481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11480_11481 : H12AffineEnvironment.transform 10 16 env11480 = env11481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env11480 == env11481) = true)

def env11482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,2097152,32,2175066,21762,8328,64,2259212,2172251,91402,2305071,2102685,2175202,256,21792,16464,2175563]

theorem envBound11482 : H12AffineFastState.Bounded env11482 := by
  intro p hp
  have h : env11482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11466_11482 : H12AffineEnvironment.transform 17 10401 env11466 = env11482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env11466 == env11482) = true)

theorem identity11482 : scanCanonicalize (H12AffineFastState.compose env11482 (packedSelected [1,11,17,18,19,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound11482 : packedSelected [1,11,17,18,19,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env11483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30082,131072,10401,1024,29908,2097152,32,2115032,21762,8328,64,2259212,2117849,4232,2251181,2102685,2114912,256,21792,16464,2115529]

theorem envBound11483 : H12AffineFastState.Bounded env11483 := by
  intro p hp
  have h : env11483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11482_11483 : H12AffineEnvironment.transform 15 30082 env11482 = env11483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env11482 == env11483) = true)

theorem identity11483 : scanCanonicalize (H12AffineFastState.compose env11483 (packedSelected [1,3,10,12,15,17,19,24,26,28,31,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound11483 : packedSelected [1,3,10,12,15,17,19,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env11484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8202,131072,10401,1024,8540,2097152,32,2101328,138,8328,64,2239620,2098513,4232,2231333,2102685,2101480,256,168,5592,2101825]

theorem envBound11484 : H12AffineFastState.Bounded env11484 := by
  intro p hp
  have h : env11484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11483_11484 : H12AffineEnvironment.transform 13 5512 env11483 = env11484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env11483 == env11484) = true)

theorem identity11484 : scanCanonicalize (H12AffineFastState.compose env11484 (packedSelected [0,1,2,3,4,5,7,8,10,11,14,18,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 13745) := by decide +kernel

theorem selectedBound11484 : packedSelected [0,1,2,3,4,5,7,8,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env11485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8202,13745,10401,1024,8540,2097152,32,2101328,138,8328,64,2103605,2098513,4232,2111892,2102685,2101480,256,168,5592,2101825]

theorem envBound11485 : H12AffineFastState.Bounded env11485 := by
  intro p hp
  have h : env11485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11484_11485 : H12AffineEnvironment.transform 16 13745 env11484 = env11485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13745 env11484 == env11485) = true)

theorem identity11485 : scanCanonicalize (H12AffineFastState.compose env11485 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound11485 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env11486 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5237,8352,8202,13388,10401,1024,8353,2097152,32,2101328,138,8328,64,2103496,2098348,4232,2111593,2102368,2101480,253,168,5157,2101825]

theorem envBound11486 : H12AffineFastState.Bounded env11486 := by
  intro p hp
  have h : env11486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11485_11486 : H12AffineEnvironment.transform 7 253 env11485 = env11486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env11485 == env11486) = true)

theorem identity11486 : scanCanonicalize (H12AffineFastState.compose env11486 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 12392) := by decide +kernel

theorem selectedBound11486 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env11487 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5237,8352,8202,13388,10401,1024,8353,12392,32,8248,138,8328,64,10400,13508,4232,2049,9224,8320,253,168,5157,8745]

theorem envBound11487 : H12AffineFastState.Bounded env11487 := by
  intro p hp
  have h : env11487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11486_11487 : H12AffineEnvironment.transform 20 12392 env11486 = env11487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12392 env11486 == env11487) = true)

theorem identity11487 : scanCanonicalize (H12AffineFastState.compose env11487 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound11487 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env11488 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,241,5237,81,251,5309,2128,1024,80,4249,32,201,138,121,64,2129,5173,4232,2049,1273,113,253,168,5157,728]

theorem envBound11488 : H12AffineFastState.Bounded env11488 := by
  intro p hp
  have h : env11488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11487_11488 : H12AffineEnvironment.transform 12 241 env11487 = env11488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env11487 == env11488) = true)

theorem identity11488 : scanCanonicalize (H12AffineFastState.compose env11488 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound11488 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env11489 : List Nat := [2,4,8,16,32,64,128,253,512,52,2048,4096,241,4161,81,251,4233,2128,52,80,4249,32,201,138,121,64,2129,4097,4232,2049,205,113,253,168,4113,728]

theorem envBound11489 : H12AffineFastState.Bounded env11489 := by
  intro p hp
  have h : env11489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11488_11489 : H12AffineEnvironment.transform 9 52 env11488 = env11489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env11488 == env11489) = true)

def env11490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound11490 : H12AffineFastState.Bounded env11490 := by
  intro p hp
  have h : env11490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11304_11490 : H12AffineEnvironment.transform 18 1025 env11304 = env11490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env11304 == env11490) = true)

theorem identity11490 : scanCanonicalize (H12AffineFastState.compose env11490 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 165336) := by decide +kernel

theorem selectedBound11490 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env11491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,4194304,8388608,16777216,8328,64,29868033,16974165,8573064,8830976,25265168,21225496,257,25379188,25403600,25207751]

theorem envBound11491 : H12AffineFastState.Bounded env11491 := by
  intro p hp
  have h : env11491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11490_11491 : H12AffineEnvironment.transform 20 165336 env11490 = env11491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165336 env11490 == env11491) = true)

def env11492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,4194304,8388608,8590420,8328,64,4510805,8393985,8573064,8830976,168004,12645452,257,21792,46212,243603]

theorem envBound11492 : H12AffineFastState.Bounded env11492 := by
  intro p hp
  have h : env11492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11491_11492 : H12AffineEnvironment.transform 23 8590420 env11491 = env11492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590420 env11491 == env11492) = true)

def env11493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,4194304,169352,98780,8328,64,4510805,163977,17664,284040,168004,4350404,257,21792,46212,243603]

theorem envBound11493 : H12AffineFastState.Bounded env11493 := by
  intro p hp
  have h : env11493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11492_11493 : H12AffineEnvironment.transform 22 169352 env11492 = env11493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env11492 == env11493) = true)

def env11494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272512,169352,98780,8328,64,64725,163977,17664,284040,168004,411972,257,21792,46212,243603]

theorem envBound11494 : H12AffineFastState.Bounded env11494 := by
  intro p hp
  have h : env11494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11493_11494 : H12AffineEnvironment.transform 21 272512 env11493 = env11494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env11493 == env11494) = true)

theorem identity11494 : scanCanonicalize (H12AffineFastState.compose env11494 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound11494 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,160013,272512,155997,95497,8328,64,2048,160860,17664,284040,156817,411972,257,21792,16465,213830]

theorem envBound11495 : H12AffineFastState.Bounded env11495 := by
  intro p hp
  have h : env11495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11494_11495 : H12AffineEnvironment.transform 14 29909 env11494 = env11495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env11494 == env11495) = true)

def env11496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272513,169352,98780,8328,64,64724,163977,17664,284040,168004,411973,257,21792,46212,243603]

theorem envBound11496 : H12AffineFastState.Bounded env11496 := by
  intro p hp
  have h : env11496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11493_11496 : H12AffineEnvironment.transform 21 272513 env11493 = env11496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env11493 == env11496) = true)

theorem identity11496 : scanCanonicalize (H12AffineFastState.compose env11496 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound11496 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,58516,272513,62660,98780,8328,64,64724,57797,17664,284040,61704,272393,257,21792,46212,120543]

theorem envBound11497 : H12AffineFastState.Bounded env11497 := by
  intro p hp
  have h : env11497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11496_11497 : H12AffineEnvironment.transform 16 24908 env11496 = env11497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env11496 == env11497) = true)

def env11498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10280,1025,32769,58516,169,62660,98780,8328,64,64724,57797,17664,32160,61704,33,257,21792,46212,120543]

theorem envBound11498 : H12AffineFastState.Bounded env11498 := by
  intro p hp
  have h : env11498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11497_11498 : H12AffineEnvironment.transform 17 10280 env11497 = env11498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11497 == env11498) = true)

theorem identity11498 : scanCanonicalize (H12AffineFastState.compose env11498 (packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound11498 : packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env11499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1124,65536,24908,10280,1025,1125,24816,169,28832,67000,8328,64,30896,26017,17664,32160,30060,33,257,21792,12512,86715]

theorem envBound11499 : H12AffineFastState.Bounded env11499 := by
  intro p hp
  have h : env11499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11498_11499 : H12AffineEnvironment.transform 14 1124 env11498 = env11499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env11498 == env11499) = true)

theorem identity11499 : scanCanonicalize (H12AffineFastState.compose env11499 (packedSelected [3,5,8,11,15,18,19,23,26,28,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound11499 : packedSelected [3,5,8,11,15,18,19,23,26,28,32,38] rootPS < 2^1333 := by decide +kernel

def env11500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1124,21511,24908,10280,1025,1125,24816,169,28832,20927,8328,64,30896,26017,17664,32160,30060,33,257,21792,12512,1724]

theorem envBound11500 : H12AffineFastState.Bounded env11500 := by
  intro p hp
  have h : env11500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11499_11500 : H12AffineEnvironment.transform 15 21511 env11499 = env11500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env11499 == env11500) = true)

theorem identity11500 : scanCanonicalize (H12AffineFastState.compose env11500 (packedSelected [0,1,2,6,7,8,11,16,17,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound11500 : packedSelected [0,1,2,6,7,8,11,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env11501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,1124,8283,5392,10280,1025,1125,5292,169,1276,9699,8328,64,3308,4605,12636,2556,304,33,257,8572,12512,1724]

theorem envBound11501 : H12AffineFastState.Bounded env11501 := by
  intro p hp
  have h : env11501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11500_11501 : H12AffineEnvironment.transform 13 13404 env11500 = env11501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env11500 == env11501) = true)

theorem identity11501 : scanCanonicalize (H12AffineFastState.compose env11501 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1457) := by decide +kernel

theorem selectedBound11501 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1457,4589,1124,1514,5392,3481,1025,1125,5292,169,1276,82,1337,64,3308,4605,5357,2556,304,33,257,1229,5457,1724]

theorem envBound11502 : H12AffineFastState.Bounded env11502 := by
  intro p hp
  have h : env11502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11501_11502 : H12AffineEnvironment.transform 12 1457 env11501 = env11502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env11501 == env11502) = true)

theorem identity11502 : scanCanonicalize (H12AffineFastState.compose env11502 (packedSelected [3,5,10,11,12,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound11502 : packedSelected [3,5,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env11503 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,241,4589,292,170,4176,2265,321,293,4588,169,444,82,121,64,2476,4605,4525,2556,304,33,257,397,4113,1020]

theorem envBound11503 : H12AffineFastState.Bounded env11503 := by
  intro p hp
  have h : env11503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11502_11503 : H12AffineEnvironment.transform 9 320 env11502 = env11503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env11502 == env11503) = true)

theorem identity11503 : scanCanonicalize (H12AffineFastState.compose env11503 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound11503 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env11504 : List Nat := [2,4,8,16,32,64,128,252,512,188,2048,4096,241,4113,216,170,4176,2265,189,217,4112,169,64,82,121,64,2128,4097,4177,2048,204,33,253,113,4113,512]

theorem envBound11504 : H12AffineFastState.Bounded env11504 := by
  intro p hp
  have h : env11504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11503_11504 : H12AffineEnvironment.transform 7 252 env11503 = env11504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env11503 == env11504) = true)

theorem identity11504 : scanCanonicalize (H12AffineFastState.compose env11504 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2792) := by decide +kernel

theorem selectedBound11504 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env11505 : List Nat := [2,4,8,16,32,64,128,252,512,188,2048,2792,241,2809,216,170,2744,2265,189,217,2808,169,64,82,121,64,2128,2793,2745,2048,204,33,253,113,2809,512]

theorem envBound11505 : H12AffineFastState.Bounded env11505 := by
  intro p hp
  have h : env11505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11504_11505 : H12AffineEnvironment.transform 11 2792 env11504 = env11505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2792 env11504 == env11505) = true)

theorem identity11505 : scanCanonicalize (H12AffineFastState.compose env11505 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11505 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11506 : List Nat := [2,4,8,16,0,64,128,220,512,156,2048,2760,209,2777,216,138,2712,2265,157,217,2776,137,64,82,89,64,2128,2761,2713,2048,204,1,221,81,2777,512]

theorem envBound11506 : H12AffineFastState.Bounded env11506 := by
  intro p hp
  have h : env11506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11505_11506 : H12AffineEnvironment.transform 4 0 env11505 = env11506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11505 == env11506) = true)

theorem identity11506 : scanCanonicalize (H12AffineFastState.compose env11506 (packedSelected [4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 198) := by decide +kernel

theorem selectedBound11506 : packedSelected [4,7,8] rootPS < 2^1333 := by decide +kernel

def env11507 : List Nat := [2,4,8,16,0,64,128,220,198,156,2048,2062,209,2079,216,138,2142,2265,157,217,2078,137,64,82,89,64,2128,2063,2143,2048,204,1,221,81,2079,198]

theorem envBound11507 : H12AffineFastState.Bounded env11507 := by
  intro p hp
  have h : env11507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11506_11507 : H12AffineEnvironment.transform 8 198 env11506 = env11507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 198 env11506 == env11507) = true)

end H12CloudChart1