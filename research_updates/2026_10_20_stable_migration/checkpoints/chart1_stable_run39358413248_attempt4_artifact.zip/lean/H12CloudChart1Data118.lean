import H12CloudChart1Data117

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env29922 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,2844,4112,2577,262,6672,2341,272,2576,6657,2609,2560,2579,2844,16,528,6672,4096,820,2565,33,256,33,4113,513]

theorem envBound29922 : H12AffineFastState.Bounded env29922 := by
  intro p hp
  have h : env29922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29921_29922 : H12AffineEnvironment.transform 12 2844 env29921 = env29922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2844 env29921 == env29922) = true)

theorem identity29922 : scanCanonicalize (H12AffineFastState.compose env29922 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound29922 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env29923 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,821,2844,805,2577,262,2341,2341,272,2576,2356,2609,2560,2579,2844,16,528,2341,821,820,2565,33,256,33,804,513]

theorem envBound29923 : H12AffineFastState.Bounded env29923 := by
  intro p hp
  have h : env29923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29922_29923 : H12AffineEnvironment.transform 11 821 env29922 = env29923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env29922 == env29923) = true)

theorem identity29923 : scanCanonicalize (H12AffineFastState.compose env29923 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound29923 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env29924 : List Nat := [2,4,8,16,32,17,8,256,0,272,2048,309,2332,293,2065,262,2341,2341,272,2064,2356,2097,2048,2067,2332,16,16,2341,309,308,2053,33,256,33,292,1]

theorem envBound29924 : H12AffineFastState.Bounded env29924 := by
  intro p hp
  have h : env29924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29923_29924 : H12AffineEnvironment.transform 8 0 env29923 = env29924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env29923 == env29924) = true)

theorem identity29924 : scanCanonicalize (H12AffineFastState.compose env29924 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29924 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env29925 : List Nat := [2,4,8,1,32,0,8,256,0,257,2048,292,2317,293,2048,262,2341,2341,257,2049,2341,2080,2048,2050,2317,1,1,2341,292,293,2053,33,256,33,292,1]

theorem envBound29925 : H12AffineFastState.Bounded env29925 := by
  intro p hp
  have h : env29925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29924_29925 : H12AffineEnvironment.transform 3 1 env29924 = env29925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29924 == env29925) = true)

theorem identity29925 : scanCanonicalize (H12AffineFastState.compose env29925 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound29925 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29926 : List Nat := [2,4,8,1,32,0,8,256,0,257,33,292,300,293,33,262,260,260,257,32,260,1,33,35,300,1,1,260,292,293,36,33,256,33,292,1]

theorem envBound29926 : H12AffineFastState.Bounded env29926 := by
  intro p hp
  have h : env29926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29925_29926 : H12AffineEnvironment.transform 10 33 env29925 = env29926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env29925 == env29926) = true)

theorem identity29926 : scanCanonicalize (H12AffineFastState.compose env29926 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29927 : List Nat := [2,4,8,1,0,0,8,256,0,257,1,260,268,261,1,262,260,260,257,0,260,1,1,3,268,1,1,260,260,261,4,1,256,1,260,1]

theorem envBound29927 : H12AffineFastState.Bounded env29927 := by
  intro p hp
  have h : env29927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29926_29927 : H12AffineEnvironment.transform 4 0 env29926 = env29927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29926 == env29927) = true)

def env29928 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272393,452649,441658,8193,65,245018,115015,17664,10281,119042,329730,256,485711,493667,63068]

theorem envBound29928 : H12AffineFastState.Bounded env29928 := by
  intro p hp
  have h : env29928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29901_29928 : H12AffineEnvironment.transform 6 9 env29901 = env29928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29901 == env29928) = true)

def env29929 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276585,272393,272441,294186,8193,65,97546,115015,17664,10281,119042,329730,256,371039,346227,63068]

theorem envBound29929 : H12AffineFastState.Bounded env29929 := by
  intro p hp
  have h : env29929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29928_29929 : H12AffineEnvironment.transform 16 49168 env29928 = env29929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env29928 == env29929) = true)

theorem identity29929 : scanCanonicalize (H12AffineFastState.compose env29929 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound29929 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29930 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,56437,1024,32769,58396,62588,62540,41311,8193,65,97546,115015,17664,10281,119042,119927,256,95530,103430,63068]

theorem envBound29930 : H12AffineFastState.Bounded env29930 := by
  intro p hp
  have h : env29930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29929_29930 : H12AffineEnvironment.transform 17 56437 env29929 = env29930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env29929 == env29930) = true)

theorem identity29930 : scanCanonicalize (H12AffineFastState.compose env29930 (packedSelected [0,4,5,7,9,10,11,15,16,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound29930 : packedSelected [0,4,5,7,9,10,11,15,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env29931 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,65536,5441,2340,1024,21840,12621,8493,8477,29710,8193,65,97546,70678,17664,10281,66643,65830,256,95530,82263,8973]

theorem envBound29931 : H12AffineFastState.Bounded env29931 := by
  intro p hp
  have h : env29931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29930_29931 : H12AffineEnvironment.transform 14 21841 env29930 = env29931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env29930 == env29931) = true)

theorem identity29931 : scanCanonicalize (H12AffineFastState.compose env29931 (packedSelected [1,3,4,5,8,14,15,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound29931 : packedSelected [1,3,4,5,8,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env29932 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8460,65536,5441,2340,1024,8461,12621,8493,8477,83,8193,65,67927,70678,12637,10281,66643,65830,256,65911,79114,8973]

theorem envBound29932 : H12AffineFastState.Bounded env29932 := by
  intro p hp
  have h : env29932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29931_29932 : H12AffineEnvironment.transform 13 13405 env29931 = env29932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env29931 == env29932) = true)

theorem identity29932 : scanCanonicalize (H12AffineFastState.compose env29932 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29932 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29933 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,80,65536,5441,2340,1024,81,4113,113,65,83,349,65,67927,70678,4097,2421,66643,65830,256,65911,70742,593]

theorem envBound29933 : H12AffineFastState.Bounded env29933 := by
  intro p hp
  have h : env29933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29932_29933 : H12AffineEnvironment.transform 12 348 env29932 = env29933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29932 == env29933) = true)

theorem identity29933 : scanCanonicalize (H12AffineFastState.compose env29933 (packedSelected [0,1,3,4,5,7,8,9,11,14] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound29933 : packedSelected [0,1,3,4,5,7,8,9,11,14] rootPS < 2^1333 := by decide +kernel

def env29934 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,80,262,5441,2340,1024,81,4113,113,65,83,349,65,2129,5392,4097,2421,1365,32,256,113,5456,593]

theorem envBound29934 : H12AffineFastState.Bounded env29934 := by
  intro p hp
  have h : env29934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29933_29934 : H12AffineEnvironment.transform 15 262 env29933 = env29934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env29933 == env29934) = true)

theorem identity29934 : scanCanonicalize (H12AffineFastState.compose env29934 (packedSelected [0,1,2,3,5,6,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound29934 : packedSelected [0,1,2,3,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env29935 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,348,2049,80,262,2113,2340,1024,81,3345,113,65,83,349,65,2129,2064,3329,2421,1365,32,256,113,2128,593]

theorem envBound29935 : H12AffineFastState.Bounded env29935 := by
  intro p hp
  have h : env29935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29934_29935 : H12AffineEnvironment.transform 11 3328 env29934 = env29935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env29934 == env29935) = true)

def env29936 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276584,272393,272440,294187,8193,65,97547,115015,17664,10281,119042,329730,256,371038,346226,63068]

theorem envBound29936 : H12AffineFastState.Bounded env29936 := by
  intro p hp
  have h : env29936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29928_29936 : H12AffineEnvironment.transform 16 49169 env29928 = env29936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29928 == env29936) = true)

theorem identity29936 : scanCanonicalize (H12AffineFastState.compose env29936 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound29936 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29937 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,262144,1024,29788,276584,272393,272440,294187,8193,65,97547,79130,17664,10281,75103,329730,256,351491,346226,513]

theorem envBound29937 : H12AffineFastState.Bounded env29937 := by
  intro p hp
  have h : env29937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29936_29937 : H12AffineEnvironment.transform 14 29789 env29936 = env29937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env29936 == env29937) = true)

theorem identity29937 : scanCanonicalize (H12AffineFastState.compose env29937 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound29937 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env29938 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,10280,1024,29788,4160,33,16,21763,8193,65,97547,79130,17664,10281,75103,73770,256,95531,90202,513]

theorem envBound29938 : H12AffineFastState.Bounded env29938 := by
  intro p hp
  have h : env29938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29937_29938 : H12AffineEnvironment.transform 17 10280 env29937 = env29938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env29937 == env29938) = true)

theorem identity29938 : scanCanonicalize (H12AffineFastState.compose env29938 (packedSelected [3,4,5,9,10,11,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound29938 : packedSelected [3,4,5,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env29939 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,263,13388,10280,1024,29788,4160,33,16,21763,8193,65,31756,13341,17664,10281,9304,8493,256,29740,24925,513]

theorem envBound29939 : H12AffineFastState.Bounded env29939 := by
  intro p hp
  have h : env29939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29938_29939 : H12AffineEnvironment.transform 15 263 env29938 = env29939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env29938 == env29939) = true)

theorem identity29939 : scanCanonicalize (H12AffineFastState.compose env29939 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound29939 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env29940 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8460,263,13388,10280,1024,8461,4160,33,16,82,8193,65,10589,13341,4177,10281,9304,8493,256,8573,13324,513]

theorem envBound29940 : H12AffineFastState.Bounded env29940 := by
  intro p hp
  have h : env29940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29939_29940 : H12AffineEnvironment.transform 13 5457 env29939 = env29940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env29939 == env29940) = true)

theorem identity29940 : scanCanonicalize (H12AffineFastState.compose env29940 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29940 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29941 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5457,80,263,5392,2420,1024,81,4160,33,16,82,349,65,2049,5441,4177,2421,1284,113,256,33,5456,513]

theorem envBound29941 : H12AffineFastState.Bounded env29941 := by
  intro p hp
  have h : env29941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29940_29941 : H12AffineEnvironment.transform 12 348 env29940 = env29941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29940 == env29941) = true)

theorem identity29941 : scanCanonicalize (H12AffineFastState.compose env29941 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1360) := by decide +kernel

theorem selectedBound29941 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env29942 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1360,4096,348,5457,80,263,5392,1060,1024,81,4160,33,16,82,349,65,1361,5441,4177,1061,1284,113,256,33,5456,513]

theorem envBound29942 : H12AffineFastState.Bounded env29942 := by
  intro p hp
  have h : env29942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29941_29942 : H12AffineEnvironment.transform 10 1360 env29941 = env29942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1360 env29941 == env29942) = true)

theorem identity29942 : scanCanonicalize (H12AffineFastState.compose env29942 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound29942 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env29943 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1360,1,348,1360,80,263,1297,1060,1024,81,65,33,16,82,349,65,1361,1344,80,1061,1284,113,256,33,1361,513]

theorem envBound29943 : H12AffineFastState.Bounded env29943 := by
  intro p hp
  have h : env29943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29942_29943 : H12AffineEnvironment.transform 11 1 env29942 = env29943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env29942 == env29943) = true)

theorem identity29943 : scanCanonicalize (H12AffineFastState.compose env29943 (packedSelected [0,3,5,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29943 : packedSelected [0,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env29944 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1281,1,269,1281,1,263,1297,1060,1024,0,16,33,16,3,268,16,1280,1297,1,1061,1284,32,256,33,1280,513]

theorem envBound29944 : H12AffineFastState.Bounded env29944 := by
  intro p hp
  have h : env29944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29943_29944 : H12AffineEnvironment.transform 5 17 env29943 = env29944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29943 == env29944) = true)

theorem identity29944 : scanCanonicalize (H12AffineFastState.compose env29944 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound29944 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29945 : List Nat := [2,4,8,16,32,17,9,256,512,52,309,1,269,309,1,263,293,16,52,0,16,33,16,3,268,16,308,293,1,17,304,32,256,33,308,513]

theorem envBound29945 : H12AffineFastState.Bounded env29945 := by
  intro p hp
  have h : env29945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29944_29945 : H12AffineEnvironment.transform 9 52 env29944 = env29945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env29944 == env29945) = true)

theorem identity29945 : scanCanonicalize (H12AffineFastState.compose env29945 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound29945 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29946 : List Nat := [2,4,8,16,32,17,9,256,1,52,309,1,269,309,1,263,293,16,52,0,16,33,16,3,268,16,308,293,1,17,304,32,256,33,308,0]

theorem envBound29946 : H12AffineFastState.Bounded env29946 := by
  intro p hp
  have h : env29946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29945_29946 : H12AffineEnvironment.transform 8 1 env29945 = env29946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env29945 == env29946) = true)

def env29947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272513,452768,441779,8328,65,245138,115150,17664,10400,119042,329731,256,485711,493802,63189]

theorem envBound29947 : H12AffineFastState.Bounded env29947 := by
  intro p hp
  have h : env29947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29900_29947 : H12AffineEnvironment.transform 21 272513 env29900 = env29947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29900 == env29947) = true)

theorem identity29947 : scanCanonicalize (H12AffineFastState.compose env29947 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190640) := by decide +kernel

theorem selectedBound29947 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,180273,16,21763,8328,65,245138,115150,17664,10400,119042,254131,256,98815,90202,63189]

theorem envBound29948 : H12AffineFastState.Bounded env29948 := by
  intro p hp
  have h : env29948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29947_29948 : H12AffineEnvironment.transform 17 190640 env29947 = env29948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env29947 == env29948) = true)

def env29949 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,180273,16,21763,8192,65,245018,115014,17664,10280,119042,254011,256,98679,90202,63069]

theorem envBound29949 : H12AffineFastState.Bounded env29949 := by
  intro p hp
  have h : env29949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29948_29949 : H12AffineEnvironment.transform 6 8 env29948 = env29949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29948 == env29949) = true)

theorem identity29949 : scanCanonicalize (H12AffineFastState.compose env29949 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound29949 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29950 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,32041,1024,32769,4160,21792,16,21763,8192,65,75787,115014,17664,10280,119042,95530,256,98679,90202,63069]

theorem envBound29950 : H12AffineFastState.Bounded env29950 := by
  intro p hp
  have h : env29950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29949_29950 : H12AffineEnvironment.transform 16 38161 env29949 = env29950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env29949 == env29950) = true)

theorem identity29950 : scanCanonicalize (H12AffineFastState.compose env29950 (packedSelected [10,16,18,20,23,31] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound29950 : packedSelected [10,16,18,20,23,31] rootPS < 2^1333 := by decide +kernel

def env29951 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,65536,13340,32041,1024,8460,4160,21792,16,21763,8192,65,75787,90187,17664,10280,94223,95530,256,73850,90202,22352]

theorem envBound29951 : H12AffineFastState.Bounded env29951 := by
  intro p hp
  have h : env29951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29950_29951 : H12AffineEnvironment.transform 14 8461 env29950 = env29951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env29950 == env29951) = true)

theorem identity29951 : scanCanonicalize (H12AffineFastState.compose env29951 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound29951 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env29952 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,263,13340,32041,1024,8460,4160,21792,16,21763,8192,65,10508,24908,17664,10280,28936,29741,256,8573,24925,22352]

theorem envBound29952 : H12AffineFastState.Bounded env29952 := by
  intro p hp
  have h : env29952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29951_29952 : H12AffineEnvironment.transform 15 263 env29951 = env29952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env29951 == env29952) = true)

theorem identity29952 : scanCanonicalize (H12AffineFastState.compose env29952 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29952 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env29953 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8461,263,13340,10281,1024,8460,4160,32,16,3,8192,65,10508,13388,4096,10280,9224,8493,256,8573,13405,592]

theorem envBound29953 : H12AffineFastState.Bounded env29953 := by
  intro p hp
  have h : env29953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29952_29953 : H12AffineEnvironment.transform 13 5376 env29952 = env29953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29952 == env29953) = true)

theorem identity29953 : scanCanonicalize (H12AffineFastState.compose env29953 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound29953 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29954 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5376,1344,263,4177,3172,1024,1345,4160,32,16,3,1101,65,3393,4097,4096,3173,69,1376,256,1328,4112,592]

theorem envBound29954 : H12AffineFastState.Bounded env29954 := by
  intro p hp
  have h : env29954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29953_29954 : H12AffineEnvironment.transform 12 1101 env29953 = env29954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env29953 == env29954) = true)

theorem identity29954 : scanCanonicalize (H12AffineFastState.compose env29954 (packedSelected [0,1,2,3,5,6,7,8,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29954 : packedSelected [0,1,2,3,5,6,7,8,12,14,15] rootPS < 2^1333 := by decide +kernel

def env29955 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,1101,5156,1124,35,4177,3172,1024,1125,4160,32,16,3,1101,65,3173,4097,4096,3173,69,1092,36,1044,4112,592]

theorem envBound29955 : H12AffineFastState.Bounded env29955 := by
  intro p hp
  have h : env29955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29954_29955 : H12AffineEnvironment.transform 7 36 env29954 = env29955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29954 == env29955) = true)

def env29956 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,180273,16,21763,8193,65,245019,115015,17664,10281,119042,254010,256,98678,90202,63068]

theorem envBound29956 : H12AffineFastState.Bounded env29956 := by
  intro p hp
  have h : env29956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29948_29956 : H12AffineEnvironment.transform 6 9 env29948 = env29956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29948 == env29956) = true)

theorem identity29956 : scanCanonicalize (H12AffineFastState.compose env29956 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound29956 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,56437,1024,32769,4160,62589,16,21763,8193,65,100695,115015,17664,10281,119042,119926,256,98678,90202,63068]

theorem envBound29957 : H12AffineFastState.Bounded env29957 := by
  intro p hp
  have h : env29957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29956_29957 : H12AffineEnvironment.transform 16 13388 env29956 = env29957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env29956 == env29957) = true)

theorem identity29957 : scanCanonicalize (H12AffineFastState.compose env29957 (packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound29957 : packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env29958 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,13388,23669,1024,1,4160,29821,16,21763,8193,65,67927,82247,17664,10281,86274,87158,256,65910,90202,30300]

theorem envBound29958 : H12AffineFastState.Bounded env29958 := by
  intro p hp
  have h : env29958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29957_29958 : H12AffineEnvironment.transform 14 0 env29957 = env29958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env29957 == env29958) = true)

theorem identity29958 : scanCanonicalize (H12AffineFastState.compose env29958 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound29958 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env29959 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,0,65536,13388,2341,1024,1,4160,8493,16,83,8193,65,67927,70679,4176,10281,66642,65830,256,65910,79114,8972]

theorem envBound29959 : H12AffineFastState.Bounded env29959 := by
  intro p hp
  have h : env29959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29958_29959 : H12AffineEnvironment.transform 13 5456 env29958 = env29959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env29958 == env29959) = true)

theorem identity29959 : scanCanonicalize (H12AffineFastState.compose env29959 (packedSelected [0,7,10,11,12,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound29959 : packedSelected [0,7,10,11,12,14,19] rootPS < 2^1333 := by decide +kernel

def env29960 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,0,343,13388,2341,1024,1,4160,8493,16,83,8193,65,2048,5440,4176,10281,1285,113,256,33,13405,8972]

theorem envBound29960 : H12AffineFastState.Bounded env29960 := by
  intro p hp
  have h : env29960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29959_29960 : H12AffineEnvironment.transform 15 343 env29959 = env29960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env29959 == env29960) = true)

theorem identity29960 : scanCanonicalize (H12AffineFastState.compose env29960 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29960 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env29961 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,0,343,5441,2341,1024,1,4160,32,16,83,268,65,2048,5440,4176,2340,1285,113,256,33,5456,513]

theorem envBound29961 : H12AffineFastState.Bounded env29961 := by
  intro p hp
  have h : env29961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29960_29961 : H12AffineEnvironment.transform 12 269 env29960 = env29961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29960 == env29961) = true)

def env29962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,452768,441778,8328,65,4691218,115150,17665,10400,119043,4268162,256,485711,493802,63188]

theorem envBound29962 : H12AffineFastState.Bounded env29962 := by
  intro p hp
  have h : env29962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29899_29962 : H12AffineEnvironment.transform 20 456945 env29899 = env29962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456945 env29899 == env29962) = true)

def env29963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272512,452768,441778,8328,65,245138,115150,17665,10400,119043,329730,256,485711,493802,63188]

theorem envBound29963 : H12AffineFastState.Bounded env29963 := by
  intro p hp
  have h : env29963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29962_29963 : H12AffineEnvironment.transform 21 272512 env29962 = env29963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29962 == env29963) = true)

theorem identity29963 : scanCanonicalize (H12AffineFastState.compose env29963 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound29963 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,396324,272512,400501,412007,8328,65,215367,79131,17665,10400,75222,329730,256,485711,490559,513]

theorem envBound29964 : H12AffineFastState.Bounded env29964 := by
  intro p hp
  have h : env29964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29963_29964 : H12AffineEnvironment.transform 14 29909 env29963 = env29964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env29963 == env29964) = true)

def env29965 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,396324,272392,400501,412007,8192,65,215367,79131,17665,10280,75102,329730,256,485711,490559,513]

theorem envBound29965 : H12AffineFastState.Bounded env29965 := by
  intro p hp
  have h : env29965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29964_29965 : H12AffineEnvironment.transform 6 8 env29964 = env29965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29964 == env29965) = true)

theorem identity29965 : scanCanonicalize (H12AffineFastState.compose env29965 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound29965 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29966 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,262144,1024,29788,355390,272392,359535,338301,8192,65,10589,79131,17665,10280,75102,329730,256,264533,269349,513]

theorem envBound29966 : H12AffineFastState.Bounded env29966 := by
  intro p hp
  have h : env29966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29965_29966 : H12AffineEnvironment.transform 16 90138 env29965 = env29966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env29965 == env29966) = true)

theorem identity29966 : scanCanonicalize (H12AffineFastState.compose env29966 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound29966 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env29967 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,97326,1024,29788,4112,87078,65,21843,8192,65,10589,79131,17665,10280,75102,29740,256,95611,90123,513]

theorem envBound29967 : H12AffineFastState.Bounded env29967 := by
  intro p hp
  have h : env29967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29966_29967 : H12AffineEnvironment.transform 17 97326 env29966 = env29967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env29966 == env29967) = true)

theorem identity29967 : scanCanonicalize (H12AffineFastState.compose env29967 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound29967 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env29968 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21511,13341,10281,1024,29788,4112,33,65,21843,8192,65,10589,24860,17665,10280,29017,29740,256,8572,13324,513]

theorem envBound29968 : H12AffineFastState.Bounded env29968 := by
  intro p hp
  have h : env29968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29967_29968 : H12AffineEnvironment.transform 15 21511 env29967 = env29968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env29967 == env29968) = true)

theorem identity29968 : scanCanonicalize (H12AffineFastState.compose env29968 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound29968 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env29969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3329,8192,16384,26972,18694,10524,10281,1024,26973,3345,33,65,18514,8192,65,10589,24860,17665,10280,27736,26925,256,8572,10509,513]

theorem envBound29969 : H12AffineFastState.Bounded env29969 := by
  intro p hp
  have h : env29969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29968_29969 : H12AffineEnvironment.transform 11 3329 env29968 = env29969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env29968 == env29969) = true)

theorem identity29969 : scanCanonicalize (H12AffineFastState.compose env29969 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound29969 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env29970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3329,268,16384,18512,18694,2064,2341,1024,18513,3345,33,65,18514,268,65,2129,16400,17665,2340,19796,18465,256,112,2049,513]

theorem envBound29970 : H12AffineFastState.Bounded env29970 := by
  intro p hp
  have h : env29970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29969_29970 : H12AffineEnvironment.transform 12 268 env29969 = env29970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env29969 == env29970) = true)

theorem identity29970 : scanCanonicalize (H12AffineFastState.compose env29970 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound29970 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env29971 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3189,120,16384,18512,18546,2064,2129,1024,18513,3173,33,65,18514,120,65,2129,16400,17525,2128,19488,18465,116,112,2049,513]

theorem envBound29971 : H12AffineFastState.Bounded env29971 := by
  intro p hp
  have h : env29971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29970_29971 : H12AffineEnvironment.transform 7 116 env29970 = env29971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env29970 == env29971) = true)

theorem identity29971 : scanCanonicalize (H12AffineFastState.compose env29971 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound29971 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env29972 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,2064,120,16384,18512,18546,2064,2129,101,18513,2048,33,65,18514,120,65,2129,16400,16400,2128,18501,18465,116,112,2049,513]

theorem envBound29972 : H12AffineFastState.Bounded env29972 := by
  intro p hp
  have h : env29972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29971_29972 : H12AffineEnvironment.transform 9 101 env29971 = env29972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env29971 == env29972) = true)

theorem identity29972 : scanCanonicalize (H12AffineFastState.compose env29972 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29972 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29973 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2064,40,16384,18432,18466,2064,2049,53,18433,2048,33,17,18434,40,17,2049,16400,16400,2048,18453,18465,36,32,2049,513]

theorem envBound29973 : H12AffineFastState.Bounded env29973 := by
  intro p hp
  have h : env29973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29972_29973 : H12AffineEnvironment.transform 5 16 env29972 = env29973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29972 == env29973) = true)

theorem identity29973 : scanCanonicalize (H12AffineFastState.compose env29973 (packedSelected [0] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound29973 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29974 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2064,40,2048,0,34,2064,2049,53,1,2048,33,17,2,40,17,2049,2064,2064,2048,21,33,36,32,2049,513]

theorem envBound29974 : H12AffineFastState.Bounded env29974 := by
  intro p hp
  have h : env29974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29973_29974 : H12AffineEnvironment.transform 13 2048 env29973 = env29974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env29973 == env29974) = true)

theorem identity29974 : scanCanonicalize (H12AffineFastState.compose env29974 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound29974 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29975 : List Nat := [2,4,8,16,32,16,8,36,26,53,2048,2064,40,2048,0,34,2064,2049,53,1,2048,33,17,2,40,17,2049,2064,2064,2048,21,33,36,32,2049,27]

theorem envBound29975 : H12AffineFastState.Bounded env29975 := by
  intro p hp
  have h : env29975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29974_29975 : H12AffineEnvironment.transform 8 26 env29974 = env29975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env29974 == env29975) = true)

def env29976 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,396324,272393,400501,412007,8193,65,215367,79131,17665,10281,75103,329730,256,485711,490559,513]

theorem envBound29976 : H12AffineFastState.Bounded env29976 := by
  intro p hp
  have h : env29976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29964_29976 : H12AffineEnvironment.transform 6 9 env29964 = env29976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29964 == env29976) = true)

theorem identity29976 : scanCanonicalize (H12AffineFastState.compose env29976 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound29976 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env29977 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1024,29789,140300,33,144477,155983,8193,65,215367,79131,17665,10281,75103,73770,256,213351,218135,513]

theorem envBound29977 : H12AffineFastState.Bounded env29977 := by
  intro p hp
  have h : env29977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29976_29977 : H12AffineEnvironment.transform 17 10280 env29976 = env29977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env29976 == env29977) = true)

theorem identity29977 : scanCanonicalize (H12AffineFastState.compose env29977 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29977 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env29978 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10280,1024,8540,140300,33,144477,144462,8193,65,203846,79131,4096,10281,75103,73770,256,201830,196886,513]

theorem envBound29978 : H12AffineFastState.Bounded env29978 := by
  intro p hp
  have h : env29978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29977_29978 : H12AffineEnvironment.transform 13 5377 env29977 = env29978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29977 == env29978) = true)

theorem identity29978 : scanCanonicalize (H12AffineFastState.compose env29978 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound29978 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env29979 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,5393,10280,1024,8540,12573,33,8524,8543,8193,65,67927,79131,4096,10281,75103,73770,256,65911,70663,513]

theorem envBound29979 : H12AffineFastState.Bounded env29979 := by
  intro p hp
  have h : env29979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29978_29979 : H12AffineEnvironment.transform 16 5393 env29978 = env29979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env29978 == env29979) = true)

theorem identity29979 : scanCanonicalize (H12AffineFastState.compose env29979 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29979 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,65536,5393,2420,1024,0,4161,33,16,3,349,65,67927,70727,4096,2421,66563,65910,256,65911,70663,513]

theorem envBound29980 : H12AffineFastState.Bounded env29980 := by
  intro p hp
  have h : env29980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29979_29980 : H12AffineEnvironment.transform 12 348 env29979 = env29980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29979 == env29980) = true)

theorem identity29980 : scanCanonicalize (H12AffineFastState.compose env29980 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound29980 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env29981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,342,5393,2420,1024,0,4161,33,16,3,349,65,2049,5393,4096,2421,1365,32,256,33,5457,513]

theorem envBound29981 : H12AffineFastState.Bounded env29981 := by
  intro p hp
  have h : env29981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29980_29981 : H12AffineEnvironment.transform 15 342 env29980 = env29981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env29980 == env29981) = true)

theorem identity29981 : scanCanonicalize (H12AffineFastState.compose env29981 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound29981 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29982 : List Nat := [2,4,8,16,32,64,9,256,512,564,2048,4096,348,4917,1,342,4901,2420,564,0,4161,33,16,3,349,65,2049,4901,4096,2421,865,32,256,33,4965,513]

theorem envBound29982 : H12AffineFastState.Bounded env29982 := by
  intro p hp
  have h : env29982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29981_29982 : H12AffineEnvironment.transform 9 564 env29981 = env29982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env29981 == env29982) = true)

theorem identity29982 : scanCanonicalize (H12AffineFastState.compose env29982 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29982 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29983 : List Nat := [2,4,8,16,32,17,9,256,512,564,2048,4096,269,4917,1,263,4901,2341,564,0,4112,33,16,3,268,16,2049,4901,4096,2340,816,32,256,33,4916,513]

theorem envBound29983 : H12AffineFastState.Bounded env29983 := by
  intro p hp
  have h : env29983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29982_29983 : H12AffineEnvironment.transform 5 17 env29982 = env29983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29982 == env29983) = true)

theorem identity29983 : scanCanonicalize (H12AffineFastState.compose env29983 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound29983 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29984 : List Nat := [2,4,8,16,32,17,9,256,512,564,2048,512,269,309,1,263,293,2341,564,0,528,33,16,3,268,16,2049,293,512,2340,816,32,256,33,308,513]

theorem envBound29984 : H12AffineFastState.Bounded env29984 := by
  intro p hp
  have h : env29984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29983_29984 : H12AffineEnvironment.transform 11 512 env29983 = env29984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env29983 == env29984) = true)

theorem identity29984 : scanCanonicalize (H12AffineFastState.compose env29984 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound29984 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29985 : List Nat := [2,4,8,16,32,17,9,256,512,564,821,512,269,309,1,263,293,528,564,0,528,33,16,3,268,16,820,293,512,529,816,32,256,33,308,513]

theorem envBound29985 : H12AffineFastState.Bounded env29985 := by
  intro p hp
  have h : env29985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29984_29985 : H12AffineEnvironment.transform 10 821 env29984 = env29985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env29984 == env29985) = true)

theorem identity29985 : scanCanonicalize (H12AffineFastState.compose env29985 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound29985 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29986 : List Nat := [2,4,8,16,32,17,9,256,293,273,16,293,269,309,1,263,293,309,273,0,309,33,16,3,268,16,17,293,293,308,21,32,256,33,308,292]

theorem envBound29986 : H12AffineFastState.Bounded env29986 := by
  intro p hp
  have h : env29986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29985_29986 : H12AffineEnvironment.transform 8 293 env29985 = env29986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env29985 == env29986) = true)

theorem identity29986 : scanCanonicalize (H12AffineFastState.compose env29986 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound29986 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29987 : List Nat := [2,4,8,16,17,17,9,256,276,273,16,276,269,260,1,263,276,260,273,0,260,16,16,3,268,16,17,276,276,261,21,17,256,16,261,277]

theorem envBound29987 : H12AffineFastState.Bounded env29987 := by
  intro p hp
  have h : env29987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29986_29987 : H12AffineEnvironment.transform 4 17 env29986 = env29987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env29986 == env29987) = true)

theorem identity29987 : scanCanonicalize (H12AffineFastState.compose env29987 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound29987 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29988 : List Nat := [2,4,8,16,17,17,9,21,1,4,16,1,24,17,1,18,1,17,4,0,17,16,16,3,25,16,17,1,1,16,21,17,21,16,16,0]

theorem envBound29988 : H12AffineFastState.Bounded env29988 := by
  intro p hp
  have h : env29988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29987_29988 : H12AffineEnvironment.transform 7 21 env29987 = env29988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env29987 == env29988) = true)

theorem identity29988 : scanCanonicalize (H12AffineFastState.compose env29988 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29988 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29989 : List Nat := [2,4,8,1,0,0,9,4,1,4,1,1,9,0,1,3,1,0,4,0,0,1,1,3,8,1,0,1,1,1,4,0,4,1,1,0]

theorem envBound29989 : H12AffineFastState.Bounded env29989 := by
  intro p hp
  have h : env29989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29988_29989 : H12AffineEnvironment.transform 3 1 env29988 = env29989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29988 == env29989) = true)

def env29990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272513,452768,441778,8328,65,245139,115150,17665,10400,119043,329731,256,485711,493802,63188]

theorem envBound29990 : H12AffineFastState.Bounded env29990 := by
  intro p hp
  have h : env29990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29962_29990 : H12AffineEnvironment.transform 21 272513 env29962 = env29990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29962 == env29990) = true)

theorem identity29990 : scanCanonicalize (H12AffineFastState.compose env29990 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound29990 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,58516,144612,62661,41431,8328,65,245139,115150,17665,10400,119043,201830,256,95530,103567,63188]

theorem envBound29991 : H12AffineFastState.Bounded env29991 := by
  intro p hp
  have h : env29991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29990_29991 : H12AffineEnvironment.transform 17 138341 env29990 = env29991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env29990 == env29991) = true)

def env29992 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,58396,144492,62541,41311,8192,65,245019,115014,17665,10280,119043,201830,256,95530,103431,63068]

theorem envBound29992 : H12AffineFastState.Bounded env29992 := by
  intro p hp
  have h : env29992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29991_29992 : H12AffineEnvironment.transform 6 8 env29991 = env29992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29991 == env29992) = true)

theorem identity29992 : scanCanonicalize (H12AffineFastState.compose env29992 (packedSelected [0,4,8,10,11,12,14,15,16,22,27,28,32] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound29992 : packedSelected [0,4,8,10,11,12,14,15,16,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env29993 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,32768,65536,131072,138341,1024,32769,50276,136212,54325,33063,120,65,236899,115014,17665,2128,119043,201830,256,87378,103431,54820]

theorem envBound29993 : H12AffineFastState.Bounded env29993 := by
  intro p hp
  have h : env29993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29992_29993 : H12AffineEnvironment.transform 12 120 env29992 = env29993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env29992 == env29993) = true)

theorem identity29993 : scanCanonicalize (H12AffineFastState.compose env29993 (packedSelected [1,3,7,10,14,16,18,19,23,24,26,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound29993 : packedSelected [1,3,7,10,14,16,18,19,23,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env29994 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21620,65536,131072,138341,1024,21621,4112,136212,65,21843,120,65,215319,70962,17665,2128,66935,201830,256,87378,82035,592]

theorem envBound29994 : H12AffineFastState.Bounded env29994 := by
  intro p hp
  have h : env29994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29993_29994 : H12AffineEnvironment.transform 14 21620 env29993 = env29994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env29993 == env29994) = true)

theorem identity29994 : scanCanonicalize (H12AffineFastState.compose env29994 (packedSelected [0,2,6,7,11,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound29994 : packedSelected [0,2,6,7,11,17,18,20] rootPS < 2^1333 := by decide +kernel

def env29995 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21620,114,131072,138341,1024,21621,4112,136212,65,21843,120,65,149861,5440,17665,2128,1285,136212,256,21792,16385,592]

theorem envBound29995 : H12AffineFastState.Bounded env29995 := by
  intro p hp
  have h : env29995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29994_29995 : H12AffineEnvironment.transform 15 114 env29994 = env29995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env29994 == env29995) = true)

theorem identity29995 : scanCanonicalize (H12AffineFastState.compose env29995 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5409) := by decide +kernel

theorem selectedBound29995 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env29996 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5409,341,114,131072,138341,1024,340,4112,136212,65,114,120,65,138308,5440,4128,2128,1285,136212,256,1,5408,592]

theorem envBound29996 : H12AffineFastState.Bounded env29996 := by
  intro p hp
  have h : env29996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29995_29996 : H12AffineEnvironment.transform 13 5409 env29995 = env29996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5409 env29995 == env29996) = true)

theorem identity29996 : scanCanonicalize (H12AffineFastState.compose env29996 (packedSelected [6,9,22] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29996 : packedSelected [6,9,22] rootPS < 2^1333 := by decide +kernel

def env29997 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,120,5124,112,114,131072,138341,1024,113,4112,136212,65,114,120,65,138308,5221,4128,2128,1056,136212,37,1,5125,592]

theorem envBound29997 : H12AffineFastState.Bounded env29997 := by
  intro p hp
  have h : env29997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29996_29997 : H12AffineEnvironment.transform 7 37 env29996 = env29997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29996 == env29997) = true)

def env29998 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,58397,144493,62540,41310,8193,65,245018,115015,17665,10281,119043,201830,256,95530,103430,63069]

theorem envBound29998 : H12AffineFastState.Bounded env29998 := by
  intro p hp
  have h : env29998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29991_29998 : H12AffineEnvironment.transform 6 9 env29991 = env29998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29991 == env29998) = true)

theorem identity29998 : scanCanonicalize (H12AffineFastState.compose env29998 (packedSelected [0,4,8,10,11,12,14,15,16,22,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound29998 : packedSelected [0,4,8,10,11,12,14,15,16,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env29999 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,41050,131072,138341,1024,32769,58397,144493,62540,41310,8193,65,138560,24861,17665,10281,29017,177212,256,54640,13404,63069]

theorem envBound29999 : H12AffineFastState.Bounded env29999 := by
  intro p hp
  have h : env29999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29998_29999 : H12AffineEnvironment.transform 15 41050 env29998 = env29999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env29998 == env29999) = true)

theorem identity29999 : scanCanonicalize (H12AffineFastState.compose env29999 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound29999 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env30000 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,41050,49169,56436,1024,32769,58397,62588,62540,41310,8193,65,56657,24861,17665,10281,29017,29741,256,54640,13404,63069]

theorem envBound30000 : H12AffineFastState.Bounded env30000 := by
  intro p hp
  have h : env30000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29999_30000 : H12AffineEnvironment.transform 16 49169 env29999 = env30000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29999 == env30000) = true)

theorem identity30000 : scanCanonicalize (H12AffineFastState.compose env30000 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound30000 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21510,13389,10280,1024,29789,4161,32,16,21762,8193,65,10509,24861,17665,10281,29017,29741,256,8492,13404,513]

theorem envBound30001 : H12AffineFastState.Bounded env30001 := by
  intro p hp
  have h : env30001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30000_30001 : H12AffineEnvironment.transform 14 29788 env30000 = env30001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env30000 == env30001) = true)

theorem identity30001 : scanCanonicalize (H12AffineFastState.compose env30001 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound30001 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env30002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8460,342,13389,10280,1024,8461,4161,32,16,82,8193,65,10509,13389,4177,10281,9225,8573,256,8492,13404,513]

theorem envBound30002 : H12AffineFastState.Bounded env30002 := by
  intro p hp
  have h : env30002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30001_30002 : H12AffineEnvironment.transform 13 5456 env30001 = env30002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env30001 == env30002) = true)

theorem identity30002 : scanCanonicalize (H12AffineFastState.compose env30002 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound30002 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30003 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,1,342,5440,2341,1024,0,4161,32,16,82,268,65,2048,5440,4177,2340,1284,112,256,33,5457,513]

theorem envBound30003 : H12AffineFastState.Bounded env30003 := by
  intro p hp
  have h : env30003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30002_30003 : H12AffineEnvironment.transform 12 269 env30002 = env30003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env30002 == env30003) = true)

theorem identity30003 : scanCanonicalize (H12AffineFastState.compose env30003 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30003 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env30004 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,263,5393,2341,1024,0,4112,32,16,3,268,16,2048,5393,4096,2340,1284,33,256,33,5376,513]

theorem envBound30004 : H12AffineFastState.Bounded env30004 := by
  intro p hp
  have h : env30004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30003_30004 : H12AffineEnvironment.transform 5 17 env30003 = env30004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30003 == env30004) = true)

theorem identity30004 : scanCanonicalize (H12AffineFastState.compose env30004 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound30004 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30005 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1328,269,49,1,263,33,2341,1024,0,1312,32,16,3,268,16,2048,33,1328,2340,1284,33,256,33,48,513]

theorem envBound30005 : H12AffineFastState.Bounded env30005 := by
  intro p hp
  have h : env30005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30004_30005 : H12AffineEnvironment.transform 11 1328 env30004 = env30005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env30004 == env30005) = true)

theorem identity30005 : scanCanonicalize (H12AffineFastState.compose env30005 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound30005 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30006 : List Nat := [2,4,8,16,32,17,9,256,276,1024,2048,1328,269,49,1,263,33,2341,1024,0,1312,32,16,3,268,16,2048,33,1328,2340,1284,33,256,33,48,277]

theorem envBound30006 : H12AffineFastState.Bounded env30006 := by
  intro p hp
  have h : env30006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30005_30006 : H12AffineEnvironment.transform 8 276 env30005 = env30006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env30005 == env30006) = true)

theorem identity30006 : scanCanonicalize (H12AffineFastState.compose env30006 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound30006 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30007 : List Nat := [2,4,8,16,32,17,9,256,276,1024,1076,1328,269,49,1,263,33,1297,1024,0,1312,32,16,3,268,16,1076,33,1328,1296,1284,33,256,33,48,277]

theorem envBound30007 : H12AffineFastState.Bounded env30007 := by
  intro p hp
  have h : env30007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30006_30007 : H12AffineEnvironment.transform 10 1076 env30006 = env30007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env30006 == env30007) = true)

theorem identity30007 : scanCanonicalize (H12AffineFastState.compose env30007 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound30007 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30008 : List Nat := [2,4,8,16,32,17,9,256,276,304,260,0,269,49,1,263,33,33,304,0,16,32,16,3,268,16,260,33,0,32,52,33,256,33,48,277]

theorem envBound30008 : H12AffineFastState.Bounded env30008 := by
  intro p hp
  have h : env30008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30007_30008 : H12AffineEnvironment.transform 9 304 env30007 = env30008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env30007 == env30008) = true)

theorem identity30008 : scanCanonicalize (H12AffineFastState.compose env30008 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound30008 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env30009 : List Nat := [2,4,8,16,32,17,9,21,1,37,17,0,24,49,1,18,33,33,37,0,16,32,16,3,25,16,17,33,0,32,52,33,21,33,48,0]

theorem envBound30009 : H12AffineFastState.Bounded env30009 := by
  intro p hp
  have h : env30009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30008_30009 : H12AffineEnvironment.transform 7 21 env30008 = env30009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env30008 == env30009) = true)

theorem identity30009 : scanCanonicalize (H12AffineFastState.compose env30009 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30009 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env30010 : List Nat := [2,4,8,0,32,1,9,5,1,37,1,0,8,33,1,2,33,33,37,0,0,32,0,3,9,0,1,33,0,32,36,33,5,33,32,0]

theorem envBound30010 : H12AffineFastState.Bounded env30010 := by
  intro p hp
  have h : env30010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30009_30010 : H12AffineEnvironment.transform 3 0 env30009 = env30010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30009 == env30010) = true)

theorem identity30010 : scanCanonicalize (H12AffineFastState.compose env30010 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30010 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30011 : List Nat := [2,4,8,0,1,1,9,5,1,4,1,0,8,0,1,2,0,0,4,0,0,1,0,3,9,0,1,0,0,1,5,0,5,0,1,0]

theorem envBound30011 : H12AffineFastState.Bounded env30011 := by
  intro p hp
  have h : env30011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30010_30011 : H12AffineEnvironment.transform 4 1 env30010 = env30011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30010 == env30011) = true)

def env30012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452769,2114882,8328,65,6385123,115151,2538993,10401,2566642,4268163,256,485711,493802,2493989]

theorem envBound30012 : H12AffineFastState.Bounded env30012 := by
  intro p hp
  have h : env30012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29898_30012 : H12AffineEnvironment.transform 22 452769 env29898 = env30012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env29898 == env30012) = true)

def env30013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452769,441778,8328,65,4691219,115151,17665,10401,119042,4268163,256,485711,493802,63189]

theorem envBound30013 : H12AffineFastState.Bounded env30013 := by
  intro p hp
  have h : env30013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30012_30013 : H12AffineEnvironment.transform 20 456944 env30012 = env30013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456944 env30012 == env30013) = true)

def env30014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452769,441778,8328,65,245139,115151,17665,10401,119042,329731,256,485711,493802,63189]

theorem envBound30014 : H12AffineFastState.Bounded env30014 := by
  intro p hp
  have h : env30014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30013_30014 : H12AffineEnvironment.transform 21 272512 env30013 = env30014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env30013 == env30014) = true)

theorem identity30014 : scanCanonicalize (H12AffineFastState.compose env30014 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247994) := by decide +kernel

theorem selectedBound30014 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,77898,254010,73755,95496,8328,65,245139,115151,17665,10401,119042,180409,256,41461,16464,63189]

theorem envBound30015 : H12AffineFastState.Bounded env30015 := by
  intro p hp
  have h : env30015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30014_30015 : H12AffineEnvironment.transform 17 247994 env30014 = env30015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247994 env30014 == env30015) = true)

def env30016 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247962,1024,32769,77898,253978,73755,95496,8328,65,245139,115151,17665,10369,119042,180377,256,41429,16464,63189]

theorem envBound30016 : H12AffineFastState.Bounded env30016 := by
  intro p hp
  have h : env30016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30015_30016 : H12AffineEnvironment.transform 4 0 env30015 = env30016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30015 == env30016) = true)

theorem identity30016 : scanCanonicalize (H12AffineFastState.compose env30016 (packedSelected [0,2,3,4,6,7,11,14,15,22,24,26,31,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound30016 : packedSelected [0,2,3,4,6,7,11,14,15,22,24,26,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env30017 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,109014,1024,32769,77898,98646,73755,95496,8328,65,122079,115151,17665,10369,119042,41429,256,41429,16464,63189]

theorem envBound30017 : H12AffineFastState.Bounded env30017 := by
  intro p hp
  have h : env30017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30016_30017 : H12AffineEnvironment.transform 16 24908 env30016 = env30017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env30016 == env30017) = true)

theorem identity30017 : scanCanonicalize (H12AffineFastState.compose env30017 (packedSelected [3,4,7,9,11,16,17,18,20,23,24,26,27,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound30017 : packedSelected [3,4,7,9,11,16,17,18,20,23,24,26,27,31,32] rootPS < 2^1333 := by decide +kernel

def env30018 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,24908,97495,1024,21760,77898,87127,73755,95496,8328,65,68062,70862,17665,10369,66563,29908,256,29908,16464,9172]

theorem envBound30018 : H12AffineFastState.Bounded env30018 := by
  intro p hp
  have h : env30018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30017_30018 : H12AffineEnvironment.transform 14 21761 env30017 = env30018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env30017 == env30018) = true)

theorem identity30018 : scanCanonicalize (H12AffineFastState.compose env30018 (packedSelected [0,2,3,4,6,7,10,17,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound30018 : packedSelected [0,2,3,4,6,7,10,17,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30019 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,21761,29963,24908,2524,1024,21760,17729,8540,21776,3,8328,65,31957,25029,17665,10369,28936,29908,256,29908,16464,9172]

theorem envBound30019 : H12AffineFastState.Bounded env30019 := by
  intro p hp
  have h : env30019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30018_30019 : H12AffineEnvironment.transform 15 29963 env30018 = env30019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env30018 == env30019) = true)

theorem identity30019 : scanCanonicalize (H12AffineFastState.compose env30019 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound30019 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30020 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,5377,0,8202,13389,2524,1024,1,4160,8540,17,3,8328,65,10708,13508,4096,10369,9225,8661,256,8661,5457,9172]

theorem envBound30020 : H12AffineFastState.Bounded env30020 := by
  intro p hp
  have h : env30020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30019_30020 : H12AffineEnvironment.transform 13 5377 env30019 = env30020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30019 == env30020) = true)

theorem identity30020 : scanCanonicalize (H12AffineFastState.compose env30020 (packedSelected [0,2,7,14,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30020 : packedSelected [0,2,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env30021 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,5377,0,8202,13340,2445,1024,1,4113,8461,17,3,8328,16,10629,13461,4096,10369,9225,8580,256,8580,5376,9093]

theorem envBound30021 : H12AffineFastState.Bounded env30021 := by
  intro p hp
  have h : env30021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30020_30021 : H12AffineEnvironment.transform 5 17 env30020 = env30021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30020 == env30021) = true)

theorem identity30021 : scanCanonicalize (H12AffineFastState.compose env30021 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound30021 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env30022 : List Nat := [2,4,8,16,0,17,128,256,512,20,2048,4096,8192,4373,0,8202,12296,2445,20,1,4113,8461,17,3,8328,16,10629,12417,4096,10369,8221,8580,256,8580,4372,9093]

theorem envBound30022 : H12AffineFastState.Bounded env30022 := by
  intro p hp
  have h : env30022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30021_30022 : H12AffineEnvironment.transform 9 20 env30021 = env30022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30021 == env30022) = true)

theorem identity30022 : scanCanonicalize (H12AffineFastState.compose env30022 (packedSelected [11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2201) := by decide +kernel

theorem selectedBound30022 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env30023 : List Nat := [2,4,8,16,0,17,128,256,512,20,2048,2201,8192,2444,0,8202,10385,2445,20,1,2184,8461,17,3,8328,16,10629,10264,2201,10369,8221,8580,256,8580,2445,9093]

theorem envBound30023 : H12AffineFastState.Bounded env30023 := by
  intro p hp
  have h : env30023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30022_30023 : H12AffineEnvironment.transform 11 2201 env30022 = env30023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2201 env30022 == env30023) = true)

theorem identity30023 : scanCanonicalize (H12AffineFastState.compose env30023 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound30023 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env30024 : List Nat := [2,4,8,16,0,17,128,256,512,20,2048,2201,389,2444,0,399,2324,2445,20,1,2184,136,17,3,269,16,2048,2461,2201,2308,408,1,256,1,2445,512]

theorem envBound30024 : H12AffineFastState.Bounded env30024 := by
  intro p hp
  have h : env30024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30023_30024 : H12AffineEnvironment.transform 12 389 env30023 = env30024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env30023 == env30024) = true)

theorem identity30024 : scanCanonicalize (H12AffineFastState.compose env30024 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound30024 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env30025 : List Nat := [2,4,8,16,0,17,128,141,512,20,2048,2201,8,2049,0,2,2201,2048,20,1,2184,136,17,3,128,16,2048,2064,2201,2185,21,1,141,1,2048,512]

theorem envBound30025 : H12AffineFastState.Bounded env30025 := by
  intro p hp
  have h : env30025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30024_30025 : H12AffineEnvironment.transform 7 141 env30024 = env30025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env30024 == env30025) = true)

theorem identity30025 : scanCanonicalize (H12AffineFastState.compose env30025 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound30025 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env30026 : List Nat := [2,4,8,16,0,17,128,141,512,20,1,152,8,0,0,2,152,1,20,1,137,136,17,3,128,16,1,17,152,136,21,1,141,1,1,512]

theorem envBound30026 : H12AffineFastState.Bounded env30026 := by
  intro p hp
  have h : env30026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30025_30026 : H12AffineEnvironment.transform 10 1 env30025 = env30026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env30025 == env30026) = true)

theorem identity30026 : scanCanonicalize (H12AffineFastState.compose env30026 (packedSelected [2,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30026 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env30027 : List Nat := [2,4,8,16,0,17,8,5,512,20,1,16,8,0,0,2,16,1,20,1,1,0,17,3,8,16,1,17,16,0,21,1,5,1,1,512]

theorem envBound30027 : H12AffineFastState.Bounded env30027 := by
  intro p hp
  have h : env30027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30026_30027 : H12AffineEnvironment.transform 6 8 env30026 = env30027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30026 == env30027) = true)

theorem identity30027 : scanCanonicalize (H12AffineFastState.compose env30027 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound30027 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30028 : List Nat := [2,1,8,16,0,17,8,0,512,17,1,16,8,0,0,2,16,1,17,1,1,0,17,3,8,16,1,17,16,0,16,1,0,1,1,512]

theorem envBound30028 : H12AffineFastState.Bounded env30028 := by
  intro p hp
  have h : env30028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30027_30028 : H12AffineEnvironment.transform 1 1 env30027 = env30028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env30027 == env30028) = true)

theorem identity30028 : scanCanonicalize (H12AffineFastState.compose env30028 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30028 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30029 : List Nat := [1,1,8,16,0,17,8,0,512,17,1,16,8,0,0,1,16,1,17,1,1,0,17,0,8,16,1,17,16,0,16,1,0,1,1,512]

theorem envBound30029 : H12AffineFastState.Bounded env30029 := by
  intro p hp
  have h : env30029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30028_30029 : H12AffineEnvironment.transform 0 1 env30028 = env30029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30028 == env30029) = true)

theorem identity30029 : scanCanonicalize (H12AffineFastState.compose env30029 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30029 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30030 : List Nat := [1,1,8,0,0,1,8,0,512,1,1,0,8,0,0,1,0,1,1,1,1,0,1,0,8,0,1,1,0,0,0,1,0,1,1,512]

theorem envBound30030 : H12AffineFastState.Bounded env30030 := by
  intro p hp
  have h : env30030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30029_30030 : H12AffineEnvironment.transform 3 0 env30029 = env30030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30029 == env30030) = true)

theorem identity30030 : scanCanonicalize (H12AffineFastState.compose env30030 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound30030 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30031 : List Nat := [1,1,0,0,0,1,0,0,512,1,1,0,0,0,0,1,0,1,1,1,1,0,1,0,0,0,1,1,0,0,0,1,0,1,1,512]

theorem envBound30031 : H12AffineFastState.Bounded env30031 := by
  intro p hp
  have h : env30031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30030_30031 : H12AffineEnvironment.transform 2 0 env30030 = env30031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env30030 == env30031) = true)

def env30032 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247963,1024,32769,77898,253979,73755,95496,8328,65,245139,115151,17665,10368,119042,180376,256,41428,16464,63189]

theorem envBound30032 : H12AffineFastState.Bounded env30032 := by
  intro p hp
  have h : env30032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30015_30032 : H12AffineEnvironment.transform 4 1 env30015 = env30032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30015 == env30032) = true)

theorem identity30032 : scanCanonicalize (H12AffineFastState.compose env30032 (packedSelected [0,2,3,4,6,7,11,14,15,22,24,26,31,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound30032 : packedSelected [0,2,3,4,6,7,11,14,15,22,24,26,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env30033 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,89347,1024,32769,77898,95619,73755,95496,8328,65,75787,115151,17665,10368,119042,21760,256,41428,16464,63189]

theorem envBound30033 : H12AffineFastState.Bounded env30033 := by
  intro p hp
  have h : env30033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30032_30033 : H12AffineEnvironment.transform 16 38296 env30032 = env30033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env30032 == env30033) = true)

theorem identity30033 : scanCanonicalize (H12AffineFastState.compose env30033 (packedSelected [0,1,2,4,5,7,8,10,11,12,17,19,22,23,24,26,31,35,41] rootPS)) = affineNative (2^(14+1) ^^^ 476) := by decide +kernel

theorem selectedBound30033 : packedSelected [0,1,2,4,5,7,8,10,11,12,17,19,22,23,24,26,31,35,41] rootPS < 2^1333 := by decide +kernel

def env30034 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,476,65536,5188,89347,1024,477,77898,95619,73755,95496,8328,65,75787,81939,17665,10368,86238,21760,256,8200,16464,30473]

theorem envBound30034 : H12AffineFastState.Bounded env30034 := by
  intro p hp
  have h : env30034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30033_30034 : H12AffineEnvironment.transform 14 476 env30033 = env30034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 476 env30033 == env30034) = true)

theorem identity30034 : scanCanonicalize (H12AffineFastState.compose env30034 (packedSelected [0,4,6,7,8,9,10,12,15,16,18,20,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 29790) := by decide +kernel

theorem selectedBound30034 : packedSelected [0,4,6,7,8,9,10,12,15,16,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env30035 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,476,29790,5188,10589,1024,477,17428,477,21573,342,8328,65,23637,13389,17665,10368,9344,21760,256,8200,16464,30473]

theorem envBound30035 : H12AffineFastState.Bounded env30035 := by
  intro p hp
  have h : env30035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30034_30035 : H12AffineEnvironment.transform 15 29790 env30034 = env30035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29790 env30034 == env30035) = true)

theorem identity30035 : scanCanonicalize (H12AffineFastState.compose env30035 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13576) := by decide +kernel

theorem selectedBound30035 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env30036 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,13576,476,342,5188,10589,1024,477,12572,477,8525,342,8328,65,10589,13389,12297,10368,9344,8200,256,8200,13656,513]

theorem envBound30036 : H12AffineFastState.Bounded env30036 := by
  intro p hp
  have h : env30036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30035_30036 : H12AffineEnvironment.transform 13 13576 env30035 = env30036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13576 env30035 == env30036) = true)

theorem identity30036 : scanCanonicalize (H12AffineFastState.compose env30036 (packedSelected [2,3,4,5,9,10,11,12,15,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound30036 : packedSelected [2,3,4,5,9,10,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env30037 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,349,5205,476,342,5188,2048,1024,477,4161,477,16,342,469,65,2048,5392,4436,2525,1501,341,256,341,5125,513]

theorem envBound30037 : H12AffineFastState.Bounded env30037 := by
  intro p hp
  have h : env30037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30036_30037 : H12AffineEnvironment.transform 12 349 env30036 = env30037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env30036 == env30037) = true)

theorem identity30037 : scanCanonicalize (H12AffineFastState.compose env30037 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound30037 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30038 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,129,5205,0,138,5188,2048,1024,1,4161,1,16,138,9,65,2048,5324,4232,2049,1025,137,220,137,5125,513]

theorem envBound30038 : H12AffineFastState.Bounded env30038 := by
  intro p hp
  have h : env30038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30037_30038 : H12AffineEnvironment.transform 7 220 env30037 = env30038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env30037 == env30038) = true)

theorem identity30038 : scanCanonicalize (H12AffineFastState.compose env30038 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1092) := by decide +kernel

theorem selectedBound30038 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30039 : List Nat := [2,4,8,16,1,64,128,220,512,1024,1092,4096,129,5205,0,138,5188,1092,1024,1,4161,1,16,138,9,65,1092,5324,4232,1093,1025,137,220,137,5125,513]

theorem envBound30039 : H12AffineFastState.Bounded env30039 := by
  intro p hp
  have h : env30039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30038_30039 : H12AffineEnvironment.transform 10 1092 env30038 = env30039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1092 env30038 == env30039) = true)

theorem identity30039 : scanCanonicalize (H12AffineFastState.compose env30039 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound30039 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env30040 : List Nat := [2,4,8,16,1,64,128,220,512,221,153,4096,129,4232,0,138,4249,153,221,1,4161,1,16,138,9,65,153,4113,4232,152,220,137,220,137,4312,513]

theorem envBound30040 : H12AffineFastState.Bounded env30040 := by
  intro p hp
  have h : env30040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30039_30040 : H12AffineEnvironment.transform 9 221 env30039 = env30040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env30039 == env30040) = true)

theorem identity30040 : scanCanonicalize (H12AffineFastState.compose env30040 (packedSelected [1,2,8] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound30040 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env30041 : List Nat := [2,4,8,16,1,64,128,220,512,221,153,65,129,201,0,138,216,153,221,1,0,1,16,138,9,65,153,80,201,152,220,137,220,137,153,513]

theorem envBound30041 : H12AffineFastState.Bounded env30041 := by
  intro p hp
  have h : env30041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30040_30041 : H12AffineEnvironment.transform 11 65 env30040 = env30041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env30040 == env30041) = true)

theorem identity30041 : scanCanonicalize (H12AffineFastState.compose env30041 (packedSelected [2,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30041 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env30042 : List Nat := [2,4,8,16,1,64,9,85,512,84,16,65,8,64,0,3,81,16,84,1,0,1,16,3,9,65,16,80,64,17,85,0,85,0,16,513]

theorem envBound30042 : H12AffineFastState.Bounded env30042 := by
  intro p hp
  have h : env30042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30041_30042 : H12AffineEnvironment.transform 6 9 env30041 = env30042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30041 == env30042) = true)

theorem identity30042 : scanCanonicalize (H12AffineFastState.compose env30042 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30042 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30043 : List Nat := [2,4,8,16,1,64,9,85,1,84,16,65,8,64,0,3,81,16,84,1,0,1,16,3,9,65,16,80,64,17,85,0,85,0,16,0]

theorem envBound30043 : H12AffineFastState.Bounded env30043 := by
  intro p hp
  have h : env30043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30042_30043 : H12AffineEnvironment.transform 8 1 env30042 = env30043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30042 == env30043) = true)

theorem identity30043 : scanCanonicalize (H12AffineFastState.compose env30043 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30043 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30044 : List Nat := [2,4,8,16,1,16,9,5,1,4,16,17,8,16,0,3,1,16,4,1,0,1,16,3,9,17,16,0,16,17,5,0,5,0,16,0]

theorem envBound30044 : H12AffineFastState.Bounded env30044 := by
  intro p hp
  have h : env30044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30043_30044 : H12AffineEnvironment.transform 5 16 env30043 = env30044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30043 == env30044) = true)

theorem identity30044 : scanCanonicalize (H12AffineFastState.compose env30044 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30044 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30045 : List Nat := [2,4,8,0,1,0,9,5,1,4,0,1,8,0,0,3,1,0,4,1,0,1,0,3,9,1,0,0,0,1,5,0,5,0,0,0]

theorem envBound30045 : H12AffineFastState.Bounded env30045 := by
  intro p hp
  have h : env30045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30044_30045 : H12AffineEnvironment.transform 3 0 env30044 = env30045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30044 == env30045) = true)

def env30046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272513,452769,441778,8328,65,245138,115151,17665,10401,119042,329730,256,485711,493802,63189]

theorem envBound30046 : H12AffineFastState.Bounded env30046 := by
  intro p hp
  have h : env30046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30013_30046 : H12AffineEnvironment.transform 21 272513 env30013 = env30046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env30013 == env30046) = true)

theorem identity30046 : scanCanonicalize (H12AffineFastState.compose env30046 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound30046 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,456944,272513,452769,441778,8328,65,171417,57796,17665,10401,61705,272393,256,411972,436449,63189]

theorem envBound30047 : H12AffineFastState.Bounded env30047 := by
  intro p hp
  have h : env30047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30046_30047 : H12AffineEnvironment.transform 15 8203 env30046 = env30047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env30046 == env30047) = true)

def env30048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,456824,272393,452649,441658,8192,65,171281,57676,17665,10281,61705,272393,256,411972,436329,63069]

theorem envBound30048 : H12AffineFastState.Bounded env30048 := by
  intro p hp
  have h : env30048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30047_30048 : H12AffineEnvironment.transform 6 8 env30047 = env30048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30047 == env30048) = true)

theorem identity30048 : scanCanonicalize (H12AffineFastState.compose env30048 (packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 43357) := by decide +kernel

theorem selectedBound30048 : packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env30049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,43357,1024,32769,151845,33108,147828,136295,8192,65,171281,57676,17665,10281,61705,33108,256,188441,131380,63069]

theorem envBound30049 : H12AffineFastState.Bounded env30049 := by
  intro p hp
  have h : env30049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30048_30049 : H12AffineEnvironment.transform 17 43357 env30048 = env30049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43357 env30048 == env30049) = true)

theorem identity30049 : scanCanonicalize (H12AffineFastState.compose env30049 (packedSelected [0,6,16,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound30049 : packedSelected [0,6,16,20,27] rootPS < 2^1333 := by decide +kernel

def env30050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38161,43357,1024,32769,50228,33108,54373,33142,8192,65,2048,57676,17665,10281,61705,33108,256,29960,37925,63069]

theorem envBound30050 : H12AffineFastState.Bounded env30050 := by
  intro p hp
  have h : env30050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30049_30050 : H12AffineEnvironment.transform 16 38161 env30049 = env30050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env30049 == env30050) = true)

theorem identity30050 : scanCanonicalize (H12AffineFastState.compose env30050 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30050 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env30051 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,13389,2049,1024,8541,25960,8200,30009,8234,8192,65,2048,16400,17665,10281,20565,8200,256,29960,13689,22273]

theorem envBound30051 : H12AffineFastState.Bounded env30051 := by
  intro p hp
  have h : env30051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30050_30051 : H12AffineEnvironment.transform 14 8540 env30050 = env30051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30050 == env30051) = true)

def env30052 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,456825,272392,452648,441659,8193,65,171280,57677,17665,10280,61705,272393,256,411972,436328,63068]

theorem envBound30052 : H12AffineFastState.Bounded env30052 := by
  intro p hp
  have h : env30052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30047_30052 : H12AffineEnvironment.transform 6 9 env30047 = env30052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30047 == env30052) = true)

theorem identity30052 : scanCanonicalize (H12AffineFastState.compose env30052 (packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound30052 : packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env30053 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,46157,262144,1024,32769,281652,272392,285797,264566,8193,65,10589,57677,17665,10280,61705,272393,256,326921,269349,63068]

theorem envBound30053 : H12AffineFastState.Bounded env30053 := by
  intro p hp
  have h : env30053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30052_30053 : H12AffineEnvironment.transform 16 46157 env30052 = env30053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env30052 == env30053) = true)

theorem identity30053 : scanCanonicalize (H12AffineFastState.compose env30053 (packedSelected [0,1,3,4,5,12,14,15,17,18,19,20,22,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound30053 : packedSelected [0,1,3,4,5,12,14,15,17,18,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env30054 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,46157,32040,1024,32769,12572,21792,8525,29790,8193,65,10589,57677,17665,10280,61705,21793,256,32801,24845,63068]

theorem envBound30054 : H12AffineFastState.Bounded env30054 := by
  intro p hp
  have h : env30054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30053_30054 : H12AffineEnvironment.transform 17 32040 env30053 = env30054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env30053 == env30054) = true)

theorem identity30054 : scanCanonicalize (H12AffineFastState.compose env30054 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30054 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env30055 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,5393,32040,1024,8541,12572,21792,8525,29790,8193,65,10589,16401,17665,10280,20565,21793,256,8573,24845,22272]

theorem envBound30055 : H12AffineFastState.Bounded env30055 := by
  intro p hp
  have h : env30055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30054_30055 : H12AffineEnvironment.transform 14 8540 env30054 = env30055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30054 == env30055) = true)

theorem identity30055 : scanCanonicalize (H12AffineFastState.compose env30055 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound30055 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env30056 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,16384,1297,1094,5393,22885,1024,1296,5457,21792,1280,20499,1100,65,3344,16401,17665,3173,20565,21793,256,1328,17728,22272]

theorem envBound30056 : H12AffineFastState.Bounded env30056 := by
  intro p hp
  have h : env30056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30055_30056 : H12AffineEnvironment.transform 12 1101 env30055 = env30056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env30055 == env30056) = true)

theorem identity30056 : scanCanonicalize (H12AffineFastState.compose env30056 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound30056 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env30057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,1101,16384,1297,1094,2065,17509,1024,1296,2129,18464,1280,19731,1100,65,3344,16401,17665,3173,19797,18465,256,1328,17728,18944]

theorem envBound30057 : H12AffineFastState.Bounded env30057 := by
  intro p hp
  have h : env30057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30056_30057 : H12AffineEnvironment.transform 11 3328 env30056 = env30057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env30056 == env30057) = true)

theorem identity30057 : scanCanonicalize (H12AffineFastState.compose env30057 (packedSelected [1,6,7,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2421) := by decide +kernel

theorem selectedBound30057 : packedSelected [1,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env30058 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,1101,2421,1297,1094,2065,3344,1024,1296,2129,341,1280,1126,1100,65,3344,2404,3188,3173,1056,340,256,1328,3125,885]

theorem envBound30058 : H12AffineFastState.Bounded env30058 := by
  intro p hp
  have h : env30058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30057_30058 : H12AffineEnvironment.transform 13 2421 env30057 = env30058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2421 env30057 == env30058) = true)

theorem identity30058 : scanCanonicalize (H12AffineFastState.compose env30058 (packedSelected [0,1,2,3,5,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 256) := by decide +kernel

theorem selectedBound30058 : packedSelected [0,1,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env30059 : List Nat := [2,4,8,16,32,64,9,256,256,1024,2048,3328,1101,2421,1297,1094,2065,3344,1024,1296,2129,341,1280,1126,1100,65,3344,2404,3188,3173,1056,340,256,1328,3125,117]

theorem envBound30059 : H12AffineFastState.Bounded env30059 := by
  intro p hp
  have h : env30059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30058_30059 : H12AffineEnvironment.transform 8 256 env30058 = env30059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 256 env30058 == env30059) = true)

theorem identity30059 : scanCanonicalize (H12AffineFastState.compose env30059 (packedSelected [1,2,4,6,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound30059 : packedSelected [1,2,4,6,8,10] rootPS < 2^1333 := by decide +kernel

def env30060 : List Nat := [2,4,8,16,32,64,9,116,116,1024,2048,3188,1101,2049,1125,1094,2065,3172,1024,1124,2129,33,1140,1126,1100,65,3172,2064,3188,3173,1056,32,116,1092,3125,117]

theorem envBound30060 : H12AffineFastState.Bounded env30060 := by
  intro p hp
  have h : env30060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30059_30060 : H12AffineEnvironment.transform 7 116 env30059 = env30060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env30059 == env30060) = true)

theorem identity30060 : scanCanonicalize (H12AffineFastState.compose env30060 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound30060 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env30061 : List Nat := [2,4,8,16,32,28,9,40,40,1024,2048,3112,1041,2049,1081,1050,2065,3128,1024,1080,2061,33,1064,1082,1040,29,3128,2064,3112,3129,1056,32,40,1048,3125,41]

theorem envBound30061 : H12AffineFastState.Bounded env30061 := by
  intro p hp
  have h : env30061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30060_30061 : H12AffineEnvironment.transform 5 28 env30060 = env30061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env30060 == env30061) = true)

theorem identity30061 : scanCanonicalize (H12AffineFastState.compose env30061 (packedSelected [0,2,3,11] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound30061 : packedSelected [0,2,3,11] rootPS < 2^1333 := by decide +kernel

def env30062 : List Nat := [2,4,8,16,32,28,9,40,40,1024,1076,28,1041,1077,1081,1050,1061,12,1024,1080,1081,33,1064,1082,1040,29,12,1060,28,13,1056,32,40,1048,1,41]

theorem envBound30062 : H12AffineFastState.Bounded env30062 := by
  intro p hp
  have h : env30062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30061_30062 : H12AffineEnvironment.transform 10 1076 env30061 = env30062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env30061 == env30062) = true)

theorem identity30062 : scanCanonicalize (H12AffineFastState.compose env30062 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30062 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30063 : List Nat := [2,4,8,16,0,28,9,8,8,1024,1044,28,1041,1045,1049,1050,1029,12,1024,1048,1049,1,1032,1050,1040,29,12,1028,28,13,1024,0,8,1048,1,9]

theorem envBound30063 : H12AffineFastState.Bounded env30063 := by
  intro p hp
  have h : env30063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30062_30063 : H12AffineEnvironment.transform 4 0 env30062 = env30063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30062 == env30063) = true)

theorem identity30063 : scanCanonicalize (H12AffineFastState.compose env30063 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound30063 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env30064 : List Nat := [2,4,4,16,0,16,5,4,4,1024,1044,16,1041,1045,1045,1046,1029,0,1024,1044,1045,1,1028,1046,1040,17,0,1028,16,1,1024,0,4,1044,1,5]

theorem envBound30064 : H12AffineFastState.Bounded env30064 := by
  intro p hp
  have h : env30064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30063_30064 : H12AffineEnvironment.transform 2 4 env30063 = env30064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env30063 == env30064) = true)

theorem identity30064 : scanCanonicalize (H12AffineFastState.compose env30064 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound30064 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30065 : List Nat := [2,4,4,16,0,16,5,4,4,20,0,16,5,1,1,2,17,0,20,0,1,1,16,2,4,17,0,16,16,1,20,0,4,0,1,5]

theorem envBound30065 : H12AffineFastState.Bounded env30065 := by
  intro p hp
  have h : env30065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30064_30065 : H12AffineEnvironment.transform 9 20 env30064 = env30065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30064 == env30065) = true)

theorem identity30065 : scanCanonicalize (H12AffineFastState.compose env30065 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound30065 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30066 : List Nat := [2,4,4,6,0,6,5,4,4,2,0,6,5,1,1,2,7,0,2,0,1,1,6,2,4,7,0,6,6,1,2,0,4,0,1,5]

theorem envBound30066 : H12AffineFastState.Bounded env30066 := by
  intro p hp
  have h : env30066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30065_30066 : H12AffineEnvironment.transform 3 6 env30065 = env30066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env30065 == env30066) = true)

theorem identity30066 : scanCanonicalize (H12AffineFastState.compose env30066 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30066 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30067 : List Nat := [2,3,3,1,0,1,2,3,3,2,0,1,2,1,1,2,0,0,2,0,1,1,1,2,3,0,0,1,1,1,2,0,3,0,1,2]

theorem envBound30067 : H12AffineFastState.Bounded env30067 := by
  intro p hp
  have h : env30067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30066_30067 : H12AffineEnvironment.transform 1 3 env30066 = env30067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30066 == env30067) = true)

def env30068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,452769,441779,8328,65,4691218,115151,17664,10401,119043,4268163,256,485711,493802,63188]

theorem envBound30068 : H12AffineFastState.Bounded env30068 := by
  intro p hp
  have h : env30068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30012_30068 : H12AffineEnvironment.transform 20 456945 env30012 = env30068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456945 env30012 == env30068) = true)

def env30069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272512,452769,441779,8328,65,245138,115151,17664,10401,119043,329731,256,485711,493802,63188]

theorem envBound30069 : H12AffineFastState.Bounded env30069 := by
  intro p hp
  have h : env30069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30068_30069 : H12AffineEnvironment.transform 21 272512 env30068 = env30069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env30068 == env30069) = true)

theorem identity30069 : scanCanonicalize (H12AffineFastState.compose env30069 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound30069 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,115870,201967,120014,98780,8328,65,245138,115151,17664,10401,119043,144492,256,21792,46213,63188]

theorem envBound30070 : H12AffineFastState.Bounded env30070 := by
  intro p hp
  have h : env30070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30069_30070 : H12AffineEnvironment.transform 17 212079 env30069 = env30070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env30069 == env30070) = true)

def env30071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130175,1024,32769,115870,120063,120014,98780,8328,65,97666,115151,17664,10401,119043,62588,256,21792,46213,63188]

theorem envBound30071 : H12AffineFastState.Bounded env30071 := by
  intro p hp
  have h : env30071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30070_30071 : H12AffineEnvironment.transform 16 49168 env30070 = env30071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env30070 == env30071) = true)

theorem identity30071 : scanCanonicalize (H12AffineFastState.compose env30071 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30071 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env30072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,65536,49168,122147,1024,32769,115870,120063,120014,98780,468,65,89310,115151,17664,2557,119043,54560,256,21792,38361,55176]

theorem envBound30072 : H12AffineFastState.Bounded env30072 := by
  intro p hp
  have h : env30072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30071_30072 : H12AffineEnvironment.transform 12 348 env30071 = env30072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30071 == env30072) = true)

theorem identity30072 : scanCanonicalize (H12AffineFastState.compose env30072 (packedSelected [1,4,5,7,8,9,16,20,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound30072 : packedSelected [1,4,5,7,8,9,16,20,24,27] rootPS < 2^1333 := by decide +kernel

def env30073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,54358,49168,2421,1024,32769,4296,169,152,21898,468,65,34952,5529,17664,2557,1365,54560,256,21792,38361,55176]

theorem envBound30073 : H12AffineFastState.Bounded env30073 := by
  intro p hp
  have h : env30073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30072_30073 : H12AffineEnvironment.transform 15 54358 env30072 = env30073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env30072 == env30073) = true)

theorem identity30073 : scanCanonicalize (H12AffineFastState.compose env30073 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound30073 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env30074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,32768,33110,38160,2421,1024,32769,4296,169,152,138,468,65,34952,5529,4096,2557,1365,32800,256,32,38361,33416]

theorem envBound30074 : H12AffineFastState.Bounded env30074 := by
  intro p hp
  have h : env30074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30073_30074 : H12AffineEnvironment.transform 13 5376 env30073 = env30074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30073 == env30074) = true)

theorem identity30074 : scanCanonicalize (H12AffineFastState.compose env30074 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 1433) := by decide +kernel

theorem selectedBound30074 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env30075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,1433,1231,4233,2421,1024,1432,4296,169,152,138,468,65,3345,5529,4096,2557,1365,1465,256,32,4160,1809]

theorem envBound30075 : H12AffineFastState.Bounded env30075 := by
  intro p hp
  have h : env30075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30074_30075 : H12AffineEnvironment.transform 14 1433 env30074 = env30075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1433 env30074 == env30075) = true)

theorem identity30075 : scanCanonicalize (H12AffineFastState.compose env30075 (packedSelected [0,1,4,7,8,9,10,14,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound30075 : packedSelected [0,1,4,7,8,9,10,14,15,16] rootPS < 2^1333 := by decide +kernel

def env30076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,64,348,1344,1433,1231,201,2421,1024,1432,136,169,152,138,468,65,3345,1497,64,2557,1365,1465,256,32,0,1809]

theorem envBound30076 : H12AffineFastState.Bounded env30076 := by
  intro p hp
  have h : env30076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30075_30076 : H12AffineEnvironment.transform 11 64 env30075 = env30076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env30075 == env30076) = true)

theorem identity30076 : scanCanonicalize (H12AffineFastState.compose env30076 (packedSelected [1,3,5,8,11,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 1433) := by decide +kernel

theorem selectedBound30076 : packedSelected [1,3,5,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env30077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1433,64,348,1344,1433,1231,201,1260,1024,1432,136,169,152,138,468,65,136,1497,64,1124,1365,1465,256,32,0,1809]

theorem envBound30077 : H12AffineFastState.Bounded env30077 := by
  intro p hp
  have h : env30077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30076_30077 : H12AffineEnvironment.transform 10 1433 env30076 = env30077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1433 env30076 == env30077) = true)

theorem identity30077 : scanCanonicalize (H12AffineFastState.compose env30077 (packedSelected [2,3,5,6,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound30077 : packedSelected [2,3,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env30078 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1125,64,160,1212,1125,1231,201,1260,1024,1124,136,169,152,138,40,65,136,1061,64,1124,1193,1093,252,32,0,1773]

theorem envBound30078 : H12AffineFastState.Bounded env30078 := by
  intro p hp
  have h : env30078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30077_30078 : H12AffineEnvironment.transform 7 252 env30077 = env30078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env30077 == env30078) = true)

theorem identity30078 : scanCanonicalize (H12AffineFastState.compose env30078 (packedSelected [0,1,4,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound30078 : packedSelected [0,1,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env30079 : List Nat := [2,4,8,16,32,64,88,36,512,1024,1125,64,120,1124,1125,1047,17,1076,1024,1124,80,113,64,82,40,65,80,1061,64,1124,1137,1093,36,32,0,1589]

theorem envBound30079 : H12AffineFastState.Bounded env30079 := by
  intro p hp
  have h : env30079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30078_30079 : H12AffineEnvironment.transform 6 88 env30078 = env30079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env30078 == env30079) = true)

theorem identity30079 : scanCanonicalize (H12AffineFastState.compose env30079 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound30079 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env30080 : List Nat := [2,4,8,16,32,64,88,36,512,53,80,64,120,81,80,34,17,1,53,81,80,113,64,82,40,65,80,16,64,81,68,112,36,32,0,512]

theorem envBound30080 : H12AffineFastState.Bounded env30080 := by
  intro p hp
  have h : env30080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30079_30080 : H12AffineEnvironment.transform 9 53 env30079 = env30080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env30079 == env30080) = true)

theorem identity30080 : scanCanonicalize (H12AffineFastState.compose env30080 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound30080 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30081 : List Nat := [2,4,8,16,32,64,88,36,18,53,80,64,120,81,80,34,17,1,53,81,80,113,64,82,40,65,80,16,64,81,68,112,36,32,0,18]

theorem envBound30081 : H12AffineFastState.Bounded env30081 := by
  intro p hp
  have h : env30081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30080_30081 : H12AffineEnvironment.transform 8 18 env30080 = env30081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env30080 == env30081) = true)

theorem identity30081 : scanCanonicalize (H12AffineFastState.compose env30081 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 41) := by decide +kernel

theorem selectedBound30081 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env30082 : List Nat := [2,4,8,16,32,41,49,36,18,53,57,41,17,56,57,34,17,1,53,56,57,24,41,59,40,40,57,16,41,56,45,25,36,32,0,18]

theorem envBound30082 : H12AffineFastState.Bounded env30082 := by
  intro p hp
  have h : env30082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30081_30082 : H12AffineEnvironment.transform 5 41 env30081 = env30082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 41 env30081 == env30082) = true)

theorem identity30082 : scanCanonicalize (H12AffineFastState.compose env30082 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound30082 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env30083 : List Nat := [2,4,8,15,32,41,46,36,13,42,38,41,14,39,38,34,14,1,42,39,38,7,41,36,40,40,38,15,41,39,45,6,36,32,0,13]

theorem envBound30083 : H12AffineFastState.Bounded env30083 := by
  intro p hp
  have h : env30083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30082_30083 : H12AffineEnvironment.transform 3 15 env30082 = env30083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env30082 == env30083) = true)

theorem identity30083 : scanCanonicalize (H12AffineFastState.compose env30083 (packedSelected [2,6] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30083 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30084 : List Nat := [2,2,8,9,32,41,40,34,11,42,32,41,8,33,32,34,8,1,42,33,32,1,41,34,40,40,32,9,41,33,43,0,34,32,0,11]

theorem envBound30084 : H12AffineFastState.Bounded env30084 := by
  intro p hp
  have h : env30084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30083_30084 : H12AffineEnvironment.transform 1 2 env30083 = env30084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30083 == env30084) = true)

theorem identity30084 : scanCanonicalize (H12AffineFastState.compose env30084 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30084 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30085 : List Nat := [2,2,8,9,0,9,8,2,11,10,0,9,8,1,0,2,8,1,10,1,0,1,9,2,8,8,0,9,9,1,11,0,2,0,0,11]

theorem envBound30085 : H12AffineFastState.Bounded env30085 := by
  intro p hp
  have h : env30085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30084_30085 : H12AffineEnvironment.transform 4 0 env30084 = env30085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30084 == env30085) = true)

def env30086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130174,1024,32769,115870,120062,120014,98780,8328,65,97667,115151,17664,10401,119043,62589,256,21792,46213,63188]

theorem envBound30086 : H12AffineFastState.Bounded env30086 := by
  intro p hp
  have h : env30086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30070_30086 : H12AffineEnvironment.transform 16 49169 env30070 = env30086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env30070 == env30086) = true)

theorem identity30086 : scanCanonicalize (H12AffineFastState.compose env30086 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound30086 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env30087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33030,49169,32120,1024,32769,17816,22008,21960,218,8328,65,64645,16585,17664,10401,20485,62589,256,21792,46213,63188]

theorem envBound30087 : H12AffineFastState.Bounded env30087 := by
  intro p hp
  have h : env30087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30086_30087 : H12AffineEnvironment.transform 15 33030 env30086 = env30087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env30086 == env30087) = true)

theorem identity30087 : scanCanonicalize (H12AffineFastState.compose env30087 (packedSelected [0,1,4,5,7,8,10,11,16,17,19,20,22,24,26,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound30087 : packedSelected [0,1,4,5,7,8,10,11,16,17,19,20,22,24,26,31,32] rootPS < 2^1333 := by decide +kernel

def env30088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,21511,5392,32120,1024,21760,17816,22008,21960,218,8328,65,10628,16585,17664,10401,20485,8572,256,21792,24964,9173]

theorem envBound30088 : H12AffineFastState.Bounded env30088 := by
  intro p hp
  have h : env30088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30087_30088 : H12AffineEnvironment.transform 14 21761 env30087 = env30088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env30087 == env30088) = true)

theorem identity30088 : scanCanonicalize (H12AffineFastState.compose env30088 (packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound30088 : packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env30089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8540,8282,5392,2341,1024,8541,12741,8613,8597,218,8328,65,10628,13460,12637,10401,9304,8572,256,8573,5593,9173]

theorem envBound30089 : H12AffineFastState.Bounded env30089 := by
  intro p hp
  have h : env30089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30088_30089 : H12AffineEnvironment.transform 13 13405 env30088 = env30089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env30088 == env30089) = true)

theorem identity30089 : scanCanonicalize (H12AffineFastState.compose env30089 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30089 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30090 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13325,8460,8202,5392,2341,1024,8461,12693,8613,8597,138,8328,17,10628,13460,12557,10401,9224,8492,256,8493,5513,9093]

theorem envBound30090 : H12AffineFastState.Bounded env30090 := by
  intro p hp
  have h : env30090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30089_30090 : H12AffineEnvironment.transform 5 16 env30089 = env30090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30089 == env30090) = true)

theorem identity30090 : scanCanonicalize (H12AffineFastState.compose env30090 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound30090 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env30091 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5512,137,399,5392,2341,1024,136,4112,32,16,138,269,17,2049,5393,4232,2340,1421,169,256,168,5513,512]

theorem envBound30091 : H12AffineFastState.Bounded env30091 := by
  intro p hp
  have h : env30091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30090_30091 : H12AffineEnvironment.transform 12 389 env30090 = env30091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env30090 == env30091) = true)

theorem identity30091 : scanCanonicalize (H12AffineFastState.compose env30091 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound30091 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30092 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,300,5409,32,294,5392,2341,1024,33,4112,32,16,35,269,17,2049,5393,4129,2340,1316,0,256,1,5408,512]

theorem envBound30092 : H12AffineFastState.Bounded env30092 := by
  intro p hp
  have h : env30092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30091_30092 : H12AffineEnvironment.transform 6 41 env30091 = env30092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env30091 == env30092) = true)

theorem identity30092 : scanCanonicalize (H12AffineFastState.compose env30092 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30092 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env30093 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,41,5156,32,35,5141,2080,1024,33,4112,32,16,35,8,17,2049,5140,4129,2081,1057,0,5,1,5157,512]

theorem envBound30093 : H12AffineFastState.Bounded env30093 := by
  intro p hp
  have h : env30093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30092_30093 : H12AffineEnvironment.transform 7 5 env30092 = env30093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30092 == env30093) = true)

theorem identity30093 : scanCanonicalize (H12AffineFastState.compose env30093 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30093 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env30094 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,8,5125,1,2,5141,2049,1024,0,4112,1,16,2,8,17,2049,5140,4096,2048,1024,0,5,1,5124,512]

theorem envBound30094 : H12AffineFastState.Bounded env30094 := by
  intro p hp
  have h : env30094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30093_30094 : H12AffineEnvironment.transform 4 1 env30093 = env30094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30093 == env30094) = true)

def env30095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272513,452769,441779,8328,65,245139,115151,17664,10401,119043,329730,256,485711,493802,63188]

theorem envBound30095 : H12AffineFastState.Bounded env30095 := by
  intro p hp
  have h : env30095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30068_30095 : H12AffineEnvironment.transform 21 272513 env30068 = env30095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env30068 == env30095) = true)

theorem identity30095 : scanCanonicalize (H12AffineFastState.compose env30095 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound30095 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,456945,272513,452769,441779,8328,65,158029,5393,17664,10401,1501,318684,256,441745,416820,63188]

theorem envBound30096 : H12AffineFastState.Bounded env30096 := by
  intro p hp
  have h : env30096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30095_30096 : H12AffineEnvironment.transform 15 54494 env30095 = env30096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env30095 == env30096) = true)

theorem identity30096 : scanCanonicalize (H12AffineFastState.compose env30096 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound30096 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env30097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,131072,262144,1024,29908,396324,272513,400500,412006,8328,65,158029,5393,17664,10401,1501,272393,256,411972,416820,513]

theorem envBound30097 : H12AffineFastState.Bounded env30097 := by
  intro p hp
  have h : env30097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30096_30097 : H12AffineEnvironment.transform 14 29909 env30096 = env30097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env30096 == env30097) = true)

theorem identity30097 : scanCanonicalize (H12AffineFastState.compose env30097 (packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound30097 : packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env30098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,342,131072,262144,1024,21897,396324,264668,400500,412006,469,65,149520,5393,17664,2556,1501,264532,256,411972,416820,513]

theorem envBound30098 : H12AffineFastState.Bounded env30098 := by
  intro p hp
  have h : env30098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30097_30098 : H12AffineEnvironment.transform 12 349 env30097 = env30098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env30097 == env30098) = true)

theorem identity30098 : scanCanonicalize (H12AffineFastState.compose env30098 (packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS)) = affineNative (2^(17+1) ^^^ 2556) := by decide +kernel

theorem selectedBound30098 : packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env30099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,342,131072,2556,1024,21897,132568,32,136584,147610,469,65,149520,5393,17664,2556,1501,168,256,147640,153032,513]

theorem envBound30099 : H12AffineFastState.Bounded env30099 := by
  intro p hp
  have h : env30099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30098_30099 : H12AffineEnvironment.transform 17 2556 env30098 = env30099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2556 env30098 == env30099) = true)

theorem identity30099 : scanCanonicalize (H12AffineFastState.compose env30099 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound30099 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env30100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,342,5529,2556,1024,21897,4161,32,17,21763,469,65,23945,5393,17664,2556,1501,168,256,21793,16465,513]

theorem envBound30100 : H12AffineFastState.Bounded env30100 := by
  intro p hp
  have h : env30100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30099_30100 : H12AffineEnvironment.transform 16 5529 env30099 = env30100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env30099 == env30100) = true)

theorem identity30100 : scanCanonicalize (H12AffineFastState.compose env30100 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound30100 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5457,217,342,5529,2556,1024,216,4161,32,17,82,469,65,2264,5393,4177,2556,1501,168,256,112,5376,513]

theorem envBound30101 : H12AffineFastState.Bounded env30101 := by
  intro p hp
  have h : env30101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30100_30101 : H12AffineEnvironment.transform 13 5457 env30100 = env30101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env30100 == env30101) = true)

theorem identity30101 : scanCanonicalize (H12AffineFastState.compose env30101 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound30101 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env30102 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5457,0,342,5440,2341,1024,1,4161,32,17,82,268,65,2049,5393,4177,2341,1284,113,256,112,5376,513]

theorem envBound30102 : H12AffineFastState.Bounded env30102 := by
  intro p hp
  have h : env30102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30101_30102 : H12AffineEnvironment.transform 6 89 env30101 = env30102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env30101 == env30102) = true)

theorem identity30102 : scanCanonicalize (H12AffineFastState.compose env30102 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1857) := by decide +kernel

theorem selectedBound30102 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30103 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,1857,349,528,0,342,513,2341,1024,1,1792,32,17,82,268,65,2049,592,1808,2341,1284,113,256,112,577,513]

theorem envBound30103 : H12AffineFastState.Bounded env30103 := by
  intro p hp
  have h : env30103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30102_30103 : H12AffineEnvironment.transform 11 1857 env30102 = env30103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1857 env30102 == env30103) = true)

theorem identity30103 : scanCanonicalize (H12AffineFastState.compose env30103 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1808) := by decide +kernel

theorem selectedBound30103 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30104 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1808,1857,349,528,0,342,513,1589,1024,1,1792,32,17,82,268,65,1809,592,1808,1589,1284,113,256,112,577,513]

theorem envBound30104 : H12AffineFastState.Bounded env30104 := by
  intro p hp
  have h : env30104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30103_30104 : H12AffineEnvironment.transform 10 1808 env30103 = env30104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1808 env30103 == env30104) = true)

theorem identity30104 : scanCanonicalize (H12AffineFastState.compose env30104 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound30104 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env30105 : List Nat := [2,4,8,16,32,64,89,256,512,36,820,869,349,528,0,342,513,529,36,1,804,32,17,82,268,65,821,592,820,529,288,113,256,112,577,513]

theorem envBound30105 : H12AffineFastState.Bounded env30105 := by
  intro p hp
  have h : env30105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30104_30105 : H12AffineEnvironment.transform 9 36 env30104 = env30105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env30104 == env30105) = true)

theorem identity30105 : scanCanonicalize (H12AffineFastState.compose env30105 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound30105 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env30106 : List Nat := [2,4,8,16,32,64,89,53,512,36,513,592,104,528,0,99,513,529,36,1,529,32,17,82,57,65,512,592,513,529,21,113,53,112,577,513]

theorem envBound30106 : H12AffineFastState.Bounded env30106 := by
  intro p hp
  have h : env30106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30105_30106 : H12AffineEnvironment.transform 7 53 env30105 = env30106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env30105 == env30106) = true)

theorem identity30106 : scanCanonicalize (H12AffineFastState.compose env30106 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30106 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env30107 : List Nat := [2,4,8,16,32,17,8,53,512,36,513,513,57,528,0,50,513,529,36,1,529,32,17,3,57,16,512,513,513,529,21,32,53,33,528,513]

theorem envBound30107 : H12AffineFastState.Bounded env30107 := by
  intro p hp
  have h : env30107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30106_30107 : H12AffineEnvironment.transform 5 17 env30106 = env30107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30106 == env30107) = true)

theorem identity30107 : scanCanonicalize (H12AffineFastState.compose env30107 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound30107 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30108 : List Nat := [2,4,8,16,32,17,8,53,16,36,17,17,57,0,0,50,17,1,36,1,1,32,17,3,57,16,16,17,17,1,21,32,53,33,0,17]

theorem envBound30108 : H12AffineFastState.Bounded env30108 := by
  intro p hp
  have h : env30108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30107_30108 : H12AffineEnvironment.transform 8 16 env30107 = env30108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env30107 == env30108) = true)

theorem identity30108 : scanCanonicalize (H12AffineFastState.compose env30108 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound30108 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30109 : List Nat := [2,4,8,16,26,17,8,15,16,30,17,17,3,0,0,8,17,1,30,1,1,26,17,3,3,16,16,17,17,1,21,26,15,27,0,17]

theorem envBound30109 : H12AffineFastState.Bounded env30109 := by
  intro p hp
  have h : env30109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30108_30109 : H12AffineEnvironment.transform 4 26 env30108 = env30109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env30108 == env30109) = true)

theorem identity30109 : scanCanonicalize (H12AffineFastState.compose env30109 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30109 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30110 : List Nat := [2,4,8,0,10,1,8,15,0,14,1,1,3,0,0,8,1,1,14,1,1,10,1,3,3,0,0,1,1,1,5,10,15,11,0,1]

theorem envBound30110 : H12AffineFastState.Bounded env30110 := by
  intro p hp
  have h : env30110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30109_30110 : H12AffineEnvironment.transform 3 0 env30109 = env30110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30109 == env30110) = true)

def env30111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound30111 : H12AffineFastState.Bounded env30111 := by
  intro p hp
  have h : env30111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29896_30111 : H12AffineEnvironment.transform 18 1025 env29896 = env30111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env29896 == env30111) = true)

theorem identity30111 : scanCanonicalize (H12AffineFastState.compose env30111 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 347491) := by decide +kernel

theorem selectedBound30111 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env30112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347491,4194304,8388608,16777216,8328,65,29868033,17091055,8722483,8830977,25265169,21244066,257,25463246,25454698,25207751]

theorem envBound30112 : H12AffineFastState.Bounded env30112 := by
  intro p hp
  have h : env30112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30111_30112 : H12AffineEnvironment.transform 20 347491 env30111 = env30112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 347491 env30111 == env30112) = true)

def env30113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347491,4194304,8388608,392436,8328,65,12729589,79131,8722483,8830977,8681701,4314198,257,8484154,8492190,8740659]

theorem envBound30113 : H12AffineFastState.Bounded env30113 := by
  intro p hp
  have h : env30113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30112_30113 : H12AffineEnvironment.transform 23 392436 env30112 = env30113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392436 env30112 == env30113) = true)

def env30114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,8388608,98780,8328,65,12729589,79131,8480027,8568105,8390093,4314198,257,8484154,8492190,8462875]

theorem envBound30114 : H12AffineFastState.Bounded env30114 := by
  intro p hp
  have h : env30114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30113_30114 : H12AffineEnvironment.transform 17 32040 env30113 = env30114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env30113 == env30114) = true)

def env30115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,16,98780,8328,65,4340965,79131,91403,179513,1501,4314198,257,95530,103566,74251]

theorem envBound30115 : H12AffineFastState.Bounded env30115 := by
  intro p hp
  have h : env30115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30114_30115 : H12AffineEnvironment.transform 22 16 env30114 = env30115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env30114 == env30115) = true)

theorem identity30115 : scanCanonicalize (H12AffineFastState.compose env30115 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 21928) := by decide +kernel

theorem selectedBound30115 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,21928,16,98780,8328,65,158029,79131,91403,179513,1501,98814,257,95530,103566,74251]

theorem envBound30116 : H12AffineFastState.Bounded env30116 := by
  intro p hp
  have h : env30116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30115_30116 : H12AffineEnvironment.transform 21 21928 env30115 = env30116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21928 env30115 == env30116) = true)

theorem identity30116 : scanCanonicalize (H12AffineFastState.compose env30116 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30116 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env30117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32040,1025,32769,4161,21928,16,41430,8328,65,158029,5393,17665,179513,1501,41460,257,21792,46212,513]

theorem envBound30117 : H12AffineFastState.Bounded env30117 := by
  intro p hp
  have h : env30117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30116_30117 : H12AffineEnvironment.transform 15 8202 env30116 = env30117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30116 == env30117) = true)

theorem identity30117 : scanCanonicalize (H12AffineFastState.compose env30117 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound30117 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32040,1025,32769,4161,21928,16,41430,8328,65,10589,5393,17665,64809,1501,41460,257,21792,46212,513]

theorem envBound30118 : H12AffineFastState.Bounded env30118 := by
  intro p hp
  have h : env30118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30117_30118 : H12AffineEnvironment.transform 16 16400 env30117 = env30118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env30117 == env30118) = true)

def env30119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,17,98780,8328,65,4340964,79131,91402,179512,1500,4314198,257,95531,103567,74250]

theorem envBound30119 : H12AffineFastState.Bounded env30119 := by
  intro p hp
  have h : env30119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30114_30119 : H12AffineEnvironment.transform 22 17 env30114 = env30119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env30114 == env30119) = true)

def env30120 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,17,98644,8192,65,4340844,79131,91402,179512,1364,4314198,257,95531,103431,74250]

theorem envBound30120 : H12AffineFastState.Bounded env30120 := by
  intro p hp
  have h : env30120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30119_30120 : H12AffineEnvironment.transform 6 8 env30119 = env30120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30119 == env30120) = true)

theorem identity30120 : scanCanonicalize (H12AffineFastState.compose env30120 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound30120 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30121 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,4194304,17,41311,8192,65,4340844,5392,17665,179512,1364,4256861,257,21792,46092,513]

theorem envBound30121 : H12AffineFastState.Bounded env30121 := by
  intro p hp
  have h : env30121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30120_30121 : H12AffineEnvironment.transform 15 8203 env30120 = env30121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env30120 == env30121) = true)

theorem identity30121 : scanCanonicalize (H12AffineFastState.compose env30121 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound30121 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env30122 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32040,1025,29788,4160,4194304,17,21762,8192,65,4340844,5392,17665,149861,1364,4194304,257,21792,16465,513]

theorem envBound30122 : H12AffineFastState.Bounded env30122 := by
  intro p hp
  have h : env30122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30121_30122 : H12AffineEnvironment.transform 14 29789 env30121 = env30122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env30121 == env30122) = true)

theorem identity30122 : scanCanonicalize (H12AffineFastState.compose env30122 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 21872) := by decide +kernel

theorem selectedBound30122 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env30123 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32040,1025,29788,4160,21872,17,21762,8192,65,157980,5392,17665,149861,1364,21872,257,21792,16465,513]

theorem envBound30123 : H12AffineFastState.Bounded env30123 := by
  intro p hp
  have h : env30123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30122_30123 : H12AffineEnvironment.transform 21 21872 env30122 = env30123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21872 env30122 == env30123) = true)

theorem identity30123 : scanCanonicalize (H12AffineFastState.compose env30123 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound30123 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env30124 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,16400,32040,1025,29788,4160,21872,17,21762,8192,65,10508,5392,17665,2421,1364,21872,257,21792,16465,513]

theorem envBound30124 : H12AffineFastState.Bounded env30124 := by
  intro p hp
  have h : env30124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30123_30124 : H12AffineEnvironment.transform 16 16400 env30123 = env30124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env30123 == env30124) = true)

theorem identity30124 : scanCanonicalize (H12AffineFastState.compose env30124 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound30124 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30125 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5392,10280,1025,8540,4160,112,17,2,8192,65,10508,5392,4097,2421,1364,112,257,32,5457,513]

theorem envBound30125 : H12AffineFastState.Bounded env30125 := by
  intro p hp
  have h : env30125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30124_30125 : H12AffineEnvironment.transform 13 5376 env30124 = env30125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30124 == env30125) = true)

theorem identity30125 : scanCanonicalize (H12AffineFastState.compose env30125 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30125 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30126 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,8203,5392,10280,1025,8461,4113,33,17,2,8192,16,10508,5392,4097,2340,1285,33,257,32,5376,513]

theorem envBound30126 : H12AffineFastState.Bounded env30126 := by
  intro p hp
  have h : env30126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30125_30126 : H12AffineEnvironment.transform 5 17 env30125 = env30126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30125 == env30126) = true)

theorem identity30126 : scanCanonicalize (H12AffineFastState.compose env30126 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound30126 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30127 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1076,8192,308,8460,8203,292,10280,1025,8461,1061,33,17,2,8192,16,10508,292,1077,2340,1285,33,257,32,308,513]

theorem envBound30127 : H12AffineFastState.Bounded env30127 := by
  intro p hp
  have h : env30127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30126_30127 : H12AffineEnvironment.transform 11 1076 env30126 = env30127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env30126 == env30127) = true)

theorem identity30127 : scanCanonicalize (H12AffineFastState.compose env30127 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2082) := by decide +kernel

theorem selectedBound30127 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env30128 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1076,2082,308,2350,2089,292,10,1025,2351,1061,33,17,2,2082,16,302,292,1077,2340,1285,33,257,32,308,513]

theorem envBound30128 : H12AffineFastState.Bounded env30128 := by
  intro p hp
  have h : env30128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30127_30128 : H12AffineEnvironment.transform 12 2082 env30127 = env30128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2082 env30127 == env30128) = true)

theorem identity30128 : scanCanonicalize (H12AffineFastState.compose env30128 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound30128 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30129 : List Nat := [2,4,8,16,32,17,8,256,512,1024,303,1076,269,308,1,262,292,10,1025,0,1061,33,17,2,269,16,302,292,1077,11,1285,33,257,32,308,513]

theorem envBound30129 : H12AffineFastState.Bounded env30129 := by
  intro p hp
  have h : env30129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30128_30129 : H12AffineEnvironment.transform 10 303 env30128 = env30129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env30128 == env30129) = true)

theorem identity30129 : scanCanonicalize (H12AffineFastState.compose env30129 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30129 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30130 : List Nat := [2,4,8,16,32,17,8,256,512,273,303,293,269,308,1,262,292,10,272,0,308,33,17,2,269,16,302,292,292,11,20,33,257,32,308,513]

theorem envBound30130 : H12AffineFastState.Bounded env30130 := by
  intro p hp
  have h : env30130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30129_30130 : H12AffineEnvironment.transform 9 273 env30129 = env30130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30129 == env30130) = true)

theorem identity30130 : scanCanonicalize (H12AffineFastState.compose env30130 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound30130 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30131 : List Nat := [2,4,8,16,27,17,8,256,512,273,276,286,269,271,1,262,287,10,272,0,271,26,17,2,269,16,277,287,287,11,20,26,257,27,271,513]

theorem envBound30131 : H12AffineFastState.Bounded env30131 := by
  intro p hp
  have h : env30131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30130_30131 : H12AffineEnvironment.transform 4 27 env30130 = env30131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env30130 == env30131) = true)

def env30132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,17,98645,8193,65,4340845,79131,91402,179512,1365,4314198,257,95531,103430,74250]

theorem envBound30132 : H12AffineFastState.Bounded env30132 := by
  intro p hp
  have h : env30132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30119_30132 : H12AffineEnvironment.transform 6 9 env30119 = env30132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30119 == env30132) = true)

theorem identity30132 : scanCanonicalize (H12AffineFastState.compose env30132 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound30132 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30133 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,32040,1025,32769,45341,4194304,17,3,8193,65,4340845,46157,58460,179512,1365,4216064,257,62589,5456,41820]

theorem envBound30133 : H12AffineFastState.Bounded env30133 := by
  intro p hp
  have h : env30133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30132_30133 : H12AffineEnvironment.transform 15 33110 env30132 = env30133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env30132 == env30133) = true)

theorem identity30133 : scanCanonicalize (H12AffineFastState.compose env30133 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound30133 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env30134 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,131072,32040,1025,8540,4160,4194304,17,3,8193,65,4340845,5392,17665,138341,1365,4216064,257,21792,5456,513]

theorem envBound30134 : H12AffineFastState.Bounded env30134 := by
  intro p hp
  have h : env30134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30133_30134 : H12AffineEnvironment.transform 14 8541 env30133 = env30134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env30133 == env30134) = true)

theorem identity30134 : scanCanonicalize (H12AffineFastState.compose env30134 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound30134 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30135 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,32040,1025,8540,4160,4194304,17,3,8193,65,4226172,5392,17665,23668,1365,4216064,257,21792,5456,513]

theorem envBound30135 : H12AffineFastState.Bounded env30135 := by
  intro p hp
  have h : env30135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30134_30135 : H12AffineEnvironment.transform 16 16401 env30134 = env30135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env30134 == env30135) = true)

theorem identity30135 : scanCanonicalize (H12AffineFastState.compose env30135 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound30135 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env30136 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,8541,8203,16401,30776,273,8540,4160,4194304,17,3,8193,65,4225388,4096,16401,22884,69,4214800,257,20528,4160,513]

theorem envBound30136 : H12AffineFastState.Bounded env30136 := by
  intro p hp
  have h : env30136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30135_30136 : H12AffineEnvironment.transform 9 272 env30135 = env30136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30135 == env30136) = true)

theorem identity30136 : scanCanonicalize (H12AffineFastState.compose env30136 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound30136 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env30137 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4404,8541,8203,4389,10508,273,8540,4160,4194304,17,3,8193,65,4204632,4096,4389,2128,69,4194596,257,260,4160,513]

theorem envBound30137 : H12AffineFastState.Bounded env30137 := by
  intro p hp
  have h : env30137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30136_30137 : H12AffineEnvironment.transform 13 4404 env30136 = env30137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env30136 == env30137) = true)

theorem identity30137 : scanCanonicalize (H12AffineFastState.compose env30137 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound30137 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env30138 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4404,8541,8203,4389,10508,273,8540,4160,113,17,3,8193,65,10281,4096,4389,2128,69,341,257,260,4160,513]

theorem envBound30138 : H12AffineFastState.Bounded env30138 := by
  intro p hp
  have h : env30138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30137_30138 : H12AffineEnvironment.transform 21 113 env30137 = env30138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env30137 == env30138) = true)

theorem identity30138 : scanCanonicalize (H12AffineFastState.compose env30138 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30138 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env30139 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4404,1,343,4389,2128,273,0,4160,113,17,3,349,65,2421,4096,4389,2128,69,341,257,260,4160,513]

theorem envBound30139 : H12AffineFastState.Bounded env30139 := by
  intro p hp
  have h : env30139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30138_30139 : H12AffineEnvironment.transform 12 348 env30138 = env30139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30138 == env30139) = true)

theorem identity30139 : scanCanonicalize (H12AffineFastState.compose env30139 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30139 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30140 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,4096,120,4112,1,115,4097,2128,53,0,4160,113,17,3,121,65,2129,4096,4097,2128,69,113,37,32,4160,513]

theorem envBound30140 : H12AffineFastState.Bounded env30140 := by
  intro p hp
  have h : env30140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30139_30140 : H12AffineEnvironment.transform 7 36 env30139 = env30140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30139 == env30140) = true)

theorem identity30140 : scanCanonicalize (H12AffineFastState.compose env30140 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 571) := by decide +kernel

theorem selectedBound30140 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env30141 : List Nat := [2,4,8,16,32,64,9,36,512,52,571,4096,120,4112,1,115,4097,619,53,0,4160,113,17,3,121,65,618,4096,4097,619,69,113,37,32,4160,513]

theorem envBound30141 : H12AffineFastState.Bounded env30141 := by
  intro p hp
  have h : env30141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30140_30141 : H12AffineEnvironment.transform 10 571 env30140 = env30141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 571 env30140 == env30141) = true)

theorem identity30141 : scanCanonicalize (H12AffineFastState.compose env30141 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30141 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30142 : List Nat := [2,4,8,16,32,16,9,36,512,52,571,4096,40,4112,1,35,4097,571,53,0,4112,33,17,3,41,17,570,4096,4097,571,21,33,37,32,4112,513]

theorem envBound30142 : H12AffineFastState.Bounded env30142 := by
  intro p hp
  have h : env30142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30141_30142 : H12AffineEnvironment.transform 5 16 env30141 = env30142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30141 == env30142) = true)

theorem identity30142 : scanCanonicalize (H12AffineFastState.compose env30142 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound30142 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30143 : List Nat := [2,4,8,16,32,16,9,36,59,52,0,4096,40,4112,1,35,4097,0,53,0,4112,33,17,3,41,17,1,4096,4097,0,21,33,37,32,4112,58]

theorem envBound30143 : H12AffineFastState.Bounded env30143 := by
  intro p hp
  have h : env30143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30142_30143 : H12AffineEnvironment.transform 8 59 env30142 = env30143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env30142 == env30143) = true)

theorem identity30143 : scanCanonicalize (H12AffineFastState.compose env30143 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30143 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30144 : List Nat := [2,4,8,0,32,0,9,36,43,36,0,4096,40,4096,1,35,4097,0,37,0,4096,33,1,3,41,1,1,4096,4097,0,5,33,37,32,4096,42]

theorem envBound30144 : H12AffineFastState.Bounded env30144 := by
  intro p hp
  have h : env30144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30143_30144 : H12AffineEnvironment.transform 3 0 env30143 = env30144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30143 == env30144) = true)

theorem identity30144 : scanCanonicalize (H12AffineFastState.compose env30144 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30144 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30145 : List Nat := [2,4,8,0,1,0,9,5,10,5,0,4096,9,4096,1,2,4097,0,4,0,4096,0,1,3,8,1,1,4096,4097,0,5,0,4,1,4096,11]

theorem envBound30145 : H12AffineFastState.Bounded env30145 := by
  intro p hp
  have h : env30145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30144_30145 : H12AffineEnvironment.transform 4 1 env30144 = env30145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30144 == env30145) = true)

theorem identity30145 : scanCanonicalize (H12AffineFastState.compose env30145 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound30145 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30146 : List Nat := [2,4,8,0,1,0,9,5,10,5,0,0,9,0,1,2,1,0,4,0,0,0,1,3,8,1,1,0,1,0,5,0,4,1,0,11]

theorem envBound30146 : H12AffineFastState.Bounded env30146 := by
  intro p hp
  have h : env30146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30145_30146 : H12AffineEnvironment.transform 11 0 env30145 = env30146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env30145 == env30146) = true)

theorem identity30146 : scanCanonicalize (H12AffineFastState.compose env30146 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30146 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30147 : List Nat := [2,4,3,0,1,0,2,5,1,5,0,0,2,0,1,2,1,0,4,0,0,0,1,3,3,1,1,0,1,0,5,0,4,1,0,0]

theorem envBound30147 : H12AffineFastState.Bounded env30147 := by
  intro p hp
  have h : env30147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30146_30147 : H12AffineEnvironment.transform 2 3 env30146 = env30147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30146 == env30147) = true)

def env30148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,8388608,98781,8328,65,12729589,79131,8480026,8568104,8390092,4314198,257,8484154,8492190,8462874]

theorem envBound30148 : H12AffineFastState.Bounded env30148 := by
  intro p hp
  have h : env30148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30113_30148 : H12AffineEnvironment.transform 17 32041 env30113 = env30148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env30113 == env30148) = true)

def env30149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,16,98781,8328,65,4340965,79131,91402,179512,1500,4314198,257,95530,103566,74250]

theorem envBound30149 : H12AffineFastState.Bounded env30149 := by
  intro p hp
  have h : env30149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30148_30149 : H12AffineEnvironment.transform 22 16 env30148 = env30149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env30148 == env30149) = true)

theorem identity30149 : scanCanonicalize (H12AffineFastState.compose env30149 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound30149 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,41341,16,98781,8328,65,171416,79131,91402,179512,1500,95531,257,95530,103566,74250]

theorem envBound30150 : H12AffineFastState.Bounded env30150 := by
  intro p hp
  have h : env30150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30149_30150 : H12AffineEnvironment.transform 21 41341 env30149 = env30150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env30149 == env30150) = true)

theorem identity30150 : scanCanonicalize (H12AffineFastState.compose env30150 (packedSelected [0,5,8,9,11,14,15,22,24,26,27,28,31,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound30150 : packedSelected [0,5,8,9,11,14,15,22,24,26,27,28,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env30151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21646,131072,32041,1025,32769,25796,41341,16,54611,8328,65,171416,24981,12676,179512,1500,8613,257,8612,49152,30340]

theorem envBound30151 : H12AffineFastState.Bounded env30151 := by
  intro p hp
  have h : env30151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30150_30151 : H12AffineEnvironment.transform 15 21646 env30150 = env30151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env30150 == env30151) = true)

theorem identity30151 : scanCanonicalize (H12AffineFastState.compose env30151 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound30151 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env30152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,32768,21646,131072,23589,1025,32769,17864,32881,16,54611,388,65,171416,16537,4232,171060,1500,169,257,168,49152,22408]

theorem envBound30152 : H12AffineFastState.Bounded env30152 := by
  intro p hp
  have h : env30152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30151_30152 : H12AffineEnvironment.transform 12 268 env30151 = env30152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env30151 == env30152) = true)

theorem identity30152 : scanCanonicalize (H12AffineFastState.compose env30152 (packedSelected [0,3,4,7,10,11,12,15,17,18,19,22,24] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound30152 : packedSelected [0,3,4,7,10,11,12,15,17,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env30153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,32768,21646,5528,23589,1025,32769,17864,32881,16,54611,388,65,34816,16537,4232,35244,1500,169,257,168,49152,22408]

theorem envBound30153 : H12AffineFastState.Bounded env30153 := by
  intro p hp
  have h : env30153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30152_30153 : H12AffineEnvironment.transform 16 5528 env30152 = env30153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env30152 == env30153) = true)

theorem identity30153 : scanCanonicalize (H12AffineFastState.compose env30153 (packedSelected [0,1,3,4,5,7,8,10,11,12,15,16,18,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound30153 : packedSelected [0,1,3,4,5,7,8,10,11,12,15,16,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env30154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,32768,263,5528,2476,1025,32769,4161,32881,16,32986,388,65,34816,5392,4232,35244,1500,169,257,168,38281,513]

theorem envBound30154 : H12AffineFastState.Bounded env30154 := by
  intro p hp
  have h : env30154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30153_30154 : H12AffineEnvironment.transform 13 5513 env30153 = env30154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env30153 == env30154) = true)

theorem identity30154 : scanCanonicalize (H12AffineFastState.compose env30154 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound30154 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env30155 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5456,32768,263,5441,2421,1025,32769,4161,32881,16,32771,349,65,34816,5392,4177,35189,1285,112,257,113,38224,513]

theorem envBound30155 : H12AffineFastState.Bounded env30155 := by
  intro p hp
  have h : env30155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30154_30155 : H12AffineEnvironment.transform 6 89 env30154 = env30155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env30154 == env30155) = true)

theorem identity30155 : scanCanonicalize (H12AffineFastState.compose env30155 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound30155 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env30156 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,1076,268,356,32768,263,373,2421,1025,32769,1141,32881,16,32771,349,65,34816,292,1125,35189,1285,112,257,113,33124,513]

theorem envBound30156 : H12AffineFastState.Bounded env30156 := by
  intro p hp
  have h : env30156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30155_30156 : H12AffineEnvironment.transform 11 1076 env30155 = env30156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env30155 == env30156) = true)

theorem identity30156 : scanCanonicalize (H12AffineFastState.compose env30156 (packedSelected [0,1,3,4,7,9,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 885) := by decide +kernel

theorem selectedBound30156 : packedSelected [0,1,3,4,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env30157 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,1076,268,356,885,263,373,2421,1025,884,1141,772,16,886,349,65,2933,292,1125,2560,1285,112,257,113,529,513]

theorem envBound30157 : H12AffineFastState.Bounded env30157 := by
  intro p hp
  have h : env30157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30156_30157 : H12AffineEnvironment.transform 14 885 env30156 = env30157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 885 env30156 == env30157) = true)

def env30158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,17,98781,8328,65,4340964,79131,91403,179513,1501,4314198,257,95531,103567,74251]

theorem envBound30158 : H12AffineFastState.Bounded env30158 := by
  intro p hp
  have h : env30158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30148_30158 : H12AffineEnvironment.transform 22 17 env30148 = env30158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env30148 == env30158) = true)

theorem identity30158 : scanCanonicalize (H12AffineFastState.compose env30158 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound30158 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32041,1025,29909,77898,4194304,17,95497,8328,65,4340964,79131,91403,149997,1501,4268162,257,95531,90203,74251]

theorem envBound30159 : H12AffineFastState.Bounded env30159 := by
  intro p hp
  have h : env30159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30158_30159 : H12AffineEnvironment.transform 14 29908 env30158 = env30159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env30158 == env30159) = true)

def env30160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10281,1025,8661,77898,4194304,17,73737,8328,65,4340964,79131,77835,138477,1501,4268162,257,73771,79195,74251]

theorem envBound30160 : H12AffineFastState.Bounded env30160 := by
  intro p hp
  have h : env30160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30159_30160 : H12AffineEnvironment.transform 13 5376 env30159 = env30160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30159 == env30160) = true)

theorem identity30160 : scanCanonicalize (H12AffineFastState.compose env30160 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30160 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8202,131072,10281,1025,8661,4160,4194304,17,3,8328,65,4340964,5393,4097,138477,1501,4194440,257,33,5457,513]

theorem envBound30161 : H12AffineFastState.Bounded env30161 := by
  intro p hp
  have h : env30161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30160_30161 : H12AffineEnvironment.transform 15 8202 env30160 = env30161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30160 == env30161) = true)

theorem identity30161 : scanCanonicalize (H12AffineFastState.compose env30161 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(21+1) ^^^ 8321) := by decide +kernel

theorem selectedBound30161 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env30162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8202,131072,10281,1025,8661,4160,8321,17,3,8328,65,138341,5393,4097,138477,1501,8201,257,33,5457,513]

theorem envBound30162 : H12AffineFastState.Bounded env30162 := by
  intro p hp
  have h : env30162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30161_30162 : H12AffineEnvironment.transform 21 8321 env30161 = env30162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8321 env30161 == env30162) = true)

theorem identity30162 : scanCanonicalize (H12AffineFastState.compose env30162 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound30162 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8202,5392,10281,1025,8661,4160,8321,17,3,8328,65,2421,5393,4097,2557,1501,8201,257,33,5457,513]

theorem envBound30163 : H12AffineFastState.Bounded env30163 := by
  intro p hp
  have h : env30163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30162_30163 : H12AffineEnvironment.transform 16 5392 env30162 = env30163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env30162 == env30163) = true)

theorem identity30163 : scanCanonicalize (H12AffineFastState.compose env30163 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound30163 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30164 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4112,8660,8202,4096,10281,273,8661,4160,8321,17,3,8328,65,2421,4097,4097,2557,205,8201,257,33,4161,513]

theorem envBound30164 : H12AffineFastState.Bounded env30164 := by
  intro p hp
  have h : env30164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30163_30164 : H12AffineEnvironment.transform 9 272 env30163 = env30164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30163 == env30164) = true)

theorem identity30164 : scanCanonicalize (H12AffineFastState.compose env30164 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 237) := by decide +kernel

theorem selectedBound30164 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env30165 : List Nat := [2,4,8,16,32,64,128,237,512,253,2048,4096,8192,4112,8249,8202,4096,10281,252,8248,4160,8321,17,3,8328,65,2200,4097,4097,2064,205,8201,236,33,4161,513]

theorem envBound30165 : H12AffineFastState.Bounded env30165 := by
  intro p hp
  have h : env30165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30164_30165 : H12AffineEnvironment.transform 7 237 env30164 = env30165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 237 env30164 == env30165) = true)

theorem identity30165 : scanCanonicalize (H12AffineFastState.compose env30165 (packedSelected [0,27] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound30165 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env30166 : List Nat := [2,4,8,16,32,64,128,237,512,253,2048,4096,160,4112,153,170,4096,2185,252,152,4160,33,17,3,40,65,2200,4097,4097,2064,205,169,236,33,4161,513]

theorem envBound30166 : H12AffineFastState.Bounded env30166 := by
  intro p hp
  have h : env30166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30165_30166 : H12AffineEnvironment.transform 12 160 env30165 = env30166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env30165 == env30166) = true)

theorem identity30166 : scanCanonicalize (H12AffineFastState.compose env30166 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound30166 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env30167 : List Nat := [2,4,8,16,32,64,128,237,512,253,2048,2200,160,2184,153,170,2200,2185,252,152,2264,33,17,3,40,65,2200,2201,2201,2064,205,169,236,33,2265,513]

theorem envBound30167 : H12AffineFastState.Bounded env30167 := by
  intro p hp
  have h : env30167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30166_30167 : H12AffineEnvironment.transform 11 2200 env30166 = env30167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env30166 == env30167) = true)

theorem identity30167 : scanCanonicalize (H12AffineFastState.compose env30167 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30167 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env30168 : List Nat := [2,4,8,16,32,64,9,100,512,116,2048,2065,41,2049,16,35,2065,2048,117,17,2129,33,17,3,40,65,2065,2064,2064,2064,68,32,101,33,2128,513]

theorem envBound30168 : H12AffineFastState.Bounded env30168 := by
  intro p hp
  have h : env30168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30167_30168 : H12AffineEnvironment.transform 6 9 env30167 = env30168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30167 == env30168) = true)

theorem identity30168 : scanCanonicalize (H12AffineFastState.compose env30168 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30168 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30169 : List Nat := [2,4,8,16,1,64,9,69,512,85,2048,2065,8,2049,16,2,2065,2048,84,17,2129,0,17,3,9,65,2065,2064,2064,2064,68,1,68,0,2128,513]

theorem envBound30169 : H12AffineFastState.Bounded env30169 := by
  intro p hp
  have h : env30169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30168_30169 : H12AffineEnvironment.transform 4 1 env30168 = env30169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30168 == env30169) = true)

theorem identity30169 : scanCanonicalize (H12AffineFastState.compose env30169 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30169 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env30170 : List Nat := [2,4,8,16,1,16,9,21,512,5,2048,2065,8,2049,16,2,2065,2048,4,17,2049,0,17,3,9,17,2065,2064,2064,2064,20,1,20,0,2048,513]

theorem envBound30170 : H12AffineFastState.Bounded env30170 := by
  intro p hp
  have h : env30170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30169_30170 : H12AffineEnvironment.transform 5 16 env30169 = env30170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30169 == env30170) = true)

theorem identity30170 : scanCanonicalize (H12AffineFastState.compose env30170 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound30170 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30171 : List Nat := [2,4,8,16,1,16,9,21,512,5,513,528,8,512,16,2,528,513,4,17,512,0,17,3,9,17,528,529,529,529,20,1,20,0,513,513]

theorem envBound30171 : H12AffineFastState.Bounded env30171 := by
  intro p hp
  have h : env30171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30170_30171 : H12AffineEnvironment.transform 10 513 env30170 = env30171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env30170 == env30171) = true)

theorem identity30171 : scanCanonicalize (H12AffineFastState.compose env30171 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30171 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30172 : List Nat := [2,4,8,16,1,16,9,21,1,5,0,17,8,1,16,2,17,0,4,17,1,0,17,3,9,17,17,16,16,16,20,1,20,0,0,0]

theorem envBound30172 : H12AffineFastState.Bounded env30172 := by
  intro p hp
  have h : env30172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30171_30172 : H12AffineEnvironment.transform 8 1 env30171 = env30172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30171 == env30172) = true)

theorem identity30172 : scanCanonicalize (H12AffineFastState.compose env30172 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30172 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30173 : List Nat := [2,4,8,0,1,0,9,5,1,5,0,1,8,1,0,2,1,0,4,1,1,0,1,3,9,1,1,0,0,0,4,1,4,0,0,0]

theorem envBound30173 : H12AffineFastState.Bounded env30173 := by
  intro p hp
  have h : env30173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30172_30173 : H12AffineEnvironment.transform 3 0 env30172 = env30173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30172 == env30173) = true)

def env30174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10280,1025,8660,77898,4194304,17,73736,8328,65,4340964,79131,77834,138476,1501,4268162,257,73770,79194,74251]

theorem envBound30174 : H12AffineFastState.Bounded env30174 := by
  intro p hp
  have h : env30174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30159_30174 : H12AffineEnvironment.transform 13 5377 env30159 = env30174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30159 == env30174) = true)

theorem identity30174 : scanCanonicalize (H12AffineFastState.compose env30174 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound30174 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8322,131072,10280,1025,8660,4296,4194304,17,138,8328,65,4340964,5529,4232,138476,1501,4194304,257,168,5592,649]

theorem envBound30175 : H12AffineFastState.Bounded env30175 := by
  intro p hp
  have h : env30175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30174_30175 : H12AffineEnvironment.transform 15 8322 env30174 = env30175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env30174 == env30175) = true)

theorem identity30175 : scanCanonicalize (H12AffineFastState.compose env30175 (packedSelected [0,4,7,11,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound30175 : packedSelected [0,4,7,11,18,22] rootPS < 2^1333 := by decide +kernel

def env30176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,136,479,131072,2421,1025,137,4296,4194304,17,138,469,65,4332985,5529,4232,138476,1501,4194304,257,168,5592,649]

theorem envBound30176 : H12AffineFastState.Bounded env30176 := by
  intro p hp
  have h : env30176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30175_30176 : H12AffineEnvironment.transform 12 349 env30175 = env30176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env30175 == env30176) = true)

theorem identity30176 : scanCanonicalize (H12AffineFastState.compose env30176 (packedSelected [0,1,2,6,7,8,10,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30176 : packedSelected [0,1,2,6,7,8,10,15,16] rootPS < 2^1333 := by decide +kernel

def env30177 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,131072,2421,1025,0,4161,4194304,17,3,348,65,4332848,5392,4097,138341,1364,4194304,257,33,5457,512]

end H12CloudChart1