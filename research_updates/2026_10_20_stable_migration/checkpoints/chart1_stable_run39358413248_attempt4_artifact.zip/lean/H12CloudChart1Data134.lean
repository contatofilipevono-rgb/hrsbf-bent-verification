import H12CloudChart1Data133

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound34003 : H12AffineFastState.Bounded env34003 := by
  intro p hp
  have h : env34003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33998_34003 : H12AffineEnvironment.transform 5 17 env33998 = env34003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33998 == env34003) = true)

def env34004 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,40,1044,0,34,1029,2049,1025,1,33,33,16,3,41,17,2048,1028,49,2049,1057,33,36,32,1044,513]

theorem envBound34004 : H12AffineFastState.Bounded env34004 := by
  intro p hp
  have h : env34004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34003_34004 : H12AffineEnvironment.transform 11 48 env34003 = env34004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env34003 == env34004) = true)

theorem identity34004 : scanCanonicalize (H12AffineFastState.compose env34004 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound34004 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34005 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,48,40,33,0,34,48,2049,52,1,33,33,16,3,41,17,2048,49,49,2049,20,33,36,32,33,513]

theorem envBound34005 : H12AffineFastState.Bounded env34005 := by
  intro p hp
  have h : env34005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34004_34005 : H12AffineEnvironment.transform 9 53 env34004 = env34005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34004 == env34005) = true)

theorem identity34005 : scanCanonicalize (H12AffineFastState.compose env34005 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound34005 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34006 : List Nat := [2,4,8,16,32,17,9,37,43,53,2048,48,40,33,0,34,48,2049,52,1,33,33,16,3,41,17,2048,49,49,2049,20,33,36,32,33,42]

theorem envBound34006 : H12AffineFastState.Bounded env34006 := by
  intro p hp
  have h : env34006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34005_34006 : H12AffineEnvironment.transform 8 43 env34005 = env34006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env34005 == env34006) = true)

def leafEnv34006 : List Nat := [2,4,8,16,32,17,9,37,43,53,2048,48,40,33,0,34,48,2049,52,1,33,33,16,3,21,41,1,17,2048,49,49,2049,20,33,36,32,5,35,33,42,1,33,0]

def active34006 : List Nat := [0,1,2,3,4,10]

def tree34006 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34006 : H12WitnessSearch.Good tree34006 := H12GlobalWitnessIndex.good

theorem leafIdentity34006 : H12AffineFastState.composeSystem env34006 rootObs = leafEnv34006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34006 rootObs == leafEnv34006) = true)

theorem terminalChecked34006 : H12PackedTerminal.terminalCheckFast leafEnv34006 active34006 tree34006 = true := by decide +kernel

def env34007 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,40,1045,0,34,1028,2049,1025,1,32,33,16,3,41,17,2048,1029,48,2049,1057,33,36,32,1045,513]

theorem envBound34007 : H12AffineFastState.Bounded env34007 := by
  intro p hp
  have h : env34007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34003_34007 : H12AffineEnvironment.transform 11 49 env34003 = env34007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env34003 == env34007) = true)

def env34008 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,49,40,33,0,34,48,2049,53,1,32,33,16,3,41,17,2048,49,48,2049,21,33,36,32,33,513]

theorem envBound34008 : H12AffineFastState.Bounded env34008 := by
  intro p hp
  have h : env34008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34007_34008 : H12AffineEnvironment.transform 9 52 env34007 = env34008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34007 == env34008) = true)

def env34009 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,49,40,32,0,34,49,2049,52,1,32,33,16,3,41,17,2048,48,48,2049,20,33,36,32,32,513]

theorem envBound34009 : H12AffineFastState.Bounded env34009 := by
  intro p hp
  have h : env34009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34007_34009 : H12AffineEnvironment.transform 9 53 env34007 = env34009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34007 == env34009) = true)

theorem identity34009 : scanCanonicalize (H12AffineFastState.compose env34009 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound34009 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34010 : List Nat := [2,4,8,16,32,17,9,37,42,53,2048,49,40,32,0,34,49,2049,52,1,32,33,16,3,41,17,2048,48,48,2049,20,33,36,32,32,43]

theorem envBound34010 : H12AffineFastState.Bounded env34010 := by
  intro p hp
  have h : env34010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34009_34010 : H12AffineEnvironment.transform 8 42 env34009 = env34010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env34009 == env34010) = true)

def leafEnv34010 : List Nat := [2,4,8,16,32,17,9,37,42,53,2048,49,40,32,0,34,49,2049,52,1,32,33,16,3,21,41,1,17,2048,48,48,2049,20,33,36,32,5,35,32,43,1,32,0]

def active34010 : List Nat := [0,1,2,3,4,10]

def tree34010 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34010 : H12WitnessSearch.Good tree34010 := H12GlobalWitnessIndex.good

theorem leafIdentity34010 : H12AffineFastState.composeSystem env34010 rootObs = leafEnv34010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34010 rootObs == leafEnv34010) = true)

theorem terminalChecked34010 : H12PackedTerminal.terminalCheckFast leafEnv34010 active34010 tree34010 = true := by decide +kernel

def env34011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32241,1025,29909,4160,155964,144476,213316,8328,64,23809,139613,160076,32120,1500,22009,257,21793,16465,74251]

theorem envBound34011 : H12AffineFastState.Bounded env34011 := by
  intro p hp
  have h : env34011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33991_34011 : H12AffineEnvironment.transform 17 32241 env33991 = env34011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32241 env33991 == env34011) = true)

theorem identity34011 : scanCanonicalize (H12AffineFastState.compose env34011 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79298) := by decide +kernel

theorem selectedBound34011 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env34012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,79298,32241,1025,29909,4160,87294,65950,29830,8328,64,23809,70815,83086,32120,1500,22009,257,21793,16465,74251]

theorem envBound34012 : H12AffineFastState.Bounded env34012 := by
  intro p hp
  have h : env34012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34011_34012 : H12AffineEnvironment.transform 16 79298 env34011 = env34012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79298 env34011 == env34012) = true)

theorem identity34012 : scanCanonicalize (H12AffineFastState.compose env34012 (packedSelected [1,5,8,11,16,17,20,24,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34012 : packedSelected [1,5,8,11,16,17,20,24,32] rootPS < 2^1333 := by decide +kernel

def env34013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,5577,32241,1025,29909,4160,29941,8597,29830,8328,64,23809,13460,25733,32120,1500,22009,257,21793,16465,512]

theorem envBound34013 : H12AffineFastState.Bounded env34013 := by
  intro p hp
  have h : env34013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34012_34013 : H12AffineEnvironment.transform 15 8203 env34012 = env34013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34012 == env34013) = true)

theorem identity34013 : scanCanonicalize (H12AffineFastState.compose env34013 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound34013 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env34014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13688,428,8203,5577,2185,1025,429,4160,397,8597,510,8328,64,10361,13460,4605,2048,1500,8321,257,8281,13609,512]

theorem envBound34014 : H12AffineFastState.Bounded env34014 := by
  intro p hp
  have h : env34014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34013_34014 : H12AffineEnvironment.transform 13 13688 env34013 = env34014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env34013 == env34014) = true)

theorem identity34014 : scanCanonicalize (H12AffineFastState.compose env34014 (packedSelected [2,4,6,11,17,18,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34014 : packedSelected [2,4,6,11,17,18,20,22] rootPS < 2^1333 := by decide +kernel

def env34015 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,292,8203,5441,2049,1025,293,4160,261,8477,374,8192,64,10361,13340,4469,2048,1364,8201,257,8281,13609,512]

theorem envBound34015 : H12AffineFastState.Bounded env34015 := by
  intro p hp
  have h : env34015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34014_34015 : H12AffineEnvironment.transform 6 8 env34014 = env34015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34014 == env34015) = true)

theorem identity34015 : scanCanonicalize (H12AffineFastState.compose env34015 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34015 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34016 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5236,292,263,5441,2049,1025,293,4160,261,17,374,268,64,2421,5392,4469,2048,1364,261,257,341,5157,512]

theorem envBound34016 : H12AffineFastState.Bounded env34016 := by
  intro p hp
  have h : env34016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34015_34016 : H12AffineEnvironment.transform 12 268 env34015 = env34016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34015 == env34016) = true)

theorem identity34016 : scanCanonicalize (H12AffineFastState.compose env34016 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound34016 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env34017 : List Nat := [2,4,8,16,32,64,8,256,512,68,2048,4096,268,4144,292,263,4357,2049,69,293,4160,261,17,374,268,64,2421,4436,4469,2048,272,261,257,341,4193,512]

theorem envBound34017 : H12AffineFastState.Bounded env34017 := by
  intro p hp
  have h : env34017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34016_34017 : H12AffineEnvironment.transform 9 68 env34016 = env34017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env34016 == env34017) = true)

theorem identity34017 : scanCanonicalize (H12AffineFastState.compose env34017 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34017 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env34018 : List Nat := [2,4,8,16,32,64,8,37,512,68,2048,4096,41,4144,1,34,4128,2049,69,0,4160,32,17,83,41,64,2128,4209,4176,2048,53,32,36,112,4193,512]

theorem envBound34018 : H12AffineFastState.Bounded env34018 := by
  intro p hp
  have h : env34018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34017_34018 : H12AffineEnvironment.transform 7 37 env34017 = env34018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34017 == env34018) = true)

theorem identity34018 : scanCanonicalize (H12AffineFastState.compose env34018 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34018 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34019 : List Nat := [2,4,8,0,32,64,8,37,512,68,2048,4096,41,4128,1,34,4128,2049,69,0,4160,32,1,67,41,64,2112,4193,4160,2048,37,32,36,96,4193,512]

theorem envBound34019 : H12AffineFastState.Bounded env34019 := by
  intro p hp
  have h : env34019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34018_34019 : H12AffineEnvironment.transform 3 0 env34018 = env34019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34018 == env34019) = true)

theorem identity34019 : scanCanonicalize (H12AffineFastState.compose env34019 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2154) := by decide +kernel

theorem selectedBound34019 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env34020 : List Nat := [2,4,8,0,32,64,8,37,512,68,2048,2154,41,2122,1,34,2122,2049,69,0,2090,32,1,67,41,64,2112,2059,2090,2048,37,32,36,96,2059,512]

theorem envBound34020 : H12AffineFastState.Bounded env34020 := by
  intro p hp
  have h : env34020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34019_34020 : H12AffineEnvironment.transform 11 2154 env34019 = env34020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2154 env34019 == env34020) = true)

theorem identity34020 : scanCanonicalize (H12AffineFastState.compose env34020 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34020 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34021 : List Nat := [2,4,8,0,1,64,8,4,512,68,2048,2123,8,2122,1,3,2122,2049,69,0,2059,1,1,67,8,64,2112,2059,2059,2048,4,1,5,65,2059,512]

theorem envBound34021 : H12AffineFastState.Bounded env34021 := by
  intro p hp
  have h : env34021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34020_34021 : H12AffineEnvironment.transform 4 1 env34020 = env34021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34020 == env34021) = true)

theorem identity34021 : scanCanonicalize (H12AffineFastState.compose env34021 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 71) := by decide +kernel

theorem selectedBound34021 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env34022 : List Nat := [2,4,8,0,1,64,8,4,512,68,71,12,8,13,1,3,13,70,69,0,76,1,1,67,8,64,7,76,76,71,4,1,5,65,76,512]

theorem envBound34022 : H12AffineFastState.Bounded env34022 := by
  intro p hp
  have h : env34022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34021_34022 : H12AffineEnvironment.transform 10 71 env34021 = env34022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 71 env34021 == env34022) = true)

theorem identity34022 : scanCanonicalize (H12AffineFastState.compose env34022 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34022 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env34023 : List Nat := [2,4,3,0,1,64,3,4,512,68,71,7,3,6,1,3,6,70,69,0,71,1,1,67,3,64,7,71,71,71,4,1,5,65,71,512]

theorem envBound34023 : H12AffineFastState.Bounded env34023 := by
  intro p hp
  have h : env34023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34022_34023 : H12AffineEnvironment.transform 2 3 env34022 = env34023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34022 == env34023) = true)

theorem identity34023 : scanCanonicalize (H12AffineFastState.compose env34023 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound34023 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34024 : List Nat := [2,4,3,0,1,0,3,4,512,4,7,7,3,6,1,3,6,6,5,0,7,1,1,3,3,0,7,7,7,7,4,1,5,1,7,512]

theorem envBound34024 : H12AffineFastState.Bounded env34024 := by
  intro p hp
  have h : env34024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34023_34024 : H12AffineEnvironment.transform 5 0 env34023 = env34024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env34023 == env34024) = true)

theorem identity34024 : scanCanonicalize (H12AffineFastState.compose env34024 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound34024 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34025 : List Nat := [2,4,3,0,1,0,3,4,2,4,7,7,3,6,1,3,6,6,5,0,7,1,1,3,3,0,7,7,7,7,4,1,5,1,7,2]

theorem envBound34025 : H12AffineFastState.Bounded env34025 := by
  intro p hp
  have h : env34025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34024_34025 : H12AffineEnvironment.transform 8 2 env34024 = env34025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env34024 == env34025) = true)

def env34026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,144477,243088,8328,64,43476,139612,160076,324700,1501,272393,257,21793,46213,74250]

theorem envBound34026 : H12AffineFastState.Bounded env34026 := by
  intro p hp
  have h : env34026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33989_34026 : H12AffineEnvironment.transform 20 4161 env33989 = env34026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env33989 == env34026) = true)

theorem identity34026 : scanCanonicalize (H12AffineFastState.compose env34026 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound34026 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4161,318549,17,98780,8328,64,43476,5392,17664,324700,1501,272393,257,21793,46213,74250]

theorem envBound34027 : H12AffineFastState.Bounded env34027 := by
  intro p hp
  have h : env34027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34026_34027 : H12AffineEnvironment.transform 16 13388 env34026 = env34027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env34026 == env34027) = true)

def env34028 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4161,318549,17,98644,8192,64,43356,5392,17664,324700,1365,272393,257,21793,46093,74250]

theorem envBound34028 : H12AffineFastState.Bounded env34028 := by
  intro p hp
  have h : env34028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34027_34028 : H12AffineEnvironment.transform 6 8 env34027 = env34028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34027 == env34028) = true)

theorem identity34028 : scanCanonicalize (H12AffineFastState.compose env34028 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound34028 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34029 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,35188,1025,32769,4161,21793,17,98644,8192,64,43356,5392,17664,32040,1365,41341,257,21793,46093,74250]

theorem envBound34029 : H12AffineFastState.Bounded env34029 := by
  intro p hp
  have h : env34029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34028_34029 : H12AffineEnvironment.transform 17 35188 env34028 = env34029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env34028 == env34029) = true)

theorem identity34029 : scanCanonicalize (H12AffineFastState.compose env34029 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound34029 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env34030 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,262,13388,35188,1025,32769,4161,21793,17,32850,8192,64,43356,5392,17664,32040,1365,41341,257,21793,46093,8972]

theorem envBound34030 : H12AffineFastState.Bounded env34030 := by
  intro p hp
  have h : env34030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34029_34030 : H12AffineEnvironment.transform 15 262 env34029 = env34030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env34029 == env34030) = true)

theorem identity34030 : scanCanonicalize (H12AffineFastState.compose env34030 (packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound34030 : packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env34031 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,262,13388,23589,1025,21840,4161,21793,17,21763,8192,64,31757,5392,17664,32040,1365,29740,257,21793,24924,8972]

theorem envBound34031 : H12AffineFastState.Bounded env34031 := by
  intro p hp
  have h : env34031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34030_34031 : H12AffineEnvironment.transform 14 21841 env34030 = env34031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env34030 == env34031) = true)

theorem identity34031 : scanCanonicalize (H12AffineFastState.compose env34031 (packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound34031 : packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env34032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,300,16384,21841,262,5472,23589,1025,21840,4161,21793,17,21763,300,64,23841,5392,17664,23556,1365,21760,257,21793,16496,544]

theorem envBound34032 : H12AffineFastState.Bounded env34032 := by
  intro p hp
  have h : env34032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34031_34032 : H12AffineEnvironment.transform 12 300 env34031 = env34032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env34031 == env34032) = true)

theorem identity34032 : scanCanonicalize (H12AffineFastState.compose env34032 (packedSelected [1,2,4,6,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound34032 : packedSelected [1,2,4,6,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env34033 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,41,16384,21588,3,5221,23589,1025,21589,4161,21540,17,21510,41,64,23588,5141,17413,23556,1104,21509,4,21540,16496,544]

theorem envBound34033 : H12AffineFastState.Bounded env34033 := by
  intro p hp
  have h : env34033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34032_34033 : H12AffineEnvironment.transform 7 5 env34032 = env34033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34032 == env34033) = true)

theorem identity34033 : scanCanonicalize (H12AffineFastState.compose env34033 (packedSelected [2,3,4,5,7,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 1620) := by decide +kernel

theorem selectedBound34033 : packedSelected [2,3,4,5,7,11,15] rootPS < 2^1333 := by decide +kernel

def env34034 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,41,1620,4608,3,5221,6769,1025,4609,4161,4720,17,4690,41,64,6768,5141,593,6736,1104,4689,4,4720,1572,544]

theorem envBound34034 : H12AffineFastState.Bounded env34034 := by
  intro p hp
  have h : env34034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34033_34034 : H12AffineEnvironment.transform 13 1620 env34033 = env34034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1620 env34033 == env34034) = true)

def env34035 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4161,318549,17,98645,8193,64,43357,5392,17664,324700,1364,272393,257,21793,46092,74250]

theorem envBound34035 : H12AffineFastState.Bounded env34035 := by
  intro p hp
  have h : env34035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34027_34035 : H12AffineEnvironment.transform 6 9 env34027 = env34035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34027 == env34035) = true)

theorem identity34035 : scanCanonicalize (H12AffineFastState.compose env34035 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound34035 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34036 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10281,1025,32769,4161,62588,17,98645,8193,64,43357,5392,17664,56437,1364,32,257,21793,46092,74250]

theorem envBound34036 : H12AffineFastState.Bounded env34036 := by
  intro p hp
  have h : env34036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34035_34036 : H12AffineEnvironment.transform 17 10281 env34035 = env34036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env34035 == env34036) = true)

theorem identity34036 : scanCanonicalize (H12AffineFastState.compose env34036 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound34036 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env34037 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,10281,1025,29788,4161,33,17,95496,8193,64,23808,5392,17664,10280,1364,32,257,21793,16465,74250]

theorem envBound34037 : H12AffineFastState.Bounded env34037 := by
  intro p hp
  have h : env34037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34036_34037 : H12AffineEnvironment.transform 14 29789 env34036 = env34037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env34036 == env34037) = true)

theorem identity34037 : scanCanonicalize (H12AffineFastState.compose env34037 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound34037 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env34038 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21591,13388,10281,1025,29788,4161,33,17,8543,8193,64,23808,5392,17664,10280,1364,32,257,21793,16465,30301]

theorem envBound34038 : H12AffineFastState.Bounded env34038 := by
  intro p hp
  have h : env34038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34037_34038 : H12AffineEnvironment.transform 15 21591 env34037 = env34038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env34037 == env34038) = true)

theorem identity34038 : scanCanonicalize (H12AffineFastState.compose env34038 (packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34038 : packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env34039 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,21511,13340,10281,1025,29708,4113,33,17,8463,8193,16,23808,5392,17664,10280,1284,32,257,21793,16385,30221]

theorem envBound34039 : H12AffineFastState.Bounded env34039 := by
  intro p hp
  have h : env34039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34038_34039 : H12AffineEnvironment.transform 5 16 env34038 = env34039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34038 == env34039) = true)

def env34040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237468,243089,8328,64,6705549,2240796,160076,2417693,2102685,6475856,257,21792,46212,2175562]

theorem envBound34040 : H12AffineFastState.Bounded env34040 := by
  intro p hp
  have h : env34040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33926_34040 : H12AffineEnvironment.transform 23 243089 env33926 = env34040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243089 env33926 == env34040) = true)

def env34041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,2237468,243089,8328,64,2144661,2240796,160076,2417693,2102685,2373704,257,21792,46212,2175562]

theorem envBound34041 : H12AffineFastState.Bounded env34041 := by
  intro p hp
  have h : env34041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34040_34041 : H12AffineEnvironment.transform 21 452632 env34040 = env34041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452632 env34040 == env34041) = true)

def env34042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,144476,243089,8328,64,43477,139612,160076,324701,1501,272392,257,21792,46212,74250]

theorem envBound34042 : H12AffineFastState.Bounded env34042 := by
  intro p hp
  have h : env34042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34041_34042 : H12AffineEnvironment.transform 20 4160 env34041 = env34042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34041 == env34042) = true)

theorem identity34042 : scanCanonicalize (H12AffineFastState.compose env34042 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34042 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4160,452632,144476,169370,8328,64,43477,139612,160076,324701,1501,272392,257,21792,46212,513]

theorem envBound34043 : H12AffineFastState.Bounded env34043 := by
  intro p hp
  have h : env34043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34042_34043 : H12AffineEnvironment.transform 15 8203 env34042 = env34043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34042 == env34043) = true)

def env34044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4160,305160,29772,54666,8328,64,43477,24908,12636,324701,1501,272392,257,21792,46212,513]

theorem envBound34044 : H12AffineFastState.Bounded env34044 := by
  intro p hp
  have h : env34044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34043_34044 : H12AffineEnvironment.transform 16 16400 env34043 = env34044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env34043 == env34044) = true)

def env34045 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4160,305160,29772,54530,8192,64,43357,24908,12636,324701,1365,272392,257,21792,46092,513]

theorem envBound34045 : H12AffineFastState.Bounded env34045 := by
  intro p hp
  have h : env34045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34044_34045 : H12AffineEnvironment.transform 6 8 env34044 = env34045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34044 == env34045) = true)

theorem identity34045 : scanCanonicalize (H12AffineFastState.compose env34045 (packedSelected [0,14,27] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound34045 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env34046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,32768,1095,16400,262144,1025,32769,4160,298052,20480,54530,1100,64,36113,17664,5392,315409,1365,265284,257,21792,36928,513]

theorem envBound34046 : H12AffineFastState.Bounded env34046 := by
  intro p hp
  have h : env34046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34045_34046 : H12AffineEnvironment.transform 12 1100 env34045 = env34046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env34045 == env34046) = true)

theorem identity34046 : scanCanonicalize (H12AffineFastState.compose env34046 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound34046 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env34047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,1296,1095,16400,262144,1025,1297,4160,264532,20480,20498,1100,64,2049,17664,5392,283905,1365,265284,257,21792,5456,513]

theorem envBound34047 : H12AffineFastState.Bounded env34047 := by
  intro p hp
  have h : env34047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34046_34047 : H12AffineEnvironment.transform 14 1296 env34046 = env34047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env34046 == env34047) = true)

theorem identity34047 : scanCanonicalize (H12AffineFastState.compose env34047 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 3172) := by decide +kernel

theorem selectedBound34047 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,1296,1095,16400,3172,1025,1297,4160,1328,20480,20498,1100,64,2049,17664,5392,22885,1365,32,257,21792,5456,513]

theorem envBound34048 : H12AffineFastState.Bounded env34048 := by
  intro p hp
  have h : env34048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34047_34048 : H12AffineEnvironment.transform 17 3172 env34047 = env34048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3172 env34047 == env34048) = true)

theorem identity34048 : scanCanonicalize (H12AffineFastState.compose env34048 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound34048 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env34049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3329,1100,16384,1296,1095,16400,3172,1025,1297,3393,1328,19713,19731,1100,64,2049,17664,2065,17508,1365,32,257,18465,2129,513]

theorem envBound34049 : H12AffineFastState.Bounded env34049 := by
  intro p hp
  have h : env34049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34048_34049 : H12AffineEnvironment.transform 11 3329 env34048 = env34049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env34048 == env34049) = true)

theorem identity34049 : scanCanonicalize (H12AffineFastState.compose env34049 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34049 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env34050 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3109,1100,16384,1076,1095,16400,3172,1025,1077,3173,1044,19493,19511,1100,64,2049,17444,2065,17508,1137,32,37,18465,2129,513]

theorem envBound34050 : H12AffineFastState.Bounded env34050 := by
  intro p hp
  have h : env34050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34049_34050 : H12AffineEnvironment.transform 7 36 env34049 = env34050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34049 == env34050) = true)

theorem identity34050 : scanCanonicalize (H12AffineFastState.compose env34050 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 2128) := by decide +kernel

theorem selectedBound34050 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env34051 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3109,1100,2128,1076,1095,2112,3172,1025,1077,3173,1044,1141,1127,1100,64,2049,3188,2065,3124,1137,32,37,113,2129,513]

theorem envBound34051 : H12AffineFastState.Bounded env34051 := by
  intro p hp
  have h : env34051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34050_34051 : H12AffineEnvironment.transform 13 2128 env34050 = env34051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2128 env34050 == env34051) = true)

theorem identity34051 : scanCanonicalize (H12AffineFastState.compose env34051 (packedSelected [1,2,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 570) := by decide +kernel

theorem selectedBound34051 : packedSelected [1,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env34052 : List Nat := [2,4,8,16,32,64,8,36,512,1024,570,1567,1100,618,1076,1095,634,1630,1025,1077,1631,1044,1141,1127,1100,64,571,1614,555,1550,1137,32,37,113,619,513]

theorem envBound34052 : H12AffineFastState.Bounded env34052 := by
  intro p hp
  have h : env34052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34051_34052 : H12AffineEnvironment.transform 10 570 env34051 = env34052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 570 env34051 == env34052) = true)

theorem identity34052 : scanCanonicalize (H12AffineFastState.compose env34052 (packedSelected [3,6,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34052 : packedSelected [3,6,9] rootPS < 2^1333 := by decide +kernel

def env34053 : List Nat := [2,4,8,16,32,16,8,36,512,1024,570,1567,1052,570,1076,1047,554,1550,1025,1077,1551,1044,1061,1079,1052,16,571,1566,555,1550,1057,32,37,33,571,513]

theorem envBound34053 : H12AffineFastState.Bounded env34053 := by
  intro p hp
  have h : env34053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34052_34053 : H12AffineEnvironment.transform 5 16 env34052 = env34053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34052 == env34053) = true)

def env34054 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4160,305160,29772,54531,8193,64,43356,24908,12636,324701,1364,272392,257,21792,46093,513]

theorem envBound34054 : H12AffineFastState.Bounded env34054 := by
  intro p hp
  have h : env34054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34044_34054 : H12AffineEnvironment.transform 6 9 env34044 = env34054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34044 == env34054) = true)

def env34055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4160,305161,29773,54667,8328,64,43477,24909,12637,324701,1501,272392,257,21792,46212,513]

theorem envBound34055 : H12AffineFastState.Bounded env34055 := by
  intro p hp
  have h : env34055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34043_34055 : H12AffineEnvironment.transform 16 16401 env34043 = env34055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env34043 == env34055) = true)

theorem identity34055 : scanCanonicalize (H12AffineFastState.compose env34055 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound34055 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8203,13389,262144,1025,32769,4160,305161,17,41431,8328,64,43477,5393,12637,294913,1501,272392,257,8572,46212,513]

theorem envBound34056 : H12AffineFastState.Bounded env34056 := by
  intro p hp
  have h : env34056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34055_34056 : H12AffineEnvironment.transform 13 13404 env34055 = env34056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env34055 == env34056) = true)

theorem identity34056 : scanCanonicalize (H12AffineFastState.compose env34056 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 43168) := by decide +kernel

theorem selectedBound34056 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8203,13389,43168,1025,32769,4160,169,17,41431,8328,64,43477,5393,12637,10401,1501,32936,257,8572,46212,513]

theorem envBound34057 : H12AffineFastState.Bounded env34057 := by
  intro p hp
  have h : env34057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34056_34057 : H12AffineEnvironment.transform 17 43168 env34056 = env34057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43168 env34056 == env34057) = true)

theorem identity34057 : scanCanonicalize (H12AffineFastState.compose env34057 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound34057 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env34058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8660,8203,13389,2420,1025,8661,4160,169,17,3,8328,64,2049,5393,12637,10401,1501,8572,257,8572,5456,513]

theorem envBound34058 : H12AffineFastState.Bounded env34058 := by
  intro p hp
  have h : env34058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34057_34058 : H12AffineEnvironment.transform 14 8660 env34057 = env34058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env34057 == env34058) = true)

theorem identity34058 : scanCanonicalize (H12AffineFastState.compose env34058 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound34058 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,0,479,5529,2420,1025,1,4160,169,17,3,348,64,2049,5393,4233,2421,1501,168,257,168,5456,513]

theorem envBound34059 : H12AffineFastState.Bounded env34059 := by
  intro p hp
  have h : env34059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34058_34059 : H12AffineEnvironment.transform 12 468 env34058 = env34059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env34058 == env34059) = true)

theorem identity34059 : scanCanonicalize (H12AffineFastState.compose env34059 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound34059 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env34060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,468,1416,0,479,1433,2420,1025,1,64,169,17,3,348,64,2049,1297,137,2421,1501,168,257,168,1360,513]

theorem envBound34060 : H12AffineFastState.Bounded env34060 := by
  intro p hp
  have h : env34060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34059_34060 : H12AffineEnvironment.transform 11 0 env34059 = env34060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env34059 == env34060) = true)

theorem identity34060 : scanCanonicalize (H12AffineFastState.compose env34060 (packedSelected [4,5,8,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 502) := by decide +kernel

theorem selectedBound34060 : packedSelected [4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env34061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,502,0,468,1416,0,479,1433,130,1025,1,64,169,17,3,348,64,503,1297,137,131,1501,168,257,168,1360,513]

theorem envBound34061 : H12AffineFastState.Bounded env34061 := by
  intro p hp
  have h : env34061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34060_34061 : H12AffineEnvironment.transform 10 502 env34060 = env34061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 502 env34060 == env34061) = true)

theorem identity34061 : scanCanonicalize (H12AffineFastState.compose env34061 (packedSelected [1,3,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34061 : packedSelected [1,3,11,18] rootPS < 2^1333 := by decide +kernel

def env34062 : List Nat := [2,4,8,16,32,16,128,256,512,1024,422,0,388,1416,0,399,1433,130,1025,1,16,169,17,3,268,16,423,1297,137,131,1421,168,257,168,1280,513]

theorem envBound34062 : H12AffineFastState.Bounded env34062 := by
  intro p hp
  have h : env34062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34061_34062 : H12AffineEnvironment.transform 5 16 env34061 = env34062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34061 == env34062) = true)

theorem identity34062 : scanCanonicalize (H12AffineFastState.compose env34062 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 403) := by decide +kernel

theorem selectedBound34062 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env34063 : List Nat := [2,4,8,16,32,16,128,256,512,403,422,0,388,27,0,399,10,130,402,1,16,169,17,3,268,16,423,130,137,131,30,168,257,168,147,513]

theorem envBound34063 : H12AffineFastState.Bounded env34063 := by
  intro p hp
  have h : env34063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34062_34063 : H12AffineEnvironment.transform 9 403 env34062 = env34063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 403 env34062 == env34063) = true)

theorem identity34063 : scanCanonicalize (H12AffineFastState.compose env34063 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound34063 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env34064 : List Nat := [2,4,8,16,32,16,50,256,512,289,276,0,310,27,0,317,10,48,288,1,16,27,17,3,268,16,277,48,59,49,30,26,257,26,33,513]

theorem envBound34064 : H12AffineFastState.Bounded env34064 := by
  intro p hp
  have h : env34064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34063_34064 : H12AffineEnvironment.transform 6 50 env34063 = env34064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env34063 == env34064) = true)

theorem identity34064 : scanCanonicalize (H12AffineFastState.compose env34064 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound34064 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env34065 : List Nat := [2,4,8,16,32,16,50,63,512,30,43,0,9,27,0,2,10,48,31,1,16,27,17,3,51,16,42,48,59,49,30,26,62,26,33,513]

theorem envBound34065 : H12AffineFastState.Bounded env34065 := by
  intro p hp
  have h : env34065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34064_34065 : H12AffineEnvironment.transform 7 63 env34064 = env34065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env34064 == env34065) = true)

theorem identity34065 : scanCanonicalize (H12AffineFastState.compose env34065 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34065 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34066 : List Nat := [2,4,8,16,0,16,18,31,512,30,11,0,9,27,0,2,10,16,31,1,16,27,17,3,19,16,10,16,27,17,30,26,30,26,1,513]

theorem envBound34066 : H12AffineFastState.Bounded env34066 := by
  intro p hp
  have h : env34066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34065_34066 : H12AffineEnvironment.transform 4 0 env34065 = env34066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34065 == env34066) = true)

theorem identity34066 : scanCanonicalize (H12AffineFastState.compose env34066 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound34066 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env34067 : List Nat := [2,4,8,15,0,15,13,0,512,1,11,0,9,4,0,2,10,15,0,1,15,4,14,3,12,15,10,15,4,14,1,5,1,5,1,513]

theorem envBound34067 : H12AffineFastState.Bounded env34067 := by
  intro p hp
  have h : env34067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34066_34067 : H12AffineEnvironment.transform 3 15 env34066 = env34067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env34066 == env34067) = true)

theorem identity34067 : scanCanonicalize (H12AffineFastState.compose env34067 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound34067 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env34068 : List Nat := [2,1,8,10,0,10,8,0,512,1,11,0,9,1,0,2,10,10,0,1,10,1,11,3,9,10,10,10,1,11,1,0,1,0,1,513]

theorem envBound34068 : H12AffineFastState.Bounded env34068 := by
  intro p hp
  have h : env34068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34067_34068 : H12AffineEnvironment.transform 1 1 env34067 = env34068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env34067 == env34068) = true)

theorem identity34068 : scanCanonicalize (H12AffineFastState.compose env34068 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34068 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34069 : List Nat := [2,1,2,0,0,0,2,0,512,1,1,0,3,1,0,2,0,0,0,1,0,1,1,3,3,0,0,0,1,1,1,0,1,0,1,513]

theorem envBound34069 : H12AffineFastState.Bounded env34069 := by
  intro p hp
  have h : env34069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34068_34069 : H12AffineEnvironment.transform 2 2 env34068 = env34069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34068 == env34069) = true)

theorem identity34069 : scanCanonicalize (H12AffineFastState.compose env34069 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound34069 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34070 : List Nat := [2,1,2,0,0,0,2,0,2,1,1,0,3,1,0,2,0,0,0,1,0,1,1,3,3,0,0,0,1,1,1,0,1,0,1,3]

theorem envBound34070 : H12AffineFastState.Bounded env34070 := by
  intro p hp
  have h : env34070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34069_34070 : H12AffineEnvironment.transform 8 2 env34069 = env34070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env34069 == env34070) = true)

theorem identity34070 : scanCanonicalize (H12AffineFastState.compose env34070 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34070 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34071 : List Nat := [1,1,1,0,0,0,1,0,1,1,1,0,0,1,0,1,0,0,0,1,0,1,1,0,0,0,0,0,1,1,1,0,1,0,1,0]

theorem envBound34071 : H12AffineFastState.Bounded env34071 := by
  intro p hp
  have h : env34071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34070_34071 : H12AffineEnvironment.transform 0 1 env34070 = env34071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34070 == env34071) = true)

def env34072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,144477,243089,8328,64,43476,139613,160076,324700,1500,272393,257,21792,46212,74251]

theorem envBound34072 : H12AffineFastState.Bounded env34072 := by
  intro p hp
  have h : env34072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34041_34072 : H12AffineEnvironment.transform 20 4161 env34041 = env34072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34041 == env34072) = true)

theorem identity34072 : scanCanonicalize (H12AffineFastState.compose env34072 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123027) := by decide +kernel

theorem selectedBound34072 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,4161,329867,120014,21762,8328,64,43476,115150,102879,324700,1500,272393,257,21792,46212,74251]

theorem envBound34073 : H12AffineFastState.Bounded env34073 := by
  intro p hp
  have h : env34073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34072_34073 : H12AffineEnvironment.transform 16 123027 env34072 = env34073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123027 env34072 == env34073) = true)

def env34074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10400,1025,32769,4161,73771,120014,21762,8328,64,43476,115150,102879,56572,1500,169,257,21792,46212,74251]

theorem envBound34074 : H12AffineFastState.Bounded env34074 := by
  intro p hp
  have h : env34074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34073_34074 : H12AffineEnvironment.transform 17 10400 env34073 = env34074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env34073 == env34074) = true)

def env34075 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10280,1025,32769,4161,73771,119878,21762,8192,64,43356,115014,102743,56436,1364,33,257,21792,46092,74251]

theorem envBound34075 : H12AffineFastState.Bounded env34075 := by
  intro p hp
  have h : env34075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34074_34075 : H12AffineEnvironment.transform 6 8 env34074 = env34075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34074 == env34075) = true)

theorem identity34075 : scanCanonicalize (H12AffineFastState.compose env34075 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound34075 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34076 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,82247,10280,1025,8541,4161,73771,95514,21762,8192,64,2048,90138,77835,32040,1364,33,257,21792,5456,74251]

theorem envBound34076 : H12AffineFastState.Bounded env34076 := by
  intro p hp
  have h : env34076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34075_34076 : H12AffineEnvironment.transform 14 8540 env34075 = env34076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env34075 == env34076) = true)

theorem identity34076 : scanCanonicalize (H12AffineFastState.compose env34076 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound34076 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env34077 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,16400,10280,1025,8541,4161,8572,29773,21762,8192,64,2048,24909,12636,32040,1364,33,257,21792,5456,9052]

theorem envBound34077 : H12AffineFastState.Bounded env34077 := by
  intro p hp
  have h : env34077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34076_34077 : H12AffineEnvironment.transform 15 343 env34076 = env34077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env34076 == env34077) = true)

theorem identity34077 : scanCanonicalize (H12AffineFastState.compose env34077 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound34077 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34078 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,343,4096,10280,1025,8541,4161,8572,9309,1298,8192,64,2048,12637,12636,11576,1364,33,257,1328,5456,9052]

theorem envBound34078 : H12AffineFastState.Bounded env34078 := by
  intro p hp
  have h : env34078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34077_34078 : H12AffineEnvironment.transform 13 4112 env34077 = env34078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env34077 == env34078) = true)

theorem identity34078 : scanCanonicalize (H12AffineFastState.compose env34078 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound34078 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env34079 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,8192,4112,8540,343,4096,10280,53,8541,4161,8572,8297,294,8192,64,2048,12637,12636,10508,352,33,257,260,4452,9052]

theorem envBound34079 : H12AffineFastState.Bounded env34079 := by
  intro p hp
  have h : env34079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34078_34079 : H12AffineEnvironment.transform 9 52 env34078 = env34079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34078 == env34079) = true)

theorem identity34079 : scanCanonicalize (H12AffineFastState.compose env34079 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound34079 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env34080 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,349,4112,1,343,4096,2421,53,0,4161,33,308,294,349,64,2048,4096,4097,2129,352,33,257,260,4452,513]

theorem envBound34080 : H12AffineFastState.Bounded env34080 := by
  intro p hp
  have h : env34080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34079_34080 : H12AffineEnvironment.transform 12 349 env34079 = env34080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env34079 == env34080) = true)

theorem identity34080 : scanCanonicalize (H12AffineFastState.compose env34080 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34080 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env34081 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,4096,120,4112,1,114,4096,2128,53,0,4161,33,17,3,120,64,2048,4096,4097,2129,69,33,36,33,4161,513]

theorem envBound34081 : H12AffineFastState.Bounded env34081 := by
  intro p hp
  have h : env34081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34080_34081 : H12AffineEnvironment.transform 7 37 env34080 = env34081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34080 == env34081) = true)

theorem identity34081 : scanCanonicalize (H12AffineFastState.compose env34081 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound34081 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34082 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,2586,120,2570,1,114,2586,2128,53,0,2651,33,17,3,120,64,2048,2586,2587,2129,69,33,36,33,2651,513]

theorem envBound34082 : H12AffineFastState.Bounded env34082 := by
  intro p hp
  have h : env34082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34081_34082 : H12AffineEnvironment.transform 11 2586 env34081 = env34082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env34081 == env34082) = true)

theorem identity34082 : scanCanonicalize (H12AffineFastState.compose env34082 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34082 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34083 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2586,40,2570,1,34,2586,2048,53,0,2571,33,17,3,40,16,2048,2586,2587,2049,21,33,36,33,2571,513]

theorem envBound34083 : H12AffineFastState.Bounded env34083 := by
  intro p hp
  have h : env34083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34082_34083 : H12AffineEnvironment.transform 5 16 env34082 = env34083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34082 == env34083) = true)

theorem identity34083 : scanCanonicalize (H12AffineFastState.compose env34083 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound34083 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34084 : List Nat := [2,4,8,16,21,16,8,16,512,1,2048,2586,29,2570,1,23,2586,2048,0,0,2571,20,17,3,29,16,2048,2586,2587,2049,21,20,17,20,2571,513]

theorem envBound34084 : H12AffineFastState.Bounded env34084 := by
  intro p hp
  have h : env34084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34083_34084 : H12AffineEnvironment.transform 4 21 env34083 = env34084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env34083 == env34084) = true)

theorem identity34084 : scanCanonicalize (H12AffineFastState.compose env34084 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 520) := by decide +kernel

theorem selectedBound34084 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34085 : List Nat := [2,4,8,16,21,16,8,16,512,1,520,18,29,2,1,23,18,520,0,0,3,20,17,3,29,16,520,18,19,521,21,20,17,20,3,513]

theorem envBound34085 : H12AffineFastState.Bounded env34085 := by
  intro p hp
  have h : env34085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34084_34085 : H12AffineEnvironment.transform 10 520 env34084 = env34085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 520 env34084 == env34085) = true)

theorem identity34085 : scanCanonicalize (H12AffineFastState.compose env34085 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound34085 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34086 : List Nat := [2,4,8,16,21,16,8,16,29,1,21,18,29,2,1,23,18,21,0,0,3,20,17,3,29,16,21,18,19,20,21,20,17,20,3,28]

theorem envBound34086 : H12AffineFastState.Bounded env34086 := by
  intro p hp
  have h : env34086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34085_34086 : H12AffineEnvironment.transform 8 29 env34085 = env34086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env34085 == env34086) = true)

theorem identity34086 : scanCanonicalize (H12AffineFastState.compose env34086 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound34086 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env34087 : List Nat := [2,4,8,5,0,5,8,5,8,1,0,7,8,2,1,2,7,0,0,0,3,1,4,3,8,5,0,7,6,1,0,1,4,1,3,9]

theorem envBound34087 : H12AffineFastState.Bounded env34087 := by
  intro p hp
  have h : env34087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34086_34087 : H12AffineEnvironment.transform 3 5 env34086 = env34087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env34086 == env34087) = true)

theorem identity34087 : scanCanonicalize (H12AffineFastState.compose env34087 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34087 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env34088 : List Nat := [0,4,8,5,0,5,8,5,8,1,0,5,8,0,1,0,5,0,0,0,1,1,4,1,8,5,0,5,4,1,0,1,4,1,1,9]

theorem envBound34088 : H12AffineFastState.Bounded env34088 := by
  intro p hp
  have h : env34088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34087_34088 : H12AffineEnvironment.transform 0 0 env34087 = env34088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34087 == env34088) = true)

def env34089 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1025,32769,4161,73771,119879,21762,8193,64,43357,115015,102742,56437,1365,32,257,21792,46093,74251]

theorem envBound34089 : H12AffineFastState.Bounded env34089 := by
  intro p hp
  have h : env34089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34074_34089 : H12AffineEnvironment.transform 6 9 env34074 = env34089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34074 == env34089) = true)

theorem identity34089 : scanCanonicalize (H12AffineFastState.compose env34089 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound34089 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env34090 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,70726,10281,1025,29789,4161,73771,73755,21762,8193,64,23809,79131,91402,10281,1365,32,257,21792,16465,74251]

theorem envBound34090 : H12AffineFastState.Bounded env34090 := by
  intro p hp
  have h : env34090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34089_34090 : H12AffineEnvironment.transform 14 29788 env34089 = env34090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env34089 == env34090) = true)

theorem identity34090 : scanCanonicalize (H12AffineFastState.compose env34090 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34090 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env34091 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,13388,10281,1025,29789,4161,33,17,21762,8193,64,23809,5393,17664,10281,1365,32,257,21792,16465,513]

theorem envBound34091 : H12AffineFastState.Bounded env34091 := by
  intro p hp
  have h : env34091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34090_34091 : H12AffineEnvironment.transform 15 8202 env34090 = env34091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34090 == env34091) = true)

theorem identity34091 : scanCanonicalize (H12AffineFastState.compose env34091 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound34091 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env34092 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,80,8202,13388,10281,1025,81,4161,33,17,8462,8193,64,10509,5393,12556,10281,1365,32,257,8492,13405,513]

theorem envBound34092 : H12AffineFastState.Bounded env34092 := by
  intro p hp
  have h : env34092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34091_34092 : H12AffineEnvironment.transform 13 13324 env34091 = env34092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env34091 == env34092) = true)

theorem identity34092 : scanCanonicalize (H12AffineFastState.compose env34092 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34092 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env34093 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,0,8202,13340,10281,1025,1,4113,33,17,8462,8193,16,10509,5393,12556,10281,1285,32,257,8492,13325,513]

theorem envBound34093 : H12AffineFastState.Bounded env34093 := by
  intro p hp
  have h : env34093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34092_34093 : H12AffineEnvironment.transform 5 16 env34092 = env34093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34092 == env34093) = true)

theorem identity34093 : scanCanonicalize (H12AffineFastState.compose env34093 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound34093 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env34094 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8192,13324,0,8202,13340,10281,1025,1,4113,33,17,8203,8193,16,10248,5140,12297,10281,1024,32,4,8233,13325,513]

theorem envBound34094 : H12AffineFastState.Bounded env34094 := by
  intro p hp
  have h : env34094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34093_34094 : H12AffineEnvironment.transform 7 5 env34093 = env34094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34093 == env34094) = true)

theorem identity34094 : scanCanonicalize (H12AffineFastState.compose env34094 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound34094 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34095 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8,5124,0,2,5140,2081,1025,1,4113,33,17,3,9,16,2048,5140,4097,2081,1024,32,4,33,5125,513]

theorem envBound34095 : H12AffineFastState.Bounded env34095 := by
  intro p hp
  have h : env34095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34094_34095 : H12AffineEnvironment.transform 12 8 env34094 = env34095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env34094 == env34095) = true)

theorem identity34095 : scanCanonicalize (H12AffineFastState.compose env34095 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34095 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34096 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,4096,8,5124,0,2,5140,2048,1025,1,4113,0,17,3,9,16,2048,5140,4097,2048,1024,1,4,0,5125,513]

theorem envBound34096 : H12AffineFastState.Bounded env34096 := by
  intro p hp
  have h : env34096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34095_34096 : H12AffineEnvironment.transform 4 1 env34095 = env34096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34095 == env34096) = true)

theorem identity34096 : scanCanonicalize (H12AffineFastState.compose env34096 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound34096 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34097 : List Nat := [2,4,8,16,1,16,9,5,512,1024,523,4096,8,5124,0,2,5140,523,1025,1,4113,0,17,3,9,16,523,5140,4097,523,1024,1,4,0,5125,513]

theorem envBound34097 : H12AffineFastState.Bounded env34097 := by
  intro p hp
  have h : env34097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34096_34097 : H12AffineEnvironment.transform 10 523 env34096 = env34097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env34096 == env34097) = true)

def env34098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10401,1025,32769,4161,73770,120014,21762,8328,64,43476,115150,102879,56573,1500,168,257,21792,46212,74251]

theorem envBound34098 : H12AffineFastState.Bounded env34098 := by
  intro p hp
  have h : env34098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34073_34098 : H12AffineEnvironment.transform 17 10401 env34073 = env34098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env34073 == env34098) = true)

def env34099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1025,32769,4161,73770,119878,21762,8192,64,43356,115014,102743,56437,1364,32,257,21792,46092,74251]

theorem envBound34099 : H12AffineFastState.Bounded env34099 := by
  intro p hp
  have h : env34099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34098_34099 : H12AffineEnvironment.transform 6 8 env34098 = env34099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34098 == env34099) = true)

theorem identity34099 : scanCanonicalize (H12AffineFastState.compose env34099 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound34099 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,38161,10281,1025,32769,4161,21792,41292,21762,8192,64,43356,46156,58461,56437,1364,32,257,21792,46092,22273]

theorem envBound34100 : H12AffineFastState.Bounded env34100 := by
  intro p hp
  have h : env34100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34099_34100 : H12AffineEnvironment.transform 15 29962 env34099 = env34100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env34099 == env34100) = true)

theorem identity34100 : scanCanonicalize (H12AffineFastState.compose env34100 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound34100 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env34101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,29962,24860,10281,1025,29708,4161,21792,21825,21762,8192,64,23889,16449,4176,10360,1364,32,257,21792,16385,22273]

theorem envBound34101 : H12AffineFastState.Bounded env34101 := by
  intro p hp
  have h : env34101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34100_34101 : H12AffineEnvironment.transform 14 29709 env34100 = env34101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env34100 == env34101) = true)

theorem identity34101 : scanCanonicalize (H12AffineFastState.compose env34101 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound34101 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env34102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,80,343,5441,10281,1025,81,4161,8573,8476,8543,8192,64,10508,13340,4176,10360,1364,32,257,8573,13404,9052]

theorem envBound34102 : H12AffineFastState.Bounded env34102 := by
  intro p hp
  have h : env34102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34101_34102 : H12AffineEnvironment.transform 13 13405 env34101 = env34102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env34101 == env34102) = true)

theorem identity34102 : scanCanonicalize (H12AffineFastState.compose env34102 (packedSelected [1,4,6,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7544) := by decide +kernel

theorem selectedBound34102 : packedSelected [1,4,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env34103 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7544,2341,80,343,5441,5457,1025,81,4161,7173,7268,7207,7544,64,5236,2404,4176,5376,1364,32,257,7173,2340,7716]

theorem envBound34103 : H12AffineFastState.Bounded env34103 := by
  intro p hp
  have h : env34103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34102_34103 : H12AffineEnvironment.transform 12 7544 env34102 = env34103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7544 env34102 == env34103) = true)

theorem identity34103 : scanCanonicalize (H12AffineFastState.compose env34103 (packedSelected [2,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound34103 : packedSelected [2,7,9,10] rootPS < 2^1333 := by decide +kernel

def env34104 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3109,349,2341,80,343,2404,2420,1025,81,3172,32,65,2,349,64,2129,2404,3189,2341,1364,32,257,32,2340,513]

theorem envBound34104 : H12AffineFastState.Bounded env34104 := by
  intro p hp
  have h : env34104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34103_34104 : H12AffineEnvironment.transform 11 3109 env34103 = env34104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env34103 == env34104) = true)

theorem identity34104 : scanCanonicalize (H12AffineFastState.compose env34104 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34104 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34105 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3109,41,2129,80,35,2064,2048,1025,81,3172,32,65,2,41,64,2129,2064,3189,2129,1056,32,117,32,2128,513]

theorem envBound34105 : H12AffineFastState.Bounded env34105 := by
  intro p hp
  have h : env34105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34104_34105 : H12AffineEnvironment.transform 7 116 env34104 = env34105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34104 == env34105) = true)

theorem identity34105 : scanCanonicalize (H12AffineFastState.compose env34105 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound34105 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34106 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1061,0,41,1140,80,35,1077,1061,1025,81,65,32,65,2,41,64,1140,1077,80,1140,1056,32,117,32,1141,513]

theorem envBound34106 : H12AffineFastState.Bounded env34106 := by
  intro p hp
  have h : env34106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34105_34106 : H12AffineEnvironment.transform 10 1061 env34105 = env34106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env34105 == env34106) = true)

theorem identity34106 : scanCanonicalize (H12AffineFastState.compose env34106 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound34106 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env34107 : List Nat := [2,4,8,16,32,64,8,116,512,101,64,0,41,17,80,35,80,64,100,81,65,32,65,2,41,64,17,80,80,17,69,32,117,32,16,513]

theorem envBound34107 : H12AffineFastState.Bounded env34107 := by
  intro p hp
  have h : env34107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34106_34107 : H12AffineEnvironment.transform 9 101 env34106 = env34107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env34106 == env34107) = true)

theorem identity34107 : scanCanonicalize (H12AffineFastState.compose env34107 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound34107 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env34108 : List Nat := [2,4,8,16,32,1,8,53,512,36,1,0,41,17,17,35,17,1,37,16,0,32,0,2,41,1,17,17,17,17,4,32,52,32,16,513]

theorem envBound34108 : H12AffineFastState.Bounded env34108 := by
  intro p hp
  have h : env34108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34107_34108 : H12AffineEnvironment.transform 5 1 env34107 = env34108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env34107 == env34108) = true)

def env34109 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10280,1025,32769,4161,73770,119879,21762,8193,64,43357,115015,102742,56436,1365,33,257,21792,46093,74251]

theorem envBound34109 : H12AffineFastState.Bounded env34109 := by
  intro p hp
  have h : env34109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34098_34109 : H12AffineEnvironment.transform 6 9 env34098 = env34109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34098 == env34109) = true)

theorem identity34109 : scanCanonicalize (H12AffineFastState.compose env34109 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound34109 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34110 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13389,10280,1025,32769,4161,62589,16,21762,8193,64,43357,5392,17665,56436,1365,33,257,21792,46093,63068]

theorem envBound34110 : H12AffineFastState.Bounded env34110 := by
  intro p hp
  have h : env34110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34109_34110 : H12AffineEnvironment.transform 15 54359 env34109 = env34110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env34109 == env34110) = true)

theorem identity34110 : scanCanonicalize (H12AffineFastState.compose env34110 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound34110 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env34111 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,13389,10280,1025,29788,4161,32,16,21762,8193,64,23808,5392,17665,10281,1365,33,257,21792,16464,513]

theorem envBound34111 : H12AffineFastState.Bounded env34111 := by
  intro p hp
  have h : env34111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34110_34111 : H12AffineEnvironment.transform 14 29789 env34110 = env34111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env34110 == env34111) = true)

theorem identity34111 : scanCanonicalize (H12AffineFastState.compose env34111 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound34111 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env34112 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,16384,20496,1095,4096,3173,1025,20497,4161,32,16,21762,1100,64,23808,5392,17665,3172,1365,33,257,21792,16464,513]

theorem envBound34112 : H12AffineFastState.Bounded env34112 := by
  intro p hp
  have h : env34112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34111_34112 : H12AffineEnvironment.transform 12 1101 env34111 = env34112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env34111 == env34112) = true)

theorem identity34112 : scanCanonicalize (H12AffineFastState.compose env34112 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound34112 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env34113 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,64,1101,16384,16464,1095,64,3173,1025,16465,1,32,16,17730,1100,64,19776,1360,17665,3172,1365,33,257,17760,16464,513]

theorem envBound34113 : H12AffineFastState.Bounded env34113 := by
  intro p hp
  have h : env34113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34112_34113 : H12AffineEnvironment.transform 11 64 env34112 = env34113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env34112 == env34113) = true)

theorem identity34113 : scanCanonicalize (H12AffineFastState.compose env34113 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound34113 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34114 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,64,349,16384,16464,343,64,2421,273,16465,1,32,16,16466,348,64,18512,64,16401,2420,69,33,257,16496,16464,513]

theorem envBound34114 : H12AffineFastState.Bounded env34114 := by
  intro p hp
  have h : env34114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34113_34114 : H12AffineEnvironment.transform 9 272 env34113 = env34114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env34113 == env34114) = true)

theorem identity34114 : scanCanonicalize (H12AffineFastState.compose env34114 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 81) := by decide +kernel

theorem selectedBound34114 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34115 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,64,349,81,1,343,64,2421,273,0,1,32,16,3,348,64,2049,64,64,2420,69,33,257,33,1,513]

theorem envBound34115 : H12AffineFastState.Bounded env34115 := by
  intro p hp
  have h : env34115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34114_34115 : H12AffineEnvironment.transform 13 81 env34114 = env34115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 81 env34114 == env34115) = true)

theorem identity34115 : scanCanonicalize (H12AffineFastState.compose env34115 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34115 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34116 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,64,120,81,1,114,64,2128,52,0,1,32,16,3,121,64,2049,64,64,2129,69,33,36,33,1,513]

theorem envBound34116 : H12AffineFastState.Bounded env34116 := by
  intro p hp
  have h : env34116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34115_34116 : H12AffineEnvironment.transform 7 37 env34115 = env34116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34115 == env34116) = true)

theorem identity34116 : scanCanonicalize (H12AffineFastState.compose env34116 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34116 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34117 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,17,41,0,1,35,17,2049,52,0,1,32,16,3,40,17,2049,17,17,2048,20,33,36,33,1,513]

theorem envBound34117 : H12AffineFastState.Bounded env34117 := by
  intro p hp
  have h : env34117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34116_34117 : H12AffineEnvironment.transform 5 17 env34116 = env34117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34116 == env34117) = true)

theorem identity34117 : scanCanonicalize (H12AffineFastState.compose env34117 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound34117 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34118 : List Nat := [2,4,8,16,32,17,9,37,512,53,512,17,41,0,1,35,17,513,52,0,1,32,16,3,40,17,513,17,17,512,20,33,36,33,1,513]

theorem envBound34118 : H12AffineFastState.Bounded env34118 := by
  intro p hp
  have h : env34118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34117_34118 : H12AffineEnvironment.transform 10 512 env34117 = env34118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env34117 == env34118) = true)

theorem identity34118 : scanCanonicalize (H12AffineFastState.compose env34118 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound34118 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34119 : List Nat := [2,4,8,16,26,17,9,31,512,15,512,17,19,0,1,25,17,513,14,0,1,26,16,3,18,17,513,17,17,512,20,27,30,27,1,513]

theorem envBound34119 : H12AffineFastState.Bounded env34119 := by
  intro p hp
  have h : env34119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34118_34119 : H12AffineEnvironment.transform 4 26 env34118 = env34119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env34118 == env34119) = true)

theorem identity34119 : scanCanonicalize (H12AffineFastState.compose env34119 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound34119 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34120 : List Nat := [2,4,8,16,26,17,9,31,0,15,0,17,19,0,1,25,17,1,14,0,1,26,16,3,18,17,1,17,17,0,20,27,30,27,1,1]

theorem envBound34120 : H12AffineFastState.Bounded env34120 := by
  intro p hp
  have h : env34120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34119_34120 : H12AffineEnvironment.transform 8 0 env34119 = env34120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env34119 == env34120) = true)

def env34121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,2237468,243089,8328,64,2144660,2240796,160076,2417693,2102685,2373705,257,21792,46212,2175562]

theorem envBound34121 : H12AffineFastState.Bounded env34121 := by
  intro p hp
  have h : env34121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34040_34121 : H12AffineEnvironment.transform 21 452633 env34040 = env34121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452633 env34040 == env34121) = true)

def env34122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,144476,243089,8328,64,43476,139612,160076,324701,1501,272393,257,21792,46212,74250]

theorem envBound34122 : H12AffineFastState.Bounded env34122 := by
  intro p hp
  have h : env34122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34121_34122 : H12AffineEnvironment.transform 20 4160 env34121 = env34122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34121 == env34122) = true)

theorem identity34122 : scanCanonicalize (H12AffineFastState.compose env34122 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound34122 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,4160,392287,73754,41431,8328,64,43476,79130,91402,324701,1501,272393,257,21792,46212,74250]

theorem envBound34123 : H12AffineFastState.Bounded env34123 := by
  intro p hp
  have h : env34123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34122_34123 : H12AffineEnvironment.transform 16 70726 env34122 = env34123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env34122 == env34123) = true)

def env34124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10400,1025,32769,4160,120063,73754,41431,8328,64,43476,79130,91402,56573,1501,169,257,21792,46212,74250]

theorem envBound34124 : H12AffineFastState.Bounded env34124 := by
  intro p hp
  have h : env34124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34123_34124 : H12AffineEnvironment.transform 17 10400 env34123 = env34124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env34123 == env34124) = true)

theorem identity34124 : scanCanonicalize (H12AffineFastState.compose env34124 (packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound34124 : packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env34125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,49304,10400,1025,32769,4160,33,62660,41431,8328,64,43476,57796,45524,56573,1501,169,257,21792,46212,63188]

theorem envBound34125 : H12AffineFastState.Bounded env34125 := by
  intro p hp
  have h : env34125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34124_34125 : H12AffineEnvironment.transform 15 54494 env34124 = env34125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env34124 == env34125) = true)

theorem identity34125 : scanCanonicalize (H12AffineFastState.compose env34125 (packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34125 : packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env34126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,32768,54494,49304,2476,1025,32769,4160,33,54728,32987,388,64,35032,49352,37080,56573,1501,169,257,21792,38280,55256]

theorem envBound34126 : H12AffineFastState.Bounded env34126 := by
  intro p hp
  have h : env34126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34125_34126 : H12AffineEnvironment.transform 12 268 env34125 = env34126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34125 == env34126) = true)

theorem identity34126 : scanCanonicalize (H12AffineFastState.compose env34126 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound34126 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env34127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,1,21727,16537,2476,1025,0,4160,33,21961,218,388,64,2265,16585,4313,23804,1501,169,257,21792,5513,22489]

theorem envBound34127 : H12AffineFastState.Bounded env34127 := by
  intro p hp
  have h : env34127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34126_34127 : H12AffineEnvironment.transform 14 1 env34126 = env34127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env34126 == env34127) = true)

theorem identity34127 : scanCanonicalize (H12AffineFastState.compose env34127 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,17,18,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34127 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env34128 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,1,21647,16537,2476,1025,0,4112,33,21913,138,388,16,2185,16537,4233,23724,1421,169,257,21792,5513,22409]

theorem envBound34128 : H12AffineFastState.Bounded env34128 := by
  intro p hp
  have h : env34128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34127_34128 : H12AffineEnvironment.transform 5 16 env34127 = env34128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34127 == env34128) = true)

theorem identity34128 : scanCanonicalize (H12AffineFastState.compose env34128 (packedSelected [2,3,4,5,9,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3212) := by decide +kernel

theorem selectedBound34128 : packedSelected [2,3,4,5,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env34129 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3212,268,16384,1,18435,16537,2476,1025,0,3228,33,18709,138,388,16,2185,16537,3077,16416,1421,169,257,18860,2309,19205]

theorem envBound34129 : H12AffineFastState.Bounded env34129 := by
  intro p hp
  have h : env34129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34128_34129 : H12AffineEnvironment.transform 11 3212 env34128 = env34129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3212 env34128 == env34129) = true)

theorem identity34129 : scanCanonicalize (H12AffineFastState.compose env34129 (packedSelected [0,1,3,4,5,6,7,8,9,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34129 : packedSelected [0,1,3,4,5,6,7,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env34130 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,3212,41,16384,1,18435,16537,2185,1025,0,3228,33,18480,138,161,16,2185,16537,3077,16416,1192,169,36,18569,2080,18976]

theorem envBound34130 : H12AffineFastState.Bounded env34130 := by
  intro p hp
  have h : env34130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34129_34130 : H12AffineEnvironment.transform 7 37 env34129 = env34130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34129 == env34130) = true)

theorem identity34130 : scanCanonicalize (H12AffineFastState.compose env34130 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(13+1) ^^^ 2184) := by decide +kernel

theorem selectedBound34130 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env34131 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,3212,41,2184,1,139,2065,2185,1025,0,3228,33,184,138,161,16,2185,2065,3077,2216,1192,169,36,1,2080,680]

theorem envBound34131 : H12AffineFastState.Bounded env34131 := by
  intro p hp
  have h : env34131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34130_34131 : H12AffineEnvironment.transform 13 2184 env34130 = env34131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2184 env34130 == env34131) = true)

theorem identity34131 : scanCanonicalize (H12AffineFastState.compose env34131 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34131 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34132 : List Nat := [2,4,8,16,1,16,128,4,512,1024,2048,3212,8,2184,1,139,2065,2185,1025,0,3228,0,153,138,128,16,2185,2065,3077,2185,1161,136,5,1,2049,649]

theorem envBound34132 : H12AffineFastState.Bounded env34132 := by
  intro p hp
  have h : env34132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34131_34132 : H12AffineEnvironment.transform 4 1 env34131 = env34132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34131 == env34132) = true)

theorem identity34132 : scanCanonicalize (H12AffineFastState.compose env34132 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound34132 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env34133 : List Nat := [2,4,8,16,1,16,128,4,512,1024,1,1165,8,137,1,139,16,136,1025,0,1181,0,153,138,128,16,136,16,1028,136,1161,136,5,1,0,649]

theorem envBound34133 : H12AffineFastState.Bounded env34133 := by
  intro p hp
  have h : env34133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34132_34133 : H12AffineEnvironment.transform 10 1 env34132 = env34133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env34132 == env34133) = true)

theorem identity34133 : scanCanonicalize (H12AffineFastState.compose env34133 (packedSelected [0,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34133 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env34134 : List Nat := [2,4,8,16,1,16,8,4,512,1024,1,1029,8,1,1,3,16,0,1025,0,1045,0,17,2,8,16,0,16,1028,0,1025,0,5,1,0,513]

theorem envBound34134 : H12AffineFastState.Bounded env34134 := by
  intro p hp
  have h : env34134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34133_34134 : H12AffineEnvironment.transform 6 8 env34133 = env34134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34133 == env34134) = true)

theorem identity34134 : scanCanonicalize (H12AffineFastState.compose env34134 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound34134 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34135 : List Nat := [2,4,8,5,1,5,8,4,512,1024,1,1029,8,1,1,3,5,0,1025,0,1024,0,4,2,8,5,0,5,1028,0,1025,0,5,1,0,513]

theorem envBound34135 : H12AffineFastState.Bounded env34135 := by
  intro p hp
  have h : env34135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34134_34135 : H12AffineEnvironment.transform 3 5 env34134 = env34135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env34134 == env34135) = true)

theorem identity34135 : scanCanonicalize (H12AffineFastState.compose env34135 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound34135 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34136 : List Nat := [2,4,8,5,1,5,8,4,512,4,1,1,8,1,1,3,5,0,5,0,4,0,4,2,8,5,0,5,0,0,5,0,5,1,0,513]

theorem envBound34136 : H12AffineFastState.Bounded env34136 := by
  intro p hp
  have h : env34136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34135_34136 : H12AffineEnvironment.transform 9 4 env34135 = env34136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env34135 == env34136) = true)

theorem identity34136 : scanCanonicalize (H12AffineFastState.compose env34136 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound34136 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34137 : List Nat := [2,4,7,5,1,5,7,4,512,4,1,1,7,1,1,3,5,0,5,0,4,0,4,2,7,5,0,5,0,0,5,0,5,1,0,513]

theorem envBound34137 : H12AffineFastState.Bounded env34137 := by
  intro p hp
  have h : env34137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34136_34137 : H12AffineEnvironment.transform 2 7 env34136 = env34137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env34136 == env34137) = true)

theorem identity34137 : scanCanonicalize (H12AffineFastState.compose env34137 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound34137 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34138 : List Nat := [2,4,7,5,1,5,7,4,0,4,1,1,7,1,1,3,5,0,5,0,4,0,4,2,7,5,0,5,0,0,5,0,5,1,0,1]

theorem envBound34138 : H12AffineFastState.Bounded env34138 := by
  intro p hp
  have h : env34138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34137_34138 : H12AffineEnvironment.transform 8 0 env34137 = env34138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env34137 == env34138) = true)

theorem identity34138 : scanCanonicalize (H12AffineFastState.compose env34138 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34138 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34139 : List Nat := [2,3,0,2,1,2,0,3,0,3,1,1,0,1,1,3,2,0,2,0,3,0,3,2,0,2,0,2,0,0,2,0,2,1,0,1]

theorem envBound34139 : H12AffineFastState.Bounded env34139 := by
  intro p hp
  have h : env34139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34138_34139 : H12AffineEnvironment.transform 1 3 env34138 = env34139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34138 == env34139) = true)

theorem identity34139 : scanCanonicalize (H12AffineFastState.compose env34139 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34139 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env34140 : List Nat := [1,0,0,1,1,1,0,0,0,0,1,1,0,1,1,0,1,0,1,0,0,0,0,1,0,1,0,1,0,0,1,0,1,1,0,1]

theorem envBound34140 : H12AffineFastState.Bounded env34140 := by
  intro p hp
  have h : env34140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34139_34140 : H12AffineEnvironment.transform 0 1 env34139 = env34140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34139 == env34140) = true)

def env34141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10401,1025,32769,4160,120062,73754,41431,8328,64,43476,79130,91402,56572,1501,168,257,21792,46212,74250]

theorem envBound34141 : H12AffineFastState.Bounded env34141 := by
  intro p hp
  have h : env34141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34123_34141 : H12AffineEnvironment.transform 17 10401 env34123 = env34141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env34123 == env34141) = true)

theorem identity34141 : scanCanonicalize (H12AffineFastState.compose env34141 (packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS)) = affineNative (2^(14+1) ^^^ 21977) := by decide +kernel

theorem selectedBound34141 : packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env34142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21977,65536,70726,10401,1025,21976,4160,65831,73754,29710,8328,64,31757,79130,91402,2341,1501,168,257,21792,24925,74250]

theorem envBound34142 : H12AffineFastState.Bounded env34142 := by
  intro p hp
  have h : env34142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34141_34142 : H12AffineEnvironment.transform 14 21977 env34141 = env34142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21977 env34141 == env34142) = true)

theorem identity34142 : scanCanonicalize (H12AffineFastState.compose env34142 (packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound34142 : packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env34143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,16384,21977,65536,70726,2265,1025,21976,4160,65831,65634,21622,240,64,23669,71010,83314,2341,1501,168,257,21792,16677,66162]

theorem envBound34143 : H12AffineFastState.Bounded env34143 := by
  intro p hp
  have h : env34143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34142_34143 : H12AffineEnvironment.transform 12 120 env34142 = env34143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env34142 == env34143) = true)

theorem identity34143 : scanCanonicalize (H12AffineFastState.compose env34143 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound34143 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,16384,21977,115,5173,2265,1025,21976,4160,340,17,21622,240,64,23669,5393,17665,2341,1501,168,257,21792,16677,513]

theorem envBound34144 : H12AffineFastState.Bounded env34144 := by
  intro p hp
  have h : env34144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34143_34144 : H12AffineEnvironment.transform 15 115 env34143 = env34144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env34143 == env34144) = true)

theorem identity34144 : scanCanonicalize (H12AffineFastState.compose env34144 (packedSelected [3,4,5,9,15,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 3173) := by decide +kernel

theorem selectedBound34144 : packedSelected [3,4,5,9,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env34145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,3173,6588,115,5173,2265,1025,6589,4160,340,17,6163,240,64,4112,5393,2404,2341,1501,168,257,6469,3392,513]

theorem envBound34145 : H12AffineFastState.Bounded env34145 := by
  intro p hp
  have h : env34145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34144_34145 : H12AffineEnvironment.transform 13 3173 env34144 = env34145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3173 env34144 == env34145) = true)

theorem identity34145 : scanCanonicalize (H12AffineFastState.compose env34145 (packedSelected [1,2,6,8,10,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound34145 : packedSelected [1,2,6,8,10,15,17] rootPS < 2^1333 := by decide +kernel

def env34146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,309,120,3173,2185,115,1280,2265,1025,2184,373,340,17,2342,240,64,293,1060,2404,2341,1501,168,257,2160,3392,513]

theorem envBound34146 : H12AffineFastState.Bounded env34146 := by
  intro p hp
  have h : env34146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34145_34146 : H12AffineEnvironment.transform 11 309 env34145 = env34146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env34145 == env34146) = true)

theorem identity34146 : scanCanonicalize (H12AffineFastState.compose env34146 (packedSelected [1,8,10,11,12,14,20] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound34146 : packedSelected [1,8,10,11,12,14,20] rootPS < 2^1333 := by decide +kernel

def env34147 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,309,120,2265,2185,115,444,2265,189,2184,373,340,17,2342,240,64,293,152,2404,2341,353,168,257,2160,2556,513]

theorem envBound34147 : H12AffineFastState.Bounded env34147 := by
  intro p hp
  have h : env34147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34146_34147 : H12AffineEnvironment.transform 9 188 env34146 = env34147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env34146 == env34147) = true)

theorem identity34147 : scanCanonicalize (H12AffineFastState.compose env34147 (packedSelected [2,4,6,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound34147 : packedSelected [2,4,6,9,12] rootPS < 2^1333 := by decide +kernel

def env34148 : List Nat := [2,4,8,16,32,64,128,256,512,188,373,309,120,428,508,115,444,428,189,509,373,340,17,83,240,64,293,152,17,80,353,168,257,261,137,513]

theorem envBound34148 : H12AffineFastState.Bounded env34148 := by
  intro p hp
  have h : env34148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34147_34148 : H12AffineEnvironment.transform 10 373 env34147 = env34148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env34147 == env34148) = true)

theorem identity34148 : scanCanonicalize (H12AffineFastState.compose env34148 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34148 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env34149 : List Nat := [2,4,8,16,32,64,8,256,512,52,373,309,120,292,372,115,308,292,53,373,373,340,17,83,120,64,293,16,17,80,353,32,257,261,1,513]

theorem envBound34149 : H12AffineFastState.Bounded env34149 := by
  intro p hp
  have h : env34149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34148_34149 : H12AffineEnvironment.transform 6 8 env34148 = env34149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34148 == env34149) = true)

theorem identity34149 : scanCanonicalize (H12AffineFastState.compose env34149 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34149 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34150 : List Nat := [2,4,8,16,32,64,8,36,512,52,81,17,120,0,80,115,16,0,53,81,81,112,17,83,120,64,1,16,17,80,69,32,37,33,1,513]

theorem envBound34150 : H12AffineFastState.Bounded env34150 := by
  intro p hp
  have h : env34150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34149_34150 : H12AffineEnvironment.transform 7 36 env34149 = env34150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34149 == env34150) = true)

theorem identity34150 : scanCanonicalize (H12AffineFastState.compose env34150 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound34150 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34151 : List Nat := [2,4,8,16,32,64,8,36,17,52,81,17,120,0,80,115,16,0,53,81,81,112,17,83,120,64,1,16,17,80,69,32,37,33,1,16]

theorem envBound34151 : H12AffineFastState.Bounded env34151 := by
  intro p hp
  have h : env34151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34150_34151 : H12AffineEnvironment.transform 8 17 env34150 = env34151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env34150 == env34151) = true)

theorem identity34151 : scanCanonicalize (H12AffineFastState.compose env34151 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound34151 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env34152 : List Nat := [2,4,8,16,10,64,8,14,17,30,81,17,82,0,80,89,16,0,31,81,81,90,17,83,82,64,1,16,17,80,69,10,15,11,1,16]

theorem envBound34152 : H12AffineFastState.Bounded env34152 := by
  intro p hp
  have h : env34152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34151_34152 : H12AffineEnvironment.transform 4 10 env34151 = env34152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env34151 == env34152) = true)

def env34153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,144477,243089,8328,64,43477,139613,160076,324700,1500,272392,257,21792,46212,74251]

theorem envBound34153 : H12AffineFastState.Bounded env34153 := by
  intro p hp
  have h : env34153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34121_34153 : H12AffineEnvironment.transform 20 4161 env34121 = env34153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34121 == env34153) = true)

theorem identity34153 : scanCanonicalize (H12AffineFastState.compose env34153 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound34153 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4161,452633,144477,155982,8328,64,43477,139613,160076,324700,1500,272392,257,21792,46212,63188]

theorem envBound34154 : H12AffineFastState.Bounded env34154 := by
  intro p hp
  have h : env34154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34153_34154 : H12AffineEnvironment.transform 15 54495 env34153 = env34154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env34153 == env34154) = true)

def env34155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146912,1025,32769,4161,54777,144477,155982,8328,64,43477,139613,160076,182716,1500,136680,257,21792,46212,63188]

theorem envBound34155 : H12AffineFastState.Bounded env34155 := by
  intro p hp
  have h : env34155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34154_34155 : H12AffineEnvironment.transform 17 146912 env34154 = env34155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146912 env34154 == env34155) = true)

theorem identity34155 : scanCanonicalize (H12AffineFastState.compose env34155 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57749) := by decide +kernel

theorem selectedBound34155 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env34156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,57749,56437,1025,32769,4161,54777,54728,32987,8328,64,43477,49352,37081,10281,1500,62589,257,21792,46212,63188]

theorem envBound34156 : H12AffineFastState.Bounded env34156 := by
  intro p hp
  have h : env34156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34155_34156 : H12AffineEnvironment.transform 16 57749 env34155 = env34156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57749 env34155 == env34156) = true)

theorem identity34156 : scanCanonicalize (H12AffineFastState.compose env34156 (packedSelected [0,9,11,12,15,18,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound34156 : packedSelected [0,9,11,12,15,18,22,27] rootPS < 2^1333 := by decide +kernel

def env34157 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,54279,57677,56437,1025,32769,4161,54561,54544,32771,8272,64,43277,49168,36865,10281,1284,62589,257,21792,46172,62988]

theorem envBound34157 : H12AffineFastState.Bounded env34157 := by
  intro p hp
  have h : env34157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34156_34157 : H12AffineEnvironment.transform 6 88 env34156 = env34157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env34156 == env34157) = true)

theorem identity34157 : scanCanonicalize (H12AffineFastState.compose env34157 (packedSelected [1,2,4,6,8,11,12,15,16,17,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34157 : packedSelected [1,2,4,6,8,11,12,15,16,17,18,19,22] rootPS < 2^1333 := by decide +kernel

def env34158 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,16384,32768,54279,49216,56437,1025,32769,4161,54561,54544,32771,349,64,34816,49168,36865,2340,1284,54640,257,21792,38225,55041]

theorem envBound34158 : H12AffineFastState.Bounded env34158 := by
  intro p hp
  have h : env34158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34157_34158 : H12AffineEnvironment.transform 12 269 env34157 = env34158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34157 == env34158) = true)

theorem identity34158 : scanCanonicalize (H12AffineFastState.compose env34158 (packedSelected [0,3,4,5,7,9,12,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound34158 : packedSelected [0,3,4,5,7,9,12,16,18,19] rootPS < 2^1333 := by decide +kernel

def env34159 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,16384,21760,263,5440,2421,1025,21761,4161,33,16,21763,349,64,23808,5392,17665,2340,1284,112,257,21792,16465,513]

theorem envBound34159 : H12AffineFastState.Bounded env34159 := by
  intro p hp
  have h : env34159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34158_34159 : H12AffineEnvironment.transform 14 21760 env34158 = env34159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env34158 == env34159) = true)

theorem identity34159 : scanCanonicalize (H12AffineFastState.compose env34159 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound34159 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env34160 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5457,81,263,5440,2421,1025,80,4161,33,16,82,349,64,2129,5392,4176,2340,1284,112,257,113,5376,513]

theorem envBound34160 : H12AffineFastState.Bounded env34160 := by
  intro p hp
  have h : env34160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34159_34160 : H12AffineEnvironment.transform 13 5457 env34159 = env34160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env34159 == env34160) = true)

theorem identity34160 : scanCanonicalize (H12AffineFastState.compose env34160 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34160 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34161 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,41,5237,81,35,5220,2129,1025,80,4161,33,16,82,121,64,2129,5172,4176,2048,1056,112,37,113,5156,513]

theorem envBound34161 : H12AffineFastState.Bounded env34161 := by
  intro p hp
  have h : env34161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34160_34161 : H12AffineEnvironment.transform 7 36 env34160 = env34161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34160 == env34161) = true)

theorem identity34161 : scanCanonicalize (H12AffineFastState.compose env34161 (packedSelected [0,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34161 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env34162 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,0,35,5173,2048,1025,1,4112,33,16,3,40,17,2048,5172,4097,2048,1056,33,37,32,5156,513]

theorem envBound34162 : H12AffineFastState.Bounded env34162 := by
  intro p hp
  have h : env34162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34161_34162 : H12AffineEnvironment.transform 5 17 env34161 = env34162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34161 == env34162) = true)

def env34163 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1044,0,35,1029,2048,1025,1,32,33,16,3,40,17,2048,1028,49,2048,1056,33,37,32,1044,513]

theorem envBound34163 : H12AffineFastState.Bounded env34163 := by
  intro p hp
  have h : env34163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34162_34163 : H12AffineEnvironment.transform 11 48 env34162 = env34163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env34162 == env34163) = true)

theorem identity34163 : scanCanonicalize (H12AffineFastState.compose env34163 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound34163 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34164 : List Nat := [2,4,8,16,32,17,9,36,512,1024,528,48,41,1044,0,35,1029,528,1025,1,32,33,16,3,40,17,528,1028,49,528,1056,33,37,32,1044,513]

theorem envBound34164 : H12AffineFastState.Bounded env34164 := by
  intro p hp
  have h : env34164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34163_34164 : H12AffineEnvironment.transform 10 528 env34163 = env34164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env34163 == env34164) = true)

def env34165 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,48,41,32,0,35,49,528,53,1,32,33,16,3,40,17,528,48,49,528,20,33,37,32,32,513]

theorem envBound34165 : H12AffineFastState.Bounded env34165 := by
  intro p hp
  have h : env34165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34164_34165 : H12AffineEnvironment.transform 9 52 env34164 = env34165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34164 == env34165) = true)

def env34166 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,48,41,33,0,35,48,528,52,1,32,33,16,3,40,17,528,49,49,528,21,33,37,32,33,513]

theorem envBound34166 : H12AffineFastState.Bounded env34166 := by
  intro p hp
  have h : env34166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34164_34166 : H12AffineEnvironment.transform 9 53 env34164 = env34166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34164 == env34166) = true)

theorem identity34166 : scanCanonicalize (H12AffineFastState.compose env34166 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound34166 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34167 : List Nat := [2,4,8,16,32,17,9,36,42,53,58,48,41,33,0,35,48,58,52,1,32,33,16,3,40,17,58,49,49,58,21,33,37,32,33,43]

theorem envBound34167 : H12AffineFastState.Bounded env34167 := by
  intro p hp
  have h : env34167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34166_34167 : H12AffineEnvironment.transform 8 42 env34166 = env34167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env34166 == env34167) = true)

def leafEnv34167 : List Nat := [2,4,8,16,32,17,9,36,42,53,58,48,41,33,0,35,48,58,52,1,32,33,16,3,20,40,1,17,58,49,49,58,21,33,37,32,5,34,33,43,1,32,0]

def active34167 : List Nat := [0,1,2,3,4]

def tree34167 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34167 : H12WitnessSearch.Good tree34167 := H12GlobalWitnessIndex.good

theorem leafIdentity34167 : H12AffineFastState.composeSystem env34167 rootObs = leafEnv34167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34167 rootObs == leafEnv34167) = true)

theorem terminalChecked34167 : H12PackedTerminal.terminalCheckFast leafEnv34167 active34167 tree34167 = true := by decide +kernel

def env34168 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1045,0,35,1028,2048,1025,1,33,33,16,3,40,17,2048,1029,48,2048,1056,33,37,32,1045,513]

theorem envBound34168 : H12AffineFastState.Bounded env34168 := by
  intro p hp
  have h : env34168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34162_34168 : H12AffineEnvironment.transform 11 49 env34162 = env34168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env34162 == env34168) = true)

theorem identity34168 : scanCanonicalize (H12AffineFastState.compose env34168 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound34168 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34169 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1573,49,41,1045,0,35,1028,1573,1025,1,33,33,16,3,40,17,1573,1029,48,1573,1056,33,37,32,1045,513]

theorem envBound34169 : H12AffineFastState.Bounded env34169 := by
  intro p hp
  have h : env34169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34168_34169 : H12AffineEnvironment.transform 10 1573 env34168 = env34169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env34168 == env34169) = true)

def env34170 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,49,41,33,0,35,48,529,53,1,33,33,16,3,40,17,529,49,48,529,20,33,37,32,33,513]

theorem envBound34170 : H12AffineFastState.Bounded env34170 := by
  intro p hp
  have h : env34170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34169_34170 : H12AffineEnvironment.transform 9 52 env34169 = env34170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34169 == env34170) = true)

def env34171 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,49,41,32,0,35,49,528,52,1,33,33,16,3,40,17,528,48,48,528,21,33,37,32,32,513]

theorem envBound34171 : H12AffineFastState.Bounded env34171 := by
  intro p hp
  have h : env34171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34169_34171 : H12AffineEnvironment.transform 9 53 env34169 = env34171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34169 == env34171) = true)

theorem identity34171 : scanCanonicalize (H12AffineFastState.compose env34171 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound34171 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34172 : List Nat := [2,4,8,16,32,17,9,36,43,53,59,49,41,32,0,35,49,59,52,1,33,33,16,3,40,17,59,48,48,59,21,33,37,32,32,42]

theorem envBound34172 : H12AffineFastState.Bounded env34172 := by
  intro p hp
  have h : env34172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34171_34172 : H12AffineEnvironment.transform 8 43 env34171 = env34172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env34171 == env34172) = true)

def leafEnv34172 : List Nat := [2,4,8,16,32,17,9,36,43,53,59,49,41,32,0,35,49,59,52,1,33,33,16,3,20,40,1,17,59,48,48,59,21,33,37,32,5,34,32,42,1,33,0]

def active34172 : List Nat := [0,1,2,3,4]

def tree34172 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34172 : H12WitnessSearch.Good tree34172 := H12GlobalWitnessIndex.good

theorem leafIdentity34172 : H12AffineFastState.composeSystem env34172 rootObs = leafEnv34172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34172 rootObs == leafEnv34172) = true)

theorem terminalChecked34172 : H12PackedTerminal.terminalCheckFast leafEnv34172 active34172 tree34172 = true := by decide +kernel

def env34173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146913,1025,32769,4161,54776,144477,155982,8328,64,43477,139613,160076,182717,1500,136681,257,21792,46212,63188]

theorem envBound34173 : H12AffineFastState.Bounded env34173 := by
  intro p hp
  have h : env34173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34154_34173 : H12AffineEnvironment.transform 17 146913 env34154 = env34173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env34154 == env34173) = true)

theorem identity34173 : scanCanonicalize (H12AffineFastState.compose env34173 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57628) := by decide +kernel

theorem selectedBound34173 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env34174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,57628,56573,1025,32769,4161,54776,54593,32850,8328,64,43477,49217,36944,10401,1500,62709,257,21792,46212,63188]

theorem envBound34174 : H12AffineFastState.Bounded env34174 := by
  intro p hp
  have h : env34174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34173_34174 : H12AffineEnvironment.transform 16 57628 env34173 = env34174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57628 env34173 == env34174) = true)

theorem identity34174 : scanCanonicalize (H12AffineFastState.compose env34174 (packedSelected [0,1,2,4,5,6,7,8,9,10,11,14,17,18,24,31] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound34174 : packedSelected [0,1,2,4,5,6,7,8,9,10,11,14,17,18,24,31] rootPS < 2^1333 := by decide +kernel

def env34175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5292,32768,32883,46512,34897,1025,32769,4161,33108,33261,32850,8328,64,43477,38125,36944,10401,1500,41049,257,396,46212,41592]

theorem envBound34175 : H12AffineFastState.Bounded env34175 := by
  intro p hp
  have h : env34175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34174_34175 : H12AffineEnvironment.transform 13 5292 env34174 = env34175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env34174 == env34175) = true)

theorem identity34175 : scanCanonicalize (H12AffineFastState.compose env34175 (packedSelected [0,1,3,4,8,10,12,14,15,16,17,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound34175 : packedSelected [0,1,3,4,8,10,12,14,15,16,17,22,24,27] rootPS < 2^1333 := by decide +kernel

def env34176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5292,216,171,13672,2185,1025,217,4161,396,309,138,8328,64,10509,5173,4232,10401,1500,8321,257,396,13404,8864]

theorem envBound34176 : H12AffineFastState.Bounded env34176 := by
  intro p hp
  have h : env34176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34175_34176 : H12AffineEnvironment.transform 14 216 env34175 = env34176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env34175 == env34176) = true)

theorem identity34176 : scanCanonicalize (H12AffineFastState.compose env34176 (packedSelected [0,1,2,6,7,8,11,12,15,17,18,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound34176 : packedSelected [0,1,2,6,7,8,11,12,15,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env34177 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5292,216,171,13460,2185,1025,217,4161,112,201,138,8328,64,10481,5173,4232,10401,1056,8321,253,112,13404,8864]

theorem envBound34177 : H12AffineFastState.Bounded env34177 := by
  intro p hp
  have h : env34177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34176_34177 : H12AffineEnvironment.transform 7 252 env34176 = env34177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env34176 == env34177) = true)

theorem identity34177 : scanCanonicalize (H12AffineFastState.compose env34177 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound34177 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env34178 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,240,5292,216,171,5220,2185,1025,217,4161,112,201,138,120,64,2049,5173,4232,2129,1056,113,253,112,5292,592]

theorem envBound34178 : H12AffineFastState.Bounded env34178 := by
  intro p hp
  have h : env34178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34177_34178 : H12AffineEnvironment.transform 12 240 env34177 = env34178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env34177 == env34178) = true)

theorem identity34178 : scanCanonicalize (H12AffineFastState.compose env34178 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound34178 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env34179 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,3109,240,2185,216,171,2113,2185,1025,217,3172,112,201,138,120,64,2049,2064,3245,2129,1056,113,253,112,2185,592]

theorem envBound34179 : H12AffineFastState.Bounded env34179 := by
  intro p hp
  have h : env34179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34178_34179 : H12AffineEnvironment.transform 11 3109 env34178 = env34179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env34178 == env34179) = true)

def env34180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254785,25265169,145662400,525568,140903597,27337993,25733062]

theorem envBound34180 : H12AffineFastState.Bounded env34180 := by
  intro p hp
  have h : env34180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33422_34180 : H12AffineEnvironment.transform 25 65 env33422 = env34180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env33422 == env34180) = true)

def env34181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356289,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound34181 : H12AffineFastState.Bounded env34181 := by
  intro p hp
  have h : env34181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34180_34181 : H12AffineEnvironment.transform 26 30393344 env34180 = env34181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env34180 == env34181) = true)

def env34182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound34182 : H12AffineFastState.Bounded env34182 := by
  intro p hp
  have h : env34182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34181_34182 : H12AffineEnvironment.transform 18 1024 env34181 = env34182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env34181 == env34182) = true)

theorem identity34182 : scanCanonicalize (H12AffineFastState.compose env34182 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8874364) := by decide +kernel

theorem selectedBound34182 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env34183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8874364,8328,65,4237692,10939888,10507601,8830977,453997,15076540,256,2534865,2509941,510650]

theorem envBound34183 : H12AffineFastState.Bounded env34183 := by
  intro p hp
  have h : env34183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34182_34183 : H12AffineEnvironment.transform 23 8874364 env34182 = env34183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8874364 env34182 == env34183) = true)

def env34184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,8388608,8874364,8328,65,4237692,8393984,8826273,8830977,453997,12645452,256,21793,46213,510650]

theorem envBound34184 : H12AffineFastState.Bounded env34184 := by
  intro p hp
  have h : env34184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34183_34184 : H12AffineEnvironment.transform 20 456944 env34183 = env34184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456944 env34183 == env34184) = true)

def env34185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452768,98780,8328,65,4237692,458144,17665,10401,453997,4594924,256,21793,46213,510650]

theorem envBound34185 : H12AffineFastState.Bounded env34185 := by
  intro p hp
  have h : env34185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34184_34185 : H12AffineEnvironment.transform 22 452768 env34184 = env34185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env34184 == env34185) = true)

def env34186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452768,98780,8328,65,295420,458144,17665,10401,453997,144492,256,21793,46213,510650]

theorem envBound34186 : H12AffineFastState.Bounded env34186 := by
  intro p hp
  have h : env34186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34185_34186 : H12AffineEnvironment.transform 21 272512 env34185 = env34186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env34185 == env34186) = true)

theorem identity34186 : scanCanonicalize (H12AffineFastState.compose env34186 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34186 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,456944,272512,452768,41431,8328,65,295420,458144,17665,10401,453997,144492,256,21793,46213,453297]

theorem envBound34187 : H12AffineFastState.Bounded env34187 := by
  intro p hp
  have h : env34187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34186_34187 : H12AffineEnvironment.transform 15 8203 env34186 = env34187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34186 == env34187) = true)

theorem identity34187 : scanCanonicalize (H12AffineFastState.compose env34187 (packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound34187 : packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env34188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8203,131072,262144,1024,0,424177,272512,420001,8662,8328,65,262653,425377,17665,10401,421228,144492,256,21793,13444,420528]

theorem envBound34188 : H12AffineFastState.Bounded env34188 := by
  intro p hp
  have h : env34188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34187_34188 : H12AffineEnvironment.transform 14 1 env34187 = env34188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env34187 == env34188) = true)

theorem identity34188 : scanCanonicalize (H12AffineFastState.compose env34188 (packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound34188 : packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env34189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8203,16400,262144,1024,0,276705,272512,272561,8662,8328,65,262653,277937,17665,10401,273788,29820,256,21793,13444,273056]

theorem envBound34189 : H12AffineFastState.Bounded env34189 := by
  intro p hp
  have h : env34189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34188_34189 : H12AffineEnvironment.transform 16 16400 env34188 = env34189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env34188 == env34189) = true)

theorem identity34189 : scanCanonicalize (H12AffineFastState.compose env34189 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound34189 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env34190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,1,8203,5528,262144,1024,0,276705,272512,272561,8662,8328,65,262653,277937,4233,10401,273788,8692,256,169,13444,273056]

theorem envBound34190 : H12AffineFastState.Bounded env34190 := by
  intro p hp
  have h : env34190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34189_34190 : H12AffineEnvironment.transform 13 5512 env34189 = env34190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env34189 == env34190) = true)

theorem identity34190 : scanCanonicalize (H12AffineFastState.compose env34190 (packedSelected [1,2,3,4,5,6,8,9,12,17,23] rootPS)) = affineNative (2^(11+1) ^^^ 2492) := by decide +kernel

theorem selectedBound34190 : packedSelected [1,2,3,4,5,6,8,9,12,17,23] rootPS < 2^1333 := by decide +kernel

def env34191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2492,8192,3124,1,8203,3108,262144,1024,0,270685,272512,272561,8662,8328,65,262653,271373,2357,10401,273788,8692,256,169,11576,273056]

theorem envBound34191 : H12AffineFastState.Bounded env34191 := by
  intro p hp
  have h : env34191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34190_34191 : H12AffineEnvironment.transform 11 2492 env34190 = env34191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2492 env34190 == env34191) = true)

theorem identity34191 : scanCanonicalize (H12AffineFastState.compose env34191 (packedSelected [0,2,3,5,6,7,11,15,16,17,18,19] rootPS)) = affineNative (2^(17+1) ^^^ 8432) := by decide +kernel

theorem selectedBound34191 : packedSelected [0,2,3,5,6,7,11,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env34192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2492,8192,3124,1,8203,3108,8432,1024,0,429,2160,2113,8662,8328,65,8461,1277,2357,10401,3468,8692,256,169,11576,2640]

theorem envBound34192 : H12AffineFastState.Bounded env34192 := by
  intro p hp
  have h : env34192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34191_34192 : H12AffineEnvironment.transform 17 8432 env34191 = env34192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8432 env34191 == env34192) = true)

theorem identity34192 : scanCanonicalize (H12AffineFastState.compose env34192 (packedSelected [2,7,10,12,17,22] rootPS)) = affineNative (2^(12+1) ^^^ 1156) := by decide +kernel

theorem selectedBound34192 : packedSelected [2,7,10,12,17,22] rootPS < 2^1333 := by decide +kernel

def env34193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2492,1156,3124,1,1167,3108,1140,1024,0,429,2160,2113,1362,1036,65,1417,1277,2357,3109,3468,1392,256,169,2492,2640]

theorem envBound34193 : H12AffineFastState.Bounded env34193 := by
  intro p hp
  have h : env34193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34192_34193 : H12AffineEnvironment.transform 12 1156 env34192 = env34193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1156 env34192 == env34193) = true)

def env34194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272513,452768,98780,8328,65,295421,458144,17665,10401,453997,144493,256,21793,46213,510650]

theorem envBound34194 : H12AffineFastState.Bounded env34194 := by
  intro p hp
  have h : env34194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34185_34194 : H12AffineEnvironment.transform 21 272513 env34185 = env34194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env34185 == env34194) = true)

theorem identity34194 : scanCanonicalize (H12AffineFastState.compose env34194 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247995) := by decide +kernel

theorem selectedBound34194 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,77899,254010,73755,98780,8328,65,215366,79131,17665,10401,75222,144493,256,21793,46213,513]

theorem envBound34195 : H12AffineFastState.Bounded env34195 := by
  intro p hp
  have h : env34195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34194_34195 : H12AffineEnvironment.transform 17 247995 env34194 = env34195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247995 env34194 == env34195) = true)

def env34196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77899,254010,73755,98644,8192,65,215366,79131,17665,10281,75102,144493,256,21793,46093,513]

theorem envBound34196 : H12AffineFastState.Bounded env34196 := by
  intro p hp
  have h : env34196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34195_34196 : H12AffineEnvironment.transform 6 8 env34195 = env34196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34195 == env34196) = true)

theorem identity34196 : scanCanonicalize (H12AffineFastState.compose env34196 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound34196 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env34197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,43049,1024,32769,77899,32800,73755,98644,8192,65,10588,79131,17665,10281,75102,87159,256,21793,46093,513]

theorem envBound34197 : H12AffineFastState.Bounded env34197 := by
  intro p hp
  have h : env34197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34196_34197 : H12AffineEnvironment.transform 16 90138 env34196 = env34197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env34196 == env34197) = true)

theorem identity34197 : scanCanonicalize (H12AffineFastState.compose env34197 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound34197 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env34198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54278,46108,43049,1024,32769,58445,32800,62493,21842,8192,65,10588,57629,17665,10281,61784,32881,256,21793,46093,513]

theorem envBound34198 : H12AffineFastState.Bounded env34198 := by
  intro p hp
  have h : env34198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34197_34198 : H12AffineEnvironment.transform 15 54278 env34197 = env34198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env34197 == env34198) = true)

theorem identity34198 : scanCanonicalize (H12AffineFastState.compose env34198 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound34198 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env34199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,16384,32768,54278,37156,36113,1024,32769,49525,32800,53541,21842,1336,65,3172,50213,17665,3345,54368,32881,256,21793,37173,513]

theorem envBound34199 : H12AffineFastState.Bounded env34199 := by
  intro p hp
  have h : env34199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34198_34199 : H12AffineEnvironment.transform 12 1336 env34198 = env34199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env34198 == env34199) = true)

theorem identity34199 : scanCanonicalize (H12AffineFastState.compose env34199 (packedSelected [2,3,4,5,6,9,10,11,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound34199 : packedSelected [2,3,4,5,6,9,10,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env34200 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,16384,21620,114,17744,22885,1024,21621,5377,21588,1361,21842,1336,65,3172,4177,17665,3345,20,21509,256,21793,17729,513]

theorem envBound34200 : H12AffineFastState.Bounded env34200 := by
  intro p hp
  have h : env34200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34199_34200 : H12AffineEnvironment.transform 14 21620 env34199 = env34200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env34199 == env34200) = true)

theorem identity34200 : scanCanonicalize (H12AffineFastState.compose env34200 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound34200 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,24,28] rootPS < 2^1333 := by decide +kernel

def env34201 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,120,16384,20788,114,16400,22885,320,20789,4161,20756,17,20498,120,65,2340,4177,16449,2129,20,20805,256,20577,16385,513]

theorem envBound34201 : H12AffineFastState.Bounded env34201 := by
  intro p hp
  have h : env34201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34200_34201 : H12AffineEnvironment.transform 9 320 env34200 = env34201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env34200 == env34201) = true)

theorem identity34201 : scanCanonicalize (H12AffineFastState.compose env34201 (packedSelected [5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound34201 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env34202 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,120,4453,81,114,4469,2048,320,80,4161,113,17,375,120,65,2340,4177,4388,2129,20,32,256,260,4452,513]

theorem envBound34202 : H12AffineFastState.Bounded env34202 := by
  intro p hp
  have h : env34202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34201_34202 : H12AffineEnvironment.transform 13 4453 env34201 = env34202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env34201 == env34202) = true)

theorem identity34202 : scanCanonicalize (H12AffineFastState.compose env34202 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34202 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34203 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,40,4405,1,34,4389,2048,272,0,4113,33,17,295,40,17,2340,4097,4388,2049,20,32,256,260,4404,513]

theorem envBound34203 : H12AffineFastState.Bounded env34203 := by
  intro p hp
  have h : env34203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34202_34203 : H12AffineEnvironment.transform 5 16 env34202 = env34203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34202 == env34203) = true)

theorem identity34203 : scanCanonicalize (H12AffineFastState.compose env34203 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34203 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34204 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,40,4113,1,34,4097,2048,52,0,4113,33,17,3,40,17,2048,4097,4096,2049,20,32,36,32,4112,513]

theorem envBound34204 : H12AffineFastState.Bounded env34204 := by
  intro p hp
  have h : env34204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34203_34204 : H12AffineEnvironment.transform 7 36 env34203 = env34204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34203 == env34204) = true)

theorem identity34204 : scanCanonicalize (H12AffineFastState.compose env34204 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34204 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34205 : List Nat := [2,4,8,16,16,16,8,20,512,4,2048,4096,24,4113,1,18,4097,2048,4,0,4113,17,17,3,24,17,2048,4097,4096,2049,20,16,20,16,4112,513]

theorem envBound34205 : H12AffineFastState.Bounded env34205 := by
  intro p hp
  have h : env34205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34204_34205 : H12AffineEnvironment.transform 4 16 env34204 = env34205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34204 == env34205) = true)

theorem identity34205 : scanCanonicalize (H12AffineFastState.compose env34205 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound34205 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34206 : List Nat := [2,4,8,16,16,16,8,20,512,4,528,4096,24,4113,1,18,4097,528,4,0,4113,17,17,3,24,17,528,4097,4096,529,20,16,20,16,4112,513]

theorem envBound34206 : H12AffineFastState.Bounded env34206 := by
  intro p hp
  have h : env34206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34205_34206 : H12AffineEnvironment.transform 10 528 env34205 = env34206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env34205 == env34206) = true)

theorem identity34206 : scanCanonicalize (H12AffineFastState.compose env34206 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound34206 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34207 : List Nat := [2,4,8,16,16,16,8,20,512,4,528,17,24,0,1,18,16,528,4,0,0,17,17,3,24,17,528,16,17,529,20,16,20,16,1,513]

theorem envBound34207 : H12AffineFastState.Bounded env34207 := by
  intro p hp
  have h : env34207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34206_34207 : H12AffineEnvironment.transform 11 17 env34206 = env34207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env34206 == env34207) = true)

theorem identity34207 : scanCanonicalize (H12AffineFastState.compose env34207 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound34207 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34208 : List Nat := [2,4,8,16,16,16,8,20,16,4,0,17,24,0,1,18,16,0,4,0,0,17,17,3,24,17,0,16,17,1,20,16,20,16,1,17]

theorem envBound34208 : H12AffineFastState.Bounded env34208 := by
  intro p hp
  have h : env34208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34207_34208 : H12AffineEnvironment.transform 8 16 env34207 = env34208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env34207 == env34208) = true)

def env34209 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77899,254010,73755,98645,8193,65,215366,79131,17665,10280,75103,144493,256,21793,46092,513]

theorem envBound34209 : H12AffineFastState.Bounded env34209 := by
  intro p hp
  have h : env34209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34195_34209 : H12AffineEnvironment.transform 6 9 env34195 = env34209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34195 == env34209) = true)

theorem identity34209 : scanCanonicalize (H12AffineFastState.compose env34209 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound34209 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env34210 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1024,32769,77899,33,73755,98645,8193,65,43357,79131,17665,10280,75103,119926,256,21793,46092,513]

theorem envBound34210 : H12AffineFastState.Bounded env34210 := by
  intro p hp
  have h : env34210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34209_34210 : H12AffineEnvironment.transform 16 122907 env34209 = env34210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env34209 == env34210) = true)

theorem identity34210 : scanCanonicalize (H12AffineFastState.compose env34210 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34210 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env34211 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,10281,1024,32769,4160,33,16,41310,8193,65,43357,5392,17665,10280,1364,62589,256,21793,46092,513]

theorem envBound34211 : H12AffineFastState.Bounded env34211 := by
  intro p hp
  have h : env34211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34210_34211 : H12AffineEnvironment.transform 15 8203 env34210 = env34211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34210 == env34211) = true)

theorem identity34211 : scanCanonicalize (H12AffineFastState.compose env34211 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34211 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env34212 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,262,49168,2340,1024,32769,4160,33,16,32851,268,65,34896,5392,17665,2341,1364,54640,256,21793,38145,513]

theorem envBound34212 : H12AffineFastState.Bounded env34212 := by
  intro p hp
  have h : env34212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34211_34212 : H12AffineEnvironment.transform 12 269 env34211 = env34212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34211 == env34212) = true)

theorem identity34212 : scanCanonicalize (H12AffineFastState.compose env34212 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound34212 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env34213 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,1,262,16401,2340,1024,0,4160,33,16,82,268,65,2129,5392,17665,2341,1364,21873,256,21793,5376,513]

theorem envBound34213 : H12AffineFastState.Bounded env34213 := by
  intro p hp
  have h : env34213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34212_34213 : H12AffineEnvironment.transform 14 1 env34212 = env34213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env34212 == env34213) = true)

theorem identity34213 : scanCanonicalize (H12AffineFastState.compose env34213 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34213 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env34214 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,262,16401,2340,1024,0,4112,33,16,2,268,17,2049,5392,17665,2341,1284,21793,256,21793,5376,513]

theorem envBound34214 : H12AffineFastState.Bounded env34214 := by
  intro p hp
  have h : env34214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34213_34214 : H12AffineEnvironment.transform 5 16 env34213 = env34214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34213 == env34214) = true)

theorem identity34214 : scanCanonicalize (H12AffineFastState.compose env34214 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound34214 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34215 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,16384,1,262,16401,2340,272,0,4112,33,16,2,268,17,2049,4096,16401,2341,20,20529,256,20529,4112,513]

theorem envBound34215 : H12AffineFastState.Bounded env34215 := by
  intro p hp
  have h : env34215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34214_34215 : H12AffineEnvironment.transform 9 272 env34214 = env34215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env34214 == env34215) = true)

theorem identity34215 : scanCanonicalize (H12AffineFastState.compose env34215 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 33) := by decide +kernel

theorem selectedBound34215 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34216 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,33,1,262,48,2340,272,0,4112,33,16,2,268,17,2049,4096,48,2341,20,4112,256,4112,4112,513]

theorem envBound34216 : H12AffineFastState.Bounded env34216 := by
  intro p hp
  have h : env34216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34215_34216 : H12AffineEnvironment.transform 13 33 env34215 = env34216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 33 env34215 == env34216) = true)

theorem identity34216 : scanCanonicalize (H12AffineFastState.compose env34216 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound34216 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env34217 : List Nat := [2,4,8,16,32,16,9,256,512,272,1,4096,269,33,1,262,48,293,272,0,4112,33,16,2,268,17,0,4096,48,292,20,4112,256,4112,4112,513]

theorem envBound34217 : H12AffineFastState.Bounded env34217 := by
  intro p hp
  have h : env34217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34216_34217 : H12AffineEnvironment.transform 10 1 env34216 = env34217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env34216 == env34217) = true)

theorem identity34217 : scanCanonicalize (H12AffineFastState.compose env34217 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound34217 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34218 : List Nat := [2,4,8,16,32,16,9,53,512,37,1,4096,56,33,1,51,48,16,37,0,4112,33,16,2,57,17,0,4096,48,17,20,4112,53,4112,4112,513]

theorem envBound34218 : H12AffineFastState.Bounded env34218 := by
  intro p hp
  have h : env34218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34217_34218 : H12AffineEnvironment.transform 7 53 env34217 = env34218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env34217 == env34218) = true)

theorem identity34218 : scanCanonicalize (H12AffineFastState.compose env34218 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound34218 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env34219 : List Nat := [2,4,8,16,17,16,9,4,512,20,1,4096,9,16,1,2,1,16,20,0,4112,16,16,2,8,17,0,4096,1,17,20,4112,4,4112,4112,513]

theorem envBound34219 : H12AffineFastState.Bounded env34219 := by
  intro p hp
  have h : env34219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34218_34219 : H12AffineEnvironment.transform 4 17 env34218 = env34219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env34218 == env34219) = true)

theorem identity34219 : scanCanonicalize (H12AffineFastState.compose env34219 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound34219 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env34220 : List Nat := [2,4,8,16,17,16,9,4,16,20,1,4096,9,16,1,2,1,16,20,0,4112,16,16,2,8,17,0,4096,1,17,20,4112,4,4112,4112,17]

theorem envBound34220 : H12AffineFastState.Bounded env34220 := by
  intro p hp
  have h : env34220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34219_34220 : H12AffineEnvironment.transform 8 16 env34219 = env34220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env34219 == env34220) = true)

def env34221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452769,98781,8328,65,4237692,458145,17664,10400,453997,4594925,256,21793,46213,510650]

theorem envBound34221 : H12AffineFastState.Bounded env34221 := by
  intro p hp
  have h : env34221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34184_34221 : H12AffineEnvironment.transform 22 452769 env34184 = env34221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env34184 == env34221) = true)

def env34222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452769,98781,8328,65,295420,458145,17664,10400,453997,144493,256,21793,46213,510650]

theorem envBound34222 : H12AffineFastState.Bounded env34222 := by
  intro p hp
  have h : env34222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34221_34222 : H12AffineEnvironment.transform 21 272512 env34221 = env34222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env34221 == env34222) = true)

theorem identity34222 : scanCanonicalize (H12AffineFastState.compose env34222 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound34222 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,456944,272512,452769,21763,8328,65,295420,458145,17664,10400,453997,144493,256,21793,46213,400996]

theorem envBound34223 : H12AffineFastState.Bounded env34223 := by
  intro p hp
  have h : env34223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34222_34223 : H12AffineEnvironment.transform 15 54494 env34222 = env34223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env34222 == env34223) = true)

def env34224 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,456824,272392,452649,21763,8192,65,295284,458025,17664,10280,453997,144493,256,21793,46093,400996]

theorem envBound34224 : H12AffineFastState.Bounded env34224 := by
  intro p hp
  have h : env34224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34223_34224 : H12AffineEnvironment.transform 6 8 env34223 = env34224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34223 == env34224) = true)

theorem identity34224 : scanCanonicalize (H12AffineFastState.compose env34224 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 24632) := by decide +kernel

theorem selectedBound34224 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env34225 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,24632,262144,1024,32769,301120,272392,296977,21763,8192,65,295284,302353,17664,10280,298325,21589,256,21793,46093,294492]

theorem envBound34225 : H12AffineFastState.Bounded env34225 := by
  intro p hp
  have h : env34225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34224_34225 : H12AffineEnvironment.transform 16 24632 env34224 = env34225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24632 env34224 == env34225) = true)

theorem identity34225 : scanCanonicalize (H12AffineFastState.compose env34225 (packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound34225 : packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS < 2^1333 := by decide +kernel

def env34226 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40971,5221,262144,1024,32769,301120,272392,296977,8542,8192,65,295284,302353,12637,10280,298325,8200,256,8572,46093,264705]

theorem envBound34226 : H12AffineFastState.Bounded env34226 := by
  intro p hp
  have h : env34226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34225_34226 : H12AffineEnvironment.transform 13 13405 env34225 = env34226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env34225 == env34226) = true)

theorem identity34226 : scanCanonicalize (H12AffineFastState.compose env34226 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound34226 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env34227 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40971,5221,2048,1024,32769,36928,8200,32785,8542,8192,65,35188,38161,12637,10280,34133,8200,256,8572,46093,513]

theorem envBound34227 : H12AffineFastState.Bounded env34227 := by
  intro p hp
  have h : env34227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34226_34227 : H12AffineEnvironment.transform 17 2048 env34226 = env34227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env34226 == env34227) = true)

theorem identity34227 : scanCanonicalize (H12AffineFastState.compose env34227 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34227 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34228 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,32768,40971,5173,2048,1024,32769,36880,8200,32785,8462,8192,17,35108,38161,12557,10280,34053,8200,256,8492,46093,513]

theorem envBound34228 : H12AffineFastState.Bounded env34228 := by
  intro p hp
  have h : env34228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34227_34228 : H12AffineEnvironment.transform 5 16 env34227 = env34228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34227 == env34228) = true)

theorem identity34228 : scanCanonicalize (H12AffineFastState.compose env34228 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound34228 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34229 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,293,8494,5173,2048,1024,292,4405,8200,308,8462,8192,17,2049,5172,12557,10280,1056,8200,256,8492,13608,513]

theorem envBound34229 : H12AffineFastState.Bounded env34229 := by
  intro p hp
  have h : env34229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34228_34229 : H12AffineEnvironment.transform 14 293 env34228 = env34229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env34228 == env34229) = true)

theorem identity34229 : scanCanonicalize (H12AffineFastState.compose env34229 (packedSelected [0,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound34229 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env34230 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,8192,12572,293,8494,4388,2048,273,292,4405,8200,308,8462,8192,17,2049,4389,12557,10280,305,8200,256,8492,12345,513]

theorem envBound34230 : H12AffineFastState.Bounded env34230 := by
  intro p hp
  have h : env34230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34229_34230 : H12AffineEnvironment.transform 9 273 env34229 = env34230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env34229 == env34230) = true)

theorem identity34230 : scanCanonicalize (H12AffineFastState.compose env34230 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound34230 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env34231 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,40,4404,293,262,4388,2048,273,292,4405,32,308,294,40,17,2049,4389,4389,2048,305,32,256,260,4113,513]

theorem envBound34231 : H12AffineFastState.Bounded env34231 := by
  intro p hp
  have h : env34231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34230_34231 : H12AffineEnvironment.transform 12 40 env34230 = env34231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env34230 == env34231) = true)

theorem identity34231 : scanCanonicalize (H12AffineFastState.compose env34231 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound34231 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env34232 : List Nat := [2,4,8,16,32,16,8,5,512,20,2048,4096,40,4145,32,3,4129,2048,20,33,4144,32,49,35,40,17,2049,4128,4128,2048,52,32,5,1,4113,513]

theorem envBound34232 : H12AffineFastState.Bounded env34232 := by
  intro p hp
  have h : env34232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34231_34232 : H12AffineEnvironment.transform 7 5 env34231 = env34232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34231 == env34232) = true)

theorem identity34232 : scanCanonicalize (H12AffineFastState.compose env34232 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34232 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env34233 : List Nat := [2,4,8,16,0,16,8,5,512,20,2048,4096,8,4113,0,3,4097,2048,20,1,4112,0,17,3,8,17,2049,4096,4096,2048,20,0,5,1,4113,513]

theorem envBound34233 : H12AffineFastState.Bounded env34233 := by
  intro p hp
  have h : env34233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34232_34233 : H12AffineEnvironment.transform 4 0 env34232 = env34233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34232 == env34233) = true)

theorem identity34233 : scanCanonicalize (H12AffineFastState.compose env34233 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2580) := by decide +kernel

theorem selectedBound34233 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34234 : List Nat := [2,4,8,16,0,16,8,5,512,20,2048,2580,8,2565,0,3,2581,2048,20,1,2564,0,17,3,8,17,2049,2580,2580,2048,20,0,5,1,2565,513]

theorem envBound34234 : H12AffineFastState.Bounded env34234 := by
  intro p hp
  have h : env34234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34233_34234 : H12AffineEnvironment.transform 11 2580 env34233 = env34234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2580 env34233 == env34234) = true)

theorem identity34234 : scanCanonicalize (H12AffineFastState.compose env34234 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound34234 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34235 : List Nat := [2,4,0,16,0,16,0,5,512,20,2048,2580,0,2565,0,3,2581,2048,20,1,2564,0,17,3,0,17,2049,2580,2580,2048,20,0,5,1,2565,513]

theorem envBound34235 : H12AffineFastState.Bounded env34235 := by
  intro p hp
  have h : env34235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34234_34235 : H12AffineEnvironment.transform 2 0 env34234 = env34235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env34234 == env34235) = true)

theorem identity34235 : scanCanonicalize (H12AffineFastState.compose env34235 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 517) := by decide +kernel

theorem selectedBound34235 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34236 : List Nat := [2,4,0,16,0,16,0,5,512,20,517,17,0,0,0,3,16,517,20,1,1,0,17,3,0,17,516,17,17,517,20,0,5,1,0,513]

theorem envBound34236 : H12AffineFastState.Bounded env34236 := by
  intro p hp
  have h : env34236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34235_34236 : H12AffineEnvironment.transform 10 517 env34235 = env34236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 517 env34235 == env34236) = true)

theorem identity34236 : scanCanonicalize (H12AffineFastState.compose env34236 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34236 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34237 : List Nat := [2,3,0,16,0,16,0,2,512,19,514,17,0,0,0,3,16,514,19,1,1,0,17,3,0,17,515,17,17,514,19,0,2,1,0,513]

theorem envBound34237 : H12AffineFastState.Bounded env34237 := by
  intro p hp
  have h : env34237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34236_34237 : H12AffineEnvironment.transform 1 3 env34236 = env34237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34236 == env34237) = true)

def env34238 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,456825,272393,452648,21763,8193,65,295285,458024,17664,10281,453997,144493,256,21793,46092,400996]

theorem envBound34238 : H12AffineFastState.Bounded env34238 := by
  intro p hp
  have h : env34238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34223_34238 : H12AffineEnvironment.transform 6 9 env34223 = env34238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34223 == env34238) = true)

theorem identity34238 : scanCanonicalize (H12AffineFastState.compose env34238 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound34238 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env34239 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,35188,1024,32769,160013,41341,155996,21763,8193,65,2049,160860,17664,10281,156697,144493,256,21793,46092,169744]

theorem envBound34239 : H12AffineFastState.Bounded env34239 := by
  intro p hp
  have h : env34239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34238_34239 : H12AffineEnvironment.transform 17 35188 env34238 = env34239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env34238 == env34239) = true)

theorem identity34239 : scanCanonicalize (H12AffineFastState.compose env34239 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound34239 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env34240 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,35188,1024,32769,58396,41341,62541,21763,8193,65,2049,57677,17664,10281,61704,41340,256,21793,46092,513]

theorem envBound34240 : H12AffineFastState.Bounded env34240 := by
  intro p hp
  have h : env34240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34239_34240 : H12AffineEnvironment.transform 16 38161 env34239 = env34240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env34239 == env34240) = true)

theorem identity34240 : scanCanonicalize (H12AffineFastState.compose env34240 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound34240 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34241 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,24909,32040,1024,29789,4160,21793,17,21763,8193,65,2049,5393,17664,10281,1364,21792,256,21793,16464,513]

theorem envBound34241 : H12AffineFastState.Bounded env34241 := by
  intro p hp
  have h : env34241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34240_34241 : H12AffineEnvironment.transform 14 29788 env34240 = env34241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env34240 == env34241) = true)

theorem identity34241 : scanCanonicalize (H12AffineFastState.compose env34241 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound34241 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34242 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,81,8203,5440,2341,1024,80,4160,8492,17,8462,8193,65,2049,5393,12557,10281,1364,8493,256,8492,13405,513]

theorem envBound34242 : H12AffineFastState.Bounded env34242 := by
  intro p hp
  have h : env34242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34241_34242 : H12AffineEnvironment.transform 13 13325 env34241 = env34242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env34241 == env34242) = true)

theorem identity34242 : scanCanonicalize (H12AffineFastState.compose env34242 (packedSelected [1,3,5,6,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound34242 : packedSelected [1,3,5,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env34243 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,8192,11341,81,8203,3328,2341,1024,80,2048,8492,17,8462,8193,65,2049,3409,10573,10281,1364,8493,256,8492,11293,513]

theorem envBound34243 : H12AffineFastState.Bounded env34243 := by
  intro p hp
  have h : env34243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34242_34243 : H12AffineEnvironment.transform 11 2112 env34242 = env34243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env34242 == env34243) = true)

theorem identity34243 : scanCanonicalize (H12AffineFastState.compose env34243 (packedSelected [4,6,7,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34243 : packedSelected [4,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env34244 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,269,3392,81,262,3328,2341,1024,80,2048,33,17,3,268,65,2049,3409,2112,2340,1364,32,256,33,3344,513]

theorem envBound34244 : H12AffineFastState.Bounded env34244 := by
  intro p hp
  have h : env34244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34243_34244 : H12AffineEnvironment.transform 12 269 env34243 = env34244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34243 == env34244) = true)

theorem identity34244 : scanCanonicalize (H12AffineFastState.compose env34244 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound34244 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34245 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1077,1141,269,373,81,262,309,1296,1024,80,1077,33,17,3,268,65,1076,356,1141,1297,1364,32,256,33,293,513]

theorem envBound34245 : H12AffineFastState.Bounded env34245 := by
  intro p hp
  have h : env34245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34244_34245 : H12AffineEnvironment.transform 10 1077 env34244 = env34245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env34244 == env34245) = true)

theorem identity34245 : scanCanonicalize (H12AffineFastState.compose env34245 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34245 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34246 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,1060,269,292,0,262,309,1296,1024,1,1077,33,17,3,268,16,1076,309,1060,1297,1285,32,256,33,293,513]

theorem envBound34246 : H12AffineFastState.Bounded env34246 := by
  intro p hp
  have h : env34246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34245_34246 : H12AffineEnvironment.transform 5 17 env34245 = env34246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34245 == env34246) = true)

theorem identity34246 : scanCanonicalize (H12AffineFastState.compose env34246 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34246 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34247 : List Nat := [2,4,8,0,32,1,9,256,512,1024,1061,1060,269,292,0,262,293,1280,1024,1,1061,33,1,3,268,0,1060,293,1060,1281,1285,32,256,33,293,513]

theorem envBound34247 : H12AffineFastState.Bounded env34247 := by
  intro p hp
  have h : env34247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34246_34247 : H12AffineEnvironment.transform 3 0 env34246 = env34247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34246 == env34247) = true)

theorem identity34247 : scanCanonicalize (H12AffineFastState.compose env34247 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound34247 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34248 : List Nat := [2,4,8,0,32,1,9,256,0,1024,1061,1060,269,292,0,262,293,1280,1024,1,1061,33,1,3,268,0,1060,293,1060,1281,1285,32,256,33,293,1]

theorem envBound34248 : H12AffineFastState.Bounded env34248 := by
  intro p hp
  have h : env34248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34247_34248 : H12AffineEnvironment.transform 8 0 env34247 = env34248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env34247 == env34248) = true)

theorem identity34248 : scanCanonicalize (H12AffineFastState.compose env34248 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound34248 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34249 : List Nat := [2,4,8,0,32,1,9,256,0,36,1,0,269,292,0,262,293,292,36,1,1,33,1,3,268,0,0,293,0,293,289,32,256,33,293,1]

theorem envBound34249 : H12AffineFastState.Bounded env34249 := by
  intro p hp
  have h : env34249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34248_34249 : H12AffineEnvironment.transform 9 36 env34248 = env34249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env34248 == env34249) = true)

theorem identity34249 : scanCanonicalize (H12AffineFastState.compose env34249 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34249 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env34250 : List Nat := [2,4,8,0,32,1,9,37,0,36,1,0,40,1,0,35,0,1,36,1,1,33,1,3,41,0,0,0,0,0,4,32,37,33,0,1]

theorem envBound34250 : H12AffineFastState.Bounded env34250 := by
  intro p hp
  have h : env34250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34249_34250 : H12AffineEnvironment.transform 7 37 env34249 = env34250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34249 == env34250) = true)

theorem identity34250 : scanCanonicalize (H12AffineFastState.compose env34250 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34250 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34251 : List Nat := [2,4,3,0,32,1,2,37,0,36,1,0,35,1,0,35,0,1,36,1,1,33,1,3,34,0,0,0,0,0,4,32,37,33,0,1]

theorem envBound34251 : H12AffineFastState.Bounded env34251 := by
  intro p hp
  have h : env34251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34250_34251 : H12AffineEnvironment.transform 2 3 env34250 = env34251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34250 == env34251) = true)

def env34252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272513,452769,98781,8328,65,295421,458145,17664,10400,453997,144492,256,21793,46213,510650]

theorem envBound34252 : H12AffineFastState.Bounded env34252 := by
  intro p hp
  have h : env34252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34221_34252 : H12AffineEnvironment.transform 21 272513 env34221 = env34252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env34221 == env34252) = true)

theorem identity34252 : scanCanonicalize (H12AffineFastState.compose env34252 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound34252 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,115871,201966,120014,98781,8328,65,245138,115150,17664,10400,119042,144492,256,21793,46213,63189]

theorem envBound34253 : H12AffineFastState.Bounded env34253 := by
  intro p hp
  have h : env34253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34252_34253 : H12AffineEnvironment.transform 17 212079 env34252 = env34253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env34252 == env34253) = true)

def env34254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130175,1024,32769,115871,120062,120014,98781,8328,65,97666,115150,17664,10400,119042,62588,256,21793,46213,63189]

theorem envBound34254 : H12AffineFastState.Bounded env34254 := by
  intro p hp
  have h : env34254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34253_34254 : H12AffineEnvironment.transform 16 49168 env34253 = env34254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env34253 == env34254) = true)

theorem identity34254 : scanCanonicalize (H12AffineFastState.compose env34254 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound34254 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env34255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,49168,32040,1024,32769,17864,21929,21913,138,8328,65,64725,16537,17664,10400,20565,62588,256,21793,46213,63189]

theorem envBound34255 : H12AffineFastState.Bounded env34255 := by
  intro p hp
  have h : env34255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34254_34255 : H12AffineEnvironment.transform 15 33111 env34254 = env34255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env34254 == env34255) = true)

theorem identity34255 : scanCanonicalize (H12AffineFastState.compose env34255 (packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound34255 : packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS < 2^1333 := by decide +kernel

def env34256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,342,16401,32040,1024,0,17864,21929,21913,138,8328,65,31956,16537,17664,10400,20565,29821,256,21793,13444,30420]

theorem envBound34256 : H12AffineFastState.Bounded env34256 := by
  intro p hp
  have h : env34256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34255_34256 : H12AffineEnvironment.transform 14 1 env34255 = env34256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env34255 == env34256) = true)

theorem identity34256 : scanCanonicalize (H12AffineFastState.compose env34256 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound34256 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env34257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,1,342,13509,2556,1024,0,12572,8573,8525,138,8328,65,2048,13389,12756,10400,9345,169,256,8693,13444,512]

theorem envBound34257 : H12AffineFastState.Bounded env34257 := by
  intro p hp
  have h : env34257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34256_34257 : H12AffineEnvironment.transform 13 13524 env34256 = env34257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env34256 == env34257) = true)

theorem identity34257 : scanCanonicalize (H12AffineFastState.compose env34257 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34257 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34258 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,13524,1,342,13509,2525,1024,0,12572,8540,8525,138,8328,65,2048,13389,12756,10369,9345,136,256,8660,13444,512]

theorem envBound34258 : H12AffineFastState.Bounded env34258 := by
  intro p hp
  have h : env34258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1