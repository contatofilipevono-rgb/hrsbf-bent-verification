import H12CloudChart1Data185

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity47127 : scanCanonicalize (H12AffineFastState.compose env47127 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47127 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47128 : List Nat := [1,4,8,16,0,16,8,4,29,1,21,16,9,21,0,1,4,21,1,1,1,1,16,1,9,17,21,5,16,21,0,1,4,0,20,28]

theorem envBound47128 : H12AffineFastState.Bounded env47128 := by
  intro p hp
  have h : env47128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47127_47128 : H12AffineEnvironment.transform 0 1 env47127 = env47128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47127 == env47128) = true)

def leafEnv47128 : List Nat := [1,4,8,16,0,16,8,4,29,1,21,16,9,21,0,1,4,21,1,1,1,1,16,1,1,9,1,17,21,5,16,21,0,1,4,0,5,1,20,28,1,0,0]

def active47128 : List Nat := [1,2,3]

def tree47128 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47128 : H12WitnessSearch.Good tree47128 := H12GlobalWitnessIndex.good

theorem leafIdentity47128 : H12AffineFastState.composeSystem env47128 rootObs = leafEnv47128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47128 rootObs == leafEnv47128) = true)

theorem terminalChecked47128 : H12PackedTerminal.terminalCheckFast leafEnv47128 active47128 tree47128 = true := by decide +kernel

def env47129 : List Nat := [2,4,8,16,0,16,8,4,512,1024,523,17,9,1045,0,2,1028,523,1024,1,0,1,16,2,9,17,523,1029,17,523,1025,1,4,0,1044,513]

theorem envBound47129 : H12AffineFastState.Bounded env47129 := by
  intro p hp
  have h : env47129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47122_47129 : H12AffineEnvironment.transform 11 17 env47122 = env47129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env47122 == env47129) = true)

theorem identity47129 : scanCanonicalize (H12AffineFastState.compose env47129 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 523) := by decide +kernel

theorem selectedBound47129 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47130 : List Nat := [2,4,8,16,0,16,8,4,512,523,523,17,9,542,0,2,527,523,523,1,0,1,16,2,9,17,523,526,17,523,522,1,4,0,543,513]

theorem envBound47130 : H12AffineFastState.Bounded env47130 := by
  intro p hp
  have h : env47130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47129_47130 : H12AffineEnvironment.transform 9 523 env47129 = env47130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 523 env47129 == env47130) = true)

def env47131 : List Nat := [2,4,8,4,0,4,8,4,512,523,523,5,9,522,0,2,527,523,523,1,0,1,4,2,9,5,523,526,5,523,522,1,4,0,523,513]

theorem envBound47131 : H12AffineFastState.Bounded env47131 := by
  intro p hp
  have h : env47131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47130_47131 : H12AffineEnvironment.transform 3 4 env47130 = env47131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env47130 == env47131) = true)

theorem identity47131 : scanCanonicalize (H12AffineFastState.compose env47131 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47131 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47132 : List Nat := [1,4,8,4,0,4,8,4,512,520,520,5,9,521,0,1,524,520,520,1,0,1,4,1,9,5,520,525,5,520,521,1,4,0,520,513]

theorem envBound47132 : H12AffineFastState.Bounded env47132 := by
  intro p hp
  have h : env47132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47131_47132 : H12AffineEnvironment.transform 0 1 env47131 = env47132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47131 == env47132) = true)

def leafEnv47132 : List Nat := [1,4,8,4,0,4,8,4,512,520,520,5,9,521,0,1,524,520,520,1,0,1,4,1,520,9,1,5,520,525,5,520,521,1,4,0,5,1,520,513,1,1,0]

def active47132 : List Nat := [1,2,8]

def tree47132 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47132 : H12WitnessSearch.Good tree47132 := H12GlobalWitnessIndex.good

theorem leafIdentity47132 : H12AffineFastState.composeSystem env47132 rootObs = leafEnv47132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47132 rootObs == leafEnv47132) = true)

theorem terminalChecked47132 : H12PackedTerminal.terminalCheckFast leafEnv47132 active47132 tree47132 = true := by decide +kernel

def env47133 : List Nat := [2,4,8,5,0,5,8,4,512,523,523,4,9,523,0,2,527,523,523,1,0,1,5,2,9,4,523,526,4,523,522,1,4,0,522,513]

theorem envBound47133 : H12AffineFastState.Bounded env47133 := by
  intro p hp
  have h : env47133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47130_47133 : H12AffineEnvironment.transform 3 5 env47130 = env47133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env47130 == env47133) = true)

theorem identity47133 : scanCanonicalize (H12AffineFastState.compose env47133 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound47133 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47134 : List Nat := [2,4,8,5,0,5,8,4,9,2,2,4,9,2,0,2,6,2,2,1,0,1,5,2,9,4,2,7,4,2,3,1,4,0,3,8]

theorem envBound47134 : H12AffineFastState.Bounded env47134 := by
  intro p hp
  have h : env47134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47133_47134 : H12AffineEnvironment.transform 8 9 env47133 = env47134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env47133 == env47134) = true)

def leafEnv47134 : List Nat := [2,4,8,5,0,5,8,4,9,2,2,4,9,2,0,2,6,2,2,1,0,1,5,2,2,9,1,4,2,7,4,2,3,1,4,0,5,2,3,8,1,1,0]

def active47134 : List Nat := [0,1,2]

def tree47134 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47134 : H12WitnessSearch.Good tree47134 := H12GlobalWitnessIndex.good

theorem leafIdentity47134 : H12AffineFastState.composeSystem env47134 rootObs = leafEnv47134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47134 rootObs == leafEnv47134) = true)

theorem terminalChecked47134 : H12PackedTerminal.terminalCheckFast leafEnv47134 active47134 tree47134 = true := by decide +kernel

def env47135 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,138340,1024,32769,4161,4194304,16,21762,8193,65,4218145,5392,17664,56437,1364,4256861,256,21792,46093,63069]

theorem envBound47135 : H12AffineFastState.Bounded env47135 := by
  intro p hp
  have h : env47135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47112_47135 : H12AffineEnvironment.transform 6 9 env47112 = env47135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47112 == env47135) = true)

theorem identity47135 : scanCanonicalize (H12AffineFastState.compose env47135 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound47135 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47136 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,35188,1024,32769,4161,4194304,16,21762,8193,65,4218145,5392,17664,56437,1364,4256861,256,21792,46093,63069]

theorem envBound47136 : H12AffineFastState.Bounded env47136 := by
  intro p hp
  have h : env47136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47135_47136 : H12AffineEnvironment.transform 16 38160 env47135 = env47136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env47135 == env47136) = true)

theorem identity47136 : scanCanonicalize (H12AffineFastState.compose env47136 (packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS)) = affineNative (2^(21+1) ^^^ 62588) := by decide +kernel

theorem selectedBound47136 : packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env47137 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,35188,1024,32769,4161,62588,16,21762,8193,65,43357,5392,17664,56437,1364,33,256,21792,46093,63069]

theorem envBound47137 : H12AffineFastState.Bounded env47137 := by
  intro p hp
  have h : env47137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47136_47137 : H12AffineEnvironment.transform 21 62588 env47136 = env47137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62588 env47136 == env47137) = true)

theorem identity47137 : scanCanonicalize (H12AffineFastState.compose env47137 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound47137 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env47138 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,342,16401,23669,1024,21760,4161,8573,16,21762,8193,65,31836,5392,17664,2420,1364,33,256,21792,24844,9052]

theorem envBound47138 : H12AffineFastState.Bounded env47138 := by
  intro p hp
  have h : env47138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47137_47138 : H12AffineEnvironment.transform 14 21761 env47137 = env47138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env47137 == env47138) = true)

theorem identity47138 : scanCanonicalize (H12AffineFastState.compose env47138 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound47138 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env47139 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,342,5393,2421,1024,0,4161,8573,16,2,8193,65,10588,5392,4096,2420,1364,33,256,32,13324,9052]

theorem envBound47139 : H12AffineFastState.Bounded env47139 := by
  intro p hp
  have h : env47139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47138_47139 : H12AffineEnvironment.transform 13 5376 env47138 = env47139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47138 == env47139) = true)

theorem identity47139 : scanCanonicalize (H12AffineFastState.compose env47139 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound47139 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env47140 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,8192,5376,1,294,5393,2309,1024,0,4145,8461,16,2,8193,49,10540,5392,4096,2308,1316,33,256,32,13324,9004]

theorem envBound47140 : H12AffineFastState.Bounded env47140 := by
  intro p hp
  have h : env47140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47139_47140 : H12AffineEnvironment.transform 5 48 env47139 = env47140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env47139 == env47140) = true)

theorem identity47140 : scanCanonicalize (H12AffineFastState.compose env47140 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound47140 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47141 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,269,5376,1,294,5393,2309,1024,0,4145,0,16,2,268,49,2081,5392,4096,2308,1316,33,256,32,5377,545]

theorem envBound47141 : H12AffineFastState.Bounded env47141 := by
  intro p hp
  have h : env47141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47140_47141 : H12AffineEnvironment.transform 12 269 env47140 = env47141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env47140 == env47141) = true)

theorem identity47141 : scanCanonicalize (H12AffineFastState.compose env47141 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 299) := by decide +kernel

theorem selectedBound47141 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env47142 : List Nat := [2,4,8,16,32,48,9,256,512,299,2048,4096,269,4139,1,294,4154,2309,299,0,4145,0,16,2,268,49,2081,4155,4096,2308,15,33,256,32,4138,545]

theorem envBound47142 : H12AffineFastState.Bounded env47142 := by
  intro p hp
  have h : env47142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47141_47142 : H12AffineEnvironment.transform 9 299 env47141 = env47142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 299 env47141 == env47142) = true)

theorem identity47142 : scanCanonicalize (H12AffineFastState.compose env47142 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47142 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env47143 : List Nat := [2,4,8,16,0,16,9,256,512,267,2048,4096,269,4107,1,262,4122,2309,267,0,4113,0,16,2,268,17,2049,4123,4096,2308,15,1,256,0,4106,513]

theorem envBound47143 : H12AffineFastState.Bounded env47143 := by
  intro p hp
  have h : env47143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47142_47143 : H12AffineEnvironment.transform 4 0 env47142 = env47143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47142 == env47143) = true)

theorem identity47143 : scanCanonicalize (H12AffineFastState.compose env47143 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47143 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47144 : List Nat := [2,4,8,10,0,10,9,256,512,267,2048,4096,269,4107,1,262,4096,2309,267,0,4107,0,10,2,268,11,2049,4097,4096,2308,15,1,256,0,4106,513]

theorem envBound47144 : H12AffineFastState.Bounded env47144 := by
  intro p hp
  have h : env47144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47143_47144 : H12AffineEnvironment.transform 3 10 env47143 = env47144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47143 == env47144) = true)

theorem identity47144 : scanCanonicalize (H12AffineFastState.compose env47144 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound47144 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47145 : List Nat := [2,4,8,10,0,10,9,256,512,267,782,4096,269,4107,1,262,4096,523,267,0,4107,0,10,2,268,11,783,4097,4096,522,15,1,256,0,4106,513]

theorem envBound47145 : H12AffineFastState.Bounded env47145 := by
  intro p hp
  have h : env47145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47144_47145 : H12AffineEnvironment.transform 10 782 env47144 = env47145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env47144 == env47145) = true)

theorem identity47145 : scanCanonicalize (H12AffineFastState.compose env47145 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound47145 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47146 : List Nat := [2,4,8,10,0,10,9,256,13,267,259,4096,269,4107,1,262,4096,6,267,0,4107,0,10,2,268,11,258,4097,4096,7,15,1,256,0,4106,12]

theorem envBound47146 : H12AffineFastState.Bounded env47146 := by
  intro p hp
  have h : env47146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47145_47146 : H12AffineEnvironment.transform 8 13 env47145 = env47146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env47145 == env47146) = true)

theorem identity47146 : scanCanonicalize (H12AffineFastState.compose env47146 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47146 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47147 : List Nat := [2,4,2,0,0,0,3,256,7,257,259,4096,263,4097,1,262,4096,6,257,0,4097,0,0,2,262,1,258,4097,4096,7,5,1,256,0,4096,6]

theorem envBound47147 : H12AffineFastState.Bounded env47147 := by
  intro p hp
  have h : env47147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47146_47147 : H12AffineEnvironment.transform 2 2 env47146 = env47147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47146 == env47147) = true)

theorem identity47147 : scanCanonicalize (H12AffineFastState.compose env47147 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 4) := by decide +kernel

theorem selectedBound47147 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47148 : List Nat := [2,4,2,0,0,0,3,256,7,257,259,4,263,5,1,262,4,6,257,0,5,0,0,2,262,1,258,5,4,7,5,1,256,0,4,6]

theorem envBound47148 : H12AffineFastState.Bounded env47148 := by
  intro p hp
  have h : env47148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47147_47148 : H12AffineEnvironment.transform 11 4 env47147 = env47148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 4 env47147 == env47148) = true)

theorem identity47148 : scanCanonicalize (H12AffineFastState.compose env47148 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47148 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47149 : List Nat := [2,4,2,0,0,0,3,5,7,4,6,4,2,5,1,3,4,6,4,0,5,0,0,2,3,1,7,5,4,7,5,1,5,0,4,6]

theorem envBound47149 : H12AffineFastState.Bounded env47149 := by
  intro p hp
  have h : env47149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47148_47149 : H12AffineEnvironment.transform 7 5 env47148 = env47149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47148 == env47149) = true)

theorem identity47149 : scanCanonicalize (H12AffineFastState.compose env47149 (packedSelected [11] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47149 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env47150 : List Nat := [1,4,1,0,0,0,0,5,4,4,5,4,1,5,1,0,4,5,4,0,5,0,0,1,0,1,4,5,4,4,5,1,5,0,4,5]

theorem envBound47150 : H12AffineFastState.Bounded env47150 := by
  intro p hp
  have h : env47150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47149_47150 : H12AffineEnvironment.transform 0 1 env47149 = env47150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47149 == env47150) = true)

def env47151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,4194304,17,98780,8328,65,4295166,5392,17665,67619,1500,4256861,256,21793,46213,74251]

theorem envBound47151 : H12AffineFastState.Bounded env47151 := by
  intro p hp
  have h : env47151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47110_47151 : H12AffineEnvironment.transform 22 17 env47110 = env47151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env47110 == env47151) = true)

theorem identity47151 : scanCanonicalize (H12AffineFastState.compose env47151 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201831) := by decide +kernel

theorem selectedBound47151 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,201831,17,98780,8328,65,171417,5392,17665,67619,1500,254010,256,21793,46213,74251]

theorem envBound47152 : H12AffineFastState.Bounded env47152 := by
  intro p hp
  have h : env47152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47151_47152 : H12AffineEnvironment.transform 21 201831 env47151 = env47152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201831 env47151 == env47152) = true)

def env47153 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,201831,17,98644,8192,65,171281,5392,17665,67619,1364,254010,256,21793,46093,74251]

theorem envBound47153 : H12AffineFastState.Bounded env47153 := by
  intro p hp
  have h : env47153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47152_47153 : H12AffineEnvironment.transform 6 8 env47152 = env47153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47152 == env47153) = true)

theorem identity47153 : scanCanonicalize (H12AffineFastState.compose env47153 (packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound47153 : packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env47154 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,179513,1024,32769,4161,156013,17,62558,8192,65,171281,5392,17665,32041,1364,169264,256,21793,46093,22273]

theorem envBound47154 : H12AffineFastState.Bounded env47154 := by
  intro p hp
  have h : env47154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47153_47154 : H12AffineEnvironment.transform 15 29962 env47153 = env47154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env47153 == env47154) = true)

theorem identity47154 : scanCanonicalize (H12AffineFastState.compose env47154 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound47154 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env47155 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,49168,32041,1024,32769,4161,41341,17,62558,8192,65,23809,5392,17665,32041,1364,21792,256,21793,46093,22273]

theorem envBound47155 : H12AffineFastState.Bounded env47155 := by
  intro p hp
  have h : env47155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47154_47155 : H12AffineEnvironment.transform 16 49168 env47154 = env47155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env47154 == env47155) = true)

theorem identity47155 : scanCanonicalize (H12AffineFastState.compose env47155 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound47155 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env47156 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,8283,38209,10360,1024,32769,4161,41341,17,41231,8192,65,2128,5392,4176,10360,1364,113,256,112,46093,592]

theorem envBound47156 : H12AffineFastState.Bounded env47156 := by
  intro p hp
  have h : env47156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47155_47156 : H12AffineEnvironment.transform 13 5457 env47155 = env47156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env47155 == env47156) = true)

theorem identity47156 : scanCanonicalize (H12AffineFastState.compose env47156 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47156 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env47157 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8541,8283,13340,10360,1024,8540,4161,32,17,82,8192,65,2128,5392,4176,10360,1364,113,256,112,5456,592]

theorem envBound47157 : H12AffineFastState.Bounded env47157 := by
  intro p hp
  have h : env47157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47156_47157 : H12AffineEnvironment.transform 14 8541 env47156 = env47157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47156 == env47157) = true)

theorem identity47157 : scanCanonicalize (H12AffineFastState.compose env47157 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound47157 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env47158 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,5457,1345,1095,4096,3172,1024,1344,4161,32,17,82,1052,65,2128,5392,4176,3172,1364,113,256,112,5456,592]

theorem envBound47158 : H12AffineFastState.Bounded env47158 := by
  intro p hp
  have h : env47158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47157_47158 : H12AffineEnvironment.transform 12 1052 env47157 = env47158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env47157 == env47158) = true)

theorem identity47158 : scanCanonicalize (H12AffineFastState.compose env47158 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound47158 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env47159 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3109,1052,2420,1345,1095,3109,3172,1024,1344,3172,32,17,82,1052,65,2128,2357,3189,3172,1364,113,256,112,2421,592]

theorem envBound47159 : H12AffineFastState.Bounded env47159 := by
  intro p hp
  have h : env47159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47158_47159 : H12AffineEnvironment.transform 11 3109 env47158 = env47159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env47158 == env47159) = true)

theorem identity47159 : scanCanonicalize (H12AffineFastState.compose env47159 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47159 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env47160 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2357,268,2420,81,343,2357,2420,272,80,2420,32,17,82,268,65,2128,2357,2405,2420,68,113,256,112,2421,592]

theorem envBound47160 : H12AffineFastState.Bounded env47160 := by
  intro p hp
  have h : env47160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47159_47160 : H12AffineEnvironment.transform 9 272 env47159 = env47160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47159 == env47160) = true)

theorem identity47160 : scanCanonicalize (H12AffineFastState.compose env47160 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound47160 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47161 : List Nat := [2,4,8,16,32,64,8,85,512,69,2048,2144,89,2081,81,2,2144,2081,69,80,2081,32,17,82,89,65,2128,2144,2096,2081,68,113,85,112,2080,592]

theorem envBound47161 : H12AffineFastState.Bounded env47161 := by
  intro p hp
  have h : env47161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47160_47161 : H12AffineEnvironment.transform 7 85 env47160 = env47161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env47160 == env47161) = true)

theorem identity47161 : scanCanonicalize (H12AffineFastState.compose env47161 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47161 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env47162 : List Nat := [2,4,8,16,1,64,8,85,512,69,2048,2113,89,2048,81,2,2113,2048,69,80,2048,1,17,82,89,65,2128,2113,2065,2048,68,80,85,81,2049,592]

theorem envBound47162 : H12AffineFastState.Bounded env47162 := by
  intro p hp
  have h : env47162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47161_47162 : H12AffineEnvironment.transform 4 1 env47161 = env47162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47161 == env47162) = true)

def env47163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,201831,17,98645,8193,65,171280,5392,17665,67619,1365,254010,256,21793,46092,74251]

theorem envBound47163 : H12AffineFastState.Bounded env47163 := by
  intro p hp
  have h : env47163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47152_47163 : H12AffineEnvironment.transform 6 9 env47152 = env47163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47152 == env47163) = true)

theorem identity47163 : scanCanonicalize (H12AffineFastState.compose env47163 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47163 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47164 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,223599,1024,8541,4161,201831,17,73737,8193,65,146508,5392,17665,67619,1365,213350,256,21793,5456,74251]

theorem envBound47164 : H12AffineFastState.Bounded env47164 := by
  intro p hp
  have h : env47164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47163_47164 : H12AffineEnvironment.transform 14 8540 env47163 = env47164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47163 == env47164) = true)

theorem identity47164 : scanCanonicalize (H12AffineFastState.compose env47164 (packedSelected [0,1,7,8,9,10,12,14,15,16,19,22,31] rootPS)) = affineNative (2^(16+1) ^^^ 70963) := by decide +kernel

theorem selectedBound47164 : packedSelected [0,1,7,8,9,10,12,14,15,16,19,22,31] rootPS < 2^1333 := by decide +kernel

def env47165 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,70963,31836,1024,8541,4161,340,17,73737,8193,65,76159,5392,17665,67619,1365,21589,256,21793,5456,74251]

theorem envBound47165 : H12AffineFastState.Bounded env47165 := by
  intro p hp
  have h : env47165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47164_47165 : H12AffineEnvironment.transform 16 70963 env47164 = env47165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70963 env47164 == env47165) = true)

theorem identity47165 : scanCanonicalize (H12AffineFastState.compose env47165 (packedSelected [1,2,5,6,7,8,9,11,19,20,22,23,24,26,27] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47165 : packedSelected [1,2,5,6,7,8,9,11,19,20,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env47166 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,8313,65536,70678,31836,1024,8312,4161,113,17,73737,8193,65,75866,5173,17444,67619,1136,21589,37,21508,5237,74251]

theorem envBound47166 : H12AffineFastState.Bounded env47166 := by
  intro p hp
  have h : env47166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47165_47166 : H12AffineEnvironment.transform 7 37 env47165 = env47166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47165 == env47166) = true)

theorem identity47166 : scanCanonicalize (H12AffineFastState.compose env47166 (packedSelected [1,2,3,5,6,8,9,10,11,14,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound47166 : packedSelected [1,2,3,5,6,8,9,10,11,14,19,22,23] rootPS < 2^1333 := by decide +kernel

def env47167 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,8313,21510,16400,31836,1024,8312,4161,113,17,29711,8193,65,31836,5173,17444,23589,1136,21589,37,21508,5237,30221]

theorem envBound47167 : H12AffineFastState.Bounded env47167 := by
  intro p hp
  have h : env47167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47166_47167 : H12AffineEnvironment.transform 15 21510 env47166 = env47167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env47166 == env47167) = true)

theorem identity47167 : scanCanonicalize (H12AffineFastState.compose env47167 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound47167 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env47168 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,13325,8313,8203,13341,2129,1024,8312,4161,113,17,2,8193,65,2129,5173,12329,10280,1136,8280,37,8201,5237,512]

theorem envBound47168 : H12AffineFastState.Bounded env47168 := by
  intro p hp
  have h : env47168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47167_47168 : H12AffineEnvironment.transform 13 13325 env47167 = env47168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env47167 == env47168) = true)

theorem identity47168 : scanCanonicalize (H12AffineFastState.compose env47168 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound47168 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env47169 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1087,4096,8192,13325,8313,8203,13341,1134,1024,8312,4161,113,17,2,8193,65,1134,5173,12329,9239,1136,8280,37,8201,5237,512]

theorem envBound47169 : H12AffineFastState.Bounded env47169 := by
  intro p hp
  have h : env47169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47168_47169 : H12AffineEnvironment.transform 10 1087 env47168 = env47169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env47168 == env47169) = true)

theorem identity47169 : scanCanonicalize (H12AffineFastState.compose env47169 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 4137) := by decide +kernel

theorem selectedBound47169 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env47170 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1087,4096,4137,1060,4176,4130,1076,1134,1024,4177,4161,113,17,2,4136,65,1134,5173,0,5182,1136,4209,37,4128,5237,512]

theorem envBound47170 : H12AffineFastState.Bounded env47170 := by
  intro p hp
  have h : env47170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47169_47170 : H12AffineEnvironment.transform 12 4137 env47169 = env47170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4137 env47169 == env47170) = true)

theorem identity47170 : scanCanonicalize (H12AffineFastState.compose env47170 (packedSelected [0,3,5,7,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound47170 : packedSelected [0,3,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env47171 : List Nat := [2,4,8,16,32,64,9,37,512,62,1,4096,4137,26,4176,4130,10,80,62,4177,4161,113,17,2,4136,65,80,4107,0,4096,78,4209,37,4128,4171,512]

theorem envBound47171 : H12AffineFastState.Bounded env47171 := by
  intro p hp
  have h : env47171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47170_47171 : H12AffineEnvironment.transform 9 62 env47170 = env47171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env47170 == env47171) = true)

theorem identity47171 : scanCanonicalize (H12AffineFastState.compose env47171 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47171 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47172 : List Nat := [2,4,8,16,32,16,9,37,512,62,1,4096,4137,26,4096,4130,10,0,62,4097,4113,33,17,2,4136,17,0,4107,0,4096,30,4129,37,4128,4123,512]

theorem envBound47172 : H12AffineFastState.Bounded env47172 := by
  intro p hp
  have h : env47172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47171_47172 : H12AffineEnvironment.transform 5 16 env47171 = env47172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47171 == env47172) = true)

theorem identity47172 : scanCanonicalize (H12AffineFastState.compose env47172 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound47172 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env47173 : List Nat := [2,4,8,16,32,16,9,37,512,62,1,42,3,26,42,8,10,0,62,43,59,33,17,2,2,17,0,33,0,42,30,11,37,10,49,512]

theorem envBound47173 : H12AffineFastState.Bounded env47173 := by
  intro p hp
  have h : env47173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47172_47173 : H12AffineEnvironment.transform 11 42 env47172 = env47173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env47172 == env47173) = true)

theorem identity47173 : scanCanonicalize (H12AffineFastState.compose env47173 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47173 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47174 : List Nat := [2,4,8,16,1,16,9,4,512,31,1,11,3,26,11,8,10,0,31,10,26,0,17,2,2,17,0,0,0,11,30,11,4,10,16,512]

theorem envBound47174 : H12AffineFastState.Bounded env47174 := by
  intro p hp
  have h : env47174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47173_47174 : H12AffineEnvironment.transform 4 1 env47173 = env47174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47173 == env47174) = true)

theorem identity47174 : scanCanonicalize (H12AffineFastState.compose env47174 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound47174 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47175 : List Nat := [2,4,8,16,1,16,9,4,14,31,1,11,3,26,11,8,10,0,31,10,26,0,17,2,2,17,0,0,0,11,30,11,4,10,16,14]

theorem envBound47175 : H12AffineFastState.Bounded env47175 := by
  intro p hp
  have h : env47175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47174_47175 : H12AffineEnvironment.transform 8 14 env47174 = env47175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env47174 == env47175) = true)

theorem identity47175 : scanCanonicalize (H12AffineFastState.compose env47175 (packedSelected [3,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound47175 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env47176 : List Nat := [0,4,8,16,1,16,9,4,12,29,1,9,1,24,9,8,8,0,29,8,24,0,17,0,0,17,0,0,0,9,28,9,4,8,16,12]

theorem envBound47176 : H12AffineFastState.Bounded env47176 := by
  intro p hp
  have h : env47176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47175_47176 : H12AffineEnvironment.transform 0 0 env47175 = env47176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env47175 == env47176) = true)

theorem identity47176 : scanCanonicalize (H12AffineFastState.compose env47176 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound47176 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env47177 : List Nat := [0,4,0,16,1,16,1,4,4,21,1,1,1,16,1,0,0,0,21,0,16,0,17,0,0,17,0,0,0,1,20,1,4,0,16,4]

theorem envBound47177 : H12AffineFastState.Bounded env47177 := by
  intro p hp
  have h : env47177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47176_47177 : H12AffineEnvironment.transform 2 0 env47176 = env47177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env47176 == env47177) = true)

theorem identity47177 : scanCanonicalize (H12AffineFastState.compose env47177 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound47177 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47178 : List Nat := [0,4,0,5,1,5,1,4,4,0,1,1,1,5,1,0,0,0,0,0,5,0,4,0,0,4,0,0,0,1,1,1,4,0,5,4]

theorem envBound47178 : H12AffineFastState.Bounded env47178 := by
  intro p hp
  have h : env47178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47177_47178 : H12AffineEnvironment.transform 3 5 env47177 = env47178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env47177 == env47178) = true)

def env47179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound47179 : H12AffineFastState.Bounded env47179 := by
  intro p hp
  have h : env47179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46976_47179 : H12AffineEnvironment.transform 18 1025 env46976 = env47179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env46976 == env47179) = true)

theorem identity47179 : scanCanonicalize (H12AffineFastState.compose env47179 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8661170) := by decide +kernel

theorem selectedBound47179 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env47180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661170,8328,65,4450483,10857534,10507601,8830976,371875,15027570,257,2485278,2428347,297845]

theorem envBound47180 : H12AffineFastState.Bounded env47180 := by
  intro p hp
  have h : env47180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47179_47180 : H12AffineEnvironment.transform 23 8661170 env47179 = env47180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8661170 env47179 == env47180) = true)

def env47181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8192,65,4450363,10857534,10507601,8830976,371755,15027570,257,2485278,2428211,297845]

theorem envBound47181 : H12AffineFastState.Bounded env47181 := by
  intro p hp
  have h : env47181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47180_47181 : H12AffineEnvironment.transform 6 8 env47180 = env47181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47180 == env47181) = true)

theorem identity47181 : scanCanonicalize (H12AffineFastState.compose env47181 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 256367) := by decide +kernel

theorem selectedBound47181 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env47182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,256367,1025,32769,2097152,4194304,8388608,8634709,8192,65,4450363,10634577,10507601,8464751,148804,14853149,257,2229617,2286684,221722]

theorem envBound47182 : H12AffineFastState.Bounded env47182 := by
  intro p hp
  have h : env47182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47181_47182 : H12AffineEnvironment.transform 17 256367 env47181 = env47182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 256367 env47181 == env47182) = true)

def env47183 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,108927,1025,32769,2097152,4194304,8388608,8487237,8192,65,4302891,10487105,10507601,8464751,1364,14738445,257,2114913,2139212,74250]

theorem envBound47183 : H12AffineFastState.Bounded env47183 := by
  intro p hp
  have h : env47183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47182_47183 : H12AffineEnvironment.transform 16 16400 env47182 = env47183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env47182 == env47183) = true)

theorem identity47183 : scanCanonicalize (H12AffineFastState.compose env47183 (packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 4235629) := by decide +kernel

theorem selectedBound47183 : packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env47184 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,108927,1025,32769,2097152,4194304,4235629,4268072,8192,65,4302891,6333484,6353980,4294658,1364,2114912,257,2114913,2139212,74250]

theorem envBound47184 : H12AffineFastState.Bounded env47184 := by
  intro p hp
  have h : env47184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47183_47184 : H12AffineEnvironment.transform 22 4235629 env47183 = env47184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235629 env47183 == env47184) = true)

theorem identity47184 : scanCanonicalize (H12AffineFastState.compose env47184 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 2122860) := by decide +kernel

theorem selectedBound47184 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env47185 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,108927,1025,32769,2097152,2122860,2147585,2180164,8192,65,2214983,49216,36944,2223214,1364,2114912,257,2114913,2139212,74250]

theorem envBound47185 : H12AffineFastState.Bounded env47185 := by
  intro p hp
  have h : env47185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47184_47185 : H12AffineEnvironment.transform 21 2122860 env47184 = env47185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122860 env47184 == env47185) = true)

theorem identity47185 : scanCanonicalize (H12AffineFastState.compose env47185 (packedSelected [11,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47185 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env47186 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,67619,1025,8541,2097152,2122860,2122845,2180164,8192,65,2190619,24860,12556,2182450,1364,2114912,257,2114913,2098448,74250]

theorem envBound47186 : H12AffineFastState.Bounded env47186 := by
  intro p hp
  have h : env47186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47185_47186 : H12AffineEnvironment.transform 14 8540 env47185 = env47186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47185 == env47186) = true)

theorem identity47186 : scanCanonicalize (H12AffineFastState.compose env47186 (packedSelected [3,4,5,9,19] rootPS)) = affineNative (2^(20+1) ^^^ 17729) := by decide +kernel

theorem selectedBound47186 : packedSelected [3,4,5,9,19] rootPS < 2^1333 := by decide +kernel

def env47187 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,67619,1025,8541,17729,8493,8476,65797,8192,65,75866,24860,12556,67699,1364,33,257,32,16465,74250]

theorem envBound47187 : H12AffineFastState.Bounded env47187 := by
  intro p hp
  have h : env47187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47186_47187 : H12AffineEnvironment.transform 20 17729 env47186 = env47187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env47186 == env47187) = true)

def env47188 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108926,1025,32769,2097152,4194304,8388608,8487236,8192,65,4302890,10487104,10507601,8464751,1365,14738444,257,2114912,2139213,74251]

theorem envBound47188 : H12AffineFastState.Bounded env47188 := by
  intro p hp
  have h : env47188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47182_47188 : H12AffineEnvironment.transform 16 16401 env47182 = env47188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env47182 == env47188) = true)

theorem identity47188 : scanCanonicalize (H12AffineFastState.compose env47188 (packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 4194353) := by decide +kernel

theorem selectedBound47188 : packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env47189 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108926,1025,32769,2097152,4194304,4194353,4292981,8192,65,4302890,6292849,6313312,4270430,1365,2155581,257,2114912,2139213,74251]

theorem envBound47189 : H12AffineFastState.Bounded env47189 := by
  intro p hp
  have h : env47189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47188_47189 : H12AffineEnvironment.transform 22 4194353 env47188 = env47189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194353 env47188 == env47189) = true)

theorem identity47189 : scanCanonicalize (H12AffineFastState.compose env47189 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 2147633) := by decide +kernel

theorem selectedBound47189 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env47190 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108926,1025,32769,2097152,2147633,2147584,2180164,8192,65,2190619,49216,36945,2223215,1365,2155581,257,2114912,2139213,74251]

theorem envBound47190 : H12AffineFastState.Bounded env47190 := by
  intro p hp
  have h : env47190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47189_47190 : H12AffineEnvironment.transform 21 2147633 env47189 = env47190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2147633 env47189 == env47190) = true)

def env47191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108926,1025,32769,50448,33,16,98644,8192,65,108555,49216,36945,76159,1365,8493,257,32880,24925,74251]

theorem envBound47191 : H12AffineFastState.Bounded env47191 := by
  intro p hp
  have h : env47191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47190_47191 : H12AffineEnvironment.transform 20 50448 env47190 = env47191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env47190 == env47191) = true)

theorem identity47191 : scanCanonicalize (H12AffineFastState.compose env47191 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47191 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env47192 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35189,1025,32769,50448,33,16,41311,8192,65,34816,49216,36945,2420,1365,8493,257,32880,24925,512]

theorem envBound47192 : H12AffineFastState.Bounded env47192 := by
  intro p hp
  have h : env47192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47191_47192 : H12AffineEnvironment.transform 15 8203 env47191 = env47192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47191 == env47192) = true)

theorem identity47192 : scanCanonicalize (H12AffineFastState.compose env47192 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound47192 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,89,16384,32768,82,16401,35189,1025,32769,50448,33,16,33030,89,65,34816,49216,36945,2420,1365,372,257,32880,16644,512]

theorem envBound47193 : H12AffineFastState.Bounded env47193 := by
  intro p hp
  have h : env47193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47192_47193 : H12AffineEnvironment.transform 12 89 env47192 = env47193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env47192 == env47193) = true)

theorem identity47193 : scanCanonicalize (H12AffineFastState.compose env47193 (packedSelected [0,7,16] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound47193 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env47194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,89,16384,292,82,16401,2129,1025,293,17460,33,16,34,89,65,2340,16740,4469,2420,1365,372,257,340,16644,512]

theorem envBound47194 : H12AffineFastState.Bounded env47194 := by
  intro p hp
  have h : env47194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47193_47194 : H12AffineEnvironment.transform 14 292 env47193 = env47194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env47193 == env47194) = true)

theorem identity47194 : scanCanonicalize (H12AffineFastState.compose env47194 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound47194 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47195 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,89,5377,292,82,5392,2129,1025,293,4405,33,16,34,89,65,2340,5221,4469,2420,1365,372,257,340,5125,512]

theorem envBound47195 : H12AffineFastState.Bounded env47195 := by
  intro p hp
  have h : env47195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47194_47195 : H12AffineEnvironment.transform 13 5377 env47194 = env47195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env47194 == env47195) = true)

theorem identity47195 : scanCanonicalize (H12AffineFastState.compose env47195 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47195 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env47196 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,89,5377,260,82,5392,2129,1025,261,4373,1,16,2,89,65,2308,5189,4437,2388,1365,340,257,340,5125,512]

theorem envBound47196 : H12AffineFastState.Bounded env47196 := by
  intro p hp
  have h : env47196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47195_47196 : H12AffineEnvironment.transform 4 0 env47195 = env47196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47195 == env47196) = true)

theorem identity47196 : scanCanonicalize (H12AffineFastState.compose env47196 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47196 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47197 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,9,5377,260,2,5392,2049,1025,261,4373,1,16,2,9,17,2308,5141,4357,2308,1285,260,257,260,5125,512]

theorem envBound47197 : H12AffineFastState.Bounded env47197 := by
  intro p hp
  have h : env47197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47196_47197 : H12AffineEnvironment.transform 5 16 env47196 = env47197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47196 == env47197) = true)

theorem identity47197 : scanCanonicalize (H12AffineFastState.compose env47197 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound47197 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env47198 : List Nat := [2,4,8,16,0,16,8,256,512,1024,528,4096,9,5377,260,2,5392,529,1025,261,4373,1,16,2,9,17,788,5141,4357,788,1285,260,257,260,5125,512]

theorem envBound47198 : H12AffineFastState.Bounded env47198 := by
  intro p hp
  have h : env47198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47197_47198 : H12AffineEnvironment.transform 10 528 env47197 = env47198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env47197 == env47198) = true)

theorem identity47198 : scanCanonicalize (H12AffineFastState.compose env47198 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound47198 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47199 : List Nat := [2,4,8,16,0,16,8,256,512,769,528,4096,9,4608,260,2,4625,529,768,261,4373,1,16,2,9,17,788,4884,4357,788,516,260,257,260,4868,512]

theorem envBound47199 : H12AffineFastState.Bounded env47199 := by
  intro p hp
  have h : env47199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47198_47199 : H12AffineEnvironment.transform 9 769 env47198 = env47199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env47198 == env47199) = true)

theorem identity47199 : scanCanonicalize (H12AffineFastState.compose env47199 (packedSelected [0,4,10] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound47199 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env47200 : List Nat := [2,4,8,16,0,16,8,256,16,273,0,4096,9,4112,260,2,4097,1,272,261,4373,1,16,2,9,17,260,4356,4357,260,20,260,257,260,4372,16]

theorem envBound47200 : H12AffineFastState.Bounded env47200 := by
  intro p hp
  have h : env47200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47199_47200 : H12AffineEnvironment.transform 8 16 env47199 = env47200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env47199 == env47200) = true)

theorem identity47200 : scanCanonicalize (H12AffineFastState.compose env47200 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 272) := by decide +kernel

theorem selectedBound47200 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47201 : List Nat := [2,4,8,16,0,16,8,256,16,273,0,272,9,256,260,2,273,1,272,261,5,1,16,2,9,17,260,20,21,260,20,260,257,260,4,16]

theorem envBound47201 : H12AffineFastState.Bounded env47201 := by
  intro p hp
  have h : env47201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47200_47201 : H12AffineEnvironment.transform 11 272 env47200 = env47201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 272 env47200 == env47201) = true)

theorem identity47201 : scanCanonicalize (H12AffineFastState.compose env47201 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 1) := by decide +kernel

theorem selectedBound47201 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47202 : List Nat := [2,4,8,16,0,16,8,1,16,16,0,17,9,1,5,2,16,1,17,4,5,1,16,2,9,17,5,20,21,5,20,5,0,5,4,16]

theorem envBound47202 : H12AffineFastState.Bounded env47202 := by
  intro p hp
  have h : env47202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47201_47202 : H12AffineEnvironment.transform 7 1 env47201 = env47202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 1 env47201 == env47202) = true)

theorem identity47202 : scanCanonicalize (H12AffineFastState.compose env47202 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47202 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47203 : List Nat := [2,4,8,0,0,0,8,1,0,0,0,1,9,1,5,2,0,1,1,4,5,1,0,2,9,1,5,4,5,5,4,5,0,5,4,0]

theorem envBound47203 : H12AffineFastState.Bounded env47203 := by
  intro p hp
  have h : env47203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47202_47203 : H12AffineEnvironment.transform 3 0 env47202 = env47203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47202 == env47203) = true)

theorem identity47203 : scanCanonicalize (H12AffineFastState.compose env47203 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound47203 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env47204 : List Nat := [2,1,8,0,0,0,8,1,0,0,0,1,9,1,0,2,0,1,1,1,0,1,0,2,9,1,0,1,0,0,1,0,0,0,1,0]

theorem envBound47204 : H12AffineFastState.Bounded env47204 := by
  intro p hp
  have h : env47204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47203_47204 : H12AffineEnvironment.transform 1 1 env47203 = env47204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env47203 == env47204) = true)

def env47205 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108926,1025,32769,50449,32,17,98645,8192,65,108554,49216,36945,76158,1365,8492,257,32881,24924,74251]

theorem envBound47205 : H12AffineFastState.Bounded env47205 := by
  intro p hp
  have h : env47205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47190_47205 : H12AffineEnvironment.transform 20 50449 env47190 = env47205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env47190 == env47205) = true)

theorem identity47205 : scanCanonicalize (H12AffineFastState.compose env47205 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47205 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env47206 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,67619,1025,8540,25676,32,17,73736,8192,65,67927,24861,12556,76158,1365,8492,257,8492,24924,74251]

theorem envBound47206 : H12AffineFastState.Bounded env47206 := by
  intro p hp
  have h : env47206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47205_47206 : H12AffineEnvironment.transform 14 8541 env47205 = env47206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47205 == env47206) = true)

theorem identity47206 : scanCanonicalize (H12AffineFastState.compose env47206 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound47206 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env47207 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4404,8541,65536,4389,67619,1025,8540,13688,32,17,73736,8192,65,67927,12329,12556,76158,1365,8492,257,8492,12392,74251]

theorem envBound47207 : H12AffineFastState.Bounded env47207 := by
  intro p hp
  have h : env47207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47206_47207 : H12AffineEnvironment.transform 13 4404 env47206 = env47207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env47206 == env47207) = true)

theorem identity47207 : scanCanonicalize (H12AffineFastState.compose env47207 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound47207 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47208 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4404,8541,35,4389,2048,1025,8540,13688,32,17,8235,8192,65,2420,12329,12556,10589,1365,8492,257,8492,12392,8744]

theorem envBound47208 : H12AffineFastState.Bounded env47208 := by
  intro p hp
  have h : env47208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47207_47208 : H12AffineEnvironment.transform 15 35 env47207 = env47208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env47207 == env47208) = true)

theorem identity47208 : scanCanonicalize (H12AffineFastState.compose env47208 (packedSelected [1,2,8,10,16] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound47208 : packedSelected [1,2,8,10,16] rootPS < 2^1333 := by decide +kernel

def env47209 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,4404,8541,35,4389,2048,321,8540,12344,32,17,8235,8192,65,2420,12329,12556,10589,21,8492,257,8492,12392,8744]

theorem envBound47209 : H12AffineFastState.Bounded env47209 := by
  intro p hp
  have h : env47209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47208_47209 : H12AffineEnvironment.transform 9 320 env47208 = env47209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env47208 == env47209) = true)

theorem identity47209 : scanCanonicalize (H12AffineFastState.compose env47209 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 2168) := by decide +kernel

theorem selectedBound47209 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env47210 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,2168,4404,2341,35,4389,2048,321,2340,6208,32,17,2131,2168,65,2420,6225,6516,293,21,2388,257,2388,6160,2640]

theorem envBound47210 : H12AffineFastState.Bounded env47210 := by
  intro p hp
  have h : env47210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47209_47210 : H12AffineEnvironment.transform 12 2168 env47209 = env47210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2168 env47209 == env47210) = true)

theorem identity47210 : scanCanonicalize (H12AffineFastState.compose env47210 (packedSelected [0,4,6,7,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47210 : packedSelected [0,4,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env47211 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,2168,4161,2128,35,4176,2048,52,2129,6208,32,17,2131,2168,65,2049,6225,6145,80,21,2081,116,2081,6160,2640]

theorem envBound47211 : H12AffineFastState.Bounded env47211 := by
  intro p hp
  have h : env47211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47210_47211 : H12AffineEnvironment.transform 7 117 env47210 = env47211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47210 == env47211) = true)

theorem identity47211 : scanCanonicalize (H12AffineFastState.compose env47211 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound47211 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env47212 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,16,2168,81,2128,35,64,2048,52,2129,2128,32,17,2131,2168,65,2049,2113,2065,80,21,2081,116,2081,2048,2640]

theorem envBound47212 : H12AffineFastState.Bounded env47212 := by
  intro p hp
  have h : env47212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47211_47212 : H12AffineEnvironment.transform 11 16 env47211 = env47212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env47211 == env47212) = true)

theorem identity47212 : scanCanonicalize (H12AffineFastState.compose env47212 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound47212 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env47213 : List Nat := [2,4,8,16,32,64,8,117,512,53,80,16,40,81,0,35,64,80,52,1,0,32,17,3,40,65,81,17,65,80,21,113,116,113,80,512]

theorem envBound47213 : H12AffineFastState.Bounded env47213 := by
  intro p hp
  have h : env47213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47212_47213 : H12AffineEnvironment.transform 10 80 env47212 = env47213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env47212 == env47213) = true)

theorem identity47213 : scanCanonicalize (H12AffineFastState.compose env47213 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47213 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47214 : List Nat := [2,4,8,16,17,64,8,68,512,4,80,16,25,81,0,18,64,80,5,1,0,17,17,3,25,65,81,17,65,80,21,64,69,64,80,512]

theorem envBound47214 : H12AffineFastState.Bounded env47214 := by
  intro p hp
  have h : env47214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47213_47214 : H12AffineEnvironment.transform 4 17 env47213 = env47214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47213 == env47214) = true)

theorem identity47214 : scanCanonicalize (H12AffineFastState.compose env47214 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound47214 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47215 : List Nat := [2,4,8,16,17,64,8,68,65,4,80,16,25,81,0,18,64,80,5,1,0,17,17,3,25,65,81,17,65,80,21,64,69,64,80,65]

theorem envBound47215 : H12AffineFastState.Bounded env47215 := by
  intro p hp
  have h : env47215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47214_47215 : H12AffineEnvironment.transform 8 65 env47214 = env47215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env47214 == env47215) = true)

theorem identity47215 : scanCanonicalize (H12AffineFastState.compose env47215 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound47215 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47216 : List Nat := [2,4,8,16,17,0,8,4,1,4,16,16,25,17,0,18,0,16,5,1,0,17,17,3,25,1,17,17,1,16,21,0,5,0,16,1]

theorem envBound47216 : H12AffineFastState.Bounded env47216 := by
  intro p hp
  have h : env47216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47215_47216 : H12AffineEnvironment.transform 5 0 env47215 = env47216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env47215 == env47216) = true)

theorem identity47216 : scanCanonicalize (H12AffineFastState.compose env47216 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47216 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47217 : List Nat := [2,4,8,1,0,0,8,4,1,4,1,1,8,0,0,3,0,1,5,1,0,0,0,3,8,1,0,0,1,1,4,0,5,0,1,1]

theorem envBound47217 : H12AffineFastState.Bounded env47217 := by
  intro p hp
  have h : env47217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47216_47217 : H12AffineEnvironment.transform 3 1 env47216 = env47217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47216 == env47217) = true)

theorem identity47217 : scanCanonicalize (H12AffineFastState.compose env47217 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound47217 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47218 : List Nat := [2,4,7,1,0,0,7,4,1,4,1,1,7,0,0,3,0,1,5,1,0,0,0,3,7,1,0,0,1,1,4,0,5,0,1,1]

theorem envBound47218 : H12AffineFastState.Bounded env47218 := by
  intro p hp
  have h : env47218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47217_47218 : H12AffineEnvironment.transform 2 7 env47217 = env47218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env47217 == env47218) = true)

def env47219 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661051,8193,65,4450362,10857534,10507601,8830976,371754,15027570,257,2485278,2428210,297845]

theorem envBound47219 : H12AffineFastState.Bounded env47219 := by
  intro p hp
  have h : env47219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47180_47219 : H12AffineEnvironment.transform 6 9 env47180 = env47219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47180 == env47219) = true)

theorem identity47219 : scanCanonicalize (H12AffineFastState.compose env47219 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound47219 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env47220 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,8429903,8193,65,4450362,10560842,10507601,8538484,75102,14795782,257,2188650,2196550,513]

theorem envBound47220 : H12AffineFastState.Bounded env47220 := by
  intro p hp
  have h : env47220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47219_47220 : H12AffineEnvironment.transform 17 35188 env47219 = env47220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env47219 == env47220) = true)

def env47221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,16,41311,8193,65,4450362,2172250,2118977,149860,75102,6407190,257,2188650,2196550,513]

theorem envBound47221 : H12AffineFastState.Bounded env47221 := by
  intro p hp
  have h : env47221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47220_47221 : H12AffineEnvironment.transform 22 16 env47220 = env47221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env47220 == env47221) = true)

theorem identity47221 : scanCanonicalize (H12AffineFastState.compose env47221 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound47221 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env47222 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,2097152,4194304,16,41311,8193,65,4229153,2172250,2118977,76159,75102,6407190,257,2188650,2196550,513]

theorem envBound47222 : H12AffineFastState.Bounded env47222 := by
  intro p hp
  have h : env47222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47221_47222 : H12AffineEnvironment.transform 16 90139 env47221 = env47222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env47221 == env47222) = true)

theorem identity47222 : scanCanonicalize (H12AffineFastState.compose env47222 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound47222 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env47223 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57676,35188,1025,32769,2097152,4194304,16,41311,8193,65,4229153,2139149,2118977,43048,41993,6309185,257,2155581,2098449,513]

theorem envBound47223 : H12AffineFastState.Bounded env47223 := by
  intro p hp
  have h : env47223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47222_47223 : H12AffineEnvironment.transform 15 33111 env47222 = env47223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env47222 == env47223) = true)

theorem identity47223 : scanCanonicalize (H12AffineFastState.compose env47223 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47223 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env47224 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10281,1025,8540,2097152,4194304,16,2,8193,65,4204924,2098512,2118977,2421,1364,6309185,257,2114912,2098449,513]

theorem envBound47224 : H12AffineFastState.Bounded env47224 := by
  intro p hp
  have h : env47224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47223_47224 : H12AffineEnvironment.transform 14 8541 env47223 = env47224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47223 == env47224) = true)

theorem identity47224 : scanCanonicalize (H12AffineFastState.compose env47224 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound47224 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47225 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10281,1025,8540,2097152,32,16,2,8193,65,10588,2098512,2118977,2421,1364,2114913,257,2114912,2098449,513]

theorem envBound47225 : H12AffineFastState.Bounded env47225 := by
  intro p hp
  have h : env47225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47224_47225 : H12AffineEnvironment.transform 21 32 env47224 = env47225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env47224 == env47225) = true)

theorem identity47225 : scanCanonicalize (H12AffineFastState.compose env47225 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound47225 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47226 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10281,1025,8540,25628,32,16,2,8193,65,10588,24908,12637,2421,1364,8573,257,8572,24845,513]

theorem envBound47226 : H12AffineFastState.Bounded env47226 := by
  intro p hp
  have h : env47226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47225_47226 : H12AffineEnvironment.transform 20 25628 env47225 = env47226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env47225 == env47226) = true)

theorem identity47226 : scanCanonicalize (H12AffineFastState.compose env47226 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound47226 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47227 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,16384,112,295,16401,2308,1025,113,17713,32,16,2,300,65,2161,16481,4208,2421,1364,80,257,81,16416,513]

theorem envBound47227 : H12AffineFastState.Bounded env47227 := by
  intro p hp
  have h : env47227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47226_47227 : H12AffineEnvironment.transform 12 301 env47226 = env47227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env47226 == env47227) = true)

theorem identity47227 : scanCanonicalize (H12AffineFastState.compose env47227 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47227 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env47228 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,301,16384,33,295,16401,2308,1025,32,17713,32,16,2,300,16,2080,16432,4129,2340,1285,1,257,0,16416,513]

theorem envBound47228 : H12AffineFastState.Bounded env47228 := by
  intro p hp
  have h : env47228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47227_47228 : H12AffineEnvironment.transform 5 17 env47227 = env47228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47227 == env47228) = true)

theorem identity47228 : scanCanonicalize (H12AffineFastState.compose env47228 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47228 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env47229 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,269,16384,1,263,16401,2308,1025,0,17681,0,16,2,268,16,2048,16400,4097,2308,1285,1,257,0,16384,513]

theorem envBound47229 : H12AffineFastState.Bounded env47229 := by
  intro p hp
  have h : env47229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47228_47229 : H12AffineEnvironment.transform 4 0 env47228 = env47229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47228 == env47229) = true)

theorem identity47229 : scanCanonicalize (H12AffineFastState.compose env47229 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound47229 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47230 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,260,269,16384,1,263,16401,2308,1025,0,17681,0,16,2,268,16,2048,16400,261,2308,1285,1,257,0,16384,513]

theorem envBound47230 : H12AffineFastState.Bounded env47230 := by
  intro p hp
  have h : env47230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47229_47230 : H12AffineEnvironment.transform 11 260 env47229 = env47230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env47229 == env47230) = true)

theorem identity47230 : scanCanonicalize (H12AffineFastState.compose env47230 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1540) := by decide +kernel

theorem selectedBound47230 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47231 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,260,269,1540,1,263,1557,2308,1025,0,789,0,16,2,268,16,2048,1556,261,2308,1285,1,257,0,1540,513]

theorem envBound47231 : H12AffineFastState.Bounded env47231 := by
  intro p hp
  have h : env47231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47230_47231 : H12AffineEnvironment.transform 13 1540 env47230 = env47231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1540 env47230 == env47231) = true)

theorem identity47231 : scanCanonicalize (H12AffineFastState.compose env47231 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound47231 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47232 : List Nat := [2,4,8,16,0,17,9,256,512,20,2048,260,269,528,1,263,513,2308,21,0,789,0,16,2,268,16,2048,512,261,2308,273,1,257,0,528,513]

theorem envBound47232 : H12AffineFastState.Bounded env47232 := by
  intro p hp
  have h : env47232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47231_47232 : H12AffineEnvironment.transform 9 20 env47231 = env47232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env47231 == env47232) = true)

theorem identity47232 : scanCanonicalize (H12AffineFastState.compose env47232 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound47232 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47233 : List Nat := [2,4,8,16,0,17,9,256,260,20,2048,260,269,276,1,263,261,2308,21,0,17,0,16,2,268,16,2048,260,261,2308,273,1,257,0,276,261]

theorem envBound47233 : H12AffineFastState.Bounded env47233 := by
  intro p hp
  have h : env47233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47232_47233 : H12AffineEnvironment.transform 8 260 env47232 = env47233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env47232 == env47233) = true)

theorem identity47233 : scanCanonicalize (H12AffineFastState.compose env47233 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound47233 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47234 : List Nat := [2,4,8,16,0,17,9,256,260,20,16,260,269,276,1,263,261,276,21,0,17,0,16,2,268,16,16,260,261,276,273,1,257,0,276,261]

theorem envBound47234 : H12AffineFastState.Bounded env47234 := by
  intro p hp
  have h : env47234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47233_47234 : H12AffineEnvironment.transform 10 16 env47233 = env47234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env47233 == env47234) = true)

def env47235 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,17,41310,8193,65,4450362,2172251,2118976,149861,75102,6407191,257,2188650,2196550,513]

theorem envBound47235 : H12AffineFastState.Bounded env47235 := by
  intro p hp
  have h : env47235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47220_47235 : H12AffineEnvironment.transform 22 17 env47220 = env47235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env47220 == env47235) = true)

theorem identity47235 : scanCanonicalize (H12AffineFastState.compose env47235 (packedSelected [0,1,5,7,8,19,20,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound47235 : packedSelected [0,1,5,7,8,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env47236 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,115734,4194304,17,41310,8193,65,4450362,57677,102742,149861,75102,4194305,257,41340,16464,513]

theorem envBound47236 : H12AffineFastState.Bounded env47236 := by
  intro p hp
  have h : env47236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47235_47236 : H12AffineEnvironment.transform 20 115734 env47235 = env47236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env47235 == env47236) = true)

def env47237 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11576,65536,131072,9292,1025,11577,92462,4194304,17,3174,8193,65,4408578,19573,81006,149861,75102,4194305,257,3140,16464,513]

theorem envBound47237 : H12AffineFastState.Bounded env47237 := by
  intro p hp
  have h : env47237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47236_47237 : H12AffineEnvironment.transform 14 11576 env47236 = env47237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11576 env47236 == env47237) = true)

theorem identity47237 : scanCanonicalize (H12AffineFastState.compose env47237 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound47237 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env47238 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11576,65536,82246,9292,1025,11577,92462,4194304,17,3174,8193,65,4195396,19573,81006,67619,75102,4194305,257,3140,16464,513]

theorem envBound47238 : H12AffineFastState.Bounded env47238 := by
  intro p hp
  have h : env47238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47237_47238 : H12AffineEnvironment.transform 16 82246 env47237 = env47238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env47237 == env47238) = true)

def env47239 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,8192,16384,8540,65536,82246,9292,1025,8541,91466,4194304,17,2,8193,65,4195396,16401,77834,66631,75102,4194305,257,32,16464,513]

theorem envBound47239 : H12AffineFastState.Bounded env47239 := by
  intro p hp
  have h : env47239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47238_47239 : H12AffineEnvironment.transform 10 1124 env47238 = env47239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env47238 == env47239) = true)

theorem identity47239 : scanCanonicalize (H12AffineFastState.compose env47239 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound47239 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47240 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,8192,16384,8540,28699,12637,9292,1025,8541,5457,4194304,17,2,8193,65,4195396,16401,16401,29788,21829,4194305,257,32,16464,513]

theorem envBound47240 : H12AffineFastState.Bounded env47240 := by
  intro p hp
  have h : env47240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47239_47240 : H12AffineEnvironment.transform 15 28699 env47239 = env47240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env47239 == env47240) = true)

theorem identity47240 : scanCanonicalize (H12AffineFastState.compose env47240 (packedSelected [11,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound47240 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env47241 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,41,16384,373,20530,4468,1125,1025,372,5457,4194304,17,2,40,65,4195396,16401,16401,21621,21829,4194305,257,32,16464,513]

theorem envBound47241 : H12AffineFastState.Bounded env47241 := by
  intro p hp
  have h : env47241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47240_47241 : H12AffineEnvironment.transform 12 41 env47240 = env47241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env47240 == env47241) = true)

theorem identity47241 : scanCanonicalize (H12AffineFastState.compose env47241 (packedSelected [1,8,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound47241 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env47242 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,4096,41,16384,1,20530,4096,1125,1025,0,5157,4194304,17,2,40,65,4195396,16401,16401,21621,21553,4194305,117,32,16464,513]

theorem envBound47242 : H12AffineFastState.Bounded env47242 := by
  intro p hp
  have h : env47242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47241_47242 : H12AffineEnvironment.transform 7 116 env47241 = env47242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env47241 == env47242) = true)

theorem identity47242 : scanCanonicalize (H12AffineFastState.compose env47242 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 1044) := by decide +kernel

theorem selectedBound47242 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env47243 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,4096,41,16384,1,20530,4096,1125,1025,0,5157,1044,17,2,40,65,80,16401,16401,21621,21553,1045,117,32,16464,513]

theorem envBound47243 : H12AffineFastState.Bounded env47243 := by
  intro p hp
  have h : env47243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47242_47243 : H12AffineEnvironment.transform 21 1044 env47242 = env47243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1044 env47242 == env47243) = true)

theorem identity47243 : scanCanonicalize (H12AffineFastState.compose env47243 (packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound47243 : packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS < 2^1333 := by decide +kernel

def env47244 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,4096,41,1076,1,5126,4096,1125,1025,0,5157,1044,17,2,40,65,80,1061,1061,4161,4101,1045,117,32,1124,513]

theorem envBound47244 : H12AffineFastState.Bounded env47244 := by
  intro p hp
  have h : env47244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47243_47244 : H12AffineEnvironment.transform 13 1076 env47243 = env47244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env47243 == env47244) = true)

theorem identity47244 : scanCanonicalize (H12AffineFastState.compose env47244 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47244 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env47245 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1077,4096,41,1076,1,5126,4096,1076,1025,0,5157,1044,17,2,40,16,1,1061,1061,4112,4101,1045,36,32,1077,513]

theorem envBound47245 : H12AffineFastState.Bounded env47245 := by
  intro p hp
  have h : env47245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47244_47245 : H12AffineEnvironment.transform 5 17 env47244 = env47245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47244 == env47245) = true)

theorem identity47245 : scanCanonicalize (H12AffineFastState.compose env47245 (packedSelected [0,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound47245 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env47246 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1077,1077,41,1076,1,51,1077,1076,1025,0,16,1044,17,2,40,16,1,1061,1061,1061,1072,1045,36,32,1077,513]

theorem envBound47246 : H12AffineFastState.Bounded env47246 := by
  intro p hp
  have h : env47246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47245_47246 : H12AffineEnvironment.transform 11 1077 env47245 = env47246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env47245 == env47246) = true)

theorem identity47246 : scanCanonicalize (H12AffineFastState.compose env47246 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound47246 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env47247 : List Nat := [2,4,8,16,32,17,9,37,512,20,33,33,41,32,1,51,33,32,21,0,16,0,17,2,40,16,1,49,49,49,36,1,36,32,33,513]

theorem envBound47247 : H12AffineFastState.Bounded env47247 := by
  intro p hp
  have h : env47247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47246_47247 : H12AffineEnvironment.transform 9 20 env47246 = env47247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env47246 == env47247) = true)

theorem identity47247 : scanCanonicalize (H12AffineFastState.compose env47247 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47247 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47248 : List Nat := [2,4,8,0,32,1,9,37,512,4,33,33,41,32,1,35,33,32,5,0,0,0,1,2,40,0,1,33,33,33,36,1,36,32,33,513]

theorem envBound47248 : H12AffineFastState.Bounded env47248 := by
  intro p hp
  have h : env47248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47247_47248 : H12AffineEnvironment.transform 3 0 env47247 = env47248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47247 == env47248) = true)

def env47249 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1125,4096,8192,16384,8541,65536,82246,9292,1025,8540,91467,4194304,17,3,8193,65,4195396,16400,77835,66630,75102,4194305,257,33,16464,513]

theorem envBound47249 : H12AffineFastState.Bounded env47249 := by
  intro p hp
  have h : env47249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47238_47249 : H12AffineEnvironment.transform 10 1125 env47238 = env47249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env47238 == env47249) = true)

def env47250 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,8192,16384,8461,65536,82198,9244,1025,8460,91419,4194304,17,3,8193,17,4195348,16400,77835,66582,75022,4194305,257,33,16384,513]

theorem envBound47250 : H12AffineFastState.Bounded env47250 := by
  intro p hp
  have h : env47250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47249_47250 : H12AffineEnvironment.transform 5 16 env47249 = env47250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47249 == env47250) = true)

theorem identity47250 : scanCanonicalize (H12AffineFastState.compose env47250 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47250 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47251 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,8192,16384,8461,8202,24860,9244,1025,8460,17681,4194304,17,3,8193,17,4195348,16400,4097,9244,1284,4194305,257,33,16384,513]

theorem envBound47251 : H12AffineFastState.Bounded env47251 := by
  intro p hp
  have h : env47251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47250_47251 : H12AffineEnvironment.transform 15 8202 env47250 = env47251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47250 == env47251) = true)

theorem identity47251 : scanCanonicalize (H12AffineFastState.compose env47251 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound47251 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47252 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,269,16384,0,263,16401,1297,1025,1,17681,4194304,17,3,268,17,4195348,16400,4097,1297,1284,4194305,257,33,16384,513]

theorem envBound47252 : H12AffineFastState.Bounded env47252 := by
  intro p hp
  have h : env47252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47251_47252 : H12AffineEnvironment.transform 12 269 env47251 = env47252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env47251 == env47252) = true)

theorem identity47252 : scanCanonicalize (H12AffineFastState.compose env47252 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21509) := by decide +kernel

theorem selectedBound47252 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env47253 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,269,16384,0,263,16401,1297,1025,1,17681,21509,17,3,268,17,20497,16400,4097,1297,1284,21508,257,33,16384,513]

theorem envBound47253 : H12AffineFastState.Bounded env47253 := by
  intro p hp
  have h : env47253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47252_47253 : H12AffineEnvironment.transform 21 21509 env47252 = env47253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21509 env47252 == env47253) = true)

theorem identity47253 : scanCanonicalize (H12AffineFastState.compose env47253 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound47253 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47254 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,269,5156,0,263,5173,1297,1025,1,4405,33,17,3,268,17,1077,5172,4097,1297,1284,32,257,33,5156,513]

theorem envBound47254 : H12AffineFastState.Bounded env47254 := by
  intro p hp
  have h : env47254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47253_47254 : H12AffineEnvironment.transform 13 5156 env47253 = env47254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env47253 == env47254) = true)

def env47255 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,544,269,1540,0,263,1557,1297,1025,1,789,33,17,3,268,17,1077,1556,545,1297,1284,32,257,33,1540,513]

theorem envBound47255 : H12AffineFastState.Bounded env47255 := by
  intro p hp
  have h : env47255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47254_47255 : H12AffineEnvironment.transform 11 544 env47254 = env47255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env47254 == env47255) = true)

def env47256 : List Nat := [2,4,8,16,32,16,9,256,512,768,821,544,269,260,0,263,277,529,769,1,789,33,17,3,268,17,821,276,545,529,516,32,257,33,260,513]

theorem envBound47256 : H12AffineFastState.Bounded env47256 := by
  intro p hp
  have h : env47256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47255_47256 : H12AffineEnvironment.transform 9 768 env47255 = env47256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env47255 == env47256) = true)

theorem identity47256 : scanCanonicalize (H12AffineFastState.compose env47256 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound47256 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47257 : List Nat := [2,4,8,16,32,16,9,256,277,21,32,309,269,260,0,263,277,260,20,1,0,33,17,3,268,17,32,276,308,260,273,32,257,33,260,276]

theorem envBound47257 : H12AffineFastState.Bounded env47257 := by
  intro p hp
  have h : env47257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47256_47257 : H12AffineEnvironment.transform 8 277 env47256 = env47257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env47256 == env47257) = true)

def env47258 : List Nat := [2,4,8,16,0,16,9,256,277,21,0,277,269,260,0,263,277,260,20,1,0,1,17,3,268,17,0,276,276,260,273,0,257,1,260,276]

theorem envBound47258 : H12AffineFastState.Bounded env47258 := by
  intro p hp
  have h : env47258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47257_47258 : H12AffineEnvironment.transform 4 0 env47257 = env47258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47257 == env47258) = true)

theorem identity47258 : scanCanonicalize (H12AffineFastState.compose env47258 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47258 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47259 : List Nat := [2,4,8,16,0,16,9,5,16,21,0,16,8,1,0,2,16,1,20,1,0,1,17,3,9,17,0,17,17,1,20,0,4,1,1,17]

theorem envBound47259 : H12AffineFastState.Bounded env47259 := by
  intro p hp
  have h : env47259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47258_47259 : H12AffineEnvironment.transform 7 5 env47258 = env47259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47258 == env47259) = true)

def leafEnv47259 : List Nat := [2,4,8,16,0,16,9,5,16,21,0,16,8,1,0,2,16,1,20,1,0,1,17,3,21,9,1,17,0,17,17,1,20,0,4,1,5,3,1,17,1,0,0]

def active47259 : List Nat := [0,1,2,3]

def tree47259 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47259 : H12WitnessSearch.Good tree47259 := H12GlobalWitnessIndex.good

theorem leafIdentity47259 : H12AffineFastState.composeSystem env47259 rootObs = leafEnv47259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47259 rootObs == leafEnv47259) = true)

theorem terminalChecked47259 : H12PackedTerminal.terminalCheckFast leafEnv47259 active47259 tree47259 = true := by decide +kernel

def env47260 : List Nat := [2,4,8,16,1,16,9,256,277,21,1,276,269,260,0,263,277,260,20,1,0,0,17,3,268,17,1,276,277,260,273,1,257,0,260,276]

theorem envBound47260 : H12AffineFastState.Bounded env47260 := by
  intro p hp
  have h : env47260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47257_47260 : H12AffineEnvironment.transform 4 1 env47257 = env47260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47257 == env47260) = true)

theorem identity47260 : scanCanonicalize (H12AffineFastState.compose env47260 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound47260 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47261 : List Nat := [2,4,8,11,1,11,9,256,270,14,1,271,269,260,0,263,270,260,15,1,0,0,10,3,268,10,1,271,270,260,266,1,257,0,260,271]

theorem envBound47261 : H12AffineFastState.Bounded env47261 := by
  intro p hp
  have h : env47261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47260_47261 : H12AffineEnvironment.transform 3 11 env47260 = env47261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env47260 == env47261) = true)

def leafEnv47261 : List Nat := [2,4,8,11,1,11,9,256,270,14,1,271,269,260,0,263,270,260,15,1,0,0,10,3,267,268,1,10,1,271,270,260,266,1,257,0,5,262,260,271,1,0,0]

def active47261 : List Nat := [0,1,2,7]

def tree47261 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47261 : H12WitnessSearch.Good tree47261 := H12GlobalWitnessIndex.good

theorem leafIdentity47261 : H12AffineFastState.composeSystem env47261 rootObs = leafEnv47261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47261 rootObs == leafEnv47261) = true)

theorem terminalChecked47261 : H12PackedTerminal.terminalCheckFast leafEnv47261 active47261 tree47261 = true := by decide +kernel

def env47262 : List Nat := [2,4,8,16,32,16,9,256,512,769,820,544,269,261,0,263,276,528,768,1,789,33,17,3,268,17,820,277,545,528,517,32,257,33,261,513]

theorem envBound47262 : H12AffineFastState.Bounded env47262 := by
  intro p hp
  have h : env47262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47255_47262 : H12AffineEnvironment.transform 9 769 env47255 = env47262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env47255 == env47262) = true)

theorem identity47262 : scanCanonicalize (H12AffineFastState.compose env47262 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47262 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47263 : List Nat := [2,4,8,16,32,16,9,5,512,516,561,544,8,0,0,2,17,528,517,1,528,33,17,3,9,17,561,16,545,528,517,32,4,33,0,513]

theorem envBound47263 : H12AffineFastState.Bounded env47263 := by
  intro p hp
  have h : env47263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47262_47263 : H12AffineEnvironment.transform 7 5 env47262 = env47263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47262 == env47263) = true)

def env47264 : List Nat := [2,4,8,16,32,16,9,5,48,52,1,16,8,0,0,2,17,32,53,1,32,33,17,3,9,17,1,16,17,32,53,32,4,33,0,49]

theorem envBound47264 : H12AffineFastState.Bounded env47264 := by
  intro p hp
  have h : env47264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47263_47264 : H12AffineEnvironment.transform 8 48 env47263 = env47264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env47263 == env47264) = true)

theorem identity47264 : scanCanonicalize (H12AffineFastState.compose env47264 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47264 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47265 : List Nat := [2,4,8,10,32,10,9,5,42,46,1,10,8,0,0,2,11,32,47,1,32,33,11,3,9,11,1,10,11,32,47,32,4,33,0,43]

theorem envBound47265 : H12AffineFastState.Bounded env47265 := by
  intro p hp
  have h : env47265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47264_47265 : H12AffineEnvironment.transform 3 10 env47264 = env47265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47264 == env47265) = true)

def leafEnv47265 : List Nat := [2,4,8,10,32,10,9,5,42,46,1,10,8,0,0,2,11,32,47,1,32,33,11,3,46,9,1,11,1,10,11,32,47,32,4,33,5,3,0,43,1,32,0]

def active47265 : List Nat := [0,1,2,4]

def tree47265 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47265 : H12WitnessSearch.Good tree47265 := H12GlobalWitnessIndex.good

theorem leafIdentity47265 : H12AffineFastState.composeSystem env47265 rootObs = leafEnv47265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47265 rootObs == leafEnv47265) = true)

theorem terminalChecked47265 : H12PackedTerminal.terminalCheckFast leafEnv47265 active47265 tree47265 = true := by decide +kernel

def env47266 : List Nat := [2,4,8,16,32,16,9,5,49,53,0,17,8,0,0,2,17,33,52,1,33,33,17,3,9,17,0,16,16,33,52,32,4,33,0,48]

theorem envBound47266 : H12AffineFastState.Bounded env47266 := by
  intro p hp
  have h : env47266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47263_47266 : H12AffineEnvironment.transform 8 49 env47263 = env47266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env47263 == env47266) = true)

def env47267 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,545,269,1541,0,263,1556,1297,1025,1,788,33,17,3,268,17,1077,1557,544,1297,1284,32,257,33,1541,513]

theorem envBound47267 : H12AffineFastState.Bounded env47267 := by
  intro p hp
  have h : env47267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47254_47267 : H12AffineEnvironment.transform 11 545 env47254 = env47267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env47254 == env47267) = true)

def env47268 : List Nat := [2,4,8,16,32,16,9,256,512,768,821,545,269,261,0,263,276,529,769,1,788,33,17,3,268,17,821,277,544,529,516,32,257,33,261,513]

theorem envBound47268 : H12AffineFastState.Bounded env47268 := by
  intro p hp
  have h : env47268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47267_47268 : H12AffineEnvironment.transform 9 768 env47267 = env47268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env47267 == env47268) = true)

theorem identity47268 : scanCanonicalize (H12AffineFastState.compose env47268 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47269 : List Nat := [2,4,8,16,0,16,9,256,512,768,789,513,269,261,0,263,276,529,769,1,788,1,17,3,268,17,789,277,512,529,516,0,257,1,261,513]

theorem envBound47269 : H12AffineFastState.Bounded env47269 := by
  intro p hp
  have h : env47269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47268_47269 : H12AffineEnvironment.transform 4 0 env47268 = env47269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47268 == env47269) = true)

def env47270 : List Nat := [2,4,8,16,0,16,9,256,276,20,1,277,269,261,0,263,276,261,21,1,0,1,17,3,268,17,1,277,276,261,272,0,257,1,261,277]

theorem envBound47270 : H12AffineFastState.Bounded env47270 := by
  intro p hp
  have h : env47270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47269_47270 : H12AffineEnvironment.transform 8 276 env47269 = env47270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env47269 == env47270) = true)

theorem identity47270 : scanCanonicalize (H12AffineFastState.compose env47270 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound47270 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47271 : List Nat := [2,4,8,11,0,11,9,256,271,15,1,270,269,261,0,263,271,261,14,1,0,1,10,3,268,10,1,270,271,261,267,0,257,1,261,270]

theorem envBound47271 : H12AffineFastState.Bounded env47271 := by
  intro p hp
  have h : env47271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47270_47271 : H12AffineEnvironment.transform 3 11 env47270 = env47271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env47270 == env47271) = true)

def leafEnv47271 : List Nat := [2,4,8,11,0,11,9,256,271,15,1,270,269,261,0,263,271,261,14,1,0,1,10,3,266,268,1,10,1,270,271,261,267,0,257,1,5,262,261,270,1,0,0]

def active47271 : List Nat := [0,1,2,7]

def tree47271 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47271 : H12WitnessSearch.Good tree47271 := H12GlobalWitnessIndex.good

theorem leafIdentity47271 : H12AffineFastState.composeSystem env47271 rootObs = leafEnv47271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47271 rootObs == leafEnv47271) = true)

theorem terminalChecked47271 : H12PackedTerminal.terminalCheckFast leafEnv47271 active47271 tree47271 = true := by decide +kernel

def env47272 : List Nat := [2,4,8,16,0,16,9,256,277,21,0,276,269,261,0,263,276,260,20,1,1,1,17,3,268,17,0,277,277,260,273,0,257,1,261,276]

theorem envBound47272 : H12AffineFastState.Bounded env47272 := by
  intro p hp
  have h : env47272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47269_47272 : H12AffineEnvironment.transform 8 277 env47269 = env47272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env47269 == env47272) = true)

theorem identity47272 : scanCanonicalize (H12AffineFastState.compose env47272 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound47272 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47273 : List Nat := [2,4,8,16,0,16,9,4,17,21,0,16,9,1,0,3,16,0,20,1,1,1,17,3,8,17,0,17,17,0,21,0,5,1,1,16]

theorem envBound47273 : H12AffineFastState.Bounded env47273 := by
  intro p hp
  have h : env47273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47272_47273 : H12AffineEnvironment.transform 7 4 env47272 = env47273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env47272 == env47273) = true)

def leafEnv47273 : List Nat := [2,4,8,16,0,16,9,4,17,21,0,16,9,1,0,3,16,0,20,1,1,1,17,3,20,8,1,17,0,17,17,0,21,0,5,1,5,2,1,16,1,1,0]

def active47273 : List Nat := [0,1,2,3]

def tree47273 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47273 : H12WitnessSearch.Good tree47273 := H12GlobalWitnessIndex.good

theorem leafIdentity47273 : H12AffineFastState.composeSystem env47273 rootObs = leafEnv47273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47273 rootObs == leafEnv47273) = true)

theorem terminalChecked47273 : H12PackedTerminal.terminalCheckFast leafEnv47273 active47273 tree47273 = true := by decide +kernel

def env47274 : List Nat := [2,4,8,16,32,16,9,256,512,769,820,545,269,260,0,263,277,528,768,1,788,33,17,3,268,17,820,276,544,528,517,32,257,33,260,513]

theorem envBound47274 : H12AffineFastState.Bounded env47274 := by
  intro p hp
  have h : env47274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47267_47274 : H12AffineEnvironment.transform 9 769 env47267 = env47274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env47267 == env47274) = true)

theorem identity47274 : scanCanonicalize (H12AffineFastState.compose env47274 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound47274 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47275 : List Nat := [2,4,8,16,32,16,9,256,49,304,261,16,269,260,0,263,277,33,305,1,293,33,17,3,268,17,261,276,17,33,52,32,257,33,260,48]

theorem envBound47275 : H12AffineFastState.Bounded env47275 := by
  intro p hp
  have h : env47275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47274_47275 : H12AffineEnvironment.transform 8 49 env47274 = env47275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env47274 == env47275) = true)

def env47276 : List Nat := [2,4,8,16,32,16,9,4,49,52,1,16,9,0,0,3,17,33,53,1,33,33,17,3,8,17,1,16,17,33,52,32,5,33,0,48]

theorem envBound47276 : H12AffineFastState.Bounded env47276 := by
  intro p hp
  have h : env47276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47275_47276 : H12AffineEnvironment.transform 7 4 env47275 = env47276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env47275 == env47276) = true)

theorem identity47276 : scanCanonicalize (H12AffineFastState.compose env47276 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47276 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47277 : List Nat := [2,4,8,10,32,10,9,4,43,46,1,10,9,0,0,3,11,33,47,1,33,33,11,3,8,11,1,10,11,33,46,32,5,33,0,42]

theorem envBound47277 : H12AffineFastState.Bounded env47277 := by
  intro p hp
  have h : env47277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47276_47277 : H12AffineEnvironment.transform 3 10 env47276 = env47277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47276 == env47277) = true)

def leafEnv47277 : List Nat := [2,4,8,10,32,10,9,4,43,46,1,10,9,0,0,3,11,33,47,1,33,33,11,3,47,8,1,11,1,10,11,33,46,32,5,33,5,2,0,42,1,33,0]

def active47277 : List Nat := [0,1,2,4]

def tree47277 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47277 : H12WitnessSearch.Good tree47277 := H12GlobalWitnessIndex.good

theorem leafIdentity47277 : H12AffineFastState.composeSystem env47277 rootObs = leafEnv47277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47277 rootObs == leafEnv47277) = true)

theorem terminalChecked47277 : H12PackedTerminal.terminalCheckFast leafEnv47277 active47277 tree47277 = true := by decide +kernel

def env47278 : List Nat := [2,4,8,16,32,16,9,5,49,53,0,16,8,1,0,2,16,33,52,1,32,33,17,3,9,17,0,17,17,33,52,32,4,33,1,48]

theorem envBound47278 : H12AffineFastState.Bounded env47278 := by
  intro p hp
  have h : env47278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47275_47278 : H12AffineEnvironment.transform 7 5 env47275 = env47278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47275 == env47278) = true)

def leafEnv47278 : List Nat := [2,4,8,16,32,16,9,5,49,53,0,16,8,1,0,2,16,33,52,1,32,33,17,3,53,9,1,17,0,17,17,33,52,32,4,33,5,3,1,48,1,32,0]

def active47278 : List Nat := [0,1,2,3,4]

def tree47278 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47278 : H12WitnessSearch.Good tree47278 := H12GlobalWitnessIndex.good

theorem leafIdentity47278 : H12AffineFastState.composeSystem env47278 rootObs = leafEnv47278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47278 rootObs == leafEnv47278) = true)

theorem terminalChecked47278 : H12PackedTerminal.terminalCheckFast leafEnv47278 active47278 tree47278 = true := by decide +kernel

def env47279 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,4096,8192,16384,8460,65536,82199,9245,1025,8461,91418,4194304,17,3,8193,16,4195349,16400,77835,66583,75023,4194305,257,33,16385,513]

theorem envBound47279 : H12AffineFastState.Bounded env47279 := by
  intro p hp
  have h : env47279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47249_47279 : H12AffineEnvironment.transform 5 17 env47249 = env47279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47249 == env47279) = true)

def env47280 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11577,65536,131072,9293,1025,11576,92463,4194304,17,3175,8193,65,4408579,19572,81007,149861,75102,4194305,257,3141,16464,513]

theorem envBound47280 : H12AffineFastState.Bounded env47280 := by
  intro p hp
  have h : env47280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47236_47280 : H12AffineEnvironment.transform 14 11577 env47236 = env47280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11577 env47236 == env47280) = true)

theorem identity47280 : scanCanonicalize (H12AffineFastState.compose env47280 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 85282) := by decide +kernel

theorem selectedBound47280 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env47281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11577,65536,85282,9293,1025,11576,92463,4194304,17,3175,8193,65,4196385,19572,81007,66631,75102,4194305,257,3141,16464,513]

theorem envBound47281 : H12AffineFastState.Bounded env47281 := by
  intro p hp
  have h : env47281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47280_47281 : H12AffineEnvironment.transform 16 85282 env47280 = env47281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 85282 env47280 == env47281) = true)

theorem identity47281 : scanCanonicalize (H12AffineFastState.compose env47281 (packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound47281 : packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS < 2^1333 := by decide +kernel

def env47282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,8192,16384,8541,65536,82246,9293,1025,8540,91467,4194304,17,3,8193,65,4195397,16400,77835,66631,75102,4194305,257,33,16464,513]

theorem envBound47282 : H12AffineFastState.Bounded env47282 := by
  intro p hp
  have h : env47282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47281_47282 : H12AffineEnvironment.transform 10 1124 env47281 = env47282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env47281 == env47282) = true)

def env47283 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,8192,16384,8461,65536,82198,9245,1025,8460,91419,4194304,17,3,8193,17,4195349,16400,77835,66583,75022,4194305,257,33,16384,513]

theorem envBound47283 : H12AffineFastState.Bounded env47283 := by
  intro p hp
  have h : env47283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47282_47283 : H12AffineEnvironment.transform 5 16 env47282 = env47283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47282 == env47283) = true)

theorem identity47283 : scanCanonicalize (H12AffineFastState.compose env47283 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47283 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47284 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,8192,16384,8461,8202,24860,9245,1025,8460,17681,4194304,17,3,8193,17,4195349,16400,4097,9245,1284,4194305,257,33,16384,513]

theorem envBound47284 : H12AffineFastState.Bounded env47284 := by
  intro p hp
  have h : env47284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47283_47284 : H12AffineEnvironment.transform 15 8202 env47283 = env47284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47283 == env47284) = true)

theorem identity47284 : scanCanonicalize (H12AffineFastState.compose env47284 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound47284 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47285 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,269,16384,0,263,16401,1296,1025,1,17681,4194304,17,3,268,17,4195349,16400,4097,1296,1284,4194305,257,33,16384,513]

theorem envBound47285 : H12AffineFastState.Bounded env47285 := by
  intro p hp
  have h : env47285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47284_47285 : H12AffineEnvironment.transform 12 269 env47284 = env47285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env47284 == env47285) = true)

theorem identity47285 : scanCanonicalize (H12AffineFastState.compose env47285 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21509) := by decide +kernel

theorem selectedBound47285 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env47286 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,269,16384,0,263,16401,1296,1025,1,17681,21509,17,3,268,17,20496,16400,4097,1296,1284,21508,257,33,16384,513]

theorem envBound47286 : H12AffineFastState.Bounded env47286 := by
  intro p hp
  have h : env47286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47285_47286 : H12AffineEnvironment.transform 21 21509 env47285 = env47286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21509 env47285 == env47286) = true)

theorem identity47286 : scanCanonicalize (H12AffineFastState.compose env47286 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound47286 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47287 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,269,5156,0,263,5173,1296,1025,1,4405,33,17,3,268,17,1076,5172,4097,1296,1284,32,257,33,5156,513]

theorem envBound47287 : H12AffineFastState.Bounded env47287 := by
  intro p hp
  have h : env47287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47286_47287 : H12AffineEnvironment.transform 13 5156 env47286 = env47287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env47286 == env47287) = true)

def env47288 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,544,269,1540,0,263,1557,1296,1025,1,789,33,17,3,268,17,1076,1556,545,1296,1284,32,257,33,1540,513]

theorem envBound47288 : H12AffineFastState.Bounded env47288 := by
  intro p hp
  have h : env47288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47287_47288 : H12AffineEnvironment.transform 11 544 env47287 = env47288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env47287 == env47288) = true)

def env47289 : List Nat := [2,4,8,16,32,16,9,256,512,768,820,544,269,260,0,263,277,528,769,1,789,33,17,3,268,17,820,276,545,528,516,32,257,33,260,513]

theorem envBound47289 : H12AffineFastState.Bounded env47289 := by
  intro p hp
  have h : env47289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47288_47289 : H12AffineEnvironment.transform 9 768 env47288 = env47289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env47288 == env47289) = true)

theorem identity47289 : scanCanonicalize (H12AffineFastState.compose env47289 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound47289 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47290 : List Nat := [2,4,8,16,32,16,9,256,48,304,260,16,269,260,0,263,277,32,305,1,293,33,17,3,268,17,260,276,17,32,52,32,257,33,260,49]

theorem envBound47290 : H12AffineFastState.Bounded env47290 := by
  intro p hp
  have h : env47290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47289_47290 : H12AffineEnvironment.transform 8 48 env47289 = env47290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env47289 == env47290) = true)

def env47291 : List Nat := [2,4,8,16,32,16,9,4,48,52,0,16,9,0,0,3,17,32,53,1,33,33,17,3,8,17,0,16,17,32,52,32,5,33,0,49]

theorem envBound47291 : H12AffineFastState.Bounded env47291 := by
  intro p hp
  have h : env47291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47290_47291 : H12AffineEnvironment.transform 7 4 env47290 = env47291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env47290 == env47291) = true)

theorem identity47291 : scanCanonicalize (H12AffineFastState.compose env47291 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47291 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47292 : List Nat := [2,4,8,10,32,10,9,4,42,46,0,10,9,0,0,3,11,32,47,1,33,33,11,3,8,11,0,10,11,32,46,32,5,33,0,43]

theorem envBound47292 : H12AffineFastState.Bounded env47292 := by
  intro p hp
  have h : env47292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47291_47292 : H12AffineEnvironment.transform 3 10 env47291 = env47292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47291 == env47292) = true)

def leafEnv47292 : List Nat := [2,4,8,10,32,10,9,4,42,46,0,10,9,0,0,3,11,32,47,1,33,33,11,3,47,8,1,11,0,10,11,32,46,32,5,33,5,2,0,43,1,33,0]

def active47292 : List Nat := [0,1,2,4]

def tree47292 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47292 : H12WitnessSearch.Good tree47292 := H12GlobalWitnessIndex.good

theorem leafIdentity47292 : H12AffineFastState.composeSystem env47292 rootObs = leafEnv47292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47292 rootObs == leafEnv47292) = true)

theorem terminalChecked47292 : H12PackedTerminal.terminalCheckFast leafEnv47292 active47292 tree47292 = true := by decide +kernel

def env47293 : List Nat := [2,4,8,16,32,16,9,5,48,53,1,16,8,1,0,2,16,32,52,1,32,33,17,3,9,17,1,17,17,32,52,32,4,33,1,49]

theorem envBound47293 : H12AffineFastState.Bounded env47293 := by
  intro p hp
  have h : env47293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47290_47293 : H12AffineEnvironment.transform 7 5 env47290 = env47293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47290 == env47293) = true)

def env47294 : List Nat := [2,4,8,16,32,16,9,256,512,769,821,544,269,261,0,263,276,529,768,1,789,33,17,3,268,17,821,277,545,529,517,32,257,33,261,513]

theorem envBound47294 : H12AffineFastState.Bounded env47294 := by
  intro p hp
  have h : env47294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47288_47294 : H12AffineEnvironment.transform 9 769 env47288 = env47294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env47288 == env47294) = true)

theorem identity47294 : scanCanonicalize (H12AffineFastState.compose env47294 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47294 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47295 : List Nat := [2,4,8,16,0,16,9,256,512,769,789,512,269,261,0,263,276,529,768,1,789,1,17,3,268,17,789,277,513,529,517,0,257,1,261,513]

theorem envBound47295 : H12AffineFastState.Bounded env47295 := by
  intro p hp
  have h : env47295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47294_47295 : H12AffineEnvironment.transform 4 0 env47294 = env47295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47294 == env47295) = true)

def env47296 : List Nat := [2,4,8,16,0,16,9,256,276,21,1,276,269,261,0,263,276,261,20,1,1,1,17,3,268,17,1,277,277,261,273,0,257,1,261,277]

theorem envBound47296 : H12AffineFastState.Bounded env47296 := by
  intro p hp
  have h : env47296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47295_47296 : H12AffineEnvironment.transform 8 276 env47295 = env47296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env47295 == env47296) = true)

theorem identity47296 : scanCanonicalize (H12AffineFastState.compose env47296 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47296 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47297 : List Nat := [2,4,8,16,0,16,9,5,17,21,1,17,8,0,0,2,17,0,20,1,1,1,17,3,9,17,1,16,16,0,20,0,4,1,0,16]

theorem envBound47297 : H12AffineFastState.Bounded env47297 := by
  intro p hp
  have h : env47297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47296_47297 : H12AffineEnvironment.transform 7 5 env47296 = env47297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47296 == env47297) = true)

def leafEnv47297 : List Nat := [2,4,8,16,0,16,9,5,17,21,1,17,8,0,0,2,17,0,20,1,1,1,17,3,21,9,1,17,1,16,16,0,20,0,4,1,5,3,0,16,1,1,0]

def active47297 : List Nat := [0,1,2,3]

def tree47297 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47297 : H12WitnessSearch.Good tree47297 := H12GlobalWitnessIndex.good

theorem leafIdentity47297 : H12AffineFastState.composeSystem env47297 rootObs = leafEnv47297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47297 rootObs == leafEnv47297) = true)

theorem terminalChecked47297 : H12PackedTerminal.terminalCheckFast leafEnv47297 active47297 tree47297 = true := by decide +kernel

def env47298 : List Nat := [2,4,8,16,0,16,9,256,277,20,0,277,269,261,0,263,276,260,21,1,0,1,17,3,268,17,0,277,276,260,272,0,257,1,261,276]

theorem envBound47298 : H12AffineFastState.Bounded env47298 := by
  intro p hp
  have h : env47298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47295_47298 : H12AffineEnvironment.transform 8 277 env47295 = env47298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env47295 == env47298) = true)

theorem identity47298 : scanCanonicalize (H12AffineFastState.compose env47298 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound47298 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47299 : List Nat := [2,4,8,11,0,11,9,256,270,15,0,270,269,261,0,263,271,260,14,1,0,1,10,3,268,10,0,270,271,260,267,0,257,1,261,271]

theorem envBound47299 : H12AffineFastState.Bounded env47299 := by
  intro p hp
  have h : env47299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47298_47299 : H12AffineEnvironment.transform 3 11 env47298 = env47299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env47298 == env47299) = true)

def leafEnv47299 : List Nat := [2,4,8,11,0,11,9,256,270,15,0,270,269,261,0,263,271,260,14,1,0,1,10,3,266,268,1,10,0,270,271,260,267,0,257,1,5,262,261,271,1,0,0]

def active47299 : List Nat := [0,1,2,7]

def tree47299 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47299 : H12WitnessSearch.Good tree47299 := H12GlobalWitnessIndex.good

theorem leafIdentity47299 : H12AffineFastState.composeSystem env47299 rootObs = leafEnv47299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47299 rootObs == leafEnv47299) = true)

theorem terminalChecked47299 : H12PackedTerminal.terminalCheckFast leafEnv47299 active47299 tree47299 = true := by decide +kernel

def env47300 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,545,269,1541,0,263,1556,1296,1025,1,788,33,17,3,268,17,1076,1557,544,1296,1284,32,257,33,1541,513]

theorem envBound47300 : H12AffineFastState.Bounded env47300 := by
  intro p hp
  have h : env47300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47287_47300 : H12AffineEnvironment.transform 11 545 env47287 = env47300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env47287 == env47300) = true)

def env47301 : List Nat := [2,4,8,16,32,16,9,256,512,768,820,545,269,261,0,263,276,528,769,1,788,33,17,3,268,17,820,277,544,528,516,32,257,33,261,513]

theorem envBound47301 : H12AffineFastState.Bounded env47301 := by
  intro p hp
  have h : env47301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47300_47301 : H12AffineEnvironment.transform 9 768 env47300 = env47301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env47300 == env47301) = true)

theorem identity47301 : scanCanonicalize (H12AffineFastState.compose env47301 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47301 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47302 : List Nat := [2,4,8,16,32,16,9,5,512,517,561,545,8,0,0,2,17,528,516,1,529,33,17,3,9,17,561,16,544,528,516,32,4,33,0,513]

theorem envBound47302 : H12AffineFastState.Bounded env47302 := by
  intro p hp
  have h : env47302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47301_47302 : H12AffineEnvironment.transform 7 5 env47301 = env47302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47301 == env47302) = true)

def env47303 : List Nat := [2,4,8,16,32,16,9,5,48,53,1,17,8,0,0,2,17,32,52,1,33,33,17,3,9,17,1,16,16,32,52,32,4,33,0,49]

theorem envBound47303 : H12AffineFastState.Bounded env47303 := by
  intro p hp
  have h : env47303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47302_47303 : H12AffineEnvironment.transform 8 48 env47302 = env47303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env47302 == env47303) = true)

def leafEnv47303 : List Nat := [2,4,8,16,32,16,9,5,48,53,1,17,8,0,0,2,17,32,52,1,33,33,17,3,53,9,1,17,1,16,16,32,52,32,4,33,5,3,0,49,1,33,0]

def active47303 : List Nat := [0,1,2,3,4]

def tree47303 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47303 : H12WitnessSearch.Good tree47303 := H12GlobalWitnessIndex.good

theorem leafIdentity47303 : H12AffineFastState.composeSystem env47303 rootObs = leafEnv47303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47303 rootObs == leafEnv47303) = true)

theorem terminalChecked47303 : H12PackedTerminal.terminalCheckFast leafEnv47303 active47303 tree47303 = true := by decide +kernel

def env47304 : List Nat := [2,4,8,16,32,16,9,5,49,52,0,16,8,0,0,2,17,33,53,1,32,33,17,3,9,17,0,16,17,33,53,32,4,33,0,48]

theorem envBound47304 : H12AffineFastState.Bounded env47304 := by
  intro p hp
  have h : env47304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47302_47304 : H12AffineEnvironment.transform 8 49 env47302 = env47304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env47302 == env47304) = true)

theorem identity47304 : scanCanonicalize (H12AffineFastState.compose env47304 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47304 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47305 : List Nat := [2,4,8,10,32,10,9,5,43,46,0,10,8,0,0,2,11,33,47,1,32,33,11,3,9,11,0,10,11,33,47,32,4,33,0,42]

theorem envBound47305 : H12AffineFastState.Bounded env47305 := by
  intro p hp
  have h : env47305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47304_47305 : H12AffineEnvironment.transform 3 10 env47304 = env47305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47304 == env47305) = true)

def leafEnv47305 : List Nat := [2,4,8,10,32,10,9,5,43,46,0,10,8,0,0,2,11,33,47,1,32,33,11,3,46,9,1,11,0,10,11,33,47,32,4,33,5,3,0,42,1,32,0]

def active47305 : List Nat := [0,1,2,4]

def tree47305 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47305 : H12WitnessSearch.Good tree47305 := H12GlobalWitnessIndex.good

theorem leafIdentity47305 : H12AffineFastState.composeSystem env47305 rootObs = leafEnv47305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47305 rootObs == leafEnv47305) = true)

theorem terminalChecked47305 : H12PackedTerminal.terminalCheckFast leafEnv47305 active47305 tree47305 = true := by decide +kernel

def env47306 : List Nat := [2,4,8,16,32,16,9,256,512,769,821,545,269,260,0,263,277,529,768,1,788,33,17,3,268,17,821,276,544,529,517,32,257,33,260,513]

theorem envBound47306 : H12AffineFastState.Bounded env47306 := by
  intro p hp
  have h : env47306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47300_47306 : H12AffineEnvironment.transform 9 769 env47300 = env47306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env47300 == env47306) = true)

theorem identity47306 : scanCanonicalize (H12AffineFastState.compose env47306 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound47306 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47307 : List Nat := [2,4,8,16,32,16,9,256,276,21,33,309,269,260,0,263,277,261,20,1,0,33,17,3,268,17,33,276,308,261,273,32,257,33,260,277]

theorem envBound47307 : H12AffineFastState.Bounded env47307 := by
  intro p hp
  have h : env47307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47306_47307 : H12AffineEnvironment.transform 8 276 env47306 = env47307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env47306 == env47307) = true)

def env47308 : List Nat := [2,4,8,16,0,16,9,256,276,21,1,277,269,260,0,263,277,261,20,1,0,1,17,3,268,17,1,276,276,261,273,0,257,1,260,277]

theorem envBound47308 : H12AffineFastState.Bounded env47308 := by
  intro p hp
  have h : env47308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47307_47308 : H12AffineEnvironment.transform 4 0 env47307 = env47308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47307 == env47308) = true)

theorem identity47308 : scanCanonicalize (H12AffineFastState.compose env47308 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound47308 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47309 : List Nat := [2,4,8,16,0,16,9,4,16,21,1,17,9,0,0,3,17,1,20,1,0,1,17,3,8,17,1,16,16,1,21,0,5,1,0,17]

theorem envBound47309 : H12AffineFastState.Bounded env47309 := by
  intro p hp
  have h : env47309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47308_47309 : H12AffineEnvironment.transform 7 4 env47308 = env47309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env47308 == env47309) = true)

def leafEnv47309 : List Nat := [2,4,8,16,0,16,9,4,16,21,1,17,9,0,0,3,17,1,20,1,0,1,17,3,20,8,1,17,1,16,16,1,21,0,5,1,5,2,0,17,1,0,0]

def active47309 : List Nat := [0,1,2,3]

def tree47309 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47309 : H12WitnessSearch.Good tree47309 := H12GlobalWitnessIndex.good

theorem leafIdentity47309 : H12AffineFastState.composeSystem env47309 rootObs = leafEnv47309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47309 rootObs == leafEnv47309) = true)

theorem terminalChecked47309 : H12PackedTerminal.terminalCheckFast leafEnv47309 active47309 tree47309 = true := by decide +kernel

def env47310 : List Nat := [2,4,8,16,1,16,9,256,276,21,0,276,269,260,0,263,277,261,20,1,0,0,17,3,268,17,0,276,277,261,273,1,257,0,260,277]

theorem envBound47310 : H12AffineFastState.Bounded env47310 := by
  intro p hp
  have h : env47310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47307_47310 : H12AffineEnvironment.transform 4 1 env47307 = env47310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47307 == env47310) = true)

theorem identity47310 : scanCanonicalize (H12AffineFastState.compose env47310 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound47310 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47311 : List Nat := [2,4,8,11,1,11,9,256,271,14,0,271,269,260,0,263,270,261,15,1,0,0,10,3,268,10,0,271,270,261,266,1,257,0,260,270]

theorem envBound47311 : H12AffineFastState.Bounded env47311 := by
  intro p hp
  have h : env47311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47310_47311 : H12AffineEnvironment.transform 3 11 env47310 = env47311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env47310 == env47311) = true)

def leafEnv47311 : List Nat := [2,4,8,11,1,11,9,256,271,14,0,271,269,260,0,263,270,261,15,1,0,0,10,3,267,268,1,10,0,271,270,261,266,1,257,0,5,262,260,270,1,0,0]

def active47311 : List Nat := [0,1,2,7]

def tree47311 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47311 : H12WitnessSearch.Good tree47311 := H12GlobalWitnessIndex.good

theorem leafIdentity47311 : H12AffineFastState.composeSystem env47311 rootObs = leafEnv47311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47311 rootObs == leafEnv47311) = true)

theorem terminalChecked47311 : H12PackedTerminal.terminalCheckFast leafEnv47311 active47311 tree47311 = true := by decide +kernel

def env47312 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,8192,16384,8460,65536,82199,9244,1025,8461,91418,4194304,17,3,8193,16,4195348,16400,77835,66582,75023,4194305,257,33,16385,513]

theorem envBound47312 : H12AffineFastState.Bounded env47312 := by
  intro p hp
  have h : env47312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47282_47312 : H12AffineEnvironment.transform 5 17 env47282 = env47312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47282 == env47312) = true)

def env47313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356288,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound47313 : H12AffineFastState.Bounded env47313 := by
  intro p hp
  have h : env47313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46975_47313 : H12AffineEnvironment.transform 26 30393345 env46975 = env47313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env46975 == env47313) = true)

def env47314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound47314 : H12AffineFastState.Bounded env47314 := by
  intro p hp
  have h : env47314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47313_47314 : H12AffineEnvironment.transform 18 1024 env47313 = env47314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env47313 == env47314) = true)

theorem identity47314 : scanCanonicalize (H12AffineFastState.compose env47314 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2534899) := by decide +kernel

theorem selectedBound47314 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env47315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2534899,8328,65,14773746,469374,10507601,8830976,10955234,4704306,256,8874335,8882426,10882613]

theorem envBound47315 : H12AffineFastState.Bounded env47315 := by
  intro p hp
  have h : env47315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47314_47315 : H12AffineEnvironment.transform 23 2534899 env47314 = env47315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2534899 env47314 == env47315) = true)

def env47316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,8388608,2114883,8328,65,14773746,115150,10507601,8399024,10600786,4268162,256,8487407,8478794,10544773]

theorem envBound47316 : H12AffineFastState.Bounded env47316 := by
  intro p hp
  have h : env47316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47315_47316 : H12AffineEnvironment.transform 17 190640 env47315 = env47316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env47315 == env47316) = true)

def env47317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101328,2114883,8328,65,4292002,115150,17665,2111712,119042,4268162,256,2199999,2191386,63189]

theorem envBound47317 : H12AffineFastState.Bounded env47317 := by
  intro p hp
  have h : env47317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47316_47317 : H12AffineEnvironment.transform 22 2101328 env47316 = env47317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env47316 == env47317) = true)

def env47318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,16,21763,8328,65,4292002,115150,17665,10400,119042,4268162,256,98815,90202,63189]

theorem envBound47318 : H12AffineFastState.Bounded env47318 := by
  intro p hp
  have h : env47318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47317_47318 : H12AffineEnvironment.transform 20 4160 env47317 = env47318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env47317 == env47318) = true)

theorem identity47318 : scanCanonicalize (H12AffineFastState.compose env47318 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound47318 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,138340,1024,29909,4160,4194304,16,21763,8328,65,4292002,79130,17665,10400,75222,4268162,256,95531,90202,513]

theorem envBound47319 : H12AffineFastState.Bounded env47319 := by
  intro p hp
  have h : env47319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47318_47319 : H12AffineEnvironment.transform 14 29908 env47318 = env47319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env47318 == env47319) = true)

def env47320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,138340,1024,8661,4160,4194304,16,3,8328,65,4270242,79130,4097,10400,75222,4268162,256,73771,79194,513]

theorem envBound47320 : H12AffineFastState.Bounded env47320 := by
  intro p hp
  have h : env47320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47319_47320 : H12AffineEnvironment.transform 13 5376 env47319 = env47320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47319 == env47320) = true)

theorem identity47320 : scanCanonicalize (H12AffineFastState.compose env47320 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound47320 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13508,10400,1024,8661,4160,4194304,16,3,8328,65,4270242,79130,4097,10400,75222,4268162,256,73771,79194,513]

theorem envBound47321 : H12AffineFastState.Bounded env47321 := by
  intro p hp
  have h : env47321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47320_47321 : H12AffineEnvironment.transform 16 13508 env47320 = env47321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env47320 == env47321) = true)

theorem identity47321 : scanCanonicalize (H12AffineFastState.compose env47321 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47321 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env47322 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,13389,10281,1024,8540,4160,4194304,16,3,8193,65,4270123,79130,4097,10281,75103,4268043,256,73771,79194,513]

theorem envBound47322 : H12AffineFastState.Bounded env47322 := by
  intro p hp
  have h : env47322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47321_47322 : H12AffineEnvironment.transform 6 9 env47321 = env47322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47321 == env47322) = true)

theorem identity47322 : scanCanonicalize (H12AffineFastState.compose env47322 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47322 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47323 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,13389,10281,1024,8540,4160,4194304,16,3,8193,65,4196385,5392,4097,10281,1365,4194305,256,33,5456,513]

theorem envBound47323 : H12AffineFastState.Bounded env47323 := by
  intro p hp
  have h : env47323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47322_47323 : H12AffineEnvironment.transform 15 8202 env47322 = env47323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47322 == env47323) = true)

theorem identity47323 : scanCanonicalize (H12AffineFastState.compose env47323 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47323 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,81,262,5441,2341,1024,80,4160,4194304,16,3,269,65,4196385,5392,4097,2341,1365,4194305,256,33,5456,513]

theorem envBound47324 : H12AffineFastState.Bounded env47324 := by
  intro p hp
  have h : env47324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47323_47324 : H12AffineEnvironment.transform 12 268 env47323 = env47324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47323 == env47324) = true)

theorem identity47324 : scanCanonicalize (H12AffineFastState.compose env47324 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound47324 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env47325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,81,262,5441,2341,1024,80,4160,33,16,3,269,65,2048,5392,4097,2341,1365,32,256,33,5456,513]

theorem envBound47325 : H12AffineFastState.Bounded env47325 := by
  intro p hp
  have h : env47325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47324_47325 : H12AffineEnvironment.transform 21 33 env47324 = env47325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env47324 == env47325) = true)

theorem identity47325 : scanCanonicalize (H12AffineFastState.compose env47325 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47325 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env47326 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5237,81,115,5172,2128,1024,80,4160,33,16,3,120,65,2048,5221,4097,2128,1056,32,117,33,5157,513]

theorem envBound47326 : H12AffineFastState.Bounded env47326 := by
  intro p hp
  have h : env47326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47325_47326 : H12AffineEnvironment.transform 7 117 env47325 = env47326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47325 == env47326) = true)

theorem identity47326 : scanCanonicalize (H12AffineFastState.compose env47326 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47326 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env47327 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,0,34,5172,2049,1024,1,4113,33,16,3,41,16,2048,5172,4097,2049,1056,32,36,33,5157,513]

theorem envBound47327 : H12AffineFastState.Bounded env47327 := by
  intro p hp
  have h : env47327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47326_47327 : H12AffineEnvironment.transform 5 17 env47326 = env47327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47326 == env47327) = true)

theorem identity47327 : scanCanonicalize (H12AffineFastState.compose env47327 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound47327 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47328 : List Nat := [2,4,8,16,32,17,9,36,512,1024,522,4096,40,5156,0,34,5172,523,1024,1,4113,33,16,3,41,16,522,5172,4097,523,1056,32,36,33,5157,513]

theorem envBound47328 : H12AffineFastState.Bounded env47328 := by
  intro p hp
  have h : env47328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47327_47328 : H12AffineEnvironment.transform 10 522 env47327 = env47328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env47327 == env47328) = true)

theorem identity47328 : scanCanonicalize (H12AffineFastState.compose env47328 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47328 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47329 : List Nat := [2,4,8,16,0,17,9,4,512,1024,522,4096,8,5124,0,2,5140,523,1024,1,4113,1,16,3,9,16,522,5140,4097,523,1024,0,4,1,5125,513]

theorem envBound47329 : H12AffineFastState.Bounded env47329 := by
  intro p hp
  have h : env47329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47328_47329 : H12AffineEnvironment.transform 4 0 env47328 = env47329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47328 == env47329) = true)

def env47330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,138340,1024,8660,4160,4194304,16,2,8328,65,4270243,79130,4096,10400,75222,4268162,256,73770,79195,513]

theorem envBound47330 : H12AffineFastState.Bounded env47330 := by
  intro p hp
  have h : env47330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47319_47330 : H12AffineEnvironment.transform 13 5377 env47319 = env47330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env47319 == env47330) = true)

theorem identity47330 : scanCanonicalize (H12AffineFastState.compose env47330 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound47330 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13389,10281,1024,8660,4160,4194304,16,2,8328,65,4270243,79130,4096,10400,75222,4268162,256,73770,79195,513]

theorem envBound47331 : H12AffineFastState.Bounded env47331 := by
  intro p hp
  have h : env47331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47330_47331 : H12AffineEnvironment.transform 16 13389 env47330 = env47331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env47330 == env47331) = true)

theorem identity47331 : scanCanonicalize (H12AffineFastState.compose env47331 (packedSelected [2,6,7,14,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound47331 : packedSelected [2,6,7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env47332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,342,13389,10281,1024,8660,4160,4194304,16,2,8328,65,4205045,13388,4096,10400,9344,4202964,256,8572,13325,513]

theorem envBound47332 : H12AffineFastState.Bounded env47332 := by
  intro p hp
  have h : env47332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47331_47332 : H12AffineEnvironment.transform 15 342 env47331 = env47332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env47331 == env47332) = true)

theorem identity47332 : scanCanonicalize (H12AffineFastState.compose env47332 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound47332 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,137,342,5393,2421,1024,136,4160,4194304,16,2,468,65,4196521,5392,4096,2556,1500,4194440,256,32,5457,513]

theorem envBound47333 : H12AffineFastState.Bounded env47333 := by
  intro p hp
  have h : env47333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47332_47333 : H12AffineEnvironment.transform 12 348 env47332 = env47333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env47332 == env47333) = true)

theorem identity47333 : scanCanonicalize (H12AffineFastState.compose env47333 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 248) := by decide +kernel

theorem selectedBound47333 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,137,342,5393,2421,1024,136,4160,248,16,2,468,65,2129,5392,4096,2556,1500,112,256,32,5457,513]

theorem envBound47334 : H12AffineFastState.Bounded env47334 := by
  intro p hp
  have h : env47334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47333_47334 : H12AffineEnvironment.transform 21 248 env47333 = env47334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 248 env47333 == env47334) = true)

theorem identity47334 : scanCanonicalize (H12AffineFastState.compose env47334 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47334 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47335 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,342,5393,2421,1024,0,4160,112,16,2,348,65,2129,5392,4096,2420,1364,112,256,32,5457,513]

theorem envBound47335 : H12AffineFastState.Bounded env47335 := by
  intro p hp
  have h : env47335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47334_47335 : H12AffineEnvironment.transform 6 8 env47334 = env47335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47334 == env47335) = true)

theorem identity47335 : scanCanonicalize (H12AffineFastState.compose env47335 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound47335 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env47336 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1280,348,1,1,342,17,2421,1024,0,1344,112,16,2,348,65,2129,16,1280,2420,1364,112,256,32,81,513]

theorem envBound47336 : H12AffineFastState.Bounded env47336 := by
  intro p hp
  have h : env47336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47335_47336 : H12AffineEnvironment.transform 11 1280 env47335 = env47336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env47335 == env47336) = true)

theorem identity47336 : scanCanonicalize (H12AffineFastState.compose env47336 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1819) := by decide +kernel

theorem selectedBound47336 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47337 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1819,1280,348,1,1,342,17,1646,1024,0,1344,112,16,2,348,65,1866,16,1280,1647,1364,112,256,32,81,513]

theorem envBound47337 : H12AffineFastState.Bounded env47337 := by
  intro p hp
  have h : env47337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47336_47337 : H12AffineEnvironment.transform 10 1819 env47336 = env47337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1819 env47336 == env47337) = true)

theorem identity47337 : scanCanonicalize (H12AffineFastState.compose env47337 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 575) := by decide +kernel

theorem selectedBound47337 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env47338 : List Nat := [2,4,8,16,32,64,8,256,512,575,292,831,348,1,1,342,17,81,575,0,895,112,16,2,348,65,373,16,831,80,875,112,256,32,81,513]

theorem envBound47338 : H12AffineFastState.Bounded env47338 := by
  intro p hp
  have h : env47338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47337_47338 : H12AffineEnvironment.transform 9 575 env47337 = env47338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 575 env47337 == env47338) = true)

theorem identity47338 : scanCanonicalize (H12AffineFastState.compose env47338 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47338 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47339 : List Nat := [2,4,8,16,32,16,8,256,512,575,292,831,268,1,1,262,17,1,575,0,815,32,16,2,268,17,293,16,831,0,827,32,256,32,1,513]

theorem envBound47339 : H12AffineFastState.Bounded env47339 := by
  intro p hp
  have h : env47339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47338_47339 : H12AffineEnvironment.transform 5 16 env47338 = env47339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47338 == env47339) = true)

theorem identity47339 : scanCanonicalize (H12AffineFastState.compose env47339 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 303) := by decide +kernel

theorem selectedBound47339 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47340 : List Nat := [2,4,8,16,32,16,8,256,303,272,292,16,268,1,1,262,17,1,272,0,0,32,16,2,268,17,293,16,16,0,20,32,256,32,1,302]

theorem envBound47340 : H12AffineFastState.Bounded env47340 := by
  intro p hp
  have h : env47340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47339_47340 : H12AffineEnvironment.transform 8 303 env47339 = env47340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 303 env47339 == env47340) = true)

theorem identity47340 : scanCanonicalize (H12AffineFastState.compose env47340 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47340 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47341 : List Nat := [2,4,8,16,32,16,8,36,11,52,0,16,40,1,1,34,17,1,52,0,0,32,16,2,40,17,1,16,16,0,20,32,36,32,1,10]

theorem envBound47341 : H12AffineFastState.Bounded env47341 := by
  intro p hp
  have h : env47341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47340_47341 : H12AffineEnvironment.transform 7 36 env47340 = env47341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47340 == env47341) = true)

theorem identity47341 : scanCanonicalize (H12AffineFastState.compose env47341 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound47341 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47342 : List Nat := [2,4,8,5,32,5,8,36,11,33,0,5,40,1,1,34,4,1,33,0,0,32,5,2,40,4,1,5,5,0,1,32,36,32,1,10]

theorem envBound47342 : H12AffineFastState.Bounded env47342 := by
  intro p hp
  have h : env47342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47341_47342 : H12AffineEnvironment.transform 3 5 env47341 = env47342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env47341 == env47342) = true)

theorem identity47342 : scanCanonicalize (H12AffineFastState.compose env47342 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound47342 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47343 : List Nat := [2,4,5,5,32,5,5,36,6,33,0,5,37,1,1,34,4,1,33,0,0,32,5,2,37,4,1,5,5,0,1,32,36,32,1,7]

theorem envBound47343 : H12AffineFastState.Bounded env47343 := by
  intro p hp
  have h : env47343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47342_47343 : H12AffineEnvironment.transform 2 5 env47342 = env47343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env47342 == env47343) = true)

theorem identity47343 : scanCanonicalize (H12AffineFastState.compose env47343 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47343 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47344 : List Nat := [2,4,5,5,1,5,5,5,6,0,0,5,4,1,1,3,4,1,0,0,0,1,5,2,4,4,1,5,5,0,1,1,5,1,1,7]

theorem envBound47344 : H12AffineFastState.Bounded env47344 := by
  intro p hp
  have h : env47344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47343_47344 : H12AffineEnvironment.transform 4 1 env47343 = env47344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47343 == env47344) = true)

def env47345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,17,21762,8328,65,4292002,115150,17665,10401,119042,4268162,256,98814,90203,63189]

theorem envBound47345 : H12AffineFastState.Bounded env47345 := by
  intro p hp
  have h : env47345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47317_47345 : H12AffineEnvironment.transform 20 4161 env47317 = env47345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env47317 == env47345) = true)

theorem identity47345 : scanCanonicalize (H12AffineFastState.compose env47345 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144613) := by decide +kernel

theorem selectedBound47345 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,144613,17,21762,8328,65,215367,115150,17665,10401,119042,201831,256,98814,90203,63189]

theorem envBound47346 : H12AffineFastState.Bounded env47346 := by
  intro p hp
  have h : env47346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47345_47346 : H12AffineEnvironment.transform 21 144613 env47345 = env47346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env47345 == env47346) = true)

def env47347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,144493,17,21762,8192,65,215367,115014,17665,10281,119042,201831,256,98678,90203,63069]

theorem envBound47347 : H12AffineFastState.Bounded env47347 := by
  intro p hp
  have h : env47347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47346_47347 : H12AffineEnvironment.transform 6 8 env47346 = env47347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47346 == env47347) = true)

theorem identity47347 : scanCanonicalize (H12AffineFastState.compose env47347 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47347 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,149860,1024,8541,4161,144493,17,21762,8192,65,215367,90138,17665,10281,94302,201831,256,73770,90203,22273]

theorem envBound47348 : H12AffineFastState.Bounded env47348 := by
  intro p hp
  have h : env47348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47347_47348 : H12AffineEnvironment.transform 14 8540 env47347 = env47348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47347 == env47348) = true)

theorem identity47348 : scanCanonicalize (H12AffineFastState.compose env47348 (packedSelected [0,7,8,9,12,14,15,18,19,20,22,23,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound47348 : packedSelected [0,7,8,9,12,14,15,18,19,20,22,23,26,28,31] rootPS < 2^1333 := by decide +kernel

def env47349 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,8540,65536,131072,138512,1024,8541,4161,144493,17,374,8192,65,204083,78958,4469,10281,74794,201831,256,73770,78895,885]

theorem envBound47349 : H12AffineFastState.Bounded env47349 := by
  intro p hp
  have h : env47349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47348_47349 : H12AffineEnvironment.transform 13 5236 env47348 = env47349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env47348 == env47349) = true)

theorem identity47349 : scanCanonicalize (H12AffineFastState.compose env47349 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound47349 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env47350 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,8232,65536,131072,138340,1024,8233,4161,144493,17,2,8192,65,203847,78958,4097,10281,74794,201831,116,73770,78895,513]

theorem envBound47350 : H12AffineFastState.Bounded env47350 := by
  intro p hp
  have h : env47350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47349_47350 : H12AffineEnvironment.transform 7 116 env47349 = env47350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env47349 == env47350) = true)

theorem identity47350 : scanCanonicalize (H12AffineFastState.compose env47350 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 78959) := by decide +kernel

theorem selectedBound47350 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env47351 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,8232,65536,78959,75787,1024,8233,4161,65538,17,2,8192,65,10280,78958,4097,10281,74794,8200,116,73770,78895,513]

theorem envBound47351 : H12AffineFastState.Bounded env47351 := by
  intro p hp
  have h : env47351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47350_47351 : H12AffineEnvironment.transform 16 78959 env47350 = env47351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78959 env47350 == env47351) = true)

theorem identity47351 : scanCanonicalize (H12AffineFastState.compose env47351 (packedSelected [11,18] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound47351 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env47352 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,4096,8192,4161,8232,65536,77914,75787,53,8233,4161,65538,17,2,8192,65,10280,77915,4097,10281,73759,8200,116,73770,77850,513]

theorem envBound47352 : H12AffineFastState.Bounded env47352 := by
  intro p hp
  have h : env47352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47351_47352 : H12AffineEnvironment.transform 9 53 env47351 = env47352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47351 == env47352) = true)

theorem identity47352 : scanCanonicalize (H12AffineFastState.compose env47352 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound47352 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env47353 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,4096,8192,4161,8232,114,12328,10361,53,8233,4161,112,17,2,8192,65,10280,12329,4097,10281,8301,8200,116,8280,12392,513]

theorem envBound47353 : H12AffineFastState.Bounded env47353 := by
  intro p hp
  have h : env47353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47352_47353 : H12AffineEnvironment.transform 15 114 env47352 = env47353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env47352 == env47353) = true)

theorem identity47353 : scanCanonicalize (H12AffineFastState.compose env47353 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47353 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47354 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,8192,4113,8232,34,12328,10281,53,8233,4113,32,17,2,8192,17,10280,12329,4097,10281,8253,8200,36,8200,12344,513]

theorem envBound47354 : H12AffineFastState.Bounded env47354 := by
  intro p hp
  have h : env47354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47353_47354 : H12AffineEnvironment.transform 5 16 env47353 = env47354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47353 == env47354) = true)

theorem identity47354 : scanCanonicalize (H12AffineFastState.compose env47354 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound47354 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env47355 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,16,8192,1,8232,34,8248,10281,53,8233,1,32,17,2,8192,17,10280,8249,17,10281,8253,8200,36,8200,8232,513]

theorem envBound47355 : H12AffineFastState.Bounded env47355 := by
  intro p hp
  have h : env47355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47354_47355 : H12AffineEnvironment.transform 11 16 env47354 = env47355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env47354 == env47355) = true)

theorem identity47355 : scanCanonicalize (H12AffineFastState.compose env47355 (packedSelected [2,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound47355 : packedSelected [2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env47356 : List Nat := [2,4,8,16,32,16,8,36,512,53,528,16,8192,1,8232,34,8248,8761,53,8233,1,32,17,2,8192,17,8760,8249,17,8761,8253,8200,36,8200,8232,513]

theorem envBound47356 : H12AffineFastState.Bounded env47356 := by
  intro p hp
  have h : env47356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47355_47356 : H12AffineEnvironment.transform 10 528 env47355 = env47356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env47355 == env47356) = true)

theorem identity47356 : scanCanonicalize (H12AffineFastState.compose env47356 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound47356 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env47357 : List Nat := [2,4,8,16,32,16,8,36,512,53,528,16,41,1,1,34,17,528,53,0,1,32,17,2,41,17,529,16,17,528,20,33,36,33,1,513]

theorem envBound47357 : H12AffineFastState.Bounded env47357 := by
  intro p hp
  have h : env47357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47356_47357 : H12AffineEnvironment.transform 12 41 env47356 = env47357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env47356 == env47357) = true)

theorem identity47357 : scanCanonicalize (H12AffineFastState.compose env47357 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47358 : List Nat := [2,4,8,16,17,16,8,21,512,4,528,16,24,1,1,19,17,528,4,0,1,17,17,2,24,17,529,16,17,528,20,16,21,16,1,513]

theorem envBound47358 : H12AffineFastState.Bounded env47358 := by
  intro p hp
  have h : env47358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47357_47358 : H12AffineEnvironment.transform 4 17 env47357 = env47358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47357 == env47358) = true)

def env47359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,144492,17,21762,8193,65,215367,115015,17665,10280,119042,201831,256,98679,90203,63068]

theorem envBound47359 : H12AffineFastState.Bounded env47359 := by
  intro p hp
  have h : env47359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47346_47359 : H12AffineEnvironment.transform 6 9 env47346 = env47359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47346 == env47359) = true)

theorem identity47359 : scanCanonicalize (H12AffineFastState.compose env47359 (packedSelected [1,3,7,8,11,12,14,15,19,20,24,26,27,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound47359 : packedSelected [1,3,7,8,11,12,14,15,19,20,24,26,27,31,32] rootPS < 2^1333 := by decide +kernel

def env47360 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33030,131072,190521,1024,32769,4161,144492,17,21762,8193,65,182337,16449,17665,10280,20484,169313,256,113,57693,63068]

theorem envBound47360 : H12AffineFastState.Bounded env47360 := by
  intro p hp
  have h : env47360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47359_47360 : H12AffineEnvironment.transform 15 33030 env47359 = env47360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env47359 == env47360) = true)

theorem identity47360 : scanCanonicalize (H12AffineFastState.compose env47360 (packedSelected [0,1,3,4,7,10,18,19,22,23,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 49217) := by decide +kernel

theorem selectedBound47360 : packedSelected [0,1,3,4,7,10,18,19,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env47361 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33030,49217,10360,1024,32769,4161,62509,17,21762,8193,65,2048,16449,17665,10280,20484,21792,256,113,57693,63068]

theorem envBound47361 : H12AffineFastState.Bounded env47361 := by
  intro p hp
  have h : env47361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47360_47361 : H12AffineEnvironment.transform 16 49217 env47360 = env47361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49217 env47360 == env47361) = true)

theorem identity47361 : scanCanonicalize (H12AffineFastState.compose env47361 (packedSelected [0,5,7,9,12,14,15,19,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound47361 : packedSelected [0,5,7,9,12,14,15,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env47362 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,21591,5392,10360,1024,21840,4161,8572,17,21762,8193,65,2048,16449,17665,10280,20484,21792,256,113,13324,8973]

theorem envBound47362 : H12AffineFastState.Bounded env47362 := by
  intro p hp
  have h : env47362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47361_47362 : H12AffineEnvironment.transform 14 21841 env47361 = env47362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env47361 == env47362) = true)

theorem identity47362 : scanCanonicalize (H12AffineFastState.compose env47362 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound47362 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env47363 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,21591,5392,2421,1024,21840,4161,113,17,21762,268,65,2048,16449,17665,2341,20484,21792,256,113,5377,512]

theorem envBound47363 : H12AffineFastState.Bounded env47363 := by
  intro p hp
  have h : env47363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47362_47363 : H12AffineEnvironment.transform 12 269 env47362 = env47363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env47362 == env47363) = true)

theorem identity47363 : scanCanonicalize (H12AffineFastState.compose env47363 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4420) := by decide +kernel

theorem selectedBound47363 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47364 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,4420,1045,1299,5392,2421,1024,1044,4161,113,17,1094,268,65,2048,4357,5189,2341,320,1124,256,113,5377,512]

theorem envBound47364 : H12AffineFastState.Bounded env47364 := by
  intro p hp
  have h : env47364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47363_47364 : H12AffineEnvironment.transform 13 4420 env47363 = env47364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4420 env47363 == env47364) = true)

theorem identity47364 : scanCanonicalize (H12AffineFastState.compose env47364 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound47364 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env47365 : List Nat := [2,4,8,16,32,64,9,256,512,305,2048,4096,269,4420,292,34,4129,2421,305,293,4161,113,17,375,268,65,2048,4357,4468,2341,320,341,256,113,4144,512]

theorem envBound47365 : H12AffineFastState.Bounded env47365 := by
  intro p hp
  have h : env47365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47364_47365 : H12AffineEnvironment.transform 9 305 env47364 = env47365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env47364 == env47365) = true)

theorem identity47365 : scanCanonicalize (H12AffineFastState.compose env47365 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47365 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env47366 : List Nat := [2,4,8,16,32,64,9,36,512,21,2048,4096,41,4192,0,34,4129,2129,21,1,4161,113,17,83,40,65,2048,4129,4176,2049,100,113,36,113,4144,512]

theorem envBound47366 : H12AffineFastState.Bounded env47366 := by
  intro p hp
  have h : env47366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47365_47366 : H12AffineEnvironment.transform 7 36 env47365 = env47366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47365 == env47366) = true)

theorem identity47366 : scanCanonicalize (H12AffineFastState.compose env47366 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound47366 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env47367 : List Nat := [2,4,8,16,32,64,9,36,512,21,2048,2064,41,2160,0,34,2097,2129,21,1,2129,113,17,83,40,65,2048,2097,2112,2049,100,113,36,113,2080,512]

theorem envBound47367 : H12AffineFastState.Bounded env47367 := by
  intro p hp
  have h : env47367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47366_47367 : H12AffineEnvironment.transform 11 2064 env47366 = env47367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env47366 == env47367) = true)

theorem identity47367 : scanCanonicalize (H12AffineFastState.compose env47367 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47367 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47368 : List Nat := [2,4,8,16,0,64,9,4,512,21,2048,2064,9,2128,0,2,2065,2129,21,1,2129,81,17,83,8,65,2048,2065,2112,2049,68,81,4,81,2048,512]

theorem envBound47368 : H12AffineFastState.Bounded env47368 := by
  intro p hp
  have h : env47368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47367_47368 : H12AffineEnvironment.transform 4 0 env47367 = env47368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47367 == env47368) = true)

theorem identity47368 : scanCanonicalize (H12AffineFastState.compose env47368 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47368 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env47369 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,2064,9,2048,0,2,2065,2049,21,1,2049,1,17,3,8,17,2048,2065,2064,2049,20,1,4,1,2048,512]

theorem envBound47369 : H12AffineFastState.Bounded env47369 := by
  intro p hp
  have h : env47369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47368_47369 : H12AffineEnvironment.transform 5 16 env47368 = env47369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47368 == env47369) = true)

theorem identity47369 : scanCanonicalize (H12AffineFastState.compose env47369 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound47369 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47370 : List Nat := [2,4,8,16,0,16,9,4,512,21,1,17,9,1,0,2,16,0,21,1,0,1,17,3,8,17,1,16,17,0,20,1,4,1,1,512]

theorem envBound47370 : H12AffineFastState.Bounded env47370 := by
  intro p hp
  have h : env47370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47369_47370 : H12AffineEnvironment.transform 10 1 env47369 = env47370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env47369 == env47370) = true)

theorem identity47370 : scanCanonicalize (H12AffineFastState.compose env47370 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound47370 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47371 : List Nat := [2,4,8,4,0,4,9,4,512,1,1,5,9,1,0,2,4,0,1,1,0,1,5,3,8,5,1,4,5,0,0,1,4,1,1,512]

theorem envBound47371 : H12AffineFastState.Bounded env47371 := by
  intro p hp
  have h : env47371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47370_47371 : H12AffineEnvironment.transform 3 4 env47370 = env47371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env47370 == env47371) = true)

theorem identity47371 : scanCanonicalize (H12AffineFastState.compose env47371 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound47371 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1