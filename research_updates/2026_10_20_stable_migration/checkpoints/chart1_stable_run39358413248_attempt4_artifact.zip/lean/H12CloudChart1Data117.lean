import H12CloudChart1Data116

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound29663 : H12AffineFastState.Bounded env29663 := by
  intro p hp
  have h : env29663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29662_29663 : H12AffineEnvironment.transform 6 8 env29662 = env29663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29662 == env29663) = true)

theorem identity29663 : scanCanonicalize (H12AffineFastState.compose env29663 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17461) := by decide +kernel

theorem selectedBound29663 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,17461,4194304,17,2,8192,64,4262262,90479,4469,2420,75102,4268415,256,74078,90415,512]

theorem envBound29664 : H12AffineFastState.Bounded env29664 := by
  intro p hp
  have h : env29664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29663_29664 : H12AffineEnvironment.transform 20 17461 env29663 = env29664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17461 env29663 == env29664) = true)

theorem identity29664 : scanCanonicalize (H12AffineFastState.compose env29664 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound29664 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env29665 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,17461,32,17,2,8192,64,67926,90479,4469,2420,75102,74079,256,74078,90415,512]

theorem envBound29665 : H12AffineFastState.Bounded env29665 := by
  intro p hp
  have h : env29665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29664_29665 : H12AffineEnvironment.transform 21 32 env29664 = env29665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env29664 == env29665) = true)

theorem identity29665 : scanCanonicalize (H12AffineFastState.compose env29665 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 19762) := by decide +kernel

theorem selectedBound29665 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env29666 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,19762,16400,10281,1024,8540,17461,32,17,2,8192,64,17508,11357,4469,2420,26732,27757,256,27756,11293,512]

theorem envBound29666 : H12AffineFastState.Bounded env29666 := by
  intro p hp
  have h : env29666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29665_29666 : H12AffineEnvironment.transform 15 19762 env29665 = env29666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19762 env29665 == env29666) = true)

theorem identity29666 : scanCanonicalize (H12AffineFastState.compose env29666 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound29666 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env29667 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5205,8541,6503,5189,10281,1024,8540,4192,32,17,2,8192,64,4145,11357,4469,2420,15417,14392,256,14393,11293,512]

theorem envBound29667 : H12AffineFastState.Bounded env29667 := by
  intro p hp
  have h : env29667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29666_29667 : H12AffineEnvironment.transform 13 5205 env29666 = env29667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env29666 == env29667) = true)

theorem identity29667 : scanCanonicalize (H12AffineFastState.compose env29667 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7212) := by decide +kernel

theorem selectedBound29667 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env29668 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7212,5205,7537,6503,5189,5125,1024,7536,4192,32,17,2,7212,64,4145,4209,4469,2420,21,1044,256,1045,4145,512]

theorem envBound29668 : H12AffineFastState.Bounded env29668 := by
  intro p hp
  have h : env29668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29667_29668 : H12AffineEnvironment.transform 12 7212 env29667 = env29668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7212 env29667 == env29668) = true)

theorem identity29668 : scanCanonicalize (H12AffineFastState.compose env29668 (packedSelected [1,2,3,4,5,6,8,9,17] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound29668 : packedSelected [1,2,3,4,5,6,8,9,17] rootPS < 2^1333 := by decide +kernel

def env29669 : List Nat := [2,4,8,16,32,64,8,256,512,21,2048,4096,6201,4160,6500,6503,4176,4112,21,6501,4192,32,17,2,6201,64,4145,4209,4469,2420,21,1,256,0,4145,512]

theorem envBound29669 : H12AffineFastState.Bounded env29669 := by
  intro p hp
  have h : env29669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29668_29669 : H12AffineEnvironment.transform 9 21 env29668 = env29669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env29668 == env29669) = true)

theorem identity29669 : scanCanonicalize (H12AffineFastState.compose env29669 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound29669 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env29670 : List Nat := [2,4,8,16,32,64,8,256,512,21,2048,2112,121,2048,292,295,2064,2128,21,293,2080,32,17,2,121,64,2161,2097,2357,2420,21,1,256,0,2161,512]

theorem envBound29670 : H12AffineFastState.Bounded env29670 := by
  intro p hp
  have h : env29670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29669_29670 : H12AffineEnvironment.transform 11 2112 env29669 = env29670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env29669 == env29670) = true)

theorem identity29670 : scanCanonicalize (H12AffineFastState.compose env29670 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29670 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env29671 : List Nat := [2,4,8,16,0,64,8,256,512,21,2048,2112,89,2048,260,263,2064,2128,21,261,2048,0,17,2,89,64,2129,2065,2325,2388,21,1,256,0,2129,512]

theorem envBound29671 : H12AffineFastState.Bounded env29671 := by
  intro p hp
  have h : env29671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29670_29671 : H12AffineEnvironment.transform 4 0 env29670 = env29671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29670 == env29671) = true)

theorem identity29671 : scanCanonicalize (H12AffineFastState.compose env29671 (packedSelected [0,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound29671 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env29672 : List Nat := [2,4,8,16,0,64,8,84,512,21,2048,2112,89,2048,80,83,2064,2128,21,81,2048,0,17,2,89,64,2129,2065,2113,2048,21,1,84,0,2129,512]

theorem envBound29672 : H12AffineFastState.Bounded env29672 := by
  intro p hp
  have h : env29672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29671_29672 : H12AffineEnvironment.transform 7 84 env29671 = env29672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env29671 == env29672) = true)

theorem identity29672 : scanCanonicalize (H12AffineFastState.compose env29672 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound29672 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29673 : List Nat := [2,4,8,16,0,64,8,84,512,21,592,528,89,592,80,83,576,512,21,81,592,0,17,2,89,64,513,577,529,592,21,1,84,0,513,512]

theorem envBound29673 : H12AffineFastState.Bounded env29673 := by
  intro p hp
  have h : env29673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29672_29673 : H12AffineEnvironment.transform 10 592 env29672 = env29673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env29672 == env29673) = true)

theorem identity29673 : scanCanonicalize (H12AffineFastState.compose env29673 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound29673 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29674 : List Nat := [2,4,8,16,0,64,8,84,80,21,0,64,89,0,80,83,16,80,21,81,0,0,17,2,89,64,81,17,65,0,21,1,84,0,81,80]

theorem envBound29674 : H12AffineFastState.Bounded env29674 := by
  intro p hp
  have h : env29674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29673_29674 : H12AffineEnvironment.transform 8 80 env29673 = env29674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env29673 == env29674) = true)

theorem identity29674 : scanCanonicalize (H12AffineFastState.compose env29674 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29674 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29675 : List Nat := [2,4,8,16,0,16,8,4,0,21,0,16,9,0,0,3,16,0,21,1,0,0,17,2,9,16,1,17,17,0,21,1,4,0,1,0]

theorem envBound29675 : H12AffineFastState.Bounded env29675 := by
  intro p hp
  have h : env29675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29674_29675 : H12AffineEnvironment.transform 5 16 env29674 = env29675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29674 == env29675) = true)

theorem identity29675 : scanCanonicalize (H12AffineFastState.compose env29675 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound29675 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29676 : List Nat := [2,4,8,15,0,15,8,4,0,10,0,15,9,0,0,3,15,0,10,1,0,0,14,2,9,15,1,14,14,0,10,1,4,0,1,0]

theorem envBound29676 : H12AffineFastState.Bounded env29676 := by
  intro p hp
  have h : env29676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29675_29676 : H12AffineEnvironment.transform 3 15 env29675 = env29676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env29675 == env29676) = true)

theorem identity29676 : scanCanonicalize (H12AffineFastState.compose env29676 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound29676 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29677 : List Nat := [2,4,6,1,0,1,6,4,0,4,0,1,7,0,0,3,1,0,4,1,0,0,0,2,7,1,1,0,0,0,4,1,4,0,1,0]

theorem envBound29677 : H12AffineFastState.Bounded env29677 := by
  intro p hp
  have h : env29677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29676_29677 : H12AffineEnvironment.transform 2 6 env29676 = env29677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env29676 == env29677) = true)

def env29678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10400,1024,8540,2097152,4194304,152,2,8328,64,4262263,2172370,2119113,2421,75223,6383042,256,2188650,2172307,513]

theorem envBound29678 : H12AffineFastState.Bounded env29678 := by
  intro p hp
  have h : env29678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29661_29678 : H12AffineEnvironment.transform 16 16401 env29661 = env29678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env29661 == env29678) = true)

def env29679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1024,8540,2097152,4194304,16,2,8192,64,4262263,2172250,2118977,2421,75103,6382922,256,2188650,2172187,513]

theorem envBound29679 : H12AffineFastState.Bounded env29679 := by
  intro p hp
  have h : env29679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29678_29679 : H12AffineEnvironment.transform 6 8 env29678 = env29679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29678 == env29679) = true)

theorem identity29679 : scanCanonicalize (H12AffineFastState.compose env29679 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound29679 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env29680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1024,8540,91466,4194304,16,2,8192,64,4262263,16400,77835,2421,75103,4194304,256,32,16465,513]

theorem envBound29680 : H12AffineFastState.Bounded env29680 := by
  intro p hp
  have h : env29680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29679_29680 : H12AffineEnvironment.transform 20 91466 env29679 = env29680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env29679 == env29680) = true)

theorem identity29680 : scanCanonicalize (H12AffineFastState.compose env29680 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound29680 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env29681 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1024,8540,91466,32,16,2,8192,64,67927,16400,77835,2421,75103,32,256,32,16465,513]

theorem envBound29681 : H12AffineFastState.Bounded env29681 := by
  intro p hp
  have h : env29681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29680_29681 : H12AffineEnvironment.transform 21 32 env29680 = env29681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env29680 == env29681) = true)

def env29682 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1024,8540,2097152,4194304,17,2,8193,64,4262263,2172251,2118976,2421,75102,6382923,256,2188650,2172186,513]

theorem envBound29682 : H12AffineFastState.Bounded env29682 := by
  intro p hp
  have h : env29682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29678_29682 : H12AffineEnvironment.transform 6 9 env29678 = env29682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29678 == env29682) = true)

theorem identity29682 : scanCanonicalize (H12AffineFastState.compose env29682 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29682 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29683 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10281,1024,8540,2097152,4194304,17,2,8193,64,4204925,2098513,2118976,2421,1364,6309185,256,2114912,2098448,513]

theorem envBound29683 : H12AffineFastState.Bounded env29683 := by
  intro p hp
  have h : env29683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29682_29683 : H12AffineEnvironment.transform 15 8202 env29682 = env29683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29682 == env29683) = true)

theorem identity29683 : scanCanonicalize (H12AffineFastState.compose env29683 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2102641) := by decide +kernel

theorem selectedBound29683 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29684 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10281,1024,8540,2097152,2102641,17,2,8193,64,2112524,2098513,2118976,2421,1364,20528,256,2114912,2098448,513]

theorem envBound29684 : H12AffineFastState.Bounded env29684 := by
  intro p hp
  have h : env29684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29683_29684 : H12AffineEnvironment.transform 21 2102641 env29683 = env29684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2102641 env29683 == env29684) = true)

theorem identity29684 : scanCanonicalize (H12AffineFastState.compose env29684 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound29684 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env29685 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,8192,16384,8541,8202,16401,10281,1024,8540,2097152,2100529,17,2,8193,64,2106444,2098513,2116864,2421,1364,18544,256,2114912,2098448,513]

theorem envBound29685 : H12AffineFastState.Bounded env29685 := by
  intro p hp
  have h : env29685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29684_29685 : H12AffineEnvironment.transform 11 2112 env29684 = env29685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env29684 == env29685) = true)

theorem identity29685 : scanCanonicalize (H12AffineFastState.compose env29685 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 3345) := by decide +kernel

theorem selectedBound29685 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,8192,16384,8541,8202,16401,10281,1024,8540,3345,32,17,2,8193,64,10589,2112,16401,2421,1364,18544,256,18545,2049,513]

theorem envBound29686 : H12AffineFastState.Bounded env29686 := by
  intro p hp
  have h : env29686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29685_29686 : H12AffineEnvironment.transform 20 3345 env29685 = env29686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3345 env29685 == env29686) = true)

theorem identity29686 : scanCanonicalize (H12AffineFastState.compose env29686 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 10588) := by decide +kernel

theorem selectedBound29686 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,8192,10588,8541,8202,10573,10281,1024,8540,3345,32,17,2,8193,64,10589,2112,10573,2421,1364,8492,256,8493,2049,513]

theorem envBound29687 : H12AffineFastState.Bounded env29687 := by
  intro p hp
  have h : env29687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29686_29687 : H12AffineEnvironment.transform 13 10588 env29686 = env29687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10588 env29686 == env29687) = true)

theorem identity29687 : scanCanonicalize (H12AffineFastState.compose env29687 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound29687 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env29688 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2112,8192,10280,8233,8202,10297,10281,1024,8232,3173,32,17,2,8193,64,10281,2112,10297,2049,1056,8280,116,8281,2049,513]

theorem envBound29688 : H12AffineFastState.Bounded env29688 := by
  intro p hp
  have h : env29688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29687_29688 : H12AffineEnvironment.transform 7 116 env29687 = env29688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env29687 == env29688) = true)

theorem identity29688 : scanCanonicalize (H12AffineFastState.compose env29688 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound29688 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env29689 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,1060,8192,9292,8233,8202,9309,9293,1024,8232,1,32,17,2,8193,64,9293,1060,9309,1125,1056,8280,116,8281,1125,513]

theorem envBound29689 : H12AffineFastState.Bounded env29689 := by
  intro p hp
  have h : env29689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29688_29689 : H12AffineEnvironment.transform 10 1124 env29688 = env29689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env29688 == env29689) = true)

theorem identity29689 : scanCanonicalize (H12AffineFastState.compose env29689 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound29689 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env29690 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,1060,121,1077,80,115,1060,1076,1024,81,1,32,17,2,120,64,1076,1060,1060,1125,1056,33,116,32,1125,513]

theorem envBound29690 : H12AffineFastState.Bounded env29690 := by
  intro p hp
  have h : env29690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29689_29690 : H12AffineEnvironment.transform 12 121 env29689 = env29690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env29689 == env29690) = true)

def env29691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound29691 : H12AffineFastState.Bounded env29691 := by
  intro p hp
  have h : env29691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29603_29691 : H12AffineEnvironment.transform 18 1025 env29603 = env29691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env29603 == env29691) = true)

theorem identity29691 : scanCanonicalize (H12AffineFastState.compose env29691 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 254082) := by decide +kernel

theorem selectedBound29691 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,254082,16777216,8328,64,21241986,18973836,2340307,336002,16934034,23160256,257,19014702,19056011,16991045]

theorem envBound29692 : H12AffineFastState.Bounded env29692 := by
  intro p hp
  have h : env29692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29691_29692 : H12AffineEnvironment.transform 22 254082 env29691 = env29692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 254082 env29691 == env29692) = true)

def env29693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,254082,16777216,8328,64,16959642,18973836,2340307,336002,16934034,19369432,257,19014702,19056011,16991045]

theorem envBound29693 : H12AffineFastState.Bounded env29693 := by
  intro p hp
  have h : env29693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29692_29693 : H12AffineEnvironment.transform 21 452632 env29692 = env29693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452632 env29692 == env29693) = true)

def env29694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,254082,243088,8328,64,97546,2240796,2340307,336002,119042,2373704,257,2199998,2191387,63189]

theorem envBound29694 : H12AffineFastState.Bounded env29694 := by
  intro p hp
  have h : env29694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29693_29694 : H12AffineEnvironment.transform 23 243088 env29693 = env29694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243088 env29693 == env29694) = true)

def env29695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,254082,243088,8328,64,97546,139612,238995,336002,119042,272392,257,98814,90203,63189]

theorem envBound29695 : H12AffineFastState.Bounded env29695 := by
  intro p hp
  have h : env29695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29694_29695 : H12AffineEnvironment.transform 20 4160 env29694 = env29695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env29694 == env29695) = true)

theorem identity29695 : scanCanonicalize (H12AffineFastState.compose env29695 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound29695 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4160,318548,120014,98780,8328,64,97546,5392,102879,336002,119042,272392,257,98814,90203,63189]

theorem envBound29696 : H12AffineFastState.Bounded env29696 := by
  intro p hp
  have h : env29696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29695_29696 : H12AffineEnvironment.transform 16 13388 env29695 = env29696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env29695 == env29696) = true)

def env29697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10400,1025,32769,4160,62708,120014,98780,8328,64,97546,5392,102879,67618,119042,168,257,98814,90203,63189]

theorem envBound29697 : H12AffineFastState.Bounded env29697 := by
  intro p hp
  have h : env29697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29696_29697 : H12AffineEnvironment.transform 17 10400 env29696 = env29697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env29696 == env29697) = true)

theorem identity29697 : scanCanonicalize (H12AffineFastState.compose env29697 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(15+1) ^^^ 62590) := by decide +kernel

theorem selectedBound29697 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env29698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62590,13388,10400,1025,32769,4160,62708,8368,30114,8328,64,35188,5392,26017,64604,9596,168,257,30080,37925,63189]

theorem envBound29698 : H12AffineFastState.Bounded env29698 := by
  intro p hp
  have h : env29698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29697_29698 : H12AffineEnvironment.transform 15 62590 env29697 = env29698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62590 env29697 == env29698) = true)

theorem identity29698 : scanCanonicalize (H12AffineFastState.compose env29698 (packedSelected [0,2,6,7,14,16,23,32,35] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound29698 : packedSelected [0,2,6,7,14,16,23,32,35] rootPS < 2^1333 := by decide +kernel

def env29699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,32768,41090,13388,10400,1025,32769,4160,40968,8368,8542,8328,64,35188,5392,12637,43168,9596,168,257,8572,37925,41513]

theorem envBound29699 : H12AffineFastState.Bounded env29699 := by
  intro p hp
  have h : env29699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29698_29699 : H12AffineEnvironment.transform 13 5372 env29698 = env29699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env29698 == env29699) = true)

theorem identity29699 : scanCanonicalize (H12AffineFastState.compose env29699 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound29699 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env29700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,0,8322,13388,10400,1025,1,4160,8200,8368,8542,8328,64,2420,5392,12637,10400,9596,168,257,8572,5157,8745]

theorem envBound29700 : H12AffineFastState.Bounded env29700 := by
  intro p hp
  have h : env29700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29699_29700 : H12AffineEnvironment.transform 14 0 env29699 = env29700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env29699 == env29700) = true)

theorem identity29700 : scanCanonicalize (H12AffineFastState.compose env29700 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound29700 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env29701 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,5372,0,8322,13388,10400,1025,1,4160,8200,8368,8234,8328,64,2048,5220,12329,10400,9224,168,117,8200,5157,8745]

theorem envBound29701 : H12AffineFastState.Bounded env29701 := by
  intro p hp
  have h : env29701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29700_29701 : H12AffineEnvironment.transform 7 116 env29700 = env29701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env29700 == env29701) = true)

def env29702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10401,1025,32769,4160,62709,120014,98780,8328,64,97546,5392,102879,67619,119042,169,257,98814,90203,63189]

theorem envBound29702 : H12AffineFastState.Bounded env29702 := by
  intro p hp
  have h : env29702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29696_29702 : H12AffineEnvironment.transform 17 10401 env29696 = env29702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env29696 == env29702) = true)

theorem identity29702 : scanCanonicalize (H12AffineFastState.compose env29702 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound29702 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env29703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,65536,13388,10401,1025,137,4160,29821,87110,65876,8328,64,97546,5392,69975,67619,86410,169,257,65910,90203,30301]

theorem envBound29703 : H12AffineFastState.Bounded env29703 := by
  intro p hp
  have h : env29703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29702_29703 : H12AffineEnvironment.transform 14 136 env29702 = env29703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env29702 == env29703) = true)

theorem identity29703 : scanCanonicalize (H12AffineFastState.compose env29703 (packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound29703 : packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS < 2^1333 := by decide +kernel

def env29704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,136,65536,5529,2420,1025,137,4160,21928,87110,65876,349,64,89311,5392,69975,67619,86410,169,257,65910,82318,22408]

theorem envBound29704 : H12AffineFastState.Bounded env29704 := by
  intro p hp
  have h : env29704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29703_29704 : H12AffineEnvironment.transform 12 469 env29703 = env29704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env29703 == env29704) = true)

theorem identity29704 : scanCanonicalize (H12AffineFastState.compose env29704 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29704 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,136,65536,5529,2420,1025,137,4160,168,65862,65876,349,64,68063,5392,69975,67619,66698,169,257,65910,70798,648]

theorem envBound29705 : H12AffineFastState.Bounded env29705 := by
  intro p hp
  have h : env29705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29704_29705 : H12AffineEnvironment.transform 13 5376 env29704 = env29705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29704 == env29705) = true)

theorem identity29705 : scanCanonicalize (H12AffineFastState.compose env29705 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound29705 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,136,262,5529,2420,1025,137,4160,168,64,82,349,64,2265,5392,4177,2341,1420,169,257,112,5512,648]

theorem envBound29706 : H12AffineFastState.Bounded env29706 := by
  intro p hp
  have h : env29706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29705_29706 : H12AffineEnvironment.transform 15 262 env29705 = env29706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env29705 == env29706) = true)

theorem identity29706 : scanCanonicalize (H12AffineFastState.compose env29706 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29706 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env29707 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,262,5392,2420,1025,0,4160,33,64,82,349,64,2128,5392,4177,2341,1285,32,257,112,5377,513]

theorem envBound29707 : H12AffineFastState.Bounded env29707 := by
  intro p hp
  have h : env29707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29706_29707 : H12AffineEnvironment.transform 6 9 env29706 = env29707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29706 == env29707) = true)

theorem identity29707 : scanCanonicalize (H12AffineFastState.compose env29707 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29707 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env29708 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,1,262,5392,2341,1025,0,4113,33,17,3,268,17,2049,5392,4096,2341,1285,32,257,33,5377,513]

theorem envBound29708 : H12AffineFastState.Bounded env29708 := by
  intro p hp
  have h : env29708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29707_29708 : H12AffineEnvironment.transform 5 17 env29707 = env29708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29707 == env29708) = true)

theorem identity29708 : scanCanonicalize (H12AffineFastState.compose env29708 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound29708 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29709 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,276,269,1044,1,262,1028,2341,1025,0,261,33,17,3,268,17,2049,1028,276,2341,1285,32,257,33,1045,513]

theorem envBound29709 : H12AffineFastState.Bounded env29709 := by
  intro p hp
  have h : env29709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29708_29709 : H12AffineEnvironment.transform 11 276 env29708 = env29709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env29708 == env29709) = true)

theorem identity29709 : scanCanonicalize (H12AffineFastState.compose env29709 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound29709 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29710 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,276,269,292,1,262,308,2341,305,0,261,33,17,3,268,17,2049,308,276,2341,53,32,257,33,293,513]

theorem envBound29710 : H12AffineFastState.Bounded env29710 := by
  intro p hp
  have h : env29710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29709_29710 : H12AffineEnvironment.transform 9 304 env29709 = env29710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env29709 == env29710) = true)

theorem identity29710 : scanCanonicalize (H12AffineFastState.compose env29710 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound29710 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29711 : List Nat := [2,4,8,16,32,17,9,256,292,304,2048,276,269,292,1,262,308,2341,305,0,261,33,17,3,268,17,2049,308,276,2341,53,32,257,33,293,293]

theorem envBound29711 : H12AffineFastState.Bounded env29711 := by
  intro p hp
  have h : env29711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29710_29711 : H12AffineEnvironment.transform 8 292 env29710 = env29711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env29710 == env29711) = true)

theorem identity29711 : scanCanonicalize (H12AffineFastState.compose env29711 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29711 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29712 : List Nat := [2,4,8,16,16,17,9,256,276,256,2048,276,269,276,1,262,260,2325,257,0,261,17,17,3,268,17,2049,260,276,2325,5,16,257,17,277,277]

theorem envBound29712 : H12AffineFastState.Bounded env29712 := by
  intro p hp
  have h : env29712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29711_29712 : H12AffineEnvironment.transform 4 16 env29711 = env29712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29711 == env29712) = true)

theorem identity29712 : scanCanonicalize (H12AffineFastState.compose env29712 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound29712 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29713 : List Nat := [2,4,8,16,16,17,9,256,276,256,16,276,269,276,1,262,260,261,257,0,261,17,17,3,268,17,17,260,276,261,5,16,257,17,277,277]

theorem envBound29713 : H12AffineFastState.Bounded env29713 := by
  intro p hp
  have h : env29713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29712_29713 : H12AffineEnvironment.transform 10 16 env29712 = env29713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env29712 == env29713) = true)

def env29714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,254082,243088,8328,64,97546,139613,238994,336002,119042,272393,257,98815,90202,63189]

theorem envBound29714 : H12AffineFastState.Bounded env29714 := by
  intro p hp
  have h : env29714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29694_29714 : H12AffineEnvironment.transform 20 4161 env29694 = env29714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env29694 == env29714) = true)

theorem identity29714 : scanCanonicalize (H12AffineFastState.compose env29714 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound29714 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4161,400588,201814,213316,8328,64,97546,139613,217414,336002,75222,272393,257,95531,90202,513]

theorem envBound29715 : H12AffineFastState.Bounded env29715 := by
  intro p hp
  have h : env29715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29714_29715 : H12AffineEnvironment.transform 14 29908 env29714 = env29715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env29714 == env29715) = true)

def env29716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4161,400452,201814,213316,8192,64,97546,139613,217414,335882,75102,272393,257,95531,90202,513]

theorem envBound29716 : H12AffineFastState.Bounded env29716 := by
  intro p hp
  have h : env29716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29715_29716 : H12AffineEnvironment.transform 6 8 env29715 = env29716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29715 == env29716) = true)

theorem identity29716 : scanCanonicalize (H12AffineFastState.compose env29716 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound29716 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1025,29789,4161,359519,29773,8543,8192,64,97546,82246,12637,335882,75102,272393,257,95531,90202,513]

theorem envBound29717 : H12AffineFastState.Bounded env29717 := by
  intro p hp
  have h : env29717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29716_29717 : H12AffineEnvironment.transform 16 90139 env29716 = env29717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env29716 == env29717) = true)

theorem identity29717 : scanCanonicalize (H12AffineFastState.compose env29717 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 76911) := by decide +kernel

theorem selectedBound29717 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,76911,1025,29789,4161,20528,29773,8543,8192,64,97546,82246,12637,3173,75102,66662,257,95531,90202,513]

theorem envBound29718 : H12AffineFastState.Bounded env29718 := by
  intro p hp
  have h : env29718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29717_29718 : H12AffineEnvironment.transform 17 76911 env29717 = env29718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76911 env29717 == env29718) = true)

theorem identity29718 : scanCanonicalize (H12AffineFastState.compose env29718 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29718 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,16401,3173,1025,29789,4161,20528,29773,8543,8192,64,23808,24908,12637,3173,1364,9324,257,21793,16464,513]

theorem envBound29719 : H12AffineFastState.Bounded env29719 := by
  intro p hp
  have h : env29719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29718_29719 : H12AffineEnvironment.transform 15 8202 env29718 = env29719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29718 == env29719) = true)

theorem identity29719 : scanCanonicalize (H12AffineFastState.compose env29719 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29719 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env29720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,5393,3173,1025,8541,4161,1328,8525,8543,8192,64,2048,13388,12637,3173,1364,9324,257,33,5456,513]

theorem envBound29720 : H12AffineFastState.Bounded env29720 := by
  intro p hp
  have h : env29720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29719_29720 : H12AffineEnvironment.transform 13 5376 env29719 = env29720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29719 == env29720) = true)

theorem identity29720 : scanCanonicalize (H12AffineFastState.compose env29720 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound29720 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5376,1297,1095,5393,3173,1025,1296,4161,1328,1280,1298,1101,64,2048,4097,5392,3173,1364,33,257,33,5456,513]

theorem envBound29721 : H12AffineFastState.Bounded env29721 := by
  intro p hp
  have h : env29721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29720_29721 : H12AffineEnvironment.transform 12 1101 env29720 = env29721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env29720 == env29721) = true)

theorem identity29721 : scanCanonicalize (H12AffineFastState.compose env29721 (packedSelected [2,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound29721 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env29722 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1361,1101,81,1297,1095,64,3173,1025,1296,1296,1328,1280,1298,1101,64,2048,1360,65,3173,1364,33,257,33,1,513]

theorem envBound29722 : H12AffineFastState.Bounded env29722 := by
  intro p hp
  have h : env29722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29721_29722 : H12AffineEnvironment.transform 11 1361 env29721 = env29722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env29721 == env29722) = true)

theorem identity29722 : scanCanonicalize (H12AffineFastState.compose env29722 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29722 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env29723 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1141,1101,81,1077,1095,64,3173,1025,1076,1076,1044,1060,1078,1101,64,2048,1140,65,3173,1136,33,37,33,1,513]

theorem envBound29723 : H12AffineFastState.Bounded env29723 := by
  intro p hp
  have h : env29723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29722_29723 : H12AffineEnvironment.transform 7 36 env29722 = env29723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29722 == env29723) = true)

theorem identity29723 : scanCanonicalize (H12AffineFastState.compose env29723 (packedSelected [2,6,12] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound29723 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env29724 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1077,1141,1101,81,1077,1095,64,80,1025,1076,1076,1044,1060,1078,1101,64,1077,1140,65,80,1136,33,37,33,1,513]

theorem envBound29724 : H12AffineFastState.Bounded env29724 := by
  intro p hp
  have h : env29724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29723_29724 : H12AffineEnvironment.transform 10 1077 env29723 = env29724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env29723 == env29724) = true)

theorem identity29724 : scanCanonicalize (H12AffineFastState.compose env29724 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound29724 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env29725 : List Nat := [2,4,8,16,32,64,8,36,512,52,1,65,121,81,1,115,64,80,53,0,0,32,16,2,121,64,1,64,65,80,68,33,37,33,1,513]

theorem envBound29725 : H12AffineFastState.Bounded env29725 := by
  intro p hp
  have h : env29725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29724_29725 : H12AffineEnvironment.transform 9 52 env29724 = env29725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env29724 == env29725) = true)

def env29726 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4161,400453,201814,213316,8193,64,97546,139613,217414,335883,75103,272393,257,95531,90202,513]

theorem envBound29726 : H12AffineFastState.Bounded env29726 := by
  intro p hp
  have h : env29726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29715_29726 : H12AffineEnvironment.transform 6 9 env29715 = env29726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29715 == env29726) = true)

theorem identity29726 : scanCanonicalize (H12AffineFastState.compose env29726 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound29726 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32040,1025,29788,4161,156013,201814,213316,8193,64,97546,139613,217414,89379,75103,21793,257,95531,90202,513]

theorem envBound29727 : H12AffineFastState.Bounded env29727 := by
  intro p hp
  have h : env29727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29726_29727 : H12AffineEnvironment.transform 17 32040 env29726 = env29727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env29726 == env29727) = true)

theorem identity29727 : scanCanonicalize (H12AffineFastState.compose env29727 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29727 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env29728 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,65536,131072,23668,1025,21760,4161,147505,201814,213316,349,64,89174,131073,217414,89379,66563,21793,257,87159,82182,513]

theorem envBound29728 : H12AffineFastState.Bounded env29728 := by
  intro p hp
  have h : env29728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29727_29728 : H12AffineEnvironment.transform 12 348 env29727 = env29728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29727 == env29728) = true)

theorem identity29728 : scanCanonicalize (H12AffineFastState.compose env29728 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound29728 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29729 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,342,131072,23668,1025,21760,4161,147505,136448,147474,349,64,23808,131073,151568,23669,1365,21793,257,21793,16464,513]

theorem envBound29729 : H12AffineFastState.Bounded env29729 := by
  intro p hp
  have h : env29729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29728_29729 : H12AffineEnvironment.transform 15 342 env29728 = env29729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env29728 == env29729) = true)

theorem identity29729 : scanCanonicalize (H12AffineFastState.compose env29729 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29729 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29730 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21761,262,131072,23588,1025,21760,4113,147505,136448,147474,269,16,23808,131073,151568,23589,1285,21793,257,21793,16384,513]

theorem envBound29730 : H12AffineFastState.Bounded env29730 := by
  intro p hp
  have h : env29730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29729_29730 : H12AffineEnvironment.transform 5 16 env29729 = env29730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29729 == env29730) = true)

theorem identity29730 : scanCanonicalize (H12AffineFastState.compose env29730 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29730 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29731 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,262,131072,2340,1025,0,4113,136497,136448,136466,269,16,2048,131073,132368,2341,1285,33,257,33,5376,513]

theorem envBound29731 : H12AffineFastState.Bounded env29731 := by
  intro p hp
  have h : env29731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29730_29731 : H12AffineEnvironment.transform 13 5376 env29730 = env29731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29730 == env29731) = true)

theorem identity29731 : scanCanonicalize (H12AffineFastState.compose env29731 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound29731 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env29732 : List Nat := [2,4,8,16,32,16,9,256,512,1024,309,4096,268,5376,1,262,131072,17,1025,0,4113,136497,136448,136466,269,16,309,131073,132368,16,1285,33,257,33,5376,513]

theorem envBound29732 : H12AffineFastState.Bounded env29732 := by
  intro p hp
  have h : env29732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29731_29732 : H12AffineEnvironment.transform 10 309 env29731 = env29732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env29731 == env29732) = true)

theorem identity29732 : scanCanonicalize (H12AffineFastState.compose env29732 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 1077) := by decide +kernel

theorem selectedBound29732 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29733 : List Nat := [2,4,8,16,32,16,9,256,512,1024,309,4096,268,5376,1,262,1077,17,1025,0,4113,4356,4405,4391,269,16,309,1076,293,16,1285,33,257,33,5376,513]

theorem envBound29733 : H12AffineFastState.Bounded env29733 := by
  intro p hp
  have h : env29733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29732_29733 : H12AffineEnvironment.transform 16 1077 env29732 = env29733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1077 env29732 == env29733) = true)

def env29734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,254082,243089,8328,64,97547,2240797,2340307,336002,119043,2373705,257,2199999,2191386,63188]

theorem envBound29734 : H12AffineFastState.Bounded env29734 := by
  intro p hp
  have h : env29734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29693_29734 : H12AffineEnvironment.transform 23 243089 env29693 = env29734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243089 env29693 == env29734) = true)

def env29735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,254082,243089,8328,64,97547,139613,238995,336002,119043,272393,257,98815,90202,63188]

theorem envBound29735 : H12AffineFastState.Bounded env29735 := by
  intro p hp
  have h : env29735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29734_29735 : H12AffineEnvironment.transform 20 4160 env29734 = env29735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env29734 == env29735) = true)

def env29736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4160,180408,254082,243089,8328,64,97547,139613,238995,67618,119043,169,257,98815,90202,63188]

theorem envBound29736 : H12AffineFastState.Bounded env29736 := by
  intro p hp
  have h : env29736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29735_29736 : H12AffineEnvironment.transform 17 10400 env29735 = env29736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env29735 == env29736) = true)

def env29737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,180272,253962,242969,8192,64,97547,139613,238875,67618,119043,33,257,98679,90202,63068]

theorem envBound29737 : H12AffineFastState.Bounded env29737 := by
  intro p hp
  have h : env29737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29736_29737 : H12AffineEnvironment.transform 6 8 env29736 = env29737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29736 == env29737) = true)

theorem identity29737 : scanCanonicalize (H12AffineFastState.compose env29737 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound29737 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10280,1025,32769,4160,95531,21777,2,8192,64,97547,103494,4096,67618,119043,33,257,98679,90202,63068]

theorem envBound29738 : H12AffineFastState.Bounded env29738 := by
  intro p hp
  have h : env29738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29737_29738 : H12AffineEnvironment.transform 16 111899 env29737 = env29738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env29737 == env29738) = true)

theorem identity29738 : scanCanonicalize (H12AffineFastState.compose env29738 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound29738 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env29739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,103494,2421,1025,32769,4160,87158,21777,2,349,64,89174,103494,4096,67618,119043,33,257,98679,82183,55041]

theorem envBound29739 : H12AffineFastState.Bounded env29739 := by
  intro p hp
  have h : env29739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29738_29739 : H12AffineEnvironment.transform 12 349 env29738 = env29739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env29738 == env29739) = true)

theorem identity29739 : scanCanonicalize (H12AffineFastState.compose env29739 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound29739 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,343,38161,2421,1025,32769,4160,21793,21777,2,349,64,23809,38161,4096,2421,53332,33,257,32800,16464,55041]

theorem envBound29740 : H12AffineFastState.Bounded env29740 := by
  intro p hp
  have h : env29740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29739_29740 : H12AffineEnvironment.transform 15 343 env29739 = env29740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env29739 == env29740) = true)

theorem identity29740 : scanCanonicalize (H12AffineFastState.compose env29740 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound29740 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env29741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,81,343,5440,2421,1025,80,4160,21793,21777,2,349,64,23809,5440,4096,2421,20485,33,257,113,16464,22352]

theorem envBound29741 : H12AffineFastState.Bounded env29741 := by
  intro p hp
  have h : env29741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29740_29741 : H12AffineEnvironment.transform 14 81 env29740 = env29741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env29740 == env29741) = true)

theorem identity29741 : scanCanonicalize (H12AffineFastState.compose env29741 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29741 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29742 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,120,16384,81,114,5221,2128,1025,80,4160,21508,21556,2,120,64,23588,5221,4096,2128,20485,33,36,113,16464,22133]

theorem envBound29742 : H12AffineFastState.Bounded env29742 := by
  intro p hp
  have h : env29742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29741_29742 : H12AffineEnvironment.transform 7 37 env29741 = env29742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29741 == env29742) = true)

theorem identity29742 : scanCanonicalize (H12AffineFastState.compose env29742 (packedSelected [3,5,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 3124) := by decide +kernel

theorem selectedBound29742 : packedSelected [3,5,11,12,14] rootPS < 2^1333 := by decide +kernel

def env29743 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,120,3124,81,114,5221,2128,1025,80,4160,6192,6144,2,120,64,4112,5221,4096,2128,7217,33,36,113,3172,6721]

theorem envBound29743 : H12AffineFastState.Bounded env29743 := by
  intro p hp
  have h : env29743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29742_29743 : H12AffineEnvironment.transform 13 3124 env29742 = env29743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3124 env29742 == env29743) = true)

theorem identity29743 : scanCanonicalize (H12AffineFastState.compose env29743 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29743 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env29744 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,3124,0,35,5172,2049,1025,1,4113,6192,6144,2,41,17,4112,5172,4096,2049,7217,33,36,32,3125,6672]

theorem envBound29744 : H12AffineFastState.Bounded env29744 := by
  intro p hp
  have h : env29744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29743_29744 : H12AffineEnvironment.transform 5 17 env29743 = env29744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29743 == env29744) = true)

theorem identity29744 : scanCanonicalize (H12AffineFastState.compose env29744 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound29744 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env29745 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,2064,41,3124,0,35,3108,2049,1025,1,2049,32,16,2,41,17,2048,3108,2064,2049,1057,33,36,32,3125,512]

theorem envBound29745 : H12AffineFastState.Bounded env29745 := by
  intro p hp
  have h : env29745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29744_29745 : H12AffineEnvironment.transform 11 2064 env29744 = env29745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env29744 == env29745) = true)

theorem identity29745 : scanCanonicalize (H12AffineFastState.compose env29745 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound29745 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29746 : List Nat := [2,4,8,16,32,17,8,37,512,20,2048,2064,41,2080,0,35,2096,2049,21,1,2049,32,16,2,41,17,2048,2096,2064,2049,53,33,36,32,2081,512]

theorem envBound29746 : H12AffineFastState.Bounded env29746 := by
  intro p hp
  have h : env29746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29745_29746 : H12AffineEnvironment.transform 9 20 env29745 = env29746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env29745 == env29746) = true)

theorem identity29746 : scanCanonicalize (H12AffineFastState.compose env29746 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29746 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29747 : List Nat := [2,4,8,16,1,17,8,4,512,20,2048,2064,8,2049,0,2,2065,2049,21,1,2049,1,16,2,8,17,2048,2065,2064,2049,20,0,5,1,2048,512]

theorem envBound29747 : H12AffineFastState.Bounded env29747 := by
  intro p hp
  have h : env29747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29746_29747 : H12AffineEnvironment.transform 4 1 env29746 = env29747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29746 == env29747) = true)

theorem identity29747 : scanCanonicalize (H12AffineFastState.compose env29747 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound29747 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29748 : List Nat := [2,4,8,16,1,17,8,4,0,20,2048,2064,8,2049,0,2,2065,2049,21,1,2049,1,16,2,8,17,2048,2065,2064,2049,20,0,5,1,2048,0]

theorem envBound29748 : H12AffineFastState.Bounded env29748 := by
  intro p hp
  have h : env29748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29747_29748 : H12AffineEnvironment.transform 8 0 env29747 = env29748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env29747 == env29748) = true)

theorem identity29748 : scanCanonicalize (H12AffineFastState.compose env29748 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound29748 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29749 : List Nat := [2,1,8,16,1,17,8,1,0,17,2048,2064,8,2049,0,2,2065,2049,16,1,2049,1,16,2,8,17,2048,2065,2064,2049,17,0,0,1,2048,0]

theorem envBound29749 : H12AffineFastState.Bounded env29749 := by
  intro p hp
  have h : env29749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29748_29749 : H12AffineEnvironment.transform 1 1 env29748 = env29749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env29748 == env29749) = true)

def env29750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,180273,253963,242968,8193,64,97547,139613,238874,67618,119043,32,257,98678,90202,63069]

theorem envBound29750 : H12AffineFastState.Bounded env29750 := by
  intro p hp
  have h : env29750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29736_29750 : H12AffineEnvironment.transform 6 9 env29736 = env29750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29736 == env29750) = true)

theorem identity29750 : scanCanonicalize (H12AffineFastState.compose env29750 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound29750 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10281,1025,32769,4160,119926,62540,41311,8193,64,97547,79130,45405,67618,119043,32,257,98678,90202,63069]

theorem envBound29751 : H12AffineFastState.Bounded env29751 := by
  intro p hp
  have h : env29751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29750_29751 : H12AffineEnvironment.transform 16 70727 env29750 = env29751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env29750 == env29751) = true)

theorem identity29751 : scanCanonicalize (H12AffineFastState.compose env29751 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound29751 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env29752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,70727,10281,1025,29789,4160,73770,16,21763,8193,64,97547,79130,17665,67618,75103,32,257,95530,90202,513]

theorem envBound29752 : H12AffineFastState.Bounded env29752 := by
  intro p hp
  have h : env29752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29751_29752 : H12AffineEnvironment.transform 14 29788 env29751 = env29752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env29751 == env29752) = true)

theorem identity29752 : scanCanonicalize (H12AffineFastState.compose env29752 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 16646) := by decide +kernel

theorem selectedBound29752 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env29753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,16646,21825,10281,1025,29789,4160,24876,16,21763,8193,64,15373,29724,17665,18724,25689,32,257,13356,8540,513]

theorem envBound29753 : H12AffineFastState.Bounded env29753 := by
  intro p hp
  have h : env29753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29752_29753 : H12AffineEnvironment.transform 15 16646 env29752 = env29753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 16646 env29752 == env29753) = true)

theorem identity29753 : scanCanonicalize (H12AffineFastState.compose env29753 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound29753 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env29754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,13658,8477,10281,1025,1,4160,5488,16,8543,8193,64,15373,64,12637,15736,4101,32,257,13356,8540,513]

theorem envBound29754 : H12AffineFastState.Bounded env29754 := by
  intro p hp
  have h : env29754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29753_29754 : H12AffineEnvironment.transform 13 13404 env29753 = env29754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env29753 == env29754) = true)

theorem identity29754 : scanCanonicalize (H12AffineFastState.compose env29754 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 5132) := by decide +kernel

theorem selectedBound29754 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env29755 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5132,80,0,342,5393,7205,1025,1,4160,5488,16,5459,5133,64,2049,64,1361,2420,4101,32,257,32,5456,513]

theorem envBound29755 : H12AffineFastState.Bounded env29755 := by
  intro p hp
  have h : env29755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29754_29755 : H12AffineEnvironment.transform 12 5132 env29754 = env29755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5132 env29754 == env29755) = true)

theorem identity29755 : scanCanonicalize (H12AffineFastState.compose env29755 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound29755 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29756 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1280,268,80,0,342,17,2341,1025,1,1344,112,16,83,269,64,2049,64,1361,2420,1285,32,257,32,80,513]

theorem envBound29756 : H12AffineFastState.Bounded env29756 := by
  intro p hp
  have h : env29756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29755_29756 : H12AffineEnvironment.transform 11 1280 env29755 = env29756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env29755 == env29756) = true)

def env29757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4160,180409,254082,243089,8328,64,97547,139613,238995,67619,119043,168,257,98815,90202,63188]

theorem envBound29757 : H12AffineFastState.Bounded env29757 := by
  intro p hp
  have h : env29757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29735_29757 : H12AffineEnvironment.transform 17 10401 env29735 = env29757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env29735 == env29757) = true)

def env29758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,180273,253962,242969,8192,64,97547,139613,238875,67619,119043,32,257,98679,90202,63068]

theorem envBound29758 : H12AffineFastState.Bounded env29758 := by
  intro p hp
  have h : env29758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29757_29758 : H12AffineEnvironment.transform 6 8 env29757 = env29758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29757 == env29758) = true)

theorem identity29758 : scanCanonicalize (H12AffineFastState.compose env29758 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29758 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1025,32769,4160,169264,242955,242969,8192,64,75786,139613,238875,67619,99330,32,257,98679,79195,41821]

theorem envBound29759 : H12AffineFastState.Bounded env29759 := by
  intro p hp
  have h : env29759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29758_29759 : H12AffineEnvironment.transform 13 5377 env29758 = env29759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29758 == env29759) = true)

theorem identity29759 : scanCanonicalize (H12AffineFastState.compose env29759 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 110603) := by decide +kernel

theorem selectedBound29759 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env29760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,110603,10281,1025,32769,4160,75067,1280,1298,8192,64,75786,102742,5392,67619,99330,32,257,98679,79195,41821]

theorem envBound29760 : H12AffineFastState.Bounded env29760 := by
  intro p hp
  have h : env29760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29759_29760 : H12AffineEnvironment.transform 16 110603 env29759 = env29760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 110603 env29759 == env29760) = true)

theorem identity29760 : scanCanonicalize (H12AffineFastState.compose env29760 (packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29760 : packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env29761 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,69975,10281,1025,8541,4160,75067,1280,1298,8192,64,75786,77834,5392,67619,75102,32,257,73771,79195,513]

theorem envBound29761 : H12AffineFastState.Bounded env29761 := by
  intro p hp
  have h : env29761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29760_29761 : H12AffineEnvironment.transform 14 8540 env29760 = env29761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29760 == env29761) = true)

theorem identity29761 : scanCanonicalize (H12AffineFastState.compose env29761 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 6194) := by decide +kernel

theorem selectedBound29761 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env29762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,6194,2405,10281,1025,8541,4160,15625,1280,1298,8192,64,12344,10296,5392,4113,15724,32,257,14361,11625,513]

theorem envBound29762 : H12AffineFastState.Bounded env29762 := by
  intro p hp
  have h : env29762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29761_29762 : H12AffineEnvironment.transform 15 6194 env29761 = env29762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6194 env29761 == env29762) = true)

theorem identity29762 : scanCanonicalize (H12AffineFastState.compose env29762 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 6201) := by decide +kernel

theorem selectedBound29762 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env29763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6201,5377,6501,6194,2405,4112,1025,6500,4160,1328,1280,1298,6201,64,2049,4097,5392,4113,1365,32,257,32,5456,513]

theorem envBound29763 : H12AffineFastState.Bounded env29763 := by
  intro p hp
  have h : env29763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29762_29763 : H12AffineEnvironment.transform 12 6201 env29762 = env29763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6201 env29762 == env29763) = true)

theorem identity29763 : scanCanonicalize (H12AffineFastState.compose env29763 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound29763 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env29764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,357,2396,1124,2048,2391,2405,373,1025,2049,293,1328,1280,1298,2396,64,2049,356,1141,372,1365,32,257,32,1077,513]

theorem envBound29764 : H12AffineFastState.Bounded env29764 := by
  intro p hp
  have h : env29764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29763_29764 : H12AffineEnvironment.transform 11 357 env29763 = env29764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env29763 == env29764) = true)

theorem identity29764 : scanCanonicalize (H12AffineFastState.compose env29764 (packedSelected [2,6,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29764 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env29765 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,16,2089,1124,2048,2082,2064,0,1025,2049,80,1093,1141,1127,2089,64,2049,17,1141,1,1056,32,116,32,1077,513]

theorem envBound29765 : H12AffineFastState.Bounded env29765 := by
  intro p hp
  have h : env29765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29764_29765 : H12AffineEnvironment.transform 7 117 env29764 = env29765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29764 == env29765) = true)

theorem identity29765 : scanCanonicalize (H12AffineFastState.compose env29765 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound29765 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env29766 : List Nat := [2,4,8,16,32,64,8,117,512,1024,81,16,120,1124,81,115,65,0,1025,80,80,1093,1141,1127,120,64,80,17,1141,1,1056,32,116,32,1077,513]

theorem envBound29766 : H12AffineFastState.Bounded env29766 := by
  intro p hp
  have h : env29766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29765_29766 : H12AffineEnvironment.transform 10 81 env29765 = env29766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env29765 == env29766) = true)

theorem identity29766 : scanCanonicalize (H12AffineFastState.compose env29766 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29766 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29767 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1,16,40,1076,1,35,17,0,1025,0,0,1045,1061,1079,40,16,0,17,1061,1,1056,32,36,32,1077,513]

theorem envBound29767 : H12AffineFastState.Bounded env29767 := by
  intro p hp
  have h : env29767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29766_29767 : H12AffineEnvironment.transform 5 16 env29766 = env29767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29766 == env29767) = true)

theorem identity29767 : scanCanonicalize (H12AffineFastState.compose env29767 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound29767 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29768 : List Nat := [2,4,8,16,32,16,8,37,512,36,1,16,40,16,1,35,17,0,37,0,0,49,1,19,40,16,0,17,1,1,4,32,36,32,17,513]

theorem envBound29768 : H12AffineFastState.Bounded env29768 := by
  intro p hp
  have h : env29768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29767_29768 : H12AffineEnvironment.transform 9 36 env29767 = env29768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env29767 == env29768) = true)

theorem identity29768 : scanCanonicalize (H12AffineFastState.compose env29768 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29768 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env29769 : List Nat := [2,4,8,1,32,1,8,37,512,36,1,1,40,1,1,35,0,0,37,0,0,32,1,2,40,1,0,0,1,1,4,32,36,32,0,513]

theorem envBound29769 : H12AffineFastState.Bounded env29769 := by
  intro p hp
  have h : env29769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29768_29769 : H12AffineEnvironment.transform 3 1 env29768 = env29769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29768 == env29769) = true)

theorem identity29769 : scanCanonicalize (H12AffineFastState.compose env29769 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29769 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29770 : List Nat := [2,4,8,1,1,1,8,4,512,5,1,1,9,1,1,2,0,0,4,0,0,1,1,2,9,1,0,0,1,1,4,1,5,1,0,513]

theorem envBound29770 : H12AffineFastState.Bounded env29770 := by
  intro p hp
  have h : env29770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29769_29770 : H12AffineEnvironment.transform 4 1 env29769 = env29770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29769 == env29770) = true)

def env29771 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,180272,253963,242968,8193,64,97547,139613,238874,67619,119043,33,257,98678,90202,63069]

theorem envBound29771 : H12AffineFastState.Bounded env29771 := by
  intro p hp
  have h : env29771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29757_29771 : H12AffineEnvironment.transform 6 9 env29757 = env29771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29757 == env29771) = true)

theorem identity29771 : scanCanonicalize (H12AffineFastState.compose env29771 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound29771 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29772 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,4160,144492,201815,213316,8193,64,97547,139613,217414,67619,75103,33,257,95530,90202,513]

theorem envBound29772 : H12AffineFastState.Bounded env29772 := by
  intro p hp
  have h : env29772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29771_29772 : H12AffineEnvironment.transform 14 29788 env29771 = env29772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env29771 == env29772) = true)

theorem identity29772 : scanCanonicalize (H12AffineFastState.compose env29772 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound29772 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env29773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,131072,10280,1025,29789,4160,144492,155997,144462,8193,64,2049,139613,140364,32041,20565,33,257,32,5456,513]

theorem envBound29773 : H12AffineFastState.Bounded env29773 := by
  intro p hp
  have h : env29773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29772_29773 : H12AffineEnvironment.transform 15 29962 env29772 = env29773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env29772 == env29773) = true)

theorem identity29773 : scanCanonicalize (H12AffineFastState.compose env29773 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound29773 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env29774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,21591,131072,2421,1025,21760,4160,136497,147456,136467,348,64,2049,131072,132369,23668,20565,33,257,32,5456,513]

theorem envBound29774 : H12AffineFastState.Bounded env29774 := by
  intro p hp
  have h : env29774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29773_29774 : H12AffineEnvironment.transform 12 349 env29773 = env29774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env29773 == env29774) = true)

theorem identity29774 : scanCanonicalize (H12AffineFastState.compose env29774 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29774 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env29775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,131072,2421,1025,1,4160,136497,136449,136467,348,64,2049,131072,132369,2421,1364,33,257,32,5456,513]

theorem envBound29775 : H12AffineFastState.Bounded env29775 := by
  intro p hp
  have h : env29775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29774_29775 : H12AffineEnvironment.transform 13 5377 env29774 = env29775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29774 == env29775) = true)

theorem identity29775 : scanCanonicalize (H12AffineFastState.compose env29775 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound29775 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,5392,2421,1025,1,4160,33,17,3,348,64,2049,5392,4097,2421,1364,33,257,32,5456,513]

theorem envBound29776 : H12AffineFastState.Bounded env29776 := by
  intro p hp
  have h : env29776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29775_29776 : H12AffineEnvironment.transform 16 5392 env29775 = env29776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env29775 == env29776) = true)

theorem identity29776 : scanCanonicalize (H12AffineFastState.compose env29776 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3418) := by decide +kernel

theorem selectedBound29776 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3418,349,2139,0,342,2122,2421,1025,1,3354,33,17,3,348,64,2049,2122,3419,2421,1364,33,257,32,2058,513]

theorem envBound29777 : H12AffineFastState.Bounded env29777 := by
  intro p hp
  have h : env29777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29776_29777 : H12AffineEnvironment.transform 11 3418 env29776 = env29777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3418 env29776 == env29777) = true)

theorem identity29777 : scanCanonicalize (H12AffineFastState.compose env29777 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound29777 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29778 : List Nat := [2,4,8,16,32,10,9,256,512,1024,2048,3344,279,2065,0,284,2048,2367,1025,1,3354,33,17,3,278,10,2049,2048,3345,2367,1310,33,257,32,2058,513]

theorem envBound29778 : H12AffineFastState.Bounded env29778 := by
  intro p hp
  have h : env29778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29777_29778 : H12AffineEnvironment.transform 5 10 env29777 = env29778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env29777 == env29778) = true)

theorem identity29778 : scanCanonicalize (H12AffineFastState.compose env29778 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29778 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env29779 : List Nat := [2,4,8,16,0,10,9,256,512,1024,2048,3344,279,2065,0,284,2048,2335,1025,1,3354,1,17,3,278,10,2049,2048,3345,2335,1310,1,257,0,2058,513]

theorem envBound29779 : H12AffineFastState.Bounded env29779 := by
  intro p hp
  have h : env29779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29778_29779 : H12AffineEnvironment.transform 4 0 env29778 = env29779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29778 == env29779) = true)

theorem identity29779 : scanCanonicalize (H12AffineFastState.compose env29779 (packedSelected [5,8,15] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound29779 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env29780 : List Nat := [2,4,8,10,0,10,9,256,512,1024,2048,3338,269,2059,0,262,2048,2309,1025,1,3328,1,11,3,268,10,2049,2048,3339,2309,1284,1,257,0,2058,513]

theorem envBound29780 : H12AffineFastState.Bounded env29780 := by
  intro p hp
  have h : env29780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29779_29780 : H12AffineEnvironment.transform 3 10 env29779 = env29780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env29779 == env29780) = true)

theorem identity29780 : scanCanonicalize (H12AffineFastState.compose env29780 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound29780 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29781 : List Nat := [2,4,8,10,0,10,9,14,512,1024,2048,3076,3,2059,0,8,2048,2059,1025,1,3086,1,11,3,2,10,2049,2048,3077,2059,1034,1,15,0,2058,513]

theorem envBound29781 : H12AffineFastState.Bounded env29781 := by
  intro p hp
  have h : env29781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29780_29781 : H12AffineEnvironment.transform 7 14 env29780 = env29781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env29780 == env29781) = true)

theorem identity29781 : scanCanonicalize (H12AffineFastState.compose env29781 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound29781 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29782 : List Nat := [2,4,8,10,0,10,9,14,11,1024,2048,3076,3,2059,0,8,2048,2059,1025,1,3086,1,11,3,2,10,2049,2048,3077,2059,1034,1,15,0,2058,10]

theorem envBound29782 : H12AffineFastState.Bounded env29782 := by
  intro p hp
  have h : env29782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29781_29782 : H12AffineEnvironment.transform 8 11 env29781 = env29782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env29781 == env29782) = true)

theorem identity29782 : scanCanonicalize (H12AffineFastState.compose env29782 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 9) := by decide +kernel

theorem selectedBound29782 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29783 : List Nat := [2,4,8,10,0,10,9,14,11,1024,9,1037,3,2,0,8,9,2,1025,1,1031,1,11,3,2,10,8,9,1036,2,1034,1,15,0,3,10]

theorem envBound29783 : H12AffineFastState.Bounded env29783 := by
  intro p hp
  have h : env29783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29782_29783 : H12AffineEnvironment.transform 10 9 env29782 = env29783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 9 env29782 == env29783) = true)

theorem identity29783 : scanCanonicalize (H12AffineFastState.compose env29783 (packedSelected [5] rootPS)) = affineNative (2^(9+1) ^^^ 6) := by decide +kernel

theorem selectedBound29783 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29784 : List Nat := [2,4,8,10,0,10,9,14,11,6,9,11,3,2,0,8,9,2,7,1,1,1,11,3,2,10,8,9,10,2,12,1,15,0,3,10]

theorem envBound29784 : H12AffineFastState.Bounded env29784 := by
  intro p hp
  have h : env29784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29783_29784 : H12AffineEnvironment.transform 9 6 env29783 = env29784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 6 env29783 == env29784) = true)

theorem identity29784 : scanCanonicalize (H12AffineFastState.compose env29784 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound29784 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29785 : List Nat := [2,4,5,7,0,7,4,3,6,6,4,6,3,2,0,5,4,2,7,1,1,1,6,3,2,7,5,4,7,2,1,1,2,0,3,7]

theorem envBound29785 : H12AffineFastState.Bounded env29785 := by
  intro p hp
  have h : env29785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29784_29785 : H12AffineEnvironment.transform 2 5 env29784 = env29785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29784 == env29785) = true)

theorem identity29785 : scanCanonicalize (H12AffineFastState.compose env29785 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound29785 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env29786 : List Nat := [0,4,5,5,0,5,4,1,4,4,4,4,1,0,0,5,4,0,5,1,1,1,4,1,0,5,5,4,5,0,1,1,0,0,1,5]

theorem envBound29786 : H12AffineFastState.Bounded env29786 := by
  intro p hp
  have h : env29786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29785_29786 : H12AffineEnvironment.transform 0 0 env29785 = env29786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env29785 == env29786) = true)

def env29787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,254082,243089,8328,64,97547,139612,238994,336002,119043,272392,257,98814,90203,63188]

theorem envBound29787 : H12AffineFastState.Bounded env29787 := by
  intro p hp
  have h : env29787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29734_29787 : H12AffineEnvironment.transform 20 4161 env29734 = env29787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env29734 == env29787) = true)

theorem identity29787 : scanCanonicalize (H12AffineFastState.compose env29787 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound29787 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4161,272512,73754,95497,8328,64,97547,57796,91402,336002,119043,272392,257,98814,90203,63188]

theorem envBound29788 : H12AffineFastState.Bounded env29788 := by
  intro p hp
  have h : env29788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29787_29788 : H12AffineEnvironment.transform 16 49304 env29787 = env29788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env29787 == env29788) = true)

def env29789 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4113,272512,73754,95497,8328,16,97547,57748,91402,336002,119043,272392,257,98734,90123,63108]

theorem envBound29789 : H12AffineFastState.Bounded env29789 := by
  intro p hp
  have h : env29789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29788_29789 : H12AffineEnvironment.transform 5 16 env29788 = env29789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29788 == env29789) = true)

theorem identity29789 : scanCanonicalize (H12AffineFastState.compose env29789 (packedSelected [3,15,17,19,24,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound29789 : packedSelected [3,15,17,19,24,31,38] rootPS < 2^1333 := by decide +kernel

def env29790 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10280,1025,32769,4113,168,73754,95497,8328,16,97547,57748,91402,67754,119043,32,257,98734,90123,63108]

theorem envBound29790 : H12AffineFastState.Bounded env29790 := by
  intro p hp
  have h : env29790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29789_29790 : H12AffineEnvironment.transform 17 10280 env29789 = env29790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env29789 == env29790) = true)

def env29791 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4112,272512,73754,95497,8328,17,97547,57749,91402,336002,119043,272392,257,98735,90122,63109]

theorem envBound29791 : H12AffineFastState.Bounded env29791 := by
  intro p hp
  have h : env29791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29788_29791 : H12AffineEnvironment.transform 5 17 env29788 = env29791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29788 == env29791) = true)

def env29792 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4112,272392,73754,95497,8192,17,97547,57629,91402,335882,119043,272392,257,98599,90122,62989]

theorem envBound29792 : H12AffineFastState.Bounded env29792 := by
  intro p hp
  have h : env29792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29791_29792 : H12AffineEnvironment.transform 6 8 env29791 = env29792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29791 == env29792) = true)

theorem identity29792 : scanCanonicalize (H12AffineFastState.compose env29792 (packedSelected [0,1,9,19,22,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound29792 : packedSelected [0,1,9,19,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env29793 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54279,49168,262144,1025,32769,4112,272392,62493,41230,8192,17,43276,57629,45325,324621,1284,272392,257,21792,46093,62989]

theorem envBound29793 : H12AffineFastState.Bounded env29793 := by
  intro p hp
  have h : env29793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29792_29793 : H12AffineEnvironment.transform 15 54279 env29792 = env29793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env29792 == env29793) = true)

theorem identity29793 : scanCanonicalize (H12AffineFastState.compose env29793 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound29793 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env29794 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54279,49168,43049,1025,32769,4112,32801,62493,41230,8192,17,43276,57629,45325,23588,1284,32801,257,21792,46093,62989]

theorem envBound29794 : H12AffineFastState.Bounded env29794 := by
  intro p hp
  have h : env29794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29793_29794 : H12AffineEnvironment.transform 17 43049 env29793 = env29794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env29793 == env29794) = true)

theorem identity29794 : scanCanonicalize (H12AffineFastState.compose env29794 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound29794 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29795 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29992,8495,13624,23809,1025,29993,4112,29961,309,21542,8192,17,23588,5173,17445,23588,1284,29961,257,21792,16677,805]

theorem envBound29795 : H12AffineFastState.Bounded env29795 := by
  intro p hp
  have h : env29795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29794_29795 : H12AffineEnvironment.transform 14 29992 env29794 = env29795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env29794 == env29795) = true)

theorem identity29795 : scanCanonicalize (H12AffineFastState.compose env29795 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29795 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env29796 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21541,34,5173,23809,1025,21540,4112,21508,309,21542,269,17,23588,5173,17445,23588,1284,21508,257,21792,16677,805]

theorem envBound29796 : H12AffineFastState.Bounded env29796 := by
  intro p hp
  have h : env29796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29795_29796 : H12AffineEnvironment.transform 12 269 env29795 = env29796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29795 == env29796) = true)

theorem identity29796 : scanCanonicalize (H12AffineFastState.compose env29796 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound29796 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29797 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,9,16384,21541,34,5173,23557,1025,21540,4112,21508,49,21542,9,17,23588,5173,17445,23588,1024,21508,5,21540,16417,545]

theorem envBound29797 : H12AffineFastState.Bounded env29797 := by
  intro p hp
  have h : env29797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29796_29797 : H12AffineEnvironment.transform 7 4 env29796 = env29797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env29796 == env29797) = true)

theorem identity29797 : scanCanonicalize (H12AffineFastState.compose env29797 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound29797 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env29798 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,9,5156,1,34,5173,2081,1025,0,4112,32,49,2,9,17,2048,5173,4097,2048,1024,32,5,0,5125,545]

theorem envBound29798 : H12AffineFastState.Bounded env29798 := by
  intro p hp
  have h : env29798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29797_29798 : H12AffineEnvironment.transform 13 5156 env29797 = env29798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env29797 == env29798) = true)

theorem identity29798 : scanCanonicalize (H12AffineFastState.compose env29798 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 3102) := by decide +kernel

theorem selectedBound29798 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env29799 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,3102,9,2106,1,34,2091,2081,1025,0,3086,32,49,2,9,17,2048,2091,3103,2048,1024,32,5,0,2075,545]

theorem envBound29799 : H12AffineFastState.Bounded env29799 := by
  intro p hp
  have h : env29799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29798_29799 : H12AffineEnvironment.transform 11 3102 env29798 = env29799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3102 env29798 == env29799) = true)

theorem identity29799 : scanCanonicalize (H12AffineFastState.compose env29799 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29799 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env29800 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,3102,9,2074,1,2,2059,2049,1025,0,3086,0,17,2,9,17,2048,2059,3103,2048,1024,0,5,0,2075,513]

theorem envBound29800 : H12AffineFastState.Bounded env29800 := by
  intro p hp
  have h : env29800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29799_29800 : H12AffineEnvironment.transform 4 0 env29799 = env29800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29799 == env29800) = true)

theorem identity29800 : scanCanonicalize (H12AffineFastState.compose env29800 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29800 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29801 : List Nat := [2,4,8,0,0,1,8,4,512,1024,2048,3086,9,2058,1,2,2059,2049,1025,0,3086,0,1,2,9,1,2048,2059,3087,2048,1024,0,5,0,2059,513]

theorem envBound29801 : H12AffineFastState.Bounded env29801 := by
  intro p hp
  have h : env29801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29800_29801 : H12AffineEnvironment.transform 3 0 env29800 = env29801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29800 == env29801) = true)

theorem identity29801 : scanCanonicalize (H12AffineFastState.compose env29801 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound29801 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29802 : List Nat := [2,4,8,0,0,1,8,4,512,1024,1540,522,9,1550,1,2,1551,1541,1025,0,522,0,1,2,9,1,1540,1551,523,1540,1024,0,5,0,1551,513]

theorem envBound29802 : H12AffineFastState.Bounded env29802 := by
  intro p hp
  have h : env29802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29801_29802 : H12AffineEnvironment.transform 10 1540 env29801 = env29802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env29801 == env29802) = true)

theorem identity29802 : scanCanonicalize (H12AffineFastState.compose env29802 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29802 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29803 : List Nat := [2,2,8,0,0,1,8,2,512,1024,1538,522,9,1544,1,2,1545,1539,1025,0,522,0,1,2,9,1,1538,1545,523,1538,1024,0,3,0,1545,513]

theorem envBound29803 : H12AffineFastState.Bounded env29803 := by
  intro p hp
  have h : env29803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29802_29803 : H12AffineEnvironment.transform 1 2 env29802 = env29803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29802 == env29803) = true)

theorem identity29803 : scanCanonicalize (H12AffineFastState.compose env29803 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29803 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env29804 : List Nat := [2,2,3,0,0,1,3,2,512,1024,1538,513,2,1539,1,2,1538,1539,1025,0,513,0,1,2,2,1,1538,1538,512,1538,1024,0,3,0,1538,513]

theorem envBound29804 : H12AffineFastState.Bounded env29804 := by
  intro p hp
  have h : env29804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29803_29804 : H12AffineEnvironment.transform 2 3 env29803 = env29804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29803 == env29804) = true)

def env29805 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4112,272393,73754,95497,8193,17,97547,57628,91402,335883,119043,272392,257,98598,90122,62988]

theorem envBound29805 : H12AffineFastState.Bounded env29805 := by
  intro p hp
  have h : env29805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29791_29805 : H12AffineEnvironment.transform 6 9 env29791 = env29805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29791 == env29805) = true)

theorem identity29805 : scanCanonicalize (H12AffineFastState.compose env29805 (packedSelected [0,1,9,19,22,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound29805 : packedSelected [0,1,9,19,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env29806 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40970,49169,262144,1025,32769,4112,272393,32784,54531,8193,17,56577,57628,50432,294913,28937,272392,257,8492,49152,62988]

theorem envBound29806 : H12AffineFastState.Bounded env29806 := by
  intro p hp
  have h : env29806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29805_29806 : H12AffineEnvironment.transform 15 40970 env29805 = env29806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env29805 == env29806) = true)

theorem identity29806 : scanCanonicalize (H12AffineFastState.compose env29806 (packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29806 : packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS < 2^1333 := by decide +kernel

def env29807 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,33031,49169,262144,1025,32769,4112,264452,32784,54531,268,17,56577,49169,50432,294913,20484,264453,257,33,49152,55041]

theorem envBound29807 : H12AffineFastState.Bounded env29807 := by
  intro p hp
  have h : env29807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29806_29807 : H12AffineEnvironment.transform 12 269 env29806 = env29807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29806 == env29807) = true)

theorem identity29807 : scanCanonicalize (H12AffineFastState.compose env29807 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound29807 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env29808 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,33031,49169,23588,1025,32769,4112,21792,32784,54531,268,17,56577,49169,50432,56357,20484,21793,257,33,49152,55041]

theorem envBound29808 : H12AffineFastState.Bounded env29808 := by
  intro p hp
  have h : env29808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29807_29808 : H12AffineEnvironment.transform 17 23588 env29807 = env29808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env29807 == env29808) = true)

theorem identity29808 : scanCanonicalize (H12AffineFastState.compose env29808 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound29808 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env29809 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21760,21511,5393,23588,1025,21761,4112,21792,21776,3,268,17,2049,5393,4096,2341,20484,21793,257,33,5376,513]

theorem envBound29809 : H12AffineFastState.Bounded env29809 := by
  intro p hp
  have h : env29809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29808_29809 : H12AffineEnvironment.transform 14 21760 env29808 = env29809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env29808 == env29809) = true)

theorem identity29809 : scanCanonicalize (H12AffineFastState.compose env29809 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29809 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env29810 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,0,263,5393,2340,1025,1,4112,32,16,3,268,17,2049,5393,4096,2341,1284,33,257,33,5376,513]

theorem envBound29810 : H12AffineFastState.Bounded env29810 := by
  intro p hp
  have h : env29810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29809_29810 : H12AffineEnvironment.transform 13 5376 env29809 = env29810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29809 == env29810) = true)

theorem identity29810 : scanCanonicalize (H12AffineFastState.compose env29810 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound29810 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29811 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,269,4404,0,263,4389,2340,53,1,4112,32,16,3,268,17,2049,4389,4096,2341,304,33,257,33,4404,513]

theorem envBound29811 : H12AffineFastState.Bounded env29811 := by
  intro p hp
  have h : env29811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29810_29811 : H12AffineEnvironment.transform 9 52 env29810 = env29811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env29810 == env29811) = true)

theorem identity29811 : scanCanonicalize (H12AffineFastState.compose env29811 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29811 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29812 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,4113,0,34,4096,2049,53,1,4112,32,16,3,41,17,2049,4096,4096,2048,21,33,36,33,4113,513]

theorem envBound29812 : H12AffineFastState.Bounded env29812 := by
  intro p hp
  have h : env29812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29811_29812 : H12AffineEnvironment.transform 7 37 env29811 = env29812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29811 == env29812) = true)

theorem identity29812 : scanCanonicalize (H12AffineFastState.compose env29812 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound29812 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29813 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2576,40,2561,0,34,2576,2049,53,1,2560,32,16,3,41,17,2049,2576,2576,2048,21,33,36,33,2561,513]

theorem envBound29813 : H12AffineFastState.Bounded env29813 := by
  intro p hp
  have h : env29813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29812_29813 : H12AffineEnvironment.transform 11 2576 env29812 = env29813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env29812 == env29813) = true)

theorem identity29813 : scanCanonicalize (H12AffineFastState.compose env29813 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound29813 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29814 : List Nat := [2,4,8,16,32,17,9,37,512,52,58,554,40,571,0,34,554,59,53,1,570,32,16,3,41,17,59,554,554,58,21,33,36,33,571,513]

theorem envBound29814 : H12AffineFastState.Bounded env29814 := by
  intro p hp
  have h : env29814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29813_29814 : H12AffineEnvironment.transform 10 58 env29813 = env29814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env29813 == env29814) = true)

theorem identity29814 : scanCanonicalize (H12AffineFastState.compose env29814 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound29814 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29815 : List Nat := [2,4,8,16,26,17,9,31,512,14,0,528,18,513,0,24,528,1,15,1,512,26,16,3,19,17,1,528,528,0,21,27,30,27,513,513]

theorem envBound29815 : H12AffineFastState.Bounded env29815 := by
  intro p hp
  have h : env29815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29814_29815 : H12AffineEnvironment.transform 4 26 env29814 = env29815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env29814 == env29815) = true)

theorem identity29815 : scanCanonicalize (H12AffineFastState.compose env29815 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound29815 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29816 : List Nat := [2,4,8,16,26,17,9,31,0,14,0,16,18,1,0,24,16,1,15,1,0,26,16,3,19,17,1,16,16,0,21,27,30,27,1,1]

theorem envBound29816 : H12AffineFastState.Bounded env29816 := by
  intro p hp
  have h : env29816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29815_29816 : H12AffineEnvironment.transform 8 0 env29815 = env29816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env29815 == env29816) = true)

def env29817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,254082,16777216,8328,64,16959643,18973836,2340307,336002,16934034,19369433,257,19014702,19056011,16991045]

theorem envBound29817 : H12AffineFastState.Bounded env29817 := by
  intro p hp
  have h : env29817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29692_29817 : H12AffineEnvironment.transform 21 452633 env29692 = env29817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452633 env29692 == env29817) = true)

def env29818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,254082,243088,8328,64,97547,2240796,2340307,336002,119042,2373705,257,2199998,2191387,63189]

theorem envBound29818 : H12AffineFastState.Bounded env29818 := by
  intro p hp
  have h : env29818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29817_29818 : H12AffineEnvironment.transform 23 243088 env29817 = env29818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243088 env29817 == env29818) = true)

def env29819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,254082,243088,8328,64,97547,139612,238995,336002,119042,272393,257,98814,90203,63189]

theorem envBound29819 : H12AffineFastState.Bounded env29819 := by
  intro p hp
  have h : env29819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29818_29819 : H12AffineEnvironment.transform 20 4160 env29818 = env29819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env29818 == env29819) = true)

theorem identity29819 : scanCanonicalize (H12AffineFastState.compose env29819 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound29819 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4160,452633,144477,155983,8328,64,43476,139612,160076,324701,1501,272393,257,21793,46212,63189]

theorem envBound29820 : H12AffineFastState.Bounded env29820 := by
  intro p hp
  have h : env29820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29819_29820 : H12AffineEnvironment.transform 15 54495 env29819 = env29820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env29819 == env29820) = true)

def env29821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146912,1025,32769,4160,54777,144477,155983,8328,64,43476,139612,160076,182717,1501,136681,257,21793,46212,63189]

theorem envBound29821 : H12AffineFastState.Bounded env29821 := by
  intro p hp
  have h : env29821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29820_29821 : H12AffineEnvironment.transform 17 146912 env29820 = env29821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146912 env29820 == env29821) = true)

theorem identity29821 : scanCanonicalize (H12AffineFastState.compose env29821 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound29821 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env29822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,5393,10481,1025,32769,4160,54777,8524,29790,8328,64,43476,13389,25693,56492,1501,248,257,21793,46212,63189]

theorem envBound29822 : H12AffineFastState.Bounded env29822 := by
  intro p hp
  have h : env29822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29821_29822 : H12AffineEnvironment.transform 16 5393 env29821 = env29822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env29821 == env29822) = true)

theorem identity29822 : scanCanonicalize (H12AffineFastState.compose env29822 (packedSelected [3,4,7,9,11,14,16,18,19,20,23,24,27,31,32,35] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound29822 : packedSelected [3,4,7,9,11,14,16,18,19,20,23,24,27,31,32,35] rootPS < 2^1333 := by decide +kernel

def env29823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33110,5393,10481,1025,32769,4160,32880,8524,8663,8328,64,43476,13389,12756,35109,1501,248,257,168,46212,41820]

theorem envBound29823 : H12AffineFastState.Bounded env29823 := by
  intro p hp
  have h : env29823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29822_29823 : H12AffineEnvironment.transform 13 5513 env29822 = env29823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env29822 == env29823) = true)

theorem identity29823 : scanCanonicalize (H12AffineFastState.compose env29823 (packedSelected [1,5,8,17,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29823 : packedSelected [1,5,8,17,24] rootPS < 2^1333 := by decide +kernel

def env29824 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,33030,5393,10401,1025,32769,4112,32800,8476,8583,8328,16,43396,13341,12676,35109,1421,168,257,168,46212,41740]

theorem envBound29824 : H12AffineFastState.Bounded env29824 := by
  intro p hp
  have h : env29824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29823_29824 : H12AffineEnvironment.transform 5 16 env29823 = env29824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29823 == env29824) = true)

theorem identity29824 : scanCanonicalize (H12AffineFastState.compose env29824 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound29824 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env29825 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,1,263,5393,10401,1025,0,4112,33,8476,8583,8328,16,10629,13341,12676,2340,1421,168,257,168,13445,8973]

theorem envBound29825 : H12AffineFastState.Bounded env29825 := by
  intro p hp
  have h : env29825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29824_29825 : H12AffineEnvironment.transform 14 1 env29824 = env29825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env29824 == env29825) = true)

theorem identity29825 : scanCanonicalize (H12AffineFastState.compose env29825 (packedSelected [2,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2460) := by decide +kernel

theorem selectedBound29825 : packedSelected [2,11,14,15] rootPS < 2^1333 := by decide +kernel

def env29826 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2460,8192,3093,1,263,3213,10401,1025,0,2444,33,8476,8583,8328,16,10629,11649,10264,2340,1421,168,257,168,11545,8973]

theorem envBound29826 : H12AffineFastState.Bounded env29826 := by
  intro p hp
  have h : env29826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29825_29826 : H12AffineEnvironment.transform 11 2460 env29825 = env29826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2460 env29825 == env29826) = true)

theorem identity29826 : scanCanonicalize (H12AffineFastState.compose env29826 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29826 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env29827 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2325,8192,3093,1,263,3076,10280,1025,0,2309,33,8476,8462,8193,16,10508,11528,10264,2340,1284,33,257,33,11545,8973]

theorem envBound29827 : H12AffineFastState.Bounded env29827 := by
  intro p hp
  have h : env29827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29826_29827 : H12AffineEnvironment.transform 6 9 env29826 = env29827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29826 == env29827) = true)

theorem identity29827 : scanCanonicalize (H12AffineFastState.compose env29827 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1818) := by decide +kernel

theorem selectedBound29827 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env29828 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1818,1551,8192,783,1,263,798,10034,1025,0,1567,33,8476,8462,8193,16,9750,8722,9986,1598,1284,33,257,33,8707,8973]

theorem envBound29828 : H12AffineFastState.Bounded env29828 := by
  intro p hp
  have h : env29828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29827_29828 : H12AffineEnvironment.transform 10 1818 env29827 = env29828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1818 env29827 == env29828) = true)

theorem identity29828 : scanCanonicalize (H12AffineFastState.compose env29828 (packedSelected [2,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29828 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env29829 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1818,1551,269,783,1,263,798,1599,1025,0,1567,33,17,3,268,16,1819,799,1551,1598,1284,33,257,33,782,512]

theorem envBound29829 : H12AffineFastState.Bounded env29829 := by
  intro p hp
  have h : env29829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29828_29829 : H12AffineEnvironment.transform 12 269 env29828 = env29829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29828 == env29829) = true)

theorem identity29829 : scanCanonicalize (H12AffineFastState.compose env29829 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound29829 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29830 : List Nat := [2,4,8,16,32,16,9,4,512,1024,1566,1551,9,523,1,3,538,1599,1025,0,1567,33,17,3,8,16,1567,539,1551,1598,1024,33,5,33,522,512]

theorem envBound29830 : H12AffineFastState.Bounded env29830 := by
  intro p hp
  have h : env29830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29829_29830 : H12AffineEnvironment.transform 7 4 env29829 = env29830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env29829 == env29830) = true)

theorem identity29830 : scanCanonicalize (H12AffineFastState.compose env29830 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29830 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29831 : List Nat := [2,4,8,16,0,16,9,4,512,1024,1566,1551,9,523,1,3,538,1567,1025,0,1567,1,17,3,8,16,1567,539,1551,1566,1024,1,5,1,522,512]

theorem envBound29831 : H12AffineFastState.Bounded env29831 := by
  intro p hp
  have h : env29831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29830_29831 : H12AffineEnvironment.transform 4 0 env29830 = env29831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29830 == env29831) = true)

theorem identity29831 : scanCanonicalize (H12AffineFastState.compose env29831 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 519) := by decide +kernel

theorem selectedBound29831 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29832 : List Nat := [2,4,8,16,0,16,9,4,512,519,25,8,9,523,1,3,538,24,518,0,24,1,17,3,8,16,24,539,8,25,519,1,5,1,522,512]

theorem envBound29832 : H12AffineFastState.Bounded env29832 := by
  intro p hp
  have h : env29832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29831_29832 : H12AffineEnvironment.transform 9 519 env29831 = env29832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 519 env29831 == env29832) = true)

theorem identity29832 : scanCanonicalize (H12AffineFastState.compose env29832 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound29832 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29833 : List Nat := [2,4,8,16,0,16,9,4,18,21,25,8,9,25,1,3,8,24,20,0,24,1,17,3,8,16,24,9,8,25,21,1,5,1,24,18]

theorem envBound29833 : H12AffineFastState.Bounded env29833 := by
  intro p hp
  have h : env29833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29832_29833 : H12AffineEnvironment.transform 8 18 env29832 = env29833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env29832 == env29833) = true)

theorem identity29833 : scanCanonicalize (H12AffineFastState.compose env29833 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound29833 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29834 : List Nat := [2,4,8,6,0,6,9,4,4,3,15,8,9,15,1,3,8,14,2,0,14,1,7,3,8,6,14,9,8,15,3,1,5,1,14,4]

theorem envBound29834 : H12AffineFastState.Bounded env29834 := by
  intro p hp
  have h : env29834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29833_29834 : H12AffineEnvironment.transform 3 6 env29833 = env29834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env29833 == env29834) = true)

def env29835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146913,1025,32769,4160,54776,144477,155983,8328,64,43476,139612,160076,182716,1501,136680,257,21793,46212,63189]

theorem envBound29835 : H12AffineFastState.Bounded env29835 := by
  intro p hp
  have h : env29835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29820_29835 : H12AffineEnvironment.transform 17 146913 env29820 = env29835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env29820 == env29835) = true)

theorem identity29835 : scanCanonicalize (H12AffineFastState.compose env29835 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound29835 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env29836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,5528,10361,1025,32769,4160,54776,8645,29911,8328,64,43476,13508,25812,56356,1501,112,257,21793,46212,63189]

theorem envBound29836 : H12AffineFastState.Bounded env29836 := by
  intro p hp
  have h : env29836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29835_29836 : H12AffineEnvironment.transform 16 5528 env29835 = env29836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env29835 == env29836) = true)

theorem identity29836 : scanCanonicalize (H12AffineFastState.compose env29836 (packedSelected [1,4,5,7,8,9,16,17,20,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound29836 : packedSelected [1,4,5,7,8,9,16,17,20,24,27] rootPS < 2^1333 := by decide +kernel

def env29837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8403,5528,10361,1025,29709,4160,8692,8645,29911,8328,64,24024,13508,25812,10280,1501,112,257,21793,16520,729]

theorem envBound29837 : H12AffineFastState.Bounded env29837 := by
  intro p hp
  have h : env29837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29836_29837 : H12AffineEnvironment.transform 14 29708 env29836 = env29837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env29836 == env29837) = true)

theorem identity29837 : scanCanonicalize (H12AffineFastState.compose env29837 (packedSelected [0,3,4,5,7,9,11,15,16,17,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29837 : packedSelected [0,3,4,5,7,9,11,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env29838 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29708,8322,5528,10280,1025,29709,4113,8613,8596,29830,8328,17,23945,13461,25733,10280,1420,33,257,21793,16520,648]

theorem envBound29838 : H12AffineFastState.Bounded env29838 := by
  intro p hp
  have h : env29838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29837_29838 : H12AffineEnvironment.transform 5 17 env29837 = env29838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29837 == env29838) = true)

theorem identity29838 : scanCanonicalize (H12AffineFastState.compose env29838 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound29838 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29839 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21897,263,5528,2477,1025,21896,4113,32,17,21763,269,17,23945,5392,17664,2477,1420,33,257,21793,16520,648]

theorem envBound29839 : H12AffineFastState.Bounded env29839 := by
  intro p hp
  have h : env29839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29838_29839 : H12AffineEnvironment.transform 12 389 env29838 = env29839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env29838 == env29839) = true)

theorem identity29839 : scanCanonicalize (H12AffineFastState.compose env29839 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29839 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env29840 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5377,136,263,5528,2477,1025,137,4113,32,17,2,269,17,2184,5392,4097,2477,1420,33,257,32,5513,648]

theorem envBound29840 : H12AffineFastState.Bounded env29840 := by
  intro p hp
  have h : env29840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29839_29840 : H12AffineEnvironment.transform 13 5377 env29839 = env29840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29839 == env29840) = true)

theorem identity29840 : scanCanonicalize (H12AffineFastState.compose env29840 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound29840 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env29841 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,40,5292,136,170,5173,2048,1025,137,4113,32,17,2,160,17,2184,5309,4097,2048,1057,33,172,32,5156,648]

theorem envBound29841 : H12AffineFastState.Bounded env29841 := by
  intro p hp
  have h : env29841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29840_29841 : H12AffineEnvironment.transform 7 173 env29840 = env29841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env29840 == env29841) = true)

theorem identity29841 : scanCanonicalize (H12AffineFastState.compose env29841 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29841 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env29842 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,0,34,5173,2048,1025,1,4113,32,17,2,40,17,2048,5173,4097,2048,1057,33,36,32,5156,512]

theorem envBound29842 : H12AffineFastState.Bounded env29842 := by
  intro p hp
  have h : env29842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29841_29842 : H12AffineEnvironment.transform 6 8 env29841 = env29842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29841 == env29842) = true)

theorem identity29842 : scanCanonicalize (H12AffineFastState.compose env29842 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound29842 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29843 : List Nat := [2,4,8,16,32,17,8,37,512,21,2048,4096,40,4145,0,34,4128,2048,20,1,4113,32,17,2,40,17,2048,4128,4097,2048,52,33,36,32,4145,512]

theorem envBound29843 : H12AffineFastState.Bounded env29843 := by
  intro p hp
  have h : env29843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29842_29843 : H12AffineEnvironment.transform 9 21 env29842 = env29843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env29842 == env29843) = true)

theorem identity29843 : scanCanonicalize (H12AffineFastState.compose env29843 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound29843 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29844 : List Nat := [2,4,8,16,32,17,8,37,512,21,522,4096,40,4145,0,34,4128,522,20,1,4113,32,17,2,40,17,522,4128,4097,522,52,33,36,32,4145,512]

theorem envBound29844 : H12AffineFastState.Bounded env29844 := by
  intro p hp
  have h : env29844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29843_29844 : H12AffineEnvironment.transform 10 522 env29843 = env29844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env29843 == env29844) = true)

theorem identity29844 : scanCanonicalize (H12AffineFastState.compose env29844 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 570) := by decide +kernel

theorem selectedBound29844 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29845 : List Nat := [2,4,8,16,32,17,8,37,512,21,522,570,40,523,0,34,538,522,20,1,555,32,17,2,40,17,522,538,571,522,52,33,36,32,523,512]

theorem envBound29845 : H12AffineFastState.Bounded env29845 := by
  intro p hp
  have h : env29845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29844_29845 : H12AffineEnvironment.transform 11 570 env29844 = env29845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 570 env29844 == env29845) = true)

theorem identity29845 : scanCanonicalize (H12AffineFastState.compose env29845 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound29845 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29846 : List Nat := [2,4,8,16,32,17,8,37,8,21,2,50,40,3,0,34,18,2,20,1,35,32,17,2,40,17,2,18,51,2,52,33,36,32,3,8]

theorem envBound29846 : H12AffineFastState.Bounded env29846 := by
  intro p hp
  have h : env29846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29845_29846 : H12AffineEnvironment.transform 8 8 env29845 = env29846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env29845 == env29846) = true)

theorem identity29846 : scanCanonicalize (H12AffineFastState.compose env29846 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29846 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env29847 : List Nat := [2,4,8,16,0,17,8,5,8,21,2,18,8,3,0,2,18,2,20,1,3,0,17,2,8,17,2,18,19,2,20,1,4,0,3,8]

theorem envBound29847 : H12AffineFastState.Bounded env29847 := by
  intro p hp
  have h : env29847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29846_29847 : H12AffineEnvironment.transform 4 0 env29846 = env29847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29846 == env29847) = true)

theorem identity29847 : scanCanonicalize (H12AffineFastState.compose env29847 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound29847 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29848 : List Nat := [2,4,8,7,0,6,8,5,8,2,2,5,8,3,0,2,5,2,3,1,3,0,6,2,8,6,2,5,4,2,3,1,4,0,3,8]

theorem envBound29848 : H12AffineFastState.Bounded env29848 := by
  intro p hp
  have h : env29848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29847_29848 : H12AffineEnvironment.transform 3 7 env29847 = env29848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env29847 == env29848) = true)

def env29849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,254082,243088,8328,64,97547,139613,238994,336002,119042,272392,257,98815,90202,63189]

theorem envBound29849 : H12AffineFastState.Bounded env29849 := by
  intro p hp
  have h : env29849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29818_29849 : H12AffineEnvironment.transform 20 4161 env29818 = env29849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env29818 == env29849) = true)

theorem identity29849 : scanCanonicalize (H12AffineFastState.compose env29849 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound29849 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,4161,392286,62661,41431,8328,64,97547,79130,45525,336002,119042,272392,257,98815,90202,63189]

theorem envBound29850 : H12AffineFastState.Bounded env29850 := by
  intro p hp
  have h : env29850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29849_29850 : H12AffineEnvironment.transform 16 70727 env29849 = env29850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env29849 == env29850) = true)

theorem identity29850 : scanCanonicalize (H12AffineFastState.compose env29850 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound29850 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env29851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,70727,262144,1025,29909,4161,329866,17,21763,8328,64,97547,79130,17665,336002,75222,272392,257,95531,90202,513]

theorem envBound29851 : H12AffineFastState.Bounded env29851 := by
  intro p hp
  have h : env29851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29850_29851 : H12AffineEnvironment.transform 14 29908 env29850 = env29851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env29850 == env29851) = true)

def env29852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,70727,262144,1025,8661,4161,329866,17,3,8328,64,75787,79130,4097,336002,75222,272392,257,73771,79194,513]

theorem envBound29852 : H12AffineFastState.Bounded env29852 := by
  intro p hp
  have h : env29852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29851_29852 : H12AffineEnvironment.transform 13 5376 env29851 = env29852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29851 == env29852) = true)

theorem identity29852 : scanCanonicalize (H12AffineFastState.compose env29852 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound29852 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,70727,10401,1025,8661,4161,73771,17,3,8328,64,75787,79130,4097,67619,75222,169,257,73771,79194,513]

theorem envBound29853 : H12AffineFastState.Bounded env29853 := by
  intro p hp
  have h : env29853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29852_29853 : H12AffineEnvironment.transform 17 10401 env29852 = env29853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env29852 == env29853) = true)

theorem identity29853 : scanCanonicalize (H12AffineFastState.compose env29853 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound29853 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env29854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8282,13341,10401,1025,8661,4161,113,17,3,8328,64,2129,5440,4097,10361,1420,169,257,113,5376,513]

theorem envBound29854 : H12AffineFastState.Bounded env29854 := by
  intro p hp
  have h : env29854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29853_29854 : H12AffineEnvironment.transform 15 8282 env29853 = env29854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env29853 == env29854) = true)

theorem identity29854 : scanCanonicalize (H12AffineFastState.compose env29854 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound29854 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,216,342,5393,2477,1025,217,4161,113,17,3,388,64,2129,5440,4097,2421,1420,169,257,113,5376,513]

theorem envBound29855 : H12AffineFastState.Bounded env29855 := by
  intro p hp
  have h : env29855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29854_29855 : H12AffineEnvironment.transform 12 268 env29854 = env29855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env29854 == env29855) = true)

def env29856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,70727,262144,1025,8660,4161,329866,17,2,8328,64,75786,79130,4096,336002,75222,272392,257,73770,79195,513]

theorem envBound29856 : H12AffineFastState.Bounded env29856 := by
  intro p hp
  have h : env29856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29851_29856 : H12AffineEnvironment.transform 13 5377 env29851 = env29856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29851 == env29856) = true)

theorem identity29856 : scanCanonicalize (H12AffineFastState.compose env29856 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound29856 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,70727,10280,1025,8660,4161,73890,17,2,8328,64,75786,79130,4096,67754,75222,32,257,73770,79195,513]

theorem envBound29857 : H12AffineFastState.Bounded env29857 := by
  intro p hp
  have h : env29857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29856_29857 : H12AffineEnvironment.transform 17 10280 env29856 = env29857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env29856 == env29857) = true)

theorem identity29857 : scanCanonicalize (H12AffineFastState.compose env29857 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound29857 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env29858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8322,13509,10280,1025,8660,4161,32,17,2,8328,64,2184,5528,4096,10280,1364,32,257,168,5593,513]

theorem envBound29858 : H12AffineFastState.Bounded env29858 := by
  intro p hp
  have h : env29858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29857_29858 : H12AffineEnvironment.transform 15 8322 env29857 = env29858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env29857 == env29858) = true)

theorem identity29858 : scanCanonicalize (H12AffineFastState.compose env29858 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound29858 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env29859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5377,81,262,5441,2476,1025,80,4161,32,17,2,268,64,2184,5528,4096,2476,1364,32,257,168,5593,513]

theorem envBound29859 : H12AffineFastState.Bounded env29859 := by
  intro p hp
  have h : env29859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29858_29859 : H12AffineEnvironment.transform 12 388 env29858 = env29859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env29858 == env29859) = true)

theorem identity29859 : scanCanonicalize (H12AffineFastState.compose env29859 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29859 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env29860 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5377,0,262,5392,2476,1025,1,4112,32,17,2,268,17,2184,5528,4096,2476,1285,32,257,168,5512,513]

theorem envBound29860 : H12AffineFastState.Bounded env29860 := by
  intro p hp
  have h : env29860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29859_29860 : H12AffineEnvironment.transform 5 17 env29859 = env29860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29859 == env29860) = true)

theorem identity29860 : scanCanonicalize (H12AffineFastState.compose env29860 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound29860 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env29861 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2357,388,3124,0,262,3109,2476,1025,1,2341,32,17,2,268,17,2184,3245,2357,2476,1285,32,257,168,3261,513]

theorem envBound29861 : H12AffineFastState.Bounded env29861 := by
  intro p hp
  have h : env29861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29860_29861 : H12AffineEnvironment.transform 11 2357 env29860 = env29861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env29860 == env29861) = true)

theorem identity29861 : scanCanonicalize (H12AffineFastState.compose env29861 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound29861 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env29862 : List Nat := [2,4,8,16,32,17,128,52,512,1024,2048,2049,176,3124,0,50,3109,2200,1025,1,2065,32,17,2,56,17,2184,3245,2049,2200,1073,32,53,168,3261,513]

theorem envBound29862 : H12AffineFastState.Bounded env29862 := by
  intro p hp
  have h : env29862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29861_29862 : H12AffineEnvironment.transform 7 52 env29861 = env29862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env29861 == env29862) = true)

theorem identity29862 : scanCanonicalize (H12AffineFastState.compose env29862 (packedSelected [0,7,12] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound29862 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env29863 : List Nat := [2,4,8,16,32,17,128,52,512,188,2048,2049,176,2184,0,50,2201,2200,189,1,2065,32,17,2,56,17,2184,2065,2049,2200,141,32,53,168,2049,513]

theorem envBound29863 : H12AffineFastState.Bounded env29863 := by
  intro p hp
  have h : env29863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29862_29863 : H12AffineEnvironment.transform 9 188 env29862 = env29863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env29862 == env29863) = true)

theorem identity29863 : scanCanonicalize (H12AffineFastState.compose env29863 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29863 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env29864 : List Nat := [2,4,8,16,32,17,9,52,512,53,2048,2049,57,2049,0,50,2064,2065,52,1,2065,32,17,2,56,17,2049,2065,2049,2065,4,32,53,33,2049,513]

theorem envBound29864 : H12AffineFastState.Bounded env29864 := by
  intro p hp
  have h : env29864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29863_29864 : H12AffineEnvironment.transform 6 9 env29863 = env29864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29863 == env29864) = true)

def env29865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,254082,243089,8328,64,97546,2240797,2340307,336002,119043,2373704,257,2199999,2191386,63188]

theorem envBound29865 : H12AffineFastState.Bounded env29865 := by
  intro p hp
  have h : env29865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29817_29865 : H12AffineEnvironment.transform 23 243089 env29817 = env29865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243089 env29817 == env29865) = true)

def env29866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,254082,243089,8328,64,97546,139613,238995,336002,119043,272392,257,98815,90202,63188]

theorem envBound29866 : H12AffineFastState.Bounded env29866 := by
  intro p hp
  have h : env29866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29865_29866 : H12AffineEnvironment.transform 20 4160 env29865 = env29866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env29865 == env29866) = true)

theorem identity29866 : scanCanonicalize (H12AffineFastState.compose env29866 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123027) := by decide +kernel

theorem selectedBound29866 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,4160,329866,17,21762,8328,64,97546,115150,17664,336002,119043,272392,257,98815,90202,63188]

theorem envBound29867 : H12AffineFastState.Bounded env29867 := by
  intro p hp
  have h : env29867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29866_29867 : H12AffineEnvironment.transform 16 123027 env29866 = env29867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123027 env29866 == env29867) = true)

def env29868 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4160,329730,17,21762,8192,64,97546,115014,17664,335882,119043,272392,257,98679,90202,63068]

theorem envBound29868 : H12AffineFastState.Bounded env29868 := by
  intro p hp
  have h : env29868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29867_29868 : H12AffineEnvironment.transform 6 8 env29867 = env29868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29867 == env29868) = true)

theorem identity29868 : scanCanonicalize (H12AffineFastState.compose env29868 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound29868 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29869 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,32040,1025,32769,4160,95530,17,21762,8192,64,97546,115014,17664,89378,119043,21792,257,98679,90202,63068]

theorem envBound29869 : H12AffineFastState.Bounded env29869 := by
  intro p hp
  have h : env29869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29868_29869 : H12AffineEnvironment.transform 17 32040 env29868 = env29869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env29868 == env29869) = true)

theorem identity29869 : scanCanonicalize (H12AffineFastState.compose env29869 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound29869 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env29870 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,90139,32040,1025,1,4160,95530,17,21762,8192,64,97546,82246,17664,89378,86275,21792,257,65911,90202,30300]

theorem envBound29870 : H12AffineFastState.Bounded env29870 := by
  intro p hp
  have h : env29870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29869_29870 : H12AffineEnvironment.transform 14 0 env29869 = env29870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env29869 == env29870) = true)

theorem identity29870 : scanCanonicalize (H12AffineFastState.compose env29870 (packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29870 : packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env29871 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,65536,82247,23668,1025,1,4160,87158,17,21762,348,64,89174,82246,17664,89378,86275,21792,257,65911,82182,22272]

theorem envBound29871 : H12AffineFastState.Bounded env29871 := by
  intro p hp
  have h : env29871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29870_29871 : H12AffineEnvironment.transform 12 348 env29870 = env29871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29870 == env29871) = true)

theorem identity29871 : scanCanonicalize (H12AffineFastState.compose env29871 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound29871 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env29872 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,21511,5440,23668,1025,1,4160,113,17,21762,348,64,2129,5441,17664,2341,1284,21792,257,21872,5377,22272]

theorem envBound29872 : H12AffineFastState.Bounded env29872 := by
  intro p hp
  have h : env29872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29871_29872 : H12AffineEnvironment.transform 15 21511 env29871 = env29872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env29871 == env29872) = true)

theorem identity29872 : scanCanonicalize (H12AffineFastState.compose env29872 (packedSelected [1,8,11] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound29872 : packedSelected [1,8,11] rootPS < 2^1333 := by decide +kernel

def env29873 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,1344,0,4423,5440,6452,1025,1,4160,113,17,4162,348,64,2129,5441,64,2341,1284,4192,257,4144,5377,4672]

theorem envBound29873 : H12AffineFastState.Bounded env29873 := by
  intro p hp
  have h : env29873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29872_29873 : H12AffineEnvironment.transform 13 1344 env29872 = env29873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env29872 == env29873) = true)

theorem identity29873 : scanCanonicalize (H12AffineFastState.compose env29873 (packedSelected [2,6,7,9,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound29873 : packedSelected [2,6,7,9,12,14] rootPS < 2^1333 := by decide +kernel

def env29874 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,348,1344,0,4423,5440,5236,1025,1,4160,113,17,4162,348,64,1297,5441,64,1125,1284,4192,257,4144,5377,4672]

theorem envBound29874 : H12AffineFastState.Bounded env29874 := by
  intro p hp
  have h : env29874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29873_29874 : H12AffineEnvironment.transform 10 1344 env29873 = env29874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env29873 == env29874) = true)

theorem identity29874 : scanCanonicalize (H12AffineFastState.compose env29874 (packedSelected [1,2,4,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound29874 : packedSelected [1,2,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env29875 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,65,348,1344,0,262,1281,1077,1025,1,1,113,17,3,348,64,1297,1280,64,1125,1284,33,257,113,1344,513]

theorem envBound29875 : H12AffineFastState.Bounded env29875 := by
  intro p hp
  have h : env29875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29874_29875 : H12AffineEnvironment.transform 11 65 env29874 = env29875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env29874 == env29875) = true)

theorem identity29875 : scanCanonicalize (H12AffineFastState.compose env29875 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound29875 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29876 : List Nat := [2,4,8,16,32,64,8,256,512,53,373,65,348,373,0,262,308,0,52,1,1,113,17,3,348,64,292,309,64,80,305,33,257,113,373,513]

theorem envBound29876 : H12AffineFastState.Bounded env29876 := by
  intro p hp
  have h : env29876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29875_29876 : H12AffineEnvironment.transform 9 53 env29875 = env29876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env29875 == env29876) = true)

def env29877 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4160,329731,17,21762,8193,64,97546,115015,17664,335883,119043,272392,257,98678,90202,63069]

theorem envBound29877 : H12AffineFastState.Bounded env29877 := by
  intro p hp
  have h : env29877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29867_29877 : H12AffineEnvironment.transform 6 9 env29867 = env29877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29867 == env29877) = true)

theorem identity29877 : scanCanonicalize (H12AffineFastState.compose env29877 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound29877 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29878 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,56436,1025,32769,4160,119927,17,21762,8193,64,97546,115015,17664,130175,119043,62588,257,98678,90202,63069]

theorem envBound29878 : H12AffineFastState.Bounded env29878 := by
  intro p hp
  have h : env29878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29877_29878 : H12AffineEnvironment.transform 17 56436 env29877 = env29878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env29877 == env29878) = true)

theorem identity29878 : scanCanonicalize (H12AffineFastState.compose env29878 (packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound29878 : packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS < 2^1333 := by decide +kernel

def env29879 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,262,57628,56436,1025,32769,4160,54641,17,21762,8193,64,31756,49217,17664,64889,53253,62588,257,32880,24924,63069]

theorem envBound29879 : H12AffineFastState.Bounded env29879 := by
  intro p hp
  have h : env29879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29878_29879 : H12AffineEnvironment.transform 15 262 env29878 = env29879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env29878 == env29879) = true)

theorem identity29879 : scanCanonicalize (H12AffineFastState.compose env29879 (packedSelected [4,10,11,12,14,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound29879 : packedSelected [4,10,11,12,14,19,22] rootPS < 2^1333 := by decide +kernel

def env29880 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,262,24861,23669,1025,0,4160,21872,17,21762,8193,64,31756,16448,17664,32120,20484,29821,257,113,24924,30300]

theorem envBound29880 : H12AffineFastState.Bounded env29880 := by
  intro p hp
  have h : env29880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29879_29880 : H12AffineEnvironment.transform 14 1 env29879 = env29880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env29879 == env29880) = true)

theorem identity29880 : scanCanonicalize (H12AffineFastState.compose env29880 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29880 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env29881 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,262,24861,23588,1025,0,4113,21793,17,21762,8193,17,31756,16401,17664,32041,20484,29740,257,32,24845,30221]

theorem envBound29881 : H12AffineFastState.Bounded env29881 := by
  intro p hp
  have h : env29881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29880_29881 : H12AffineEnvironment.transform 5 17 env29880 = env29881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29880 == env29881) = true)

theorem identity29881 : scanCanonicalize (H12AffineFastState.compose env29881 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound29881 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env29882 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,16384,1,262,24861,22544,53,0,4113,20757,17,20790,8193,17,30776,16401,16692,31005,20484,28696,257,32,24845,29241]

theorem envBound29882 : H12AffineFastState.Bounded env29882 := by
  intro p hp
  have h : env29882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29881_29882 : H12AffineEnvironment.transform 9 52 env29881 = env29882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env29881 == env29882) = true)

theorem identity29882 : scanCanonicalize (H12AffineFastState.compose env29882 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound29882 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env29883 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,12572,1,262,4097,10508,53,0,4113,8201,17,8234,8193,17,2340,12557,12328,2049,8472,260,257,32,4113,805]

theorem envBound29883 : H12AffineFastState.Bounded env29883 := by
  intro p hp
  have h : env29883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29882_29883 : H12AffineEnvironment.transform 13 12572 env29882 = env29883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env29882 == env29883) = true)

theorem identity29883 : scanCanonicalize (H12AffineFastState.compose env29883 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29883 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env29884 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,269,4113,1,262,4097,2049,53,0,4113,260,17,295,268,17,2340,4096,4389,2049,21,260,257,32,4113,805]

theorem envBound29884 : H12AffineFastState.Bounded env29884 := by
  intro p hp
  have h : env29884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29883_29884 : H12AffineEnvironment.transform 12 269 env29883 = env29884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29883 == env29884) = true)

theorem identity29884 : scanCanonicalize (H12AffineFastState.compose env29884 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound29884 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env29885 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2356,269,2341,1,262,2357,2049,53,0,2341,260,17,295,268,17,2340,2356,2065,2049,21,260,257,32,2341,805]

theorem envBound29885 : H12AffineFastState.Bounded env29885 := by
  intro p hp
  have h : env29885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29884_29885 : H12AffineEnvironment.transform 11 2356 env29884 = env29885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env29884 == env29885) = true)

def env29886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,254082,243089,8328,64,97546,139612,238994,336002,119043,272393,257,98814,90203,63188]

theorem envBound29886 : H12AffineFastState.Bounded env29886 := by
  intro p hp
  have h : env29886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29865_29886 : H12AffineEnvironment.transform 20 4161 env29865 = env29886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env29865 == env29886) = true)

theorem identity29886 : scanCanonicalize (H12AffineFastState.compose env29886 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound29886 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4161,452633,180361,169370,8328,64,23809,139612,165273,262281,61704,272393,257,41461,16464,63188]

theorem envBound29887 : H12AffineFastState.Bounded env29887 := by
  intro p hp
  have h : env29887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29886_29887 : H12AffineEnvironment.transform 15 8203 env29886 = env29887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env29886 == env29887) = true)

theorem identity29887 : scanCanonicalize (H12AffineFastState.compose env29887 (packedSelected [1,4,7,9,12,15,19,27,28,31,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound29887 : packedSelected [1,4,7,9,12,15,19,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env29888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,57676,262144,1025,32769,4161,264533,8645,29910,8328,64,23809,49168,25813,262281,61704,272393,257,41461,16464,63188]

theorem envBound29888 : H12AffineFastState.Bounded env29888 := by
  intro p hp
  have h : env29888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29887_29888 : H12AffineEnvironment.transform 16 57676 env29887 = env29888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env29887 == env29888) = true)

theorem identity29888 : scanCanonicalize (H12AffineFastState.compose env29888 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound29888 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env29889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,57676,43048,1025,32769,4161,41341,8645,29910,8328,64,23809,49168,25813,43169,61704,32801,257,41461,16464,63188]

theorem envBound29889 : H12AffineFastState.Bounded env29889 := by
  intro p hp
  have h : env29889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29888_29889 : H12AffineEnvironment.transform 17 43048 env29888 = env29889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env29888 == env29889) = true)

theorem identity29889 : scanCanonicalize (H12AffineFastState.compose env29889 (packedSelected [1,3,5,8,10,18,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound29889 : packedSelected [1,3,5,8,10,18,23,26] rootPS < 2^1333 := by decide +kernel

def env29890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,8203,25029,10401,1025,136,4161,8692,8645,29910,8328,64,23809,16537,25813,10280,29057,168,257,8572,16464,30301]

theorem envBound29890 : H12AffineFastState.Bounded env29890 := by
  intro p hp
  have h : env29890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29889_29890 : H12AffineEnvironment.transform 14 137 env29889 = env29890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env29889 == env29890) = true)

theorem identity29890 : scanCanonicalize (H12AffineFastState.compose env29890 (packedSelected [3,10,17,18,19,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound29890 : packedSelected [3,10,17,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env29891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,8203,5529,10401,1025,136,4161,8692,8645,138,8328,64,10589,13509,4233,10280,1501,168,257,8572,13324,513]

theorem envBound29891 : H12AffineFastState.Bounded env29891 := by
  intro p hp
  have h : env29891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29890_29891 : H12AffineEnvironment.transform 13 13404 env29890 = env29891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env29890 == env29891) = true)

theorem identity29891 : scanCanonicalize (H12AffineFastState.compose env29891 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29891 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env29892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,8203,5392,10280,1025,1,4161,8573,8524,3,8193,64,10589,13388,4096,10280,1364,33,257,8572,13324,513]

theorem envBound29892 : H12AffineFastState.Bounded env29892 := by
  intro p hp
  have h : env29892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29891_29892 : H12AffineEnvironment.transform 6 9 env29891 = env29892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29891 == env29892) = true)

theorem identity29892 : scanCanonicalize (H12AffineFastState.compose env29892 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound29892 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29893 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,5392,2421,1025,1,4161,32,17,3,348,64,2048,5393,4096,2421,1364,33,257,33,5457,513]

theorem envBound29893 : H12AffineFastState.Bounded env29893 := by
  intro p hp
  have h : env29893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29892_29893 : H12AffineEnvironment.transform 12 349 env29892 = env29893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env29892 == env29893) = true)

theorem identity29893 : scanCanonicalize (H12AffineFastState.compose env29893 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1135) := by decide +kernel

theorem selectedBound29893 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29894 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1135,4096,349,5377,0,342,5392,1306,1025,1,4161,32,17,3,348,64,1135,5393,4096,1306,1364,33,257,33,5457,513]

theorem envBound29894 : H12AffineFastState.Bounded env29894 := by
  intro p hp
  have h : env29894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29893_29894 : H12AffineEnvironment.transform 10 1135 env29893 = env29894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1135 env29893 == env29894) = true)

def env29895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254784,25265169,145662401,525568,140903596,27337993,25733062]

theorem envBound29895 : H12AffineFastState.Bounded env29895 := by
  intro p hp
  have h : env29895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29141_29895 : H12AffineEnvironment.transform 25 65 env29141 = env29895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env29141 == env29895) = true)

def env29896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356288,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound29896 : H12AffineFastState.Bounded env29896 := by
  intro p hp
  have h : env29896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29895_29896 : H12AffineEnvironment.transform 26 30393344 env29895 = env29896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env29895 == env29896) = true)

def env29897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound29897 : H12AffineFastState.Bounded env29897 := by
  intro p hp
  have h : env29897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29896_29897 : H12AffineEnvironment.transform 18 1024 env29896 = env29897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env29896 == env29897) = true)

theorem identity29897 : scanCanonicalize (H12AffineFastState.compose env29897 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10923491) := by decide +kernel

theorem selectedBound29897 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10923491,8328,65,6385123,8857966,10507600,8830976,2566642,13092898,256,485711,493802,2493989]

theorem envBound29898 : H12AffineFastState.Bounded env29898 := by
  intro p hp
  have h : env29898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29897_29898 : H12AffineEnvironment.transform 23 10923491 env29897 = env29898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10923491 env29897 == env29898) = true)

def env29899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452768,2114883,8328,65,6385123,115150,2538992,10400,2566642,4268162,256,485711,493802,2493989]

theorem envBound29899 : H12AffineFastState.Bounded env29899 := by
  intro p hp
  have h : env29899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29898_29899 : H12AffineEnvironment.transform 22 452768 env29898 = env29899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env29898 == env29899) = true)

def env29900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452768,441779,8328,65,4691219,115150,17664,10400,119042,4268162,256,485711,493802,63189]

theorem envBound29900 : H12AffineFastState.Bounded env29900 := by
  intro p hp
  have h : env29900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29899_29900 : H12AffineEnvironment.transform 20 456944 env29899 = env29900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456944 env29899 == env29900) = true)

def env29901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452768,441779,8328,65,245139,115150,17664,10400,119042,329730,256,485711,493802,63189]

theorem envBound29901 : H12AffineFastState.Bounded env29901 := by
  intro p hp
  have h : env29901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29900_29901 : H12AffineEnvironment.transform 21 272512 env29900 = env29901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29900 == env29901) = true)

def env29902 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272392,452648,441659,8192,65,245019,115014,17664,10280,119042,329730,256,485711,493666,63069]

theorem envBound29902 : H12AffineFastState.Bounded env29902 := by
  intro p hp
  have h : env29902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29901_29902 : H12AffineEnvironment.transform 6 8 env29901 = env29902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29901 == env29902) = true)

def env29903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276584,272392,272440,294187,8192,65,97547,115014,17664,10280,119042,329730,256,371039,346226,63069]

theorem envBound29903 : H12AffineFastState.Bounded env29903 := by
  intro p hp
  have h : env29903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29902_29903 : H12AffineEnvironment.transform 16 49168 env29902 = env29903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env29902 == env29903) = true)

theorem identity29903 : scanCanonicalize (H12AffineFastState.compose env29903 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound29903 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,32041,1024,32769,17729,21793,21777,2,8192,65,97547,115014,17664,10280,119042,95531,256,119926,79195,63069]

theorem envBound29904 : H12AffineFastState.Bounded env29904 := by
  intro p hp
  have h : env29904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29903_29904 : H12AffineEnvironment.transform 17 32041 env29903 = env29904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env29903 == env29904) = true)

theorem identity29904 : scanCanonicalize (H12AffineFastState.compose env29904 (packedSelected [0,1,4,5,10,12,14,15,18,19,20,22,23,24,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 54643) := by decide +kernel

theorem selectedBound29904 : packedSelected [0,1,4,5,10,12,14,15,18,19,20,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env29905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54643,49168,32041,1024,32769,17729,21793,21777,2,8192,65,43128,5173,17664,10280,1137,41048,256,261,57384,63069]

theorem envBound29905 : H12AffineFastState.Bounded env29905 := by
  intro p hp
  have h : env29905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29904_29905 : H12AffineEnvironment.transform 15 54643 env29904 = env29905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54643 env29904 == env29905) = true)

theorem identity29905 : scanCanonicalize (H12AffineFastState.compose env29905 (packedSelected [2,3,5,6,7,9,10,11,12,15,16,22,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound29905 : packedSelected [2,3,5,6,7,9,10,11,12,15,16,22,23,27] rootPS < 2^1333 := by decide +kernel

def env29906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,8575,13340,32041,1024,29709,17729,21793,21777,2,8192,65,23668,5173,17664,10280,1137,21588,256,261,5156,593]

theorem envBound29906 : H12AffineFastState.Bounded env29906 := by
  intro p hp
  have h : env29906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29905_29906 : H12AffineEnvironment.transform 14 29708 env29905 = env29906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env29905 == env29906) = true)

theorem identity29906 : scanCanonicalize (H12AffineFastState.compose env29906 (packedSelected [0,2,4,6,7,9,10,11,12,15,18,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound29906 : packedSelected [0,2,4,6,7,9,10,11,12,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env29907 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,8192,16384,28729,8575,12329,31004,53,28728,16756,20756,20772,2,8192,65,22593,4096,16693,10280,68,20577,256,261,4113,593]

theorem envBound29907 : H12AffineFastState.Bounded env29907 := by
  intro p hp
  have h : env29907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29906_29907 : H12AffineEnvironment.transform 9 53 env29906 = env29907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env29906 == env29907) = true)

theorem identity29907 : scanCanonicalize (H12AffineFastState.compose env29907 (packedSelected [3,4,5,9,10,11,12,14,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound29907 : packedSelected [3,4,5,9,10,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env29908 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,41,16384,20496,342,4096,22837,53,20497,16756,20756,20772,2,41,65,22593,4096,16693,2049,68,20577,256,261,4113,593]

theorem envBound29908 : H12AffineFastState.Bounded env29908 := by
  intro p hp
  have h : env29908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29907_29908 : H12AffineEnvironment.transform 12 41 env29907 = env29908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env29907 == env29908) = true)

theorem identity29908 : scanCanonicalize (H12AffineFastState.compose env29908 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound29908 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29909 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,41,4112,0,342,4096,2341,53,1,4452,260,308,2,41,65,2129,4096,4389,2049,68,113,256,261,4113,593]

theorem envBound29909 : H12AffineFastState.Bounded env29909 := by
  intro p hp
  have h : env29909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29908_29909 : H12AffineEnvironment.transform 13 4112 env29908 = env29909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env29908 == env29909) = true)

theorem identity29909 : scanCanonicalize (H12AffineFastState.compose env29909 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29909 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env29910 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,41,4112,0,35,4096,2128,53,1,4113,113,65,2,41,65,2129,4096,4176,2049,68,113,117,112,4113,593]

theorem envBound29910 : H12AffineFastState.Bounded env29910 := by
  intro p hp
  have h : env29910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29909_29910 : H12AffineEnvironment.transform 7 117 env29909 = env29910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29909 == env29910) = true)

theorem identity29910 : scanCanonicalize (H12AffineFastState.compose env29910 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29910 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29911 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,41,4112,0,35,4096,2048,53,1,4113,33,17,2,41,17,2049,4096,4096,2049,20,33,37,32,4113,513]

theorem envBound29911 : H12AffineFastState.Bounded env29911 := by
  intro p hp
  have h : env29911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29910_29911 : H12AffineEnvironment.transform 5 16 env29910 = env29911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29910 == env29911) = true)

theorem identity29911 : scanCanonicalize (H12AffineFastState.compose env29911 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound29911 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29912 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,512,41,528,0,35,512,2048,53,1,529,33,17,2,41,17,2049,512,512,2049,20,33,37,32,529,513]

theorem envBound29912 : H12AffineFastState.Bounded env29912 := by
  intro p hp
  have h : env29912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29911_29912 : H12AffineEnvironment.transform 11 512 env29911 = env29912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env29911 == env29912) = true)

theorem identity29912 : scanCanonicalize (H12AffineFastState.compose env29912 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound29912 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29913 : List Nat := [2,4,8,16,32,16,8,37,512,53,11,512,41,528,0,35,512,11,53,1,529,33,17,2,41,17,10,512,512,10,20,33,37,32,529,513]

theorem envBound29913 : H12AffineFastState.Bounded env29913 := by
  intro p hp
  have h : env29913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29912_29913 : H12AffineEnvironment.transform 10 11 env29912 = env29913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env29912 == env29913) = true)

theorem identity29913 : scanCanonicalize (H12AffineFastState.compose env29913 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound29913 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29914 : List Nat := [2,4,8,16,32,16,8,37,26,53,11,26,41,10,0,35,26,11,53,1,11,33,17,2,41,17,10,26,26,10,20,33,37,32,11,27]

theorem envBound29914 : H12AffineFastState.Bounded env29914 := by
  intro p hp
  have h : env29914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29913_29914 : H12AffineEnvironment.transform 8 26 env29913 = env29914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env29913 == env29914) = true)

def env29915 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276585,272392,272441,294186,8192,65,97546,115014,17664,10280,119042,329730,256,371038,346227,63069]

theorem envBound29915 : H12AffineFastState.Bounded env29915 := by
  intro p hp
  have h : env29915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29902_29915 : H12AffineEnvironment.transform 16 49169 env29902 = env29915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29902 == env29915) = true)

theorem identity29915 : scanCanonicalize (H12AffineFastState.compose env29915 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29915 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29916 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,38161,262144,1024,32769,276585,272392,272441,272426,8192,65,75786,103494,4096,10280,99330,329730,256,371038,335219,41821]

theorem envBound29916 : H12AffineFastState.Bounded env29916 := by
  intro p hp
  have h : env29916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29915_29916 : H12AffineEnvironment.transform 13 5376 env29915 = env29916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29915 == env29916) = true)

theorem identity29916 : scanCanonicalize (H12AffineFastState.compose env29916 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29916 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env29917 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,13389,262144,1024,8541,276585,272392,272441,272426,8192,65,75786,79130,4096,10280,75102,329730,256,329730,335219,513]

theorem envBound29917 : H12AffineFastState.Bounded env29917 := by
  intro p hp
  have h : env29917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29916_29917 : H12AffineEnvironment.transform 14 8540 env29916 = env29917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29916 == env29917) = true)

theorem identity29917 : scanCanonicalize (H12AffineFastState.compose env29917 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound29917 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29918 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8540,65536,12637,262144,272,8541,276585,272392,272441,272426,8192,65,75786,77834,4096,10280,73806,329730,256,329730,333923,513]

theorem envBound29918 : H12AffineFastState.Bounded env29918 := by
  intro p hp
  have h : env29918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29917_29918 : H12AffineEnvironment.transform 9 272 env29917 = env29918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env29917 == env29918) = true)

theorem identity29918 : scanCanonicalize (H12AffineFastState.compose env29918 (packedSelected [0,1,7,8,16,19] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound29918 : packedSelected [0,1,7,8,16,19] rootPS < 2^1333 := by decide +kernel

def env29919 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8540,65536,12637,2420,272,8541,12573,8572,8525,8542,8192,65,75786,77834,4096,10280,73806,65910,256,65910,69911,513]

theorem envBound29919 : H12AffineFastState.Bounded env29919 := by
  intro p hp
  have h : env29919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29918_29919 : H12AffineEnvironment.transform 17 2420 env29918 = env29919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env29918 == env29919) = true)

theorem identity29919 : scanCanonicalize (H12AffineFastState.compose env29919 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound29919 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env29920 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8540,343,12637,2420,272,8541,12573,8572,8525,8542,8192,65,10589,12637,4096,10280,8473,33,256,33,4160,513]

theorem envBound29920 : H12AffineFastState.Bounded env29920 := by
  intro p hp
  have h : env29920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29919_29920 : H12AffineEnvironment.transform 15 343 env29919 = env29920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env29919 == env29920) = true)

theorem identity29920 : scanCanonicalize (H12AffineFastState.compose env29920 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29920 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29921 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,8192,4112,8461,262,12556,2341,272,8460,12573,8493,8476,8463,8192,16,10508,12556,4096,10280,8473,33,256,33,4113,513]

theorem envBound29921 : H12AffineFastState.Bounded env29921 := by
  intro p hp
  have h : env29921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29920_29921 : H12AffineEnvironment.transform 5 17 env29920 = env29921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29920 == env29921) = true)

theorem identity29921 : scanCanonicalize (H12AffineFastState.compose env29921 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 2844) := by decide +kernel

theorem selectedBound29921 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1