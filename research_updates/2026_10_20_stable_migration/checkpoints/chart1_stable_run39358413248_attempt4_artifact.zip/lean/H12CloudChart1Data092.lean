import H12CloudChart1Data091

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound23289 : H12AffineFastState.Bounded env23289 := by
  intro p hp
  have h : env23289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23288_23289 : H12AffineEnvironment.transform 8 31 env23288 = env23289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env23288 == env23289) = true)

def leafEnv23289 : List Nat := [2,4,8,16,0,16,8,4,31,21,1,16,8,1,0,2,17,0,20,1,1,0,17,2,20,8,1,17,0,16,17,1,21,1,5,0,5,2,1,31,1,1,0]

def active23289 : List Nat := [0,1,2,3]

def tree23289 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23289 : H12WitnessSearch.Good tree23289 := H12GlobalWitnessIndex.good

theorem leafIdentity23289 : H12AffineFastState.composeSystem env23289 rootObs = leafEnv23289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23289 rootObs == leafEnv23289) = true)

theorem terminalChecked23289 : H12PackedTerminal.terminalCheckFast leafEnv23289 active23289 tree23289 = true := by decide +kernel

def env23290 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,8,1045,0,2,1029,2049,1025,1,0,0,17,2,8,17,2049,1028,16,2048,1024,1,5,0,1045,512]

theorem envBound23290 : H12AffineFastState.Bounded env23290 := by
  intro p hp
  have h : env23290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23283_23290 : H12AffineEnvironment.transform 11 17 env23283 = env23290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env23283 == env23290) = true)

theorem identity23290 : scanCanonicalize (H12AffineFastState.compose env23290 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound23290 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23291 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,17,8,1045,0,2,1029,1,1025,1,0,0,17,2,8,17,1,1028,16,0,1024,1,5,0,1045,512]

theorem envBound23291 : H12AffineFastState.Bounded env23291 := by
  intro p hp
  have h : env23291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23290_23291 : H12AffineEnvironment.transform 10 0 env23290 = env23291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env23290 == env23291) = true)

def env23292 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,17,8,1,0,2,17,1,21,1,0,0,17,2,8,17,1,16,16,0,20,1,5,0,1,512]

theorem envBound23292 : H12AffineFastState.Bounded env23292 := by
  intro p hp
  have h : env23292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23291_23292 : H12AffineEnvironment.transform 9 20 env23291 = env23292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env23291 == env23292) = true)

theorem identity23292 : scanCanonicalize (H12AffineFastState.compose env23292 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound23292 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23293 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,8,1,0,2,5,1,1,1,0,0,5,2,8,5,1,4,4,0,0,1,5,0,1,512]

theorem envBound23293 : H12AffineFastState.Bounded env23293 := by
  intro p hp
  have h : env23293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23292_23293 : H12AffineEnvironment.transform 3 4 env23292 = env23293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env23292 == env23293) = true)

def leafEnv23293 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,8,1,0,2,5,1,1,1,0,0,5,2,1,8,1,5,1,4,4,0,0,1,5,0,5,2,1,512,1,0,0]

def active23293 : List Nat := [0,1,2,8]

def tree23293 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23293 : H12WitnessSearch.Good tree23293 := H12GlobalWitnessIndex.good

theorem leafIdentity23293 : H12AffineFastState.composeSystem env23293 rootObs = leafEnv23293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23293 rootObs == leafEnv23293) = true)

theorem terminalChecked23293 : H12PackedTerminal.terminalCheckFast leafEnv23293 active23293 tree23293 = true := by decide +kernel

def env23294 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,8,0,0,2,16,1,20,1,0,0,17,2,8,17,1,17,16,0,21,1,5,0,0,512]

theorem envBound23294 : H12AffineFastState.Bounded env23294 := by
  intro p hp
  have h : env23294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23291_23294 : H12AffineEnvironment.transform 9 21 env23291 = env23294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env23291 == env23294) = true)

theorem identity23294 : scanCanonicalize (H12AffineFastState.compose env23294 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound23294 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23295 : List Nat := [2,4,8,16,0,16,8,4,30,21,0,17,8,0,0,2,16,1,20,1,0,0,17,2,8,17,1,17,16,0,21,1,5,0,0,30]

theorem envBound23295 : H12AffineFastState.Bounded env23295 := by
  intro p hp
  have h : env23295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23294_23295 : H12AffineEnvironment.transform 8 30 env23294 = env23295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env23294 == env23295) = true)

def leafEnv23295 : List Nat := [2,4,8,16,0,16,8,4,30,21,0,17,8,0,0,2,16,1,20,1,0,0,17,2,20,8,1,17,1,17,16,0,21,1,5,0,5,2,0,30,1,0,0]

def active23295 : List Nat := [0,1,2,3]

def tree23295 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23295 : H12WitnessSearch.Good tree23295 := H12GlobalWitnessIndex.good

theorem leafIdentity23295 : H12AffineFastState.composeSystem env23295 rootObs = leafEnv23295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23295 rootObs == leafEnv23295) = true)

theorem terminalChecked23295 : H12PackedTerminal.terminalCheckFast leafEnv23295 active23295 tree23295 = true := by decide +kernel

def env23296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115734,4194304,17,95496,8193,65,4365617,79131,102742,190520,61704,4314199,257,95530,103431,120407]

theorem envBound23296 : H12AffineFastState.Bounded env23296 := by
  intro p hp
  have h : env23296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23273_23296 : H12AffineEnvironment.transform 6 9 env23273 = env23296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23273 == env23296) = true)

theorem identity23296 : scanCanonicalize (H12AffineFastState.compose env23296 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound23296 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23297 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,4160,4194304,17,41310,8193,65,4365617,57677,17664,190520,61704,4194305,257,41340,16465,513]

theorem envBound23297 : H12AffineFastState.Bounded env23297 := by
  intro p hp
  have h : env23297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23296_23297 : H12AffineEnvironment.transform 15 54358 env23296 = env23297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env23296 == env23297) = true)

def env23298 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10281,1025,32769,4112,4194304,17,41230,8193,17,4365617,57629,17664,190520,61704,4194305,257,41260,16385,513]

theorem envBound23298 : H12AffineFastState.Bounded env23298 := by
  intro p hp
  have h : env23298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23297_23298 : H12AffineEnvironment.transform 5 16 env23297 = env23298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23297 == env23298) = true)

theorem identity23298 : scanCanonicalize (H12AffineFastState.compose env23298 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound23298 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env23299 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10281,1025,32769,4112,8493,17,41230,8193,17,179228,57629,17664,190520,61704,8492,257,41260,16385,513]

theorem envBound23299 : H12AffineFastState.Bounded env23299 := by
  intro p hp
  have h : env23299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23298_23299 : H12AffineEnvironment.transform 21 8493 env23298 = env23299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env23298 == env23299) = true)

theorem identity23299 : scanCanonicalize (H12AffineFastState.compose env23299 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound23299 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23300 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,38160,10281,1025,32769,4112,8493,17,41230,8193,17,10508,57629,17664,32040,61704,8492,257,41260,16385,513]

theorem envBound23300 : H12AffineFastState.Bounded env23300 := by
  intro p hp
  have h : env23300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23299_23300 : H12AffineEnvironment.transform 16 38160 env23299 = env23300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env23299 == env23300) = true)

theorem identity23300 : scanCanonicalize (H12AffineFastState.compose env23300 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23300 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23301 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,32768,33031,38160,10281,1025,32769,4112,8493,17,41230,8193,17,10508,46108,4097,10281,41993,8492,257,41260,5376,513]

theorem envBound23301 : H12AffineFastState.Bounded env23301 := by
  intro p hp
  have h : env23301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23300_23301 : H12AffineEnvironment.transform 13 5377 env23300 = env23301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23300 == env23301) = true)

theorem identity23301 : scanCanonicalize (H12AffineFastState.compose env23301 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound23301 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23302 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,32768,33031,38160,2340,1025,32769,4112,32,17,32771,268,17,2049,38161,4097,2340,34052,33,257,32801,5376,513]

theorem envBound23302 : H12AffineFastState.Bounded env23302 := by
  intro p hp
  have h : env23302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23301_23302 : H12AffineEnvironment.transform 12 269 env23301 = env23302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env23301 == env23302) = true)

theorem identity23302 : scanCanonicalize (H12AffineFastState.compose env23302 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23302 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env23303 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,262,5393,2340,1025,0,4112,32,17,2,268,17,2049,5392,4097,2340,1285,33,257,32,5376,513]

theorem envBound23303 : H12AffineFastState.Bounded env23303 := by
  intro p hp
  have h : env23303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23302_23303 : H12AffineEnvironment.transform 14 1 env23302 = env23303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23302 == env23303) = true)

theorem identity23303 : scanCanonicalize (H12AffineFastState.compose env23303 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound23303 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23304 : List Nat := [2,4,8,16,32,16,9,52,512,1024,2048,4096,57,5173,1,50,5157,2064,1025,0,4112,32,17,2,56,17,2049,5156,4097,2064,1073,33,53,32,5172,513]

theorem envBound23304 : H12AffineFastState.Bounded env23304 := by
  intro p hp
  have h : env23304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23303_23304 : H12AffineEnvironment.transform 7 52 env23303 = env23304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env23303 == env23304) = true)

theorem identity23304 : scanCanonicalize (H12AffineFastState.compose env23304 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound23304 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23305 : List Nat := [2,4,8,16,32,16,9,52,512,1024,2048,1573,57,528,1,50,512,2064,1025,0,1589,32,17,2,56,17,2049,513,1572,2064,1073,33,53,32,529,513]

theorem envBound23305 : H12AffineFastState.Bounded env23305 := by
  intro p hp
  have h : env23305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23304_23305 : H12AffineEnvironment.transform 11 1573 env23304 = env23305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env23304 == env23305) = true)

theorem identity23305 : scanCanonicalize (H12AffineFastState.compose env23305 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound23305 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23306 : List Nat := [2,4,8,16,32,16,9,52,512,564,2048,17,57,528,1,50,512,2064,565,0,1,32,17,2,56,17,2049,513,16,2064,517,33,53,32,529,513]

theorem envBound23306 : H12AffineFastState.Bounded env23306 := by
  intro p hp
  have h : env23306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23305_23306 : H12AffineEnvironment.transform 9 564 env23305 = env23306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env23305 == env23306) = true)

def env23307 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10281,1025,32769,4113,4194304,17,41231,8193,16,4365617,57628,17664,190520,61704,4194305,257,41261,16384,513]

theorem envBound23307 : H12AffineFastState.Bounded env23307 := by
  intro p hp
  have h : env23307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23297_23307 : H12AffineEnvironment.transform 5 17 env23297 = env23307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23297 == env23307) = true)

theorem identity23307 : scanCanonicalize (H12AffineFastState.compose env23307 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23307 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env23308 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,21511,131072,10281,1025,1,4113,4194304,17,8463,8193,16,4332849,24860,17664,157752,28936,4194305,257,8493,16384,513]

theorem envBound23308 : H12AffineFastState.Bounded env23308 := by
  intro p hp
  have h : env23308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23307_23308 : H12AffineEnvironment.transform 14 0 env23307 = env23308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23307 == env23308) = true)

theorem identity23308 : scanCanonicalize (H12AffineFastState.compose env23308 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound23308 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env23309 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,21511,131072,10281,1025,1,4113,8492,17,8463,8193,16,146461,24860,17664,157752,28936,8493,257,8493,16384,513]

theorem envBound23309 : H12AffineFastState.Bounded env23309 := by
  intro p hp
  have h : env23309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23308_23309 : H12AffineEnvironment.transform 21 8492 env23308 = env23309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env23308 == env23309) = true)

theorem identity23309 : scanCanonicalize (H12AffineFastState.compose env23309 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound23309 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23310 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,21511,16401,10281,1025,1,4113,8492,17,8463,8193,16,31756,24860,17664,10281,28936,8493,257,8493,16384,513]

theorem envBound23310 : H12AffineFastState.Bounded env23310 := by
  intro p hp
  have h : env23310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23309_23310 : H12AffineEnvironment.transform 16 16401 env23309 = env23310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23309 == env23310) = true)

theorem identity23310 : scanCanonicalize (H12AffineFastState.compose env23310 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23310 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23311 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,0,263,5393,10281,1025,1,4113,8492,17,8463,8193,16,10508,13340,4096,10281,9224,8493,257,8493,5376,513]

theorem envBound23311 : H12AffineFastState.Bounded env23311 := by
  intro p hp
  have h : env23311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23310_23311 : H12AffineEnvironment.transform 13 5376 env23310 = env23311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23310 == env23311) = true)

theorem identity23311 : scanCanonicalize (H12AffineFastState.compose env23311 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound23311 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23312 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,41,5376,0,263,5393,2048,1025,1,4113,261,17,294,40,16,2341,5173,4096,2048,1057,260,257,260,5376,513]

theorem envBound23312 : H12AffineFastState.Bounded env23312 := by
  intro p hp
  have h : env23312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23311_23312 : H12AffineEnvironment.transform 12 41 env23311 = env23312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env23311 == env23312) = true)

theorem identity23312 : scanCanonicalize (H12AffineFastState.compose env23312 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound23312 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env23313 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3329,41,2049,0,263,2064,2048,1025,1,3344,261,17,294,40,16,2341,2356,3329,2048,1057,260,257,260,2049,513]

theorem envBound23313 : H12AffineFastState.Bounded env23313 := by
  intro p hp
  have h : env23313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23312_23313 : H12AffineEnvironment.transform 11 3329 env23312 = env23313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env23312 == env23313) = true)

theorem identity23313 : scanCanonicalize (H12AffineFastState.compose env23313 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23313 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env23314 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1,1280,41,0,0,263,17,1,1025,1,1297,261,17,294,40,16,292,309,1280,1,1057,260,257,260,0,513]

theorem envBound23314 : H12AffineFastState.Bounded env23314 := by
  intro p hp
  have h : env23314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23313_23314 : H12AffineEnvironment.transform 10 1 env23313 = env23314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23313 == env23314) = true)

theorem identity23314 : scanCanonicalize (H12AffineFastState.compose env23314 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23314 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env23315 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1,1061,41,0,0,34,17,1,1025,1,1076,32,17,3,40,16,1,16,1061,1,1057,33,36,33,0,513]

theorem envBound23315 : H12AffineFastState.Bounded env23315 := by
  intro p hp
  have h : env23315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23314_23315 : H12AffineEnvironment.transform 7 37 env23314 = env23315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23314 == env23315) = true)

theorem identity23315 : scanCanonicalize (H12AffineFastState.compose env23315 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound23315 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23316 : List Nat := [2,4,8,16,32,17,9,37,512,53,1,16,41,0,0,34,17,1,52,1,1,32,17,3,40,16,1,16,16,1,20,33,36,33,0,513]

theorem envBound23316 : H12AffineFastState.Bounded env23316 := by
  intro p hp
  have h : env23316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23315_23316 : H12AffineEnvironment.transform 9 53 env23315 = env23316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env23315 == env23316) = true)

theorem identity23316 : scanCanonicalize (H12AffineFastState.compose env23316 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound23316 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23317 : List Nat := [2,4,8,16,32,17,9,37,21,53,1,16,41,0,0,34,17,1,52,1,1,32,17,3,40,16,1,16,16,1,20,33,36,33,0,20]

theorem envBound23317 : H12AffineFastState.Bounded env23317 := by
  intro p hp
  have h : env23317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23316_23317 : H12AffineEnvironment.transform 8 21 env23316 = env23317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env23316 == env23317) = true)

theorem identity23317 : scanCanonicalize (H12AffineFastState.compose env23317 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound23317 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23318 : List Nat := [2,4,8,6,32,7,9,37,3,35,1,6,41,0,0,34,7,1,34,1,1,32,7,3,40,6,1,6,6,1,2,33,36,33,0,2]

theorem envBound23318 : H12AffineFastState.Bounded env23318 := by
  intro p hp
  have h : env23318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23317_23318 : H12AffineEnvironment.transform 3 6 env23317 = env23318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env23317 == env23318) = true)

theorem identity23318 : scanCanonicalize (H12AffineFastState.compose env23318 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound23318 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23319 : List Nat := [2,4,1,6,32,7,0,37,3,35,1,6,32,0,0,34,7,1,34,1,1,32,7,3,33,6,1,6,6,1,2,33,36,33,0,2]

theorem envBound23319 : H12AffineFastState.Bounded env23319 := by
  intro p hp
  have h : env23319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23318_23319 : H12AffineEnvironment.transform 2 1 env23318 = env23319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env23318 == env23319) = true)

theorem identity23319 : scanCanonicalize (H12AffineFastState.compose env23319 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23319 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23320 : List Nat := [2,4,1,6,0,7,0,5,3,3,1,6,0,0,0,2,7,1,2,1,1,0,7,3,1,6,1,6,6,1,2,1,4,1,0,2]

theorem envBound23320 : H12AffineFastState.Bounded env23320 := by
  intro p hp
  have h : env23320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23319_23320 : H12AffineEnvironment.transform 4 0 env23319 = env23320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23319 == env23320) = true)

def env23321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356288,25265169,23160257,525568,27902124,27337992,25733062]

theorem envBound23321 : H12AffineFastState.Bounded env23321 := by
  intro p hp
  have h : env23321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22932_23321 : H12AffineEnvironment.transform 26 30393345 env22932 = env23321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env22932 == env23321) = true)

def env23322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound23322 : H12AffineFastState.Bounded env23322 := by
  intro p hp
  have h : env23322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23321_23322 : H12AffineEnvironment.transform 18 1024 env23321 = env23322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env23321 == env23322) = true)

theorem identity23322 : scanCanonicalize (H12AffineFastState.compose env23322 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 485879) := by decide +kernel

theorem selectedBound23322 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,485879,16777216,8328,65,21015030,18973837,2571430,109047,17231334,23160257,256,19311963,19287295,17287729]

theorem envBound23323 : H12AffineFastState.Bounded env23323 := by
  intro p hp
  have h : env23323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23322_23323 : H12AffineEnvironment.transform 22 485879 env23322 = env23323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 485879 env23322 == env23323) = true)

def env23324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,156012,485879,16777216,8328,65,16959642,18973837,2571430,109047,17231334,19072173,256,19311963,19287295,17287729]

theorem envBound23324 : H12AffineFastState.Bounded env23324 := by
  intro p hp
  have h : env23324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23323_23324 : H12AffineEnvironment.transform 21 156012 env23323 = env23324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156012 env23323 == env23324) = true)

def env23325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156012,485879,16777216,8328,65,16959642,17246709,102878,109047,17231334,17148373,256,16777251,16834951,17287729]

theorem envBound23325 : H12AffineFastState.Bounded env23325 := by
  intro p hp
  have h : env23325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23324_23325 : H12AffineEnvironment.transform 20 437624 env23324 = env23325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437624 env23324 == env23325) = true)

theorem identity23325 : scanCanonicalize (H12AffineFastState.compose env23325 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 362528) := by decide +kernel

theorem selectedBound23325 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env23326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156012,485879,362528,8328,65,475322,172501,102878,109047,222662,8693,256,362499,354727,147985]

theorem envBound23326 : H12AffineFastState.Bounded env23326 := by
  intro p hp
  have h : env23326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23325_23326 : H12AffineEnvironment.transform 23 362528 env23325 = env23326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 362528 env23325 == env23326) = true)

def env23327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,322920,8572,338407,362528,8328,65,327850,57797,102878,109047,75222,8693,256,362499,354727,513]

theorem envBound23327 : H12AffineFastState.Bounded env23327 := by
  intro p hp
  have h : env23327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23326_23327 : H12AffineEnvironment.transform 16 16400 env23326 = env23327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env23326 == env23327) = true)

theorem identity23327 : scanCanonicalize (H12AffineFastState.compose env23327 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23327 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,322920,8572,264684,305195,8328,65,270497,57797,45525,35324,1501,8693,256,305160,281004,513]

theorem envBound23328 : H12AffineFastState.Bounded env23328 := by
  intro p hp
  have h : env23328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23327_23328 : H12AffineEnvironment.transform 15 8203 env23327 = env23328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23327 == env23328) = true)

theorem identity23328 : scanCanonicalize (H12AffineFastState.compose env23328 (packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound23328 : packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env23329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10400,1024,32769,50632,8572,8524,32907,8328,65,2049,57797,45525,35324,1501,8693,256,32936,24844,513]

theorem envBound23329 : H12AffineFastState.Bounded env23329 := by
  intro p hp
  have h : env23329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23328_23329 : H12AffineEnvironment.transform 17 10400 env23328 = env23329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env23328 == env23329) = true)

theorem identity23329 : scanCanonicalize (H12AffineFastState.compose env23329 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound23329 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env23330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8203,16400,10400,1024,0,17865,8572,8524,138,8328,65,2049,25028,12756,2557,1501,8693,256,169,24844,513]

theorem envBound23330 : H12AffineFastState.Bounded env23330 := by
  intro p hp
  have h : env23330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23329_23330 : H12AffineEnvironment.transform 14 1 env23329 = env23330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23329 == env23330) = true)

theorem identity23330 : scanCanonicalize (H12AffineFastState.compose env23330 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound23330 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env23331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,1,398,16400,2341,1024,0,17865,249,201,138,269,65,2049,16449,4177,2557,1501,112,256,169,16521,513]

theorem envBound23331 : H12AffineFastState.Bounded env23331 := by
  intro p hp
  have h : env23331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23330_23331 : H12AffineEnvironment.transform 12 389 env23330 = env23331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env23330 == env23331) = true)

theorem identity23331 : scanCanonicalize (H12AffineFastState.compose env23331 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23331 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env23332 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,1,398,16400,2341,1024,0,17816,168,152,138,269,16,2049,16400,4096,2476,1420,33,256,169,16521,513]

theorem envBound23332 : H12AffineFastState.Bounded env23332 := by
  intro p hp
  have h : env23332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23331_23332 : H12AffineEnvironment.transform 5 17 env23331 = env23332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23331 == env23332) = true)

theorem identity23332 : scanCanonicalize (H12AffineFastState.compose env23332 (packedSelected [5,7,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3245) := by decide +kernel

theorem selectedBound23332 : packedSelected [5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env23333 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3245,389,16384,1,398,16400,2341,1024,0,17816,168,152,138,269,16,2049,16400,3245,2476,1420,33,256,169,16521,513]

theorem envBound23333 : H12AffineFastState.Bounded env23333 := by
  intro p hp
  have h : env23333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23332_23333 : H12AffineEnvironment.transform 11 3245 env23332 = env23333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3245 env23332 == env23333) = true)

theorem identity23333 : scanCanonicalize (H12AffineFastState.compose env23333 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound23333 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env23334 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,2065,389,16384,1,398,16400,2341,188,0,16676,168,152,138,269,16,2049,16400,2065,2476,304,33,256,169,16521,513]

theorem envBound23334 : H12AffineFastState.Bounded env23334 := by
  intro p hp
  have h : env23334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23333_23334 : H12AffineEnvironment.transform 9 188 env23333 = env23334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env23333 == env23334) = true)

theorem identity23334 : scanCanonicalize (H12AffineFastState.compose env23334 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23334 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env23335 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2065,268,16384,1,263,16400,2341,53,0,16676,33,17,3,269,16,2049,16400,2065,2341,304,33,256,32,16384,513]

theorem envBound23335 : H12AffineFastState.Bounded env23335 := by
  intro p hp
  have h : env23335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23334_23335 : H12AffineEnvironment.transform 6 9 env23334 = env23335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23334 == env23335) = true)

theorem identity23335 : scanCanonicalize (H12AffineFastState.compose env23335 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound23335 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23336 : List Nat := [2,4,8,16,32,17,9,20,512,53,2048,2065,24,16384,1,19,16400,2097,53,0,16432,33,17,3,25,16,2049,16400,2065,2097,36,33,20,32,16384,513]

theorem envBound23336 : H12AffineFastState.Bounded env23336 := by
  intro p hp
  have h : env23336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23335_23336 : H12AffineEnvironment.transform 7 20 env23335 = env23336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env23335 == env23336) = true)

theorem identity23336 : scanCanonicalize (H12AffineFastState.compose env23336 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 513) := by decide +kernel

theorem selectedBound23336 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23337 : List Nat := [2,4,8,16,32,17,9,20,512,53,2048,2065,24,513,1,19,529,2097,53,0,561,33,17,3,25,16,2049,529,2065,2097,36,33,20,32,513,513]

theorem envBound23337 : H12AffineFastState.Bounded env23337 := by
  intro p hp
  have h : env23337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23336_23337 : H12AffineEnvironment.transform 13 513 env23336 = env23337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 513 env23336 == env23337) = true)

theorem identity23337 : scanCanonicalize (H12AffineFastState.compose env23337 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound23337 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23338 : List Nat := [2,4,8,16,32,17,9,20,512,53,49,32,24,513,1,19,529,0,53,0,561,33,17,3,25,16,48,529,32,0,36,33,20,32,513,513]

theorem envBound23338 : H12AffineFastState.Bounded env23338 := by
  intro p hp
  have h : env23338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23337_23338 : H12AffineEnvironment.transform 10 49 env23337 = env23338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env23337 == env23338) = true)

theorem identity23338 : scanCanonicalize (H12AffineFastState.compose env23338 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23338 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23339 : List Nat := [2,4,8,16,1,17,9,20,512,20,16,1,24,513,1,19,529,0,20,0,528,0,17,3,25,16,17,529,1,0,5,0,20,1,513,513]

theorem envBound23339 : H12AffineFastState.Bounded env23339 := by
  intro p hp
  have h : env23339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23338_23339 : H12AffineEnvironment.transform 4 1 env23338 = env23339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23338 == env23339) = true)

theorem identity23339 : scanCanonicalize (H12AffineFastState.compose env23339 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23339 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23340 : List Nat := [2,4,8,0,1,1,9,4,512,4,0,1,8,513,1,3,513,0,4,0,512,0,1,3,9,0,1,513,1,0,5,0,4,1,513,513]

theorem envBound23340 : H12AffineFastState.Bounded env23340 := by
  intro p hp
  have h : env23340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23339_23340 : H12AffineEnvironment.transform 3 0 env23339 = env23340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23339 == env23340) = true)

theorem identity23340 : scanCanonicalize (H12AffineFastState.compose env23340 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound23340 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23341 : List Nat := [2,4,8,0,1,1,9,4,0,4,0,1,8,1,1,3,1,0,4,0,0,0,1,3,9,0,1,1,1,0,5,0,4,1,1,1]

theorem envBound23341 : H12AffineFastState.Bounded env23341 := by
  intro p hp
  have h : env23341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23340_23341 : H12AffineEnvironment.transform 8 0 env23340 = env23341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23340 == env23341) = true)

theorem identity23341 : scanCanonicalize (H12AffineFastState.compose env23341 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound23341 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23342 : List Nat := [2,4,2,0,1,1,3,4,0,4,0,1,2,1,1,3,1,0,4,0,0,0,1,3,3,0,1,1,1,0,5,0,4,1,1,1]

theorem envBound23342 : H12AffineFastState.Bounded env23342 := by
  intro p hp
  have h : env23342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23341_23342 : H12AffineEnvironment.transform 2 2 env23341 = env23342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env23341 == env23342) = true)

def env23343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,322921,8573,338406,362528,8328,65,327851,57796,102878,109047,75223,8693,256,362499,354727,512]

theorem envBound23343 : H12AffineFastState.Bounded env23343 := by
  intro p hp
  have h : env23343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23326_23343 : H12AffineEnvironment.transform 16 16401 env23326 = env23343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23326 == env23343) = true)

theorem identity23343 : scanCanonicalize (H12AffineFastState.compose env23343 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 122147) := by decide +kernel

theorem selectedBound23343 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,122147,1024,32769,77898,8573,62661,21763,8328,65,56712,57796,102878,109047,75223,8693,256,21792,46212,512]

theorem envBound23344 : H12AffineFastState.Bounded env23344 := by
  intro p hp
  have h : env23344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23343_23344 : H12AffineEnvironment.transform 17 122147 env23343 = env23344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122147 env23343 == env23344) = true)

theorem identity23344 : scanCanonicalize (H12AffineFastState.compose env23344 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound23344 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env23345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,16401,76278,1024,29908,77898,8573,16,21763,8328,65,10589,5393,91403,89378,75223,8693,256,21792,16465,512]

theorem envBound23345 : H12AffineFastState.Bounded env23345 := by
  intro p hp
  have h : env23345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23344_23345 : H12AffineEnvironment.transform 14 29909 env23344 = env23345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env23344 == env23345) = true)

theorem identity23345 : scanCanonicalize (H12AffineFastState.compose env23345 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound23345 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,34,16401,10708,1024,29908,12392,8573,16,21763,8328,65,10589,5393,25897,23808,9717,8693,256,21792,16465,512]

theorem envBound23346 : H12AffineFastState.Bounded env23346 := by
  intro p hp
  have h : env23346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23345_23346 : H12AffineEnvironment.transform 15 34 env23345 = env23346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env23345 == env23346) = true)

theorem identity23346 : scanCanonicalize (H12AffineFastState.compose env23346 (packedSelected [1,2,3,4,8,10,12,14,15,17,18,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13556) := by decide +kernel

theorem selectedBound23346 : packedSelected [1,2,3,4,8,10,12,14,15,17,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env23347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13556,33,34,13541,10708,1024,32,12392,8573,16,8695,8328,65,10589,5393,4573,10740,9717,8693,256,8660,13477,512]

theorem envBound23347 : H12AffineFastState.Bounded env23347 := by
  intro p hp
  have h : env23347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23346_23347 : H12AffineEnvironment.transform 13 13556 env23346 = env23347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13556 env23346 == env23347) = true)

theorem identity23347 : scanCanonicalize (H12AffineFastState.compose env23347 (packedSelected [2,4,6,7,11,14,17,18,22,27] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound23347 : packedSelected [2,4,6,7,11,14,17,18,22,27] rootPS < 2^1333 := by decide +kernel

def env23348 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,13556,33,34,13541,10368,1024,32,12392,8233,16,8355,8328,65,10249,5189,4233,10400,9377,8353,84,8320,13477,512]

theorem envBound23348 : H12AffineFastState.Bounded env23348 := by
  intro p hp
  have h : env23348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23347_23348 : H12AffineEnvironment.transform 7 84 env23347 = env23348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env23347 == env23348) = true)

theorem identity23348 : scanCanonicalize (H12AffineFastState.compose env23348 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound23348 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env23349 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,40,5340,33,34,5325,2216,1024,32,4160,1,16,139,160,65,2081,5189,4233,2184,1161,137,84,168,5261,512]

theorem envBound23349 : H12AffineFastState.Bounded env23349 := by
  intro p hp
  have h : env23349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23348_23349 : H12AffineEnvironment.transform 12 40 env23348 = env23349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env23348 == env23349) = true)

theorem identity23349 : scanCanonicalize (H12AffineFastState.compose env23349 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound23349 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env23350 : List Nat := [2,4,8,16,32,64,128,84,512,1024,1076,4096,40,5340,33,34,5325,1180,1024,32,4160,1,16,139,160,65,1045,5189,4233,1212,1161,137,84,168,5261,512]

theorem envBound23350 : H12AffineFastState.Bounded env23350 := by
  intro p hp
  have h : env23350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23349_23350 : H12AffineEnvironment.transform 10 1076 env23349 = env23350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env23349 == env23350) = true)

theorem identity23350 : scanCanonicalize (H12AffineFastState.compose env23350 (packedSelected [2,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound23350 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env23351 : List Nat := [2,4,8,16,32,64,89,84,512,1024,1076,4096,40,5125,33,34,5140,1093,1024,32,4160,1,16,82,121,65,1045,5189,4176,1125,1104,80,84,113,5204,512]

theorem envBound23351 : H12AffineFastState.Bounded env23351 := by
  intro p hp
  have h : env23351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23350_23351 : H12AffineEnvironment.transform 6 89 env23350 = env23351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env23350 == env23351) = true)

theorem identity23351 : scanCanonicalize (H12AffineFastState.compose env23351 (packedSelected [5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound23351 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env23352 : List Nat := [2,4,8,16,32,64,89,84,123,1024,1076,4096,40,5125,33,34,5140,1093,1024,32,4160,1,16,82,121,65,1045,5189,4176,1125,1104,80,84,113,5204,123]

theorem envBound23352 : H12AffineFastState.Bounded env23352 := by
  intro p hp
  have h : env23352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23351_23352 : H12AffineEnvironment.transform 8 123 env23351 = env23352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env23351 == env23352) = true)

theorem identity23352 : scanCanonicalize (H12AffineFastState.compose env23352 (packedSelected [1,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound23352 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env23353 : List Nat := [2,4,8,16,32,64,89,84,123,1024,1076,1060,40,33,33,34,48,1093,1024,32,1124,1,16,82,121,65,1045,97,1140,1125,1104,80,84,113,112,123]

theorem envBound23353 : H12AffineFastState.Bounded env23353 := by
  intro p hp
  have h : env23353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23352_23353 : H12AffineEnvironment.transform 11 1060 env23352 = env23353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env23352 == env23353) = true)

theorem identity23353 : scanCanonicalize (H12AffineFastState.compose env23353 (packedSelected [1,4] rootPS)) = affineNative (2^(9+1) ^^^ 103) := by decide +kernel

theorem selectedBound23353 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env23354 : List Nat := [2,4,8,16,32,64,89,84,123,103,83,67,40,33,33,34,48,34,103,32,3,1,16,82,121,65,114,97,19,2,55,80,84,113,112,123]

theorem envBound23354 : H12AffineFastState.Bounded env23354 := by
  intro p hp
  have h : env23354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23353_23354 : H12AffineEnvironment.transform 9 103 env23353 = env23354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 103 env23353 == env23354) = true)

theorem identity23354 : scanCanonicalize (H12AffineFastState.compose env23354 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound23354 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23355 : List Nat := [2,4,8,16,2,64,89,84,89,69,83,67,10,3,3,0,18,0,69,2,3,1,16,82,91,65,80,67,19,2,21,80,84,83,82,89]

theorem envBound23355 : H12AffineFastState.Bounded env23355 := by
  intro p hp
  have h : env23355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23354_23355 : H12AffineEnvironment.transform 4 2 env23354 = env23355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env23354 == env23355) = true)

theorem identity23355 : scanCanonicalize (H12AffineFastState.compose env23355 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23355 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23356 : List Nat := [2,4,8,16,2,17,8,5,8,20,2,18,10,3,3,0,18,0,20,2,3,1,16,3,10,16,1,18,19,2,21,1,5,2,3,8]

theorem envBound23356 : H12AffineFastState.Bounded env23356 := by
  intro p hp
  have h : env23356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23355_23356 : H12AffineEnvironment.transform 5 17 env23355 = env23356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23355 == env23356) = true)

theorem identity23356 : scanCanonicalize (H12AffineFastState.compose env23356 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound23356 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23357 : List Nat := [2,4,8,13,2,12,8,5,8,9,2,15,10,3,3,0,15,0,9,2,3,1,13,3,10,13,1,15,14,2,8,1,5,2,3,8]

theorem envBound23357 : H12AffineFastState.Bounded env23357 := by
  intro p hp
  have h : env23357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23356_23357 : H12AffineEnvironment.transform 3 13 env23356 = env23357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env23356 == env23357) = true)

theorem identity23357 : scanCanonicalize (H12AffineFastState.compose env23357 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound23357 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23358 : List Nat := [1,4,8,13,1,12,8,5,8,9,1,12,9,0,0,0,12,0,9,1,0,1,13,0,9,13,1,12,13,1,8,1,5,1,0,8]

theorem envBound23358 : H12AffineFastState.Bounded env23358 := by
  intro p hp
  have h : env23358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23357_23358 : H12AffineEnvironment.transform 0 1 env23357 = env23358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env23357 == env23358) = true)

def env23359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156012,485879,16777216,8328,65,16959642,17246708,102879,109047,17231334,17148372,256,16777250,16834950,17287729]

theorem envBound23359 : H12AffineFastState.Bounded env23359 := by
  intro p hp
  have h : env23359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23324_23359 : H12AffineEnvironment.transform 20 437625 env23324 = env23359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437625 env23324 == env23359) = true)

theorem identity23359 : scanCanonicalize (H12AffineFastState.compose env23359 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 223719) := by decide +kernel

theorem selectedBound23359 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env23360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,115870,156012,16,16777216,8328,65,16959642,16793619,102879,109047,16876545,16957491,256,16777250,16834950,16819158]

theorem envBound23360 : H12AffineFastState.Bounded env23360 := by
  intro p hp
  have h : env23360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23359_23360 : H12AffineEnvironment.transform 17 223719 env23359 = env23360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223719 env23359 == env23360) = true)

def env23361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,115870,156012,16,95496,8328,65,245138,79131,102879,109047,61705,243003,256,95530,103566,120542]

theorem envBound23361 : H12AffineFastState.Bounded env23361 := by
  intro p hp
  have h : env23361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23360_23361 : H12AffineEnvironment.transform 23 95496 env23360 = env23361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env23360 == env23361) = true)

def env23362 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,115734,156012,16,95496,8192,65,245018,79131,102743,108927,61705,243003,256,95530,103430,120406]

theorem envBound23362 : H12AffineFastState.Bounded env23362 := by
  intro p hp
  have h : env23362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23361_23362 : H12AffineEnvironment.transform 6 8 env23361 = env23362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23361 == env23362) = true)

theorem identity23362 : scanCanonicalize (H12AffineFastState.compose env23362 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound23362 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,89379,1024,32769,115734,21792,16,95496,8192,65,100694,79131,102743,108927,61705,98679,256,95530,103430,120406]

theorem envBound23363 : H12AffineFastState.Bounded env23363 := by
  intro p hp
  have h : env23363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23362_23363 : H12AffineEnvironment.transform 16 13388 env23362 = env23363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env23362 == env23363) = true)

theorem identity23363 : scanCanonicalize (H12AffineFastState.compose env23363 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound23363 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env23364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21591,13388,2420,1024,32769,36929,21792,16,8543,8192,65,56577,24908,50432,64808,61705,54560,256,8573,49233,33281]

theorem envBound23364 : H12AffineFastState.Bounded env23364 := by
  intro p hp
  have h : env23364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23363_23364 : H12AffineEnvironment.transform 15 21591 env23363 = env23364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env23363 == env23364) = true)

def env23365 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,115735,156012,16,95496,8193,65,245019,79131,102742,108926,61705,243003,256,95530,103431,120407]

theorem envBound23365 : H12AffineFastState.Bounded env23365 := by
  intro p hp
  have h : env23365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23361_23365 : H12AffineEnvironment.transform 6 9 env23361 = env23365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23361 == env23365) = true)

theorem identity23365 : scanCanonicalize (H12AffineFastState.compose env23365 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound23365 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23366 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,130175,1024,32769,115735,62589,16,95496,8193,65,75786,79131,102742,108926,61705,73770,256,95530,103431,120407]

theorem envBound23366 : H12AffineFastState.Bounded env23366 := by
  intro p hp
  have h : env23366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23365_23366 : H12AffineEnvironment.transform 16 38161 env23365 = env23366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env23365 == env23366) = true)

theorem identity23366 : scanCanonicalize (H12AffineFastState.compose env23366 (packedSelected [1,3,8,9,12,16,19,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound23366 : packedSelected [1,3,8,9,12,16,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env23367 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,263,38161,64888,1024,32769,50448,62589,16,29711,8193,65,10509,13340,36945,43129,61705,8493,256,29741,38144,55120]

theorem envBound23367 : H12AffineFastState.Bounded env23367 := by
  intro p hp
  have h : env23367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23366_23367 : H12AffineEnvironment.transform 15 263 env23366 = env23367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env23366 == env23367) = true)

theorem identity23367 : scanCanonicalize (H12AffineFastState.compose env23367 (packedSelected [0,1,2,6,7,8,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound23367 : packedSelected [0,1,2,6,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env23368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,263,38161,35108,1024,32769,45388,32801,16,83,8193,65,10509,13340,36945,43129,34133,8493,256,113,38144,41740]

theorem envBound23368 : H12AffineFastState.Bounded env23368 := by
  intro p hp
  have h : env23368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23367_23368 : H12AffineEnvironment.transform 13 13404 env23367 = env23368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env23367 == env23368) = true)

theorem identity23368 : scanCanonicalize (H12AffineFastState.compose env23368 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound23368 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env23369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,81,263,5440,2421,1024,80,12573,112,16,83,8193,65,10509,13340,4096,10280,1284,8493,256,113,5457,9053]

theorem envBound23369 : H12AffineFastState.Bounded env23369 := by
  intro p hp
  have h : env23369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23368_23369 : H12AffineEnvironment.transform 14 81 env23368 = env23369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env23368 == env23369) = true)

theorem identity23369 : scanCanonicalize (H12AffineFastState.compose env23369 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound23369 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env23370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5157,81,263,5440,2421,1024,80,4452,112,16,83,120,65,2420,5221,4096,2129,1284,340,256,113,5457,804]

theorem envBound23370 : H12AffineFastState.Bounded env23370 := by
  intro p hp
  have h : env23370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23369_23370 : H12AffineEnvironment.transform 12 121 env23369 = env23370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env23369 == env23370) = true)

theorem identity23370 : scanCanonicalize (H12AffineFastState.compose env23370 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound23370 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env23371 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5157,81,115,5172,2049,1024,80,4112,112,16,83,120,65,2048,5221,4096,2129,1136,32,116,113,5157,592]

theorem envBound23371 : H12AffineFastState.Bounded env23371 := by
  intro p hp
  have h : env23371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23370_23371 : H12AffineEnvironment.transform 7 116 env23370 = env23371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env23370 == env23371) = true)

theorem identity23371 : scanCanonicalize (H12AffineFastState.compose env23371 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound23371 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env23372 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3109,121,2048,81,115,2065,2049,1024,80,3125,112,16,83,120,65,2048,2112,3109,2129,1136,32,116,113,2048,592]

theorem envBound23372 : H12AffineFastState.Bounded env23372 := by
  intro p hp
  have h : env23372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23371_23372 : H12AffineEnvironment.transform 11 3109 env23371 = env23372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env23371 == env23372) = true)

theorem identity23372 : scanCanonicalize (H12AffineFastState.compose env23372 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound23372 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env23373 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,2113,121,2048,81,115,2065,2049,100,80,2129,112,16,83,120,65,2048,2112,2113,2129,20,32,116,113,2048,592]

theorem envBound23373 : H12AffineFastState.Bounded env23373 := by
  intro p hp
  have h : env23373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23372_23373 : H12AffineEnvironment.transform 9 100 env23372 = env23373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env23372 == env23373) = true)

theorem identity23373 : scanCanonicalize (H12AffineFastState.compose env23373 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23373 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env23374 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,2065,41,2048,1,35,2065,2049,52,0,2049,32,16,3,40,17,2048,2064,2065,2049,20,32,36,33,2048,512]

theorem envBound23374 : H12AffineFastState.Bounded env23374 := by
  intro p hp
  have h : env23374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23373_23374 : H12AffineEnvironment.transform 5 16 env23373 = env23374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23373 == env23374) = true)

theorem identity23374 : scanCanonicalize (H12AffineFastState.compose env23374 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 37) := by decide +kernel

theorem selectedBound23374 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23375 : List Nat := [2,4,8,16,32,16,9,36,512,52,37,52,41,37,1,35,52,36,52,0,36,32,16,3,40,17,37,53,52,36,20,32,36,33,37,512]

theorem envBound23375 : H12AffineFastState.Bounded env23375 := by
  intro p hp
  have h : env23375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23374_23375 : H12AffineEnvironment.transform 10 37 env23374 = env23375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 37 env23374 == env23375) = true)

theorem identity23375 : scanCanonicalize (H12AffineFastState.compose env23375 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound23375 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23376 : List Nat := [2,4,8,16,32,16,9,36,12,52,37,52,41,37,1,35,52,36,52,0,36,32,16,3,40,17,37,53,52,36,20,32,36,33,37,12]

theorem envBound23376 : H12AffineFastState.Bounded env23376 := by
  intro p hp
  have h : env23376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23375_23376 : H12AffineEnvironment.transform 8 12 env23375 = env23376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env23375 == env23376) = true)

theorem identity23376 : scanCanonicalize (H12AffineFastState.compose env23376 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23376 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23377 : List Nat := [2,4,8,16,0,16,9,4,12,20,5,20,9,5,1,3,20,4,20,0,4,0,16,3,8,17,5,21,20,4,20,0,4,1,5,12]

theorem envBound23377 : H12AffineFastState.Bounded env23377 := by
  intro p hp
  have h : env23377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23376_23377 : H12AffineEnvironment.transform 4 0 env23376 = env23377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23376 == env23377) = true)

theorem identity23377 : scanCanonicalize (H12AffineFastState.compose env23377 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound23377 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23378 : List Nat := [0,4,8,16,0,16,9,4,12,20,5,20,9,5,1,1,20,4,20,0,4,0,16,1,8,17,5,21,20,4,20,0,4,1,5,12]

theorem envBound23378 : H12AffineFastState.Bounded env23378 := by
  intro p hp
  have h : env23378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23377_23378 : H12AffineEnvironment.transform 0 0 env23377 = env23378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env23377 == env23378) = true)

def env23379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,115870,156012,16,95497,8328,65,245139,79130,102879,109047,61704,243002,256,95531,103567,120543]

theorem envBound23379 : H12AffineFastState.Bounded env23379 := by
  intro p hp
  have h : env23379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23360_23379 : H12AffineEnvironment.transform 23 95497 env23360 = env23379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env23360 == env23379) = true)

theorem identity23379 : scanCanonicalize (H12AffineFastState.compose env23379 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound23379 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,179513,1024,32769,4160,156012,16,41431,8328,65,158029,57796,17665,32041,61704,156132,256,41461,16465,513]

theorem envBound23380 : H12AffineFastState.Bounded env23380 := by
  intro p hp
  have h : env23380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23379_23380 : H12AffineEnvironment.transform 15 54494 env23379 = env23380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env23379 == env23380) = true)

def env23381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179513,1024,32769,4160,156012,16,41311,8192,65,158029,57676,17665,32041,61704,156012,256,41341,16465,513]

theorem envBound23381 : H12AffineFastState.Bounded env23381 := by
  intro p hp
  have h : env23381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23380_23381 : H12AffineEnvironment.transform 6 8 env23380 = env23381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23380 == env23381) = true)

theorem identity23381 : scanCanonicalize (H12AffineFastState.compose env23381 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound23381 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23382 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13389,35188,1024,32769,4160,21793,16,41311,8192,65,23808,57676,17665,32041,61704,21793,256,41341,16465,513]

theorem envBound23382 : H12AffineFastState.Bounded env23382 := by
  intro p hp
  have h : env23382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23381_23382 : H12AffineEnvironment.transform 16 13389 env23381 = env23382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env23381 == env23382) = true)

theorem identity23382 : scanCanonicalize (H12AffineFastState.compose env23382 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound23382 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env23383 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,9293,28699,13389,11577,1024,9292,4160,21793,16,1298,8192,65,23808,17665,17665,32041,21829,21793,256,1328,16465,513]

theorem envBound23383 : H12AffineFastState.Bounded env23383 := by
  intro p hp
  have h : env23383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23382_23383 : H12AffineEnvironment.transform 14 9293 env23382 = env23383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env23382 == env23383) = true)

theorem identity23383 : scanCanonicalize (H12AffineFastState.compose env23383 (packedSelected [3,5,9,10,14,22] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound23383 : packedSelected [3,5,9,10,14,22] rootPS < 2^1333 := by decide +kernel

def env23384 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,0,21590,4096,2420,1024,1,4160,21793,16,1298,1101,65,23808,17665,17665,22884,21829,21793,256,1328,16465,513]

theorem envBound23384 : H12AffineFastState.Bounded env23384 := by
  intro p hp
  have h : env23384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23383_23384 : H12AffineEnvironment.transform 12 1101 env23383 = env23384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env23383 == env23384) = true)

def env23385 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179513,1024,32769,4160,156012,16,41310,8193,65,158029,57677,17665,32041,61704,156013,256,41340,16465,513]

theorem envBound23385 : H12AffineFastState.Bounded env23385 := by
  intro p hp
  have h : env23385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23380_23385 : H12AffineEnvironment.transform 6 9 env23380 = env23385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23380 == env23385) = true)

theorem identity23385 : scanCanonicalize (H12AffineFastState.compose env23385 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound23385 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23386 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,10281,1024,32769,4160,62588,16,41310,8193,65,64605,57677,17665,32041,61704,62589,256,41340,16465,513]

theorem envBound23386 : H12AffineFastState.Bounded env23386 := by
  intro p hp
  have h : env23386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23385_23386 : H12AffineEnvironment.transform 16 38160 env23385 = env23386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env23385 == env23386) = true)

theorem identity23386 : scanCanonicalize (H12AffineFastState.compose env23386 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23386 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env23387 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,38160,10281,1024,32769,4160,41341,16,41310,8193,65,43356,46156,4096,10280,41993,41340,256,41340,5456,513]

theorem envBound23387 : H12AffineFastState.Bounded env23387 := by
  intro p hp
  have h : env23387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23386_23387 : H12AffineEnvironment.transform 13 5377 env23386 = env23387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23386 == env23387) = true)

theorem identity23387 : scanCanonicalize (H12AffineFastState.compose env23387 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound23387 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23388 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,373,35,5221,10281,1024,372,4160,8200,16,8235,8193,65,10281,13625,4096,10280,9596,8201,256,8201,5456,513]

theorem envBound23388 : H12AffineFastState.Bounded env23388 := by
  intro p hp
  have h : env23388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23387_23388 : H12AffineEnvironment.transform 14 373 env23387 = env23388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env23387 == env23388) = true)

theorem identity23388 : scanCanonicalize (H12AffineFastState.compose env23388 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23388 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env23389 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5156,80,35,5221,10281,1024,81,4160,8200,16,8235,8193,65,10281,13340,4096,10280,9305,8201,37,8201,5237,513]

theorem envBound23389 : H12AffineFastState.Bounded env23389 := by
  intro p hp
  have h : env23389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23388_23389 : H12AffineEnvironment.transform 7 37 env23388 = env23389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23388 == env23389) = true)

theorem identity23389 : scanCanonicalize (H12AffineFastState.compose env23389 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound23389 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env23390 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5156,80,35,5221,2049,1024,81,4160,32,16,3,41,65,2049,5172,4096,2048,1137,33,37,33,5237,513]

theorem envBound23390 : H12AffineFastState.Bounded env23390 := by
  intro p hp
  have h : env23390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23389_23390 : H12AffineEnvironment.transform 12 40 env23389 = env23390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env23389 == env23390) = true)

theorem identity23390 : scanCanonicalize (H12AffineFastState.compose env23390 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound23390 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env23391 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,64,40,1124,80,35,1061,2049,1024,81,0,32,16,3,41,65,2049,1140,64,2048,1137,33,37,33,1077,513]

theorem envBound23391 : H12AffineFastState.Bounded env23391 := by
  intro p hp
  have h : env23391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23390_23391 : H12AffineEnvironment.transform 11 64 env23390 = env23391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env23390 == env23391) = true)

theorem identity23391 : scanCanonicalize (H12AffineFastState.compose env23391 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound23391 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env23392 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1125,64,40,1124,80,35,1061,1124,1024,81,0,32,16,3,41,65,1124,1140,64,1125,1137,33,37,33,1077,513]

theorem envBound23392 : H12AffineFastState.Bounded env23392 := by
  intro p hp
  have h : env23392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23391_23392 : H12AffineEnvironment.transform 10 1125 env23391 = env23392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env23391 == env23392) = true)

theorem identity23392 : scanCanonicalize (H12AffineFastState.compose env23392 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23392 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env23393 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1077,16,40,1076,0,35,1061,1076,1024,1,0,32,16,3,41,17,1076,1060,16,1077,1057,33,37,33,1077,513]

theorem envBound23393 : H12AffineFastState.Bounded env23393 := by
  intro p hp
  have h : env23393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23392_23393 : H12AffineEnvironment.transform 5 16 env23392 = env23393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23392 == env23393) = true)

theorem identity23393 : scanCanonicalize (H12AffineFastState.compose env23393 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23393 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23394 : List Nat := [2,4,8,0,32,0,9,37,512,1024,1061,0,40,1060,0,35,1061,1060,1024,1,0,32,0,3,41,1,1060,1060,0,1061,1057,33,37,33,1061,513]

theorem envBound23394 : H12AffineFastState.Bounded env23394 := by
  intro p hp
  have h : env23394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23393_23394 : H12AffineEnvironment.transform 3 0 env23393 = env23394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23393 == env23394) = true)

theorem identity23394 : scanCanonicalize (H12AffineFastState.compose env23394 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound23394 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23395 : List Nat := [2,4,8,0,32,0,9,37,512,47,10,0,40,11,0,35,10,11,47,1,0,32,0,3,41,1,11,11,0,10,14,33,37,33,10,513]

theorem envBound23395 : H12AffineFastState.Bounded env23395 := by
  intro p hp
  have h : env23395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23394_23395 : H12AffineEnvironment.transform 9 47 env23394 = env23395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env23394 == env23395) = true)

theorem identity23395 : scanCanonicalize (H12AffineFastState.compose env23395 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound23395 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23396 : List Nat := [2,4,8,0,10,0,9,15,512,5,10,0,2,11,0,9,10,11,5,1,0,10,0,3,3,1,11,11,0,10,14,11,15,11,10,513]

theorem envBound23396 : H12AffineFastState.Bounded env23396 := by
  intro p hp
  have h : env23396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23395_23396 : H12AffineEnvironment.transform 4 10 env23395 = env23396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env23395 == env23396) = true)

theorem identity23396 : scanCanonicalize (H12AffineFastState.compose env23396 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound23396 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23397 : List Nat := [2,4,8,0,10,0,9,15,14,5,10,0,2,11,0,9,10,11,5,1,0,10,0,3,3,1,11,11,0,10,14,11,15,11,10,15]

theorem envBound23397 : H12AffineFastState.Bounded env23397 := by
  intro p hp
  have h : env23397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23396_23397 : H12AffineEnvironment.transform 8 14 env23396 = env23397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env23396 == env23397) = true)

theorem identity23397 : scanCanonicalize (H12AffineFastState.compose env23397 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound23397 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23398 : List Nat := [2,4,3,0,1,0,2,4,5,5,1,0,2,0,0,2,1,0,5,1,0,1,0,3,3,1,0,0,0,1,5,0,4,0,1,4]

theorem envBound23398 : H12AffineFastState.Bounded env23398 := by
  intro p hp
  have h : env23398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23397_23398 : H12AffineEnvironment.transform 2 3 env23397 = env23398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env23397 == env23398) = true)

theorem identity23398 : scanCanonicalize (H12AffineFastState.compose env23398 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound23398 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23399 : List Nat := [1,4,0,0,1,0,1,4,5,5,1,0,1,0,0,1,1,0,5,1,0,1,0,0,0,1,0,0,0,1,5,0,4,0,1,4]

theorem envBound23399 : H12AffineFastState.Bounded env23399 := by
  intro p hp
  have h : env23399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23398_23399 : H12AffineEnvironment.transform 0 1 env23398 = env23399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env23398 == env23399) = true)

def env23400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,156013,485879,16777216,8328,65,16959643,18973837,2571430,109047,17231334,19072172,256,19311963,19287295,17287729]

theorem envBound23400 : H12AffineFastState.Bounded env23400 := by
  intro p hp
  have h : env23400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23323_23400 : H12AffineEnvironment.transform 21 156013 env23323 = env23400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156013 env23323 == env23400) = true)

def env23401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156013,485879,16777216,8328,65,16959643,17246709,102878,109047,17231334,17148372,256,16777251,16834951,17287729]

theorem envBound23401 : H12AffineFastState.Bounded env23401 := by
  intro p hp
  have h : env23401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23400_23401 : H12AffineEnvironment.transform 20 437624 env23400 = env23401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437624 env23400 == env23401) = true)

theorem identity23401 : scanCanonicalize (H12AffineFastState.compose env23401 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188871) := by decide +kernel

theorem selectedBound23401 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env23402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156013,485879,188871,8328,65,10588,378930,102878,109047,265249,477203,256,188900,131136,338934]

theorem envBound23402 : H12AffineFastState.Bounded env23402 := by
  intro p hp
  have h : env23402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23401_23402 : H12AffineEnvironment.transform 23 188871 env23401 = env23402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188871 env23401 == env23402) = true)

def env23403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,156013,120015,188871,8328,65,10588,226570,102878,109047,176409,128299,256,188900,131136,235214]

theorem envBound23403 : H12AffineFastState.Bounded env23403 := by
  intro p hp
  have h : env23403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23402_23403 : H12AffineEnvironment.transform 17 179512 env23402 = env23403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env23402 == env23403) = true)

theorem identity23403 : scanCanonicalize (H12AffineFastState.compose env23403 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound23403 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,122147,1024,32769,4160,65910,120015,98780,8328,65,10588,5393,102878,109047,119042,128299,256,98815,90203,63189]

theorem envBound23404 : H12AffineFastState.Bounded env23404 := by
  intro p hp
  have h : env23404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23403_23404 : H12AffineEnvironment.transform 16 90139 env23403 = env23404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env23403 == env23404) = true)

def env23405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,122147,1024,32769,4160,65910,119879,98644,8192,65,10588,5393,102742,108927,119042,128299,256,98679,90203,63069]

theorem envBound23405 : H12AffineFastState.Bounded env23405 := by
  intro p hp
  have h : env23405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23404_23405 : H12AffineEnvironment.transform 6 8 env23404 = env23405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23404 == env23405) = true)

theorem identity23405 : scanCanonicalize (H12AffineFastState.compose env23405 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound23405 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env23406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,76159,1024,29789,4160,65910,73755,95496,8192,65,10588,5393,91402,89379,75102,65911,256,95531,90203,513]

theorem envBound23406 : H12AffineFastState.Bounded env23406 := by
  intro p hp
  have h : env23406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23405_23406 : H12AffineEnvironment.transform 14 29788 env23405 = env23406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env23405 == env23406) = true)

theorem identity23406 : scanCanonicalize (H12AffineFastState.compose env23406 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23406 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env23407 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,16400,2420,1024,29789,4160,8573,16,21763,8192,65,10588,5393,17665,32040,1365,8572,256,21792,16464,513]

theorem envBound23407 : H12AffineFastState.Bounded env23407 := by
  intro p hp
  have h : env23407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23406_23407 : H12AffineEnvironment.transform 15 8203 env23406 = env23407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23406 == env23407) = true)

theorem identity23407 : scanCanonicalize (H12AffineFastState.compose env23407 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound23407 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23408 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,20497,1094,16400,2420,1024,20496,4160,1328,16,21763,1101,65,3345,5393,17665,22885,1365,1329,256,21792,16464,513]

theorem envBound23408 : H12AffineFastState.Bounded env23408 := by
  intro p hp
  have h : env23408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23407_23408 : H12AffineEnvironment.transform 12 1101 env23407 = env23408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env23407 == env23408) = true)

def env23409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,122147,1024,32769,4160,65910,119878,98645,8193,65,10588,5393,102743,108926,119042,128299,256,98678,90203,63068]

theorem envBound23409 : H12AffineFastState.Bounded env23409 := by
  intro p hp
  have h : env23409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23404_23409 : H12AffineEnvironment.transform 6 9 env23404 = env23409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23404 == env23409) = true)

theorem identity23409 : scanCanonicalize (H12AffineFastState.compose env23409 (packedSelected [4,5,9,12,15,16,19,24,35] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound23409 : packedSelected [4,5,9,12,15,16,19,24,35] rootPS < 2^1333 := by decide +kernel

def env23410 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90139,76159,1024,29789,4160,65910,73754,95497,8193,65,10588,5393,91403,89378,75102,65911,256,95530,90203,512]

theorem envBound23410 : H12AffineFastState.Bounded env23410 := by
  intro p hp
  have h : env23410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23409_23410 : H12AffineEnvironment.transform 14 29788 env23409 = env23410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env23409 == env23410) = true)

theorem identity23410 : scanCanonicalize (H12AffineFastState.compose env23410 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound23410 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23411 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,34,24633,10589,1024,29789,4160,340,8248,29995,8193,65,10588,5393,25897,23808,9596,341,256,29960,24697,512]

theorem envBound23411 : H12AffineFastState.Bounded env23411 := by
  intro p hp
  have h : env23411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23410_23411 : H12AffineEnvironment.transform 15 34 env23410 = env23411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env23410 == env23411) = true)

theorem identity23411 : scanCanonicalize (H12AffineFastState.compose env23411 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound23411 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env23412 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,34,5220,10589,1024,0,4160,340,8248,374,8193,65,10588,5393,4468,10589,9596,341,256,341,5156,512]

theorem envBound23412 : H12AffineFastState.Bounded env23412 := by
  intro p hp
  have h : env23412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23411_23412 : H12AffineEnvironment.transform 13 13405 env23411 = env23412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env23411 == env23412) = true)

theorem identity23412 : scanCanonicalize (H12AffineFastState.compose env23412 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound23412 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23413 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,12572,1,34,4389,10589,321,0,4160,340,8248,374,8193,65,10588,4176,4468,10589,8253,341,256,341,4453,512]

theorem envBound23413 : H12AffineFastState.Bounded env23413 := by
  intro p hp
  have h : env23413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23412_23413 : H12AffineEnvironment.transform 9 321 env23412 = env23413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env23412 == env23413) = true)

theorem identity23413 : scanCanonicalize (H12AffineFastState.compose env23413 (packedSelected [0,4,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 887) := by decide +kernel

theorem selectedBound23413 : packedSelected [0,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env23414 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,887,4715,1,34,4389,2602,321,0,4160,340,847,374,886,65,2603,4176,4468,2602,842,341,256,341,4453,512]

theorem envBound23414 : H12AffineFastState.Bounded env23414 := by
  intro p hp
  have h : env23414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23413_23414 : H12AffineEnvironment.transform 12 887 env23413 = env23414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 887 env23413 == env23414) = true)

theorem identity23414 : scanCanonicalize (H12AffineFastState.compose env23414 (packedSelected [3,5,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound23414 : packedSelected [3,5,10,11,15] rootPS < 2^1333 := by decide +kernel

def env23415 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,2097,887,2650,1,34,2324,2602,321,0,2161,340,847,374,886,65,2603,2145,2373,2602,842,341,256,341,2388,512]

theorem envBound23415 : H12AffineFastState.Bounded env23415 := by
  intro p hp
  have h : env23415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23414_23415 : H12AffineEnvironment.transform 11 2097 env23414 = env23415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env23414 == env23415) = true)

theorem identity23415 : scanCanonicalize (H12AffineFastState.compose env23415 (packedSelected [0,2,4,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound23415 : packedSelected [0,2,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env23416 : List Nat := [2,4,8,16,32,64,9,256,512,321,293,276,887,895,1,34,49,783,321,0,340,340,847,374,886,65,782,324,96,783,842,341,256,341,113,512]

theorem envBound23416 : H12AffineFastState.Bounded env23416 := by
  intro p hp
  have h : env23416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23415_23416 : H12AffineEnvironment.transform 10 293 env23415 = env23416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env23415 == env23416) = true)

theorem identity23416 : scanCanonicalize (H12AffineFastState.compose env23416 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 303) := by decide +kernel

theorem selectedBound23416 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23417 : List Nat := [2,4,8,16,32,64,9,256,303,321,293,276,88,80,1,34,49,32,321,0,340,340,96,374,89,65,33,324,96,32,101,341,256,341,113,303]

theorem envBound23417 : H12AffineFastState.Bounded env23417 := by
  intro p hp
  have h : env23417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23416_23417 : H12AffineEnvironment.transform 8 303 env23416 = env23417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 303 env23416 == env23417) = true)

theorem identity23417 : scanCanonicalize (H12AffineFastState.compose env23417 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 44) := by decide +kernel

theorem selectedBound23417 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23418 : List Nat := [2,4,8,16,32,64,9,44,3,109,9,56,88,80,1,34,49,32,109,0,120,120,96,90,89,65,33,104,96,32,101,121,44,121,113,3]

theorem envBound23418 : H12AffineFastState.Bounded env23418 := by
  intro p hp
  have h : env23418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23417_23418 : H12AffineEnvironment.transform 7 44 env23417 = env23418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 44 env23417 == env23418) = true)

theorem identity23418 : scanCanonicalize (H12AffineFastState.compose env23418 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23418 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env23419 : List Nat := [2,4,8,16,32,17,9,44,3,60,9,56,9,1,1,34,49,32,60,0,41,41,49,11,8,16,33,57,49,32,52,40,44,40,32,3]

theorem envBound23419 : H12AffineFastState.Bounded env23419 := by
  intro p hp
  have h : env23419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23418_23419 : H12AffineEnvironment.transform 5 17 env23418 = env23419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23418 == env23419) = true)

theorem identity23419 : scanCanonicalize (H12AffineFastState.compose env23419 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound23419 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env23420 : List Nat := [2,4,8,16,8,17,9,4,3,20,9,16,9,1,1,10,25,8,20,0,1,1,25,11,8,16,9,17,25,8,28,0,4,0,8,3]

theorem envBound23420 : H12AffineFastState.Bounded env23420 := by
  intro p hp
  have h : env23420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23419_23420 : H12AffineEnvironment.transform 4 8 env23419 = env23420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env23419 == env23420) = true)

def env23421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,156013,120014,188871,8328,65,10588,226571,102878,109047,176408,128298,256,188900,131136,235215]

theorem envBound23421 : H12AffineFastState.Bounded env23421 := by
  intro p hp
  have h : env23421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23402_23421 : H12AffineEnvironment.transform 17 179513 env23402 = env23421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env23402 == env23421) = true)

theorem identity23421 : scanCanonicalize (H12AffineFastState.compose env23421 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound23421 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149996,1024,29908,4161,156013,73755,136466,8328,65,10588,226571,91403,89378,148941,66047,256,136497,131136,221722]

theorem envBound23422 : H12AffineFastState.Bounded env23422 := by
  intro p hp
  have h : env23422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23421_23422 : H12AffineEnvironment.transform 14 29909 env23421 = env23422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env23421 == env23422) = true)

def env23423 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,149948,1024,29828,4113,155965,73755,136466,8328,17,10508,226571,91403,89378,148893,65967,256,136497,131088,221722]

theorem envBound23423 : H12AffineFastState.Bounded env23423 := by
  intro p hp
  have h : env23423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23422_23423 : H12AffineEnvironment.transform 5 16 env23422 = env23423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23422 == env23423) = true)

theorem identity23423 : scanCanonicalize (H12AffineFastState.compose env23423 (packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound23423 : packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env23424 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,79130,97446,1024,29828,4113,87079,73755,73736,8328,17,10508,16401,91403,89378,94343,65967,256,73771,79114,22272]

theorem envBound23424 : H12AffineFastState.Bounded env23424 := by
  intro p hp
  have h : env23424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23423_23424 : H12AffineEnvironment.transform 16 79130 env23423 = env23424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env23423 == env23424) = true)

theorem identity23424 : scanCanonicalize (H12AffineFastState.compose env23424 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound23424 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env23425 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8322,5528,23588,1024,29828,4113,29861,153,138,8328,17,10508,16401,17801,32160,20485,8493,256,169,5512,22272]

theorem envBound23425 : H12AffineFastState.Bounded env23425 := by
  intro p hp
  have h : env23425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23424_23425 : H12AffineEnvironment.transform 15 8322 env23424 = env23425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env23424 == env23425) = true)

theorem identity23425 : scanCanonicalize (H12AffineFastState.compose env23425 (packedSelected [3,4,8,9,10,11,12,14,15,16,17,18,20] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound23425 : packedSelected [3,4,8,9,10,11,12,14,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env23426 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,29829,8322,5172,23588,1024,29828,4113,29861,153,138,8328,17,10400,16401,17445,31756,20485,8321,172,169,5156,22188]

theorem envBound23426 : H12AffineFastState.Bounded env23426 := by
  intro p hp
  have h : env23426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23425_23426 : H12AffineEnvironment.transform 7 172 env23425 = env23426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env23425 == env23426) = true)

theorem identity23426 : scanCanonicalize (H12AffineFastState.compose env23426 (packedSelected [0,2,4,5,6,7,8,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound23426 : packedSelected [0,2,4,5,6,7,8,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23427 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5156,8353,8322,5172,2048,1024,8352,4113,8321,153,138,8328,17,10400,5173,4097,10280,1057,8321,172,169,5156,648]

theorem envBound23427 : H12AffineFastState.Bounded env23427 := by
  intro p hp
  have h : env23427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23426_23427 : H12AffineEnvironment.transform 13 5156 env23426 = env23427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env23426 == env23427) = true)

theorem identity23427 : scanCanonicalize (H12AffineFastState.compose env23427 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 129) := by decide +kernel

theorem selectedBound23427 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23428 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,129,5156,32,3,5172,2048,1024,33,4113,0,153,138,9,17,2081,5173,4097,2217,1057,0,172,169,5156,648]

theorem envBound23428 : H12AffineFastState.Bounded env23428 := by
  intro p hp
  have h : env23428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23427_23428 : H12AffineEnvironment.transform 12 129 env23427 = env23428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env23427 == env23428) = true)

theorem identity23428 : scanCanonicalize (H12AffineFastState.compose env23428 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound23428 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23429 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,41,5156,32,3,5172,2048,1024,33,4113,0,49,34,9,17,2081,5173,4097,2049,1057,0,4,1,5156,544]

theorem envBound23429 : H12AffineFastState.Bounded env23429 := by
  intro p hp
  have h : env23429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23428_23429 : H12AffineEnvironment.transform 6 40 env23428 = env23429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env23428 == env23429) = true)

theorem identity23429 : scanCanonicalize (H12AffineFastState.compose env23429 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23429 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env23430 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,9,5124,0,3,5140,2048,1024,1,4113,0,17,2,9,17,2049,5141,4097,2049,1025,0,4,1,5124,512]

theorem envBound23430 : H12AffineFastState.Bounded env23430 := by
  intro p hp
  have h : env23430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23429_23430 : H12AffineEnvironment.transform 4 0 env23429 = env23430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23429 == env23430) = true)

def env23431 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,149949,1024,29829,4112,155964,73755,136466,8328,16,10509,226571,91403,89378,148892,65966,256,136497,131089,221722]

theorem envBound23431 : H12AffineFastState.Bounded env23431 := by
  intro p hp
  have h : env23431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23422_23431 : H12AffineEnvironment.transform 5 17 env23422 = env23431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23422 == env23431) = true)

theorem identity23431 : scanCanonicalize (H12AffineFastState.compose env23431 (packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23431 : packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env23432 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,65536,131072,149813,1024,29709,4112,155964,73755,136466,8192,16,10509,226571,91403,89378,148756,65830,256,136497,131089,221722]

theorem envBound23432 : H12AffineFastState.Bounded env23432 := by
  intro p hp
  have h : env23432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23431_23432 : H12AffineEnvironment.transform 6 8 env23431 = env23432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23431 == env23432) = true)

theorem identity23432 : scanCanonicalize (H12AffineFastState.compose env23432 (packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 21794) := by decide +kernel

theorem selectedBound23432 : packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env23433 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,21794,131072,149813,1024,29709,4112,155964,30009,136466,8192,16,10509,139305,12329,2048,148756,21508,256,136497,131089,145208]

theorem envBound23433 : H12AffineFastState.Bounded env23433 := by
  intro p hp
  have h : env23433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23432_23433 : H12AffineEnvironment.transform 15 21794 env23432 = env23433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21794 env23432 == env23433) = true)

theorem identity23433 : scanCanonicalize (H12AffineFastState.compose env23433 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 13625) := by decide +kernel

theorem selectedBound23433 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env23434 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,21794,13625,31756,1024,29709,4112,21509,30009,8235,8192,16,10509,5392,12329,2048,28717,21508,256,8200,13608,513]

theorem envBound23434 : H12AffineFastState.Bounded env23434 := by
  intro p hp
  have h : env23434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23433_23434 : H12AffineEnvironment.transform 16 13625 env23433 = env23434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13625 env23433 == env23434) = true)

theorem identity23434 : scanCanonicalize (H12AffineFastState.compose env23434 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 12344) := by decide +kernel

theorem selectedBound23434 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env23435 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,12344,1076,9498,13625,3124,1024,1077,4112,9277,1281,8235,8192,16,10509,5392,12329,2048,21,9276,256,8200,13608,513]

theorem envBound23435 : H12AffineFastState.Bounded env23435 := by
  intro p hp
  have h : env23435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23434_23435 : H12AffineEnvironment.transform 13 12344 env23434 = env23435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12344 env23434 == env23435) = true)

theorem identity23435 : scanCanonicalize (H12AffineFastState.compose env23435 (packedSelected [0,3,4,5,7,9,10,14,17] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound23435 : packedSelected [0,3,4,5,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env23436 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,8192,12344,1,8495,12556,2049,53,0,4112,8200,308,8235,8192,16,10509,4389,12329,2048,21,8201,256,8200,12573,513]

theorem envBound23436 : H12AffineFastState.Bounded env23436 := by
  intro p hp
  have h : env23436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23435_23436 : H12AffineEnvironment.transform 9 53 env23435 = env23436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env23435 == env23436) = true)

def env23437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156013,485879,16777216,8328,65,16959643,17246708,102879,109047,17231334,17148373,256,16777250,16834950,17287729]

theorem envBound23437 : H12AffineFastState.Bounded env23437 := by
  intro p hp
  have h : env23437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23400_23437 : H12AffineEnvironment.transform 20 437625 env23400 = env23437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437625 env23400 == env23437) = true)

def env23438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156013,485879,510000,8328,65,327851,57796,102879,109047,75222,156133,256,509970,469430,513]

theorem envBound23438 : H12AffineFastState.Bounded env23438 := by
  intro p hp
  have h : env23438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23437_23438 : H12AffineEnvironment.transform 23 510000 env23437 = env23438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510000 env23437 == env23438) = true)

def env23439 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156013,485759,510000,8192,65,327715,57676,102743,108927,75102,156013,256,509970,469310,513]

theorem envBound23439 : H12AffineFastState.Bounded env23439 := by
  intro p hp
  have h : env23439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23438_23439 : H12AffineEnvironment.transform 6 8 env23438 = env23439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23438 == env23439) = true)

theorem identity23439 : scanCanonicalize (H12AffineFastState.compose env23439 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound23439 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env23440 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,380258,65910,264548,305195,8192,65,327715,57676,102743,108927,75102,65910,256,305161,280869,513]

theorem envBound23440 : H12AffineFastState.Bounded env23440 := by
  intro p hp
  have h : env23440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23439_23440 : H12AffineEnvironment.transform 16 90139 env23439 = env23440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env23439 == env23440) = true)

theorem identity23440 : scanCanonicalize (H12AffineFastState.compose env23440 (packedSelected [0,1,4,5,8,9,11,15,17,18,20,23,24,27,32,38] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound23440 : packedSelected [0,1,4,5,8,9,11,15,17,18,20,23,24,27,32,38] rootPS < 2^1333 := by decide +kernel

def env23441 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,32768,65536,77914,262144,1024,32769,367907,65910,264548,305195,8192,65,327715,45325,102743,108927,75102,65910,256,305161,268644,513]

theorem envBound23441 : H12AffineFastState.Bounded env23441 := by
  intro p hp
  have h : env23441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23440_23441 : H12AffineEnvironment.transform 13 4161 env23440 = env23441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env23440 == env23441) = true)

theorem identity23441 : scanCanonicalize (H12AffineFastState.compose env23441 (packedSelected [0,7,8,10,17,18,20,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound23441 : packedSelected [0,7,8,10,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env23442 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,32768,8282,4096,262144,1024,32769,310649,8492,264548,305195,8192,65,270457,45325,45325,35109,1284,8492,256,305161,268644,513]

theorem envBound23442 : H12AffineFastState.Bounded env23442 := by
  intro p hp
  have h : env23442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23441_23442 : H12AffineEnvironment.transform 15 8282 env23441 = env23442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env23441 == env23442) = true)

theorem identity23442 : scanCanonicalize (H12AffineFastState.compose env23442 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound23442 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env23443 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,32768,8282,4096,35188,1024,32769,13325,8492,32784,8543,8192,65,43277,45325,45325,35109,1284,8492,256,8573,36880,513]

theorem envBound23443 : H12AffineFastState.Bounded env23443 := by
  intro p hp
  have h : env23443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23442_23443 : H12AffineEnvironment.transform 17 35188 env23442 = env23443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env23442 == env23443) = true)

def env23444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156013,485758,510000,8193,65,327714,57677,102742,108926,75103,156012,256,509970,469311,513]

theorem envBound23444 : H12AffineFastState.Bounded env23444 := by
  intro p hp
  have h : env23444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23438_23444 : H12AffineEnvironment.transform 6 9 env23438 = env23444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23438 == env23444) = true)

theorem identity23444 : scanCanonicalize (H12AffineFastState.compose env23444 (packedSelected [0,3,10,11,14,15,16,17,18,19,20,23,24,27,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound23444 : packedSelected [0,3,10,11,14,15,16,17,18,19,20,23,24,27,32,38] rootPS < 2^1333 := by decide +kernel

def env23445 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,396324,156013,485758,485741,8193,65,327714,16400,77835,67619,75103,156012,256,485711,469311,513]

theorem envBound23445 : H12AffineFastState.Bounded env23445 := by
  intro p hp
  have h : env23445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23444_23445 : H12AffineEnvironment.transform 14 8541 env23444 = env23445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env23444 == env23445) = true)

theorem identity23445 : scanCanonicalize (H12AffineFastState.compose env23445 (packedSelected [1,3,7,14,16,18,23,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 223551) := by decide +kernel

theorem selectedBound23445 : packedSelected [1,3,7,14,16,18,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env23446 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,223551,1024,8540,91419,156013,65,82,8193,65,157981,16400,77835,67619,75103,156012,256,112,16384,513]

theorem envBound23446 : H12AffineFastState.Bounded env23446 := by
  intro p hp
  have h : env23446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23445_23446 : H12AffineEnvironment.transform 17 223551 env23445 = env23446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223551 env23445 == env23446) = true)

theorem identity23446 : scanCanonicalize (H12AffineFastState.compose env23446 (packedSelected [2,6,16,17,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23446 : packedSelected [2,6,16,17,20] rootPS < 2^1333 := by decide +kernel

def env23447 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,65536,131072,223551,1024,8460,91419,155965,17,2,8193,17,157981,16400,77835,67619,75023,155964,256,32,16384,513]

theorem envBound23447 : H12AffineFastState.Bounded env23447 := by
  intro p hp
  have h : env23447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23446_23447 : H12AffineEnvironment.transform 5 16 env23446 = env23447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23446 == env23447) = true)

theorem identity23447 : scanCanonicalize (H12AffineFastState.compose env23447 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound23447 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env23448 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,65536,16400,76079,1024,8460,91419,8493,17,2,8193,17,10509,16400,77835,67619,75023,8492,256,32,16384,513]

theorem envBound23448 : H12AffineFastState.Bounded env23448 := by
  intro p hp
  have h : env23448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23447_23448 : H12AffineEnvironment.transform 16 16400 env23447 = env23448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env23447 == env23448) = true)

theorem identity23448 : scanCanonicalize (H12AffineFastState.compose env23448 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23448 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23449 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,65536,16400,67619,1024,0,82967,33,17,2,269,17,2049,16400,69895,67619,66563,32,256,32,16384,513]

theorem envBound23449 : H12AffineFastState.Bounded env23449 := by
  intro p hp
  have h : env23449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23448_23449 : H12AffineEnvironment.transform 12 268 env23448 = env23449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23448 == env23449) = true)

theorem identity23449 : scanCanonicalize (H12AffineFastState.compose env23449 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound23449 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23450 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2049,268,16384,1,65536,16400,67619,1024,0,82967,33,17,2,269,17,2049,16400,67846,67619,66563,32,256,32,16384,513]

theorem envBound23450 : H12AffineFastState.Bounded env23450 := by
  intro p hp
  have h : env23450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23449_23450 : H12AffineEnvironment.transform 11 2049 env23449 = env23450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env23449 == env23450) = true)

theorem identity23450 : scanCanonicalize (H12AffineFastState.compose env23450 (packedSelected [1,3,4,5,8,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound23450 : packedSelected [1,3,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env23451 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1281,1280,268,16384,1,65536,16400,66850,1024,0,82967,33,17,2,269,17,1280,16400,66567,66850,66563,32,256,32,16384,513]

theorem envBound23451 : H12AffineFastState.Bounded env23451 := by
  intro p hp
  have h : env23451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23450_23451 : H12AffineEnvironment.transform 10 1281 env23450 = env23451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env23450 == env23451) = true)

theorem identity23451 : scanCanonicalize (H12AffineFastState.compose env23451 (packedSelected [0,2,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 17415) := by decide +kernel

theorem selectedBound23451 : packedSelected [0,2,9,10] rootPS < 2^1333 := by decide +kernel

def env23452 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1281,1280,268,16384,1,17415,16400,16677,1024,0,16,33,17,2,269,17,1280,16400,16384,16677,16388,32,256,32,16384,513]

theorem envBound23452 : H12AffineFastState.Bounded env23452 := by
  intro p hp
  have h : env23452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23451_23452 : H12AffineEnvironment.transform 15 17415 env23451 = env23452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17415 env23451 == env23452) = true)

theorem identity23452 : scanCanonicalize (H12AffineFastState.compose env23452 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound23452 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env23453 : List Nat := [2,4,8,16,32,16,9,256,512,37,292,293,268,16384,1,16418,16400,16677,37,0,16,33,17,2,269,17,293,16400,16384,16677,16388,32,256,32,16384,513]

theorem envBound23453 : H12AffineFastState.Bounded env23453 := by
  intro p hp
  have h : env23453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23452_23453 : H12AffineEnvironment.transform 9 37 env23452 = env23453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env23452 == env23453) = true)

theorem identity23453 : scanCanonicalize (H12AffineFastState.compose env23453 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound23453 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23454 : List Nat := [2,4,8,16,32,16,9,256,512,37,292,293,268,293,1,263,309,0,37,0,16,33,17,2,269,17,293,309,293,0,289,32,256,32,293,513]

theorem envBound23454 : H12AffineFastState.Bounded env23454 := by
  intro p hp
  have h : env23454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23453_23454 : H12AffineEnvironment.transform 13 293 env23453 = env23454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env23453 == env23454) = true)

theorem identity23454 : scanCanonicalize (H12AffineFastState.compose env23454 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound23454 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23455 : List Nat := [2,4,8,16,32,16,9,256,293,37,292,293,268,293,1,263,309,0,37,0,16,33,17,2,269,17,293,309,293,0,289,32,256,32,293,292]

theorem envBound23455 : H12AffineFastState.Bounded env23455 := by
  intro p hp
  have h : env23455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23454_23455 : H12AffineEnvironment.transform 8 293 env23454 = env23455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env23454 == env23455) = true)

theorem identity23455 : scanCanonicalize (H12AffineFastState.compose env23455 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23455 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23456 : List Nat := [2,4,8,1,32,1,9,256,293,37,292,293,268,293,1,263,292,0,37,0,1,33,0,2,269,0,293,292,293,0,289,32,256,32,293,292]

theorem envBound23456 : H12AffineFastState.Bounded env23456 := by
  intro p hp
  have h : env23456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23455_23456 : H12AffineEnvironment.transform 3 1 env23455 = env23456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23455 == env23456) = true)

theorem identity23456 : scanCanonicalize (H12AffineFastState.compose env23456 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23456 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23457 : List Nat := [2,4,8,1,1,1,9,256,260,4,261,260,268,260,1,263,261,0,4,0,1,0,0,2,269,0,260,261,260,0,256,1,256,1,260,261]

theorem envBound23457 : H12AffineFastState.Bounded env23457 := by
  intro p hp
  have h : env23457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23456_23457 : H12AffineEnvironment.transform 4 1 env23456 = env23457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23456 == env23457) = true)

theorem identity23457 : scanCanonicalize (H12AffineFastState.compose env23457 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23457 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23458 : List Nat := [2,4,8,1,1,1,9,5,1,4,0,1,9,1,1,2,0,0,4,0,1,0,0,2,8,0,1,0,1,0,5,1,5,1,1,0]

theorem envBound23458 : H12AffineFastState.Bounded env23458 := by
  intro p hp
  have h : env23458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23457_23458 : H12AffineEnvironment.transform 7 5 env23457 = env23458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23457 == env23458) = true)

def env23459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156013,485879,510001,8328,65,327850,57797,102879,109047,75223,156132,256,509971,469431,512]

theorem envBound23459 : H12AffineFastState.Bounded env23459 := by
  intro p hp
  have h : env23459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23437_23459 : H12AffineEnvironment.transform 23 510001 env23437 = env23459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510001 env23437 == env23459) = true)

theorem identity23459 : scanCanonicalize (H12AffineFastState.compose env23459 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound23459 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,156013,120014,95496,8328,65,245139,57797,102879,109047,75223,156132,256,95530,103566,512]

theorem envBound23460 : H12AffineFastState.Bounded env23460 := by
  intro p hp
  have h : env23460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23459_23460 : H12AffineEnvironment.transform 17 179513 env23459 = env23460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env23459 == env23460) = true)

theorem identity23460 : scanCanonicalize (H12AffineFastState.compose env23460 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103631) := by decide +kernel

theorem selectedBound23460 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env23461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103631,76278,1024,32769,4160,128418,120014,95496,8328,65,10588,57797,102879,109047,75223,128299,256,95530,103566,512]

theorem envBound23461 : H12AffineFastState.Bounded env23461 := by
  intro p hp
  have h : env23461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23460_23461 : H12AffineEnvironment.transform 16 103631 env23460 = env23461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103631 env23460 == env23461) = true)

theorem identity23461 : scanCanonicalize (H12AffineFastState.compose env23461 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound23461 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env23462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16400,64809,1024,32769,4160,8573,17,41431,8328,65,10588,57797,17664,32040,61704,8692,256,41461,16465,512]

theorem envBound23462 : H12AffineFastState.Bounded env23462 := by
  intro p hp
  have h : env23462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23461_23462 : H12AffineEnvironment.transform 15 54495 env23461 = env23462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env23461 == env23462) = true)

theorem identity23462 : scanCanonicalize (H12AffineFastState.compose env23462 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound23462 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env23463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,16384,32768,54495,16400,56577,1024,32769,4160,341,17,33279,160,65,2420,49645,17664,23808,53536,476,256,33245,16465,512]

theorem envBound23463 : H12AffineFastState.Bounded env23463 := by
  intro p hp
  have h : env23463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23462_23463 : H12AffineEnvironment.transform 12 40 env23462 = env23463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env23462 == env23463) = true)

theorem identity23463 : scanCanonicalize (H12AffineFastState.compose env23463 (packedSelected [2,4,5,12,14,15,17,18,19,20,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21929) := by decide +kernel

theorem selectedBound23463 : packedSelected [2,4,5,12,14,15,17,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env23464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,16384,21929,374,16400,2216,1024,21928,4160,341,17,21590,160,65,2420,5188,17664,23808,1161,476,256,21620,16465,512]

theorem envBound23464 : H12AffineFastState.Bounded env23464 := by
  intro p hp
  have h : env23464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23463_23464 : H12AffineEnvironment.transform 14 21929 env23463 = env23464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21929 env23463 == env23464) = true)

theorem identity23464 : scanCanonicalize (H12AffineFastState.compose env23464 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound23464 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env23465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5376,169,374,5392,2216,1024,168,4160,341,17,342,160,65,2420,5188,4096,2048,1161,476,256,372,5457,512]

theorem envBound23465 : H12AffineFastState.Bounded env23465 := by
  intro p hp
  have h : env23465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23464_23465 : H12AffineEnvironment.transform 13 5376 env23464 = env23465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env23464 == env23465) = true)

theorem identity23465 : scanCanonicalize (H12AffineFastState.compose env23465 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound23465 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env23466 : List Nat := [2,4,8,16,32,49,128,256,512,1024,2048,4096,40,5376,169,263,5392,2216,1024,168,4145,292,17,295,160,48,2309,5173,4096,2048,1161,429,256,261,5408,512]

theorem envBound23466 : H12AffineFastState.Bounded env23466 := by
  intro p hp
  have h : env23466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23465_23466 : H12AffineEnvironment.transform 5 49 env23465 = env23466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env23465 == env23466) = true)

theorem identity23466 : scanCanonicalize (H12AffineFastState.compose env23466 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound23466 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23467 : List Nat := [2,4,8,16,32,49,128,172,512,1024,2048,4096,40,5292,169,171,5308,2216,1024,168,4145,136,17,139,160,48,2217,5173,4096,2048,1161,1,172,169,5260,512]

theorem envBound23467 : H12AffineFastState.Bounded env23467 := by
  intro p hp
  have h : env23467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23466_23467 : H12AffineEnvironment.transform 7 172 env23466 = env23467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env23466 == env23467) = true)

theorem identity23467 : scanCanonicalize (H12AffineFastState.compose env23467 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound23467 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23468 : List Nat := [2,4,8,16,32,49,128,172,512,1024,1213,4096,40,5292,169,171,5308,1045,1024,168,4145,136,17,139,160,48,1044,5173,4096,1213,1161,1,172,169,5260,512]

theorem envBound23468 : H12AffineFastState.Bounded env23468 := by
  intro p hp
  have h : env23468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23467_23468 : H12AffineEnvironment.transform 10 1213 env23467 = env23468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env23467 == env23468) = true)

theorem identity23468 : scanCanonicalize (H12AffineFastState.compose env23468 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound23468 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env23469 : List Nat := [2,4,8,16,32,49,128,172,512,21,168,4096,40,4281,169,171,4265,0,21,168,4145,136,17,139,160,48,1,4128,4096,168,156,1,172,169,4249,512]

theorem envBound23469 : H12AffineFastState.Bounded env23469 := by
  intro p hp
  have h : env23469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23468_23469 : H12AffineEnvironment.transform 9 21 env23468 = env23469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env23468 == env23469) = true)

theorem identity23469 : scanCanonicalize (H12AffineFastState.compose env23469 (packedSelected [0,2,3,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound23469 : packedSelected [0,2,3,5,9] rootPS < 2^1333 := by decide +kernel

def env23470 : List Nat := [2,4,8,16,32,49,128,172,512,21,168,17,40,168,169,171,184,0,21,168,32,136,17,139,160,48,1,49,17,168,156,1,172,169,136,512]

theorem envBound23470 : H12AffineFastState.Bounded env23470 := by
  intro p hp
  have h : env23470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23469_23470 : H12AffineEnvironment.transform 11 17 env23469 = env23470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env23469 == env23470) = true)

theorem identity23470 : scanCanonicalize (H12AffineFastState.compose env23470 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23470 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env23471 : List Nat := [2,4,8,16,32,49,9,37,512,21,33,17,40,33,32,34,49,0,21,33,32,1,17,2,41,48,1,49,17,33,21,1,37,32,1,512]

theorem envBound23471 : H12AffineFastState.Bounded env23471 := by
  intro p hp
  have h : env23471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23470_23471 : H12AffineEnvironment.transform 6 9 env23470 = env23471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23470 == env23471) = true)

def env23472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound23472 : H12AffineFastState.Bounded env23472 := by
  intro p hp
  have h : env23472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23321_23472 : H12AffineEnvironment.transform 18 1025 env23321 = env23472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env23321 == env23472) = true)

theorem identity23472 : scanCanonicalize (H12AffineFastState.compose env23472 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 297334) := by decide +kernel

theorem selectedBound23472 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297334,8328,65,12798326,2428410,10507601,8830977,8719719,6679735,257,10833371,10857598,8661681]

theorem envBound23473 : H12AffineFastState.Bounded env23473 := by
  intro p hp
  have h : env23473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23472_23473 : H12AffineEnvironment.transform 23 297334 env23472 = env23473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 297334 env23472 == env23473) = true)

def env23474 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297334,8192,65,12798326,2428274,10507601,8830977,8719719,6679615,257,10833235,10857598,8661561]

theorem envBound23474 : H12AffineFastState.Bounded env23474 := by
  intro p hp
  have h : env23474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23473_23474 : H12AffineEnvironment.transform 6 8 env23473 = env23474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23473 == env23474) = true)

def env23475 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297334,8192,65,12650854,2428274,10507601,8683537,8719719,6679615,257,10833235,10857598,8661561]

theorem envBound23475 : H12AffineFastState.Bounded env23475 := by
  intro p hp
  have h : env23475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23474_23475 : H12AffineEnvironment.transform 16 16400 env23474 = env23475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env23474 == env23475) = true)

theorem identity23475 : scanCanonicalize (H12AffineFastState.compose env23475 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound23475 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env23476 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,17,297334,8192,65,4262263,2428274,2118976,294912,331126,6679615,257,2444610,2468975,272936]

theorem envBound23476 : H12AffineFastState.Bounded env23476 := by
  intro p hp
  have h : env23476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23475_23476 : H12AffineEnvironment.transform 22 17 env23475 = env23476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env23475 == env23476) = true)

theorem identity23476 : scanCanonicalize (H12AffineFastState.compose env23476 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound23476 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env23477 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,17,41311,8192,65,4262263,2172251,2118976,43049,75103,6407190,257,2188651,2196550,513]

theorem envBound23477 : H12AffineFastState.Bounded env23477 := by
  intro p hp
  have h : env23477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23476_23477 : H12AffineEnvironment.transform 17 10281 env23476 = env23477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23476 == env23477) = true)

def env23478 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58396,4194304,17,41311,8192,65,4262263,115015,45404,43049,75103,4268042,257,98679,90202,513]

theorem envBound23478 : H12AffineFastState.Bounded env23478 := by
  intro p hp
  have h : env23478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23477_23478 : H12AffineEnvironment.transform 20 58396 env23477 = env23478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env23477 == env23478) = true)

theorem identity23478 : scanCanonicalize (H12AffineFastState.compose env23478 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound23478 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env23479 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1025,8540,17729,4194304,17,2,8192,65,4262263,90138,4097,2420,75103,4268042,257,73770,90202,513]

theorem envBound23479 : H12AffineFastState.Bounded env23479 := by
  intro p hp
  have h : env23479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23478_23479 : H12AffineEnvironment.transform 14 8541 env23478 = env23479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env23478 == env23479) = true)

theorem identity23479 : scanCanonicalize (H12AffineFastState.compose env23479 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound23479 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env23480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,263,16400,10281,1025,8540,17729,4194304,17,2,8192,65,4196464,24861,4097,2420,9304,4202765,257,8493,24925,513]

theorem envBound23480 : H12AffineFastState.Bounded env23480 := by
  intro p hp
  have h : env23480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23479_23480 : H12AffineEnvironment.transform 15 263 env23479 = env23480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env23479 == env23480) = true)

theorem identity23480 : scanCanonicalize (H12AffineFastState.compose env23480 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound23480 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env23481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,263,16400,10281,1025,8540,17729,113,17,2,8192,65,2049,24861,4097,2420,9304,8572,257,8493,24925,513]

theorem envBound23481 : H12AffineFastState.Bounded env23481 := by
  intro p hp
  have h : env23481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23480_23481 : H12AffineEnvironment.transform 21 113 env23480 = env23481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env23480 == env23481) = true)

theorem identity23481 : scanCanonicalize (H12AffineFastState.compose env23481 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23481 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env23482 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,263,16400,10281,1025,8460,17681,33,17,2,8192,17,2049,24861,4097,2340,9224,8492,257,8493,24845,513]

theorem envBound23482 : H12AffineFastState.Bounded env23482 := by
  intro p hp
  have h : env23482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23481_23482 : H12AffineEnvironment.transform 5 16 env23481 = env23482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23481 == env23482) = true)

def env23483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58397,4194304,17,41311,8192,65,4262263,115014,45405,43049,75103,4268043,257,98678,90203,513]

theorem envBound23483 : H12AffineFastState.Bounded env23483 := by
  intro p hp
  have h : env23483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23477_23483 : H12AffineEnvironment.transform 20 58397 env23477 = env23483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env23477 == env23483) = true)

theorem identity23483 : scanCanonicalize (H12AffineFastState.compose env23483 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23483 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1025,32769,58397,4194304,17,41311,8192,65,4204924,57677,45405,43049,1364,4194304,257,41341,16464,513]

theorem envBound23484 : H12AffineFastState.Bounded env23484 := by
  intro p hp
  have h : env23484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23483_23484 : H12AffineEnvironment.transform 15 8203 env23483 = env23484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23483 == env23484) = true)

theorem identity23484 : scanCanonicalize (H12AffineFastState.compose env23484 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound23484 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env23485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1025,32769,58397,113,17,41311,8192,65,10509,57677,45405,43049,1364,113,257,41341,16464,513]

theorem envBound23485 : H12AffineFastState.Bounded env23485 := by
  intro p hp
  have h : env23485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23484_23485 : H12AffineEnvironment.transform 21 113 env23484 = env23485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env23484 == env23485) = true)

theorem identity23485 : scanCanonicalize (H12AffineFastState.compose env23485 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound23485 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,343,16400,2421,1025,32769,50497,113,17,32771,348,65,2129,49169,36865,35189,1364,113,257,32801,16464,513]

theorem envBound23486 : H12AffineFastState.Bounded env23486 := by
  intro p hp
  have h : env23486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23485_23486 : H12AffineEnvironment.transform 12 348 env23485 = env23486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env23485 == env23486) = true)

theorem identity23486 : scanCanonicalize (H12AffineFastState.compose env23486 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23486 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env23487 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,263,16400,2341,1025,32769,50449,33,17,32771,268,17,2049,49169,36865,35109,1284,33,257,32801,16384,513]

theorem envBound23487 : H12AffineFastState.Bounded env23487 := by
  intro p hp
  have h : env23487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23486_23487 : H12AffineEnvironment.transform 5 16 env23486 = env23487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23486 == env23487) = true)

theorem identity23487 : scanCanonicalize (H12AffineFastState.compose env23487 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23487 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23488 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,0,263,16400,2341,1025,1,17681,33,17,3,268,17,2049,16401,4097,2341,1284,33,257,33,16384,513]

theorem envBound23488 : H12AffineFastState.Bounded env23488 := by
  intro p hp
  have h : env23488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23487_23488 : H12AffineEnvironment.transform 14 0 env23487 = env23488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23487 == env23488) = true)

theorem identity23488 : scanCanonicalize (H12AffineFastState.compose env23488 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound23488 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23489 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,263,5393,2341,1025,1,4112,33,17,3,268,17,2049,5392,4097,2341,1284,33,257,33,5377,513]

theorem envBound23489 : H12AffineFastState.Bounded env23489 := by
  intro p hp
  have h : env23489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23488_23489 : H12AffineEnvironment.transform 13 5377 env23488 = env23489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env23488 == env23489) = true)

theorem identity23489 : scanCanonicalize (H12AffineFastState.compose env23489 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound23489 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23490 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,308,268,1077,0,263,1061,2341,1025,1,292,33,17,3,268,17,2049,1060,309,2341,1284,33,257,33,1077,513]

theorem envBound23490 : H12AffineFastState.Bounded env23490 := by
  intro p hp
  have h : env23490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23489_23490 : H12AffineEnvironment.transform 11 308 env23489 = env23490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env23489 == env23490) = true)

def env23491 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297334,8192,65,12650855,2428274,10507601,8683536,8719719,6679615,257,10833235,10857598,8661561]

theorem envBound23491 : H12AffineFastState.Bounded env23491 := by
  intro p hp
  have h : env23491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23474_23491 : H12AffineEnvironment.transform 16 16401 env23474 = env23491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23474 == env23491) = true)

theorem identity23491 : scanCanonicalize (H12AffineFastState.compose env23491 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound23491 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env23492 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,8388608,41311,8192,65,12650855,2172251,10507601,8431673,8463694,6407190,257,10577274,10585175,8389136]

theorem envBound23492 : H12AffineFastState.Bounded env23492 := by
  intro p hp
  have h : env23492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23491_23492 : H12AffineEnvironment.transform 17 10281 env23491 = env23492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env23491 == env23492) = true)

theorem identity23492 : scanCanonicalize (H12AffineFastState.compose env23492 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound23492 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env23493 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,17,41311,8192,65,4262262,2172251,2118976,43048,75103,6407190,257,2188651,2196550,513]

theorem envBound23493 : H12AffineFastState.Bounded env23493 := by
  intro p hp
  have h : env23493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23492_23493 : H12AffineEnvironment.transform 22 17 env23492 = env23493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env23492 == env23493) = true)

theorem identity23493 : scanCanonicalize (H12AffineFastState.compose env23493 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound23493 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env23494 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,115734,4194304,17,41311,8192,65,4262262,57677,102742,43048,75103,4194304,257,41341,16464,513]

theorem envBound23494 : H12AffineFastState.Bounded env23494 := by
  intro p hp
  have h : env23494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23493_23494 : H12AffineEnvironment.transform 20 115734 env23493 = env23494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env23493 == env23494) = true)

theorem identity23494 : scanCanonicalize (H12AffineFastState.compose env23494 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound23494 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env23495 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,16401,10281,1025,32769,50497,4194304,17,41311,8192,65,4196385,57677,36865,43048,9224,4194304,257,41341,16464,513]

theorem envBound23495 : H12AffineFastState.Bounded env23495 := by
  intro p hp
  have h : env23495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23494_23495 : H12AffineEnvironment.transform 15 343 env23494 = env23495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env23494 == env23495) = true)

theorem identity23495 : scanCanonicalize (H12AffineFastState.compose env23495 (packedSelected [0,7,11,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound23495 : packedSelected [0,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env23496 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,16401,10281,1025,8541,25629,4194304,17,3,8192,65,4196385,16401,12637,2420,9224,4194304,257,33,16464,513]

theorem envBound23496 : H12AffineFastState.Bounded env23496 := by
  intro p hp
  have h : env23496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23495_23496 : H12AffineEnvironment.transform 14 8540 env23495 = env23496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env23495 == env23496) = true)

theorem identity23496 : scanCanonicalize (H12AffineFastState.compose env23496 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound23496 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env23497 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,16401,10281,1025,8541,25629,8572,17,3,8192,65,10589,16401,12637,2420,9224,8572,257,33,16464,513]

theorem envBound23497 : H12AffineFastState.Bounded env23497 := by
  intro p hp
  have h : env23497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23496_23497 : H12AffineEnvironment.transform 21 8572 env23496 = env23497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env23496 == env23497) = true)

theorem identity23497 : scanCanonicalize (H12AffineFastState.compose env23497 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 1313) := by decide +kernel

theorem selectedBound23497 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env23498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,1313,8540,343,1328,10281,1025,8541,8508,8572,17,3,8192,65,10589,1328,12637,2420,9224,8572,257,33,1393,513]

theorem envBound23498 : H12AffineFastState.Bounded env23498 := by
  intro p hp
  have h : env23498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23497_23498 : H12AffineEnvironment.transform 13 1313 env23497 = env23498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1313 env23497 == env23498) = true)

theorem identity23498 : scanCanonicalize (H12AffineFastState.compose env23498 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound23498 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env23499 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,1313,1,343,1328,2420,1025,0,97,33,17,3,349,65,2048,1328,4096,2420,1365,33,257,33,1393,513]

theorem envBound23499 : H12AffineFastState.Bounded env23499 := by
  intro p hp
  have h : env23499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23498_23499 : H12AffineEnvironment.transform 12 349 env23498 = env23499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env23498 == env23499) = true)

theorem identity23499 : scanCanonicalize (H12AffineFastState.compose env23499 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound23499 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23500 : List Nat := [2,4,8,16,32,64,8,256,512,785,2048,4096,349,560,1,343,545,2420,784,0,97,33,17,3,349,65,2048,545,4096,2420,580,33,257,33,608,513]

theorem envBound23500 : H12AffineFastState.Bounded env23500 := by
  intro p hp
  have h : env23500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23499_23500 : H12AffineEnvironment.transform 9 785 env23499 = env23500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env23499 == env23500) = true)

def env23501 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297334,8193,65,12798326,2428275,10507601,8830977,8719719,6679614,257,10833234,10857598,8661560]

theorem envBound23501 : H12AffineFastState.Bounded env23501 := by
  intro p hp
  have h : env23501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23473_23501 : H12AffineEnvironment.transform 6 9 env23473 = env23501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23473 == env23501) = true)

def env23502 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297334,8193,65,12650854,2428275,10507601,8683537,8719719,6679614,257,10833234,10857598,8661560]

theorem envBound23502 : H12AffineFastState.Bounded env23502 := by
  intro p hp
  have h : env23502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23501_23502 : H12AffineEnvironment.transform 16 16400 env23501 = env23502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env23501 == env23502) = true)

theorem identity23502 : scanCanonicalize (H12AffineFastState.compose env23502 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 41292) := by decide +kernel

theorem selectedBound23502 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env23503 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,41292,297334,8193,65,4302890,2428275,2159645,270685,371755,6679614,257,2485278,2428210,297844]

theorem envBound23503 : H12AffineFastState.Bounded env23503 := by
  intro p hp
  have h : env23503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23502_23503 : H12AffineEnvironment.transform 22 41292 env23502 = env23503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41292 env23502 == env23503) = true)

theorem identity23503 : scanCanonicalize (H12AffineFastState.compose env23503 (packedSelected [0,9,14,17,21,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23503 : packedSelected [0,9,14,17,21,22,27,35] rootPS < 2^1333 := by decide +kernel

def env23504 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,2097152,4194304,41292,297334,8193,65,4229153,2370936,2159645,270685,298016,6605877,257,2411541,2370873,297844]

theorem envBound23504 : H12AffineFastState.Bounded env23504 := by
  intro p hp
  have h : env23504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23503_23504 : H12AffineEnvironment.transform 15 8203 env23503 = env23504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23503 == env23504) = true)

theorem identity23504 : scanCanonicalize (H12AffineFastState.compose env23504 (packedSelected [0,1,3,5,8,9,10,11,18,19,21,22,23,27,32] rootPS)) = affineNative (2^(20+1) ^^^ 290104) := by decide +kernel

theorem selectedBound23504 : packedSelected [0,1,3,5,8,9,10,11,18,19,21,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env23505 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,290104,4194304,41292,297334,8193,65,4229153,16448,301349,270685,298016,4235533,257,41261,16385,297844]

theorem envBound23505 : H12AffineFastState.Bounded env23505 := by
  intro p hp
  have h : env23505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23504_23505 : H12AffineEnvironment.transform 20 290104 env23504 = env23505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290104 env23504 == env23505) = true)

theorem identity23505 : scanCanonicalize (H12AffineFastState.compose env23505 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 272393) := by decide +kernel

theorem selectedBound23505 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env23506 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,290104,272393,41292,297334,8193,65,303144,16448,301349,270685,298016,297220,257,41261,16385,297844]

theorem envBound23506 : H12AffineFastState.Bounded env23506 := by
  intro p hp
  have h : env23506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23505_23506 : H12AffineEnvironment.transform 21 272393 env23505 = env23506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272393 env23505 == env23506) = true)

theorem identity23506 : scanCanonicalize (H12AffineFastState.compose env23506 (packedSelected [3,10,16,17,19,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound23506 : packedSelected [3,10,16,17,19,20,24] rootPS < 2^1333 := by decide +kernel

def env23507 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,262144,1025,8540,290104,272393,17,272427,8193,65,262517,16448,276600,270685,273789,272473,257,112,16385,272937]

theorem envBound23507 : H12AffineFastState.Bounded env23507 := by
  intro p hp
  have h : env23507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23506_23507 : H12AffineEnvironment.transform 14 8541 env23506 = env23507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env23506 == env23507) = true)

theorem identity23507 : scanCanonicalize (H12AffineFastState.compose env23507 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound23507 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env23508 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10360,1025,8540,17728,113,17,83,8193,65,10509,16448,4096,2341,1285,33,257,112,16385,593]

theorem envBound23508 : H12AffineFastState.Bounded env23508 := by
  intro p hp
  have h : env23508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23507_23508 : H12AffineEnvironment.transform 17 10360 env23507 = env23508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env23507 == env23508) = true)

theorem identity23508 : scanCanonicalize (H12AffineFastState.compose env23508 (packedSelected [2,3,4,5,9,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound23508 : packedSelected [2,3,4,5,9,10,16] rootPS < 2^1333 := by decide +kernel

def env23509 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,8541,8203,5221,10360,1025,8540,4405,113,17,83,8193,65,10509,5173,4096,2341,1285,33,257,112,5236,593]

theorem envBound23509 : H12AffineFastState.Bounded env23509 := by
  intro p hp
  have h : env23509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23508_23509 : H12AffineEnvironment.transform 13 5237 env23508 = env23509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env23508 == env23509) = true)

theorem identity23509 : scanCanonicalize (H12AffineFastState.compose env23509 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound23509 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env23510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5237,1,343,5221,2340,1025,0,4405,113,17,83,349,65,2129,5173,4096,2341,1285,33,257,112,5236,593]

theorem envBound23510 : H12AffineFastState.Bounded env23510 := by
  intro p hp
  have h : env23510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23509_23510 : H12AffineEnvironment.transform 12 348 env23509 = env23510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env23509 == env23510) = true)

theorem identity23510 : scanCanonicalize (H12AffineFastState.compose env23510 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound23510 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env23511 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,348,4161,1,343,4177,2340,53,0,4405,113,17,83,349,65,2129,4097,4096,2341,305,33,257,112,4160,593]

theorem envBound23511 : H12AffineFastState.Bounded env23511 := by
  intro p hp
  have h : env23511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23510_23511 : H12AffineEnvironment.transform 9 52 env23510 = env23511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env23510 == env23511) = true)

theorem identity23511 : scanCanonicalize (H12AffineFastState.compose env23511 (packedSelected [2,3,4,5,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound23511 : packedSelected [2,3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env23512 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,2064,348,2129,1,343,2113,2340,53,0,2341,113,17,83,349,65,2129,2065,2064,2341,305,33,257,112,2128,593]

theorem envBound23512 : H12AffineFastState.Bounded env23512 := by
  intro p hp
  have h : env23512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23511_23512 : H12AffineEnvironment.transform 11 2064 env23511 = env23512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env23511 == env23512) = true)

theorem identity23512 : scanCanonicalize (H12AffineFastState.compose env23512 (packedSelected [0,2,3,5,7,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23512 : packedSelected [0,2,3,5,7,17] rootPS < 2^1333 := by decide +kernel

def env23513 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,2064,268,2049,1,263,2065,2340,53,0,2341,33,17,3,269,17,2049,2065,2064,2341,305,33,257,32,2048,513]

theorem envBound23513 : H12AffineFastState.Bounded env23513 := by
  intro p hp
  have h : env23513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23512_23513 : H12AffineEnvironment.transform 5 16 env23512 = env23513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23512 == env23513) = true)

theorem identity23513 : scanCanonicalize (H12AffineFastState.compose env23513 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound23513 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23514 : List Nat := [2,4,8,16,32,16,9,256,512,52,303,319,268,302,1,263,318,11,53,0,10,33,17,3,269,17,302,318,319,10,305,33,257,32,303,513]

theorem envBound23514 : H12AffineFastState.Bounded env23514 := by
  intro p hp
  have h : env23514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23513_23514 : H12AffineEnvironment.transform 10 303 env23513 = env23514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env23513 == env23514) = true)

def env23515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297334,8193,65,12650855,2428275,10507601,8683536,8719719,6679614,257,10833234,10857598,8661560]

theorem envBound23515 : H12AffineFastState.Bounded env23515 := by
  intro p hp
  have h : env23515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23501_23515 : H12AffineEnvironment.transform 16 16401 env23501 = env23515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env23501 == env23515) = true)

theorem identity23515 : scanCanonicalize (H12AffineFastState.compose env23515 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound23515 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env23516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,8388608,3,8193,65,12650855,2196486,10507601,8391013,8487954,6382923,257,10601511,10560779,8430413]

theorem envBound23516 : H12AffineFastState.Bounded env23516 := by
  intro p hp
  have h : env23516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23515_23516 : H12AffineEnvironment.transform 17 35189 env23515 = env23516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env23515 == env23516) = true)

theorem identity23516 : scanCanonicalize (H12AffineFastState.compose env23516 (packedSelected [0,9,14,17,21,22,27,35] rootPS)) = affineNative (2^(22+1) ^^^ 98630) := by decide +kernel

theorem selectedBound23516 : packedSelected [0,9,14,17,21,22,27,35] rootPS < 2^1333 := by decide +kernel

def env23517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,98630,3,8193,65,4229153,2196486,2216983,100387,1364,6382923,257,2114913,2139213,74251]

theorem envBound23517 : H12AffineFastState.Bounded env23517 := by
  intro p hp
  have h : env23517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23516_23517 : H12AffineEnvironment.transform 22 98630 env23516 = env23517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98630 env23516 == env23517) = true)

theorem identity23517 : scanCanonicalize (H12AffineFastState.compose env23517 (packedSelected [0,4,7,12,15,16,17,20,21,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound23517 : packedSelected [0,4,7,12,15,16,17,20,21,22,38,41] rootPS < 2^1333 := by decide +kernel

def env23518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,73771,98630,3,8193,65,108554,2196486,2216983,100387,1364,2114912,257,2114913,2139213,74251]

theorem envBound23518 : H12AffineFastState.Bounded env23518 := by
  intro p hp
  have h : env23518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23517_23518 : H12AffineEnvironment.transform 21 73771 env23517 = env23518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env23517 == env23518) = true)

theorem identity23518 : scanCanonicalize (H12AffineFastState.compose env23518 (packedSelected [18,23] rootPS)) = affineNative (2^(20+1) ^^^ 25677) := by decide +kernel

theorem selectedBound23518 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env23519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,25677,73771,98630,3,8193,65,108554,122955,110682,100387,1364,8493,257,8492,49152,74251]

theorem envBound23519 : H12AffineFastState.Bounded env23519 := by
  intro p hp
  have h : env23519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23518_23519 : H12AffineEnvironment.transform 20 25677 env23518 = env23519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25677 env23518 == env23519) = true)

theorem identity23519 : scanCanonicalize (H12AffineFastState.compose env23519 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound23519 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env23520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16401,35189,1025,32769,25677,41340,17,3,8193,65,10589,24860,12557,2420,1364,8493,257,8492,49152,41820]

theorem envBound23520 : H12AffineFastState.Bounded env23520 := by
  intro p hp
  have h : env23520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23519_23520 : H12AffineEnvironment.transform 15 33111 env23519 = env23520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env23519 == env23520) = true)

theorem identity23520 : scanCanonicalize (H12AffineFastState.compose env23520 (packedSelected [1,2,3,7,9,10,11,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23520 : packedSelected [1,2,3,7,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env23521 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,8192,16384,32768,32850,16401,34928,1025,32769,25677,41081,17,3,8193,65,10328,24601,12296,2161,1105,8232,4,8233,49152,41561]

theorem envBound23521 : H12AffineFastState.Bounded env23521 := by
  intro p hp
  have h : env23521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23520_23521 : H12AffineEnvironment.transform 7 5 env23520 = env23521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23520 == env23521) = true)

theorem identity23521 : scanCanonicalize (H12AffineFastState.compose env23521 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound23521 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env23522 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,8192,16384,81,3,16401,2081,1025,80,25677,8232,17,3,8193,65,10328,24601,12296,2161,1105,8232,4,8233,16465,8712]

theorem envBound23522 : H12AffineFastState.Bounded env23522 := by
  intro p hp
  have h : env23522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23521_23522 : H12AffineEnvironment.transform 14 81 env23521 = env23522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env23521 == env23522) = true)

theorem identity23522 : scanCanonicalize (H12AffineFastState.compose env23522 (packedSelected [1,2,3,4,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound23522 : packedSelected [1,2,3,4,7,10,16] rootPS < 2^1333 := by decide +kernel

def env23523 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,8,16384,81,3,16401,2081,1025,80,17477,32,17,3,9,65,2128,16401,4096,2161,1105,32,4,33,16465,512]

theorem envBound23523 : H12AffineFastState.Bounded env23523 := by
  intro p hp
  have h : env23523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23522_23523 : H12AffineEnvironment.transform 12 8 env23522 = env23523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env23522 == env23523) = true)

theorem identity23523 : scanCanonicalize (H12AffineFastState.compose env23523 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound23523 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env23524 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,8,16384,33,3,16401,2081,1025,32,17461,32,17,3,9,49,2080,16401,4096,2049,1057,32,4,33,16417,512]

theorem envBound23524 : H12AffineFastState.Bounded env23524 := by
  intro p hp
  have h : env23524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23523_23524 : H12AffineEnvironment.transform 5 48 env23523 = env23524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env23523 == env23524) = true)

theorem identity23524 : scanCanonicalize (H12AffineFastState.compose env23524 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound23524 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env23525 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,8,5124,33,3,5141,2081,1025,32,4145,32,17,3,9,49,2080,5141,4096,2049,1057,32,4,33,5157,512]

theorem envBound23525 : H12AffineFastState.Bounded env23525 := by
  intro p hp
  have h : env23525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23524_23525 : H12AffineEnvironment.transform 13 5124 env23524 = env23525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env23524 == env23525) = true)

theorem identity23525 : scanCanonicalize (H12AffineFastState.compose env23525 (packedSelected [20] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23525 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env23526 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5124,0,3,5141,2048,1025,1,4112,1,17,3,9,16,2049,5141,4096,2049,1024,1,4,0,5124,512]

theorem envBound23526 : H12AffineFastState.Bounded env23526 := by
  intro p hp
  have h : env23526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23525_23526 : H12AffineEnvironment.transform 4 1 env23525 = env23526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23525 == env23526) = true)

def env23527 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,8,1044,0,3,1029,2048,1025,1,0,1,17,3,9,16,2049,1029,16,2049,1024,1,4,0,1044,512]

theorem envBound23527 : H12AffineFastState.Bounded env23527 := by
  intro p hp
  have h : env23527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23526_23527 : H12AffineEnvironment.transform 11 16 env23526 = env23527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env23526 == env23527) = true)

def env23528 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,8,0,0,3,17,2048,21,1,0,1,17,3,9,16,2049,17,16,2049,20,1,4,0,0,512]

theorem envBound23528 : H12AffineFastState.Bounded env23528 := by
  intro p hp
  have h : env23528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23527_23528 : H12AffineEnvironment.transform 9 20 env23527 = env23528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env23527 == env23528) = true)

theorem identity23528 : scanCanonicalize (H12AffineFastState.compose env23528 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 542) := by decide +kernel

theorem selectedBound23528 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23529 : List Nat := [2,4,8,16,1,17,9,5,512,20,542,16,8,0,0,3,17,542,21,1,0,1,17,3,9,16,543,17,16,543,20,1,4,0,0,512]

theorem envBound23529 : H12AffineFastState.Bounded env23529 := by
  intro p hp
  have h : env23529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23528_23529 : H12AffineEnvironment.transform 10 542 env23528 = env23529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 542 env23528 == env23529) = true)

def leafEnv23529 : List Nat := [2,4,8,16,1,17,9,5,512,20,542,16,8,0,0,3,17,542,21,1,0,1,17,3,21,9,1,16,543,17,16,543,20,1,4,0,5,2,0,512,1,0,0]

def active23529 : List Nat := [0,1,2,3,8]

def tree23529 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23529 : H12WitnessSearch.Good tree23529 := H12GlobalWitnessIndex.good

theorem leafIdentity23529 : H12AffineFastState.composeSystem env23529 rootObs = leafEnv23529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23529 rootObs == leafEnv23529) = true)

theorem terminalChecked23529 : H12PackedTerminal.terminalCheckFast leafEnv23529 active23529 tree23529 = true := by decide +kernel

def env23530 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,8,1,0,3,16,2048,20,1,0,1,17,3,9,16,2049,16,16,2049,21,1,4,0,1,512]

theorem envBound23530 : H12AffineFastState.Bounded env23530 := by
  intro p hp
  have h : env23530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23527_23530 : H12AffineEnvironment.transform 9 21 env23527 = env23530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env23527 == env23530) = true)

theorem identity23530 : scanCanonicalize (H12AffineFastState.compose env23530 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound23530 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23531 : List Nat := [2,4,8,16,1,17,9,5,512,21,20,16,8,1,0,3,16,20,20,1,0,1,17,3,9,16,21,16,16,21,21,1,4,0,1,512]

theorem envBound23531 : H12AffineFastState.Bounded env23531 := by
  intro p hp
  have h : env23531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23530_23531 : H12AffineEnvironment.transform 10 20 env23530 = env23531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env23530 == env23531) = true)

def leafEnv23531 : List Nat := [2,4,8,16,1,17,9,5,512,21,20,16,8,1,0,3,16,20,20,1,0,1,17,3,20,9,1,16,21,16,16,21,21,1,4,0,5,2,1,512,1,0,0]

def active23531 : List Nat := [0,1,2,3,8]

def tree23531 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23531 : H12WitnessSearch.Good tree23531 := H12GlobalWitnessIndex.good

theorem leafIdentity23531 : H12AffineFastState.composeSystem env23531 rootObs = leafEnv23531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23531 rootObs == leafEnv23531) = true)

theorem terminalChecked23531 : H12PackedTerminal.terminalCheckFast leafEnv23531 active23531 tree23531 = true := by decide +kernel

def env23532 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,8,1045,0,3,1028,2048,1025,1,1,1,17,3,9,16,2049,1028,17,2049,1024,1,4,0,1045,512]

theorem envBound23532 : H12AffineFastState.Bounded env23532 := by
  intro p hp
  have h : env23532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23526_23532 : H12AffineEnvironment.transform 11 17 env23526 = env23532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env23526 == env23532) = true)

theorem identity23532 : scanCanonicalize (H12AffineFastState.compose env23532 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound23532 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23533 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,8,0,0,3,17,2048,20,1,1,1,17,3,9,16,2049,17,17,2049,21,1,4,0,0,512]

theorem envBound23533 : H12AffineFastState.Bounded env23533 := by
  intro p hp
  have h : env23533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23532_23533 : H12AffineEnvironment.transform 9 21 env23532 = env23533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env23532 == env23533) = true)

theorem identity23533 : scanCanonicalize (H12AffineFastState.compose env23533 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound23533 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23534 : List Nat := [2,4,8,16,1,17,9,5,512,21,21,17,8,0,0,3,17,21,20,1,1,1,17,3,9,16,20,17,17,20,21,1,4,0,0,512]

theorem envBound23534 : H12AffineFastState.Bounded env23534 := by
  intro p hp
  have h : env23534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23533_23534 : H12AffineEnvironment.transform 10 21 env23533 = env23534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env23533 == env23534) = true)

def leafEnv23534 : List Nat := [2,4,8,16,1,17,9,5,512,21,21,17,8,0,0,3,17,21,20,1,1,1,17,3,20,9,1,16,20,17,17,20,21,1,4,0,5,2,0,512,1,1,0]

def active23534 : List Nat := [0,1,2,3,8]

def tree23534 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23534 : H12WitnessSearch.Good tree23534 := H12GlobalWitnessIndex.good

theorem leafIdentity23534 : H12AffineFastState.composeSystem env23534 rootObs = leafEnv23534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23534 rootObs == leafEnv23534) = true)

theorem terminalChecked23534 : H12PackedTerminal.terminalCheckFast leafEnv23534 active23534 tree23534 = true := by decide +kernel

def env23535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,1073741824,92374096,145662401,525568,140903596,27337992,25733062]

theorem envBound23535 : H12AffineFastState.Bounded env23535 := by
  intro p hp
  have h : env23535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21008_23535 : H12AffineEnvironment.transform 31 145662401 env21008 = env23535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env21008 == env23535) = true)

def env23536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254784,92374096,145662401,525568,140903596,27337992,25733062]

theorem envBound23536 : H12AffineFastState.Bounded env23536 := by
  intro p hp
  have h : env23536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23535_23536 : H12AffineEnvironment.transform 29 155254784 env23535 = env23536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env23535 == env23536) = true)

def env23537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254784,25265168,145662401,525568,140903596,27337992,25733062]

theorem envBound23537 : H12AffineFastState.Bounded env23537 := by
  intro p hp
  have h : env23537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23536_23537 : H12AffineEnvironment.transform 25 64 env23536 = env23537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env23536 == env23537) = true)

def env23538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356288,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound23538 : H12AffineFastState.Bounded env23538 := by
  intro p hp
  have h : env23538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23537_23538 : H12AffineEnvironment.transform 26 30393344 env23537 = env23538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env23537 == env23538) = true)

def env23539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound23539 : H12AffineFastState.Bounded env23539 := by
  intro p hp
  have h : env23539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23538_23539 : H12AffineEnvironment.transform 18 1024 env23538 = env23539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env23538 == env23539) = true)

theorem identity23539 : scanCanonicalize (H12AffineFastState.compose env23539 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8429903) := by decide +kernel

theorem selectedBound23539 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429903,8328,64,4677967,10560962,10507600,8830976,75103,14795918,256,2188771,2196551,649]

theorem envBound23540 : H12AffineFastState.Bounded env23540 := by
  intro p hp
  have h : env23540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23539_23540 : H12AffineEnvironment.transform 23 8429903 env23539 = env23540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8429903 env23539 == env23540) = true)

def env23541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429903,8192,64,4677967,10560842,10507600,8830976,75103,14795782,256,2188651,2196551,513]

theorem envBound23541 : H12AffineFastState.Bounded env23541 := by
  intro p hp
  have h : env23541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23540_23541 : H12AffineEnvironment.transform 6 8 env23540 = env23541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23540 == env23541) = true)

def env23542 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41311,8192,64,4677967,2172250,2118976,442384,75103,6407190,256,2188651,2196551,513]

theorem envBound23542 : H12AffineFastState.Bounded env23542 := by
  intro p hp
  have h : env23542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23541_23542 : H12AffineEnvironment.transform 22 16 env23541 = env23542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env23541 == env23542) = true)

def env23543 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41311,8192,64,4677967,115014,45404,442384,75103,4268042,256,98679,90203,513]

end H12CloudChart1