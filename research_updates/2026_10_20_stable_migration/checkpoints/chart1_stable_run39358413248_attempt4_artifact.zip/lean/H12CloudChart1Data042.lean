import H12CloudChart1Data041

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound10485 : H12AffineFastState.Bounded env10485 := by
  intro p hp
  have h : env10485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10484_10485 : H12AffineEnvironment.transform 0 0 env10484 = env10485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env10484 == env10485) = true)

def env10486 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,160013,272392,169217,41310,8193,64,2048,163840,45404,283905,156696,411972,257,21793,46093,169745]

theorem envBound10486 : H12AffineFastState.Bounded env10486 := by
  intro p hp
  have h : env10486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10468_10486 : H12AffineEnvironment.transform 6 9 env10468 = env10486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10468 == env10486) = true)

theorem identity10486 : scanCanonicalize (H12AffineFastState.compose env10486 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound10486 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env10487 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,138340,1025,32769,160013,144492,169217,41310,8193,64,2048,163840,45404,149861,156696,21792,257,21793,46093,169745]

theorem envBound10487 : H12AffineFastState.Bounded env10487 := by
  intro p hp
  have h : env10487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10486_10487 : H12AffineEnvironment.transform 17 138340 env10486 = env10487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env10486 == env10487) = true)

theorem identity10487 : scanCanonicalize (H12AffineFastState.compose env10487 (packedSelected [0,1,9,10,16,18,19,20,22,23,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound10487 : packedSelected [0,1,9,10,16,18,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env10488 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24909,32041,1025,32769,4160,21793,62540,41310,8193,64,2048,57677,45404,10280,1365,21792,257,21793,46093,63068]

theorem envBound10488 : H12AffineFastState.Bounded env10488 := by
  intro p hp
  have h : env10488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10487_10488 : H12AffineEnvironment.transform 16 24909 env10487 = env10488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env10487 == env10488) = true)

theorem identity10488 : scanCanonicalize (H12AffineFastState.compose env10488 (packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 8493) := by decide +kernel

theorem selectedBound10488 : packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env10489 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8493,30074,24909,32041,1025,8492,4160,21793,21857,115,8193,64,2048,16480,4209,10280,1365,21792,257,21793,5408,22385]

theorem envBound10489 : H12AffineFastState.Bounded env10489 := by
  intro p hp
  have h : env10489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10488_10489 : H12AffineEnvironment.transform 14 8493 env10488 = env10489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8493 env10488 == env10489) = true)

theorem identity10489 : scanCanonicalize (H12AffineFastState.compose env10489 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 13356) := by decide +kernel

theorem selectedBound10489 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env10490 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13356,8493,342,5473,2309,1025,8492,4160,8461,8525,115,8193,64,2048,13388,4209,10280,1365,8460,257,8461,5408,9053]

theorem envBound10490 : H12AffineFastState.Bounded env10490 := by
  intro p hp
  have h : env10490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10489_10490 : H12AffineEnvironment.transform 13 13356 env10489 = env10490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13356 env10489 == env10490) = true)

theorem identity10490 : scanCanonicalize (H12AffineFastState.compose env10490 (packedSelected [3,5,6,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound10490 : packedSelected [3,5,6,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env10491 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5488,113,342,5473,2309,1025,112,4160,81,17,115,349,64,2048,5392,4209,2420,1365,80,257,81,5408,513]

theorem envBound10491 : H12AffineFastState.Bounded env10491 := by
  intro p hp
  have h : env10491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10490_10491 : H12AffineEnvironment.transform 12 348 env10490 = env10491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env10490 == env10491) = true)

theorem identity10491 : scanCanonicalize (H12AffineFastState.compose env10491 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10491 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10492 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5409,32,263,5424,2309,1025,33,4113,0,17,34,268,17,2048,5392,4128,2341,1284,1,257,0,5408,513]

theorem envBound10492 : H12AffineFastState.Bounded env10492 := by
  intro p hp
  have h : env10492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10491_10492 : H12AffineEnvironment.transform 5 17 env10491 = env10492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10491 == env10492) = true)

theorem identity10492 : scanCanonicalize (H12AffineFastState.compose env10492 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound10492 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env10493 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1297,4096,269,5409,32,263,5424,1044,1025,33,4113,0,17,34,268,17,1297,5392,4128,1076,1284,1,257,0,5408,513]

theorem envBound10493 : H12AffineFastState.Bounded env10493 := by
  intro p hp
  have h : env10493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10492_10493 : H12AffineEnvironment.transform 10 1297 env10492 = env10493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env10492 == env10493) = true)

theorem identity10493 : scanCanonicalize (H12AffineFastState.compose env10493 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1541) := by decide +kernel

theorem selectedBound10493 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10494 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1297,1541,269,804,32,263,821,1044,1025,33,1556,0,17,34,268,17,1297,789,1573,1076,1284,1,257,0,805,513]

theorem envBound10494 : H12AffineFastState.Bounded env10494 := by
  intro p hp
  have h : env10494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10493_10494 : H12AffineEnvironment.transform 11 1541 env10493 = env10494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1541 env10493 == env10494) = true)

theorem identity10494 : scanCanonicalize (H12AffineFastState.compose env10494 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 800) := by decide +kernel

theorem selectedBound10494 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10495 : List Nat := [2,4,8,16,32,17,9,256,512,800,561,293,269,804,32,263,821,820,801,33,308,0,17,34,268,17,561,789,261,788,548,1,257,0,805,513]

theorem envBound10495 : H12AffineFastState.Bounded env10495 := by
  intro p hp
  have h : env10495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10494_10495 : H12AffineEnvironment.transform 9 800 env10494 = env10495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 800 env10494 == env10495) = true)

theorem identity10495 : scanCanonicalize (H12AffineFastState.compose env10495 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound10495 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env10496 : List Nat := [2,4,8,16,17,17,9,256,512,785,512,276,269,789,17,263,772,773,784,16,261,0,17,19,268,17,512,789,261,788,533,1,257,0,788,513]

theorem envBound10496 : H12AffineFastState.Bounded env10496 := by
  intro p hp
  have h : env10496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10495_10496 : H12AffineEnvironment.transform 4 17 env10495 = env10496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env10495 == env10496) = true)

theorem identity10496 : scanCanonicalize (H12AffineFastState.compose env10496 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound10496 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env10497 : List Nat := [2,4,8,16,17,17,9,256,260,21,260,276,269,17,17,263,0,1,20,16,261,0,17,19,268,17,260,17,261,16,273,1,257,0,16,261]

theorem envBound10497 : H12AffineFastState.Bounded env10497 := by
  intro p hp
  have h : env10497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10496_10497 : H12AffineEnvironment.transform 8 260 env10496 = env10497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env10496 == env10497) = true)

theorem identity10497 : scanCanonicalize (H12AffineFastState.compose env10497 (packedSelected [0,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10497 : packedSelected [0,10] rootPS < 2^1333 := by decide +kernel

def env10498 : List Nat := [2,4,8,1,0,0,9,256,260,4,260,261,269,0,0,263,0,1,5,1,261,0,0,2,268,0,260,0,261,1,256,1,257,0,1,261]

theorem envBound10498 : H12AffineFastState.Bounded env10498 := by
  intro p hp
  have h : env10498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10497_10498 : H12AffineEnvironment.transform 3 1 env10497 = env10498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10497 == env10498) = true)

def env10499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,4194304,8388608,8642568,8328,64,4464648,8393984,8529109,8830976,156696,12645452,257,21792,46213,213967]

theorem envBound10499 : H12AffineFastState.Bounded env10499 := by
  intro p hp
  have h : env10499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10383_10499 : H12AffineEnvironment.transform 20 160133 env10383 = env10499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160133 env10383 == env10499) = true)

def env10500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,4194304,169216,95496,8328,64,4464648,163840,45525,283904,156696,4350284,257,21792,46213,213967]

theorem envBound10500 : H12AffineFastState.Bounded env10500 := by
  intro p hp
  have h : env10500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10499_10500 : H12AffineEnvironment.transform 22 169216 env10499 = env10500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env10499 == env10500) = true)

def env10501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272512,169216,95496,8328,64,2184,163840,45525,283904,156696,412108,257,21792,46213,213967]

theorem envBound10501 : H12AffineFastState.Bounded env10501 := by
  intro p hp
  have h : env10501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10500_10501 : H12AffineEnvironment.transform 21 272512 env10500 = env10501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env10500 == env10501) = true)

def env10502 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272392,169216,95496,8192,64,2048,163840,45405,283904,156696,411972,257,21792,46093,213831]

theorem envBound10502 : H12AffineFastState.Bounded env10502 := by
  intro p hp
  have h : env10502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10501_10502 : H12AffineEnvironment.transform 6 8 env10501 = env10502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10501 == env10502) = true)

def env10503 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58397,272392,16,95496,8192,64,2048,5392,45405,283904,61704,318548,257,21792,46093,120407]

theorem envBound10503 : H12AffineFastState.Bounded env10503 := by
  intro p hp
  have h : env10503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10502_10503 : H12AffineEnvironment.transform 16 38160 env10502 = env10503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env10502 == env10503) = true)

theorem identity10503 : scanCanonicalize (H12AffineFastState.compose env10503 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound10503 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10504 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,38160,262144,1025,32769,58397,272392,16,2,8192,64,2048,5392,45405,283904,61704,318548,257,21792,46093,41821]

theorem envBound10504 : H12AffineFastState.Bounded env10504 := by
  intro p hp
  have h : env10504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10503_10504 : H12AffineEnvironment.transform 15 29962 env10503 = env10504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env10503 == env10504) = true)

theorem identity10504 : scanCanonicalize (H12AffineFastState.compose env10504 (packedSelected [1,3,5,8,10,16,18,20,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10504 : packedSelected [1,3,5,8,10,16,18,20,23,26] rootPS < 2^1333 := by decide +kernel

def env10505 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,21591,38160,262144,1025,32769,50496,264533,16,2,349,64,2048,5392,36864,283904,53333,318548,257,21792,38224,33280]

theorem envBound10505 : H12AffineFastState.Bounded env10505 := by
  intro p hp
  have h : env10505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10504_10505 : H12AffineEnvironment.transform 12 349 env10504 = env10505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10504 == env10505) = true)

theorem identity10505 : scanCanonicalize (H12AffineFastState.compose env10505 (packedSelected [0,1,4,5,7,8,16,18,20,22,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound10505 : packedSelected [0,1,4,5,7,8,16,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env10506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,21591,38160,56436,1025,32769,50496,54561,16,2,349,64,2048,5392,36864,35188,53333,32,257,21792,38224,33280]

theorem envBound10506 : H12AffineFastState.Bounded env10506 := by
  intro p hp
  have h : env10506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10505_10506 : H12AffineEnvironment.transform 17 56436 env10505 = env10506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env10505 == env10506) = true)

theorem identity10506 : scanCanonicalize (H12AffineFastState.compose env10506 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound10506 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env10507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,21591,5393,23669,1025,0,17729,21792,16,2,349,64,2048,5392,4097,2421,20564,32,257,21792,5457,513]

theorem envBound10507 : H12AffineFastState.Bounded env10507 := by
  intro p hp
  have h : env10507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10506_10507 : H12AffineEnvironment.transform 14 1 env10506 = env10507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env10506 == env10507) = true)

theorem identity10507 : scanCanonicalize (H12AffineFastState.compose env10507 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound10507 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4112,1,1095,5393,3173,1025,0,5457,1328,16,2,349,64,2048,5392,4097,2421,68,32,257,1328,5457,513]

theorem envBound10508 : H12AffineFastState.Bounded env10508 := by
  intro p hp
  have h : env10508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10507_10508 : H12AffineEnvironment.transform 13 4112 env10507 = env10508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env10507 == env10508) = true)

theorem identity10508 : scanCanonicalize (H12AffineFastState.compose env10508 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound10508 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10509 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,349,4112,1,342,4096,2420,272,0,4160,33,16,2,349,64,2048,4097,4097,2421,68,32,257,33,4160,513]

theorem envBound10509 : H12AffineFastState.Bounded env10509 := by
  intro p hp
  have h : env10509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10508_10509 : H12AffineEnvironment.transform 9 273 env10508 = env10509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env10508 == env10509) = true)

theorem identity10509 : scanCanonicalize (H12AffineFastState.compose env10509 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound10509 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10510 : List Nat := [2,4,8,16,32,32,8,256,512,273,2048,4096,317,4112,1,310,4096,2324,272,0,4128,33,16,2,317,32,2048,4097,4097,2325,36,32,257,33,4128,513]

theorem envBound10510 : H12AffineFastState.Bounded env10510 := by
  intro p hp
  have h : env10510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10509_10510 : H12AffineEnvironment.transform 5 32 env10509 = env10510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env10509 == env10510) = true)

theorem identity10510 : scanCanonicalize (H12AffineFastState.compose env10510 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 773) := by decide +kernel

theorem selectedBound10510 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10511 : List Nat := [2,4,8,16,32,32,8,256,512,273,2048,773,317,789,1,310,773,2324,272,0,805,33,16,2,317,32,2048,772,772,2325,36,32,257,33,805,513]

theorem envBound10511 : H12AffineFastState.Bounded env10511 := by
  intro p hp
  have h : env10511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10510_10511 : H12AffineEnvironment.transform 11 773 env10510 = env10511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env10510 == env10511) = true)

theorem identity10511 : scanCanonicalize (H12AffineFastState.compose env10511 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound10511 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10512 : List Nat := [2,4,8,16,16,16,8,256,512,273,2048,773,269,789,1,262,773,2324,272,0,789,17,16,2,269,16,2048,772,772,2325,20,16,257,17,789,513]

theorem envBound10512 : H12AffineFastState.Bounded env10512 := by
  intro p hp
  have h : env10512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10511_10512 : H12AffineEnvironment.transform 4 16 env10511 = env10512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env10511 == env10512) = true)

theorem identity10512 : scanCanonicalize (H12AffineFastState.compose env10512 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound10512 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10513 : List Nat := [2,4,8,16,16,16,8,256,512,273,789,773,269,789,1,262,773,513,272,0,789,17,16,2,269,16,789,772,772,512,20,16,257,17,789,513]

theorem envBound10513 : H12AffineFastState.Bounded env10513 := by
  intro p hp
  have h : env10513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10512_10513 : H12AffineEnvironment.transform 10 789 env10512 = env10513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env10512 == env10513) = true)

theorem identity10513 : scanCanonicalize (H12AffineFastState.compose env10513 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound10513 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10514 : List Nat := [2,4,8,16,16,16,8,256,261,273,16,0,269,16,1,262,0,260,272,0,16,17,16,2,269,16,16,1,1,261,20,16,257,17,16,260]

theorem envBound10514 : H12AffineFastState.Bounded env10514 := by
  intro p hp
  have h : env10514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10513_10514 : H12AffineEnvironment.transform 8 261 env10513 = env10514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env10513 == env10514) = true)

theorem identity10514 : scanCanonicalize (H12AffineFastState.compose env10514 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10514 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10515 : List Nat := [2,4,8,16,16,16,8,4,1,21,16,0,9,16,1,2,0,0,20,0,16,17,16,2,9,16,16,1,1,1,20,16,5,17,16,0]

theorem envBound10515 : H12AffineFastState.Bounded env10515 := by
  intro p hp
  have h : env10515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10514_10515 : H12AffineEnvironment.transform 7 4 env10514 = env10515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10514 == env10515) = true)

theorem identity10515 : scanCanonicalize (H12AffineFastState.compose env10515 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound10515 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10516 : List Nat := [2,4,8,11,11,11,8,4,1,14,11,0,9,11,1,2,0,0,15,0,11,10,11,2,9,11,11,1,1,1,15,11,5,10,11,0]

theorem envBound10516 : H12AffineFastState.Bounded env10516 := by
  intro p hp
  have h : env10516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10515_10516 : H12AffineEnvironment.transform 3 11 env10515 = env10516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env10515 == env10516) = true)

def env10517 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58396,272392,17,95496,8192,64,2048,5393,45405,283904,61705,318549,257,21792,46093,120406]

theorem envBound10517 : H12AffineFastState.Bounded env10517 := by
  intro p hp
  have h : env10517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10502_10517 : H12AffineEnvironment.transform 16 38161 env10502 = env10517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env10502 == env10517) = true)

theorem identity10517 : scanCanonicalize (H12AffineFastState.compose env10517 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound10517 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10518 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,89378,1025,32769,58396,95530,17,95496,8192,64,2048,5393,45405,67618,61705,98679,257,21792,46093,120406]

theorem envBound10518 : H12AffineFastState.Bounded env10518 := by
  intro p hp
  have h : env10518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10517_10518 : H12AffineEnvironment.transform 17 89378 env10517 = env10518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env10517 == env10518) = true)

theorem identity10518 : scanCanonicalize (H12AffineFastState.compose env10518 (packedSelected [1,7,8,12,14,15,19,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 62510) := by decide +kernel

theorem selectedBound10518 : packedSelected [1,7,8,12,14,15,19,20,27] rootPS < 2^1333 := by decide +kernel

def env10519 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62510,38161,43276,1025,32769,58396,33028,17,33062,8192,64,2048,5393,45405,64524,61705,30041,257,21792,46093,8824]

theorem envBound10519 : H12AffineFastState.Bounded env10519 := by
  intro p hp
  have h : env10519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10518_10519 : H12AffineEnvironment.transform 15 62510 env10518 = env10519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62510 env10518 == env10519) = true)

theorem identity10519 : scanCanonicalize (H12AffineFastState.compose env10519 (packedSelected [1,2,3,5,6,8,9,10,11,14,16,18,20,22,26] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound10519 : packedSelected [1,2,3,5,6,8,9,10,11,14,16,18,20,22,26] rootPS < 2^1333 := by decide +kernel

def env10520 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,41343,38161,43276,1025,32769,45389,33028,17,33062,8192,64,2048,5393,45405,43357,42072,8200,257,113,46093,8824]

theorem envBound10520 : H12AffineFastState.Bounded env10520 := by
  intro p hp
  have h : env10520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10519_10520 : H12AffineEnvironment.transform 13 5457 env10519 = env10520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env10519 == env10520) = true)

theorem identity10520 : scanCanonicalize (H12AffineFastState.compose env10520 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound10520 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env10521 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5157,32768,40971,37989,43128,1025,32769,45113,32880,17,32850,8192,64,2048,5221,45097,43049,42072,8200,117,113,46093,8824]

theorem envBound10521 : H12AffineFastState.Bounded env10521 := by
  intro p hp
  have h : env10521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10520_10521 : H12AffineEnvironment.transform 7 116 env10520 = env10521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env10520 == env10521) = true)

theorem identity10521 : scanCanonicalize (H12AffineFastState.compose env10521 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound10521 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env10522 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,121,5157,32768,32882,37989,34817,1025,32769,36928,32880,17,32850,121,64,2048,5221,36944,34896,33825,113,117,113,38004,513]

theorem envBound10522 : H12AffineFastState.Bounded env10522 := by
  intro p hp
  have h : env10522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10521_10522 : H12AffineEnvironment.transform 12 121 env10521 = env10522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env10521 == env10522) = true)

theorem identity10522 : scanCanonicalize (H12AffineFastState.compose env10522 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 7204) := by decide +kernel

theorem selectedBound10522 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env10523 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,121,5157,7204,7254,2113,5157,1025,7205,3172,7252,17,7286,121,64,2048,5221,3188,5236,6149,113,117,113,2128,513]

theorem envBound10523 : H12AffineFastState.Bounded env10523 := by
  intro p hp
  have h : env10523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10522_10523 : H12AffineEnvironment.transform 14 7204 env10522 = env10523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7204 env10522 == env10523) = true)

theorem identity10523 : scanCanonicalize (H12AffineFastState.compose env10523 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10523 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env10524 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,7204,7174,2065,5157,1025,7205,3124,7172,17,7206,41,16,2048,5173,3108,5156,6149,33,37,33,2048,513]

theorem envBound10524 : H12AffineFastState.Bounded env10524 := by
  intro p hp
  have h : env10524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10523_10524 : H12AffineEnvironment.transform 5 16 env10523 = env10524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10523 == env10524) = true)

theorem identity10524 : scanCanonicalize (H12AffineFastState.compose env10524 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound10524 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env10525 : List Nat := [2,4,8,16,32,16,8,36,512,36,2048,4096,41,4097,6144,6178,2065,4097,37,6145,2064,6176,17,6146,41,16,2048,4113,2048,4096,6149,33,37,33,2048,513]

theorem envBound10525 : H12AffineFastState.Bounded env10525 := by
  intro p hp
  have h : env10525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10524_10525 : H12AffineEnvironment.transform 9 36 env10524 = env10525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env10524 == env10525) = true)

theorem identity10525 : scanCanonicalize (H12AffineFastState.compose env10525 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2560) := by decide +kernel

theorem selectedBound10525 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env10526 : List Nat := [2,4,8,16,32,16,8,36,512,36,2048,2560,41,2561,512,546,2065,2561,37,513,2064,544,17,514,41,16,2048,2577,2048,2560,517,33,37,33,2048,513]

theorem envBound10526 : H12AffineFastState.Bounded env10526 := by
  intro p hp
  have h : env10526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10525_10526 : H12AffineEnvironment.transform 11 2560 env10525 = env10526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2560 env10525 == env10526) = true)

theorem identity10526 : scanCanonicalize (H12AffineFastState.compose env10526 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound10526 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env10527 : List Nat := [2,4,8,16,32,16,8,36,512,36,16,528,41,529,512,546,1,529,37,513,0,544,17,514,41,16,16,513,16,528,517,33,37,33,16,513]

theorem envBound10527 : H12AffineFastState.Bounded env10527 := by
  intro p hp
  have h : env10527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10526_10527 : H12AffineEnvironment.transform 10 16 env10526 = env10527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env10526 == env10527) = true)

theorem identity10527 : scanCanonicalize (H12AffineFastState.compose env10527 (packedSelected [1,3,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10527 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env10528 : List Nat := [2,4,8,1,32,1,8,36,512,36,1,513,41,512,512,546,1,512,37,513,0,544,0,514,41,1,1,513,1,513,517,33,37,33,1,513]

theorem envBound10528 : H12AffineFastState.Bounded env10528 := by
  intro p hp
  have h : env10528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10527_10528 : H12AffineEnvironment.transform 3 1 env10527 = env10528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10527 == env10528) = true)

theorem identity10528 : scanCanonicalize (H12AffineFastState.compose env10528 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound10528 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env10529 : List Nat := [2,4,8,1,32,1,8,36,1,36,1,0,41,1,1,35,1,1,37,0,0,33,0,3,41,1,1,0,1,0,4,33,37,33,1,0]

theorem envBound10529 : H12AffineFastState.Bounded env10529 := by
  intro p hp
  have h : env10529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10528_10529 : H12AffineEnvironment.transform 8 1 env10528 = env10529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env10528 == env10529) = true)

def env10530 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272393,169216,95496,8193,64,2049,163840,45404,283904,156696,411973,257,21792,46092,213830]

theorem envBound10530 : H12AffineFastState.Bounded env10530 := by
  intro p hp
  have h : env10530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10501_10530 : H12AffineEnvironment.transform 6 9 env10501 = env10530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10501 == env10530) = true)

def env10531 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272393,16,95496,8193,64,2049,5392,45404,283904,61704,318549,257,21792,46092,120406]

theorem envBound10531 : H12AffineFastState.Bounded env10531 := by
  intro p hp
  have h : env10531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10530_10531 : H12AffineEnvironment.transform 16 38160 env10530 = env10531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env10530 == env10531) = true)

theorem identity10531 : scanCanonicalize (H12AffineFastState.compose env10531 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound10531 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,262144,1025,32769,58396,272393,16,41311,8193,64,2049,5392,45404,283904,61704,318549,257,21792,46092,513]

theorem envBound10532 : H12AffineFastState.Bounded env10532 := by
  intro p hp
  have h : env10532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10531_10532 : H12AffineEnvironment.transform 15 54359 env10531 = env10532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env10531 == env10532) = true)

theorem identity10532 : scanCanonicalize (H12AffineFastState.compose env10532 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound10532 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54359,38160,262144,1025,32769,50496,264533,16,32771,349,64,2049,5392,36864,283904,53332,318549,257,21792,38224,513]

theorem envBound10533 : H12AffineFastState.Bounded env10533 := by
  intro p hp
  have h : env10533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10532_10533 : H12AffineEnvironment.transform 12 348 env10532 = env10533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env10532 == env10533) = true)

theorem identity10533 : scanCanonicalize (H12AffineFastState.compose env10533 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10533 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,33110,38160,262144,1025,32769,36929,264533,16,32771,349,64,2049,5392,36864,262145,34133,297300,257,33,38224,513]

theorem envBound10534 : H12AffineFastState.Bounded env10534 := by
  intro p hp
  have h : env10534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10533_10534 : H12AffineEnvironment.transform 13 5377 env10533 = env10534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10533 == env10534) = true)

theorem identity10534 : scanCanonicalize (H12AffineFastState.compose env10534 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound10534 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,33110,38160,2421,1025,32769,36929,32,16,32771,349,64,2049,5392,36864,2420,34133,32801,257,33,38224,513]

theorem envBound10535 : H12AffineFastState.Bounded env10535 := by
  intro p hp
  have h : env10535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10534_10535 : H12AffineEnvironment.transform 17 2421 env10534 = env10535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env10534 == env10535) = true)

theorem identity10535 : scanCanonicalize (H12AffineFastState.compose env10535 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound10535 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10536 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4113,32768,33110,36864,2421,273,32769,36929,32,16,32771,349,64,2049,4096,36864,2420,32837,32801,257,33,36928,513]

theorem envBound10536 : H12AffineFastState.Bounded env10536 := by
  intro p hp
  have h : env10536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10535_10536 : H12AffineEnvironment.transform 9 272 env10535 = env10536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env10535 == env10536) = true)

theorem identity10536 : scanCanonicalize (H12AffineFastState.compose env10536 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2129) := by decide +kernel

theorem selectedBound10536 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env10537 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4113,2129,2311,6225,2421,273,2128,6160,32,16,2130,349,64,2049,4096,6225,2420,2068,2160,257,33,6161,513]

theorem envBound10537 : H12AffineFastState.Bounded env10537 := by
  intro p hp
  have h : env10537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10536_10537 : H12AffineEnvironment.transform 14 2129 env10536 = env10537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2129 env10536 == env10537) = true)

theorem identity10537 : scanCanonicalize (H12AffineFastState.compose env10537 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound10537 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env10538 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2112,348,2129,2129,2311,17,2421,273,2128,80,32,16,2130,349,64,2049,2112,17,2420,2068,2160,257,33,81,513]

theorem envBound10538 : H12AffineFastState.Bounded env10538 := by
  intro p hp
  have h : env10538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10537_10538 : H12AffineEnvironment.transform 11 2112 env10537 = env10538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env10537 == env10538) = true)

theorem identity10538 : scanCanonicalize (H12AffineFastState.compose env10538 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound10538 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env10539 : List Nat := [2,4,8,16,32,64,9,256,512,272,293,357,348,372,372,34,17,80,273,373,80,32,16,375,349,64,292,357,17,81,305,341,257,33,81,513]

theorem envBound10539 : H12AffineFastState.Bounded env10539 := by
  intro p hp
  have h : env10539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10538_10539 : H12AffineEnvironment.transform 10 293 env10538 = env10539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env10538 == env10539) = true)

theorem identity10539 : scanCanonicalize (H12AffineFastState.compose env10539 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound10539 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10540 : List Nat := [2,4,8,16,32,64,9,256,293,272,293,357,348,372,372,34,17,80,273,373,80,32,16,375,349,64,292,357,17,81,305,341,257,33,81,292]

theorem envBound10540 : H12AffineFastState.Bounded env10540 := by
  intro p hp
  have h : env10540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10539_10540 : H12AffineEnvironment.transform 8 293 env10539 = env10540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env10539 == env10540) = true)

theorem identity10540 : scanCanonicalize (H12AffineFastState.compose env10540 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound10540 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env10541 : List Nat := [2,4,8,16,32,64,9,116,81,100,81,17,40,0,0,34,17,80,101,1,80,32,16,3,41,64,80,17,17,81,69,33,117,33,81,80]

theorem envBound10541 : H12AffineFastState.Bounded env10541 := by
  intro p hp
  have h : env10541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10540_10541 : H12AffineEnvironment.transform 7 116 env10540 = env10541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env10540 == env10541) = true)

theorem identity10541 : scanCanonicalize (H12AffineFastState.compose env10541 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound10541 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10542 : List Nat := [2,4,8,16,32,43,9,31,58,15,58,17,40,0,0,34,17,59,14,1,59,32,16,3,41,43,59,17,17,58,46,33,30,33,58,59]

theorem envBound10542 : H12AffineFastState.Bounded env10542 := by
  intro p hp
  have h : env10542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10541_10542 : H12AffineEnvironment.transform 5 43 env10541 = env10542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env10541 == env10542) = true)

theorem identity10542 : scanCanonicalize (H12AffineFastState.compose env10542 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound10542 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10543 : List Nat := [2,4,8,16,26,17,9,31,0,15,0,17,18,0,0,24,17,1,14,1,1,26,16,3,19,17,1,17,17,0,20,27,30,27,0,1]

theorem envBound10543 : H12AffineFastState.Bounded env10543 := by
  intro p hp
  have h : env10543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10542_10543 : H12AffineEnvironment.transform 4 26 env10542 = env10543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env10542 == env10543) = true)

def env10544 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272393,17,95496,8193,64,2049,5393,45404,283904,61705,318548,257,21792,46092,120407]

theorem envBound10544 : H12AffineFastState.Bounded env10544 := by
  intro p hp
  have h : env10544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10530_10544 : H12AffineEnvironment.transform 16 38161 env10530 = env10544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env10530 == env10544) = true)

theorem identity10544 : scanCanonicalize (H12AffineFastState.compose env10544 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound10544 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10545 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,130174,1025,32769,58397,119927,17,95496,8193,64,2049,5393,45404,108926,61705,73770,257,21792,46092,120407]

theorem envBound10545 : H12AffineFastState.Bounded env10545 := by
  intro p hp
  have h : env10545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10544_10545 : H12AffineEnvironment.transform 17 130174 env10544 = env10545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env10544 == env10545) = true)

theorem identity10545 : scanCanonicalize (H12AffineFastState.compose env10545 (packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound10545 : packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env10546 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21510,38161,43128,1025,32769,58397,32881,17,8462,8193,64,2049,5393,45404,64888,61705,29740,257,21792,46092,33361]

theorem envBound10546 : H12AffineFastState.Bounded env10546 := by
  intro p hp
  have h : env10546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10545_10546 : H12AffineEnvironment.transform 15 21510 env10545 = env10546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env10545 == env10546) = true)

theorem identity10546 : scanCanonicalize (H12AffineFastState.compose env10546 (packedSelected [0,1,2,6,7,8,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound10546 : packedSelected [0,1,2,6,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env10547 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,342,38161,43128,1025,32769,45389,32881,17,8462,8193,64,2049,5393,45404,43048,42073,8572,257,112,46092,33361]

theorem envBound10547 : H12AffineFastState.Bounded env10547 := by
  intro p hp
  have h : env10547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10546_10547 : H12AffineEnvironment.transform 13 5456 env10546 = env10547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env10546 == env10547) = true)

theorem identity10547 : scanCanonicalize (H12AffineFastState.compose env10547 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound10547 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env10548 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,32768,342,38161,35108,1025,32769,36881,32881,17,82,349,64,2049,5393,36864,35188,34053,32,257,112,38224,33361]

theorem envBound10548 : H12AffineFastState.Bounded env10548 := by
  intro p hp
  have h : env10548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10547_10548 : H12AffineEnvironment.transform 12 348 env10547 = env10548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env10547 == env10548) = true)

theorem identity10548 : scanCanonicalize (H12AffineFastState.compose env10548 (packedSelected [0,1,2,4,5,6,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 8017) := by decide +kernel

theorem selectedBound10548 : packedSelected [0,1,2,4,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env10549 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,8017,342,2624,5749,1025,8016,3904,7968,17,82,349,64,2049,5393,3921,5669,6740,32,257,112,2561,7424]

theorem envBound10549 : H12AffineFastState.Bounded env10549 := by
  intro p hp
  have h : env10549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10548_10549 : H12AffineEnvironment.transform 14 8017 env10548 = env10549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8017 env10548 == env10549) = true)

theorem identity10549 : scanCanonicalize (H12AffineFastState.compose env10549 (packedSelected [4,5,7,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound10549 : packedSelected [4,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env10550 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1076,348,356,2917,342,2624,577,1025,2916,3904,2836,17,82,349,64,2049,293,3921,529,3680,32,257,112,2561,2356]

theorem envBound10550 : H12AffineFastState.Bounded env10550 := by
  intro p hp
  have h : env10550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10549_10550 : H12AffineEnvironment.transform 11 1076 env10549 = env10550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env10549 == env10550) = true)

theorem identity10550 : scanCanonicalize (H12AffineFastState.compose env10550 (packedSelected [2,3,5,6,10,14] rootPS)) = affineNative (2^(10+1) ^^^ 869) := by decide +kernel

theorem selectedBound10550 : packedSelected [2,3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env10551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,869,1076,348,356,0,342,293,577,1025,1,1061,113,17,82,349,64,868,293,1076,529,1285,32,257,112,356,593]

theorem envBound10551 : H12AffineFastState.Bounded env10551 := by
  intro p hp
  have h : env10551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10550_10551 : H12AffineEnvironment.transform 10 869 env10550 = env10551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 869 env10550 == env10551) = true)

theorem identity10551 : scanCanonicalize (H12AffineFastState.compose env10551 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound10551 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env10552 : List Nat := [2,4,8,16,32,64,9,256,512,784,869,804,348,356,0,342,293,577,785,1,821,113,17,82,349,64,868,293,804,529,533,32,257,112,356,593]

theorem envBound10552 : H12AffineFastState.Bounded env10552 := by
  intro p hp
  have h : env10552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10551_10552 : H12AffineEnvironment.transform 9 784 env10551 = env10552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env10551 == env10552) = true)

theorem identity10552 : scanCanonicalize (H12AffineFastState.compose env10552 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound10552 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env10553 : List Nat := [2,4,8,16,32,64,9,116,512,612,529,592,40,16,0,34,81,577,613,1,577,113,17,82,41,64,528,81,592,529,533,32,117,112,16,593]

theorem envBound10553 : H12AffineFastState.Bounded env10553 := by
  intro p hp
  have h : env10553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10552_10553 : H12AffineEnvironment.transform 7 116 env10552 = env10553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env10552 == env10553) = true)

theorem identity10553 : scanCanonicalize (H12AffineFastState.compose env10553 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10553 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env10554 : List Nat := [2,4,8,16,32,17,9,37,512,565,529,513,40,16,0,34,0,528,564,1,528,32,17,3,41,17,528,0,513,529,533,32,36,33,16,512]

theorem envBound10554 : H12AffineFastState.Bounded env10554 := by
  intro p hp
  have h : env10554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10553_10554 : H12AffineEnvironment.transform 5 17 env10553 = env10554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10553 == env10554) = true)

theorem identity10554 : scanCanonicalize (H12AffineFastState.compose env10554 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10554 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10555 : List Nat := [2,4,8,16,0,17,9,5,512,533,529,513,8,16,0,2,0,528,532,1,528,0,17,3,9,17,528,0,513,529,533,0,4,1,16,512]

theorem envBound10555 : H12AffineFastState.Bounded env10555 := by
  intro p hp
  have h : env10555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10554_10555 : H12AffineEnvironment.transform 4 0 env10554 = env10555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10554 == env10555) = true)

theorem identity10555 : scanCanonicalize (H12AffineFastState.compose env10555 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound10555 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10556 : List Nat := [2,4,8,16,0,17,9,5,1,20,16,0,8,16,0,2,0,17,21,1,17,0,17,3,9,17,17,0,0,16,20,0,4,1,16,1]

theorem envBound10556 : H12AffineFastState.Bounded env10556 := by
  intro p hp
  have h : env10556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10555_10556 : H12AffineEnvironment.transform 8 1 env10555 = env10556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env10555 == env10556) = true)

theorem identity10556 : scanCanonicalize (H12AffineFastState.compose env10556 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound10556 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10557 : List Nat := [2,1,8,16,0,17,9,0,1,17,16,0,8,16,0,2,0,17,16,1,17,0,17,3,9,17,17,0,0,16,17,0,1,1,16,1]

theorem envBound10557 : H12AffineFastState.Bounded env10557 := by
  intro p hp
  have h : env10557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10556_10557 : H12AffineEnvironment.transform 1 1 env10556 = env10557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env10556 == env10557) = true)

def env10558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272513,169216,95496,8328,64,2185,163840,45525,283904,156696,412109,257,21792,46213,213967]

theorem envBound10558 : H12AffineFastState.Bounded env10558 := by
  intro p hp
  have h : env10558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10500_10558 : H12AffineEnvironment.transform 21 272513 env10500 = env10558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env10500 == env10558) = true)

theorem identity10558 : scanCanonicalize (H12AffineFastState.compose env10558 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound10558 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58516,272513,17,95496,8328,64,2185,5393,45525,283904,61705,318684,257,21792,46213,120542]

theorem envBound10559 : H12AffineFastState.Bounded env10559 := by
  intro p hp
  have h : env10559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10558_10559 : H12AffineEnvironment.transform 16 38161 env10558 = env10559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env10558 == env10559) = true)

def env10560 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58396,272393,17,95496,8192,64,2049,5393,45405,283904,61705,318548,257,21792,46093,120406]

theorem envBound10560 : H12AffineFastState.Bounded env10560 := by
  intro p hp
  have h : env10560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10559_10560 : H12AffineEnvironment.transform 6 8 env10559 = env10560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10559 == env10560) = true)

theorem identity10560 : scanCanonicalize (H12AffineFastState.compose env10560 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound10560 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10561 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,89378,1025,32769,58396,95531,17,95496,8192,64,2049,5393,45405,67618,61705,98678,257,21792,46093,120406]

theorem envBound10561 : H12AffineFastState.Bounded env10561 := by
  intro p hp
  have h : env10561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10560_10561 : H12AffineEnvironment.transform 17 89378 env10560 = env10561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env10560 == env10561) = true)

theorem identity10561 : scanCanonicalize (H12AffineFastState.compose env10561 (packedSelected [1,7,8,12,14,15,19,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound10561 : packedSelected [1,7,8,12,14,15,19,20,27] rootPS < 2^1333 := by decide +kernel

def env10562 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,372,65536,5221,89378,1025,373,25960,95531,17,95496,8192,64,2049,5393,12329,67618,28797,65538,257,21792,13689,87842]

theorem envBound10562 : H12AffineFastState.Bounded env10562 := by
  intro p hp
  have h : env10562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10561_10562 : H12AffineEnvironment.transform 14 372 env10561 = env10562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env10561 == env10562) = true)

theorem identity10562 : scanCanonicalize (H12AffineFastState.compose env10562 (packedSelected [4,8,9,10,12,14,15,18,20,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound10562 : packedSelected [4,8,9,10,12,14,15,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env10563 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,372,343,5221,23669,1025,373,25960,29820,17,29791,8192,64,2049,5393,12329,2421,28797,341,257,21792,13689,22133]

theorem envBound10563 : H12AffineFastState.Bounded env10563 := by
  intro p hp
  have h : env10563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10562_10563 : H12AffineEnvironment.transform 15 343 env10562 = env10563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env10562 == env10563) = true)

theorem identity10563 : scanCanonicalize (H12AffineFastState.compose env10563 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound10563 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env10564 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,372,343,5221,10588,1025,373,4161,341,17,374,8192,64,2049,5393,12329,2421,1364,341,257,8201,13689,9052]

theorem envBound10564 : H12AffineFastState.Bounded env10564 := by
  intro p hp
  have h : env10564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10563_10564 : H12AffineEnvironment.transform 13 13609 env10563 = env10564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env10563 == env10564) = true)

theorem identity10564 : scanCanonicalize (H12AffineFastState.compose env10564 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound10564 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10565 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,9,5408,372,343,5221,2389,1025,373,4161,341,17,374,9,64,2049,5393,4128,2421,1364,341,257,0,5488,853]

theorem envBound10565 : H12AffineFastState.Bounded env10565 := by
  intro p hp
  have h : env10565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10564_10565 : H12AffineEnvironment.transform 12 9 env10564 = env10565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env10564 == env10565) = true)

theorem identity10565 : scanCanonicalize (H12AffineFastState.compose env10565 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound10565 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10566 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,9,5236,32,3,5221,2049,1025,33,4161,1,17,34,9,64,2049,5189,4128,2081,1024,1,85,0,5156,513]

theorem envBound10566 : H12AffineFastState.Bounded env10566 := by
  intro p hp
  have h : env10566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10565_10566 : H12AffineEnvironment.transform 7 84 env10565 = env10566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env10565 == env10566) = true)

theorem identity10566 : scanCanonicalize (H12AffineFastState.compose env10566 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound10566 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10567 : List Nat := [2,4,8,16,32,49,8,37,512,1024,2048,4096,9,5125,32,3,5140,2049,1025,33,4144,1,17,34,9,49,2049,5172,4128,2081,1024,1,36,0,5156,513]

theorem envBound10567 : H12AffineFastState.Bounded env10567 := by
  intro p hp
  have h : env10567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10566_10567 : H12AffineEnvironment.transform 5 49 env10566 = env10567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env10566 == env10567) = true)

theorem identity10567 : scanCanonicalize (H12AffineFastState.compose env10567 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound10567 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10568 : List Nat := [2,4,8,16,32,49,8,37,512,1024,2048,1076,9,49,32,3,32,2049,1025,33,1028,1,17,34,9,49,2049,0,1044,2081,1024,1,36,0,16,513]

theorem envBound10568 : H12AffineFastState.Bounded env10568 := by
  intro p hp
  have h : env10568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10567_10568 : H12AffineEnvironment.transform 11 1076 env10567 = env10568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env10567 == env10568) = true)

theorem identity10568 : scanCanonicalize (H12AffineFastState.compose env10568 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound10568 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env10569 : List Nat := [2,4,8,16,32,49,8,37,512,1024,1061,1076,9,49,32,3,32,1060,1025,33,1028,1,17,34,9,49,1060,0,1044,1028,1024,1,36,0,16,513]

theorem envBound10569 : H12AffineFastState.Bounded env10569 := by
  intro p hp
  have h : env10569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10568_10569 : H12AffineEnvironment.transform 10 1061 env10568 = env10569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env10568 == env10569) = true)

theorem identity10569 : scanCanonicalize (H12AffineFastState.compose env10569 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound10569 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10570 : List Nat := [2,4,8,16,32,49,8,37,48,1024,1061,1076,9,49,32,3,32,1060,1025,33,1028,1,17,34,9,49,1060,0,1044,1028,1024,1,36,0,16,49]

theorem envBound10570 : H12AffineFastState.Bounded env10570 := by
  intro p hp
  have h : env10570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10569_10570 : H12AffineEnvironment.transform 8 48 env10569 = env10570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env10569 == env10570) = true)

theorem identity10570 : scanCanonicalize (H12AffineFastState.compose env10570 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound10570 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env10571 : List Nat := [2,4,8,16,32,49,8,37,48,5,32,49,9,49,32,3,32,33,4,33,1,1,17,34,9,49,33,0,17,1,5,1,36,0,16,49]

theorem envBound10571 : H12AffineFastState.Bounded env10571 := by
  intro p hp
  have h : env10571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10570_10571 : H12AffineEnvironment.transform 9 5 env10570 = env10571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env10570 == env10571) = true)

def env10572 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272392,17,95496,8193,64,2048,5393,45404,283904,61705,318549,257,21792,46092,120407]

theorem envBound10572 : H12AffineFastState.Bounded env10572 := by
  intro p hp
  have h : env10572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10559_10572 : H12AffineEnvironment.transform 6 9 env10559 = env10572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10559 == env10572) = true)

theorem identity10572 : scanCanonicalize (H12AffineFastState.compose env10572 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound10572 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10573 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,130174,1025,32769,58397,119926,17,95496,8193,64,2048,5393,45404,108926,61705,73771,257,21792,46092,120407]

theorem envBound10573 : H12AffineFastState.Bounded env10573 := by
  intro p hp
  have h : env10573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10572_10573 : H12AffineEnvironment.transform 17 130174 env10572 = env10573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env10572 == env10573) = true)

theorem identity10573 : scanCanonicalize (H12AffineFastState.compose env10573 (packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound10573 : packedSelected [0,1,3,5,7,8,11,12,14,16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env10574 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,38161,43048,1025,32769,58397,32800,17,8542,8193,64,2048,5393,45404,64808,61705,29821,257,21792,46092,33281]

theorem envBound10574 : H12AffineFastState.Bounded env10574 := by
  intro p hp
  have h : env10574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10573_10574 : H12AffineEnvironment.transform 15 21590 env10573 = env10574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env10573 == env10574) = true)

theorem identity10574 : scanCanonicalize (H12AffineFastState.compose env10574 (packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound10574 : packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS < 2^1333 := by decide +kernel

def env10575 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,342,38161,43048,1025,32769,45341,32800,17,8542,8193,64,2048,5393,45404,43048,41993,8573,257,32,46092,33281]

theorem envBound10575 : H12AffineFastState.Bounded env10575 := by
  intro p hp
  have h : env10575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10574_10575 : H12AffineEnvironment.transform 13 5376 env10574 = env10575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10574 == env10575) = true)

theorem identity10575 : scanCanonicalize (H12AffineFastState.compose env10575 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound10575 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env10576 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,342,13388,2421,1025,8540,4160,8573,17,8542,8193,64,2048,5393,4097,2421,1364,8573,257,32,5457,9052]

theorem envBound10576 : H12AffineFastState.Bounded env10576 := by
  intro p hp
  have h : env10576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10575_10576 : H12AffineEnvironment.transform 14 8541 env10575 = env10576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env10575 == env10576) = true)

theorem identity10576 : scanCanonicalize (H12AffineFastState.compose env10576 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 5432) := by decide +kernel

theorem selectedBound10576 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10577 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5432,5376,5221,342,372,2421,1025,5220,4160,5189,17,5222,5433,64,2048,5393,4097,2421,1364,5189,257,32,5457,5732]

theorem envBound10577 : H12AffineFastState.Bounded env10577 := by
  intro p hp
  have h : env10577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10576_10577 : H12AffineEnvironment.transform 12 5432 env10576 = env10577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5432 env10576 == env10577) = true)

theorem identity10577 : scanCanonicalize (H12AffineFastState.compose env10577 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound10577 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env10578 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,5196,5236,5221,34,0,2049,1025,5220,4160,5189,17,5222,5197,64,2048,5221,4097,2049,1056,5189,117,32,5157,5732]

theorem envBound10578 : H12AffineFastState.Bounded env10578 := by
  intro p hp
  have h : env10578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10577_10578 : H12AffineEnvironment.transform 7 116 env10577 = env10578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env10577 == env10578) = true)

theorem identity10578 : scanCanonicalize (H12AffineFastState.compose env10578 (packedSelected [1,6,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 1124) := by decide +kernel

theorem selectedBound10578 : packedSelected [1,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env10579 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,1124,40,16,1,34,0,2049,1025,0,1060,33,17,2,41,64,2048,1,1125,2049,1056,33,117,32,65,512]

theorem envBound10579 : H12AffineFastState.Bounded env10579 := by
  intro p hp
  have h : env10579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10578_10579 : H12AffineEnvironment.transform 11 1124 env10578 = env10579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1124 env10578 == env10579) = true)

theorem identity10579 : scanCanonicalize (H12AffineFastState.compose env10579 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 112) := by decide +kernel

theorem selectedBound10579 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10580 : List Nat := [2,4,8,16,32,64,9,116,112,1024,2048,1124,40,16,1,34,0,2049,1025,0,1060,33,17,2,41,64,2048,1,1125,2049,1056,33,117,32,65,112]

theorem envBound10580 : H12AffineFastState.Bounded env10580 := by
  intro p hp
  have h : env10580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10579_10580 : H12AffineEnvironment.transform 8 112 env10579 = env10580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 112 env10579 == env10580) = true)

theorem identity10580 : scanCanonicalize (H12AffineFastState.compose env10580 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound10580 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10581 : List Nat := [2,4,8,16,32,48,9,4,0,1024,2048,1044,40,16,1,34,0,2049,1025,0,1060,33,17,2,41,48,2048,1,1045,2049,1056,33,5,32,49,0]

theorem envBound10581 : H12AffineFastState.Bounded env10581 := by
  intro p hp
  have h : env10581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10580_10581 : H12AffineEnvironment.transform 5 48 env10580 = env10581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env10580 == env10581) = true)

theorem identity10581 : scanCanonicalize (H12AffineFastState.compose env10581 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound10581 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env10582 : List Nat := [2,4,8,16,32,48,9,4,0,20,2048,0,40,16,1,34,0,2049,21,0,48,33,17,2,41,48,2048,1,1,2049,52,33,5,32,49,0]

theorem envBound10582 : H12AffineFastState.Bounded env10582 := by
  intro p hp
  have h : env10582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10581_10582 : H12AffineEnvironment.transform 9 20 env10581 = env10582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env10581 == env10582) = true)

theorem identity10582 : scanCanonicalize (H12AffineFastState.compose env10582 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound10582 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10583 : List Nat := [2,4,8,16,32,48,9,4,0,20,48,0,40,16,1,34,0,49,21,0,48,33,17,2,41,48,48,1,1,49,52,33,5,32,49,0]

theorem envBound10583 : H12AffineFastState.Bounded env10583 := by
  intro p hp
  have h : env10583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10582_10583 : H12AffineEnvironment.transform 10 48 env10582 = env10583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env10582 == env10583) = true)

theorem identity10583 : scanCanonicalize (H12AffineFastState.compose env10583 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound10583 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env10584 : List Nat := [2,4,8,5,32,37,9,4,0,1,37,0,40,5,1,34,0,36,0,0,37,33,4,2,41,37,37,1,1,36,33,33,5,32,36,0]

theorem envBound10584 : H12AffineFastState.Bounded env10584 := by
  intro p hp
  have h : env10584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10583_10584 : H12AffineEnvironment.transform 3 5 env10583 = env10584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env10583 == env10584) = true)

theorem identity10584 : scanCanonicalize (H12AffineFastState.compose env10584 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10584 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env10585 : List Nat := [2,4,8,5,0,5,9,4,0,1,5,0,8,5,1,2,0,4,0,0,5,1,4,2,9,5,5,1,1,4,1,1,5,0,4,0]

theorem envBound10585 : H12AffineFastState.Bounded env10585 := by
  intro p hp
  have h : env10585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10584_10585 : H12AffineEnvironment.transform 4 0 env10584 = env10585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10584 == env10585) = true)

def env10586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,4194304,169217,95497,8328,64,4464648,163841,45524,283905,156696,4350285,257,21792,46213,213967]

theorem envBound10586 : H12AffineFastState.Bounded env10586 := by
  intro p hp
  have h : env10586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10499_10586 : H12AffineEnvironment.transform 22 169217 env10499 = env10586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env10499 == env10586) = true)

def env10587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272512,169217,95497,8328,64,2184,163841,45524,283905,156696,412109,257,21792,46213,213967]

theorem envBound10587 : H12AffineFastState.Bounded env10587 := by
  intro p hp
  have h : env10587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10586_10587 : H12AffineEnvironment.transform 21 272512 env10586 = env10587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env10586 == env10587) = true)

theorem identity10587 : scanCanonicalize (H12AffineFastState.compose env10587 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound10587 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,160133,272512,156116,95497,8328,64,2184,160980,17665,283905,156696,412109,257,21792,16464,213967]

theorem envBound10588 : H12AffineFastState.Bounded env10588 := by
  intro p hp
  have h : env10588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10587_10588 : H12AffineEnvironment.transform 14 29909 env10587 = env10588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env10587 == env10588) = true)

def env10589 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,160013,272392,155996,95497,8192,64,2048,160860,17665,283905,156696,411973,257,21792,16464,213831]

theorem envBound10589 : H12AffineFastState.Bounded env10589 := by
  intro p hp
  have h : env10589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10588_10589 : H12AffineEnvironment.transform 6 8 env10588 = env10589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10588 == env10589) = true)

theorem identity10589 : scanCanonicalize (H12AffineFastState.compose env10589 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound10589 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env10590 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,23668,1025,29788,160013,29820,155996,95497,8192,64,2048,160860,17665,2421,156696,136497,257,21792,16464,213831]

theorem envBound10590 : H12AffineFastState.Bounded env10590 := by
  intro p hp
  have h : env10590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10589_10590 : H12AffineEnvironment.transform 17 23668 env10589 = env10590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env10589 == env10590) = true)

theorem identity10590 : scanCanonicalize (H12AffineFastState.compose env10590 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10590 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env10591 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,65536,131072,23668,1025,21761,151632,21793,147457,87124,349,64,2048,152833,17665,2421,148805,136497,257,21792,16464,213831]

theorem envBound10591 : H12AffineFastState.Bounded env10591 := by
  intro p hp
  have h : env10591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10590_10591 : H12AffineEnvironment.transform 12 349 env10590 = env10591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10590 == env10591) = true)

theorem identity10591 : scanCanonicalize (H12AffineFastState.compose env10591 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 81971) := by decide +kernel

theorem selectedBound10591 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env10592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,65536,81971,23668,1025,21761,69731,21793,65586,87124,349,64,2048,70962,17665,2421,66934,87298,257,21792,16464,884]

theorem envBound10592 : H12AffineFastState.Bounded env10592 := by
  intro p hp
  have h : env10592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10591_10592 : H12AffineEnvironment.transform 16 81971 env10591 = env10592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 81971 env10591 == env10592) = true)

theorem identity10592 : scanCanonicalize (H12AffineFastState.compose env10592 (packedSelected [0,1,4,7,8,12,15,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound10592 : packedSelected [0,1,4,7,8,12,15,19,22] rootPS < 2^1333 := by decide +kernel

def env10593 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,21621,65536,81971,23668,1025,21620,69731,21588,65586,87124,40,64,2048,70727,17524,2048,66563,87159,116,21589,16464,513]

theorem envBound10593 : H12AffineFastState.Bounded env10593 := by
  intro p hp
  have h : env10593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10592_10593 : H12AffineEnvironment.transform 7 117 env10592 = env10593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env10592 == env10593) = true)

theorem identity10593 : scanCanonicalize (H12AffineFastState.compose env10593 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound10593 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10594 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,1,65536,70727,2048,1025,0,69731,32,65586,65568,40,64,2048,70727,4096,2048,66563,65539,116,33,5156,513]

theorem envBound10594 : H12AffineFastState.Bounded env10594 := by
  intro p hp
  have h : env10594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10593_10594 : H12AffineEnvironment.transform 13 5236 env10593 = env10594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env10593 == env10594) = true)

theorem identity10594 : scanCanonicalize (H12AffineFastState.compose env10594 (packedSelected [0,1,3,4,7,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 5127) := by decide +kernel

theorem selectedBound10594 : packedSelected [0,1,3,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env10595 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,1,5127,64,2048,1025,0,1124,32,5173,5159,40,64,2048,64,4096,2048,4100,5124,116,33,5156,513]

theorem envBound10595 : H12AffineFastState.Bounded env10595 := by
  intro p hp
  have h : env10595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10594_10595 : H12AffineEnvironment.transform 15 5127 env10594 = env10595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5127 env10594 == env10595) = true)

theorem identity10595 : scanCanonicalize (H12AffineFastState.compose env10595 (packedSelected [0,5,7,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound10595 : packedSelected [0,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env10596 : List Nat := [2,4,8,16,32,64,8,117,512,1024,0,4096,40,5236,1,5127,64,0,1025,0,1124,32,5173,5159,40,64,0,64,4096,0,4100,5124,116,33,5156,513]

theorem envBound10596 : H12AffineFastState.Bounded env10596 := by
  intro p hp
  have h : env10596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10595_10596 : H12AffineEnvironment.transform 10 0 env10595 = env10596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env10595 == env10596) = true)

theorem identity10596 : scanCanonicalize (H12AffineFastState.compose env10596 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound10596 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env10597 : List Nat := [2,4,8,16,32,64,8,117,512,1024,0,64,40,1076,1,1095,64,0,1025,0,1124,32,1141,1127,40,64,0,64,64,0,68,1092,116,33,1124,513]

theorem envBound10597 : H12AffineFastState.Bounded env10597 := by
  intro p hp
  have h : env10597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10596_10597 : H12AffineEnvironment.transform 11 64 env10596 = env10597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env10596 == env10597) = true)

theorem identity10597 : scanCanonicalize (H12AffineFastState.compose env10597 (packedSelected [1,2,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound10597 : packedSelected [1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env10598 : List Nat := [2,4,8,16,32,64,8,117,512,53,0,64,40,1,1,114,64,0,52,0,81,32,64,82,40,64,0,64,64,0,68,113,116,33,81,513]

theorem envBound10598 : H12AffineFastState.Bounded env10598 := by
  intro p hp
  have h : env10598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10597_10598 : H12AffineEnvironment.transform 9 53 env10597 = env10598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env10597 == env10598) = true)

theorem identity10598 : scanCanonicalize (H12AffineFastState.compose env10598 (packedSelected [14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10598 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env10599 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,17,40,1,1,35,17,0,52,0,0,32,17,3,40,17,0,17,17,0,21,32,37,33,0,513]

theorem envBound10599 : H12AffineFastState.Bounded env10599 := by
  intro p hp
  have h : env10599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10598_10599 : H12AffineEnvironment.transform 5 17 env10598 = env10599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10598 == env10599) = true)

theorem identity10599 : scanCanonicalize (H12AffineFastState.compose env10599 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound10599 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10600 : List Nat := [2,4,8,16,16,17,8,20,512,5,0,17,24,1,1,19,17,0,4,0,0,16,17,3,24,17,0,17,17,0,21,16,21,17,0,513]

theorem envBound10600 : H12AffineFastState.Bounded env10600 := by
  intro p hp
  have h : env10600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10599_10600 : H12AffineEnvironment.transform 4 16 env10599 = env10600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env10599 == env10600) = true)

theorem identity10600 : scanCanonicalize (H12AffineFastState.compose env10600 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10600 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10601 : List Nat := [2,4,8,0,0,1,8,4,512,5,0,1,8,1,1,3,1,0,4,0,0,0,1,3,8,1,0,1,1,0,5,0,5,1,0,513]

theorem envBound10601 : H12AffineFastState.Bounded env10601 := by
  intro p hp
  have h : env10601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10600_10601 : H12AffineEnvironment.transform 3 0 env10600 = env10601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10600 == env10601) = true)

theorem identity10601 : scanCanonicalize (H12AffineFastState.compose env10601 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound10601 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10602 : List Nat := [2,4,8,0,0,1,8,4,1,5,0,1,8,1,1,3,1,0,4,0,0,0,1,3,8,1,0,1,1,0,5,0,5,1,0,0]

theorem envBound10602 : H12AffineFastState.Bounded env10602 := by
  intro p hp
  have h : env10602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10601_10602 : H12AffineEnvironment.transform 8 1 env10601 = env10602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env10601 == env10602) = true)

def env10603 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,160012,272393,155997,95497,8193,64,2049,160861,17665,283905,156696,411972,257,21792,16464,213830]

theorem envBound10603 : H12AffineFastState.Bounded env10603 := by
  intro p hp
  have h : env10603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10588_10603 : H12AffineEnvironment.transform 6 9 env10588 = env10603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10588 == env10603) = true)

theorem identity10603 : scanCanonicalize (H12AffineFastState.compose env10603 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound10603 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env10604 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,67619,1025,29789,160012,73770,155997,95497,8193,64,2049,160861,17665,89378,156696,213351,257,21792,16464,213830]

theorem envBound10604 : H12AffineFastState.Bounded env10604 := by
  intro p hp
  have h : env10604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10603_10604 : H12AffineEnvironment.transform 17 67619 env10603 = env10604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env10603 == env10604) = true)

theorem identity10604 : scanCanonicalize (H12AffineFastState.compose env10604 (packedSelected [5,8,16,20,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound10604 : packedSelected [5,8,16,20,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env10605 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,82247,67619,1025,29789,77899,73770,73754,95497,8193,64,2049,79130,17665,89378,75103,32,257,21792,16464,513]

theorem envBound10605 : H12AffineFastState.Bounded env10605 := by
  intro p hp
  have h : env10605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10604_10605 : H12AffineEnvironment.transform 16 82247 env10604 = env10605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env10604 == env10605) = true)

theorem identity10605 : scanCanonicalize (H12AffineFastState.compose env10605 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10605 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10606 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,65536,82247,67619,1025,21760,69910,65911,65863,87124,348,64,2049,70727,17665,89378,66562,32,257,21792,16464,513]

theorem envBound10606 : H12AffineFastState.Bounded env10606 := by
  intro p hp
  have h : env10606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10605_10606 : H12AffineEnvironment.transform 12 349 env10605 = env10606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10605 == env10606) = true)

theorem identity10606 : scanCanonicalize (H12AffineFastState.compose env10606 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound10606 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env10607 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,342,16401,2421,1025,21760,4160,33,17,21762,348,64,2049,5393,17665,23668,1364,32,257,21792,16464,513]

theorem envBound10607 : H12AffineFastState.Bounded env10607 := by
  intro p hp
  have h : env10607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10606_10607 : H12AffineEnvironment.transform 15 342 env10606 = env10607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env10606 == env10607) = true)

theorem identity10607 : scanCanonicalize (H12AffineFastState.compose env10607 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound10607 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10608 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5393,2421,1025,0,4160,33,17,2,348,64,2049,5393,4097,2420,1364,32,257,32,5456,513]

theorem envBound10608 : H12AffineFastState.Bounded env10608 := by
  intro p hp
  have h : env10608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10607_10608 : H12AffineEnvironment.transform 13 5376 env10607 = env10608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10607 == env10608) = true)

theorem identity10608 : scanCanonicalize (H12AffineFastState.compose env10608 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound10608 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10609 : List Nat := [2,4,8,16,32,64,9,256,512,1024,91,4096,349,5376,1,342,5393,302,1025,0,4160,33,17,2,348,64,90,5393,4097,303,1364,32,257,32,5456,513]

theorem envBound10609 : H12AffineFastState.Bounded env10609 := by
  intro p hp
  have h : env10609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10608_10609 : H12AffineEnvironment.transform 10 91 env10608 = env10609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env10608 == env10609) = true)

theorem identity10609 : scanCanonicalize (H12AffineFastState.compose env10609 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound10609 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,91,0,349,1280,1,342,1297,302,1025,0,64,33,17,2,348,64,90,1297,1,303,1364,32,257,32,1360,513]

theorem envBound10610 : H12AffineFastState.Bounded env10610 := by
  intro p hp
  have h : env10610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10609_10610 : H12AffineEnvironment.transform 11 0 env10609 = env10610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env10609 == env10610) = true)

theorem identity10610 : scanCanonicalize (H12AffineFastState.compose env10610 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound10610 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env10611 : List Nat := [2,4,8,16,32,64,9,84,512,1024,91,0,9,1108,1,2,1093,122,1025,0,64,33,17,2,8,64,90,1093,1,123,1024,32,85,32,1028,513]

theorem envBound10611 : H12AffineFastState.Bounded env10611 := by
  intro p hp
  have h : env10611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10610_10611 : H12AffineEnvironment.transform 7 84 env10610 = env10611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env10610 == env10611) = true)

def env10612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272513,169217,95497,8328,64,2185,163841,45524,283905,156696,412108,257,21792,46213,213967]

theorem envBound10612 : H12AffineFastState.Bounded env10612 := by
  intro p hp
  have h : env10612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10586_10612 : H12AffineEnvironment.transform 21 272513 env10586 = env10612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env10586 == env10612) = true)

theorem identity10612 : scanCanonicalize (H12AffineFastState.compose env10612 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound10612 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,4160,272513,62660,95497,8328,64,2185,57796,45524,283905,1501,272393,257,21792,46213,74250]

theorem envBound10613 : H12AffineFastState.Bounded env10613 := by
  intro p hp
  have h : env10613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10612_10613 : H12AffineEnvironment.transform 16 25029 env10612 = env10613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env10612 == env10613) = true)

theorem identity10613 : scanCanonicalize (H12AffineFastState.compose env10613 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10613 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env10614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25029,262144,1025,32769,4160,272513,62660,21762,8328,64,2185,57796,45524,283905,1501,272393,257,21792,46213,513]

theorem envBound10614 : H12AffineFastState.Bounded env10614 := by
  intro p hp
  have h : env10614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10613_10614 : H12AffineEnvironment.transform 15 8203 env10613 = env10614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10613 == env10614) = true)

theorem identity10614 : scanCanonicalize (H12AffineFastState.compose env10614 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound10614 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env10615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8203,5529,262144,1025,32769,4160,272513,32920,8542,8328,64,2185,38296,45524,270685,1501,272393,257,8572,46213,513]

theorem envBound10615 : H12AffineFastState.Bounded env10615 := by
  intro p hp
  have h : env10615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10614_10615 : H12AffineEnvironment.transform 13 13404 env10614 = env10615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env10614 == env10615) = true)

theorem identity10615 : scanCanonicalize (H12AffineFastState.compose env10615 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound10615 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env10616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8203,5529,2421,1025,32769,4160,8692,32920,8542,8328,64,2185,38296,45524,10280,1501,8572,257,8572,46213,513]

theorem envBound10616 : H12AffineFastState.Bounded env10616 := by
  intro p hp
  have h : env10616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10615_10616 : H12AffineEnvironment.transform 17 2421 env10615 = env10616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env10615 == env10616) = true)

theorem identity10616 : scanCanonicalize (H12AffineFastState.compose env10616 (packedSelected [1,2,3,4,5,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 508) := by decide +kernel

theorem selectedBound10616 : packedSelected [1,2,3,4,5,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env10617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,508,8203,5529,2421,1025,509,4160,8692,356,8542,8328,64,2185,5220,12328,10280,1501,8572,257,8572,13689,513]

theorem envBound10617 : H12AffineFastState.Bounded env10617 := by
  intro p hp
  have h : env10617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10616_10617 : H12AffineEnvironment.transform 14 508 env10616 = env10617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 508 env10616 == env10617) = true)

theorem identity10617 : scanCanonicalize (H12AffineFastState.compose env10617 (packedSelected [0,6,7,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound10617 : packedSelected [0,6,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env10618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5236,508,35,5529,2421,1025,509,4160,476,356,374,160,64,2185,5220,4096,2048,1501,340,257,340,5457,513]

theorem envBound10618 : H12AffineFastState.Bounded env10618 := by
  intro p hp
  have h : env10618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10617_10618 : H12AffineEnvironment.transform 12 40 env10617 = env10618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env10617 == env10618) = true)

theorem identity10618 : scanCanonicalize (H12AffineFastState.compose env10618 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10618 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env10619 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5236,373,35,5392,2421,1025,372,4160,341,356,374,41,64,2048,5220,4096,2048,1364,340,257,340,5457,513]

theorem envBound10619 : H12AffineFastState.Bounded env10619 := by
  intro p hp
  have h : env10619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10618_10619 : H12AffineEnvironment.transform 6 9 env10618 = env10619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10618 == env10619) = true)

theorem identity10619 : scanCanonicalize (H12AffineFastState.compose env10619 (packedSelected [2,3,5,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound10619 : packedSelected [2,3,5,10,11] rootPS < 2^1333 := by decide +kernel

def env10620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1077,40,65,373,35,293,2421,1025,372,1141,341,356,374,41,64,2048,81,1077,2048,1364,340,257,340,356,513]

theorem envBound10620 : H12AffineFastState.Bounded env10620 := by
  intro p hp
  have h : env10620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10619_10620 : H12AffineEnvironment.transform 11 1077 env10619 = env10620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env10619 == env10620) = true)

theorem identity10620 : scanCanonicalize (H12AffineFastState.compose env10620 (packedSelected [2,6,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound10620 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env10621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,0,1077,40,65,373,35,293,373,1025,372,1141,341,356,374,41,64,0,81,1077,0,1364,340,257,340,356,513]

theorem envBound10621 : H12AffineFastState.Bounded env10621 := by
  intro p hp
  have h : env10621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10620_10621 : H12AffineEnvironment.transform 10 0 env10620 = env10621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env10620 == env10621) = true)

theorem identity10621 : scanCanonicalize (H12AffineFastState.compose env10621 (packedSelected [0,2,3,5,6,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10621 : packedSelected [0,2,3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env10622 : List Nat := [2,4,8,16,32,64,9,37,512,1024,0,1077,40,65,80,35,0,80,1025,81,1141,112,65,83,41,64,0,81,1077,0,1137,113,36,113,65,513]

theorem envBound10622 : H12AffineFastState.Bounded env10622 := by
  intro p hp
  have h : env10622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10621_10622 : H12AffineEnvironment.transform 7 37 env10621 = env10622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10621 == env10622) = true)

theorem identity10622 : scanCanonicalize (H12AffineFastState.compose env10622 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound10622 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10623 : List Nat := [2,4,8,16,32,64,9,37,512,36,0,17,40,65,80,35,0,80,37,81,81,112,65,83,41,64,0,81,17,0,85,113,36,113,65,513]

theorem envBound10623 : H12AffineFastState.Bounded env10623 := by
  intro p hp
  have h : env10623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10622_10623 : H12AffineEnvironment.transform 9 36 env10622 = env10623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env10622 == env10623) = true)

theorem identity10623 : scanCanonicalize (H12AffineFastState.compose env10623 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10623 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env10624 : List Nat := [2,4,8,16,32,16,9,37,512,36,0,17,40,17,0,35,0,0,37,1,1,32,17,3,41,16,0,1,17,0,5,33,36,33,17,513]

theorem envBound10624 : H12AffineFastState.Bounded env10624 := by
  intro p hp
  have h : env10624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10623_10624 : H12AffineEnvironment.transform 5 16 env10623 = env10624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10623 == env10624) = true)

theorem identity10624 : scanCanonicalize (H12AffineFastState.compose env10624 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound10624 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10625 : List Nat := [2,4,8,10,32,10,9,37,512,36,0,11,40,11,0,35,0,0,37,1,1,32,11,3,41,10,0,1,11,0,5,33,36,33,11,513]

theorem envBound10625 : H12AffineFastState.Bounded env10625 := by
  intro p hp
  have h : env10625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10624_10625 : H12AffineEnvironment.transform 3 10 env10624 = env10625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env10624 == env10625) = true)

theorem identity10625 : scanCanonicalize (H12AffineFastState.compose env10625 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound10625 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10626 : List Nat := [2,4,8,10,10,10,9,15,512,14,0,11,2,11,0,9,0,0,15,1,1,10,11,3,3,10,0,1,11,0,5,11,14,11,11,513]

theorem envBound10626 : H12AffineFastState.Bounded env10626 := by
  intro p hp
  have h : env10626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10625_10626 : H12AffineEnvironment.transform 4 10 env10625 = env10626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env10625 == env10626) = true)

theorem identity10626 : scanCanonicalize (H12AffineFastState.compose env10626 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound10626 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10627 : List Nat := [2,4,8,10,10,10,9,15,4,14,0,11,2,11,0,9,0,0,15,1,1,10,11,3,3,10,0,1,11,0,5,11,14,11,11,5]

theorem envBound10627 : H12AffineFastState.Bounded env10627 := by
  intro p hp
  have h : env10627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10626_10627 : H12AffineEnvironment.transform 8 4 env10626 = env10627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env10626 == env10627) = true)

def env10628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254784,25265169,145662400,525568,140903597,27337992,25733062]

theorem envBound10628 : H12AffineFastState.Bounded env10628 := by
  intro p hp
  have h : env10628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9919_10628 : H12AffineEnvironment.transform 25 65 env9919 = env10628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env9919 == env10628) = true)

def env10629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356288,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound10629 : H12AffineFastState.Bounded env10629 := by
  intro p hp
  have h : env10629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10628_10629 : H12AffineEnvironment.transform 26 30393344 env10628 = env10629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env10628 == env10629) = true)

def env10630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound10630 : H12AffineFastState.Bounded env10630 := by
  intro p hp
  have h : env10630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10629_10630 : H12AffineEnvironment.transform 18 1024 env10629 = env10630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env10629 == env10630) = true)

theorem identity10630 : scanCanonicalize (H12AffineFastState.compose env10630 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2534760) := by decide +kernel

theorem selectedBound10630 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env10631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534760,16777216,8328,65,23162216,18973836,456761,2125160,19343737,23160256,256,17263045,17270880,19271342]

theorem envBound10631 : H12AffineFastState.Bounded env10631 := by
  intro p hp
  have h : env10631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10630_10631 : H12AffineEnvironment.transform 22 2534760 env10630 = env10631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2534760 env10630 == env10631) = true)

def env10632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534760,474340,8328,65,6705548,2537576,456761,2125160,2102685,6707492,256,21793,46212,2175562]

theorem envBound10632 : H12AffineFastState.Bounded env10632 := by
  intro p hp
  have h : env10632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10631_10632 : H12AffineEnvironment.transform 23 474340 env10631 = env10632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474340 env10631 == env10632) = true)

def env10633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,2097152,4194304,2101328,98780,8328,65,6352052,2098512,17665,2125160,2102685,6349852,256,21793,46212,2175562]

theorem envBound10633 : H12AffineFastState.Bounded env10633 := by
  intro p hp
  have h : env10633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10632_10633 : H12AffineEnvironment.transform 17 179512 env10632 = env10633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env10632 == env10633) = true)

def env10634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,4194304,16,98780,8328,65,4259060,5392,17665,32040,1501,4256860,256,21793,46212,74250]

theorem envBound10634 : H12AffineFastState.Bounded env10634 := by
  intro p hp
  have h : env10634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10633_10634 : H12AffineEnvironment.transform 20 4160 env10633 = env10634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10633 == env10634) = true)

def env10635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,4194304,16,98644,8192,65,4258940,5392,17665,32040,1365,4256860,256,21793,46092,74250]

theorem envBound10635 : H12AffineFastState.Bounded env10635 := by
  intro p hp
  have h : env10635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10634_10635 : H12AffineEnvironment.transform 6 8 env10634 = env10635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10634 == env10635) = true)

theorem identity10635 : scanCanonicalize (H12AffineFastState.compose env10635 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound10635 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10636 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,108926,1024,32769,4160,4194304,16,98644,8192,65,4258940,5392,17665,32040,1365,4256860,256,21793,46092,74250]

theorem envBound10636 : H12AffineFastState.Bounded env10636 := by
  intro p hp
  have h : env10636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10635_10636 : H12AffineEnvironment.transform 16 70726 env10635 = env10636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env10635 == env10636) = true)

theorem identity10636 : scanCanonicalize (H12AffineFastState.compose env10636 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound10636 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env10637 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,70726,108926,1024,32769,4160,4194304,16,98644,8192,65,4229152,5392,12637,2420,1365,4227072,256,8573,46092,74250]

theorem envBound10637 : H12AffineFastState.Bounded env10637 := by
  intro p hp
  have h : env10637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10636_10637 : H12AffineEnvironment.transform 13 13404 env10636 = env10637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env10636 == env10637) = true)

theorem identity10637 : scanCanonicalize (H12AffineFastState.compose env10637 (packedSelected [3,4,5,9,10,11,12,14,16,18,23,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound10637 : packedSelected [3,4,5,9,10,11,12,14,16,18,23,32,38] rootPS < 2^1333 := by decide +kernel

def env10638 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,373,65536,70726,75787,1024,372,4160,4194304,16,65569,8192,65,4196693,5392,12637,2420,1365,4194677,256,8573,13689,74250]

theorem envBound10638 : H12AffineFastState.Bounded env10638 := by
  intro p hp
  have h : env10638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10637_10638 : H12AffineEnvironment.transform 14 373 env10637 = env10638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env10637 == env10638) = true)

theorem identity10638 : scanCanonicalize (H12AffineFastState.compose env10638 (packedSelected [0,3,5,7,9,10,11,14,15,18,20,22,23,32,41] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound10638 : packedSelected [0,3,5,7,9,10,11,14,15,18,20,22,23,32,41] rootPS < 2^1333 := by decide +kernel

def env10639 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,373,65536,70726,75787,1024,372,4160,8201,16,65569,8192,65,10588,5392,12637,2420,1365,8572,256,8573,13689,74250]

theorem envBound10639 : H12AffineFastState.Bounded env10639 := by
  intro p hp
  have h : env10639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10638_10639 : H12AffineEnvironment.transform 21 8201 env10638 = env10639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env10638 == env10639) = true)

theorem identity10639 : scanCanonicalize (H12AffineFastState.compose env10639 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound10639 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env10640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5237,373,65536,70726,67618,1024,372,4160,32,16,65569,41,65,2421,5392,4468,2420,1365,341,256,340,5456,66083]

theorem envBound10640 : H12AffineFastState.Bounded env10640 := by
  intro p hp
  have h : env10640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10639_10640 : H12AffineEnvironment.transform 12 41 env10639 = env10640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env10639 == env10640) = true)

theorem identity10640 : scanCanonicalize (H12AffineFastState.compose env10640 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound10640 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env10641 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,1,65536,70726,67618,1024,0,4160,32,16,65569,41,65,2049,5220,4096,2048,1057,33,116,32,5156,66083]

theorem envBound10641 : H12AffineFastState.Bounded env10641 := by
  intro p hp
  have h : env10641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10640_10641 : H12AffineEnvironment.transform 7 116 env10640 = env10641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env10640 == env10641) = true)

theorem identity10641 : scanCanonicalize (H12AffineFastState.compose env10641 (packedSelected [2,3,4,5,9,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound10641 : packedSelected [2,3,4,5,9,10,20] rootPS < 2^1333 := by decide +kernel

def env10642 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,1,35,5221,2049,1024,0,4160,32,16,2,41,65,2049,5220,4096,2048,1057,33,116,32,5156,512]

theorem envBound10642 : H12AffineFastState.Bounded env10642 := by
  intro p hp
  have h : env10642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10641_10642 : H12AffineEnvironment.transform 15 35 env10641 = env10642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env10641 == env10642) = true)

theorem identity10642 : scanCanonicalize (H12AffineFastState.compose env10642 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound10642 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10643 : List Nat := [2,4,8,16,32,64,8,116,512,1024,554,4096,41,5237,1,35,5221,555,1024,0,4160,32,16,2,41,65,555,5220,4096,554,1057,33,116,32,5156,512]

theorem envBound10643 : H12AffineFastState.Bounded env10643 := by
  intro p hp
  have h : env10643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10642_10643 : H12AffineEnvironment.transform 10 554 env10642 = env10643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env10642 == env10643) = true)

theorem identity10643 : scanCanonicalize (H12AffineFastState.compose env10643 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound10643 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10644 : List Nat := [2,4,8,16,32,48,8,4,512,1024,554,4096,41,5125,1,35,5141,555,1024,0,4144,32,16,2,41,49,555,5140,4096,554,1057,33,4,32,5156,512]

theorem envBound10644 : H12AffineFastState.Bounded env10644 := by
  intro p hp
  have h : env10644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10643_10644 : H12AffineEnvironment.transform 5 48 env10643 = env10644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env10643 == env10644) = true)

def env10645 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,4194304,16,98645,8193,65,4258941,5392,17665,32040,1364,4256860,256,21793,46093,74250]

theorem envBound10645 : H12AffineFastState.Bounded env10645 := by
  intro p hp
  have h : env10645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10634_10645 : H12AffineEnvironment.transform 6 9 env10634 = env10645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10634 == env10645) = true)

theorem identity10645 : scanCanonicalize (H12AffineFastState.compose env10645 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound10645 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,67619,1024,32769,4160,4194304,16,98645,8193,65,4258941,5392,17665,32040,1364,4256860,256,21793,46093,74250]

theorem envBound10646 : H12AffineFastState.Bounded env10646 := by
  intro p hp
  have h : env10646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10645_10646 : H12AffineEnvironment.transform 16 111899 env10645 = env10646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env10645 == env10646) = true)

theorem identity10646 : scanCanonicalize (H12AffineFastState.compose env10646 (packedSelected [0,1,2,3,4,6,8,9,10,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound10646 : packedSelected [0,1,2,3,4,6,8,9,10,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env10647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,46157,2421,1024,32769,4160,4194304,16,32771,8193,65,4258941,5392,17665,32040,1364,4256860,256,21793,46093,9052]

theorem envBound10647 : H12AffineFastState.Bounded env10647 := by
  intro p hp
  have h : env10647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10646_10647 : H12AffineEnvironment.transform 15 342 env10646 = env10647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env10646 == env10647) = true)

theorem identity10647 : scanCanonicalize (H12AffineFastState.compose env10647 (packedSelected [0,1,4,5,7,8,18,19,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound10647 : packedSelected [0,1,4,5,7,8,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env10648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,46157,2421,1024,32769,4160,8572,16,32771,8193,65,56577,5392,17665,32040,1364,54560,256,21793,46093,9052]

theorem envBound10648 : H12AffineFastState.Bounded env10648 := by
  intro p hp
  have h : env10648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10647_10648 : H12AffineEnvironment.transform 21 8572 env10647 = env10648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env10647 == env10648) = true)

theorem identity10648 : scanCanonicalize (H12AffineFastState.compose env10648 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound10648 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env10649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,342,5393,2421,1024,8541,4160,8572,16,8543,8193,65,31837,5392,17665,32040,1364,29820,256,21793,5457,9052]

theorem envBound10649 : H12AffineFastState.Bounded env10649 := by
  intro p hp
  have h : env10649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10648_10649 : H12AffineEnvironment.transform 14 8540 env10648 = env10649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env10648 == env10649) = true)

theorem identity10649 : scanCanonicalize (H12AffineFastState.compose env10649 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13576) := by decide +kernel

theorem selectedBound10649 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10650 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13576,8540,342,5393,2421,1024,8541,4160,8572,16,8543,8193,65,2389,5392,12297,2080,1364,372,256,8233,5457,9052]

theorem envBound10650 : H12AffineFastState.Bounded env10650 := by
  intro p hp
  have h : env10650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10649_10650 : H12AffineEnvironment.transform 13 13576 env10649 = env10650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13576 env10649 == env10650) = true)

theorem identity10650 : scanCanonicalize (H12AffineFastState.compose env10650 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound10650 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env10651 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8192,13405,8201,3,5188,2080,1024,8200,4160,8233,16,8202,8193,65,2048,5189,12297,2080,1025,33,85,8233,5124,8713]

theorem envBound10651 : H12AffineFastState.Bounded env10651 := by
  intro p hp
  have h : env10651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10650_10651 : H12AffineEnvironment.transform 7 85 env10650 = env10651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env10650 == env10651) = true)

theorem identity10651 : scanCanonicalize (H12AffineFastState.compose env10651 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10651 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10652 : List Nat := [2,4,8,16,1,64,9,85,512,1024,2048,4096,8192,13405,8201,3,5188,2049,1024,8200,4160,8200,16,8202,8193,65,2048,5189,12297,2049,1025,0,85,8200,5124,8713]

theorem envBound10652 : H12AffineFastState.Bounded env10652 := by
  intro p hp
  have h : env10652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10651_10652 : H12AffineEnvironment.transform 4 1 env10651 = env10652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10651 == env10652) = true)

theorem identity10652 : scanCanonicalize (H12AffineFastState.compose env10652 (packedSelected [3,5,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound10652 : packedSelected [3,5,10,16] rootPS < 2^1333 := by decide +kernel

def env10653 : List Nat := [2,4,8,16,1,64,9,85,512,1024,2048,4096,8,5205,1,3,5188,2049,1024,0,4160,0,16,2,9,65,2048,5189,4097,2049,1025,0,85,0,5124,513]

theorem envBound10653 : H12AffineFastState.Bounded env10653 := by
  intro p hp
  have h : env10653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10652_10653 : H12AffineEnvironment.transform 12 8 env10652 = env10653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env10652 == env10653) = true)

theorem identity10653 : scanCanonicalize (H12AffineFastState.compose env10653 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound10653 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10654 : List Nat := [2,4,8,16,1,64,9,85,512,69,2048,4096,8,4112,1,3,4097,2049,69,0,4160,0,16,2,9,65,2048,4096,4097,2049,68,0,85,0,4161,513]

theorem envBound10654 : H12AffineFastState.Bounded env10654 := by
  intro p hp
  have h : env10654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10653_10654 : H12AffineEnvironment.transform 9 69 env10653 = env10654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env10653 == env10654) = true)

theorem identity10654 : scanCanonicalize (H12AffineFastState.compose env10654 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound10654 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10655 : List Nat := [2,4,8,16,1,64,9,85,512,69,2048,16,8,0,1,3,17,2049,69,0,80,0,16,2,9,65,2048,16,17,2049,68,0,85,0,81,513]

theorem envBound10655 : H12AffineFastState.Bounded env10655 := by
  intro p hp
  have h : env10655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10654_10655 : H12AffineEnvironment.transform 11 16 env10654 = env10655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env10654 == env10655) = true)

theorem identity10655 : scanCanonicalize (H12AffineFastState.compose env10655 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound10655 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10656 : List Nat := [2,4,8,16,1,1,9,20,512,4,2048,16,8,0,1,3,17,2049,4,0,17,0,16,2,9,0,2048,16,17,2049,5,0,20,0,16,513]

theorem envBound10656 : H12AffineFastState.Bounded env10656 := by
  intro p hp
  have h : env10656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10655_10656 : H12AffineEnvironment.transform 5 1 env10655 = env10656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env10655 == env10656) = true)

theorem identity10656 : scanCanonicalize (H12AffineFastState.compose env10656 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound10656 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10657 : List Nat := [2,4,8,16,1,1,9,20,16,4,2048,16,8,0,1,3,17,2049,4,0,17,0,16,2,9,0,2048,16,17,2049,5,0,20,0,16,17]

theorem envBound10657 : H12AffineFastState.Bounded env10657 := by
  intro p hp
  have h : env10657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10656_10657 : H12AffineEnvironment.transform 8 16 env10656 = env10657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env10656 == env10657) = true)

theorem identity10657 : scanCanonicalize (H12AffineFastState.compose env10657 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound10657 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10658 : List Nat := [2,4,8,16,1,1,9,20,16,4,10,16,8,0,1,3,17,11,4,0,17,0,16,2,9,0,10,16,17,11,5,0,20,0,16,17]

theorem envBound10658 : H12AffineFastState.Bounded env10658 := by
  intro p hp
  have h : env10658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10657_10658 : H12AffineEnvironment.transform 10 10 env10657 = env10658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env10657 == env10658) = true)

theorem identity10658 : scanCanonicalize (H12AffineFastState.compose env10658 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound10658 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env10659 : List Nat := [2,4,8,11,1,1,9,15,11,4,10,11,8,0,1,3,10,11,4,0,10,0,11,2,9,0,10,11,10,11,5,0,15,0,11,10]

theorem envBound10659 : H12AffineFastState.Bounded env10659 := by
  intro p hp
  have h : env10659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10658_10659 : H12AffineEnvironment.transform 3 11 env10658 = env10659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env10658 == env10659) = true)

def env10660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,4194304,17,98780,8328,65,4259061,5393,17665,32041,1500,4256861,256,21793,46212,74251]

theorem envBound10660 : H12AffineFastState.Bounded env10660 := by
  intro p hp
  have h : env10660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10633_10660 : H12AffineEnvironment.transform 20 4161 env10633 = env10660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env10633 == env10660) = true)

theorem identity10660 : scanCanonicalize (H12AffineFastState.compose env10660 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169400) := by decide +kernel

theorem selectedBound10660 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,169400,17,98780,8328,65,158029,5393,17665,32041,1500,156133,256,21793,46212,74251]

theorem envBound10661 : H12AffineFastState.Bounded env10661 := by
  intro p hp
  have h : env10661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10660_10661 : H12AffineEnvironment.transform 21 169400 env10660 = env10661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env10660 == env10661) = true)

theorem identity10661 : scanCanonicalize (H12AffineFastState.compose env10661 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound10661 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env10662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179512,1024,32769,4161,169400,17,41430,8328,65,158029,5393,17665,32041,1500,156133,256,21793,46212,513]

theorem envBound10662 : H12AffineFastState.Bounded env10662 := by
  intro p hp
  have h : env10662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10661_10662 : H12AffineEnvironment.transform 15 8202 env10661 = env10662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env10661 == env10662) = true)

theorem identity10662 : scanCanonicalize (H12AffineFastState.compose env10662 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound10662 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,64808,1024,32769,4161,54696,17,41430,8328,65,10589,5393,17665,32041,1500,8693,256,21793,46212,513]

theorem envBound10663 : H12AffineFastState.Bounded env10663 := by
  intro p hp
  have h : env10663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10662_10663 : H12AffineEnvironment.transform 16 16400 env10662 = env10663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env10662 == env10663) = true)

theorem identity10663 : scanCanonicalize (H12AffineFastState.compose env10663 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound10663 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env10664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8202,16400,2341,1024,29708,4161,8613,17,21979,8328,65,10589,5393,17665,32041,1500,8693,256,21793,16521,513]

theorem envBound10664 : H12AffineFastState.Bounded env10664 := by
  intro p hp
  have h : env10664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10663_10664 : H12AffineEnvironment.transform 14 29709 env10663 = env10664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env10663 == env10664) = true)

theorem identity10664 : scanCanonicalize (H12AffineFastState.compose env10664 (packedSelected [1,2,4,5,6,8,9,14,18,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10664 : packedSelected [1,2,4,5,6,8,9,14,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env10665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,21761,262,16400,2341,1024,21760,4161,169,17,21979,388,65,2129,5393,17665,23589,1500,249,256,21793,16521,513]

theorem envBound10665 : H12AffineFastState.Bounded env10665 := by
  intro p hp
  have h : env10665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10664_10665 : H12AffineEnvironment.transform 12 268 env10664 = env10665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10664 == env10665) = true)

theorem identity10665 : scanCanonicalize (H12AffineFastState.compose env10665 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound10665 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env10666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5156,293,262,5172,2341,1024,292,4161,169,17,511,388,65,2129,5393,4389,2049,1500,249,256,261,5293,513]

theorem envBound10666 : H12AffineFastState.Bounded env10666 := by
  intro p hp
  have h : env10666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10665_10666 : H12AffineEnvironment.transform 13 5156 env10665 = env10666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env10665 == env10666) = true)

theorem identity10666 : scanCanonicalize (H12AffineFastState.compose env10666 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound10666 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env10667 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,268,4160,293,262,4176,2341,100,292,4161,169,17,511,388,65,2129,4469,4389,2049,440,249,256,261,4297,513]

theorem envBound10667 : H12AffineFastState.Bounded env10667 := by
  intro p hp
  have h : env10667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10666_10667 : H12AffineEnvironment.transform 9 100 env10666 = env10667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env10666 == env10667) = true)

theorem identity10667 : scanCanonicalize (H12AffineFastState.compose env10667 (packedSelected [2,3,6,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound10667 : packedSelected [2,3,6,8,10] rootPS < 2^1333 := by decide +kernel

def env10668 : List Nat := [2,4,8,16,32,64,88,256,512,100,2048,4096,268,4160,293,262,4176,2341,100,292,4161,113,17,295,348,65,2129,4469,4389,2049,352,33,256,261,4113,513]

theorem envBound10668 : H12AffineFastState.Bounded env10668 := by
  intro p hp
  have h : env10668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10667_10668 : H12AffineEnvironment.transform 6 88 env10667 = env10668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env10667 == env10668) = true)

theorem identity10668 : scanCanonicalize (H12AffineFastState.compose env10668 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10668 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10669 : List Nat := [2,4,8,16,32,64,88,37,512,100,2048,4096,41,4160,0,35,4176,2048,100,1,4161,113,17,2,121,65,2129,4176,4096,2049,69,33,37,32,4113,513]

theorem envBound10669 : H12AffineFastState.Bounded env10669 := by
  intro p hp
  have h : env10669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10668_10669 : H12AffineEnvironment.transform 7 37 env10668 = env10669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10668 == env10669) = true)

theorem identity10669 : scanCanonicalize (H12AffineFastState.compose env10669 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10669 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10670 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,41,4112,0,35,4096,2048,52,1,4113,33,17,2,41,17,2049,4096,4096,2049,21,33,37,32,4113,513]

theorem envBound10670 : H12AffineFastState.Bounded env10670 := by
  intro p hp
  have h : env10670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10669_10670 : H12AffineEnvironment.transform 5 16 env10669 = env10670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10669 == env10670) = true)

theorem identity10670 : scanCanonicalize (H12AffineFastState.compose env10670 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound10670 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10671 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,513,41,529,0,35,513,2048,52,1,528,33,17,2,41,17,2049,513,513,2049,21,33,37,32,528,513]

theorem envBound10671 : H12AffineFastState.Bounded env10671 := by
  intro p hp
  have h : env10671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10670_10671 : H12AffineEnvironment.transform 11 513 env10670 = env10671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env10670 == env10671) = true)

theorem identity10671 : scanCanonicalize (H12AffineFastState.compose env10671 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound10671 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10672 : List Nat := [2,4,8,16,32,16,8,37,512,52,11,513,41,529,0,35,513,11,52,1,528,33,17,2,41,17,10,513,513,10,21,33,37,32,528,513]

theorem envBound10672 : H12AffineFastState.Bounded env10672 := by
  intro p hp
  have h : env10672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10671_10672 : H12AffineEnvironment.transform 10 11 env10671 = env10672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env10671 == env10672) = true)

theorem identity10672 : scanCanonicalize (H12AffineFastState.compose env10672 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound10672 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10673 : List Nat := [2,4,8,16,32,16,8,37,26,52,11,27,41,11,0,35,27,11,52,1,10,33,17,2,41,17,10,27,27,10,21,33,37,32,10,27]

theorem envBound10673 : H12AffineFastState.Bounded env10673 := by
  intro p hp
  have h : env10673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10672_10673 : H12AffineEnvironment.transform 8 26 env10672 = env10673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env10672 == env10673) = true)

def env10674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,2097152,4194304,2101329,98781,8328,65,6352053,2098513,17664,2125160,2102685,6349853,256,21793,46212,2175562]

theorem envBound10674 : H12AffineFastState.Bounded env10674 := by
  intro p hp
  have h : env10674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10632_10674 : H12AffineEnvironment.transform 17 179513 env10632 = env10674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env10632 == env10674) = true)

def env10675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,4194304,17,98781,8328,65,4259061,5393,17664,32040,1501,4256861,256,21793,46212,74250]

theorem envBound10675 : H12AffineFastState.Bounded env10675 := by
  intro p hp
  have h : env10675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10674_10675 : H12AffineEnvironment.transform 20 4160 env10674 = env10675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10674 == env10675) = true)

theorem identity10675 : scanCanonicalize (H12AffineFastState.compose env10675 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156013) := by decide +kernel

theorem selectedBound10675 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,156013,17,98781,8328,65,171416,5393,17664,32040,1501,169264,256,21793,46212,74250]

theorem envBound10676 : H12AffineFastState.Bounded env10676 := by
  intro p hp
  have h : env10676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10675_10676 : H12AffineEnvironment.transform 21 156013 env10675 = env10676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156013 env10675 == env10676) = true)

def env10677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,156013,17,98645,8192,65,171280,5393,17664,32040,1365,169264,256,21793,46092,74250]

theorem envBound10677 : H12AffineFastState.Bounded env10677 := by
  intro p hp
  have h : env10677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10676_10677 : H12AffineEnvironment.transform 6 8 env10676 = env10677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10676 == env10677) = true)

theorem identity10677 : scanCanonicalize (H12AffineFastState.compose env10677 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound10677 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,179513,1024,32769,4160,156013,17,2,8192,65,171280,5393,17664,32040,1365,169264,256,21793,46092,41821]

theorem envBound10678 : H12AffineFastState.Bounded env10678 := by
  intro p hp
  have h : env10678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10677_10678 : H12AffineEnvironment.transform 15 33111 env10677 = env10678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env10677 == env10678) = true)

theorem identity10678 : scanCanonicalize (H12AffineFastState.compose env10678 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 49216) := by decide +kernel

theorem selectedBound10678 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env10679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,49216,32121,1024,32769,4160,41261,17,2,8192,65,23888,5393,17664,32040,1365,21872,256,21793,46092,41821]

theorem envBound10679 : H12AffineFastState.Bounded env10679 := by
  intro p hp
  have h : env10679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10678_10679 : H12AffineEnvironment.transform 16 49216 env10678 = env10679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49216 env10678 == env10679) = true)

theorem identity10679 : scanCanonicalize (H12AffineFastState.compose env10679 (packedSelected [0,1,3,7,8,9,10,12,14,15,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound10679 : packedSelected [0,1,3,7,8,9,10,12,14,15,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env10680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,32768,33111,46392,2049,1024,32769,4160,41261,17,2,8192,65,10280,5393,12408,2128,1365,8200,256,8281,46092,41821]

theorem envBound10680 : H12AffineFastState.Bounded env10680 := by
  intro p hp
  have h : env10680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10679_10680 : H12AffineEnvironment.transform 13 13688 env10679 = env10680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env10679 == env10680) = true)

theorem identity10680 : scanCanonicalize (H12AffineFastState.compose env10680 (packedSelected [2,3,6,9,10,11,14,18,19,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound10680 : packedSelected [2,3,6,9,10,11,14,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env10681 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8461,8282,5173,2049,1024,8460,4160,32,17,2,8192,65,10280,5393,12408,2128,1365,8200,256,8281,5377,592]

theorem envBound10681 : H12AffineFastState.Bounded env10681 := by
  intro p hp
  have h : env10681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10680_10681 : H12AffineEnvironment.transform 14 8461 env10680 = env10681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env10680 == env10681) = true)

theorem identity10681 : scanCanonicalize (H12AffineFastState.compose env10681 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10681 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env10682 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5236,1,342,5173,2049,1024,0,4160,32,17,2,268,65,2340,5393,4468,2128,1365,260,256,341,5377,592]

theorem envBound10682 : H12AffineFastState.Bounded env10682 := by
  intro p hp
  have h : env10682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10681_10682 : H12AffineEnvironment.transform 12 268 env10681 = env10682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10681 == env10682) = true)

theorem identity10682 : scanCanonicalize (H12AffineFastState.compose env10682 (packedSelected [2,3,5,6,10,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10682 : packedSelected [2,3,5,6,10,12,14] rootPS < 2^1333 := by decide +kernel

def env10683 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5156,1,262,5173,2049,1024,0,4112,32,17,2,268,17,2340,5393,4388,2048,1285,260,256,261,5377,512]

theorem envBound10683 : H12AffineFastState.Bounded env10683 := by
  intro p hp
  have h : env10683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10682_10683 : H12AffineEnvironment.transform 5 16 env10682 = env10683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10682 == env10683) = true)

theorem identity10683 : scanCanonicalize (H12AffineFastState.compose env10683 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10683 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10684 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,268,5125,1,262,5140,2049,1024,0,4112,1,17,2,268,17,2309,5393,4357,2048,1285,260,256,261,5377,512]

theorem envBound10684 : H12AffineFastState.Bounded env10684 := by
  intro p hp
  have h : env10684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10683_10684 : H12AffineEnvironment.transform 4 1 env10683 = env10684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10683 == env10684) = true)

theorem identity10684 : scanCanonicalize (H12AffineFastState.compose env10684 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound10684 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env10685 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,9,5125,1,3,5140,2049,1024,0,4112,1,17,2,9,17,2048,5140,4096,2048,1024,1,5,0,5124,512]

theorem envBound10685 : H12AffineFastState.Bounded env10685 := by
  intro p hp
  have h : env10685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10684_10685 : H12AffineEnvironment.transform 7 5 env10684 = env10685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env10684 == env10685) = true)

theorem identity10685 : scanCanonicalize (H12AffineFastState.compose env10685 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound10685 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10686 : List Nat := [2,4,8,16,1,16,8,5,512,20,2048,4096,9,4113,1,3,4096,2049,20,0,4112,1,17,2,9,17,2048,4096,4096,2048,20,1,5,0,4112,512]

theorem envBound10686 : H12AffineFastState.Bounded env10686 := by
  intro p hp
  have h : env10686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10685_10686 : H12AffineEnvironment.transform 9 20 env10685 = env10686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env10685 == env10686) = true)

theorem identity10686 : scanCanonicalize (H12AffineFastState.compose env10686 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound10686 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10687 : List Nat := [2,4,8,16,1,16,8,5,512,20,528,4096,9,4113,1,3,4096,529,20,0,4112,1,17,2,9,17,528,4096,4096,528,20,1,5,0,4112,512]

theorem envBound10687 : H12AffineFastState.Bounded env10687 := by
  intro p hp
  have h : env10687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10686_10687 : H12AffineEnvironment.transform 10 528 env10686 = env10687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env10686 == env10687) = true)

theorem identity10687 : scanCanonicalize (H12AffineFastState.compose env10687 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound10687 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10688 : List Nat := [2,4,8,16,1,16,8,5,15,20,31,4096,9,4113,1,3,4096,30,20,0,4112,1,17,2,9,17,31,4096,4096,31,20,1,5,0,4112,15]

theorem envBound10688 : H12AffineFastState.Bounded env10688 := by
  intro p hp
  have h : env10688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10687_10688 : H12AffineEnvironment.transform 8 15 env10687 = env10688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env10687 == env10688) = true)

theorem identity10688 : scanCanonicalize (H12AffineFastState.compose env10688 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound10688 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10689 : List Nat := [2,4,8,16,1,16,8,5,15,20,31,16,9,1,1,3,16,30,20,0,0,1,17,2,9,17,31,16,16,31,20,1,5,0,0,15]

theorem envBound10689 : H12AffineFastState.Bounded env10689 := by
  intro p hp
  have h : env10689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10688_10689 : H12AffineEnvironment.transform 11 16 env10688 = env10689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env10688 == env10689) = true)

theorem identity10689 : scanCanonicalize (H12AffineFastState.compose env10689 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound10689 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10690 : List Nat := [2,4,7,16,1,16,7,5,0,20,16,16,6,1,1,3,16,17,20,0,0,1,17,2,6,17,16,16,16,16,20,1,5,0,0,0]

theorem envBound10690 : H12AffineFastState.Bounded env10690 := by
  intro p hp
  have h : env10690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10689_10690 : H12AffineEnvironment.transform 2 7 env10689 = env10690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env10689 == env10690) = true)

theorem identity10690 : scanCanonicalize (H12AffineFastState.compose env10690 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10690 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10691 : List Nat := [2,4,7,0,1,0,7,5,0,4,0,0,6,1,1,3,0,1,4,0,0,1,1,2,6,1,0,0,0,0,4,1,5,0,0,0]

theorem envBound10691 : H12AffineFastState.Bounded env10691 := by
  intro p hp
  have h : env10691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10690_10691 : H12AffineEnvironment.transform 3 0 env10690 = env10691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10690 == env10691) = true)

def env10692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,156013,17,98644,8193,65,171281,5393,17664,32040,1364,169264,256,21793,46093,74250]

theorem envBound10692 : H12AffineFastState.Bounded env10692 := by
  intro p hp
  have h : env10692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10676_10692 : H12AffineEnvironment.transform 6 9 env10676 = env10692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10676 == env10692) = true)

theorem identity10692 : scanCanonicalize (H12AffineFastState.compose env10692 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10692 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1024,32769,4160,156013,17,41311,8193,65,171281,5393,17664,32040,1364,169264,256,21793,46093,513]

theorem envBound10693 : H12AffineFastState.Bounded env10693 := by
  intro p hp
  have h : env10693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10692_10693 : H12AffineEnvironment.transform 15 8203 env10692 = env10693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10692 == env10693) = true)

theorem identity10693 : scanCanonicalize (H12AffineFastState.compose env10693 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound10693 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10694 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,64808,1024,32769,4160,8572,17,41311,8193,65,56576,5393,17664,32040,1364,54561,256,21793,46093,513]

theorem envBound10694 : H12AffineFastState.Bounded env10694 := by
  intro p hp
  have h : env10694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10693_10694 : H12AffineEnvironment.transform 16 16401 env10693 = env10694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env10693 == env10694) = true)

theorem identity10694 : scanCanonicalize (H12AffineFastState.compose env10694 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound10694 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10695 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,23668,1024,8541,4160,8572,17,3,8193,65,31836,5393,17664,32040,1364,29821,256,21793,5457,513]

theorem envBound10695 : H12AffineFastState.Bounded env10695 := by
  intro p hp
  have h : env10695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10694_10695 : H12AffineEnvironment.transform 14 8540 env10694 = env10695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env10694 == env10695) = true)

theorem identity10695 : scanCanonicalize (H12AffineFastState.compose env10695 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10695 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10696 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,8203,16401,23589,1024,8460,4113,8493,17,3,8193,16,31757,5393,17664,32040,1285,29740,256,21793,5376,513]

theorem envBound10696 : H12AffineFastState.Bounded env10696 := by
  intro p hp
  have h : env10696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10695_10696 : H12AffineEnvironment.transform 5 17 env10695 = env10696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10695 == env10696) = true)

theorem identity10696 : scanCanonicalize (H12AffineFastState.compose env10696 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 15132) := by decide +kernel

theorem selectedBound10696 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env10697 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,15132,8461,8203,15117,10041,1024,8460,4113,8493,17,3,8193,16,1809,5393,15900,1588,1285,3888,256,11837,5376,513]

theorem envBound10697 : H12AffineFastState.Bounded env10697 := by
  intro p hp
  have h : env10697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10696_10697 : H12AffineEnvironment.transform 13 15132 env10696 = env10697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15132 env10696 == env10697) = true)

def env10698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,4194304,16,98781,8328,65,4259060,5392,17664,32041,1500,4256860,256,21793,46212,74251]

theorem envBound10698 : H12AffineFastState.Bounded env10698 := by
  intro p hp
  have h : env10698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10674_10698 : H12AffineEnvironment.transform 20 4161 env10674 = env10698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env10674 == env10698) = true)

theorem identity10698 : scanCanonicalize (H12AffineFastState.compose env10698 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound10698 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149997,1024,29909,4161,4194304,16,95497,8328,65,4196384,5392,17664,32041,1500,4194440,256,21793,16464,74251]

theorem envBound10699 : H12AffineFastState.Bounded env10699 := by
  intro p hp
  have h : env10699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10698_10699 : H12AffineEnvironment.transform 14 29908 env10698 = env10699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env10698 == env10699) = true)

def env10700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,138477,1024,8661,4161,4194304,16,73737,8328,65,4196384,5392,4096,10281,1500,4194440,256,33,5456,74251]

theorem envBound10700 : H12AffineFastState.Bounded env10700 := by
  intro p hp
  have h : env10700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10699_10700 : H12AffineEnvironment.transform 13 5376 env10699 = env10700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10699 == env10700) = true)

theorem identity10700 : scanCanonicalize (H12AffineFastState.compose env10700 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound10700 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,70726,67755,1024,8661,4161,4194304,16,73737,8328,65,4196384,5392,4096,10281,1500,4194440,256,33,5456,74251]

theorem envBound10701 : H12AffineFastState.Bounded env10701 := by
  intro p hp
  have h : env10701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10700_10701 : H12AffineEnvironment.transform 16 70726 env10700 = env10701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env10700 == env10701) = true)

theorem identity10701 : scanCanonicalize (H12AffineFastState.compose env10701 (packedSelected [0,1,3,4,7,8,9,11,15,18,19,20,23,24] rootPS)) = affineNative (2^(21+1) ^^^ 8613) := by decide +kernel

theorem selectedBound10701 : packedSelected [0,1,3,4,7,8,9,11,15,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env10702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,70726,67755,1024,8661,4161,8613,16,73737,8328,65,10629,5392,4096,10281,1500,8493,256,33,5456,74251]

theorem envBound10702 : H12AffineFastState.Bounded env10702 := by
  intro p hp
  have h : env10702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10701_10702 : H12AffineEnvironment.transform 21 8613 env10701 = env10702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8613 env10701 == env10702) = true)

theorem identity10702 : scanCanonicalize (H12AffineFastState.compose env10702 (packedSelected [3,5,9,12,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound10702 : packedSelected [3,5,9,12,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env10703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,479,5529,2420,1024,8661,4161,8613,16,8662,8328,65,10629,5392,4096,10281,1500,8493,256,33,5456,9172]

theorem envBound10703 : H12AffineFastState.Bounded env10703 := by
  intro p hp
  have h : env10703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10702_10703 : H12AffineEnvironment.transform 15 479 env10702 = env10703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env10702 == env10703) = true)

theorem identity10703 : scanCanonicalize (H12AffineFastState.compose env10703 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10703 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10704 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,342,5392,2420,1024,8540,4161,8492,16,8543,8193,65,10508,5392,4096,10281,1365,8493,256,33,5456,9053]

theorem envBound10704 : H12AffineFastState.Bounded env10704 := by
  intro p hp
  have h : env10704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10703_10704 : H12AffineEnvironment.transform 6 9 env10703 = env10704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10703 == env10704) = true)

theorem identity10704 : scanCanonicalize (H12AffineFastState.compose env10704 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10704 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env10705 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,5392,2420,1024,1,4161,113,16,2,348,65,2129,5392,4096,2420,1365,112,256,33,5456,512]

theorem envBound10705 : H12AffineFastState.Bounded env10705 := by
  intro p hp
  have h : env10705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10704_10705 : H12AffineEnvironment.transform 12 349 env10704 = env10705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10704 == env10705) = true)

theorem identity10705 : scanCanonicalize (H12AffineFastState.compose env10705 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound10705 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10706 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,301,5376,0,294,5392,2308,1024,1,4145,1,16,2,300,49,2081,5392,4096,2308,1317,0,256,33,5408,512]

theorem envBound10706 : H12AffineFastState.Bounded env10706 := by
  intro p hp
  have h : env10706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10705_10706 : H12AffineEnvironment.transform 5 48 env10705 = env10706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env10705 == env10706) = true)

theorem identity10706 : scanCanonicalize (H12AffineFastState.compose env10706 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound10706 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env10707 : List Nat := [2,4,8,16,32,48,9,256,512,1024,1076,4096,301,5376,0,294,5392,1328,1024,1,4145,1,16,2,300,49,1045,5392,4096,1328,1317,0,256,33,5408,512]

theorem envBound10707 : H12AffineFastState.Bounded env10707 := by
  intro p hp
  have h : env10707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10706_10707 : H12AffineEnvironment.transform 10 1076 env10706 = env10707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env10706 == env10707) = true)

theorem identity10707 : scanCanonicalize (H12AffineFastState.compose env10707 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound10707 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env10708 : List Nat := [2,4,8,16,32,48,9,256,512,1024,1076,1061,301,293,0,294,309,1328,1024,1,1044,1,16,2,300,49,1045,309,1061,1328,1317,0,256,33,261,512]

theorem envBound10708 : H12AffineFastState.Bounded env10708 := by
  intro p hp
  have h : env10708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10707_10708 : H12AffineEnvironment.transform 11 1061 env10707 = env10708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env10707 == env10708) = true)

theorem identity10708 : scanCanonicalize (H12AffineFastState.compose env10708 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound10708 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env10709 : List Nat := [2,4,8,16,32,48,9,5,512,1024,1076,1061,40,32,0,35,48,1077,1024,1,1044,1,16,2,41,49,1045,48,1061,1077,1056,0,5,33,0,512]

theorem envBound10709 : H12AffineFastState.Bounded env10709 := by
  intro p hp
  have h : env10709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10708_10709 : H12AffineEnvironment.transform 7 5 env10708 = env10709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env10708 == env10709) = true)

theorem identity10709 : scanCanonicalize (H12AffineFastState.compose env10709 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound10709 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10710 : List Nat := [2,4,8,16,32,48,9,5,1,1024,1076,1061,40,32,0,35,48,1077,1024,1,1044,1,16,2,41,49,1045,48,1061,1077,1056,0,5,33,0,1]

theorem envBound10710 : H12AffineFastState.Bounded env10710 := by
  intro p hp
  have h : env10710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10709_10710 : H12AffineEnvironment.transform 8 1 env10709 = env10710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env10709 == env10710) = true)

theorem identity10710 : scanCanonicalize (H12AffineFastState.compose env10710 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10710 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10711 : List Nat := [2,4,8,16,1,17,9,5,1,1024,1045,1028,9,1,0,2,17,1044,1024,1,1044,1,16,2,8,16,1045,17,1028,1044,1025,0,5,0,0,1]

theorem envBound10711 : H12AffineFastState.Bounded env10711 := by
  intro p hp
  have h : env10711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10710_10711 : H12AffineEnvironment.transform 4 1 env10710 = env10711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10710 == env10711) = true)

theorem identity10711 : scanCanonicalize (H12AffineFastState.compose env10711 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound10711 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10712 : List Nat := [2,4,8,16,1,17,9,5,1,20,1,16,9,1,0,2,17,0,20,1,0,1,16,2,8,16,1,17,16,0,21,0,5,0,0,1]

theorem envBound10712 : H12AffineFastState.Bounded env10712 := by
  intro p hp
  have h : env10712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10711_10712 : H12AffineEnvironment.transform 9 20 env10711 = env10712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env10711 == env10712) = true)

theorem identity10712 : scanCanonicalize (H12AffineFastState.compose env10712 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound10712 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10713 : List Nat := [2,4,8,15,1,14,9,5,1,11,1,15,9,1,0,2,14,0,11,1,0,1,15,2,8,15,1,14,15,0,10,0,5,0,0,1]

theorem envBound10713 : H12AffineFastState.Bounded env10713 := by
  intro p hp
  have h : env10713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10712_10713 : H12AffineEnvironment.transform 3 15 env10712 = env10713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env10712 == env10713) = true)

theorem identity10713 : scanCanonicalize (H12AffineFastState.compose env10713 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound10713 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10714 : List Nat := [2,4,7,0,1,1,6,5,1,4,1,0,6,1,0,2,1,0,4,1,0,1,0,2,7,0,1,1,0,0,5,0,5,0,0,1]

theorem envBound10714 : H12AffineFastState.Bounded env10714 := by
  intro p hp
  have h : env10714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10713_10714 : H12AffineEnvironment.transform 2 7 env10713 = env10714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env10713 == env10714) = true)

def env10715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,138476,1024,8660,4161,4194304,16,73736,8328,65,4196384,5392,4097,10280,1500,4194440,256,32,5457,74251]

theorem envBound10715 : H12AffineFastState.Bounded env10715 := by
  intro p hp
  have h : env10715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10699_10715 : H12AffineEnvironment.transform 13 5377 env10699 = env10715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10699 == env10715) = true)

theorem identity10715 : scanCanonicalize (H12AffineFastState.compose env10715 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound10715 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,70862,67618,1024,8660,4161,4194304,16,73736,8328,65,4196384,5392,4097,10280,1500,4194440,256,32,5457,74251]

theorem envBound10716 : H12AffineFastState.Bounded env10716 := by
  intro p hp
  have h : env10716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10715_10716 : H12AffineEnvironment.transform 16 70862 env10715 = env10716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env10715 == env10716) = true)

theorem identity10716 : scanCanonicalize (H12AffineFastState.compose env10716 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound10716 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,13508,10280,1024,8660,4161,4194304,16,2,8328,65,4196384,5392,4097,10280,1500,4194440,256,32,5457,513]

theorem envBound10717 : H12AffineFastState.Bounded env10717 := by
  intro p hp
  have h : env10717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10716_10717 : H12AffineEnvironment.transform 15 8202 env10716 = env10717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env10716 == env10717) = true)

theorem identity10717 : scanCanonicalize (H12AffineFastState.compose env10717 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8613) := by decide +kernel

theorem selectedBound10717 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,13508,10280,1024,8660,4161,8613,16,2,8328,65,10629,5392,4097,10280,1500,8493,256,32,5457,513]

theorem envBound10718 : H12AffineFastState.Bounded env10718 := by
  intro p hp
  have h : env10718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10717_10718 : H12AffineEnvironment.transform 21 8613 env10717 = env10718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8613 env10717 == env10718) = true)

theorem identity10718 : scanCanonicalize (H12AffineFastState.compose env10718 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10718 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env10719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,13388,10280,1024,8540,4161,8493,16,2,8192,65,10509,5392,4097,10280,1364,8493,256,32,5457,513]

theorem envBound10719 : H12AffineFastState.Bounded env10719 := by
  intro p hp
  have h : env10719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10718_10719 : H12AffineEnvironment.transform 6 8 env10718 = env10719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10718 == env10719) = true)

theorem identity10719 : scanCanonicalize (H12AffineFastState.compose env10719 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound10719 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env10720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1280,8192,1,8541,8202,8524,10280,1024,8540,1345,8493,16,2,8192,65,10509,16,1281,10280,1364,8493,256,32,81,513]

theorem envBound10720 : H12AffineFastState.Bounded env10720 := by
  intro p hp
  have h : env10720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10719_10720 : H12AffineEnvironment.transform 11 1280 env10719 = env10720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env10719 == env10720) = true)

theorem identity10720 : scanCanonicalize (H12AffineFastState.compose env10720 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound10720 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env10721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1280,2088,1,2421,2082,2404,0,1024,2420,1345,2309,16,2,2088,65,293,16,1281,0,1364,2309,256,32,81,513]

theorem envBound10721 : H12AffineFastState.Bounded env10721 := by
  intro p hp
  have h : env10721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10720_10721 : H12AffineEnvironment.transform 12 2088 env10720 = env10721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env10720 == env10721) = true)

theorem identity10721 : scanCanonicalize (H12AffineFastState.compose env10721 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound10721 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10722 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,16,2088,1,2421,2082,2404,0,272,2420,81,2309,16,2,2088,65,293,16,17,0,68,2309,256,32,81,513]

theorem envBound10722 : H12AffineFastState.Bounded env10722 := by
  intro p hp
  have h : env10722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10721_10722 : H12AffineEnvironment.transform 9 272 env10721 = env10722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env10721 == env10722) = true)

def env10723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534760,474341,8328,65,6705549,2537577,456761,2125160,2102684,6707493,256,21792,46213,2175563]

theorem envBound10723 : H12AffineFastState.Bounded env10723 := by
  intro p hp
  have h : env10723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10631_10723 : H12AffineEnvironment.transform 23 474341 env10631 = env10723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474341 env10631 == env10723) = true)

def env10724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,2097152,4194304,2101328,98781,8328,65,6352053,2098513,17665,2125160,2102684,6349853,256,21792,46213,2175563]

theorem envBound10724 : H12AffineFastState.Bounded env10724 := by
  intro p hp
  have h : env10724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10723_10724 : H12AffineEnvironment.transform 17 179512 env10723 = env10724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env10723 == env10724) = true)

def env10725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,4194304,16,98781,8328,65,4259061,5393,17665,32040,1500,4256861,256,21792,46213,74251]

theorem envBound10725 : H12AffineFastState.Bounded env10725 := by
  intro p hp
  have h : env10725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10724_10725 : H12AffineEnvironment.transform 20 4160 env10724 = env10725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10724 == env10725) = true)

theorem identity10725 : scanCanonicalize (H12AffineFastState.compose env10725 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound10725 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,179512,1024,32769,4160,4194304,16,21762,8328,65,4259061,5393,17665,32040,1500,4256861,256,21792,46213,63188]

theorem envBound10726 : H12AffineFastState.Bounded env10726 := by
  intro p hp
  have h : env10726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10725_10726 : H12AffineEnvironment.transform 15 54495 env10725 = env10726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env10725 == env10726) = true)

def env10727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179512,1024,32769,4160,4194304,16,21762,8192,65,4258941,5393,17665,32040,1364,4256861,256,21792,46093,63068]

theorem envBound10727 : H12AffineFastState.Bounded env10727 := by
  intro p hp
  have h : env10727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10726_10727 : H12AffineEnvironment.transform 6 8 env10726 = env10727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10726 == env10727) = true)

theorem identity10727 : scanCanonicalize (H12AffineFastState.compose env10727 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound10727 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10728 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,32040,1024,32769,4160,4194304,16,21762,8192,65,4258941,5393,17665,32040,1364,4256861,256,21792,46093,63068]

theorem envBound10728 : H12AffineFastState.Bounded env10728 := by
  intro p hp
  have h : env10728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10727_10728 : H12AffineEnvironment.transform 16 49168 env10727 = env10728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env10727 == env10728) = true)

theorem identity10728 : scanCanonicalize (H12AffineFastState.compose env10728 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 32800) := by decide +kernel

theorem selectedBound10728 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env10729 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,32040,1024,32769,4160,32800,16,21762,8192,65,31837,5393,17665,32040,1364,29821,256,21792,46093,63068]

theorem envBound10729 : H12AffineFastState.Bounded env10729 := by
  intro p hp
  have h : env10729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10728_10729 : H12AffineEnvironment.transform 21 32800 env10728 = env10729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32800 env10728 == env10729) = true)

theorem identity10729 : scanCanonicalize (H12AffineFastState.compose env10729 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound10729 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env10730 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,342,5393,32040,1024,21760,4160,21793,16,21762,8192,65,31837,5393,17665,32040,1364,29821,256,21792,24844,9053]

theorem envBound10730 : H12AffineFastState.Bounded env10730 := by
  intro p hp
  have h : env10730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10729_10730 : H12AffineEnvironment.transform 14 21761 env10729 = env10730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env10729 == env10730) = true)

theorem identity10730 : scanCanonicalize (H12AffineFastState.compose env10730 (packedSelected [3,4,5,6,9,10,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound10730 : packedSelected [3,4,5,6,9,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env10731 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,8192,16384,21589,2,5189,31868,1024,21588,4160,21621,16,21590,8192,65,31837,5189,17493,31868,1024,29821,84,21620,24664,8713]

theorem envBound10731 : H12AffineFastState.Bounded env10731 := by
  intro p hp
  have h : env10731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10730_10731 : H12AffineEnvironment.transform 7 84 env10730 = env10731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env10730 == env10731) = true)

theorem identity10731 : scanCanonicalize (H12AffineFastState.compose env10731 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13437) := by decide +kernel

theorem selectedBound10731 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env10732 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,8192,13437,8232,2,5189,2049,1024,8233,4160,8200,16,8235,8192,65,2080,5189,12328,2049,1024,0,84,8201,5157,8713]

theorem envBound10732 : H12AffineFastState.Bounded env10732 := by
  intro p hp
  have h : env10732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10731_10732 : H12AffineEnvironment.transform 13 13437 env10731 = env10732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13437 env10731 == env10732) = true)

theorem identity10732 : scanCanonicalize (H12AffineFastState.compose env10732 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound10732 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env10733 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,9,5236,33,2,5189,2049,1024,32,4160,1,16,34,9,65,2080,5189,4129,2049,1024,0,84,0,5157,512]

theorem envBound10733 : H12AffineFastState.Bounded env10733 := by
  intro p hp
  have h : env10733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10732_10733 : H12AffineEnvironment.transform 12 9 env10732 = env10733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env10732 == env10733) = true)

theorem identity10733 : scanCanonicalize (H12AffineFastState.compose env10733 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10733 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10734 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,9,5205,0,2,5189,2049,1024,1,4160,1,16,3,9,65,2049,5189,4096,2049,1024,0,84,0,5124,512]

theorem envBound10734 : H12AffineFastState.Bounded env10734 := by
  intro p hp
  have h : env10734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10733_10734 : H12AffineEnvironment.transform 4 1 env10733 = env10734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10733 == env10734) = true)

theorem identity10734 : scanCanonicalize (H12AffineFastState.compose env10734 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound10734 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10735 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,16,9,1093,0,2,1109,2049,1024,1,80,1,16,3,9,65,2049,1109,16,2049,1024,0,84,0,1044,512]

theorem envBound10735 : H12AffineFastState.Bounded env10735 := by
  intro p hp
  have h : env10735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10734_10735 : H12AffineEnvironment.transform 11 16 env10734 = env10735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env10734 == env10735) = true)

theorem identity10735 : scanCanonicalize (H12AffineFastState.compose env10735 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound10735 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env10736 : List Nat := [2,4,8,16,1,64,8,84,512,5,2048,16,9,64,0,2,80,2049,5,1,80,1,16,3,9,65,2049,80,16,2049,5,0,84,0,17,512]

theorem envBound10736 : H12AffineFastState.Bounded env10736 := by
  intro p hp
  have h : env10736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10735_10736 : H12AffineEnvironment.transform 9 5 env10735 = env10736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env10735 == env10736) = true)

theorem identity10736 : scanCanonicalize (H12AffineFastState.compose env10736 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound10736 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10737 : List Nat := [2,4,8,16,1,64,8,84,512,5,64,16,9,64,0,2,80,65,5,1,80,1,16,3,9,65,65,80,16,65,5,0,84,0,17,512]

theorem envBound10737 : H12AffineFastState.Bounded env10737 := by
  intro p hp
  have h : env10737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10736_10737 : H12AffineEnvironment.transform 10 64 env10736 = env10737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env10736 == env10737) = true)

theorem identity10737 : scanCanonicalize (H12AffineFastState.compose env10737 (packedSelected [0,1,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10737 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env10738 : List Nat := [2,4,8,16,1,16,8,4,512,5,16,16,9,16,0,2,0,17,5,1,0,1,16,3,9,17,17,0,16,17,5,0,4,0,17,512]

theorem envBound10738 : H12AffineFastState.Bounded env10738 := by
  intro p hp
  have h : env10738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10737_10738 : H12AffineEnvironment.transform 5 16 env10737 = env10738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10737 == env10738) = true)

theorem identity10738 : scanCanonicalize (H12AffineFastState.compose env10738 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10738 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env10739 : List Nat := [2,4,8,1,1,1,8,4,512,5,1,1,9,1,0,2,0,0,5,1,0,1,1,3,9,0,0,0,1,0,5,0,4,0,0,512]

theorem envBound10739 : H12AffineFastState.Bounded env10739 := by
  intro p hp
  have h : env10739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10738_10739 : H12AffineEnvironment.transform 3 1 env10738 = env10739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10738 == env10739) = true)

theorem identity10739 : scanCanonicalize (H12AffineFastState.compose env10739 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound10739 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10740 : List Nat := [2,4,8,1,1,1,8,4,14,5,1,1,9,1,0,2,0,0,5,1,0,1,1,3,9,0,0,0,1,0,5,0,4,0,0,14]

theorem envBound10740 : H12AffineFastState.Bounded env10740 := by
  intro p hp
  have h : env10740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1