import H12CloudChart1Data026

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans6691_6692 : H12AffineEnvironment.transform 17 2341 env6691 = env6692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env6691 == env6692) = true)

theorem identity6692 : scanCanonicalize (H12AffineFastState.compose env6692 (packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1840) := by decide +kernel

theorem selectedBound6692 : packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env6693 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,1840,8613,8714,1045,2341,1025,8613,1464,32,445,398,8329,444,2696,1840,1693,2729,1569,908,257,648,1213,512]

theorem envBound6693 : H12AffineFastState.Bounded env6693 := by
  intro p hp
  have h : env6693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6692_6693 : H12AffineEnvironment.transform 13 1840 env6692 = env6693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1840 env6692 == env6693) = true)

theorem identity6693 : scanCanonicalize (H12AffineFastState.compose env6693 (packedSelected [0,1,3,4,7,9,12,13,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6693 : packedSelected [0,1,3,4,7,9,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env6694 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1045,8192,1692,8201,8714,1045,2185,1025,8201,1044,32,17,34,8329,16,2696,1692,1693,2729,1569,544,173,648,1213,512]

theorem envBound6694 : H12AffineFastState.Bounded env6694 := by
  intro p hp
  have h : env6694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6693_6694 : H12AffineEnvironment.transform 7 172 env6693 = env6694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6693 == env6694) = true)

theorem identity6694 : scanCanonicalize (H12AffineFastState.compose env6694 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound6694 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6695 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1703,1045,8192,1692,8201,8714,1045,1582,1025,8201,1044,32,17,34,8329,16,1071,1692,1693,1038,1569,544,173,648,1213,512]

theorem envBound6695 : H12AffineFastState.Bounded env6695 := by
  intro p hp
  have h : env6695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6694_6695 : H12AffineEnvironment.transform 10 1703 env6694 = env6695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env6694 == env6695) = true)

theorem identity6695 : scanCanonicalize (H12AffineFastState.compose env6695 (packedSelected [2,3,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1710) := by decide +kernel

theorem selectedBound6695 : packedSelected [2,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env6696 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1703,1045,1710,1692,1703,1188,1045,1582,1025,1703,1044,32,17,34,1575,16,1071,1692,1693,1038,1569,544,173,648,1213,512]

theorem envBound6696 : H12AffineFastState.Bounded env6696 := by
  intro p hp
  have h : env6696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6695_6696 : H12AffineEnvironment.transform 12 1710 env6695 = env6696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1710 env6695 == env6696) = true)

theorem identity6696 : scanCanonicalize (H12AffineFastState.compose env6696 (packedSelected [2,3] rootPS)) = affineNative (2^(9+1) ^^^ 647) := by decide +kernel

theorem selectedBound6696 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env6697 : List Nat := [2,4,8,16,32,17,128,172,512,647,32,658,41,27,32,547,658,169,646,32,659,32,17,34,160,16,680,27,26,649,166,544,173,648,570,512]

theorem envBound6697 : H12AffineFastState.Bounded env6697 := by
  intro p hp
  have h : env6697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6696_6697 : H12AffineEnvironment.transform 9 647 env6696 = env6697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 647 env6696 == env6697) = true)

theorem identity6697 : scanCanonicalize (H12AffineFastState.compose env6697 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound6697 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env6698 : List Nat := [2,4,8,16,32,17,19,63,512,532,32,513,41,27,32,547,513,58,533,32,512,32,17,34,51,16,571,27,26,538,53,544,62,539,570,512]

theorem envBound6698 : H12AffineFastState.Bounded env6698 := by
  intro p hp
  have h : env6698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6697_6698 : H12AffineEnvironment.transform 6 19 env6697 = env6698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env6697 == env6698) = true)

theorem identity6698 : scanCanonicalize (H12AffineFastState.compose env6698 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound6698 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6699 : List Nat := [2,4,8,16,32,17,19,63,0,20,32,1,41,27,32,35,1,58,21,32,0,32,17,34,51,16,59,27,26,26,53,32,62,27,58,0]

theorem envBound6699 : H12AffineFastState.Bounded env6699 := by
  intro p hp
  have h : env6699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6698_6699 : H12AffineEnvironment.transform 8 0 env6698 = env6699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env6698 == env6699) = true)

theorem identity6699 : scanCanonicalize (H12AffineFastState.compose env6699 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound6699 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6700 : List Nat := [2,4,8,16,27,17,19,4,0,20,27,1,18,27,27,24,1,1,21,27,0,27,17,25,8,16,0,27,26,26,14,27,5,27,1,0]

theorem envBound6700 : H12AffineFastState.Bounded env6700 := by
  intro p hp
  have h : env6700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6699_6700 : H12AffineEnvironment.transform 4 27 env6699 = env6700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env6699 == env6700) = true)

theorem identity6700 : scanCanonicalize (H12AffineFastState.compose env6700 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound6700 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6701 : List Nat := [2,4,8,11,0,10,8,4,0,15,0,1,9,0,0,3,1,1,14,0,0,0,10,2,8,11,0,0,1,1,14,0,5,0,1,0]

theorem envBound6701 : H12AffineFastState.Bounded env6701 := by
  intro p hp
  have h : env6701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6700_6701 : H12AffineEnvironment.transform 3 11 env6700 = env6701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env6700 == env6701) = true)

def env6702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,2147483648,3343452565,525568,1107306665,34359738368,59279183]

theorem envBound6702 : H12AffineFastState.Bounded env6702 := by
  intro p hp
  have h : env6702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4_6702 : H12AffineEnvironment.transform 31 3343452565 env4 = env6702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3343452565 env4 == env6702) = true)

def env6703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,2147483648,3309906205,525568,1073743905,34359738368,25733063]

theorem envBound6703 : H12AffineFastState.Bounded env6703 := by
  intro p hp
  have h : env6703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6702_6703 : H12AffineEnvironment.transform 24 8328 env6702 = env6703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env6702 == env6703) = true)

theorem identity6703 : scanCanonicalize (H12AffineFastState.compose env6703 (packedSelected [6,25] rootPS)) = affineNative (2^(30+1) ^^^ 92374097) := by decide +kernel

theorem selectedBound6703 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env6704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,92374097,1086893388,525568,1073743905,34359738368,25733063]

theorem envBound6704 : H12AffineFastState.Bounded env6704 := by
  intro p hp
  have h : env6704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6703_6704 : H12AffineEnvironment.transform 30 92374097 env6703 = env6704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 30 92374097 env6703 == env6704) = true)

def env6705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,268570624,1073741824,92374097,1086893388,525568,1073743905,34359738368,25733063]

theorem envBound6705 : H12AffineFastState.Bounded env6705 := by
  intro p hp
  have h : env6705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6704_6705 : H12AffineEnvironment.transform 28 268570624 env6704 = env6705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570624 env6704 == env6705) = true)

theorem identity6705 : scanCanonicalize (H12AffineFastState.compose env6705 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(26+1) ^^^ 25994574) := by decide +kernel

theorem selectedBound6705 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env6706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,25994574,268435456,268570624,1073741824,92374097,1086893388,525568,1073743905,34359738368,25733063]

theorem envBound6706 : H12AffineFastState.Bounded env6706 := by
  intro p hp
  have h : env6706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6705_6706 : H12AffineEnvironment.transform 26 25994574 env6705 = env6706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 25994574 env6705 == env6706) = true)

def env6707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988132,8328,67108864,360618,268435456,268570624,1073741824,67674549,1086893388,525568,1073743905,34359738368,98851]

theorem envBound6707 : H12AffineFastState.Bounded env6707 := by
  intro p hp
  have h : env6707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6706_6707 : H12AffineEnvironment.transform 23 8988132 env6706 = env6707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8988132 env6706 == env6707) = true)

theorem identity6707 : scanCanonicalize (H12AffineFastState.compose env6707 (packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(29+1) ^^^ 13208934) := by decide +kernel

theorem selectedBound6707 : packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env6708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988132,8328,67108864,360618,268435456,268570624,13208934,67674549,73770,525568,13206855,34359738368,98851]

theorem envBound6708 : H12AffineFastState.Bounded env6708 := by
  intro p hp
  have h : env6708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6707_6708 : H12AffineEnvironment.transform 29 13208934 env6707 = env6708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 13208934 env6707 == env6708) = true)

def env6709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988132,8328,67108864,360618,77615104,77742080,13208934,67674549,73770,525568,13206855,34359738368,98851]

theorem envBound6709 : H12AffineFastState.Bounded env6709 := by
  intro p hp
  have h : env6709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6708_6709 : H12AffineEnvironment.transform 27 77615104 env6708 = env6709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 77615104 env6708 == env6709) = true)

theorem identity6709 : scanCanonicalize (H12AffineFastState.compose env6709 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(25+1) ^^^ 566497) := by decide +kernel

theorem selectedBound6709 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988132,8328,566497,360618,11072737,11199713,13208934,1364,73770,525568,13206855,34359738368,98851]

theorem envBound6710 : H12AffineFastState.Bounded env6710 := by
  intro p hp
  have h : env6710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6709_6710 : H12AffineEnvironment.transform 25 566497 env6709 = env6710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 566497 env6709 == env6710) = true)

def env6711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,4194304,8388608,8988132,8328,525377,335882,11031617,11158593,13184454,1364,73770,525568,13182439,34359738368,74371]

theorem envBound6711 : H12AffineFastState.Bounded env6711 := by
  intro p hp
  have h : env6711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6710_6711 : H12AffineEnvironment.transform 14 8352 env6710 = env6711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env6710 == env6711) = true)

def env6712 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,4194304,8388608,8987672,8328,525377,335882,11031617,11158593,13184058,1192,73770,525564,13181979,34359738368,74371]

theorem envBound6712 : H12AffineFastState.Bounded env6712 := by
  intro p hp
  have h : env6712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6711_6712 : H12AffineEnvironment.transform 7 252 env6711 = env6712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env6711 == env6712) = true)

theorem identity6712 : scanCanonicalize (H12AffineFastState.compose env6712 (packedSelected [3,7,10,13,20,21,24,26,27,35] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound6712 : packedSelected [3,7,10,13,20,21,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env6713 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,73891,8388608,8987672,8328,525377,335882,11031617,11158593,8916121,1192,73770,525564,8914104,34359738368,74371]

theorem envBound6713 : H12AffineFastState.Bounded env6713 := by
  intro p hp
  have h : env6713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6712_6713 : H12AffineEnvironment.transform 21 73891 env6712 = env6713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env6712 == env6713) = true)

def env6714 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,4328,8352,65536,131072,262144,524288,8352,2097152,73891,8388608,8987672,8328,525377,335882,11011241,11146409,8916121,1192,73770,525564,8914104,34359738368,74371]

theorem envBound6714 : H12AffineFastState.Bounded env6714 := by
  intro p hp
  have h : env6714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6713_6714 : H12AffineEnvironment.transform 13 4328 env6713 = env6714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4328 env6713 == env6714) = true)

theorem identity6714 : scanCanonicalize (H12AffineFastState.compose env6714 (packedSelected [3,5,7,9,10,13,20,21,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound6714 : packedSelected [3,5,7,9,10,13,20,21,22,27] rootPS < 2^1333 := by decide +kernel

def env6715 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,4328,8352,65536,70863,262144,524288,8352,2097152,73891,8388608,8987672,8328,525377,335882,11011241,11075686,8916121,1192,73770,525564,8914104,34359738368,74371]

theorem envBound6715 : H12AffineFastState.Bounded env6715 := by
  intro p hp
  have h : env6715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6714_6715 : H12AffineEnvironment.transform 16 70863 env6714 = env6715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env6714 == env6715) = true)

def env6716 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4248,8352,65536,70847,262144,524288,8352,2097152,73891,8388608,8987672,8328,525361,335882,11011241,11075606,8916121,1192,73770,525452,8914104,34359738368,74371]

theorem envBound6716 : H12AffineFastState.Bounded env6716 := by
  intro p hp
  have h : env6716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6715_6716 : H12AffineEnvironment.transform 5 48 env6715 = env6716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env6715 == env6716) = true)

theorem identity6716 : scanCanonicalize (H12AffineFastState.compose env6716 (packedSelected [0,1,2,3,4,6,7,9,14,21,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound6716 : packedSelected [0,1,2,3,4,6,7,9,14,21,24,28] rootPS < 2^1333 := by decide +kernel

def env6717 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4248,8352,35,5276,262144,524288,8352,2097152,8320,8388608,8922171,8328,525361,270377,11011241,11010101,8916121,1192,8201,525452,8914104,34359738368,8864]

theorem envBound6717 : H12AffineFastState.Bounded env6717 := by
  intro p hp
  have h : env6717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6716_6717 : H12AffineEnvironment.transform 15 35 env6716 = env6717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env6716 == env6717) = true)

def env6718 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4248,8352,35,5276,262144,524288,8352,2097152,8320,533680,139,8328,525361,270377,2105369,2106501,10281,1192,8201,525452,8200,34359738368,8864]

theorem envBound6718 : H12AffineFastState.Bounded env6718 := by
  intro p hp
  have h : env6718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6717_6718 : H12AffineEnvironment.transform 22 533680 env6717 = env6718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 533680 env6717 == env6718) = true)

theorem identity6718 : scanCanonicalize (H12AffineFastState.compose env6718 (packedSelected [6,12,13,14,15] rootPS)) = affineNative (2^(34+1) ^^^ 2894005) := by decide +kernel

theorem selectedBound6718 : packedSelected [6,12,13,14,15] rootPS < 2^1333 := by decide +kernel

def env6719 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4248,8352,35,5276,262144,524288,8352,2097152,8320,533680,139,8328,525361,270377,2105369,2106501,10281,1192,8201,525452,8200,2894005,8864]

theorem envBound6719 : H12AffineFastState.Bounded env6719 := by
  intro p hp
  have h : env6719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6718_6719 : H12AffineEnvironment.transform 34 2894005 env6718 = env6719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 2894005 env6718 == env6719) = true)

theorem identity6719 : scanCanonicalize (H12AffineFastState.compose env6719 (packedSelected [0,2,4,6,7,9,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound6719 : packedSelected [0,2,4,6,7,9,13,14] rootPS < 2^1333 := by decide +kernel

def env6720 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4248,8352,35,5276,2184,524288,8352,2097152,8320,533680,139,8328,525361,10401,2105369,2106501,10281,1192,8201,525452,8200,2629693,8864]

theorem envBound6720 : H12AffineFastState.Bounded env6720 := by
  intro p hp
  have h : env6720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6719_6720 : H12AffineEnvironment.transform 17 2184 env6719 = env6720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env6719 == env6720) = true)

theorem identity6720 : scanCanonicalize (H12AffineFastState.compose env6720 (packedSelected [2,3,5,6,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound6720 : packedSelected [2,3,5,6,10,11,18] rootPS < 2^1333 := by decide +kernel

def env6721 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,160,4248,0,35,5276,2184,524288,0,2097152,32,525328,139,40,525361,2049,2097337,2098213,2185,1192,169,525452,168,2621597,512]

theorem envBound6721 : H12AffineFastState.Bounded env6721 := by
  intro p hp
  have h : env6721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6720_6721 : H12AffineEnvironment.transform 12 160 env6720 = env6721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env6720 == env6721) = true)

theorem identity6721 : scanCanonicalize (H12AffineFastState.compose env6721 (packedSelected [1,3] rootPS)) = affineNative (2^(20+1) ^^^ 5260) := by decide +kernel

theorem selectedBound6721 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6722 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,160,4248,0,35,5276,2184,524288,0,5260,32,525328,139,40,525361,2049,5173,4265,2185,1192,169,525452,168,529425,512]

theorem envBound6722 : H12AffineFastState.Bounded env6722 := by
  intro p hp
  have h : env6722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6721_6722 : H12AffineEnvironment.transform 20 5260 env6721 = env6722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5260 env6721 == env6722) = true)

theorem identity6722 : scanCanonicalize (H12AffineFastState.compose env6722 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6722 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env6723 : List Nat := [2,4,8,16,32,48,41,37,512,1024,2048,4096,9,4145,0,35,5173,2081,524288,0,5157,32,525328,34,40,525361,2049,5173,4096,2080,1025,0,525349,1,529425,512]

theorem envBound6723 : H12AffineFastState.Bounded env6723 := by
  intro p hp
  have h : env6723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6722_6723 : H12AffineEnvironment.transform 6 41 env6722 = env6723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6722 == env6723) = true)

def env6724 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4248,8352,35,5276,262144,524288,8352,2097152,8320,533681,138,8328,525361,270377,2105368,2106500,10280,1192,8201,525452,8201,34359738368,8864]

theorem envBound6724 : H12AffineFastState.Bounded env6724 := by
  intro p hp
  have h : env6724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6717_6724 : H12AffineEnvironment.transform 22 533681 env6717 = env6724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 533681 env6717 == env6724) = true)

theorem identity6724 : scanCanonicalize (H12AffineFastState.compose env6724 (packedSelected [6,12,13,14,15] rootPS)) = affineNative (2^(34+1) ^^^ 2886688) := by decide +kernel

theorem selectedBound6724 : packedSelected [6,12,13,14,15] rootPS < 2^1333 := by decide +kernel

def env6725 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4248,8352,35,5276,262144,524288,8352,2097152,8320,533681,138,8328,525361,270377,2105368,2106500,10280,1192,8201,525452,8201,2886688,8864]

theorem envBound6725 : H12AffineFastState.Bounded env6725 := by
  intro p hp
  have h : env6725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6724_6725 : H12AffineEnvironment.transform 34 2886688 env6724 = env6725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 2886688 env6724 == env6725) = true)

theorem identity6725 : scanCanonicalize (H12AffineFastState.compose env6725 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(20+1) ^^^ 537745) := by decide +kernel

theorem selectedBound6725 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env6726 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4248,8352,35,5276,262144,524288,8352,537745,8320,533681,138,8328,525361,270377,529545,528405,10280,1192,8201,525452,8201,276657,8864]

theorem envBound6726 : H12AffineFastState.Bounded env6726 := by
  intro p hp
  have h : env6726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6725_6726 : H12AffineEnvironment.transform 20 537745 env6725 = env6726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 537745 env6725 == env6726) = true)

theorem identity6726 : scanCanonicalize (H12AffineFastState.compose env6726 (packedSelected [0,2,4,6,7,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound6726 : packedSelected [0,2,4,6,7,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env6727 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8,4248,168,35,5276,262144,524288,168,529561,136,525497,138,128,525361,262177,529545,528405,2080,1192,1,525452,1,268473,680]

theorem envBound6727 : H12AffineFastState.Bounded env6727 := by
  intro p hp
  have h : env6727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6726_6727 : H12AffineEnvironment.transform 12 8 env6726 = env6727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env6726 == env6727) = true)

theorem identity6727 : scanCanonicalize (H12AffineFastState.compose env6727 (packedSelected [3,4,5,6,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 1670) := by decide +kernel

theorem selectedBound6727 : packedSelected [3,4,5,6,7,12] rootPS < 2^1333 := by decide +kernel

def env6728 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,1670,8,1566,168,35,538,262144,524288,168,524831,136,525497,138,128,525361,262177,524815,525971,2080,1192,1,525452,1,265791,680]

theorem envBound6728 : H12AffineFastState.Bounded env6728 := by
  intro p hp
  have h : env6728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6727_6728 : H12AffineEnvironment.transform 11 1670 env6727 = env6728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1670 env6727 == env6728) = true)

theorem identity6728 : scanCanonicalize (H12AffineFastState.compose env6728 (packedSelected [0,2,3,4,5,11,20] rootPS)) = affineNative (2^(18+1) ^^^ 189) := by decide +kernel

theorem selectedBound6728 : packedSelected [0,2,3,4,5,11,20] rootPS < 2^1333 := by decide +kernel

def env6729 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,1670,8,1566,168,35,538,262144,189,168,674,136,1028,138,128,1164,262177,690,1582,2080,1192,1,1073,1,265791,680]

theorem envBound6729 : H12AffineFastState.Bounded env6729 := by
  intro p hp
  have h : env6729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6728_6729 : H12AffineEnvironment.transform 18 189 env6728 = env6729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 189 env6728 == env6729) = true)

theorem identity6729 : scanCanonicalize (H12AffineFastState.compose env6729 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound6729 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env6730 : List Nat := [2,4,8,16,32,48,128,140,512,14,2048,648,8,528,168,35,538,262144,189,168,674,136,10,138,128,130,262177,690,544,2080,166,1,63,1,264753,680]

theorem envBound6730 : H12AffineFastState.Bounded env6730 := by
  intro p hp
  have h : env6730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6729_6730 : H12AffineEnvironment.transform 9 14 env6729 = env6730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env6729 == env6730) = true)

theorem identity6730 : scanCanonicalize (H12AffineFastState.compose env6730 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6730 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6731 : List Nat := [2,4,8,16,32,48,40,36,512,14,2048,544,8,528,0,35,538,262144,21,0,522,32,10,34,40,42,262177,538,544,2080,14,1,63,1,264753,512]

theorem envBound6731 : H12AffineFastState.Bounded env6731 := by
  intro p hp
  have h : env6731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6730_6731 : H12AffineEnvironment.transform 6 40 env6730 = env6731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6730 == env6731) = true)

theorem identity6731 : scanCanonicalize (H12AffineFastState.compose env6731 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound6731 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env6732 : List Nat := [2,4,8,16,26,10,18,30,512,14,2048,538,8,528,0,25,538,262144,21,0,522,26,10,24,18,16,262171,538,538,2074,14,1,5,1,264715,512]

theorem envBound6732 : H12AffineFastState.Bounded env6732 := by
  intro p hp
  have h : env6732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6731_6732 : H12AffineEnvironment.transform 4 26 env6731 = env6732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env6731 == env6732) = true)

theorem identity6732 : scanCanonicalize (H12AffineFastState.compose env6732 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound6732 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env6733 : List Nat := [2,4,8,16,26,10,18,30,512,14,522,538,8,528,0,25,538,262144,21,0,522,26,10,24,18,16,262171,538,538,528,14,1,5,1,262145,512]

theorem envBound6733 : H12AffineFastState.Bounded env6733 := by
  intro p hp
  have h : env6733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6732_6733 : H12AffineEnvironment.transform 10 522 env6732 = env6733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env6732 == env6733) = true)

theorem identity6733 : scanCanonicalize (H12AffineFastState.compose env6733 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound6733 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6734 : List Nat := [2,4,8,16,26,10,18,30,2,14,8,24,8,18,0,25,24,262144,21,0,8,26,10,24,18,16,262171,24,24,18,14,1,5,1,262145,2]

theorem envBound6734 : H12AffineFastState.Bounded env6734 := by
  intro p hp
  have h : env6734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6733_6734 : H12AffineEnvironment.transform 8 2 env6733 = env6734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env6733 == env6734) = true)

def env6735 : List Nat := [2,4,8,0,10,10,2,14,2,14,8,8,8,2,0,9,8,262144,5,0,8,10,10,8,2,0,262155,8,8,2,14,1,5,1,262145,2]

theorem envBound6735 : H12AffineFastState.Bounded env6735 := by
  intro p hp
  have h : env6735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6734_6735 : H12AffineEnvironment.transform 3 0 env6734 = env6735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6734 == env6735) = true)

theorem identity6735 : scanCanonicalize (H12AffineFastState.compose env6735 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6735 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6736 : List Nat := [2,0,8,0,10,10,2,10,2,10,8,8,8,2,0,9,8,262144,1,0,8,10,10,8,2,0,262155,8,8,2,10,1,1,1,262145,2]

theorem envBound6736 : H12AffineFastState.Bounded env6736 := by
  intro p hp
  have h : env6736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6735_6736 : H12AffineEnvironment.transform 1 0 env6735 = env6736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6735 == env6736) = true)

def env6737 : List Nat := [2,0,8,0,10,10,2,10,2,10,8,8,8,2,0,9,8,8,1,0,8,10,10,8,2,0,3,8,8,2,10,1,1,1,9,2]

theorem envBound6737 : H12AffineFastState.Bounded env6737 := by
  intro p hp
  have h : env6737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6736_6737 : H12AffineEnvironment.transform 17 8 env6736 = env6737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8 env6736 == env6737) = true)

def leafEnv6737 : List Nat := [2,0,8,0,10,10,2,10,2,10,8,8,8,2,0,9,8,8,1,0,8,10,10,8,1,2,1,0,3,8,8,2,10,1,1,1,11,3,9,2,1,2,0]

def active6737 : List Nat := [0,2]

def tree6737 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6737 : H12WitnessSearch.Good tree6737 := H12GlobalWitnessIndex.good

theorem leafIdentity6737 : H12AffineFastState.composeSystem env6737 rootObs = leafEnv6737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6737 rootObs == leafEnv6737) = true)

theorem terminalChecked6737 : H12PackedTerminal.terminalCheckFast leafEnv6737 active6737 tree6737 = true := by decide +kernel

def env6738 : List Nat := [2,0,8,0,10,10,2,10,2,10,8,8,8,2,0,9,8,9,1,0,8,10,10,8,2,0,2,8,8,2,10,1,1,1,8,2]

theorem envBound6738 : H12AffineFastState.Bounded env6738 := by
  intro p hp
  have h : env6738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6736_6738 : H12AffineEnvironment.transform 17 9 env6736 = env6738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9 env6736 == env6738) = true)

theorem identity6738 : scanCanonicalize (H12AffineFastState.compose env6738 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6738 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6739 : List Nat := [2,0,2,0,0,0,2,0,2,0,2,2,2,2,0,3,2,3,1,0,2,0,0,2,2,0,2,2,2,2,0,1,1,1,2,2]

theorem envBound6739 : H12AffineFastState.Bounded env6739 := by
  intro p hp
  have h : env6739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6738_6739 : H12AffineEnvironment.transform 2 2 env6738 = env6739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6738 == env6739) = true)

def leafEnv6739 : List Nat := [2,0,2,0,0,0,2,0,2,0,2,2,2,2,0,3,2,3,1,0,2,0,0,2,1,2,1,0,2,2,2,2,0,1,1,1,1,3,2,2,1,3,0]

def active6739 : List Nat := [0]

def tree6739 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6739 : H12WitnessSearch.Good tree6739 := H12GlobalWitnessIndex.good

theorem leafIdentity6739 : H12AffineFastState.composeSystem env6739 rootObs = leafEnv6739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6739 rootObs == leafEnv6739) = true)

theorem terminalChecked6739 : H12PackedTerminal.terminalCheckFast leafEnv6739 active6739 tree6739 = true := by decide +kernel

def env6740 : List Nat := [2,4,8,1,11,10,3,15,2,14,8,9,8,3,0,8,9,262144,4,0,8,11,10,9,3,1,262154,9,9,3,14,1,5,1,262145,2]

theorem envBound6740 : H12AffineFastState.Bounded env6740 := by
  intro p hp
  have h : env6740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6734_6740 : H12AffineEnvironment.transform 3 1 env6734 = env6740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6734 == env6740) = true)

theorem identity6740 : scanCanonicalize (H12AffineFastState.compose env6740 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 6) := by decide +kernel

theorem selectedBound6740 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6741 : List Nat := [2,4,8,1,11,10,3,15,2,14,8,9,8,3,0,8,9,6,4,0,8,11,10,9,3,1,12,9,9,3,14,1,5,1,7,2]

theorem envBound6741 : H12AffineFastState.Bounded env6741 := by
  intro p hp
  have h : env6741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6740_6741 : H12AffineEnvironment.transform 17 6 env6740 = env6741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6 env6740 == env6741) = true)

def env6742 : List Nat := [2,0,8,1,11,10,3,11,2,10,8,9,8,3,0,8,9,2,0,0,8,11,10,9,3,1,8,9,9,3,10,1,1,1,3,2]

theorem envBound6742 : H12AffineFastState.Bounded env6742 := by
  intro p hp
  have h : env6742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6741_6742 : H12AffineEnvironment.transform 1 0 env6741 = env6742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6741 == env6742) = true)

def env6743 : List Nat := [2,1,8,1,11,10,3,10,2,11,8,9,8,3,0,8,9,3,1,0,8,11,10,9,3,1,9,9,9,3,11,1,0,1,2,2]

theorem envBound6743 : H12AffineFastState.Bounded env6743 := by
  intro p hp
  have h : env6743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6741_6743 : H12AffineEnvironment.transform 1 1 env6741 = env6743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6741 == env6743) = true)

theorem identity6743 : scanCanonicalize (H12AffineFastState.compose env6743 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6743 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6744 : List Nat := [2,1,2,1,1,0,3,0,2,1,2,3,2,3,0,2,3,3,1,0,2,1,0,3,3,1,3,3,3,3,1,1,0,1,2,2]

theorem envBound6744 : H12AffineFastState.Bounded env6744 := by
  intro p hp
  have h : env6744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6743_6744 : H12AffineEnvironment.transform 2 2 env6743 = env6744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6743 == env6744) = true)

def leafEnv6744 : List Nat := [2,1,2,1,1,0,3,0,2,1,2,3,2,3,0,2,3,3,1,0,2,1,0,3,1,3,1,1,3,3,3,3,1,1,0,1,1,3,2,2,1,2,0]

def active6744 : List Nat := [0]

def tree6744 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6744 : H12WitnessSearch.Good tree6744 := H12GlobalWitnessIndex.good

theorem leafIdentity6744 : H12AffineFastState.composeSystem env6744 rootObs = leafEnv6744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6744 rootObs == leafEnv6744) = true)

theorem terminalChecked6744 : H12PackedTerminal.terminalCheckFast leafEnv6744 active6744 tree6744 = true := by decide +kernel

def env6745 : List Nat := [2,4,8,16,32,49,128,141,512,1024,2048,4096,8192,4249,8352,65536,70846,262144,524288,8352,2097152,73891,8388608,8987672,8328,525360,335882,11011241,11075607,8916121,1192,73770,525453,8914104,34359738368,74371]

theorem envBound6745 : H12AffineFastState.Bounded env6745 := by
  intro p hp
  have h : env6745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6715_6745 : H12AffineEnvironment.transform 5 49 env6715 = env6745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env6715 == env6745) = true)

theorem identity6745 : scanCanonicalize (H12AffineFastState.compose env6745 (packedSelected [0,1,2,3,4,6,7,9,14,21,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound6745 : packedSelected [0,1,2,3,4,6,7,9,14,21,24,28] rootPS < 2^1333 := by decide +kernel

def env6746 : List Nat := [2,4,8,16,32,49,128,141,512,1024,2048,4096,160,4249,0,65536,70846,262144,524288,0,2097152,65539,8388608,8979640,40,525360,327850,11011241,11075607,8916121,1192,65674,525453,8914104,34359738368,66083]

theorem envBound6746 : H12AffineFastState.Bounded env6746 := by
  intro p hp
  have h : env6746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6745_6746 : H12AffineEnvironment.transform 12 160 env6745 = env6746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env6745 == env6746) = true)

def env6747 : List Nat := [2,4,8,16,32,49,128,141,512,52,2048,4096,160,4249,0,65536,69770,262144,524288,0,2097152,65539,8388608,8978572,40,524292,327850,11010205,11075607,8915117,156,65674,524473,8913036,34359738368,66083]

theorem envBound6747 : H12AffineFastState.Bounded env6747 := by
  intro p hp
  have h : env6747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6746_6747 : H12AffineEnvironment.transform 9 52 env6746 = env6747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env6746 == env6747) = true)

theorem identity6747 : scanCanonicalize (H12AffineFastState.compose env6747 (packedSelected [6,12,13,14,15] rootPS)) = affineNative (2^(34+1) ^^^ 2885652) := by decide +kernel

theorem selectedBound6747 : packedSelected [6,12,13,14,15] rootPS < 2^1333 := by decide +kernel

def env6748 : List Nat := [2,4,8,16,32,49,128,141,512,52,2048,4096,160,4249,0,65536,69770,262144,524288,0,2097152,65539,8388608,8978572,40,524292,327850,11010205,11075607,8915117,156,65674,524473,8913036,2885652,66083]

theorem envBound6748 : H12AffineFastState.Bounded env6748 := by
  intro p hp
  have h : env6748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6747_6748 : H12AffineEnvironment.transform 34 2885652 env6747 = env6748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 2885652 env6747 == env6748) = true)

theorem identity6748 : scanCanonicalize (H12AffineFastState.compose env6748 (packedSelected [4,6,11,13,14,20,22,23] rootPS)) = affineNative (2^(22+1) ^^^ 589830) := by decide +kernel

theorem selectedBound6748 : packedSelected [4,6,11,13,14,20,22,23] rootPS < 2^1333 := by decide +kernel

def env6749 : List Nat := [2,4,8,16,32,49,128,141,512,52,2048,4096,160,4249,0,65536,69770,262144,524288,0,2097152,65539,589830,138,40,524292,327850,2162843,2097169,67755,156,65674,524473,65674,2885652,66083]

theorem envBound6749 : H12AffineFastState.Bounded env6749 := by
  intro p hp
  have h : env6749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6748_6749 : H12AffineEnvironment.transform 22 589830 env6748 = env6749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 589830 env6748 == env6749) = true)

theorem identity6749 : scanCanonicalize (H12AffineFastState.compose env6749 (packedSelected [0,2,4,6,7,9,13,14] rootPS)) = affineNative (2^(20+1) ^^^ 528388) := by decide +kernel

theorem selectedBound6749 : packedSelected [0,2,4,6,7,9,13,14] rootPS < 2^1333 := by decide +kernel

def env6750 : List Nat := [2,4,8,16,32,49,128,141,512,52,2048,4096,160,4249,0,65536,69770,262144,524288,0,528388,65539,589830,138,40,524292,327850,594079,528405,67755,156,65674,524473,65674,268304,66083]

theorem envBound6750 : H12AffineFastState.Bounded env6750 := by
  intro p hp
  have h : env6750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6749_6750 : H12AffineEnvironment.transform 20 528388 env6749 = env6750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 528388 env6749 == env6750) = true)

theorem identity6750 : scanCanonicalize (H12AffineFastState.compose env6750 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6750 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env6751 : List Nat := [2,4,8,16,32,49,41,36,512,52,2048,4096,9,4144,0,65536,69667,262144,524288,0,528388,65539,589830,35,40,524292,327683,593974,528405,67586,53,65571,524304,65571,268304,66083]

theorem envBound6751 : H12AffineFastState.Bounded env6751 := by
  intro p hp
  have h : env6751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6750_6751 : H12AffineEnvironment.transform 6 41 env6750 = env6751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6750 == env6751) = true)

theorem identity6751 : scanCanonicalize (H12AffineFastState.compose env6751 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(18+1) ^^^ 68102) := by decide +kernel

theorem selectedBound6751 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env6752 : List Nat := [2,4,8,16,32,49,41,36,512,52,2048,4096,9,4144,0,65536,69667,262144,68102,0,72194,65539,2560,35,40,68098,327683,6704,72211,67586,53,65571,68118,65571,268304,66083]

theorem envBound6752 : H12AffineFastState.Bounded env6752 := by
  intro p hp
  have h : env6752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6751_6752 : H12AffineEnvironment.transform 18 68102 env6751 = env6752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 68102 env6751 == env6752) = true)

theorem identity6752 : scanCanonicalize (H12AffineFastState.compose env6752 (packedSelected [1,6,7,8,9,11] rootPS)) = affineNative (2^(17+1) ^^^ 4106) := by decide +kernel

theorem selectedBound6752 : packedSelected [1,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env6753 : List Nat := [2,4,8,16,32,49,41,36,512,52,2048,4096,9,4144,0,65536,69667,4106,68102,0,72194,65539,2560,35,40,68098,69641,6704,72211,67586,53,65571,68118,65571,2074,66083]

theorem envBound6753 : H12AffineFastState.Bounded env6753 := by
  intro p hp
  have h : env6753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6752_6753 : H12AffineEnvironment.transform 17 4106 env6752 = env6753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4106 env6752 == env6753) = true)

theorem identity6753 : scanCanonicalize (H12AffineFastState.compose env6753 (packedSelected [2,3,4,6,7,8,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound6753 : packedSelected [2,3,4,6,7,8,18] rootPS < 2^1333 := by decide +kernel

def env6754 : List Nat := [2,4,8,16,32,49,41,36,512,52,2048,4096,9,4144,0,35,4096,4106,2597,0,6689,32,2560,35,40,2593,4138,6704,6704,2081,53,0,2613,0,2074,512]

theorem envBound6754 : H12AffineFastState.Bounded env6754 := by
  intro p hp
  have h : env6754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6753_6754 : H12AffineEnvironment.transform 15 35 env6753 = env6754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env6753 == env6754) = true)

theorem identity6754 : scanCanonicalize (H12AffineFastState.compose env6754 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound6754 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env6755 : List Nat := [2,4,8,16,32,49,41,36,512,52,2048,2090,9,2074,0,35,2090,2080,2597,0,523,32,2560,35,40,2593,2048,538,538,2081,53,0,2613,0,2074,512]

theorem envBound6755 : H12AffineFastState.Bounded env6755 := by
  intro p hp
  have h : env6755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6754_6755 : H12AffineEnvironment.transform 11 2090 env6754 = env6755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env6754 == env6755) = true)

theorem identity6755 : scanCanonicalize (H12AffineFastState.compose env6755 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6755 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6756 : List Nat := [2,4,8,1,32,32,41,36,512,37,2048,2090,9,2059,0,35,2090,2080,2597,0,523,32,2560,35,40,2593,2048,523,523,2081,36,0,2596,0,2059,512]

theorem envBound6756 : H12AffineFastState.Bounded env6756 := by
  intro p hp
  have h : env6756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6755_6756 : H12AffineEnvironment.transform 3 1 env6755 = env6756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6755 == env6756) = true)

theorem identity6756 : scanCanonicalize (H12AffineFastState.compose env6756 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound6756 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6757 : List Nat := [2,4,8,1,11,11,2,15,512,14,2048,2049,9,2059,0,8,2049,2059,2574,0,523,11,2560,8,3,2570,2048,523,523,2058,15,0,2575,0,2059,512]

theorem envBound6757 : H12AffineFastState.Bounded env6757 := by
  intro p hp
  have h : env6757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6756_6757 : H12AffineEnvironment.transform 4 11 env6756 = env6757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env6756 == env6757) = true)

theorem identity6757 : scanCanonicalize (H12AffineFastState.compose env6757 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound6757 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6758 : List Nat := [2,4,8,1,11,11,2,15,512,14,523,522,9,512,0,8,522,512,5,0,523,11,11,8,3,1,523,523,523,513,15,0,4,0,512,512]

theorem envBound6758 : H12AffineFastState.Bounded env6758 := by
  intro p hp
  have h : env6758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6757_6758 : H12AffineEnvironment.transform 10 523 env6757 = env6758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env6757 == env6758) = true)

theorem identity6758 : scanCanonicalize (H12AffineFastState.compose env6758 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound6758 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6759 : List Nat := [0,4,8,1,9,9,0,13,512,12,521,520,9,512,0,8,520,512,5,0,521,9,9,8,1,1,521,521,521,513,13,0,4,0,512,512]

theorem envBound6759 : H12AffineFastState.Bounded env6759 := by
  intro p hp
  have h : env6759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6758_6759 : H12AffineEnvironment.transform 0 0 env6758 = env6759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env6758 == env6759) = true)

theorem identity6759 : scanCanonicalize (H12AffineFastState.compose env6759 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6759 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6760 : List Nat := [0,1,8,1,9,9,0,8,512,9,521,520,9,512,0,8,520,512,0,0,521,9,9,8,1,1,521,521,521,513,8,0,1,0,512,512]

theorem envBound6760 : H12AffineFastState.Bounded env6760 := by
  intro p hp
  have h : env6760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6759_6760 : H12AffineEnvironment.transform 1 1 env6759 = env6760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6759 == env6760) = true)

def env6761 : List Nat := [2,4,8,16,32,49,128,141,512,53,2048,4096,160,4249,0,65536,69771,262144,524288,0,2097152,65539,8388608,8978573,40,524293,327850,11010204,11075607,8915116,157,65674,524472,8913037,34359738368,66083]

theorem envBound6761 : H12AffineFastState.Bounded env6761 := by
  intro p hp
  have h : env6761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6746_6761 : H12AffineEnvironment.transform 9 53 env6746 = env6761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env6746 == env6761) = true)

theorem identity6761 : scanCanonicalize (H12AffineFastState.compose env6761 (packedSelected [6,12,13,14,15] rootPS)) = affineNative (2^(34+1) ^^^ 10815506) := by decide +kernel

theorem selectedBound6761 : packedSelected [6,12,13,14,15] rootPS < 2^1333 := by decide +kernel

def env6762 : List Nat := [2,4,8,16,32,49,128,141,512,53,2048,4096,160,4249,0,65536,69771,262144,524288,0,2097152,65539,8388608,8978573,40,524293,327850,11010204,11075607,8915116,157,65674,524472,8913037,10815506,66083]

theorem envBound6762 : H12AffineFastState.Bounded env6762 := by
  intro p hp
  have h : env6762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6761_6762 : H12AffineEnvironment.transform 34 10815506 env6761 = env6762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 10815506 env6761 == env6762) = true)

theorem identity6762 : scanCanonicalize (H12AffineFastState.compose env6762 (packedSelected [0,4,6,7,9,11,13,23] rootPS)) = affineNative (2^(22+1) ^^^ 589831) := by decide +kernel

theorem selectedBound6762 : packedSelected [0,4,6,7,9,11,13,23] rootPS < 2^1333 := by decide +kernel

def env6763 : List Nat := [2,4,8,16,32,49,128,141,512,53,2048,4096,160,4249,0,65536,69771,262144,524288,0,2097152,65539,589831,138,40,524293,327850,2162843,2097168,67755,157,65674,524472,65674,2885653,66083]

theorem envBound6763 : H12AffineFastState.Bounded env6763 := by
  intro p hp
  have h : env6763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6762_6763 : H12AffineEnvironment.transform 22 589831 env6762 = env6763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 589831 env6762 == env6763) = true)

theorem identity6763 : scanCanonicalize (H12AffineFastState.compose env6763 (packedSelected [0,2,4,6,7,9,13,14] rootPS)) = affineNative (2^(20+1) ^^^ 593958) := by decide +kernel

theorem selectedBound6763 : packedSelected [0,2,4,6,7,9,13,14] rootPS < 2^1333 := by decide +kernel

def env6764 : List Nat := [2,4,8,16,32,49,128,141,512,53,2048,4096,160,4249,0,65536,69771,262144,524288,0,593958,65539,589831,138,40,524293,327850,528573,593974,67755,157,65674,524472,65674,333875,66083]

theorem envBound6764 : H12AffineFastState.Bounded env6764 := by
  intro p hp
  have h : env6764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6763_6764 : H12AffineEnvironment.transform 20 593958 env6763 = env6764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 593958 env6763 == env6764) = true)

theorem identity6764 : scanCanonicalize (H12AffineFastState.compose env6764 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6764 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env6765 : List Nat := [2,4,8,16,32,49,41,36,512,53,2048,4096,9,4144,0,65536,69666,262144,524288,0,593958,65539,589831,35,40,524293,327683,528404,593974,67586,52,65571,524305,65571,333875,66083]

theorem envBound6765 : H12AffineFastState.Bounded env6765 := by
  intro p hp
  have h : env6765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6764_6765 : H12AffineEnvironment.transform 6 41 env6764 = env6765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6764 == env6765) = true)

theorem identity6765 : scanCanonicalize (H12AffineFastState.compose env6765 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(15+1) ^^^ 2579) := by decide +kernel

theorem selectedBound6765 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env6766 : List Nat := [2,4,8,16,32,49,41,36,512,53,2048,4096,9,4144,0,2579,6705,262144,524288,0,530997,2576,526868,35,40,524293,264720,528404,530981,529,52,2608,524305,2608,266784,2096]

theorem envBound6766 : H12AffineFastState.Bounded env6766 := by
  intro p hp
  have h : env6766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6765_6766 : H12AffineEnvironment.transform 15 2579 env6765 = env6766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2579 env6765 == env6766) = true)

theorem identity6766 : scanCanonicalize (H12AffineFastState.compose env6766 (packedSelected [1,2,5,6,7,9,11] rootPS)) = affineNative (2^(17+1) ^^^ 6715) := by decide +kernel

theorem selectedBound6766 : packedSelected [1,2,5,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env6767 : List Nat := [2,4,8,16,32,49,41,36,512,53,2048,4096,9,4144,0,2579,6705,6715,524288,0,530997,2576,526868,35,40,524293,4139,528404,530981,529,52,2608,524305,2608,2075,2096]

theorem envBound6767 : H12AffineFastState.Bounded env6767 := by
  intro p hp
  have h : env6767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6766_6767 : H12AffineEnvironment.transform 17 6715 env6766 = env6767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6715 env6766 == env6767) = true)

theorem identity6767 : scanCanonicalize (H12AffineFastState.compose env6767 (packedSelected [1,3,20] rootPS)) = affineNative (2^(18+1) ^^^ 21) := by decide +kernel

theorem selectedBound6767 : packedSelected [1,3,20] rootPS < 2^1333 := by decide +kernel

def env6768 : List Nat := [2,4,8,16,32,49,41,36,512,53,2048,4096,9,4144,0,2579,6705,6715,21,0,6688,2576,2561,35,40,16,4139,4097,6704,529,52,2608,4,2608,2075,2096]

theorem envBound6768 : H12AffineFastState.Bounded env6768 := by
  intro p hp
  have h : env6768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6767_6768 : H12AffineEnvironment.transform 18 21 env6767 = env6768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21 env6767 == env6768) = true)

theorem identity6768 : scanCanonicalize (H12AffineFastState.compose env6768 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound6768 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env6769 : List Nat := [2,4,8,16,32,49,41,36,512,53,522,4096,9,4144,0,25,4155,4145,21,0,4138,26,11,35,40,16,4139,4097,4154,529,52,58,4,58,529,570]

theorem envBound6769 : H12AffineFastState.Bounded env6769 := by
  intro p hp
  have h : env6769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6768_6769 : H12AffineEnvironment.transform 10 522 env6768 = env6769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env6768 == env6769) = true)

theorem identity6769 : scanCanonicalize (H12AffineFastState.compose env6769 (packedSelected [2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound6769 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env6770 : List Nat := [2,4,8,16,26,11,19,30,512,15,522,4096,9,4106,0,25,4097,4107,21,0,4112,26,11,25,18,16,4113,4097,4096,529,14,0,4,0,529,512]

theorem envBound6770 : H12AffineFastState.Bounded env6770 := by
  intro p hp
  have h : env6770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6769_6770 : H12AffineEnvironment.transform 4 26 env6769 = env6770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env6769 == env6770) = true)

theorem identity6770 : scanCanonicalize (H12AffineFastState.compose env6770 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound6770 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env6771 : List Nat := [2,4,8,8,2,11,11,6,512,15,522,4096,9,4106,0,1,4097,4107,13,0,4104,2,11,1,10,8,4105,4097,4096,521,14,0,4,0,521,512]

theorem envBound6771 : H12AffineFastState.Bounded env6771 := by
  intro p hp
  have h : env6771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6770_6771 : H12AffineEnvironment.transform 3 8 env6770 = env6771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env6770 == env6771) = true)

def env6772 : List Nat := [2,4,8,8,2,11,11,6,512,15,522,512,9,522,0,1,513,523,13,0,520,2,11,1,10,8,521,513,512,521,14,0,4,0,521,512]

theorem envBound6772 : H12AffineFastState.Bounded env6772 := by
  intro p hp
  have h : env6772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6771_6772 : H12AffineEnvironment.transform 11 512 env6771 = env6772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env6771 == env6772) = true)

theorem identity6772 : scanCanonicalize (H12AffineFastState.compose env6772 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6772 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6773 : List Nat := [2,4,2,2,2,1,1,6,512,5,512,512,3,512,0,1,513,513,7,0,514,2,1,1,0,2,515,513,512,515,4,0,4,0,515,512]

theorem envBound6773 : H12AffineFastState.Bounded env6773 := by
  intro p hp
  have h : env6773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6772_6773 : H12AffineEnvironment.transform 2 2 env6772 = env6773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6772 == env6773) = true)

theorem identity6773 : scanCanonicalize (H12AffineFastState.compose env6773 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound6773 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6774 : List Nat := [2,4,2,2,2,1,1,6,5,5,5,5,3,5,0,1,4,4,7,0,7,2,1,1,0,2,6,4,5,6,4,0,4,0,6,5]

theorem envBound6774 : H12AffineFastState.Bounded env6774 := by
  intro p hp
  have h : env6774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6773_6774 : H12AffineEnvironment.transform 8 5 env6773 = env6774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env6773 == env6774) = true)

def leafEnv6774 : List Nat := [2,4,2,2,2,1,1,6,5,5,5,5,3,5,0,1,4,4,7,0,7,2,1,1,6,0,1,2,6,4,5,6,4,0,4,0,6,2,6,5,1,5,0]

def active6774 : List Nat := [0,1]

def tree6774 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6774 : H12WitnessSearch.Good tree6774 := H12GlobalWitnessIndex.good

theorem leafIdentity6774 : H12AffineFastState.composeSystem env6774 rootObs = leafEnv6774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6774 rootObs == leafEnv6774) = true)

theorem terminalChecked6774 : H12PackedTerminal.terminalCheckFast leafEnv6774 active6774 tree6774 = true := by decide +kernel

def env6775 : List Nat := [2,4,8,8,2,11,11,6,512,15,522,513,9,523,0,1,512,522,13,0,521,2,11,1,10,8,520,512,513,521,14,0,4,0,521,512]

theorem envBound6775 : H12AffineFastState.Bounded env6775 := by
  intro p hp
  have h : env6775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6771_6775 : H12AffineEnvironment.transform 11 513 env6771 = env6775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env6771 == env6775) = true)

theorem identity6775 : scanCanonicalize (H12AffineFastState.compose env6775 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound6775 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6776 : List Nat := [2,4,1,1,2,2,2,6,512,6,515,513,0,514,0,1,512,515,4,0,512,2,2,1,3,1,513,512,513,512,7,0,4,0,512,512]

theorem envBound6776 : H12AffineFastState.Bounded env6776 := by
  intro p hp
  have h : env6776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6775_6776 : H12AffineEnvironment.transform 2 1 env6775 = env6776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env6775 == env6776) = true)

theorem identity6776 : scanCanonicalize (H12AffineFastState.compose env6776 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound6776 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6777 : List Nat := [2,4,1,1,2,2,2,6,7,6,4,6,0,5,0,1,7,4,4,0,7,2,2,1,3,1,6,7,6,7,7,0,4,0,7,7]

theorem envBound6777 : H12AffineFastState.Bounded env6777 := by
  intro p hp
  have h : env6777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6776_6777 : H12AffineEnvironment.transform 8 7 env6776 = env6777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env6776 == env6777) = true)

def leafEnv6777 : List Nat := [2,4,1,1,2,2,2,6,7,6,4,6,0,5,0,1,7,4,4,0,7,2,2,1,5,3,1,1,6,7,6,7,7,0,4,0,6,2,7,7,1,4,0]

def active6777 : List Nat := [0,1]

def tree6777 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6777 : H12WitnessSearch.Good tree6777 := H12GlobalWitnessIndex.good

theorem leafIdentity6777 : H12AffineFastState.composeSystem env6777 rootObs = leafEnv6777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6777 rootObs == leafEnv6777) = true)

theorem terminalChecked6777 : H12PackedTerminal.terminalCheckFast leafEnv6777 active6777 tree6777 = true := by decide +kernel

def env6778 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,4329,8352,65536,131072,262144,524288,8352,2097152,73891,8388608,8987672,8328,525377,335882,11011240,11146408,8916121,1192,73770,525564,8914104,34359738368,74371]

theorem envBound6778 : H12AffineFastState.Bounded env6778 := by
  intro p hp
  have h : env6778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6713_6778 : H12AffineEnvironment.transform 13 4329 env6713 = env6778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4329 env6713 == env6778) = true)

theorem identity6778 : scanCanonicalize (H12AffineFastState.compose env6778 (packedSelected [3,5,7,9,10,13,20,21,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound6778 : packedSelected [3,5,7,9,10,13,20,21,22,27] rootPS < 2^1333 := by decide +kernel

def env6779 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,4329,8352,65536,13388,262144,524288,8352,2097152,73891,8388608,8987672,8328,525377,335882,11011240,11018468,8916121,1192,73770,525564,8914104,34359738368,74371]

theorem envBound6779 : H12AffineFastState.Bounded env6779 := by
  intro p hp
  have h : env6779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6778_6779 : H12AffineEnvironment.transform 16 13388 env6778 = env6779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env6778 == env6779) = true)

def env6780 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4249,8352,65536,13372,262144,524288,8352,2097152,73891,8388608,8987672,8328,525361,335882,11011240,11018388,8916121,1192,73770,525452,8914104,34359738368,74371]

theorem envBound6780 : H12AffineFastState.Bounded env6780 := by
  intro p hp
  have h : env6780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6779_6780 : H12AffineEnvironment.transform 5 48 env6779 = env6780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env6779 == env6780) = true)

theorem identity6780 : scanCanonicalize (H12AffineFastState.compose env6780 (packedSelected [0,1,2,3,4,6,7,9,14,21,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound6780 : packedSelected [0,1,2,3,4,6,7,9,14,21,24,28] rootPS < 2^1333 := by decide +kernel

def env6781 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4249,8352,35,13372,262144,524288,8352,2097152,8320,8388608,8922171,8328,525361,270377,11011240,11018388,8916121,1192,8201,525452,8914104,34359738368,8864]

theorem envBound6781 : H12AffineFastState.Bounded env6781 := by
  intro p hp
  have h : env6781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6780_6781 : H12AffineEnvironment.transform 15 35 env6780 = env6781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env6780 == env6781) = true)

def env6782 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4249,8352,35,13372,262144,524288,8352,2097152,8320,533680,139,8328,525361,270377,2105368,2098212,10281,1192,8201,525452,8200,34359738368,8864]

theorem envBound6782 : H12AffineFastState.Bounded env6782 := by
  intro p hp
  have h : env6782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6781_6782 : H12AffineEnvironment.transform 22 533680 env6781 = env6782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 533680 env6781 == env6782) = true)

theorem identity6782 : scanCanonicalize (H12AffineFastState.compose env6782 (packedSelected [6,12,13,14,15] rootPS)) = affineNative (2^(34+1) ^^^ 2885653) := by decide +kernel

theorem selectedBound6782 : packedSelected [6,12,13,14,15] rootPS < 2^1333 := by decide +kernel

def env6783 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4249,8352,35,13372,262144,524288,8352,2097152,8320,533680,139,8328,525361,270377,2105368,2098212,10281,1192,8201,525452,8200,2885653,8864]

theorem envBound6783 : H12AffineFastState.Bounded env6783 := by
  intro p hp
  have h : env6783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6782_6783 : H12AffineEnvironment.transform 34 2885653 env6782 = env6783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 2885653 env6782 == env6783) = true)

theorem identity6783 : scanCanonicalize (H12AffineFastState.compose env6783 (packedSelected [0,2,4,6,7,9,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound6783 : packedSelected [0,2,4,6,7,9,13,14] rootPS < 2^1333 := by decide +kernel

def env6784 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4249,8352,35,13372,2184,524288,8352,2097152,8320,533680,139,8328,525361,10401,2105368,2098212,10281,1192,8201,525452,8200,2621597,8864]

theorem envBound6784 : H12AffineFastState.Bounded env6784 := by
  intro p hp
  have h : env6784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6783_6784 : H12AffineEnvironment.transform 17 2184 env6783 = env6784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env6783 == env6784) = true)

theorem identity6784 : scanCanonicalize (H12AffineFastState.compose env6784 (packedSelected [2,3,5,6,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound6784 : packedSelected [2,3,5,6,10,11,18] rootPS < 2^1333 := by decide +kernel

def env6785 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,160,4249,0,35,5276,2184,524288,0,2097152,32,525328,139,40,525361,2049,2097336,2098212,2185,1192,169,525452,168,2621597,512]

theorem envBound6785 : H12AffineFastState.Bounded env6785 := by
  intro p hp
  have h : env6785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6784_6785 : H12AffineEnvironment.transform 12 160 env6784 = env6785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env6784 == env6785) = true)

theorem identity6785 : scanCanonicalize (H12AffineFastState.compose env6785 (packedSelected [1,3] rootPS)) = affineNative (2^(20+1) ^^^ 5261) := by decide +kernel

theorem selectedBound6785 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6786 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,160,4249,0,35,5276,2184,524288,0,5261,32,525328,139,40,525361,2049,5173,4265,2185,1192,169,525452,168,529424,512]

theorem envBound6786 : H12AffineFastState.Bounded env6786 := by
  intro p hp
  have h : env6786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6785_6786 : H12AffineEnvironment.transform 20 5261 env6785 = env6786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5261 env6785 == env6786) = true)

theorem identity6786 : scanCanonicalize (H12AffineFastState.compose env6786 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6786 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env6787 : List Nat := [2,4,8,16,32,48,41,37,512,1024,2048,4096,9,4144,0,35,5173,2081,524288,0,5156,32,525328,34,40,525361,2049,5173,4096,2080,1025,0,525349,1,529424,512]

theorem envBound6787 : H12AffineFastState.Bounded env6787 := by
  intro p hp
  have h : env6787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6786_6787 : H12AffineEnvironment.transform 6 41 env6786 = env6787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6786 == env6787) = true)

def env6788 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4249,8352,35,13372,262144,524288,8352,2097152,8320,533681,138,8328,525361,270377,2105369,2098213,10280,1192,8201,525452,8201,34359738368,8864]

theorem envBound6788 : H12AffineFastState.Bounded env6788 := by
  intro p hp
  have h : env6788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6781_6788 : H12AffineEnvironment.transform 22 533681 env6781 = env6788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 533681 env6781 == env6788) = true)

theorem identity6788 : scanCanonicalize (H12AffineFastState.compose env6788 (packedSelected [6,12,13,14,15] rootPS)) = affineNative (2^(34+1) ^^^ 2894977) := by decide +kernel

theorem selectedBound6788 : packedSelected [6,12,13,14,15] rootPS < 2^1333 := by decide +kernel

def env6789 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4249,8352,35,13372,262144,524288,8352,2097152,8320,533681,138,8328,525361,270377,2105369,2098213,10280,1192,8201,525452,8201,2894977,8864]

theorem envBound6789 : H12AffineFastState.Bounded env6789 := by
  intro p hp
  have h : env6789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6788_6789 : H12AffineEnvironment.transform 34 2894977 env6788 = env6789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 2894977 env6788 == env6789) = true)

theorem identity6789 : scanCanonicalize (H12AffineFastState.compose env6789 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(20+1) ^^^ 537745) := by decide +kernel

theorem selectedBound6789 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env6790 : List Nat := [2,4,8,16,32,48,128,140,512,1024,2048,4096,8192,4249,8352,35,13372,262144,524288,8352,537745,8320,533681,138,8328,525361,270377,529544,536756,10280,1192,8201,525452,8201,268304,8864]

theorem envBound6790 : H12AffineFastState.Bounded env6790 := by
  intro p hp
  have h : env6790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6789_6790 : H12AffineEnvironment.transform 20 537745 env6789 = env6790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 537745 env6789 == env6790) = true)

theorem identity6790 : scanCanonicalize (H12AffineFastState.compose env6790 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6790 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env6791 : List Nat := [2,4,8,16,32,48,40,36,512,1024,2048,4096,8192,4145,8200,35,13372,262144,524288,8200,537657,8232,533529,34,8224,525361,270377,529440,536604,10280,1024,8201,525348,8201,268304,8712]

theorem envBound6791 : H12AffineFastState.Bounded env6791 := by
  intro p hp
  have h : env6791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6790_6791 : H12AffineEnvironment.transform 6 40 env6790 = env6791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6790 == env6791) = true)

theorem identity6791 : scanCanonicalize (H12AffineFastState.compose env6791 (packedSelected [1,6,7,8,9,11] rootPS)) = affineNative (2^(18+1) ^^^ 278035) := by decide +kernel

theorem selectedBound6791 : packedSelected [1,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env6792 : List Nat := [2,4,8,16,32,48,40,36,512,1024,2048,4096,8192,4145,8200,35,13372,262144,278035,8200,264746,8232,268810,34,8224,277026,270377,272947,265743,10280,1024,8201,277047,8201,268304,8712]

theorem envBound6792 : H12AffineFastState.Bounded env6792 := by
  intro p hp
  have h : env6792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6791_6792 : H12AffineEnvironment.transform 18 278035 env6791 = env6792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 278035 env6791 == env6792) = true)

theorem identity6792 : scanCanonicalize (H12AffineFastState.compose env6792 (packedSelected [0,1,2,3,5,8,9,10,12,20] rootPS)) = affineNative (2^(17+1) ^^^ 15879) := by decide +kernel

theorem selectedBound6792 : packedSelected [0,1,2,3,5,8,9,10,12,20] rootPS < 2^1333 := by decide +kernel

def env6793 : List Nat := [2,4,8,16,32,48,40,36,512,1024,2048,4096,8192,4145,8200,35,13372,15879,20,8200,13357,8232,9229,34,8224,1061,7726,5172,12296,10280,1024,8201,1072,8201,9751,8712]

theorem envBound6793 : H12AffineFastState.Bounded env6793 := by
  intro p hp
  have h : env6793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6792_6793 : H12AffineEnvironment.transform 17 15879 env6792 = env6793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 15879 env6792 == env6793) = true)

theorem identity6793 : scanCanonicalize (H12AffineFastState.compose env6793 (packedSelected [0,3,6,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound6793 : packedSelected [0,3,6,8,9] rootPS < 2^1333 := by decide +kernel

def env6794 : List Nat := [2,4,8,16,32,48,40,36,512,14,2048,4096,8192,4145,8200,35,12338,14857,20,8200,12323,8232,8195,34,8224,43,6688,4154,12296,10280,14,8201,62,8201,8729,8712]

theorem envBound6794 : H12AffineFastState.Bounded env6794 := by
  intro p hp
  have h : env6794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6793_6794 : H12AffineEnvironment.transform 9 14 env6793 = env6794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env6793 == env6794) = true)

theorem identity6794 : scanCanonicalize (H12AffineFastState.compose env6794 (packedSelected [2,6,12] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound6794 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env6795 : List Nat := [2,4,8,16,32,48,40,36,512,14,561,4096,8192,4145,8200,35,12338,12344,20,8200,12323,8232,8195,34,8224,43,4113,4154,12296,8729,14,8201,62,8201,8729,8712]

theorem envBound6795 : H12AffineFastState.Bounded env6795 := by
  intro p hp
  have h : env6795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6794_6795 : H12AffineEnvironment.transform 10 561 env6794 = env6795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env6794 == env6795) = true)

theorem identity6795 : scanCanonicalize (H12AffineFastState.compose env6795 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound6795 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env6796 : List Nat := [2,4,8,16,32,48,40,36,512,14,561,4096,51,4145,59,35,4097,4107,20,59,4112,27,48,34,19,43,4113,4154,4155,554,14,58,62,58,554,571]

theorem envBound6796 : H12AffineFastState.Bounded env6796 := by
  intro p hp
  have h : env6796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6795_6796 : H12AffineEnvironment.transform 12 51 env6795 = env6796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env6795 == env6796) = true)

theorem identity6796 : scanCanonicalize (H12AffineFastState.compose env6796 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound6796 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env6797 : List Nat := [2,4,8,16,27,11,19,31,512,14,522,4096,8,4106,0,24,4097,4107,20,0,4112,27,11,25,19,16,4113,4097,4096,529,14,1,5,1,529,512]

theorem envBound6797 : H12AffineFastState.Bounded env6797 := by
  intro p hp
  have h : env6797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6796_6797 : H12AffineEnvironment.transform 4 27 env6796 = env6797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env6796 == env6797) = true)

theorem identity6797 : scanCanonicalize (H12AffineFastState.compose env6797 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound6797 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env6798 : List Nat := [2,4,8,9,2,11,10,6,512,14,522,4096,8,4106,0,1,4097,4107,13,0,4105,2,11,0,10,9,4104,4097,4096,520,14,1,5,1,520,512]

theorem envBound6798 : H12AffineFastState.Bounded env6798 := by
  intro p hp
  have h : env6798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6797_6798 : H12AffineEnvironment.transform 3 9 env6797 = env6798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env6797 == env6798) = true)

def env6799 : List Nat := [2,4,8,9,2,11,10,6,512,14,522,512,8,522,0,1,513,523,13,0,521,2,11,0,10,9,520,513,512,520,14,1,5,1,520,512]

theorem envBound6799 : H12AffineFastState.Bounded env6799 := by
  intro p hp
  have h : env6799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6798_6799 : H12AffineEnvironment.transform 11 512 env6798 = env6799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env6798 == env6799) = true)

theorem identity6799 : scanCanonicalize (H12AffineFastState.compose env6799 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6799 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6800 : List Nat := [2,4,3,2,2,0,1,6,512,5,513,512,3,513,0,1,513,512,6,0,514,2,0,0,1,2,515,513,512,515,5,1,5,1,515,512]

theorem envBound6800 : H12AffineFastState.Bounded env6800 := by
  intro p hp
  have h : env6800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6799_6800 : H12AffineEnvironment.transform 2 3 env6799 = env6800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6799 == env6800) = true)

theorem identity6800 : scanCanonicalize (H12AffineFastState.compose env6800 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound6800 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6801 : List Nat := [2,4,3,2,2,0,1,6,6,5,7,6,3,7,0,1,7,6,6,0,4,2,0,0,1,2,5,7,6,5,5,1,5,1,5,6]

theorem envBound6801 : H12AffineFastState.Bounded env6801 := by
  intro p hp
  have h : env6801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6800_6801 : H12AffineEnvironment.transform 8 6 env6800 = env6801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env6800 == env6801) = true)

def leafEnv6801 : List Nat := [2,4,3,2,2,0,1,6,6,5,7,6,3,7,0,1,7,6,6,0,4,2,0,0,6,1,1,2,5,7,6,5,5,1,5,1,7,3,5,6,1,7,0]

def active6801 : List Nat := [0,1]

def tree6801 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6801 : H12WitnessSearch.Good tree6801 := H12GlobalWitnessIndex.good

theorem leafIdentity6801 : H12AffineFastState.composeSystem env6801 rootObs = leafEnv6801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6801 rootObs == leafEnv6801) = true)

theorem terminalChecked6801 : H12PackedTerminal.terminalCheckFast leafEnv6801 active6801 tree6801 = true := by decide +kernel

def env6802 : List Nat := [2,4,8,9,2,11,10,6,512,14,522,513,8,523,0,1,512,522,13,0,520,2,11,0,10,9,521,512,513,520,14,1,5,1,520,512]

theorem envBound6802 : H12AffineFastState.Bounded env6802 := by
  intro p hp
  have h : env6802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6798_6802 : H12AffineEnvironment.transform 11 513 env6798 = env6802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env6798 == env6802) = true)

theorem identity6802 : scanCanonicalize (H12AffineFastState.compose env6802 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound6802 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6803 : List Nat := [2,4,1,0,2,2,3,6,512,7,515,513,1,514,0,1,512,515,4,0,513,2,2,0,3,0,512,512,513,513,7,1,5,1,513,512]

theorem envBound6803 : H12AffineFastState.Bounded env6803 := by
  intro p hp
  have h : env6803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6802_6803 : H12AffineEnvironment.transform 2 1 env6802 = env6803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env6802 == env6803) = true)

theorem identity6803 : scanCanonicalize (H12AffineFastState.compose env6803 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound6803 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6804 : List Nat := [2,4,1,0,2,2,3,6,4,7,7,5,1,6,0,1,4,7,4,0,5,2,2,0,3,0,4,4,5,5,7,1,5,1,5,4]

theorem envBound6804 : H12AffineFastState.Bounded env6804 := by
  intro p hp
  have h : env6804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6803_6804 : H12AffineEnvironment.transform 8 4 env6803 = env6804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env6803 == env6804) = true)

def leafEnv6804 : List Nat := [2,4,1,0,2,2,3,6,4,7,7,5,1,6,0,1,4,7,4,0,5,2,2,0,4,3,1,0,4,4,5,5,7,1,5,1,7,3,5,4,1,7,0]

def active6804 : List Nat := [0,1]

def tree6804 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6804 : H12WitnessSearch.Good tree6804 := H12GlobalWitnessIndex.good

theorem leafIdentity6804 : H12AffineFastState.composeSystem env6804 rootObs = leafEnv6804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6804 rootObs == leafEnv6804) = true)

theorem terminalChecked6804 : H12PackedTerminal.terminalCheckFast leafEnv6804 active6804 tree6804 = true := by decide +kernel

def env6805 : List Nat := [2,4,8,16,32,49,128,141,512,1024,2048,4096,8192,4248,8352,65536,13373,262144,524288,8352,2097152,73891,8388608,8987672,8328,525360,335882,11011240,11018389,8916121,1192,73770,525453,8914104,34359738368,74371]

theorem envBound6805 : H12AffineFastState.Bounded env6805 := by
  intro p hp
  have h : env6805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6779_6805 : H12AffineEnvironment.transform 5 49 env6779 = env6805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env6779 == env6805) = true)

theorem identity6805 : scanCanonicalize (H12AffineFastState.compose env6805 (packedSelected [0,1,2,3,4,6,7,9,14,21,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound6805 : packedSelected [0,1,2,3,4,6,7,9,14,21,24,28] rootPS < 2^1333 := by decide +kernel

def env6806 : List Nat := [2,4,8,16,32,49,128,141,512,1024,2048,4096,160,4248,0,65536,5277,262144,524288,0,2097152,65539,8388608,8979640,40,525360,327850,11011240,11010101,8916121,1192,65674,525453,8914104,34359738368,66083]

theorem envBound6806 : H12AffineFastState.Bounded env6806 := by
  intro p hp
  have h : env6806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6805_6806 : H12AffineEnvironment.transform 12 160 env6805 = env6806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env6805 == env6806) = true)

def env6807 : List Nat := [2,4,8,16,32,49,128,141,512,52,2048,4096,160,4248,0,65536,4265,262144,524288,0,2097152,65539,8388608,8978572,40,524292,327850,11010204,11010101,8915117,156,65674,524473,8913036,34359738368,66083]

theorem envBound6807 : H12AffineFastState.Bounded env6807 := by
  intro p hp
  have h : env6807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6806_6807 : H12AffineEnvironment.transform 9 52 env6806 = env6807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env6806 == env6807) = true)

theorem identity6807 : scanCanonicalize (H12AffineFastState.compose env6807 (packedSelected [6,12,13,14,15] rootPS)) = affineNative (2^(34+1) ^^^ 10750000) := by decide +kernel

theorem selectedBound6807 : packedSelected [6,12,13,14,15] rootPS < 2^1333 := by decide +kernel

def env6808 : List Nat := [2,4,8,16,32,49,128,141,512,52,2048,4096,160,4248,0,65536,4265,262144,524288,0,2097152,65539,8388608,8978572,40,524292,327850,11010204,11010101,8915117,156,65674,524473,8913036,10750000,66083]

theorem envBound6808 : H12AffineFastState.Bounded env6808 := by
  intro p hp
  have h : env6808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6807_6808 : H12AffineEnvironment.transform 34 10750000 env6807 = env6808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 10750000 env6807 == env6808) = true)

theorem identity6808 : scanCanonicalize (H12AffineFastState.compose env6808 (packedSelected [2,3,5,6,10,11,13,21,23] rootPS)) = affineNative (2^(22+1) ^^^ 589830) := by decide +kernel

theorem selectedBound6808 : packedSelected [2,3,5,6,10,11,13,21,23] rootPS < 2^1333 := by decide +kernel

def env6809 : List Nat := [2,4,8,16,32,49,128,141,512,52,2048,4096,160,4248,0,65536,4265,262144,524288,0,2097152,65539,589830,138,40,524292,327850,2162842,2162739,67755,156,65674,524473,65674,2951222,66083]

theorem envBound6809 : H12AffineFastState.Bounded env6809 := by
  intro p hp
  have h : env6809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6808_6809 : H12AffineEnvironment.transform 22 589830 env6808 = env6809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 589830 env6808 == env6809) = true)

theorem identity6809 : scanCanonicalize (H12AffineFastState.compose env6809 (packedSelected [0,2,4,6,7,9,13,14] rootPS)) = affineNative (2^(20+1) ^^^ 528388) := by decide +kernel

theorem selectedBound6809 : packedSelected [0,2,4,6,7,9,13,14] rootPS < 2^1333 := by decide +kernel

def env6810 : List Nat := [2,4,8,16,32,49,128,141,512,52,2048,4096,160,4248,0,65536,4265,262144,524288,0,528388,65539,589830,138,40,524292,327850,594078,593975,67755,156,65674,524473,65674,333874,66083]

theorem envBound6810 : H12AffineFastState.Bounded env6810 := by
  intro p hp
  have h : env6810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6809_6810 : H12AffineEnvironment.transform 20 528388 env6809 = env6810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 528388 env6809 == env6810) = true)

theorem identity6810 : scanCanonicalize (H12AffineFastState.compose env6810 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6810 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env6811 : List Nat := [2,4,8,16,32,49,41,36,512,52,2048,4096,9,4145,0,65536,4096,262144,524288,0,528388,65539,589830,35,40,524292,327683,593975,593975,67586,53,65571,524304,65571,333874,66083]

theorem envBound6811 : H12AffineFastState.Bounded env6811 := by
  intro p hp
  have h : env6811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6810_6811 : H12AffineEnvironment.transform 6 41 env6810 = env6811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6810 == env6811) = true)

theorem identity6811 : scanCanonicalize (H12AffineFastState.compose env6811 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound6811 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env6812 : List Nat := [2,4,8,16,32,49,41,36,512,52,561,4096,9,4145,0,65536,4096,262144,524288,0,528388,65539,589830,35,40,524292,327683,593975,593975,66099,53,65571,524304,65571,332291,66083]

theorem envBound6812 : H12AffineFastState.Bounded env6812 := by
  intro p hp
  have h : env6812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6811_6812 : H12AffineEnvironment.transform 10 561 env6811 = env6812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env6811 == env6812) = true)

theorem identity6812 : scanCanonicalize (H12AffineFastState.compose env6812 (packedSelected [1,2,5,6,7,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 4665) := by decide +kernel

theorem selectedBound6812 : packedSelected [1,2,5,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env6813 : List Nat := [2,4,8,16,32,49,41,36,512,52,561,4096,9,4145,0,4665,4096,262144,524288,0,528388,4666,528959,35,40,524292,266810,524814,524814,4106,53,4634,524304,4634,262202,4122]

theorem envBound6813 : H12AffineFastState.Bounded env6813 := by
  intro p hp
  have h : env6813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6812_6813 : H12AffineEnvironment.transform 15 4665 env6812 = env6813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4665 env6812 == env6813) = true)

theorem identity6813 : scanCanonicalize (H12AffineFastState.compose env6813 (packedSelected [3,4,5,6,7,18] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound6813 : packedSelected [3,4,5,6,7,18] rootPS < 2^1333 := by decide +kernel

def env6814 : List Nat := [2,4,8,16,32,49,41,36,512,52,561,538,9,555,0,35,538,262144,524288,0,524830,32,524325,35,40,524292,262176,524814,524814,528,53,0,524304,0,262202,512]

theorem envBound6814 : H12AffineFastState.Bounded env6814 := by
  intro p hp
  have h : env6814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6813_6814 : H12AffineEnvironment.transform 11 538 env6813 = env6814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env6813 == env6814) = true)

theorem identity6814 : scanCanonicalize (H12AffineFastState.compose env6814 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(18+1) ^^^ 20) := by decide +kernel

theorem selectedBound6814 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env6815 : List Nat := [2,4,8,16,32,49,41,36,512,52,561,538,9,555,0,35,538,262144,20,0,522,32,49,35,40,16,262176,538,538,528,53,0,4,0,262202,512]

theorem envBound6815 : H12AffineFastState.Bounded env6815 := by
  intro p hp
  have h : env6815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6814_6815 : H12AffineEnvironment.transform 18 20 env6814 = env6815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 20 env6814 == env6815) = true)

theorem identity6815 : scanCanonicalize (H12AffineFastState.compose env6815 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound6815 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6816 : List Nat := [2,4,8,16,27,10,18,31,512,15,522,538,9,528,0,24,538,262144,20,0,522,27,10,24,19,16,262171,538,538,528,14,0,4,0,262145,512]

theorem envBound6816 : H12AffineFastState.Bounded env6816 := by
  intro p hp
  have h : env6816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6815_6816 : H12AffineEnvironment.transform 4 27 env6815 = env6816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env6815 == env6816) = true)

theorem identity6816 : scanCanonicalize (H12AffineFastState.compose env6816 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound6816 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6817 : List Nat := [2,4,8,16,27,10,18,31,3,15,9,25,9,19,0,24,25,262144,20,0,9,27,10,24,19,16,262171,25,25,19,14,0,4,0,262145,3]

theorem envBound6817 : H12AffineFastState.Bounded env6817 := by
  intro p hp
  have h : env6817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6816_6817 : H12AffineEnvironment.transform 8 3 env6816 = env6817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env6816 == env6817) = true)

def env6818 : List Nat := [2,4,8,0,11,10,2,15,3,15,9,9,9,3,0,8,9,262144,4,0,9,11,10,8,3,0,262155,9,9,3,14,0,4,0,262145,3]

theorem envBound6818 : H12AffineFastState.Bounded env6818 := by
  intro p hp
  have h : env6818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6817_6818 : H12AffineEnvironment.transform 3 0 env6817 = env6818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6817 == env6818) = true)

theorem identity6818 : scanCanonicalize (H12AffineFastState.compose env6818 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6818 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6819 : List Nat := [2,1,8,0,11,10,2,10,3,10,9,9,9,3,0,8,9,262144,1,0,9,11,10,8,3,0,262155,9,9,3,11,0,1,0,262145,3]

theorem envBound6819 : H12AffineFastState.Bounded env6819 := by
  intro p hp
  have h : env6819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6818_6819 : H12AffineEnvironment.transform 1 1 env6818 = env6819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6818 == env6819) = true)

def env6820 : List Nat := [2,1,8,0,11,10,2,10,3,10,9,9,9,3,0,8,9,8,1,0,9,11,10,8,3,0,3,9,9,3,11,0,1,0,9,3]

theorem envBound6820 : H12AffineFastState.Bounded env6820 := by
  intro p hp
  have h : env6820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6819_6820 : H12AffineEnvironment.transform 17 8 env6819 = env6820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8 env6819 == env6820) = true)

theorem identity6820 : scanCanonicalize (H12AffineFastState.compose env6820 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6820 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6821 : List Nat := [2,1,3,0,0,1,2,1,3,1,2,2,2,3,0,3,2,3,1,0,2,0,1,3,3,0,3,2,2,3,0,0,1,0,2,3]

theorem envBound6821 : H12AffineFastState.Bounded env6821 := by
  intro p hp
  have h : env6821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6820_6821 : H12AffineEnvironment.transform 2 3 env6820 = env6821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6820 == env6821) = true)

def leafEnv6821 : List Nat := [2,1,3,0,0,1,2,1,3,1,2,2,2,3,0,3,2,3,1,0,2,0,1,3,0,3,1,0,3,2,2,3,0,0,1,0,1,2,2,3,1,2,0]

def active6821 : List Nat := [0]

def tree6821 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6821 : H12WitnessSearch.Good tree6821 := H12GlobalWitnessIndex.good

theorem leafIdentity6821 : H12AffineFastState.composeSystem env6821 rootObs = leafEnv6821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6821 rootObs == leafEnv6821) = true)

theorem terminalChecked6821 : H12PackedTerminal.terminalCheckFast leafEnv6821 active6821 tree6821 = true := by decide +kernel

def env6822 : List Nat := [2,1,8,0,11,10,2,10,3,10,9,9,9,3,0,8,9,9,1,0,9,11,10,8,3,0,2,9,9,3,11,0,1,0,8,3]

theorem envBound6822 : H12AffineFastState.Bounded env6822 := by
  intro p hp
  have h : env6822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6819_6822 : H12AffineEnvironment.transform 17 9 env6819 = env6822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9 env6819 == env6822) = true)

def env6823 : List Nat := [2,4,8,1,10,10,3,14,3,15,9,8,9,2,0,9,8,262144,5,0,9,10,10,9,2,1,262154,8,8,2,14,0,4,0,262145,3]

theorem envBound6823 : H12AffineFastState.Bounded env6823 := by
  intro p hp
  have h : env6823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6817_6823 : H12AffineEnvironment.transform 3 1 env6817 = env6823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6817 == env6823) = true)

theorem identity6823 : scanCanonicalize (H12AffineFastState.compose env6823 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 6) := by decide +kernel

theorem selectedBound6823 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6824 : List Nat := [2,4,8,1,10,10,3,14,3,15,9,8,9,2,0,9,8,6,5,0,9,10,10,9,2,1,12,8,8,2,14,0,4,0,7,3]

theorem envBound6824 : H12AffineFastState.Bounded env6824 := by
  intro p hp
  have h : env6824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6823_6824 : H12AffineEnvironment.transform 17 6 env6823 = env6824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6 env6823 == env6824) = true)

def env6825 : List Nat := [2,0,8,1,10,10,3,10,3,11,9,8,9,2,0,9,8,2,1,0,9,10,10,9,2,1,8,8,8,2,10,0,0,0,3,3]

theorem envBound6825 : H12AffineFastState.Bounded env6825 := by
  intro p hp
  have h : env6825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6824_6825 : H12AffineEnvironment.transform 1 0 env6824 = env6825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6824 == env6825) = true)

theorem identity6825 : scanCanonicalize (H12AffineFastState.compose env6825 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6825 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6826 : List Nat := [2,0,3,1,1,1,3,1,3,0,2,3,2,2,0,2,3,2,1,0,2,1,1,2,2,1,3,3,3,2,1,0,0,0,3,3]

theorem envBound6826 : H12AffineFastState.Bounded env6826 := by
  intro p hp
  have h : env6826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6825_6826 : H12AffineEnvironment.transform 2 3 env6825 = env6826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6825 == env6826) = true)

def leafEnv6826 : List Nat := [2,0,3,1,1,1,3,1,3,0,2,3,2,2,0,2,3,2,1,0,2,1,1,2,0,2,1,1,3,3,3,2,1,0,0,0,1,2,3,3,1,2,0]

def active6826 : List Nat := [0]

def tree6826 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6826 : H12WitnessSearch.Good tree6826 := H12GlobalWitnessIndex.good

theorem leafIdentity6826 : H12AffineFastState.composeSystem env6826 rootObs = leafEnv6826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6826 rootObs == leafEnv6826) = true)

theorem terminalChecked6826 : H12PackedTerminal.terminalCheckFast leafEnv6826 active6826 tree6826 = true := by decide +kernel

def env6827 : List Nat := [2,1,8,1,10,10,3,11,3,10,9,8,9,2,0,9,8,3,0,0,9,10,10,9,2,1,9,8,8,2,11,0,1,0,2,3]

theorem envBound6827 : H12AffineFastState.Bounded env6827 := by
  intro p hp
  have h : env6827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6824_6827 : H12AffineEnvironment.transform 1 1 env6824 = env6827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6824 == env6827) = true)

def leafEnv6827 : List Nat := [2,1,8,1,10,10,3,11,3,10,9,8,9,2,0,9,8,3,0,0,9,10,10,9,1,2,1,1,9,8,8,2,11,0,1,0,11,2,2,3,1,8,0]

def active6827 : List Nat := [0,2]

def tree6827 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6827 : H12WitnessSearch.Good tree6827 := H12GlobalWitnessIndex.good

theorem leafIdentity6827 : H12AffineFastState.composeSystem env6827 rootObs = leafEnv6827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6827 rootObs == leafEnv6827) = true)

theorem terminalChecked6827 : H12PackedTerminal.terminalCheckFast leafEnv6827 active6827 tree6827 = true := by decide +kernel

def env6828 : List Nat := [2,4,8,16,32,49,128,141,512,53,2048,4096,160,4248,0,65536,4264,262144,524288,0,2097152,65539,8388608,8978573,40,524293,327850,11010205,11010101,8915116,157,65674,524472,8913037,34359738368,66083]

theorem envBound6828 : H12AffineFastState.Bounded env6828 := by
  intro p hp
  have h : env6828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6806_6828 : H12AffineEnvironment.transform 9 53 env6806 = env6828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env6806 == env6828) = true)

theorem identity6828 : scanCanonicalize (H12AffineFastState.compose env6828 (packedSelected [6,12,13,14,15] rootPS)) = affineNative (2^(34+1) ^^^ 2951223) := by decide +kernel

theorem selectedBound6828 : packedSelected [6,12,13,14,15] rootPS < 2^1333 := by decide +kernel

def env6829 : List Nat := [2,4,8,16,32,49,128,141,512,53,2048,4096,160,4248,0,65536,4264,262144,524288,0,2097152,65539,8388608,8978573,40,524293,327850,11010205,11010101,8915116,157,65674,524472,8913037,2951223,66083]

theorem envBound6829 : H12AffineFastState.Bounded env6829 := by
  intro p hp
  have h : env6829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6828_6829 : H12AffineEnvironment.transform 34 2951223 env6828 = env6829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 2951223 env6828 == env6829) = true)

theorem identity6829 : scanCanonicalize (H12AffineFastState.compose env6829 (packedSelected [0,4,6,7,9,11,13,23] rootPS)) = affineNative (2^(22+1) ^^^ 589831) := by decide +kernel

theorem selectedBound6829 : packedSelected [0,4,6,7,9,11,13,23] rootPS < 2^1333 := by decide +kernel

def env6830 : List Nat := [2,4,8,16,32,49,128,141,512,53,2048,4096,160,4248,0,65536,4264,262144,524288,0,2097152,65539,589831,138,40,524293,327850,2162842,2162738,67755,157,65674,524472,65674,2951223,66083]

theorem envBound6830 : H12AffineFastState.Bounded env6830 := by
  intro p hp
  have h : env6830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6829_6830 : H12AffineEnvironment.transform 22 589831 env6829 = env6830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 589831 env6829 == env6830) = true)

theorem identity6830 : scanCanonicalize (H12AffineFastState.compose env6830 (packedSelected [0,2,4,6,7,9,13,14] rootPS)) = affineNative (2^(20+1) ^^^ 593958) := by decide +kernel

theorem selectedBound6830 : packedSelected [0,2,4,6,7,9,13,14] rootPS < 2^1333 := by decide +kernel

def env6831 : List Nat := [2,4,8,16,32,49,128,141,512,53,2048,4096,160,4248,0,65536,4264,262144,524288,0,593958,65539,589831,138,40,524293,327850,528572,528404,67755,157,65674,524472,65674,268305,66083]

theorem envBound6831 : H12AffineFastState.Bounded env6831 := by
  intro p hp
  have h : env6831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6830_6831 : H12AffineEnvironment.transform 20 593958 env6830 = env6831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 593958 env6830 == env6831) = true)

theorem identity6831 : scanCanonicalize (H12AffineFastState.compose env6831 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound6831 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env6832 : List Nat := [2,4,8,16,32,49,128,141,512,53,2048,4096,160,4248,0,138,4264,262144,524288,0,528556,137,524429,138,40,524293,262176,528572,528404,2081,157,0,524472,0,268305,681]

theorem envBound6832 : H12AffineFastState.Bounded env6832 := by
  intro p hp
  have h : env6832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6831_6832 : H12AffineEnvironment.transform 15 138 env6831 = env6832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env6831 == env6832) = true)

theorem identity6832 : scanCanonicalize (H12AffineFastState.compose env6832 (packedSelected [1,4,5,6,9,10] rootPS)) = affineNative (2^(18+1) ^^^ 2596) := by decide +kernel

theorem selectedBound6832 : packedSelected [1,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env6833 : List Nat := [2,4,8,16,32,49,128,141,512,53,2048,4096,160,4248,0,138,4264,262144,2596,0,6792,137,2729,138,40,2593,262176,6808,6704,2081,157,0,2716,0,268305,681]

theorem envBound6833 : H12AffineFastState.Bounded env6833 := by
  intro p hp
  have h : env6833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6832_6833 : H12AffineEnvironment.transform 18 2596 env6832 = env6833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 2596 env6832 == env6833) = true)

theorem identity6833 : scanCanonicalize (H12AffineFastState.compose env6833 (packedSelected [0,1,4,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound6833 : packedSelected [0,1,4,8,11] rootPS < 2^1333 := by decide +kernel

def env6834 : List Nat := [2,4,8,16,32,49,128,141,512,53,2048,2090,160,2226,0,138,2178,262144,2596,0,674,137,2729,138,40,2593,262176,690,538,2081,157,0,2716,0,262203,681]

theorem envBound6834 : H12AffineFastState.Bounded env6834 := by
  intro p hp
  have h : env6834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6833_6834 : H12AffineEnvironment.transform 11 2090 env6833 = env6834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env6833 == env6834) = true)

theorem identity6834 : scanCanonicalize (H12AffineFastState.compose env6834 (packedSelected [0,1,3,4,6,7,9,20] rootPS)) = affineNative (2^(10+1) ^^^ 665) := by decide +kernel

theorem selectedBound6834 : packedSelected [0,1,3,4,6,7,9,20] rootPS < 2^1333 := by decide +kernel

def env6835 : List Nat := [2,4,8,16,32,49,128,141,512,53,665,691,160,555,0,138,539,262144,189,0,674,137,48,138,40,184,262176,690,538,696,157,0,5,0,262203,681]

theorem envBound6835 : H12AffineFastState.Bounded env6835 := by
  intro p hp
  have h : env6835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6834_6835 : H12AffineEnvironment.transform 10 665 env6834 = env6835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 665 env6834 == env6835) = true)

theorem identity6835 : scanCanonicalize (H12AffineFastState.compose env6835 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound6835 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env6836 : List Nat := [2,4,8,16,32,49,19,30,512,53,522,544,51,555,0,25,539,262144,46,0,561,26,48,25,40,43,262176,545,538,555,14,0,5,0,262203,570]

theorem envBound6836 : H12AffineFastState.Bounded env6836 := by
  intro p hp
  have h : env6836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6835_6836 : H12AffineEnvironment.transform 6 19 env6835 = env6836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env6835 == env6836) = true)

def env6837 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,4194304,8388608,8987673,8328,525377,335882,11031617,11158593,13184059,1193,73770,525565,13181978,34359738368,74371]

theorem envBound6837 : H12AffineFastState.Bounded env6837 := by
  intro p hp
  have h : env6837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6711_6837 : H12AffineEnvironment.transform 7 253 env6711 = env6837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env6711 == env6837) = true)

def env6838 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,4194304,8388608,8987673,8328,525377,335882,11031617,11158593,13184059,1193,73770,525565,13181978,6951968,74371]

theorem envBound6838 : H12AffineFastState.Bounded env6838 := by
  intro p hp
  have h : env6838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6837_6838 : H12AffineEnvironment.transform 34 6951968 env6837 = env6838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 6951968 env6837 == env6838) = true)

theorem identity6838 : scanCanonicalize (H12AffineFastState.compose env6838 (packedSelected [13,21] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound6838 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env6839 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,33,8388608,8987673,8328,525377,335882,11031617,11158593,8989722,1193,73770,525565,8987707,2757633,74371]

theorem envBound6839 : H12AffineFastState.Bounded env6839 := by
  intro p hp
  have h : env6839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6838_6839 : H12AffineEnvironment.transform 21 33 env6838 = env6839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env6838 == env6839) = true)

def env6840 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,0,65536,131072,262144,524288,0,2097152,33,8388608,8979641,40,525377,327850,11031617,11158593,8981690,1193,65674,525565,8979611,2757633,66083]

theorem envBound6840 : H12AffineFastState.Bounded env6840 := by
  intro p hp
  have h : env6840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6839_6840 : H12AffineEnvironment.transform 12 160 env6839 = env6840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env6839 == env6840) = true)

theorem identity6840 : scanCanonicalize (H12AffineFastState.compose env6840 (packedSelected [0,2,4,6,7,9,12,13,14,15,17] rootPS)) = affineNative (2^(22+1) ^^^ 725214) := by decide +kernel

theorem selectedBound6840 : packedSelected [0,2,4,6,7,9,12,13,14,15,17] rootPS < 2^1333 := by decide +kernel

def env6841 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,0,65536,131072,262144,524288,0,2097152,33,725214,136295,40,525377,327850,2311327,2184351,138340,1193,65674,525565,136261,2757633,66083]

theorem envBound6841 : H12AffineFastState.Bounded env6841 := by
  intro p hp
  have h : env6841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6840_6841 : H12AffineEnvironment.transform 22 725214 env6840 = env6841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 725214 env6840 == env6841) = true)

theorem identity6841 : scanCanonicalize (H12AffineFastState.compose env6841 (packedSelected [0,2,3,4,5,6,7,9,10,11,13,14,18] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound6841 : packedSelected [0,2,3,4,5,6,7,9,10,11,13,14,18] rootPS < 2^1333 := by decide +kernel

def env6842 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,0,65536,131072,67755,524288,0,2097152,33,725214,136295,40,525377,2049,2311327,2184351,138340,1193,65674,525565,136261,2757633,66083]

theorem envBound6842 : H12AffineFastState.Bounded env6842 := by
  intro p hp
  have h : env6842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6841_6842 : H12AffineEnvironment.transform 17 67755 env6841 = env6842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env6841 == env6842) = true)

theorem identity6842 : scanCanonicalize (H12AffineFastState.compose env6842 (packedSelected [0,2,3,4,5,6,7,9,10,12,13,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound6842 : packedSelected [0,2,3,4,5,6,7,9,10,12,13,14,15] rootPS < 2^1333 := by decide +kernel

def env6843 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,0,34,131072,2185,524288,0,2097152,33,659708,136295,40,525377,2049,2245821,2118845,138340,1193,168,525565,136261,2757633,513]

theorem envBound6843 : H12AffineFastState.Bounded env6843 := by
  intro p hp
  have h : env6843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6842_6843 : H12AffineEnvironment.transform 15 34 env6842 = env6843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env6842 == env6843) = true)

theorem identity6843 : scanCanonicalize (H12AffineFastState.compose env6843 (packedSelected [3,5,10] rootPS)) = affineNative (2^(18+1) ^^^ 148496) := by decide +kernel

theorem selectedBound6843 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6844 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,0,34,131072,2185,148496,0,2097152,33,21740,136295,40,147537,2049,2245821,2118845,138340,1193,168,147693,136261,2117649,513]

theorem envBound6844 : H12AffineFastState.Bounded env6844 := by
  intro p hp
  have h : env6844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6843_6844 : H12AffineEnvironment.transform 18 148496 env6843 = env6844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 148496 env6843 == env6844) = true)

theorem identity6844 : scanCanonicalize (H12AffineFastState.compose env6844 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(20+1) ^^^ 132349) := by decide +kernel

theorem selectedBound6844 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env6845 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,0,34,131072,2185,148496,0,132349,33,21740,136295,40,147537,2049,16448,151616,138340,1193,168,147693,136261,152812,513]

theorem envBound6845 : H12AffineFastState.Bounded env6845 := by
  intro p hp
  have h : env6845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6844_6845 : H12AffineEnvironment.transform 20 132349 env6844 = env6845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132349 env6844 == env6845) = true)

theorem identity6845 : scanCanonicalize (H12AffineFastState.compose env6845 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6845 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env6846 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8,16384,0,34,131072,2081,148496,0,132181,33,21572,136295,40,147537,2049,16448,151616,138340,1025,0,147525,136261,152644,513]

theorem envBound6846 : H12AffineFastState.Bounded env6846 := by
  intro p hp
  have h : env6846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6845_6846 : H12AffineEnvironment.transform 6 40 env6845 = env6846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6845 == env6846) = true)

theorem identity6846 : scanCanonicalize (H12AffineFastState.compose env6846 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 3695) := by decide +kernel

theorem selectedBound6846 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env6847 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8,3695,0,34,131072,2081,133759,0,132181,33,6699,136295,40,134718,2049,3631,138799,138340,1025,0,134698,136261,137771,513]

theorem envBound6847 : H12AffineFastState.Bounded env6847 := by
  intro p hp
  have h : env6847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6846_6847 : H12AffineEnvironment.transform 13 3695 env6846 = env6847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3695 env6846 == env6847) = true)

theorem identity6847 : scanCanonicalize (H12AffineFastState.compose env6847 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 1663) := by decide +kernel

theorem selectedBound6847 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env6848 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,1663,8,3695,0,34,131072,2081,133759,0,132181,33,3156,131608,40,134718,2049,3631,133200,133659,1025,0,134698,131642,134228,513]

theorem envBound6848 : H12AffineFastState.Bounded env6848 := by
  intro p hp
  have h : env6848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6847_6848 : H12AffineEnvironment.transform 11 1663 env6847 = env6848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1663 env6847 == env6848) = true)

theorem identity6848 : scanCanonicalize (H12AffineFastState.compose env6848 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 571) := by decide +kernel

theorem selectedBound6848 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env6849 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,1663,8,3695,0,34,571,2081,2116,0,1646,33,3156,35,40,3077,2049,3631,2667,2080,1025,0,3089,1,3695,513]

theorem envBound6849 : H12AffineFastState.Bounded env6849 := by
  intro p hp
  have h : env6849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6848_6849 : H12AffineEnvironment.transform 16 571 env6848 = env6849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 571 env6848 == env6849) = true)

theorem identity6849 : scanCanonicalize (H12AffineFastState.compose env6849 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound6849 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6850 : List Nat := [2,4,8,16,32,64,40,85,512,1024,554,1663,8,1093,0,34,571,523,622,0,1646,33,1662,35,40,1583,555,1029,65,522,1025,0,1595,1,1093,513]

theorem envBound6850 : H12AffineFastState.Bounded env6850 := by
  intro p hp
  have h : env6850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6849_6850 : H12AffineEnvironment.transform 10 554 env6849 = env6850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env6849 == env6850) = true)

theorem identity6850 : scanCanonicalize (H12AffineFastState.compose env6850 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound6850 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6851 : List Nat := [2,4,8,16,32,64,40,85,43,1024,1,1108,8,1093,0,34,16,32,69,0,1093,33,1109,35,40,1028,0,1029,65,33,1025,0,1040,1,1093,42]

theorem envBound6851 : H12AffineFastState.Bounded env6851 := by
  intro p hp
  have h : env6851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6850_6851 : H12AffineEnvironment.transform 8 43 env6850 = env6851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env6850 == env6851) = true)

theorem identity6851 : scanCanonicalize (H12AffineFastState.compose env6851 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound6851 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6852 : List Nat := [2,4,8,16,0,64,8,85,11,1024,1,1108,8,1093,0,2,16,0,69,0,1093,1,1109,3,8,1028,0,1029,65,1,1025,0,1040,1,1093,10]

theorem envBound6852 : H12AffineFastState.Bounded env6852 := by
  intro p hp
  have h : env6852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6851_6852 : H12AffineEnvironment.transform 4 0 env6851 = env6852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6851 == env6852) = true)

def env6853 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,1,65536,131072,262144,524288,1,2097152,33,8388608,8979640,41,525377,327851,11031617,11158593,8981691,1193,65675,525565,8979610,2757633,66082]

theorem envBound6853 : H12AffineFastState.Bounded env6853 := by
  intro p hp
  have h : env6853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6839_6853 : H12AffineEnvironment.transform 12 161 env6839 = env6853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env6839 == env6853) = true)

theorem identity6853 : scanCanonicalize (H12AffineFastState.compose env6853 (packedSelected [0,2,4,6,7,9,12,13,14,15,17] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound6853 : packedSelected [0,2,4,6,7,9,12,13,14,15,17] rootPS < 2^1333 := by decide +kernel

def env6854 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,1,65536,5357,262144,524288,1,2097152,33,8388608,8979640,41,525377,327851,11031617,11030700,8981691,1193,65675,525565,8979610,2621676,66082]

theorem envBound6854 : H12AffineFastState.Bounded env6854 := by
  intro p hp
  have h : env6854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6853_6854 : H12AffineEnvironment.transform 16 5357 env6853 = env6854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env6853 == env6854) = true)

theorem identity6854 : scanCanonicalize (H12AffineFastState.compose env6854 (packedSelected [3,5,10,11,12,13,15,18] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound6854 : packedSelected [3,5,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env6855 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,1,65536,5357,2184,524288,1,2097152,33,8388608,8979640,41,525377,67619,11031617,11030700,8981691,1193,65675,525565,8979610,2621676,66082]

theorem envBound6855 : H12AffineFastState.Bounded env6855 := by
  intro p hp
  have h : env6855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6854_6855 : H12AffineEnvironment.transform 17 2184 env6854 = env6855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env6854 == env6855) = true)

theorem identity6855 : scanCanonicalize (H12AffineFastState.compose env6855 (packedSelected [3,5,10,13] rootPS)) = affineNative (2^(22+1) ^^^ 590898) := by decide +kernel

theorem selectedBound6855 : packedSelected [3,5,10,13] rootPS < 2^1333 := by decide +kernel

def env6856 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,1,65536,5357,2184,524288,1,2097152,33,590898,138,41,525377,67619,2183283,2184350,2185,1193,65675,525565,168,2621676,66082]

theorem envBound6856 : H12AffineFastState.Bounded env6856 := by
  intro p hp
  have h : env6856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6855_6856 : H12AffineEnvironment.transform 22 590898 env6855 = env6856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 590898 env6855 == env6856) = true)

theorem identity6856 : scanCanonicalize (H12AffineFastState.compose env6856 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(20+1) ^^^ 83103) := by decide +kernel

theorem selectedBound6856 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env6857 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,1,65536,5357,2184,524288,1,83103,33,590898,138,41,525377,67619,5356,4097,2185,1193,65675,525565,168,607347,66082]

theorem envBound6857 : H12AffineFastState.Bounded env6857 := by
  intro p hp
  have h : env6857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6856_6857 : H12AffineEnvironment.transform 20 83103 env6856 = env6857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83103 env6856 == env6857) = true)

theorem identity6857 : scanCanonicalize (H12AffineFastState.compose env6857 (packedSelected [0,3,5,6,7,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6857 : packedSelected [0,3,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env6858 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,9,16384,1,65536,5189,2080,524288,1,82999,33,590898,34,41,525377,67619,5188,4097,2081,1025,65571,525397,0,607347,66082]

theorem envBound6858 : H12AffineFastState.Bounded env6858 := by
  intro p hp
  have h : env6858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6857_6858 : H12AffineEnvironment.transform 6 40 env6857 = env6858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6857 == env6858) = true)

theorem identity6858 : scanCanonicalize (H12AffineFastState.compose env6858 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound6858 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env6859 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,9,16384,1,34,5189,2080,524288,1,17429,33,525328,34,41,525377,2049,5188,4097,2081,1025,1,525397,0,541777,512]

theorem envBound6859 : H12AffineFastState.Bounded env6859 := by
  intro p hp
  have h : env6859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6858_6859 : H12AffineEnvironment.transform 15 34 env6858 = env6859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env6858 == env6859) = true)

def env6860 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,9,16384,1,34,5189,2080,1104,1,17429,33,64,34,41,17,2049,5188,4097,2081,1025,1,5,0,16385,512]

theorem envBound6860 : H12AffineFastState.Bounded env6860 := by
  intro p hp
  have h : env6860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6859_6860 : H12AffineEnvironment.transform 18 1104 env6859 = env6860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env6859 == env6860) = true)

theorem identity6860 : scanCanonicalize (H12AffineFastState.compose env6860 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 80) := by decide +kernel

theorem selectedBound6860 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6861 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,9,80,1,34,5189,2080,1104,1,1093,33,64,34,41,17,2049,5188,4097,2081,1025,1,5,0,81,512]

theorem envBound6861 : H12AffineFastState.Bounded env6861 := by
  intro p hp
  have h : env6861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6860_6861 : H12AffineEnvironment.transform 13 80 env6860 = env6861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 80 env6860 == env6861) = true)

theorem identity6861 : scanCanonicalize (H12AffineFastState.compose env6861 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1086) := by decide +kernel

theorem selectedBound6861 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6862 : List Nat := [2,4,8,16,32,64,40,85,512,1024,1086,4096,9,80,1,34,5189,1054,1104,1,1093,33,64,34,41,17,1087,5188,4097,1055,1025,1,5,0,81,512]

theorem envBound6862 : H12AffineFastState.Bounded env6862 := by
  intro p hp
  have h : env6862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6861_6862 : H12AffineEnvironment.transform 10 1086 env6861 = env6862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1086 env6861 == env6862) = true)

theorem identity6862 : scanCanonicalize (H12AffineFastState.compose env6862 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound6862 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env6863 : List Nat := [2,4,8,16,32,33,40,52,512,1024,1086,4096,9,49,1,34,5156,1054,1073,1,1060,33,33,34,41,17,1087,5157,4097,1055,1025,1,5,0,48,512]

theorem envBound6863 : H12AffineFastState.Bounded env6863 := by
  intro p hp
  have h : env6863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6862_6863 : H12AffineEnvironment.transform 5 33 env6862 = env6863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env6862 == env6863) = true)

theorem identity6863 : scanCanonicalize (H12AffineFastState.compose env6863 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound6863 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env6864 : List Nat := [2,4,8,16,27,26,19,15,512,1024,1029,4096,9,10,1,25,5151,1054,1034,1,1055,26,26,25,18,17,1028,5150,4097,1055,1025,1,5,0,11,512]

theorem envBound6864 : H12AffineFastState.Bounded env6864 := by
  intro p hp
  have h : env6864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6863_6864 : H12AffineEnvironment.transform 4 27 env6863 = env6864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env6863 == env6864) = true)

def env6865 : List Nat := [2,4,8,16,27,26,19,15,512,1024,1029,1044,9,10,1,25,11,1054,1034,1,1055,26,26,25,18,17,1028,10,1045,1055,1025,1,5,0,11,512]

theorem envBound6865 : H12AffineFastState.Bounded env6865 := by
  intro p hp
  have h : env6865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6864_6865 : H12AffineEnvironment.transform 11 1044 env6864 = env6865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env6864 == env6865) = true)

theorem identity6865 : scanCanonicalize (H12AffineFastState.compose env6865 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 518) := by decide +kernel

theorem selectedBound6865 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6866 : List Nat := [2,4,8,16,27,26,19,15,512,518,515,530,9,10,1,25,11,536,524,1,537,26,26,25,18,17,514,10,531,537,519,1,5,0,11,512]

theorem envBound6866 : H12AffineFastState.Bounded env6866 := by
  intro p hp
  have h : env6866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6865_6866 : H12AffineEnvironment.transform 9 518 env6865 = env6866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 518 env6865 == env6866) = true)

def env6867 : List Nat := [2,4,8,16,27,26,19,15,24,30,27,10,9,10,1,25,11,0,20,1,1,26,26,25,18,17,26,10,11,1,31,1,5,0,11,24]

theorem envBound6867 : H12AffineFastState.Bounded env6867 := by
  intro p hp
  have h : env6867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6866_6867 : H12AffineEnvironment.transform 8 24 env6866 = env6867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 24 env6866 == env6867) = true)

theorem identity6867 : scanCanonicalize (H12AffineFastState.compose env6867 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound6867 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6868 : List Nat := [2,4,8,6,13,12,5,15,14,8,13,10,9,10,1,15,11,0,2,1,1,12,12,15,4,7,12,10,11,1,9,1,5,0,11,14]

theorem envBound6868 : H12AffineFastState.Bounded env6868 := by
  intro p hp
  have h : env6868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6867_6868 : H12AffineEnvironment.transform 3 6 env6867 = env6868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env6867 == env6868) = true)

def leafEnv6868 : List Nat := [2,4,8,6,13,12,5,15,14,8,13,10,9,10,1,15,11,0,2,1,1,12,12,15,2,4,1,7,12,10,11,1,9,1,5,0,15,2,11,14,1,1,0]

def active6868 : List Nat := [0,1,2]

def tree6868 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6868 : H12WitnessSearch.Good tree6868 := H12GlobalWitnessIndex.good

theorem leafIdentity6868 : H12AffineFastState.composeSystem env6868 rootObs = leafEnv6868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6868 rootObs == leafEnv6868) = true)

theorem terminalChecked6868 : H12PackedTerminal.terminalCheckFast leafEnv6868 active6868 tree6868 = true := by decide +kernel

def env6869 : List Nat := [2,4,8,16,27,26,19,15,25,31,26,11,9,10,1,25,11,1,21,1,0,26,26,25,18,17,27,10,10,0,30,1,5,0,11,25]

theorem envBound6869 : H12AffineFastState.Bounded env6869 := by
  intro p hp
  have h : env6869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6866_6869 : H12AffineEnvironment.transform 8 25 env6866 = env6869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 25 env6866 == env6869) = true)

theorem identity6869 : scanCanonicalize (H12AffineFastState.compose env6869 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound6869 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6870 : List Nat := [2,4,8,5,14,15,6,15,12,10,15,11,9,10,1,12,11,1,0,1,0,15,15,12,7,4,14,10,10,0,11,1,5,0,11,12]

theorem envBound6870 : H12AffineFastState.Bounded env6870 := by
  intro p hp
  have h : env6870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6869_6870 : H12AffineEnvironment.transform 3 5 env6869 = env6870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env6869 == env6870) = true)

def leafEnv6870 : List Nat := [2,4,8,5,14,15,6,15,12,10,15,11,9,10,1,12,11,1,0,1,0,15,15,12,0,7,1,4,14,10,10,0,11,1,5,0,15,2,11,12,1,0,0]

def active6870 : List Nat := [0,1,2]

def tree6870 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6870 : H12WitnessSearch.Good tree6870 := H12GlobalWitnessIndex.good

theorem leafIdentity6870 : H12AffineFastState.composeSystem env6870 rootObs = leafEnv6870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6870 rootObs == leafEnv6870) = true)

theorem terminalChecked6870 : H12PackedTerminal.terminalCheckFast leafEnv6870 active6870 tree6870 = true := by decide +kernel

def env6871 : List Nat := [2,4,8,16,27,26,19,15,512,1024,1029,1045,9,10,1,25,10,1054,1034,1,1055,26,26,25,18,17,1028,11,1044,1055,1025,1,5,0,11,512]

theorem envBound6871 : H12AffineFastState.Bounded env6871 := by
  intro p hp
  have h : env6871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6864_6871 : H12AffineEnvironment.transform 11 1045 env6864 = env6871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env6864 == env6871) = true)

theorem identity6871 : scanCanonicalize (H12AffineFastState.compose env6871 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 25) := by decide +kernel

theorem selectedBound6871 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6872 : List Nat := [2,4,8,16,27,26,19,15,25,1024,1029,1045,9,10,1,25,10,1054,1034,1,1055,26,26,25,18,17,1028,11,1044,1055,1025,1,5,0,11,25]

theorem envBound6872 : H12AffineFastState.Bounded env6872 := by
  intro p hp
  have h : env6872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6871_6872 : H12AffineEnvironment.transform 8 25 env6871 = env6872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 25 env6871 == env6872) = true)

def env6873 : List Nat := [2,4,8,16,27,26,19,15,25,28,25,9,9,10,1,25,10,2,22,1,3,26,26,25,18,17,24,11,8,3,29,1,5,0,11,25]

theorem envBound6873 : H12AffineFastState.Bounded env6873 := by
  intro p hp
  have h : env6873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6872_6873 : H12AffineEnvironment.transform 9 28 env6872 = env6873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 28 env6872 == env6873) = true)

theorem identity6873 : scanCanonicalize (H12AffineFastState.compose env6873 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound6873 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6874 : List Nat := [2,4,8,5,14,15,6,15,12,9,12,9,9,10,1,12,10,2,3,1,3,15,15,12,7,4,13,11,8,3,8,1,5,0,11,12]

theorem envBound6874 : H12AffineFastState.Bounded env6874 := by
  intro p hp
  have h : env6874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6873_6874 : H12AffineEnvironment.transform 3 5 env6873 = env6874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env6873 == env6874) = true)

def leafEnv6874 : List Nat := [2,4,8,5,14,15,6,15,12,9,12,9,9,10,1,12,10,2,3,1,3,15,15,12,3,7,1,4,13,11,8,3,8,1,5,0,15,2,11,12,1,3,0]

def active6874 : List Nat := [0,1,2]

def tree6874 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6874 : H12WitnessSearch.Good tree6874 := H12GlobalWitnessIndex.good

theorem leafIdentity6874 : H12AffineFastState.composeSystem env6874 rootObs = leafEnv6874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6874 rootObs == leafEnv6874) = true)

theorem terminalChecked6874 : H12PackedTerminal.terminalCheckFast leafEnv6874 active6874 tree6874 = true := by decide +kernel

def env6875 : List Nat := [2,4,8,16,27,26,19,15,25,29,24,8,9,10,1,25,10,3,23,1,2,26,26,25,18,17,25,11,9,2,28,1,5,0,11,25]

theorem envBound6875 : H12AffineFastState.Bounded env6875 := by
  intro p hp
  have h : env6875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6872_6875 : H12AffineEnvironment.transform 9 29 env6872 = env6875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 29 env6872 == env6875) = true)

theorem identity6875 : scanCanonicalize (H12AffineFastState.compose env6875 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound6875 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6876 : List Nat := [2,4,8,7,12,13,4,15,14,10,15,8,9,10,1,14,10,3,0,1,2,13,13,14,5,6,14,11,9,2,11,1,5,0,11,14]

theorem envBound6876 : H12AffineFastState.Bounded env6876 := by
  intro p hp
  have h : env6876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6875_6876 : H12AffineEnvironment.transform 3 7 env6875 = env6876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env6875 == env6876) = true)

def leafEnv6876 : List Nat := [2,4,8,7,12,13,4,15,14,10,15,8,9,10,1,14,10,3,0,1,2,13,13,14,0,5,1,6,14,11,9,2,11,1,5,0,15,2,11,14,1,2,0]

def active6876 : List Nat := [0,1,2]

def tree6876 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6876 : H12WitnessSearch.Good tree6876 := H12GlobalWitnessIndex.good

theorem leafIdentity6876 : H12AffineFastState.composeSystem env6876 rootObs = leafEnv6876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6876 rootObs == leafEnv6876) = true)

theorem terminalChecked6876 : H12PackedTerminal.terminalCheckFast leafEnv6876 active6876 tree6876 = true := by decide +kernel

def env6877 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,9,16384,1,34,5189,2080,1105,1,17429,33,65,34,41,16,2049,5188,4097,2081,1025,1,4,0,16384,512]

theorem envBound6877 : H12AffineFastState.Bounded env6877 := by
  intro p hp
  have h : env6877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6859_6877 : H12AffineEnvironment.transform 18 1105 env6859 = env6877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env6859 == env6877) = true)

theorem identity6877 : scanCanonicalize (H12AffineFastState.compose env6877 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1093) := by decide +kernel

theorem selectedBound6877 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6878 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,9,1093,1,34,5189,2080,1105,1,80,33,65,34,41,16,2049,5188,4097,2081,1025,1,4,0,1093,512]

theorem envBound6878 : H12AffineFastState.Bounded env6878 := by
  intro p hp
  have h : env6878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6877_6878 : H12AffineEnvironment.transform 13 1093 env6877 = env6878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1093 env6877 == env6878) = true)

theorem identity6878 : scanCanonicalize (H12AffineFastState.compose env6878 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound6878 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6879 : List Nat := [2,4,8,16,32,64,40,85,512,1024,1087,4096,9,1093,1,34,5189,1055,1105,1,80,33,65,34,41,16,1086,5188,4097,1054,1025,1,4,0,1093,512]

theorem envBound6879 : H12AffineFastState.Bounded env6879 := by
  intro p hp
  have h : env6879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6878_6879 : H12AffineEnvironment.transform 10 1087 env6878 = env6879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env6878 == env6879) = true)

theorem identity6879 : scanCanonicalize (H12AffineFastState.compose env6879 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound6879 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env6880 : List Nat := [2,4,8,16,32,11,40,30,512,1024,1087,4096,9,1038,1,34,5134,1055,1050,1,27,33,10,34,41,16,1086,5135,4097,1054,1025,1,4,0,1038,512]

theorem envBound6880 : H12AffineFastState.Bounded env6880 := by
  intro p hp
  have h : env6880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6879_6880 : H12AffineEnvironment.transform 5 11 env6879 = env6880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env6879 == env6880) = true)

theorem identity6880 : scanCanonicalize (H12AffineFastState.compose env6880 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound6880 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env6881 : List Nat := [2,4,8,16,17,11,25,30,512,1024,1038,4096,9,1038,1,19,5134,1055,1050,1,27,16,10,19,24,16,1039,5135,4097,1054,1025,1,4,0,1038,512]

theorem envBound6881 : H12AffineFastState.Bounded env6881 := by
  intro p hp
  have h : env6881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6880_6881 : H12AffineEnvironment.transform 4 17 env6880 = env6881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env6880 == env6881) = true)

def env6882 : List Nat := [2,4,8,16,17,11,25,30,512,1024,1038,1044,9,1038,1,19,26,1055,1050,1,27,16,10,19,24,16,1039,27,1045,1054,1025,1,4,0,1038,512]

theorem envBound6882 : H12AffineFastState.Bounded env6882 := by
  intro p hp
  have h : env6882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6881_6882 : H12AffineEnvironment.transform 11 1044 env6881 = env6882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env6881 == env6882) = true)

theorem identity6882 : scanCanonicalize (H12AffineFastState.compose env6882 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 541) := by decide +kernel

theorem selectedBound6882 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6883 : List Nat := [2,4,8,16,17,11,25,30,512,541,531,521,9,531,1,19,26,514,519,1,27,16,10,19,24,16,530,27,520,515,540,1,4,0,531,512]

theorem envBound6883 : H12AffineFastState.Bounded env6883 := by
  intro p hp
  have h : env6883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6882_6883 : H12AffineEnvironment.transform 9 541 env6882 = env6883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 541 env6882 == env6883) = true)

def env6884 : List Nat := [2,4,8,16,17,11,25,30,16,13,3,25,9,3,1,19,26,18,23,1,27,16,10,19,24,16,2,27,24,19,12,1,4,0,3,16]

theorem envBound6884 : H12AffineFastState.Bounded env6884 := by
  intro p hp
  have h : env6884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6883_6884 : H12AffineEnvironment.transform 8 16 env6883 = env6884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env6883 == env6884) = true)

theorem identity6884 : scanCanonicalize (H12AffineFastState.compose env6884 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound6884 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6885 : List Nat := [2,4,8,7,6,11,14,9,7,13,3,14,9,3,1,4,13,5,0,1,12,7,10,4,15,7,2,12,15,4,12,1,4,0,3,7]

theorem envBound6885 : H12AffineFastState.Bounded env6885 := by
  intro p hp
  have h : env6885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6884_6885 : H12AffineEnvironment.transform 3 7 env6884 = env6885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env6884 == env6885) = true)

def leafEnv6885 : List Nat := [2,4,8,7,6,11,14,9,7,13,3,14,9,3,1,4,13,5,0,1,12,7,10,4,0,15,1,7,2,12,15,4,12,1,4,0,8,2,3,7,1,13,0]

def active6885 : List Nat := [0,1,2]

def tree6885 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6885 : H12WitnessSearch.Good tree6885 := H12GlobalWitnessIndex.good

theorem leafIdentity6885 : H12AffineFastState.composeSystem env6885 rootObs = leafEnv6885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6885 rootObs == leafEnv6885) = true)

theorem terminalChecked6885 : H12PackedTerminal.terminalCheckFast leafEnv6885 active6885 tree6885 = true := by decide +kernel

def env6886 : List Nat := [2,4,8,16,17,11,25,30,17,12,2,24,9,2,1,19,26,19,22,1,27,16,10,19,24,16,3,27,25,18,13,1,4,0,2,17]

theorem envBound6886 : H12AffineFastState.Bounded env6886 := by
  intro p hp
  have h : env6886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6883_6886 : H12AffineEnvironment.transform 8 17 env6883 = env6886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env6883 == env6886) = true)

theorem identity6886 : scanCanonicalize (H12AffineFastState.compose env6886 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound6886 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6887 : List Nat := [2,4,8,4,5,11,13,10,5,12,2,12,9,2,1,7,14,7,2,1,15,4,10,7,12,4,3,15,13,6,13,1,4,0,2,5]

theorem envBound6887 : H12AffineFastState.Bounded env6887 := by
  intro p hp
  have h : env6887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6886_6887 : H12AffineEnvironment.transform 3 4 env6886 = env6887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env6886 == env6887) = true)

def leafEnv6887 : List Nat := [2,4,8,4,5,11,13,10,5,12,2,12,9,2,1,7,14,7,2,1,15,4,10,7,2,12,1,4,3,15,13,6,13,1,4,0,11,2,2,5,1,14,0]

def active6887 : List Nat := [0,1,2]

def tree6887 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6887 : H12WitnessSearch.Good tree6887 := H12GlobalWitnessIndex.good

theorem leafIdentity6887 : H12AffineFastState.composeSystem env6887 rootObs = leafEnv6887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6887 rootObs == leafEnv6887) = true)

theorem terminalChecked6887 : H12PackedTerminal.terminalCheckFast leafEnv6887 active6887 tree6887 = true := by decide +kernel

def env6888 : List Nat := [2,4,8,16,17,11,25,30,512,1024,1038,1045,9,1038,1,19,27,1055,1050,1,27,16,10,19,24,16,1039,26,1044,1054,1025,1,4,0,1038,512]

theorem envBound6888 : H12AffineFastState.Bounded env6888 := by
  intro p hp
  have h : env6888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6881_6888 : H12AffineEnvironment.transform 11 1045 env6881 = env6888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env6881 == env6888) = true)

theorem identity6888 : scanCanonicalize (H12AffineFastState.compose env6888 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 19) := by decide +kernel

theorem selectedBound6888 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6889 : List Nat := [2,4,8,16,17,11,25,30,19,1024,1038,1045,9,1038,1,19,27,1055,1050,1,27,16,10,19,24,16,1039,26,1044,1054,1025,1,4,0,1038,19]

theorem envBound6889 : H12AffineFastState.Bounded env6889 := by
  intro p hp
  have h : env6889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6888_6889 : H12AffineEnvironment.transform 8 19 env6888 = env6889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 19 env6888 == env6889) = true)

def env6890 : List Nat := [2,4,8,16,17,11,25,30,19,12,2,25,9,2,1,19,27,19,22,1,27,16,10,19,24,16,3,26,24,18,13,1,4,0,2,19]

theorem envBound6890 : H12AffineFastState.Bounded env6890 := by
  intro p hp
  have h : env6890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6889_6890 : H12AffineEnvironment.transform 9 12 env6889 = env6890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 12 env6889 == env6890) = true)

theorem identity6890 : scanCanonicalize (H12AffineFastState.compose env6890 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound6890 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6891 : List Nat := [2,4,8,6,7,11,15,8,5,12,2,15,9,2,1,5,13,5,0,1,13,6,10,5,14,6,3,12,14,4,13,1,4,0,2,5]

theorem envBound6891 : H12AffineFastState.Bounded env6891 := by
  intro p hp
  have h : env6891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6890_6891 : H12AffineEnvironment.transform 3 6 env6890 = env6891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env6890 == env6891) = true)

def leafEnv6891 : List Nat := [2,4,8,6,7,11,15,8,5,12,2,15,9,2,1,5,13,5,0,1,13,6,10,5,0,14,1,6,3,12,14,4,13,1,4,0,9,2,2,5,1,12,0]

def active6891 : List Nat := [0,1,2]

def tree6891 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6891 : H12WitnessSearch.Good tree6891 := H12GlobalWitnessIndex.good

theorem leafIdentity6891 : H12AffineFastState.composeSystem env6891 rootObs = leafEnv6891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6891 rootObs == leafEnv6891) = true)

theorem terminalChecked6891 : H12PackedTerminal.terminalCheckFast leafEnv6891 active6891 tree6891 = true := by decide +kernel

def env6892 : List Nat := [2,4,8,16,17,11,25,30,19,13,3,24,9,3,1,19,27,18,23,1,27,16,10,19,24,16,2,26,25,19,12,1,4,0,3,19]

theorem envBound6892 : H12AffineFastState.Bounded env6892 := by
  intro p hp
  have h : env6892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6889_6892 : H12AffineEnvironment.transform 9 13 env6889 = env6892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 13 env6889 == env6892) = true)

theorem identity6892 : scanCanonicalize (H12AffineFastState.compose env6892 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound6892 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6893 : List Nat := [2,4,8,4,5,11,13,10,7,13,3,12,9,3,1,7,15,6,3,1,15,4,10,7,12,4,2,14,13,7,12,1,4,0,3,7]

theorem envBound6893 : H12AffineFastState.Bounded env6893 := by
  intro p hp
  have h : env6893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6892_6893 : H12AffineEnvironment.transform 3 4 env6892 = env6893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env6892 == env6893) = true)

def leafEnv6893 : List Nat := [2,4,8,4,5,11,13,10,7,13,3,12,9,3,1,7,15,6,3,1,15,4,10,7,3,12,1,4,2,14,13,7,12,1,4,0,11,2,3,7,1,14,0]

def active6893 : List Nat := [0,1,2]

def tree6893 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6893 : H12WitnessSearch.Good tree6893 := H12GlobalWitnessIndex.good

theorem leafIdentity6893 : H12AffineFastState.composeSystem env6893 rootObs = leafEnv6893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6893 rootObs == leafEnv6893) = true)

theorem terminalChecked6893 : H12PackedTerminal.terminalCheckFast leafEnv6893 active6893 tree6893 = true := by decide +kernel

def env6894 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,4194304,8388608,8987673,8328,525377,335882,11031617,11158593,13184059,1193,73770,525565,13181978,6951969,74371]

theorem envBound6894 : H12AffineFastState.Bounded env6894 := by
  intro p hp
  have h : env6894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6837_6894 : H12AffineEnvironment.transform 34 6951969 env6837 = env6894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 6951969 env6837 == env6894) = true)

theorem identity6894 : scanCanonicalize (H12AffineFastState.compose env6894 (packedSelected [13,21] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound6894 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env6895 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,73890,8388608,8987673,8328,525377,335882,11031617,11158593,8916121,1193,73770,525565,8914104,2831491,74371]

theorem envBound6895 : H12AffineFastState.Bounded env6895 := by
  intro p hp
  have h : env6895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6894_6895 : H12AffineEnvironment.transform 21 73890 env6894 = env6895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env6894 == env6895) = true)

theorem identity6895 : scanCanonicalize (H12AffineFastState.compose env6895 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound6895 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env6896 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,8323,131072,262144,524288,8352,2097152,33,8388608,8914074,8328,525377,262281,11031617,11158593,8916121,1193,169,525565,8914104,2757632,512]

theorem envBound6896 : H12AffineFastState.Bounded env6896 := by
  intro p hp
  have h : env6896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6895_6896 : H12AffineEnvironment.transform 15 8323 env6895 = env6896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env6895 == env6896) = true)

theorem identity6896 : scanCanonicalize (H12AffineFastState.compose env6896 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17597) := by decide +kernel

theorem selectedBound6896 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6897 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,8323,131072,262144,524288,8352,17597,33,8388608,8914074,8328,525377,262281,8917244,9044220,8916121,1193,169,525565,8914104,676029,512]

theorem envBound6897 : H12AffineFastState.Bounded env6897 := by
  intro p hp
  have h : env6897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6896_6897 : H12AffineEnvironment.transform 20 17597 env6896 = env6897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17597 env6896 == env6897) = true)

theorem identity6897 : scanCanonicalize (H12AffineFastState.compose env6897 (packedSelected [11,12,13,15,18] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound6897 : packedSelected [11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env6898 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,8323,131072,2185,524288,8352,17597,33,8388608,8914074,8328,525377,2048,8917244,9044220,8916121,1193,169,525565,8914104,676029,512]

theorem envBound6898 : H12AffineFastState.Bounded env6898 := by
  intro p hp
  have h : env6898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6897_6898 : H12AffineEnvironment.transform 17 2185 env6897 = env6898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env6897 == env6898) = true)

theorem identity6898 : scanCanonicalize (H12AffineFastState.compose env6898 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound6898 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env6899 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,0,35,131072,2185,524288,0,17597,33,8388608,8914074,40,525377,2048,8917244,9044220,8916121,1193,169,525565,8914104,676029,512]

theorem envBound6899 : H12AffineFastState.Bounded env6899 := by
  intro p hp
  have h : env6899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6898_6899 : H12AffineEnvironment.transform 12 160 env6898 = env6899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env6898 == env6899) = true)

theorem identity6899 : scanCanonicalize (H12AffineFastState.compose env6899 (packedSelected [1,3,5,8,12,13] rootPS)) = affineNative (2^(22+1) ^^^ 659708) := by decide +kernel

theorem selectedBound6899 : packedSelected [1,3,5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env6900 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,0,35,131072,2185,524288,0,17597,33,659708,136294,40,525377,2048,131072,4096,138341,1193,169,525565,136260,676029,512]

theorem envBound6900 : H12AffineFastState.Bounded env6900 := by
  intro p hp
  have h : env6900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6899_6900 : H12AffineEnvironment.transform 22 659708 env6899 = env6900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 659708 env6899 == env6900) = true)

theorem identity6900 : scanCanonicalize (H12AffineFastState.compose env6900 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound6900 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env6901 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,0,35,5357,2185,524288,0,17597,33,525329,139,40,525377,2048,5357,4096,2184,1193,169,525565,169,541776,512]

theorem envBound6901 : H12AffineFastState.Bounded env6901 := by
  intro p hp
  have h : env6901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6900_6901 : H12AffineEnvironment.transform 16 5357 env6900 = env6901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env6900 == env6901) = true)

theorem identity6901 : scanCanonicalize (H12AffineFastState.compose env6901 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1692) := by decide +kernel

theorem selectedBound6901 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6902 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,1692,0,35,5357,2185,524288,0,545,33,525329,139,40,525377,2048,5357,4096,2184,1193,169,525565,169,525004,512]

theorem envBound6902 : H12AffineFastState.Bounded env6902 := by
  intro p hp
  have h : env6902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6901_6902 : H12AffineEnvironment.transform 13 1692 env6901 = env6902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1692 env6901 == env6902) = true)

theorem identity6902 : scanCanonicalize (H12AffineFastState.compose env6902 (packedSelected [2,6] rootPS)) = affineNative (2^(18+1) ^^^ 1104) := by decide +kernel

theorem selectedBound6902 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env6903 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,1692,0,35,5357,2185,1104,0,545,33,65,139,40,17,2048,5357,4096,2184,1193,169,173,169,1692,512]

theorem envBound6903 : H12AffineFastState.Bounded env6903 := by
  intro p hp
  have h : env6903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6902_6903 : H12AffineEnvironment.transform 18 1104 env6902 = env6903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env6902 == env6903) = true)

theorem identity6903 : scanCanonicalize (H12AffineFastState.compose env6903 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 253) := by decide +kernel

theorem selectedBound6903 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6904 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,160,609,0,35,4112,2185,173,0,545,33,65,139,40,17,2048,4112,4096,2184,84,169,173,169,609,512]

theorem envBound6904 : H12AffineFastState.Bounded env6904 := by
  intro p hp
  have h : env6904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6903_6904 : H12AffineEnvironment.transform 9 253 env6903 = env6904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 253 env6903 == env6904) = true)

theorem identity6904 : scanCanonicalize (H12AffineFastState.compose env6904 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 74) := by decide +kernel

theorem selectedBound6904 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6905 : List Nat := [2,4,8,16,32,64,128,253,512,253,74,4096,160,609,0,35,4112,195,173,0,545,33,65,139,40,17,74,4112,4096,194,84,169,173,169,609,512]

theorem envBound6905 : H12AffineFastState.Bounded env6905 := by
  intro p hp
  have h : env6905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6904_6905 : H12AffineEnvironment.transform 10 74 env6904 = env6905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 74 env6904 == env6905) = true)

theorem identity6905 : scanCanonicalize (H12AffineFastState.compose env6905 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 83) := by decide +kernel

theorem selectedBound6905 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env6906 : List Nat := [2,4,8,16,32,64,83,46,512,46,74,4096,115,609,0,35,4112,16,126,0,545,33,65,88,40,17,74,4112,4096,17,84,122,126,122,609,512]

theorem envBound6906 : H12AffineFastState.Bounded env6906 := by
  intro p hp
  have h : env6906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6905_6906 : H12AffineEnvironment.transform 6 83 env6905 = env6906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 83 env6905 == env6906) = true)

theorem identity6906 : scanCanonicalize (H12AffineFastState.compose env6906 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 58) := by decide +kernel

theorem selectedBound6906 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env6907 : List Nat := [2,4,8,16,32,64,83,46,512,46,74,58,115,609,0,35,42,16,126,0,545,33,65,88,40,17,74,42,58,17,84,122,126,122,609,512]

theorem envBound6907 : H12AffineFastState.Bounded env6907 := by
  intro p hp
  have h : env6907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6906_6907 : H12AffineEnvironment.transform 11 58 env6906 = env6907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 58 env6906 == env6907) = true)

theorem identity6907 : scanCanonicalize (H12AffineFastState.compose env6907 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 107) := by decide +kernel

theorem selectedBound6907 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env6908 : List Nat := [2,4,8,16,32,64,83,46,107,46,74,58,115,10,0,35,42,16,126,0,74,33,65,88,40,17,74,42,58,17,84,122,126,122,10,107]

theorem envBound6908 : H12AffineFastState.Bounded env6908 := by
  intro p hp
  have h : env6908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6907_6908 : H12AffineEnvironment.transform 8 107 env6907 = env6908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 107 env6907 == env6908) = true)

theorem identity6908 : scanCanonicalize (H12AffineFastState.compose env6908 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 52) := by decide +kernel

theorem selectedBound6908 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6909 : List Nat := [2,4,8,16,32,52,39,46,31,46,62,58,7,10,0,35,42,16,10,0,62,33,53,44,40,17,62,42,58,17,32,14,10,14,10,31]

theorem envBound6909 : H12AffineFastState.Bounded env6909 := by
  intro p hp
  have h : env6909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6908_6909 : H12AffineEnvironment.transform 5 52 env6908 = env6909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 52 env6908 == env6909) = true)

theorem identity6909 : scanCanonicalize (H12AffineFastState.compose env6909 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound6909 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env6910 : List Nat := [2,4,8,11,32,47,39,46,4,46,37,33,7,10,0,35,42,11,10,0,37,33,46,44,40,10,37,42,33,10,32,14,10,14,10,4]

theorem envBound6910 : H12AffineFastState.Bounded env6910 := by
  intro p hp
  have h : env6910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6909_6910 : H12AffineEnvironment.transform 3 11 env6909 = env6910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env6909 == env6910) = true)

def env6911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,4194304,8388608,8988132,8328,525376,335883,11031616,11158592,13184455,1364,73770,525568,13182438,34359738368,74370]

theorem envBound6911 : H12AffineFastState.Bounded env6911 := by
  intro p hp
  have h : env6911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6710_6911 : H12AffineEnvironment.transform 14 8353 env6710 = env6911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env6710 == env6911) = true)

theorem identity6911 : scanCanonicalize (H12AffineFastState.compose env6911 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound6911 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env6912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,477,8388608,8988132,8328,525376,335883,11031616,11158592,8989722,1364,73770,525568,8987707,34359738368,74370]

theorem envBound6912 : H12AffineFastState.Bounded env6912 := by
  intro p hp
  have h : env6912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6911_6912 : H12AffineEnvironment.transform 21 477 env6911 = env6912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env6911 == env6912) = true)

def env6913 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,373,8388608,8987980,8224,525376,335883,11031616,11158592,8989722,1364,73770,525568,8987707,34359738368,74282]

theorem envBound6913 : H12AffineFastState.Bounded env6913 := by
  intro p hp
  have h : env6913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6912_6913 : H12AffineEnvironment.transform 6 40 env6912 = env6913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6912 == env6913) = true)

theorem identity6913 : scanCanonicalize (H12AffineFastState.compose env6913 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(34+1) ^^^ 82294) := by decide +kernel

theorem selectedBound6913 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env6914 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,373,8388608,8987980,8224,525376,335883,11031616,11158592,8989722,1364,73770,525568,8987707,82294,74282]

theorem envBound6914 : H12AffineFastState.Bounded env6914 := by
  intro p hp
  have h : env6914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6913_6914 : H12AffineEnvironment.transform 34 82294 env6913 = env6914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 82294 env6913 == env6914) = true)

theorem identity6914 : scanCanonicalize (H12AffineFastState.compose env6914 (packedSelected [11,18] rootPS)) = affineNative (2^(15+1) ^^^ 374) := by decide +kernel

theorem selectedBound6914 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env6915 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8201,374,131072,262144,524288,8201,2097152,373,8388608,8922170,8224,525376,270717,11031616,11158592,8924524,1364,8540,525568,8922445,16384,9052]

theorem envBound6915 : H12AffineFastState.Bounded env6915 := by
  intro p hp
  have h : env6915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6914_6915 : H12AffineEnvironment.transform 15 374 env6914 = env6915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 374 env6914 == env6915) = true)

theorem identity6915 : scanCanonicalize (H12AffineFastState.compose env6915 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound6915 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env6916 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8201,374,5393,262144,524288,8201,2097152,373,8388608,8922170,8224,525376,270717,11031616,11030865,8924524,1364,8540,525568,8922445,16384,9052]

theorem envBound6916 : H12AffineFastState.Bounded env6916 := by
  intro p hp
  have h : env6916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6915_6916 : H12AffineEnvironment.transform 16 5393 env6915 = env6916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env6915 == env6916) = true)

theorem identity6916 : scanCanonicalize (H12AffineFastState.compose env6916 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(22+1) ^^^ 525328) := by decide +kernel

theorem selectedBound6916 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env6917 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8201,374,5393,262144,524288,8201,2097152,373,525328,8234,8224,525376,270717,2117712,2118977,10620,1364,8540,525568,8541,16384,9052]

theorem envBound6917 : H12AffineFastState.Bounded env6917 := by
  intro p hp
  have h : env6917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6916_6917 : H12AffineEnvironment.transform 22 525328 env6916 = env6917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525328 env6916 == env6917) = true)

theorem identity6917 : scanCanonicalize (H12AffineFastState.compose env6917 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 549145) := by decide +kernel

theorem selectedBound6917 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env6918 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8201,374,5393,262144,524288,8201,549145,373,525328,8234,8224,525376,270717,536905,537688,10620,1364,8540,525568,8541,16384,9052]

theorem envBound6918 : H12AffineFastState.Bounded env6918 := by
  intro p hp
  have h : env6918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6917_6918 : H12AffineEnvironment.transform 20 549145 env6917 = env6918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 549145 env6917 == env6918) = true)

theorem identity6918 : scanCanonicalize (H12AffineFastState.compose env6918 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound6918 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6919 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,349,16384,340,374,5393,262144,524288,340,540740,373,525328,375,381,525376,262176,528404,529669,2081,1364,1,525568,0,16384,513]

theorem envBound6919 : H12AffineFastState.Bounded env6919 := by
  intro p hp
  have h : env6919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6918_6919 : H12AffineEnvironment.transform 12 349 env6918 = env6919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env6918 == env6919) = true)

theorem identity6919 : scanCanonicalize (H12AffineFastState.compose env6919 (packedSelected [2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound6919 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env6920 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8,16384,1,35,5188,262144,524288,1,540740,32,525328,34,40,525376,262176,528404,529488,2081,1025,1,525397,0,16384,513]

theorem envBound6920 : H12AffineFastState.Bounded env6920 := by
  intro p hp
  have h : env6920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6919_6920 : H12AffineEnvironment.transform 7 85 env6919 = env6920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env6919 == env6920) = true)

theorem identity6920 : scanCanonicalize (H12AffineFastState.compose env6920 (packedSelected [3,5,10] rootPS)) = affineNative (2^(18+1) ^^^ 20565) := by decide +kernel

theorem selectedBound6920 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6921 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8,16384,1,35,5188,262144,20565,1,4113,32,21573,34,40,21525,262176,16449,17413,2081,1025,1,21504,0,16384,513]

theorem envBound6921 : H12AffineFastState.Bounded env6921 := by
  intro p hp
  have h : env6921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6920_6921 : H12AffineEnvironment.transform 18 20565 env6920 = env6921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 20565 env6920 == env6921) = true)

def env6922 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,372,8388608,8987981,8225,525376,335883,11031616,11158592,8989722,1364,73770,525568,8987707,34359738368,74283]

theorem envBound6922 : H12AffineFastState.Bounded env6922 := by
  intro p hp
  have h : env6922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6912_6922 : H12AffineEnvironment.transform 6 41 env6912 = env6922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6912 == env6922) = true)

theorem identity6922 : scanCanonicalize (H12AffineFastState.compose env6922 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(34+1) ^^^ 24924) := by decide +kernel

theorem selectedBound6922 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env6923 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,372,8388608,8987981,8225,525376,335883,11031616,11158592,8989722,1364,73770,525568,8987707,24924,74283]

theorem envBound6923 : H12AffineFastState.Bounded env6923 := by
  intro p hp
  have h : env6923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6922_6923 : H12AffineEnvironment.transform 34 24924 env6922 = env6923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 24924 env6922 == env6923) = true)

theorem identity6923 : scanCanonicalize (H12AffineFastState.compose env6923 (packedSelected [11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 375) := by decide +kernel

theorem selectedBound6923 : packedSelected [11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env6924 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8200,375,131072,262144,524288,8200,2097152,372,8388608,8922170,8225,525376,270716,11031616,11158592,8924525,1364,8541,525568,8922444,24924,9052]

theorem envBound6924 : H12AffineFastState.Bounded env6924 := by
  intro p hp
  have h : env6924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6923_6924 : H12AffineEnvironment.transform 15 375 env6923 = env6924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 375 env6923 == env6924) = true)

theorem identity6924 : scanCanonicalize (H12AffineFastState.compose env6924 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound6924 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env6925 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8200,375,5393,262144,524288,8200,2097152,372,8388608,8922170,8225,525376,270716,11031616,11030865,8924525,1364,8541,525568,8922444,24924,9052]

theorem envBound6925 : H12AffineFastState.Bounded env6925 := by
  intro p hp
  have h : env6925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6924_6925 : H12AffineEnvironment.transform 16 5393 env6924 = env6925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env6924 == env6925) = true)

theorem identity6925 : scanCanonicalize (H12AffineFastState.compose env6925 (packedSelected [11,14,17,20,21] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound6925 : packedSelected [11,14,17,20,21] rootPS < 2^1333 := by decide +kernel

def env6926 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,348,16384,340,375,5393,262144,524288,340,2097152,372,8388608,8914278,381,525376,262176,11031616,11030865,8916017,1364,1,525568,8913936,16384,512]

theorem envBound6926 : H12AffineFastState.Bounded env6926 := by
  intro p hp
  have h : env6926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6925_6926 : H12AffineEnvironment.transform 12 348 env6925 = env6926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env6925 == env6926) = true)

theorem identity6926 : scanCanonicalize (H12AffineFastState.compose env6926 (packedSelected [1,3,8,10,24] rootPS)) = affineNative (2^(22+1) ^^^ 2114816) := by decide +kernel

theorem selectedBound6926 : packedSelected [1,3,8,10,24] rootPS < 2^1333 := by decide +kernel

def env6927 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,348,16384,340,375,5393,262144,524288,340,2097152,372,2114816,2637926,381,525376,262176,528704,529489,2640177,1364,1,525568,2638096,16384,512]

theorem envBound6927 : H12AffineFastState.Bounded env6927 := by
  intro p hp
  have h : env6927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6926_6927 : H12AffineEnvironment.transform 22 2114816 env6926 = env6927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114816 env6926 == env6927) = true)

theorem identity6927 : scanCanonicalize (H12AffineFastState.compose env6927 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound6927 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env6928 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,16384,0,35,5189,262144,524288,0,2097152,32,2114644,2637926,41,525376,262176,528404,529489,2639973,1024,1,525396,2637892,16384,512]

theorem envBound6928 : H12AffineFastState.Bounded env6928 := by
  intro p hp
  have h : env6928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6927_6928 : H12AffineEnvironment.transform 7 84 env6927 = env6928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env6927 == env6928) = true)

theorem identity6928 : scanCanonicalize (H12AffineFastState.compose env6928 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17428) := by decide +kernel

theorem selectedBound6928 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6929 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,16384,0,35,5189,262144,524288,0,17428,32,64,525426,41,525376,262176,528404,529489,527473,1024,1,525396,525392,16384,512]

theorem envBound6929 : H12AffineFastState.Bounded env6929 := by
  intro p hp
  have h : env6929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6928_6929 : H12AffineEnvironment.transform 20 17428 env6928 = env6929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17428 env6928 == env6929) = true)

def env6930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988132,8328,67108864,360618,77615105,77742081,13208934,67674549,73770,525568,13206855,34359738368,98851]

theorem envBound6930 : H12AffineFastState.Bounded env6930 := by
  intro p hp
  have h : env6930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6708_6930 : H12AffineEnvironment.transform 27 77615105 env6708 = env6930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 77615105 env6708 == env6930) = true)

theorem identity6930 : scanCanonicalize (H12AffineFastState.compose env6930 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(25+1) ^^^ 599234) := by decide +kernel

theorem selectedBound6930 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988132,8328,599234,360618,11105475,11232451,13208934,99703,73770,525568,13206855,34359738368,98851]

theorem envBound6931 : H12AffineFastState.Bounded env6931 := by
  intro p hp
  have h : env6931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6930_6931 : H12AffineEnvironment.transform 25 599234 env6930 = env6931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 599234 env6930 == env6931) = true)

def env6932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,41340,8388608,8988132,8328,599234,360618,11105475,11232451,8989722,99703,73770,525568,8987707,34359738368,98851]

theorem envBound6932 : H12AffineFastState.Bounded env6932 := by
  intro p hp
  have h : env6932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6931_6932 : H12AffineEnvironment.transform 21 41340 env6931 = env6932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env6931 == env6932) = true)

def env6933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,524288,8540,2097152,32,8388608,8988132,8328,599234,336374,11105475,11232451,8989722,74795,73770,525568,8987707,34359738368,74623]

theorem envBound6933 : H12AffineFastState.Bounded env6933 := by
  intro p hp
  have h : env6933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6932_6933 : H12AffineEnvironment.transform 14 8540 env6932 = env6933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env6932 == env6933) = true)

theorem identity6933 : scanCanonicalize (H12AffineFastState.compose env6933 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound6933 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8575,131072,262144,524288,8540,2097152,32,8388608,8914075,8328,525757,262281,11031996,11158972,8916325,1364,341,525568,8914244,34359738368,512]

theorem envBound6934 : H12AffineFastState.Bounded env6934 := by
  intro p hp
  have h : env6934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6933_6934 : H12AffineEnvironment.transform 15 8575 env6933 = env6934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env6933 == env6934) = true)

def env6935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8575,131072,262144,524288,8540,151632,32,8388608,8914075,8328,525757,262281,9045484,8918508,8916325,1364,341,525568,8914244,34359738368,512]

theorem envBound6935 : H12AffineFastState.Bounded env6935 := by
  intro p hp
  have h : env6935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6934_6935 : H12AffineEnvironment.transform 20 151632 env6934 = env6935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env6934 == env6935) = true)

theorem identity6935 : scanCanonicalize (H12AffineFastState.compose env6935 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound6935 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1