import H12CloudChart1Data022

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env5690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41003,8329,8388688,323792,16385,16893,22641,74795,12644669,257,20560,4239489,8389612]

theorem envBound5690 : H12AffineFastState.Bounded env5690 := by
  intro p hp
  have h : env5690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5641_5690 : H12AffineEnvironment.transform 18 1025 env5641 = env5690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5641 == env5690) = true)

theorem identity5690 : scanCanonicalize (H12AffineFastState.compose env5690 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4240597) := by decide +kernel

theorem selectedBound5690 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,4240597,41003,8329,4240517,323792,16385,16893,22641,74795,17896,257,20560,4239489,4241209]

theorem envBound5691 : H12AffineFastState.Bounded env5691 := by
  intro p hp
  have h : env5691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5690_5691 : H12AffineEnvironment.transform 22 4240597 env5690 = env5691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240597 env5690 == env5691) = true)

def env5692 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,4240517,41003,8329,4240517,323712,16385,16813,22561,74795,17848,257,20480,4239489,4241209]

theorem envBound5692 : H12AffineFastState.Bounded env5692 := by
  intro p hp
  have h : env5692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5691_5692 : H12AffineEnvironment.transform 5 16 env5691 = env5692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5691 == env5692) = true)

theorem identity5692 : scanCanonicalize (H12AffineFastState.compose env5692 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 46393) := by decide +kernel

theorem selectedBound5692 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5693 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,46393,444,41003,8329,444,323712,16385,16813,22561,74795,17848,257,20480,1464,512]

theorem envBound5693 : H12AffineFastState.Bounded env5693 := by
  intro p hp
  have h : env5693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5692_5693 : H12AffineEnvironment.transform 21 46393 env5692 = env5693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46393 env5692 == env5693) = true)

theorem identity5693 : scanCanonicalize (H12AffineFastState.compose env5693 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound5693 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5694 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,32768,65536,1296,262144,1025,32768,1212,41348,444,41003,8329,444,320573,16385,16813,19612,74795,17848,257,17597,1464,512]

theorem envBound5694 : H12AffineFastState.Bounded env5694 := by
  intro p hp
  have h : env5694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5693_5694 : H12AffineEnvironment.transform 11 1213 env5693 = env5694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env5693 == env5694) = true)

theorem identity5694 : scanCanonicalize (H12AffineFastState.compose env5694 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound5694 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5695 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,65536,1296,262144,1025,26261,1212,18193,444,18110,8329,444,262824,16385,16813,19612,74795,17848,257,17597,1464,512]

theorem envBound5695 : H12AffineFastState.Bounded env5695 := by
  intro p hp
  have h : env5695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5694_5695 : H12AffineEnvironment.transform 14 26261 env5694 = env5695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env5694 == env5695) = true)

theorem identity5695 : scanCanonicalize (H12AffineFastState.compose env5695 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25663) := by decide +kernel

theorem selectedBound5695 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5696 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,25663,1296,262144,1025,26261,1212,18193,444,18110,8329,444,262824,16385,16813,19612,16404,17848,257,17597,1464,512]

theorem envBound5696 : H12AffineFastState.Bounded env5696 := by
  intro p hp
  have h : env5696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5695_5696 : H12AffineEnvironment.transform 15 25663 env5695 = env5696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25663 env5695 == env5696) = true)

theorem identity5696 : scanCanonicalize (H12AffineFastState.compose env5696 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5696 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env5697 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1044,8192,16384,26172,25663,1296,262144,1025,26172,1045,18193,277,17943,8224,277,262657,16385,16644,19509,16404,17681,257,17428,1297,512]

theorem envBound5697 : H12AffineFastState.Bounded env5697 := by
  intro p hp
  have h : env5697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5696_5697 : H12AffineEnvironment.transform 6 41 env5696 = env5697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5696 == env5697) = true)

def env5698 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,4240516,41003,8329,4240517,323713,16385,16812,22560,74795,17849,257,20481,4239489,4241209]

theorem envBound5698 : H12AffineFastState.Bounded env5698 := by
  intro p hp
  have h : env5698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5691_5698 : H12AffineEnvironment.transform 5 17 env5691 = env5698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5691 == env5698) = true)

def env5699 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1025,32768,4097,4194304,4240516,41003,8329,4240517,323713,16385,16400,22560,74795,17413,189,20481,4239489,4241029]

theorem envBound5699 : H12AffineFastState.Bounded env5699 := by
  intro p hp
  have h : env5699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5698_5699 : H12AffineEnvironment.transform 7 188 env5698 = env5699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env5698 == env5699) = true)

theorem identity5699 : scanCanonicalize (H12AffineFastState.compose env5699 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 13493) := by decide +kernel

theorem selectedBound5699 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5700 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,13493,65536,4112,262144,1025,13493,4097,4194304,4194353,5278,8329,4194352,279604,16385,16400,22560,74795,17413,189,20481,4195380,4194864]

theorem envBound5700 : H12AffineFastState.Bounded env5700 := by
  intro p hp
  have h : env5700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5699_5700 : H12AffineEnvironment.transform 14 13493 env5699 = env5700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13493 env5699 == env5700) = true)

def env5701 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13477,65536,4096,262144,1025,13477,4097,4194304,4194337,5262,8329,4194336,279588,16385,16384,22560,74795,17413,173,20481,4195364,4194848]

theorem envBound5701 : H12AffineFastState.Bounded env5701 := by
  intro p hp
  have h : env5701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5700_5701 : H12AffineEnvironment.transform 3 0 env5700 = env5701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5700 == env5701) = true)

theorem identity5701 : scanCanonicalize (H12AffineFastState.compose env5701 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 25734) := by decide +kernel

theorem selectedBound5701 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5702 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13477,25734,4096,262144,1025,13477,4097,4194304,4194337,5262,8329,4194336,279588,16385,16384,22560,16557,17413,173,20481,4195364,4194848]

theorem envBound5702 : H12AffineFastState.Bounded env5702 := by
  intro p hp
  have h : env5702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5701_5702 : H12AffineEnvironment.transform 15 25734 env5701 = env5702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25734 env5701 == env5702) = true)

theorem identity5702 : scanCanonicalize (H12AffineFastState.compose env5702 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 19596) := by decide +kernel

theorem selectedBound5702 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env5703 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13477,25734,4096,19596,1025,13477,4097,4194304,4194337,5262,8329,4194336,2216,16385,16384,22560,16557,17413,173,20481,4195364,4194848]

theorem envBound5703 : H12AffineFastState.Bounded env5703 := by
  intro p hp
  have h : env5703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5702_5703 : H12AffineEnvironment.transform 17 19596 env5702 = env5703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19596 env5702 == env5703) = true)

theorem identity5703 : scanCanonicalize (H12AffineFastState.compose env5703 (packedSelected [0,3,5,7,10,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 1573) := by decide +kernel

theorem selectedBound5703 : packedSelected [0,3,5,7,10,18,20,23] rootPS < 2^1333 := by decide +kernel

def env5704 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,1573,13477,8867,4096,2729,1025,13477,4097,4194304,4194337,5262,8329,4194336,2216,1572,1573,7685,1672,544,173,5668,4195364,4194848]

theorem envBound5704 : H12AffineFastState.Bounded env5704 := by
  intro p hp
  have h : env5704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5703_5704 : H12AffineEnvironment.transform 13 1573 env5703 = env5704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1573 env5703 == env5704) = true)

theorem identity5704 : scanCanonicalize (H12AffineFastState.compose env5704 (packedSelected [0,1,2,3,4,7,11,12,15,18,22] rootPS)) = affineNative (2^(21+1) ^^^ 136) := by decide +kernel

theorem selectedBound5704 : packedSelected [0,1,2,3,4,7,11,12,15,18,22] rootPS < 2^1333 := by decide +kernel

def env5705 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,1573,13477,8867,4096,2729,1025,13477,4097,136,169,5262,8329,168,2216,1572,1573,7685,1672,544,173,5668,1196,680]

theorem envBound5705 : H12AffineFastState.Bounded env5705 := by
  intro p hp
  have h : env5705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5704_5705 : H12AffineEnvironment.transform 21 136 env5704 = env5705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env5704 == env5705) = true)

theorem identity5705 : scanCanonicalize (H12AffineFastState.compose env5705 (packedSelected [0,1,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound5705 : packedSelected [0,1,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env5706 : List Nat := [2,4,8,0,32,1,128,172,136,1024,2048,4096,8192,1197,13477,8235,4096,2081,1025,13477,4097,136,169,5262,8329,168,2216,1196,1197,7309,1024,168,173,5292,1196,32]

theorem envBound5706 : H12AffineFastState.Bounded env5706 := by
  intro p hp
  have h : env5706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5705_5706 : H12AffineEnvironment.transform 8 136 env5705 = env5706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env5705 == env5706) = true)

theorem identity5706 : scanCanonicalize (H12AffineFastState.compose env5706 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound5706 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env5707 : List Nat := [2,4,8,0,32,1,128,172,136,1024,2048,4096,5133,1197,168,5158,4096,2081,1025,168,4097,136,169,5262,5252,168,2216,1196,1197,7309,1024,168,173,5292,1196,32]

theorem envBound5707 : H12AffineFastState.Bounded env5707 := by
  intro p hp
  have h : env5707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5706_5707 : H12AffineEnvironment.transform 12 5133 env5706 = env5707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env5706 == env5707) = true)

theorem identity5707 : scanCanonicalize (H12AffineFastState.compose env5707 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound5707 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env5708 : List Nat := [2,4,8,0,32,1,128,172,136,14,2048,4096,4099,163,168,4136,4096,2081,15,168,4097,136,169,4224,4234,168,2216,162,163,6275,14,168,173,4258,162,32]

theorem envBound5708 : H12AffineFastState.Bounded env5708 := by
  intro p hp
  have h : env5708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5707_5708 : H12AffineEnvironment.transform 9 14 env5707 = env5708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env5707 == env5708) = true)

def env5709 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,13476,65536,4097,262144,1025,13476,4097,4194304,4194336,5263,8329,4194337,279589,16385,16385,22560,74795,17413,172,20481,4195365,4194849]

theorem envBound5709 : H12AffineFastState.Bounded env5709 := by
  intro p hp
  have h : env5709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5700_5709 : H12AffineEnvironment.transform 3 1 env5700 = env5709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5700 == env5709) = true)

theorem identity5709 : scanCanonicalize (H12AffineFastState.compose env5709 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(11+1) ^^^ 1197) := by decide +kernel

theorem selectedBound5709 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5710 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,8201,65536,1196,262144,1025,8201,1196,4194304,4194336,34,8329,4194337,279589,16385,16385,19597,74795,17413,172,17580,4195365,4194849]

theorem envBound5710 : H12AffineFastState.Bounded env5710 := by
  intro p hp
  have h : env5710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5709_5710 : H12AffineEnvironment.transform 11 1197 env5709 = env5710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1197 env5709 == env5710) = true)

theorem identity5710 : scanCanonicalize (H12AffineFastState.compose env5710 (packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound5710 : packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env5711 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,8201,65536,1196,262144,1025,8201,1196,73891,73859,34,8329,73858,279589,16385,16385,19597,74795,17413,172,17580,74886,74370]

theorem envBound5711 : H12AffineFastState.Bounded env5711 := by
  intro p hp
  have h : env5711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5710_5711 : H12AffineEnvironment.transform 21 73891 env5710 = env5711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env5710 == env5711) = true)

theorem identity5711 : scanCanonicalize (H12AffineFastState.compose env5711 (packedSelected [0,2,7,11,13,18,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 20140) := by decide +kernel

theorem selectedBound5711 : packedSelected [0,2,7,11,13,18,20,21] rootPS < 2^1333 := by decide +kernel

def env5712 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,8201,65536,1196,20140,1025,8201,1196,73891,73859,34,8329,73858,2697,16385,16385,19597,74795,17413,172,17580,74886,74370]

theorem envBound5712 : H12AffineFastState.Bounded env5712 := by
  intro p hp
  have h : env5712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5711_5712 : H12AffineEnvironment.transform 17 20140 env5711 = env5712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20140 env5711 == env5712) = true)

theorem identity5712 : scanCanonicalize (H12AffineFastState.compose env5712 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound5712 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env5713 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,8201,8714,1196,20140,1025,8201,1196,681,649,34,8329,648,2697,16385,16385,19597,1569,17413,172,17580,1676,136]

theorem envBound5713 : H12AffineFastState.Bounded env5713 := by
  intro p hp
  have h : env5713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5712_5713 : H12AffineEnvironment.transform 15 8714 env5712 = env5713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env5712 == env5713) = true)

theorem identity5713 : scanCanonicalize (H12AffineFastState.compose env5713 (packedSelected [0,2,4,12,18] rootPS)) = affineNative (2^(13+1) ^^^ 11783) := by decide +kernel

theorem selectedBound5713 : packedSelected [0,2,4,12,18] rootPS < 2^1333 := by decide +kernel

def env5714 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,11783,8201,8714,1196,8363,1025,8201,1196,681,649,34,8329,648,2697,11782,11782,8842,1569,10754,172,10923,1676,136]

theorem envBound5714 : H12AffineFastState.Bounded env5714 := by
  intro p hp
  have h : env5714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5713_5714 : H12AffineEnvironment.transform 13 11783 env5713 = env5714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11783 env5713 == env5714) = true)

theorem identity5714 : scanCanonicalize (H12AffineFastState.compose env5714 (packedSelected [0,3,5,6,7,11,13,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound5714 : packedSelected [0,3,5,6,7,11,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5715 : List Nat := [2,4,8,1,32,0,128,173,512,1024,1540,1197,8192,8195,8201,8714,1196,8363,1025,8201,1196,681,649,34,8329,648,1165,8194,8194,8842,1569,9222,172,9391,1676,136]

theorem envBound5715 : H12AffineFastState.Bounded env5715 := by
  intro p hp
  have h : env5715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5714_5715 : H12AffineEnvironment.transform 10 1540 env5714 = env5715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env5714 == env5715) = true)

theorem identity5715 : scanCanonicalize (H12AffineFastState.compose env5715 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 1679) := by decide +kernel

theorem selectedBound5715 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env5716 : List Nat := [2,4,8,1,32,0,128,173,512,1024,1540,1197,1679,1676,1670,1157,1196,1572,1025,1670,1196,681,649,34,1542,648,1165,1677,1677,1029,1569,649,172,544,1676,136]

theorem envBound5716 : H12AffineFastState.Bounded env5716 := by
  intro p hp
  have h : env5716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5715_5716 : H12AffineEnvironment.transform 12 1679 env5715 = env5716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1679 env5715 == env5716) = true)

theorem identity5716 : scanCanonicalize (H12AffineFastState.compose env5716 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 131) := by decide +kernel

theorem selectedBound5716 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env5717 : List Nat := [2,4,8,1,32,0,128,173,131,1024,1159,1197,1036,1039,1029,1157,1196,1191,1025,1029,1196,42,10,34,1157,11,1165,1038,1038,1029,1186,10,172,163,1039,136]

theorem envBound5717 : H12AffineFastState.Bounded env5717 := by
  intro p hp
  have h : env5717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5716_5717 : H12AffineEnvironment.transform 8 131 env5716 = env5717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 131 env5716 == env5717) = true)

def env5718 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1025,32768,4097,4194304,4240516,41003,8329,4240517,323713,16385,16401,22560,74795,17412,188,20481,4239489,4241028]

theorem envBound5718 : H12AffineFastState.Bounded env5718 := by
  intro p hp
  have h : env5718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5698_5718 : H12AffineEnvironment.transform 7 189 env5698 = env5718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env5698 == env5718) = true)

theorem identity5718 : scanCanonicalize (H12AffineFastState.compose env5718 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 53403) := by decide +kernel

theorem selectedBound5718 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5719 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,53403,4113,262144,1025,32768,4097,4194304,4240516,41003,8329,4240517,323713,16385,16401,22560,62640,17412,188,20481,4239489,4241028]

theorem envBound5719 : H12AffineFastState.Bounded env5719 := by
  intro p hp
  have h : env5719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5718_5719 : H12AffineEnvironment.transform 15 53403 env5718 = env5719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53403 env5718 == env5719) = true)

def env5720 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,4096,8192,16384,32768,53387,4097,262144,1025,32768,4097,4194304,4240516,41003,8329,4240517,323713,16385,16385,22560,62624,17412,172,20481,4239489,4241028]

theorem envBound5720 : H12AffineFastState.Bounded env5720 := by
  intro p hp
  have h : env5720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5719_5720 : H12AffineEnvironment.transform 3 0 env5719 = env5720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5719 == env5720) = true)

theorem identity5720 : scanCanonicalize (H12AffineFastState.compose env5720 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound5720 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5721 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,1029,8192,16384,32768,50318,1028,262144,1025,32768,1028,4194304,4235393,41003,8329,4235392,320644,16385,16385,19493,57509,17412,172,17412,4236420,4235905]

theorem envBound5721 : H12AffineFastState.Bounded env5721 := by
  intro p hp
  have h : env5721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5720_5721 : H12AffineEnvironment.transform 11 1029 env5720 = env5721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env5720 == env5721) = true)

theorem identity5721 : scanCanonicalize (H12AffineFastState.compose env5721 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5721 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5722 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1029,8192,16384,32768,50214,1028,262144,1025,32768,1028,4194304,4235305,41003,8225,4235304,320556,16385,16385,19493,57357,17412,4,17412,4236332,4235817]

theorem envBound5722 : H12AffineFastState.Bounded env5722 := by
  intro p hp
  have h : env5722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5721_5722 : H12AffineEnvironment.transform 6 40 env5721 = env5722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5721 == env5722) = true)

theorem identity5722 : scanCanonicalize (H12AffineFastState.compose env5722 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound5722 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5723 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1029,8192,16384,8201,25647,1028,262144,1025,8201,1028,4194304,4194336,34,8225,4194337,279589,16385,16385,19493,16388,17412,4,17412,4195365,4194848]

theorem envBound5723 : H12AffineFastState.Bounded env5723 := by
  intro p hp
  have h : env5723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5722_5723 : H12AffineEnvironment.transform 14 8201 env5722 = env5723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env5722 == env5723) = true)

theorem identity5723 : scanCanonicalize (H12AffineFastState.compose env5723 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 8713) := by decide +kernel

theorem selectedBound5723 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5724 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1029,8192,16384,8201,25647,1028,8713,1025,8201,1028,4194304,4194336,34,8225,4194337,26156,16385,16385,19493,16388,17412,4,17412,4195365,4194848]

theorem envBound5724 : H12AffineFastState.Bounded env5724 := by
  intro p hp
  have h : env5724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5723_5724 : H12AffineEnvironment.transform 17 8713 env5723 = env5724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8713 env5723 == env5724) = true)

theorem identity5724 : scanCanonicalize (H12AffineFastState.compose env5724 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 20014) := by decide +kernel

theorem selectedBound5724 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env5725 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1029,8192,16384,8201,25647,1028,8713,1025,8201,1028,20014,19982,34,8225,19983,26156,16385,16385,19493,16388,17412,4,17412,18955,19470]

theorem envBound5725 : H12AffineFastState.Bounded env5725 := by
  intro p hp
  have h : env5725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5724_5725 : H12AffineEnvironment.transform 21 20014 env5724 = env5725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20014 env5724 == env5725) = true)

theorem identity5725 : scanCanonicalize (H12AffineFastState.compose env5725 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound5725 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5726 : List Nat := [2,4,8,0,32,1,40,5,512,1024,522,1029,8192,16384,8201,25647,1028,8713,1025,8201,1028,17444,17412,34,8225,17413,26156,16385,16385,17967,16388,17412,4,17412,16385,17924]

theorem envBound5726 : H12AffineFastState.Bounded env5726 := by
  intro p hp
  have h : env5726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5725_5726 : H12AffineEnvironment.transform 10 522 env5725 = env5726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env5725 == env5726) = true)

theorem identity5726 : scanCanonicalize (H12AffineFastState.compose env5726 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 555) := by decide +kernel

theorem selectedBound5726 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5727 : List Nat := [2,4,8,0,32,1,40,5,512,1024,522,1029,8192,555,8201,9732,1028,8713,1025,8201,1028,1551,1583,34,8225,1582,9223,554,554,1028,559,1583,4,1583,554,1071]

theorem envBound5727 : H12AffineFastState.Bounded env5727 := by
  intro p hp
  have h : env5727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5726_5727 : H12AffineEnvironment.transform 13 555 env5726 = env5727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 555 env5726 == env5727) = true)

theorem identity5727 : scanCanonicalize (H12AffineFastState.compose env5727 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 1069) := by decide +kernel

theorem selectedBound5727 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5728 : List Nat := [2,4,8,0,32,1,40,5,512,1024,522,1029,1069,555,1060,553,1028,1572,1025,1060,1028,1551,1583,34,1036,1582,42,554,554,1028,559,1583,4,1583,554,1071]

theorem envBound5728 : H12AffineFastState.Bounded env5728 := by
  intro p hp
  have h : env5728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5727_5728 : H12AffineEnvironment.transform 12 1069 env5727 = env5728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1069 env5727 == env5728) = true)

theorem identity5728 : scanCanonicalize (H12AffineFastState.compose env5728 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound5728 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env5729 : List Nat := [2,4,8,0,32,1,40,5,512,37,522,32,8,555,1,553,33,513,36,1,33,554,522,34,41,523,42,554,554,33,559,522,4,522,554,10]

theorem envBound5729 : H12AffineFastState.Bounded env5729 := by
  intro p hp
  have h : env5729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5728_5729 : H12AffineEnvironment.transform 9 37 env5728 = env5729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env5728 == env5729) = true)

theorem identity5729 : scanCanonicalize (H12AffineFastState.compose env5729 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound5729 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env5730 : List Nat := [2,4,8,0,32,1,40,5,11,37,1,32,8,32,1,34,33,10,36,1,33,33,1,34,41,0,42,33,33,33,36,1,4,1,33,10]

theorem envBound5730 : H12AffineFastState.Bounded env5730 := by
  intro p hp
  have h : env5730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5729_5730 : H12AffineEnvironment.transform 8 11 env5729 = env5730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env5729 == env5730) = true)

theorem identity5730 : scanCanonicalize (H12AffineFastState.compose env5730 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound5730 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5731 : List Nat := [2,4,8,0,10,1,2,5,11,15,1,10,8,10,1,8,11,10,14,1,11,11,1,8,3,0,0,11,11,11,14,1,4,1,11,10]

theorem envBound5731 : H12AffineFastState.Bounded env5731 := by
  intro p hp
  have h : env5731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5730_5731 : H12AffineEnvironment.transform 4 10 env5730 = env5731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env5730 == env5731) = true)

theorem identity5731 : scanCanonicalize (H12AffineFastState.compose env5731 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5731 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5732 : List Nat := [2,1,8,0,10,1,2,0,11,10,1,10,8,10,1,8,11,10,11,1,11,11,1,8,3,0,0,11,11,11,11,1,1,1,11,10]

theorem envBound5732 : H12AffineFastState.Bounded env5732 := by
  intro p hp
  have h : env5732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5731_5732 : H12AffineEnvironment.transform 1 1 env5731 = env5732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5731 == env5732) = true)

def env5733 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53386,4096,262144,1025,32768,4097,4194304,4240516,41003,8329,4240517,323713,16385,16384,22560,62625,17412,173,20481,4239489,4241028]

theorem envBound5733 : H12AffineFastState.Bounded env5733 := by
  intro p hp
  have h : env5733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5719_5733 : H12AffineEnvironment.transform 3 1 env5719 = env5733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5719 == env5733) = true)

def env5734 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53386,4096,262144,1025,32768,4097,41088,5124,41003,8329,5125,323713,16385,16384,22560,62625,17412,173,20481,4097,5636]

theorem envBound5734 : H12AffineFastState.Bounded env5734 := by
  intro p hp
  have h : env5734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5733_5734 : H12AffineEnvironment.transform 21 41088 env5733 = env5734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env5733 == env5734) = true)

theorem identity5734 : scanCanonicalize (H12AffineFastState.compose env5734 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 61093) := by decide +kernel

theorem selectedBound5734 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5735 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53386,4096,61093,1025,32768,4097,41088,5124,41003,8329,5125,7716,16385,16384,22560,62625,17412,173,20481,4097,5636]

theorem envBound5735 : H12AffineFastState.Bounded env5735 := by
  intro p hp
  have h : env5735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5734_5735 : H12AffineEnvironment.transform 17 61093 env5734 = env5735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 61093 env5734 == env5735) = true)

theorem identity5735 : scanCanonicalize (H12AffineFastState.compose env5735 (packedSelected [9,13,17,22] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound5735 : packedSelected [9,13,17,22] rootPS < 2^1333 := by decide +kernel

def env5736 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,16384,32768,50214,1196,61093,1025,32768,1197,41088,168,41003,8329,169,2696,16385,16384,19596,57357,17412,173,17581,1197,680]

theorem envBound5736 : H12AffineFastState.Bounded env5736 := by
  intro p hp
  have h : env5736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5735_5736 : H12AffineEnvironment.transform 11 1196 env5735 = env5736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env5735 == env5736) = true)

theorem identity5736 : scanCanonicalize (H12AffineFastState.compose env5736 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound5736 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5737 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,16384,8200,25646,1196,20141,1025,8200,1197,136,168,35,8329,169,2696,16385,16384,19596,16389,17412,173,17581,1197,680]

theorem envBound5737 : H12AffineFastState.Bounded env5737 := by
  intro p hp
  have h : env5737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5736_5737 : H12AffineEnvironment.transform 14 8200 env5736 = env5737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env5736 == env5737) = true)

theorem identity5737 : scanCanonicalize (H12AffineFastState.compose env5737 (packedSelected [6,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 2090) := by decide +kernel

theorem selectedBound5737 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env5738 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,2090,8200,11268,1196,1671,1025,8200,1197,136,168,35,8329,169,2696,2091,2090,1190,2095,3118,173,3207,1197,680]

theorem envBound5738 : H12AffineFastState.Bounded env5738 := by
  intro p hp
  have h : env5738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5737_5738 : H12AffineEnvironment.transform 13 2090 env5737 = env5738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2090 env5737 == env5738) = true)

def env5739 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53386,4096,262144,1025,32768,4097,41089,5125,41003,8329,5124,323713,16385,16384,22560,62625,17412,173,20481,4096,5637]

theorem envBound5739 : H12AffineFastState.Bounded env5739 := by
  intro p hp
  have h : env5739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5733_5739 : H12AffineEnvironment.transform 21 41089 env5733 = env5739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env5733 == env5739) = true)

theorem identity5739 : scanCanonicalize (H12AffineFastState.compose env5739 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 43528) := by decide +kernel

theorem selectedBound5739 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5740 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53386,4096,43528,1025,32768,4097,41089,5125,41003,8329,5124,23177,16385,16384,22560,62625,17412,173,20481,4096,5637]

theorem envBound5740 : H12AffineFastState.Bounded env5740 := by
  intro p hp
  have h : env5740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5739_5740 : H12AffineEnvironment.transform 17 43528 env5739 = env5740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43528 env5739 == env5740) = true)

theorem identity5740 : scanCanonicalize (H12AffineFastState.compose env5740 (packedSelected [9,13,17,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5740 : packedSelected [9,13,17,22] rootPS < 2^1333 := by decide +kernel

def env5741 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,4096,8192,16384,32768,53283,4096,43528,1025,32768,4097,41000,5125,41003,8224,5124,23072,16385,16384,22560,62472,17412,4,20481,4096,5637]

theorem envBound5741 : H12AffineFastState.Bounded env5741 := by
  intro p hp
  have h : env5741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5740_5741 : H12AffineEnvironment.transform 6 41 env5740 = env5741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5740 == env5741) = true)

theorem identity5741 : scanCanonicalize (H12AffineFastState.compose env5741 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(13+1) ^^^ 1572) := by decide +kernel

theorem selectedBound5741 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env5742 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,4096,8192,1572,32768,38407,4096,43528,1025,32768,4097,41000,5125,41003,8224,5124,7172,1573,1572,7684,45612,544,4,5669,4096,5637]

theorem envBound5742 : H12AffineFastState.Bounded env5742 := by
  intro p hp
  have h : env5742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5741_5742 : H12AffineEnvironment.transform 13 1572 env5741 = env5742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1572 env5741 == env5742) = true)

def env5743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,67108864,134217728,76039249,76039597,134523041,75572347,147588588,525568,134520960,82355409,8914925]

theorem envBound5743 : H12AffineFastState.Bounded env5743 := by
  intro p hp
  have h : env5743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4841_5743 : H12AffineEnvironment.transform 27 76039249 env4841 = env5743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 76039249 env4841 == env5743) = true)

def env5744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,67108864,77914240,76039249,76039597,77613089,75572347,73983340,525568,77611008,82355409,8914925]

theorem envBound5744 : H12AffineFastState.Bounded env5744 := by
  intro p hp
  have h : env5744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5743_5744 : H12AffineEnvironment.transform 26 77914240 env5743 = env5744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 77914240 env5743 == env5744) = true)

def env5745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,8914000,2942160,16385,16893,2641009,598059,14737724,525568,2638928,6332545,8914925]

theorem envBound5745 : H12AffineFastState.Bounded env5745 := by
  intro p hp
  have h : env5745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5744_5745 : H12AffineEnvironment.transform 25 8914000 env5744 = env5745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env5744 == env5745) = true)

def env5746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41003,8329,8914000,849104,16385,16893,547953,598059,12644668,525568,545872,4239489,8914925]

theorem envBound5746 : H12AffineFastState.Bounded env5746 := by
  intro p hp
  have h : env5746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5745_5746 : H12AffineEnvironment.transform 20 4096 env5745 = env5746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env5745 == env5746) = true)

def env5747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41003,8329,8388688,323792,16385,16893,22641,74795,12644668,256,20560,4239489,8389613]

theorem envBound5747 : H12AffineFastState.Bounded env5747 := by
  intro p hp
  have h : env5747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5746_5747 : H12AffineEnvironment.transform 18 1024 env5746 = env5747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5746 == env5747) = true)

theorem identity5747 : scanCanonicalize (H12AffineFastState.compose env5747 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 91350) := by decide +kernel

theorem selectedBound5747 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,91350,41003,8329,91270,323792,16385,16893,22641,74795,4298218,256,20560,4239489,91963]

theorem envBound5748 : H12AffineFastState.Bounded env5748 := by
  intro p hp
  have h : env5748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5747_5748 : H12AffineEnvironment.transform 22 91350 env5747 = env5748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 91350 env5747 == env5748) = true)

def env5749 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,4194304,91270,41003,8329,91270,323712,16385,16813,22561,74795,4298170,256,20480,4239489,91963]

theorem envBound5749 : H12AffineFastState.Bounded env5749 := by
  intro p hp
  have h : env5749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5748_5749 : H12AffineEnvironment.transform 5 16 env5748 = env5749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5748 == env5749) = true)

def env5750 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,46480,91270,41003,8329,91270,323712,16385,16813,22561,74795,73770,256,20480,1297,91963]

theorem envBound5750 : H12AffineFastState.Bounded env5750 := by
  intro p hp
  have h : env5750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5749_5750 : H12AffineEnvironment.transform 21 46480 env5749 = env5750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46480 env5749 == env5750) = true)

theorem identity5750 : scanCanonicalize (H12AffineFastState.compose env5750 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5750 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env5751 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4096,46392,91182,41003,8225,91182,323624,16385,16645,22561,74795,73770,256,20480,1297,91963]

theorem envBound5751 : H12AffineFastState.Bounded env5751 := by
  intro p hp
  have h : env5751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5750_5751 : H12AffineEnvironment.transform 6 40 env5750 = env5751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5750 == env5751) = true)

theorem identity5751 : scanCanonicalize (H12AffineFastState.compose env5751 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound5751 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env5752 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,8200,65536,4357,262144,1024,8200,4096,5424,91182,35,8225,91182,282656,16385,16645,22561,74795,73770,256,20480,1297,91963]

theorem envBound5752 : H12AffineFastState.Bounded env5752 := by
  intro p hp
  have h : env5752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5751_5752 : H12AffineEnvironment.transform 14 8200 env5751 = env5752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env5751 == env5752) = true)

theorem identity5752 : scanCanonicalize (H12AffineFastState.compose env5752 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound5752 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5753 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,8200,65536,4357,2081,1024,8200,4096,5424,91182,35,8225,91182,22529,16385,16645,22561,74795,73770,256,20480,1297,91963]

theorem envBound5753 : H12AffineFastState.Bounded env5753 := by
  intro p hp
  have h : env5753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5752_5753 : H12AffineEnvironment.transform 17 2081 env5752 = env5753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env5752 == env5753) = true)

theorem identity5753 : scanCanonicalize (H12AffineFastState.compose env5753 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4129) := by decide +kernel

theorem selectedBound5753 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env5754 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,4129,8200,65536,4357,2081,1024,8200,4096,5424,78863,35,8225,78863,2080,4128,4388,2048,74795,73770,256,33,1297,79642]

theorem envBound5754 : H12AffineFastState.Bounded env5754 := by
  intro p hp
  have h : env5754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5753_5754 : H12AffineEnvironment.transform 13 4129 env5753 = env5754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4129 env5753 == env5754) = true)

theorem identity5754 : scanCanonicalize (H12AffineFastState.compose env5754 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound5754 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env5755 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,2088,4129,2080,65536,4357,2081,1024,2080,4096,5424,72743,35,2057,72743,2080,4128,4388,2048,68611,67586,256,33,1297,73522]

theorem envBound5755 : H12AffineFastState.Bounded env5755 := by
  intro p hp
  have h : env5755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5754_5755 : H12AffineEnvironment.transform 12 2088 env5754 = env5755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env5754 == env5755) = true)

theorem identity5755 : scanCanonicalize (H12AffineFastState.compose env5755 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 4610) := by decide +kernel

theorem selectedBound5755 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env5756 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,2088,4129,2080,4610,4357,2081,1024,2080,4096,5424,3621,35,2057,3621,2080,4128,4388,2048,7681,6656,256,33,1297,3376]

theorem envBound5756 : H12AffineFastState.Bounded env5756 := by
  intro p hp
  have h : env5756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5755_5756 : H12AffineEnvironment.transform 15 4610 env5755 = env5756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4610 env5755 == env5756) = true)

theorem identity5756 : scanCanonicalize (H12AffineFastState.compose env5756 (packedSelected [2,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5756 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env5757 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,2088,4129,2080,4610,4097,2081,1024,2080,4096,5172,3621,35,2057,3621,2080,4128,4128,2048,7681,6656,4,33,1045,3124]

theorem envBound5757 : H12AffineFastState.Bounded env5757 := by
  intro p hp
  have h : env5757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5756_5757 : H12AffineEnvironment.transform 7 4 env5756 = env5757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5756 == env5757) = true)

theorem identity5757 : scanCanonicalize (H12AffineFastState.compose env5757 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1038) := by decide +kernel

theorem selectedBound5757 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env5758 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,1038,2088,1071,2080,1548,1039,2081,1024,2080,1038,58,3621,35,2057,3621,2080,1070,1070,2048,2575,3598,4,33,1045,3124]

theorem envBound5758 : H12AffineFastState.Bounded env5758 := by
  intro p hp
  have h : env5758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5757_5758 : H12AffineEnvironment.transform 11 1038 env5757 = env5758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1038 env5757 == env5758) = true)

theorem identity5758 : scanCanonicalize (H12AffineFastState.compose env5758 (packedSelected [10,15] rootPS)) = affineNative (2^(10+1) ^^^ 1583) := by decide +kernel

theorem selectedBound5758 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env5759 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1583,1038,1543,1071,1551,1548,1039,1550,1024,1551,1038,58,10,35,1574,10,1551,1070,1070,1583,1056,33,4,33,1045,539]

theorem envBound5759 : H12AffineFastState.Bounded env5759 := by
  intro p hp
  have h : env5759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5758_5759 : H12AffineEnvironment.transform 10 1583 env5758 = env5759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1583 env5758 == env5759) = true)

def env5760 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,46481,91270,41003,8329,91270,323712,16385,16813,22561,74795,73771,256,20480,1296,91963]

theorem envBound5760 : H12AffineFastState.Bounded env5760 := by
  intro p hp
  have h : env5760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5749_5760 : H12AffineEnvironment.transform 21 46481 env5749 = env5760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46481 env5749 == env5760) = true)

theorem identity5760 : scanCanonicalize (H12AffineFastState.compose env5760 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 38194) := by decide +kernel

theorem selectedBound5760 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env5761 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,38194,4525,262144,1024,32768,4096,46481,61876,41003,8329,61876,323712,16385,16813,22561,45337,46361,256,20480,1296,61961]

theorem envBound5761 : H12AffineFastState.Bounded env5761 := by
  intro p hp
  have h : env5761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5760_5761 : H12AffineEnvironment.transform 15 38194 env5760 = env5761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38194 env5760 == env5761) = true)

theorem identity5761 : scanCanonicalize (H12AffineFastState.compose env5761 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 63544) := by decide +kernel

theorem selectedBound5761 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env5762 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,38194,4525,63544,1024,32768,4096,46481,61876,41003,8329,61876,2232,16385,16813,22561,45337,46361,256,20480,1296,61961]

theorem envBound5762 : H12AffineFastState.Bounded env5762 := by
  intro p hp
  have h : env5762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5761_5762 : H12AffineEnvironment.transform 17 63544 env5761 = env5762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63544 env5761 == env5762) = true)

theorem identity5762 : scanCanonicalize (H12AffineFastState.compose env5762 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound5762 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env5763 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1044,8192,16384,32768,33062,1465,60460,1024,32768,1044,41349,58784,41003,8329,58784,2232,16385,16813,19509,42253,41229,256,17428,1296,58909]

theorem envBound5763 : H12AffineFastState.Bounded env5763 := by
  intro p hp
  have h : env5763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5762_5763 : H12AffineEnvironment.transform 11 1044 env5762 = env5763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env5762 == env5763) = true)

theorem identity5763 : scanCanonicalize (H12AffineFastState.compose env5763 (packedSelected [0,1,3,6,7,13,17,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 28183) := by decide +kernel

theorem selectedBound5763 : packedSelected [0,1,3,6,7,13,17,20,24,28] rootPS < 2^1333 := by decide +kernel

def env5764 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1044,8192,16384,28183,28465,1465,571,1024,28183,1044,20370,2999,20028,8329,2999,2232,16385,16813,19509,19226,20250,256,17428,1296,2058]

theorem envBound5764 : H12AffineFastState.Bounded env5764 := by
  intro p hp
  have h : env5764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5763_5764 : H12AffineEnvironment.transform 14 28183 env5763 = env5764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28183 env5763 == env5764) = true)

theorem identity5764 : scanCanonicalize (H12AffineFastState.compose env5764 (packedSelected [0,1,5,6,7,8,10,17,20,21,24,31] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound5764 : packedSelected [0,1,5,6,7,8,10,17,20,21,24,31] rootPS < 2^1333 := by decide +kernel

def env5765 : List Nat := [2,4,8,16,32,16,128,256,512,1024,522,1044,8192,16384,25629,25915,1465,571,1024,25629,1044,17816,445,17462,8329,445,690,16385,16813,17983,16656,17680,256,17428,1296,512]

theorem envBound5765 : H12AffineFastState.Bounded env5765 := by
  intro p hp
  have h : env5765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5764_5765 : H12AffineEnvironment.transform 10 522 env5764 = env5765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env5764 == env5765) = true)

theorem identity5765 : scanCanonicalize (H12AffineFastState.compose env5765 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound5765 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5766 : List Nat := [2,4,8,16,32,16,128,172,512,1024,522,1044,8192,16384,25629,25751,1045,571,1024,25629,1044,17460,17,17462,8329,17,690,16385,16385,17983,16572,17596,172,17428,1212,512]

theorem envBound5766 : H12AffineFastState.Bounded env5766 := by
  intro p hp
  have h : env5766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5765_5766 : H12AffineEnvironment.transform 7 172 env5765 = env5766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env5765 == env5766) = true)

theorem identity5766 : scanCanonicalize (H12AffineFastState.compose env5766 (packedSelected [1,3,6,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5766 : packedSelected [1,3,6,12,15] rootPS < 2^1333 := by decide +kernel

def env5767 : List Nat := [2,4,8,16,32,16,40,4,512,1024,522,1044,8192,16384,25629,25663,1045,571,1024,25629,1044,17460,17,17462,8225,17,538,16385,16385,17983,16404,17428,4,17428,1044,512]

theorem envBound5767 : H12AffineFastState.Bounded env5767 := by
  intro p hp
  have h : env5767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5766_5767 : H12AffineEnvironment.transform 6 40 env5766 = env5767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5766 == env5767) = true)

theorem identity5767 : scanCanonicalize (H12AffineFastState.compose env5767 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1573) := by decide +kernel

theorem selectedBound5767 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5768 : List Nat := [2,4,8,16,32,16,40,4,512,1024,522,1044,8192,1573,8760,8730,1045,571,1024,8760,1044,529,17,531,8225,17,538,1572,1572,26,1585,561,4,561,1044,512]

theorem envBound5768 : H12AffineFastState.Bounded env5768 := by
  intro p hp
  have h : env5768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5767_5768 : H12AffineEnvironment.transform 13 1573 env5767 = env5768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1573 env5767 == env5768) = true)

theorem identity5768 : scanCanonicalize (H12AffineFastState.compose env5768 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 19) := by decide +kernel

theorem selectedBound5768 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5769 : List Nat := [2,4,8,16,32,16,40,4,512,1024,522,1044,19,1573,555,521,1045,571,1024,555,1044,529,17,531,50,17,538,1572,1572,26,1585,561,4,561,1044,512]

theorem envBound5769 : H12AffineFastState.Bounded env5769 := by
  intro p hp
  have h : env5769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5768_5769 : H12AffineEnvironment.transform 12 19 env5768 = env5769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 19 env5768 == env5769) = true)

theorem identity5769 : scanCanonicalize (H12AffineFastState.compose env5769 (packedSelected [1,2,3,4,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound5769 : packedSelected [1,2,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env5770 : List Nat := [2,4,8,16,32,16,40,4,32,1024,42,1044,19,1029,11,41,1045,27,1024,11,1044,49,17,51,50,17,58,1028,1028,26,1041,17,4,17,1044,32]

theorem envBound5770 : H12AffineFastState.Bounded env5770 := by
  intro p hp
  have h : env5770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5769_5770 : H12AffineEnvironment.transform 8 32 env5769 = env5770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env5769 == env5770) = true)

theorem identity5770 : scanCanonicalize (H12AffineFastState.compose env5770 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound5770 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env5771 : List Nat := [2,4,8,11,32,11,40,4,32,1024,42,1039,8,1029,11,41,1038,0,1024,11,1039,42,10,40,41,10,33,1028,1028,1,1034,10,4,10,1039,32]

theorem envBound5771 : H12AffineFastState.Bounded env5771 := by
  intro p hp
  have h : env5771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5770_5771 : H12AffineEnvironment.transform 3 11 env5770 = env5771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env5770 == env5771) = true)

theorem identity5771 : scanCanonicalize (H12AffineFastState.compose env5771 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound5771 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5772 : List Nat := [2,4,8,11,32,11,40,4,32,14,42,1,8,11,11,41,0,0,14,11,1,42,10,40,41,10,33,10,10,1,4,10,4,10,1,32]

theorem envBound5772 : H12AffineFastState.Bounded env5772 := by
  intro p hp
  have h : env5772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5771_5772 : H12AffineEnvironment.transform 9 14 env5771 = env5772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env5771 == env5772) = true)

theorem identity5772 : scanCanonicalize (H12AffineFastState.compose env5772 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5772 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5773 : List Nat := [2,4,3,0,32,0,35,4,32,5,33,1,3,0,0,34,0,0,5,0,1,33,1,35,34,1,33,1,1,1,4,1,4,1,1,32]

theorem envBound5773 : H12AffineFastState.Bounded env5773 := by
  intro p hp
  have h : env5773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5772_5773 : H12AffineEnvironment.transform 2 3 env5772 = env5773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5772 == env5773) = true)

theorem identity5773 : scanCanonicalize (H12AffineFastState.compose env5773 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5773 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5774 : List Nat := [2,4,3,0,1,0,2,4,1,5,0,1,3,0,0,3,0,0,5,0,1,0,1,2,3,1,0,1,1,1,4,1,4,1,1,1]

theorem envBound5774 : H12AffineFastState.Bounded env5774 := by
  intro p hp
  have h : env5774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5773_5774 : H12AffineEnvironment.transform 4 1 env5773 = env5774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5773 == env5774) = true)

def env5775 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,91271,41003,8329,91270,323713,16385,16812,22560,74795,4298171,256,20481,4239489,91963]

theorem envBound5775 : H12AffineFastState.Bounded env5775 := by
  intro p hp
  have h : env5775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5748_5775 : H12AffineEnvironment.transform 5 17 env5748 = env5775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5748 == env5775) = true)

theorem identity5775 : scanCanonicalize (H12AffineFastState.compose env5775 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 25915) := by decide +kernel

theorem selectedBound5775 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5776 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25915,4524,262144,1024,32768,4096,4194304,444,41003,8329,445,323713,16385,16812,22560,16656,4255872,256,20481,4239489,512]

theorem envBound5776 : H12AffineFastState.Bounded env5776 := by
  intro p hp
  have h : env5776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5775_5776 : H12AffineEnvironment.transform 15 25915 env5775 = env5776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25915 env5775 == env5776) = true)

theorem identity5776 : scanCanonicalize (H12AffineFastState.compose env5776 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound5776 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5777 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25915,4524,262144,1024,32768,4096,41348,444,41003,8329,445,323713,16385,16812,22560,16656,20740,256,20481,4357,512]

theorem envBound5777 : H12AffineFastState.Bounded env5777 := by
  intro p hp
  have h : env5777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5776_5777 : H12AffineEnvironment.transform 21 41348 env5776 = env5777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env5776 == env5777) = true)

theorem identity5777 : scanCanonicalize (H12AffineFastState.compose env5777 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound5777 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5778 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,25915,4524,262144,1024,26261,4096,18193,444,18110,8329,445,267796,16385,16812,22560,16656,20740,256,20481,4357,512]

theorem envBound5778 : H12AffineFastState.Bounded env5778 := by
  intro p hp
  have h : env5778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5777_5778 : H12AffineEnvironment.transform 14 26261 env5777 = env5778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env5777 == env5778) = true)

theorem identity5778 : scanCanonicalize (H12AffineFastState.compose env5778 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1465) := by decide +kernel

theorem selectedBound5778 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5779 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,26261,25915,1045,262144,1024,26261,1465,18193,444,18110,8329,445,263085,16385,16812,19865,16656,17597,256,17848,1212,512]

theorem envBound5779 : H12AffineFastState.Bounded env5779 := by
  intro p hp
  have h : env5779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5778_5779 : H12AffineEnvironment.transform 11 1465 env5778 = env5779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env5778 == env5779) = true)

theorem identity5779 : scanCanonicalize (H12AffineFastState.compose env5779 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound5779 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env5780 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,26261,25915,1045,2340,1024,26261,1465,18193,444,18110,8329,445,2697,16385,16812,19865,16656,17597,256,17848,1212,512]

theorem envBound5780 : H12AffineFastState.Bounded env5780 := by
  intro p hp
  have h : env5780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5779_5780 : H12AffineEnvironment.transform 17 2340 env5779 = env5780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env5779 == env5780) = true)

theorem identity5780 : scanCanonicalize (H12AffineFastState.compose env5780 (packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1945) := by decide +kernel

theorem selectedBound5780 : packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env5781 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,1945,8460,8866,1045,2340,1024,8460,1465,136,444,295,8329,445,2697,1944,1589,2560,1673,804,256,545,1212,512]

theorem envBound5781 : H12AffineFastState.Bounded env5781 := by
  intro p hp
  have h : env5781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5780_5781 : H12AffineEnvironment.transform 13 1945 env5780 = env5781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1945 env5780 == env5781) = true)

theorem identity5781 : scanCanonicalize (H12AffineFastState.compose env5781 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5781 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env5782 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,1840,8460,8715,1045,2340,1024,8460,1296,33,277,295,8224,276,2592,1841,1589,2560,1568,804,256,545,1045,512]

theorem envBound5782 : H12AffineFastState.Bounded env5782 := by
  intro p hp
  have h : env5782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5781_5782 : H12AffineEnvironment.transform 6 41 env5781 = env5782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5781 == env5782) = true)

theorem identity5782 : scanCanonicalize (H12AffineFastState.compose env5782 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5782 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5783 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1045,8192,1589,8201,8715,1045,2081,1024,8201,1045,33,16,34,8224,17,2592,1588,1589,2560,1568,545,5,545,1045,512]

theorem envBound5783 : H12AffineFastState.Bounded env5783 := by
  intro p hp
  have h : env5783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5782_5783 : H12AffineEnvironment.transform 7 5 env5782 = env5783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5782 == env5783) = true)

theorem identity5783 : scanCanonicalize (H12AffineFastState.compose env5783 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound5783 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5784 : List Nat := [2,4,8,16,32,17,41,5,33,1024,2048,1045,8192,1044,8201,8234,1045,2081,1024,8201,1045,33,16,34,8224,17,2049,1045,1044,2081,1025,0,5,0,1045,33]

theorem envBound5784 : H12AffineFastState.Bounded env5784 := by
  intro p hp
  have h : env5784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5783_5784 : H12AffineEnvironment.transform 8 33 env5783 = env5784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env5783 == env5784) = true)

theorem identity5784 : scanCanonicalize (H12AffineFastState.compose env5784 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound5784 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5785 : List Nat := [2,4,8,16,32,17,41,5,33,1024,2048,1045,2098,1044,2107,2072,1045,2081,1024,2107,1045,33,16,34,2066,17,2049,1045,1044,2081,1025,0,5,0,1045,33]

theorem envBound5785 : H12AffineFastState.Bounded env5785 := by
  intro p hp
  have h : env5785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5784_5785 : H12AffineEnvironment.transform 12 2098 env5784 = env5785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env5784 == env5785) = true)

theorem identity5785 : scanCanonicalize (H12AffineFastState.compose env5785 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound5785 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5786 : List Nat := [2,4,8,16,26,17,19,5,27,1024,2048,1045,2056,1044,2049,2072,1045,2075,1024,2049,1045,27,16,24,2066,17,2049,1045,1044,2075,1025,0,5,0,1045,27]

theorem envBound5786 : H12AffineFastState.Bounded env5786 := by
  intro p hp
  have h : env5786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5785_5786 : H12AffineEnvironment.transform 4 26 env5785 = env5786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env5785 == env5786) = true)

theorem identity5786 : scanCanonicalize (H12AffineFastState.compose env5786 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound5786 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5787 : List Nat := [2,4,8,16,26,17,19,5,27,20,2048,1,2056,0,2049,2072,1,2075,20,2049,1,27,16,24,2066,17,2049,1,0,2075,21,0,5,0,1,27]

theorem envBound5787 : H12AffineFastState.Bounded env5787 := by
  intro p hp
  have h : env5787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5786_5787 : H12AffineEnvironment.transform 9 20 env5786 = env5787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env5786 == env5787) = true)

theorem identity5787 : scanCanonicalize (H12AffineFastState.compose env5787 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound5787 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5788 : List Nat := [2,4,8,16,26,17,19,5,27,20,26,1,18,0,27,2,1,1,20,27,1,27,16,24,8,17,27,1,0,1,21,0,5,0,1,27]

theorem envBound5788 : H12AffineFastState.Bounded env5788 := by
  intro p hp
  have h : env5788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5787_5788 : H12AffineEnvironment.transform 10 26 env5787 = env5788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env5787 == env5788) = true)

theorem identity5788 : scanCanonicalize (H12AffineFastState.compose env5788 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound5788 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5789 : List Nat := [2,4,8,10,0,11,9,5,1,14,0,1,8,0,1,2,1,1,14,1,1,1,10,2,8,11,1,1,0,1,15,0,5,0,1,1]

theorem envBound5789 : H12AffineFastState.Bounded env5789 := by
  intro p hp
  have h : env5789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5788_5789 : H12AffineEnvironment.transform 3 10 env5788 = env5789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env5788 == env5789) = true)

def env5790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41003,8329,8388689,323793,16385,16893,22640,74794,12644668,257,20561,4239489,8389612]

theorem envBound5790 : H12AffineFastState.Bounded env5790 := by
  intro p hp
  have h : env5790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5746_5790 : H12AffineEnvironment.transform 18 1025 env5746 = env5790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5746 == env5790) = true)

theorem identity5790 : scanCanonicalize (H12AffineFastState.compose env5790 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 8663) := by decide +kernel

theorem selectedBound5790 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8663,4605,262144,1025,32768,4096,4194304,8388608,41003,8329,8388689,323793,16385,16893,22640,1533,12644668,257,20561,4239489,8389612]

theorem envBound5791 : H12AffineFastState.Bounded env5791 := by
  intro p hp
  have h : env5791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5790_5791 : H12AffineEnvironment.transform 15 8663 env5790 = env5791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8663 env5790 == env5791) = true)

def env5792 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,262144,1025,32768,4096,4194304,8388608,41003,8329,8388609,323713,16385,16813,22560,1453,12644668,257,20481,4239489,8389564]

theorem envBound5792 : H12AffineFastState.Bounded env5792 := by
  intro p hp
  have h : env5792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5791_5792 : H12AffineEnvironment.transform 5 16 env5791 = env5792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5791 == env5792) = true)

theorem identity5792 : scanCanonicalize (H12AffineFastState.compose env5792 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound5792 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5793 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,262144,1025,32768,4096,4194304,444,41003,8329,445,323713,16385,16813,22560,1453,4255872,257,20481,4239489,512]

theorem envBound5793 : H12AffineFastState.Bounded env5793 := by
  intro p hp
  have h : env5793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5792_5793 : H12AffineEnvironment.transform 22 444 env5792 = env5793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env5792 == env5793) = true)

theorem identity5793 : scanCanonicalize (H12AffineFastState.compose env5793 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound5793 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5794 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,262144,1025,32768,4096,41349,444,41003,8329,445,323713,16385,16813,22560,1453,20741,257,20481,4356,512]

theorem envBound5794 : H12AffineFastState.Bounded env5794 := by
  intro p hp
  have h : env5794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5793_5794 : H12AffineEnvironment.transform 21 41349 env5793 = env5794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env5793 == env5794) = true)

theorem identity5794 : scanCanonicalize (H12AffineFastState.compose env5794 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound5794 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5795 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,8583,4525,262144,1025,26260,4096,18193,444,18111,8329,445,267797,16385,16813,22560,1453,20741,257,20481,4356,512]

theorem envBound5795 : H12AffineFastState.Bounded env5795 := by
  intro p hp
  have h : env5795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5794_5795 : H12AffineEnvironment.transform 14 26260 env5794 = env5795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env5794 == env5795) = true)

theorem identity5795 : scanCanonicalize (H12AffineFastState.compose env5795 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4357) := by decide +kernel

theorem selectedBound5795 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5796 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4357,14225,8583,4525,262144,1025,14225,4096,5652,444,6074,8329,445,267797,4356,4264,2341,1453,0,257,260,4356,512]

theorem envBound5796 : H12AffineFastState.Bounded env5796 := by
  intro p hp
  have h : env5796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5795_5796 : H12AffineEnvironment.transform 13 4357 env5795 = env5796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4357 env5795 == env5796) = true)

theorem identity5796 : scanCanonicalize (H12AffineFastState.compose env5796 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5796 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env5797 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,4096,8192,4096,13972,8322,4264,262144,1025,13972,4096,5652,185,5823,8329,184,267797,4097,4264,2080,1192,0,4,1,4097,512]

theorem envBound5797 : H12AffineFastState.Bounded env5797 := by
  intro p hp
  have h : env5797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5796_5797 : H12AffineEnvironment.transform 7 5 env5796 = env5797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5796 == env5797) = true)

theorem identity5797 : scanCanonicalize (H12AffineFastState.compose env5797 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7869) := by decide +kernel

theorem selectedBound5797 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5798 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,4096,8192,4096,13972,8322,4264,7869,1025,13972,4096,5652,185,5823,8329,184,2216,4097,4264,2080,1192,0,4,1,4097,512]

theorem envBound5798 : H12AffineFastState.Bounded env5798 := by
  intro p hp
  have h : env5798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5797_5798 : H12AffineEnvironment.transform 17 7869 env5797 = env5798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7869 env5797 == env5798) = true)

theorem identity5798 : scanCanonicalize (H12AffineFastState.compose env5798 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound5798 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env5799 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1588,8192,1588,8352,8322,1692,2185,1025,8352,1588,32,185,139,8329,184,2216,1589,1692,2080,1192,0,4,1,1589,512]

theorem envBound5799 : H12AffineFastState.Bounded env5799 := by
  intro p hp
  have h : env5799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5798_5799 : H12AffineEnvironment.transform 11 1588 env5798 = env5799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env5798 == env5799) = true)

theorem identity5799 : scanCanonicalize (H12AffineFastState.compose env5799 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 154) := by decide +kernel

theorem selectedBound5799 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env5800 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1588,154,1588,58,24,1692,2185,1025,58,1588,32,185,139,19,184,2216,1589,1692,2080,1192,0,4,1,1589,512]

theorem envBound5800 : H12AffineFastState.Bounded env5800 := by
  intro p hp
  have h : env5800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5799_5800 : H12AffineEnvironment.transform 12 154 env5799 = env5800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 154 env5799 == env5800) = true)

theorem identity5800 : scanCanonicalize (H12AffineFastState.compose env5800 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 690) := by decide +kernel

theorem selectedBound5800 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env5801 : List Nat := [2,4,8,16,32,16,128,5,512,1024,690,1588,154,1588,58,24,1692,571,1025,58,1588,32,185,139,19,184,538,1589,1692,658,1192,0,4,1,1589,512]

theorem envBound5801 : H12AffineFastState.Bounded env5801 := by
  intro p hp
  have h : env5801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5800_5801 : H12AffineEnvironment.transform 10 690 env5800 = env5801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 690 env5800 == env5801) = true)

theorem identity5801 : scanCanonicalize (H12AffineFastState.compose env5801 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound5801 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env5802 : List Nat := [2,4,8,10,32,10,128,5,512,1024,680,1582,128,1582,32,2,1670,545,1025,32,1582,32,163,139,9,162,512,1583,1670,648,1192,0,4,1,1583,512]

theorem envBound5802 : H12AffineFastState.Bounded env5802 := by
  intro p hp
  have h : env5802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5801_5802 : H12AffineEnvironment.transform 3 10 env5801 = env5802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env5801 == env5802) = true)

theorem identity5802 : scanCanonicalize (H12AffineFastState.compose env5802 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5802 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env5803 : List Nat := [2,4,8,10,1,10,128,5,512,1024,649,1551,128,1551,1,2,1670,512,1025,1,1551,1,130,139,9,131,512,1550,1670,648,1161,0,4,1,1550,512]

theorem envBound5803 : H12AffineFastState.Bounded env5803 := by
  intro p hp
  have h : env5803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5802_5803 : H12AffineEnvironment.transform 4 1 env5802 = env5803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5802 == env5803) = true)

theorem identity5803 : scanCanonicalize (H12AffineFastState.compose env5803 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound5803 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env5804 : List Nat := [2,4,8,10,1,10,128,5,137,1024,0,1158,128,1158,1,2,1039,137,1025,1,1158,1,130,139,9,131,137,1159,1039,1,1161,0,4,1,1159,137]

theorem envBound5804 : H12AffineFastState.Bounded env5804 := by
  intro p hp
  have h : env5804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5803_5804 : H12AffineEnvironment.transform 8 137 env5803 = env5804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env5803 == env5804) = true)

theorem identity5804 : scanCanonicalize (H12AffineFastState.compose env5804 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound5804 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5805 : List Nat := [2,4,8,10,1,10,8,5,1,1024,0,1038,8,1038,1,2,1039,1,1025,1,1038,1,10,3,9,11,1,1039,1039,1,1025,0,4,1,1039,1]

theorem envBound5805 : H12AffineFastState.Bounded env5805 := by
  intro p hp
  have h : env5805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5804_5805 : H12AffineEnvironment.transform 6 8 env5804 = env5805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env5804 == env5805) = true)

theorem identity5805 : scanCanonicalize (H12AffineFastState.compose env5805 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5805 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5806 : List Nat := [2,4,3,1,1,1,3,5,1,1024,0,1029,3,1029,1,2,1028,1,1025,1,1029,1,1,3,2,0,1,1028,1028,1,1025,0,4,1,1028,1]

theorem envBound5806 : H12AffineFastState.Bounded env5806 := by
  intro p hp
  have h : env5806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5805_5806 : H12AffineEnvironment.transform 2 3 env5805 = env5806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5805 == env5806) = true)

def leafEnv5806 : List Nat := [2,4,3,1,1,1,3,5,1,1024,0,1029,3,1029,1,2,1028,1,1025,1,1029,1,1,3,1024,2,1,0,1,1028,1028,1,1025,0,4,1,5,2,1028,1,1,1029,0]

def active5806 : List Nat := [0,1,9]

def tree5806 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5806 : H12WitnessSearch.Good tree5806 := H12GlobalWitnessIndex.good

theorem leafIdentity5806 : H12AffineFastState.composeSystem env5806 rootObs = leafEnv5806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5806 rootObs == leafEnv5806) = true)

theorem terminalChecked5806 : H12PackedTerminal.terminalCheckFast leafEnv5806 active5806 tree5806 = true := by decide +kernel

def env5807 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,262144,1025,32768,4096,4194304,8388608,41003,8329,8388608,323712,16385,16812,22561,1452,12644668,257,20480,4239489,8389565]

theorem envBound5807 : H12AffineFastState.Bounded env5807 := by
  intro p hp
  have h : env5807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5791_5807 : H12AffineEnvironment.transform 5 17 env5791 = env5807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5791 == env5807) = true)

def env5808 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,43136,1025,32768,4096,4194304,8388608,41003,8329,8388608,22528,16385,16812,22561,1452,12644668,257,20480,4239489,8389565]

theorem envBound5808 : H12AffineFastState.Bounded env5808 := by
  intro p hp
  have h : env5808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5807_5808 : H12AffineEnvironment.transform 17 43136 env5807 = env5808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43136 env5807 == env5808) = true)

theorem identity5808 : scanCanonicalize (H12AffineFastState.compose env5808 (packedSelected [0,1,3,4,7,10,13,17,18,22,23,24,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 4235669) := by decide +kernel

theorem selectedBound5808 : packedSelected [0,1,3,4,7,10,13,17,18,22,23,24,28,31] rootPS < 2^1333 := by decide +kernel

def env5809 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,43136,1025,32768,4096,4194304,4235669,41003,8329,4235669,22528,16385,16812,22561,1452,20649,257,20480,4239489,4235816]

theorem envBound5809 : H12AffineFastState.Bounded env5809 := by
  intro p hp
  have h : env5809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5808_5809 : H12AffineEnvironment.transform 22 4235669 env5808 = env5809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235669 env5808 == env5809) = true)

theorem identity5809 : scanCanonicalize (H12AffineFastState.compose env5809 (packedSelected [0,1,3,9,13,18,21,22,23,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound5809 : packedSelected [0,1,3,9,13,18,21,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env5810 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,43136,1025,32768,4096,41260,185,41003,8329,185,22528,16385,16812,22561,1452,20649,257,20480,4525,772]

theorem envBound5810 : H12AffineFastState.Bounded env5810 := by
  intro p hp
  have h : env5810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5809_5810 : H12AffineEnvironment.transform 21 41260 env5809 = env5810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env5809 == env5810) = true)

theorem identity5810 : scanCanonicalize (H12AffineFastState.compose env5810 (packedSelected [4,9,13,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5810 : packedSelected [4,9,13,20,21] rootPS < 2^1333 := by decide +kernel

def env5811 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,32768,8494,4356,43048,1025,32768,4096,41260,17,41003,8225,17,22528,16385,16644,22561,1284,20481,257,20480,4357,772]

theorem envBound5811 : H12AffineFastState.Bounded env5811 := by
  intro p hp
  have h : env5811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5810_5811 : H12AffineEnvironment.transform 6 40 env5810 = env5811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5810 == env5811) = true)

theorem identity5811 : scanCanonicalize (H12AffineFastState.compose env5811 (packedSelected [0,3,4,5,7,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2309) := by decide +kernel

theorem selectedBound5811 : packedSelected [0,3,4,5,7,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env5812 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,2309,8192,16384,32768,8494,2049,43048,1025,32768,2309,41260,17,41003,8225,17,16645,16385,16644,16676,1284,18692,257,18693,2048,772]

theorem envBound5812 : H12AffineFastState.Bounded env5812 := by
  intro p hp
  have h : env5812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5811_5812 : H12AffineEnvironment.transform 11 2309 env5811 = env5812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2309 env5811 == env5812) = true)

theorem identity5812 : scanCanonicalize (H12AffineFastState.compose env5812 (packedSelected [0,1,3,5,7,8,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 11836) := by decide +kernel

theorem selectedBound5812 : packedSelected [0,1,3,5,7,8,13,17] rootPS < 2^1333 := by decide +kernel

def env5813 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,2309,8192,16384,11836,8494,2049,1556,1025,11836,2309,3856,17,3607,8225,17,16645,16385,16644,16676,1284,18692,257,18693,2048,772]

theorem envBound5813 : H12AffineFastState.Bounded env5813 := by
  intro p hp
  have h : env5813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5812_5813 : H12AffineEnvironment.transform 14 11836 env5812 = env5813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11836 env5812 == env5813) = true)

theorem identity5813 : scanCanonicalize (H12AffineFastState.compose env5813 (packedSelected [0,1,2,3,6,7,12,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound5813 : packedSelected [0,1,2,3,6,7,12,13,18] rootPS < 2^1333 := by decide +kernel

def env5814 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,2309,1063,16384,2587,1289,2049,1556,1025,2587,2309,3856,17,3607,1030,17,16645,16385,16644,16676,1284,18692,257,18693,2048,772]

theorem envBound5814 : H12AffineFastState.Bounded env5814 := by
  intro p hp
  have h : env5814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5813_5814 : H12AffineEnvironment.transform 12 1063 env5813 = env5814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env5813 == env5814) = true)

def env5815 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,43137,1025,32768,4096,4194304,8388608,41003,8329,8388608,22529,16385,16812,22561,1452,12644668,257,20480,4239489,8389565]

theorem envBound5815 : H12AffineFastState.Bounded env5815 := by
  intro p hp
  have h : env5815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5807_5815 : H12AffineEnvironment.transform 17 43137 env5807 = env5815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43137 env5807 == env5815) = true)

theorem identity5815 : scanCanonicalize (H12AffineFastState.compose env5815 (packedSelected [0,1,3,4,7,10,13,17,18,22,23,24,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 4214833) := by decide +kernel

theorem selectedBound5815 : packedSelected [0,1,3,4,7,10,13,17,18,22,23,24,28,31] rootPS < 2^1333 := by decide +kernel

def env5816 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,43137,1025,32768,4096,4194304,4214833,41003,8329,4214833,22529,16385,16812,22561,1452,41229,257,20480,4239489,4215692]

theorem envBound5816 : H12AffineFastState.Bounded env5816 := by
  intro p hp
  have h : env5816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5815_5816 : H12AffineEnvironment.transform 22 4214833 env5815 = env5816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4214833 env5815 == env5816) = true)

theorem identity5816 : scanCanonicalize (H12AffineFastState.compose env5816 (packedSelected [0,2,5,6,15,21,22,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound5816 : packedSelected [0,2,5,6,15,21,22,23,24] rootPS < 2^1333 := by decide +kernel

def env5817 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,8235,4097,43137,1025,32768,4096,4194304,4214833,41003,8329,4214833,22529,16385,16385,22561,1025,41120,172,20480,4239489,4215329]

theorem envBound5817 : H12AffineFastState.Bounded env5817 := by
  intro p hp
  have h : env5817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5816_5817 : H12AffineEnvironment.transform 7 173 env5816 = env5817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env5816 == env5817) = true)

theorem identity5817 : scanCanonicalize (H12AffineFastState.compose env5817 (packedSelected [2,3,4,5,6,7,11,12,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound5817 : packedSelected [2,3,4,5,6,7,11,12,20,21] rootPS < 2^1333 := by decide +kernel

def env5818 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4097,32768,8235,4097,43137,1025,32768,4096,4194304,4194352,41003,8329,4194352,2048,4096,4096,2080,1025,41120,172,1,4239489,4194848]

theorem envBound5818 : H12AffineFastState.Bounded env5818 := by
  intro p hp
  have h : env5818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5817_5818 : H12AffineEnvironment.transform 13 4097 env5817 = env5818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env5817 == env5818) = true)

theorem identity5818 : scanCanonicalize (H12AffineFastState.compose env5818 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound5818 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env5819 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4097,8200,8235,4097,2185,1025,8200,4096,4194304,4194352,35,8329,4194352,2048,4096,4096,2080,1025,168,172,1,4198537,4194848]

theorem envBound5819 : H12AffineFastState.Bounded env5819 := by
  intro p hp
  have h : env5819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5818_5819 : H12AffineEnvironment.transform 14 8200 env5818 = env5819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env5818 == env5819) = true)

theorem identity5819 : scanCanonicalize (H12AffineFastState.compose env5819 (packedSelected [0,1,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7317) := by decide +kernel

theorem selectedBound5819 : packedSelected [0,1,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env5820 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7317,4097,7325,7358,4097,2185,1025,7325,4096,4194304,4194352,35,7196,4194352,2048,4096,4096,2080,1025,168,172,1,4198537,4194848]

theorem envBound5820 : H12AffineFastState.Bounded env5820 := by
  intro p hp
  have h : env5820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5819_5820 : H12AffineEnvironment.transform 12 7317 env5819 = env5820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7317 env5819 == env5820) = true)

theorem identity5820 : scanCanonicalize (H12AffineFastState.compose env5820 (packedSelected [0,7,10,17] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound5820 : packedSelected [0,7,10,17] rootPS < 2^1333 := by decide +kernel

def env5821 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1692,2569,1693,2561,2594,1693,2185,1025,2561,1692,4194304,4194352,35,2688,4194352,2048,1692,1692,2080,1025,168,172,1,4195861,4194848]

theorem envBound5821 : H12AffineFastState.Bounded env5821 := by
  intro p hp
  have h : env5821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5820_5821 : H12AffineEnvironment.transform 11 1692 env5820 = env5821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env5820 == env5821) = true)

def env5822 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,1588,2569,1589,2561,2594,1589,2081,1025,2561,1588,4194304,4194352,35,2600,4194352,2048,1588,1588,2080,1025,0,4,1,4195861,4194848]

theorem envBound5822 : H12AffineFastState.Bounded env5822 := by
  intro p hp
  have h : env5822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5821_5822 : H12AffineEnvironment.transform 6 40 env5821 = env5822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5821 == env5822) = true)

theorem identity5822 : scanCanonicalize (H12AffineFastState.compose env5822 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound5822 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5823 : List Nat := [2,4,8,16,16,17,24,5,512,1024,2048,1540,2569,1541,2561,2578,1541,2065,1025,2561,1540,4194304,4194304,19,2584,4194304,2048,1540,1540,2064,1025,0,4,1,4195861,4194832]

theorem envBound5823 : H12AffineFastState.Bounded env5823 := by
  intro p hp
  have h : env5823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5822_5823 : H12AffineEnvironment.transform 4 16 env5822 = env5823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env5822 == env5823) = true)

theorem identity5823 : scanCanonicalize (H12AffineFastState.compose env5823 (packedSelected [0,2,4] rootPS)) = affineNative (2^(21+1) ^^^ 2571) := by decide +kernel

theorem selectedBound5823 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env5824 : List Nat := [2,4,8,16,16,17,24,5,512,1024,2048,1540,2569,1541,2561,2578,1541,2065,1025,2561,1540,2571,2571,19,2584,2571,2048,1540,1540,2064,1025,0,4,1,3102,2075]

theorem envBound5824 : H12AffineFastState.Bounded env5824 := by
  intro p hp
  have h : env5824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5823_5824 : H12AffineEnvironment.transform 21 2571 env5823 = env5824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2571 env5823 == env5824) = true)

theorem identity5824 : scanCanonicalize (H12AffineFastState.compose env5824 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound5824 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env5825 : List Nat := [2,4,8,16,16,17,24,5,512,1024,529,1540,24,1541,16,3,1541,512,1025,16,1540,26,26,19,9,26,529,1540,1540,513,1025,0,4,1,1551,522]

theorem envBound5825 : H12AffineFastState.Bounded env5825 := by
  intro p hp
  have h : env5825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5824_5825 : H12AffineEnvironment.transform 10 529 env5824 = env5825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env5824 == env5825) = true)

theorem identity5825 : scanCanonicalize (H12AffineFastState.compose env5825 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound5825 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5826 : List Nat := [2,4,8,1,1,0,9,5,512,1024,512,1540,9,1541,1,3,1541,512,1025,1,1540,11,11,2,9,11,512,1540,1540,513,1025,0,4,1,1551,522]

theorem envBound5826 : H12AffineFastState.Bounded env5826 := by
  intro p hp
  have h : env5826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5825_5826 : H12AffineEnvironment.transform 3 1 env5825 = env5826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5825 == env5826) = true)

theorem identity5826 : scanCanonicalize (H12AffineFastState.compose env5826 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound5826 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5827 : List Nat := [2,4,8,1,1,0,9,5,11,1024,11,1039,9,1038,1,3,1038,11,1025,1,1039,11,11,2,9,11,11,1039,1039,10,1025,0,4,1,1028,1]

theorem envBound5827 : H12AffineFastState.Bounded env5827 := by
  intro p hp
  have h : env5827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5826_5827 : H12AffineEnvironment.transform 8 11 env5826 = env5827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env5826 == env5827) = true)

theorem identity5827 : scanCanonicalize (H12AffineFastState.compose env5827 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5827 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5828 : List Nat := [2,4,2,1,1,0,3,5,1,1024,1,1029,3,1028,1,3,1028,1,1025,1,1029,1,1,2,3,1,1,1029,1029,0,1025,0,4,1,1028,1]

theorem envBound5828 : H12AffineFastState.Bounded env5828 := by
  intro p hp
  have h : env5828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5827_5828 : H12AffineEnvironment.transform 2 2 env5827 = env5828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5827 == env5828) = true)

def leafEnv5828 : List Nat := [2,4,2,1,1,0,3,5,1,1024,1,1029,3,1028,1,3,1028,1,1025,1,1029,1,1,2,1024,3,1,1,1,1029,1029,0,1025,0,4,1,5,2,1028,1,1,1028,0]

def active5828 : List Nat := [0,1,9]

def tree5828 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5828 : H12WitnessSearch.Good tree5828 := H12GlobalWitnessIndex.good

theorem leafIdentity5828 : H12AffineFastState.composeSystem env5828 rootObs = leafEnv5828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5828 rootObs == leafEnv5828) = true)

theorem terminalChecked5828 : H12PackedTerminal.terminalCheckFast leafEnv5828 active5828 tree5828 = true := by decide +kernel

def env5829 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1589,2569,1588,2561,2594,1588,2080,1025,2561,1589,4194304,4194352,35,2601,4194352,2048,1589,1589,2080,1025,1,5,1,4195861,4194848]

theorem envBound5829 : H12AffineFastState.Bounded env5829 := by
  intro p hp
  have h : env5829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5821_5829 : H12AffineEnvironment.transform 6 41 env5821 = env5829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5821 == env5829) = true)

theorem identity5829 : scanCanonicalize (H12AffineFastState.compose env5829 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound5829 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env5830 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1551,1589,1030,1588,1038,1069,1588,1583,1025,1038,1589,4194304,4194352,35,1062,4194352,1551,1589,1589,1583,1025,1,5,1,4195861,4194848]

theorem envBound5830 : H12AffineFastState.Bounded env5830 := by
  intro p hp
  have h : env5830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5829_5830 : H12AffineEnvironment.transform 10 1551 env5829 = env5830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env5829 == env5830) = true)

theorem identity5830 : scanCanonicalize (H12AffineFastState.compose env5830 (packedSelected [11] rootPS)) = affineNative (2^(21+1) ^^^ 544) := by decide +kernel

theorem selectedBound5830 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5831 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1551,1589,1030,1588,1038,1069,1588,1583,1025,1038,1589,544,528,35,1062,528,1551,1589,1589,1583,1025,1,5,1,1077,0]

theorem envBound5831 : H12AffineFastState.Bounded env5831 := by
  intro p hp
  have h : env5831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5830_5831 : H12AffineEnvironment.transform 21 544 env5830 = env5831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 544 env5830 == env5831) = true)

theorem identity5831 : scanCanonicalize (H12AffineFastState.compose env5831 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound5831 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5832 : List Nat := [2,4,8,16,32,17,41,4,512,52,571,513,50,512,58,25,512,539,53,58,513,544,528,35,18,528,571,513,513,539,53,1,5,1,1,0]

theorem envBound5832 : H12AffineFastState.Bounded env5832 := by
  intro p hp
  have h : env5832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5831_5832 : H12AffineEnvironment.transform 9 52 env5831 = env5832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env5831 == env5832) = true)

def env5833 : List Nat := [2,4,8,16,32,17,41,4,0,52,59,1,50,0,58,25,0,27,53,58,1,32,16,35,18,16,59,1,1,27,53,1,5,1,1,0]

theorem envBound5833 : H12AffineFastState.Bounded env5833 := by
  intro p hp
  have h : env5833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5832_5833 : H12AffineEnvironment.transform 8 0 env5832 = env5833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5832 == env5833) = true)

theorem identity5833 : scanCanonicalize (H12AffineFastState.compose env5833 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound5833 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5834 : List Nat := [2,4,8,16,27,17,18,4,0,15,0,1,9,0,1,25,0,27,14,1,1,27,16,24,18,16,0,1,1,27,14,1,5,1,1,0]

theorem envBound5834 : H12AffineFastState.Bounded env5834 := by
  intro p hp
  have h : env5834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5833_5834 : H12AffineEnvironment.transform 4 27 env5833 = env5834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env5833 == env5834) = true)

def env5835 : List Nat := [2,4,8,16,32,17,41,4,1,52,58,0,50,1,58,25,1,26,53,58,0,33,17,35,18,17,58,0,0,26,53,1,5,1,1,0]

theorem envBound5835 : H12AffineFastState.Bounded env5835 := by
  intro p hp
  have h : env5835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5832_5835 : H12AffineEnvironment.transform 8 1 env5832 = env5835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5832 == env5835) = true)

theorem identity5835 : scanCanonicalize (H12AffineFastState.compose env5835 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound5835 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5836 : List Nat := [2,4,8,5,32,4,41,4,1,33,47,0,39,1,47,12,1,15,32,47,0,33,4,35,7,4,47,0,0,15,32,1,5,1,1,0]

theorem envBound5836 : H12AffineFastState.Bounded env5836 := by
  intro p hp
  have h : env5836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5835_5836 : H12AffineEnvironment.transform 3 5 env5835 = env5836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env5835 == env5836) = true)

theorem identity5836 : scanCanonicalize (H12AffineFastState.compose env5836 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound5836 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5837 : List Nat := [2,4,7,5,32,4,38,4,1,33,32,0,39,1,32,3,1,0,32,32,0,33,4,35,7,4,32,0,0,0,32,1,5,1,1,0]

theorem envBound5837 : H12AffineFastState.Bounded env5837 := by
  intro p hp
  have h : env5837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5836_5837 : H12AffineEnvironment.transform 2 7 env5836 = env5837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env5836 == env5837) = true)

theorem identity5837 : scanCanonicalize (H12AffineFastState.compose env5837 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5837 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env5838 : List Nat := [2,0,3,1,32,0,34,0,1,33,32,0,35,1,32,3,1,0,32,32,0,33,0,35,3,0,32,0,0,0,32,1,1,1,1,0]

theorem envBound5838 : H12AffineFastState.Bounded env5838 := by
  intro p hp
  have h : env5838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5837_5838 : H12AffineEnvironment.transform 1 0 env5837 = env5838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5837 == env5838) = true)

def leafEnv5838 : List Nat := [2,0,3,1,32,0,34,0,1,33,32,0,35,1,32,3,1,0,32,32,0,33,0,35,33,3,1,0,32,0,0,0,32,1,1,1,1,35,1,0,1,0,0]

def active5838 : List Nat := [0,4]

def tree5838 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5838 : H12WitnessSearch.Good tree5838 := H12GlobalWitnessIndex.good

theorem leafIdentity5838 : H12AffineFastState.composeSystem env5838 rootObs = leafEnv5838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5838 rootObs == leafEnv5838) = true)

theorem terminalChecked5838 : H12PackedTerminal.terminalCheckFast leafEnv5838 active5838 tree5838 = true := by decide +kernel

def env5839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41003,8329,8914000,849105,16385,16893,547952,598059,12644669,525568,545873,4239488,8914925]

theorem envBound5839 : H12AffineFastState.Bounded env5839 := by
  intro p hp
  have h : env5839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5745_5839 : H12AffineEnvironment.transform 20 4097 env5745 = env5839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env5745 == env5839) = true)

def env5840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41003,8329,8388688,323793,16385,16893,22640,74795,12644669,256,20561,4239488,8389613]

theorem envBound5840 : H12AffineFastState.Bounded env5840 := by
  intro p hp
  have h : env5840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5839_5840 : H12AffineEnvironment.transform 18 1024 env5839 = env5840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5839 == env5840) = true)

theorem identity5840 : scanCanonicalize (H12AffineFastState.compose env5840 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 115783) := by decide +kernel

theorem selectedBound5840 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,115783,8388608,41003,8329,8388688,323793,16385,16893,22640,74795,8467834,256,20561,95431,8389613]

theorem envBound5841 : H12AffineFastState.Bounded env5841 := by
  intro p hp
  have h : env5841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5840_5841 : H12AffineEnvironment.transform 21 115783 env5840 = env5841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115783 env5840 == env5841) = true)

def env5842 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,115735,8388608,41003,8329,8388608,323713,16385,16813,22560,74795,8467754,256,20481,95383,8389565]

theorem envBound5842 : H12AffineFastState.Bounded env5842 := by
  intro p hp
  have h : env5842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5841_5842 : H12AffineEnvironment.transform 5 16 env5841 = env5842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5841 == env5842) = true)

theorem identity5842 : scanCanonicalize (H12AffineFastState.compose env5842 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound5842 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5843 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,115735,445,41003,8329,445,323713,16385,16813,22560,74795,78999,256,20481,95383,512]

theorem envBound5843 : H12AffineFastState.Bounded env5843 := by
  intro p hp
  have h : env5843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5842_5843 : H12AffineEnvironment.transform 22 445 env5842 = env5843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env5842 == env5843) = true)

theorem identity5843 : scanCanonicalize (H12AffineFastState.compose env5843 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 26002) := by decide +kernel

theorem selectedBound5843 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5844 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26002,4525,262144,1024,32768,4097,41349,445,41003,8329,445,323713,16385,16813,22560,16825,20741,256,20481,4357,512]

theorem envBound5844 : H12AffineFastState.Bounded env5844 := by
  intro p hp
  have h : env5844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5843_5844 : H12AffineEnvironment.transform 15 26002 env5843 = env5844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26002 env5843 == env5844) = true)

theorem identity5844 : scanCanonicalize (H12AffineFastState.compose env5844 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound5844 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5845 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,26002,4525,262144,1024,26260,4097,18193,445,18111,8329,445,267797,16385,16813,22560,16825,20741,256,20481,4357,512]

theorem envBound5845 : H12AffineFastState.Bounded env5845 := by
  intro p hp
  have h : env5845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5844_5845 : H12AffineEnvironment.transform 14 26260 env5844 = env5845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env5844 == env5845) = true)

theorem identity5845 : scanCanonicalize (H12AffineFastState.compose env5845 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound5845 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5846 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,26260,26002,1213,262144,1024,26260,1297,18193,445,18111,8329,445,262917,16385,16813,19760,16825,17429,256,17681,1045,512]

theorem envBound5846 : H12AffineFastState.Bounded env5846 := by
  intro p hp
  have h : env5846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5845_5846 : H12AffineEnvironment.transform 11 1296 env5845 = env5846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env5845 == env5846) = true)

theorem identity5846 : scanCanonicalize (H12AffineFastState.compose env5846 (packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 1841) := by decide +kernel

theorem selectedBound5846 : packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS < 2^1333 := by decide +kernel

def env5847 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1841,8613,8867,1213,262144,1024,8613,1297,32,445,398,8329,445,262917,1840,1692,2561,1672,804,256,544,1045,512]

theorem envBound5847 : H12AffineFastState.Bounded env5847 := by
  intro p hp
  have h : env5847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5846_5847 : H12AffineEnvironment.transform 13 1841 env5846 = env5847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1841 env5846 == env5847) = true)

theorem identity5847 : scanCanonicalize (H12AffineFastState.compose env5847 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound5847 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env5848 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1692,8200,8867,1213,262144,1024,8200,1212,32,16,35,8329,16,262824,1693,1692,2561,1672,649,173,544,1045,512]

theorem envBound5848 : H12AffineFastState.Bounded env5848 := by
  intro p hp
  have h : env5848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5847_5848 : H12AffineEnvironment.transform 7 173 env5847 = env5848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env5847 == env5848) = true)

theorem identity5848 : scanCanonicalize (H12AffineFastState.compose env5848 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1583) := by decide +kernel

theorem selectedBound5848 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5849 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1692,8200,8867,1213,1583,1024,8200,1212,32,16,35,8329,16,1159,1693,1692,2561,1672,649,173,544,1045,512]

theorem envBound5849 : H12AffineFastState.Bounded env5849 := by
  intro p hp
  have h : env5849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5848_5849 : H12AffineEnvironment.transform 17 1583 env5848 = env5849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1583 env5848 == env5849) = true)

def env5850 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,115734,8388608,41003,8329,8388609,323712,16385,16812,22561,74795,8467755,256,20480,95382,8389564]

theorem envBound5850 : H12AffineFastState.Bounded env5850 := by
  intro p hp
  have h : env5850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5841_5850 : H12AffineEnvironment.transform 5 17 env5841 = env5850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5841 == env5850) = true)

def env5851 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,115734,5376,41003,8329,5377,323712,16385,16812,22561,74795,73771,256,20480,95382,5820]

theorem envBound5851 : H12AffineFastState.Bounded env5851 := by
  intro p hp
  have h : env5851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5850_5851 : H12AffineEnvironment.transform 22 5376 env5850 = env5851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5376 env5850 == env5851) = true)

theorem identity5851 : scanCanonicalize (H12AffineFastState.compose env5851 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(14+1) ^^^ 25781) := by decide +kernel

theorem selectedBound5851 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env5852 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,25781,65536,4524,262144,1024,25781,4097,73891,5376,17566,8329,5377,267317,16385,16812,22561,74795,73771,256,20480,95382,5820]

theorem envBound5852 : H12AffineFastState.Bounded env5852 := by
  intro p hp
  have h : env5852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5851_5852 : H12AffineEnvironment.transform 14 25781 env5851 = env5852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25781 env5851 == env5852) = true)

theorem identity5852 : scanCanonicalize (H12AffineFastState.compose env5852 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 7308) := by decide +kernel

theorem selectedBound5852 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env5853 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,25781,65536,4524,7308,1024,25781,4097,73891,5376,17566,8329,5377,2233,16385,16812,22561,74795,73771,256,20480,95382,5820]

theorem envBound5853 : H12AffineFastState.Bounded env5853 := by
  intro p hp
  have h : env5853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5852_5853 : H12AffineEnvironment.transform 17 7308 env5852 = env5853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7308 env5852 == env5853) = true)

theorem identity5853 : scanCanonicalize (H12AffineFastState.compose env5853 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(15+1) ^^^ 26002) := by decide +kernel

theorem selectedBound5853 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env5854 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,25781,26002,4524,7308,1024,25781,4097,17713,5376,17566,8329,5377,2233,16385,16812,22561,16825,17849,256,20480,4356,5820]

theorem envBound5854 : H12AffineFastState.Bounded env5854 := by
  intro p hp
  have h : env5854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5853_5854 : H12AffineEnvironment.transform 15 26002 env5853 = env5854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26002 env5853 == env5854) = true)

theorem identity5854 : scanCanonicalize (H12AffineFastState.compose env5854 (packedSelected [1,5,6,10,12,15,17,21] rootPS)) = affineNative (2^(13+1) ^^^ 6927) := by decide +kernel

theorem selectedBound5854 : packedSelected [1,5,6,10,12,15,17,21] rootPS < 2^1333 := by decide +kernel

def env5855 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,6927,16314,16029,4524,7308,1024,16314,4097,7742,5376,8081,8329,5377,2233,6926,6819,814,6838,7862,256,2831,4356,5820]

theorem envBound5855 : H12AffineFastState.Bounded env5855 := by
  intro p hp
  have h : env5855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5854_5855 : H12AffineEnvironment.transform 13 6927 env5854 = env5855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6927 env5854 == env5855) = true)

theorem identity5855 : scanCanonicalize (H12AffineFastState.compose env5855 (packedSelected [0,1,3,6,7,13,17,20,24,28] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound5855 : packedSelected [0,1,3,6,7,13,17,20,24,28] rootPS < 2^1333 := by decide +kernel

def env5856 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,6819,15894,16029,4096,7308,1024,15894,4097,7742,5292,7741,8329,5293,2233,6818,6819,642,6838,7862,172,2723,4264,5820]

theorem envBound5856 : H12AffineFastState.Bounded env5856 := by
  intro p hp
  have h : env5856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5855_5856 : H12AffineEnvironment.transform 7 172 env5855 = env5856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env5855 == env5856) = true)

theorem identity5856 : scanCanonicalize (H12AffineFastState.compose env5856 (packedSelected [0,1,5,6,7,10,12,13,15,17,20] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound5856 : packedSelected [0,1,5,6,7,10,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env5857 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1693,8192,3134,10379,10240,1693,2577,1024,10379,1692,2211,561,2208,8329,560,2233,3135,3134,642,3115,2091,172,2723,1589,33]

theorem envBound5857 : H12AffineFastState.Bounded env5857 := by
  intro p hp
  have h : env5857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5856_5857 : H12AffineEnvironment.transform 11 1693 env5856 = env5857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env5856 == env5857) = true)

theorem identity5857 : scanCanonicalize (H12AffineFastState.compose env5857 (packedSelected [0,1,2,4,5,7,9,10,11,12,13,15,17,23] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound5857 : packedSelected [0,1,2,4,5,7,9,10,11,12,13,15,17,23] rootPS < 2^1333 := by decide +kernel

def env5858 : List Nat := [2,4,8,16,32,17,57,21,512,1024,2048,1572,8192,3134,10290,10240,1572,2577,1024,10290,1573,2074,561,2073,8240,560,2048,3135,3134,571,3115,2091,21,2586,1589,33]

theorem envBound5858 : H12AffineFastState.Bounded env5858 := by
  intro p hp
  have h : env5858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5857_5858 : H12AffineEnvironment.transform 6 57 env5857 = env5858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env5857 == env5858) = true)

theorem identity5858 : scanCanonicalize (H12AffineFastState.compose env5858 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound5858 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env5859 : List Nat := [2,4,8,16,32,17,57,21,512,1024,2048,1572,2563,3134,561,515,1572,2577,1024,561,1573,2074,561,2073,2611,560,2048,3135,3134,571,3115,2091,21,2586,1589,33]

theorem envBound5859 : H12AffineFastState.Bounded env5859 := by
  intro p hp
  have h : env5859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5858_5859 : H12AffineEnvironment.transform 12 2563 env5858 = env5859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env5858 == env5859) = true)

theorem identity5859 : scanCanonicalize (H12AffineFastState.compose env5859 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1060) := by decide +kernel

theorem selectedBound5859 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env5860 : List Nat := [2,4,8,16,32,17,57,21,512,1024,1060,1572,1575,26,561,515,1572,1589,1024,561,1573,1086,561,1085,1559,560,1060,27,26,571,15,1039,21,1598,1589,33]

theorem envBound5860 : H12AffineFastState.Bounded env5860 := by
  intro p hp
  have h : env5860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5859_5860 : H12AffineEnvironment.transform 10 1060 env5859 = env5860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env5859 == env5860) = true)

theorem identity5860 : scanCanonicalize (H12AffineFastState.compose env5860 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound5860 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env5861 : List Nat := [2,4,8,16,32,17,57,21,512,36,0,512,515,26,561,515,512,529,36,561,513,26,561,25,563,560,0,27,26,571,15,43,21,538,529,33]

theorem envBound5861 : H12AffineFastState.Bounded env5861 := by
  intro p hp
  have h : env5861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5860_5861 : H12AffineEnvironment.transform 9 36 env5860 = env5861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env5860 == env5861) = true)

theorem identity5861 : scanCanonicalize (H12AffineFastState.compose env5861 (packedSelected [0,3,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound5861 : packedSelected [0,3,6,8] rootPS < 2^1333 := by decide +kernel

def env5862 : List Nat := [2,4,8,16,17,17,8,21,512,21,0,512,515,26,512,515,512,529,21,512,513,26,512,25,514,513,0,27,26,522,15,26,21,538,529,16]

theorem envBound5862 : H12AffineFastState.Bounded env5862 := by
  intro p hp
  have h : env5862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5861_5862 : H12AffineEnvironment.transform 4 17 env5861 = env5862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env5861 == env5862) = true)

theorem identity5862 : scanCanonicalize (H12AffineFastState.compose env5862 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5862 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5863 : List Nat := [2,4,8,0,1,1,8,5,512,5,0,512,515,10,512,515,512,513,5,512,513,10,512,9,514,513,0,11,10,522,15,10,5,522,513,0]

theorem envBound5863 : H12AffineFastState.Bounded env5863 := by
  intro p hp
  have h : env5863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5862_5863 : H12AffineEnvironment.transform 3 0 env5862 = env5863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5862 == env5863) = true)

theorem identity5863 : scanCanonicalize (H12AffineFastState.compose env5863 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5863 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env5864 : List Nat := [2,4,2,0,1,1,2,5,512,5,0,512,515,0,512,515,512,513,5,512,513,0,512,3,514,513,0,1,0,512,5,0,5,512,513,0]

theorem envBound5864 : H12AffineFastState.Bounded env5864 := by
  intro p hp
  have h : env5864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5863_5864 : H12AffineEnvironment.transform 2 2 env5863 = env5864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5863 == env5864) = true)

theorem identity5864 : scanCanonicalize (H12AffineFastState.compose env5864 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5864 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5865 : List Nat := [2,4,2,0,1,1,2,5,0,5,0,0,3,0,0,3,0,1,5,0,1,0,0,3,2,1,0,1,0,0,5,0,5,0,1,0]

theorem envBound5865 : H12AffineFastState.Bounded env5865 := by
  intro p hp
  have h : env5865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5864_5865 : H12AffineEnvironment.transform 8 0 env5864 = env5865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5864 == env5865) = true)

def env5866 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,115734,5377,41003,8329,5376,323712,16385,16812,22561,74795,73770,256,20480,95382,5821]

theorem envBound5866 : H12AffineFastState.Bounded env5866 := by
  intro p hp
  have h : env5866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5850_5866 : H12AffineEnvironment.transform 22 5377 env5850 = env5866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5377 env5850 == env5866) = true)

theorem identity5866 : scanCanonicalize (H12AffineFastState.compose env5866 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5866 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env5867 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4097,115734,5377,41003,8224,5376,323625,16385,16645,22561,74795,73770,256,20480,95295,5652]

theorem envBound5867 : H12AffineFastState.Bounded env5867 := by
  intro p hp
  have h : env5867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5866_5867 : H12AffineEnvironment.transform 6 41 env5866 = env5867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5866 == env5867) = true)

theorem identity5867 : scanCanonicalize (H12AffineFastState.compose env5867 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound5867 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env5868 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,16384,8201,65536,4357,262144,1024,8201,4097,91167,5377,34,8224,5376,282656,16385,16645,22561,74795,73770,256,20480,95295,5652]

theorem envBound5868 : H12AffineFastState.Bounded env5868 := by
  intro p hp
  have h : env5868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5867_5868 : H12AffineEnvironment.transform 14 8201 env5867 = env5868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env5867 == env5868) = true)

theorem identity5868 : scanCanonicalize (H12AffineFastState.compose env5868 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound5868 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5869 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,16384,8201,65536,4357,2080,1024,8201,4097,91167,5377,34,8224,5376,22528,16385,16645,22561,74795,73770,256,20480,95295,5652]

theorem envBound5869 : H12AffineFastState.Bounded env5869 := by
  intro p hp
  have h : env5869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5868_5869 : H12AffineEnvironment.transform 17 2080 env5868 = env5869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env5868 == env5869) = true)

theorem identity5869 : scanCanonicalize (H12AffineFastState.compose env5869 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4129) := by decide +kernel

theorem selectedBound5869 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env5870 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,4129,8201,65536,4357,2080,1024,8201,4097,78910,5377,34,8224,5376,2081,4128,4388,2048,74795,73770,256,33,74782,5652]

theorem envBound5870 : H12AffineFastState.Bounded env5870 := by
  intro p hp
  have h : env5870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5869_5870 : H12AffineEnvironment.transform 13 4129 env5869 = env5870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4129 env5869 == env5870) = true)

theorem identity5870 : scanCanonicalize (H12AffineFastState.compose env5870 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(15+1) ^^^ 2343) := by decide +kernel

theorem selectedBound5870 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env5871 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,4129,8201,2343,4357,2080,1024,8201,4097,15641,5377,34,8224,5376,2081,4128,4388,2048,11532,10509,256,33,11577,5652]

theorem envBound5871 : H12AffineFastState.Bounded env5871 := by
  intro p hp
  have h : env5871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5870_5871 : H12AffineEnvironment.transform 15 2343 env5870 = env5871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2343 env5870 == env5871) = true)

theorem identity5871 : scanCanonicalize (H12AffineFastState.compose env5871 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2852) := by decide +kernel

theorem selectedBound5871 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env5872 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,2852,8192,2821,8201,2343,2593,2080,1024,8201,2853,9789,3621,34,8224,3620,2081,2820,2560,2048,11532,10509,256,33,11577,3376]

theorem envBound5872 : H12AffineFastState.Bounded env5872 := by
  intro p hp
  have h : env5872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5871_5872 : H12AffineEnvironment.transform 11 2852 env5871 = env5872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2852 env5871 == env5872) = true)

theorem identity5872 : scanCanonicalize (H12AffineFastState.compose env5872 (packedSelected [2,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5872 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env5873 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,2592,8192,2561,8201,2083,2593,2080,1024,8201,2593,9789,3621,34,8224,3620,2081,2560,2560,2048,11272,10249,4,33,11325,3124]

theorem envBound5873 : H12AffineFastState.Bounded env5873 := by
  intro p hp
  have h : env5873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5872_5873 : H12AffineEnvironment.transform 7 4 env5872 = env5873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5872 == env5873) = true)

theorem identity5873 : scanCanonicalize (H12AffineFastState.compose env5873 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1542) := by decide +kernel

theorem selectedBound5873 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env5874 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,2592,1542,2561,1551,2083,2593,2080,1024,1551,2593,59,3621,34,1574,3620,2081,2560,2560,2048,2574,3599,4,33,2619,3124]

theorem envBound5874 : H12AffineFastState.Bounded env5874 := by
  intro p hp
  have h : env5874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5873_5874 : H12AffineEnvironment.transform 12 1542 env5873 = env5874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1542 env5873 == env5874) = true)

theorem identity5874 : scanCanonicalize (H12AffineFastState.compose env5874 (packedSelected [10,15] rootPS)) = affineNative (2^(10+1) ^^^ 1582) := by decide +kernel

theorem selectedBound5874 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env5875 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1582,1038,1542,1071,1551,1549,1039,1550,1024,1551,1039,59,11,34,1574,10,1551,1070,1070,1582,1056,33,4,33,1045,538]

theorem envBound5875 : H12AffineFastState.Bounded env5875 := by
  intro p hp
  have h : env5875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5874_5875 : H12AffineEnvironment.transform 10 1582 env5874 = env5875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1582 env5874 == env5875) = true)

def env5876 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1550,1038,1542,1039,1551,1549,1039,1550,1024,1551,1039,27,11,2,1542,10,1551,1038,1038,1550,1024,1,4,1,1045,538]

theorem envBound5876 : H12AffineFastState.Bounded env5876 := by
  intro p hp
  have h : env5876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5875_5876 : H12AffineEnvironment.transform 4 0 env5875 = env5876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env5875 == env5876) = true)

theorem identity5876 : scanCanonicalize (H12AffineFastState.compose env5876 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound5876 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5877 : List Nat := [2,4,8,16,0,17,9,4,512,20,538,26,530,27,539,537,27,538,20,539,27,27,11,2,530,10,539,26,26,538,20,1,4,1,1,538]

theorem envBound5877 : H12AffineFastState.Bounded env5877 := by
  intro p hp
  have h : env5877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5876_5877 : H12AffineEnvironment.transform 9 20 env5876 = env5877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env5876 == env5877) = true)

theorem identity5877 : scanCanonicalize (H12AffineFastState.compose env5877 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound5877 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env5878 : List Nat := [2,4,8,16,0,17,9,4,26,20,0,26,8,27,1,3,27,0,20,1,27,27,11,2,8,10,1,26,26,0,20,1,4,1,1,0]

theorem envBound5878 : H12AffineFastState.Bounded env5878 := by
  intro p hp
  have h : env5878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5877_5878 : H12AffineEnvironment.transform 8 26 env5877 = env5878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env5877 == env5878) = true)

def env5879 : List Nat := [2,4,8,4,0,5,9,4,14,0,0,14,8,15,1,3,15,0,0,1,15,15,11,2,8,10,1,14,14,0,0,1,4,1,1,0]

theorem envBound5879 : H12AffineFastState.Bounded env5879 := by
  intro p hp
  have h : env5879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5878_5879 : H12AffineEnvironment.transform 3 4 env5878 = env5879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env5878 == env5879) = true)

def env5880 : List Nat := [2,0,8,0,0,1,9,0,10,0,0,10,8,11,1,3,11,0,0,1,11,11,11,2,8,10,1,10,10,0,0,1,0,1,1,0]

theorem envBound5880 : H12AffineFastState.Bounded env5880 := by
  intro p hp
  have h : env5880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5879_5880 : H12AffineEnvironment.transform 1 0 env5879 = env5880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5879 == env5880) = true)

theorem identity5880 : scanCanonicalize (H12AffineFastState.compose env5880 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5880 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env5881 : List Nat := [2,0,3,0,0,1,2,0,1,0,0,1,3,0,1,3,0,0,0,1,0,0,0,2,3,1,1,1,1,0,0,1,0,1,1,0]

theorem envBound5881 : H12AffineFastState.Bounded env5881 := by
  intro p hp
  have h : env5881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5880_5881 : H12AffineEnvironment.transform 2 3 env5880 = env5881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5880 == env5881) = true)

def leafEnv5881 : List Nat := [2,0,3,0,0,1,2,0,1,0,0,1,3,0,1,3,0,0,0,1,0,0,0,2,1,3,1,1,1,1,1,0,0,1,0,1,1,2,1,0,1,0,0]

def active5881 : List Nat := [0]

def tree5881 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5881 : H12WitnessSearch.Good tree5881 := H12GlobalWitnessIndex.good

theorem leafIdentity5881 : H12AffineFastState.composeSystem env5881 rootObs = leafEnv5881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5881 rootObs == leafEnv5881) = true)

theorem terminalChecked5881 : H12PackedTerminal.terminalCheckFast leafEnv5881 active5881 tree5881 = true := by decide +kernel

def env5882 : List Nat := [2,1,8,1,0,0,9,1,11,0,0,11,8,10,1,3,10,0,0,1,10,10,11,2,8,10,1,11,11,0,0,1,1,1,1,0]

theorem envBound5882 : H12AffineFastState.Bounded env5882 := by
  intro p hp
  have h : env5882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5879_5882 : H12AffineEnvironment.transform 1 1 env5879 = env5882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5879 == env5882) = true)

def env5883 : List Nat := [2,4,8,5,0,4,9,4,15,1,0,15,8,14,1,3,14,0,1,1,14,14,11,2,8,10,1,15,15,0,1,1,4,1,1,0]

theorem envBound5883 : H12AffineFastState.Bounded env5883 := by
  intro p hp
  have h : env5883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5878_5883 : H12AffineEnvironment.transform 3 5 env5878 = env5883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env5878 == env5883) = true)

theorem identity5883 : scanCanonicalize (H12AffineFastState.compose env5883 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound5883 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5884 : List Nat := [2,4,7,5,0,4,6,4,0,1,0,0,7,1,1,3,1,0,1,1,1,1,4,2,7,5,1,0,0,0,1,1,4,1,1,0]

theorem envBound5884 : H12AffineFastState.Bounded env5884 := by
  intro p hp
  have h : env5884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5883_5884 : H12AffineEnvironment.transform 2 7 env5883 = env5884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env5883 == env5884) = true)

def env5885 : List Nat := [2,4,8,16,1,17,8,4,512,1024,1551,1038,1542,1038,1551,1549,1039,1550,1024,1551,1039,26,11,3,1543,10,1551,1039,1039,1551,1025,0,4,0,1045,538]

theorem envBound5885 : H12AffineFastState.Bounded env5885 := by
  intro p hp
  have h : env5885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5875_5885 : H12AffineEnvironment.transform 4 1 env5875 = env5885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5875 == env5885) = true)

theorem identity5885 : scanCanonicalize (H12AffineFastState.compose env5885 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 526) := by decide +kernel

theorem selectedBound5885 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5886 : List Nat := [2,4,8,16,1,17,8,4,512,526,1,512,8,512,1,3,513,0,526,1,513,26,11,3,9,10,1,513,513,1,527,0,4,0,539,538]

theorem envBound5886 : H12AffineFastState.Bounded env5886 := by
  intro p hp
  have h : env5886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5885_5886 : H12AffineEnvironment.transform 9 526 env5885 = env5886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 526 env5885 == env5886) = true)

theorem identity5886 : scanCanonicalize (H12AffineFastState.compose env5886 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5886 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env5887 : List Nat := [2,4,8,16,1,17,8,4,0,14,1,0,8,0,1,3,1,0,14,1,1,26,11,3,9,10,1,1,1,1,15,0,4,0,27,26]

theorem envBound5887 : H12AffineFastState.Bounded env5887 := by
  intro p hp
  have h : env5887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5886_5887 : H12AffineEnvironment.transform 8 0 env5886 = env5887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5886 == env5887) = true)

def env5888 : List Nat := [2,4,8,4,1,5,8,4,0,14,1,0,8,0,1,3,1,0,14,1,1,14,11,3,9,10,1,1,1,1,15,0,4,0,15,14]

theorem envBound5888 : H12AffineFastState.Bounded env5888 := by
  intro p hp
  have h : env5888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5887_5888 : H12AffineEnvironment.transform 3 4 env5887 = env5888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env5887 == env5888) = true)

def env5889 : List Nat := [2,4,8,5,1,4,8,4,0,14,1,0,8,0,1,3,1,0,14,1,1,15,11,3,9,10,1,1,1,1,15,0,4,0,14,15]

theorem envBound5889 : H12AffineFastState.Bounded env5889 := by
  intro p hp
  have h : env5889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5887_5889 : H12AffineEnvironment.transform 3 5 env5887 = env5889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env5887 == env5889) = true)

theorem identity5889 : scanCanonicalize (H12AffineFastState.compose env5889 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound5889 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5890 : List Nat := [2,4,6,5,1,4,6,4,0,0,1,0,6,0,1,3,1,0,0,1,1,1,5,3,7,4,1,1,1,1,1,0,4,0,0,1]

theorem envBound5890 : H12AffineFastState.Bounded env5890 := by
  intro p hp
  have h : env5890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5889_5890 : H12AffineEnvironment.transform 2 6 env5889 = env5890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env5889 == env5890) = true)

theorem identity5890 : scanCanonicalize (H12AffineFastState.compose env5890 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5890 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env5891 : List Nat := [2,1,3,0,1,1,3,1,0,0,1,0,3,0,1,3,1,0,0,1,1,1,0,3,2,1,1,1,1,1,1,0,1,0,0,1]

theorem envBound5891 : H12AffineFastState.Bounded env5891 := by
  intro p hp
  have h : env5891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5890_5891 : H12AffineEnvironment.transform 1 1 env5890 = env5891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5890 == env5891) = true)

def leafEnv5891 : List Nat := [2,1,3,0,1,1,3,1,0,0,1,0,3,0,1,3,1,0,0,1,1,1,0,3,0,2,1,1,1,1,1,1,1,0,1,0,0,3,0,1,1,0,0]

def active5891 : List Nat := [0]

def tree5891 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5891 : H12WitnessSearch.Good tree5891 := H12GlobalWitnessIndex.good

theorem leafIdentity5891 : H12AffineFastState.composeSystem env5891 rootObs = leafEnv5891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5891 rootObs == leafEnv5891) = true)

theorem terminalChecked5891 : H12PackedTerminal.terminalCheckFast leafEnv5891 active5891 tree5891 = true := by decide +kernel

def env5892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41003,8329,8388689,323792,16385,16893,22641,74794,12644669,257,20560,4239488,8389612]

theorem envBound5892 : H12AffineFastState.Bounded env5892 := by
  intro p hp
  have h : env5892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5839_5892 : H12AffineEnvironment.transform 18 1025 env5839 = env5892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5839 == env5892) = true)

theorem identity5892 : scanCanonicalize (H12AffineFastState.compose env5892 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4292935) := by decide +kernel

theorem selectedBound5892 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,4292935,41003,8329,4292886,323792,16385,16893,22641,74794,94330,257,20560,4239488,4293291]

theorem envBound5893 : H12AffineFastState.Bounded env5893 := by
  intro p hp
  have h : env5893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5892_5893 : H12AffineEnvironment.transform 22 4292935 env5892 = env5893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292935 env5892 == env5893) = true)

def env5894 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,4292887,41003,8329,4292886,323712,16385,16813,22561,74794,94250,257,20480,4239488,4293291]

theorem envBound5894 : H12AffineFastState.Bounded env5894 := by
  intro p hp
  have h : env5894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5893_5894 : H12AffineEnvironment.transform 5 16 env5893 = env5894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5893 == env5894) = true)

def env5895 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,262144,1025,32768,4097,4194304,4292887,41003,8329,4292886,303232,4097,4525,2081,74794,73770,257,0,4239488,4293291]

theorem envBound5895 : H12AffineFastState.Bounded env5895 := by
  intro p hp
  have h : env5895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5894_5895 : H12AffineEnvironment.transform 13 4096 env5894 = env5895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env5894 == env5895) = true)

theorem identity5895 : scanCanonicalize (H12AffineFastState.compose env5895 (packedSelected [2,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33063) := by decide +kernel

theorem selectedBound5895 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env5896 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,33063,4525,262144,1025,32768,4097,4194304,4194352,41003,8329,4194353,303232,4097,4525,2081,42253,41229,257,0,4239488,4195212]

theorem envBound5896 : H12AffineFastState.Bounded env5896 := by
  intro p hp
  have h : env5896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5895_5896 : H12AffineEnvironment.transform 15 33063 env5895 = env5896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33063 env5895 == env5896) = true)

def env5897 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8200,8495,4525,262144,1025,8200,4097,4194304,4194352,35,8329,4194353,262280,4097,4525,2081,1285,261,257,0,4198536,4195212]

theorem envBound5897 : H12AffineFastState.Bounded env5897 := by
  intro p hp
  have h : env5897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5896_5897 : H12AffineEnvironment.transform 14 8200 env5896 = env5897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env5896 == env5897) = true)

theorem identity5897 : scanCanonicalize (H12AffineFastState.compose env5897 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 266387) := by decide +kernel

theorem selectedBound5897 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5898 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8200,8495,4525,262144,1025,8200,4097,266387,266403,35,8329,266402,262280,4097,4525,2081,1285,261,257,0,262171,267039]

theorem envBound5898 : H12AffineFastState.Bounded env5898 := by
  intro p hp
  have h : env5898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5897_5898 : H12AffineEnvironment.transform 21 266387 env5897 = env5898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 266387 env5897 == env5898) = true)

theorem identity5898 : scanCanonicalize (H12AffineFastState.compose env5898 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 1923) := by decide +kernel

theorem selectedBound5898 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env5899 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8200,8495,4525,1923,1025,8200,4097,5904,5920,35,8329,5921,1803,4097,4525,2081,1285,261,257,0,1944,5276]

theorem envBound5899 : H12AffineFastState.Bounded env5899 := by
  intro p hp
  have h : env5899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5898_5899 : H12AffineEnvironment.transform 17 1923 env5898 = env5899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1923 env5898 == env5899) = true)

theorem identity5899 : scanCanonicalize (H12AffineFastState.compose env5899 (packedSelected [0,1,3,4,7,8,9,10,12,13,15,24] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound5899 : packedSelected [0,1,3,4,7,8,9,10,12,13,15,24] rootPS < 2^1333 := by decide +kernel

def env5900 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1803,4096,8192,4096,8200,8495,4525,1923,1025,8200,4097,5904,5920,35,8329,5921,1803,4097,4525,1834,1285,261,257,0,1944,5276]

theorem envBound5900 : H12AffineFastState.Bounded env5900 := by
  intro p hp
  have h : env5900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5899_5900 : H12AffineEnvironment.transform 10 1803 env5899 = env5900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env5899 == env5900) = true)

theorem identity5900 : scanCanonicalize (H12AffineFastState.compose env5900 (packedSelected [3,4,5,7,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 4886) := by decide +kernel

theorem selectedBound5900 : packedSelected [3,4,5,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env5901 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1803,4096,4886,4096,4894,4665,4525,1923,1025,4894,4097,5904,5920,35,5023,5921,1803,4097,4525,1834,1285,261,257,0,1944,5276]

theorem envBound5901 : H12AffineFastState.Bounded env5901 := by
  intro p hp
  have h : env5901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5900_5901 : H12AffineEnvironment.transform 12 4886 env5900 = env5901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4886 env5900 == env5901) = true)

theorem identity5901 : scanCanonicalize (H12AffineFastState.compose env5901 (packedSelected [4,7,10,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound5901 : packedSelected [4,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env5902 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1703,4096,4794,4096,4786,4665,4097,1583,1025,4786,4097,5820,5772,35,4659,5773,1703,4097,4097,1670,1193,169,173,0,1588,5276]

theorem envBound5902 : H12AffineFastState.Bounded env5902 := by
  intro p hp
  have h : env5902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5901_5902 : H12AffineEnvironment.transform 7 172 env5901 = env5902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env5901 == env5902) = true)

theorem identity5902 : scanCanonicalize (H12AffineFastState.compose env5902 (packedSelected [4,5,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5902 : packedSelected [4,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env5903 : List Nat := [2,4,8,16,32,16,128,172,0,1024,1191,4096,4282,4096,4274,4153,4097,1071,1025,4274,4097,5308,5260,35,4147,5261,1191,4097,4097,1158,1193,169,173,0,1076,5276]

theorem envBound5903 : H12AffineFastState.Bounded env5903 := by
  intro p hp
  have h : env5903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5902_5903 : H12AffineEnvironment.transform 8 0 env5902 = env5903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5902 == env5903) = true)

theorem identity5903 : scanCanonicalize (H12AffineFastState.compose env5903 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound5903 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env5904 : List Nat := [2,4,8,16,32,16,128,172,0,1024,1191,1,187,1,179,56,0,1071,1025,179,0,1213,1165,35,50,1164,1191,0,0,1158,1193,169,173,0,1076,1181]

theorem envBound5904 : H12AffineFastState.Bounded env5904 := by
  intro p hp
  have h : env5904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5903_5904 : H12AffineEnvironment.transform 11 1 env5903 = env5904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env5903 == env5904) = true)

theorem identity5904 : scanCanonicalize (H12AffineFastState.compose env5904 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5904 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env5905 : List Nat := [2,4,8,16,32,16,41,5,0,1024,1038,1,18,1,26,56,0,1071,1025,26,0,1044,1060,35,50,1061,1038,0,0,1071,1024,0,4,0,1076,1076]

theorem envBound5905 : H12AffineFastState.Bounded env5905 := by
  intro p hp
  have h : env5905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5904_5905 : H12AffineEnvironment.transform 6 41 env5904 = env5905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5904 == env5905) = true)

def env5906 : List Nat := [2,4,8,16,32,16,41,5,0,0,14,1,18,1,26,56,0,47,1,26,0,20,36,35,50,37,14,0,0,47,0,0,4,0,52,52]

theorem envBound5906 : H12AffineFastState.Bounded env5906 := by
  intro p hp
  have h : env5906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5905_5906 : H12AffineEnvironment.transform 9 0 env5905 = env5906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env5905 == env5906) = true)

theorem identity5906 : scanCanonicalize (H12AffineFastState.compose env5906 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound5906 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5907 : List Nat := [2,4,8,16,15,16,6,5,0,0,14,1,18,1,26,23,0,0,1,26,0,20,11,12,29,10,14,0,0,0,0,0,4,0,27,27]

theorem envBound5907 : H12AffineFastState.Bounded env5907 := by
  intro p hp
  have h : env5907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5906_5907 : H12AffineEnvironment.transform 4 15 env5906 = env5907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env5906 == env5907) = true)

def env5908 : List Nat := [2,4,8,4,15,4,6,5,0,0,14,1,6,1,14,3,0,0,1,14,0,0,11,12,9,10,14,0,0,0,0,0,4,0,15,15]

theorem envBound5908 : H12AffineFastState.Bounded env5908 := by
  intro p hp
  have h : env5908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5907_5908 : H12AffineEnvironment.transform 3 4 env5907 = env5908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env5907 == env5908) = true)

def env5909 : List Nat := [2,4,8,5,15,5,6,5,0,0,14,1,7,1,15,2,0,0,1,15,0,1,11,12,8,10,14,0,0,0,0,0,4,0,14,14]

theorem envBound5909 : H12AffineFastState.Bounded env5909 := by
  intro p hp
  have h : env5909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5907_5909 : H12AffineEnvironment.transform 3 5 env5907 = env5909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env5907 == env5909) = true)

theorem identity5909 : scanCanonicalize (H12AffineFastState.compose env5909 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound5909 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5910 : List Nat := [2,4,7,5,0,5,6,5,0,0,1,1,7,1,0,2,0,0,1,0,0,1,4,3,7,5,1,0,0,0,0,0,4,0,1,1]

theorem envBound5910 : H12AffineFastState.Bounded env5910 := by
  intro p hp
  have h : env5910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5909_5910 : H12AffineEnvironment.transform 2 7 env5909 = env5910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env5909 == env5910) = true)

theorem identity5910 : scanCanonicalize (H12AffineFastState.compose env5910 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5910 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env5911 : List Nat := [2,0,3,1,0,1,2,1,0,0,1,1,3,1,0,2,0,0,1,0,0,1,0,3,3,1,1,0,0,0,0,0,0,0,1,1]

theorem envBound5911 : H12AffineFastState.Bounded env5911 := by
  intro p hp
  have h : env5911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5910_5911 : H12AffineEnvironment.transform 1 0 env5910 = env5911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5910 == env5911) = true)

def leafEnv5911 : List Nat := [2,0,3,1,0,1,2,1,0,0,1,1,3,1,0,2,0,0,1,0,0,1,0,3,1,3,1,1,1,0,0,0,0,0,0,0,1,2,1,1,1,0,0]

def active5911 : List Nat := [0]

def tree5911 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5911 : H12WitnessSearch.Good tree5911 := H12GlobalWitnessIndex.good

theorem leafIdentity5911 : H12AffineFastState.composeSystem env5911 rootObs = leafEnv5911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5911 rootObs == leafEnv5911) = true)

theorem terminalChecked5911 : H12PackedTerminal.terminalCheckFast leafEnv5911 active5911 tree5911 = true := by decide +kernel

def env5912 : List Nat := [2,4,8,16,32,16,41,5,0,1,15,1,18,1,26,56,0,46,0,26,0,21,37,35,50,36,15,0,0,46,1,0,4,0,53,53]

theorem envBound5912 : H12AffineFastState.Bounded env5912 := by
  intro p hp
  have h : env5912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5905_5912 : H12AffineEnvironment.transform 9 1 env5905 = env5912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env5905 == env5912) = true)

theorem identity5912 : scanCanonicalize (H12AffineFastState.compose env5912 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound5912 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5913 : List Nat := [2,4,8,11,32,11,41,5,0,1,15,1,9,1,1,35,0,46,0,1,0,14,37,35,41,36,15,0,0,46,1,0,4,0,46,46]

theorem envBound5913 : H12AffineFastState.Bounded env5913 := by
  intro p hp
  have h : env5913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5912_5913 : H12AffineEnvironment.transform 3 11 env5912 = env5913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env5912 == env5913) = true)

def env5914 : List Nat := [2,4,8,11,0,11,9,5,0,1,15,1,9,1,1,3,0,14,0,1,0,14,5,3,9,4,15,0,0,14,1,0,4,0,14,14]

theorem envBound5914 : H12AffineFastState.Bounded env5914 := by
  intro p hp
  have h : env5914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5913_5914 : H12AffineEnvironment.transform 4 0 env5913 = env5914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env5913 == env5914) = true)

def env5915 : List Nat := [2,4,8,11,1,11,8,5,0,1,15,1,9,1,1,2,0,15,0,1,0,14,4,2,8,5,15,0,0,15,1,0,4,0,15,15]

theorem envBound5915 : H12AffineFastState.Bounded env5915 := by
  intro p hp
  have h : env5915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5913_5915 : H12AffineEnvironment.transform 4 1 env5913 = env5915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5913 == env5915) = true)

theorem identity5915 : scanCanonicalize (H12AffineFastState.compose env5915 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound5915 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5916 : List Nat := [2,4,6,5,1,5,6,5,0,1,1,1,7,1,1,2,0,1,0,1,0,0,4,2,6,5,1,0,0,1,1,0,4,0,1,1]

theorem envBound5916 : H12AffineFastState.Bounded env5916 := by
  intro p hp
  have h : env5916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5915_5916 : H12AffineEnvironment.transform 2 6 env5915 = env5916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env5915 == env5916) = true)

theorem identity5916 : scanCanonicalize (H12AffineFastState.compose env5916 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5916 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env5917 : List Nat := [2,0,2,1,1,1,2,1,0,1,1,1,3,1,1,2,0,1,0,1,0,0,0,2,2,1,1,0,0,1,1,0,0,0,1,1]

theorem envBound5917 : H12AffineFastState.Bounded env5917 := by
  intro p hp
  have h : env5917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5916_5917 : H12AffineEnvironment.transform 1 0 env5916 = env5917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5916 == env5917) = true)

def leafEnv5917 : List Nat := [2,0,2,1,1,1,2,1,0,1,1,1,3,1,1,2,0,1,0,1,0,0,0,2,0,2,1,1,1,0,0,1,1,0,0,0,1,3,1,1,1,0,0]

def active5917 : List Nat := [0]

def tree5917 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5917 : H12WitnessSearch.Good tree5917 := H12GlobalWitnessIndex.good

theorem leafIdentity5917 : H12AffineFastState.composeSystem env5917 rootObs = leafEnv5917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5917 rootObs == leafEnv5917) = true)

theorem terminalChecked5917 : H12PackedTerminal.terminalCheckFast leafEnv5917 active5917 tree5917 = true := by decide +kernel

def env5918 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8201,8494,4525,262144,1025,8201,4097,4194304,4194352,34,8329,4194353,262281,4097,4525,2081,1284,260,257,0,4198537,4195212]

theorem envBound5918 : H12AffineFastState.Bounded env5918 := by
  intro p hp
  have h : env5918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5896_5918 : H12AffineEnvironment.transform 14 8201 env5896 = env5918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env5896 == env5918) = true)

theorem identity5918 : scanCanonicalize (H12AffineFastState.compose env5918 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4383) := by decide +kernel

theorem selectedBound5918 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5919 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8201,8494,4525,4383,1025,8201,4097,4194304,4194352,34,8329,4194353,4502,4097,4525,2081,1284,260,257,0,4198537,4195212]

theorem envBound5919 : H12AffineFastState.Bounded env5919 := by
  intro p hp
  have h : env5919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5918_5919 : H12AffineEnvironment.transform 17 4383 env5918 = env5919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4383 env5918 == env5919) = true)

theorem identity5919 : scanCanonicalize (H12AffineFastState.compose env5919 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 1841) := by decide +kernel

theorem selectedBound5919 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env5920 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1841,8192,1841,8201,8494,1692,1582,1025,8201,1840,4194304,4194352,34,8329,4194353,1703,1840,1692,2081,1284,260,257,0,4196280,4195212]

theorem envBound5920 : H12AffineFastState.Bounded env5920 := by
  intro p hp
  have h : env5920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5919_5920 : H12AffineEnvironment.transform 11 1841 env5919 = env5920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1841 env5919 == env5920) = true)

theorem identity5920 : scanCanonicalize (H12AffineFastState.compose env5920 (packedSelected [0,4,7,8,9,10,12,15,17,28] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound5920 : packedSelected [0,4,7,8,9,10,12,15,17,28] rootPS < 2^1333 := by decide +kernel

def env5921 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1551,1841,8192,1841,8201,8494,1692,1582,1025,8201,1840,4194304,4194352,34,8329,4194353,1703,1840,1692,1582,1284,260,257,0,4196280,4195212]

theorem envBound5921 : H12AffineFastState.Bounded env5921 := by
  intro p hp
  have h : env5921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5920_5921 : H12AffineEnvironment.transform 10 1551 env5920 = env5921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env5920 == env5921) = true)

theorem identity5921 : scanCanonicalize (H12AffineFastState.compose env5921 (packedSelected [0,1,2,3,4,5,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound5921 : packedSelected [0,1,2,3,4,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env5922 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1551,1841,1031,1841,1038,1321,1692,1582,1025,1038,1840,4194304,4194352,34,1166,4194353,1703,1840,1692,1582,1284,260,257,0,4196280,4195212]

theorem envBound5922 : H12AffineFastState.Bounded env5922 := by
  intro p hp
  have h : env5922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5921_5922 : H12AffineEnvironment.transform 12 1031 env5921 = env5922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env5921 == env5922) = true)

theorem identity5922 : scanCanonicalize (H12AffineFastState.compose env5922 (packedSelected [1,4,7,8,10,11,13] rootPS)) = affineNative (2^(21+1) ^^^ 648) := by decide +kernel

theorem selectedBound5922 : packedSelected [1,4,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env5923 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1551,1841,1031,1841,1038,1321,1692,1582,1025,1038,1840,648,696,34,1166,697,1703,1840,1692,1582,1284,260,257,0,1328,260]

theorem envBound5923 : H12AffineFastState.Bounded env5923 := by
  intro p hp
  have h : env5923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5922_5923 : H12AffineEnvironment.transform 21 648 env5922 = env5923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 648 env5922 == env5923) = true)

theorem identity5923 : scanCanonicalize (H12AffineFastState.compose env5923 (packedSelected [0,1,2,3,11] rootPS)) = affineNative (2^(9+1) ^^^ 392) := by decide +kernel

theorem selectedBound5923 : packedSelected [0,1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env5924 : List Nat := [2,4,8,16,32,16,128,256,512,392,903,697,399,697,390,161,788,934,393,390,696,648,696,34,262,697,815,696,788,934,140,260,257,0,184,260]

theorem envBound5924 : H12AffineFastState.Bounded env5924 := by
  intro p hp
  have h : env5924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5923_5924 : H12AffineEnvironment.transform 9 392 env5923 = env5924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 392 env5923 == env5924) = true)

theorem identity5924 : scanCanonicalize (H12AffineFastState.compose env5924 (packedSelected [0,1,3,7,9,10,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound5924 : packedSelected [0,1,3,7,9,10,15] rootPS < 2^1333 := by decide +kernel

def env5925 : List Nat := [2,4,8,16,32,16,128,172,512,36,555,697,35,697,42,161,696,522,37,42,696,648,696,34,170,697,643,696,696,522,140,168,173,0,184,168]

theorem envBound5925 : H12AffineFastState.Bounded env5925 := by
  intro p hp
  have h : env5925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5924_5925 : H12AffineEnvironment.transform 7 172 env5924 = env5925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env5924 == env5925) = true)

theorem identity5925 : scanCanonicalize (H12AffineFastState.compose env5925 (packedSelected [0,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5925 : packedSelected [0,3,8] rootPS < 2^1333 := by decide +kernel

def env5926 : List Nat := [2,4,8,16,32,16,40,4,512,36,555,529,35,529,42,9,528,522,37,42,528,544,528,34,2,529,555,528,528,522,36,0,5,0,16,0]

theorem envBound5926 : H12AffineFastState.Bounded env5926 := by
  intro p hp
  have h : env5926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5925_5926 : H12AffineEnvironment.transform 6 40 env5925 = env5926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5925 == env5926) = true)

def env5927 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4525,262144,1025,32768,4097,4194304,4292887,41003,8329,4292886,303233,4096,4524,2080,74794,73771,257,1,4239488,4293291]

theorem envBound5927 : H12AffineFastState.Bounded env5927 := by
  intro p hp
  have h : env5927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5894_5927 : H12AffineEnvironment.transform 13 4097 env5894 = env5927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env5894 == env5927) = true)

theorem identity5927 : scanCanonicalize (H12AffineFastState.compose env5927 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound5927 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env5928 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4525,262144,1025,32768,4097,73891,41396,41003,8329,41397,303233,4096,4524,2080,74794,73771,257,1,102435,41480]

theorem envBound5928 : H12AffineFastState.Bounded env5928 := by
  intro p hp
  have h : env5928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5927_5928 : H12AffineEnvironment.transform 21 73891 env5927 = env5928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env5927 == env5928) = true)

theorem identity5928 : scanCanonicalize (H12AffineFastState.compose env5928 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 75954) := by decide +kernel

theorem selectedBound5928 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env5929 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4525,75954,1025,32768,4097,73891,41396,41003,8329,41397,100403,4096,4524,2080,74794,73771,257,1,102435,41480]

theorem envBound5929 : H12AffineFastState.Bounded env5929 := by
  intro p hp
  have h : env5929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5928_5929 : H12AffineEnvironment.transform 17 75954 env5928 = env5929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75954 env5928 == env5929) = true)

theorem identity5929 : scanCanonicalize (H12AffineFastState.compose env5929 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound5929 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env5930 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,33166,4525,43324,1025,32768,4097,41261,41396,41003,8329,41397,2493,4096,4524,2080,42404,41381,257,1,4525,41480]

theorem envBound5930 : H12AffineFastState.Bounded env5930 := by
  intro p hp
  have h : env5930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5929_5930 : H12AffineEnvironment.transform 15 33166 env5929 = env5930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env5929 == env5930) = true)

theorem identity5930 : scanCanonicalize (H12AffineFastState.compose env5930 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound5930 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env5931 : List Nat := [2,4,8,16,32,16,128,256,512,1024,951,4096,8192,4097,32768,33166,4525,41611,1025,32768,4097,41261,41396,41003,8329,41397,522,4096,4524,919,42404,41381,257,1,4525,41480]

theorem envBound5931 : H12AffineFastState.Bounded env5931 := by
  intro p hp
  have h : env5931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5930_5931 : H12AffineEnvironment.transform 10 951 env5930 = env5931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env5930 == env5931) = true)

theorem identity5931 : scanCanonicalize (H12AffineFastState.compose env5931 (packedSelected [0,2,4,7,9,11,23] rootPS)) = affineNative (2^(14+1) ^^^ 13972) := by decide +kernel

theorem selectedBound5931 : packedSelected [0,2,4,7,9,11,23] rootPS < 2^1333 := by decide +kernel

def env5932 : List Nat := [2,4,8,16,32,16,128,256,512,1024,951,4096,8192,4097,13972,14106,4525,5151,1025,13972,4097,6073,5920,5823,8329,5921,522,4096,4524,919,4912,5937,257,1,4525,5276]

theorem envBound5932 : H12AffineFastState.Bounded env5932 := by
  intro p hp
  have h : env5932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5931_5932 : H12AffineEnvironment.transform 14 13972 env5931 = env5932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13972 env5931 == env5932) = true)

theorem identity5932 : scanCanonicalize (H12AffineFastState.compose env5932 (packedSelected [0,1,4,5,7,8,9,12,15,21,24] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound5932 : packedSelected [0,1,4,5,7,8,9,12,15,21,24] rootPS < 2^1333 := by decide +kernel

def env5933 : List Nat := [2,4,8,16,32,16,128,256,512,1024,951,4096,8,4097,5788,5906,4525,5151,1025,5788,4097,6073,5920,5823,129,5921,522,4096,4524,919,4912,5937,257,1,4525,5276]

theorem envBound5933 : H12AffineFastState.Bounded env5933 := by
  intro p hp
  have h : env5933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5932_5933 : H12AffineEnvironment.transform 12 8 env5932 = env5933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env5932 == env5933) = true)

theorem identity5933 : scanCanonicalize (H12AffineFastState.compose env5933 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1686) := by decide +kernel

theorem selectedBound5933 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5934 : List Nat := [2,4,8,16,32,16,128,256,512,1024,951,1686,8,1687,10,388,1851,649,1025,10,1687,303,438,41,129,439,522,1686,1850,919,1446,423,257,1,1851,522]

theorem envBound5934 : H12AffineFastState.Bounded env5934 := by
  intro p hp
  have h : env5934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5933_5934 : H12AffineEnvironment.transform 11 1686 env5933 = env5934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1686 env5933 == env5934) = true)

theorem identity5934 : scanCanonicalize (H12AffineFastState.compose env5934 (packedSelected [0,3,4,5,6,7,8,9,12,13,15,28] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound5934 : packedSelected [0,3,4,5,6,7,8,9,12,13,15,28] rootPS < 2^1333 := by decide +kernel

def env5935 : List Nat := [2,4,8,16,32,16,57,256,512,1024,782,1583,8,1582,10,317,1851,560,1025,10,1582,303,271,41,56,270,522,1583,1850,814,1311,286,257,1,1851,522]

theorem envBound5935 : H12AffineFastState.Bounded env5935 := by
  intro p hp
  have h : env5935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5934_5935 : H12AffineEnvironment.transform 6 57 env5934 = env5935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env5934 == env5935) = true)

theorem identity5935 : scanCanonicalize (H12AffineFastState.compose env5935 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound5935 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5936 : List Nat := [2,4,8,16,32,16,57,30,512,1024,528,1583,8,1582,10,35,1573,560,1025,10,1582,49,17,41,56,16,522,1583,1572,560,1025,0,31,1,1573,522]

theorem envBound5936 : H12AffineFastState.Bounded env5936 := by
  intro p hp
  have h : env5936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5935_5936 : H12AffineEnvironment.transform 7 30 env5935 = env5936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env5935 == env5936) = true)

def env5937 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,4292886,41003,8329,4292886,323713,16385,16812,22560,74794,94251,257,20481,4239488,4293291]

theorem envBound5937 : H12AffineFastState.Bounded env5937 := by
  intro p hp
  have h : env5937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5893_5937 : H12AffineEnvironment.transform 5 17 env5893 = env5937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5893 == env5937) = true)

theorem identity5937 : scanCanonicalize (H12AffineFastState.compose env5937 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 98475) := by decide +kernel

theorem selectedBound5937 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5938 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,98475,445,41003,8329,445,323713,16385,16812,22560,74794,94251,257,20481,77867,512]

theorem envBound5938 : H12AffineFastState.Bounded env5938 := by
  intro p hp
  have h : env5938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5937_5938 : H12AffineEnvironment.transform 21 98475 env5937 = env5938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98475 env5937 == env5938) = true)

theorem identity5938 : scanCanonicalize (H12AffineFastState.compose env5938 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound5938 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5939 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8495,4524,262144,1025,32768,4097,41348,445,41003,8329,445,323713,16385,16812,22560,1285,20740,257,20481,4356,512]

theorem envBound5939 : H12AffineFastState.Bounded env5939 := by
  intro p hp
  have h : env5939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5938_5939 : H12AffineEnvironment.transform 15 8495 env5938 = env5939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env5938 == env5939) = true)

theorem identity5939 : scanCanonicalize (H12AffineFastState.compose env5939 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound5939 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5940 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,8495,4524,262144,1025,26261,4097,18193,445,18110,8329,445,267796,16385,16812,22560,1285,20740,257,20481,4356,512]

theorem envBound5940 : H12AffineFastState.Bounded env5940 := by
  intro p hp
  have h : env5940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5939_5940 : H12AffineEnvironment.transform 14 26261 env5939 = env5940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env5939 == env5940) = true)

theorem identity5940 : scanCanonicalize (H12AffineFastState.compose env5940 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4525) := by decide +kernel

theorem selectedBound5940 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5941 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,14136,8495,4524,262144,1025,14136,4097,5820,445,5907,8329,445,267796,4524,4097,2445,1285,169,257,428,4356,512]

theorem envBound5941 : H12AffineFastState.Bounded env5941 := by
  intro p hp
  have h : env5941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5940_5941 : H12AffineEnvironment.transform 13 4525 env5940 = env5941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4525 env5940 == env5941) = true)

theorem identity5941 : scanCanonicalize (H12AffineFastState.compose env5941 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound5941 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env5942 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,14136,8495,4524,2184,1025,14136,4097,5820,445,5907,8329,445,7836,4524,4097,2445,1285,169,257,428,4356,512]

theorem envBound5942 : H12AffineFastState.Bounded env5942 := by
  intro p hp
  have h : env5942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5941_5942 : H12AffineEnvironment.transform 17 2184 env5941 = env5942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env5941 == env5942) = true)

theorem identity5942 : scanCanonicalize (H12AffineFastState.compose env5942 (packedSelected [18,23] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5942 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env5943 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,4357,14136,8495,4356,2080,1025,14136,4097,5652,277,5907,8225,277,7732,4356,4097,2341,1285,1,257,260,4356,512]

theorem envBound5943 : H12AffineFastState.Bounded env5943 := by
  intro p hp
  have h : env5943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5942_5943 : H12AffineEnvironment.transform 6 40 env5942 = env5943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5942 == env5943) = true)

end H12CloudChart1