import H12CloudChart1Data206

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity52425 : scanCanonicalize (H12AffineFastState.compose env52425 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound52425 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env52426 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,21511,5393,2340,1024,0,4112,33,16,3,268,17,2049,16401,17664,23589,20485,32,256,33,16385,513]

theorem envBound52426 : H12AffineFastState.Bounded env52426 := by
  intro p hp
  have h : env52426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52425_52426 : H12AffineEnvironment.transform 14 1 env52425 = env52426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env52425 == env52426) = true)

theorem identity52426 : scanCanonicalize (H12AffineFastState.compose env52426 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound52426 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52427 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,262,5393,2340,1024,0,4112,33,16,3,268,17,2049,5392,4097,2340,1284,32,256,33,5376,513]

theorem envBound52427 : H12AffineFastState.Bounded env52427 := by
  intro p hp
  have h : env52427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52426_52427 : H12AffineEnvironment.transform 13 5377 env52426 = env52427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52426 == env52427) = true)

theorem identity52427 : scanCanonicalize (H12AffineFastState.compose env52427 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound52427 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52428 : List Nat := [2,4,8,16,32,17,9,20,512,1024,2048,4096,25,5141,1,18,5125,2096,1024,0,4112,33,16,3,24,17,2049,5124,4097,2096,1040,32,20,33,5140,513]

theorem envBound52428 : H12AffineFastState.Bounded env52428 := by
  intro p hp
  have h : env52428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52427_52428 : H12AffineEnvironment.transform 7 20 env52427 = env52428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env52427 == env52428) = true)

theorem identity52428 : scanCanonicalize (H12AffineFastState.compose env52428 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound52428 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52429 : List Nat := [2,4,8,16,32,17,9,20,512,1024,2048,1573,25,560,1,18,544,2096,1024,0,1589,33,16,3,24,17,2049,545,1572,2096,1040,32,20,33,561,513]

theorem envBound52429 : H12AffineFastState.Bounded env52429 := by
  intro p hp
  have h : env52429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52428_52429 : H12AffineEnvironment.transform 11 1573 env52428 = env52429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env52428 == env52429) = true)

theorem identity52429 : scanCanonicalize (H12AffineFastState.compose env52429 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound52429 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52430 : List Nat := [2,4,8,16,32,17,9,20,512,53,2048,528,25,560,1,18,544,2096,53,0,512,33,16,3,24,17,2049,545,529,2096,37,32,20,33,561,513]

theorem envBound52430 : H12AffineFastState.Bounded env52430 := by
  intro p hp
  have h : env52430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52429_52430 : H12AffineEnvironment.transform 9 53 env52429 = env52430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52429 == env52430) = true)

theorem identity52430 : scanCanonicalize (H12AffineFastState.compose env52430 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52430 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52431 : List Nat := [2,4,8,16,0,17,9,20,512,21,2048,528,25,528,1,18,512,2064,21,0,512,1,16,3,24,17,2049,513,529,2064,5,0,20,1,529,513]

theorem envBound52431 : H12AffineFastState.Bounded env52431 := by
  intro p hp
  have h : env52431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52430_52431 : H12AffineEnvironment.transform 4 0 env52430 = env52431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52430 == env52431) = true)

theorem identity52431 : scanCanonicalize (H12AffineFastState.compose env52431 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound52431 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52432 : List Nat := [2,4,8,16,0,17,9,20,512,21,529,528,25,528,1,18,512,513,21,0,512,1,16,3,24,17,528,513,529,513,5,0,20,1,529,513]

theorem envBound52432 : H12AffineFastState.Bounded env52432 := by
  intro p hp
  have h : env52432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52431_52432 : H12AffineEnvironment.transform 10 529 env52431 = env52432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env52431 == env52432) = true)

def env52433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,272392,17,41310,8193,64,171280,57676,17665,442384,61704,272393,256,41341,16465,512]

theorem envBound52433 : H12AffineFastState.Bounded env52433 := by
  intro p hp
  have h : env52433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52409_52433 : H12AffineEnvironment.transform 22 17 env52409 = env52433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env52409 == env52433) = true)

theorem identity52433 : scanCanonicalize (H12AffineFastState.compose env52433 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 56576) := by decide +kernel

theorem selectedBound52433 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52434 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,56576,1024,32769,4161,62728,17,41310,8193,64,171280,57676,17665,138512,61704,62729,256,41341,16465,512]

theorem envBound52434 : H12AffineFastState.Bounded env52434 := by
  intro p hp
  have h : env52434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52433_52434 : H12AffineEnvironment.transform 17 56576 env52433 = env52434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56576 env52433 == env52434) = true)

theorem identity52434 : scanCanonicalize (H12AffineFastState.compose env52434 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound52434 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29993,8574,131072,10281,1024,29992,4161,33,17,21623,8193,64,157753,5221,17665,138512,1057,32,256,21588,16465,512]

theorem envBound52435 : H12AffineFastState.Bounded env52435 := by
  intro p hp
  have h : env52435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52434_52435 : H12AffineEnvironment.transform 14 29993 env52434 = env52435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env52434 == env52435) = true)

theorem identity52435 : scanCanonicalize (H12AffineFastState.compose env52435 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound52435 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env52436 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29993,8574,5393,10281,1024,29992,4161,33,17,21623,8193,64,32040,5221,17665,2049,1057,32,256,21588,16465,512]

theorem envBound52436 : H12AffineFastState.Bounded env52436 := by
  intro p hp
  have h : env52436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52435_52436 : H12AffineEnvironment.transform 16 5393 env52435 = env52436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env52435 == env52436) = true)

theorem identity52436 : scanCanonicalize (H12AffineFastState.compose env52436 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound52436 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52437 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2088,16384,23809,2390,5393,1,1024,23808,4161,33,17,21623,2089,64,21760,5221,17665,2049,1057,32,256,21588,16465,512]

theorem envBound52437 : H12AffineFastState.Bounded env52437 := by
  intro p hp
  have h : env52437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52436_52437 : H12AffineEnvironment.transform 12 2088 env52436 = env52437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env52436 == env52437) = true)

theorem identity52437 : scanCanonicalize (H12AffineFastState.compose env52437 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 3376) := by decide +kernel

theorem selectedBound52437 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env52438 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2088,3376,4145,2390,5393,1,1024,4144,4161,33,17,6471,2089,64,6192,5221,2097,2049,1057,32,256,6500,3425,512]

theorem envBound52438 : H12AffineFastState.Bounded env52438 := by
  intro p hp
  have h : env52438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52437_52438 : H12AffineEnvironment.transform 13 3376 env52437 = env52438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3376 env52437 == env52438) = true)

theorem identity52438 : scanCanonicalize (H12AffineFastState.compose env52438 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound52438 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52439 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,2088,3376,3377,2390,2065,1,1024,3376,3393,33,17,1095,2089,64,1328,2405,2097,2049,1057,32,256,1124,3425,512]

theorem envBound52439 : H12AffineFastState.Bounded env52439 := by
  intro p hp
  have h : env52439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52438_52439 : H12AffineEnvironment.transform 11 3328 env52438 = env52439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env52438 == env52439) = true)

theorem identity52439 : scanCanonicalize (H12AffineFastState.compose env52439 (packedSelected [0,1,2,6,7,8,10,14,15,23] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound52439 : packedSelected [0,1,2,6,7,8,10,14,15,23] rootPS < 2^1333 := by decide +kernel

def env52440 : List Nat := [2,4,8,16,32,64,9,256,512,1024,32,1312,8,1296,1297,374,49,1,1024,1296,1377,33,17,1095,9,64,1328,325,17,33,1057,32,256,1124,1345,512]

theorem envBound52440 : H12AffineFastState.Bounded env52440 := by
  intro p hp
  have h : env52440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52439_52440 : H12AffineEnvironment.transform 10 32 env52439 = env52440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env52439 == env52440) = true)

theorem identity52440 : scanCanonicalize (H12AffineFastState.compose env52440 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound52440 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env52441 : List Nat := [2,4,8,16,32,64,9,117,512,1024,32,1109,8,1125,1124,3,49,1,1024,1125,1044,33,17,1095,9,64,1093,48,17,33,1057,32,117,1124,1076,512]

theorem envBound52441 : H12AffineFastState.Bounded env52441 := by
  intro p hp
  have h : env52441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52440_52441 : H12AffineEnvironment.transform 7 117 env52440 = env52441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env52440 == env52441) = true)

theorem identity52441 : scanCanonicalize (H12AffineFastState.compose env52441 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound52441 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env52442 : List Nat := [2,4,8,16,32,64,9,117,512,549,32,624,8,576,577,3,49,1,549,576,561,33,17,610,9,64,608,48,17,33,516,32,117,577,529,512]

theorem envBound52442 : H12AffineFastState.Bounded env52442 := by
  intro p hp
  have h : env52442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52441_52442 : H12AffineEnvironment.transform 9 549 env52441 = env52442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env52441 == env52442) = true)

theorem identity52442 : scanCanonicalize (H12AffineFastState.compose env52442 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52442 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env52443 : List Nat := [2,4,8,0,32,64,9,101,512,549,32,608,8,576,577,3,33,1,549,576,545,33,1,610,9,64,608,32,1,33,516,32,101,577,513,512]

theorem envBound52443 : H12AffineFastState.Bounded env52443 := by
  intro p hp
  have h : env52443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52442_52443 : H12AffineEnvironment.transform 3 0 env52442 = env52443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52442 == env52443) = true)

def env52444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound52444 : H12AffineFastState.Bounded env52444 := by
  intro p hp
  have h : env52444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52230_52444 : H12AffineEnvironment.transform 18 1025 env52230 = env52444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env52230 == env52444) = true)

theorem identity52444 : scanCanonicalize (H12AffineFastState.compose env52444 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10626078) := by decide +kernel

theorem selectedBound52444 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env52445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10626078,8328,64,6677535,8626322,10507601,8830976,2334734,12796382,257,254130,196886,2263001]

theorem envBound52445 : H12AffineFastState.Bounded env52445 := by
  intro p hp
  have h : env52445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52444_52445 : H12AffineEnvironment.transform 23 10626078 env52444 = env52445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10626078 env52444 == env52445) = true)

def env52446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,155996,2114882,8328,64,6677535,115150,2241549,303452,2334734,4268162,257,254130,196886,2263001]

theorem envBound52446 : H12AffineFastState.Bounded env52446 := by
  intro p hp
  have h : env52446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52445_52446 : H12AffineEnvironment.transform 22 155996 env52445 = env52446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 155996 env52445 == env52446) = true)

def env52447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534744,155996,2114882,8328,64,215367,115150,2241549,303452,2334734,2592218,257,254130,196886,2263001]

theorem envBound52447 : H12AffineFastState.Bounded env52447 := by
  intro p hp
  have h : env52447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52446_52447 : H12AffineEnvironment.transform 21 2534744 env52446 = env52447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534744 env52446 == env52447) = true)

def env52448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155996,21762,8328,64,215367,115150,140365,303452,241742,499098,257,254130,196886,169881]

theorem envBound52448 : H12AffineFastState.Bounded env52448 := by
  intro p hp
  have h : env52448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52447_52448 : H12AffineEnvironment.transform 20 4160 env52447 = env52448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env52447 == env52448) = true)

theorem identity52448 : scanCanonicalize (H12AffineFastState.compose env52448 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound52448 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4160,441624,155996,21762,8328,64,171416,5393,140365,303452,156817,411973,257,144493,185801,169881]

theorem envBound52449 : H12AffineFastState.Bounded env52449 := by
  intro p hp
  have h : env52449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52448_52449 : H12AffineEnvironment.transform 15 54495 env52448 = env52449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env52448 == env52449) = true)

def env52450 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,4112,441624,155916,21762,8328,16,171416,5393,140317,303372,156817,411925,257,144445,185753,169881]

theorem envBound52450 : H12AffineFastState.Bounded env52450 := by
  intro p hp
  have h : env52450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52449_52450 : H12AffineEnvironment.transform 5 16 env52449 = env52450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52449 == env52450) = true)

theorem identity52450 : scanCanonicalize (H12AffineFastState.compose env52450 (packedSelected [1,4,7,9,19,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound52450 : packedSelected [1,4,7,9,19,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52451 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,146744,1025,32769,4112,32800,155916,21762,8328,16,171416,5393,140317,171060,156817,29741,257,144445,185753,169881]

theorem envBound52451 : H12AffineFastState.Bounded env52451 := by
  intro p hp
  have h : env52451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52450_52451 : H12AffineEnvironment.transform 17 146744 env52450 = env52451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env52450 == env52451) = true)

theorem identity52451 : scanCanonicalize (H12AffineFastState.compose env52451 (packedSelected [0,1,3,4,7,19,22,24,26,28] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound52451 : packedSelected [0,1,3,4,7,19,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env52452 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21761,398,131072,146744,1025,21760,4112,21793,155916,21762,8328,16,149657,5393,140317,149813,156817,29741,257,144445,131224,148120]

theorem envBound52452 : H12AffineFastState.Bounded env52452 := by
  intro p hp
  have h : env52452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52451_52452 : H12AffineEnvironment.transform 14 21761 env52451 = env52452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env52451 == env52452) = true)

theorem identity52452 : scanCanonicalize (H12AffineFastState.compose env52452 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 24981) := by decide +kernel

theorem selectedBound52452 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52453 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21761,398,24981,23725,1025,21760,4112,21793,153,21762,8328,16,10508,5393,17800,10400,1284,29741,257,21928,24845,8973]

theorem envBound52453 : H12AffineFastState.Bounded env52453 := by
  intro p hp
  have h : env52453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52452_52453 : H12AffineEnvironment.transform 16 24981 env52452 = env52453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24981 env52452 == env52453) = true)

theorem identity52453 : scanCanonicalize (H12AffineFastState.compose env52453 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound52453 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52454 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13444,8581,398,5393,10281,1025,8580,4112,8613,153,8582,8328,16,10508,5393,12556,10400,1284,169,257,8492,5513,8973]

theorem envBound52454 : H12AffineFastState.Bounded env52454 := by
  intro p hp
  have h : env52454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52453_52454 : H12AffineEnvironment.transform 13 13444 env52453 = env52454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env52453 == env52454) = true)

theorem identity52454 : scanCanonicalize (H12AffineFastState.compose env52454 (packedSelected [0,1,3,5,7,8,11,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound52454 : packedSelected [0,1,3,5,7,8,11,15,16] rootPS < 2^1333 := by decide +kernel

def env52455 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3329,8192,10629,8581,398,2064,10281,1025,8580,3345,8613,153,8582,8328,16,10508,2064,11277,10400,1284,169,257,8492,2184,8973]

theorem envBound52455 : H12AffineFastState.Bounded env52455 := by
  intro p hp
  have h : env52455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52454_52455 : H12AffineEnvironment.transform 11 3329 env52454 = env52455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env52454 == env52455) = true)

theorem identity52455 : scanCanonicalize (H12AffineFastState.compose env52455 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound52455 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env52456 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3329,388,2049,1,398,2064,2477,1025,0,3345,33,153,2,268,16,2184,2064,3465,2340,1284,169,257,168,2184,649]

theorem envBound52456 : H12AffineFastState.Bounded env52456 := by
  intro p hp
  have h : env52456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52455_52456 : H12AffineEnvironment.transform 12 388 env52455 = env52456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env52455 == env52456) = true)

theorem identity52456 : scanCanonicalize (H12AffineFastState.compose env52456 (packedSelected [0,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound52456 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env52457 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,3329,301,2049,1,295,2064,2308,1025,0,3345,33,48,2,268,16,2081,2064,3360,2340,1284,0,257,1,2081,544]

theorem envBound52457 : H12AffineFastState.Bounded env52457 := by
  intro p hp
  have h : env52457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52456_52457 : H12AffineEnvironment.transform 6 41 env52456 = env52457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env52456 == env52457) = true)

theorem identity52457 : scanCanonicalize (H12AffineFastState.compose env52457 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52457 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52458 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,3329,268,2049,1,262,2064,2308,1025,0,3345,0,17,2,268,16,2048,2064,3329,2309,1284,0,257,1,2048,513]

theorem envBound52458 : H12AffineFastState.Bounded env52458 := by
  intro p hp
  have h : env52458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52457_52458 : H12AffineEnvironment.transform 4 1 env52457 = env52458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52457 == env52458) = true)

theorem identity52458 : scanCanonicalize (H12AffineFastState.compose env52458 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound52458 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52459 : List Nat := [2,4,8,16,1,16,8,256,512,1024,261,1028,268,260,1,262,277,1,1025,0,1044,0,17,2,268,16,261,277,1028,0,1284,0,257,1,261,513]

theorem envBound52459 : H12AffineFastState.Bounded env52459 := by
  intro p hp
  have h : env52459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52458_52459 : H12AffineEnvironment.transform 10 261 env52458 = env52459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env52458 == env52459) = true)

theorem identity52459 : scanCanonicalize (H12AffineFastState.compose env52459 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound52459 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52460 : List Nat := [2,4,8,16,1,16,8,256,512,272,261,276,268,260,1,262,277,1,273,0,260,0,17,2,268,16,261,277,276,0,20,0,257,1,261,513]

theorem envBound52460 : H12AffineFastState.Bounded env52460 := by
  intro p hp
  have h : env52460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52459_52460 : H12AffineEnvironment.transform 9 272 env52459 = env52460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env52459 == env52460) = true)

theorem identity52460 : scanCanonicalize (H12AffineFastState.compose env52460 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound52460 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52461 : List Nat := [2,4,8,16,1,16,8,256,1,272,261,276,268,260,1,262,277,1,273,0,260,0,17,2,268,16,261,277,276,0,20,0,257,1,261,0]

theorem envBound52461 : H12AffineFastState.Bounded env52461 := by
  intro p hp
  have h : env52461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52460_52461 : H12AffineEnvironment.transform 8 1 env52460 = env52461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env52460 == env52461) = true)

theorem identity52461 : scanCanonicalize (H12AffineFastState.compose env52461 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound52461 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52462 : List Nat := [2,4,8,16,1,16,8,5,1,21,0,17,9,1,1,3,16,1,20,0,1,0,17,2,9,16,0,16,17,0,20,0,4,1,0,0]

theorem envBound52462 : H12AffineFastState.Bounded env52462 := by
  intro p hp
  have h : env52462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52461_52462 : H12AffineEnvironment.transform 7 5 env52461 = env52462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env52461 == env52462) = true)

theorem identity52462 : scanCanonicalize (H12AffineFastState.compose env52462 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52462 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52463 : List Nat := [2,4,8,11,1,11,8,5,1,14,0,10,9,1,1,3,11,1,15,0,1,0,10,2,9,11,0,11,10,0,15,0,4,1,0,0]

theorem envBound52463 : H12AffineFastState.Bounded env52463 := by
  intro p hp
  have h : env52463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52462_52463 : H12AffineEnvironment.transform 3 11 env52462 = env52463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52462 == env52463) = true)

theorem identity52463 : scanCanonicalize (H12AffineFastState.compose env52463 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound52463 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env52464 : List Nat := [2,4,3,0,1,0,3,5,1,5,0,1,2,1,1,3,0,1,4,0,1,0,1,2,2,0,0,0,1,0,4,0,4,1,0,0]

theorem envBound52464 : H12AffineFastState.Bounded env52464 := by
  intro p hp
  have h : env52464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52463_52464 : H12AffineEnvironment.transform 2 3 env52463 = env52464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env52463 == env52464) = true)

def env52465 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,4113,441624,155917,21762,8328,17,171416,5393,140316,303373,156817,411924,257,144444,185752,169881]

theorem envBound52465 : H12AffineFastState.Bounded env52465 := by
  intro p hp
  have h : env52465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52449_52465 : H12AffineEnvironment.transform 5 17 env52449 = env52465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52449 == env52465) = true)

theorem identity52465 : scanCanonicalize (H12AffineFastState.compose env52465 (packedSelected [1,4,7,9,19,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 182716) := by decide +kernel

theorem selectedBound52465 : packedSelected [1,4,7,9,19,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52466 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,182716,1025,32769,4113,29860,155917,21762,8328,17,171416,5393,140316,157873,156817,32936,257,144444,185752,169881]

theorem envBound52466 : H12AffineFastState.Bounded env52466 := by
  intro p hp
  have h : env52466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52465_52466 : H12AffineEnvironment.transform 17 182716 env52465 = env52466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182716 env52465 == env52466) = true)

theorem identity52466 : scanCanonicalize (H12AffineFastState.compose env52466 (packedSelected [5,8,10,11,16,17,18,20,23,24,26,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound52466 : packedSelected [5,8,10,11,16,17,18,20,23,24,26,28,32] rootPS < 2^1333 := by decide +kernel

def env52467 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,49168,2476,1025,32769,4113,29860,41245,21762,8328,17,23944,5393,58380,43169,42113,32936,257,62508,5512,22409]

theorem envBound52467 : H12AffineFastState.Bounded env52467 := by
  intro p hp
  have h : env52467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52466_52467 : H12AffineEnvironment.transform 16 49168 env52466 = env52467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env52466 == env52467) = true)

theorem identity52467 : scanCanonicalize (H12AffineFastState.compose env52467 (packedSelected [0,3,4,7,10,16,19,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound52467 : packedSelected [0,3,4,7,10,16,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env52468 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13325,32768,41091,46109,2476,1025,32769,4113,169,41245,8463,8328,17,10629,5393,36865,43169,42113,32936,257,32801,5512,9092]

theorem envBound52468 : H12AffineFastState.Bounded env52468 := by
  intro p hp
  have h : env52468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52467_52468 : H12AffineEnvironment.transform 13 13325 env52467 = env52468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env52467 == env52468) = true)

theorem identity52468 : scanCanonicalize (H12AffineFastState.compose env52468 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound52468 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env52469 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5512,32768,33030,38296,2476,1025,32769,4113,169,32920,138,269,17,2048,5393,36865,35108,34052,32936,257,32801,5512,513]

theorem envBound52469 : H12AffineFastState.Bounded env52469 := by
  intro p hp
  have h : env52469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52468_52469 : H12AffineEnvironment.transform 12 389 env52468 = env52469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env52468 == env52469) = true)

theorem identity52469 : scanCanonicalize (H12AffineFastState.compose env52469 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52469 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52470 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,32768,33030,38160,2340,1025,32769,4113,33,32784,2,269,17,2048,5393,36865,35108,34052,32800,257,32801,5376,513]

theorem envBound52470 : H12AffineFastState.Bounded env52470 := by
  intro p hp
  have h : env52470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52469_52470 : H12AffineEnvironment.transform 6 8 env52469 = env52470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52469 == env52470) = true)

theorem identity52470 : scanCanonicalize (H12AffineFastState.compose env52470 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound52470 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52471 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,0,262,5392,2340,1025,1,4113,33,16,2,269,17,2048,5393,4097,2340,1284,32,257,33,5376,513]

theorem envBound52471 : H12AffineFastState.Bounded env52471 := by
  intro p hp
  have h : env52471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52470_52471 : H12AffineEnvironment.transform 14 0 env52470 = env52471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env52470 == env52471) = true)

theorem identity52471 : scanCanonicalize (H12AffineFastState.compose env52471 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52471 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52472 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5157,0,35,5173,2049,1025,1,4113,33,16,2,40,17,2048,5172,4097,2049,1057,32,36,33,5157,513]

theorem envBound52472 : H12AffineFastState.Bounded env52472 := by
  intro p hp
  have h : env52472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52471_52472 : H12AffineEnvironment.transform 7 37 env52471 = env52472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52471 == env52472) = true)

def env52473 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1045,0,35,1029,2049,1025,1,33,33,16,2,40,17,2048,1028,49,2049,1057,32,36,33,1045,513]

theorem envBound52473 : H12AffineFastState.Bounded env52473 := by
  intro p hp
  have h : env52473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52472_52473 : H12AffineEnvironment.transform 11 48 env52472 = env52473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env52472 == env52473) = true)

theorem identity52473 : scanCanonicalize (H12AffineFastState.compose env52473 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound52473 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52474 : List Nat := [2,4,8,16,32,17,8,37,16,1024,2048,48,40,1045,0,35,1029,2049,1025,1,33,33,16,2,40,17,2048,1028,49,2049,1057,32,36,33,1045,17]

theorem envBound52474 : H12AffineFastState.Bounded env52474 := by
  intro p hp
  have h : env52474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52473_52474 : H12AffineEnvironment.transform 8 16 env52473 = env52474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env52473 == env52474) = true)

def env52475 : List Nat := [2,4,8,16,32,17,8,37,16,52,2048,48,40,33,0,35,49,2049,53,1,33,33,16,2,40,17,2048,48,49,2049,21,32,36,33,33,17]

theorem envBound52475 : H12AffineFastState.Bounded env52475 := by
  intro p hp
  have h : env52475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52474_52475 : H12AffineEnvironment.transform 9 52 env52474 = env52475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52474 == env52475) = true)

theorem identity52475 : scanCanonicalize (H12AffineFastState.compose env52475 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound52475 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52476 : List Nat := [2,4,8,16,32,17,8,37,16,52,32,48,40,33,0,35,49,33,53,1,33,33,16,2,40,17,32,48,49,33,21,32,36,33,33,17]

theorem envBound52476 : H12AffineFastState.Bounded env52476 := by
  intro p hp
  have h : env52476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52475_52476 : H12AffineEnvironment.transform 10 32 env52475 = env52476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env52475 == env52476) = true)

def leafEnv52476 : List Nat := [2,4,8,16,32,17,8,37,16,52,32,48,40,33,0,35,49,33,53,1,33,33,16,2,20,40,1,17,32,48,49,33,21,32,36,33,5,35,33,17,1,33,0]

def active52476 : List Nat := [0,1,2,3,4]

def tree52476 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52476 : H12WitnessSearch.Good tree52476 := H12GlobalWitnessIndex.good

theorem leafIdentity52476 : H12AffineFastState.composeSystem env52476 rootObs = leafEnv52476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52476 rootObs == leafEnv52476) = true)

theorem terminalChecked52476 : H12PackedTerminal.terminalCheckFast leafEnv52476 active52476 tree52476 = true := by decide +kernel

def env52477 : List Nat := [2,4,8,16,32,17,8,37,16,53,2048,48,40,32,0,35,48,2049,52,1,33,33,16,2,40,17,2048,49,49,2049,20,32,36,33,32,17]

theorem envBound52477 : H12AffineFastState.Bounded env52477 := by
  intro p hp
  have h : env52477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52474_52477 : H12AffineEnvironment.transform 9 53 env52474 = env52477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52474 == env52477) = true)

theorem identity52477 : scanCanonicalize (H12AffineFastState.compose env52477 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound52477 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52478 : List Nat := [2,4,8,16,32,17,8,37,16,53,26,48,40,32,0,35,48,27,52,1,33,33,16,2,40,17,26,49,49,27,20,32,36,33,32,17]

theorem envBound52478 : H12AffineFastState.Bounded env52478 := by
  intro p hp
  have h : env52478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52477_52478 : H12AffineEnvironment.transform 10 26 env52477 = env52478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env52477 == env52478) = true)

def leafEnv52478 : List Nat := [2,4,8,16,32,17,8,37,16,53,26,48,40,32,0,35,48,27,52,1,33,33,16,2,21,40,1,17,26,49,49,27,20,32,36,33,5,35,32,17,1,33,0]

def active52478 : List Nat := [0,1,2,3,4]

def tree52478 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52478 : H12WitnessSearch.Good tree52478 := H12GlobalWitnessIndex.good

theorem leafIdentity52478 : H12AffineFastState.composeSystem env52478 rootObs = leafEnv52478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52478 rootObs == leafEnv52478) = true)

theorem terminalChecked52478 : H12PackedTerminal.terminalCheckFast leafEnv52478 active52478 tree52478 = true := by decide +kernel

def env52479 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1044,0,35,1028,2049,1025,1,32,33,16,2,40,17,2048,1029,48,2049,1057,32,36,33,1044,513]

theorem envBound52479 : H12AffineFastState.Bounded env52479 := by
  intro p hp
  have h : env52479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52472_52479 : H12AffineEnvironment.transform 11 49 env52472 = env52479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env52472 == env52479) = true)

theorem identity52479 : scanCanonicalize (H12AffineFastState.compose env52479 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound52479 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52480 : List Nat := [2,4,8,16,32,17,8,37,512,549,2048,49,40,561,0,35,545,2049,548,1,32,33,16,2,40,17,2048,544,48,2049,516,32,36,33,561,513]

theorem envBound52480 : H12AffineFastState.Bounded env52480 := by
  intro p hp
  have h : env52480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52479_52480 : H12AffineEnvironment.transform 9 549 env52479 = env52480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env52479 == env52480) = true)

def env52481 : List Nat := [2,4,8,16,32,17,8,37,16,53,2048,49,40,33,0,35,49,2049,52,1,32,33,16,2,40,17,2048,48,48,2049,20,32,36,33,33,17]

theorem envBound52481 : H12AffineFastState.Bounded env52481 := by
  intro p hp
  have h : env52481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52480_52481 : H12AffineEnvironment.transform 8 16 env52480 = env52481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env52480 == env52481) = true)

theorem identity52481 : scanCanonicalize (H12AffineFastState.compose env52481 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound52481 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52482 : List Nat := [2,4,8,16,32,17,8,37,16,53,26,49,40,33,0,35,49,27,52,1,32,33,16,2,40,17,26,48,48,27,20,32,36,33,33,17]

theorem envBound52482 : H12AffineFastState.Bounded env52482 := by
  intro p hp
  have h : env52482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52481_52482 : H12AffineEnvironment.transform 10 26 env52481 = env52482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env52481 == env52482) = true)

def leafEnv52482 : List Nat := [2,4,8,16,32,17,8,37,16,53,26,49,40,33,0,35,49,27,52,1,32,33,16,2,21,40,1,17,26,48,48,27,20,32,36,33,5,35,33,17,1,32,0]

def active52482 : List Nat := [0,1,2,3,4]

def tree52482 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52482 : H12WitnessSearch.Good tree52482 := H12GlobalWitnessIndex.good

theorem leafIdentity52482 : H12AffineFastState.composeSystem env52482 rootObs = leafEnv52482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52482 rootObs == leafEnv52482) = true)

theorem terminalChecked52482 : H12PackedTerminal.terminalCheckFast leafEnv52482 active52482 tree52482 = true := by decide +kernel

def env52483 : List Nat := [2,4,8,16,32,17,8,37,17,52,2048,49,40,32,0,35,48,2049,53,1,32,33,16,2,40,17,2048,49,48,2049,21,32,36,33,32,16]

theorem envBound52483 : H12AffineFastState.Bounded env52483 := by
  intro p hp
  have h : env52483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52480_52483 : H12AffineEnvironment.transform 8 17 env52480 = env52483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env52480 == env52483) = true)

theorem identity52483 : scanCanonicalize (H12AffineFastState.compose env52483 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound52483 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52484 : List Nat := [2,4,8,16,32,17,8,37,17,52,33,49,40,32,0,35,48,32,53,1,32,33,16,2,40,17,33,49,48,32,21,32,36,33,32,16]

theorem envBound52484 : H12AffineFastState.Bounded env52484 := by
  intro p hp
  have h : env52484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52483_52484 : H12AffineEnvironment.transform 10 33 env52483 = env52484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env52483 == env52484) = true)

def leafEnv52484 : List Nat := [2,4,8,16,32,17,8,37,17,52,33,49,40,32,0,35,48,32,53,1,32,33,16,2,20,40,1,17,33,49,48,32,21,32,36,33,5,35,32,16,1,32,0]

def active52484 : List Nat := [0,1,2,3,4]

def tree52484 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52484 : H12WitnessSearch.Good tree52484 := H12GlobalWitnessIndex.good

theorem leafIdentity52484 : H12AffineFastState.composeSystem env52484 rootObs = leafEnv52484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52484 rootObs == leafEnv52484) = true)

theorem terminalChecked52484 : H12PackedTerminal.terminalCheckFast leafEnv52484 active52484 tree52484 = true := by decide +kernel

def env52485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155996,21763,8328,64,215367,115150,140364,303452,241743,499099,257,254130,196886,169880]

theorem envBound52485 : H12AffineFastState.Bounded env52485 := by
  intro p hp
  have h : env52485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52447_52485 : H12AffineEnvironment.transform 20 4161 env52447 = env52485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env52447 == env52485) = true)

theorem identity52485 : scanCanonicalize (H12AffineFastState.compose env52485 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound52485 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4161,392286,73755,21763,8328,64,2048,115150,91403,303452,61704,318684,257,41461,16465,120543]

theorem envBound52486 : H12AffineFastState.Bounded env52486 := by
  intro p hp
  have h : env52486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52485_52486 : H12AffineEnvironment.transform 16 82247 env52485 = env52486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env52485 == env52486) = true)

def env52487 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,262144,1025,32769,4113,392206,73755,21763,8328,16,2048,115102,91403,303372,61704,318604,257,41381,16385,120463]

theorem envBound52487 : H12AffineFastState.Bounded env52487 := by
  intro p hp
  have h : env52487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52486_52487 : H12AffineEnvironment.transform 5 16 env52486 = env52487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52486 == env52487) = true)

theorem identity52487 : scanCanonicalize (H12AffineFastState.compose env52487 (packedSelected [3,4,7,9,15,19,24,27,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound52487 : packedSelected [3,4,7,9,15,19,24,27,31,38] rootPS < 2^1333 := by decide +kernel

def env52488 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,137,65536,82199,262144,1025,136,4113,359559,73755,21763,8328,16,2048,82199,91403,270725,29057,285701,257,8492,16385,87558]

theorem envBound52488 : H12AffineFastState.Bounded env52488 := by
  intro p hp
  have h : env52488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52487_52488 : H12AffineEnvironment.transform 14 137 env52487 = env52488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env52487 == env52488) = true)

theorem identity52488 : scanCanonicalize (H12AffineFastState.compose env52488 (packedSelected [1,4,7,9,18,23,26,27,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound52488 : packedSelected [1,4,7,9,18,23,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52489 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,137,65536,82199,262144,1025,136,4113,351490,65950,21763,269,16,2048,82199,83086,262144,20484,285701,257,169,16385,87558]

theorem envBound52489 : H12AffineFastState.Bounded env52489 := by
  intro p hp
  have h : env52489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52488_52489 : H12AffineEnvironment.transform 12 389 env52488 = env52489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env52488 == env52489) = true)

theorem identity52489 : scanCanonicalize (H12AffineFastState.compose env52489 (packedSelected [0,3,4,7,10,19,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound52489 : packedSelected [0,3,4,7,10,19,22,24] rootPS < 2^1333 := by decide +kernel

def env52490 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5376,137,65536,70679,262144,1025,136,4113,329730,65950,3,269,16,2048,70679,70030,262144,1284,264453,257,169,5377,66310]

theorem envBound52490 : H12AffineFastState.Bounded env52490 := by
  intro p hp
  have h : env52490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52489_52490 : H12AffineEnvironment.transform 13 5376 env52489 = env52490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52489 == env52490) = true)

theorem identity52490 : scanCanonicalize (H12AffineFastState.compose env52490 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound52490 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env52491 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5376,137,65536,70679,67755,1025,136,4113,169,65950,3,269,16,2048,70679,70030,67755,1284,65966,257,169,5377,66310]

theorem envBound52491 : H12AffineFastState.Bounded env52491 := by
  intro p hp
  have h : env52491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52490_52491 : H12AffineEnvironment.transform 17 67755 env52490 = env52491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env52490 == env52491) = true)

theorem identity52491 : scanCanonicalize (H12AffineFastState.compose env52491 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52491 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env52492 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,65536,70679,67618,1025,1,4113,32,65815,3,269,16,2048,70679,69895,67618,1284,65831,257,32,5377,66310]

theorem envBound52492 : H12AffineFastState.Bounded env52492 := by
  intro p hp
  have h : env52492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52491_52492 : H12AffineEnvironment.transform 6 9 env52491 = env52492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52491 == env52492) = true)

theorem identity52492 : scanCanonicalize (H12AffineFastState.compose env52492 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(15+1) ^^^ 2310) := by decide +kernel

theorem selectedBound52492 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env52493 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,2310,7441,292,1025,1,4113,32,2065,3,269,16,2048,7441,6145,292,1284,2081,257,32,5377,2560]

theorem envBound52493 : H12AffineFastState.Bounded env52493 := by
  intro p hp
  have h : env52493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52492_52493 : H12AffineEnvironment.transform 15 2310 env52492 = env52493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2310 env52492 == env52493) = true)

theorem identity52493 : scanCanonicalize (H12AffineFastState.compose env52493 (packedSelected [2,3,4,5,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound52493 : packedSelected [2,3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env52494 : List Nat := [2,4,8,16,32,16,9,256,512,1024,292,4096,268,5376,0,34,5173,292,1025,1,4113,32,309,3,269,16,292,5173,4389,292,1284,261,257,32,5377,804]

theorem envBound52494 : H12AffineFastState.Bounded env52494 := by
  intro p hp
  have h : env52494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52493_52494 : H12AffineEnvironment.transform 10 292 env52493 = env52494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env52493 == env52494) = true)

theorem identity52494 : scanCanonicalize (H12AffineFastState.compose env52494 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound52494 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env52495 : List Nat := [2,4,8,16,32,16,9,256,512,1024,292,1280,268,0,0,34,309,292,1025,1,1297,32,309,3,269,16,292,309,1061,292,1284,261,257,32,1,804]

theorem envBound52495 : H12AffineFastState.Bounded env52495 := by
  intro p hp
  have h : env52495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52494_52495 : H12AffineEnvironment.transform 11 1280 env52494 = env52495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env52494 == env52495) = true)

theorem identity52495 : scanCanonicalize (H12AffineFastState.compose env52495 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound52495 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env52496 : List Nat := [2,4,8,16,32,16,9,256,512,273,292,17,268,0,0,34,309,292,272,1,0,32,309,3,269,16,292,309,308,292,21,261,257,32,1,804]

theorem envBound52496 : H12AffineFastState.Bounded env52496 := by
  intro p hp
  have h : env52496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52495_52496 : H12AffineEnvironment.transform 9 273 env52495 = env52496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env52495 == env52496) = true)

theorem identity52496 : scanCanonicalize (H12AffineFastState.compose env52496 (packedSelected [3,5,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound52496 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env52497 : List Nat := [2,4,8,16,32,16,9,36,512,53,0,17,40,0,0,34,17,0,52,1,0,32,17,3,41,16,0,17,16,0,21,33,37,32,1,512]

theorem envBound52497 : H12AffineFastState.Bounded env52497 := by
  intro p hp
  have h : env52497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52496_52497 : H12AffineEnvironment.transform 7 36 env52496 = env52497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env52496 == env52497) = true)

theorem identity52497 : scanCanonicalize (H12AffineFastState.compose env52497 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 37) := by decide +kernel

theorem selectedBound52497 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52498 : List Nat := [2,4,8,16,32,16,9,36,37,53,0,17,40,0,0,34,17,0,52,1,0,32,17,3,41,16,0,17,16,0,21,33,37,32,1,37]

theorem envBound52498 : H12AffineFastState.Bounded env52498 := by
  intro p hp
  have h : env52498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52497_52498 : H12AffineEnvironment.transform 8 37 env52497 = env52498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 37 env52497 == env52498) = true)

theorem identity52498 : scanCanonicalize (H12AffineFastState.compose env52498 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound52498 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52499 : List Nat := [2,4,8,8,32,8,9,36,37,45,0,9,40,0,0,34,9,0,44,1,0,32,9,3,41,8,0,9,8,0,13,33,37,32,1,37]

theorem envBound52499 : H12AffineFastState.Bounded env52499 := by
  intro p hp
  have h : env52499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52498_52499 : H12AffineEnvironment.transform 3 8 env52498 = env52499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env52498 == env52499) = true)

theorem identity52499 : scanCanonicalize (H12AffineFastState.compose env52499 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound52499 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52500 : List Nat := [2,4,8,8,8,8,9,12,13,5,0,9,0,0,0,10,9,0,4,1,0,8,9,3,1,8,0,9,8,0,13,9,13,8,1,13]

theorem envBound52500 : H12AffineFastState.Bounded env52500 := by
  intro p hp
  have h : env52500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52499_52500 : H12AffineEnvironment.transform 4 8 env52499 = env52500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env52499 == env52500) = true)

theorem identity52500 : scanCanonicalize (H12AffineFastState.compose env52500 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound52500 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env52501 : List Nat := [1,4,8,8,8,8,9,12,13,5,0,9,0,0,0,9,9,0,4,1,0,8,9,0,1,8,0,9,8,0,13,9,13,8,1,13]

theorem envBound52501 : H12AffineFastState.Bounded env52501 := by
  intro p hp
  have h : env52501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52500_52501 : H12AffineEnvironment.transform 0 1 env52500 = env52501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env52500 == env52501) = true)

theorem identity52501 : scanCanonicalize (H12AffineFastState.compose env52501 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound52501 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env52502 : List Nat := [1,4,0,0,0,0,1,4,5,5,0,1,0,0,0,1,1,0,4,1,0,0,1,0,1,0,0,1,0,0,5,1,5,0,1,5]

theorem envBound52502 : H12AffineFastState.Bounded env52502 := by
  intro p hp
  have h : env52502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52501_52502 : H12AffineEnvironment.transform 2 0 env52501 = env52502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env52501 == env52502) = true)

def env52503 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,262144,1025,32769,4112,392207,73755,21763,8328,17,2048,115103,91403,303373,61704,318605,257,41380,16384,120462]

theorem envBound52503 : H12AffineFastState.Bounded env52503 := by
  intro p hp
  have h : env52503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52486_52503 : H12AffineEnvironment.transform 5 17 env52486 = env52503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52486 == env52503) = true)

theorem identity52503 : scanCanonicalize (H12AffineFastState.compose env52503 (packedSelected [3,4,7,9,15,19,24,27,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 100522) := by decide +kernel

theorem selectedBound52503 : packedSelected [3,4,7,9,15,19,24,27,31,38] rootPS < 2^1333 := by decide +kernel

def env52504 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,100522,1025,32769,4112,29861,73755,21763,8328,17,2048,115103,91403,76199,61704,87079,257,41380,16384,120462]

theorem envBound52504 : H12AffineFastState.Bounded env52504 := by
  intro p hp
  have h : env52504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52503_52504 : H12AffineEnvironment.transform 17 100522 env52503 = env52504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100522 env52503 == env52504) = true)

theorem identity52504 : scanCanonicalize (H12AffineFastState.compose env52504 (packedSelected [0,1,4,7,10,16,19,20,22,28] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound52504 : packedSelected [0,1,4,7,10,16,19,20,22,28] rootPS < 2^1333 := by decide +kernel

def env52505 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,32768,65536,82198,100522,1025,32769,4112,21792,65950,21763,269,17,2048,115103,83086,67618,53389,87079,257,32801,16384,120462]

theorem envBound52505 : H12AffineFastState.Bounded env52505 := by
  intro p hp
  have h : env52505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52504_52505 : H12AffineEnvironment.transform 12 389 env52504 = env52505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env52504 == env52505) = true)

theorem identity52505 : scanCanonicalize (H12AffineFastState.compose env52505 (packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 54415) := by decide +kernel

theorem selectedBound52505 : packedSelected [0,9,16,17,18,19,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env52506 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,32768,54415,38297,23589,1025,32769,4112,21792,54545,21763,269,17,2048,5392,36865,56493,53389,32936,257,32801,16384,513]

theorem envBound52506 : H12AffineFastState.Bounded env52506 := by
  intro p hp
  have h : env52506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52505_52506 : H12AffineEnvironment.transform 15 54415 env52505 = env52506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54415 env52505 == env52506) = true)

theorem identity52506 : scanCanonicalize (H12AffineFastState.compose env52506 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound52506 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env52507 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5513,32768,33030,38297,2476,1025,32769,4112,169,32920,138,269,17,2048,5392,36865,35108,34052,32936,257,32801,5513,513]

theorem envBound52507 : H12AffineFastState.Bounded env52507 := by
  intro p hp
  have h : env52507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52506_52507 : H12AffineEnvironment.transform 13 5513 env52506 = env52507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env52506 == env52507) = true)

theorem identity52507 : scanCanonicalize (H12AffineFastState.compose env52507 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52507 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52508 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,32768,33030,38161,2340,1025,32769,4112,33,32784,2,269,17,2048,5392,36865,35108,34052,32800,257,32801,5377,513]

theorem envBound52508 : H12AffineFastState.Bounded env52508 := by
  intro p hp
  have h : env52508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52507_52508 : H12AffineEnvironment.transform 6 8 env52507 = env52508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52507 == env52508) = true)

theorem identity52508 : scanCanonicalize (H12AffineFastState.compose env52508 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound52508 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env52509 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,262,5393,2340,1025,1,4112,33,16,2,269,17,2048,5392,4097,2340,1284,32,257,33,5377,513]

theorem envBound52509 : H12AffineFastState.Bounded env52509 := by
  intro p hp
  have h : env52509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52508_52509 : H12AffineEnvironment.transform 14 0 env52508 = env52509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env52508 == env52509) = true)

theorem identity52509 : scanCanonicalize (H12AffineFastState.compose env52509 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound52509 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52510 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5157,0,34,5173,2048,1025,1,4112,33,16,2,41,17,2048,5172,4097,2048,1056,32,37,33,5157,513]

theorem envBound52510 : H12AffineFastState.Bounded env52510 := by
  intro p hp
  have h : env52510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52509_52510 : H12AffineEnvironment.transform 7 36 env52509 = env52510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env52509 == env52510) = true)

def env52511 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,41,1045,0,34,1029,2048,1025,1,32,33,16,2,41,17,2048,1028,49,2048,1056,32,37,33,1045,513]

theorem envBound52511 : H12AffineFastState.Bounded env52511 := by
  intro p hp
  have h : env52511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52510_52511 : H12AffineEnvironment.transform 11 48 env52510 = env52511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env52510 == env52511) = true)

theorem identity52511 : scanCanonicalize (H12AffineFastState.compose env52511 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound52511 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52512 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1077,48,41,1045,0,34,1029,1077,1025,1,32,33,16,2,41,17,1077,1028,49,1077,1056,32,37,33,1045,513]

theorem envBound52512 : H12AffineFastState.Bounded env52512 := by
  intro p hp
  have h : env52512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52511_52512 : H12AffineEnvironment.transform 10 1077 env52511 = env52512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env52511 == env52512) = true)

def env52513 : List Nat := [2,4,8,16,32,17,8,36,512,52,1,48,41,33,0,34,49,1,53,1,32,33,16,2,41,17,1,48,49,1,20,32,37,33,33,513]

theorem envBound52513 : H12AffineFastState.Bounded env52513 := by
  intro p hp
  have h : env52513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52512_52513 : H12AffineEnvironment.transform 9 52 env52512 = env52513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52512 == env52513) = true)

theorem identity52513 : scanCanonicalize (H12AffineFastState.compose env52513 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52513 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52514 : List Nat := [2,4,8,16,1,17,8,5,512,21,1,17,8,0,0,3,16,1,20,1,1,0,16,2,8,17,1,17,16,1,20,1,4,0,0,513]

theorem envBound52514 : H12AffineFastState.Bounded env52514 := by
  intro p hp
  have h : env52514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52513_52514 : H12AffineEnvironment.transform 4 1 env52513 = env52514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52513 == env52514) = true)

def leafEnv52514 : List Nat := [2,4,8,16,1,17,8,5,512,21,1,17,8,0,0,3,16,1,20,1,1,0,16,2,21,8,1,17,1,17,16,1,20,1,4,0,5,3,0,513,1,1,0]

def active52514 : List Nat := [0,1,2,3,8]

def tree52514 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52514 : H12WitnessSearch.Good tree52514 := H12GlobalWitnessIndex.good

theorem leafIdentity52514 : H12AffineFastState.composeSystem env52514 rootObs = leafEnv52514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52514 rootObs == leafEnv52514) = true)

theorem terminalChecked52514 : H12PackedTerminal.terminalCheckFast leafEnv52514 active52514 tree52514 = true := by decide +kernel

def env52515 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,41,32,0,34,48,0,52,1,32,33,16,2,41,17,0,49,49,0,21,32,37,33,32,513]

theorem envBound52515 : H12AffineFastState.Bounded env52515 := by
  intro p hp
  have h : env52515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52512_52515 : H12AffineEnvironment.transform 9 53 env52512 = env52515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52512 == env52515) = true)

theorem identity52515 : scanCanonicalize (H12AffineFastState.compose env52515 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound52515 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52516 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,48,41,32,0,34,48,0,52,1,32,33,16,2,41,17,0,49,49,0,21,32,37,33,32,10]

theorem envBound52516 : H12AffineFastState.Bounded env52516 := by
  intro p hp
  have h : env52516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52515_52516 : H12AffineEnvironment.transform 8 11 env52515 = env52516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env52515 == env52516) = true)

def leafEnv52516 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,48,41,32,0,34,48,0,52,1,32,33,16,2,20,41,1,17,0,49,49,0,21,32,37,33,5,34,32,10,1,32,0]

def active52516 : List Nat := [0,1,2,3,4]

def tree52516 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52516 : H12WitnessSearch.Good tree52516 := H12GlobalWitnessIndex.good

theorem leafIdentity52516 : H12AffineFastState.composeSystem env52516 rootObs = leafEnv52516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52516 rootObs == leafEnv52516) = true)

theorem terminalChecked52516 : H12PackedTerminal.terminalCheckFast leafEnv52516 active52516 tree52516 = true := by decide +kernel

def env52517 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,41,1044,0,34,1028,2048,1025,1,33,33,16,2,41,17,2048,1029,48,2048,1056,32,37,33,1044,513]

theorem envBound52517 : H12AffineFastState.Bounded env52517 := by
  intro p hp
  have h : env52517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52510_52517 : H12AffineEnvironment.transform 11 49 env52510 = env52517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env52510 == env52517) = true)

theorem identity52517 : scanCanonicalize (H12AffineFastState.compose env52517 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound52517 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52518 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,49,41,1044,0,34,1028,0,1025,1,33,33,16,2,41,17,0,1029,48,0,1056,32,37,33,1044,513]

theorem envBound52518 : H12AffineFastState.Bounded env52518 := by
  intro p hp
  have h : env52518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52517_52518 : H12AffineEnvironment.transform 10 0 env52517 = env52518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env52517 == env52518) = true)

def env52519 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,41,32,0,34,48,0,53,1,33,33,16,2,41,17,0,49,48,0,20,32,37,33,32,513]

theorem envBound52519 : H12AffineFastState.Bounded env52519 := by
  intro p hp
  have h : env52519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52518_52519 : H12AffineEnvironment.transform 9 52 env52518 = env52519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env52518 == env52519) = true)

theorem identity52519 : scanCanonicalize (H12AffineFastState.compose env52519 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52519 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52520 : List Nat := [2,4,8,16,1,17,8,5,512,21,0,16,8,1,0,3,17,0,20,1,0,0,16,2,8,17,0,16,17,0,20,1,4,0,1,513]

theorem envBound52520 : H12AffineFastState.Bounded env52520 := by
  intro p hp
  have h : env52520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52519_52520 : H12AffineEnvironment.transform 4 1 env52519 = env52520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52519 == env52520) = true)

def leafEnv52520 : List Nat := [2,4,8,16,1,17,8,5,512,21,0,16,8,1,0,3,17,0,20,1,0,0,16,2,21,8,1,17,0,16,17,0,20,1,4,0,5,3,1,513,1,0,0]

def active52520 : List Nat := [0,1,2,3,8]

def tree52520 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52520 : H12WitnessSearch.Good tree52520 := H12GlobalWitnessIndex.good

theorem leafIdentity52520 : H12AffineFastState.composeSystem env52520 rootObs = leafEnv52520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52520 rootObs == leafEnv52520) = true)

theorem terminalChecked52520 : H12PackedTerminal.terminalCheckFast leafEnv52520 active52520 tree52520 = true := by decide +kernel

def env52521 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,49,41,33,0,34,49,0,52,1,33,33,16,2,41,17,0,48,48,0,21,32,37,33,33,513]

theorem envBound52521 : H12AffineFastState.Bounded env52521 := by
  intro p hp
  have h : env52521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52518_52521 : H12AffineEnvironment.transform 9 53 env52518 = env52521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52518 == env52521) = true)

theorem identity52521 : scanCanonicalize (H12AffineFastState.compose env52521 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound52521 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52522 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,49,41,33,0,34,49,0,52,1,33,33,16,2,41,17,0,48,48,0,21,32,37,33,33,10]

theorem envBound52522 : H12AffineFastState.Bounded env52522 := by
  intro p hp
  have h : env52522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52521_52522 : H12AffineEnvironment.transform 8 11 env52521 = env52522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env52521 == env52522) = true)

def leafEnv52522 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,49,41,33,0,34,49,0,52,1,33,33,16,2,20,41,1,17,0,48,48,0,21,32,37,33,5,34,33,10,1,33,0]

def active52522 : List Nat := [0,1,2,3,4]

def tree52522 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood52522 : H12WitnessSearch.Good tree52522 := H12GlobalWitnessIndex.good

theorem leafIdentity52522 : H12AffineFastState.composeSystem env52522 rootObs = leafEnv52522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env52522 rootObs == leafEnv52522) = true)

theorem terminalChecked52522 : H12PackedTerminal.terminalCheckFast leafEnv52522 active52522 tree52522 = true := by decide +kernel

def env52523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534745,155996,2114882,8328,64,215366,115150,2241549,303452,2334734,2592219,257,254130,196886,2263001]

theorem envBound52523 : H12AffineFastState.Bounded env52523 := by
  intro p hp
  have h : env52523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52446_52523 : H12AffineEnvironment.transform 21 2534745 env52446 = env52523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534745 env52446 == env52523) = true)

def env52524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155996,21762,8328,64,215366,115150,140365,303452,241742,499099,257,254130,196886,169881]

theorem envBound52524 : H12AffineFastState.Bounded env52524 := by
  intro p hp
  have h : env52524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52523_52524 : H12AffineEnvironment.transform 20 4160 env52523 = env52524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env52523 == env52524) = true)

theorem identity52524 : scanCanonicalize (H12AffineFastState.compose env52524 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112018) := by decide +kernel

theorem selectedBound52524 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,262144,1025,32769,4160,329867,120014,21762,8328,64,64724,115150,102879,303452,1500,272393,257,21792,46212,74251]

theorem envBound52525 : H12AffineFastState.Bounded env52525 := by
  intro p hp
  have h : env52525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52524_52525 : H12AffineEnvironment.transform 16 112018 env52524 = env52525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112018 env52524 == env52525) = true)

def env52526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,10400,1025,32769,4160,73771,120014,21762,8328,64,64724,115150,102879,35324,1500,169,257,21792,46212,74251]

theorem envBound52526 : H12AffineFastState.Bounded env52526 := by
  intro p hp
  have h : env52526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52525_52526 : H12AffineEnvironment.transform 17 10400 env52525 = env52526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env52525 == env52526) = true)

theorem identity52526 : scanCanonicalize (H12AffineFastState.compose env52526 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound52526 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38296,10400,1025,32769,4160,33,62660,21762,8328,64,64724,57796,45525,35324,1500,169,257,21792,46212,513]

theorem envBound52527 : H12AffineFastState.Bounded env52527 := by
  intro p hp
  have h : env52527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52526_52527 : H12AffineEnvironment.transform 15 8202 env52526 = env52527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env52526 == env52527) = true)

theorem identity52527 : scanCanonicalize (H12AffineFastState.compose env52527 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound52527 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env52528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,8202,16401,10400,1025,21896,4160,33,8525,21762,8328,64,10589,13389,25692,23669,1500,169,257,21792,24845,513]

theorem envBound52528 : H12AffineFastState.Bounded env52528 := by
  intro p hp
  have h : env52528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52527_52528 : H12AffineEnvironment.transform 14 21897 env52527 = env52528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env52527 == env52528) = true)

theorem identity52528 : scanCanonicalize (H12AffineFastState.compose env52528 (packedSelected [0,2,5,6,7,10,12,14,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 3324) := by decide +kernel

theorem selectedBound52528 : packedSelected [0,2,5,6,7,10,12,14,23,24] rootPS < 2^1333 := by decide +kernel

def env52529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3324,8192,16384,18805,8202,16401,10400,1025,18804,3260,33,8525,18942,8328,64,10589,10417,25692,16521,1500,169,257,18908,24845,513]

theorem envBound52529 : H12AffineFastState.Bounded env52529 := by
  intro p hp
  have h : env52529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52528_52529 : H12AffineEnvironment.transform 11 3324 env52528 = env52529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3324 env52528 == env52529) = true)

theorem identity52529 : scanCanonicalize (H12AffineFastState.compose env52529 (packedSelected [0,2,6,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3269) := by decide +kernel

theorem selectedBound52529 : packedSelected [0,2,6,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env52530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3324,3269,16384,18805,3279,16401,1125,1025,18804,3260,33,3464,18942,3149,64,1432,1140,18585,16521,1500,169,257,18908,19912,513]

theorem envBound52530 : H12AffineFastState.Bounded env52530 := by
  intro p hp
  have h : env52530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52529_52530 : H12AffineEnvironment.transform 12 3269 env52529 = env52530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3269 env52529 == env52530) = true)

theorem identity52530 : scanCanonicalize (H12AffineFastState.compose env52530 (packedSelected [0,3,5,10,14,27] rootPS)) = affineNative (2^(13+1) ^^^ 3308) := by decide +kernel

theorem selectedBound52530 : packedSelected [0,3,5,10,14,27] rootPS < 2^1333 := by decide +kernel

def env52531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3324,3269,3308,1433,3279,3325,1125,1025,1432,3260,33,3464,1298,3149,64,1432,1140,1141,3173,1500,169,257,1328,292,513]

theorem envBound52531 : H12AffineFastState.Bounded env52531 := by
  intro p hp
  have h : env52531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52530_52531 : H12AffineEnvironment.transform 13 3308 env52530 = env52531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3308 env52530 == env52531) = true)

theorem identity52531 : scanCanonicalize (H12AffineFastState.compose env52531 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound52531 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env52532 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,3324,3269,3308,1260,3279,3325,1125,1025,1261,3260,33,3325,1127,3149,64,1261,1140,1141,3173,1193,169,116,1093,81,513]

theorem envBound52532 : H12AffineFastState.Bounded env52532 := by
  intro p hp
  have h : env52532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52531_52532 : H12AffineEnvironment.transform 7 117 env52531 = env52532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env52531 == env52532) = true)

theorem identity52532 : scanCanonicalize (H12AffineFastState.compose env52532 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound52532 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52533 : List Nat := [2,4,8,16,32,64,128,117,512,236,2048,2064,2089,2048,0,2083,2065,137,237,1,2128,33,2065,139,2209,64,1,152,153,2185,69,169,116,169,81,513]

theorem envBound52533 : H12AffineFastState.Bounded env52533 := by
  intro p hp
  have h : env52533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52532_52533 : H12AffineEnvironment.transform 9 236 env52532 = env52533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env52532 == env52533) = true)

theorem identity52533 : scanCanonicalize (H12AffineFastState.compose env52533 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound52533 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env52534 : List Nat := [2,4,8,16,32,64,128,117,512,236,1,17,40,1,0,34,16,137,237,1,81,33,16,139,160,64,1,152,153,136,69,169,116,169,81,513]

theorem envBound52534 : H12AffineFastState.Bounded env52534 := by
  intro p hp
  have h : env52534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52533_52534 : H12AffineEnvironment.transform 10 1 env52533 = env52534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env52533 == env52534) = true)

theorem identity52534 : scanCanonicalize (H12AffineFastState.compose env52534 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound52534 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52535 : List Nat := [2,4,8,16,32,64,72,117,512,36,1,17,40,1,0,34,16,65,37,1,81,33,16,67,104,64,1,80,81,64,69,97,116,97,81,513]

theorem envBound52535 : H12AffineFastState.Bounded env52535 := by
  intro p hp
  have h : env52535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52534_52535 : H12AffineEnvironment.transform 6 72 env52534 = env52535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env52534 == env52535) = true)

theorem identity52535 : scanCanonicalize (H12AffineFastState.compose env52535 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52535 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52536 : List Nat := [2,4,8,16,1,64,72,84,512,5,1,17,9,1,0,3,16,65,4,1,81,0,16,67,73,64,1,80,81,64,69,64,85,64,81,513]

theorem envBound52536 : H12AffineFastState.Bounded env52536 := by
  intro p hp
  have h : env52536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52535_52536 : H12AffineEnvironment.transform 4 1 env52535 = env52536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52535 == env52536) = true)

theorem identity52536 : scanCanonicalize (H12AffineFastState.compose env52536 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound52536 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52537 : List Nat := [2,4,8,16,1,64,72,84,65,5,1,17,9,1,0,3,16,65,4,1,81,0,16,67,73,64,1,80,81,64,69,64,85,64,81,64]

theorem envBound52537 : H12AffineFastState.Bounded env52537 := by
  intro p hp
  have h : env52537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52536_52537 : H12AffineEnvironment.transform 8 65 env52536 = env52537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env52536 == env52537) = true)

theorem identity52537 : scanCanonicalize (H12AffineFastState.compose env52537 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52537 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env52538 : List Nat := [2,4,8,16,1,17,25,5,16,5,1,17,9,1,0,3,16,16,4,1,0,0,16,18,24,17,1,1,0,17,20,17,4,17,0,17]

theorem envBound52538 : H12AffineFastState.Bounded env52538 := by
  intro p hp
  have h : env52538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52537_52538 : H12AffineEnvironment.transform 5 17 env52537 = env52538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52537 == env52538) = true)

def env52539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,10401,1025,32769,4160,73770,120014,21762,8328,64,64724,115150,102879,35325,1500,168,257,21792,46212,74251]

theorem envBound52539 : H12AffineFastState.Bounded env52539 := by
  intro p hp
  have h : env52539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52525_52539 : H12AffineEnvironment.transform 17 10401 env52525 = env52539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env52525 == env52539) = true)

theorem identity52539 : scanCanonicalize (H12AffineFastState.compose env52539 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound52539 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,65536,90138,10401,1025,21897,4160,73770,65862,21762,8328,64,10588,70726,83031,23669,1500,168,257,21792,24844,74251]

theorem envBound52540 : H12AffineFastState.Bounded env52540 := by
  intro p hp
  have h : env52540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52539_52540 : H12AffineEnvironment.transform 14 21896 env52539 = env52540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env52539 == env52540) = true)

theorem identity52540 : scanCanonicalize (H12AffineFastState.compose env52540 (packedSelected [0,1,2,6,8,12,14,19,23,27,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound52540 : packedSelected [0,1,2,6,8,12,14,19,23,27,32,38] rootPS < 2^1333 := by decide +kernel

def env52541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,65536,82247,2556,1025,21897,4160,65911,65862,21762,469,64,2049,70726,83031,23669,1500,168,257,21792,16465,66390]

theorem envBound52541 : H12AffineFastState.Bounded env52541 := by
  intro p hp
  have h : env52541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52540_52541 : H12AffineEnvironment.transform 12 349 env52540 = env52541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env52540 == env52541) = true)

theorem identity52541 : scanCanonicalize (H12AffineFastState.compose env52541 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,17,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound52541 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,17,20,23,24] rootPS < 2^1333 := by decide +kernel

def env52542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,262,16449,2556,1025,21897,4160,113,64,21762,469,64,2049,5440,17745,23669,1500,168,257,21792,16465,592]

theorem envBound52542 : H12AffineFastState.Bounded env52542 := by
  intro p hp
  have h : env52542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52541_52542 : H12AffineEnvironment.transform 15 262 env52541 = env52542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env52541 == env52542) = true)

theorem identity52542 : scanCanonicalize (H12AffineFastState.compose env52542 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound52542 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env52543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,262,5441,2556,1025,137,4160,113,64,2,469,64,2049,5440,4177,2421,1500,168,257,32,5457,592]

theorem envBound52543 : H12AffineFastState.Bounded env52543 := by
  intro p hp
  have h : env52543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52542_52543 : H12AffineEnvironment.transform 13 5376 env52542 = env52543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52542 == env52543) = true)

theorem identity52543 : scanCanonicalize (H12AffineFastState.compose env52543 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound52543 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52544 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,161,5372,136,250,5309,2048,1025,137,4160,113,64,2,41,64,2049,5308,4177,2185,1056,168,253,32,5293,592]

theorem envBound52544 : H12AffineFastState.Bounded env52544 := by
  intro p hp
  have h : env52544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52543_52544 : H12AffineEnvironment.transform 7 252 env52543 = env52544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env52543 == env52544) = true)

theorem identity52544 : scanCanonicalize (H12AffineFastState.compose env52544 (packedSelected [0,1,3,5,6,7,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound52544 : packedSelected [0,1,3,5,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52545 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,184,161,1092,136,250,1029,2048,1025,137,248,113,64,2,41,64,2049,1028,233,2185,1056,168,253,32,1045,592]

theorem envBound52545 : H12AffineFastState.Bounded env52545 := by
  intro p hp
  have h : env52545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52544_52545 : H12AffineEnvironment.transform 11 184 env52544 = env52545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env52544 == env52545) = true)

theorem identity52545 : scanCanonicalize (H12AffineFastState.compose env52545 (packedSelected [1,2,3,5,6,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1092) := by decide +kernel

theorem selectedBound52545 : packedSelected [1,2,3,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env52546 : List Nat := [2,4,8,16,32,64,128,252,512,1024,1092,184,161,1092,136,250,1029,1092,1025,137,248,113,64,2,41,64,1093,1028,233,1229,1056,168,253,32,1045,592]

theorem envBound52546 : H12AffineFastState.Bounded env52546 := by
  intro p hp
  have h : env52546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52545_52546 : H12AffineEnvironment.transform 10 1092 env52545 = env52546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1092 env52545 == env52546) = true)

theorem identity52546 : scanCanonicalize (H12AffineFastState.compose env52546 (packedSelected [0,1,4,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound52546 : packedSelected [0,1,4,8,10] rootPS < 2^1333 := by decide +kernel

def env52547 : List Nat := [2,4,8,16,32,64,128,252,512,237,169,184,161,169,136,250,232,169,236,137,248,113,64,2,41,64,168,233,233,32,205,168,253,32,248,592]

theorem envBound52547 : H12AffineFastState.Bounded env52547 := by
  intro p hp
  have h : env52547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52546_52547 : H12AffineEnvironment.transform 9 237 env52546 = env52547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env52546 == env52547) = true)

theorem identity52547 : scanCanonicalize (H12AffineFastState.compose env52547 (packedSelected [4,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound52547 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env52548 : List Nat := [2,4,8,16,32,64,89,37,512,52,112,97,120,112,81,35,49,112,53,80,33,113,64,2,41,64,113,48,48,32,20,113,36,32,33,592]

theorem envBound52548 : H12AffineFastState.Bounded env52548 := by
  intro p hp
  have h : env52548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52547_52548 : H12AffineEnvironment.transform 6 89 env52547 = env52548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env52547 == env52548) = true)

theorem identity52548 : scanCanonicalize (H12AffineFastState.compose env52548 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound52548 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52549 : List Nat := [2,4,8,16,32,48,41,37,512,52,0,17,8,0,33,35,49,0,53,32,33,1,48,2,41,48,1,48,48,32,20,1,36,32,33,544]

theorem envBound52549 : H12AffineFastState.Bounded env52549 := by
  intro p hp
  have h : env52549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52548_52549 : H12AffineEnvironment.transform 5 48 env52548 = env52549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env52548 == env52549) = true)

theorem identity52549 : scanCanonicalize (H12AffineFastState.compose env52549 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52549 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52550 : List Nat := [2,4,8,16,0,16,9,5,512,20,0,17,8,0,1,3,17,0,21,0,1,1,16,2,9,16,1,16,16,0,20,1,4,0,1,512]

theorem envBound52550 : H12AffineFastState.Bounded env52550 := by
  intro p hp
  have h : env52550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52549_52550 : H12AffineEnvironment.transform 4 0 env52549 = env52550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52549 == env52550) = true)

theorem identity52550 : scanCanonicalize (H12AffineFastState.compose env52550 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound52550 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52551 : List Nat := [2,4,8,16,0,16,9,5,15,20,0,17,8,0,1,3,17,0,21,0,1,1,16,2,9,16,1,16,16,0,20,1,4,0,1,15]

theorem envBound52551 : H12AffineFastState.Bounded env52551 := by
  intro p hp
  have h : env52551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52550_52551 : H12AffineEnvironment.transform 8 15 env52550 = env52551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env52550 == env52551) = true)

def env52552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441624,155996,21763,8328,64,215366,115150,140364,303452,241743,499098,257,254130,196886,169880]

theorem envBound52552 : H12AffineFastState.Bounded env52552 := by
  intro p hp
  have h : env52552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52523_52552 : H12AffineEnvironment.transform 20 4161 env52523 = env52552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env52523 == env52552) = true)

theorem identity52552 : scanCanonicalize (H12AffineFastState.compose env52552 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound52552 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,441624,155996,21763,8328,64,158028,57796,140364,303452,168005,441744,257,180408,139548,169880]

theorem envBound52553 : H12AffineFastState.Bounded env52553 := by
  intro p hp
  have h : env52553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52552_52553 : H12AffineEnvironment.transform 15 8202 env52552 = env52553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env52552 == env52553) = true)

theorem identity52553 : scanCanonicalize (H12AffineFastState.compose env52553 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound52553 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env52554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38297,262144,1025,32769,4161,272513,62661,21763,8328,64,64725,57796,45525,303452,1500,272393,257,21793,46213,513]

theorem envBound52554 : H12AffineFastState.Bounded env52554 := by
  intro p hp
  have h : env52554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52553_52554 : H12AffineEnvironment.transform 16 38297 env52553 = env52554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env52553 == env52554) = true)

theorem identity52554 : scanCanonicalize (H12AffineFastState.compose env52554 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound52554 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env52555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38297,64808,1025,32769,4161,54697,62661,21763,8328,64,64725,57796,45525,23668,1500,54561,257,21793,46213,513]

theorem envBound52555 : H12AffineFastState.Bounded env52555 := by
  intro p hp
  have h : env52555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52554_52555 : H12AffineEnvironment.transform 17 64808 env52554 = env52555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env52554 == env52555) = true)

theorem identity52555 : scanCanonicalize (H12AffineFastState.compose env52555 (packedSelected [2,3,5,6,8,12,15,17,28,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound52555 : packedSelected [2,3,5,6,8,12,15,17,28,38,41] rootPS < 2^1333 := by decide +kernel

def env52556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8202,24981,2340,1025,29709,4161,8613,201,21763,8328,64,2265,5576,17881,23668,1500,8493,257,21793,16521,513]

theorem envBound52556 : H12AffineFastState.Bounded env52556 := by
  intro p hp
  have h : env52556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52555_52556 : H12AffineEnvironment.transform 14 29708 env52555 = env52556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env52555 == env52556) = true)

theorem identity52556 : scanCanonicalize (H12AffineFastState.compose env52556 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound52556 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env52557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21977,479,16448,2340,1025,21976,4161,112,201,21763,349,64,2265,5576,17881,23668,1500,248,257,21793,16521,513]

theorem envBound52557 : H12AffineFastState.Bounded env52557 := by
  intro p hp
  have h : env52557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52556_52557 : H12AffineEnvironment.transform 12 469 env52556 = env52557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env52556 == env52557) = true)

def env52558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,155997,2114883,8328,64,6677535,115151,2241548,303453,2334734,4268163,257,254130,196886,2263001]

theorem envBound52558 : H12AffineFastState.Bounded env52558 := by
  intro p hp
  have h : env52558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52445_52558 : H12AffineEnvironment.transform 22 155997 env52445 = env52558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 155997 env52445 == env52558) = true)

def env52559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534744,155997,2114883,8328,64,215367,115151,2241548,303453,2334734,2592219,257,254130,196886,2263001]

theorem envBound52559 : H12AffineFastState.Bounded env52559 := by
  intro p hp
  have h : env52559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52558_52559 : H12AffineEnvironment.transform 21 2534744 env52558 = env52559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534744 env52558 == env52559) = true)

def env52560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155997,21763,8328,64,215367,115151,140364,303453,241742,499099,257,254130,196886,169881]

theorem envBound52560 : H12AffineFastState.Bounded env52560 := by
  intro p hp
  have h : env52560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52559_52560 : H12AffineEnvironment.transform 20 4160 env52559 = env52560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env52559 == env52560) = true)

def env52561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,169264,155997,21763,8328,64,215367,115151,140364,35189,241742,243123,257,254130,196886,169881]

theorem envBound52561 : H12AffineFastState.Bounded env52561 := by
  intro p hp
  have h : env52561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52560_52561 : H12AffineEnvironment.transform 17 10280 env52560 = env52561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52560 == env52561) = true)

def env52562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4160,21792,41293,21763,8328,64,100695,115151,58460,35189,94302,95651,257,73890,114950,22409]

theorem envBound52562 : H12AffineFastState.Bounded env52562 := by
  intro p hp
  have h : env52562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52561_52562 : H12AffineEnvironment.transform 16 49168 env52561 = env52562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env52561 == env52562) = true)

theorem identity52562 : scanCanonicalize (H12AffineFastState.compose env52562 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound52562 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,25029,10280,1025,8660,4160,21792,152,21763,8328,64,75906,90138,17801,10400,94302,95651,257,73890,90323,22409]

theorem envBound52563 : H12AffineFastState.Bounded env52563 := by
  intro p hp
  have h : env52563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52562_52563 : H12AffineEnvironment.transform 14 8661 env52562 = env52563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env52562 == env52563) = true)

theorem identity52563 : scanCanonicalize (H12AffineFastState.compose env52563 (packedSelected [2,4,6,11,19,20,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound52563 : packedSelected [2,4,6,11,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env52564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8661,65536,13625,10280,1025,8660,4160,476,152,511,8328,64,75906,79078,4469,10400,74914,74079,257,73890,78895,885]

theorem envBound52564 : H12AffineFastState.Bounded env52564 := by
  intro p hp
  have h : env52564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52563_52564 : H12AffineEnvironment.transform 13 5372 env52563 = env52564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env52563 == env52564) = true)

theorem identity52564 : scanCanonicalize (H12AffineFastState.compose env52564 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound52564 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env52565 : List Nat := [2,4,8,16,32,64,128,256,512,53,2048,4096,8192,4297,8661,65536,12556,10280,52,8660,4160,476,152,511,8328,64,75906,78035,4469,10400,73879,74079,257,73890,77850,885]

theorem envBound52565 : H12AffineFastState.Bounded env52565 := by
  intro p hp
  have h : env52565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52564_52565 : H12AffineEnvironment.transform 9 53 env52564 = env52565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env52564 == env52565) = true)

theorem identity52565 : scanCanonicalize (H12AffineFastState.compose env52565 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound52565 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env52566 : List Nat := [2,4,8,16,32,64,128,256,512,53,2048,4096,8192,4297,8661,478,12556,10280,52,8660,4160,476,152,511,8328,64,10588,12557,4469,10400,8521,8321,257,8572,12740,885]

theorem envBound52566 : H12AffineFastState.Bounded env52566 := by
  intro p hp
  have h : env52566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52565_52566 : H12AffineEnvironment.transform 15 478 env52565 = env52566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env52565 == env52566) = true)

theorem identity52566 : scanCanonicalize (H12AffineFastState.compose env52566 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound52566 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52567 : List Nat := [2,4,8,16,32,64,128,173,512,53,2048,4096,8192,4297,8312,115,12449,10280,52,8313,4160,113,152,82,8328,64,10481,12448,4312,10400,8420,8321,172,8401,12393,728]

theorem envBound52567 : H12AffineFastState.Bounded env52567 := by
  intro p hp
  have h : env52567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52566_52567 : H12AffineEnvironment.transform 7 173 env52566 = env52567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52566 == env52567) = true)

theorem identity52567 : scanCanonicalize (H12AffineFastState.compose env52567 (packedSelected [12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52567 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env52568 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,4096,8192,4161,8312,115,12329,10280,52,8313,4160,113,16,82,8192,64,10361,12328,4176,10280,8300,8201,36,8281,12393,592]

theorem envBound52568 : H12AffineFastState.Bounded env52568 := by
  intro p hp
  have h : env52568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52567_52568 : H12AffineEnvironment.transform 6 8 env52567 = env52568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52567 == env52568) = true)

theorem identity52568 : scanCanonicalize (H12AffineFastState.compose env52568 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound52568 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env52569 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,65,8192,0,8312,115,8296,10280,52,8313,1,113,16,82,8192,64,10361,8297,17,10280,8300,8201,36,8281,8232,592]

theorem envBound52569 : H12AffineFastState.Bounded env52569 := by
  intro p hp
  have h : env52569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52568_52569 : H12AffineEnvironment.transform 11 65 env52568 = env52569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env52568 == env52569) = true)

theorem identity52569 : scanCanonicalize (H12AffineFastState.compose env52569 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound52569 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env52570 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,65,40,0,80,115,64,2048,52,81,1,113,16,82,40,64,2129,65,17,2048,68,33,36,113,0,592]

theorem envBound52570 : H12AffineFastState.Bounded env52570 := by
  intro p hp
  have h : env52570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52569_52570 : H12AffineEnvironment.transform 12 40 env52569 = env52570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env52569 == env52570) = true)

theorem identity52570 : scanCanonicalize (H12AffineFastState.compose env52570 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound52570 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env52571 : List Nat := [2,4,8,16,32,64,8,37,512,53,112,65,40,0,80,115,64,112,52,81,1,113,16,82,40,64,33,65,17,112,68,33,36,113,0,592]

theorem envBound52571 : H12AffineFastState.Bounded env52571 := by
  intro p hp
  have h : env52571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52570_52571 : H12AffineEnvironment.transform 10 112 env52570 = env52571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env52570 == env52571) = true)

theorem identity52571 : scanCanonicalize (H12AffineFastState.compose env52571 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound52571 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env52572 : List Nat := [2,4,8,16,32,64,8,37,96,53,112,65,40,0,80,115,64,112,52,81,1,113,16,82,40,64,33,65,17,112,68,33,36,113,0,48]

theorem envBound52572 : H12AffineFastState.Bounded env52572 := by
  intro p hp
  have h : env52572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52571_52572 : H12AffineEnvironment.transform 8 96 env52571 = env52572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env52571 == env52572) = true)

theorem identity52572 : scanCanonicalize (H12AffineFastState.compose env52572 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound52572 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52573 : List Nat := [2,4,8,16,17,64,8,20,81,4,65,65,25,0,80,66,64,65,5,81,1,64,16,82,25,64,16,65,17,65,68,16,21,64,0,1]

theorem envBound52573 : H12AffineFastState.Bounded env52573 := by
  intro p hp
  have h : env52573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52572_52573 : H12AffineEnvironment.transform 4 17 env52572 = env52573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env52572 == env52573) = true)

theorem identity52573 : scanCanonicalize (H12AffineFastState.compose env52573 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound52573 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env52574 : List Nat := [2,4,8,16,17,0,8,20,17,4,1,1,25,0,16,2,0,1,5,17,1,0,16,18,25,0,16,1,17,1,4,16,21,0,0,1]

theorem envBound52574 : H12AffineFastState.Bounded env52574 := by
  intro p hp
  have h : env52574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52573_52574 : H12AffineEnvironment.transform 5 0 env52573 = env52574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env52573 == env52574) = true)

theorem identity52574 : scanCanonicalize (H12AffineFastState.compose env52574 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52574 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52575 : List Nat := [2,4,8,0,1,0,8,4,1,4,1,1,9,0,0,2,0,1,5,1,1,0,0,2,9,0,0,1,1,1,4,0,5,0,0,1]

theorem envBound52575 : H12AffineFastState.Bounded env52575 := by
  intro p hp
  have h : env52575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52574_52575 : H12AffineEnvironment.transform 3 0 env52574 = env52575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52574 == env52575) = true)

theorem identity52575 : scanCanonicalize (H12AffineFastState.compose env52575 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound52575 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52576 : List Nat := [2,1,8,0,1,0,8,1,1,1,1,1,9,0,0,2,0,1,0,1,1,0,0,2,9,0,0,1,1,1,1,0,0,0,0,1]

theorem envBound52576 : H12AffineFastState.Bounded env52576 := by
  intro p hp
  have h : env52576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52575_52576 : H12AffineEnvironment.transform 1 1 env52575 = env52576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env52575 == env52576) = true)

theorem identity52576 : scanCanonicalize (H12AffineFastState.compose env52576 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound52576 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52577 : List Nat := [2,1,1,0,1,0,1,1,1,1,1,1,0,0,0,2,0,1,0,1,1,0,0,2,0,0,0,1,1,1,1,0,0,0,0,1]

theorem envBound52577 : H12AffineFastState.Bounded env52577 := by
  intro p hp
  have h : env52577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52576_52577 : H12AffineEnvironment.transform 2 1 env52576 = env52577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env52576 == env52577) = true)

theorem identity52577 : scanCanonicalize (H12AffineFastState.compose env52577 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound52577 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env52578 : List Nat := [1,1,1,0,1,0,1,1,1,1,1,1,0,0,0,1,0,1,0,1,1,0,0,1,0,0,0,1,1,1,1,0,0,0,0,1]

theorem envBound52578 : H12AffineFastState.Bounded env52578 := by
  intro p hp
  have h : env52578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52577_52578 : H12AffineEnvironment.transform 0 1 env52577 = env52578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env52577 == env52578) = true)

def env52579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4160,21793,41292,21763,8328,64,100694,115151,58461,35189,94303,95650,257,73891,114951,22408]

theorem envBound52579 : H12AffineFastState.Bounded env52579 := by
  intro p hp
  have h : env52579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52561_52579 : H12AffineEnvironment.transform 16 49169 env52561 = env52579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env52561 == env52579) = true)

theorem identity52579 : scanCanonicalize (H12AffineFastState.compose env52579 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound52579 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,24909,10280,1025,8541,4160,21793,16,21763,8328,64,75786,90259,17665,10281,94303,95650,257,73891,90203,22408]

theorem envBound52580 : H12AffineFastState.Bounded env52580 := by
  intro p hp
  have h : env52580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52579_52580 : H12AffineEnvironment.transform 14 8540 env52579 = env52580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52579 == env52580) = true)

theorem identity52580 : scanCanonicalize (H12AffineFastState.compose env52580 (packedSelected [2,5,6,7,9,11,16,18,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 9447) := by decide +kernel

theorem selectedBound52580 : packedSelected [2,5,6,7,9,11,16,18,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,9447,24909,10280,1025,8541,4160,21793,16,21763,8328,64,3309,17524,17665,10281,21688,20805,257,1092,17596,22408]

theorem envBound52581 : H12AffineFastState.Bounded env52581 := by
  intro p hp
  have h : env52581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52580_52581 : H12AffineEnvironment.transform 15 9447 env52580 = env52581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9447 env52580 == env52581) = true)

theorem identity52581 : scanCanonicalize (H12AffineFastState.compose env52581 (packedSelected [0,2,3,5,6,7,8,11,18,19,20,26,28] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound52581 : packedSelected [0,2,3,5,6,7,8,11,18,19,20,26,28] rootPS < 2^1333 := by decide +kernel

def env52582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,8540,9447,13673,10280,1025,8541,4160,261,16,295,8328,64,3309,4176,4389,10281,156,1377,257,1092,4248,940]

theorem envBound52582 : H12AffineFastState.Bounded env52582 := by
  intro p hp
  have h : env52582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52581_52582 : H12AffineEnvironment.transform 13 5156 env52581 = env52582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env52581 == env52582) = true)

theorem identity52582 : scanCanonicalize (H12AffineFastState.compose env52582 (packedSelected [0,1,3,4,5,7,8,10,12,15,16,18,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound52582 : packedSelected [0,1,3,4,5,7,8,10,12,15,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env52583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,161,5156,509,1094,5576,2185,1025,508,4160,261,16,295,41,64,3309,4176,4389,2184,156,1377,257,1092,4248,940]

theorem envBound52583 : H12AffineFastState.Bounded env52583 := by
  intro p hp
  have h : env52583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52582_52583 : H12AffineEnvironment.transform 12 161 env52582 = env52583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env52582 == env52583) = true)

theorem identity52583 : scanCanonicalize (H12AffineFastState.compose env52583 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound52583 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env52584 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,161,4541,509,479,4177,2185,408,508,4160,261,16,295,41,64,2420,4176,4389,2184,156,248,257,477,4248,940]

theorem envBound52584 : H12AffineFastState.Bounded env52584 := by
  intro p hp
  have h : env52584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52583_52584 : H12AffineEnvironment.transform 9 409 env52583 = env52584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env52583 == env52584) = true)

theorem identity52584 : scanCanonicalize (H12AffineFastState.compose env52584 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52584 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env52585 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,40,4404,372,342,4177,2048,273,373,4160,261,16,295,41,64,2420,4176,4389,2049,21,113,257,340,4113,805]

theorem envBound52585 : H12AffineFastState.Bounded env52585 := by
  intro p hp
  have h : env52585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52584_52585 : H12AffineEnvironment.transform 6 9 env52584 = env52585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52584 == env52585) = true)

theorem identity52585 : scanCanonicalize (H12AffineFastState.compose env52585 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound52585 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52586 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,40,4161,1,35,4177,2048,100,0,4160,112,16,82,41,64,2049,4176,4176,2049,21,113,116,33,4113,592]

theorem envBound52586 : H12AffineFastState.Bounded env52586 := by
  intro p hp
  have h : env52586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52585_52586 : H12AffineEnvironment.transform 7 117 env52585 = env52586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env52585 == env52586) = true)

theorem identity52586 : scanCanonicalize (H12AffineFastState.compose env52586 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52586 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52587 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,40,4112,1,35,4096,2048,53,0,4113,33,16,3,41,17,2049,4097,4097,2049,21,32,37,33,4113,513]

theorem envBound52587 : H12AffineFastState.Bounded env52587 := by
  intro p hp
  have h : env52587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52586_52587 : H12AffineEnvironment.transform 5 17 env52586 = env52587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52586 == env52587) = true)

theorem identity52587 : scanCanonicalize (H12AffineFastState.compose env52587 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound52587 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52588 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,1,40,17,1,35,1,2048,53,0,16,33,16,3,41,17,2049,0,0,2049,21,32,37,33,16,513]

theorem envBound52588 : H12AffineFastState.Bounded env52588 := by
  intro p hp
  have h : env52588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52587_52588 : H12AffineEnvironment.transform 11 1 env52587 = env52588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env52587 == env52588) = true)

theorem identity52588 : scanCanonicalize (H12AffineFastState.compose env52588 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound52588 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52589 : List Nat := [2,4,8,16,32,17,9,36,512,52,554,1,40,17,1,35,1,554,53,0,16,33,16,3,41,17,555,0,0,555,21,32,37,33,16,513]

theorem envBound52589 : H12AffineFastState.Bounded env52589 := by
  intro p hp
  have h : env52589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52588_52589 : H12AffineEnvironment.transform 10 554 env52588 = env52589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env52588 == env52589) = true)

def env52590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,169265,155997,21763,8328,64,215367,115151,140364,35188,241742,243122,257,254130,196886,169881]

theorem envBound52590 : H12AffineFastState.Bounded env52590 := by
  intro p hp
  have h : env52590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52560_52590 : H12AffineEnvironment.transform 17 10281 env52560 = env52590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52560 == env52590) = true)

def env52591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4160,21793,41293,21763,8328,64,100695,115151,58460,35188,94302,95650,257,73890,114950,22409]

theorem envBound52591 : H12AffineFastState.Bounded env52591 := by
  intro p hp
  have h : env52591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52590_52591 : H12AffineEnvironment.transform 16 49168 env52590 = env52591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env52590 == env52591) = true)

theorem identity52591 : scanCanonicalize (H12AffineFastState.compose env52591 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52591 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4160,21793,41293,21763,8192,64,100695,115015,58460,35188,94302,95530,257,73770,114950,22273]

theorem envBound52592 : H12AffineFastState.Bounded env52592 := by
  intro p hp
  have h : env52592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52591_52592 : H12AffineEnvironment.transform 6 8 env52591 = env52592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52591 == env52592) = true)

theorem identity52592 : scanCanonicalize (H12AffineFastState.compose env52592 (packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52592 : packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52593 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24909,10281,1025,8540,4160,21793,16,21763,8192,64,75786,90138,17665,10281,94302,95530,257,73770,90203,22273]

theorem envBound52593 : H12AffineFastState.Bounded env52593 := by
  intro p hp
  have h : env52593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52592_52593 : H12AffineEnvironment.transform 14 8541 env52592 = env52593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52592 == env52593) = true)

theorem identity52593 : scanCanonicalize (H12AffineFastState.compose env52593 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound52593 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env52594 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8541,65536,5393,10281,1025,8540,4160,8573,16,8543,8192,64,75786,70726,12637,10281,66562,65910,257,73770,70663,9053]

theorem envBound52594 : H12AffineFastState.Bounded env52594 := by
  intro p hp
  have h : env52594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52593_52594 : H12AffineEnvironment.transform 13 13404 env52593 = env52594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env52593 == env52594) = true)

theorem identity52594 : scanCanonicalize (H12AffineFastState.compose env52594 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound52594 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,65536,5393,2421,1025,0,4160,33,16,3,348,64,67926,70726,4097,2421,66562,65910,257,65910,70663,513]

theorem envBound52595 : H12AffineFastState.Bounded env52595 := by
  intro p hp
  have h : env52595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52594_52595 : H12AffineEnvironment.transform 12 348 env52594 = env52595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env52594 == env52595) = true)

theorem identity52595 : scanCanonicalize (H12AffineFastState.compose env52595 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound52595 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env52596 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,343,5393,2421,1025,0,4160,33,16,3,348,64,2049,5393,4097,2421,1365,33,257,33,5456,513]

theorem envBound52596 : H12AffineFastState.Bounded env52596 := by
  intro p hp
  have h : env52596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52595_52596 : H12AffineEnvironment.transform 15 343 env52595 = env52596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env52595 == env52596) = true)

theorem identity52596 : scanCanonicalize (H12AffineFastState.compose env52596 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2367) := by decide +kernel

theorem selectedBound52596 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2367,348,3135,1,343,3118,2421,1025,0,2431,33,16,3,348,64,2049,3118,2366,2421,1365,33,257,33,3183,513]

theorem envBound52597 : H12AffineFastState.Bounded env52597 := by
  intro p hp
  have h : env52597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52596_52597 : H12AffineEnvironment.transform 11 2367 env52596 = env52597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2367 env52596 == env52597) = true)

theorem identity52597 : scanCanonicalize (H12AffineFastState.compose env52597 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 127) := by decide +kernel

theorem selectedBound52597 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52598 : List Nat := [2,4,8,16,32,64,8,256,512,127,2048,2367,348,2112,1,343,2129,2421,126,0,2431,33,16,3,348,64,2049,2129,2366,2421,298,33,257,33,2064,513]

theorem envBound52598 : H12AffineFastState.Bounded env52598 := by
  intro p hp
  have h : env52598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52597_52598 : H12AffineEnvironment.transform 9 127 env52597 = env52598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 127 env52597 == env52598) = true)

theorem identity52598 : scanCanonicalize (H12AffineFastState.compose env52598 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound52598 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env52599 : List Nat := [2,4,8,16,32,64,8,36,512,127,2048,2075,120,2112,1,115,2129,2129,126,0,2139,33,16,3,120,64,2049,2129,2074,2129,14,33,37,33,2064,513]

theorem envBound52599 : H12AffineFastState.Bounded env52599 := by
  intro p hp
  have h : env52599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52598_52599 : H12AffineEnvironment.transform 7 36 env52598 = env52599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env52598 == env52599) = true)

theorem identity52599 : scanCanonicalize (H12AffineFastState.compose env52599 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound52599 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env52600 : List Nat := [2,4,8,16,32,64,8,36,512,127,17,10,120,81,1,115,64,64,126,0,74,33,16,3,120,64,16,64,11,64,14,33,37,33,1,513]

theorem envBound52600 : H12AffineFastState.Bounded env52600 := by
  intro p hp
  have h : env52600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52599_52600 : H12AffineEnvironment.transform 10 17 env52599 = env52600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env52599 == env52600) = true)

theorem identity52600 : scanCanonicalize (H12AffineFastState.compose env52600 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound52600 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52601 : List Nat := [2,4,8,16,32,43,8,36,512,20,17,10,19,58,1,24,43,43,21,0,33,33,16,3,19,43,16,43,11,43,14,33,37,33,1,513]

theorem envBound52601 : H12AffineFastState.Bounded env52601 := by
  intro p hp
  have h : env52601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52600_52601 : H12AffineEnvironment.transform 5 43 env52600 = env52601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env52600 == env52601) = true)

def env52602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4160,21792,41292,21763,8328,64,100694,115151,58461,35188,94303,95651,257,73891,114951,22408]

theorem envBound52602 : H12AffineFastState.Bounded env52602 := by
  intro p hp
  have h : env52602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52590_52602 : H12AffineEnvironment.transform 16 49169 env52590 = env52602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env52590 == env52602) = true)

theorem identity52602 : scanCanonicalize (H12AffineFastState.compose env52602 (packedSelected [0,3,8,9,16,19,20,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound52602 : packedSelected [0,3,8,9,16,19,20,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env52603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21511,49169,10281,1025,32769,4160,21792,41292,21763,8328,64,56657,38344,58461,35188,9304,8612,257,29860,38144,22408]

theorem envBound52603 : H12AffineFastState.Bounded env52603 := by
  intro p hp
  have h : env52603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52602_52603 : H12AffineEnvironment.transform 15 21511 env52602 = env52603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env52602 == env52603) = true)

theorem identity52603 : scanCanonicalize (H12AffineFastState.compose env52603 (packedSelected [0,2,5,6,7,16,18,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound52603 : packedSelected [0,2,5,6,7,16,18,24,26,32] rootPS < 2^1333 := by decide +kernel

def env52604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,21511,16537,10281,1025,137,4160,21792,8644,21763,8328,64,24025,5440,25813,2556,9304,8612,257,29860,5512,22408]

theorem envBound52604 : H12AffineFastState.Bounded env52604 := by
  intro p hp
  have h : env52604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52603_52604 : H12AffineEnvironment.transform 14 136 env52603 = env52604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env52603 == env52604) = true)

theorem identity52604 : scanCanonicalize (H12AffineFastState.compose env52604 (packedSelected [0,2,3,6,7,10,11,16,19,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound52604 : packedSelected [0,2,3,6,7,10,11,16,19,23,24] rootPS < 2^1333 := by decide +kernel

def env52605 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,80,21511,16449,10281,1025,81,4160,21792,8476,21763,8272,64,23809,5440,25613,2340,9304,8572,257,29820,5456,22352]

theorem envBound52605 : H12AffineFastState.Bounded env52605 := by
  intro p hp
  have h : env52605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52604_52605 : H12AffineEnvironment.transform 6 88 env52604 = env52605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env52604 == env52605) = true)

theorem identity52605 : scanCanonicalize (H12AffineFastState.compose env52605 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52605 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env52606 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,16384,80,21511,16449,2340,1025,81,4160,21792,17,21763,349,64,23809,5440,17664,2340,1365,113,257,21873,5456,22352]

theorem envBound52606 : H12AffineFastState.Bounded env52606 := by
  intro p hp
  have h : env52606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52605_52606 : H12AffineEnvironment.transform 12 269 env52605 = env52606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52605 == env52606) = true)

theorem identity52606 : scanCanonicalize (H12AffineFastState.compose env52606 (packedSelected [0,7,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound52606 : packedSelected [0,7,11,14,15] rootPS < 2^1333 := by decide +kernel

def env52607 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5157,80,34,5220,2340,1025,81,4160,261,17,294,349,64,2340,5440,4389,2340,1365,113,257,340,5456,885]

theorem envBound52607 : H12AffineFastState.Bounded env52607 := by
  intro p hp
  have h : env52607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52606_52607 : H12AffineEnvironment.transform 13 5157 env52606 = env52607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env52606 == env52607) = true)

theorem identity52607 : scanCanonicalize (H12AffineFastState.compose env52607 (packedSelected [2,3,4,5,6,9,10,12,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound52607 : packedSelected [2,3,4,5,6,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env52608 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,41,5157,80,34,5220,2048,1025,81,4160,33,17,2,121,64,2048,5220,4097,2048,1137,113,37,112,5236,593]

theorem envBound52608 : H12AffineFastState.Bounded env52608 := by
  intro p hp
  have h : env52608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52607_52608 : H12AffineEnvironment.transform 7 36 env52607 = env52608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env52607 == env52608) = true)

theorem identity52608 : scanCanonicalize (H12AffineFastState.compose env52608 (packedSelected [1,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound52608 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env52609 : List Nat := [2,4,8,16,32,64,88,36,512,1024,523,4096,41,5157,80,34,5220,523,1025,81,4160,33,17,2,121,64,523,5220,4097,523,1137,113,37,112,5236,593]

theorem envBound52609 : H12AffineFastState.Bounded env52609 := by
  intro p hp
  have h : env52609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52608_52609 : H12AffineEnvironment.transform 10 523 env52608 = env52609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env52608 == env52609) = true)

theorem identity52609 : scanCanonicalize (H12AffineFastState.compose env52609 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52609 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52610 : List Nat := [2,4,8,16,32,16,8,36,512,1024,523,4096,41,5157,0,34,5172,523,1025,1,4112,33,17,2,41,16,523,5172,4097,523,1057,33,37,32,5156,513]

theorem envBound52610 : H12AffineFastState.Bounded env52610 := by
  intro p hp
  have h : env52610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52609_52610 : H12AffineEnvironment.transform 5 16 env52609 = env52610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52609 == env52610) = true)

def env52611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441625,155997,21762,8328,64,215367,115151,140365,303453,241743,499098,257,254130,196886,169880]

theorem envBound52611 : H12AffineFastState.Bounded env52611 := by
  intro p hp
  have h : env52611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52559_52611 : H12AffineEnvironment.transform 20 4161 env52559 = env52611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env52559 == env52611) = true)

theorem identity52611 : scanCanonicalize (H12AffineFastState.compose env52611 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound52611 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,4161,272512,62660,21762,8328,64,122078,115151,45524,303453,75222,329731,257,95531,103567,513]

theorem envBound52612 : H12AffineFastState.Bounded env52612 := by
  intro p hp
  have h : env52612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52611_52612 : H12AffineEnvironment.transform 16 38297 env52611 = env52612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env52611 == env52612) = true)

def env52613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,272392,62540,21762,8192,64,121942,115015,45404,303453,75102,329731,257,95531,103431,513]

theorem envBound52613 : H12AffineFastState.Bounded env52613 := by
  intro p hp
  have h : env52613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52612_52613 : H12AffineEnvironment.transform 6 8 env52612 = env52613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52612 == env52613) = true)

def env52614 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,4161,32,62540,21762,8192,64,121942,115015,45404,35189,75102,73771,257,95531,103431,513]

theorem envBound52614 : H12AffineFastState.Bounded env52614 := by
  intro p hp
  have h : env52614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52613_52614 : H12AffineEnvironment.transform 17 10280 env52613 = env52614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env52613 == env52614) = true)

theorem identity52614 : scanCanonicalize (H12AffineFastState.compose env52614 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound52614 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52615 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,24909,10280,1025,29789,4161,32,16,21762,8192,64,75786,79131,17664,32041,75102,73771,257,95531,90203,513]

theorem envBound52615 : H12AffineFastState.Bounded env52615 := by
  intro p hp
  have h : env52615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52614_52615 : H12AffineEnvironment.transform 14 29788 env52614 = env52615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env52614 == env52615) = true)

theorem identity52615 : scanCanonicalize (H12AffineFastState.compose env52615 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 12363) := by decide +kernel

theorem selectedBound52615 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env52616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,12363,24909,10280,1025,29789,4161,32,16,21762,8192,64,6209,1360,17664,32041,5397,4192,257,17760,20496,513]

theorem envBound52616 : H12AffineFastState.Bounded env52616 := by
  intro p hp
  have h : env52616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52615_52616 : H12AffineEnvironment.transform 15 12363 env52615 = env52616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12363 env52615 == env52616) = true)

theorem identity52616 : scanCanonicalize (H12AffineFastState.compose env52616 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 4381) := by decide +kernel

theorem selectedBound52616 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env52617 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4381,16384,17729,342,20560,6453,1025,17728,4161,32,16,21762,4381,64,6209,1360,17664,19508,5397,4192,257,17760,20496,513]

theorem envBound52617 : H12AffineFastState.Bounded env52617 := by
  intro p hp
  have h : env52617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52616_52617 : H12AffineEnvironment.transform 12 4381 env52616 = env52617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4381 env52616 == env52617) = true)

theorem identity52617 : scanCanonicalize (H12AffineFastState.compose env52617 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound52617 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env52618 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4381,5376,4161,342,1360,6453,1025,4160,4161,32,16,2,4381,64,6209,1360,4096,6452,5397,4192,257,4192,1296,513]

theorem envBound52618 : H12AffineFastState.Bounded env52618 := by
  intro p hp
  have h : env52618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52617_52618 : H12AffineEnvironment.transform 13 5376 env52617 = env52618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env52617 == env52618) = true)

theorem identity52618 : scanCanonicalize (H12AffineFastState.compose env52618 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound52618 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52619 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1360,1101,80,1297,342,1360,3173,1025,1296,1297,32,16,2,1101,64,3345,1360,1360,3172,69,1328,257,1328,1296,513]

theorem envBound52619 : H12AffineFastState.Bounded env52619 := by
  intro p hp
  have h : env52619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52618_52619 : H12AffineEnvironment.transform 11 1360 env52618 = env52619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env52618 == env52619) = true)

theorem identity52619 : scanCanonicalize (H12AffineFastState.compose env52619 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound52619 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env52620 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,1360,1101,80,1297,342,1360,293,1025,1296,1297,32,16,2,1101,64,81,1360,1360,292,69,1328,257,1328,1296,513]

theorem envBound52620 : H12AffineFastState.Bounded env52620 := by
  intro p hp
  have h : env52620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52619_52620 : H12AffineEnvironment.transform 10 1344 env52619 = env52620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env52619 == env52620) = true)

theorem identity52620 : scanCanonicalize (H12AffineFastState.compose env52620 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound52620 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env52621 : List Nat := [2,4,8,16,32,64,8,256,512,321,1,17,268,80,80,342,17,293,320,81,80,32,16,2,268,64,81,17,17,292,69,113,257,113,81,513]

theorem envBound52621 : H12AffineFastState.Bounded env52621 := by
  intro p hp
  have h : env52621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52620_52621 : H12AffineEnvironment.transform 9 321 env52620 = env52621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env52620 == env52621) = true)

theorem identity52621 : scanCanonicalize (H12AffineFastState.compose env52621 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52621 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52622 : List Nat := [2,4,8,16,32,16,8,256,512,273,1,17,268,0,0,262,17,293,272,1,0,32,16,2,268,16,1,17,17,292,21,33,257,33,1,513]

theorem envBound52622 : H12AffineFastState.Bounded env52622 := by
  intro p hp
  have h : env52622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52621_52622 : H12AffineEnvironment.transform 5 16 env52621 = env52622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52621 == env52622) = true)

theorem identity52622 : scanCanonicalize (H12AffineFastState.compose env52622 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound52622 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52623 : List Nat := [2,4,8,16,32,16,8,20,512,5,1,17,24,0,0,18,17,49,4,1,0,32,16,2,24,16,1,17,17,48,21,33,21,33,1,513]

theorem envBound52623 : H12AffineFastState.Bounded env52623 := by
  intro p hp
  have h : env52623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52622_52623 : H12AffineEnvironment.transform 7 20 env52622 = env52623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env52622 == env52623) = true)

theorem identity52623 : scanCanonicalize (H12AffineFastState.compose env52623 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52623 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52624 : List Nat := [2,4,8,16,32,16,8,20,0,5,1,17,24,0,0,18,17,49,4,1,0,32,16,2,24,16,1,17,17,48,21,33,21,33,1,1]

theorem envBound52624 : H12AffineFastState.Bounded env52624 := by
  intro p hp
  have h : env52624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52623_52624 : H12AffineEnvironment.transform 8 0 env52623 = env52624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52623 == env52624) = true)

theorem identity52624 : scanCanonicalize (H12AffineFastState.compose env52624 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound52624 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52625 : List Nat := [2,4,8,16,17,16,8,20,0,5,1,17,24,0,0,18,17,0,4,1,0,17,16,2,24,16,1,17,17,1,21,16,21,16,1,1]

theorem envBound52625 : H12AffineFastState.Bounded env52625 := by
  intro p hp
  have h : env52625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52624_52625 : H12AffineEnvironment.transform 4 17 env52624 = env52625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env52624 == env52625) = true)

theorem identity52625 : scanCanonicalize (H12AffineFastState.compose env52625 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52625 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52626 : List Nat := [2,4,8,11,10,11,8,15,0,5,1,10,3,0,0,9,10,0,4,1,0,10,11,2,3,11,1,10,10,1,14,11,14,11,1,1]

theorem envBound52626 : H12AffineFastState.Bounded env52626 := by
  intro p hp
  have h : env52626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52625_52626 : H12AffineEnvironment.transform 3 11 env52625 = env52626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52625 == env52626) = true)

theorem identity52626 : scanCanonicalize (H12AffineFastState.compose env52626 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound52626 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env52627 : List Nat := [2,4,3,0,1,0,3,4,0,5,1,1,3,0,0,2,1,0,4,1,0,1,0,2,3,0,1,1,1,1,5,0,5,0,1,1]

theorem envBound52627 : H12AffineFastState.Bounded env52627 := by
  intro p hp
  have h : env52627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52626_52627 : H12AffineEnvironment.transform 2 3 env52626 = env52627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env52626 == env52627) = true)

def env52628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4161,33,62540,21762,8192,64,121942,115015,45404,35188,75102,73770,257,95531,103431,513]

theorem envBound52628 : H12AffineFastState.Bounded env52628 := by
  intro p hp
  have h : env52628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52613_52628 : H12AffineEnvironment.transform 17 10281 env52613 = env52628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52613 == env52628) = true)

theorem identity52628 : scanCanonicalize (H12AffineFastState.compose env52628 (packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound52628 : packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS < 2^1333 := by decide +kernel

def env52629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,65536,13341,10281,1025,8461,4161,33,21824,21762,8192,64,97626,90187,4176,10360,75102,73770,257,95531,79115,513]

theorem envBound52629 : H12AffineFastState.Bounded env52629 := by
  intro p hp
  have h : env52629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52628_52629 : H12AffineEnvironment.transform 14 8460 env52628 = env52629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env52628 == env52629) = true)

theorem identity52629 : scanCanonicalize (H12AffineFastState.compose env52629 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound52629 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env52630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,30043,13341,10281,1025,8461,4161,33,21824,21762,8192,64,2049,5392,4176,10360,20485,21873,257,112,16464,513]

theorem envBound52630 : H12AffineFastState.Bounded env52630 := by
  intro p hp
  have h : env52630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52629_52630 : H12AffineEnvironment.transform 15 30043 env52629 = env52630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env52629 == env52630) = true)

theorem identity52630 : scanCanonicalize (H12AffineFastState.compose env52630 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52630 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env52631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,1,21590,5392,2340,1025,0,4161,33,21824,21762,269,64,2049,5392,4176,2421,20485,21873,257,112,16464,513]

theorem envBound52631 : H12AffineFastState.Bounded env52631 := by
  intro p hp
  have h : env52631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52630_52631 : H12AffineEnvironment.transform 12 269 env52630 = env52631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52630 == env52631) = true)

theorem identity52631 : scanCanonicalize (H12AffineFastState.compose env52631 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound52631 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env52632 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,1,343,5392,2340,1025,0,4161,33,65,3,269,64,2049,5392,4176,2421,1284,112,257,112,5457,513]

theorem envBound52632 : H12AffineFastState.Bounded env52632 := by
  intro p hp
  have h : env52632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52631_52632 : H12AffineEnvironment.transform 13 5377 env52631 = env52632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52631 == env52632) = true)

theorem identity52632 : scanCanonicalize (H12AffineFastState.compose env52632 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52632 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52633 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,262,5392,2340,1025,0,4112,33,16,3,269,17,2049,5392,4097,2340,1284,33,257,33,5376,513]

theorem envBound52633 : H12AffineFastState.Bounded env52633 := by
  intro p hp
  have h : env52633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52632_52633 : H12AffineEnvironment.transform 5 17 env52632 = env52633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52632 == env52633) = true)

theorem identity52633 : scanCanonicalize (H12AffineFastState.compose env52633 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound52633 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52634 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1,269,1280,1,262,1297,2340,1025,0,17,33,16,3,269,17,2049,1297,0,2340,1284,33,257,33,1281,513]

theorem envBound52634 : H12AffineFastState.Bounded env52634 := by
  intro p hp
  have h : env52634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52633_52634 : H12AffineEnvironment.transform 11 1 env52633 = env52634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env52633 == env52634) = true)

theorem identity52634 : scanCanonicalize (H12AffineFastState.compose env52634 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound52634 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52635 : List Nat := [2,4,8,16,32,17,8,256,512,1024,318,1,269,1280,1,262,1297,26,1025,0,17,33,16,3,269,17,319,1297,0,26,1284,33,257,33,1281,513]

theorem envBound52635 : H12AffineFastState.Bounded env52635 := by
  intro p hp
  have h : env52635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52634_52635 : H12AffineEnvironment.transform 10 318 env52634 = env52635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env52634 == env52635) = true)

theorem identity52635 : scanCanonicalize (H12AffineFastState.compose env52635 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound52635 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52636 : List Nat := [2,4,8,16,32,17,8,256,512,21,318,1,269,277,1,262,260,26,20,0,17,33,16,3,269,17,319,260,0,26,273,33,257,33,276,513]

theorem envBound52636 : H12AffineFastState.Bounded env52636 := by
  intro p hp
  have h : env52636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52635_52636 : H12AffineEnvironment.transform 9 21 env52635 = env52636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env52635 == env52636) = true)

theorem identity52636 : scanCanonicalize (H12AffineFastState.compose env52636 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound52636 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52637 : List Nat := [2,4,8,16,32,17,8,53,512,21,11,1,56,32,1,51,49,26,20,0,17,33,16,3,56,17,10,49,0,26,36,33,52,33,33,513]

theorem envBound52637 : H12AffineFastState.Bounded env52637 := by
  intro p hp
  have h : env52637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52636_52637 : H12AffineEnvironment.transform 7 53 env52636 = env52637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env52636 == env52637) = true)

theorem identity52637 : scanCanonicalize (H12AffineFastState.compose env52637 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound52637 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52638 : List Nat := [2,4,8,16,26,17,8,15,512,21,11,1,2,26,1,9,11,26,20,0,17,27,16,3,2,17,10,11,0,26,30,27,14,27,27,513]

theorem envBound52638 : H12AffineFastState.Bounded env52638 := by
  intro p hp
  have h : env52638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52637_52638 : H12AffineEnvironment.transform 4 26 env52637 = env52638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env52637 == env52638) = true)

theorem identity52638 : scanCanonicalize (H12AffineFastState.compose env52638 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound52638 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env52639 : List Nat := [2,4,2,16,16,17,2,5,512,21,1,1,2,16,1,3,1,16,20,0,17,17,16,3,2,17,0,1,0,16,20,17,4,17,17,513]

theorem envBound52639 : H12AffineFastState.Bounded env52639 := by
  intro p hp
  have h : env52639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52638_52639 : H12AffineEnvironment.transform 2 2 env52638 = env52639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env52638 == env52639) = true)

theorem identity52639 : scanCanonicalize (H12AffineFastState.compose env52639 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 19) := by decide +kernel

theorem selectedBound52639 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52640 : List Nat := [2,4,2,16,16,17,2,5,19,21,1,1,2,16,1,3,1,16,20,0,17,17,16,3,2,17,0,1,0,16,20,17,4,17,17,18]

theorem envBound52640 : H12AffineFastState.Bounded env52640 := by
  intro p hp
  have h : env52640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52639_52640 : H12AffineEnvironment.transform 8 19 env52639 = env52640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 19 env52639 == env52640) = true)

theorem identity52640 : scanCanonicalize (H12AffineFastState.compose env52640 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52640 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env52641 : List Nat := [2,4,2,1,1,0,2,5,2,4,1,1,2,1,1,3,1,1,5,0,0,0,1,3,2,0,0,1,0,1,5,0,4,0,0,3]

theorem envBound52641 : H12AffineFastState.Bounded env52641 := by
  intro p hp
  have h : env52641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52640_52641 : H12AffineEnvironment.transform 3 1 env52640 = env52641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52640 == env52641) = true)

theorem identity52641 : scanCanonicalize (H12AffineFastState.compose env52641 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52641 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52642 : List Nat := [2,2,2,1,1,0,2,3,2,2,1,1,2,1,1,3,1,1,3,0,0,0,1,3,2,0,0,1,0,1,3,0,2,0,0,3]

theorem envBound52642 : H12AffineFastState.Bounded env52642 := by
  intro p hp
  have h : env52642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52641_52642 : H12AffineEnvironment.transform 1 2 env52641 = env52642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52641 == env52642) = true)

def env52643 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,272393,62541,21762,8193,64,121943,115014,45405,303453,75103,329731,257,95531,103430,513]

theorem envBound52643 : H12AffineFastState.Bounded env52643 := by
  intro p hp
  have h : env52643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52612_52643 : H12AffineEnvironment.transform 6 9 env52612 = env52643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52612 == env52643) = true)

theorem identity52643 : scanCanonicalize (H12AffineFastState.compose env52643 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound52643 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env52644 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38160,262144,1025,32769,4161,272393,62541,21762,8193,64,10588,13389,45405,303453,53332,326920,257,32800,24845,513]

theorem envBound52644 : H12AffineFastState.Bounded env52644 := by
  intro p hp
  have h : env52644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52643_52644 : H12AffineEnvironment.transform 15 62731 env52643 = env52644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env52643 == env52644) = true)

theorem identity52644 : scanCanonicalize (H12AffineFastState.compose env52644 (packedSelected [0,3,4,5,7,9,10,12,14,38] rootPS)) = affineNative (2^(14+1) ^^^ 1125) := by decide +kernel

theorem selectedBound52644 : packedSelected [0,3,4,5,7,9,10,12,14,38] rootPS < 2^1333 := by decide +kernel

def env52645 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1125,29038,4469,262144,1025,1124,4161,272393,28712,21762,8193,64,10588,13389,13624,271672,21553,293229,257,1093,24845,513]

theorem envBound52645 : H12AffineFastState.Bounded env52645 := by
  intro p hp
  have h : env52645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52644_52645 : H12AffineEnvironment.transform 14 1125 env52644 = env52645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1125 env52644 == env52645) = true)

theorem identity52645 : scanCanonicalize (H12AffineFastState.compose env52645 (packedSelected [4,8,9,10,11,14,17,20,23,28] rootPS)) = affineNative (2^(17+1) ^^^ 22884) := by decide +kernel

theorem selectedBound52645 : packedSelected [4,8,9,10,11,14,17,20,23,28] rootPS < 2^1333 := by decide +kernel

def env52646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1125,29038,4469,22884,1025,1124,4161,29037,28712,21762,8193,64,10588,13389,13624,31836,21553,8201,257,1093,24845,513]

theorem envBound52646 : H12AffineFastState.Bounded env52646 := by
  intro p hp
  have h : env52646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52645_52646 : H12AffineEnvironment.transform 17 22884 env52645 = env52646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22884 env52645 == env52646) = true)

theorem identity52646 : scanCanonicalize (H12AffineFastState.compose env52646 (packedSelected [2,4,6,9,11,14,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound52646 : packedSelected [2,4,6,9,11,14,20,23] rootPS < 2^1333 := by decide +kernel

def env52647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,1125,20758,4469,22884,1025,1124,4161,20757,20560,21762,121,64,2340,5173,5440,23588,21553,113,257,1093,16757,513]

theorem envBound52647 : H12AffineFastState.Bounded env52647 := by
  intro p hp
  have h : env52647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52646_52647 : H12AffineEnvironment.transform 12 120 env52646 = env52647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env52646 == env52647) = true)

theorem identity52647 : scanCanonicalize (H12AffineFastState.compose env52647 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound52647 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env52648 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,120,16384,292,20758,4469,22884,320,293,4161,20757,20560,20547,121,64,2340,4468,4097,22885,20848,113,257,260,16757,513]

theorem envBound52648 : H12AffineFastState.Bounded env52648 := by
  intro p hp
  have h : env52648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52647_52648 : H12AffineEnvironment.transform 9 321 env52647 = env52648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env52647 == env52648) = true)

theorem identity52648 : scanCanonicalize (H12AffineFastState.compose env52648 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound52648 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env52649 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,120,4452,292,114,4469,2048,320,293,4161,113,308,295,121,64,2340,4468,4097,2049,20,113,257,260,4113,513]

theorem envBound52649 : H12AffineFastState.Bounded env52649 := by
  intro p hp
  have h : env52649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52648_52649 : H12AffineEnvironment.transform 13 4452 env52648 = env52649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env52648 == env52649) = true)

theorem identity52649 : scanCanonicalize (H12AffineFastState.compose env52649 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound52649 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env52650 : List Nat := [2,4,8,16,32,48,9,256,512,305,2048,4096,8,4372,292,2,4357,2048,304,293,4145,1,308,295,9,48,2340,4356,4097,2049,20,1,257,260,4113,513]

theorem envBound52650 : H12AffineFastState.Bounded env52650 := by
  intro p hp
  have h : env52650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52649_52650 : H12AffineEnvironment.transform 5 48 env52649 = env52650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env52649 == env52650) = true)

theorem identity52650 : scanCanonicalize (H12AffineFastState.compose env52650 (packedSelected [0,2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound52650 : packedSelected [0,2,5,8] rootPS < 2^1333 := by decide +kernel

def env52651 : List Nat := [2,4,8,16,32,48,9,256,512,305,260,4096,8,4372,292,2,4357,260,304,293,4145,1,308,295,9,48,32,4356,4097,261,20,1,257,260,4113,513]

theorem envBound52651 : H12AffineFastState.Bounded env52651 := by
  intro p hp
  have h : env52651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52650_52651 : H12AffineEnvironment.transform 10 260 env52650 = env52651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env52650 == env52651) = true)

theorem identity52651 : scanCanonicalize (H12AffineFastState.compose env52651 (packedSelected [0,1,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound52651 : packedSelected [0,1,5,6] rootPS < 2^1333 := by decide +kernel

def env52652 : List Nat := [2,4,8,16,32,48,9,52,512,5,48,4096,8,4128,16,2,4145,48,4,17,4145,1,0,19,9,48,32,4144,4097,49,20,1,53,48,4113,513]

theorem envBound52652 : H12AffineFastState.Bounded env52652 := by
  intro p hp
  have h : env52652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52651_52652 : H12AffineEnvironment.transform 7 52 env52651 = env52652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env52651 == env52652) = true)

theorem identity52652 : scanCanonicalize (H12AffineFastState.compose env52652 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound52652 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env52653 : List Nat := [2,4,8,16,32,48,9,52,512,5,48,0,8,32,16,2,49,48,4,17,49,1,0,19,9,48,32,48,1,49,20,1,53,48,17,513]

theorem envBound52653 : H12AffineFastState.Bounded env52653 := by
  intro p hp
  have h : env52653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52652_52653 : H12AffineEnvironment.transform 11 0 env52652 = env52653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env52652 == env52653) = true)

theorem identity52653 : scanCanonicalize (H12AffineFastState.compose env52653 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound52653 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env52654 : List Nat := [2,4,8,16,32,48,9,52,48,5,48,0,8,32,16,2,49,48,4,17,49,1,0,19,9,48,32,48,1,49,20,1,53,48,17,49]

theorem envBound52654 : H12AffineFastState.Bounded env52654 := by
  intro p hp
  have h : env52654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52653_52654 : H12AffineEnvironment.transform 8 48 env52653 = env52654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env52653 == env52654) = true)

theorem identity52654 : scanCanonicalize (H12AffineFastState.compose env52654 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound52654 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env52655 : List Nat := [2,4,8,16,17,1,9,5,1,5,1,0,8,17,16,2,0,1,4,17,0,1,0,19,9,1,17,1,1,0,20,1,4,1,17,0]

theorem envBound52655 : H12AffineFastState.Bounded env52655 := by
  intro p hp
  have h : env52655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52654_52655 : H12AffineEnvironment.transform 4 17 env52654 = env52655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env52654 == env52655) = true)

def env52656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534745,155997,2114883,8328,64,215366,115151,2241548,303453,2334734,2592218,257,254130,196886,2263001]

theorem envBound52656 : H12AffineFastState.Bounded env52656 := by
  intro p hp
  have h : env52656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52558_52656 : H12AffineEnvironment.transform 21 2534745 env52558 = env52656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534745 env52558 == env52656) = true)

def env52657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441625,155997,21763,8328,64,215366,115151,140364,303453,241742,499098,257,254130,196886,169881]

theorem envBound52657 : H12AffineFastState.Bounded env52657 := by
  intro p hp
  have h : env52657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52656_52657 : H12AffineEnvironment.transform 20 4160 env52656 = env52657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env52656 == env52657) = true)

theorem identity52657 : scanCanonicalize (H12AffineFastState.compose env52657 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound52657 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env52658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318549,17,21763,8328,64,75786,115151,17664,303453,119042,392406,257,98814,90202,63189]

theorem envBound52658 : H12AffineFastState.Bounded env52658 := by
  intro p hp
  have h : env52658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52657_52658 : H12AffineEnvironment.transform 16 24908 env52657 = env52658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env52657 == env52658) = true)

def env52659 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318549,17,21763,8192,64,75786,115015,17664,303453,119042,392286,257,98678,90202,63069]

theorem envBound52659 : H12AffineFastState.Bounded env52659 := by
  intro p hp
  have h : env52659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52658_52659 : H12AffineEnvironment.transform 6 8 env52658 = env52659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52658 == env52659) = true)

theorem identity52659 : scanCanonicalize (H12AffineFastState.compose env52659 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound52659 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env52660 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10281,1025,32769,4160,62588,17,21763,8192,64,75786,115015,17664,35188,119042,119927,257,98678,90202,63069]

theorem envBound52660 : H12AffineFastState.Bounded env52660 := by
  intro p hp
  have h : env52660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52659_52660 : H12AffineEnvironment.transform 17 10281 env52659 = env52660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env52659 == env52660) = true)

theorem identity52660 : scanCanonicalize (H12AffineFastState.compose env52660 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound52660 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env52661 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,13389,10281,1025,32769,4160,41341,17,2,8192,64,75786,103494,4097,35188,99331,98678,257,98678,79195,41820]

theorem envBound52661 : H12AffineFastState.Bounded env52661 := by
  intro p hp
  have h : env52661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52660_52661 : H12AffineEnvironment.transform 13 5377 env52660 = env52661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env52660 == env52661) = true)

theorem identity52661 : scanCanonicalize (H12AffineFastState.compose env52661 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52661 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env52662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,13389,10281,1025,8540,4160,32,17,2,8192,64,75786,79131,4097,10281,75102,73771,257,73771,79195,513]

theorem envBound52662 : H12AffineFastState.Bounded env52662 := by
  intro p hp
  have h : env52662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52661_52662 : H12AffineEnvironment.transform 14 8541 env52661 = env52662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52661 == env52662) = true)

theorem identity52662 : scanCanonicalize (H12AffineFastState.compose env52662 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52662 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env52663 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,65536,13340,10281,1025,8461,4113,32,17,2,8192,17,75786,79131,4097,10281,75023,73771,257,73771,79114,513]

theorem envBound52663 : H12AffineFastState.Bounded env52663 := by
  intro p hp
  have h : env52663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52662_52663 : H12AffineEnvironment.transform 5 17 env52662 = env52663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52662 == env52663) = true)

theorem identity52663 : scanCanonicalize (H12AffineFastState.compose env52663 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound52663 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env52664 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,263,13340,10281,1025,8461,4113,32,17,2,8192,17,10509,13340,4097,10281,9224,8492,257,8492,13325,513]

theorem envBound52664 : H12AffineFastState.Bounded env52664 := by
  intro p hp
  have h : env52664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52663_52664 : H12AffineEnvironment.transform 15 263 env52663 = env52664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env52663 == env52664) = true)

theorem identity52664 : scanCanonicalize (H12AffineFastState.compose env52664 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3354) := by decide +kernel

theorem selectedBound52664 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env52665 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3354,8192,2075,8460,263,10502,10281,1025,8461,3339,32,17,2,8192,17,10509,10502,3355,10281,9224,8492,257,8492,10519,513]

theorem envBound52665 : H12AffineFastState.Bounded env52665 := by
  intro p hp
  have h : env52665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52664_52665 : H12AffineEnvironment.transform 11 3354 env52664 = env52665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3354 env52664 == env52665) = true)

theorem identity52665 : scanCanonicalize (H12AffineFastState.compose env52665 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound52665 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env52666 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3354,51,2075,319,263,2357,2074,1025,318,3339,32,17,2,51,17,2366,2357,3355,2074,1083,287,257,287,2340,513]

theorem envBound52666 : H12AffineFastState.Bounded env52666 := by
  intro p hp
  have h : env52666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52665_52666 : H12AffineEnvironment.transform 12 51 env52665 = env52666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env52665 == env52666) = true)

theorem identity52666 : scanCanonicalize (H12AffineFastState.compose env52666 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound52666 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52667 : List Nat := [2,4,8,16,32,17,8,63,512,1024,2048,3109,51,2075,0,56,2058,2074,1025,1,3124,32,17,2,51,17,2049,2058,3108,2074,1083,32,62,32,2075,513]

theorem envBound52667 : H12AffineFastState.Bounded env52667 := by
  intro p hp
  have h : env52667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52666_52667 : H12AffineEnvironment.transform 7 63 env52666 = env52667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env52666 == env52667) = true)

theorem identity52667 : scanCanonicalize (H12AffineFastState.compose env52667 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound52667 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52668 : List Nat := [2,4,8,16,32,17,8,63,512,15,2048,2090,51,2075,0,56,2058,2074,14,1,2107,32,17,2,51,17,2049,2058,2091,2074,52,32,62,32,2075,513]

theorem envBound52668 : H12AffineFastState.Bounded env52668 := by
  intro p hp
  have h : env52668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52667_52668 : H12AffineEnvironment.transform 9 15 env52667 = env52668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env52667 == env52668) = true)

theorem identity52668 : scanCanonicalize (H12AffineFastState.compose env52668 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound52668 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52669 : List Nat := [2,4,8,16,32,17,8,63,48,15,2048,2090,51,2075,0,56,2058,2074,14,1,2107,32,17,2,51,17,2049,2058,2091,2074,52,32,62,32,2075,49]

theorem envBound52669 : H12AffineFastState.Bounded env52669 := by
  intro p hp
  have h : env52669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52668_52669 : H12AffineEnvironment.transform 8 48 env52668 = env52669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env52668 == env52669) = true)

theorem identity52669 : scanCanonicalize (H12AffineFastState.compose env52669 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound52669 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52670 : List Nat := [2,4,8,16,32,17,8,63,48,15,16,58,51,11,0,56,26,10,14,1,43,32,17,2,51,17,17,26,59,10,52,32,62,32,11,49]

theorem envBound52670 : H12AffineFastState.Bounded env52670 := by
  intro p hp
  have h : env52670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52669_52670 : H12AffineEnvironment.transform 10 16 env52669 = env52670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env52669 == env52670) = true)

theorem identity52670 : scanCanonicalize (H12AffineFastState.compose env52670 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound52670 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52671 : List Nat := [2,4,8,16,27,17,8,4,11,15,16,1,8,11,0,3,26,10,14,1,16,27,17,2,8,17,17,26,0,10,15,27,5,27,11,10]

theorem envBound52671 : H12AffineFastState.Bounded env52671 := by
  intro p hp
  have h : env52671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52670_52671 : H12AffineEnvironment.transform 4 27 env52670 = env52671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env52670 == env52671) = true)

theorem identity52671 : scanCanonicalize (H12AffineFastState.compose env52671 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52671 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52672 : List Nat := [2,3,8,16,27,17,8,3,11,8,16,1,8,11,0,3,26,10,9,1,16,27,17,2,8,17,17,26,0,10,8,27,2,27,11,10]

theorem envBound52672 : H12AffineFastState.Bounded env52672 := by
  intro p hp
  have h : env52672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52671_52672 : H12AffineEnvironment.transform 1 3 env52671 = env52672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52671 == env52672) = true)

theorem identity52672 : scanCanonicalize (H12AffineFastState.compose env52672 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52672 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52673 : List Nat := [2,3,8,1,10,0,8,3,11,8,1,1,8,11,0,3,11,10,9,1,1,10,0,2,8,0,0,11,0,10,8,10,2,10,11,10]

theorem envBound52673 : H12AffineFastState.Bounded env52673 := by
  intro p hp
  have h : env52673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52672_52673 : H12AffineEnvironment.transform 3 1 env52672 = env52673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52672 == env52673) = true)

end H12CloudChart1