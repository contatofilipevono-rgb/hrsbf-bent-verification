import H12CloudChart1Data057

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound14579 : H12AffineFastState.Bounded env14579 := by
  intro p hp
  have h : env14579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14578_14579 : H12AffineEnvironment.transform 6 8 env14578 = env14579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14578 == env14579) = true)

theorem identity14579 : scanCanonicalize (H12AffineFastState.compose env14579 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14579 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env14580 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,262,49168,2341,1025,32769,4113,21792,32784,2,268,16,56576,38160,50433,35109,1284,32,257,21792,38145,513]

theorem envBound14580 : H12AffineFastState.Bounded env14580 := by
  intro p hp
  have h : env14580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14579_14580 : H12AffineEnvironment.transform 5 16 env14579 = env14580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14579 == env14580) = true)

theorem identity14580 : scanCanonicalize (H12AffineFastState.compose env14580 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound14580 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14581 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,0,262,16400,2341,1025,1,4113,21792,16,2,268,16,23808,5392,17665,2341,1284,32,257,21792,5377,513]

theorem envBound14581 : H12AffineFastState.Bounded env14581 := by
  intro p hp
  have h : env14581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14580_14581 : H12AffineEnvironment.transform 14 0 env14580 = env14581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env14580 == env14581) = true)

theorem identity14581 : scanCanonicalize (H12AffineFastState.compose env14581 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 795) := by decide +kernel

theorem selectedBound14581 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env14582 : List Nat := [2,4,8,16,32,16,8,256,512,795,2048,4096,268,16384,0,262,16400,2341,794,1,4113,21051,16,2,268,16,23067,4619,16922,2341,543,32,257,21051,4634,513]

theorem envBound14582 : H12AffineFastState.Bounded env14582 := by
  intro p hp
  have h : env14582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14581_14582 : H12AffineEnvironment.transform 9 795 env14581 = env14582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 795 env14581 == env14582) = true)

def env14583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4161,21793,41293,73857,8328,64,64724,46157,58460,35189,1500,32,257,21792,46213,74251]

theorem envBound14583 : H12AffineFastState.Bounded env14583 := by
  intro p hp
  have h : env14583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14575_14583 : H12AffineEnvironment.transform 16 49169 env14575 = env14583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env14575 == env14583) = true)

theorem identity14583 : scanCanonicalize (H12AffineFastState.compose env14583 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound14583 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49169,10281,1025,32769,4161,21793,41293,3,8328,64,64724,46157,58460,35189,1500,32,257,21792,46213,649]

theorem envBound14584 : H12AffineFastState.Bounded env14584 := by
  intro p hp
  have h : env14584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14583_14584 : H12AffineEnvironment.transform 15 8322 env14583 = env14584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env14583 == env14584) = true)

theorem identity14584 : scanCanonicalize (H12AffineFastState.compose env14584 (packedSelected [9,10,12,16,18,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound14584 : packedSelected [9,10,12,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env14585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13445,32768,8322,46228,10281,1025,32769,4161,8612,41293,3,8328,64,34897,46157,37081,35189,1500,32,257,8613,46213,649]

theorem envBound14585 : H12AffineFastState.Bounded env14585 := by
  intro p hp
  have h : env14585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14584_14585 : H12AffineEnvironment.transform 13 13445 env14584 = env14585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env14584 == env14585) = true)

theorem identity14585 : scanCanonicalize (H12AffineFastState.compose env14585 (packedSelected [0,1,4,7,8,9,11,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound14585 : packedSelected [0,1,4,7,8,9,11,16,19] rootPS < 2^1333 := by decide +kernel

def env14586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13445,137,8322,13341,10281,1025,136,4161,8612,8644,3,8328,64,2264,13508,4176,2556,1500,32,257,8613,13324,649]

theorem envBound14586 : H12AffineFastState.Bounded env14586 := by
  intro p hp
  have h : env14586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14585_14586 : H12AffineEnvironment.transform 14 137 env14585 = env14586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env14585 == env14586) = true)

theorem identity14586 : scanCanonicalize (H12AffineFastState.compose env14586 (packedSelected [1,2,4,6,8,9,10,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14586 : packedSelected [1,2,4,6,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env14587 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,0,8203,13341,10281,1025,1,4161,8493,8525,3,8193,64,2129,13389,4176,2421,1365,32,257,8492,13324,512]

theorem envBound14587 : H12AffineFastState.Bounded env14587 := by
  intro p hp
  have h : env14587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14586_14587 : H12AffineEnvironment.transform 6 9 env14586 = env14587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14586 == env14587) = true)

theorem identity14587 : scanCanonicalize (H12AffineFastState.compose env14587 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14587 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14588 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,13324,0,8203,13341,10248,1025,1,4161,8460,8525,3,8193,64,2129,13389,4176,2388,1365,1,257,8461,13324,512]

theorem envBound14588 : H12AffineFastState.Bounded env14588 := by
  intro p hp
  have h : env14588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14587_14588 : H12AffineEnvironment.transform 4 1 env14587 = env14588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14587 == env14588) = true)

theorem identity14588 : scanCanonicalize (H12AffineFastState.compose env14588 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14588 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14589 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,349,5457,0,342,5440,2389,1025,1,4161,81,16,3,348,64,2129,5392,4176,2388,1365,1,257,80,5457,512]

theorem envBound14589 : H12AffineFastState.Bounded env14589 := by
  intro p hp
  have h : env14589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14588_14589 : H12AffineEnvironment.transform 12 349 env14588 = env14589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14588 == env14589) = true)

theorem identity14589 : scanCanonicalize (H12AffineFastState.compose env14589 (packedSelected [2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound14589 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env14590 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,9,5125,0,2,5140,2049,1025,1,4161,81,16,3,8,64,2129,5188,4176,2048,1025,1,85,80,5125,512]

theorem envBound14590 : H12AffineFastState.Bounded env14590 := by
  intro p hp
  have h : env14590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14589_14590 : H12AffineEnvironment.transform 7 84 env14589 = env14590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env14589 == env14590) = true)

def env14591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356288,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound14591 : H12AffineFastState.Bounded env14591 := by
  intro p hp
  have h : env14591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14277_14591 : H12AffineEnvironment.transform 26 30393345 env14277 = env14591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env14277 == env14591) = true)

def env14592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound14592 : H12AffineFastState.Bounded env14592 := by
  intro p hp
  have h : env14592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14591_14592 : H12AffineEnvironment.transform 18 1024 env14591 = env14592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env14591 == env14592) = true)

theorem identity14592 : scanCanonicalize (H12AffineFastState.compose env14592 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10577360) := by decide +kernel

theorem selectedBound14592 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10577360,8328,64,6727121,8446300,10507600,8830976,2154944,12582928,256,41341,16600,2213398]

theorem envBound14593 : H12AffineFastState.Bounded env14593 := by
  intro p hp
  have h : env14593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14592_14593 : H12AffineEnvironment.transform 23 10577360 env14592 = env14593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10577360 env14592 == env14593) = true)

def env14594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,2097152,4194304,8388608,10577360,8328,64,6705549,8393984,10507600,8795228,2102684,12582928,256,21793,16600,2175562]

theorem envBound14594 : H12AffineFastState.Bounded env14594 := by
  intro p hp
  have h : env14594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14593_14594 : H12AffineEnvironment.transform 14 29788 env14593 = env14594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env14593 == env14594) = true)

def env14595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,2097152,4194304,2114896,73856,8328,64,6705549,2117712,4096,2519308,2102684,6309184,256,21793,16600,2175562]

theorem envBound14595 : H12AffineFastState.Bounded env14595 := by
  intro p hp
  have h : env14595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14594_14595 : H12AffineEnvironment.transform 22 2114896 env14594 = env14595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114896 env14594 == env14595) = true)

def env14596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17728,4194304,16,73856,8328,64,4592845,5392,4096,406604,20700,4194304,256,21793,16600,96010]

theorem envBound14596 : H12AffineFastState.Bounded env14596 := by
  intro p hp
  have h : env14596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14595_14596 : H12AffineEnvironment.transform 20 17728 env14595 = env14596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env14595 == env14596) = true)

theorem identity14596 : scanCanonicalize (H12AffineFastState.compose env14596 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound14596 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,30083,131072,262144,1024,29789,17728,4194304,16,21763,8328,64,4592845,5392,4096,406604,20700,4194304,256,21793,16600,649]

theorem envBound14597 : H12AffineFastState.Bounded env14597 := by
  intro p hp
  have h : env14597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14596_14597 : H12AffineEnvironment.transform 15 30083 env14596 = env14597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env14596 == env14597) = true)

def env14598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8323,131072,262144,1024,8541,4160,4194304,16,3,8328,64,4592845,5392,4096,406604,1500,4194304,256,33,5592,649]

theorem envBound14598 : H12AffineFastState.Bounded env14598 := by
  intro p hp
  have h : env14598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14597_14598 : H12AffineEnvironment.transform 13 5376 env14597 = env14598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env14597 == env14598) = true)

theorem identity14598 : scanCanonicalize (H12AffineFastState.compose env14598 (packedSelected [0,3,9,10,12,14,15,22,24,26,27,35,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14598 : packedSelected [0,3,9,10,12,14,15,22,24,26,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env14599 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,4194304,16,3,8192,64,4592709,5392,4096,406604,1364,4194304,256,33,5456,513]

theorem envBound14599 : H12AffineFastState.Bounded env14599 := by
  intro p hp
  have h : env14599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14598_14599 : H12AffineEnvironment.transform 6 8 env14598 = env14599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14598 == env14599) = true)

theorem identity14599 : scanCanonicalize (H12AffineFastState.compose env14599 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 144445) := by decide +kernel

theorem selectedBound14599 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14600 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,144445,16,3,8192,64,270456,5392,4096,406604,1364,144445,256,33,5456,513]

theorem envBound14600 : H12AffineFastState.Bounded env14600 := by
  intro p hp
  have h : env14600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14599_14600 : H12AffineEnvironment.transform 21 144445 env14599 = env14600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144445 env14599 == env14600) = true)

theorem identity14600 : scanCanonicalize (H12AffineFastState.compose env14600 (packedSelected [0,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound14600 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env14601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,138341,1024,8541,4160,144445,16,3,8192,64,146461,5392,4096,10281,1364,144445,256,33,5456,513]

theorem envBound14601 : H12AffineFastState.Bounded env14601 := by
  intro p hp
  have h : env14601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14600_14601 : H12AffineEnvironment.transform 17 138341 env14600 = env14601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env14600 == env14601) = true)

theorem identity14601 : scanCanonicalize (H12AffineFastState.compose env14601 (packedSelected [0,1,4,7,8,9,12,14,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound14601 : packedSelected [0,1,4,7,8,9,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env14602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,13389,10280,1024,8541,4160,112,16,3,8192,64,2128,5392,4096,10281,1364,112,256,33,5456,513]

theorem envBound14602 : H12AffineFastState.Bounded env14602 := by
  intro p hp
  have h : env14602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14601_14602 : H12AffineEnvironment.transform 16 13389 env14601 = env14602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env14601 == env14602) = true)

theorem identity14602 : scanCanonicalize (H12AffineFastState.compose env14602 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound14602 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14603 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4112,8540,8203,12637,10280,272,8541,4160,112,16,3,8192,64,2128,4096,4096,10281,68,112,256,33,4160,513]

theorem envBound14603 : H12AffineFastState.Bounded env14603 := by
  intro p hp
  have h : env14603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14602_14603 : H12AffineEnvironment.transform 9 272 env14602 = env14603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14602 == env14603) = true)

theorem identity14603 : scanCanonicalize (H12AffineFastState.compose env14603 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound14603 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env14604 : List Nat := [2,4,8,16,32,64,8,256,512,272,80,4096,8192,4112,8540,8203,12637,8312,272,8541,4160,112,16,3,8192,64,0,4096,4096,8313,68,112,256,33,4160,513]

theorem envBound14604 : H12AffineFastState.Bounded env14604 := by
  intro p hp
  have h : env14604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14603_14604 : H12AffineEnvironment.transform 10 80 env14603 = env14604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env14603 == env14604) = true)

theorem identity14604 : scanCanonicalize (H12AffineFastState.compose env14604 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14604 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14605 : List Nat := [2,4,8,16,32,16,8,256,512,272,0,4096,8192,4112,8460,8203,12557,8232,272,8461,4112,32,16,3,8192,16,0,4096,4096,8233,20,32,256,33,4112,513]

theorem envBound14605 : H12AffineFastState.Bounded env14605 := by
  intro p hp
  have h : env14605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14604_14605 : H12AffineEnvironment.transform 5 16 env14604 = env14605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14604 == env14605) = true)

theorem identity14605 : scanCanonicalize (H12AffineFastState.compose env14605 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound14605 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env14606 : List Nat := [2,4,8,16,32,16,8,256,512,272,0,4096,41,4112,293,34,4388,1,272,292,4112,32,16,3,41,16,0,4096,4096,0,20,32,256,33,4112,513]

theorem envBound14606 : H12AffineFastState.Bounded env14606 := by
  intro p hp
  have h : env14606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14605_14606 : H12AffineEnvironment.transform 12 41 env14605 = env14606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env14605 == env14606) = true)

theorem identity14606 : scanCanonicalize (H12AffineFastState.compose env14606 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound14606 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14607 : List Nat := [2,4,8,16,32,16,8,256,512,272,0,308,41,292,293,34,16,1,272,292,292,32,16,3,41,16,0,308,308,0,20,32,256,33,292,513]

theorem envBound14607 : H12AffineFastState.Bounded env14607 := by
  intro p hp
  have h : env14607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14606_14607 : H12AffineEnvironment.transform 11 308 env14606 = env14607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env14606 == env14607) = true)

theorem identity14607 : scanCanonicalize (H12AffineFastState.compose env14607 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14607 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env14608 : List Nat := [2,4,8,16,32,16,8,37,512,53,0,17,41,1,0,34,16,1,53,1,1,32,16,3,41,16,0,17,17,0,20,32,37,33,1,513]

theorem envBound14608 : H12AffineFastState.Bounded env14608 := by
  intro p hp
  have h : env14608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14607_14608 : H12AffineEnvironment.transform 7 37 env14607 = env14608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14607 == env14608) = true)

theorem identity14608 : scanCanonicalize (H12AffineFastState.compose env14608 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound14608 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14609 : List Nat := [2,4,8,16,32,16,8,37,21,53,0,17,41,1,0,34,16,1,53,1,1,32,16,3,41,16,0,17,17,0,20,32,37,33,1,20]

theorem envBound14609 : H12AffineFastState.Bounded env14609 := by
  intro p hp
  have h : env14609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14608_14609 : H12AffineEnvironment.transform 8 21 env14608 = env14609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env14608 == env14609) = true)

theorem identity14609 : scanCanonicalize (H12AffineFastState.compose env14609 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound14609 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14610 : List Nat := [2,4,8,16,3,16,8,6,21,22,0,17,10,1,0,1,16,1,22,1,1,3,16,3,10,16,0,17,17,0,20,3,6,2,1,20]

theorem envBound14610 : H12AffineFastState.Bounded env14610 := by
  intro p hp
  have h : env14610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14609_14610 : H12AffineEnvironment.transform 4 3 env14609 = env14610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env14609 == env14610) = true)

theorem identity14610 : scanCanonicalize (H12AffineFastState.compose env14610 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14610 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14611 : List Nat := [2,4,8,1,3,1,8,6,4,7,0,0,10,1,0,1,1,1,7,1,1,3,1,3,10,1,0,0,0,0,5,3,6,2,1,5]

theorem envBound14611 : H12AffineFastState.Bounded env14611 := by
  intro p hp
  have h : env14611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14610_14611 : H12AffineEnvironment.transform 3 1 env14610 = env14611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14610 == env14611) = true)

theorem identity14611 : scanCanonicalize (H12AffineFastState.compose env14611 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound14611 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14612 : List Nat := [2,4,2,1,3,1,2,6,4,7,0,0,0,1,0,1,1,1,7,1,1,3,1,3,0,1,0,0,0,0,5,3,6,2,1,5]

theorem envBound14612 : H12AffineFastState.Bounded env14612 := by
  intro p hp
  have h : env14612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14611_14612 : H12AffineEnvironment.transform 2 2 env14611 = env14612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env14611 == env14612) = true)

theorem identity14612 : scanCanonicalize (H12AffineFastState.compose env14612 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound14612 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14613 : List Nat := [0,4,0,1,1,1,0,4,4,5,0,0,0,1,0,1,1,1,5,1,1,1,1,1,0,1,0,0,0,0,5,1,4,0,1,5]

theorem envBound14613 : H12AffineFastState.Bounded env14613 := by
  intro p hp
  have h : env14613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14612_14613 : H12AffineEnvironment.transform 0 0 env14612 = env14613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env14612 == env14613) = true)

def env14614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8322,131072,262144,1024,8540,4161,4194304,16,2,8328,64,4592845,5392,4096,406604,1501,4194304,256,32,5593,649]

theorem envBound14614 : H12AffineFastState.Bounded env14614 := by
  intro p hp
  have h : env14614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14597_14614 : H12AffineEnvironment.transform 13 5377 env14597 = env14614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14597 == env14614) = true)

theorem identity14614 : scanCanonicalize (H12AffineFastState.compose env14614 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14614 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14615 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,4194304,16,2,8192,64,4592709,5392,4096,406604,1365,4194304,256,32,5457,513]

theorem envBound14615 : H12AffineFastState.Bounded env14615 := by
  intro p hp
  have h : env14615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14614_14615 : H12AffineEnvironment.transform 6 8 env14614 = env14615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14614 == env14615) = true)

theorem identity14615 : scanCanonicalize (H12AffineFastState.compose env14615 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound14615 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,32,16,2,8192,64,398437,5392,4096,406604,1365,32,256,32,5457,513]

theorem envBound14616 : H12AffineFastState.Bounded env14616 := by
  intro p hp
  have h : env14616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14615_14616 : H12AffineEnvironment.transform 21 32 env14615 = env14616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env14615 == env14616) = true)

theorem identity14616 : scanCanonicalize (H12AffineFastState.compose env14616 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound14616 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14617 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,5392,262144,1024,8540,4161,32,16,2,8192,64,262517,5392,4096,270684,1365,32,256,32,5457,513]

theorem envBound14617 : H12AffineFastState.Bounded env14617 := by
  intro p hp
  have h : env14617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14616_14617 : H12AffineEnvironment.transform 16 5392 env14616 = env14617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env14616 == env14617) = true)

def env14618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17729,4194304,17,73856,8328,64,4592844,5393,4096,406605,20701,4194305,256,21793,16600,96011]

theorem envBound14618 : H12AffineFastState.Bounded env14618 := by
  intro p hp
  have h : env14618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14595_14618 : H12AffineEnvironment.transform 20 17729 env14595 = env14618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env14595 == env14618) = true)

theorem identity14618 : scanCanonicalize (H12AffineFastState.compose env14618 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 95650) := by decide +kernel

theorem selectedBound14618 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17729,95650,17,73856,8328,64,483694,5393,4096,406605,20701,95651,256,21793,16600,96011]

theorem envBound14619 : H12AffineFastState.Bounded env14619 := by
  intro p hp
  have h : env14619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14618_14619 : H12AffineEnvironment.transform 21 95650 env14618 = env14619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95650 env14618 == env14619) = true)

theorem identity14619 : scanCanonicalize (H12AffineFastState.compose env14619 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound14619 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env14620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1024,29789,17729,95650,17,73856,8328,64,262517,5393,4096,349270,20701,95651,256,21793,16600,96011]

theorem envBound14620 : H12AffineFastState.Bounded env14620 := by
  intro p hp
  have h : env14620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14619_14620 : H12AffineEnvironment.transform 16 90139 env14619 = env14620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env14619 == env14620) = true)

theorem identity14620 : scanCanonicalize (H12AffineFastState.compose env14620 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound14620 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env14621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,29962,5393,262144,1024,29789,17729,168,17,21898,8328,64,262517,5393,4096,270684,20701,169,256,21793,16600,513]

theorem envBound14621 : H12AffineFastState.Bounded env14621 := by
  intro p hp
  have h : env14621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14620_14621 : H12AffineEnvironment.transform 15 29962 env14620 = env14621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env14620 == env14621) = true)

theorem identity14621 : scanCanonicalize (H12AffineFastState.compose env14621 (packedSelected [11,18,21,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14621 : packedSelected [11,18,21,23,32] rootPS < 2^1333 := by decide +kernel

def env14622 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,5393,262144,1024,29789,17729,32,17,21762,8192,64,262517,5393,4096,270684,20565,33,256,21793,16464,513]

theorem envBound14622 : H12AffineFastState.Bounded env14622 := by
  intro p hp
  have h : env14622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14621_14622 : H12AffineEnvironment.transform 6 8 env14621 = env14622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14621 == env14622) = true)

theorem identity14622 : scanCanonicalize (H12AffineFastState.compose env14622 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound14622 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env14623 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,21590,5393,262144,1024,21761,17729,32,17,21762,348,64,262517,5393,4096,262144,20565,33,256,21793,16464,513]

theorem envBound14623 : H12AffineFastState.Bounded env14623 := by
  intro p hp
  have h : env14623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14622_14623 : H12AffineEnvironment.transform 12 348 env14622 = env14623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env14622 == env14623) = true)

theorem identity14623 : scanCanonicalize (H12AffineFastState.compose env14623 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound14623 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14624 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,21590,5393,2421,1024,21761,17729,32,17,21762,348,64,2048,5393,4096,2421,20565,33,256,21793,16464,513]

theorem envBound14624 : H12AffineFastState.Bounded env14624 := by
  intro p hp
  have h : env14624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14623_14624 : H12AffineEnvironment.transform 17 2421 env14623 = env14624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env14623 == env14624) = true)

theorem identity14624 : scanCanonicalize (H12AffineFastState.compose env14624 (packedSelected [4,9,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound14624 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env14625 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5457,81,263,5393,2421,1024,80,4112,32,17,83,348,64,2048,5393,4096,2421,1284,33,256,112,5377,513]

theorem envBound14625 : H12AffineFastState.Bounded env14625 := by
  intro p hp
  have h : env14625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14624_14625 : H12AffineEnvironment.transform 13 5457 env14624 = env14625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env14624 == env14625) = true)

def env14626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,2097152,4194304,2114897,73857,8328,64,6705549,2117713,4097,2519309,2102684,6309185,256,21793,16600,2175562]

theorem envBound14626 : H12AffineFastState.Bounded env14626 := by
  intro p hp
  have h : env14626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14594_14626 : H12AffineEnvironment.transform 22 2114897 env14594 = env14626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114897 env14594 == env14626) = true)

def env14627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17728,4194304,17,73857,8328,64,4592845,5393,4097,406605,20700,4194305,256,21793,16600,96010]

theorem envBound14627 : H12AffineFastState.Bounded env14627 := by
  intro p hp
  have h : env14627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14626_14627 : H12AffineEnvironment.transform 20 17728 env14626 = env14627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env14626 == env14627) = true)

theorem identity14627 : scanCanonicalize (H12AffineFastState.compose env14627 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 95531) := by decide +kernel

theorem selectedBound14627 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17728,95531,17,73857,8328,64,483814,5393,4097,406605,20700,95530,256,21793,16600,96010]

theorem envBound14628 : H12AffineFastState.Bounded env14628 := by
  intro p hp
  have h : env14628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14627_14628 : H12AffineEnvironment.transform 21 95531 env14627 = env14628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95531 env14627 == env14628) = true)

def env14629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4160,73771,17,73857,8328,64,472294,5393,4097,406605,1500,73770,256,33,5592,74250]

theorem envBound14629 : H12AffineFastState.Bounded env14629 := by
  intro p hp
  have h : env14629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14628_14629 : H12AffineEnvironment.transform 13 5376 env14628 = env14629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env14628 == env14629) = true)

theorem identity14629 : scanCanonicalize (H12AffineFastState.compose env14629 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound14629 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,67618,1024,8541,4160,73771,17,73857,8328,64,146628,5393,4097,212079,1500,73770,256,33,5592,74250]

theorem envBound14630 : H12AffineFastState.Bounded env14630 := by
  intro p hp
  have h : env14630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14629_14630 : H12AffineEnvironment.transform 17 67618 env14629 = env14630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env14629 == env14630) = true)

theorem identity14630 : scanCanonicalize (H12AffineFastState.compose env14630 (packedSelected [1,10,16,18,20,23,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound14630 : packedSelected [1,10,16,18,20,23,26,28] rootPS < 2^1333 := by decide +kernel

def env14631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,5393,67618,1024,8541,4160,73771,17,73857,8328,64,10709,5393,4097,76158,1500,73770,256,33,5592,74250]

theorem envBound14631 : H12AffineFastState.Bounded env14631 := by
  intro p hp
  have h : env14631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14630_14631 : H12AffineEnvironment.transform 16 5393 env14630 = env14631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env14630 == env14631) = true)

theorem identity14631 : scanCanonicalize (H12AffineFastState.compose env14631 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14631 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env14632 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,5393,67618,1024,8541,4160,73771,17,73736,8193,64,10588,5393,4097,76158,1365,73770,256,33,5457,74250]

theorem envBound14632 : H12AffineFastState.Bounded env14632 := by
  intro p hp
  have h : env14632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14631_14632 : H12AffineEnvironment.transform 6 9 env14631 = env14632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14631 == env14632) = true)

theorem identity14632 : scanCanonicalize (H12AffineFastState.compose env14632 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound14632 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,292,65536,5393,67618,1024,293,4160,65619,17,65648,121,64,2340,5393,4097,67846,1365,65618,256,33,5457,66162]

theorem envBound14633 : H12AffineFastState.Bounded env14633 := by
  intro p hp
  have h : env14633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14632_14633 : H12AffineEnvironment.transform 12 120 env14632 = env14633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env14632 == env14633) = true)

theorem identity14633 : scanCanonicalize (H12AffineFastState.compose env14633 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound14633 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env14634 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,120,4112,292,65536,4097,67618,272,293,4160,65619,17,65648,121,64,2340,4097,4097,67846,69,65618,256,33,4161,66162]

theorem envBound14634 : H12AffineFastState.Bounded env14634 := by
  intro p hp
  have h : env14634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14633_14634 : H12AffineEnvironment.transform 9 272 env14633 = env14634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14633 == env14634) = true)

theorem identity14634 : scanCanonicalize (H12AffineFastState.compose env14634 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14634 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14635 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,4096,120,4112,0,65536,4097,67618,52,1,4160,65619,17,65648,121,64,2048,4097,4097,67618,69,65618,36,33,4161,66162]

theorem envBound14635 : H12AffineFastState.Bounded env14635 := by
  intro p hp
  have h : env14635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14634_14635 : H12AffineEnvironment.transform 7 36 env14634 = env14635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14634 == env14635) = true)

theorem identity14635 : scanCanonicalize (H12AffineFastState.compose env14635 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(15+1) ^^^ 4146) := by decide +kernel

theorem selectedBound14635 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env14636 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,4096,120,4112,0,4146,4097,6160,52,1,4160,4193,17,4162,121,64,2048,4097,4097,6160,69,4192,36,33,4161,4672]

theorem envBound14636 : H12AffineFastState.Bounded env14636 := by
  intro p hp
  have h : env14636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14635_14636 : H12AffineEnvironment.transform 15 4146 env14635 = env14636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4146 env14635 == env14636) = true)

theorem identity14636 : scanCanonicalize (H12AffineFastState.compose env14636 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 635) := by decide +kernel

theorem selectedBound14636 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env14637 : List Nat := [2,4,8,16,32,64,9,36,512,52,635,4096,120,4112,0,4146,4097,4715,52,1,4160,4193,17,4162,121,64,635,4097,4097,4715,69,4192,36,33,4161,4672]

theorem envBound14637 : H12AffineFastState.Bounded env14637 := by
  intro p hp
  have h : env14637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14636_14637 : H12AffineEnvironment.transform 10 635 env14636 = env14637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 635 env14636 == env14637) = true)

theorem identity14637 : scanCanonicalize (H12AffineFastState.compose env14637 (packedSelected [12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14637 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env14638 : List Nat := [2,4,8,16,32,17,9,36,512,52,554,4096,41,4112,0,4146,4097,4666,52,1,4113,4144,17,4115,40,17,554,4097,4097,4666,20,4145,36,33,4112,4625]

theorem envBound14638 : H12AffineFastState.Bounded env14638 := by
  intro p hp
  have h : env14638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14637_14638 : H12AffineEnvironment.transform 5 17 env14637 = env14638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14637 == env14638) = true)

theorem identity14638 : scanCanonicalize (H12AffineFastState.compose env14638 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound14638 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env14639 : List Nat := [2,4,8,16,32,17,9,36,11,52,33,4096,41,4112,0,4146,4097,4145,52,1,4113,4144,17,4115,40,17,33,4097,4097,4145,20,4145,36,33,4112,4122]

theorem envBound14639 : H12AffineFastState.Bounded env14639 := by
  intro p hp
  have h : env14639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14638_14639 : H12AffineEnvironment.transform 8 11 env14638 = env14639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env14638 == env14639) = true)

theorem identity14639 : scanCanonicalize (H12AffineFastState.compose env14639 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 31) := by decide +kernel

theorem selectedBound14639 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env14640 : List Nat := [2,4,8,16,31,17,9,27,11,11,30,4096,22,4112,0,4109,4097,4110,11,1,4113,4111,17,4115,23,17,30,4097,4097,4110,20,4110,27,30,4112,4122]

theorem envBound14640 : H12AffineFastState.Bounded env14640 := by
  intro p hp
  have h : env14640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14639_14640 : H12AffineEnvironment.transform 4 31 env14639 = env14640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 31 env14639 == env14640) = true)

theorem identity14640 : scanCanonicalize (H12AffineFastState.compose env14640 (packedSelected [1,2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound14640 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env14641 : List Nat := [1,4,8,16,28,17,9,24,8,8,29,4096,21,4112,0,4109,4097,4109,8,1,4113,4108,17,4112,20,17,29,4097,4097,4109,20,4109,24,29,4112,4121]

theorem envBound14641 : H12AffineFastState.Bounded env14641 := by
  intro p hp
  have h : env14641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14640_14641 : H12AffineEnvironment.transform 0 1 env14640 = env14641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env14640 == env14641) = true)

theorem identity14641 : scanCanonicalize (H12AffineFastState.compose env14641 (packedSelected [1,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound14641 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env14642 : List Nat := [1,4,8,16,28,17,9,24,8,8,29,16,21,0,0,29,17,29,8,1,1,28,17,0,20,17,29,17,17,29,20,29,24,29,0,9]

theorem envBound14642 : H12AffineFastState.Bounded env14642 := by
  intro p hp
  have h : env14642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14641_14642 : H12AffineEnvironment.transform 11 16 env14641 = env14642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env14641 == env14642) = true)

theorem identity14642 : scanCanonicalize (H12AffineFastState.compose env14642 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound14642 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14643 : List Nat := [1,4,8,13,1,12,9,5,8,8,0,13,8,0,0,0,12,0,8,1,1,1,12,0,9,12,0,12,12,0,9,0,5,0,0,9]

theorem envBound14643 : H12AffineFastState.Bounded env14643 := by
  intro p hp
  have h : env14643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14642_14643 : H12AffineEnvironment.transform 3 13 env14642 = env14643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env14642 == env14643) = true)

def env14644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,4161,73770,17,73857,8328,64,472295,5393,4097,406605,1501,73771,256,32,5593,74251]

theorem envBound14644 : H12AffineFastState.Bounded env14644 := by
  intro p hp
  have h : env14644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14628_14644 : H12AffineEnvironment.transform 13 5377 env14628 = env14644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14628 == env14644) = true)

theorem identity14644 : scanCanonicalize (H12AffineFastState.compose env14644 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound14644 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,67755,1024,8540,4161,73770,17,73857,8328,64,146508,5393,4097,212198,1501,73771,256,32,5593,74251]

theorem envBound14645 : H12AffineFastState.Bounded env14645 := by
  intro p hp
  have h : env14645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14644_14645 : H12AffineEnvironment.transform 17 67755 env14644 = env14645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env14644 == env14645) = true)

theorem identity14645 : scanCanonicalize (H12AffineFastState.compose env14645 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound14645 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env14646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,5392,67755,1024,8540,4161,73770,17,73857,8328,64,10588,5393,4097,76278,1501,73771,256,32,5593,74251]

theorem envBound14646 : H12AffineFastState.Bounded env14646 := by
  intro p hp
  have h : env14646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14645_14646 : H12AffineEnvironment.transform 16 5392 env14645 = env14646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env14645 == env14646) = true)

def env14647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17729,4194304,16,73857,8328,64,4592844,5392,4097,406604,20701,4194304,256,21793,16600,96011]

theorem envBound14647 : H12AffineFastState.Bounded env14647 := by
  intro p hp
  have h : env14647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14626_14647 : H12AffineEnvironment.transform 20 17729 env14626 = env14647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env14626 == env14647) = true)

theorem identity14647 : scanCanonicalize (H12AffineFastState.compose env14647 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound14647 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,29962,131072,262144,1024,29789,17729,4194304,16,21899,8328,64,4592844,5392,4097,406604,20701,4194304,256,21793,16600,513]

theorem envBound14648 : H12AffineFastState.Bounded env14648 := by
  intro p hp
  have h : env14648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14647_14648 : H12AffineEnvironment.transform 15 29962 env14647 = env14648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env14647 == env14648) = true)

def env14649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8202,131072,262144,1024,8541,4161,4194304,16,139,8328,64,4592844,5392,4097,406604,1501,4194304,256,33,5592,513]

theorem envBound14649 : H12AffineFastState.Bounded env14649 := by
  intro p hp
  have h : env14649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14648_14649 : H12AffineEnvironment.transform 13 5376 env14648 = env14649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env14648 == env14649) = true)

theorem identity14649 : scanCanonicalize (H12AffineFastState.compose env14649 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2556) := by decide +kernel

theorem selectedBound14649 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8202,131072,2556,1024,8541,4161,4194304,16,139,8328,64,4332848,5392,4097,146864,1501,4194304,256,33,5592,513]

theorem envBound14650 : H12AffineFastState.Bounded env14650 := by
  intro p hp
  have h : env14650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14649_14650 : H12AffineEnvironment.transform 17 2556 env14649 = env14650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2556 env14649 == env14650) = true)

theorem identity14650 : scanCanonicalize (H12AffineFastState.compose env14650 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14650 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,131072,2420,1024,8541,4161,4194304,16,3,8192,64,4332848,5392,4097,146744,1365,4194304,256,33,5456,513]

theorem envBound14651 : H12AffineFastState.Bounded env14651 := by
  intro p hp
  have h : env14651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14650_14651 : H12AffineEnvironment.transform 6 8 env14650 = env14651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14650 == env14651) = true)

theorem identity14651 : scanCanonicalize (H12AffineFastState.compose env14651 (packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(21+1) ^^^ 144492) := by decide +kernel

theorem selectedBound14651 : packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env14652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,131072,2420,1024,8541,4161,144492,16,3,8192,64,10588,5392,4097,146744,1365,144492,256,33,5456,513]

theorem envBound14652 : H12AffineFastState.Bounded env14652 := by
  intro p hp
  have h : env14652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14651_14652 : H12AffineEnvironment.transform 21 144492 env14651 = env14652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144492 env14651 == env14652) = true)

theorem identity14652 : scanCanonicalize (H12AffineFastState.compose env14652 (packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14652 : packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env14653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,343,131072,2420,1024,0,4161,136497,16,3,349,64,2049,5392,4097,138341,1365,136497,256,33,5456,513]

theorem envBound14653 : H12AffineFastState.Bounded env14653 := by
  intro p hp
  have h : env14653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14652_14653 : H12AffineEnvironment.transform 12 349 env14652 = env14653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14652 == env14653) = true)

theorem identity14653 : scanCanonicalize (H12AffineFastState.compose env14653 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound14653 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,343,5393,2420,1024,0,4161,32,16,3,349,64,2049,5392,4097,2420,1365,32,256,33,5456,513]

theorem envBound14654 : H12AffineFastState.Bounded env14654 := by
  intro p hp
  have h : env14654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14653_14654 : H12AffineEnvironment.transform 16 5393 env14653 = env14654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env14653 == env14654) = true)

theorem identity14654 : scanCanonicalize (H12AffineFastState.compose env14654 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound14654 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1572,349,804,1,343,821,2420,1024,0,1637,32,16,3,349,64,2049,820,1573,2420,1365,32,256,33,884,513]

theorem envBound14655 : H12AffineFastState.Bounded env14655 := by
  intro p hp
  have h : env14655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14654_14655 : H12AffineEnvironment.transform 11 1572 env14654 = env14655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env14654 == env14655) = true)

theorem identity14655 : scanCanonicalize (H12AffineFastState.compose env14655 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound14655 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1573,1572,349,804,1,343,821,1873,1024,0,1637,32,16,3,349,64,1572,820,1573,1873,1365,32,256,33,884,513]

theorem envBound14656 : H12AffineFastState.Bounded env14656 := by
  intro p hp
  have h : env14656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14655_14656 : H12AffineEnvironment.transform 10 1573 env14655 = env14656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env14655 == env14656) = true)

def env14657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8203,131072,262144,1024,8540,4160,4194304,16,138,8328,64,4592844,5392,4097,406604,1500,4194304,256,32,5593,513]

theorem envBound14657 : H12AffineFastState.Bounded env14657 := by
  intro p hp
  have h : env14657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14648_14657 : H12AffineEnvironment.transform 13 5377 env14648 = env14657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14648 == env14657) = true)

theorem identity14657 : scanCanonicalize (H12AffineFastState.compose env14657 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146913) := by decide +kernel

theorem selectedBound14657 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8203,131072,146913,1024,8540,4160,4194304,16,138,8328,64,4204845,5392,4097,2477,1500,4194304,256,32,5593,513]

theorem envBound14658 : H12AffineFastState.Bounded env14658 := by
  intro p hp
  have h : env14658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14657_14658 : H12AffineEnvironment.transform 17 146913 env14657 = env14658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env14657 == env14658) = true)

theorem identity14658 : scanCanonicalize (H12AffineFastState.compose env14658 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 136497) := by decide +kernel

theorem selectedBound14658 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env14659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8203,131072,146913,1024,8540,4160,136497,16,138,8328,64,146460,5392,4097,2477,1500,136497,256,32,5593,513]

theorem envBound14659 : H12AffineFastState.Bounded env14659 := by
  intro p hp
  have h : env14659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14658_14659 : H12AffineEnvironment.transform 21 136497 env14658 = env14659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136497 env14658 == env14659) = true)

theorem identity14659 : scanCanonicalize (H12AffineFastState.compose env14659 (packedSelected [0,1,4,7,10,18,19,22,23,28] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound14659 : packedSelected [0,1,4,7,10,18,19,22,23,28] rootPS < 2^1333 := by decide +kernel

def env14660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8203,13461,2420,1024,8540,4160,8612,16,138,8328,64,2185,5392,4097,2477,1500,8612,256,32,5593,513]

theorem envBound14660 : H12AffineFastState.Bounded env14660 := by
  intro p hp
  have h : env14660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14659_14660 : H12AffineEnvironment.transform 16 13461 env14659 = env14660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env14659 == env14660) = true)

theorem identity14660 : scanCanonicalize (H12AffineFastState.compose env14660 (packedSelected [0,1,3,5,7,8,9,10,14,18,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound14660 : packedSelected [0,1,3,5,7,8,9,10,14,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env14661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5377,217,399,5393,2420,1024,216,4160,32,16,138,268,64,2185,5392,4097,2477,1500,32,256,32,5593,513]

theorem envBound14661 : H12AffineFastState.Bounded env14661 := by
  intro p hp
  have h : env14661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14660_14661 : H12AffineEnvironment.transform 12 388 env14660 = env14661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env14660 == env14661) = true)

theorem identity14661 : scanCanonicalize (H12AffineFastState.compose env14661 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound14661 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env14662 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,241,5236,217,250,5220,2049,1024,216,4160,32,16,138,121,64,2185,5221,4097,2264,1193,32,117,32,5292,513]

theorem envBound14662 : H12AffineFastState.Bounded env14662 := by
  intro p hp
  have h : env14662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14661_14662 : H12AffineEnvironment.transform 7 117 env14661 = env14662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env14661 == env14662) = true)

theorem identity14662 : scanCanonicalize (H12AffineFastState.compose env14662 (packedSelected [5,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound14662 : packedSelected [5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env14663 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,3189,241,2049,217,250,2065,2049,1024,216,3125,32,16,138,121,64,2185,2064,3188,2264,1193,32,117,32,2265,513]

theorem envBound14663 : H12AffineFastState.Bounded env14663 := by
  intro p hp
  have h : env14663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14662_14663 : H12AffineEnvironment.transform 11 3189 env14662 = env14663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env14662 == env14663) = true)

theorem identity14663 : scanCanonicalize (H12AffineFastState.compose env14663 (packedSelected [1,3,4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound14663 : packedSelected [1,3,4,9,11] rootPS < 2^1333 := by decide +kernel

def env14664 : List Nat := [2,4,8,16,32,64,128,117,512,1024,1076,65,241,1077,217,250,1061,1077,1024,216,1,32,16,138,121,64,1213,1060,64,1260,1193,32,117,32,1261,513]

theorem envBound14664 : H12AffineFastState.Bounded env14664 := by
  intro p hp
  have h : env14664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14663_14664 : H12AffineEnvironment.transform 10 1076 env14663 = env14664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env14663 == env14664) = true)

theorem identity14664 : scanCanonicalize (H12AffineFastState.compose env14664 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound14664 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env14665 : List Nat := [2,4,8,16,32,64,89,117,512,1024,1076,65,40,1077,0,35,1061,1077,1024,1,1,32,16,83,121,64,1124,1060,64,1077,1136,32,117,32,1076,513]

theorem envBound14665 : H12AffineFastState.Bounded env14665 := by
  intro p hp
  have h : env14665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14664_14665 : H12AffineEnvironment.transform 6 89 env14664 = env14665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env14664 == env14665) = true)

def env14666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,2097152,4194304,8388608,10577360,8328,64,6705548,8393985,10507600,8795229,2102685,12582928,256,21792,16600,2175563]

theorem envBound14666 : H12AffineFastState.Bounded env14666 := by
  intro p hp
  have h : env14666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14593_14666 : H12AffineEnvironment.transform 14 29789 env14593 = env14666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env14593 == env14666) = true)

def env14667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,2097152,4194304,2114896,73856,8328,64,6705548,2117713,4096,2519309,2102685,6309184,256,21792,16600,2175563]

theorem envBound14667 : H12AffineFastState.Bounded env14667 := by
  intro p hp
  have h : env14667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14666_14667 : H12AffineEnvironment.transform 22 2114896 env14666 = env14667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114896 env14666 == env14667) = true)

def env14668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17728,4194304,16,73856,8328,64,4592844,5393,4096,406605,20701,4194304,256,21792,16600,96011]

theorem envBound14668 : H12AffineFastState.Bounded env14668 := by
  intro p hp
  have h : env14668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14667_14668 : H12AffineEnvironment.transform 20 17728 env14667 = env14668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env14667 == env14668) = true)

theorem identity14668 : scanCanonicalize (H12AffineFastState.compose env14668 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14668 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14669 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17728,4194304,16,73736,8192,64,4592708,5393,4096,406605,20565,4194304,256,21792,16464,96011]

theorem envBound14669 : H12AffineFastState.Bounded env14669 := by
  intro p hp
  have h : env14669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14668_14669 : H12AffineEnvironment.transform 6 8 env14668 = env14669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14668 == env14669) = true)

theorem identity14669 : scanCanonicalize (H12AffineFastState.compose env14669 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound14669 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14670 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,131072,262144,1024,29788,17728,4194304,16,21762,8192,64,4592708,5393,4096,406605,20565,4194304,256,21792,16464,513]

theorem envBound14670 : H12AffineFastState.Bounded env14670 := by
  intro p hp
  have h : env14670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14669_14670 : H12AffineEnvironment.transform 15 29962 env14669 = env14670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env14669 == env14670) = true)

def env14671 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,8192,16384,29789,29962,131072,262144,1024,29788,17728,4194304,16,21762,8192,64,4592708,5393,4096,406605,20565,4194304,256,21792,16464,513]

theorem envBound14671 : H12AffineFastState.Bounded env14671 := by
  intro p hp
  have h : env14671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14670_14671 : H12AffineEnvironment.transform 10 0 env14670 = env14671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env14670 == env14671) = true)

theorem identity14671 : scanCanonicalize (H12AffineFastState.compose env14671 (packedSelected [4,9,11] rootPS)) = affineNative (2^(17+1) ^^^ 147765) := by decide +kernel

theorem selectedBound14671 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env14672 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,8192,16384,29789,29962,131072,147765,1024,29788,17728,4194304,16,21762,8192,64,4216177,5393,4096,30072,20565,4194304,256,21792,16464,513]

theorem envBound14672 : H12AffineFastState.Bounded env14672 := by
  intro p hp
  have h : env14672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14671_14672 : H12AffineEnvironment.transform 17 147765 env14671 = env14672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 147765 env14671 == env14672) = true)

theorem identity14672 : scanCanonicalize (H12AffineFastState.compose env14672 (packedSelected [0,1,2,3,6,18,20,23,24,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound14672 : packedSelected [0,1,2,3,6,18,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env14673 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,8192,16384,29789,29962,5392,21541,1024,29788,17728,4194304,16,21762,8192,64,4216177,5393,4096,30072,20565,4194304,256,21792,16464,513]

theorem envBound14673 : H12AffineFastState.Bounded env14673 := by
  intro p hp
  have h : env14673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14672_14673 : H12AffineEnvironment.transform 16 5392 env14672 = env14673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env14672 == env14673) = true)

theorem identity14673 : scanCanonicalize (H12AffineFastState.compose env14673 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound14673 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env14674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,8192,13324,81,262,5392,8233,1024,80,12620,4194304,16,8462,8192,64,4202877,5393,4096,372,9305,4194304,256,8492,13404,513]

theorem envBound14674 : H12AffineFastState.Bounded env14674 := by
  intro p hp
  have h : env14674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14673_14674 : H12AffineEnvironment.transform 13 13324 env14673 = env14674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env14673 == env14674) = true)

theorem identity14674 : scanCanonicalize (H12AffineFastState.compose env14674 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound14674 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,8192,13324,81,262,5392,8233,1024,80,12620,8492,16,8462,8192,64,81,5393,4096,372,9305,8492,256,8492,13404,513]

theorem envBound14675 : H12AffineFastState.Bounded env14675 := by
  intro p hp
  have h : env14675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14674_14675 : H12AffineEnvironment.transform 21 8492 env14674 = env14675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env14674 == env14675) = true)

theorem identity14675 : scanCanonicalize (H12AffineFastState.compose env14675 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound14675 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,41,5157,81,262,5392,0,1024,80,4453,261,16,295,41,64,81,5393,4096,372,1136,261,256,261,5237,513]

theorem envBound14676 : H12AffineFastState.Bounded env14676 := by
  intro p hp
  have h : env14676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14675_14676 : H12AffineEnvironment.transform 12 41 env14675 = env14676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env14675 == env14676) = true)

theorem identity14676 : scanCanonicalize (H12AffineFastState.compose env14676 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound14676 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14677 : List Nat := [2,4,8,16,32,64,8,117,512,1024,0,4096,41,5157,81,115,5221,0,1024,80,4112,112,16,82,41,64,81,5220,4096,1,1136,112,117,112,5237,513]

theorem envBound14677 : H12AffineFastState.Bounded env14677 := by
  intro p hp
  have h : env14677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14676_14677 : H12AffineEnvironment.transform 7 117 env14676 = env14677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env14676 == env14677) = true)

theorem identity14677 : scanCanonicalize (H12AffineFastState.compose env14677 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound14677 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env14678 : List Nat := [2,4,8,16,32,64,8,117,512,69,0,4096,41,4192,81,115,4128,0,69,80,4112,112,16,82,41,64,81,4129,4096,1,53,112,117,112,4144,513]

theorem envBound14678 : H12AffineFastState.Bounded env14678 := by
  intro p hp
  have h : env14678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14677_14678 : H12AffineEnvironment.transform 9 69 env14677 = env14678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env14677 == env14678) = true)

theorem identity14678 : scanCanonicalize (H12AffineFastState.compose env14678 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound14678 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env14679 : List Nat := [2,4,8,16,32,64,8,117,512,69,0,48,41,80,81,115,16,0,69,80,32,112,16,82,41,64,81,17,48,1,53,112,117,112,0,513]

theorem envBound14679 : H12AffineFastState.Bounded env14679 := by
  intro p hp
  have h : env14679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14678_14679 : H12AffineEnvironment.transform 11 48 env14678 = env14679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env14678 == env14679) = true)

theorem identity14679 : scanCanonicalize (H12AffineFastState.compose env14679 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 31) := by decide +kernel

theorem selectedBound14679 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env14680 : List Nat := [2,4,8,16,32,31,8,42,512,26,0,48,41,15,14,44,16,0,26,15,32,47,16,13,41,31,14,17,48,1,53,47,42,47,0,513]

theorem envBound14680 : H12AffineFastState.Bounded env14680 := by
  intro p hp
  have h : env14680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14679_14680 : H12AffineEnvironment.transform 5 31 env14679 = env14680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 31 env14679 == env14680) = true)

theorem identity14680 : scanCanonicalize (H12AffineFastState.compose env14680 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound14680 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14681 : List Nat := [2,4,8,16,14,31,8,4,512,26,0,30,7,15,14,2,16,0,26,15,14,1,16,13,7,31,14,17,30,1,27,1,4,1,0,513]

theorem envBound14681 : H12AffineFastState.Bounded env14681 := by
  intro p hp
  have h : env14681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14680_14681 : H12AffineEnvironment.transform 4 14 env14680 = env14681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env14680 == env14681) = true)

def env14682 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,8192,16384,29789,29962,131072,262144,1024,29788,17728,4194304,16,21762,8192,64,4592708,5393,4096,406605,20565,4194304,256,21792,16464,513]

theorem envBound14682 : H12AffineFastState.Bounded env14682 := by
  intro p hp
  have h : env14682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14670_14682 : H12AffineEnvironment.transform 10 1 env14670 = env14682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env14670 == env14682) = true)

theorem identity14682 : scanCanonicalize (H12AffineFastState.compose env14682 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound14682 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env14683 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,8192,16384,29789,29962,24860,262144,1024,29788,17728,4194304,16,21762,8192,64,4486488,5393,4096,283985,20565,4194304,256,21792,16464,513]

theorem envBound14683 : H12AffineFastState.Bounded env14683 := by
  intro p hp
  have h : env14683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14682_14683 : H12AffineEnvironment.transform 16 24860 env14682 = env14683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env14682 == env14683) = true)

theorem identity14683 : scanCanonicalize (H12AffineFastState.compose env14683 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 21792) := by decide +kernel

theorem selectedBound14683 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14684 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,8192,16384,29789,29962,24860,262144,1024,29788,17728,21792,16,21762,8192,64,270456,5393,4096,283985,20565,21792,256,21792,16464,513]

theorem envBound14684 : H12AffineFastState.Bounded env14684 := by
  intro p hp
  have h : env14684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14683_14684 : H12AffineEnvironment.transform 21 21792 env14683 = env14684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env14683 == env14684) = true)

theorem identity14684 : scanCanonicalize (H12AffineFastState.compose env14684 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 30072) := by decide +kernel

theorem selectedBound14684 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env14685 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,8192,16384,29789,29962,24860,30072,1024,29788,17728,21792,16,21762,8192,64,21760,5393,4096,8233,20565,21792,256,21792,16464,513]

theorem envBound14685 : H12AffineFastState.Bounded env14685 := by
  intro p hp
  have h : env14685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14684_14685 : H12AffineEnvironment.transform 17 30072 env14684 = env14685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30072 env14684 == env14685) = true)

theorem identity14685 : scanCanonicalize (H12AffineFastState.compose env14685 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14685 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env14686 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,349,16384,21760,21591,16449,21541,1024,21761,17728,21792,16,21762,349,64,21760,5393,4096,372,20565,21792,256,21792,16464,513]

theorem envBound14686 : H12AffineFastState.Bounded env14686 := by
  intro p hp
  have h : env14686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14685_14686 : H12AffineEnvironment.transform 12 349 env14685 = env14686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14685 == env14686) = true)

def env14687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17729,4194304,17,73856,8328,64,4592845,5392,4096,406604,20700,4194305,256,21792,16600,96010]

theorem envBound14687 : H12AffineFastState.Bounded env14687 := by
  intro p hp
  have h : env14687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14667_14687 : H12AffineEnvironment.transform 20 17729 env14667 = env14687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env14667 == env14687) = true)

theorem identity14687 : scanCanonicalize (H12AffineFastState.compose env14687 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound14687 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17729,168,17,73856,8328,64,398437,5392,4096,406604,20700,169,256,21792,16600,96010]

theorem envBound14688 : H12AffineFastState.Bounded env14688 := by
  intro p hp
  have h : env14688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14687_14688 : H12AffineEnvironment.transform 21 168 env14687 = env14688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env14687 == env14688) = true)

theorem identity14688 : scanCanonicalize (H12AffineFastState.compose env14688 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound14688 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env14689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1024,29788,17729,168,17,73856,8328,64,357502,5392,4096,349271,20700,169,256,21792,16600,96010]

theorem envBound14689 : H12AffineFastState.Bounded env14689 := by
  intro p hp
  have h : env14689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14688_14689 : H12AffineEnvironment.transform 16 90139 env14688 = env14689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env14688 == env14689) = true)

theorem identity14689 : scanCanonicalize (H12AffineFastState.compose env14689 (packedSelected [1,3,4,5,7,8,9,10,11,14,16,18,19,20,21,23,27,32,35] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14689 : packedSelected [1,3,4,5,7,8,9,10,11,14,16,18,19,20,21,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env14690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1024,29788,17729,32,17,73736,8192,64,357502,5392,4096,349271,20564,33,256,21792,16464,96010]

theorem envBound14690 : H12AffineFastState.Bounded env14690 := by
  intro p hp
  have h : env14690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14689_14690 : H12AffineEnvironment.transform 6 8 env14689 = env14690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14689 == env14690) = true)

theorem identity14690 : scanCanonicalize (H12AffineFastState.compose env14690 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound14690 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14691 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,89378,1024,29788,17729,32,17,73736,8192,64,10588,5392,4096,2421,20564,33,256,21792,16464,96010]

theorem envBound14691 : H12AffineFastState.Bounded env14691 := by
  intro p hp
  have h : env14691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14690_14691 : H12AffineEnvironment.transform 17 89378 env14690 = env14691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env14690 == env14691) = true)

theorem identity14691 : scanCanonicalize (H12AffineFastState.compose env14691 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound14691 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env14692 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8283,16448,32121,1024,29788,17729,32,17,83,8192,64,10588,5392,4096,2421,20564,33,256,21792,16464,22353]

theorem envBound14692 : H12AffineFastState.Bounded env14692 := by
  intro p hp
  have h : env14692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14691_14692 : H12AffineEnvironment.transform 15 8283 env14691 = env14692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env14691 == env14692) = true)

theorem identity14692 : scanCanonicalize (H12AffineFastState.compose env14692 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound14692 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env14693 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8461,8283,5392,10281,1024,8460,4113,32,17,83,8192,64,10588,5392,4096,2421,1284,33,256,112,5376,513]

theorem envBound14693 : H12AffineFastState.Bounded env14693 := by
  intro p hp
  have h : env14693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14692_14693 : H12AffineEnvironment.transform 13 5456 env14692 = env14693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env14692 == env14693) = true)

theorem identity14693 : scanCanonicalize (H12AffineFastState.compose env14693 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound14693 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env14694 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,81,263,5392,2421,1024,80,4113,32,17,83,348,64,2048,5392,4096,2421,1284,33,256,112,5376,513]

theorem envBound14694 : H12AffineFastState.Bounded env14694 := by
  intro p hp
  have h : env14694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14693_14694 : H12AffineEnvironment.transform 12 348 env14693 = env14694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env14693 == env14694) = true)

def env14695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,2097152,4194304,2114897,73857,8328,64,6705548,2117712,4097,2519308,2102685,6309185,256,21792,16600,2175563]

theorem envBound14695 : H12AffineFastState.Bounded env14695 := by
  intro p hp
  have h : env14695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14666_14695 : H12AffineEnvironment.transform 22 2114897 env14666 = env14695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114897 env14666 == env14695) = true)

def env14696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17728,4194304,17,73857,8328,64,4592844,5392,4097,406604,20701,4194305,256,21792,16600,96011]

theorem envBound14696 : H12AffineFastState.Bounded env14696 := by
  intro p hp
  have h : env14696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14695_14696 : H12AffineEnvironment.transform 20 17728 env14695 = env14696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env14695 == env14696) = true)

theorem identity14696 : scanCanonicalize (H12AffineFastState.compose env14696 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound14696 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17728,32,17,73857,8328,64,398572,5392,4097,406604,20701,33,256,21792,16600,96011]

theorem envBound14697 : H12AffineFastState.Bounded env14697 := by
  intro p hp
  have h : env14697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14696_14697 : H12AffineEnvironment.transform 21 32 env14696 = env14697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env14696 == env14697) = true)

def env14698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4160,32,17,73857,8328,64,398572,5392,4097,406604,1501,33,256,32,5592,74251]

theorem envBound14698 : H12AffineFastState.Bounded env14698 := by
  intro p hp
  have h : env14698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14697_14698 : H12AffineEnvironment.transform 13 5376 env14697 = env14698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env14697 == env14698) = true)

theorem identity14698 : scanCanonicalize (H12AffineFastState.compose env14698 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound14698 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,67755,1024,8540,4160,32,17,73857,8328,64,203847,5392,4097,212199,1501,33,256,32,5592,74251]

theorem envBound14699 : H12AffineFastState.Bounded env14699 := by
  intro p hp
  have h : env14699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14698_14699 : H12AffineEnvironment.transform 17 67755 env14698 = env14699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env14698 == env14699) = true)

theorem identity14699 : scanCanonicalize (H12AffineFastState.compose env14699 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound14699 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env14700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,131072,10281,1024,8540,4160,32,17,3,8328,64,146629,5392,4097,138341,1501,33,256,32,5592,649]

theorem envBound14700 : H12AffineFastState.Bounded env14700 := by
  intro p hp
  have h : env14700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14699_14700 : H12AffineEnvironment.transform 15 8322 env14699 = env14700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env14699 == env14700) = true)

theorem identity14700 : scanCanonicalize (H12AffineFastState.compose env14700 (packedSelected [0,2,7,11,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5577) := by decide +kernel

theorem selectedBound14700 : packedSelected [0,2,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env14701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,5577,10281,1024,8540,4160,32,17,3,8328,64,10508,5392,4097,2476,1501,33,256,32,5592,649]

theorem envBound14701 : H12AffineFastState.Bounded env14701 := by
  intro p hp
  have h : env14701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14700_14701 : H12AffineEnvironment.transform 16 5577 env14700 = env14701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5577 env14700 == env14701) = true)

theorem identity14701 : scanCanonicalize (H12AffineFastState.compose env14701 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14701 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env14702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,80,399,5577,2340,1024,81,4160,32,17,3,389,64,2049,5392,4097,2476,1501,33,256,32,5592,649]

theorem envBound14702 : H12AffineFastState.Bounded env14702 := by
  intro p hp
  have h : env14702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14701_14702 : H12AffineEnvironment.transform 12 269 env14701 = env14702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14701 == env14702) = true)

theorem identity14702 : scanCanonicalize (H12AffineFastState.compose env14702 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14702 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14703 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,80,262,5440,2340,1024,81,4160,32,17,3,268,64,2049,5392,4097,2341,1364,33,256,32,5457,512]

theorem envBound14703 : H12AffineFastState.Bounded env14703 := by
  intro p hp
  have h : env14703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14702_14703 : H12AffineEnvironment.transform 6 9 env14702 = env14703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14702 == env14703) = true)

theorem identity14703 : scanCanonicalize (H12AffineFastState.compose env14703 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound14703 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env14704 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,88,5205,80,83,5141,2161,1024,81,4160,32,17,3,89,64,2049,5189,4097,2160,1025,33,85,32,5124,512]

theorem envBound14704 : H12AffineFastState.Bounded env14704 := by
  intro p hp
  have h : env14704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14703_14704 : H12AffineEnvironment.transform 7 85 env14703 = env14704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env14703 == env14704) = true)

theorem identity14704 : scanCanonicalize (H12AffineFastState.compose env14704 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14704 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14705 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8,5125,0,3,5141,2081,1024,1,4112,32,17,3,9,16,2049,5141,4097,2080,1025,33,5,32,5124,512]

theorem envBound14705 : H12AffineFastState.Bounded env14705 := by
  intro p hp
  have h : env14705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14704_14705 : H12AffineEnvironment.transform 5 16 env14704 = env14705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14704 == env14705) = true)

theorem identity14705 : scanCanonicalize (H12AffineFastState.compose env14705 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14705 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14706 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,4096,8,5125,0,3,5141,2048,1024,1,4112,1,17,3,9,16,2049,5141,4097,2049,1025,0,5,1,5124,512]

theorem envBound14706 : H12AffineFastState.Bounded env14706 := by
  intro p hp
  have h : env14706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14705_14706 : H12AffineEnvironment.transform 4 1 env14705 = env14706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14705 == env14706) = true)

theorem identity14706 : scanCanonicalize (H12AffineFastState.compose env14706 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound14706 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14707 : List Nat := [2,4,8,16,1,16,9,5,512,1024,523,4096,8,5125,0,3,5141,523,1024,1,4112,1,17,3,9,16,522,5141,4097,522,1025,0,5,1,5124,512]

theorem envBound14707 : H12AffineFastState.Bounded env14707 := by
  intro p hp
  have h : env14707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14706_14707 : H12AffineEnvironment.transform 10 523 env14706 = env14707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env14706 == env14707) = true)

def env14708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,4161,32,17,73857,8328,64,398572,5392,4097,406604,1500,33,256,33,5593,74250]

theorem envBound14708 : H12AffineFastState.Bounded env14708 := by
  intro p hp
  have h : env14708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14697_14708 : H12AffineEnvironment.transform 13 5377 env14697 = env14708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14697 == env14708) = true)

theorem identity14708 : scanCanonicalize (H12AffineFastState.compose env14708 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound14708 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,67618,1024,8541,4161,32,17,73857,8328,64,203982,5392,4097,212078,1500,33,256,33,5593,74250]

theorem envBound14709 : H12AffineFastState.Bounded env14709 := by
  intro p hp
  have h : env14709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14708_14709 : H12AffineEnvironment.transform 17 67618 env14708 = env14709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env14708 == env14709) = true)

theorem identity14709 : scanCanonicalize (H12AffineFastState.compose env14709 (packedSelected [0,5,8,9,10,16,18,19,20,22,23,24,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound14709 : packedSelected [0,5,8,9,10,16,18,19,20,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env14710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,5441,67618,1024,8541,4161,32,17,73857,8328,64,67983,5392,4097,76079,1500,33,256,33,5593,74250]

theorem envBound14710 : H12AffineFastState.Bounded env14710 := by
  intro p hp
  have h : env14710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14709_14710 : H12AffineEnvironment.transform 16 5441 env14709 = env14710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env14709 == env14710) = true)

theorem identity14710 : scanCanonicalize (H12AffineFastState.compose env14710 (packedSelected [1,2,5,6,8,9,11,14,18,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound14710 : packedSelected [1,2,5,6,8,9,11,14,18,22,24] rootPS < 2^1333 := by decide +kernel

def env14711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,0,65536,5441,67618,1024,1,4161,32,17,66013,468,64,67983,5392,4097,67699,1500,33,256,33,5593,66390]

theorem envBound14711 : H12AffineFastState.Bounded env14711 := by
  intro p hp
  have h : env14711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14710_14711 : H12AffineEnvironment.transform 12 348 env14710 = env14711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env14710 == env14711) = true)

theorem identity14711 : scanCanonicalize (H12AffineFastState.compose env14711 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound14711 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env14712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,0,263,5441,2341,1024,1,4161,32,17,218,468,64,2184,5392,4097,2420,1500,33,256,33,5593,593]

theorem envBound14712 : H12AffineFastState.Bounded env14712 := by
  intro p hp
  have h : env14712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14711_14712 : H12AffineEnvironment.transform 15 263 env14711 = env14712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env14711 == env14712) = true)

theorem identity14712 : scanCanonicalize (H12AffineFastState.compose env14712 (packedSelected [0,1,3,4,5,7,8,9,11,12,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 1417) := by decide +kernel

theorem selectedBound14712 : packedSelected [0,1,3,4,5,7,8,9,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env14713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1417,348,136,0,263,200,2341,1024,1,1480,32,17,218,468,64,2184,153,1416,2420,1500,33,256,33,80,593]

theorem envBound14713 : H12AffineFastState.Bounded env14713 := by
  intro p hp
  have h : env14713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14712_14713 : H12AffineEnvironment.transform 11 1417 env14712 = env14713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1417 env14712 == env14713) = true)

theorem identity14713 : scanCanonicalize (H12AffineFastState.compose env14713 (packedSelected [2,6,14] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound14713 : packedSelected [2,6,14] rootPS < 2^1333 := by decide +kernel

def env14714 : List Nat := [2,4,8,16,32,64,128,256,512,173,2048,292,348,136,0,263,200,2341,173,1,357,32,17,218,468,64,2184,153,293,2420,369,33,256,33,80,593]

theorem envBound14714 : H12AffineFastState.Bounded env14714 := by
  intro p hp
  have h : env14714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14713_14714 : H12AffineEnvironment.transform 9 173 env14713 = env14714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env14713 == env14714) = true)

theorem identity14714 : scanCanonicalize (H12AffineFastState.compose env14714 (packedSelected [0,2,3,5,6,7,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound14714 : packedSelected [0,2,3,5,6,7,12,15] rootPS < 2^1333 := by decide +kernel

def env14715 : List Nat := [2,4,8,16,32,64,128,256,512,173,428,292,348,136,0,263,200,137,173,1,357,32,17,218,468,64,292,153,293,216,369,33,256,33,80,593]

theorem envBound14715 : H12AffineFastState.Bounded env14715 := by
  intro p hp
  have h : env14715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14714_14715 : H12AffineEnvironment.transform 10 428 env14714 = env14715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env14714 == env14715) = true)

theorem identity14715 : scanCanonicalize (H12AffineFastState.compose env14715 (packedSelected [1,2,4,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14715 : packedSelected [1,2,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env14716 : List Nat := [2,4,8,16,32,17,128,256,512,173,428,292,269,136,0,263,153,137,173,1,308,32,17,139,389,17,292,153,293,137,288,33,256,33,1,512]

theorem envBound14716 : H12AffineFastState.Bounded env14716 := by
  intro p hp
  have h : env14716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14715_14716 : H12AffineEnvironment.transform 5 17 env14715 = env14716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14715 == env14716) = true)

theorem identity14716 : scanCanonicalize (H12AffineFastState.compose env14716 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 150) := by decide +kernel

theorem selectedBound14716 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14717 : List Nat := [2,4,8,16,32,17,128,150,512,173,58,178,155,136,0,145,153,137,173,1,162,32,17,139,19,17,178,153,179,137,182,33,150,33,1,512]

theorem envBound14717 : H12AffineFastState.Bounded env14717 := by
  intro p hp
  have h : env14717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14716_14717 : H12AffineEnvironment.transform 7 150 env14716 = env14717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 150 env14716 == env14717) = true)

theorem identity14717 : scanCanonicalize (H12AffineFastState.compose env14717 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14717 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14718 : List Nat := [2,4,8,16,0,17,128,150,512,141,26,146,155,136,0,145,153,137,141,1,130,0,17,139,19,17,146,153,147,137,150,1,150,1,1,512]

theorem envBound14718 : H12AffineFastState.Bounded env14718 := by
  intro p hp
  have h : env14718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14717_14718 : H12AffineEnvironment.transform 4 0 env14717 = env14718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14717 == env14718) = true)

theorem identity14718 : scanCanonicalize (H12AffineFastState.compose env14718 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound14718 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14719 : List Nat := [2,4,8,16,0,17,2,20,512,15,26,16,25,10,0,19,27,11,15,1,0,0,17,9,19,17,16,27,17,11,20,1,20,1,1,512]

theorem envBound14719 : H12AffineFastState.Bounded env14719 := by
  intro p hp
  have h : env14719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14718_14719 : H12AffineEnvironment.transform 6 2 env14718 = env14719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env14718 == env14719) = true)

theorem identity14719 : scanCanonicalize (H12AffineFastState.compose env14719 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound14719 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14720 : List Nat := [2,2,8,16,0,17,2,18,512,9,26,16,25,10,0,19,27,11,9,1,0,0,17,9,19,17,16,27,17,11,18,1,18,1,1,512]

theorem envBound14720 : H12AffineFastState.Bounded env14720 := by
  intro p hp
  have h : env14720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14719_14720 : H12AffineEnvironment.transform 1 2 env14719 = env14720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env14719 == env14720) = true)

theorem identity14720 : scanCanonicalize (H12AffineFastState.compose env14720 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound14720 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14721 : List Nat := [2,2,8,11,0,10,2,9,512,9,1,11,2,10,0,8,0,11,9,1,0,0,10,9,8,10,11,0,10,11,9,1,9,1,1,512]

theorem envBound14721 : H12AffineFastState.Bounded env14721 := by
  intro p hp
  have h : env14721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14720_14721 : H12AffineEnvironment.transform 3 11 env14720 = env14721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env14720 == env14721) = true)

theorem identity14721 : scanCanonicalize (H12AffineFastState.compose env14721 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound14721 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14722 : List Nat := [2,2,8,11,0,10,2,9,9,9,1,11,2,10,0,8,0,11,9,1,0,0,10,9,8,10,11,0,10,11,9,1,9,1,1,9]

theorem envBound14722 : H12AffineFastState.Bounded env14722 := by
  intro p hp
  have h : env14722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14721_14722 : H12AffineEnvironment.transform 8 9 env14721 = env14722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env14721 == env14722) = true)

theorem identity14722 : scanCanonicalize (H12AffineFastState.compose env14722 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound14722 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14723 : List Nat := [2,2,2,1,0,0,2,3,3,3,1,1,2,0,0,2,0,1,3,1,0,0,0,3,2,0,1,0,0,1,3,1,3,1,1,3]

theorem envBound14723 : H12AffineFastState.Bounded env14723 := by
  intro p hp
  have h : env14723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14722_14723 : H12AffineEnvironment.transform 2 2 env14722 = env14723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env14722 == env14723) = true)

theorem identity14723 : scanCanonicalize (H12AffineFastState.compose env14723 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound14723 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14724 : List Nat := [0,0,0,1,0,0,0,1,1,1,1,1,0,0,0,0,0,1,1,1,0,0,0,1,0,0,1,0,0,1,1,1,1,1,1,1]

theorem envBound14724 : H12AffineFastState.Bounded env14724 := by
  intro p hp
  have h : env14724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14723_14724 : H12AffineEnvironment.transform 0 0 env14723 = env14724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env14723 == env14724) = true)

def env14725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17729,4194304,16,73857,8328,64,4592845,5393,4097,406605,20700,4194304,256,21792,16600,96010]

theorem envBound14725 : H12AffineFastState.Bounded env14725 := by
  intro p hp
  have h : env14725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14695_14725 : H12AffineEnvironment.transform 20 17729 env14695 = env14725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env14695 == env14725) = true)

def env14726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4161,4194304,16,73857,8328,64,4592845,5393,4097,406605,1500,4194304,256,32,5592,74250]

theorem envBound14726 : H12AffineFastState.Bounded env14726 := by
  intro p hp
  have h : env14726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14725_14726 : H12AffineEnvironment.transform 13 5376 env14725 = env14726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env14725 == env14726) = true)

theorem identity14726 : scanCanonicalize (H12AffineFastState.compose env14726 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14726 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4161,4194304,16,138,8328,64,4592845,5393,4097,406605,1500,4194304,256,32,5592,513]

theorem envBound14727 : H12AffineFastState.Bounded env14727 := by
  intro p hp
  have h : env14727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14726_14727 : H12AffineEnvironment.transform 15 8203 env14726 = env14727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14726 == env14727) = true)

theorem identity14727 : scanCanonicalize (H12AffineFastState.compose env14727 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146912) := by decide +kernel

theorem selectedBound14727 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,131072,146912,1024,8540,4161,4194304,16,138,8328,64,4204845,5393,4097,2477,1500,4194304,256,32,5592,513]

theorem envBound14728 : H12AffineFastState.Bounded env14728 := by
  intro p hp
  have h : env14728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14727_14728 : H12AffineEnvironment.transform 17 146912 env14727 = env14728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146912 env14727 == env14728) = true)

theorem identity14728 : scanCanonicalize (H12AffineFastState.compose env14728 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 136496) := by decide +kernel

theorem selectedBound14728 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env14729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,131072,146912,1024,8540,4161,136496,16,138,8328,64,146461,5393,4097,2477,1500,136496,256,32,5592,513]

theorem envBound14729 : H12AffineFastState.Bounded env14729 := by
  intro p hp
  have h : env14729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14728_14729 : H12AffineEnvironment.transform 21 136496 env14728 = env14729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136496 env14728 == env14729) = true)

theorem identity14729 : scanCanonicalize (H12AffineFastState.compose env14729 (packedSelected [0,1,4,7,10,18,19,22,23,28] rootPS)) = affineNative (2^(16+1) ^^^ 13460) := by decide +kernel

theorem selectedBound14729 : packedSelected [0,1,4,7,10,18,19,22,23,28] rootPS < 2^1333 := by decide +kernel

def env14730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,13460,2420,1024,8540,4161,8612,16,138,8328,64,2185,5393,4097,2477,1500,8612,256,32,5592,513]

theorem envBound14730 : H12AffineFastState.Bounded env14730 := by
  intro p hp
  have h : env14730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14729_14730 : H12AffineEnvironment.transform 16 13460 env14729 = env14730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13460 env14729 == env14730) = true)

theorem identity14730 : scanCanonicalize (H12AffineFastState.compose env14730 (packedSelected [0,1,3,5,7,8,9,10,14,18,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound14730 : packedSelected [0,1,3,5,7,8,9,10,14,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env14731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,217,399,5392,2420,1024,216,4161,32,16,138,268,64,2185,5393,4097,2477,1500,32,256,32,5592,513]

theorem envBound14731 : H12AffineFastState.Bounded env14731 := by
  intro p hp
  have h : env14731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14730_14731 : H12AffineEnvironment.transform 12 388 env14730 = env14731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env14730 == env14731) = true)

theorem identity14731 : scanCanonicalize (H12AffineFastState.compose env14731 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound14731 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env14732 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,40,5292,217,35,5308,2264,1024,216,4161,32,16,138,160,64,2185,5309,4097,2049,1136,32,172,32,5236,513]

theorem envBound14732 : H12AffineFastState.Bounded env14732 := by
  intro p hp
  have h : env14732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14731_14732 : H12AffineEnvironment.transform 7 172 env14731 = env14732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env14731 == env14732) = true)

theorem identity14732 : scanCanonicalize (H12AffineFastState.compose env14732 (packedSelected [5,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound14732 : packedSelected [5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env14733 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,3108,40,2184,217,35,2200,2264,1024,216,3173,32,16,138,160,64,2185,2201,3109,2049,1136,32,172,32,2128,513]

theorem envBound14733 : H12AffineFastState.Bounded env14733 := by
  intro p hp
  have h : env14733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14732_14733 : H12AffineEnvironment.transform 11 3108 env14732 = env14733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env14732 == env14733) = true)

theorem identity14733 : scanCanonicalize (H12AffineFastState.compose env14733 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1260) := by decide +kernel

theorem selectedBound14733 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env14734 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1260,200,40,1124,217,35,1140,1076,1024,216,137,32,16,138,160,64,1125,1141,201,1261,1136,32,172,32,1212,513]

theorem envBound14734 : H12AffineFastState.Bounded env14734 := by
  intro p hp
  have h : env14734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14733_14734 : H12AffineEnvironment.transform 10 1260 env14733 = env14734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1260 env14733 == env14734) = true)

def env14735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,4160,4194304,16,73857,8328,64,4592845,5393,4097,406605,1501,4194304,256,33,5593,74251]

theorem envBound14735 : H12AffineFastState.Bounded env14735 := by
  intro p hp
  have h : env14735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14725_14735 : H12AffineEnvironment.transform 13 5377 env14725 = env14735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14725 == env14735) = true)

theorem identity14735 : scanCanonicalize (H12AffineFastState.compose env14735 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound14735 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8322,131072,262144,1024,8541,4160,4194304,16,3,8328,64,4592845,5393,4097,406605,1501,4194304,256,33,5593,649]

theorem envBound14736 : H12AffineFastState.Bounded env14736 := by
  intro p hp
  have h : env14736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14735_14736 : H12AffineEnvironment.transform 15 8322 env14735 = env14736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env14735 == env14736) = true)

theorem identity14736 : scanCanonicalize (H12AffineFastState.compose env14736 (packedSelected [0,3,9,10,12,14,15,22,24,26,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound14736 : packedSelected [0,3,9,10,12,14,15,22,24,26,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env14737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8322,131072,10281,1024,8541,4160,4194304,16,3,8328,64,4340964,5393,4097,138340,1501,4194304,256,33,5593,649]

theorem envBound14737 : H12AffineFastState.Bounded env14737 := by
  intro p hp
  have h : env14737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14736_14737 : H12AffineEnvironment.transform 17 10281 env14736 = env14737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14736 == env14737) = true)

theorem identity14737 : scanCanonicalize (H12AffineFastState.compose env14737 (packedSelected [11,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound14737 : packedSelected [11,16,18,20] rootPS < 2^1333 := by decide +kernel

def env14738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,137,343,131072,2556,1024,136,4160,4194304,16,3,349,64,4332849,5393,4097,138340,1501,4194304,256,33,5593,649]

theorem envBound14738 : H12AffineFastState.Bounded env14738 := by
  intro p hp
  have h : env14738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14737_14738 : H12AffineEnvironment.transform 12 469 env14737 = env14738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env14737 == env14738) = true)

theorem identity14738 : scanCanonicalize (H12AffineFastState.compose env14738 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound14738 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,137,343,5392,2556,1024,136,4160,4194304,16,3,349,64,4196385,5393,4097,2420,1501,4194304,256,33,5593,649]

theorem envBound14739 : H12AffineFastState.Bounded env14739 := by
  intro p hp
  have h : env14739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14738_14739 : H12AffineEnvironment.transform 16 5392 env14738 = env14739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env14738 == env14739) = true)

theorem identity14739 : scanCanonicalize (H12AffineFastState.compose env14739 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound14739 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env14740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,137,343,5392,2556,1024,136,4160,32,16,3,349,64,2049,5393,4097,2420,1501,32,256,33,5593,649]

theorem envBound14740 : H12AffineFastState.Bounded env14740 := by
  intro p hp
  have h : env14740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14739_14740 : H12AffineEnvironment.transform 21 32 env14739 = env14740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env14739 == env14740) = true)

theorem identity14740 : scanCanonicalize (H12AffineFastState.compose env14740 (packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14740 : packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env14741 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5377,137,262,5392,2477,1024,136,4113,32,16,3,268,17,2049,5393,4097,2341,1420,32,256,33,5512,649]

theorem envBound14741 : H12AffineFastState.Bounded env14741 := by
  intro p hp
  have h : env14741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14740_14741 : H12AffineEnvironment.transform 5 17 env14740 = env14741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14740 == env14741) = true)

theorem identity14741 : scanCanonicalize (H12AffineFastState.compose env14741 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14741 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env14742 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,262,5392,2340,1024,1,4113,32,16,3,268,17,2049,5393,4097,2341,1285,32,256,33,5377,512]

theorem envBound14742 : H12AffineFastState.Bounded env14742 := by
  intro p hp
  have h : env14742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14741_14742 : H12AffineEnvironment.transform 6 9 env14741 = env14742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14741 == env14742) = true)

theorem identity14742 : scanCanonicalize (H12AffineFastState.compose env14742 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14742 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14743 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,269,5377,0,262,5392,2309,1024,1,4113,1,16,3,268,17,2049,5393,4097,2308,1285,1,256,0,5377,512]

theorem envBound14743 : H12AffineFastState.Bounded env14743 := by
  intro p hp
  have h : env14743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14742_14743 : H12AffineEnvironment.transform 4 1 env14742 = env14743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14742 == env14743) = true)

theorem identity14743 : scanCanonicalize (H12AffineFastState.compose env14743 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14743 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14744 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5124,0,3,5141,2048,1024,1,4113,1,16,3,9,17,2049,5140,4097,2049,1024,1,5,0,5124,512]

theorem envBound14744 : H12AffineFastState.Bounded env14744 := by
  intro p hp
  have h : env14744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14743_14744 : H12AffineEnvironment.transform 7 5 env14743 = env14744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14743 == env14744) = true)

def env14745 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,8,1044,0,3,1029,2048,1024,1,1,1,16,3,9,17,2049,1028,17,2049,1024,1,5,0,1044,512]

theorem envBound14745 : H12AffineFastState.Bounded env14745 := by
  intro p hp
  have h : env14745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14744_14745 : H12AffineEnvironment.transform 11 16 env14744 = env14745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env14744 == env14745) = true)

def env14746 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,8,0,0,3,17,2048,20,1,1,1,16,3,9,17,2049,16,17,2049,20,1,5,0,0,512]

theorem envBound14746 : H12AffineFastState.Bounded env14746 := by
  intro p hp
  have h : env14746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14745_14746 : H12AffineEnvironment.transform 9 20 env14745 = env14746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env14745 == env14746) = true)

theorem identity14746 : scanCanonicalize (H12AffineFastState.compose env14746 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound14746 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14747 : List Nat := [2,4,8,16,1,17,9,5,30,20,2048,16,8,0,0,3,17,2048,20,1,1,1,16,3,9,17,2049,16,17,2049,20,1,5,0,0,30]

theorem envBound14747 : H12AffineFastState.Bounded env14747 := by
  intro p hp
  have h : env14747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14746_14747 : H12AffineEnvironment.transform 8 30 env14746 = env14747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env14746 == env14747) = true)

def leafEnv14747 : List Nat := [2,4,8,16,1,17,9,5,30,20,2048,16,8,0,0,3,17,2048,20,1,1,1,16,3,20,9,1,17,2049,16,17,2049,20,1,5,0,4,2,0,30,1,1,0]

def active14747 : List Nat := [0,1,2,3,10]

def tree14747 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14747 : H12WitnessSearch.Good tree14747 := H12GlobalWitnessIndex.good

theorem leafIdentity14747 : H12AffineFastState.composeSystem env14747 rootObs = leafEnv14747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14747 rootObs == leafEnv14747) = true)

theorem terminalChecked14747 : H12PackedTerminal.terminalCheckFast leafEnv14747 active14747 tree14747 = true := by decide +kernel

def env14748 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,8,1,0,3,16,2048,21,1,1,1,16,3,9,17,2049,17,17,2049,21,1,5,0,1,512]

theorem envBound14748 : H12AffineFastState.Bounded env14748 := by
  intro p hp
  have h : env14748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14745_14748 : H12AffineEnvironment.transform 9 21 env14745 = env14748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env14745 == env14748) = true)

theorem identity14748 : scanCanonicalize (H12AffineFastState.compose env14748 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound14748 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14749 : List Nat := [2,4,8,4,1,5,9,5,512,1,2048,4,8,1,0,3,4,2048,1,1,1,1,4,3,9,5,2049,5,5,2049,1,1,5,0,1,512]

theorem envBound14749 : H12AffineFastState.Bounded env14749 := by
  intro p hp
  have h : env14749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14748_14749 : H12AffineEnvironment.transform 3 4 env14748 = env14749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env14748 == env14749) = true)

def leafEnv14749 : List Nat := [2,4,8,4,1,5,9,5,512,1,2048,4,8,1,0,3,4,2048,1,1,1,1,4,3,1,9,1,5,2049,5,5,2049,1,1,5,0,4,2,1,512,1,1,0]

def active14749 : List Nat := [0,1,2,8,10]

def tree14749 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14749 : H12WitnessSearch.Good tree14749 := H12GlobalWitnessIndex.good

theorem leafIdentity14749 : H12AffineFastState.composeSystem env14749 rootObs = leafEnv14749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14749 rootObs == leafEnv14749) = true)

theorem terminalChecked14749 : H12PackedTerminal.terminalCheckFast leafEnv14749 active14749 tree14749 = true := by decide +kernel

def env14750 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,8,1045,0,3,1028,2048,1024,1,0,1,16,3,9,17,2049,1029,16,2049,1024,1,5,0,1045,512]

theorem envBound14750 : H12AffineFastState.Bounded env14750 := by
  intro p hp
  have h : env14750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14744_14750 : H12AffineEnvironment.transform 11 17 env14744 = env14750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env14744 == env14750) = true)

theorem identity14750 : scanCanonicalize (H12AffineFastState.compose env14750 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound14750 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14751 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,8,1,0,3,16,2048,20,1,0,1,16,3,9,17,2049,17,16,2049,20,1,5,0,1,512]

theorem envBound14751 : H12AffineFastState.Bounded env14751 := by
  intro p hp
  have h : env14751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14750_14751 : H12AffineEnvironment.transform 9 20 env14750 = env14751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env14750 == env14751) = true)

theorem identity14751 : scanCanonicalize (H12AffineFastState.compose env14751 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound14751 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14752 : List Nat := [2,4,8,16,1,17,9,5,31,20,2048,17,8,1,0,3,16,2048,20,1,0,1,16,3,9,17,2049,17,16,2049,20,1,5,0,1,31]

theorem envBound14752 : H12AffineFastState.Bounded env14752 := by
  intro p hp
  have h : env14752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14751_14752 : H12AffineEnvironment.transform 8 31 env14751 = env14752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env14751 == env14752) = true)

def leafEnv14752 : List Nat := [2,4,8,16,1,17,9,5,31,20,2048,17,8,1,0,3,16,2048,20,1,0,1,16,3,20,9,1,17,2049,17,16,2049,20,1,5,0,4,2,1,31,1,0,0]

def active14752 : List Nat := [0,1,2,3,10]

def tree14752 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14752 : H12WitnessSearch.Good tree14752 := H12GlobalWitnessIndex.good

theorem leafIdentity14752 : H12AffineFastState.composeSystem env14752 rootObs = leafEnv14752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14752 rootObs == leafEnv14752) = true)

theorem terminalChecked14752 : H12PackedTerminal.terminalCheckFast leafEnv14752 active14752 tree14752 = true := by decide +kernel

def env14753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound14753 : H12AffineFastState.Bounded env14753 := by
  intro p hp
  have h : env14753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14591_14753 : H12AffineEnvironment.transform 18 1025 env14591 = env14753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env14591 == env14753) = true)

theorem identity14753 : scanCanonicalize (H12AffineFastState.compose env14753 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 165201) := by decide +kernel

theorem selectedBound14753 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,4194304,8388608,16777216,8328,64,29868032,16974300,8572929,8830977,25265168,21225617,257,25379325,25403481,25207751]

theorem envBound14754 : H12AffineFastState.Bounded env14754 := by
  intro p hp
  have h : env14754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14753_14754 : H12AffineEnvironment.transform 20 165201 env14753 = env14754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165201 env14753 == env14754) = true)

def env14755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,4194304,8388608,8590556,8328,64,4510940,8393984,8572929,8830977,168140,12645453,257,21793,46213,243483]

theorem envBound14755 : H12AffineFastState.Bounded env14755 := by
  intro p hp
  have h : env14755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14754_14755 : H12AffineEnvironment.transform 23 8590556 env14754 = env14755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590556 env14754 == env14755) = true)

def env14756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,4194304,169216,98780,8328,64,4510940,163840,17665,283905,168140,4350285,257,21793,46213,243483]

theorem envBound14756 : H12AffineFastState.Bounded env14756 := by
  intro p hp
  have h : env14756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14755_14756 : H12AffineEnvironment.transform 22 169216 env14755 = env14756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env14755 == env14756) = true)

def env14757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272512,169216,98780,8328,64,64604,163840,17665,283905,168140,412109,257,21793,46213,243483]

theorem envBound14757 : H12AffineFastState.Bounded env14757 := by
  intro p hp
  have h : env14757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14756_14757 : H12AffineEnvironment.transform 21 272512 env14756 = env14757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env14756 == env14757) = true)

theorem identity14757 : scanCanonicalize (H12AffineFastState.compose env14757 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14757 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,165201,272512,169216,41431,8328,64,64604,163840,17665,283905,168140,412109,257,21793,46213,169744]

theorem envBound14758 : H12AffineFastState.Bounded env14758 := by
  intro p hp
  have h : env14758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14757_14758 : H12AffineEnvironment.transform 15 8203 env14757 = env14758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14757 == env14758) = true)

def env14759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,165201,272392,169216,41311,8192,64,64604,163840,17665,283905,168004,411973,257,21793,46093,169744]

theorem envBound14759 : H12AffineFastState.Bounded env14759 := by
  intro p hp
  have h : env14759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14758_14759 : H12AffineEnvironment.transform 6 8 env14758 = env14759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14758 == env14759) = true)

theorem identity14759 : scanCanonicalize (H12AffineFastState.compose env14759 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound14759 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env14760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,138340,1025,32769,165201,144492,169216,41311,8192,64,64604,163840,17665,149861,168004,21793,257,21793,46093,169744]

theorem envBound14760 : H12AffineFastState.Bounded env14760 := by
  intro p hp
  have h : env14760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14759_14760 : H12AffineEnvironment.transform 17 138340 env14759 = env14760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env14759 == env14760) = true)

theorem identity14760 : scanCanonicalize (H12AffineFastState.compose env14760 (packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound14760 : packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env14761 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,5220,2048,1025,32769,37173,8200,33124,41311,8192,64,64604,37988,17665,23809,33824,21793,257,21793,46093,33652]

theorem envBound14761 : H12AffineFastState.Bounded env14761 := by
  intro p hp
  have h : env14761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14760_14761 : H12AffineEnvironment.transform 16 5220 env14760 = env14761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env14760 == env14761) = true)

theorem identity14761 : scanCanonicalize (H12AffineFastState.compose env14761 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound14761 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env14762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8203,5220,2048,1025,32769,37173,8200,33124,41311,8192,64,34816,37988,12637,10589,33824,8573,257,8573,46093,33652]

theorem envBound14762 : H12AffineFastState.Bounded env14762 := by
  intro p hp
  have h : env14762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14761_14762 : H12AffineEnvironment.transform 13 13404 env14761 = env14762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env14761 == env14762) = true)

theorem identity14762 : scanCanonicalize (H12AffineFastState.compose env14762 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound14762 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env14763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,372,8203,5220,2048,1025,373,4161,8200,16,8235,8192,64,2420,5392,12637,10589,1364,8573,257,8573,13689,512]

theorem envBound14763 : H12AffineFastState.Bounded env14763 := by
  intro p hp
  have h : env14763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14762_14763 : H12AffineEnvironment.transform 14 372 env14762 = env14763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env14762 == env14763) = true)

theorem identity14763 : scanCanonicalize (H12AffineFastState.compose env14763 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound14763 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,301,5489,372,294,5220,2048,1025,373,4161,293,16,262,301,64,2420,5392,4208,2160,1364,80,257,80,5204,512]

theorem envBound14764 : H12AffineFastState.Bounded env14764 := by
  intro p hp
  have h : env14764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14763_14764 : H12AffineEnvironment.transform 12 301 env14763 = env14764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env14763 == env14764) = true)

theorem identity14764 : scanCanonicalize (H12AffineFastState.compose env14764 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14764 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14765 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,268,5456,341,263,5189,2048,1025,340,4161,260,16,262,268,64,2389,5392,4177,2129,1364,80,257,80,5204,512]

theorem envBound14765 : H12AffineFastState.Bounded env14765 := by
  intro p hp
  have h : env14765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14764_14765 : H12AffineEnvironment.transform 4 1 env14764 = env14765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14764 == env14765) = true)

theorem identity14765 : scanCanonicalize (H12AffineFastState.compose env14765 (packedSelected [0,2,3,4,5,7,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound14765 : packedSelected [0,2,3,4,5,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env14766 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,1361,268,1,341,263,276,2048,1025,340,1296,260,16,262,268,64,2389,65,1280,2129,1364,80,257,80,261,512]

theorem envBound14766 : H12AffineFastState.Bounded env14766 := by
  intro p hp
  have h : env14766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14765_14766 : H12AffineEnvironment.transform 11 1361 env14765 = env14766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env14765 == env14766) = true)

theorem identity14766 : scanCanonicalize (H12AffineFastState.compose env14766 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound14766 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env14767 : List Nat := [2,4,8,16,1,64,8,256,512,1024,1044,1361,268,1,341,263,276,1044,1025,340,1296,260,16,262,268,64,1345,65,1280,1093,1364,80,257,80,261,512]

theorem envBound14767 : H12AffineFastState.Bounded env14767 := by
  intro p hp
  have h : env14767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14766_14767 : H12AffineEnvironment.transform 10 1044 env14766 = env14767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env14766 == env14767) = true)

theorem identity14767 : scanCanonicalize (H12AffineFastState.compose env14767 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14767 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env14768 : List Nat := [2,4,8,16,1,16,8,256,512,1024,1044,1281,268,1,261,263,276,1044,1025,260,1296,260,16,262,268,16,1297,17,1280,1045,1284,0,257,0,261,512]

theorem envBound14768 : H12AffineFastState.Bounded env14768 := by
  intro p hp
  have h : env14768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14767_14768 : H12AffineEnvironment.transform 5 16 env14767 = env14768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14767 == env14768) = true)

theorem identity14768 : scanCanonicalize (H12AffineFastState.compose env14768 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound14768 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env14769 : List Nat := [2,4,8,16,1,16,8,256,512,273,261,16,268,1,261,263,276,261,272,260,1,260,16,262,268,16,0,17,17,260,21,0,257,0,261,512]

theorem envBound14769 : H12AffineFastState.Bounded env14769 := by
  intro p hp
  have h : env14769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14768_14769 : H12AffineEnvironment.transform 9 273 env14768 = env14769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14768 == env14769) = true)

theorem identity14769 : scanCanonicalize (H12AffineFastState.compose env14769 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14769 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14770 : List Nat := [2,4,8,16,1,16,8,4,512,21,1,16,8,1,1,3,16,1,20,0,1,0,16,2,8,16,0,17,17,0,21,0,5,0,1,512]

theorem envBound14770 : H12AffineFastState.Bounded env14770 := by
  intro p hp
  have h : env14770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14769_14770 : H12AffineEnvironment.transform 7 4 env14769 = env14770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14769 == env14770) = true)

theorem identity14770 : scanCanonicalize (H12AffineFastState.compose env14770 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound14770 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14771 : List Nat := [2,4,8,16,1,16,8,4,17,21,1,16,8,1,1,3,16,1,20,0,1,0,16,2,8,16,0,17,17,0,21,0,5,0,1,17]

theorem envBound14771 : H12AffineFastState.Bounded env14771 := by
  intro p hp
  have h : env14771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14770_14771 : H12AffineEnvironment.transform 8 17 env14770 = env14771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env14770 == env14771) = true)

theorem identity14771 : scanCanonicalize (H12AffineFastState.compose env14771 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound14771 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14772 : List Nat := [2,4,8,15,1,15,8,4,14,10,1,15,8,1,1,3,15,1,11,0,1,0,15,2,8,15,0,14,14,0,10,0,5,0,1,14]

theorem envBound14772 : H12AffineFastState.Bounded env14772 := by
  intro p hp
  have h : env14772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14771_14772 : H12AffineEnvironment.transform 3 15 env14771 = env14772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env14771 == env14772) = true)

theorem identity14772 : scanCanonicalize (H12AffineFastState.compose env14772 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound14772 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14773 : List Nat := [2,4,6,1,1,1,6,4,0,4,1,1,6,1,1,3,1,1,5,0,1,0,1,2,6,1,0,0,0,0,4,0,5,0,1,0]

theorem envBound14773 : H12AffineFastState.Bounded env14773 := by
  intro p hp
  have h : env14773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14772_14773 : H12AffineEnvironment.transform 2 6 env14772 = env14773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env14772 == env14773) = true)

def env14774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,165201,272393,169216,41310,8193,64,64604,163840,17665,283905,168005,411972,257,21793,46092,169744]

theorem envBound14774 : H12AffineFastState.Bounded env14774 := by
  intro p hp
  have h : env14774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14758_14774 : H12AffineEnvironment.transform 6 9 env14758 = env14774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14758 == env14774) = true)

theorem identity14774 : scanCanonicalize (H12AffineFastState.compose env14774 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound14774 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env14775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1025,32769,165201,169264,169216,41310,8193,64,64604,163840,17665,190520,168005,62589,257,21793,46092,169744]

theorem envBound14775 : H12AffineFastState.Bounded env14775 := by
  intro p hp
  have h : env14775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14774_14775 : H12AffineEnvironment.transform 17 179513 env14774 = env14775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env14774 == env14775) = true)

def env14776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272513,169216,98780,8328,64,64605,163840,17665,283905,168140,412108,257,21793,46213,243483]

theorem envBound14776 : H12AffineFastState.Bounded env14776 := by
  intro p hp
  have h : env14776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14756_14776 : H12AffineEnvironment.transform 21 272513 env14756 = env14776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env14756 == env14776) = true)

theorem identity14776 : scanCanonicalize (H12AffineFastState.compose env14776 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound14776 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,262144,1025,32769,77899,272513,73754,98780,8328,64,64605,79130,17665,283905,75222,392406,257,21793,46213,513]

theorem envBound14777 : H12AffineFastState.Bounded env14777 := by
  intro p hp
  have h : env14777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14776_14777 : H12AffineEnvironment.transform 16 111898 env14776 = env14777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env14776 == env14777) = true)

def env14778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,90138,262144,1025,21761,77899,272513,73754,87260,8328,64,10589,79130,17665,283905,75222,338390,257,21793,24965,513]

theorem envBound14778 : H12AffineFastState.Bounded env14778 := by
  intro p hp
  have h : env14778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14777_14778 : H12AffineEnvironment.transform 14 21760 env14777 = env14778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env14777 == env14778) = true)

theorem identity14778 : scanCanonicalize (H12AffineFastState.compose env14778 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14778 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,16401,262144,1025,21761,4160,272513,17,29911,8328,64,10589,5393,17665,283905,1501,264669,257,21793,24965,513]

theorem envBound14779 : H12AffineFastState.Bounded env14779 := by
  intro p hp
  have h : env14779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14778_14779 : H12AffineEnvironment.transform 15 8203 env14778 = env14779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14778 == env14779) = true)

theorem identity14779 : scanCanonicalize (H12AffineFastState.compose env14779 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound14779 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env14780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,16401,2557,1025,21761,4160,8572,17,29911,8328,64,10589,5393,17665,23804,1501,32,257,21793,24965,513]

theorem envBound14780 : H12AffineFastState.Bounded env14780 := by
  intro p hp
  have h : env14780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14779_14780 : H12AffineEnvironment.transform 17 2557 env14779 = env14780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env14779 == env14780) = true)

theorem identity14780 : scanCanonicalize (H12AffineFastState.compose env14780 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound14780 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,137,8203,5528,2557,1025,136,4160,8572,17,8542,8328,64,10589,5393,4232,2421,1501,32,257,168,13324,513]

theorem envBound14781 : H12AffineFastState.Bounded env14781 := by
  intro p hp
  have h : env14781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14780_14781 : H12AffineEnvironment.transform 13 5513 env14780 = env14781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env14780 == env14781) = true)

theorem identity14781 : scanCanonicalize (H12AffineFastState.compose env14781 (packedSelected [2,3,5,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound14781 : packedSelected [2,3,5,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env14782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,5513,137,430,5528,2557,1025,136,4160,217,17,251,301,64,2296,5393,4232,2421,1501,32,257,168,5545,513]

theorem envBound14782 : H12AffineFastState.Bounded env14782 := by
  intro p hp
  have h : env14782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14781_14782 : H12AffineEnvironment.transform 12 421 env14781 = env14782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env14781 == env14782) = true)

theorem identity14782 : scanCanonicalize (H12AffineFastState.compose env14782 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound14782 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env14783 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,4096,348,5488,112,343,5473,2308,1025,113,4160,32,17,2,301,64,2049,5393,4209,2421,1316,32,257,81,5456,513]

theorem envBound14783 : H12AffineFastState.Bounded env14783 := by
  intro p hp
  have h : env14783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14782_14783 : H12AffineEnvironment.transform 6 121 env14782 = env14783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env14782 == env14783) = true)

theorem identity14783 : scanCanonicalize (H12AffineFastState.compose env14783 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14783 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14784 : List Nat := [2,4,8,16,32,64,121,36,512,1024,2048,4096,120,5204,112,115,5189,2080,1025,113,4160,32,17,2,9,64,2049,5173,4209,2129,1024,32,37,81,5236,513]

theorem envBound14784 : H12AffineFastState.Bounded env14784 := by
  intro p hp
  have h : env14784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14783_14784 : H12AffineEnvironment.transform 7 36 env14783 = env14784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14783 == env14784) = true)

theorem identity14784 : scanCanonicalize (H12AffineFastState.compose env14784 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound14784 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env14785 : List Nat := [2,4,8,16,32,59,2,36,512,1024,2048,4096,3,5167,11,8,5182,2080,1025,10,4155,32,17,2,9,59,2049,5173,4106,2090,1024,32,37,42,5135,513]

theorem envBound14785 : H12AffineFastState.Bounded env14785 := by
  intro p hp
  have h : env14785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14784_14785 : H12AffineEnvironment.transform 5 59 env14784 = env14785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env14784 == env14785) = true)

theorem identity14785 : scanCanonicalize (H12AffineFastState.compose env14785 (packedSelected [0,1,2,5,7,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound14785 : packedSelected [0,1,2,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env14786 : List Nat := [2,4,8,16,32,59,2,36,512,1024,2048,3108,3,2059,11,8,2074,2080,1025,10,3103,32,17,2,9,59,2049,2065,3118,2090,1024,32,37,42,2091,513]

theorem envBound14786 : H12AffineFastState.Bounded env14786 := by
  intro p hp
  have h : env14786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14785_14786 : H12AffineEnvironment.transform 11 3108 env14785 = env14786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env14785 == env14786) = true)

theorem identity14786 : scanCanonicalize (H12AffineFastState.compose env14786 (packedSelected [4,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound14786 : packedSelected [4,7,10] rootPS < 2^1333 := by decide +kernel

def env14787 : List Nat := [2,4,8,16,32,59,2,36,512,1024,1566,570,3,1557,11,8,1540,1598,1025,10,513,32,17,2,9,59,1567,1551,560,1588,1024,32,37,42,1589,513]

theorem envBound14787 : H12AffineFastState.Bounded env14787 := by
  intro p hp
  have h : env14787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14786_14787 : H12AffineEnvironment.transform 10 1566 env14786 = env14787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env14786 == env14787) = true)

theorem identity14787 : scanCanonicalize (H12AffineFastState.compose env14787 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound14787 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env14788 : List Nat := [2,4,8,16,32,59,2,36,512,533,11,570,3,0,11,8,17,43,532,10,513,32,17,2,9,59,10,26,560,33,533,32,37,42,32,513]

theorem envBound14788 : H12AffineFastState.Bounded env14788 := by
  intro p hp
  have h : env14788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14787_14788 : H12AffineEnvironment.transform 9 533 env14787 = env14788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env14787 == env14788) = true)

theorem identity14788 : scanCanonicalize (H12AffineFastState.compose env14788 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound14788 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env14789 : List Nat := [2,4,8,11,32,32,2,36,512,526,11,545,3,0,11,8,10,43,527,10,513,32,10,2,9,32,10,1,555,33,526,32,37,42,32,513]

theorem envBound14789 : H12AffineFastState.Bounded env14789 := by
  intro p hp
  have h : env14789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14788_14789 : H12AffineEnvironment.transform 3 11 env14788 = env14789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env14788 == env14789) = true)

theorem identity14789 : scanCanonicalize (H12AffineFastState.compose env14789 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound14789 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env14790 : List Nat := [2,4,8,11,32,32,2,36,7,9,11,38,3,0,11,8,10,43,8,10,6,32,10,2,9,32,10,1,44,33,9,32,37,42,32,6]

theorem envBound14790 : H12AffineFastState.Bounded env14790 := by
  intro p hp
  have h : env14790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14789_14790 : H12AffineEnvironment.transform 8 7 env14789 = env14790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env14789 == env14790) = true)

theorem identity14790 : scanCanonicalize (H12AffineFastState.compose env14790 (packedSelected [0,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound14790 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env14791 : List Nat := [2,4,8,11,14,14,2,10,7,9,11,8,3,0,11,8,10,5,8,10,6,14,10,2,9,14,10,1,2,15,9,14,11,4,14,6]

theorem envBound14791 : H12AffineFastState.Bounded env14791 := by
  intro p hp
  have h : env14791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14790_14791 : H12AffineEnvironment.transform 4 14 env14790 = env14791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env14790 == env14791) = true)

theorem identity14791 : scanCanonicalize (H12AffineFastState.compose env14791 (packedSelected [0,1,3,14] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound14791 : packedSelected [0,1,3,14] rootPS < 2^1333 := by decide +kernel

def env14792 : List Nat := [2,4,1,2,7,7,2,3,7,0,2,1,3,0,2,1,3,5,1,3,6,7,3,2,0,7,3,1,2,6,0,7,2,4,7,6]

theorem envBound14792 : H12AffineFastState.Bounded env14792 := by
  intro p hp
  have h : env14792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14791_14792 : H12AffineEnvironment.transform 2 1 env14791 = env14792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env14791 == env14792) = true)

theorem identity14792 : scanCanonicalize (H12AffineFastState.compose env14792 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound14792 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env14793 : List Nat := [2,0,1,2,3,3,2,3,3,0,2,1,3,0,2,1,3,1,1,3,2,3,3,2,0,3,3,1,2,2,0,3,2,0,3,2]

theorem envBound14793 : H12AffineFastState.Bounded env14793 := by
  intro p hp
  have h : env14793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14792_14793 : H12AffineEnvironment.transform 1 0 env14792 = env14793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env14792 == env14793) = true)

theorem identity14793 : scanCanonicalize (H12AffineFastState.compose env14793 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound14793 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14794 : List Nat := [1,0,1,1,0,0,1,0,0,0,1,1,0,0,1,1,0,1,1,0,1,0,0,1,0,0,0,1,1,1,0,0,1,0,0,1]

theorem envBound14794 : H12AffineFastState.Bounded env14794 := by
  intro p hp
  have h : env14794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14793_14794 : H12AffineEnvironment.transform 0 1 env14793 = env14794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env14793 == env14794) = true)

def env14795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,90139,262144,1025,21760,77899,272513,73754,87261,8328,64,10588,79130,17665,283905,75222,338391,257,21793,24964,513]

theorem envBound14795 : H12AffineFastState.Bounded env14795 := by
  intro p hp
  have h : env14795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14777_14795 : H12AffineEnvironment.transform 14 21761 env14777 = env14795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env14777 == env14795) = true)

def env14796 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,90139,262144,1025,21760,77899,272393,73754,87125,8192,64,10588,79130,17665,283905,75102,338271,257,21793,24844,513]

theorem envBound14796 : H12AffineFastState.Bounded env14796 := by
  intro p hp
  have h : env14796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14795_14796 : H12AffineEnvironment.transform 6 8 env14795 = env14796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14795 == env14796) = true)

theorem identity14796 : scanCanonicalize (H12AffineFastState.compose env14796 (packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound14796 : packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS < 2^1333 := by decide +kernel

def env14797 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,1047,25612,262144,1025,21760,13404,272393,9229,20546,8192,64,10588,12557,17665,283905,8521,273736,257,21793,24844,513]

theorem envBound14797 : H12AffineFastState.Bounded env14797 := by
  intro p hp
  have h : env14797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14796_14797 : H12AffineEnvironment.transform 15 1047 env14796 = env14797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env14796 == env14797) = true)

theorem identity14797 : scanCanonicalize (H12AffineFastState.compose env14797 (packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound14797 : packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS < 2^1333 := by decide +kernel

def env14798 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12392,9577,1047,5220,262144,1025,9576,13404,272393,9229,8234,8192,64,10588,12557,13673,271721,8521,273736,257,9545,4452,513]

theorem envBound14798 : H12AffineFastState.Bounded env14798 := by
  intro p hp
  have h : env14798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14797_14798 : H12AffineEnvironment.transform 13 12392 env14797 = env14798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env14797 == env14798) = true)

theorem identity14798 : scanCanonicalize (H12AffineFastState.compose env14798 (packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound14798 : packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env14799 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5156,293,1047,5220,262144,1025,292,4112,265285,65,1126,1100,64,3344,5441,4389,262437,1285,264452,257,261,4452,513]

theorem envBound14799 : H12AffineFastState.Bounded env14799 := by
  intro p hp
  have h : env14799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14798_14799 : H12AffineEnvironment.transform 12 1100 env14798 = env14799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env14798 == env14799) = true)

theorem identity14799 : scanCanonicalize (H12AffineFastState.compose env14799 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 3392) := by decide +kernel

theorem selectedBound14799 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env14800 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5156,293,1047,5220,3392,1025,292,4112,261,65,1126,1100,64,3344,5441,4389,3173,1285,1092,257,261,4452,513]

theorem envBound14800 : H12AffineFastState.Bounded env14800 := by
  intro p hp
  have h : env14800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14799_14800 : H12AffineEnvironment.transform 17 3392 env14799 = env14800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3392 env14799 == env14800) = true)

theorem identity14800 : scanCanonicalize (H12AffineFastState.compose env14800 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound14800 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env14801 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,1100,5156,81,1047,5220,3124,1025,80,4112,113,65,1126,1100,64,3172,5173,4177,3173,1137,1092,117,113,4112,513]

theorem envBound14801 : H12AffineFastState.Bounded env14801 := by
  intro p hp
  have h : env14801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14800_14801 : H12AffineEnvironment.transform 7 116 env14800 = env14801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env14800 == env14801) = true)

theorem identity14801 : scanCanonicalize (H12AffineFastState.compose env14801 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound14801 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env14802 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,4096,41,4161,81,114,4097,2129,100,80,4112,113,65,3,41,64,2049,4176,4177,2048,20,33,117,113,4112,513]

theorem envBound14802 : H12AffineFastState.Bounded env14802 := by
  intro p hp
  have h : env14802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14801_14802 : H12AffineEnvironment.transform 9 101 env14801 = env14802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env14801 == env14802) = true)

theorem identity14802 : scanCanonicalize (H12AffineFastState.compose env14802 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14802 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14803 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,4096,41,4112,0,35,4097,2048,53,1,4112,32,16,3,41,17,2049,4097,4096,2048,20,33,36,32,4112,513]

theorem envBound14803 : H12AffineFastState.Bounded env14803 := by
  intro p hp
  have h : env14803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14802_14803 : H12AffineEnvironment.transform 5 17 env14802 = env14803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14802 == env14803) = true)

theorem identity14803 : scanCanonicalize (H12AffineFastState.compose env14803 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound14803 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14804 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,2609,41,2593,0,35,2608,2048,53,1,2593,32,16,3,41,17,2049,2608,2609,2048,20,33,36,32,2593,513]

theorem envBound14804 : H12AffineFastState.Bounded env14804 := by
  intro p hp
  have h : env14804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14803_14804 : H12AffineEnvironment.transform 11 2609 env14803 = env14804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env14803 == env14804) = true)

theorem identity14804 : scanCanonicalize (H12AffineFastState.compose env14804 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14804 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14805 : List Nat := [2,4,8,0,32,1,8,37,512,36,2048,2593,41,2593,0,35,2592,2048,37,1,2593,32,0,3,41,1,2049,2592,2593,2048,4,33,36,32,2593,513]

theorem envBound14805 : H12AffineFastState.Bounded env14805 := by
  intro p hp
  have h : env14805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14804_14805 : H12AffineEnvironment.transform 3 0 env14804 = env14805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14804 == env14805) = true)

def env14806 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,90139,262144,1025,21760,77899,272392,73754,87124,8193,64,10588,79130,17665,283905,75103,338270,257,21793,24845,513]

theorem envBound14806 : H12AffineFastState.Bounded env14806 := by
  intro p hp
  have h : env14806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14795_14806 : H12AffineEnvironment.transform 6 9 env14795 = env14806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14795 == env14806) = true)

theorem identity14806 : scanCanonicalize (H12AffineFastState.compose env14806 (packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14806 : packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS < 2^1333 := by decide +kernel

def env14807 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8202,16401,262144,1025,21760,4161,272392,16,29790,8193,64,10588,5392,17665,283905,1365,264532,257,21793,24845,513]

theorem envBound14807 : H12AffineFastState.Bounded env14807 := by
  intro p hp
  have h : env14807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14806_14807 : H12AffineEnvironment.transform 15 8202 env14806 = env14807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14806 == env14807) = true)

theorem identity14807 : scanCanonicalize (H12AffineFastState.compose env14807 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound14807 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,8202,13389,262144,1025,8540,4161,272392,16,2,8193,64,10588,5392,12637,270685,1365,264532,257,8573,5457,513]

theorem envBound14808 : H12AffineFastState.Bounded env14808 := by
  intro p hp
  have h : env14808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14807_14808 : H12AffineEnvironment.transform 13 13404 env14807 = env14808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env14807 == env14808) = true)

theorem identity14808 : scanCanonicalize (H12AffineFastState.compose env14808 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 10508) := by decide +kernel

theorem selectedBound14808 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env14809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,8202,13389,10508,1025,8540,4161,260,16,2,8193,64,10588,5392,12637,2129,1365,8280,257,8573,5457,513]

theorem envBound14809 : H12AffineFastState.Bounded env14809 := by
  intro p hp
  have h : env14809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14808_14809 : H12AffineEnvironment.transform 17 10508 env14808 = env14809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10508 env14808 == env14809) = true)

theorem identity14809 : scanCanonicalize (H12AffineFastState.compose env14809 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound14809 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env14810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,4112,1297,1094,4097,3392,1025,1296,4161,260,16,2,1101,64,3344,5392,5393,2129,1365,1044,257,1329,5457,513]

theorem envBound14810 : H12AffineFastState.Bounded env14810 := by
  intro p hp
  have h : env14810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14809_14810 : H12AffineEnvironment.transform 12 1100 env14809 = env14810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env14809 == env14810) = true)

theorem identity14810 : scanCanonicalize (H12AffineFastState.compose env14810 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound14810 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,356,1100,372,1297,1094,357,3392,1025,1296,293,260,16,2,1101,64,3344,1140,1141,2129,1365,1044,257,1329,1077,513]

theorem envBound14811 : H12AffineFastState.Bounded env14811 := by
  intro p hp
  have h : env14811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14810_14811 : H12AffineEnvironment.transform 11 356 env14810 = env14811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env14810 == env14811) = true)

theorem identity14811 : scanCanonicalize (H12AffineFastState.compose env14811 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound14811 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env14812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,356,1100,372,1297,1094,357,1296,1025,1296,293,260,16,2,1101,64,1344,1140,1141,1,1365,1044,257,1329,1077,513]

theorem envBound14812 : H12AffineFastState.Bounded env14812 := by
  intro p hp
  have h : env14812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14811_14812 : H12AffineEnvironment.transform 10 80 env14811 = env14812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env14811 == env14812) = true)

theorem identity14812 : scanCanonicalize (H12AffineFastState.compose env14812 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14812 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env14813 : List Nat := [2,4,8,16,32,64,9,256,512,53,80,356,121,372,292,115,357,293,52,293,293,260,16,2,120,64,373,65,64,1,352,33,257,260,0,513]

theorem envBound14813 : H12AffineFastState.Bounded env14813 := by
  intro p hp
  have h : env14813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14812_14813 : H12AffineEnvironment.transform 9 53 env14812 = env14813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14812 == env14813) = true)

def env14814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,4194304,169217,98781,8328,64,4510940,163841,17664,283904,168140,4350284,257,21793,46213,243483]

theorem envBound14814 : H12AffineFastState.Bounded env14814 := by
  intro p hp
  have h : env14814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14755_14814 : H12AffineEnvironment.transform 22 169217 env14755 = env14814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env14755 == env14814) = true)

def env14815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272512,169217,98781,8328,64,64604,163841,17664,283904,168140,412108,257,21793,46213,243483]

theorem envBound14815 : H12AffineFastState.Bounded env14815 := by
  intro p hp
  have h : env14815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14814_14815 : H12AffineEnvironment.transform 21 272512 env14814 = env14815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env14814 == env14815) = true)

theorem identity14815 : scanCanonicalize (H12AffineFastState.compose env14815 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound14815 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,165201,272512,169217,21763,8328,64,64604,163841,17664,283904,168140,412108,257,21793,46213,156613]

theorem envBound14816 : H12AffineFastState.Bounded env14816 := by
  intro p hp
  have h : env14816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14815_14816 : H12AffineEnvironment.transform 15 54494 env14815 = env14816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env14815 == env14816) = true)

def env14817 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,165201,272392,169217,21763,8192,64,64604,163841,17664,283904,168004,411972,257,21793,46093,156493]

theorem envBound14817 : H12AffineFastState.Bounded env14817 := by
  intro p hp
  have h : env14817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14816_14817 : H12AffineEnvironment.transform 6 8 env14816 = env14817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14816 == env14817) = true)

theorem identity14817 : scanCanonicalize (H12AffineFastState.compose env14817 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound14817 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env14818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,157753,1025,32769,165201,147505,169217,21763,8192,64,64604,163841,17664,146745,168004,8573,257,21793,46093,156493]

theorem envBound14818 : H12AffineFastState.Bounded env14818 := by
  intro p hp
  have h : env14818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14817_14818 : H12AffineEnvironment.transform 17 157753 env14817 = env14818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env14817 == env14818) = true)

theorem identity14818 : scanCanonicalize (H12AffineFastState.compose env14818 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound14818 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env14819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49168,43049,1025,32769,17729,32801,21777,21763,8192,64,64604,16401,17664,64809,20564,8573,257,21793,46093,41821]

theorem envBound14819 : H12AffineFastState.Bounded env14819 := by
  intro p hp
  have h : env14819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14818_14819 : H12AffineEnvironment.transform 16 49168 env14818 = env14819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env14818 == env14819) = true)

theorem identity14819 : scanCanonicalize (H12AffineFastState.compose env14819 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound14819 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env14820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40971,46157,43049,1025,32769,12572,32801,8524,8542,8192,64,34817,13388,12637,35188,9225,8573,257,8572,46093,41821]

theorem envBound14820 : H12AffineFastState.Bounded env14820 := by
  intro p hp
  have h : env14820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14819_14820 : H12AffineEnvironment.transform 13 13405 env14819 = env14820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env14819 == env14820) = true)

theorem identity14820 : scanCanonicalize (H12AffineFastState.compose env14820 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound14820 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env14821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8540,343,5393,2421,1025,8541,12572,8573,8524,8542,8192,64,10589,13388,12637,10280,9225,8573,257,8572,5457,513]

theorem envBound14821 : H12AffineFastState.Bounded env14821 := by
  intro p hp
  have h : env14821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14820_14821 : H12AffineEnvironment.transform 14 8540 env14820 = env14821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env14820 == env14821) = true)

theorem identity14821 : scanCanonicalize (H12AffineFastState.compose env14821 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14821 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14822 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,8460,263,5393,2341,1025,8461,12572,8493,8476,8462,8192,16,10509,13340,12557,10280,9225,8493,257,8492,5377,513]

theorem envBound14822 : H12AffineFastState.Bounded env14822 := by
  intro p hp
  have h : env14822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14821_14822 : H12AffineEnvironment.transform 5 16 env14821 = env14822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14821 == env14822) = true)

theorem identity14822 : scanCanonicalize (H12AffineFastState.compose env14822 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1848) := by decide +kernel

theorem selectedBound14822 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14823 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1848,4917,1588,263,5393,2341,1025,1589,5668,1557,1572,1590,1848,16,3637,4900,5685,3856,817,1557,257,1556,5377,513]

theorem envBound14823 : H12AffineFastState.Bounded env14823 := by
  intro p hp
  have h : env14823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14822_14823 : H12AffineEnvironment.transform 12 1848 env14822 = env14823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1848 env14822 == env14823) = true)

theorem identity14823 : scanCanonicalize (H12AffineFastState.compose env14823 (packedSelected [0,1,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound14823 : packedSelected [0,1,8,9,10] rootPS < 2^1333 := by decide +kernel

def env14824 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1280,1848,1589,1588,263,17,2341,1025,1589,804,1557,1572,1590,1848,16,3637,1572,821,3856,817,1557,257,1556,1,513]

theorem envBound14824 : H12AffineFastState.Bounded env14824 := by
  intro p hp
  have h : env14824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14823_14824 : H12AffineEnvironment.transform 11 1280 env14823 = env14824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env14823 == env14824) = true)

theorem identity14824 : scanCanonicalize (H12AffineFastState.compose env14824 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound14824 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env14825 : List Nat := [2,4,8,16,32,16,8,53,512,1024,2048,1077,1549,1589,1588,50,17,2064,1025,1589,529,1557,1572,1590,1549,16,3637,1572,512,3621,516,1557,52,1556,1,513]

theorem envBound14825 : H12AffineFastState.Bounded env14825 := by
  intro p hp
  have h : env14825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14824_14825 : H12AffineEnvironment.transform 7 53 env14824 = env14825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env14824 == env14825) = true)

theorem identity14825 : scanCanonicalize (H12AffineFastState.compose env14825 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound14825 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14826 : List Nat := [2,4,8,16,32,16,8,53,512,1024,1573,1077,1549,1589,1588,50,17,1589,1025,1589,529,1557,1572,1590,1549,16,16,1572,512,0,516,1557,52,1556,1,513]

theorem envBound14826 : H12AffineFastState.Bounded env14826 := by
  intro p hp
  have h : env14826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14825_14826 : H12AffineEnvironment.transform 10 1573 env14825 = env14826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env14825 == env14826) = true)

theorem identity14826 : scanCanonicalize (H12AffineFastState.compose env14826 (packedSelected [4,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound14826 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env14827 : List Nat := [2,4,8,16,32,16,8,53,1,1024,1060,1077,1036,1076,1077,50,17,1076,1025,1076,16,1044,1061,1079,1036,16,16,1061,1,0,5,1044,52,1045,1,0]

theorem envBound14827 : H12AffineFastState.Bounded env14827 := by
  intro p hp
  have h : env14827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14826_14827 : H12AffineEnvironment.transform 8 1 env14826 = env14827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14826 == env14827) = true)

theorem identity14827 : scanCanonicalize (H12AffineFastState.compose env14827 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14827 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14828 : List Nat := [2,4,8,1,32,1,8,36,1,1024,1060,1060,1036,1061,1060,35,0,1061,1025,1061,1,1029,1061,1062,1036,1,1,1061,1,0,5,1029,37,1028,1,0]

theorem envBound14828 : H12AffineFastState.Bounded env14828 := by
  intro p hp
  have h : env14828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14827_14828 : H12AffineEnvironment.transform 3 1 env14827 = env14828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14827 == env14828) = true)

theorem identity14828 : scanCanonicalize (H12AffineFastState.compose env14828 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound14828 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14829 : List Nat := [2,4,3,1,32,1,3,36,1,1024,1060,1060,1031,1061,1060,35,0,1061,1025,1061,1,1029,1061,1062,1031,1,1,1061,1,0,5,1029,37,1028,1,0]

theorem envBound14829 : H12AffineFastState.Bounded env14829 := by
  intro p hp
  have h : env14829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14828_14829 : H12AffineEnvironment.transform 2 3 env14828 = env14829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env14828 == env14829) = true)

def env14830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,165201,272393,169217,21763,8193,64,64604,163841,17664,283904,168005,411973,257,21793,46092,156492]

theorem envBound14830 : H12AffineFastState.Bounded env14830 := by
  intro p hp
  have h : env14830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14816_14830 : H12AffineEnvironment.transform 6 9 env14816 = env14830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14816 == env14830) = true)

theorem identity14830 : scanCanonicalize (H12AffineFastState.compose env14830 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 149860) := by decide +kernel

theorem selectedBound14830 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env14831 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,149860,1025,32769,165201,156013,169217,21763,8193,64,64604,163841,17664,138340,168005,33,257,21793,46092,156492]

theorem envBound14831 : H12AffineFastState.Bounded env14831 := by
  intro p hp
  have h : env14831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14830_14831 : H12AffineEnvironment.transform 17 149860 env14830 = env14831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env14830 == env14831) = true)

theorem identity14831 : scanCanonicalize (H12AffineFastState.compose env14831 (packedSelected [0,1,3,5,7,8,11,12,14,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 49217) := by decide +kernel

theorem selectedBound14831 : packedSelected [0,1,3,5,7,8,11,12,14,19,26] rootPS < 2^1333 := by decide +kernel

def env14832 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49217,35109,1025,32769,17680,41260,21824,21763,8193,64,64604,16448,17664,56357,20484,33,257,21793,46092,41741]

theorem envBound14832 : H12AffineFastState.Bounded env14832 := by
  intro p hp
  have h : env14832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14831_14832 : H12AffineEnvironment.transform 16 49217 env14831 = env14832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49217 env14831 == env14832) = true)

theorem identity14832 : scanCanonicalize (H12AffineFastState.compose env14832 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound14832 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env14833 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,13340,32120,1025,29788,17680,21873,21824,21763,8193,64,2049,16448,17664,10360,20484,33,257,21793,16465,22352]

theorem envBound14833 : H12AffineFastState.Bounded env14833 := by
  intro p hp
  have h : env14833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14832_14833 : H12AffineEnvironment.transform 14 29789 env14832 = env14833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env14832 == env14833) = true)

theorem identity14833 : scanCanonicalize (H12AffineFastState.compose env14833 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound14833 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14834 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8460,8202,13340,10281,1025,8461,4161,32,17,82,8193,64,2049,5393,4177,10360,1365,33,257,112,5376,513]

theorem envBound14834 : H12AffineFastState.Bounded env14834 := by
  intro p hp
  have h : env14834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14833_14834 : H12AffineEnvironment.transform 13 5457 env14833 = env14834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env14833 == env14834) = true)

theorem identity14834 : scanCanonicalize (H12AffineFastState.compose env14834 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

end H12CloudChart1