import H12CloudChart1Data008

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans2191_2192 : H12AffineEnvironment.transform 15 8314 env2191 = env2192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env2191 == env2192) = true)

theorem identity2192 : scanCanonicalize (H12AffineFastState.compose env2192 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(16+1) ^^^ 16633) := by decide +kernel

theorem selectedBound2192 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2193 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,233,8192,16384,8432,8314,16633,262144,1024,8432,2097152,32,185,139,8328,233,262177,16385,16,2080,1024,1,5,0,16632,512]

theorem envBound2193 : H12AffineFastState.Bounded env2193 := by
  intro p hp
  have h : env2193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2192_2193 : H12AffineEnvironment.transform 16 16633 env2192 = env2193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env2192 == env2193) = true)

theorem identity2193 : scanCanonicalize (H12AffineFastState.compose env2193 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 271479) := by decide +kernel

theorem selectedBound2193 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env2194 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,233,8192,16384,8432,8314,16633,262144,1024,8432,271479,32,185,139,8328,233,262177,16385,16,2080,1024,1,5,0,16632,512]

theorem envBound2194 : H12AffineFastState.Bounded env2194 := by
  intro p hp
  have h : env2194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2193_2194 : H12AffineEnvironment.transform 20 271479 env2193 = env2194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 271479 env2193 == env2194) = true)

theorem identity2194 : scanCanonicalize (H12AffineFastState.compose env2194 (packedSelected [3,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound2194 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env2195 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,17,8192,16384,8200,8314,16385,262144,1024,8200,271479,32,65,115,8304,17,262177,16385,16,2080,1024,1,5,0,16384,512]

theorem envBound2195 : H12AffineFastState.Bounded env2195 := by
  intro p hp
  have h : env2195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2194_2195 : H12AffineEnvironment.transform 6 120 env2194 = env2195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env2194 == env2195) = true)

theorem identity2195 : scanCanonicalize (H12AffineFastState.compose env2195 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 1150) := by decide +kernel

theorem selectedBound2195 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2196 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,17,8192,16384,8200,8314,16385,1150,1024,8200,8201,32,65,115,8304,17,1119,16385,16,2080,1024,1,5,0,16384,512]

theorem envBound2196 : H12AffineFastState.Bounded env2196 := by
  intro p hp
  have h : env2196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2195_2196 : H12AffineEnvironment.transform 17 1150 env2195 = env2196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1150 env2195 == env2196) = true)

theorem identity2196 : scanCanonicalize (H12AffineFastState.compose env2196 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound2196 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env2197 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,17,9,16384,1,115,16385,1150,1024,1,0,32,65,115,121,17,1119,16385,16,2080,1024,1,5,0,16384,512]

theorem envBound2197 : H12AffineFastState.Bounded env2197 := by
  intro p hp
  have h : env2197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2196_2197 : H12AffineEnvironment.transform 12 9 env2196 = env2197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env2196 == env2197) = true)

theorem identity2197 : scanCanonicalize (H12AffineFastState.compose env2197 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 1093) := by decide +kernel

theorem selectedBound2197 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env2198 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,17,9,1093,1,115,1092,1150,1024,1,0,32,65,115,121,17,1119,1092,16,2080,1024,1,5,0,1093,512]

theorem envBound2198 : H12AffineFastState.Bounded env2198 := by
  intro p hp
  have h : env2198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2197_2198 : H12AffineEnvironment.transform 13 1093 env2197 = env2198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1093 env2197 == env2198) = true)

theorem identity2198 : scanCanonicalize (H12AffineFastState.compose env2198 (packedSelected [0,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound2198 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env2199 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,17,9,1045,1,35,1044,1070,1024,1,0,32,17,35,41,17,1039,1044,16,2080,1024,1,5,0,1045,512]

theorem envBound2199 : H12AffineFastState.Bounded env2199 := by
  intro p hp
  have h : env2199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2198_2199 : H12AffineEnvironment.transform 5 16 env2198 = env2199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env2198 == env2199) = true)

theorem identity2199 : scanCanonicalize (H12AffineFastState.compose env2199 (packedSelected [1,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound2199 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env2200 : List Nat := [2,4,8,16,32,16,40,5,512,1024,1039,17,9,1045,1,35,1044,1070,1024,1,0,32,17,35,41,17,1039,1044,16,1071,1024,1,5,0,1045,512]

theorem envBound2200 : H12AffineFastState.Bounded env2200 := by
  intro p hp
  have h : env2200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2199_2200 : H12AffineEnvironment.transform 10 1039 env2199 = env2200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env2199 == env2200) = true)

theorem identity2200 : scanCanonicalize (H12AffineFastState.compose env2200 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound2200 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2201 : List Nat := [2,4,8,16,17,16,25,5,512,1024,1039,17,9,1045,1,18,1044,1055,1024,1,0,17,17,18,24,17,1039,1044,16,1054,1024,1,5,0,1045,512]

theorem envBound2201 : H12AffineFastState.Bounded env2201 := by
  intro p hp
  have h : env2201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2200_2201 : H12AffineEnvironment.transform 4 17 env2200 = env2201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2200 == env2201) = true)

def env2202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147473,409817,16385,151552,2080,16852469,4341977,257,0,34359738368,16925299]

theorem envBound2202 : H12AffineFastState.Bounded env2202 := by
  intro p hp
  have h : env2202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2150_2202 : H12AffineEnvironment.transform 18 1025 env2150 = env2202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env2150 == env2202) = true)

def env2203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147473,409817,16385,151552,2080,16852469,4341977,257,0,131072,16925299]

theorem envBound2203 : H12AffineFastState.Bounded env2203 := by
  intro p hp
  have h : env2203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2202_2203 : H12AffineEnvironment.transform 34 131072 env2202 = env2203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2202 == env2203) = true)

theorem identity2203 : scanCanonicalize (H12AffineFastState.compose env2203 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 6309118) := by decide +kernel

theorem selectedBound2203 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,6309118,8328,147473,409817,16385,151552,2080,6381835,4341977,257,0,131072,6424205]

theorem envBound2204 : H12AffineFastState.Bounded env2204 := by
  intro p hp
  have h : env2204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2203_2204 : H12AffineEnvironment.transform 23 6309118 env2203 = env2204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6309118 env2203 == env2204) = true)

theorem identity2204 : scanCanonicalize (H12AffineFastState.compose env2204 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 2114676) := by decide +kernel

theorem selectedBound2204 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,2114676,147520,138,8328,147473,409817,16385,151552,2080,75135,2229421,257,0,131072,148217]

theorem envBound2205 : H12AffineFastState.Bounded env2205 := by
  intro p hp
  have h : env2205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2204_2205 : H12AffineEnvironment.transform 21 2114676 env2204 = env2205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114676 env2204 == env2205) = true)

theorem identity2205 : scanCanonicalize (H12AffineFastState.compose env2205 (packedSelected [3,5,8,10,17,21,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 132433) := by decide +kernel

theorem selectedBound2205 : packedSelected [3,5,8,10,17,21,28,31] rootPS < 2^1333 := by decide +kernel

def env2206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,132433,147749,147520,138,8328,147473,409817,16385,151552,2080,75135,508,257,0,131072,148217]

theorem envBound2206 : H12AffineFastState.Bounded env2206 := by
  intro p hp
  have h : env2206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2205_2206 : H12AffineEnvironment.transform 20 132433 env2205 = env2206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132433 env2205 == env2206) = true)

theorem identity2206 : scanCanonicalize (H12AffineFastState.compose env2206 (packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound2206 : packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env2207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,131072,262144,1025,8693,132433,147749,147520,138,8328,147473,409817,16385,151552,2080,1025,508,257,0,131072,148217]

theorem envBound2207 : H12AffineFastState.Bounded env2207 := by
  intro p hp
  have h : env2207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2206_2207 : H12AffineEnvironment.transform 15 8574 env2206 = env2207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env2206 == env2207) = true)

def env2208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16632,262144,1025,8693,17833,477,184,138,8328,233,262177,16385,4344,2080,1025,508,257,0,16632,513]

theorem envBound2208 : H12AffineFastState.Bounded env2208 := by
  intro p hp
  have h : env2208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2207_2208 : H12AffineEnvironment.transform 16 16632 env2207 = env2208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env2207 == env2208) = true)

theorem identity2208 : scanCanonicalize (H12AffineFastState.compose env2208 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound2208 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env2209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,8693,8574,13556,262144,1025,8693,12709,477,184,138,8328,233,262177,13325,4344,2080,1025,508,257,0,13556,513]

theorem envBound2209 : H12AffineFastState.Bounded env2209 := by
  intro p hp
  have h : env2209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2208_2209 : H12AffineEnvironment.transform 13 13324 env2208 = env2209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env2208 == env2209) = true)

theorem identity2209 : scanCanonicalize (H12AffineFastState.compose env2209 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound2209 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,5124,509,374,5372,262144,1025,509,4525,477,184,138,128,233,262177,5125,4344,2080,1025,508,257,0,5372,513]

theorem envBound2210 : H12AffineFastState.Bounded env2210 := by
  intro p hp
  have h : env2210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2209_2210 : H12AffineEnvironment.transform 12 8 env2209 = env2210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env2209 == env2210) = true)

theorem identity2210 : scanCanonicalize (H12AffineFastState.compose env2210 (packedSelected [4,6,9,20] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound2210 : packedSelected [4,6,9,20] rootPS < 2^1333 := by decide +kernel

def env2211 : List Nat := [2,4,8,16,32,64,105,256,512,1024,2048,4096,8,5124,276,374,5141,262144,1025,276,4420,308,81,99,105,0,262177,5125,4113,2080,1025,277,257,0,5141,513]

theorem envBound2211 : H12AffineFastState.Bounded env2211 := by
  intro p hp
  have h : env2211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2210_2211 : H12AffineEnvironment.transform 6 105 env2210 = env2211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env2210 == env2211) = true)

theorem identity2211 : scanCanonicalize (H12AffineFastState.compose env2211 (packedSelected [0,2,6,7,11,12,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound2211 : packedSelected [0,2,6,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env2212 : List Nat := [2,4,8,16,32,64,105,256,512,1024,2048,4096,8,5124,276,374,5141,2080,1025,276,4420,308,81,99,105,0,2049,5125,4113,2080,1025,277,257,0,5141,513]

theorem envBound2212 : H12AffineFastState.Bounded env2212 := by
  intro p hp
  have h : env2212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2211_2212 : H12AffineEnvironment.transform 17 2080 env2211 = env2212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env2211 == env2212) = true)

theorem identity2212 : scanCanonicalize (H12AffineFastState.compose env2212 (packedSelected [0,2,6,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound2212 : packedSelected [0,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env2213 : List Nat := [2,4,8,16,32,64,105,5,512,1024,2048,4096,8,5124,17,115,5141,2080,1025,17,4161,49,81,99,105,0,2049,5125,4113,2080,1025,16,4,0,5141,513]

theorem envBound2213 : H12AffineFastState.Bounded env2213 := by
  intro p hp
  have h : env2213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2212_2213 : H12AffineEnvironment.transform 7 5 env2212 = env2213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env2212 == env2213) = true)

theorem identity2213 : scanCanonicalize (H12AffineFastState.compose env2213 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound2213 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2214 : List Nat := [2,4,8,16,32,1,40,5,512,1024,2048,4096,8,5124,17,50,5141,2080,1025,17,4096,49,16,34,40,0,2049,5125,4113,2080,1025,16,4,0,5141,513]

theorem envBound2214 : H12AffineFastState.Bounded env2214 := by
  intro p hp
  have h : env2214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2213_2214 : H12AffineEnvironment.transform 5 1 env2213 = env2214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2213 == env2214) = true)

theorem identity2214 : scanCanonicalize (H12AffineFastState.compose env2214 (packedSelected [4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1567) := by decide +kernel

theorem selectedBound2214 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env2215 : List Nat := [2,4,8,16,32,1,40,5,512,1024,2048,1567,8,539,17,50,522,2080,1025,17,1567,49,16,34,40,0,2049,538,1550,2080,1025,16,4,0,522,513]

theorem envBound2215 : H12AffineFastState.Bounded env2215 := by
  intro p hp
  have h : env2215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2214_2215 : H12AffineEnvironment.transform 11 1567 env2214 = env2215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1567 env2214 == env2215) = true)

theorem identity2215 : scanCanonicalize (H12AffineFastState.compose env2215 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound2215 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env2216 : List Nat := [2,4,8,1,32,1,40,5,512,1024,2048,1550,8,522,0,35,522,2080,1025,0,1550,32,1,34,40,0,2049,523,1550,2080,1025,1,4,0,522,513]

theorem envBound2216 : H12AffineFastState.Bounded env2216 := by
  intro p hp
  have h : env2216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2215_2216 : H12AffineEnvironment.transform 3 1 env2215 = env2216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env2215 == env2216) = true)

theorem identity2216 : scanCanonicalize (H12AffineFastState.compose env2216 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound2216 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2217 : List Nat := [2,4,8,1,32,1,40,5,512,1024,0,1550,8,522,0,35,522,32,1025,0,1550,32,1,34,40,0,1,523,1550,32,1025,1,4,0,522,513]

theorem envBound2217 : H12AffineFastState.Bounded env2217 := by
  intro p hp
  have h : env2217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2216_2217 : H12AffineEnvironment.transform 10 0 env2216 = env2217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env2216 == env2217) = true)

theorem identity2217 : scanCanonicalize (H12AffineFastState.compose env2217 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound2217 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2218 : List Nat := [2,4,8,1,32,1,40,5,512,36,0,554,8,522,0,35,522,32,37,0,554,32,1,34,40,0,1,523,554,32,37,1,4,0,522,513]

theorem envBound2218 : H12AffineFastState.Bounded env2218 := by
  intro p hp
  have h : env2218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2217_2218 : H12AffineEnvironment.transform 9 36 env2217 = env2218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env2217 == env2218) = true)

theorem identity2218 : scanCanonicalize (H12AffineFastState.compose env2218 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound2218 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2219 : List Nat := [2,4,1,1,32,1,33,5,512,36,0,547,1,515,0,35,515,32,37,0,547,32,1,34,33,0,1,514,547,32,37,1,4,0,515,513]

theorem envBound2219 : H12AffineFastState.Bounded env2219 := by
  intro p hp
  have h : env2219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2218_2219 : H12AffineEnvironment.transform 2 1 env2218 = env2219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env2218 == env2219) = true)

theorem identity2219 : scanCanonicalize (H12AffineFastState.compose env2219 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound2219 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env2220 : List Nat := [2,4,1,1,32,1,33,5,34,36,0,1,1,33,0,35,33,32,37,0,1,32,1,34,33,0,1,32,1,32,37,1,4,0,33,35]

theorem envBound2220 : H12AffineFastState.Bounded env2220 := by
  intro p hp
  have h : env2220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2219_2220 : H12AffineEnvironment.transform 8 34 env2219 = env2220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env2219 == env2220) = true)

theorem identity2220 : scanCanonicalize (H12AffineFastState.compose env2220 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound2220 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2221 : List Nat := [2,4,1,1,5,1,4,5,7,1,0,1,1,4,0,6,4,5,0,0,1,5,1,7,4,0,1,5,1,5,0,1,4,0,4,6]

theorem envBound2221 : H12AffineFastState.Bounded env2221 := by
  intro p hp
  have h : env2221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2220_2221 : H12AffineEnvironment.transform 4 5 env2220 = env2221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env2220 == env2221) = true)

def env2222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16633,262144,1025,8693,17832,476,185,138,8328,232,262176,16385,4345,2080,1025,508,257,0,16633,512]

theorem envBound2222 : H12AffineFastState.Bounded env2222 := by
  intro p hp
  have h : env2222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2207_2222 : H12AffineEnvironment.transform 16 16633 env2207 = env2222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env2207 == env2222) = true)

theorem identity2222 : scanCanonicalize (H12AffineFastState.compose env2222 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound2222 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env2223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16633,10281,1025,8693,17832,476,185,138,8328,232,10249,16385,4345,2080,1025,508,257,0,16633,512]

theorem envBound2223 : H12AffineFastState.Bounded env2223 := by
  intro p hp
  have h : env2223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2222_2223 : H12AffineEnvironment.transform 17 10281 env2222 = env2223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env2222 == env2223) = true)

theorem identity2223 : scanCanonicalize (H12AffineFastState.compose env2223 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound2223 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env2224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,16384,81,218,16633,2445,1025,81,17832,476,185,138,300,232,2477,16385,4345,2080,1025,508,257,0,16633,512]

theorem envBound2224 : H12AffineFastState.Bounded env2224 := by
  intro p hp
  have h : env2224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2223_2224 : H12AffineEnvironment.transform 12 420 env2223 = env2224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env2223 == env2224) = true)

theorem identity2224 : scanCanonicalize (H12AffineFastState.compose env2224 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound2224 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env2225 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,4096,224,16384,81,218,16633,2249,1025,81,17644,152,185,138,104,232,2281,16385,4345,2080,1025,184,69,0,16633,512]

theorem envBound2225 : H12AffineFastState.Bounded env2225 := by
  intro p hp
  have h : env2225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2224_2225 : H12AffineEnvironment.transform 7 68 env2224 = env2225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env2224 == env2225) = true)

def env2226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147473,409817,16385,151552,2080,16852469,4341977,257,0,131073,16925299]

theorem envBound2226 : H12AffineFastState.Bounded env2226 := by
  intro p hp
  have h : env2226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2202_2226 : H12AffineEnvironment.transform 34 131073 env2202 = env2226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2202 == env2226) = true)

theorem identity2226 : scanCanonicalize (H12AffineFastState.compose env2226 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4216063) := by decide +kernel

theorem selectedBound2226 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,4216063,8328,147473,409817,16385,151552,2080,4288778,4341977,257,0,131073,4331148]

theorem envBound2227 : H12AffineFastState.Bounded env2227 := by
  intro p hp
  have h : env2227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2226_2227 : H12AffineEnvironment.transform 23 4216063 env2226 = env2227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4216063 env2226 == env2227) = true)

theorem identity2227 : scanCanonicalize (H12AffineFastState.compose env2227 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 29995) := by decide +kernel

theorem selectedBound2227 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,29995,131072,262144,1025,8693,2097152,4194304,147520,4216063,8328,147473,409817,16385,151552,2080,4195361,4341977,257,0,131073,4331148]

theorem envBound2228 : H12AffineFastState.Bounded env2228 := by
  intro p hp
  have h : env2228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2227_2228 : H12AffineEnvironment.transform 15 29995 env2227 = env2228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29995 env2227 == env2228) = true)

theorem identity2228 : scanCanonicalize (H12AffineFastState.compose env2228 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound2228 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env2229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5205,8693,8574,131072,262144,1025,8693,2097152,4194304,136213,4194474,8328,136260,398476,5204,132181,2080,4195361,4330636,257,0,131073,4331148]

theorem envBound2229 : H12AffineFastState.Bounded env2229 := by
  intro p hp
  have h : env2229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2228_2229 : H12AffineEnvironment.transform 13 5205 env2228 = env2229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env2228 == env2229) = true)

def env2230 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,5205,8541,8574,131072,262144,1025,8541,2097152,4194304,136213,4194306,8224,136260,398372,5204,132181,2080,4195361,4330532,257,0,131073,4331044]

theorem envBound2230 : H12AffineFastState.Bounded env2230 := by
  intro p hp
  have h : env2230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2229_2230 : H12AffineEnvironment.transform 6 40 env2229 = env2230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2229 == env2230) = true)

theorem identity2230 : scanCanonicalize (H12AffineFastState.compose env2230 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound2230 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env2231 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,5205,8541,8574,131072,262144,1025,8541,2097152,32,136213,34,8224,136260,398372,5204,132181,2080,1025,136196,257,0,131073,136708]

theorem envBound2231 : H12AffineFastState.Bounded env2231 := by
  intro p hp
  have h : env2231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2230_2231 : H12AffineEnvironment.transform 21 32 env2230 = env2231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env2230 == env2231) = true)

theorem identity2231 : scanCanonicalize (H12AffineFastState.compose env2231 (packedSelected [0,2,3,4,5,6,7,9,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 276537) := by decide +kernel

theorem selectedBound2231 : packedSelected [0,2,3,4,5,6,7,9,10,17] rootPS < 2^1333 := by decide +kernel

def env2232 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,5205,8541,8574,131072,262144,1025,8541,276537,32,136213,34,8224,136260,398372,5204,132181,2080,1025,136196,257,0,131073,136708]

theorem envBound2232 : H12AffineFastState.Bounded env2232 := by
  intro p hp
  have h : env2232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2231_2232 : H12AffineEnvironment.transform 20 276537 env2231 = env2232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276537 env2231 == env2232) = true)

theorem identity2232 : scanCanonicalize (H12AffineFastState.compose env2232 (packedSelected [0,1,2,4,6,7,8,9,13,19] rootPS)) = affineNative (2^(16+1) ^^^ 5456) := by decide +kernel

theorem selectedBound2232 : packedSelected [0,1,2,4,6,7,8,9,13,19] rootPS < 2^1333 := by decide +kernel

def env2233 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,5205,8541,8574,5456,262144,1025,8541,276537,32,325,34,8224,276,262516,5204,4357,2080,1025,340,257,0,5457,852]

theorem envBound2233 : H12AffineFastState.Bounded env2233 := by
  intro p hp
  have h : env2233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2232_2233 : H12AffineEnvironment.transform 16 5456 env2232 = env2233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5456 env2232 == env2233) = true)

theorem identity2233 : scanCanonicalize (H12AffineFastState.compose env2233 (packedSelected [2,6,12,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 2160) := by decide +kernel

theorem selectedBound2233 : packedSelected [2,6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env2234 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,5205,8541,8574,5456,2160,1025,8541,12361,32,325,34,8224,276,2308,5204,4357,2080,1025,340,257,0,5457,852]

theorem envBound2234 : H12AffineFastState.Bounded env2234 := by
  intro p hp
  have h : env2234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2233_2234 : H12AffineEnvironment.transform 17 2160 env2233 = env2234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2160 env2233 == env2234) = true)

theorem identity2234 : scanCanonicalize (H12AffineFastState.compose env2234 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound2234 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env2235 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,5205,8201,8234,5124,2160,1025,8201,12361,32,17,34,8224,64,2128,5204,4177,2080,1025,0,85,0,5125,512]

theorem envBound2235 : H12AffineFastState.Bounded env2235 := by
  intro p hp
  have h : env2235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2234_2235 : H12AffineEnvironment.transform 7 84 env2234 = env2235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env2234 == env2235) = true)

theorem identity2235 : scanCanonicalize (H12AffineFastState.compose env2235 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 5676) := by decide +kernel

theorem selectedBound2235 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2236 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,5676,5205,5669,5638,5124,2160,1025,5669,1637,32,17,34,5644,64,2128,5204,4177,2080,1025,0,85,0,5125,512]

theorem envBound2236 : H12AffineFastState.Bounded env2236 := by
  intro p hp
  have h : env2236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2235_2236 : H12AffineEnvironment.transform 12 5676 env2235 = env2236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5676 env2235 == env2236) = true)

theorem identity2236 : scanCanonicalize (H12AffineFastState.compose env2236 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 1652) := by decide +kernel

theorem selectedBound2236 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env2237 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,1652,88,545,81,114,624,2160,1025,81,1637,32,17,34,120,64,2128,544,1573,2080,1025,0,85,0,625,512]

theorem envBound2237 : H12AffineFastState.Bounded env2237 := by
  intro p hp
  have h : env2237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2236_2237 : H12AffineEnvironment.transform 11 1652 env2236 = env2237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1652 env2236 == env2237) = true)

theorem identity2237 : scanCanonicalize (H12AffineFastState.compose env2237 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound2237 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env2238 : List Nat := [2,4,8,16,32,64,40,84,512,4,2048,624,88,545,81,114,624,2160,5,81,609,32,17,34,120,64,2128,544,545,2080,5,0,85,0,625,512]

theorem envBound2238 : H12AffineFastState.Bounded env2238 := by
  intro p hp
  have h : env2238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2237_2238 : H12AffineEnvironment.transform 9 4 env2237 = env2238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env2237 == env2238) = true)

theorem identity2238 : scanCanonicalize (H12AffineFastState.compose env2238 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 586) := by decide +kernel

theorem selectedBound2238 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env2239 : List Nat := [2,4,8,16,32,64,40,84,512,4,586,624,88,545,81,114,624,570,5,81,609,32,17,34,120,64,538,544,545,618,5,0,85,0,625,512]

theorem envBound2239 : H12AffineFastState.Bounded env2239 := by
  intro p hp
  have h : env2239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2238_2239 : H12AffineEnvironment.transform 10 586 env2238 = env2239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 586 env2238 == env2239) = true)

def env2240 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,5205,8540,8574,131072,262144,1025,8540,2097152,4194304,136213,4194307,8225,136260,398373,5204,132181,2080,4195361,4330533,257,0,131073,4331045]

theorem envBound2240 : H12AffineFastState.Bounded env2240 := by
  intro p hp
  have h : env2240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2229_2240 : H12AffineEnvironment.transform 6 41 env2229 = env2240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env2229 == env2240) = true)

theorem identity2240 : scanCanonicalize (H12AffineFastState.compose env2240 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 136228) := by decide +kernel

theorem selectedBound2240 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env2241 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,5205,8540,8574,131072,262144,1025,8540,2097152,136228,136213,136231,8225,136260,398373,5204,132181,2080,135173,1,257,0,131073,513]

theorem envBound2241 : H12AffineFastState.Bounded env2241 := by
  intro p hp
  have h : env2241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2240_2241 : H12AffineEnvironment.transform 21 136228 env2240 = env2241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136228 env2240 == env2241) = true)

theorem identity2241 : scanCanonicalize (H12AffineFastState.compose env2241 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 132180) := by decide +kernel

theorem selectedBound2241 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2242 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,5205,8540,8574,131072,262144,1025,8540,132180,136228,136213,136231,8225,136260,398373,5204,132181,2080,135173,1,257,0,131073,513]

theorem envBound2242 : H12AffineFastState.Bounded env2242 := by
  intro p hp
  have h : env2242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2241_2242 : H12AffineEnvironment.transform 20 132180 env2241 = env2242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132180 env2241 == env2242) = true)

theorem identity2242 : scanCanonicalize (H12AffineFastState.compose env2242 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound2242 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2243 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,5205,8540,8574,5393,262144,1025,8540,4421,309,260,310,8225,341,262452,5204,4420,2080,1300,1,257,0,5392,513]

theorem envBound2243 : H12AffineFastState.Bounded env2243 := by
  intro p hp
  have h : env2243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2242_2243 : H12AffineEnvironment.transform 16 5393 env2242 = env2243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env2242 == env2243) = true)

theorem identity2243 : scanCanonicalize (H12AffineFastState.compose env2243 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound2243 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env2244 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,5205,8200,8234,5189,262144,1025,8200,4113,97,80,98,8225,1,262240,5204,4112,2080,1088,1,85,0,5188,513]

theorem envBound2244 : H12AffineFastState.Bounded env2244 := by
  intro p hp
  have h : env2244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2243_2244 : H12AffineEnvironment.transform 7 84 env2243 = env2244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env2243 == env2244) = true)

theorem identity2244 : scanCanonicalize (H12AffineFastState.compose env2244 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound2244 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env2245 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,4096,8192,5124,8200,8234,5140,262144,1025,8200,4113,48,1,51,8225,1,262193,5125,4112,2080,1041,1,4,0,5141,513]

theorem envBound2245 : H12AffineFastState.Bounded env2245 := by
  intro p hp
  have h : env2245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2244_2245 : H12AffineEnvironment.transform 5 17 env2244 = env2245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env2244 == env2245) = true)

theorem identity2245 : scanCanonicalize (H12AffineFastState.compose env2245 (packedSelected [0,2,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound2245 : packedSelected [0,2,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env2246 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,4096,24,5124,16,50,5140,262144,1025,16,4113,48,1,51,57,1,262193,5125,4112,2080,1041,1,4,0,5141,513]

theorem envBound2246 : H12AffineFastState.Bounded env2246 := by
  intro p hp
  have h : env2246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2245_2246 : H12AffineEnvironment.transform 12 24 env2245 = env2246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env2245 == env2246) = true)

theorem identity2246 : scanCanonicalize (H12AffineFastState.compose env2246 (packedSelected [1,2,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(17+1) ^^^ 2097) := by decide +kernel

theorem selectedBound2246 : packedSelected [1,2,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env2247 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,4096,24,5124,16,50,5140,2097,1025,16,4113,48,1,51,57,1,2048,5125,4112,2080,1041,1,4,0,5141,513]

theorem envBound2247 : H12AffineFastState.Bounded env2247 := by
  intro p hp
  have h : env2247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2246_2247 : H12AffineEnvironment.transform 17 2097 env2246 = env2247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2097 env2246 == env2247) = true)

theorem identity2247 : scanCanonicalize (H12AffineFastState.compose env2247 (packedSelected [3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound2247 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env2248 : List Nat := [2,4,8,16,32,17,41,5,512,5,2048,4096,24,4097,16,50,4113,2097,4,16,4113,48,1,51,57,1,2048,4096,4112,2080,20,1,4,0,4112,513]

theorem envBound2248 : H12AffineFastState.Bounded env2248 := by
  intro p hp
  have h : env2248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2247_2248 : H12AffineEnvironment.transform 9 5 env2247 = env2248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env2247 == env2248) = true)

def env2249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,147521,16777216,8328,672785,935129,16385,151552,2080,17375732,4867289,525568,0,34359738368,17450611]

theorem envBound2249 : H12AffineFastState.Bounded env2249 := by
  intro p hp
  have h : env2249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2149_2249 : H12AffineEnvironment.transform 22 147521 env2149 = env2249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env2149 == env2249) = true)

def env2250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147473,409817,16385,151552,2080,16852468,4341977,256,0,34359738368,16925299]

theorem envBound2250 : H12AffineFastState.Bounded env2250 := by
  intro p hp
  have h : env2250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2249_2250 : H12AffineEnvironment.transform 18 1024 env2249 = env2250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env2249 == env2250) = true)

def env2251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147473,409817,16385,151552,2080,16852468,4341977,256,0,131072,16925299]

theorem envBound2251 : H12AffineFastState.Bounded env2251 := by
  intro p hp
  have h : env2251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2250_2251 : H12AffineEnvironment.transform 34 131072 env2250 = env2251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2250 == env2251) = true)

theorem identity2251 : scanCanonicalize (H12AffineFastState.compose env2251 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 6427119) := by decide +kernel

theorem selectedBound2251 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,6427119,8328,147473,409817,16385,151552,2080,6501403,4341977,256,0,131072,6312860]

theorem envBound2252 : H12AffineFastState.Bounded env2252 := by
  intro p hp
  have h : env2252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2251_2252 : H12AffineEnvironment.transform 23 6427119 env2251 = env2252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6427119 env2251 == env2252) = true)

theorem identity2252 : scanCanonicalize (H12AffineFastState.compose env2252 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound2252 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1024,8693,2097152,4194304,147521,6427119,8328,147473,409817,16385,151552,2080,6427745,4341977,256,0,131072,6312860]

theorem envBound2253 : H12AffineFastState.Bounded env2253 := by
  intro p hp
  have h : env2253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2252_2253 : H12AffineEnvironment.transform 15 8314 env2252 = env2253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env2252 == env2253) = true)

def env2254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1024,8693,2097152,147672,147521,2117943,8328,147473,409817,16385,151552,2080,2118841,1,256,0,131072,2233156]

theorem envBound2254 : H12AffineFastState.Bounded env2254 := by
  intro p hp
  have h : env2254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2253_2254 : H12AffineEnvironment.transform 21 147672 env2253 = env2254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147672 env2253 == env2254) = true)

theorem identity2254 : scanCanonicalize (H12AffineFastState.compose env2254 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound2254 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2255 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,131072,262144,1024,8432,2097152,147672,147521,2117682,8328,147473,409817,16385,151552,2080,2118841,1,5,0,131072,2232897]

theorem envBound2255 : H12AffineFastState.Bounded env2255 := by
  intro p hp
  have h : env2255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2254_2255 : H12AffineEnvironment.transform 7 5 env2254 = env2255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env2254 == env2255) = true)

def env2256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1024,8693,2097152,147673,147521,2117942,8328,147473,409817,16385,151552,2080,2118840,0,256,0,131072,2233157]

theorem envBound2256 : H12AffineFastState.Bounded env2256 := by
  intro p hp
  have h : env2256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2253_2256 : H12AffineEnvironment.transform 21 147673 env2253 = env2256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147673 env2253 == env2256) = true)

theorem identity2256 : scanCanonicalize (H12AffineFastState.compose env2256 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 135232) := by decide +kernel

theorem selectedBound2256 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1024,8693,135232,147673,147521,147830,8328,147473,409817,16385,151552,2080,148728,0,256,0,131072,773]

theorem envBound2257 : H12AffineFastState.Bounded env2257 := by
  intro p hp
  have h : env2257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2256_2257 : H12AffineEnvironment.transform 20 135232 env2256 = env2257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 135232 env2256 == env2257) = true)

theorem identity2257 : scanCanonicalize (H12AffineFastState.compose env2257 (packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 2524) := by decide +kernel

theorem selectedBound2257 : packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env2258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,2524,1024,8693,135232,147673,147521,147830,8328,147473,149765,16385,151552,2080,148728,0,256,0,131072,773]

theorem envBound2258 : H12AffineFastState.Bounded env2258 := by
  intro p hp
  have h : env2258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2257_2258 : H12AffineEnvironment.transform 17 2524 env2257 = env2258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2524 env2257 == env2258) = true)

theorem identity2258 : scanCanonicalize (H12AffineFastState.compose env2258 (packedSelected [1,5,8,17,18,21,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 16633) := by decide +kernel

theorem selectedBound2258 : packedSelected [1,5,8,17,18,21,23,24] rootPS < 2^1333 := by decide +kernel

def env2259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,16633,2524,1024,8693,20665,32,184,399,8328,232,2556,16385,4345,2080,1025,0,256,0,16633,773]

theorem envBound2259 : H12AffineFastState.Bounded env2259 := by
  intro p hp
  have h : env2259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2258_2259 : H12AffineEnvironment.transform 16 16633 env2258 = env2259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env2258 == env2259) = true)

theorem identity2259 : scanCanonicalize (H12AffineFastState.compose env2259 (packedSelected [2,6,12,13,18] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound2259 : packedSelected [2,6,12,13,18] rootPS < 2^1333 := by decide +kernel

def env2260 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8433,8314,16633,2264,1024,8433,20665,32,184,139,8328,232,2296,16385,4345,2080,1025,0,4,0,16633,513]

theorem envBound2260 : H12AffineFastState.Bounded env2260 := by
  intro p hp
  have h : env2260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2259_2260 : H12AffineEnvironment.transform 7 4 env2259 = env2260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env2259 == env2260) = true)

theorem identity2260 : scanCanonicalize (H12AffineFastState.compose env2260 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(13+1) ^^^ 3767) := by decide +kernel

theorem selectedBound2260 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env2261 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,3767,8433,8314,3662,2264,1024,8433,7694,32,184,139,8328,232,2296,3766,4345,2080,1025,0,4,0,3662,513]

theorem envBound2261 : H12AffineFastState.Bounded env2261 := by
  intro p hp
  have h : env2261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2260_2261 : H12AffineEnvironment.transform 13 3767 env2260 = env2261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3767 env2260 == env2261) = true)

theorem identity2261 : scanCanonicalize (H12AffineFastState.compose env2261 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1751) := by decide +kernel

theorem selectedBound2261 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env2262 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1751,4096,8192,96,8433,8314,153,1551,1024,8433,4313,32,184,139,8328,232,1583,97,4345,1783,1025,0,4,0,153,513]

theorem envBound2262 : H12AffineFastState.Bounded env2262 := by
  intro p hp
  have h : env2262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2261_2262 : H12AffineEnvironment.transform 10 1751 env2261 = env2262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1751 env2261 == env2262) = true)

theorem identity2262 : scanCanonicalize (H12AffineFastState.compose env2262 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1156) := by decide +kernel

theorem selectedBound2262 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2263 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1751,4096,1156,96,1141,1278,153,1551,1024,1141,4313,32,184,139,1036,232,1583,97,4345,1783,1025,0,4,0,153,513]

theorem envBound2263 : H12AffineFastState.Bounded env2263 := by
  intro p hp
  have h : env2263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2262_2263 : H12AffineEnvironment.transform 12 1156 env2262 = env2263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1156 env2262 == env2263) = true)

theorem identity2263 : scanCanonicalize (H12AffineFastState.compose env2263 (packedSelected [0,1,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 1751) := by decide +kernel

theorem selectedBound2263 : packedSelected [0,1,5,9] rootPS < 2^1333 := by decide +kernel

def env2264 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1751,1751,1156,96,1141,1278,153,1551,1024,1141,1550,32,184,139,1036,232,1583,97,1582,1783,1025,0,4,0,153,513]

theorem envBound2264 : H12AffineFastState.Bounded env2264 := by
  intro p hp
  have h : env2264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2263_2264 : H12AffineEnvironment.transform 11 1751 env2263 = env2264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1751 env2263 == env2264) = true)

theorem identity2264 : scanCanonicalize (H12AffineFastState.compose env2264 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 646) := by decide +kernel

theorem selectedBound2264 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env2265 : List Nat := [2,4,8,16,32,64,128,4,512,646,81,81,514,96,755,632,153,137,646,755,136,32,184,139,650,232,169,97,168,113,647,0,4,0,153,513]

theorem envBound2265 : H12AffineFastState.Bounded env2265 := by
  intro p hp
  have h : env2265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2264_2265 : H12AffineEnvironment.transform 9 646 env2264 = env2265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 646 env2264 == env2265) = true)

theorem identity2265 : scanCanonicalize (H12AffineFastState.compose env2265 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound2265 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2266 : List Nat := [2,4,8,16,32,64,121,4,512,639,81,81,514,96,522,632,96,112,639,522,113,32,65,114,627,17,80,97,81,113,638,0,4,0,96,513]

theorem envBound2266 : H12AffineFastState.Bounded env2266 := by
  intro p hp
  have h : env2266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2265_2266 : H12AffineEnvironment.transform 6 121 env2265 = env2266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env2265 == env2266) = true)

theorem identity2266 : scanCanonicalize (H12AffineFastState.compose env2266 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 107) := by decide +kernel

theorem selectedBound2266 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2267 : List Nat := [2,4,8,16,32,64,121,4,107,20,81,81,105,96,97,19,96,112,20,97,113,32,65,114,24,17,80,97,81,113,21,0,4,0,96,106]

theorem envBound2267 : H12AffineFastState.Bounded env2267 := by
  intro p hp
  have h : env2267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2266_2267 : H12AffineEnvironment.transform 8 107 env2266 = env2267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 107 env2266 == env2267) = true)

theorem identity2267 : scanCanonicalize (H12AffineFastState.compose env2267 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound2267 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env2268 : List Nat := [2,4,8,1,32,64,104,4,107,5,64,64,105,96,97,2,96,97,5,97,96,32,65,99,9,0,65,97,64,96,4,0,4,0,96,106]

theorem envBound2268 : H12AffineFastState.Bounded env2268 := by
  intro p hp
  have h : env2268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2267_2268 : H12AffineEnvironment.transform 3 1 env2267 = env2268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env2267 == env2268) = true)

theorem identity2268 : scanCanonicalize (H12AffineFastState.compose env2268 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound2268 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env2269 : List Nat := [2,4,8,1,32,32,8,4,11,5,32,32,9,0,1,2,0,1,5,1,0,32,33,3,9,0,33,1,32,0,4,0,4,0,0,10]

theorem envBound2269 : H12AffineFastState.Bounded env2269 := by
  intro p hp
  have h : env2269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2268_2269 : H12AffineEnvironment.transform 5 32 env2268 = env2269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env2268 == env2269) = true)

theorem identity2269 : scanCanonicalize (H12AffineFastState.compose env2269 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound2269 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2270 : List Nat := [2,4,8,1,2,2,8,4,11,5,2,2,9,0,1,2,0,1,5,1,0,2,3,3,9,0,3,1,2,0,4,0,4,0,0,10]

theorem envBound2270 : H12AffineFastState.Bounded env2270 := by
  intro p hp
  have h : env2270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2269_2270 : H12AffineEnvironment.transform 4 2 env2269 = env2270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env2269 == env2270) = true)

theorem identity2270 : scanCanonicalize (H12AffineFastState.compose env2270 (packedSelected [11] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound2270 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env2271 : List Nat := [1,4,8,1,1,1,8,4,8,5,1,1,9,0,1,1,0,1,5,1,0,1,0,0,9,0,0,1,1,0,4,0,4,0,0,9]

theorem envBound2271 : H12AffineFastState.Bounded env2271 := by
  intro p hp
  have h : env2271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2270_2271 : H12AffineEnvironment.transform 0 1 env2270 = env2271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env2270 == env2271) = true)

theorem identity2271 : scanCanonicalize (H12AffineFastState.compose env2271 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound2271 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2272 : List Nat := [1,4,4,1,1,1,4,4,4,5,1,1,5,0,1,1,0,1,5,1,0,1,0,0,5,0,0,1,1,0,4,0,4,0,0,5]

theorem envBound2272 : H12AffineFastState.Bounded env2272 := by
  intro p hp
  have h : env2272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2271_2272 : H12AffineEnvironment.transform 2 4 env2271 = env2272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env2271 == env2272) = true)

def env2273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147473,409817,16385,151552,2080,16852468,4341977,256,0,131073,16925299]

theorem envBound2273 : H12AffineFastState.Bounded env2273 := by
  intro p hp
  have h : env2273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2250_2273 : H12AffineEnvironment.transform 34 131073 env2250 = env2273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2250 == env2273) = true)

theorem identity2273 : scanCanonicalize (H12AffineFastState.compose env2273 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4325870) := by decide +kernel

theorem selectedBound2273 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,4325870,8328,147473,409817,16385,151552,2080,4400154,4341977,256,0,131073,4211613]

theorem envBound2274 : H12AffineFastState.Bounded env2274 := by
  intro p hp
  have h : env2274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2273_2274 : H12AffineEnvironment.transform 23 4325870 env2273 = env2274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4325870 env2273 == env2274) = true)

theorem identity2274 : scanCanonicalize (H12AffineFastState.compose env2274 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound2274 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,293,147521,131275,8328,147473,409817,16385,151552,2080,206143,147964,256,0,131073,17080]

theorem envBound2275 : H12AffineFastState.Bounded env2275 := by
  intro p hp
  have h : env2275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2274_2275 : H12AffineEnvironment.transform 21 293 env2274 = env2275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env2274 == env2275) = true)

def env2276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,184,8693,65536,131072,262144,1024,8693,2097152,293,131321,131275,8328,131241,393313,185,135352,2080,206143,131396,256,0,131073,512]

theorem envBound2276 : H12AffineFastState.Bounded env2276 := by
  intro p hp
  have h : env2276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2275_2276 : H12AffineEnvironment.transform 13 184 env2275 = env2276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env2275 == env2276) = true)

theorem identity2276 : scanCanonicalize (H12AffineFastState.compose env2276 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound2276 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2277 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,184,8432,65536,131072,262144,1024,8432,2097152,32,131321,131275,8328,131241,393313,185,135352,2080,205882,131137,5,0,131073,512]

theorem envBound2277 : H12AffineFastState.Bounded env2277 := by
  intro p hp
  have h : env2277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2276_2277 : H12AffineEnvironment.transform 7 5 env2276 = env2277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env2276 == env2277) = true)

theorem identity2277 : scanCanonicalize (H12AffineFastState.compose env2277 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound2277 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2278 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,184,8432,8314,131072,262144,1024,8432,2097152,32,131321,131275,8328,131241,393313,185,135352,2080,132160,131137,5,0,131073,512]

theorem envBound2278 : H12AffineFastState.Bounded env2278 := by
  intro p hp
  have h : env2278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2277_2278 : H12AffineEnvironment.transform 15 8314 env2277 = env2278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env2277 == env2278) = true)

theorem identity2278 : scanCanonicalize (H12AffineFastState.compose env2278 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(16+1) ^^^ 65) := by decide +kernel

theorem selectedBound2278 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2279 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,184,8432,8314,65,262144,1024,8432,2097152,32,184,138,8328,232,262176,185,4345,2080,1025,0,5,0,64,512]

theorem envBound2279 : H12AffineFastState.Bounded env2279 := by
  intro p hp
  have h : env2279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2278_2279 : H12AffineEnvironment.transform 16 65 env2278 = env2279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 65 env2278 == env2279) = true)

theorem identity2279 : scanCanonicalize (H12AffineFastState.compose env2279 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 11438) := by decide +kernel

theorem selectedBound2279 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env2280 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,184,8432,8314,65,262144,1024,8432,11438,32,184,138,8328,232,262176,185,4345,2080,1025,0,5,0,64,512]

theorem envBound2280 : H12AffineFastState.Bounded env2280 := by
  intro p hp
  have h : env2280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2279_2280 : H12AffineEnvironment.transform 20 11438 env2279 = env2280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11438 env2279 == env2280) = true)

theorem identity2280 : scanCanonicalize (H12AffineFastState.compose env2280 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound2280 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env2281 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,184,8432,8314,65,2264,1024,8432,11438,32,184,138,8328,232,2296,185,4345,2080,1025,0,5,0,64,512]

theorem envBound2281 : H12AffineFastState.Bounded env2281 := by
  intro p hp
  have h : env2281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2280_2281 : H12AffineEnvironment.transform 17 2264 env2280 = env2281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env2280 == env2281) = true)

theorem identity2281 : scanCanonicalize (H12AffineFastState.compose env2281 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound2281 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env2282 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,4096,8192,64,8200,8314,65,2080,1024,8200,11350,32,64,114,8304,16,2048,65,4097,2080,1025,0,5,0,64,512]

theorem envBound2282 : H12AffineFastState.Bounded env2282 := by
  intro p hp
  have h : env2282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2281_2282 : H12AffineEnvironment.transform 6 120 env2281 = env2282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env2281 == env2282) = true)

theorem identity2282 : scanCanonicalize (H12AffineFastState.compose env2282 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound2282 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2283 : List Nat := [2,4,8,16,32,1,57,5,512,1024,2048,4096,8192,1,8200,8251,0,2080,1024,8200,11287,32,1,51,8241,16,2048,0,4097,2080,1025,0,5,0,1,512]

theorem envBound2283 : H12AffineFastState.Bounded env2283 := by
  intro p hp
  have h : env2283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2282_2283 : H12AffineEnvironment.transform 5 1 env2282 = env2283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2282 == env2283) = true)

theorem identity2283 : scanCanonicalize (H12AffineFastState.compose env2283 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound2283 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2284 : List Nat := [2,4,8,16,32,1,57,5,512,1024,43,4096,8192,1,8200,8251,0,11,1024,8200,9276,32,1,51,8241,16,43,0,4097,11,1025,0,5,0,1,512]

theorem envBound2284 : H12AffineFastState.Bounded env2284 := by
  intro p hp
  have h : env2284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2283_2284 : H12AffineEnvironment.transform 10 43 env2283 = env2284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env2283 == env2284) = true)

theorem identity2284 : scanCanonicalize (H12AffineFastState.compose env2284 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound2284 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2285 : List Nat := [2,4,8,16,32,1,57,5,512,1024,43,4096,1030,1,1038,1085,0,11,1024,1038,58,32,1,51,1079,16,43,0,4097,11,1025,0,5,0,1,512]

theorem envBound2285 : H12AffineFastState.Bounded env2285 := by
  intro p hp
  have h : env2285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2284_2285 : H12AffineEnvironment.transform 12 1030 env2284 = env2285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env2284 == env2285) = true)

theorem identity2285 : scanCanonicalize (H12AffineFastState.compose env2285 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound2285 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env2286 : List Nat := [2,4,8,16,17,1,8,5,512,1024,26,4096,1030,1,1038,1036,0,11,1024,1038,11,17,1,2,1030,16,26,0,4097,11,1025,0,5,0,1,512]

theorem envBound2286 : H12AffineFastState.Bounded env2286 := by
  intro p hp
  have h : env2286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2285_2286 : H12AffineEnvironment.transform 4 17 env2285 = env2286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env2285 == env2286) = true)

theorem identity2286 : scanCanonicalize (H12AffineFastState.compose env2286 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound2286 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env2287 : List Nat := [2,4,8,1,0,1,8,5,512,1024,11,4096,1030,1,1038,1036,0,11,1024,1038,11,0,1,2,1030,1,11,0,4097,11,1025,0,5,0,1,512]

theorem envBound2287 : H12AffineFastState.Bounded env2287 := by
  intro p hp
  have h : env2287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2286_2287 : H12AffineEnvironment.transform 3 1 env2286 = env2287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env2286 == env2287) = true)

def env2288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,185,8693,65536,131072,262144,1024,8693,2097152,293,131320,131275,8328,131240,393312,184,135353,2080,206143,131397,256,0,131073,513]

theorem envBound2288 : H12AffineFastState.Bounded env2288 := by
  intro p hp
  have h : env2288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2275_2288 : H12AffineEnvironment.transform 13 185 env2275 = env2288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env2275 == env2288) = true)

theorem identity2288 : scanCanonicalize (H12AffineFastState.compose env2288 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4437) := by decide +kernel

theorem selectedBound2288 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,185,8693,65536,131072,262144,1024,8693,4437,293,131320,131275,8328,131240,393312,184,135353,2080,206143,131397,256,0,131073,513]

theorem envBound2289 : H12AffineFastState.Bounded env2289 := by
  intro p hp
  have h : env2289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2288_2289 : H12AffineEnvironment.transform 20 4437 env2288 = env2289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4437 env2288 == env2289) = true)

theorem identity2289 : scanCanonicalize (H12AffineFastState.compose env2289 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 73787) := by decide +kernel

theorem selectedBound2289 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,185,8693,65536,73787,262144,1024,8693,4437,293,73923,73968,8328,73875,335963,184,77954,2080,1284,74110,256,0,73786,513]

theorem envBound2290 : H12AffineFastState.Bounded env2290 := by
  intro p hp
  have h : env2290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2289_2290 : H12AffineEnvironment.transform 16 73787 env2289 = env2290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 73787 env2289 == env2290) = true)

theorem identity2290 : scanCanonicalize (H12AffineFastState.compose env2290 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound2290 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env2291 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,185,8201,65536,73787,262144,1024,8201,4265,217,73923,73968,8328,73875,335963,184,77954,2080,1272,73858,252,0,73786,513]

theorem envBound2291 : H12AffineFastState.Bounded env2291 := by
  intro p hp
  have h : env2291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2290_2291 : H12AffineEnvironment.transform 7 252 env2290 = env2291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2290 == env2291) = true)

theorem identity2291 : scanCanonicalize (H12AffineFastState.compose env2291 (packedSelected [1,3,4,9,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound2291 : packedSelected [1,3,4,9,20,24,28] rootPS < 2^1333 := by decide +kernel

def env2292 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,185,8201,8322,185,262144,1024,8201,4265,217,65,114,8328,17,262361,184,4096,2080,1272,0,252,0,184,513]

theorem envBound2292 : H12AffineFastState.Bounded env2292 := by
  intro p hp
  have h : env2292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2291_2292 : H12AffineEnvironment.transform 15 8322 env2291 = env2292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env2291 == env2292) = true)

theorem identity2292 : scanCanonicalize (H12AffineFastState.compose env2292 (packedSelected [0,3,5,7,10,13,17,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound2292 : packedSelected [0,3,5,7,10,13,17,20] rootPS < 2^1333 := by decide +kernel

def env2293 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1,8192,185,8201,8322,185,262144,1024,8201,168,217,65,114,8328,17,262361,184,1,2080,1272,0,252,0,184,513]

theorem envBound2293 : H12AffineFastState.Bounded env2293 := by
  intro p hp
  have h : env2293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2292_2293 : H12AffineEnvironment.transform 11 1 env2292 = env2293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env2292 == env2293) = true)

theorem identity2293 : scanCanonicalize (H12AffineFastState.compose env2293 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 1069) := by decide +kernel

theorem selectedBound2293 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env2294 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1,1069,185,1060,1199,185,262144,1024,1060,168,217,65,114,1189,17,262361,184,1,2080,1272,0,252,0,184,513]

theorem envBound2294 : H12AffineFastState.Bounded env2294 := by
  intro p hp
  have h : env2294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2293_2294 : H12AffineEnvironment.transform 12 1069 env2293 = env2294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1069 env2293 == env2294) = true)

theorem identity2294 : scanCanonicalize (H12AffineFastState.compose env2294 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound2294 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2295 : List Nat := [2,4,8,16,32,64,128,252,512,116,2048,1,89,185,80,219,185,262144,116,80,168,217,65,114,209,17,262361,184,1,2080,140,0,252,0,184,513]

theorem envBound2295 : H12AffineFastState.Bounded env2295 := by
  intro p hp
  have h : env2295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2294_2295 : H12AffineEnvironment.transform 9 116 env2294 = env2295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env2294 == env2295) = true)

theorem identity2295 : scanCanonicalize (H12AffineFastState.compose env2295 (packedSelected [0,1,3,5,7,8,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 2296) := by decide +kernel

theorem selectedBound2295 : packedSelected [0,1,3,5,7,8,12,13] rootPS < 2^1333 := by decide +kernel

def env2296 : List Nat := [2,4,8,16,32,64,128,252,512,116,2048,1,89,185,80,219,185,2296,116,80,168,217,65,114,209,17,2081,184,1,2080,140,0,252,0,184,513]

theorem envBound2296 : H12AffineFastState.Bounded env2296 := by
  intro p hp
  have h : env2296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2295_2296 : H12AffineEnvironment.transform 17 2296 env2295 = env2296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2296 env2295 == env2296) = true)

theorem identity2296 : scanCanonicalize (H12AffineFastState.compose env2296 (packedSelected [0,1,3,5,6,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound2296 : packedSelected [0,1,3,5,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env2297 : List Nat := [2,4,8,16,32,64,128,252,512,116,16,1,89,185,80,219,185,232,116,80,168,217,65,114,209,17,49,184,1,48,140,0,252,0,184,513]

theorem envBound2297 : H12AffineFastState.Bounded env2297 := by
  intro p hp
  have h : env2297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2296_2297 : H12AffineEnvironment.transform 10 16 env2296 = env2297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env2296 == env2297) = true)

theorem identity2297 : scanCanonicalize (H12AffineFastState.compose env2297 (packedSelected [0,1,6,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2297 : packedSelected [0,1,6,7,8] rootPS < 2^1333 := by decide +kernel

def env2298 : List Nat := [2,4,8,16,32,64,40,84,512,116,16,1,89,17,80,115,17,64,116,80,0,113,65,114,121,17,49,16,1,48,36,0,84,0,16,513]

theorem envBound2298 : H12AffineFastState.Bounded env2298 := by
  intro p hp
  have h : env2298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2297_2298 : H12AffineEnvironment.transform 6 40 env2297 = env2298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2297 == env2298) = true)

theorem identity2298 : scanCanonicalize (H12AffineFastState.compose env2298 (packedSelected [1,3,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound2298 : packedSelected [1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env2299 : List Nat := [2,4,8,16,22,64,30,84,512,66,16,1,89,17,80,69,17,64,66,80,0,71,65,68,79,17,7,16,1,6,18,0,84,0,16,513]

theorem envBound2299 : H12AffineFastState.Bounded env2299 := by
  intro p hp
  have h : env2299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2298_2299 : H12AffineEnvironment.transform 4 22 env2298 = env2299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env2298 == env2299) = true)

theorem identity2299 : scanCanonicalize (H12AffineFastState.compose env2299 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound2299 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env2300 : List Nat := [2,4,8,16,22,64,30,84,90,66,16,1,89,17,80,69,17,64,66,80,0,71,65,68,79,17,7,16,1,6,18,0,84,0,16,91]

theorem envBound2300 : H12AffineFastState.Bounded env2300 := by
  intro p hp
  have h : env2300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2299_2300 : H12AffineEnvironment.transform 8 90 env2299 = env2300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env2299 == env2300) = true)

theorem identity2300 : scanCanonicalize (H12AffineFastState.compose env2300 (packedSelected [0,1,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound2300 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env2301 : List Nat := [0,4,8,16,20,64,28,84,88,64,16,1,89,17,80,69,17,64,64,80,0,69,65,68,77,17,5,16,1,4,16,0,84,0,16,89]

theorem envBound2301 : H12AffineFastState.Bounded env2301 := by
  intro p hp
  have h : env2301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2300_2301 : H12AffineEnvironment.transform 0 0 env2300 = env2301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env2300 == env2301) = true)

def env2302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147472,409816,16385,151552,2080,16852469,4341976,257,0,34359738368,16925298]

theorem envBound2302 : H12AffineFastState.Bounded env2302 := by
  intro p hp
  have h : env2302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2249_2302 : H12AffineEnvironment.transform 18 1025 env2249 = env2302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env2249 == env2302) = true)

def env2303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147472,409816,16385,151552,2080,16852469,4341976,257,0,131072,16925298]

theorem envBound2303 : H12AffineFastState.Bounded env2303 := by
  intro p hp
  have h : env2303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2302_2303 : H12AffineEnvironment.transform 34 131072 env2302 = env2303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2302 == env2303) = true)

theorem identity2303 : scanCanonicalize (H12AffineFastState.compose env2303 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 6296750) := by decide +kernel

theorem selectedBound2303 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,6296750,8328,147472,409816,16385,151552,2080,6369627,4341976,257,0,131072,6444764]

theorem envBound2304 : H12AffineFastState.Bounded env2304 := by
  intro p hp
  have h : env2304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2303_2304 : H12AffineEnvironment.transform 23 6296750 env2303 = env2304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6296750 env2303 == env2304) = true)

theorem identity2304 : scanCanonicalize (H12AffineFastState.compose env2304 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 2102309) := by decide +kernel

theorem selectedBound2304 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,2102309,147521,139,8328,147472,409816,16385,151552,2080,75134,2249981,257,0,131072,148217]

theorem envBound2305 : H12AffineFastState.Bounded env2305 := by
  intro p hp
  have h : env2305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2304_2305 : H12AffineEnvironment.transform 21 2102309 env2304 = env2305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2102309 env2304 == env2305) = true)

def env2306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16632,262144,1025,8693,2097152,2102309,185,139,8328,232,262176,16385,4344,2080,75134,2102277,257,0,16632,513]

theorem envBound2306 : H12AffineFastState.Bounded env2306 := by
  intro p hp
  have h : env2306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2305_2306 : H12AffineEnvironment.transform 16 16632 env2305 = env2306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env2305 == env2306) = true)

theorem identity2306 : scanCanonicalize (H12AffineFastState.compose env2306 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound2306 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2307 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,4096,8192,16384,8693,65536,16632,262144,84,8693,2097152,2101360,185,139,8328,232,262176,16385,4344,2080,74027,2101328,257,0,16632,513]

theorem envBound2307 : H12AffineFastState.Bounded env2307 := by
  intro p hp
  have h : env2307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2306_2307 : H12AffineEnvironment.transform 9 85 env2306 = env2307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env2306 == env2307) = true)

theorem identity2307 : scanCanonicalize (H12AffineFastState.compose env2307 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 4264) := by decide +kernel

theorem selectedBound2307 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env2308 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,4096,8192,16384,8693,65536,16632,262144,84,8693,4264,216,185,139,8328,232,262176,16385,4344,2080,74027,248,257,0,16632,513]

theorem envBound2308 : H12AffineFastState.Bounded env2308 := by
  intro p hp
  have h : env2308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2307_2308 : H12AffineEnvironment.transform 20 4264 env2307 = env2308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4264 env2307 == env2308) = true)

theorem identity2308 : scanCanonicalize (H12AffineFastState.compose env2308 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8583) := by decide +kernel

theorem selectedBound2308 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2309 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,4096,8192,16384,8693,8583,16632,262144,84,8693,4264,216,185,139,8328,232,262176,16385,4344,2080,172,248,257,0,16632,513]

theorem envBound2309 : H12AffineFastState.Bounded env2309 := by
  intro p hp
  have h : env2309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2308_2309 : H12AffineEnvironment.transform 15 8583 env2308 = env2309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8583 env2308 == env2309) = true)

theorem identity2309 : scanCanonicalize (H12AffineFastState.compose env2309 (packedSelected [13,17] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2309 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env2310 : List Nat := [2,4,8,16,32,64,40,256,512,85,2048,4096,8192,16384,8541,8495,16464,262144,84,8541,4096,112,17,35,8224,64,262176,16385,4176,2080,4,80,257,0,16464,513]

theorem envBound2310 : H12AffineFastState.Bounded env2310 := by
  intro p hp
  have h : env2310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2309_2310 : H12AffineEnvironment.transform 6 40 env2309 = env2310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2309 == env2310) = true)

theorem identity2310 : scanCanonicalize (H12AffineFastState.compose env2310 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 22640) := by decide +kernel

theorem selectedBound2310 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env2311 : List Nat := [2,4,8,16,32,64,40,256,512,85,2048,4096,8192,16384,8541,8495,16464,22640,84,8541,4096,112,17,35,8224,64,22608,16385,4176,2080,4,80,257,0,16464,513]

theorem envBound2311 : H12AffineFastState.Bounded env2311 := by
  intro p hp
  have h : env2311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2310_2311 : H12AffineEnvironment.transform 17 22640 env2310 = env2311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22640 env2310 == env2311) = true)

theorem identity2311 : scanCanonicalize (H12AffineFastState.compose env2311 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2423) := by decide +kernel

theorem selectedBound2311 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env2312 : List Nat := [2,4,8,16,32,64,40,256,512,85,2048,4096,2423,16384,2090,2136,16464,22640,84,2090,4096,112,17,35,2391,64,22608,16385,4176,2080,4,80,257,0,16464,513]

theorem envBound2312 : H12AffineFastState.Bounded env2312 := by
  intro p hp
  have h : env2312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2311_2312 : H12AffineEnvironment.transform 12 2423 env2311 = env2312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2423 env2311 == env2312) = true)

theorem identity2312 : scanCanonicalize (H12AffineFastState.compose env2312 (packedSelected [1,2,3,5,6,8,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 6160) := by decide +kernel

theorem selectedBound2312 : packedSelected [1,2,3,5,6,8,12,15] rootPS < 2^1333 := by decide +kernel

def env2313 : List Nat := [2,4,8,16,32,64,40,256,512,85,2048,4096,2423,6160,2090,2136,6208,96,84,2090,4096,112,17,35,2391,64,64,6161,4176,2080,4,80,257,0,6208,513]

theorem envBound2313 : H12AffineFastState.Bounded env2313 := by
  intro p hp
  have h : env2313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2312_2313 : H12AffineEnvironment.transform 13 6160 env2312 = env2313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6160 env2312 == env2313) = true)

theorem identity2313 : scanCanonicalize (H12AffineFastState.compose env2313 (packedSelected [2,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound2313 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env2314 : List Nat := [2,4,8,16,32,0,40,256,512,21,2048,4096,2359,6160,2090,2072,6144,32,20,2090,4096,48,17,35,2327,0,0,6161,4112,2080,4,16,257,0,6144,513]

theorem envBound2314 : H12AffineFastState.Bounded env2314 := by
  intro p hp
  have h : env2314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2313_2314 : H12AffineEnvironment.transform 5 0 env2313 = env2314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env2313 == env2314) = true)

theorem identity2314 : scanCanonicalize (H12AffineFastState.compose env2314 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound2314 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env2315 : List Nat := [2,4,8,16,32,0,40,256,512,21,17,4096,294,4097,59,9,4113,32,20,59,4096,48,17,35,262,0,0,4096,4112,49,4,16,257,0,4113,513]

theorem envBound2315 : H12AffineFastState.Bounded env2315 := by
  intro p hp
  have h : env2315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2314_2315 : H12AffineEnvironment.transform 10 17 env2314 = env2315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env2314 == env2315) = true)

theorem identity2315 : scanCanonicalize (H12AffineFastState.compose env2315 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound2315 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env2316 : List Nat := [2,4,8,16,32,0,40,256,512,21,17,261,294,260,59,9,276,32,20,59,261,48,17,35,262,0,0,261,277,49,4,16,257,0,276,513]

theorem envBound2316 : H12AffineFastState.Bounded env2316 := by
  intro p hp
  have h : env2316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2315_2316 : H12AffineEnvironment.transform 11 261 env2315 = env2316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env2315 == env2316) = true)

theorem identity2316 : scanCanonicalize (H12AffineFastState.compose env2316 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound2316 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env2317 : List Nat := [2,4,8,16,32,0,40,62,512,21,17,59,24,58,59,9,42,32,20,59,59,48,17,35,56,0,0,59,43,49,4,16,63,0,42,513]

theorem envBound2317 : H12AffineFastState.Bounded env2317 := by
  intro p hp
  have h : env2317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2316_2317 : H12AffineEnvironment.transform 7 62 env2316 = env2317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env2316 == env2317) = true)

theorem identity2317 : scanCanonicalize (H12AffineFastState.compose env2317 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound2317 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2318 : List Nat := [2,4,8,16,32,0,40,62,32,21,17,59,24,58,59,9,42,32,20,59,59,48,17,35,56,0,0,59,43,49,4,16,63,0,42,33]

theorem envBound2318 : H12AffineFastState.Bounded env2318 := by
  intro p hp
  have h : env2318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2317_2318 : H12AffineEnvironment.transform 8 32 env2317 = env2318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env2317 == env2318) = true)

theorem identity2318 : scanCanonicalize (H12AffineFastState.compose env2318 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound2318 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env2319 : List Nat := [2,4,8,2,32,0,40,44,32,7,3,41,10,40,41,9,42,32,6,41,41,34,3,35,42,0,0,41,43,35,4,2,45,0,42,33]

theorem envBound2319 : H12AffineFastState.Bounded env2319 := by
  intro p hp
  have h : env2319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2318_2319 : H12AffineEnvironment.transform 3 2 env2318 = env2319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env2318 == env2319) = true)

theorem identity2319 : scanCanonicalize (H12AffineFastState.compose env2319 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound2319 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env2320 : List Nat := [2,4,1,2,32,0,33,37,32,7,3,32,3,33,32,0,35,32,6,32,32,34,3,35,35,0,0,32,34,35,4,2,36,0,35,33]

theorem envBound2320 : H12AffineFastState.Bounded env2320 := by
  intro p hp
  have h : env2320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2319_2320 : H12AffineEnvironment.transform 2 1 env2319 = env2320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env2319 == env2320) = true)

theorem identity2320 : scanCanonicalize (H12AffineFastState.compose env2320 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound2320 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2321 : List Nat := [2,4,1,2,5,0,4,0,5,7,3,5,3,4,5,0,6,5,6,5,5,7,3,6,6,0,0,5,7,6,4,2,1,0,6,4]

theorem envBound2321 : H12AffineFastState.Bounded env2321 := by
  intro p hp
  have h : env2321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2320_2321 : H12AffineEnvironment.transform 4 5 env2320 = env2321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env2320 == env2321) = true)

theorem identity2321 : scanCanonicalize (H12AffineFastState.compose env2321 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound2321 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2322 : List Nat := [2,2,1,2,3,0,2,0,3,1,3,3,3,2,3,0,0,3,0,3,3,1,3,0,0,0,0,3,1,0,2,2,1,0,0,2]

theorem envBound2322 : H12AffineFastState.Bounded env2322 := by
  intro p hp
  have h : env2322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2321_2322 : H12AffineEnvironment.transform 1 2 env2321 = env2322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env2321 == env2322) = true)

theorem identity2322 : scanCanonicalize (H12AffineFastState.compose env2322 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound2322 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2323 : List Nat := [1,1,1,1,0,0,1,0,0,1,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,1,1,1,0,0,1]

theorem envBound2323 : H12AffineFastState.Bounded env2323 := by
  intro p hp
  have h : env2323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2322_2323 : H12AffineEnvironment.transform 0 1 env2322 = env2323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env2322 == env2323) = true)

def env2324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16633,262144,1025,8693,2097152,2102309,184,139,8328,233,262177,16385,4345,2080,75134,2102276,257,0,16633,512]

theorem envBound2324 : H12AffineFastState.Bounded env2324 := by
  intro p hp
  have h : env2324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2305_2324 : H12AffineEnvironment.transform 16 16633 env2305 = env2324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env2305 == env2324) = true)

theorem identity2324 : scanCanonicalize (H12AffineFastState.compose env2324 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 5124) := by decide +kernel

theorem selectedBound2324 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16633,262144,1025,8693,5124,33,184,139,8328,233,262177,16385,4345,2080,75134,0,257,0,16633,512]

theorem envBound2325 : H12AffineFastState.Bounded env2325 := by
  intro p hp
  have h : env2325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2324_2325 : H12AffineEnvironment.transform 20 5124 env2324 = env2325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5124 env2324 == env2325) = true)

theorem identity2325 : scanCanonicalize (H12AffineFastState.compose env2325 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound2325 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env2326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16633,262144,1025,8693,5124,33,184,139,8328,233,262177,16385,4345,2080,1024,0,257,0,16633,512]

theorem envBound2326 : H12AffineFastState.Bounded env2326 := by
  intro p hp
  have h : env2326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2325_2326 : H12AffineEnvironment.transform 15 8574 env2325 = env2326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env2325 == env2326) = true)

def env2327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147472,409816,16385,151552,2080,16852469,4341976,257,0,131073,16925298]

theorem envBound2327 : H12AffineFastState.Bounded env2327 := by
  intro p hp
  have h : env2327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2302_2327 : H12AffineEnvironment.transform 34 131073 env2302 = env2327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2302 == env2327) = true)

theorem identity2327 : scanCanonicalize (H12AffineFastState.compose env2327 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4195503) := by decide +kernel

theorem selectedBound2327 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,4195503,8328,147472,409816,16385,151552,2080,4268378,4341976,257,0,131073,4343517]

theorem envBound2328 : H12AffineFastState.Bounded env2328 := by
  intro p hp
  have h : env2328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2327_2328 : H12AffineEnvironment.transform 23 4195503 env2327 = env2328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4195503 env2327 == env2328) = true)

theorem identity2328 : scanCanonicalize (H12AffineFastState.compose env2328 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 9594) := by decide +kernel

theorem selectedBound2328 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,9594,131072,262144,1025,8693,2097152,4194304,147521,4195503,8328,147472,409816,16385,151552,2080,4195360,4341976,257,0,131073,4343517]

theorem envBound2329 : H12AffineFastState.Bounded env2329 := by
  intro p hp
  have h : env2329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2328_2329 : H12AffineEnvironment.transform 15 9594 env2328 = env2329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9594 env2328 == env2329) = true)

theorem identity2329 : scanCanonicalize (H12AffineFastState.compose env2329 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 148701) := by decide +kernel

theorem selectedBound2329 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env2330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,9594,131072,262144,1025,8693,2097152,148701,147521,147570,8328,147472,409816,16385,151552,2080,147709,1029,257,0,131073,512]

theorem envBound2330 : H12AffineFastState.Bounded env2330 := by
  intro p hp
  have h : env2330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2329_2330 : H12AffineEnvironment.transform 21 148701 env2329 = env2330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 148701 env2329 == env2330) = true)

theorem identity2330 : scanCanonicalize (H12AffineFastState.compose env2330 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 17660) := by decide +kernel

theorem selectedBound2330 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,9594,17660,262144,1025,8693,2097152,33,1213,1166,8328,1260,263204,16385,5372,2080,1025,1029,257,0,17661,512]

theorem envBound2331 : H12AffineFastState.Bounded env2331 := by
  intro p hp
  have h : env2331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2330_2331 : H12AffineEnvironment.transform 16 17660 env2330 = env2331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17660 env2330 == env2331) = true)

theorem identity2331 : scanCanonicalize (H12AffineFastState.compose env2331 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound2331 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2332 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8693,8574,16632,262144,5,8693,2097152,33,185,138,8328,232,262176,16385,4344,2080,5,1,257,0,16633,512]

theorem envBound2332 : H12AffineFastState.Bounded env2332 := by
  intro p hp
  have h : env2332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2331_2332 : H12AffineEnvironment.transform 9 4 env2331 = env2332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env2331 == env2332) = true)

theorem identity2332 : scanCanonicalize (H12AffineFastState.compose env2332 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound2332 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env2333 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8693,8574,16632,2080,5,8693,2097152,33,185,138,8328,232,2048,16385,4344,2080,5,1,257,0,16633,512]

theorem envBound2333 : H12AffineFastState.Bounded env2333 := by
  intro p hp
  have h : env2333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2332_2333 : H12AffineEnvironment.transform 17 2080 env2332 = env2333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env2332 == env2333) = true)

theorem identity2333 : scanCanonicalize (H12AffineFastState.compose env2333 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound2333 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env2334 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,16384,8201,8322,16632,2080,5,8201,2097152,33,185,138,8328,232,2048,16385,4344,2080,5,1,253,0,16633,512]

theorem envBound2334 : H12AffineFastState.Bounded env2334 := by
  intro p hp
  have h : env2334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2333_2334 : H12AffineEnvironment.transform 7 252 env2333 = env2334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2333 == env2334) = true)

theorem identity2334 : scanCanonicalize (H12AffineFastState.compose env2334 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(20+1) ^^^ 26826) := by decide +kernel

theorem selectedBound2334 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env2335 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,16384,8201,8322,16632,2080,5,8201,26826,33,185,138,8328,232,2048,16385,4344,2080,5,1,253,0,16633,512]

theorem envBound2335 : H12AffineFastState.Bounded env2335 := by
  intro p hp
  have h : env2335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2334_2335 : H12AffineEnvironment.transform 20 26826 env2334 = env2335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26826 env2334 == env2335) = true)

theorem identity2335 : scanCanonicalize (H12AffineFastState.compose env2335 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 12497) := by decide +kernel

theorem selectedBound2335 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env2336 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,12497,8201,8322,12329,2080,5,8201,6171,33,185,138,8328,232,2048,12496,4344,2080,5,1,253,0,12328,512]

theorem envBound2336 : H12AffineFastState.Bounded env2336 := by
  intro p hp
  have h : env2336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2335_2336 : H12AffineEnvironment.transform 13 12497 env2335 = env2336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12497 env2335 == env2336) = true)

theorem identity2336 : scanCanonicalize (H12AffineFastState.compose env2336 (packedSelected [0,1,2,3,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 2282) := by decide +kernel

theorem selectedBound2336 : packedSelected [0,1,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env2337 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,2282,6203,2275,2152,6339,2080,5,2275,6171,33,185,138,2146,232,2048,6202,4344,2080,5,1,253,0,6338,512]

theorem envBound2337 : H12AffineFastState.Bounded env2337 := by
  intro p hp
  have h : env2337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2336_2337 : H12AffineEnvironment.transform 12 2282 env2336 = env2337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2282 env2336 == env2337) = true)

theorem identity2337 : scanCanonicalize (H12AffineFastState.compose env2337 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2217) := by decide +kernel

theorem selectedBound2337 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env2338 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,2217,2282,146,2275,2152,106,2080,5,2275,178,33,185,138,2146,232,2048,147,2129,2080,5,1,253,0,107,512]

theorem envBound2338 : H12AffineFastState.Bounded env2338 := by
  intro p hp
  have h : env2338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2337_2338 : H12AffineEnvironment.transform 11 2217 env2337 = env2338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2217 env2337 == env2338) = true)

theorem identity2338 : scanCanonicalize (H12AffineFastState.compose env2338 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound2338 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2339 : List Nat := [2,4,8,16,32,64,128,252,512,4,58,147,208,146,217,82,106,26,5,217,178,33,185,138,88,232,58,147,107,26,5,1,253,0,107,512]

theorem envBound2339 : H12AffineFastState.Bounded env2339 := by
  intro p hp
  have h : env2339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2338_2339 : H12AffineEnvironment.transform 10 58 env2338 = env2339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env2338 == env2339) = true)

theorem identity2339 : scanCanonicalize (H12AffineFastState.compose env2339 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound2339 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env2340 : List Nat := [2,4,8,16,32,42,128,150,512,4,58,147,186,146,179,56,0,26,5,179,178,33,185,138,50,130,58,147,1,26,5,1,151,0,1,512]

theorem envBound2340 : H12AffineFastState.Bounded env2340 := by
  intro p hp
  have h : env2340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2339_2340 : H12AffineEnvironment.transform 5 42 env2339 = env2340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env2339 == env2340) = true)

theorem identity2340 : scanCanonicalize (H12AffineFastState.compose env2340 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound2340 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2341 : List Nat := [2,4,8,16,32,42,18,4,512,4,58,1,40,0,33,56,0,26,5,33,32,33,43,24,50,16,58,1,1,26,5,1,5,0,1,512]

theorem envBound2341 : H12AffineFastState.Bounded env2341 := by
  intro p hp
  have h : env2341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2340_2341 : H12AffineEnvironment.transform 6 18 env2340 = env2341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env2340 == env2341) = true)

theorem identity2341 : scanCanonicalize (H12AffineFastState.compose env2341 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound2341 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2342 : List Nat := [2,4,8,16,10,0,18,4,512,4,16,1,2,0,11,18,0,26,5,11,10,11,1,24,24,16,16,1,1,26,5,1,5,0,1,512]

theorem envBound2342 : H12AffineFastState.Bounded env2342 := by
  intro p hp
  have h : env2342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2341_2342 : H12AffineEnvironment.transform 4 10 env2341 = env2342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env2341 == env2342) = true)

theorem identity2342 : scanCanonicalize (H12AffineFastState.compose env2342 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound2342 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env2343 : List Nat := [2,4,8,11,10,0,9,4,512,4,11,1,2,0,11,9,0,1,5,11,10,11,1,3,3,11,11,1,1,1,5,1,5,0,1,512]

theorem envBound2343 : H12AffineFastState.Bounded env2343 := by
  intro p hp
  have h : env2343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2342_2343 : H12AffineEnvironment.transform 3 11 env2342 = env2343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env2342 == env2343) = true)

theorem identity2343 : scanCanonicalize (H12AffineFastState.compose env2343 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound2343 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env2344 : List Nat := [2,4,2,1,0,0,3,4,512,4,1,1,2,0,1,3,0,1,5,1,0,1,1,3,3,1,1,1,1,1,5,1,5,0,1,512]

theorem envBound2344 : H12AffineFastState.Bounded env2344 := by
  intro p hp
  have h : env2344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2343_2344 : H12AffineEnvironment.transform 2 2 env2343 = env2344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env2343 == env2344) = true)

theorem identity2344 : scanCanonicalize (H12AffineFastState.compose env2344 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound2344 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2345 : List Nat := [2,4,2,1,0,0,3,4,6,4,1,1,2,0,1,3,0,1,5,1,0,1,1,3,3,1,1,1,1,1,5,1,5,0,1,6]

theorem envBound2345 : H12AffineFastState.Bounded env2345 := by
  intro p hp
  have h : env2345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2344_2345 : H12AffineEnvironment.transform 8 6 env2344 = env2345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env2344 == env2345) = true)

def env2346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914001,9176216,268435456,268570625,268453921,17399808,281601388,525568,268451841,34359738368,25733063]

theorem envBound2346 : H12AffineFastState.Bounded env2346 := by
  intro p hp
  have h : env2346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1820_2346 : H12AffineEnvironment.transform 25 8914001 env1820 = env2346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env1820 == env2346) = true)

def env2347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914001,9176216,16384,151553,2081,17399808,13149548,525568,1,34359738368,25733063]

theorem envBound2347 : H12AffineFastState.Bounded env2347 := by
  intro p hp
  have h : env2347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2346_2347 : H12AffineEnvironment.transform 27 16384 env2346 = env2347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env2346 == env2347) = true)

def env2348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,16777216,8328,8914001,9176216,16384,151553,2081,17375732,13108376,525568,1,34359738368,25691699]

theorem envBound2348 : H12AffineFastState.Bounded env2348 := by
  intro p hp
  have h : env2348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2347_2348 : H12AffineEnvironment.transform 14 8692 env2347 = env2348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env2347 == env2348) = true)

def env2349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,147520,16777216,8328,672785,935128,16384,151553,2081,17375732,4867288,525568,1,34359738368,17450611]

theorem envBound2349 : H12AffineFastState.Bounded env2349 := by
  intro p hp
  have h : env2349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2348_2349 : H12AffineEnvironment.transform 22 147520 env2348 = env2349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env2348 == env2349) = true)

def env2350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147473,409816,16384,151553,2081,16852468,4341976,256,1,34359738368,16925299]

theorem envBound2350 : H12AffineFastState.Bounded env2350 := by
  intro p hp
  have h : env2350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2349_2350 : H12AffineEnvironment.transform 18 1024 env2349 = env2350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env2349 == env2350) = true)

def env2351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147473,409816,16384,151553,2081,16852468,4341976,256,1,131072,16925299]

theorem envBound2351 : H12AffineFastState.Bounded env2351 := by
  intro p hp
  have h : env2351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2350_2351 : H12AffineEnvironment.transform 34 131072 env2350 = env2351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2350 == env2351) = true)

theorem identity2351 : scanCanonicalize (H12AffineFastState.compose env2351 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 148851) := by decide +kernel

theorem selectedBound2351 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,148851,8328,147473,409816,16384,151553,2081,221319,4341976,256,1,131072,1792]

theorem envBound2352 : H12AffineFastState.Bounded env2352 := by
  intro p hp
  have h : env2352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2351_2352 : H12AffineEnvironment.transform 23 148851 env2351 = env2352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 148851 env2351 == env2352) = true)

theorem identity2352 : scanCanonicalize (H12AffineFastState.compose env2352 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 222374) := by decide +kernel

theorem selectedBound2352 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,222374,147520,148851,8328,147473,409816,16384,151553,2081,221319,74878,256,1,131072,1792]

theorem envBound2353 : H12AffineFastState.Bounded env2353 := by
  intro p hp
  have h : env2353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2352_2353 : H12AffineEnvironment.transform 21 222374 env2352 = env2353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 222374 env2352 == env2353) = true)

theorem identity2353 : scanCanonicalize (H12AffineFastState.compose env2353 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound2353 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env2354 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,131072,262144,256,8692,2097152,221606,147520,147571,8328,147473,409816,16384,151553,2081,221319,74110,256,1,131072,512]

theorem envBound2354 : H12AffineFastState.Bounded env2354 := by
  intro p hp
  have h : env2354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2353_2354 : H12AffineEnvironment.transform 9 256 env2353 = env2354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env2353 == env2354) = true)

theorem identity2354 : scanCanonicalize (H12AffineFastState.compose env2354 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90503) := by decide +kernel

theorem selectedBound2354 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2355 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,90503,262144,256,8692,2097152,33,74183,74228,8328,74134,336223,16384,78214,2081,256,74110,256,1,90503,512]

theorem envBound2355 : H12AffineFastState.Bounded env2355 := by
  intro p hp
  have h : env2355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2354_2355 : H12AffineEnvironment.transform 16 90503 env2354 = env2355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90503 env2354 == env2355) = true)

theorem identity2355 : scanCanonicalize (H12AffineFastState.compose env2355 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound2355 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2356 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,8574,16633,262144,256,8692,2097152,33,185,138,8328,232,262177,16384,4344,2081,256,0,256,1,16633,512]

theorem envBound2356 : H12AffineFastState.Bounded env2356 := by
  intro p hp
  have h : env2356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2355_2356 : H12AffineEnvironment.transform 15 8574 env2355 = env2356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env2355 == env2356) = true)

theorem identity2356 : scanCanonicalize (H12AffineFastState.compose env2356 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound2356 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env2357 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,8574,16633,2081,256,8692,2097152,33,185,138,8328,232,2048,16384,4344,2081,256,0,256,1,16633,512]

theorem envBound2357 : H12AffineFastState.Bounded env2357 := by
  intro p hp
  have h : env2357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2356_2357 : H12AffineEnvironment.transform 17 2081 env2356 = env2357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env2356 == env2357) = true)

theorem identity2357 : scanCanonicalize (H12AffineFastState.compose env2357 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound2357 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env2358 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,4096,8192,16384,8200,8322,16633,2081,252,8200,2097152,33,185,138,8328,232,2048,16384,4344,2081,252,0,252,1,16633,512]

theorem envBound2358 : H12AffineFastState.Bounded env2358 := by
  intro p hp
  have h : env2358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2357_2358 : H12AffineEnvironment.transform 7 252 env2357 = env2358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2357 == env2358) = true)

theorem identity2358 : scanCanonicalize (H12AffineFastState.compose env2358 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(20+1) ^^^ 26674) := by decide +kernel

theorem selectedBound2358 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env2359 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,4096,8192,16384,8200,8322,16633,2081,252,8200,26674,33,185,138,8328,232,2048,16384,4344,2081,252,0,252,1,16633,512]

theorem envBound2359 : H12AffineFastState.Bounded env2359 := by
  intro p hp
  have h : env2359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2358_2359 : H12AffineEnvironment.transform 20 26674 env2358 = env2359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26674 env2358 == env2359) = true)

theorem identity2359 : scanCanonicalize (H12AffineFastState.compose env2359 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 12497) := by decide +kernel

theorem selectedBound2359 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env2360 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,4096,8192,12497,8200,8322,12328,2081,252,8200,6371,33,185,138,8328,232,2048,12497,4344,2081,252,0,252,1,12328,512]

theorem envBound2360 : H12AffineFastState.Bounded env2360 := by
  intro p hp
  have h : env2360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2359_2360 : H12AffineEnvironment.transform 13 12497 env2359 = env2360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12497 env2359 == env2360) = true)

theorem identity2360 : scanCanonicalize (H12AffineFastState.compose env2360 (packedSelected [0,1,2,3,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 2282) := by decide +kernel

theorem selectedBound2360 : packedSelected [0,1,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env2361 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,4096,2282,6203,2274,2152,6338,2081,252,2274,6371,33,185,138,2146,232,2048,6203,4344,2081,252,0,252,1,6338,512]

theorem envBound2361 : H12AffineFastState.Bounded env2361 := by
  intro p hp
  have h : env2361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2360_2361 : H12AffineEnvironment.transform 12 2282 env2360 = env2361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2282 env2360 == env2361) = true)

theorem identity2361 : scanCanonicalize (H12AffineFastState.compose env2361 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2128) := by decide +kernel

theorem selectedBound2361 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env2362 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,2128,2282,107,2274,2152,146,2081,252,2274,179,33,185,138,2146,232,2048,107,2216,2081,252,0,252,1,146,512]

theorem envBound2362 : H12AffineFastState.Bounded env2362 := by
  intro p hp
  have h : env2362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2361_2362 : H12AffineEnvironment.transform 11 2128 env2361 = env2362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2128 env2361 == env2362) = true)

theorem identity2362 : scanCanonicalize (H12AffineFastState.compose env2362 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound2362 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env2363 : List Nat := [2,4,8,16,32,64,128,252,512,252,194,146,40,107,32,170,146,227,252,32,179,33,185,138,160,232,194,107,106,227,252,0,252,1,146,512]

theorem envBound2363 : H12AffineFastState.Bounded env2363 := by
  intro p hp
  have h : env2363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2362_2363 : H12AffineEnvironment.transform 10 194 env2362 = env2363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env2362 == env2363) = true)

theorem identity2363 : scanCanonicalize (H12AffineFastState.compose env2363 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound2363 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env2364 : List Nat := [2,4,8,16,32,64,19,111,512,111,81,1,40,107,32,57,1,112,111,32,32,33,42,25,51,123,81,107,106,112,111,0,111,1,1,512]

theorem envBound2364 : H12AffineFastState.Bounded env2364 := by
  intro p hp
  have h : env2364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2363_2364 : H12AffineEnvironment.transform 6 19 env2363 = env2364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env2363 == env2364) = true)

theorem identity2364 : scanCanonicalize (H12AffineFastState.compose env2364 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound2364 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2365 : List Nat := [2,4,8,16,32,42,19,5,512,5,59,1,40,1,32,57,1,26,5,32,32,33,42,25,51,17,59,1,0,26,5,0,5,1,1,512]

theorem envBound2365 : H12AffineFastState.Bounded env2365 := by
  intro p hp
  have h : env2365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2364_2365 : H12AffineEnvironment.transform 5 42 env2364 = env2365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env2364 == env2365) = true)

theorem identity2365 : scanCanonicalize (H12AffineFastState.compose env2365 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound2365 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2366 : List Nat := [2,4,8,16,0,10,19,5,512,5,27,1,8,1,0,25,1,26,5,0,0,1,10,25,19,17,27,1,0,26,5,0,5,1,1,512]

theorem envBound2366 : H12AffineFastState.Bounded env2366 := by
  intro p hp
  have h : env2366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2365_2366 : H12AffineEnvironment.transform 4 0 env2365 = env2366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env2365 == env2366) = true)

theorem identity2366 : scanCanonicalize (H12AffineFastState.compose env2366 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound2366 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2367 : List Nat := [2,4,5,16,0,7,19,5,512,5,22,1,5,1,0,20,1,23,5,0,0,1,7,20,19,17,22,1,0,23,5,0,5,1,1,512]

theorem envBound2367 : H12AffineFastState.Bounded env2367 := by
  intro p hp
  have h : env2367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2366_2367 : H12AffineEnvironment.transform 2 5 env2366 = env2367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2366 == env2367) = true)

theorem identity2367 : scanCanonicalize (H12AffineFastState.compose env2367 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound2367 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env2368 : List Nat := [2,4,5,1,0,7,2,5,512,5,7,1,5,1,0,5,1,6,5,0,0,1,7,5,2,0,7,1,0,6,5,0,5,1,1,512]

theorem envBound2368 : H12AffineFastState.Bounded env2368 := by
  intro p hp
  have h : env2368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2367_2368 : H12AffineEnvironment.transform 3 1 env2367 = env2368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env2367 == env2368) = true)

theorem identity2368 : scanCanonicalize (H12AffineFastState.compose env2368 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound2368 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env2369 : List Nat := [2,2,3,1,0,1,2,3,512,3,1,1,3,1,0,3,1,0,3,0,0,1,1,3,2,0,1,1,0,0,3,0,3,1,1,512]

theorem envBound2369 : H12AffineFastState.Bounded env2369 := by
  intro p hp
  have h : env2369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2368_2369 : H12AffineEnvironment.transform 1 2 env2368 = env2369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env2368 == env2369) = true)

def env2370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,16777216,8328,147473,409816,16384,151553,2081,16852468,4341976,256,1,131073,16925299]

theorem envBound2370 : H12AffineFastState.Bounded env2370 := by
  intro p hp
  have h : env2370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2350_2370 : H12AffineEnvironment.transform 34 131073 env2350 = env2370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2350 == env2370) = true)

theorem identity2370 : scanCanonicalize (H12AffineFastState.compose env2370 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2250099) := by decide +kernel

theorem selectedBound2370 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,2097152,4194304,147520,2250099,8328,147473,409816,16384,151553,2081,2322567,4341976,256,1,131073,2103040]

theorem envBound2371 : H12AffineFastState.Bounded env2371 := by
  intro p hp
  have h : env2371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2370_2371 : H12AffineEnvironment.transform 23 2250099 env2370 = env2371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2250099 env2370 == env2371) = true)

theorem identity2371 : scanCanonicalize (H12AffineFastState.compose env2371 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(20+1) ^^^ 153080) := by decide +kernel

theorem selectedBound2371 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,153080,4194304,147520,139,8328,147473,409816,16384,151553,2081,75135,4341976,256,1,131073,148216]

theorem envBound2372 : H12AffineFastState.Bounded env2372 := by
  intro p hp
  have h : env2372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2371_2372 : H12AffineEnvironment.transform 20 153080 env2371 = env2372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 153080 env2371 == env2372) = true)

def env2373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,153080,32,147520,139,8328,147473,409816,16384,151553,2081,75135,147704,256,1,131073,148216]

theorem envBound2373 : H12AffineFastState.Bounded env2373 := by
  intro p hp
  have h : env2373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2372_2373 : H12AffineEnvironment.transform 21 32 env2372 = env2373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env2372 == env2373) = true)

theorem identity2373 : scanCanonicalize (H12AffineFastState.compose env2373 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90502) := by decide +kernel

theorem selectedBound2373 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,90502,262144,1024,8692,78974,32,74182,139,8328,74135,336222,16384,78215,2081,75135,74110,256,1,90503,74622]

theorem envBound2374 : H12AffineFastState.Bounded env2374 := by
  intro p hp
  have h : env2374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2373_2374 : H12AffineEnvironment.transform 16 90502 env2373 = env2374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90502 env2373 == env2374) = true)

theorem identity2374 : scanCanonicalize (H12AffineFastState.compose env2374 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8662) := by decide +kernel

theorem selectedBound2374 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env2375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8662,16464,262144,1024,8692,5544,32,16,139,8328,65,262280,16384,4177,2081,1193,168,256,1,16465,680]

theorem envBound2375 : H12AffineFastState.Bounded env2375 := by
  intro p hp
  have h : env2375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2374_2375 : H12AffineEnvironment.transform 15 8662 env2374 = env2375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8662 env2374 == env2375) = true)

theorem identity2375 : scanCanonicalize (H12AffineFastState.compose env2375 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 12312) := by decide +kernel

theorem selectedBound2375 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,21,23] rootPS < 2^1333 := by decide +kernel

def env2376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12312,8692,8662,12360,262144,1024,8692,5544,32,16,139,8328,65,262280,12312,4177,2081,1193,168,256,1,12361,680]

theorem envBound2376 : H12AffineFastState.Bounded env2376 := by
  intro p hp
  have h : env2376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2375_2376 : H12AffineEnvironment.transform 13 12312 env2375 = env2376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12312 env2375 == env2376) = true)

theorem identity2376 : scanCanonicalize (H12AffineFastState.compose env2376 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound2376 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env2377 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,12312,8540,8574,12360,262144,1024,8540,5376,32,16,35,8224,65,262176,12312,4177,2081,1025,0,256,1,12361,512]

theorem envBound2377 : H12AffineFastState.Bounded env2377 := by
  intro p hp
  have h : env2377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2376_2377 : H12AffineEnvironment.transform 6 40 env2376 = env2377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env2376 == env2377) = true)

theorem identity2377 : scanCanonicalize (H12AffineFastState.compose env2377 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound2377 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env2378 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,12312,8461,8495,12313,262144,1024,8461,5376,32,16,35,8224,16,262176,12312,4096,2081,1025,0,256,1,12312,512]

theorem envBound2378 : H12AffineFastState.Bounded env2378 := by
  intro p hp
  have h : env2378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2377_2378 : H12AffineEnvironment.transform 5 17 env2377 = env2378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env2377 == env2378) = true)

theorem identity2378 : scanCanonicalize (H12AffineFastState.compose env2378 (packedSelected [0,2,4,5,6,7,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 8982) := by decide +kernel

theorem selectedBound2378 : packedSelected [0,2,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env2379 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,12312,8461,8495,12313,8982,1024,8461,5376,32,16,35,8224,16,9014,12312,4096,2081,1025,0,256,1,12312,512]

theorem envBound2379 : H12AffineFastState.Bounded env2379 := by
  intro p hp
  have h : env2379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2378_2379 : H12AffineEnvironment.transform 17 8982 env2378 = env2379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8982 env2378 == env2379) = true)

theorem identity2379 : scanCanonicalize (H12AffineFastState.compose env2379 (packedSelected [0,1,3,6,7,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2871) := by decide +kernel

theorem selectedBound2379 : packedSelected [0,1,3,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env2380 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,2871,6959,2618,2584,6958,2081,1024,2618,5376,32,16,35,2839,16,2049,6959,4096,2081,1025,0,256,1,6959,512]

theorem envBound2380 : H12AffineFastState.Bounded env2380 := by
  intro p hp
  have h : env2380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2379_2380 : H12AffineEnvironment.transform 12 2871 env2379 = env2380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2871 env2379 == env2380) = true)

theorem identity2380 : scanCanonicalize (H12AffineFastState.compose env2380 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound2380 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env2381 : List Nat := [2,4,8,16,32,17,40,256,512,1024,528,4096,295,4415,42,8,4414,561,1024,42,5376,32,16,35,263,16,529,4415,4096,561,1025,0,256,1,4415,512]

theorem envBound2381 : H12AffineFastState.Bounded env2381 := by
  intro p hp
  have h : env2381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2380_2381 : H12AffineEnvironment.transform 10 528 env2380 = env2381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env2380 == env2381) = true)

theorem identity2381 : scanCanonicalize (H12AffineFastState.compose env2381 (packedSelected [1,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound2381 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env2382 : List Nat := [2,4,8,16,32,17,40,256,49,1024,33,4096,295,4415,42,8,4414,0,1024,42,5376,32,16,35,263,16,32,4415,4096,0,1025,0,256,1,4415,49]

theorem envBound2382 : H12AffineFastState.Bounded env2382 := by
  intro p hp
  have h : env2382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2381_2382 : H12AffineEnvironment.transform 8 49 env2381 = env2382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env2381 == env2382) = true)

theorem identity2382 : scanCanonicalize (H12AffineFastState.compose env2382 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound2382 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env2383 : List Nat := [2,4,8,16,32,17,40,256,49,1024,33,1280,295,1087,42,8,1086,0,1024,42,0,32,16,35,263,16,32,1087,1280,0,1025,0,256,1,1087,49]

theorem envBound2383 : H12AffineFastState.Bounded env2383 := by
  intro p hp
  have h : env2383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2382_2383 : H12AffineEnvironment.transform 11 1280 env2382 = env2383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env2382 == env2383) = true)

theorem identity2383 : scanCanonicalize (H12AffineFastState.compose env2383 (packedSelected [0,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound2383 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env2384 : List Nat := [2,4,8,16,32,17,40,256,49,36,33,292,295,27,42,8,26,0,36,42,0,32,16,35,263,16,32,27,292,0,37,0,256,1,27,49]

theorem envBound2384 : H12AffineFastState.Bounded env2384 := by
  intro p hp
  have h : env2384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2383_2384 : H12AffineEnvironment.transform 9 36 env2383 = env2384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env2383 == env2384) = true)

theorem identity2384 : scanCanonicalize (H12AffineFastState.compose env2384 (packedSelected [0,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound2384 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env2385 : List Nat := [2,4,8,16,32,17,40,53,49,36,33,17,18,27,42,8,26,0,36,42,0,32,16,35,50,16,32,27,17,0,37,0,53,1,27,49]

theorem envBound2385 : H12AffineFastState.Bounded env2385 := by
  intro p hp
  have h : env2385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2384_2385 : H12AffineEnvironment.transform 7 53 env2384 = env2385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env2384 == env2385) = true)

theorem identity2385 : scanCanonicalize (H12AffineFastState.compose env2385 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound2385 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2386 : List Nat := [2,4,8,16,28,17,20,9,13,24,29,17,18,27,22,8,26,0,24,22,0,28,16,31,14,16,28,27,17,0,25,0,9,1,27,13]

theorem envBound2386 : H12AffineFastState.Bounded env2386 := by
  intro p hp
  have h : env2386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2385_2386 : H12AffineEnvironment.transform 4 28 env2385 = env2386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env2385 == env2386) = true)

theorem identity2386 : scanCanonicalize (H12AffineFastState.compose env2386 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound2386 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env2387 : List Nat := [2,4,8,11,7,10,15,9,13,3,6,10,9,0,13,8,1,0,3,13,0,7,11,4,14,11,7,0,10,0,2,0,9,1,0,13]

theorem envBound2387 : H12AffineFastState.Bounded env2387 := by
  intro p hp
  have h : env2387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2386_2387 : H12AffineEnvironment.transform 3 11 env2386 = env2387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env2386 == env2387) = true)

theorem identity2387 : scanCanonicalize (H12AffineFastState.compose env2387 (packedSelected [0,11] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound2387 : packedSelected [0,11] rootPS < 2^1333 := by decide +kernel

def env2388 : List Nat := [2,4,5,6,7,7,2,4,0,3,6,7,4,0,0,5,1,0,3,0,0,7,6,4,3,6,7,0,7,0,2,0,4,1,0,0]

theorem envBound2388 : H12AffineFastState.Bounded env2388 := by
  intro p hp
  have h : env2388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2387_2388 : H12AffineEnvironment.transform 2 5 env2387 = env2388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env2387 == env2388) = true)

theorem identity2388 : scanCanonicalize (H12AffineFastState.compose env2388 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound2388 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2389 : List Nat := [2,2,3,0,1,1,2,2,0,3,0,1,2,0,0,3,1,0,3,0,0,1,0,2,3,0,1,0,1,0,2,0,2,1,0,0]

theorem envBound2389 : H12AffineFastState.Bounded env2389 := by
  intro p hp
  have h : env2389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2388_2389 : H12AffineEnvironment.transform 1 2 env2388 = env2389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env2388 == env2389) = true)

def env2390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1024,8692,153080,33,147520,139,8328,147473,409816,16384,151553,2081,75135,147705,256,1,131073,148216]

theorem envBound2390 : H12AffineFastState.Bounded env2390 := by
  intro p hp
  have h : env2390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2372_2390 : H12AffineEnvironment.transform 21 33 env2372 = env2390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env2372 == env2390) = true)

theorem identity2390 : scanCanonicalize (H12AffineFastState.compose env2390 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound2390 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,131072,262144,1024,8692,153080,33,147520,139,8328,147473,409816,16384,151553,2081,1025,147705,256,1,131073,148216]

theorem envBound2391 : H12AffineFastState.Bounded env2391 := by
  intro p hp
  have h : env2391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2390_2391 : H12AffineEnvironment.transform 15 8574 env2390 = env2391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env2390 == env2391) = true)

theorem identity2391 : scanCanonicalize (H12AffineFastState.compose env2391 (packedSelected [1,5,8,17,19,21,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16632) := by decide +kernel

theorem selectedBound2391 : packedSelected [1,5,8,17,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env2392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8574,16632,262144,1024,8692,5376,33,184,139,8328,233,262176,16384,4345,2081,1025,1,256,1,16633,512]

theorem envBound2392 : H12AffineFastState.Bounded env2392 := by
  intro p hp
  have h : env2392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2391_2392 : H12AffineEnvironment.transform 16 16632 env2391 = env2392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env2391 == env2392) = true)

def env2393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,16777216,8328,147472,409817,16384,151553,2081,16852469,4341977,257,1,34359738368,16925298]

theorem envBound2393 : H12AffineFastState.Bounded env2393 := by
  intro p hp
  have h : env2393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2349_2393 : H12AffineEnvironment.transform 18 1025 env2349 = env2393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env2349 == env2393) = true)

def env2394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,16777216,8328,147472,409817,16384,151553,2081,16852469,4341977,257,1,131072,16925298]

theorem envBound2394 : H12AffineFastState.Bounded env2394 := by
  intro p hp
  have h : env2394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2393_2394 : H12AffineEnvironment.transform 34 131072 env2393 = env2394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env2393 == env2394) = true)

theorem identity2394 : scanCanonicalize (H12AffineFastState.compose env2394 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 16435) := by decide +kernel

theorem selectedBound2394 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,16435,8328,147472,409817,16384,151553,2081,91590,4341977,257,1,131072,131649]

theorem envBound2395 : H12AffineFastState.Bounded env2395 := by
  intro p hp
  have h : env2395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2394_2395 : H12AffineEnvironment.transform 23 16435 env2394 = env2395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 16435 env2394 == env2395) = true)

theorem identity2395 : scanCanonicalize (H12AffineFastState.compose env2395 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound2395 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,293,147520,16435,8328,147472,409817,16384,151553,2081,91590,147964,257,1,131072,131649]

theorem envBound2396 : H12AffineFastState.Bounded env2396 := by
  intro p hp
  have h : env2396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2395_2396 : H12AffineEnvironment.transform 21 293 env2395 = env2396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env2395 == env2396) = true)

def env2397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,64,262144,1025,8692,2097152,293,16384,16435,8328,16464,278681,16384,20545,2081,91590,16828,257,1,64,513]

theorem envBound2397 : H12AffineFastState.Bounded env2397 := by
  intro p hp
  have h : env2397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2396_2397 : H12AffineEnvironment.transform 16 64 env2396 = env2397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 64 env2396 == env2397) = true)

theorem identity2397 : scanCanonicalize (H12AffineFastState.compose env2397 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4436) := by decide +kernel

theorem selectedBound2397 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,64,262144,1025,8692,4436,293,16384,16435,8328,16464,278681,16384,20545,2081,91590,16828,257,1,64,513]

theorem envBound2398 : H12AffineFastState.Bounded env2398 := by
  intro p hp
  have h : env2398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2397_2398 : H12AffineEnvironment.transform 20 4436 env2397 = env2398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4436 env2397 == env2398) = true)

theorem identity2398 : scanCanonicalize (H12AffineFastState.compose env2398 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound2398 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,24771,64,262144,1025,8692,4436,293,16384,16435,8328,16464,278681,16384,20545,2081,1285,16828,257,1,64,513]

theorem envBound2399 : H12AffineFastState.Bounded env2399 := by
  intro p hp
  have h : env2399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2398_2399 : H12AffineEnvironment.transform 15 24771 env2398 = env2399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env2398 == env2399) = true)

theorem identity2399 : scanCanonicalize (H12AffineFastState.compose env2399 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound2399 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env2400 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,24771,64,262144,1025,8200,4264,217,16384,16435,8328,16464,278681,16384,20545,2081,1273,16448,253,1,64,513]

theorem envBound2400 : H12AffineFastState.Bounded env2400 := by
  intro p hp
  have h : env2400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2399_2400 : H12AffineEnvironment.transform 7 252 env2399 = env2400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env2399 == env2400) = true)

theorem identity2400 : scanCanonicalize (H12AffineFastState.compose env2400 (packedSelected [1,3,4,9,20,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 65) := by decide +kernel

theorem selectedBound2400 : packedSelected [1,3,4,9,20,24,28] rootPS < 2^1333 := by decide +kernel

def env2401 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,65,8200,8322,64,262144,1025,8200,4264,217,65,114,8328,17,262360,65,4096,2081,1273,1,253,1,64,513]

theorem envBound2401 : H12AffineFastState.Bounded env2401 := by
  intro p hp
  have h : env2401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2400_2401 : H12AffineEnvironment.transform 13 65 env2400 = env2401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 65 env2400 == env2401) = true)

theorem identity2401 : scanCanonicalize (H12AffineFastState.compose env2401 (packedSelected [0,3,5,7,10,13,17,20] rootPS)) = affineNative (2^(11+1) ^^^ 248) := by decide +kernel

theorem selectedBound2401 : packedSelected [0,3,5,7,10,13,17,20] rootPS < 2^1333 := by decide +kernel

def env2402 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,248,8192,65,8200,8322,64,262144,1025,8200,80,217,65,114,8328,17,262360,65,248,2081,1273,1,253,1,64,513]

theorem envBound2402 : H12AffineFastState.Bounded env2402 := by
  intro p hp
  have h : env2402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2401_2402 : H12AffineEnvironment.transform 11 248 env2401 = env2402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 248 env2401 == env2402) = true)

theorem identity2402 : scanCanonicalize (H12AffineFastState.compose env2402 (packedSelected [0,1,4,7,8,9,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 1069) := by decide +kernel

theorem selectedBound2402 : packedSelected [0,1,4,7,8,9,13,17] rootPS < 2^1333 := by decide +kernel

def env2403 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,248,1069,65,1061,1199,64,262144,1025,1061,80,217,65,114,1189,17,262360,65,248,2081,1273,1,253,1,64,513]

theorem envBound2403 : H12AffineFastState.Bounded env2403 := by
  intro p hp
  have h : env2403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2402_2403 : H12AffineEnvironment.transform 12 1069 env2402 = env2403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1069 env2402 == env2403) = true)

theorem identity2403 : scanCanonicalize (H12AffineFastState.compose env2403 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound2403 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2404 : List Nat := [2,4,8,16,32,64,128,252,512,140,2048,248,161,65,169,35,64,262144,141,169,80,217,65,114,41,17,262360,65,248,2081,117,1,253,1,64,513]

theorem envBound2404 : H12AffineFastState.Bounded env2404 := by
  intro p hp
  have h : env2404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2403_2404 : H12AffineEnvironment.transform 9 140 env2403 = env2404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env2403 == env2404) = true)

theorem identity2404 : scanCanonicalize (H12AffineFastState.compose env2404 (packedSelected [0,7,10,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound2404 : packedSelected [0,7,10,12,13] rootPS < 2^1333 := by decide +kernel

def env2405 : List Nat := [2,4,8,16,32,64,89,37,512,85,2048,33,120,65,112,35,64,262144,84,112,80,0,65,114,41,17,262145,65,33,2081,117,1,36,1,64,513]

theorem envBound2405 : H12AffineFastState.Bounded env2405 := by
  intro p hp
  have h : env2405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2404_2405 : H12AffineEnvironment.transform 6 89 env2404 = env2405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env2404 == env2405) = true)

theorem identity2405 : scanCanonicalize (H12AffineFastState.compose env2405 (packedSelected [0,1,3,5,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound2405 : packedSelected [0,1,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env2406 : List Nat := [2,4,8,16,32,64,89,37,512,85,48,33,120,65,112,35,64,262144,84,112,80,0,65,114,41,17,262145,65,33,17,117,1,36,1,64,513]

theorem envBound2406 : H12AffineFastState.Bounded env2406 := by
  intro p hp
  have h : env2406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2405_2406 : H12AffineEnvironment.transform 10 48 env2405 = env2406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env2405 == env2406) = true)

theorem identity2406 : scanCanonicalize (H12AffineFastState.compose env2406 (packedSelected [0,1,3,5,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 619) := by decide +kernel

theorem selectedBound2406 : packedSelected [0,1,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env2407 : List Nat := [2,4,8,16,32,64,89,37,512,85,48,33,120,65,112,35,64,619,84,112,80,0,65,114,41,17,618,65,33,17,117,1,36,1,64,513]

theorem envBound2407 : H12AffineFastState.Bounded env2407 := by
  intro p hp
  have h : env2407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2406_2407 : H12AffineEnvironment.transform 17 619 env2406 = env2407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 619 env2406 == env2407) = true)

theorem identity2407 : scanCanonicalize (H12AffineFastState.compose env2407 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound2407 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env2408 : List Nat := [2,4,8,16,32,17,8,37,512,4,48,33,41,16,33,35,17,570,5,33,1,0,16,35,41,17,571,16,33,17,36,1,36,1,17,513]

theorem envBound2408 : H12AffineFastState.Bounded env2408 := by
  intro p hp
  have h : env2408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2407_2408 : H12AffineEnvironment.transform 5 17 env2407 = env2408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env2407 == env2408) = true)

theorem identity2408 : scanCanonicalize (H12AffineFastState.compose env2408 (packedSelected [3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 54) := by decide +kernel

theorem selectedBound2408 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env2409 : List Nat := [2,4,8,16,32,17,8,37,54,4,48,33,41,16,33,35,17,12,5,33,1,0,16,35,41,17,13,16,33,17,36,1,36,1,17,55]

theorem envBound2409 : H12AffineFastState.Bounded env2409 := by
  intro p hp
  have h : env2409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2408_2409 : H12AffineEnvironment.transform 8 54 env2408 = env2409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 54 env2408 == env2409) = true)

theorem identity2409 : scanCanonicalize (H12AffineFastState.compose env2409 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound2409 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env2410 : List Nat := [2,4,8,16,1,17,8,4,23,4,17,0,8,16,0,2,17,12,5,0,1,0,16,2,8,17,13,16,0,17,5,1,5,1,17,22]

theorem envBound2410 : H12AffineFastState.Bounded env2410 := by
  intro p hp
  have h : env2410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2409_2410 : H12AffineEnvironment.transform 4 1 env2409 = env2410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env2409 == env2410) = true)

theorem identity2410 : scanCanonicalize (H12AffineFastState.compose env2410 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound2410 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2411 : List Nat := [2,4,8,0,1,1,8,4,7,4,1,0,8,0,0,2,1,12,5,0,1,0,0,2,8,1,13,0,0,1,5,1,5,1,1,6]

theorem envBound2411 : H12AffineFastState.Bounded env2411 := by
  intro p hp
  have h : env2411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2410_2411 : H12AffineEnvironment.transform 3 0 env2410 = env2411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env2410 == env2411) = true)

theorem identity2411 : scanCanonicalize (H12AffineFastState.compose env2411 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound2411 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2412 : List Nat := [2,4,6,0,1,1,6,4,7,4,1,0,6,0,0,2,1,2,5,0,1,0,0,2,6,1,3,0,0,1,5,1,5,1,1,6]

theorem envBound2412 : H12AffineFastState.Bounded env2412 := by
  intro p hp
  have h : env2412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2411_2412 : H12AffineEnvironment.transform 2 6 env2411 = env2412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env2411 == env2412) = true)

theorem identity2412 : scanCanonicalize (H12AffineFastState.compose env2412 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound2412 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env2413 : List Nat := [2,3,1,0,1,1,1,3,0,3,1,0,1,0,0,2,1,2,2,0,1,0,0,2,1,1,3,0,0,1,2,1,2,1,1,1]

theorem envBound2413 : H12AffineFastState.Bounded env2413 := by
  intro p hp
  have h : env2413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2412_2413 : H12AffineEnvironment.transform 1 3 env2412 = env2413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env2412 == env2413) = true)

def env2414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,65,262144,1025,8692,2097152,293,16385,16435,8328,16465,278680,16384,20544,2081,91590,16829,257,1,65,512]

theorem envBound2414 : H12AffineFastState.Bounded env2414 := by
  intro p hp
  have h : env2414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2396_2414 : H12AffineEnvironment.transform 16 65 env2396 = env2414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 65 env2396 == env2414) = true)

theorem identity2414 : scanCanonicalize (H12AffineFastState.compose env2414 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound2414 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2415 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8433,65536,65,262144,1025,8433,2097152,32,16385,16435,8328,16465,278680,16384,20544,2081,91331,16568,4,1,65,512]

theorem envBound2415 : H12AffineFastState.Bounded env2415 := by
  intro p hp
  have h : env2415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2414_2415 : H12AffineEnvironment.transform 7 5 env2414 = env2415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env2414 == env2415) = true)

theorem identity2415 : scanCanonicalize (H12AffineFastState.compose env2415 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound2415 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2416 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8433,8314,65,262144,1025,8433,2097152,32,16385,16435,8328,16465,278680,16384,20544,2081,17593,16568,4,1,65,512]

theorem envBound2416 : H12AffineFastState.Bounded env2416 := by
  intro p hp
  have h : env2416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2415_2416 : H12AffineEnvironment.transform 15 8314 env2415 = env2416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env2415 == env2416) = true)

theorem identity2416 : scanCanonicalize (H12AffineFastState.compose env2416 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound2416 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env2417 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,185,8433,8314,65,262144,1025,8433,2097152,32,184,138,8328,232,262177,185,4345,2081,1024,1,4,1,65,512]

theorem envBound2417 : H12AffineFastState.Bounded env2417 := by
  intro p hp
  have h : env2417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2416_2417 : H12AffineEnvironment.transform 13 185 env2416 = env2417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env2416 == env2417) = true)

theorem identity2417 : scanCanonicalize (H12AffineFastState.compose env2417 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 11438) := by decide +kernel

theorem selectedBound2417 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env2418 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,185,8433,8314,65,262144,1025,8433,11438,32,184,138,8328,232,262177,185,4345,2081,1024,1,4,1,65,512]

theorem envBound2418 : H12AffineFastState.Bounded env2418 := by
  intro p hp
  have h : env2418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2417_2418 : H12AffineEnvironment.transform 20 11438 env2417 = env2418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11438 env2417 == env2418) = true)

theorem identity2418 : scanCanonicalize (H12AffineFastState.compose env2418 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 2265) := by decide +kernel

theorem selectedBound2418 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env2419 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,185,8433,8314,65,2265,1025,8433,11438,32,184,138,8328,232,2296,185,4345,2081,1024,1,4,1,65,512]

theorem envBound2419 : H12AffineFastState.Bounded env2419 := by
  intro p hp
  have h : env2419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2418_2419 : H12AffineEnvironment.transform 17 2265 env2418 = env2419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2265 env2418 == env2419) = true)

theorem identity2419 : scanCanonicalize (H12AffineFastState.compose env2419 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound2419 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env2420 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,4096,8192,65,8201,8314,65,2081,1025,8201,11350,32,64,114,8304,16,2048,65,4097,2081,1024,1,4,1,65,512]

theorem envBound2420 : H12AffineFastState.Bounded env2420 := by
  intro p hp
  have h : env2420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2419_2420 : H12AffineEnvironment.transform 6 120 env2419 = env2420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env2419 == env2420) = true)

theorem identity2420 : scanCanonicalize (H12AffineFastState.compose env2420 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound2420 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2421 : List Nat := [2,4,8,16,32,1,57,5,512,1024,2048,4096,8192,0,8201,8251,0,2081,1025,8201,11287,32,1,51,8241,16,2048,0,4097,2081,1024,1,4,1,0,512]

theorem envBound2421 : H12AffineFastState.Bounded env2421 := by
  intro p hp
  have h : env2421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2420_2421 : H12AffineEnvironment.transform 5 1 env2420 = env2421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env2420 == env2421) = true)

theorem identity2421 : scanCanonicalize (H12AffineFastState.compose env2421 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound2421 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env2422 : List Nat := [2,4,8,16,32,1,57,5,512,1024,42,4096,8192,0,8201,8251,0,11,1025,8201,9277,32,1,51,8241,16,42,0,4097,11,1024,1,4,1,0,512]

theorem envBound2422 : H12AffineFastState.Bounded env2422 := by
  intro p hp
  have h : env2422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2421_2422 : H12AffineEnvironment.transform 10 42 env2421 = env2422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env2421 == env2422) = true)

theorem identity2422 : scanCanonicalize (H12AffineFastState.compose env2422 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound2422 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2423 : List Nat := [2,4,8,16,32,1,57,5,512,1024,42,4096,1030,0,1039,1085,0,11,1025,1039,59,32,1,51,1079,16,42,0,4097,11,1024,1,4,1,0,512]

theorem envBound2423 : H12AffineFastState.Bounded env2423 := by
  intro p hp
  have h : env2423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2422_2423 : H12AffineEnvironment.transform 12 1030 env2422 = env2423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env2422 == env2423) = true)

theorem identity2423 : scanCanonicalize (H12AffineFastState.compose env2423 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound2423 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env2424 : List Nat := [2,4,8,16,16,1,9,5,512,1024,26,4096,1030,0,1039,1037,0,11,1025,1039,11,16,1,3,1031,16,26,0,4097,11,1024,1,4,1,0,512]

theorem envBound2424 : H12AffineFastState.Bounded env2424 := by
  intro p hp
  have h : env2424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2423_2424 : H12AffineEnvironment.transform 4 16 env2423 = env2424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env2423 == env2424) = true)

theorem identity2424 : scanCanonicalize (H12AffineFastState.compose env2424 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound2424 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env2425 : List Nat := [2,4,8,0,0,1,9,5,512,1024,10,4096,1030,0,1039,1037,0,11,1025,1039,11,0,1,3,1031,0,10,0,4097,11,1024,1,4,1,0,512]

theorem envBound2425 : H12AffineFastState.Bounded env2425 := by
  intro p hp
  have h : env2425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2424_2425 : H12AffineEnvironment.transform 3 0 env2424 = env2425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env2424 == env2425) = true)

def env2426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,16777216,8328,147472,409817,16384,151553,2081,16852469,4341977,257,1,131073,16925298]

theorem envBound2426 : H12AffineFastState.Bounded env2426 := by
  intro p hp
  have h : env2426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2393_2426 : H12AffineEnvironment.transform 34 131073 env2393 = env2426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env2393 == env2426) = true)

theorem identity2426 : scanCanonicalize (H12AffineFastState.compose env2426 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2117683) := by decide +kernel

theorem selectedBound2426 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147520,2117683,8328,147472,409817,16384,151553,2081,2192838,4341977,257,1,131073,2232897]

theorem envBound2427 : H12AffineFastState.Bounded env2427 := by
  intro p hp
  have h : env2427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2426_2427 : H12AffineEnvironment.transform 23 2117683 env2426 = env2427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2117683 env2426 == env2427) = true)

theorem identity2427 : scanCanonicalize (H12AffineFastState.compose env2427 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound2427 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env2428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8314,131072,262144,1025,8692,2097152,4194304,147520,2117683,8328,147472,409817,16384,151553,2081,2119100,4341977,257,1,131073,2232897]

theorem envBound2428 : H12AffineFastState.Bounded env2428 := by
  intro p hp
  have h : env2428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2427_2428 : H12AffineEnvironment.transform 15 8314 env2427 = env2428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env2427 == env2428) = true)

def env2429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8314,131072,262144,1025,8692,135232,4194304,147520,147571,8328,147472,409817,16384,151553,2081,148988,4341977,257,1,131073,513]

theorem envBound2429 : H12AffineFastState.Bounded env2429 := by
  intro p hp
  have h : env2429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2428_2429 : H12AffineEnvironment.transform 20 135232 env2428 = env2429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 135232 env2428 == env2429) = true)

theorem identity2429 : scanCanonicalize (H12AffineFastState.compose env2429 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 131121) := by decide +kernel

theorem selectedBound2429 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8314,131072,262144,1025,8692,135232,131121,147520,147571,8328,147472,409817,16384,151553,2081,148988,16616,257,1,131073,513]

theorem envBound2430 : H12AffineFastState.Bounded env2430 := by
  intro p hp
  have h : env2430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2429_2430 : H12AffineEnvironment.transform 21 131121 env2429 = env2430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 131121 env2429 == env2430) = true)

theorem identity2430 : scanCanonicalize (H12AffineFastState.compose env2430 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 493) := by decide +kernel

theorem selectedBound2430 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,493,8692,8314,131072,262144,1025,8692,135232,131121,131501,131486,8328,131581,393524,493,135660,2081,132113,261,257,1,131073,513]

theorem envBound2431 : H12AffineFastState.Bounded env2431 := by
  intro p hp
  have h : env2431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2430_2431 : H12AffineEnvironment.transform 13 493 env2430 = env2431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 493 env2430 == env2431) = true)

theorem identity2431 : scanCanonicalize (H12AffineFastState.compose env2431 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 233) := by decide +kernel

theorem selectedBound2431 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env2432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,493,8692,8314,233,262144,1025,8692,4265,216,324,375,8328,276,262621,493,4357,2081,1272,261,257,1,232,513]

theorem envBound2432 : H12AffineFastState.Bounded env2432 := by
  intro p hp
  have h : env2432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2431_2432 : H12AffineEnvironment.transform 16 233 env2431 = env2432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 233 env2431 == env2432) = true)

theorem identity2432 : scanCanonicalize (H12AffineFastState.compose env2432 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1520) := by decide +kernel

theorem selectedBound2432 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env2433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1520,493,1028,1418,233,262144,1025,1028,4265,216,324,375,1400,276,262621,493,4357,2081,1272,261,257,1,232,513]

theorem envBound2433 : H12AffineFastState.Bounded env2433 := by
  intro p hp
  have h : env2433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2432_2433 : H12AffineEnvironment.transform 12 1520 env2432 = env2433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1520 env2432 == env2433) = true)

theorem identity2433 : scanCanonicalize (H12AffineFastState.compose env2433 (packedSelected [3,4,5,9,10,13,17,18,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 2265) := by decide +kernel

theorem selectedBound2433 : packedSelected [3,4,5,9,10,13,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env2434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1520,493,1028,1418,233,2265,1025,1028,4265,216,324,375,1400,276,2308,493,4357,2081,1272,261,257,1,232,513]

theorem envBound2434 : H12AffineFastState.Bounded env2434 := by
  intro p hp
  have h : env2434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2433_2434 : H12AffineEnvironment.transform 17 2265 env2433 = env2434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2265 env2433 == env2434) = true)

theorem identity2434 : scanCanonicalize (H12AffineFastState.compose env2434 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound2434 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env2435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,169,4096,1520,493,1028,1418,233,112,1025,1028,4265,216,324,375,1400,276,429,493,4357,136,1272,261,257,1,232,513]

theorem envBound2435 : H12AffineFastState.Bounded env2435 := by
  intro p hp
  have h : env2435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2434_2435 : H12AffineEnvironment.transform 10 169 env2434 = env2435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env2434 == env2435) = true)

theorem identity2435 : scanCanonicalize (H12AffineFastState.compose env2435 (packedSelected [2,3,5,6,10,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound2435 : packedSelected [2,3,5,6,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env2436 : List Nat := [2,4,8,16,32,64,128,256,512,288,169,4096,208,493,292,170,233,112,289,292,4265,216,324,375,88,276,429,493,4357,136,472,261,257,1,232,513]

theorem envBound2436 : H12AffineFastState.Bounded env2436 := by
  intro p hp
  have h : env2436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2435_2436 : H12AffineEnvironment.transform 9 288 env2435 = env2436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env2435 == env2436) = true)

theorem identity2436 : scanCanonicalize (H12AffineFastState.compose env2436 (packedSelected [1,2,6,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound2436 : packedSelected [1,2,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env2437 : List Nat := [2,4,8,16,32,64,128,256,42,288,169,4096,208,493,292,170,233,112,289,292,4265,216,324,375,88,276,429,493,4357,136,472,261,257,1,232,43]

theorem envBound2437 : H12AffineFastState.Bounded env2437 := by
  intro p hp
  have h : env2437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2436_2437 : H12AffineEnvironment.transform 8 42 env2436 = env2437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env2436 == env2437) = true)

theorem identity2437 : scanCanonicalize (H12AffineFastState.compose env2437 (packedSelected [0,1,2,3,5,7,8,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound2437 : packedSelected [0,1,2,3,5,7,8,13,17] rootPS < 2^1333 := by decide +kernel

def env2438 : List Nat := [2,4,8,16,32,64,128,256,42,288,169,1,208,493,292,170,233,112,289,292,168,216,324,375,88,276,429,493,260,136,472,261,257,1,232,43]

theorem envBound2438 : H12AffineFastState.Bounded env2438 := by
  intro p hp
  have h : env2438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2437_2438 : H12AffineEnvironment.transform 11 1 env2437 = env2438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env2437 == env2438) = true)

theorem identity2438 : scanCanonicalize (H12AffineFastState.compose env2438 (packedSelected [1,2,4,6,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound2438 : packedSelected [1,2,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env2439 : List Nat := [2,4,8,16,32,64,128,117,42,85,169,1,208,152,81,170,233,112,84,81,168,216,49,2,88,97,216,152,113,136,173,112,116,1,232,43]

theorem envBound2439 : H12AffineFastState.Bounded env2439 := by
  intro p hp
  have h : env2439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2438_2439 : H12AffineEnvironment.transform 7 117 env2438 = env2439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env2438 == env2439) = true)

theorem identity2439 : scanCanonicalize (H12AffineFastState.compose env2439 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound2439 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env2440 : List Nat := [2,4,8,16,32,49,128,4,42,36,169,1,161,152,32,170,152,1,37,32,168,169,49,2,41,16,169,152,0,136,173,1,5,1,153,43]

theorem envBound2440 : H12AffineFastState.Bounded env2440 := by
  intro p hp
  have h : env2440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2439_2440 : H12AffineEnvironment.transform 5 49 env2439 = env2440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env2439 == env2440) = true)

theorem identity2440 : scanCanonicalize (H12AffineFastState.compose env2440 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound2440 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2441 : List Nat := [2,4,8,16,1,16,128,4,11,5,136,1,128,152,1,139,152,1,4,1,137,136,16,2,8,16,136,152,0,136,140,1,5,1,153,10]

theorem envBound2441 : H12AffineFastState.Bounded env2441 := by
  intro p hp
  have h : env2441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2440_2441 : H12AffineEnvironment.transform 4 1 env2440 = env2441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env2440 == env2441) = true)

theorem identity2441 : scanCanonicalize (H12AffineFastState.compose env2441 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound2441 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env2442 : List Nat := [2,4,8,14,1,14,128,4,11,5,136,1,128,134,1,139,134,1,4,1,137,136,14,2,8,14,136,134,0,136,140,1,5,1,135,10]

theorem envBound2442 : H12AffineFastState.Bounded env2442 := by
  intro p hp
  have h : env2442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2441_2442 : H12AffineEnvironment.transform 3 14 env2441 = env2442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env2441 == env2442) = true)

theorem identity2442 : scanCanonicalize (H12AffineFastState.compose env2442 (packedSelected [0,2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound2442 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env2443 : List Nat := [0,4,8,12,1,12,128,4,9,5,136,1,128,132,1,137,132,1,4,1,137,136,12,0,8,12,136,132,0,136,140,1,5,1,133,8]

theorem envBound2443 : H12AffineFastState.Bounded env2443 := by
  intro p hp
  have h : env2443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2442_2443 : H12AffineEnvironment.transform 0 0 env2442 = env2443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env2442 == env2443) = true)

theorem identity2443 : scanCanonicalize (H12AffineFastState.compose env2443 (packedSelected [8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound2443 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env2444 : List Nat := [0,4,8,12,1,12,8,4,9,5,0,1,8,12,1,1,12,1,4,1,1,0,12,0,8,12,0,12,0,0,4,1,5,1,13,8]

theorem envBound2444 : H12AffineFastState.Bounded env2444 := by
  intro p hp
  have h : env2444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2443_2444 : H12AffineEnvironment.transform 6 8 env2443 = env2444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env2443 == env2444) = true)

theorem identity2444 : scanCanonicalize (H12AffineFastState.compose env2444 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound2444 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2445 : List Nat := [0,4,4,0,1,0,4,4,5,5,0,1,4,0,1,1,0,1,4,1,1,0,0,0,4,0,0,0,0,0,4,1,5,1,1,4]

theorem envBound2445 : H12AffineFastState.Bounded env2445 := by
  intro p hp
  have h : env2445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2444_2445 : H12AffineEnvironment.transform 2 4 env2444 = env2445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env2444 == env2445) = true)

theorem identity2445 : scanCanonicalize (H12AffineFastState.compose env2445 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound2445 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env2446 : List Nat := [0,1,1,0,1,0,1,1,0,0,0,1,1,0,1,1,0,1,1,1,1,0,0,0,1,0,0,0,0,0,1,1,0,1,1,1]

theorem envBound2446 : H12AffineFastState.Bounded env2446 := by
  intro p hp
  have h : env2446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1